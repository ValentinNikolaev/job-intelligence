# Director Process Management (m/w/d)

Posted: 2026-08-17T20:29:46Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**Warum Wir?**

Bei uns erwarten Dich weltweit verteilte, internationale Teams, flache Hierarchien und eine offene Unternehmenskultur, die zum Mitgestalten einlädt. Mobiles Arbeiten und flexible Arbeitszeiten gehören für uns zum Alltag. Möchtest Du Teil eines innovativen Unternehmens werden, dessen Lösung den Arbeitsalltag in unterschiedlichsten Branchen digitalisiert? Dann werde Teil unseres Teams!

**Das erwartet Dich**

Als Director Process Management (m/w/d) übernimmst Du die strategische Leitung des Prozessmanagements im Bereich IT-Infrastructure & Process Excellence und verantwortest den gesamten Prozesslebenszyklus – von der Gestaltung bis zur Optimierung. Du führst interdisziplinäre Teams, verbesserst Prozesse kontinuierlich und sorgst dafür, dass unsere Prozesslandschaft effizient, integriert und zukunftsfähig bleibt.

Zu Deinen Aufgaben gehören:

- Du leitest interdisziplinäre Teams (Business Process Consultants, Service-, Quality- und Knowledge Management), verantwortest Budget und Ressourcen und präsentierst Management-Reports und Empfehlungen auf C-Level.
- Du gestaltest, dokumentierst und optimierst Geschäftsprozesse end-to-end und setzt dabei innovative Technologien und Automatisierungslösungen ein.
- Du schaffst eine enge Zusammenarbeit zwischen Prozessverantwortlichen und Systemverantwortlichen, um reibungslose digitale Transformation und langfristige Zukunftsfähigkeit sicherzustellen.
- Du begleitest die Entwicklung neuer Prozesse, unterstützt die Prozessverantwortlichen durch Training und Integration in interne Softwaresysteme und findest datenbasierte Optimierungspotenziale.
- Du überwachst die Prozess- und Qualitätsmanagement-Systeme, stellst Compliance (z.B. ISO 9001) und Auditbereitschaft sicher.
- Du entwickelst Knowledge Management- und Prozessdigitalisierungsstrategien, förderst organisationsweites Lernen und Integration mit IT und Business-Systemen.

**Das bringst Du mit**

- Du hast ein abgeschlossenes Studium (Bachelor/Master) in BWL, Wirtschaftsingenieurwesen, IT oder einem verwandten Bereich.
- Du bringst langjährige Erfahrung im Prozessmanagement, Consulting oder Transformation mit und hast führungsstarke Kompetenzen bewiesen.
- Du beherrschst Prozessdesign, Implementierung, Lifecycle-Management und gängige Methoden (z. B. BPMN, Lean, Six Sigma, ITIL, ISO 9001).
- Du bist kommunikationsstark, kannst Stakeholder auf allen Ebenen überzeugen und baust erfolgreich Konsens auf.
- Du gehst strategisch, analytisch und lösungsorientiert vor, hast einen starken Fokus auf Effizienz und Durchsatz – und bringst Projektmanagement-Erfahrung in komplexen Organisationsstrukturen mit.
- Anpassungsfähigkeit, Innovationsgeist und Kundenorientierung zeichnen Dich ebenso aus wie die Motivation, eine serviceorientierte und qualitätsstarke Unternehmenskultur voranzutreiben.
- Du kommunizierst fließend in Deutsch und Englisch und agierst souverän auf allen Ebenen.

**Darauf kannst Du Dich freuen**

Es gibt viele gute Gründe für DocuWare – unsere Unternehmenskultur ist nur einer davon.
Im Team von DocuWare profitierst auch Du von diesen Vorteilen:

- **Weltweit verteilte, internationale Teams:** Du triffst uns in Germering, New York, Sofia oder vielen anderen Locations.
- **Flexibler Arbeitsort und Arbeitszeit:** Du arbeitest mobil oder in unserem modernen und gut ausgestattetem Büro – dabei teilst Du Dir deine Arbeitszeit flexibel ein.
- **Individuelle Förderung:** Nach einer intensiven Einarbeitung bekommst Du regelmäßig auf Dich zugeschnittene Weiterbildungen (u.a. Kongresse, interne Teambuilding Maßnahmen).
- **Wohl verdiente Erholung:** Neben 35 Urlaubstagen im Jahr bieten wir Dir ein breites Sport- und Massageangebot, Kicker-Tisch und einen entspannenden Lounge-Bereich.
- **Gesunde Ernährung:** Zusammen genießen wir Fairtrade Kaffee mit Bio-Milch oder HaferDrink, Snacks und frisches Obst – alles kostenlos – sowie bezuschussten Lunch aus dem Foodji-Kühlschrank.
- **Team-Spirit:** Regelmäßige Events für Mitarbeitende - virtuell oder vor Ort sorgen für Zusammenhalt.
- **Nachhaltigkeit und soziales Engagement:** DocuWare steht für papierloses Arbeiten und unterstützt ehrenamtliche Organisationen und lokale Sportvereine.
- **Gute Erreichbarkeit auf allen Wegen:** Komm ins Büro mit dem geleasten E-Bike (Jobrad), per S-Bahn oder über die Autobahnen A96/A99 (Dein E-Auto kannst Du vor Ort kostenlos laden).
- **Du sorgst vor & wir unterstützen Dich dabei:** DocuWare bezuschusst Deine betriebliche Altersvorsorge.
- **Ein stabiler Arbeitsplatz:** In unserem langjährig bestehenden und stetig wachsenden Unternehmen erhältst Du eine unbefristete Festanstellung.
- **Wir nutzen immer die neuesten Technologien:** Erfahre mehr auf Stackshare.
- **Einzigartige Vorteile:** Wähle eine von drei großartigen Optionen (Bonago, E-Gym oder Bezuschussung des Deutschlandtickets) nach Deinen Bedürfnissen.
- **30 Tage Work from Abroad:** Erlebe internationale Erfahrungen und erweitere Deinen Horizont.
- **Family First:** Bevorzugte Anmeldung in unserer ausgewählten Kindertagesstätte in Germering (keine Garantie).
- **Buddy Programm:** Du erhältst einen Buddy, der Dir den Einstieg erleichtert und Dich in Deinen ersten Wochen bei DocuWare unterstützt.
Für noch mehr Einblicke, schau doch gerne auf unserem [Instagram](https://www.instagram.com/life.at.docuware/) vorbei!

**Kontaktperson**

Anja Krieling
Recruiting Specialist & Employer Branding

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
