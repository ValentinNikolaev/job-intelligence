# (Senior) Direct Response Copywriter (m/w/d) - 100% remote

Posted: 2026-08-17T15:30:27Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**"Damit Sie wieder die Dinge tun können, die Ihnen Freude bereiten."**

Unter diesem Motto entwickeln wir bei **Health Routine** natürliche Produkte, die wirken.

Speziell für Menschen über 50, die nicht mehr alles hinnehmen wollen, was „normal“ sein soll.

Und unsere Marke ist dabei längst kein Geheimtipp mehr.

Über **1.000.000 Kunden** vertrauen bereits auf unsere Produkte.

Weil wir nicht nur versprechen, sondern wirklich helfen (mit Garantie).

Unser Ziel? Die **bekannteste Gesundheitsmarke für Menschen über 50** zu werden – mit modernen Produkten, smarter Kommunikation und ehrlichem Impact.

Jetzt bauen wir das **stärkste Copy-Team im DACH-Raum** – und dafür brauchen wir Dich als **Direct Response Copywriter/in** (m/w/d) in Vollzeit.

## Aufgaben

**Deine Mission: Du schreibst, was wirklich bewegt ... und verkauft.**

Wir suchen jemanden, der Menschen über 50 besser versteht, als ihre Hausärztin.

- **Du schreibst Texte, die wirken:** Sales Pages, Advertorials, VSLs. Du bringst unsere Produkte so rüber, dass sich unsere Zielgruppe verstanden fühlt. Und überzeugt klickt.

- **Du denkst wie unsere Kunden:** Du verstehst ihre Sorgen, Ängste und Bedürfnisse - und bringst das auf den Punkt.

- **Du arbeitest eng mit Media Buying & Creative zusammen:** Gemeinsam wertet ihr Reportings aus, entwickelt Konzepte und optimiert Kampagnen.

Was **NICHT** zu deinen Aufgaben gehört:

- Du musst **keine SEO-Texte** schreiben oder **Blogartikel pflegen.**

- Du bist **nicht für den Social Media Kalender** zuständig – aber Du darfst gerne kreative Ideen für Paid Video Ads liefern.

- Du musst **nicht mit Content Creatorn schreiben** oder sie briefen – unser Creative-Team kümmert sich darum.

Zusammengefasst: Dein Schwerpunkt liegt auf **verkaufsstarker Copy** mit klarem Ziel: **Neukunden gewinnen**.

## Qualifikation

- Du bringst bereits **relevante Erfahrung im (Direct Response) Copywriting mit** und hast bereits fundierte Marketingkenntnisse.

- Du nutzt **moderne AI-Tools** für Zielgruppen- und Wettbewerbsrecherche, Voice-of-Customer-Analysen, die Entwicklung neuer Angles und die schnelle Erstellung von Copy-Varianten. Mithilfe von AI-Bildgenerierung machst Du Deine Ideen außerdem visuell greifbar.

- Du bist aufgeschlossen und bereit, **Neues auszuprobieren**. Uns geht es darum, schnell zu testen und zu lernen.

- Du besitzt eine **schnelle Auffassungsgabe** und integrierst neue Ideen & Erkenntnisse schnell.

- Du sprichst und schreibst Deutsch auf **muttersprachlichem Niveau**. Auch auf Englisch kannst du dich **fließend** verständigen.

## Benefits

Klar, du könntest auch für Matratzen, Fitness-Tracker oder Zahnschienen texten...

Oder Du schreibst Texte, die echten Menschen helfen, ihre Lebensqualität zurückzugewinnen.

Deine Entscheidung.

Aber hier ein paar gute Gründe, warum Health Routine der bessere Weg ist:

- **Du kannst bei uns eine starke Wachstumskurve hinlegen**. Dafür investieren wir auch gerne in Deine Weiterbildung und ermöglichen Dir Zugang zu Kursen, Masterminds, unserem Netzwerk etc.

- **Du wirst Teil eines ambitionierten Teams**. Wir sind ein schnell wachsendes Unternehmen mit klarer Vision, flachen Hierarchien und ehrlichem Miteinander.

- **Du schreibst für Produkte, die wirklich gebraucht werden**. Unsere Community feiert uns, weil wir Probleme lösen, die andere ignorieren – mit Produkten, die halten, was sie versprechen.

- **Du arbeitest bei uns flexibel und eigenverantwortlich**. Du hast die Möglichkeit, sowohl **100%** **remote** als auch **vor Ort im Büro** in Innsbruck zu arbeiten. Deine Arbeitszeit kannst Du Dir selber flexibel einteilen.

- **Du erhältst eine kompetitive, leistungsorientierte Vergütung**. Gute Arbeit soll sich lohnen! Deshalb bekommst Du bei uns nicht nur ein wettbewerbsfähiges Gehalt, sondern auch die Chance auf zusätzliche Boni, wenn Deine Texte wirklich performen.

Wir wachsen schnell und haben viel vor – deshalb wäre der perfekte Start: am liebsten sofort.

Aber wir wissen auch: Die besten Entscheidungen brauchen manchmal etwas Zeit. Und für die richtige Person nehmen wir uns die gern.

So läuft’s bei uns ab:

- **Erstes Kennenlernen**

In einem **15–20-minütigen Call** sprichst Du mit **Felix**, einem unserer Co-Founder. Ihr sprecht über Health Routine, die Rolle und darüber, ob es menschlich und fachlich passt.

- **Deine Copy-Case Study**

Wenn der Funke überspringt, bekommst Du eine kleine Copywriting-Aufgabe. Du hast einige Tage Zeit, sie auszuarbeiten. Wir freuen uns auf Deine Ideen, Deinen Stil und Deine Herangehensweise.

- **Persönliches Gespräch (vor Ort oder remote)**

Im Anschluss besprechen wir gemeinsam Deine Case Study, geben Dir ehrliches Feedback und Du lernst weitere Teammitglieder aus dem Marketing kennen.

- **Angebot & Start bei Health Routine**

Wenn für beide Seiten alles passt, bekommst Du zeitnah ein Angebot – und wirst Teil eines Teams, das jeden Tag daran arbeitet, echte Lebensqualität zurückzugeben.

Der gesamte Prozess dauert in der Regel **2–3 Wochen**.

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
