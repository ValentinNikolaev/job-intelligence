# Senior Data Analyst (m/f/d) - Hamburg

Posted: 2026-08-17T17:55:31Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

***Location****: Come and join us in Hamburg, Berlin or Barcelona!*

Freenow by Lyft empowers smarter mobility decisions helping people to move freely and cities to thrive.

We are looking for a Senior Data Analyst (m/f/d) to collaborate with our operational squads. In this role you will be able to become an expert in our business and data analysis systems and environment to allow you to champion data-driven decisions as part of the Data Operations team.

Be ready to work in a multinational, diverse, highly motivated and collaborative team of passionate analysts who strive for excellence and like to have fun. Are you ready for your next ride?

## **YOUR DAILY ADVENTURES WILL INCLUDE:**

- Focus on analysing and presenting recommendations/process changes/new initiatives to management using insights derived from data.

- Use your technical skills such as actively engaging in configuration and programming in the data environment, querying data via SQL from the data lake, automating data processes, deep dive analysis in Python and adjusting ETL tasks.

- Bringing new insights and championing them using your analyses, dashboards, and good storytelling! We value ideas over hierarchy, and there's always a new path to follow if your idea is convincing and well-backed with data.

- Develop monitoring tools to measure performance and help the business achieve its objectives.

- Create queries to answer operational and business questions across our many operational teams to support decisions.

- Communicate results in a clear and impactful manner.

## **TO BE SUCCESSFUL IN THIS ROLE:**

- Educated to Degree Level or higher in an analytical discipline such as Engineering, Computer Science or Economics

- 5+ years of experience in an analytical role

- You have curiosity in your essence, which motivates you to answer WHY things happened, not only scratching the surface, but aiming for well-founded actionable results

- Curiosity about AI and its practical applications in analytics, experience using LLMs or AI-powered tools in a data context

- Excellent technical skills including SQL knowledge, familiarity with visualisation tools (Metabase in particular is a plus) and python/R

- Enthusiastic, outgoing and personable - you have the ability to think on your feet, work independently and also proactively with others to find solutions to issues

- You understand how to engage and influence decision makers and have excellent communication skills

- Driven - you are motivated to find solutions to problems and constantly go the extra mile

- Strong communication and interpersonal skills as well as excellent written and spoken English

## **BENEFITS & PERKS IN A NUTSHELL:**

- Flexible working arrangements

- LinkedIn Learning

- Sabbatical & special leave policies

- WeRoad partnership

- Birthday, 24th + 31st December off

- Short term EU work policy

- Mobility Credit

- Health Insurance

- Employee assistance program

## **DIVERSITY, EQUITY & INCLUSION:**

FREE NOW is an equal opportunity employer and we consider qualified applicants regardless of race, religion, national origin, gender, gender identity, sexual orientation, disability or age.
We want you to grow and evolve,[ bring your true self to work](https://www.youtube.com/watch?v=dOUL_n8pSGQ).

## **ABOUT US:**

Freenow by Lyft empowers smarter mobility decisions, helping people to move freely and cities to thrive. Through our multi-mobility app, we feature broad options for everyone across 9 European markets and over 180 cities. Millions of passengers can access services including taxis, private hire vehicles, carsharing, car rental, e-scooters, e-bikes, e-mopeds, and public transport within a single app.

In July 2025 Freenow was acquired by Lyft, a global mobility platform, which connects riders and drivers for billions of rides across North America and Europe. Together, Freenow and Lyft are creating a more caring and connected world, with transportation for everyone. We are a global, diverse, highly motivated, and collaborative team that strives for excellence and likes to have fun. Ready for your next ride?[](https://www.linkedin.com/company/free-now/life/2b1603ea-741a-49f8-9847-f1214f483a1a/)

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
