# (Senior) IT Manager (m/w/d)

Posted: 2026-08-17T20:30:46Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**Was dich erwartet**

casavi wächst und unsere IT wächst mit uns. Als Senior IT Manager*in übernimmst du die volle Verantwortung für unsere IT-Organisation, von SaaS-Governance und Hardware-Management bis hin zu Prozessautomatisierung und internen Tools. Du baust auf einem soliden Fundament auf, verbesserst was bereits existiert, und schaffst die Strukturen, die wir zum Skalieren brauchen. Eine Rolle, in der du wirklich gestalten kannst. Ideal für jemanden, der Eigenverantwortung sucht, proaktiv handelt und echten Impact hinterlassen möchte.

**Dein Job bei uns**

-

SaaS & Tool Governance: Du übernimmst die Verantwortung für unser gesamtes SaaS-Portfolio, von Lizenzverwaltung und Zugriffskontrolle bis hin zur Evaluierung neuer Tools und der Sicherstellung einer lückenlosen Dokumentation und Governance

-

AI & Prozessautomatisierung: Du identifizierst und implementierst KI-gestützte Lösungen zur Automatisierung interner Prozesse und Steigerung der Produktivität bei casavi. Du unterstützt Mitarbeitende bei der Evaluierung und dem effektiven Einsatz von KI-Tools und etablierst klare Richtlinien für deren sicheren und verantwortungsvollen Umgang

-

Hardware & Vertragsmanagement: Du verwaltest und optimierst Hardwareverträge, behältst Vertragslaufzeiten im Blick und stellst ein kosteneffizientes Lifecycle-Management für Mac- und Windows-Geräte mit Hexnode und NinjaOne sicher

-

Mitarbeiter-IT-Support (1st/2nd Level): Du kümmerst dich um Hardware-Beschaffung, Geräteeinrichtung, Lifecycle-Management und interne Tickets und sorgst für einen schnellen und zuverlässigen Support für alle Mitarbeitenden

-

On- & Offboarding Redesign: Du analysierst unsere bestehenden On- und Offboarding-Prozesse, identifizierst Schwachstellen und baust einen skalierbaren, gut dokumentierten Prozess auf, inklusive der Automatisierung von Identity and Access Management (IAM)

-

IT Research & Innovation: Du evaluierst proaktiv neue Tools, Technologien und KI-gestützte Lösungen, die die interne Produktivität und Effizienz verbessern

-

Security Foundations: Du setzt Sicherheitsstandards durch (MFA, Least Privilege, VPN) und trägst zur Härtung unserer IT-Umgebung bei

-

IT-Infrastruktur: Du verwaltest die Büro-IT-Infrastruktur (WLAN, Meetingräume, Drucker) und stellst einen sicheren Netzwerkzugang für hybrides und remote Arbeiten sicher

**Dein Profil**

-

Fundierte praktische Erfahrung in der IT-Organisation, in der Systemadministration oder in der Workplace-IT, idealerweise in einem Scale-up oder SaaS-Unternehmen

-

Sicherer Umgang mit MDM- und RMM-Tools (idealerweise Hexnode und NinjaOne) sowie Erfahrung im Management einer vielfältigen Hardware-Umgebung mit macOS und Windows

-

Tiefes Verständnis von SaaS-Governance, IAM und Access Management, inklusive praktischer Erfahrung mit Google Workspace, Jira und Confluence. Idealerweise hast du solche Strukturen bereits von Grund auf aufgebaut

-

Eine prozessorientierte Denkweise: Du löst nicht nur Probleme, du entwickelst Systeme, die deren Entstehung verhindern

-

Proaktiv, strukturiert und selbstorganisiert, in der Lage mehrere IT-Projekte gleichzeitig zu managen

-

Solides Verständnis von IT-Sicherheitsprinzipien, einschließlich SaaS-Audits, MFA- und Least-Privilege-Durchsetzung sowie Netzwerk- und VPN-Management

-

Fließende Deutsch- und Englischkenntnisse (C1+), da du Mitarbeiter in beiden Sprachen unterstützen wirst

-

Praktische Erfahrung in der Evaluierung und Implementierung von KI-Tools zur Verbesserung interner Workflows und Produktivität

**Darauf kannst Du Dich freuen**

- Ein ambitioniertes und sympathisches Team, das bevorzugt mit agilen Methoden arbeitet - das beweist auch unser Kununu-Score von 4,6
- Flexible & hybride Arbeitszeitmodelle
- 60 Tage pro Jahr Workation in der EU & 2 Tage Social Leave
- Regelmäßige Firmenevents
- Kita-Zuschuss & betriebliche Altersvorsorge
- Corporate Benefits
- Vergünstigte Mitgliedschaft bei EGYM Wellpass & Sportangebote
- Vielfältige Entwicklungsmöglichkeiten

** Du möchtest Teil unserer Erfolgsstory werden?**

Bist du ein Teamplayer und auf der Suche nach einer Möglichkeit, in einem internationalen und agilen Umfeld zu wachsen? Dann komm in unser Team! Bewirb dich jetzt und erzähle unserer Recruiting Managerin Anna, warum du der oder die Richtige für diese Stelle bist. Wir freuen uns auf deine Bewerbung mit Lebenslauf, frühestmöglichen Eintrittstermin und Gehaltsvorstellung. Bitte sende deine Bewerbungsunterlagen auf Deutsch oder Englisch.
Lust auf einen umfassenden Blick hinter die Kulissen von casavi? Folge uns auf Instagram @casavipeople und erfahre, wie das Teamleben bei casavi aussieht.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
