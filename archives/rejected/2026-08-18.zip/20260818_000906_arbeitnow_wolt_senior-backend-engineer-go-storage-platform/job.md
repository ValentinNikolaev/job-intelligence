# Senior Backend Engineer(Go), Storage Platform

Posted: 2026-08-17T17:55:35Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

## About Wolt

At Wolt, we create technology that brings joy, simplicity and earnings to the neighborhoods of the world. In 2014 we started with delivery of restaurant food. Now we’re building the delivery of (almost) everything and you’ll find us in over 500 cities in 30 countries around the world. In 2022 we joined forces with DoorDash and together we keep on dreaming big and expanding across the globe.

Working at Wolt isn’t always easy, but it’s definitely exciting. Here you’ll learn more, build more, and ship more than in most other companies. You’ll be challenged a lot, but also have a lot of fun on the way. So, if you’re a self-starter with drive and entrepreneurial spirit, this could be the ride of your life.

## What you’ll be doing

As part of Wolt’s Platform department (Core Group), you’ll help improve and automate operations for our storage access platform - our real time database abstraction layer solution designed with scale and resiliency in mind . The product you will build enforces best practices by design, abstracts database infrastructure, and supports Multi-Region architecture through data sharding and replication. You join a team of highly skilled engineers in designing, building and optimizing this platform and ensuring smooth developer onboarding, constant improvement and optimization.

As an engineer on the Storage access platform team, you’ll work on platform features such as UI for developer teams, storage abstraction layer, database automation, client SDK and proxy, Change Data Capture pipelines, caching and ephemeral storage, Hot & Cold storage management and more.

## Our humble expectations

You’ll be a great fit for this role if you have the following skills and experience:

- A strong developer-to-developer mindset, with a genuine enjoyment of building for internal customers and treating other engineers as your primary users.

- Adaptability and strong motivation for working with distributed systems.

- A data-driven approach to decision-making and a collaborative mindset, with the ability to navigate disagreements constructively and deliver consistently.

- Autonomy in dynamic, fast-paced environments with frequent change.

- A product- and platform-oriented approach to engineering challenges.

- Excellent communication skills, with the ability to engage effectively with stakeholders and cross-functional teams.

- A collaborative spirit and experience contributing to diverse and inclusive work environments.

### Technical proficiencies:

- Expertise in NoSQL databases, particularly Cassandra or DynamoDB.

- Experience with large-scale distributed systems, emphasizing both velocity and scalability.

- Familiarity with SRE principles; however, a background in Backend Development is essential.

- Practical knowledge of Kubernetes, including EKS, as an end user.

You don’t need to tick every box, but if you see yourself in many of these points, we’d love to hear from you!

## **
**What we offer

At Wolt, we’re committed to building an environment where engineers can make an impact while enjoying meaningful challenges. As a member of the the team you’ll enjoy:

- Working on solutions that support millions of users

- Solving complex problems in performance, reliability and automation

- A collaborative and inclusive culture that supports your professional and personal well-being

We also offer flexible work arrangements, competitive compensation, and ongoing learning opportunities to help you thrive.

## Our Commitment to Diversity and Inclusion

We’re committed to growing and empowering a more inclusive community within our company, industry, and cities. That’s why we hire and cultivate diverse teams of people from all backgrounds, experiences, and perspectives. We believe that true innovation happens when everyone has room at the table and the tools, resources, and opportunity to excel.

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
