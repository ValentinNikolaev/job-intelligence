# Revenue Operations Manager - GTM Engineering & Signals

Posted: 2026-08-17T17:40:19Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

At **Statista**, we’re all about facts and data, for we are the world's leading business data platform. By providing reliable and easy-to-use data as well as various data analytics products and services, we empower people worldwide to make fact-based decisions.

Founded in Hamburg in 2007, we have quickly grown into a global company with offices in major cities such as London, New York, Berlin and Tokyo. And we still have a lot of plans. Our constant growth does not only prove our success, but also keeps creating new development and career opportunities for our employees.

We value and celebrate our diverse culture. You are welcome here for who you are, no matter where you come from, what you look like, or whether you prefer bar graphs to pie charts. Your story matters – keep writing it as part of our team.

Are you ready to join us?

**Your Job:**

-

Design, build, and continuously improve Clay workflows for account enrichment, signal detection, and scoring, and own the technical execution end-to-end from initial setup to ongoing iteration.

-

Translate strategic account priorities into Salesforce by structuring account fields, signals, and TAM views that directly support Sales execution across regions (GSA, EMEA, AMERICAS, APAC).

-

Implement and operationalize account prioritization logic (e.g., Tier 1-3) based on signals and scoring, enabling Sales to clearly identify where to focus and why.

-

Establish and refine a lean, high-quality set of account-level signals (e.g., hiring activity, tech stack changes, funding events, business model indicators) and continuously test their impact on pipeline generation.

-

Create intuitive, easy-to-use structures in Salesforce (e.g., list views, filters, signal fields) so Sales teams can act on prioritized accounts without friction.

-

Collaborate closely with the Head of Lead Management on strategic direction, and work with Sales, RevOps, and Data teams on prioritization logic, ownership models, and TAM usage.

**Your Profil:**

-

2-4+ years of experience in Revenue Operations, Growth Ops, or a similar GTM-focused role

-

Strong hands-on experience with Clay, including enrichment workflows, signal setup, and scoring models

-

Solid working knowledge of Salesforce, especially account-based setups, fields, and list views

-

Proven track record of building outbound systems or data workflows actively used by GTM teams

-

Analytical thinking paired with a pragmatic, execution-focused mindset and the ability to build systems from scratch

-

Nice to have: experience with signal-based GTM, intent data setups, or B2B SaaS environments

**Your Team:**

The Sales Operations team is part of the sales organization of Statista. We support more than 300 employees from the Marketing, Sales, and Client Success, Marketing departments. Our tasks include analyzing sales data, forecasting, and the constant monitoring of KPIs. Not only do we strive to support our global Sales team on a daily basis by optimizing processes, but we are also responsible for the sales tools and systems, with Salesforce as our main CRM Tool.

**What we offer**

In addition to our great team, culture, and our shared goal of empowering people with data, there are many other things that make Statista a great place to work! Join us and benefit from:

-

Work from abroad up to 30 calendar days a year

-

Hybrid work and flex-time

-

International team and social events

-

Subsidized urban mobility and access to fitness and wellness options

-

Free access to Langdock and all its amazing functionalities

-

Career & training opportunities

-

Attractive locations and modern offices

-

Mental health support with OpenUp

*Some of the benefits listed here apply only to the German entity and to Junior-level roles or above.*

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
