# Data Analyst FlixTrain Operations (m/w/d)

Posted: 2026-08-17T20:45:26Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Bei FlixTrain gestaltest du die Zukunft der Mobilität aktiv mit. Wir bieten dir nicht nur sichere Arbeitsplätze sowie attraktive Zusatzleistungen, sondern auch ein dynamisches, internationales Umfeld, in dem deine Ideen echten Einfluss haben.

FlixTrain hat es sich zum Ziel gesetzt, Zugreisen in Deutschland besser, umweltfreundlicher und barrierefreier zu gestalten. Wir wachsen rasant und damit auch unser Anspruch, jede Entscheidung datenbasiert zu treffen. Deshalb bauen wir etwas Neues auf: ein eigenes, zentrales Data-Analytics-Team bei FlixTrain. Du gehörst zu den ersten Mitarbeitern dieses Teams - das bedeutet echte Verantwortung, echten Einfluss und die Chance, unsere Arbeit mit Daten vom ersten Tag an mitzugestalten. Gemeinsam mit einem erfahrenen Analysten entwickeln Sie unsere Standards und arbeiten eng mit unseren operativen Abteilungen zusammen, um operative Daten in Dashboards, Erkenntnisse und Entscheidungen zu übersetzen, die das Unternehmen voranbringen.

**Über die Rolle**

- Gemeinsam mit unseren Fachbereichen entwickelst du End-to-End-Analytics-Lösungen mit Power BI, Snowflake, Python und Git und schaffst damit die Grundlage für datenbasierte Entscheidungen

- Als Ansprechpartner für den Datenbereich Operations übersetzt du komplexe Fragestellungen in aussagekräftige Analysen, Dashboards und Handlungsempfehlungen und unterstützt in der Aufbauphase des Teams auch weitere Unternehmensbereiche

- Datenpipelines und Reporting-Prozesse entwickelst und automatisierst du kontinuierlich weiter und integrierst externe Datenquellen in unser Data Warehouse

- In enger Zusammenarbeit mit unseren Data- und Engineering-Teams verantwortest du den gesamten Lifecycle deiner Analytics-Lösungen – von der Datenmodellierung über Testing und Visualisierung bis hin zum produktiven Betrieb

- Durch hohe Qualitätsstandards, saubere Dokumentation und verlässliche KPI-Modelle sorgst du dafür, dass unsere Datenprodukte als „Single Source of Truth" genutzt werden können

**Über Dich**

- Erfolgreich abgeschlossenes Studium im Bereich Wirtschaftsinformatik, Informatik, Data Science, Mathematik oder Statistik oder eine vergleichbare Qualifikation

- Mindestens zwei Jahre Berufserfahrung als Data Analyst, Business Analyst, Analytics Engineer oder in einer vergleichbaren analytischen Rolle

- Sehr gute Kenntnisse in SQL, Python und Git sowie Erfahrung in der Erstellung von Dashboards und Reports mit Power BI

- Analytisches Denkvermögen, ein gutes Verständnis für Business-Zusammenhänge sowie eine strukturierte und eigenverantwortliche Arbeitsweise zeichnen dich aus

- Sehr gute Deutsch- und Englischkenntnisse sowie Freude an der Zusammenarbeit mit unterschiedlichen Stakeholdern

*Bei uns zählt der Blick auf das Ganze – auch wenn du nicht alle Anforderungen zu 100 % erfüllst, aber dennoch glaubst, etwas bewegen zu können, freuen wir uns auf deine Bewerbung! *

**Was Wir Bieten**

- **Reisevorteile:** 12 kostenlose Flix-Gutscheine + 12 Rabattgutscheine für Freunde & Familie.

- **Arbeiten von Überall:** Je nach Rolle kannst du bis zu 60 Tage pro Jahr von einem anderen Standort aus arbeiten.

- **Hybrides Arbeitsmodell:** Wir sind ein Unternehmen mit Bürokultur, bieten jedoch Flexibilität, um Arbeit und Leben in Einklang zu bringen.

- **Gesundheits- und Wohlfühlangebote:** Zugang zu vertraulichen Einzelberatungen, Kursen und Stressbewältigungsmaßnahmen – für dich und bis zu vier Familienangehörige.

- **Lernen & Entwicklung:** Nutze Sprachkurse, Schulungen und Experten-Sessions, um deine Fähigkeiten auszubauen.

- **Mentoring-Programm:** Vernetze dich mit erfahrenen Kollegen, um Einblicke zu gewinnen und deine Karriere zu beschleunigen.

**Warum Teil von Flix werden?**

Bei Flix konzentrieren wir uns darauf, Reisen einfach, sicher und erschwinglich zu gestalten – sowohl für unsere Passagiere als auch für unsere Mitarbeiter. Hier geht es schnell voran, und es gibt viel Raum, etwas zu bewegen. Wir wachsen und entwickeln uns täglich weiter und suchen Menschen, die bereit sind, sich einzubringen und die Art und Weise, wie wir arbeiten, mitzugestalten.

Wenn du einen Job suchst, in dem du wachsen und etwas bewirken kannst, dann bist du bei FlixTrain genau richtig. Hier kannst du Teil eines Teams werden, in dem dein Beitrag zählt und du deine Reise selbst gestalten kannst!

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
