# Head of Sales

Posted: 2026-08-17T20:40:27Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

# **about us**

Every 10 minutes, 18 million conversations happen between businesses and consumers around the world.

For decades, the consumer side of those conversations sucked: long queues, robotic menus, repeated explanations, and advice that is often unhelpful. Most people today still cannot simply say what their problem is in natural language when communicating with businesses.

AI changes that. For the first time, companies can have natural conversations with customers at massive scale. Every B2C company - from energy providers to telcos to insurers - will use AI agents to talk to their customers. The number of conversations businesses will handle is going to explode in the coming years.

At telli, we are solving the challenges that come with that shift. Today, leading B2C companies like Sky are already using telli to deploy thousands of voice agents to provide their customers with a new experience. But building a first voice agent is easy, getting it to drive real outcomes for customers and businesses is the hard part. telli helps companies build, deploy, and improve consumer-facing AI voice agents at scale. This will become one of the most important software categories of the next decade, and we intend to win it.

We are a small, AI-pilled team that likes to solve hard problems. Be it engineering, product, or GTM - we build, experiment, and move fast, while heavily leveraging the capabilities of AI models. All of us like to challenge ourselves and take real ownership over what we do, all while still staying humble and keeping a low-ego culture.

Check out our [**principles**](https://principles.telli.com/) to see how we work.

### **Key facts**

-

Location: Berlin

-

Employment Type: Full Time

-

Location Type: On-Site (100%)

-

Department: Growth

-

Compensation: OTE (incl. commission) €180.000 - €240.000 + equity

### **Interview process**

Phase 1 → Role Check and Deep Dive with The Combine, our hiring partner

Phase 2 → Assessment Day at our office with telli and The Combine

Phase 3 → Reference and Investor checks

### **Your mission**

You’re the key person responsible for telli’s sales performance. You drive growth by building an outstanding sales organization and hiring a team aligned with our [principles](https://principles.telli.com/). You support and enable your team through regular training and coaching on individual and team level.

You combine hiring, leadership and enablement to continuously enhance the quality and size of the team. You support and shadow your sales team in their daily activities and deals. You own collaboration of sales with our internal departments (marketing, product, customer operations).

### **Your day-to-day at telli**

-

Lead a sales team of high performers, hire further members, train & coach daily

-

Structure & Manage quota attainment and support deals through Shadowing & Feedback, Pipeline Reviews, Reporting and Forecasting

-

Drive career growth of your team members, guide them to unfold their highest potential and become productive contributors to telli’s mission

-

Create and execute state-of-the-art GTM processes together with our Revenue Operations department

-

Collaborate with other departments (marketing, product, customer operations) to execute an aligned GTM strategy

-

Establish “what good looks like” in our sales culture

-

Lead the prospective middle management layer of team leads

### **Your key skills and traits**

-

You’re an outstanding enabler → the sales team is your primary focus, you’re a strong mentor, trainer and coach, you’re a challenger with attention to detail

-

You build great teams → you build coherent organizations in line with our GTM strategy, you set a high bar for performance and have strong hiring methodologies and interviewing skills

-

You’re an elite GTM leader → you understand sales performance mechanisms and create work structures that drive high sales productivity daily, you communicate goals and processes to the team comprehensively and drive and maintain motivation

-

You possess strong sales skills → you love sales and transfer that to the team, you’re a consultative seller with strong stakeholder management and the ability to structure and execute complex deals

-

You can lead a high-growth startup through transitions → you have a strong compass and prioritization towards our strategy, you simultaneously work on short-, mid- and long-term goals, you embrace change and have high agency

-

You’re a strong communicator → you’re thoughtful but specific in your communication with internal departments (e.g. product), you convey requirements in a structured and prioritized manner, you utilize operational and customer data to make convincing cases

-

You’re AI-native → you utilize AI in your daily work for internal purposes as well as for customer work, you’re comfortable with complex technological problems and are motivated to learn all about telli, our product and industry

### **Benefits at telli**

-

Above-market pay & equity

-

Access to any (AI) tool that makes you more productive

-

Gym subscription (Urban Sports)

-

Free dinner in the office

-

Regular off-sites

Compensation: €180K – €240K

- • OTE (incl. commission) + equity €180K – €240K

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
