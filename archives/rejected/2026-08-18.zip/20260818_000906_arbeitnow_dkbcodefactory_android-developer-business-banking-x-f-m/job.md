# Android Developer - Business Banking (x,f,m)

Posted: 2026-08-17T20:55:25Z

## Rejection

- Category: role_mismatch
- Reason: title is an obvious mismatch for a backend profile

**We****lcome to DKB Code Factory…. **

**{ { … ****a_place_to_stay_yourself:**

**} } ; **

**{ { … ****a_place_to_stay_curious:**

**Curious about building the future of mobile banking?**

Join DKB Code Factory as an Android Developer and contribute to building the foundation of an innovative mobile banking app targeting small to mid-sized businesses. Work with modern Android technologies to deliver scalable, user-centric features while growing your expertise in a collaborative, agile environment.

**} } ; **

#### **{ your_responsibilities: [**

- Own the implementation and continuous evolution of a modular, scalable Android architecture based on MVVM, Jetpack Compose, and Kotlin Coroutines.

- Collaborate closely with Product, Design, Backend, and QA to refine requirements, clarify edge cases, and deliver high-quality user flows.

- Support CI/CD pipelines, automated testing, and documentation to ensure smooth development processes.

- Deliver prioritized user flows integrated with backend APIs.

- Drive code quality by writing meaningful automated tests, participating in code reviews, and improving engineering standards where needed.

- Participate in iterative product development cycles driven by user feedback and analytics.

#### ] } ;

**{ following_qualifications_would_be_in_line_with_our_desired_profile_for_this_position: [**

- 3+ years of native Android development experience using Kotlin and Java.

- Solid knowledge of Jetpack Compose and Android architecture components.

- Experience with RESTful APIs, Git, CI/CD, and automated testing frameworks (JUnit, Espresso).

- Understanding of Material Design guidelines and app deployment on Google Play Store.

- Agile and Scrum experience in cross-functional teams.

- Fluent in English; German language skills are a plus.

#### ] } ;

**Have the feeling you don't match every single requirement? Don’t worry! We encourage you to apply anyways, even if your qualifications do not align perfectly. You might still be just the right candidate for us!**

**{ { … ****a_place_to_stay_together:**

From Morning Daily to Afterwork Drink, team spirit is essential to us. The heart of our togetherness is that we truly are connected with each other: We not only share fun & laughter, but also honest opinions - because that's how we grow: We exchange ideas, give support in our personal development, and celebrate success together! Besides our great community, we also offer numerous other* [benefits](https://www.dkbcodefactory.com/jobs#what-we-offer)*...

**} } ;**

**

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
