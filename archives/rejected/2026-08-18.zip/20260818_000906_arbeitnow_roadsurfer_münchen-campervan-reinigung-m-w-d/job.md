# MÜNCHEN - Campervan Reinigung (m/w/d)

Posted: 2026-08-17T17:40:07Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**Warum roadsurfer?**

-

**TEAMSPIRIT & TEAMEVENTS**: Freu dich auf eine kollegiale Atmosphäre mit flachen Hierarchien, jede Menge Spaß und großartigem Teamspirit sowie regelmäßige Teamevents wie gemeinsame Sportsessions, Grillabende oder einfach nur ein Feierabenddrink an deiner Station.

-

**CAMPER BUDGET**: Du bekommst eine jährliche Freimiete für unsere Camper, damit du den #happyroadsurfing Lifestyle selbst erleben kannst.

-

**JOBRAD**: Bleibe fit mit unserem Angebot eines Jobrads.

-

**DISCOUNTS:** Nutze unsere Corporate Benefits Plattform, die Travel Industry Card und Family & Friends Rabatte.

**Die Rolle - deine Leidenschaft**

-

Du bist zuständig für die fachgerechte Innen- und Außenaufbereitung unserer Vans

-

Du führst den technischen Check-up durch (Reifendruck, Öl- und Wasserstand prüfen)

-

Du hast ein Auge auf unsere Camper-Vans bei Rückgabe nach dem Urlaub und prüfst entstandene Schäden

-

Du übernimmst die Beseitigung von Beklebungen und leichte Lackreparaturen

-

Du unterstützt zusätzlich bei weiteren arbeitsbezogenen Aufgaben

**Was du brauchst, um mit uns auf einer Welle zu surfen**

-

Du bist zuverlässig, motiviert und hast Freude im Umgang mit Camper-Vans

-

Du bist absolut Hands-On (hast also kein Problem damit dir die Hände schmutzig zu machen)

-

Selbstständiges und sorgfältiges Arbeiten ist für dich kein Problem

-

Du hast einen Führerschein der Klasse B

-

Kenntnisse im Bereich der Aufbereitung und technisches Verständnis wünschenswert

**Dein Gehalt**

Wir ❤️ Transparenz. Das Gehaltsband für diese Position liegt zwischen 30.000 EUR und 32.000 EUR brutto jährlich. Wir führen aktuell Gehaltsbänder in unseren Stellenbeschreibungen ein, um sicherzustellen, dass alle Mitarbeitenden fair behandelt werden. Sobald wir uns im Bewerbungsprozess besser kennenlernen und deine Fähigkeiten und Erfahrungen noch genauer einschätzen können, finden wir gemeinsam heraus, welche Stufe innerhalb des Gehaltsbands am besten zu dir passt. In einem jährlichen Feedbackgespräch wird dein Gehalt mindestens einmal im Jahr überprüft.

**Bereit zur surfen?**

Wir freuen uns auf deine Bewerbung! Für Rückfragen kannst du dich auch gern jederzeit an ----- wenden. Bitte bewirb dich ausschließlich über unser Bewerbertool – so geht nichts verloren und wir können deine Bewerbung schnell bearbeiten.

**ABOUT #ROADSURFER**

We are more than Europe's largest campervan rental company. In 2021 we launched our platform roadsurfer spots in addition to our other products rent, abo and sales – a platform where you can discover and book unique camping spots. But that’s only the beginning. We are growing fast, so hop on board and join us on our journey. The roadsurfer philosophy is simple: rent an RV, start your adventure, be happy. Come ride the wave with us!

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
