# Senior Software Engineer / AI Enabler (m/f/d)

Posted: 2026-08-17T20:56:01Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**A career driven by you. **Join AutoScout24 Group and experience life in the fast lane. We’re not just leading the market; we’re creating it. We’re constantly innovating, evolving and transforming things for our customers. We’re driven, ambitious and determined to do our best work, together. For a career that doesn’t stand still, where you can put your ideasin the driving seat and change the way the world moves, join our global community.

We’re hiring a Software Engineer to join Search & Performance group at AutoScout24 – the group behind the Algorithms and Data Quality that powers the AutoScout24 Search Experience and Ad Products. This role is about real ownership: you’ll work on high-traffic systems, shape key parts of our user experience, and contribute to critical business outcomes.

**What you’ll do:   **

- Work on product and tech initiatives finding the right mix between effort, quality and user value

- Optimize and improve the AS24 technology stack by targeting individual and team efficiency, applying future proven concepts, architectural principles, and frameworks

- Support our agile product development approach

**   What you need to succeed:   **

- Deep expertise in Java and Spring Boot, with a breadth of knowledge across a range of languages and technologies in both Object-Oriented and Functional paradigms; able to quickly grasp new concepts and tools Experience with Scala is a plus

- 5+ years of Software Engineering experience, hands-on experience with PostgreSQL, DynamoDB, Kafka, and AWS is a strong plus

- Team player but also decisive mentality

- Demonstrated personal excellence in using GenAI coding tools (for example GitHub Copilot, ChatGPT, Cursor, OpenAI Codex) to significantly improve your own development speed and quality: code generation, refactoring, debugging, tests and documentation.

- Experience integrating LLM APIs (such as OpenAI, Anthropic, Azure OpenAI, Vertex AI or similar) into applications or internal tools.

- A pragmatic view of GenAI: you understand its limitations and risks and know how to put guardrails in place (reviews, tests, policies) to keep usage safe, compliant and sustainable at scale.

**A culture of growth **

With over 50 nationalities represented, we’re proud to welcome people of all backgrounds to our growing community, and we’re always finding new ways to help people feel welcomed and included. Here, you’ll have the tools, training and support you need to work in a way that suits you, learn new skills and reach your potential.

**For a career where you can drive our business and shape your future, apply now. **

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
