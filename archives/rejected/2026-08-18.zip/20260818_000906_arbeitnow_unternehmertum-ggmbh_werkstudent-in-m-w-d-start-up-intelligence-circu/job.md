# Werkstudent_in (m/w/d) Start-up Intelligence Circular Economy

Posted: 2026-08-17T20:10:26Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**Über uns**

CIRCULAR REPUBLIC ist Europas führende Implementierungsplattform für die Circular Economy – Teil von UnternehmerTUM, Europas größtem Zentrum für Innovation und Gründung. Wir befähigen Unternehmen und Start-ups, zirkuläre Innovationen und skalierbare Geschäftsmodelle zu realisieren.
Kreislaufwirtschaft ist einer der Schlüssel zur Lösung des Klimawandels – und zugleich Teil der Antwort auf geopolitische Krisen, Rohstoffabhängigkeiten und Lieferkettenprobleme. Mit unserem Innovationsökosystem vernetzen wir relevante Akteure entlang der Wertschöpfungskette und setzen die Impulse, die es für eine resiliente, nachhaltige und wettbewerbsfähige Wirtschaft von morgen braucht.

**Deine Aufgaben**

- Du verantwortest die Pflege unserer Start-up Datenbank und unterstützt die Erstellung des Startup Landscape Reports.
- Du verantwortest die Wartung und Erweiterung unseres AI-Agenten zur automatisierten Erstellung unserer Start-up Datenbank.
- Du bringst dich aktiv in die Optimierung und Automatisierung von teaminternen Prozessen ein.
- Du unterstützt bei der Entwicklung neuer Workshop Angebote.
- Du wirkst aktiv bei der Vorbereitung unseres CIRCULAR REPUBLIC FESTIVALS 2027 mit und bringst Deine Ideen für die Konzeption der Workshop Area des Festivals ein.

**Dein Profil**

- Du studierst BWL, Wirtschaftsinformatik, Umweltwissenschaften, Ingenieurwesen oder eine vergleichbare Fachrichtung.
- Du hast eine hohe Affinität für neue AI-Tools und Use Cases und hast bereits Erfahrung in der Entwicklung von Agenten und Automatisierungen (z.B. mit Make).
- Du interessierst dich für Nachhaltigkeit und das Thema Kreislaufwirtschaft und hast idealerweise erste praktische Erfahrungen in diesen Bereichen gesammelt
- Du arbeitest selbstständig, übernimmst Verantwortung und bist hoch motiviert, relevante Themen unternehmerisch zu treiben.
- Du arbeitest gut und gerne als Teil eines kleinen agilen Teams.
- Du verfügst über ausgezeichnete Kommunikationsfähigkeiten in Deutsch und Englisch.

**Deine Vorteile**

- **Flexibilität: **flexible Arbeitszeiten, Gleitzeitkonto, Homeoffice-Möglichkeit, moderner Arbeitsplatz im Munich Urban Colab.
- **Kommunikation & Arbeitsklima:** abwechslungsreiche Tätigkeiten in einem engagierten Team mit teamübergreifende Vernetzungsangeboten, Unternehmens- und Teamevents.
- **UnternehmerTUM MakerSpace: **Mitgliedschaft und Gratiskurse in unseren beiden Hightech-Werkstätten in Garching und München.
- **Fitness und mentale Gesundheit: **Zugang zu kostenlosen Achtsamkeits- und Sportkursen (Yoga, Pilates, CrossFit, Functional Training).
- **Sinnstiftende Tätigkeit:** Einblick in relevante Themen und Unterstützung bei Projekten mit impact.

**Vielfalt ist uns wichtig**

Vielfalt bereichert unser Team. Wir ermutigen ausdrücklich alle qualifizierten Personen zur Bewerbung, unabhängig von Geschlecht, sozialer und ethnischer Herkunft, sexueller Orientierung, Religion, Alter oder Behinderung.

**Kontakt**

Franziska Kopp, People & Culture Manager
UnternehmerTUM GmbH
Lichtenbergstraße 6, 85748 Garching bei München

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
