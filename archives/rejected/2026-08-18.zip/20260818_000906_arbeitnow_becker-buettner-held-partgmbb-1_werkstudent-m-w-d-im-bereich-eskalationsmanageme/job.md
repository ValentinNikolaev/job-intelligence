# Werkstudent (m/w/d) im Bereich Eskalationsmanagement (16-20 Wochenstunden)

Posted: 2026-08-17T17:09:44Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**Aufgaben**

- Unterstützung bei bestehenden Projekten in der Energiewirtschaft im Bereich Eskalationsmanagement
- Verarbeitung, Strukturierung und Digitalisierung von Verwaltungsunterlagen
- Mitwirkung bei der Implementierung und Weiterentwicklung digitaler Prozesse und Tools
- Aufnahme der elektronischen, telefonischen oder postalischen Kundenrückmeldungen sowie Dokumentation in der Akte
- Unterstützung des Teams im Tagesgeschäft und bei administrativen Aufgaben

**Profil**

- Du bist aktuell im Studiengang Rechtswissenschaften oder Wirtschaftsrecht immatrikuliert und bist mindestens 1 Jahr verfügbar.
- Erste Erfahrungen im Bereich Projektmanagement sind von Vorteil
- Sehr gute Deutschkenntnisse (mind. auf dem Niveau C1)
- Du überzeugst mit deiner schnellen Auffassungsgabe und deiner strukturierten, eigenständigen Arbeitsweise.
- Eine ausgeprägte Do-it-Mentalität und starke Kommunikationsfähigkeiten runden Dein Profil ab.

**Warum wir?**

Bei BBH arbeitest Du in einem modernen Arbeitsumfeld mit zentral gelegenen Standorten. Kein Tag ist wie der andere! Spannende Fragestellungen lösen wir interdisziplinär gemeinsam mit Kolleg:innen. Gleichzeitig fördern wir Deine persönliche Weiterentwicklung. Natürlich haben wir noch mehr zu bieten:

- Stundenlohn: 18 Euro für Bachelorstudierende, 20 Euro für Masterstudierende
- Flexible Arbeitszeiten und die Möglichkeit mobil zu arbeiten
- Vergünstigter Mittagstisch
- Attraktive Preisnachlässe und Rabatte bei namhaften Anbietern für Produkte, Dienstleistungen und öffentliche Einrichtungen
- Betriebliches Gesundheitsmanagement zur Förderung der mentalen und körperlichen Gesundheit, inklusive vergünstigte Mitgliedschaft bei Urban Sports

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
