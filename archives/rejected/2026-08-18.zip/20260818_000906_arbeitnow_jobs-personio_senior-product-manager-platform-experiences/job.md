# Senior Product Manager — Platform Experiences

Posted: 2026-08-17T23:09:33Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
