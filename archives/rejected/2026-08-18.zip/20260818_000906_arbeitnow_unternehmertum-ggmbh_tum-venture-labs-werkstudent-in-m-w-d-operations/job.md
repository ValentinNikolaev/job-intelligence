# TUM Venture Labs: Werkstudent_in (m/w/d) Operations Legal Tech Colab

Posted: 2026-08-17T20:10:26Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**Über uns**

Das Legal Tech Colab (LTC) ist der Hub für Software-Startups im Rechtsbereich. Als gemeinnützige Initiative von UnternehmerTUM, den TUM Venture Labs und dem Bayerischen Staatsministerium der Justiz unterstützen wir unsere Mitglieder dabei, Lösungen für rechtliche Herausforderungen durch neue Technologien einfacher, besser, schneller und für alle zugänglich zu machen. Unser Ziel ist es, Europas führenden Hub für international skalierbare Legal Tech Start-ups aufzubauen.

**Deine Aufgaben**

-

**Automatisierung & Prozesse:** Aufbau und Pflege von Automatisierungen in[ Make.com](http://make.com/), die HubSpot, Salesforce, Notion und Slack miteinander verbinden, von der ersten Idee bis zum laufenden Betrieb.

-

**CRM & Daten:** Abgleich und Pflege unserer Kontakt- und Unternehmensdaten zwischen HubSpot und Salesforce, inklusive Lösung von Dopplungen und Zuordnungsfehlern.

-

**Dashboards & Wissensmanagement: **Pflege unseres Notion-Knowledge Hubs, damit Startups jederzeit Zugriff auf relevantes Wissen haben.

-

**Startup-Betreuung:** Du bist Ansprechpartner für unsere Mitglieder bei bestimmten Themen zu Onboarding, bei der Nutzung unserer Angebote und bei der Vergabe der Arbeitsplätze, die wir zur Verfügung stellen.

**Dein Profil**

-

Du studierst Wirtschaftsinformatik, Data Science, Management & Technology, BWL oder ein vergleichbares Fach mit guten Studienleistungen.

-

Du begeisterst dich für Automatisierung, Daten und digitale Tools. Ein starkes Interesse an Legal Tech oder Start-ups ist von Vorteil.

-

Du hast die Fähigkeit, dir übertragene Aufgaben selbstständig voranzutreiben und umzusetzen, und übernimmst Verantwortung für deren sorgfältige Erledigung.

-

Du arbeitest gerne im Team und hast Lust auf direkten Austausch mit Gründer:innen und Start-ups.

-

Du bist neugierig und tüftelst gerne an technischen Problemen. Erfahrung mit Tools wie[ Make.com](http://make.com/), HubSpot, Salesforce, Notion, Slack, Mailchimp oder Google Data Studio ist von Vorteil.

-

Du hast 15 bis 20 Stunden pro Woche Zeit.

-

Du kommunizierst sicher und präzise in Deutsch und Englisch.

**Deine Vorteile**

-

Ein offenes Umfeld, das Eigeninitiative und -verantwortung fördert und Möglichkeiten zum Mitgestaltung bietet.

-

Eine Vergütung von 16 € pro Stunde.

-

Flache Hierarchien, hohe Freiheitsgrade und eine enge Zusammenarbeit mit einem dynamischen und begeisternden Team.

-

Die Möglichkeit zur Vernetzung mit Unternehmer:innen, Führungskräften und Expert:innen im Start-up- und Legal-Tech-Umfeld, die das Sprungbrett für deine spätere Karriere sein können.

-

Vielseitige Einblicke in verschiedene (juristische) Berufsbilder und Branchen.

-

Kostenlose Sportangebote an unseren Standorten (Yoga, Functional Training, Cross Fit etc.).

**Vielfalt ist uns wichtig**

Vielfalt bereichert unser Team. Wir ermutigen ausdrücklich alle qualifizierten Personen zur Bewerbung, unabhängig von Geschlecht, sozialer und ethnischer Herkunft, sexueller Orientierung, Religion, Alter oder Behinderung.

**Kontakt**

Nadine Heuberger, People & Culture Manager
UnternehmerTUM GmbH
Lichtenbergstraße 6, 85748 Garching/München

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
