# Senior Software Engineer (m/f/d): AI-Native Development

Posted: 2026-08-17T20:09:48Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
