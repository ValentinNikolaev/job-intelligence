# Berater Informationssicherheit (m/w/d) - Remote

Posted: 2026-08-17T17:55:04Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Hast Du Lust, Teil eines Teams zu werden, das mit Verantwortung, gegenseitiger Wertschätzung und einem klaren Blick für Informationssicherheit an einer digitalen Zukunft arbeitet, die für uns alle zählt?

*"Im Bereich Informationssicherheits-Management legen wir großen Wert darauf, auf die individuellen Anforderungen unserer Kunden einzugehen, so dass sie den größtmöglichen Nutzen aus unserer Zusammenarbeit ziehen können - getreu dem Motto: "So standardisiert wie möglich, so individuell wie nötig". Dabei orientieren wir uns stets an nationalen und internationalen Standards. So individuell wie unsere Kunden sind auch die Mitglieder unseres Teams - wir leben von und fördern die individuellen Fähigkeiten unserer Mitarbeiter und profitieren gemeinsam von den jeweiligen Erfahrungen. Zusammen sind wir ein starkes, stetig wachsendes Team, in das jeder seine individuellen Fähigkeiten einbringen kann, darf und soll." Claus Möhler, Head of Information Security Management*

Du fühlst Dich angesprochen? Unser Team wächst stetig und wir suchen Dich als **Berater Informationssicherheit (m/w/d)** an einem unserer **Standorte **oder **Remote**, um unsere Kunden gemeinsam bestmöglich zu beraten und zu unterstützen.

### **WAS DU BEI UNS MACHST**

- Beratung unserer Kunden bei der Erstellung, Umsetzung und Überprüfung von Sicherheitskonzepten in (teil)projektführender Funktion

- Durchführung von IT-Risikoanalysen sowie die Implementierung und Entwicklung von Sicherheitsstandards & -prozessen

- Den Kundenbedarf proaktiv erkennen: Dokumentation, Prüfung und Bewertung der Prozesse

- Zielorientierte Konzipierung individueller Lösungen gemeinsam mit unseren Kunden, dabei sprichst Du „ihre Sprache“

- Unterstützung bei der Implementierung und Fortentwicklung des ISMS bei unseren Kunden

- Verbessern der Risikosituation / Informationssicherheit durch Initiieren, Koordinieren und Überwachen der empfohlenen Handlungsfelder – Deine Hands-on Mentalität ist bei unseren Kunden gefragt

### **WIE DU UNS BEGEISTERST**

- Erfolgreich abgeschlossenes Studium der Informatik, Mathematik, Ingenieurwissenschaften, Wirtschaftsinformatik oder eine vergleichbare IT-Ausbildung inkl. einer der Position angemessenen mehrjährigen Berufserfahrung in der IT-Sicherheitsbranche

- Erfahrung bei der Einführung und Weiterentwicklung von Managementsystemen der Informationssicherheit nach ISO27001 und/oder BSI IT-Grundschutz, idealerweise auch erste Berührungspunkte zu B3S

- Idealerweise Kenntnisse in der Erstellung von IT-Sicherheits-, Notfall- und Betriebskonzepten sowie von Risikoanalysen zur Informationssicherheit nach ISO27005

- Erste Audit-Erfahrungen und branchengängige Personenzertifikate sowie erste Kenntnisse im Projektmanagement (z.B. gemäß PRINCE2) im Kontext des Gesundheitssektors wünschenswert

- Hohes Maß an Analysefähigkeit, selbstständiges Arbeiten & Verantwortungsbewusstsein in (teil)projektführender Funktion sowie eine hohe Einsatz- und Reisebereitschaft

- Eine überzeugende Kommunikationsfähigkeit mit sehr guten Deutsch- und Englischkenntnissen sowie eine service- und kundenorientierte Arbeitsweise

### **FEEL GOOD KULTUR @SITSGROUP**

- **Wertschätzung:** Eine offen-herzliche, respektvolle und wertschätzende Kommunikationskultur steht bei uns an erster Stelle.

- **Teamspirit: **Es erwarten Dich spannende und vielseitige Aufgaben gepaart mit einem tollen und unterstützenden Team um Dich herum. Wir fördern nicht nur eine gesunde, sondern auch kollegiale Teamstruktur.

- **Onboarding & Einarbeitung: **Wir legen großen Wert auf ein strukturiertes Onboarding und eine intensive Einarbeitung. Wir möchten, dass Du bei uns gut ankommst!

- **Work-Life-Blending:** Wir bieten Dir die Option auf mobiles Arbeiten und flexible Arbeitszeitmodelle mit Fokus auf eine gesunde Work-Life-Balance.

- **Perspektiven:** Du erhältst vielfältige Freiräume für kreatives Arbeiten, persönliche Entwicklungsoptionen und interessante Weiterbildungsmöglichkeiten – auch im Team.

- **Corporate Benefits:** Auf Dich warten interessante und zahlreiche Mitarbeiterkonditionen.

- **Hire a Friend**!: Empfehle Deinen Wunschkollegen! Unser lukratives Mitarbeiterempfehlungsprogramm liegt uns besonders am Herzen und macht sich auch für Dich bezahlt!

- **Modern Workplace:** Du erhältst von uns eine moderne IT-Ausstattung (bspw. Firmenlaptop, Headsets, Zweitbildschirm, Smartphone etc.).

- **Großartige Unternehmenskultur:** Wir pflegen eine offene Du-Kultur und feiern legendäre größere und kleinere Teamevents!

### **ÜBERZEUGT? SO GEHT’S WEITER**

Wir freuen uns über Deinen aussagekräftigen CV, den Du über das untenstehende Formular hochladen kannst. Ein Anschreiben darfst Du gerne weglassen.

Solltest Du uns noch weitere Dokumente zur Verfügung stellen wollen, kannst Du sie in diesem Feld einfügen.

Wir freuen uns sehr Dich kennenzulernen!

### **DU WILLST NOCH MEHR ÜBER UNS WISSEN****?**

**SITS Group** - Sicherheit braucht Partner: Als führende Unternehmensgruppe für IT Security stehen wir für eine ganzheitliche Sicherheit. Mit über 700 Mitarbeitenden vereint die SITS Group Erfahrung, Kompetenz, Ressourcen und Services hochkarätiger IT Security-Provider zu einem umfassenden Ganzen. Für unsere Kunden bieten wir mithilfe innovativer Lösungen und Technologien Gesamtkonzepte zur IT Security, die auf den Aspekten Schützen, Erkennen und Abwehren beruhen. Dazu zählen der Einsatz maßgeschneiderter Strategien, die Sensibilisierung der Mitarbeitenden sowie weitreichende Servicepakete. Sämtliche Prozesse in Unternehmen werden immer stärker digital vernetzt. Dank aufeinander abgestimmter Maßnahmen und einem mehrschichtigen Schutzsystem sind unsere Kunden für die Zukunft gewappnet.

Hilf uns die IT-Sicherheit unserer Kunden zu schützen und werde Teil unserer großartigen Vision mit einem einzigartigen Teamgeist.

### **KONTAKT**

Bei Fragen kannst Du Dich gerne per **Email** an **▶** Sina Aboltakhti (Senior Talent Acquisition Partner) wenden.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
