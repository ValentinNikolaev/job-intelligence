# Senior Recruiter (m/w/d)

Posted: 2026-08-17T15:20:15Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Wir suchen Dich zum nächstmöglichen Zeitpunkt in **Vollzeit** (40 Stunden Woche) als

**Senior Recruiter (w/m/d)**

für unser Service-Office und unsere bundesweit ansässigen Restaurantbetriebe. Dein **Hauptsitz** wird in **München** sein (Kustermannpark nähe Ostbahnhof.)

Als **Senior Recruiter (w/m/d) **bist Du Teil unseres HR People & Development Teams und wirst **den Bereich Recruiting weiterentwickeln und auf das nächste Level bringen**. Bei uns arbeitest Du in einem dynamischen Umfeld mit kurzen Entscheidungswegen und profitierst gleichzeitig von den Strukturen und Entwicklungsmöglichkeiten der internationalen Vermaat Gruppe (mit den Marken L&D, tailor made catering, Die Kochmanufaktur, Join Program) mit rund 145 Betrieben in Deutschland.

**
WORUM ES GEHT**

-

Steuerung des gesamten Recruiting-Prozesses für unsere vier Marken deutschlandweit

-

Entwicklung und Umsetzung moderner Recruiting-Strategien zur Gewinnung von Fach- und Führungskräften

-

Ansprechpartner für Hiring Manager und Führungskräfte in allen Recruiting-Fragen

-

Beratung der Fachbereiche hinsichtlich Anforderungsprofilen, Recruiting-Strategien und Arbeitsmarkt

-

Active Sourcing über LinkedIn, Xing und weitere Plattformen

-

Analyse relevanter Recruiting-Kennzahlen sowie Ableitung geeigneter Maßnahmen

-

Betreuung und Weiterentwicklung unseres Bewerbermanagementsystems (Personio)

-

Aufbau und Optimierung von Recruiting-Prozessen, Standards und Interviewleitfäden

-

Mitarbeit bei Employer Branding und Social Recruiting

-

Teil des People & Development Teams für Themen wie Personalentwicklung, Employer Branding, Talent Management, Onboarding, Mitarbeiterbindung, Prozessoptimierung, KPIs und HR-Projekte.

**WAS WIR BIETEN**

-

Eine attraktive Vergütung, interessante Aufgaben und die Chancen eines rasant wachsenden Unternehmens.

-

Einen unbefristeten Arbeitsplatz mit Zukunft.

-

30 Tage Urlaub und weitere Zusatzleistungen, z. B. auch Subventionierung der Mitgliedschaft im Urban Sports Club.

-

Viel Gestaltungsspielraum und die Möglichkeit, Recruiting aktiv weiterzuentwickeln

-

Kurze Entscheidungswege und Eigenverantwortung

-

Flexibles Arbeiten mit der Möglichkeit auf mobiles Arbeiten 2x in der Woche

-

Kostenlose Snacks, Kaffee, Getränke und Verpflegung während der Arbeitszeit in unseren Betrieben

**WAS DU MITBRINGST**

-

Erfolgreich abgeschlossene kaufmännische Ausbildung oder Studium und 4 – 6 Jahre Erfahrung im Personalmanagement mit Schwerpunkt Recruiting.

-

Grundlegende Kenntnisse von Recruiting-Instrumenten und Kanälen, sowie im Active Sourcing

-

Starke kommunikative Fähigkeiten, sowie ein verbindliches und souveränes Auftreten

-

Hohes Maß an Empathie und Resilienz mit der Begeisterung Kollegen für das Unternehmen zu gewinnen

-

Teamfähigkeit, Flexibilität und eine strukturierte Arbeitsweise

-

Selbstständiges & gewissenhaftes Arbeiten, Hands-on-Mentalität und Kreativität

-

Sichere Kenntnisse im Umgang mit allen gängigen MS Office-Anwendungen

-

Erfahrung im Social Media Recruiting wünschenswert

-

Sehr gute Deutsch- und Englischkenntnisse

**Haben wir dein Interesse geweckt? Dann freuen wir uns auf deine Bewerbung über unser Online-Bewerbungsformular.**
Alternativ gerne per E-Mail
Christian Krosse
Teamlead People & Development

tailor made catering GmbH
www.tailormade.catering

**WER WIR SIND UND DIE AUFGABE**

**Vermaat Deutschland Holding GmbH** vereint die erfolgreichen Marken **L & D, tailor made catering, Die Kochmanufaktur und Join Program** unter einem Dach. Gemeinsam stehen wir für hochwertige Betriebsgastronomie, innovative Konzepte und echte Gastfreundschaft. Als Teil der international erfolgreichen Vermaat Gruppe verbinden wir die Stärke einer wachsenden Unternehmensgruppe mit der Individualität unserer Marken. Die nächsten Jahre stehen ganz im Zeichen von Wachstum, der Weiterentwicklung unserer Organisation und spannenden Zukunftsprojekten – und genau dafür suchen wir Menschen, die diesen Weg aktiv mitgestalten möchten.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
