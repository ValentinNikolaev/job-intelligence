# iOS Developer (x,f,m)

Posted: 2026-08-17T20:55:25Z

## Rejection

- Category: role_mismatch
- Reason: title is an obvious mismatch for a backend profile

-- einfügen --

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
