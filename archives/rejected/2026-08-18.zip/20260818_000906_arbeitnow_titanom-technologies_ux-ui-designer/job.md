# UX / UI Designer

Posted: 2026-08-17T20:20:39Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Titanom ist ein KI- und Softwareunternehmen mit Fokus auf digitale Produkte in Bildung, öffentlichem Sektor und angrenzenden Bereichen. Unsere Mission ist es Lösungen zu entwickeln, die nicht nur technisch funktionieren, sondern im Alltag bestehen – langfristig, sicher und nutzerorientiert.

### Deine Rolle als UX/ UI Designer: Digitale Lernprodukte gestalten, die wirklich genutzt werden

Als UX/UI Designer bei Titanom entwickelst du nutzerzentrierte UX-Konzepte und intuitive UI-Designs für moderne Web- und KI-Anwendungen. In enger Zusammenarbeit mit Product Ownern und dem Entwicklungsteam übersetzt du komplexe Anforderungen in klare, begeisternde User Experiences.

### Dein Impact bei Titanom:

- **UX-Konzeption & UI-Design:** Du entwickelst durchdachte UX-Konzepte und hochwertige, nutzerzentrierte UI-Designs für moderne Web-Anwendungen - von der ersten Idee bis zur Umsetzung.
- **Research, Usability-Tests & Optimierung:** Du planst, moderierst und wertest Usability-Tests aus, leitest konkrete Optimierungsmaßnahmen ab und überführst User-Feedback kontinuierlich in den Designprozess.
- **Wireframing & Prototyping:** Du erstellst Wireframes, User Flows und interaktive Prototypen und arbeitest dabei eng mit Product Ownern, Entwicklern und weiteren Fachbereichen zusammen.
- **Interaktionsdesign & User Journeys:** Du gestaltest intuitive Interaktionen, klare Informationsarchitekturen und effiziente Workflows, die Nutzer:innen entlang ihrer gesamten User Journey begeistern.
- **Design-Systeme & Konsistenz:** Du wirkst an der Weiterentwicklung von Design-Systemen, Komponenten und Gestaltungsrichtlinien mit und sorgst für ein konsistentes Nutzererlebnis über alle Anwendungen hinweg.
- **Kommunikation & Zusammenarbeit:** Du präsentierst und begründest Designentscheidungen verständlich vor internen Teams und Stakeholdern und begleitest die technische Umsetzung gemeinsam mit der Entwicklung.

**Requirements**

- Abgeschlossenes Studium in **UX Design, Interaction Design, Medieninformatik** oder eine vergleichbare Ausbildung
- Mindestens **ein Jahr praktische Erfahrung im UX/UI Design** sowie fundierte Kenntnisse in **Design Thinking** und **User-Centered Design**
- Sehr gute Kenntnisse in Gestaltungs- und Prototyping-Tools, insbesondere **Figma** sowie der **Adobe Creative Suite**
- Erste praktische Erfahrung im Einsatz von **KI-gestützten Tools und Technologien** innerhalb des Designprozesses
- Strukturierte, zielorientierte und eigenverantwortliche Arbeitsweise sowie die Fähigkeit, die **technische Umsetzbarkeit**von Designs eng mit der Entwicklung abzustimmen
- Hohes Maß an Kreativität, Eigeninitiative und technischem Verständnis sowie sehr gute **Deutschkenntnisse (mindestens C1)** und gute **Englischkenntnisse (mindestens B2**

### Deine Vergütung

Für diese Position bieten wir ein Fixgehalt im Bereich von **45.000 bis 50.000 EUR pro Jahr**, abhängig von deinen individuellen Stärken und Erfahrungen. Uns ist wichtig, dass du von Anfang an weißt, woran du bist, deshalb kommunizieren wir die Gehaltsrange offen und transparent. Im persönlichen Gespräch finden wir gemeinsam heraus, welche Einstufung am besten zu dir passt. Denn wir glauben daran, dass Transparenz und Wertschätzung mehr sind als Worte.

**Benefits**

- **Faire & flexible Arbeitskultur:** Wir bieten flexible Arbeitszeiten, 30 Tage Urlaub und eine transparente Überstundenvergütung – denn jede Minute deiner Arbeit wird bei uns wertgeschätzt.
- **Erstklassige Ausstattung & Extras:** Arbeite mit Top-Equipment (z.B. MacBooks) und profitiere von steuerfreien Zusatzleistungen wie 50-Euro-Gutscheinen oder einer Urban-Sports-Club-Mitgliedschaft.
- **10%** **Education Time:** Wir unterstützen dich dabei, kontinuierlich zu lernen und zu wachsen!
- **Dein Wachstum ist unser Wachstum:** In einem schnell wachsenden Unternehmen entstehen ständig neue Aufstiegschancen. Du gestaltest deinen Karriereweg aktiv mit.
- **Ein starkes, ambitioniertes Team:** Dich erwartet eine motivierte und dynamische Mannschaft, die eine gemeinsame Vision verfolgt.
- **Ein Büro, das mehr kann:** Freu dich auf ein phänomenales und gut erreichbares Büro mit Gym, Sauna, Nintendo, Tischtennis, Kicker, Ruheraum und Dachterrasse
- **Ein Kühlschrank voll mit deinen Lieblingsgetränken: **Wir bieten eine umfangreiche Getränke-Flat!
- **Legendäre Firmenfeiern und Events: **Wir feiern unsere Erfolge mit unvergesslichen Firmenfeiern und spannenden Teamevents.

### FAQ – Häufige Fragen zur Stelle bei Titanom

***Brauche ich Vorerfahrung mit KI-Technologie? ***

Tiefgehende Vorerfahrung ist nicht erforderlich. Wichtig ist vor allem dein Interesse am Umgang mit KI, da sie ein zentraler Bestandteil des Arbeitsalltags ist.

***Welche Qualifikationen sind erforderlich?***

Ein Studium in einem passenden Bereich (z. B. im Bereich UX.Design, Interaction Design, Medieninformatik) ist von Vorteil, aber kein Muss. Quereinsteiger:innen, die praktische Erfahrung im Bereich UX/UI Design und fundierte Kenntnisse im Design Thinking und User Centered Design mitbringen, sind bei uns ebenfalls herzlich willkommen.

***Welche Soft Skills sind wichtig?***

Wir suchen jemanden mit Motivation und Drive, Leidenschaft für UX/UI Design, einem hohen Qualitätsbewusstsein, einer Hands-On-Mentalität und der Fähigkeit, kreativ Probleme zu lösen. Zudem solltest du Lust auf deine persönliche Entwicklung haben und Lernbereit sein!

***Gibt es Möglichkeiten zur Weiterbildung?***

Ja, absolut! Bildung und Weiterentwicklung haben bei uns höchste Priorität – nicht nur extern, sondern auch intern. Wir bieten dir die Möglichkeit, an zwei-wöchentlichen Workshops zum Thema Arbeiten mit KI teilzunehmen, um dein Wissen kontinuierlich zu erweitern und dich persönlich wie fachlich weiterzuentwickeln.

***Wie sieht die Zusammenarbeit im Team aus?***

Du arbeitest eng mit Software Enginieers, Product Managern und anderen Designer:innen zusammen. Durch regelmäßige Reviews und den Austausch im Team gestalten wir die Entwicklungsprozesse gemeinsam und fördern eine offene Feedback-Kultur.

***Was macht die Arbeit bei Titanom besonders?***

Bei uns hast du die Chance, mit modernsten Technologien an innovativen Bildungsprojekten zu arbeiten, die echten Impact haben. Wir legen großen Wert auf kreative Problemlösungen, Teamarbeit und persönliche Weiterentwicklung.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
