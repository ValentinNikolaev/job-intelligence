# Heating System Supply Chain Lead

Posted: 2026-08-17T17:40:20Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**WHO WE ARE**

Proxima Fusion is Europe’s fastest-growing fusion company and the continent’s best-funded fusion player, as well as the first spin-out from the Max Planck Institute for Plasma Physics (IPP). Backed by over €650M and powered by a growing team across Munich, Zurich, and Oxford, we are developing the hardware and infrastructure needed to deliver the world’s first commercial stellarator fusion power plant.

Our concept advances the most mature fusion technology out there, the Wendelstein 7-X stellarator, through two next-generation machines: Alpha and Stellaris. Our work combines stellarator optimization, advanced computation, machine learning, and high-temperature superconducting magnets to unlock higher-performance designs that were previously out of reach.

Turning these designs into a functioning fusion power plant requires excellence and ownership across every discipline, from physics and engineering to software, manufacturing, law, and business functions.

**WHY JOIN PROXIMA FUSION**

-

**Work on a civilisation-scale problem **- Clean, baseload fusion energy is one of the few genuinely world-changing challenges, and every hire in Finance, People, or Legal directly accelerates the path to a working stellarator.

-

**Grow as fast as the company does** - With headcount set to roughly 5x in a few years and major technical milestones ahead on the path to our demo machine and first power plant, your role grows under you; today's hire is tomorrow's function lead.

-

**Tackle problems that don't exist elsewhere** - Fusion sits at a rare intersection of deep-tech R&D, industrial procurement, government relations, and venture financing, so non-tech functions face challenges no other workplace can offer.

**YOUR IMPACT**
As the Heating System Supply Chain Lead, you will join Proxima's Plasma Heating System team to drive the development and delivery of the heating systems for our net scientific gain Alpha stellarator. Drawing on deep expertise in high-power microwave and particle heating sources, you will act as the expert customer and technical integrator across the grants, partnerships, and contracts that constitute the Alpha heating system supply chain.

The experience and insight gained on Alpha will directly inform the heating system for Stellaris - Proxima's First of a Kind powerplant, targeted for operation in the 2030s. You will play a central role in capturing those learnings and translating them into the supplier strategies that will underpin a heating system capable of driving a commercial stellarator.

**WHAT YOU WILL DO**

-

Using your extensive domain expertise in one of the common heating systems used in fusion today, you will drive delivery of the high power Radio Frequency and particle sources being developed by Proxima’s partners.

-

Evaluation of vendor proposals and designs to determine the optimal path to efficiently deliver power to the Alpha stellarator.

-

Draw from and contribute to our stellarator design process by integrating the system being developed within the Proxima supply chain with the wider Alpha stellarator and the teams delivering them.

-

Interface with the Alpha project management and external partnerships teams to realize the delivery of RF components using a combination of internal and grant funding.

**WHO YOU ARE**

-

Direct experience leading the delivery and installation of a megawatt-level heating or particle accelerator system.

-

Record of driving success in projects dependent on an interplay of both vendor delivered and internally developed systems.

-

Exceptional communication and interpersonal skills, with the ability to articulate complex technical concepts clearly to non-experts.

-

Quality assurance and validation experience of high power heating systems are a plus - knowing how these parts come together is a must.

-

Experience with gyrotrons and associated components including transmission systems, launcher antennas, and RF loads.

**INTERVIEW PROCESS**

-

Recruiter Interview (30-60 min)

-

Technical Screening (30 min)

-

Technical Panel (3x60 min)

*This role sits at Level 3 of our framework, please inquire during the recruitment process for further information.

*At Proxima Fusion, our mission is bold: making limitless clean energy a reality. To get there, we need a high-performing, diverse team that brings different perspectives, challenges assumptions, and builds together with purpose. We know that diversity of thought and experience leads to better ideas, stronger execution, and a more resilient team. We don’t look at how you identify, what you look like, who you choose to worship or what ethnicity you are. We care about what you can bring to the table.*

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
