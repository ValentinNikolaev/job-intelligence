# Werkstudent:in – Talent Acquisition (m/w/d)

Posted: 2026-08-17T20:40:22Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Als **Werkstudent:in im Bereich Talent Acquisition** übernimmst du echte Verantwortung bei der Identifikation und Ansprache von Führungskräften und begleitest Kandidat:innen entlang des gesamten Recruiting-Prozesses. Du unterstützt unser Executive Recruiting für Deutschland, Polen und globale Positionen, baust belastbare Talent-Pipelines auf und sorgst dafür, dass jede:r Kandidat:in eine erstklassige Erfahrung erlebt. Dabei lernst du die vollständige Wertschöpfungskette anspruchsvoller Personalgewinnung in einem international wachsenden Unternehmen kennen.

PERGOLUX entwickelt und verkauft skandinavisch inspirierte Outdoor-Living-Produkte wie Pergolen und Gartenmöbel direkt an Endkund:innen. Mit rund 300 Mitarbeiter:innen, einem neunstelligen Umsatz und Präsenz in acht Ländern gehören wir zu den am beständigsten wachsenden Unternehmen unserer Branche.

## **Deine Aufgaben**

-

Du recherchierst und identifizierst Führungskräfte über LinkedIn, Boolean Search, interne Tools und kreative Ansprachestrategien und baust starke Pipelines über Funktionen und Märkte hinweg auf.

-

Du steuerst die Candidate Journey vom ersten Kontakt bis zur Shortlist, koordinierst Ansprache, Follow-ups und Updates und sorgst für eine durchgehend hochwertige Kandidat:innen-Erfahrung.

-

Du wirst schrittweise in erste Kandidat:innen-Screenings eingearbeitet und trägst zur Bewertung im Auswahlprozess bei, inklusive Einblick in Interviews und Assessment-Frameworks.

-

Du beobachtest Branchentrends, Talentbewegungen und Organisationsstrukturen von Wettbewerbern und erstellst daraus strategische Talent Maps.

-

Du pflegst aktuelle Pipeline-Reports und teilst relevante Erkenntnisse mit den Hiring-Teams, um datenbasierte Entscheidungen zu ermöglichen.

## **Dein Profil**

-

Du studierst HR, BWL, Psychologie oder ein verwandtes Fach (Bachelor/Master) und hast noch mindestens 2–3 Semester Studienzeit vor dir.

-

Du hast erste Erfahrung in Recruiting, HR oder anspruchsvollem Kund:innenkontakt; Interesse an Executive Search und strategischem HR sind ein Plus.

-

Du kommunizierst klar und empathisch auf sehr gutem Deutsch (C1) und fließendem Englisch, stellst durchdachte Fragen und gehst gerne auf Menschen zu.

-

Du arbeitest strukturiert und verbindlich, hältst Prozesse in Bewegung und behältst Pipelines und Fortschritte im Blick.

-

Du bewegst dich sicher in Sourcing-Plattformen, ATS-Systemen und Tabellen und gehst mit sensiblen Informationen diskret und vertrauensvoll um.

**💼 Vergütung** — 15 € pro Stunde (brutto)

🗺️ **Bürostandort** – Schlesische Str. 27 C, 10997 Berlin

**🚀 Entwicklung und Karriere** — Du wirst von erfahrenen Executive Recruitern gecoacht, übernimmst von Beginn an echte Verantwortung für deine Pipelines, arbeitest in einem internationalen, kollaborativen Team über ganz Europa hinweg und kannst mit dem Wachstum von PERGOLUX in Fach- und Führungsrollen hineinwachsen.

## **⏰ Urlaub und Flexibilität**

-

Start ab sofort

-

ca. 20 Stunden/Woche, flexibel um deine Vorlesungen und Prüfungen herum, in den Semesterferien nach Absprache mehr

-

hybrides Arbeiten mit Präsenz im Berliner Büro

-

bis zu 30 Urlaubstage, beginnend bei 27

-

eine Woche Remote-Workation pro Jahr in der EU/UK

## **🌟 Benefits und Lifestyle**

-

Jobrad / Bike-Leasing-Programm für nachhaltiges und gesundes Pendeln

-

Moderne Ausstattung und Laptops (Apple oder Windows)

-

Mitarbeiter:innen-Rabatte auf PERGOLUX-Produkte

-

Team-Kultur mit regelmäßigen Events (Sommerfest, Weihnachtsfeier, After-Work-Treffen) und Retreats

**So bewirbst du dich**

Klingt das nach deinem nächsten Schritt? Dann bewirb dich über unsere [Career Page](https://pergolux.careers/) oder finde uns auf [LinkedIn](https://www.linkedin.com/company/pergolux/posts/?feedView=all). Wir freuen uns darauf, von dir zu hören.

### PERGOLUX ist ein Arbeitgeber der Chancengleichheit. Wir begrüßen Bewerbungen von Menschen mit unterschiedlichem Hintergrund, denn es geht uns weniger darum, jedes Kästchen abzuhaken, als darum, was du einbringst!

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
