# Technical Product Owner (m/w/d)

Posted: 2026-08-17T17:29:49Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**Das sind wir**

Seit 2000 macht die [ITA Logistics Group](https://www.italogistics.com/) den Versand für Unternehmen einfacher, transparenter und effizienter. Mit unseren Plattformen [LetMeShip](https://www.letmeship.com/de/) und [ParcelParcel](https://www.parcelparcel.com/nl_EN/en-home/) können Unternehmen ihren täglichen Versand schnell vergleichen und direkt buchen. Dabei bündeln wir zahlreiche Versanddienstleister auf unseren Plattformen und kombinieren moderne Technologie mit persönlichem Service.

An mehreren Standorten in Europa arbeiten unsere Teams täglich daran, Versandprozesse nachhaltig zu vereinfachen. Wir setzen auf offene Zusammenarbeit sowie kurze Entscheidungswege und suchen Menschen, die Verantwortung übernehmen, Ideen einbringen und aktiv mitgestalten möchten.

**Deine Rolle**

Als (Technical) Product Owner (m/w/d) bist du Teil unseres Product Teams und übernimmst Verantwortung für zentrale technische Schnittstellen und Integrationen unserer Plattformen. Dein Fokus liegt insbesondere auf unseren Customer APIs, der Unified Carrier Interface (UCI) sowie perspektivisch der Unified Financial Platform (UFP) und unserer HubSpot-Integration.

Dabei bewegst du dich an der Schnittstelle zwischen Product, Engineering und Business. Du verstehst technische Zusammenhänge, übersetzt unterschiedliche Anforderungen in klare Prioritäten und sorgst gemeinsam mit unseren Teams dafür, dass unsere Integrationen zuverlässig funktionieren und sich kontinuierlich weiterentwickeln.

Du arbeitest eng mit unseren Product Ownern, unserem Technical Business Analyst, Software Engineers und Data Insights zusammen und bist gleichzeitig wichtige Ansprechperson für interne Stakeholder, Kunden, Carrier und externe Partner.

**Deine Aufgaben**

-

Du übernimmst die Verantwortung für die Roadmap unserer Customer APIs für LMS Enterprise und LMS Next und entwickelst diese strategisch weiter.

-

Du treibst die Migration unserer API-Kunden von LMS Enterprise zu LMS Next voran und identifizierst, welche Features und Carrier-Integrationen dafür benötigt werden.

-

Du bist technische Ansprechperson für unsere API-Kunden und unterstützt bei Fragen sowie bei der Analyse und Lösung von Problemen.

-

Du verantwortest gemeinsam mit internen und externen Stakeholdern die Weiterentwicklung unserer Unified Carrier Interface (UCI).

-

Du analysierst Anforderungen an Carrier-Features und Services, bereitest diese für unser Engineering auf und unterstützt QA bei der Definition relevanter Test Cases.

-

Du stehst im direkten Austausch mit unseren Carriern und klärst technische Anforderungen und Besonderheiten rund um deren Integrationen.

-

Nach dem Go-live übernimmst du die Verantwortung für unsere Unified Financial Platform (UFP) und steuerst deren Backlog und Weiterentwicklung.

-

Du behältst unsere bestehende HubSpot-Integration im Blick und priorisierst Anpassungen entsprechend neuer Business-Anforderungen und Feedbacks.

-

Über alle Themen hinweg bringst du Engineering, Business Stakeholder, Carrier und externe Partner zusammen und sorgst für klare Anforderungen, Prioritäten und Entscheidungen.

**Das bringst du mit**

-

Du verfügst über einen technischen Hintergrund, beispielsweise in Software Engineering oder Informatik, oder hast bereits mehrere Jahre an der Schnittstelle zwischen Product und Engineering gearbeitet.

-

Du bringst Erfahrung als Product Owner oder Product Manager mit – idealerweise im Umfeld von APIs, Plattformen oder technischen Integrationen.

-

Du hast ein gutes Verständnis von APIs, API Design, Versionierung und Migrationsstrategien und kannst technische Diskussionen mit unseren Engineers auf Augenhöhe führen.

-

Du kannst komplexe technische Zusammenhänge verstehen und sie für unterschiedliche Stakeholder verständlich übersetzen.

-

Du bist sicher im Stakeholder Management und kannst unterschiedliche technische und wirtschaftliche Anforderungen gegeneinander abwägen und priorisieren.

-

Mehrere parallele Workstreams und wechselnde Prioritäten bringen dich nicht aus dem Konzept – du behältst den Überblick und setzt klare Schwerpunkte.

-

Du arbeitest gerne kollaborativ und standortübergreifend mit Kollegen in Hamburg und Naarden zusammen.

-

Du interessierst dich für AI Tools und digitale Lösungen und probierst gerne neue Wege aus, um Prozesse und Workflows effizienter zu gestalten.

-

Erfahrung in Logistik, Parcel oder Freight Tech, insbesondere mit Carrier-API-Integrationen, ist ein Plus.

-

Kenntnisse rund um HubSpot bzw. CRM-Integrationen oder Finanz- und Invoicing-Systeme sind ebenfalls von Vorteil.

**Warum ITA Logistics Group?**

Bei uns erwartet dich ein Arbeitsumfeld, in dem neue Ideen ausdrücklich willkommen sind und Feedback nicht nur erlaubt, sondern erwünscht ist. Wir hinterfragen Bestehendes, arbeiten agil und entwickeln uns kontinuierlich weiter. Dazu gehört für uns auch der Einsatz moderner digitaler Tools und KI-Anwendungen, die deinen Arbeitsalltag sinnvoll unterstützen und Prozesse effizienter machen.

Deine Vorteile

-

30 Tage Urlaub

-

Flexible Arbeitszeiten & hybrides Arbeiten

-

Zeiterfassung & Überstundenausgleich

-

Deutschlandticket oder Parkplatz-Zuschuss

-

SpenditCard mit monatlich 50 € Guthaben

-

Betriebliche Altersvorsorge

-

Corporate Benefits Program

-

Workation-Möglichkeit

-

Beratung & Unterstützung durch das Fürstenberg Institut

Dein Start

Ein strukturierter Onboarding-Prozess sorgt dafür, dass du dich von Anfang an gut zurecht findest. Du lernst Schritt für Schritt unsere Teams, Prozesse und Plattformen kennen und kannst dich schnell in deine neue Rolle einbringen.

Mehr Informationen findest du auf unserer [Karriereseite.](https://www.letmeship.com/de/karriere/)

**Werde Teil der ITA Crew**

Klingt gut? Dann freut sich Franziska Linge auf deine Bewerbung (Lebenslauf reicht uns) inklusive Gehaltsvorstellung und frühestmöglichem Startdatum.

Wir begrüßen Bewerbungen aller Menschen unabhängig von Geschlecht, Herkunft, Alter, Behinderung, sexueller Orientierung oder Religion.

Bewerber:innen mit Schwerbehinderung werden bei gleicher Eignung bevorzugt berücksichtigt.

Mehr Informationen findest du unter[ www.letmeship.com](http://www.letmeship.com).

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
