# Social Media & Performance Marketing Manager (m/w/d)

Posted: 2026-08-17T21:30:34Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**Immobilien. Marketing. Performance.**

Wir bei **Kanzelsberger Immobilien** stehen für moderne Immobilienvermarktung, hochwertige Präsentation und einen professionellen Vertriebsprozess. Dabei denken wir Immobilienmarketing nicht nur in schönen Bildern und Social-Media-Posts, sondern entlang der gesamten Customer Journey – vom ersten Kontakt bis zum qualifizierten Lead.

Für den weiteren Ausbau unseres Marketings suchen wir einen **Social Media & Performance Marketing Manager (m/w/d)**, der kreative Inhalte mit datengetriebenem Marketing verbindet.

Du hast ein Gespür für guten Content, verstehst aber gleichzeitig, wie aus Reichweite echte Anfragen entstehen? Du kannst eine Kampagne nicht nur gestalten, sondern auch planen, ausspielen, messen und optimieren? Dann möchten wir dich kennenlernen.

## Aufgaben

Du übernimmst gemeinsam mit uns die Weiterentwicklung unseres digitalen Marketings und verantwortest unter anderem:

- **Social Media Management:** Planung, Erstellung und Veröffentlichung von Content für unsere Social-Media-Kanäle

- **Content Creation:** Gestaltung von Posts, Stories, Reels, Anzeigen und weiteren digitalen Werbemitteln

- **Performance Marketing:** Konzeption, Steuerung und Optimierung von Paid-Social- und Performance-Kampagnen

- **Ads & Kampagnen:** Entwicklung zielgruppenspezifischer Werbekampagnen für Immobilien, Neubauprojekte und unsere Unternehmensmarke

- **Landing Pages:** Konzeption und Gestaltung von Landing Pages mit klarem Fokus auf Conversion und Leadgenerierung

- **Customer Journey:** Entwicklung sinnvoller Customer Journeys vom ersten Werbekontakt bis zur konkreten Anfrage

- **Funnel Marketing:** Aufbau und Optimierung von Funnel-Strukturen für unterschiedliche Zielgruppen und Immobilienprodukte

- **Newsletter & E-Mail-Marketing:** Erstellung, Gestaltung und Weiterentwicklung unserer Newsletter und automatisierter E-Mail-Strecken

- **A/B-Testing:** Entwicklung und Durchführung von Tests für Creatives, Texte, Zielgruppen, Landing Pages und Kampagnen

- **Analyse & Optimierung:** Auswertung relevanter KPIs und kontinuierliche Verbesserung unserer Kampagnen

- **Marketingplanung:** Entwicklung von Kampagnenideen und Redaktionsplänen sowie deren strukturierte Umsetzung

## Qualifikation

Wir suchen weniger nach einem perfekten Lebenslauf als nach jemandem, der **Marketing versteht, kreativ denkt und Dinge eigenständig umsetzen kann.**

Idealerweise bringst du Folgendes mit:

- Erfahrung im Bereich **Social Media und Performance Marketing**

- Verständnis für **Leadgenerierung, Conversion und digitale Vertriebsprozesse**

- Erfahrung mit der Planung und Steuerung von **Social Ads**

- Kenntnisse im Aufbau von **Landing Pages, Funnels und Customer Journeys**

- Erfahrung im **Newsletter- und E-Mail-Marketing**

- Sicherer Umgang mit **Canva**

- Erfahrung mit **CapCut** und der Erstellung bzw. Bearbeitung von Reels und Kurzvideos

- gutes Gespür für Gestaltung, Bildsprache, Typografie und moderne Markenkommunikation

- Verständnis für Kennzahlen wie CPC, CPL, CTR und Conversion Rate

- Erfahrung mit **A/B-Tests** und der datenbasierten Optimierung von Kampagnen

- sehr gute Deutschkenntnisse und ein sicheres Gefühl für Texte und Werbebotschaften

- strukturierte, eigenständige und lösungsorientierte Arbeitsweise

**Was uns besonders wichtig ist**

Wir suchen jemanden, der nicht nur Aufgaben abarbeitet.

Du solltest Lust darauf haben, **Ideen einzubringen, Kampagnen selbst zu entwickeln und Verantwortung für deren Erfolg zu übernehmen.**

Ein neues Immobilienprojekt kommt auf den Markt? Dann möchten wir gemeinsam überlegen: Wer ist die Zielgruppe? Wie sprechen wir sie an? Welche Creatives benötigen wir? Wie sieht die Landing Page aus? Welcher Funnel steckt dahinter? Und wie verwandeln wir Aufmerksamkeit möglichst effizient in qualifizierte Interessenten?

Genau an dieser Schnittstelle zwischen **Kreativität, Marke, Daten und Vertrieb** sollst du dich bei uns bewegen.

## Benefits

**Was dich bei uns erwartet**

- ein modernes und wachsendes Immobilienunternehmen

- abwechslungsreiche Immobilien und Neubauprojekte

- viel Gestaltungsspielraum und kurze Entscheidungswege

- die Möglichkeit, unser digitales Marketing aktiv mit aufzubauen und weiterzuentwickeln

- eigenverantwortliches Arbeiten statt starrer Konzernstrukturen

- ein modernes Arbeitsumfeld in Erding

- hochwertige Immobilienprojekte und entsprechend viel Potenzial für kreativen Content

- direkte Zusammenarbeit mit Geschäftsführung und Vertrieb

- Raum für neue Ideen, Tools und Marketingansätze

- eine langfristige Perspektive in einem wachsenden Unternehmen

**Klingt nach dir?**

Dann möchten wir dich kennenlernen.

Schick uns gerne deinen Lebenslauf und – falls vorhanden – Beispiele bisheriger Arbeiten, Kampagnen, Social-Media-Accounts oder Projekte.

**Kanzelsberger Immobilien**

Erding

Wir freuen uns auf deine Bewerbung.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
