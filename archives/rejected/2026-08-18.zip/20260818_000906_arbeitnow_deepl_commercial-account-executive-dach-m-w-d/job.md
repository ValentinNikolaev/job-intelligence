# Commercial Account Executive | DACH (m/w/d)

Posted: 2026-08-17T20:40:13Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

# **Meet DeepL**

DeepL is a global AI product and research company focused on building secure, intelligent solutions to complex business problems. Over 200,000 business customers and millions of individuals across 228 global markets today trust DeepL's Language AI platform for human-like translation, improved writing and real-time voice translation.
Founded in 2017 by CEO Jaroslaw “Jarek” Kutylowski, DeepL now has around 1,000 passionate employees and is supported by world-renowned investors including Benchmark, IVP, and Index Ventures.

Our goal is to become the global leader in trusted, intelligent AI technology, building products that drive better communication, foster connections, and create a meaningful impact. To achieve this, we need talented people like you to join our journey. If you’re ready to shape the future of AI and grow your career in a fast-moving, purpose-driven environment, DeepL is your next destination.

## **What sets us apart**

What sets us apart is our blend of cutting-edge AI technology, meaningful work, and a culture where people truly thrive. We’re a team of innovators, researchers, and creators driven by a shared purpose to unlock human potential by making work simpler, smarter, and more connected.

When we share what it’s like to work at DeepL, the reactions are overwhelmingly positive. This might be because of our technology that helps millions of people and businesses communicate and work better every day, or because of the trust, curiosity, and care that shape our culture.

What we know for sure is this: being part of DeepL means joining a team dedicated to innovation, growth, and well-being. Discover more about life at DeepL on[LinkedIn](https://www.linkedin.com/company/deepl/),[Instagram](https://www.instagram.com/deepl_official/), and our [Blog](https://www.deepl.com/en/blog).

## **Meet the team behind this journey**

We're looking for an experienced Commercial Account Executive to drive DeepL's continued expansion and market leadership in the DACH region (Germany, Austria, Switzerland). This is an exceptional opportunity to leverage DeepL's strong brand presence and market position in German-speaking countries, building on our success while capturing new business opportunities across this dynamic market. You'll be responsible for managing all aspects of the sales process with a primary focus on landing new business deals and strengthening our market dominance.

This role offers the chance to work in a region where DeepL is already recognized as a market leader. You'll be building on established relationships and expanding our footprint with new commercial clients (up to 500 employees), seeing the direct impact of your work as DeepL solidifies its position as the go-to translation solution in the DACH market. If you're energized by the prospect of driving growth in a strong market and want to be part of our continued success story, this role is for you.

## **Your responsibilities**

**Expand our DACH market leadership **

-

You will leverage DeepL's established market-leading position to present our translation service to new clients and deepen relationships with existing partners across the German-speaking business landscape.

-

Expand DeepL's footprint in the DACH region, establishing relationships with key accounts and driving growth in this strategically important market.

**Drive business development**

-

Become an ambassador for DeepL's products and an expert on DACH customers' needs, troubleshooting and rapidly resolving inquiries.

-

As a trusted partner to potential new business and incoming customers, you will qualify and convert leads and manage the entire sales cycle.

-

Build a robust pipeline of new business opportunities, pursuing upselling and cross-selling opportunities as relationships mature.

-

Respond to inbound prospects and customers, managing a high volume of opportunities from qualification to close.

**Achieve and exceed targets**

-

Strive to meet and exceed monthly activity, pipeline, and revenue goals.

-

Forecast and track all opportunities and customer details including use cases, purchase timeframes, and next steps.

-

Work closely with our diverse, international, and welcoming teams from SDR to Marketing to ensure continued market success.

## **Qualities we look for**

**Experience and expertise**

-

Proven full-cycle sales experience, with a track record of growing markets or territories and expanding existing business.

-

Expertise in software sales - especially SaaS - preferred.

-

Entrepreneurial mindset with the ability to thrive in dynamic environments and identify new growth opportunities.

**Skills and attributes **

-

Exceptional organisation, presentation, and communication skills (both verbal and written).

-

You feel at home in a fast-paced environment: you're able to shift priorities and adapt to dynamic situations.

-

You're excited by the challenge of driving growth and expanding our market presence.

-

You enjoy being part of a team and thrive by supporting your colleagues and collaborating with cross-functional teams.

**Language requirements **

-

Fluency in German and English is essential

## **What we offer**

-

**Diverse and internationally distributed team**: joining our team means becoming part of a large, global community with people of more than 90 nationalities. We're more than just colleagues; we're a group of professionals with a shared mission to connect diverse cultures. Our global presence is growing–we've doubled in size nearly every year, with our employees based in the UK, Germany, the Netherlands, Poland, the US, and Japan, and we continue to expand our network.

-

**Open communication, regular feedback**: as a language-focused company, we value the importance of clear, honest communication. We value smooth collaboration, direct and actionable feedback, and believe that leading with empathy and growth mindset makes us better together.

-

**Hybrid work, flexible hours**: we offer a hybrid work schedule, with team members coming into the office twice a week. This allows you to engage directly with your team and experience the unique energy of our workspace, while still enjoying the flexibility and comfort of working from home. With flexible working hours and trust in your productivity, we are in sync with your team’s general locations and time zones to foster effective and seamless collaboration.

-

**Regular in-person team events**: we bond over vibrant events that are as unique as our team, from local team and business unit gatherings, to new-joiner onboardings, to company-wide events that bring us all together–literally.

-

**Monthly full-day hacking sessions**: every month, we have Hack Fridays, where you can spend your time diving into a project you're passionate about and get the opportunity to work with other teams–we value your initiatives, impact, and creativity.

-

**30 days of annual leave**: we value your peace of mind. With 30 days off (excluding public holidays) and access to mental health resources, we make sure you're as strong mentally as you are professionally.

-

**Competitive benefits**: just as our team spans the globe, so does our benefits package. We've crafted it to reflect the diversity of our team and tailored it to align with your unique location, to ensure you feel supported every step of the way.

If this role and our mission resonate with you, but you're hesitant because you don't check all the boxes, don't let that hold you back. At DeepL, it's all about the value you bring and the growth we can foster together. Go ahead, apply—let's discover your potential together. We can't wait to meet you!

## **We are an equal opportunity employer**

You are welcome at DeepL for who you are - we appreciate authenticity here. Our product is for everyone, and so is our workplace. The more voices we have represented and amplified in our business, the more we will all succeed, contribute, and think forward! So bring us your personal experience, your perspectives, and your background. It’s in our diversity that we will find the power to break down language barriers in the world.

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
