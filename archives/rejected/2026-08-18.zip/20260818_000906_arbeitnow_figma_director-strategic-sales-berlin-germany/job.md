# Director, Strategic Sales (Berlin, Germany)

Posted: 2026-08-17T17:55:34Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Figma is growing our team of passionate creatives and builders on a mission to make design accessible to all. Figma’s platform helps teams bring ideas to life—whether you're brainstorming, creating a prototype, translating designs into code, or iterating with AI. From idea to product, Figma empowers teams to streamline workflows, move faster, and work together in real time from anywhere in the world. If you're excited to shape the future of design and collaboration, join us!

We are looking for a Director, Strategic Sales to join our team of creatives, engineers, marketers, and business leaders. You aren't the typical sales leader, and we aren't the typical design tool company. At Figma, we challenge conventional thinking and expect you to bring that same mindset. With this role, you'll help shape a sales org still early in its growth trajectory. You'll lead a team focused on our largest clients in driving meaningful relationships that add value to the customer experience and revenue to our bottom line.

Figma is growing and moving fast. Our next team member will be adaptable, comfortable embracing change, a true team-player, and love working with our growing footprint of Fortune 1000 customers. You won't be alone! Figma has an incredible team and you'll work closely with other groups including Support, Design, Engineering, Product Marketing, and Community. As our Director, Strategic Sales, you will lead a team of Strategic Account Executives in Berlin responsible for continuing the growth of our top tier accounts.

#### **What you'll do at Figma:**

- Drive the development of strategic sales roadmaps, prioritizing initiatives, and goals to maximize revenue generation

- Present and position our products effectively to C-level executives. Participate in customer and prospect meetings, coaching your team through live selling opportunities

- Monitor market trends, competitive landscapes, and industry developments to inform strategic sales decisions and adapt strategies as needed

- Collaborate closely with the marketing and product teams to ensure they understand and can service the needs of the market and members in the region

- Be passionate about career development and coaching. Build a diverse team, create and foster an environment of belonging

- Lead weekly forecast meetings and mentor the Sales team on strategies to help exceed their goals. Bring strong sales excellence, process and methodology as we expand and scale the business

#### **We'd love to hear from you if you have:**

- 7+ years of sales experience (preferably within SaaS) with 3+ years of management experience

- Experience managing strategic accounts and understanding of our technical and competitive landscape

- Track record of adapting strategy and execution as business needs evolve

- Exceptional coaching, writing, discovery and presentation skills with a proven track record of leading successful and consistent sales team

- Track record of increasing customer satisfaction and building lasting customer relationships

At Figma, one of our values is Grow as you go. We believe in hiring smart, curious people who are excited to learn and develop their skills. If you’re excited about this role but your past experience doesn’t align perfectly with the points outlined in the job description, we encourage you to apply anyways. You may be just the right candidate for this or other roles.

At Figma we celebrate and support our differences. We know employing a team rich in diverse thoughts, experiences, and opinions allows our employees, our product and our community to flourish. Figma is an [equal opportunity workplace](https://www.eeoc.gov/sites/default/files/2022-10/EEOC_KnowYourRights_screen_reader_10_20.pdf) - we are dedicated to equal employment opportunities regardless of race, color, ancestry, religion, sex, national origin, sexual orientation, age, citizenship, marital status, disability, gender identity/expression, veteran status**, **or any other characteristic protected by law. We also consider qualified applicants regardless of criminal histories, consistent with legal requirements.

We will work to ensure individuals with disabilities are provided reasonable accommodation to apply for a role, participate in the interview process, perform essential job functions, and receive other benefits and privileges of employment. If you require accommodation, please reach out to

Examples of accommodations include but are not limited to:

- Holding interviews in an accessible location

- Enabling closed captioning on video conferencing

- Ensuring all written communication be compatible with screen readers

- Changing the mode or format of interviews

To ensure the integrity of our hiring process and facilitate a more personal connection, we require all candidates keep their cameras on during video interviews. Additionally, if hired you will be required to attend in person onboarding.

By applying for this job, the candidate acknowledges and agrees that any personal data contained in their application or supporting materials will be processed in accordance with [Figma's Candidate Privacy Notice](https://www.figma.com/legal/candidate-privacy-notice/).

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
