# Senior Machine Learning Engineer: Search Quality

Posted: 2026-08-17T20:40:18Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

## **About us**

Launched in 2019, Constructor is an AI-first ecommerce search and discovery platform that helps shoppers find the right products at the right time and enables leading global e-commerce brands to drive meaningful revenue and conversion gains.

As a Senior Machine Learning Engineer in the Search Quality team, you will improve the e-commerce experience for hundreds of millions of users across the world by building the systems that power relevance for global retailers - from fashion and grocery to electronics and hardware.

The mission is to measure search quality, push it higher, and catch degradations before the user does. You will achieve this through a blend of fine-tuned LLMs for relevance judgment, real-time models, and deep offline analysis of query logs.

##
**About the Job**

Your primary focus will be relevance evaluation and quality improvements:

-

LLM-based evaluation. We fine-tune our own models to assess relevance. This involves teaching the model to understand query intent, represent items from messy catalog data, and align model judgments with real user behavior.

-

Real-time quality in production. Reranking, filtering, signal computation. Latency is a strict requirement, so quality vs speed tradeoff is constant.

-

Automated quality monitoring and agentic insights. Pipelines to detect degradations and find underperforming patterns. Agent-based systems that generate actionable recommendations for the product data and search configurations.

##
**What makes this interesting**

-

Multi-domain, multi-language, at scale - 40+ languages, 20+ domains. The models need to generalize across all of them - without per-customer rules or overrides.

-

No universal ground truth. A grocery retailer and a fashion retailer may have different perceptions on what "relevant" means.

-

Efficiency at scale. Optimizing and scaling LLM inference across our entire customer base.

##
**Requirements**

-

4+ years shipping production ML systems

-

Experience with search, information retrieval, or recommendation systems

-

Hands-on experience with fine-tuning, evaluation frameworks, and scaling LLM deployments

-

Strong Python and PyTorch. Fluency in SQL and data orchestration tools (Spark, Airflow)

-

Experience designing and running A/B tests to validate model impact

-

Excellent English communication skills

-

Experience collaborating in cross-functional teams (ranking, product, data engineering)

##
**Benefits**

-

🧠 Work with smart and empathetic people who will help you grow and make a meaningful impact.

-

🎉 Regular team offsite events to connect and collaborate.

-

🌎 Fully remote team - choose where you live.

-

🏝️ Unlimited vacation time - we strongly encourage all of our employees take at least 3 weeks per year.

-

🛋️ Work from home stipend! We want you to have the resources you need to set up your home office.

-

💻 Apple laptops provided for new employees.

-

🧑‍🎓 Training and development budget for every employee, refreshed each year.

-

👪 Maternity & Paternity leave for qualified employees.

-

💵 Base salary: $80k–$120K USD, depending on knowledge, skills, experience, and interview results

-

📈 Stock options - offered in addition to the base salary

##
**Diversity, Equity, and Inclusion at Constructor**

At [Constructor.io](http://Constructor.io) we are committed to cultivating a work environment that is diverse, equitable, and inclusive. As an equal opportunity employer, we welcome individuals of all backgrounds and provide equal opportunities to all applicants regardless of their education, diversity of opinion, race, color, religion, gender, gender expression, sexual orientation, national origin, genetics, disability, age, veteran status or affiliation in any other protected group.

*Studies have shown that women and people of color may be less likely to apply for jobs unless they meet every one of the qualifications listed. Our primary interest is in finding the best candidate for the job. We encourage you to apply even if you don’t meet all of our listed qualifications.*

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
