# Data Scientist

Posted: 2026-08-17T17:55:24Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Global Dimensions is currently seeking a **Data Scientist** for a position in **Stuttgart, Germany**, to support mission-critical data analysis and intelligence requirements.

**Essential Job Functions:**

Perform data cleaning, preprocessing, integration, and quality assurance to ensure data accuracy and usability.

Conduct data analysis and prepare datasets for visualization and reporting.

Develop dashboards and complex data visualizations using tools such as Tableau and Power BI.

Perform routine data quality checks and identify data inconsistencies or anomalies.

Apply statistical methods, hypothesis testing, and machine learning techniques to support analytical requirements.

Apply AI/ML models to analyze structured and unstructured data.

Utilize Activity-Based Intelligence (ABI) tools and tradecraft to support mission requirements.

Communicate analytical findings and technical information clearly to stakeholders.

**Required Skills: **

Due to the sensitivity of customer related requirements, U.S. Citizenship is required.

Bachelor's degree in Data Science, Data Engineering, Information Technology, Computer Science, Information Science, or a related field from an accredited institution; **or**

Minimum **7 years of data science support experience**, with a portion of the experience occurring within the last two years.

Experience with **Python** and automated methodologies.

Knowledge and experience with hypothesis testing, statistical analysis, machine learning, and training solutions.

Knowledge of communication tradecraft techniques.

Experience utilizing **ABI tools and tradecraft**.

Experience with data preprocessing, integration, quality assurance, and visualization.

**Desired Skills: **

Previous **Intelligence Community (IC)** experience.

Experience developing dashboards using **Tableau and/or Power BI**.

Experience applying AI/ML techniques to unstructured data analysis.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
