# Senior Sales Manager HR-Services (m/w/d)

Posted: 2026-08-17T23:09:46Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**Was kommt auf Dich zu?**

- Eigenverantwortliche Akquisition von Neukunden für unsere Dienstleistungen in den Bereichen **Executive Search, Recruiting, Interim Management und HR-Outsourcing** in der DACH-Region.
- Identifikation, Ansprache und Gewinnung von Entscheidern auf C-Level sowie auf Geschäftsführungs-, HR- und Personalleitungsebene.
- Entwicklung individueller Vertriebskonzepte und Beratung von Kunden zu passgenauen Lösungen entlang ihrer HR-Strategie und Personalbedarfe.
- Steuerung des gesamten Sales Cycles – von der Lead-Generierung über die Bedarfsanalyse und Angebotserstellung bis zum Vertragsabschluss.
- Durchführung von Präsentationen, Workshops und Vertragsverhandlungen auf Managementebene.
- Aufbau und Pflege eines nachhaltigen Netzwerks aus Kunden, Multiplikatoren und Kooperationspartnern.
- Enge Zusammenarbeit mit unseren Teams aus Executive Search, Recruiting, Interim Management und HR Consulting, um optimale Kundenlösungen zu entwickeln und Projekte erfolgreich zu übergeben.
- Entwicklung langfristiger Kundenbeziehungen sowie Identifikation von Cross- und Upselling-Potenzialen innerhalb unseres HR-Serviceportfolios.
- Verantwortung für die Erreichung ambitionierter Umsatz- und Wachstumsziele.

**Was solltest Du mitbringen?**

- Erfolgreich abgeschlossenes Studium im Bereich Wirtschaft, Personalmanagement, Vertrieb oder eine vergleichbare Qualifikation.
- Mehrjährige erfolgreiche Vertriebserfahrung im B2B-Dienstleistungsumfeld, idealerweise in den Bereichen **Executive Search, Personalberatung, Recruiting, Personaldienstleistungen, HR-Outsourcing oder Interim Management**.
- Nachweisbare Erfolge im Vertrieb erklärungsbedürftiger Dienstleistungen und im Aufbau nachhaltiger Kundenbeziehungen.
- Fundiertes Verständnis moderner HR-Prozesse sowie der Herausforderungen in der Gewinnung, Entwicklung und Bindung von Fach- und Führungskräften.
- Erfahrung im Vertrieb beratungsintensiver Lösungen sowie ausgeprägte Abschlussstärke und Hunter-Mentalität.
- Souveränes Auftreten und Kommunikationsstärke auf Management- und C-Level.
- Eigenverantwortliche, strukturierte und ergebnisorientierte Arbeitsweise sowie ausgeprägtes unternehmerisches Denken.
- Verhandlungssichere Deutsch- sowie gute Englischkenntnisse.
- Reisebereitschaft innerhalb der DACH-Region.

**Was kannst Du von uns erwarten?**

- Eine partnerschaftliche Arbeitsatmosphäre auf Augenhöhe, begleitet von einem hervorragenden Zusammenhalt unter Kollegen
- Flache Hierarchien in einem professionellen und interkulturell geprägten Unternehmensumfeld
- Ein attraktives Fixgehalt sowie variables Gehaltspaket. Ergänzt um betriebliche Altersvorsorge und „Benefitprogramm“
- Gezielte und individuelle Entwicklungs- und Weiterbildungsmöglichkeiten
- Bereitstellung von professionellem IT-Equipment und Mobiltelefon
- Attraktiver Firmensitz direkt am Rhein, im Herzen von Düsseldorf
- Flexibles Arbeitsmodus
- Mitarbeiterveranstaltungen und Familienevents
- E-Bike-Leasing mit Rundumschutz-Paket für bis zu zwei Räder

**Kontakt**

Herr Andreas Miltzner
Cecilienallee 6-7
40474 Düsseldorf
0152 227 227 59
Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
