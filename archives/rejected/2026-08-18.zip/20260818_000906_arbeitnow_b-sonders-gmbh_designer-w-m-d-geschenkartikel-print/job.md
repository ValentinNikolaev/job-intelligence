# Designer (w/m/d) Geschenkartikel & Print

Posted: 2026-08-17T19:30:27Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

***Wir sind b.sonders – wir zaubern anderen ein Lächeln in Gesicht!***

Seit unserer Gründung im Jahr 2008 entwickeln wir Geschenkartikel, die mit viel Herz und Liebe zum Detail gestaltet sind.

Dazu gehören liebevoll illustrierte Grußkarten, hochwertige Geschenkideen, edle Papeterie, charmante Verpackungen und innovative Soundprodukte.

Unser Ziel ist es, Freude zu bereiten und besondere Momente zu schaffen.

Unsere Stärke liegt in kreativen Designideen, die Emotionen wecken und Menschen verbinden. Von der ersten Idee bis zum fertigen Produkt begleiten wir unsere Kunden mit einem eingespielten Team aus den Bereichen Design und Produktentwicklung sowie erfahrenen Produktionspartnern.

Unsere Mission ist es, Glücksmomente zu gestalten, denn das Schönste auf der Welt ist es, anderen eine Freude zu machen.

Für unser 13-köpfiges Team und unser neues Büro suchen wir

**Designer (w/m/d) Geschenkartikel & Print**

## Aufgaben

Du gestaltest mit Leidenschaft und Kreativität einzigartige Geschenkartikel, Grußkarten und hochwertige Papeterieprodukte. Dabei entwickelst du neue Ideen, setzt Designs um und arbeitest eng mit der Reinzeichnung und Produktentwicklung zusammen, um innovative und ansprechende Produkte zu realisieren, die anderen ein Lächeln zaubern.

Dein Kernaufgabenbereich im Überblick:

- Entwicklung von kreativen Ideen und Konzepten für neue Geschenkartikel und Grußkartenserien

- Gestaltung von Printdesigns in unterschiedlichen Stilrichtungen

- Vorbereitung der Entwürfe für die Reinzeichnung

- Recherche von Trends, Bildwelten und gestalterischen Inspirationen

- Mitwirkung bei der Erstellung von Prototypen und Mustern in enger Zusammenarbeit mit der Produktentwicklung

- Bildbearbeitung und visuelle Aufbereitung von Designideen zur internen Abstimmung

## Qualifikation

- **Berufserfahrung:** Du hast bereits Erfahrungen im Bereich Design gesammelt, sei es im Studium, durch Praktika oder im Job. Entscheidender als dein Werdegang sind deine kreative Stärke und Begeisterung für gutes Design.

- **Branchenbezug:** Erste Berührungspunkte mit Grußkarten, Papeterie oder Geschenkartikeln sind Voraussetzung, sei es durch Berufserfahrung oder durch eigene kreative Projekte. Wenn du Freude an der Gestaltung dieser Produkte hast, bist du bei uns richtig.

- **Ausbildung:** Du hast ein Studium im Bereich Kommunikationsdesign, Grafikdesign, Visuelle Kommunikation oder Mediengestaltung abgeschlossen oder eine Ausbildung, z. B. als Mediengestalter/in, Gestaltungstechnische/r Assistent/in, Produktdesigner/in oder Medientechnologe/-in Druck, gemacht. Alternativ bringst du entsprechende praktische Berufserfahrung mit.

- **Arbeitsweise:** Du arbeitest selbstständig, strukturiert und zuverlässig, findest kreative Lösungen und nutzt Inspirationsquellen gezielt für deine Ideen. Zudem übernimmst du gerne Verantwortung für deine Projekte.

- **Teamarbeit:** Du fühlst dich in einem kleinen, familiären Team wohl und bist gerne ein wichtiger Teil davon.

- **Sprachen:** Du verfügst über sehr gute Deutschkenntnisse und idealerweise gute Englischkenntnisse.

## Benefits

- **Flexible Arbeitszeiten:** In Abstimmung kannst du deine Arbeitszeiten, im Rahmen unserer Kernarbeitszeit zwischen 09:00 und 16:00 Uhr, flexibel gestalten.

- **Unsere Arbeitsweise:** Wir sind ein kleines, eingespieltes Team und arbeiten bewusst gemeinsam vor Ort. Der direkte Austausch macht uns kreativ und erfolgreich, deshalb ist Homeoffice bei uns nicht vorgesehen.

- **Kreative Freiheit:** Du bekommst Raum für deine Ideen, Eigenverantwortung und die Möglichkeit, deine Handschrift in unsere Produkte einzubringen.

- **Unsere Arbeitsweise:** Wir sind ein kleines, eingespieltes Team mit Leidenschaft für Gestaltung, das effizient, familiär und auf Augenhöhe zusammenarbeitet.

- **Wertschätzung:** Wir leben eine offene Feedbackkultur und feiern Erfolge gemeinsam – ob bei lockeren Mittagspausen oder inspirierenden Teamevents.

- **Individuelle Entwicklung:** Wir fördern deine Stärken und bieten dir die Chance, dich mit uns fachlich und persönlich weiterzuentwickeln – ganz ohne steile Hierarchien.

- **Dein Arbeitsplatz:** Dich erwartet ein modernes, hochwertig eingerichtetes Büro mit kreativer Atmosphäre in zentraler Lage mit Anbindung an den öffentlichen Nahverkehr.

- **Attraktives Vergütungspaket:** Wir bieten dir eine unbefristete und sichere Anstellung mit einem attraktiven Gehaltspaket.

DU WILLST AUCH B.SONDERS SEIN?

Dann bewirb dich jetzt unkompliziert mit deinem Lebenslauf.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
