# Working Student Brand & Communication Spain (m|w|d)

Posted: 2026-08-17T15:20:15Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Great social content feels local, relevant and made for the platform - not simply adapted for it. For our Spanish audience, that means spotting the right trends, turning ideas into content and knowing what makes people stop scrolling.

You will support our Spanish brand activities by creating and publishing social media content, particularly short-form video. You will get hands-on experience across the full content process, from the first idea to filming, editing, publishing and learning from the results.

### About your new role

-

You plan and create social media content for the Spanish market, developing ideas around current trends, cultural moments, audience interests and brand priorities.

-

You film, cut and edit short-form videos and create supporting assets such as stories, static posts, captions and subtitles.

-

You help manage the social media content calendar, publish assigned content on time and ensure it follows our visual identity, tone of voice and quality standards.

-

You monitor comments and messages, respond in the appropriate tone and escalate relevant topics when necessary.

-

You track basic content performance, monitor social media trends and competitors in Spain and use what you learn to improve upcoming content. When an idea turns into content that earns stronger engagement, you can see the direct effect of your work.

### Skills & Requirements

#### Must-have

-

You are a native Spanish speaker and can communicate confidently in English or German at B2 level.

-

You have initial practical experience creating social media content and editing video, for example with Canva and CapCut or comparable tools.

-

You are comfortable writing social media copy and working with common office and content management tools.

-

You take ownership and independently drive topics forward.

#### Nice-to-have

-

You bring intrinsic motivation and a proactive mindset.

### **At idealo you can expect**

-

**You want to further your education?** We take your personal development goals seriously and, in addition to our idealo Learning Hub, eLearning offerings (e.g., Udemy), coaching & mediation, we also offer you the opportunity to benefit individually from additional learning and development budget.

-

**And what about the office? **Our office in the heart of Berlin offers free organic breakfast, excellent free lunch (vegan and vegetarian), as well as free coffee, lemonades and after-work beer, in addition to the "standard foosball". It also has a fabulous rooftop terrace with view of the whole of berlin where you can network with colleagues from our group of companies.

-

**In need of additional support in any areas of your life?** We offer free counseling and support in all areas of life (professional, private, family, health, etc.) in cooperation with the [pme-Familienservice](https://mein.familienservice.de/en/).

-

**Want to keep yourself fit?** We offer many different fitness and sports options, such as an Urban Sports or Gympass membership, to suit your personal needs.

-

**And what else is there?** Of course, success must be celebrated! In addition to team events, you can also expect big company events and other moments of organized connection with others in the company and your team throughout the year!

#LI-NY1

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
