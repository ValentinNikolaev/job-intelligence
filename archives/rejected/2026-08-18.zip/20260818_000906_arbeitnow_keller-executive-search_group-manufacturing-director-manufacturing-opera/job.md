# Group Manufacturing Director - Manufacturing Operations

Posted: 2026-08-17T17:20:13Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Our client manufactures plumbing, heating, air-conditioning, and refrigeration (PHAR) fittings and valves on a global scale. Operating from multiple production sites across Europe, the company is widely recognised for its engineering excellence and the reliability of what it makes.

The successful candidate will assume complete accountability for the operational, financial, and strategic results of the group's European manufacturing facilities, while also coordinating closely with its Asian manufacturing partners. Reporting into the Group CEO, you will work primarily to achieve or exceed budgeted performance at every plant, all the while keeping operations safe, efficient, competitive on cost, and centred on the customer.

Pitched at senior operational leadership level, the role will appeal to a professional grounded in engineering and manufacturing who has genuinely led across several sites. Running an international operation of this scale takes considerable energy and organisation, and the post carries frequent business reviews alongside regular travel throughout Europe and Asia.

**Responsibilities:**

- Building and developing the manufacturing leadership team, taking in succession planning and employee engagement
- Holding accountability for manufacturing costs at every site and driving ongoing gains in cost competitiveness
- Keeping each facility on track to hit its budgeted operational, quality, and safety targets
- Guaranteeing that products reliably meet both customer and regulatory quality expectations
- Collaborating with Commercial, Sales, Supply Chain, and the Executive Leadership team on cross-functional improvement work
- Upholding a safe working environment and complete regulatory and environmental compliance at all locations
- Reporting on performance to the CEO each month, flagging significant risks quickly, and keeping a rolling 12-month manufacturing improvement plan in place
- Planning, justifying, carrying out, and tracking capital investment projects across the manufacturing footprint
- Working hand in hand with the Supply Chain Director to meet customer service commitments and deliver the approved production plan
- Driving alignment, performance, and dependable supply from Asian manufacturing operations, with regular supplier performance reviews

This role can be based in Wetzlar or Attendorn, Germany, Cordoba, Spain, or Poznan, Poland, and involves extensive international travel across Europe and Asia.

**Requirements**

- Experience running large operational budgets and manufacturing P&L
- A track record you can evidence of raising productivity, cost, quality, safety, and profitability through Lean manufacturing, operational excellence, and continuous improvement
- Fluent spoken and written English, backed by excellent communication skills
- Proven leadership of international, multi-site manufacturing across Europe, with ownership of operational, financial, and strategic performance
- Familiarity with the plumbing, heating, air-conditioning, and refrigeration (PHAR) sector, valves, fluid control, or comparable industrial or automotive Tier 1 manufacturing is useful, though not a prerequisite
- An engineering degree (Mechanical, Manufacturing, Industrial, or equivalent) is essential; an MBA, postgraduate business qualification, or Lean Six Sigma Black Belt would strengthen an application
- A commercially minded leader who can influence executives and lead cross-functional collaboration across Manufacturing, Supply Chain, Sales, and Finance
- The willingness and capacity to undertake extensive international travel across Europe and Asia
- Hands-on experience with capital investment projects, spanning justification, execution, and post-investment review
- Experience presenting operational and financial performance to CEO or Board-level audiences
- Experience coordinating with manufacturing partners or suppliers outside your home region, ideally including Asian manufacturing operations
- Strong people development and leadership skills, including a history of building succession plans for critical roles

**Benefits**

- Base salary range €120,000 – €150,000
- Annual bonus scheme, incremental up to a maximum of 40% of base salary, based on budget being reached and above
- Paid leave ranges from 21 to 30 days annually depending on location

Keller is a recruitment agency that provides services to clients ranging from startups and non profits to multinational corporations. Keller emphasizes ethical search processes, attentive candidate care, and leadership placements that support long-term client outcomes.

To learn more about the firm and about our candidate services - please visit
[](https://www.kellerexecutivesearch.com/executive-recruitment-headhunters-united-kingdom-uk/)[](https://www.kellerexecutivesearch.com/executive-recruitment-headhunters-poland-warsaw-and-krakow/)[Executive Search Germany:Headhunter and Recruitment Services in Germany](https://www.kellerexecutivesearch.com/executive-recruitment-headhunters-germany-berlin/)

**Equal Employment Opportunity and Non-Discrimination Policy **

**Equal Employment Opportunity Statement **

Both Keller Executive Search and our clients are Equal Opportunity Employers. For all positions, whether with Keller Executive Search or our clients, qualified applicants will receive consideration for employment without regard to race, skin color, religion, sex, sexual orientation, gender identity, gender expression, nationality, age, disability, genetic information, or any other characteristic protected under EU law and the laws of the respective EU member states.

**Commitment to Diversity **

Keller Executive Search and its clients are committed to fostering a diverse and inclusive work environment where all individuals are valued and respected. We recognize and celebrate the cultural diversity across EU member states.

**Reasonable Accommodations **

Both Keller Executive Search and our clients are committed to providing reasonable accommodations to individuals with disabilities, in accordance with EU Directive 2000/78/EC and national laws of EU member states. We engage in an interactive process to determine effective, reasonable accommodations.

**Compensation Information **

For client positions, compensation information will be provided in accordance with applicable EU and national laws. When required by law, salary information will be included in job postings or provided during the recruitment process. We are committed to pay transparency and equal pay for equal work, in line with EU Directive 2006/54/EC and national laws on pay equity.

**Compliance with Laws **

Both Keller Executive Search and our clients comply with EU laws, directives, and regulations, as well as national laws of EU member states governing non-discrimination in employment. This policy applies to all employment terms and conditions, including recruiting, hiring, placement, promotion, termination, layoff, recall, transfer, leaves of absence, compensation, and training.

**Workplace Harassment **

Both Keller Executive Search and our clients expressly prohibit any form of workplace harassment based on any protected characteristic under EU law and the laws of EU member states. This includes, but is not limited to, harassment based on race, ethnic origin, religion, sex, sexual orientation, gender identity or expression, nationality, age, disability, or genetic information.

**Data Protection and Privacy **

We process personal data in compliance with the General Data Protection Regulation (GDPR) and applicable national data protection laws. For more information about how we collect and process personal data for recruitment and employment purposes, please review our Privacy Policy at [www.kellerexecutivesearch.com](http://www.kellerexecutivesearch.com/).

**Pay Equity **

Both Keller Executive Search and our clients are committed to pay equity and conduct periodic pay equity analyses in accordance with applicable EU and national laws.

**Working Time and Leave **

We comply with EU Directive 2003/88/EC concerning certain aspects of the organization of working time, as well as national laws of EU member states regarding working hours, rest periods, and leave entitlements.

**Health and Safety **

We are committed to providing a safe and healthy work environment in accordance with EU Framework Directive 89/391/EEC on Safety and Health at Work and relevant national laws of EU member states.

**Works Councils and Employee Representation **

We respect the rights of employees to form and join works councils and other forms of employee representation in accordance with EU Directive 2009/38/EC and national laws of EU member states.

**Country-Specific Declarations **

While this policy provides a general framework applicable across the EU, it's important to note that specific employment laws can vary significantly between EU member states. To ensure full compliance with local regulations, we make the following provisions:

- Local Law Compliance: In addition to EU-wide regulations, we comply with all national laws and regulations of the specific EU member state where the employment takes place.
- Country-Specific Addenda: For each EU country where we operate, we maintain country-specific addenda to this policy. These addenda outline any additional requirements, protections, or procedures mandated by national law that go beyond or differ from EU-wide standards.
- Language Requirements: In countries where local law requires that employment policies be provided in the local language, we will make available a properly translated version of this policy and its country-specific addendum.
- Notification of Applicable Laws: During the recruitment process, candidates will be informed of the specific national laws that apply to their potential employment, in addition to EU-wide regulations.
- Regular Updates: We commit to regularly reviewing and updating our country-specific addenda to reflect any changes in national employment laws.
- Precedence of National Law: Where national law provides greater protection or additional rights to employees beyond what is outlined in this general EU policy, the national law will take precedence.
- Specific Declarations: Where required by national law, we will make specific declarations regarding matters such as:

- Pay transparency and gender pay gap reporting
- Working time arrangements

- Collective bargaining agreements

- Data protection and privacy measures

- Whistleblower protection mechanisms

- Any quota systems for underrepresented groups in employment

- Access to Information: Employees and candidates can request information about the country-specific policies applicable to their employment or potential employment by contacting

Keller Executive Search and our clients may use artificial intelligence (AI) tools to assist in the recruitment and candidate evaluation process. These tools are used exclusively to support human decision-making by helping to review and assess candidate qualifications and materials. AI is never used to automatically reject, disqualify, or make final hiring decisions about candidates. All AI-assisted evaluations are reviewed by experienced recruitment professionals, and all hiring decisions are made by qualified human recruiters. Our use of AI is designed to enhance fairness, consistency, and efficiency while maintaining our commitment to equal employment opportunity and non-discrimination principles.

**Genetic Information **

In accordance with EU and national laws, both Keller Executive Search and our clients do not discriminate based on genetic information. We do not request or require genetic information from applicants or employees, except as permitted by law.

**Local Laws **

Both Keller Executive Search and our clients comply with all applicable local laws and ordinances regarding employment practices in the areas where we operate within the EU.

**Note:** This job posting may be for a position with Keller Executive Search or one of our clients. The specific employer will be identified during the application and interview process. Employment laws and requirements may vary depending on the employer and location within the EU.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
