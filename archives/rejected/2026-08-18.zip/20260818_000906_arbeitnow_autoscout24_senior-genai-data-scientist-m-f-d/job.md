# Senior GenAI Data Scientist (m/f/d)

Posted: 2026-08-17T20:56:01Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**A career driven by you.** Join AutoScout24 Group and experience life in the fast lane. We’re not just leading the market; we’re creating it. We’re constantly innovating, evolving, and transforming things for our customers. We’re driven, ambitious, and determined to do our best work together. For a career that doesn’t stand still, where you can put your ideas in the driving seat and change the way the world moves, join our international community.

As **Senior GenAI Data Scientist**, you’ll join our Data Science organisation and drive the development of next-generation AI solutions across the company. You will take ownership of building agentic GenAI systems, integrating knowledge into models, and setting up strong evaluation and monitoring frameworks that ensure we deliver reliable, scalable, and high-value AI products. This position is **permanent **and located in **Munich **(Germany) or **Toronto **(Canada).

**What you’ll do:**

- Design and build agentic GenAI systems using modern frameworks such as LangChain, AutoGen or Atomic Agents, taking the lead on translating product needs into scalable AI solutions and delivering production-ready implementations.

- Drive harness engineering practices across Data Science projects, creating agent-ready repositories, workflows, standards, and feedback loops that enable software engineering agents to generate, test, maintain, and review code reliably across AI, ML, and data products.

- Develop and maintain knowledge integration pipelines, including RAG architectures, custom model fine-tuning, vector search, and other grounding methods to ensure our AI systems have the right context for accurate, relevant outputs.

- Define evaluation strategies, build ground-truth datasets, and create automated test and monitoring setups to ensure stable long-term model performance and proactively detect issues such as drift or hallucination.

- Collaborate with engineering, data, and product teams to integrate AI components into platforms, workflows, and customer-facing products, designing clean APIs, robust pipelines, and scalable deployment patterns.

- Act as a hands-on expert for GenAI and agentic software engineering topics, mentoring peers, guiding solution architecture, and driving best practices in coding, testing, repository design, documentation, observability, and harness engineering across the team and beyond.

- Experiment with new tools, models, and architectures, identify high-impact AI opportunities, and build prototypes that can scale into production-ready solutions.

**What you’ll bring:**

- A degree in computer science, data science, engineering, or a related field.

- Experience designing maintainable, agent-ready engineering environments, including repository structures, coding standards, automated test suites, CI/CD workflows, documentation patterns, and feedback mechanisms that allow software engineering agents to safely generate, modify, review, and maintain code.

- Experience with knowledge graphs, graph-based retrieval, semantic modelling, or ontology-driven knowledge representation is a plus.

- Strong coding skills in Python and experience with robust software engineering practices.

- Practical experience with RAG pipelines, vector databases, embeddings, or fine-tuning workflows.

- Strong understanding of common challenges in AI development (ground-truth evaluation data, monitoring, integration complexity, model drift).

- Experience deploying AI systems in a cloud environment and working with modern ML stacks.

- Familiarity with MLOps, prompt engineering, or LLM-based application design.

- Ability to explain complex AI topics in clear and actionable language to technical and non-technical stakeholders.

- High motivation, ownership mentality, and a strong drive to build impactful AI products.

- Fluency in English; German is a plus.

**A culture of growth. **With over 50 nationalities represented, we’re proud to welcome people of all backgrounds to our growing community, and we’re always finding new ways to help people feel welcomed and included. Here, you’ll have the tools, training and support you need to work in a way that suits you, learn new skills and reach your potential.

**For a career where you can drive our business and shape your future, apply now.**

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
