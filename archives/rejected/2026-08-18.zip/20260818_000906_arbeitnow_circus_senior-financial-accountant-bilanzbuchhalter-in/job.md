# (Senior) Financial Accountant / Bilanzbuchhalter:in (f/m/d)

Posted: 2026-08-17T17:09:53Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**Our Mission**

At Circus (Xetra: CA1), headquartered in Munich, we are pioneering global developments in on-demand autonomous food production. Everything from creation to production and operation – enabled by seamlessly integrated cutting-edge robotics and transformative AI technology.

Our foundation rests in the extensive developments of groundbreaking robotics driven by artificial intelligence, previously the missing link in achieving true autonomous food automation. This is the moment for a new status quo: Just as autonomous driving will disrupt how we build cities, organize our days, and live our lives, so will we shift our whole reality around food.

Our Team is backing a paradigm shift in one of humanity's most important sectors with the sharpest minds in Robotics, AI, Engineering and Culinary, collaborating closely with industry-leading partners to revolutionize every aspect of the food service experience.

Join us as we forge ahead, crafting a future where the art of cooking and the science of technology converge to create a world that thinks differently about food than it has for thousands of years—a world where food means something new.

**About the Role**

We are looking for a motivated, professional Financial Accountant to become an integral member of our in-house Finance team. This is a key position responsible for managing core accounting functions and supporting major finance tasks liaising with external providers and our internal team.

This position is available both full-time and part-time.

**Your Daily Business**

- Independent management of financial accounting (general ledger, accounts receivable, accounts payable, fixed assets)
- Preparation of monthly, quarterly and annual financial statements in compliance with German GAAP (HGB)
- Active participation in year-end closing and audit processes
- Contribute to the group consolidation process and reporting
- Support in the optimization and automation of finance processes
- Close collaboration with internal departments and external partners

**Base Qualifications**

- Completed commercial training with further qualification as a "Bilanzbuchhalter/in (IHK)" (or currently in training), or equivalent qualification
- 1–3 years of relevant professional experience preferred
- Proficient user of DATEV
- SAP and/or MS Dynamics experience is also a plus
- Sound knowledge of HGB (German GAAP); IFRS knowledge is a strong plus
- Fluent in German and English, both written and spoken
- Independent, team-oriented, and hands-on working style
- Enthusiasm for driving change and shaping processes in a sustainable way

**Preferred Qualifications**

- SAP and/or MS Dynamics experience

**Our Offer**

- **Competitive Compensation:** Competitive compensation package with stock options for full-time employees.
- **Work-Life Balance:** Regular team events, hybrid work setup, 2 months/year remote work (Worcation), unlimited vacation days, and a corporate pension plan.
- **Personal Development:** Personal budget for training, in-house trainings, and growth opportunities in a fast-paced environment.
- **Mobility:** Monthly budget for mobility or other expenses, and a subsidized Dance Mobility Subscription for E-Bike/E-Moped.
- **Well-Being:** Discounted Urban Sports Club membership and Wellhub for a variety of well-being offerings.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
