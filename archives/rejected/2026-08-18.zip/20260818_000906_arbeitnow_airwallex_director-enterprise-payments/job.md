# Director, Enterprise, Payments

Posted: 2026-08-17T17:40:29Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

## **About Airwallex**

Airwallex is the only unified payments and financial platform for global businesses. Powered by our unique combination of proprietary infrastructure and software, we empower over 250,000 businesses worldwide – including Brex, Navan, Qantas, SHEIN and many more – with fully integrated solutions to manage everything from business accounts, payments, spend management and treasury, to embedded finance at a global scale.

Proudly founded in Melbourne, we have a team of over 2,300 of the brightest and most innovative people in tech across 27 offices around the globe. Valued at US$11 billion and backed by world-leading investors including T. Rowe Price, Visa, Mastercard, Robinhood Ventures, Sequoia, Salesforce Ventures, DST Global, and Lone Pine Capital, Airwallex is leading the charge in building the global payments and financial platform of the future. If you’re ready to do the most ambitious work of your career, join us.

## **Attributes We Value**

We hire successful builders with founder-like energy who want real impact, accelerated learning, and true ownership. You bring strong role-related expertise and sharp thinking, and you’re motivated by our mission and [operating principles](https://www.airwallex.com/us/operating-principles). You move fast with good judgment, dig deep with curiosity, and make decisions from first principles, balancing speed and rigor.

You're humble and collaborative; turn zero‑to‑one ideas into real products, and you “get stuff done” end-to-end. You use AI to work smarter and solve problems faster. Here, you’ll tackle complex, high‑visibility problems with exceptional teammates and grow your career as we build the future of global banking. If that sounds like you, let’s build what’s next.

**About the Team **

We are building a new Enterprise Payments team – a dedicated motion focused on winning and expanding large enterprise customers around Airwallex’s payment acceptance solutions.

This is a greenfield opportunity: you will be among the first Enterprise hires in the Enterprise team, helping define the sales playbook, shape GTM strategy, and close the deals that put Airwallex on the map in the enterprise payment acceptance category.

**What You’ll Do**

**New Business & Pipeline Generation**

-

Own end-to-end enterprise sales cycles from prospecting through to contract signature, with deal sizes typically $250K+ ARR

-

Build and manage a high-quality pipeline of enterprise prospects through outbound prospecting, partner referrals, field events, and industry networks

-

Conduct white space analysis and account planning to prioritise highest-potential opportunities within your territory

-

Run structured, consultative sales processes: discovery, value proposition design, stakeholder mapping, commercial negotiation, and close

**Customer & Stakeholder Engagement**

-

Engage and build trust with multiple senior stakeholders – CFO, CPO, Head of Finance, IT and Procurement – across complex buying committees

-

Deliver compelling executive-level presentations and business cases that connect Airwallex’s payment acceptance capabilities to specific customer outcomes

-

Represent Airwallex at industry events, conferences, and customer roundtables to build brand presence in the enterprise payment acceptance market

-

Partner with Solutions Engineering and Product to run proof-of-concepts and tailored demos that showcase platform value

**Cross-functional Collaboration**

-

Work closely with the Enterprise Payments product team to relay customer insights and influence roadmap priorities

-

Collaborate with Marketing on territory demand generation, ABM campaigns, and competitive positioning

-

Coordinate with Implementation post-close to ensure a seamless handover and strong early adoption

-

Maintain rigorous CRM hygiene – accurate pipeline data, forecasting, and activity logging in Salesforce

**Market & Competitive Intelligence**

-

Develop deep expertise in enterprise payment acceptance, card acquiring, payment service providers, payment orchestration, fraud prevention, and checkout optimisation to credibly position Airwallex against competition

-

Stay current on market trends, customer procurement patterns, and the competitive landscape to sharpen your sales approach

-

Contribute to the development of the Enterprise Payments GTM playbook — messaging, objection handling, competitive battlecards

**Who You Are**

We’re looking for people who meet the minimum requirements for this role. The preferred qualifications are great to have, but are not mandatory.

**Minimum Qualifications**

-

10+ years of total experience, including 3+ years in enterprise sales (hunting/new business) at a payments or fintech company.

-

Proven track record of consistently exceeding quota on complex enterprise deals ($250K+ ARR) with long sales cycles.

-

Demonstrated ability to manage full commercial cycles: prospecting, multi-stakeholder discovery, value selling, and negotiating legal/procurement terms.

-

Fluent in English and native-level proficiency in German.

-

Adaptable, results-driven mindset with a track record of thriving in high-growth, fast-paced environments.

-

English and German communication: Communicate with clarity and credibility in both English (fluent) and German (native).

**Preferred Qualifications**

-

Deep domain expertise in payment acceptance, card acquiring, PSPs, payment orchestration, or adjacent enterprise SaaS.

-

Foundational understanding of accounting and complex financial flows.

-

Strong executive-level presentation skills with experience multi-threading across CFOs, Heads of Product, and Procurement.

-

Proven ability to create structure and navigate ambiguous, early-stage enterprise sales environments.

## **Applicant Safety Policy: Fraud and Third-Party Recruiters**

*To protect you from recruitment scams, please be aware that Airwallex will not ask for bank details, sensitive ID numbers (i.e. passport), or any form of payment during the application or interview process. All official communication will come from an @*[*airwallex.com*](http://airwallex.com)* email address. Please apply only through *[*careers.airwallex.com*](http://careers.airwallex.com)* or our official LinkedIn page.*

*Airwallex does not accept unsolicited resumes from search firms/recruiters. Airwallex will not pay any fees to search firms/recruiters if a candidate is submitted by a search firm/recruiter unless an agreement has been entered into with respect to specific open position(s). Search firms/recruiters submitting resumes to Airwallex on an unsolicited basis shall be deemed to accept this condition, regardless of any other provision to the contrary.*

## **Equal opportunity**

Airwallex is proud to be an equal opportunity employer. We value diversity and anyone seeking employment at Airwallex is considered based on merit, qualifications, competence and talent. We don’t regard color, religion, race, national origin, sexual orientation, ancestry, citizenship, sex, marital or family status, disability, gender, or any other legally protected status when making our hiring decisions. If you have a disability or special need that requires accommodation, please let us know.

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
