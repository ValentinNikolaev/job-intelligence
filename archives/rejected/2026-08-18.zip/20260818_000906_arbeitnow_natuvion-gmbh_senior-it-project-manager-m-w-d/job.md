# Senior IT Project Manager (m/w/d)

Posted: 2026-08-17T20:30:19Z

## Rejection

- Category: tech_stack
- Reason: role does not mention Go/Golang or PHP

Du hast Erfahrung in der Steuerung komplexer IT‑ und Transformationsprojekte und möchtest Verantwortung übernehmen – fachlich, organisatorisch und gegenüber unseren Kunden?
Du arbeitest strukturiert, kommunikationsstark und fühlst dich sowohl in klassischen als auch agilen Projektumfeldern zu Hause? Dann passt diese Rolle perfekt zu dir.

#### **Was dich erwartet:**

Als **Senior IT Project Manager** übernimmst du die **End‑to‑End‑Verantwortung** für anspruchsvolle IT‑ und SAP‑nahe Projekte. Du steuerst Projekte entlang von Zeit, Budget, Qualität und Profitabilität, bist zentrale Ansprechperson für Kunden und Stakeholder und bringst Projektmanagement‑Standards aktiv weiter nach vorne.
Dich erwartet ein Umfeld mit Gestaltungsfreiraum, klarer Verantwortung und kurzen Entscheidungswegen.

#### **Deine Aufgaben:**

-

Planung, Steuerung und Umsetzung komplexer IT‑Projekte (klassisch & agil)

-

Aktives Stakeholder‑Management inkl. Kommunikation, Eskalationen und Konfliktlösung

-

Sicherstellung von Budget, Forecast und Projektprofitabilität

-

Identifikation, Bewertung und Steuerung von Risiken und Änderungen

-

Sicherstellung von Projekt‑ und Qualitätsstandards sowie technischer Dokumentation

-

Vorbereitung und Moderation von Meetings, Workshops und Management‑Präsentationen

-

Enge Zusammenarbeit mit Kunden, internen Teams und Consultants

#### **Dein Profil:**

-

Mehrjährige Erfahrung im Management komplexer IT‑ bzw. Transformationsprojekte (klassisch & agil)

-

Sicherer Umgang mit gängigen Projektmanagement‑Tools wie MS365, Jira, Confluence sowie idealerweise SAP‑nahen PM‑Frameworks (z. B. SAP Activate, Signavio)

-

Erfahrung in Budget‑, Ressourcen‑ und Forecast‑Steuerung sowie Verantwortung für Projektprofitabilität

-

Gutes technisches Verständnis für IT‑ und SAP‑Landschaften sowie Schnittstellen, Architekturen und Migrationsszenarien

-

Strukturierte, eigenverantwortliche und qualitätsbewusste Arbeitsweise – auch in anspruchsvollen Projektsituationen

-

Ausgeprägte Kommunikations‑ und Präsentationsstärke im Umgang mit Kunden, Stakeholdern und internen Teams

-

Sehr gute Deutsch‑ und Englischkenntnisse

**Falls du denkst, dass du nicht alle Anforderungen erfüllst: Bei uns sind deiner Entwicklung „keine Grenzen gesetzt“! Geh mit uns gemeinsam deinen Weg – Wir unterstützen dich dabei! Zeige uns einfach, wer du bist.**

#### **Was dich bei uns erwartet:**

Ein Umfeld, das jederzeit offen für Veränderungen und Optimierungen ist. Ein „das war schon immer so“ gibt es bei uns nicht. Du hast die Chance, dein Wissen einzubringen, Prozesse zu gestalten, vorhandene Themen zu standardisieren oder Abläufe zu optimieren. Sei Impulsgeber und bringe uns mit deiner Expertise noch weiter nach vorne!

#### Wir schaffen Rahmenbedingungen, in denen du dich wohlfühlst:

-

Home-Office Verträge & absolute Flexibilität durch freie Gestaltung der Arbeitszeit

-

Unbefristete Festanstellung und 30 Tage Urlaub

-

FlexWork: Bis zu 3 Monate pro Jahr remote aus dem europäischen Ausland arbeiten

-

Monatliches Budget für individuell wählbare Benefits aus über 50 möglichen Angeboten über emplu, verschiedene Angebote über Corporate Benefits, sowie Fahrrad- und Autoleasing per Gehaltsumwandlung

-

Mental Health Benefit 'Nilo' – 12 kostenlose Sessions mit Psycholog:innen jährlich sowie Zugang zu Meditationen und Kursen

-

Wir unterstützen dich gezielt bei deiner fachlichen und persönlichen Entwicklung bei Natuvion

-

Mentorenprogramm für eine strukturierte und persönliche Einarbeitung

-

**Werde Teil des #teamgreen - **Bei Natuvion arbeitest du an innovativen Projekten als Teil eines Teams, das füreinander einsteht. Wir setzen auf Zusammenarbeit, Offenheit und Vertrauen

-

Modernes Equipment und zentrale Büros in Walldorf, Berlin, München und Leipzig

-

Uns ist deine langfristige Perspektive wichtig, deshalb bezuschussen wir deine betriebliche Altersvorsorge sowie vermögenswirksame Leistungen

**Join #teamgreen **- Natuvion ist ein digitales Umzugsunternehmen.

Unser Team bewegt keine Tische, Aktenschränke oder Stühle. Natuvion transportiert geschäftskritische Daten und Prozesse von einer Technologieplattform auf eine andere. Typische Natuvion „Umzugsdienstleistungen“ umfassen Datenmigration, Datentransformation, Datenintegration, Datenschutz, Datensicherheit und Datenqualität.

Unsere >400 BeraterInnen und EntwicklerInnen in Deutschland, Österreich, Slowakei, USA und Australien verfügen über weitreichendes Knowhow bei (SAP®-)Projekten und ein profundes Prozessverständnis über Branchengrenzen hinweg. Mit viel Erfahrung, Engagement und Einsatz begleiten sie unsere Kunden mit Beratung, Dienstleistung und eigener Softwaretechnologie. So ermöglichen wir Unternehmen, ihre Daten und Prozesse immer auf den modernsten und innovativsten Plattformen zu nutzen.

Du bist interessiert? Wir freuen uns auf deine Bewerbung und darauf, dich kennenzulernen!

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
