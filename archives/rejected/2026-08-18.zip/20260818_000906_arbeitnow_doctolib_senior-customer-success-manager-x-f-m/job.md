# Senior Customer Success Manager (x/f/m)

Posted: 2026-08-17T20:55:15Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

### **Werde Teil unserer Mission, werde Teil von Doctolib!**

Gemeinsam mit uns gestaltest Du die Zukunft der Gesundheitsversorgung – digital, zugänglich und besser für alle. Als Senior Customer Success Manager (m/w/d) bist Du fachliche Expertin oder Experte in Deinem Team und trägst mit Deinem Wissen maßgeblich zum Erfolg Deines Kundenportfolios bei. Du entwickelst überzeugende Geschäftsargumente, unterstützt Dein Team in anspruchsvollen Situationen und optimierst kontinuierlich Prozesse und Methoden – für noch bessere Ergebnisse und zufriedenere Kunden.

Mit Deinem Engagement hilfst Du dabei, Gesundheitsfachkräften den Arbeitsalltag zu erleichtern – damit sie mehr Zeit für das haben, was wirklich zählt: die bestmögliche Versorgung ihrer Patientinnen und Patienten.

##

## **Deine Aufgaben**:

- **Du verantwortest Umsatzthemen und entwickelst überzeugende Geschäftsargumente**: Du führst Vertragserweiterungen durch, erarbeitest den Kundennutzen und unterstützt bei der kaufmännischen Umsetzung

- **Du erkennst Wachstumschancen und setzt sie um:** Du identifizierst Möglichkeiten für Vertragserweiterungen, Verlängerungen und Kundenrückgewinnung und verantwortest diese wichtigen Kundenkontaktpunkte in enger Abstimmung mit Deinem Team

- **Du gibst Kundenfeedback strukturiert weiter:** Du leitest wichtige Rückmeldungen und systemische Themen an die relevanten internen Bereiche weiter und trägst so zur kontinuierlichen Verbesserung der Kundenerlebnisse bei

- **Du entwickelst Arbeitsweisen und Prozesse weiter**: Du identifizierst Verbesserungspotenziale, setzt diese um und steigerst so die Wirksamkeit und Skalierbarkeit der Kundenbetreuung

- **Du arbeitest bereichsübergreifend an Lösungen**: Du arbeitest mit relevanten Ansprechpersonen zusammen, um wiederkehrende Themen zu lösen und die gesamte Kundenbetreuung kontinuierlich zu verbessern

###

## **Dein Profil**

Vorab der kurze Hinweis: Falls Du dem unten beschriebenen Profil nicht exakt entsprichst, aber trotzdem der Meinung bist, dass die Stellenausschreibung zu Deinen Fähigkeiten passt: Bewirb Dich gerne trotzdem!

### **Um Teil unseres Teams zu werden, bringst Du folgendes mit:**

- **2-4 Jahre Erfahrung** im Customer Success, Account Management oder einer vergleichbaren kundenorientierten Rolle – idealerweise im B2B SaaS-Umfeld

- **Portfoliomanagement-Skills:** Du behältst auch bei vielen Kunden den Überblick, priorisierst intelligent und arbeitest datengetrieben

- **Beziehungsstärke:** Du baust echte Partnerschaften auf, nicht nur Geschäftsbeziehungen – authentisch, empathisch und auf Augenhöhe

- **Kommerzielle Denkweise:** Du verstehst Business-Logiken, erkennst Verkaufschancen und trägst gerne Umsatzverantwortung

- **Hands-on-Mentalität:** Du packst an, koordinierst eigenständig und bringst Dinge zum Abschluss – kein "das ist nicht mein Job"

- **Kommunikation:** Sehr gutes Deutsch (mind. C1) und gutes Englisch (mind. B2)

### **Besonders interessant sind für uns außerdem**

- **Healthcare-Erfahrung:** Kenntnisse im Gesundheitswesen, idealerweise aus dem Praxis- oder Klinikumfeld

- **Technisches Verständnis:** Affinität für Software-Produkte und die Fähigkeit, auch komplexere Features verständlich zu erklären

- **Datenaffinität:** Du arbeitest gerne mit CRM-Systemen (z.B. Salesforce), Dashboards und nutzt Daten zur Entscheidungsfindung

## **Was wir dir bieten**

- Ein von Doctolib gesponsertes Deutschlandticket, wenn Du aus dem Büro oder im Hybridmodus arbeitest

- 28 Urlaubstage + 1 Tag zusätzlich für jedes volle Beschäftigungs-Kalenderjahr (max. 30 Tage)

- Die Möglichkeit, 10 Tag eim Jahr im Ausland zu arbeiten

- Eine betriebliche Krankenversicherung mit tollen Zusatzleistungen

- Eine betriebliche Altersvorsorge (bAV) mit einem Arbeitgeberzuschuss von 40 % (15 % während der Probezeit)

- Das Doctolib Parent Care Programm, das extra Elternzeit (1 Monat) u.v.m. enthält

- Kostenlose Mental Health- und Coaching-Sessions über einen externen Partner

- Zusätzlich zu gesunden Snacks und einem regelmäßigen Frühstücksbuffet, bieten wir Essensgutscheine

- Ein gefördertes Sportangebot mit unserem Partner Urban Sports Club

- Für pflegende Betreuungspersonen und Beschäftigte mit Behinderungen gibt es ein Angebot, das flexiblere Arbeitszeiten, zusätzliche Freistellung aus medizinischen Gründen und psychologische Unterstützung beinhaltet

- Teilnahme an Doctolibs langfristigem Mitarbeiterbeteiligungsprogramm DoctoGrowth

## **Der Interview-Prozess**

- Erstes Vorstellungsgespräch mit Talent

- Interview mit der Hiring Managerin inkl. Case Study

- Finaler Call mit Stefanie Möllenhoff- Head Of

- Mindestens eine Referenzprüfung

## **Job Details**

- Festanstellung

- Vollzeit

- Arbeitsort: Berlin

- Startdatum ab sofort

Wir verfolgen die Vision, die Gesundheit aller zu verbessern. Dies spiegelt sich auch im Recruiting wider. Wir evaluieren Bewerbungen ausschließlich auf der Grundlage von Qualifikation und Motivation. Diskriminierung wird bei uns nicht toleriert.

Je diverser unser Team und die Ideen sind, desto mehr wird unser Produkt die Gesundheit unserer Nutzer:innen verbessern können. Deshalb laden wir dich ein, dich bei uns zu bewerben, unabhängig von Geschlecht, Religion, Alter, sexueller Orientierung, ethnischer Herkunft oder Behinderung.
Um Chancengleichheit zu gewährleisten, kannst Du in deiner Bewerbung auf Angaben wie Fotos, Alter, etc. verzichten. Lass uns bitte wissen, welche Vorkehrungen wir treffen können, um Dich bestmöglich zu unterstützen. Wir freuen uns, mit Dir das Gesundheitswesen zu digitalisieren!

Alle bereitgestellten Informationen werden von Doctolib für das Bewerbungsmanagement verarbeitet. Für Details zur Datenverarbeitung klicke bitte [hier](https://doctolib.legal/B2C-Privacy-Policy-Career-DE). Bei Fragen oder wenn Du Deine Rechte wahrnehmen möchtest, wende Dich bitte an hr.dataprivacy(at)doctolib.com.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
