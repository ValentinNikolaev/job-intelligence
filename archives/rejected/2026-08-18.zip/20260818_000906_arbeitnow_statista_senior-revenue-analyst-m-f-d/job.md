# (Senior) Revenue Analyst (m/f/d)

Posted: 2026-08-17T17:40:19Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

At **Statista**, we’re all about facts and data, for we are the world's leading business data platform. By providing reliable and easy-to-use data as well as various data analytics products and services, we empower people worldwide to make fact-based decisions.

Founded in Hamburg in 2007, we have quickly grown into a global company with offices in major cities such as London, New York, Berlin and Tokyo. And we still have a lot of plans. Our constant growth does not only prove our success, but also keeps creating new development and career opportunities for our employees.

We value and celebrate our diverse culture. You are welcome here for who you are, no matter where you come from, what you look like, or whether you prefer bar graphs to pie charts. Your story matters – keep writing it as part of our team.

Are you ready to join us?

**Your role**

-

Own and manage top-line revenue planning in close collaboration with Controlling, including annual budgeting, quarterly forecasts (RFC), and global revenue targets

-

Translate revenue plans into concrete sales targets and ensure alignment across regions and stakeholders

-

Prepare and consolidate monthly performance analyses, providing clear insights and recommendations for senior leadership (CLT)

-

Create high-quality presentations and decision materials for C-level stakeholders, including performance updates and business reviews

-

Support the preparation and coordination of global Quarterly Business Reviews (QBRs) in collaboration with Sales leadership

-

Monitor revenue performance, identify deviations from plan, and proactively highlight risks and opportunities

-

Collaborate closely with Sales, Revenue Operations, Finance, and other stakeholders to ensure consistency of planning and reporting

-

Support and further develop forecasting logic, planning assumptions, and financial models

-

Contribute to improving data quality and reporting structures in collaboration with Data and BI teams

-

Calculate and validate bonus payouts based on target achievement for Sales, ensuring accuracy, transparency, and alignment with incentive schemes

**Your profile**

-

University degree in Business Administration, Economics, Finance, or a comparable field

-

Several years of experience in controlling, revenue analytics, or a similar role

-

Strong understanding of budgeting, forecasting, and financial planning processes

-

Excellent analytical skills with the ability to translate numbers into clear business insights

-

Advanced Excel and strong PowerPoint skills, with the ability to create structured and compelling management presentations

-

Basic SQL or data modelling skills are a plus

-

Strong communication and stakeholder management skills, especially when working with senior leadership

-

Structured, detail-oriented, and reliable working style with a strong sense of ownership

**What we offer**

In addition to our great team, culture, and our shared goal of empowering people with data, there are many other things that make Statista a great place to work! Join us and benefit from:

-

Work from abroad up to 30 calendar days a year

-

Hybrid work and flex-time

-

International team and social events

-

Subsidized urban mobility and access to fitness and wellness options

-

Free access to Langdock and all its amazing functionalities

-

Career & training opportunities

-

Attractive locations and modern offices

-

Mental health support with OpenUp

*Some of the benefits listed here apply only to the German entity and to Junior-level roles or above.*

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
