# Director Accounting Operations (m/f/d)

Posted: 2026-08-17T20:56:01Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**A career driven by you.**
Join **AutoScout24 Group** and experience life in the fast lane. We’re not just leading the market; we’re creating it. We’re constantly innovating, evolving, and transforming things for our customers. We’re driven, ambitious, and determined to do our best work together. For a career that doesn’t stand still, where you can put your ideas in the driving seat and change the way the world moves, join our international community.

#### **Why this role is unique**

- High-impact leadership role with **direct visibility to senior management**

- Opportunity to shape a scalable accounting organization in a complex multi-entity environment

- Key role in **finance transformation and exit readiness**

- Ownership of end-to-end accounting operations across all German entities

- Leadership and development responsibility for a **team of ~20 FTE**

#### **What you’ll do**

- **Lead Accounting Operations** across all German entities (Accounts Payable, Accounts Receivable, General Ledger)

- Ensure accurate, timely, and **compliant financial statements** (HGB / IFRS)

- Drive process standardization, efficiency, and scalability

- Act as senior interface to Group Accounting, Group Reporting, and auditors

- Manage and **develop the accounting organization** and team

#### **What you’ll bring**

- Proven experience in **accounting leadership** in complex, multi-entity environments

- Deep knowledge of financial accounting standards (HGB / IFRS)

- Track record of building or **transforming accounting** organizations

- **Strong leadership** and stakeholder management skills

- Fluent in **German and English**

**A culture of growth**

With over 50 nationalities represented, we’re proud to welcome people of all backgrounds to our growing community, and we’re always finding new ways to help people feel welcomed and included. Here, you’ll have the tools, training and support you need to work in a way that suits you, learn new skills and reach your potential.

**Ready to drive change in Finance?** Apply now and put your ideas in the driving seat at **AutoScout24 Group**.

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
