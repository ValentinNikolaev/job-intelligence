# AI Founding Engineer: RF Machine Learning (SIGINT) (f/m/d)

Posted: 2026-08-23T22:00:27Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Modern conflict runs on the electromagnetic spectrum. Every drone, every radio, every radar leaves a trace in it. Datacept builds cognitive electronic warfare systems that listen to that spectrum, understand what is in it, and act on it.

At the centre of this sits one capability: models that learn directly from raw I/Q data. Not from decoded protocols, not from hand-built feature extractors, but from the signal as it arrives at the antenna. This is how we handle emitters no system has seen before, in environments where new frequencies, new protocols, and new platforms appear faster than any rulebook can follow.

We are looking for engineers who have this capability.

## Tasks

**Your role**

You are the founding engineer for RF machine learning at Datacept. You take responsibility for the cognitive core of our systems. The layer that turns received I/Q data into detection, classification, and understanding of emitters for SIGINT and COMINT missions.

We build the foundation model in a space where no foundation models exist. The domain of RF machine learning is just in its starting phase. Methods that work in audio and computer vision like self-supervised pretraining, learned representations, large pretrained backbones carry over to RF only if you understand why they work.

Second, the models have to run in the field. Our systems are deployed at ports, stadiums, critical infrastructure, and military sites, on hardware with real limits on compute and power.

Our cloud platform enables scalable processing of the largest RF datasets, here we can deploy the full power of the foundation model. We maintain one of the largest RF datasets in the world which is constantly growing.

Besides being the integral part of the engineering team you will directly work with the founders. You set the direction for RFML at Datacept, you make the architectural decisions, and as we grow you build the team around you.

**What you will do**

- Design and train models that learn from raw I/Q recordings: detection, classification, and more

- Research and implement ML methods from other domains to improve our data pipelines

- Define how we evaluate: test sets, metrics, and scenarios that reflect real conditions such as domain shift between sensors, sites, and interference environments

- Make models fit the hardware: Besides the foundation model we need expert models that are also compact and deployable on edge

- Continuous testing of all pipelines in real world conditions provides continuous feedback

- Integrate new data sources into our data platform

**How we work**

- Fast learners over specific backgrounds. We care more about how quickly you pick up new skills than where you have worked before – the spectrum changes faster than any CV

- Intellectual honesty. The right answer matters more than being right. You challenge assumptions, test ideas against real recordings, and pivot when the data says so

- Adaptability. We are organised, but things change quickly – a new idea, a customer trial, a funding deadline. You find a way to make it work and balance short-term deliverables with the long-term architecture

- Ownership of outcomes. You optimise your own time, focus on what matters to deliver quickly, and cut out inefficiencies. Nobody manages your calendar for you

- Not building in a vacuum. You stay connected to hardware, to the founders, and to the customers at the sites we protect, so that all the pieces fit together in the field

## Requirements

**Skills**

- You have built and shipped ML systems that people depend on, preferably on signal-like data: audio, time series, sensor streams, images, video or ideally RF

- You understand self-supervised learning well enough to explain why a given method works, and you can move ML ideas between domains with intent

- You have strong mathematical fundamentals and are comfortable when the problem first has to be formulated before it can be solved

- You go from idea to prototype to deployed model on your own, and you ask for help when it speeds things up rather than when you are stuck

- You work well with few fixed structures and changing priorities

- You are prepared for the intensity of a founding role: long and unconventional working hours, field trials, deployments

- You want to contribute to Europe's technological sovereignty in a domain where it is currently lacking

**Helpful, not required**

- Prior work in RF or signal-centric ML: spectrum sensing, modulation recognition, SIGINT, EW. We are just as interested in people from adjacent domains who have shown they can reason about hard problems and are eager to learn

- Projects that you build yourself (in the software/hardware) space. We want people that can create things and not just implement a set of requirements.

- Signal processing basics: sampling, spectral analysis, I/Q representation

- SDR, communications engineering, or embedded background

- Publications, open-source work, or architectures that made it into production

## Benefits

- Possibility to contribute to strengthening Europe's sovereignty

- Virtual shares (VSOP) as part of the founding engineer package

- A development and compensation roadmap that we define together and that grows with the company

- Remote work with full mobile equipment, plus a workplace at both of our locations: Hamburg HafenCity (HQ) and Horneburg (R&D)

- Insights & Access to real RF data, real hardware, and real deployments

**Hiring process**

- Intro call (15 min, remote) – who you are, why Datacept

- Technical interview (45–60 min, remote) – we start with a technical challenge right away

- Final call, in person in Hamburg with all three founders

- Reference check and offer within 48 hours

**About Datacept**

Datacept GmbH, founded in Hamburg in 2025, builds cognitive electronic warfare systems for spectrum awareness, counter-drone defence, and the protection of critical infrastructure. Our platform unifies passive wideband sensing, AI-driven signal analysis, and the RF data infrastructure that ties them together.

We have raised pre-seed capital and are backed by German federal funding. We work with critical infrastructure operators, defence agencies, and NATO partners to give Europe the intelligence we need in the electromagnetic spectrum.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
