# Onboarding Manager (m/w/d) – du machst Partner erfolgreich

Posted: 2026-08-24T04:00:46Z

## Rejection

- Category: tech_stack
- Reason: role does not mention Go/Golang or PHP

**Über TREELAX Partner**

TREELAX Partner ist die führende Branchensoftware für Baumpflegebetriebe in Deutschland. Ein komplettes ERP, das den ganzen Betrieb abbildet. Wir heißen nicht zufällig **Partner**. Wir verstehen uns als Digitalisierungspartner unserer Betriebe, betreuen sie intensiv und kennen jeden einzelnen. Wir arbeiten deutschlandweit aus dem Homeoffice, und KI steckt in allem, was wir tun.

**Genervt von der üblichen Servicekultur in Deutschland? Willst du zeigen, wie guter Service wirklich geht, und die Extra-Meile gehen?**

Unsere Partner sind Baumpflegebetriebe, die oft mit Zettel, Excel und Bauchgefühl arbeiten. Für viele ist unsere Software der erste echte Schritt in die digitale Welt. Manche sind schon bei der ersten Videokonferenz unsicher. Genau diese Menschen holst du ab, führst sie und machst sie erfolgreich.

Und zwar nicht nur in den ersten Wochen. Du bleibst dauerhaft ihr fester Ansprechpartner. Du betreust vor allem kleine und mittlere Betriebe, langfristig bis zu 100 Partner, und sorgst dafür, dass sie sich jederzeit gut aufgehoben fühlen.

## Was du machst

- Du nimmst neue Partnerbetriebe an die Hand. Du richtest ihr System ein, schulst sie und begleitest sie, remote per Video, bis der Umstieg leicht von der Hand geht.

- Du bleibst dauerhaft ihr Ansprechpartner. Du beantwortest Fragen geduldig und verständlich und machst aus „kompliziert“ ein „ach, so einfach“.

- **Du begleitest Veränderung.** Du bringst Menschen dazu, alte Gewohnheiten loszulassen. Du gehst mit unterschiedlichen Betriebskulturen um und nimmst Widerstände gegen Neues ernst, statt sie zu übergehen.

- **Du bist Erfolgsmanager und Lotse.** Das beste System nützt nichts, wenn es niemand nutzt. Du sorgst dafür, dass deine Partner es wirklich einsetzen und dadurch erfolgreicher werden.

- Läuft ein Partner richtig gut, erkennst du, wo noch mehr für ihn möglich ist, etwa eine professionelle Website oder Online-Marketing. Du sprichst es an, immer vom echten Mehrwert her und ohne Verkaufsdruck.

**Wir richten uns nach dem Partner, nicht umgekehrt.** Das heißt auch: flexible Arbeitszeiten. Manche Baumpfleger haben erst morgens vor der Baustelle oder abends danach Zeit. Wenn du bereit bist, dich darauf einzustellen, machst du genau den Unterschied, den unsere Partner bei uns lieben.

## Was du verdienst

- **60.000 € Fixgehalt.**

- **Erfolgsbonus** für Partner, die durch dich erfolgreich starten und aktiv bleiben.

- **Upsell-Provision**, wenn ein Partner durch dich mehr Wert zieht.

- **Zielgehalt rund 70.000 €.** Deutschlandweit aus dem Homeoffice.

## Was du mitbringst

- **Echten Servicegedanken.** Guter Service ist für dich Anspruch, nicht lästige Pflicht. Du gehst gern die Extra-Meile.

- Echtes Interesse an Menschen und einen guten Draht zu Praktikern. Du sprichst die Sprache von Machern.

- **Fingerspitzengefühl für Veränderung.** Du spürst, wann jemand skeptisch ist, und holst ihn ab, statt ihn zu überfahren.

- Geduld und Köpfchen. Du erklärst Kompliziertes einfach und denkst dich mit Freude in ein breites System hinein, bis du es wirklich verstehst.

- Verlässlichkeit. Worauf du dich einlässt, ziehst du sauber durch.

- Eine eigenständige, strukturierte Arbeitsweise, zeitliche Flexibilität und sehr gutes Deutsch.

*Du musst nicht aus der grünen Branche kommen. Aber du willst sie kennenlernen. Baumpflege hat eine eigene Sprache und eine überraschend tolle Gemeinschaft. Wir bieten dir sogar einen Praxistag bei einem unserer Partner vor Ort, damit du weißt, wovon du sprichst. Vorerfahrung ist kein Muss. Entscheidend ist die Bereitschaft, dich auf Neues einzulassen, genau wie unsere Partner sich auf die Software einlassen müssen.*

## Wann wir NICHT zusammenpassen

Sei ehrlich zu dir. Wir passen nicht zusammen, wenn du …

- … guten Service als lästige Pflicht statt als Anspruch siehst.

- … nur Systeme einrichten willst, aber keine Lust hast, Menschen zu führen und mitzunehmen.

- … bei Widerstand oder Skepsis schnell die Geduld verlierst.

- … eine starre 9-bis-17-Uhr-Routine brauchst und dich nicht mal auf einen frühen oder späten Termin einlässt.

- … nicht bereit bist, dich in eine fremde Branche mit eigener Sprache einzuarbeiten.

## Wie wir arbeiten

- **Deutschlandweit aus dem Homeoffice.** Wir messen dich an Ergebnissen, nicht an Stunden. Konkret heißt das: erfolgreich gestartete Partner, ein hoher Nutzungsgrad der Software, zufriedene Betriebe und sinnvolle Upsells.

- **KI nimmt dir Routine ab**, damit du Zeit für Menschen hast.

- **Wir kennen jeden Partner persönlich.**

- **Kein Mikromanagement.** Klare Ziele, dein Weg.

## Leitmesse in Augsburg

Einmal im Jahr trifft sich die ganze Branche auf der Leitmesse in Augsburg (Ende April). Dort sind wir mit großem Stand am Start, und wir wollen jeden im Team dabei haben. Reisebereitschaft dorthin setzen wir voraus. Dieses Jahr waren wir am Start. Bist du beim nächsten Mal dabei?

[▶ Unser Aftermovie aus Augsburg](https://www.youtube.com/watch?v=IkhDcmRfWvE)

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
