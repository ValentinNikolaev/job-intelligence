# Werkstudent*in News (m/w/d)

Posted: 2026-08-23T23:09:48Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**Stellendetails**

Für unseren Standort Mainz suchen wir zum nächstmöglichen Zeitpunkt für bis zu 20 Wochenstunden und zunächst befristet eine*n Werkstudent*in News (m/w/d).

**Deine Aufgaben**

- Du erstellst, aktualisierst und visualisierst Web-Inhalte
- Du kümmerst dich um die Aufbereitung von Web-Inhalten auf Social Media Plattformen
- Du schneidest Videos, verfasst redaktionelle Texte und bist Teil des Community Managements
- Du betreibst gewissenhafte Faktenrecherche

**Dein Profil**

- Du hast großes Interesse an politischen und gesellschaftlichen Themen
- Du zeichnest dich durch präzises und selbstständiges Arbeiten aus
- Du überzeugst durch deine breite Allgemeinbildung und deine schnelle Auffassungsgabe
- Du arbeitest auch unter Zeitdruck konzentriert und fokussiert
- Du hast Lust auf flexible Arbeitszeiten
- Du hast gute Computerkenntnisse und bist sehr versiert im Umgang mit den gängigen MS Office-Programmen
- Du verfügst über sehr gute Deutsch- und gute Englischkenntnisse in Wort und Schrift

**Unser Angebot an dich**

Bei uns erwartet dich ein abwechslungsreiches Aufgabengebiet mit Gestaltungsspielraum für eigenverantwortliches Handeln. Zusammen mit dem motivierten und engagierten Team arbeitest du an spannenden Aufgaben und abwechslungsreichen Themen. Unsere Kultur ist geprägt von einem offenen Austausch, einem entspannten, aber professionellen Miteinander und flachen Hierarchien. Hier erwartet dich ein attraktiver und moderner, ergonomischer Arbeitsplatz sowie eine grüne Büroumgebung. Damit du Studium-, Arbeits- und Privatleben bestmöglich kombinieren kannst, besteht nach Absprache mit deiner Führungskraft die Möglichkeit zur flexiblen Arbeitszeitgestaltung und Mobile Office. Neben Flexibilität, netten Kolleg*innen und einladenden Büros kannst du dich außerdem auf regelmäßige Firmenevents und vieles mehr freuen.

**Kontakt**

Da sich unser Content an eine vielseitige Gesellschaft richtet, möchten wir auch in unseren Teams die gesellschaftliche Vielfalt repräsentieren. Auch, wenn du unserem Anforderungsprofil nicht zu 100% entsprichst, freuen wir uns darauf, dich durch deinen **Lebenslauf, Zeugnisse und ein Motivationsschreiben** kennenzulernen. Wir freuen uns außerdem, wenn du uns neben deiner Gehaltsvorstellung auch dein frühestmögliches Eintrittsdatum verrätst.

Deine Ansprechpersonen:
Georg & Ruben (Fachabteilung) **
**Nina (Recruiting)

**Wir freuen uns auf dich!**

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
