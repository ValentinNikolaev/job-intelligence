# (Senior) Pre-Sales Consultant (d/f/m)

Posted: 2026-08-23T23:24:13Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**Gestalte die Zukunft von Live-Entertainment-Tech**

Willkommen bei vivenu – dem globalen Vorreiter für Event-Ticketing-Technologie und einem der weltweit schnellst wachsenden Tech-Unternehmen im Live-Entertainment. Wir revolutionieren Ticketing für internationale Größen wie die Grammys, die Golden Globes, die Stanford University und den Hockenheimring – und machen aus einer einfachen Ticketing-Transaktion einen echten strategischen Wettbewerbsvorteil. Mit über 65 Millionen US-Dollar an Finanzierung im Rücken ermöglicht unsere Plattform Veranstaltern, ihre Markenpräsenz selbst zu steuern, tiefgreifende Datenanalysen zu nutzen und Ticketing nahtlos in ihre digitale Infrastruktur zu integrieren.

Mit sechs Standorten weltweit bieten wir eine intuitive, individuell anpassbare Lösung und branchenführenden Support, der selbst die komplexesten Herausforderungen im Ticketing vereinfacht. So helfen wir Veranstaltern, außergewöhnliche Erlebnisse zu schaffen und nachhaltiges Wachstum zu erzielen.

Werde Teil unserer Mission – und gestalte die Zukunft von Live-Entertainment mit.

**Als (Senior) Pre-Sales Consultant (d/f/m) am Standort Düsseldorf wirst du...**

-

das strategische und konzeptionelle Rückgrat unseres Sales-Prozesses bilden und unsere Strategic Account Executives bei hochkarätigen Enterprise-Deals unterstützen

-

das End-to-End-Management, die inhaltliche Ausarbeitung und cross-funktionale Koordination von komplexen RFPs, RFIs und öffentlichen Ausschreibungen übernehmen

-

überzeugende Business Cases und Value-Architekturen entwickeln, die unseren potenziellen Kunden zeigen, wie sie mit vivenu ihren Umsatz maximieren können

-

das PMO für neu gewonnene Enterprise-Kunden steuern und einen reibungslosen Übergang vom Sales in die Implementierung (Professional Services) sicherstellen

-

konzeptionelle Kunden-Workshops und Discovery-Sessions vorbereiten und gemeinsam mit den Account Executives durchführen

-

branchenspezifische Anforderungen analysieren und passgenaue Lösungsangebote aus unserer Plattform ableiten

-

als zentrale Schnittstelle zwischen Legal, Tech, Product und Leadership agieren, um Deadlines einzuhalten und höchste Qualität in unseren Angeboten zu garantieren

-

interne Sales-Enablement-Strukturen aufbauen, indem du wiederverwendbare Assets, ROI-Rechner und Best-Practice-Antworten für zukünftige Pitches erstellst

**Wir suchen Kandidat*innen, die...**

-

ein Studium (Bachelor/Master) idealerweise in BWL, Wirtschaftsinformatik, Management oder einem vergleichbaren Bereich erfolgreich abgeschlossen haben

-

3 bis 5 Jahre Berufserfahrung im Pre-Sales, in der IT-Beratung, im Sales Support oder im IT-Projektmanagement/PMO mitbringen

-

ein starkes Verständnis für B2B-Software (SaaS), digitale Transformationsprozesse und Enterprise-IT-Architekturen besitzen

-

über herausragende Deutsch- und Englischkenntnisse (B2B-Verhandlungsniveau) verfügen

-

sich durch eine extrem strukturierte, detailgenaue Arbeitsweise auszeichnen und gleichzeitig konzeptionell und lösungsorientiert denken

-

idealerweise bereits nachweisbare Erfolge im Management komplexer RFP-/Bid-Prozesse (öffentliche Ausschreibungen oder Enterprise-Kunden) vorweisen können

-

im Idealfall Branchenkenntnisse im Bereich Kultur, Performing Arts, Venues oder Ticketing mitbringen (kein Muss, aber ein großes Plus)

**Warum bei vivenu einsteigen?**

**Live-Entertainment-Technologie**

Spiele eine entscheidende Rolle für globale Marken und gestalte das Fan-Erlebnis neu – von Festivals bis hin zu großen Sport Events. Bei uns bist du Teil des Business of Fun – angetrieben von modernster Technologie, die besondere Momente für Millionen greifbar macht.

**Nachhaltiges Wachstum**

Wir wachsen nachhaltig auf einer profitablen, von Investoren unterstützten Basis mit echtem Product-Market-Fit. Das bedeutet kontinuierliche Investitionen in unsere Mitarbeitenden, unsere Produkte und unsere langfristige Vision.

**Top-Tier Team**

Arbeite mit über 160 engagierten Profis zusammen – darunter Führungskräfte von Google, Slack und Salesforce. Gemeinsam gestalten wir die Zukunft der Live-Entertainment-Technologie – Entscheidung für Entscheidung.

**Globale DNA**

Wir sind ein vielfältiges, leistungsorientiertes Team mit sechs Standorten weltweit. Bei uns zählen Talent und Impact – nicht Hierarchie oder Hintergrund.

**Rasantes Wachstum, in jeder Hinsicht**

Sifted zählt uns regelmäßig zu den am schnellsten wachsenden Scale-ups in Europa. Wir werden angetrieben durch konstantes Lernen, gemeinsame Erfolge und kollektives Wachstum.

**Next-Gen-Führungskräfte & Insights**

Arbeite Seite an Seite mit einigen der klügsten Köpfe in Tech – von Forbes 30 Under 30-Gründern bis hin zu „Executive of the Year“-Preisträgern. Bei vivenu setzt du neue Standards für die Zukunft der Ticketing-Branche.

**vivenu Inklusions-Statement**

Bei vivenu glauben wir, dass unsere Mitarbeitenden unseren Erfolg ausmachen – und dass wir mit mutigen, vielfältigen Menschen gewinnen. Die stärksten Teams entstehen durch unterschiedliche Perspektiven, Erfahrungen und Stimmen. Wir setzen uns dafür ein, ein Arbeitsumfeld zu schaffen, in dem sich alle befähigt fühlen, sich einzubringen, zu wachsen und zu gedeihen, um die Zukunft des Live-Entertainments weltweit mitzugestalten.

Schau dir auch [hier](https://vivenu.com/career#mission) unser Mission Statement und unsere Corporate Values an.

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
