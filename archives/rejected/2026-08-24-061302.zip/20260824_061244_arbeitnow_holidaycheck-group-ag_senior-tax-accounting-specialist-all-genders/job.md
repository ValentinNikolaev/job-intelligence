# (Senior) Tax & Accounting Specialist (all genders)

Posted: 2026-08-23T23:29:22Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**Starte deine ganz persönliche Reise – mit HolidayCheck!**

Bei HolidayCheck dreht sich alles darum, gemeinsam Urlaub besser zu machen. Wir ermöglichen nicht nur unseren Reisenden die schönste Zeit des Jahres, sondern schaffen auch für unser Team eine inspirierende Arbeitsatmosphäre – in unserem modernen Büros in München oder Bottighofen.

Unsere Unternehmenswerte leben wir täglich: Als #TeamHolidayCheck schaffen wir Vertrauen, übernehmen Verantwortung und lieben, was wir tun – für das perfekte Urlaubserlebnis.

Du übernimmst die Verantwortung für local tax compliance und tax accounting/ tax governance für die Gesellschaften in Deutschland und der Schweiz. Du unterstützt das Hauptbuchhaltung für Deutschland und die Schweiz eigenständig, mit direktem Einfluss auf Prozesse und enger Zusammenarbeit mit den Abteilungen, Muttergesellschaft in Offenburg, Steuerberatern und Wirtschaftsprüfern.

**Deine Aufgaben**

- Unterstützung bei der Erstellung von Steuererklärungen sowie enge Zusammenarbeit mit externen Steuerberatern und Wirtschaftsprüfern
- Unterstützung bei der Erstellung von Monats-, Quartals- und Jahresabschlüssen nach HGB und OR
- Qualitätssicherung und Dokumentation wichtiger buchhalterischer Vorgänge
- Abstimmung mit den Bereichen Debitoren, Kreditoren und Lohnbuchhaltung
- Mitwirkung bei kaufmännischen Themen wie neuen Geschäftsmodellen und der Transferpreisdokumentation
- Optimierung und Weiterentwicklung bestehender Buchhaltungsprozesse
- Klärung neuer bilanzieller Sachverhalte
- Einbringung neuer Ideen zur Weiterentwicklung und Automatisierung von Prozessen, auch unter Einsatz von KI

**Das bringst du mit**

- Kaufmännische Ausbildung mit Weiterbildung, z. B. zum Bilanzbuchhalter, Steuerfachangestellten oder mit eidgenössischem Fachausweis
- Mehrjährige Erfahrung in der Buchhaltung oder Steuerberatung, idealerweise auch im internationalen Umfeld
- Fundierte Kenntnisse im deutschen Steuerrecht sowie in HGB und OR; Kenntnisse des Schweizer Steuerrechts sind von Vorteil
- Gutes Verständnis für relevante rechtliche Rahmenbedingungen
- Gute SAP-Kenntnisse und sicherer Umgang mit Excel
- Analytische, eigenverantwortliche und strukturierte Arbeitsweise
- Teamfähigkeit, Organisationstalent und ausgeprägte Lösungsorientierung
- Sehr gute Deutschkenntnisse sowie gute Englischkenntnisse in Wort und Schrift

**Unser „All Inclusive Package” für dich **

**Workation & Flexibilität  **

- 20 Tage Workation innerhalb der EU – arbeite, wo andere Urlaub machen 
- 60/40 Hybrid-Modell: Zwei Büro-Tage für Austausch & Teamspirit, drei Tage flexibel remote 
- Flexible Arbeitszeiten – Frühaufsteher oder Langschläfer? Bei uns passt beides!
**Entwicklung & Kultur  **

- Umfangreiche interne & externe Trainingsangebote 
- Vielfältige Unternehmenskultur mit über 30 Nationalitäten 
- Vom Newbie zum Champion:  Strukturiertes Onboarding für einen perfekten Start 
**Extras & Wertschätzung  **

- Jubiläumsjubel in Form von zusätzlichen Urlaubstagen oder Reisezuschüssen 
- Freie Wahl deiner Arbeits-Hardware – Mac, Windows oder Linux 
- Kostenfreier Parkplatz oder Zuschuss für den ÖPNV 
**Work-Life-Balance & Gesundheit  **

- Kita-Zuschuss für eine familienfreundliche Balance 
- Je nach Standort: EGYM Wellpass Mitgliedschaft oder Gym-Zuschuss 
- Gesunde & leckere Mahlzeiten in der Kantine
**Bist du bereit, dich dem HolidayCheck-Abenteuer anzuschließen?** Dann schnapp Dir Deinen Koffer voller Talente und schicke uns Deine Bewerbung!

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
