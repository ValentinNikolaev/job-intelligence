# Consultant Data & AI / Digitale Transformation Public Sector (all genders)

Posted: 2026-08-24T02:09:54Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**Über ]init[**

Du möchtest die Gesellschaft von morgen mitgestalten? Dann bist du bei ]init[ richtig. Denn unsere digitalen Lösungen sind für Menschen gemacht und haben gesellschaftliche Relevanz. Klingt spannend? Dann steig ein und arbeite gemeinsam mit über 1.400 ]init[s in interdisziplinären Teams an unseren sieben Standorten – oder flexibel von überall in Deutschland aus.

**Deine Mission bei ]init[**

Gestalte die Digitalisierung des Public Sector von morgen!Du willst nicht nur zuschauen, wie sich die öffentliche Verwaltung weiterentwickelt, sondern mit deinen analytischen und technischen Fähigkeiten aktiv dazu beitragen? Du hast Freude daran, komplexe Fragestellungen zu durchdringen, Daten intelligent zu nutzen und daraus innovative, praxisnahe Lösungen zu entwickeln? Ob Data Analytics, Künstliche Intelligenz oder die Konzeption digitaler Lösungen – bei uns bringst du Technologie, Daten und fachliche Anforderungen zusammen und gestaltest die digitale Transformation unserer Kund aktiv mit.

Sei dabei als **Consultant Data & AI / Digitale Transformation Public Sector (all genders)** – aus Mainz heraus mit der Option auf Homeoffice!

**Das gibt es zu tun**

- Du begleitest unsere Kund aus dem Public Sector bei anspruchsvollen Digitalisierungs- und Transformationsprojekten – von der Analyse und Konzeption bis zur Umsetzung.
- Du analysierst komplexe fachliche und technische Problemstellungen, strukturierst Anforderungen und entwickelst daraus pragmatische Lösungsansätze.
- Du analysierst und interpretierst Daten, erkennst relevante Zusammenhänge und leitest daraus konkrete Handlungsempfehlungen und Entscheidungsgrundlagen ab.
- Du bereitest Daten und Analyseergebnisse anschaulich auf und vermittelst auch komplexe technische Zusammenhänge verständlich und adressatengerecht.
- Du wirkst an datengetriebenen Lösungen und innovativen Anwendungsfällen rund um Data Analytics, Machine Learning und Generative AI mit.
- Du bewertest unterschiedliche Lösungsansätze systematisch und unterstützt dabei, aus analytischen Erkenntnissen umsetzbare Maßnahmen zu entwickeln.
- Gemeinsam mit interdisziplinären Teams entwickelst du Lösungen an der Schnittstelle von Fachlichkeit, Technologie und Organisation.
- Du arbeitest dich eigenständig in neue Technologien, Methoden und fachliche Themen ein, probierst neue Ansätze aus und bringst deine Ideen aktiv in unsere Projekte ein.
- Du wirkst bei Workshops, Präsentationen sowie der Abstimmung mit unterschiedlichen Stakeholdern mit.

**Das bringst du mit**

- Ein erfolgreich abgeschlossenes Studium in Physik, Mathematik, Informatik, Data Science, Wirtschaftsinformatik oder einer vergleichbaren analytisch-technischen Fachrichtung.
- Ausgeprägte analytische und konzeptionelle Fähigkeiten sowie die Fähigkeit, komplexe Problemstellungen strukturiert zu erfassen und in handhabbare Fragestellungen zu übersetzen.
- Erfahrung in der Analyse und Verarbeitung größerer Datenmengen sowie ein gutes Verständnis für statistische und quantitative Methoden.
- Praktische Programmiererfahrung, idealerweise mit Python; Kenntnisse in weiteren Programmiersprachen, SQL, Git oder gängigen Data-Science-Bibliotheken sind ein Plus.
- Erste Berührungspunkte mit Machine Learning, Generative AI oder anderen modernen datengetriebenen Technologien sind von Vorteil.
- Eine strukturierte und faktenbasierte Arbeitsweise sowie die Fähigkeit, Ergebnisse kritisch zu hinterfragen und unterschiedliche Lösungsansätze systematisch zu bewerten.
- Interesse an IT-Beratung, digitaler Transformation und den Herausforderungen der Digitalisierung des öffentlichen Sektors.
- Freude daran, dich schnell und eigenständig in neue fachliche und technische Themen einzuarbeiten und neue Technologien auszuprobieren.
- Kommunikationsstärke und die Fähigkeit, komplexe Sachverhalte verständlich für unterschiedliche Zielgruppen aufzubereiten.
- Freude an der Zusammenarbeit in interdisziplinären Teams sowie mit Kund und unterschiedlichen Stakeholdern.
- Sehr gute Deutsch- und gute Englischkenntnisse.

**Das bieten wir dir**

- Because we care: Deine Work-Life-Balance liegt uns am Herzen. Aus diesem Grund sichern wir dir 30 Urlaubstage zu, flexible Arbeitszeiten sowie Workation im EU-Ausland!
- Work with us: Wir arbeiten deutschlandweit mobil zusammen - full-time oder im Teilzeitmodell deiner Wahl. Du entscheidest, wo du arbeiten möchtest.
- Learn with us: In unserer ]init[ Akademie und mit zahlreichen Trainings im Jahr machen wir dich fit für deine Ziele & Herausforderungen. Eigne dir regelmäßig neue Kompetenzen an und wachse über dich hinaus, denn wir wollen, dass du gerne bei uns bist und dich nach deinen Interessen entwickeln kannst.
- Grow with us: Lerne unsere Learning Lunches & Nutshells kennen, die dir neben deinem Einsatz in Projekten einen abteilungsübergreifenden Austausch ermöglichen. In unseren Teams unterstützen wir uns gegenseitig dabei, mutig zu denken, um gemeinsam den digitalen Wandel zu gestalten.
- Ride with us: Du bleibst gerne in Bewegung? Wir bezuschussen dein ÖPNV-Ticket und entwickeln unsere Corporate Mobility Benefits kontinuierlich weiter - für dich und für mehr nachhaltige Mobilität in urbanen Räumen.
- Start with us: Dein Einstieg ist vom ersten Moment an organisiert! Mit unserer virtuellen Welcome Week kommst du bei ]init[ richtig gut an. Eine enge Begleitung durch Patenschaften & Vernetzungsangebote gehören bei uns zu einem gelungenen Start dazu.

**Werde Teil des Teams**

Mit uns machst du einen echten Unterschied — auch für dein Arbeitsleben. Teilzeit oder Vollzeit, remote oder im Office.
Du findest dich mit deiner Erfahrung in diesen Punkten wieder? Am besten lernen wir uns direkt kennen! Wir freuen uns auf deine Bewerbung, gerne mit der Angabe des frühestmöglichen Eintrittsdatums sowie deinem Gehaltswunsch. **Anne **aus dem Recruiting-Team freut sich auf den Austausch mit dir!

Da uns und unseren Kund:innen Sicherheit wichtig ist, kann je nach Position nach etwaiger Zusage eine vertrauliche Abfrage zum Sicherheitscheck erforderlich sein.

**Recruiter**

Anne Kroll

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
