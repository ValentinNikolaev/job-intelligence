# Senior VTC Engineer

Posted: 2026-08-23T23:24:32Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**About the Organization**

Now is a great time to join Redhorse Corporation. We are a solution-driven company delivering data insights and technology solutions to customers with missions critical to U.S. national interests. We’re looking for thoughtful, skilled professionals who thrive as trusted partners building technology-agnostic solutions and want to apply their talents supporting customers with difficult and important mission sets.

**Join the Team Building the Future of AI for National Security**

We are redefining how the U.S. Government transforms data into operational advantage through artificial intelligence, graph analytics, and mission-driven software engineering. Our teams work alongside the Department of Defense to build secure, scalable capabilities that enable analysts and decision-makers to move faster, reason better, and operate with greater confidence.

Our approach combines human-centered design, modern software engineering, graph technologies, artificial intelligence, and agile delivery to solve some of the nation’s most challenging problems.

**About the Role**

We’re looking for an exceptional Senior VTC Engineer to support mission-critical collaboration and secure communication efforts within the Department of Defense. Our team functions and collaborates across multiple workstreams including engineering, mission operations, and executive leadership, ensuring highly technical projects deliver measurable outcomes.

Working directly with other engineers, architects, and mission users, the Unified Communications Engineer will be responsible for the daily management, troubleshooting, and optimization of enterprise-level Video Teleconferencing (VTC) and conference room systems. This role ensures that secure, multi-classified communication channels remain operational and scalable, allowing decision-makers to operate with confidence across global environments.

This position is ideal for someone who thrives delivering mission-focused infrastructure work, enjoys bringing structure to complex hardware and network environments, and understands that successful national security operations require disciplined execution and reliable communications.

**Key Responsibilities**

- Provide daily management and expert-level support for site VTC and Conference Room systems, including scheduling with external sites and configuring rooms for high-stakes conferences.

- Troubleshoot complex VTC and conference room equipment failures; perform fault isolation and execute repairs or coordinate with external offices for component support.

- Manage video capturing and transfers to media streaming servers to ensure mission data is accessible.

- Perform routine performance testing and maintenance on computer workstations and VTC equipment to ensure optimal capacity and performance.

- Schedule AV/VTC sessions and maintain call schedules, coordinating reservations for executive-level users and outside agencies.

- Conduct site surveys to establish AV/VTC system requirements and draft Standard Operating Procedures (SOP) for VTC operations.

- Perform system security functions, including the development of system security plans and vulnerability remediation.

- Operate and maintain VTC Bridges (switches) and Studio environments across SBU and SECRET domains, facilitating multiple concurrent sessions.

- Develop and deliver trend analysis regarding system load, usage, and response times to drive infrastructure improvements.

- Provide client training on control interfaces and audio/visual equipment, and train other IT professionals within the organization.

- Act as equipment custodian, performing inventory asset management and accountability functions.

- Implement secure configurations and maintain compliance consistent with DoD cybersecurity requirements (IAT Level II).

**Experience/Clearance**

- Active Top Secret clearance with SCI eligibility (TS/SCI required).

- Bachelor’s degree (BA/BS) in a technical discipline. An equivalency of 12+ years of relevant experience may be considered in lieu of a degree.

- 5+ years of relevant experience in Unified Communications or VTC Engineering, with an upward trajectory.

- 8+ years of supervisory/managerial experience preferred.

- Certifications: Must be IAT Level II Certified (e.g., Security+) and maintain relevant Computer Environment certifications.

- Technical Proficiency: Hands-on experience configuring Tandberg/Cisco Codecs and a strong understanding of basic networking.

- Proficiency in Microsoft Office Suite (PowerPoint, Word, Excel, Access, and Outlook).

- Experience supporting government or defense programs, specifically with multi-security classified IP video teleconferencing.

- Strong analytical, debugging, and systems thinking skills with the ability to communicate complex technical concepts to technical and non-technical stakeholders.

- Ability to work independently and collaboratively in multidisciplinary teams.

- Commitment to delivering secure, reliable, and mission-focused communication solutions.

The salary range provided for this position represents the anticipated base salary for successful candidates. Actual compensation will be determined based on a variety of factors, including relevant experience, education, certifications, skills, security clearance level, geographic location, market conditions, and internal equity. In addition to base salary, eligible employees may participate in Redhorse's comprehensive benefits programs and may be eligible for performance-based or other incentive compensation, where applicable.

Redhorse Corporation is an equal opportunity employer. All qualified applicants will receive consideration for employment and will not be discriminated against on the basis of race, color, religion, sex, sexual orientation, gender identity, national origin, veteran status, disability, or any other protected class.

If you are a qualified individual with a disability or a disabled veteran, you may request a reasonable accommodation if you are unable or limited in your ability to access job openings or apply for a job on this site as a result of your disability. You can request reasonable accommodations by contacting Talent Acquisition -----

Redhorse Corporation shall, in its discretion, modify or adjust the position to meet Redhorse’s changing needs. This job description is not a contract and may be adjusted as deemed appropriate in Redhorse’s sole discretion.

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
