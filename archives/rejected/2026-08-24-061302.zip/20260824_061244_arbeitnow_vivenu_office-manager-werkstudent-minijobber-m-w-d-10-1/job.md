# Office Manager Werkstudent / Minijobber (m/w/d), 10-15 Stunden pro Woche

Posted: 2026-08-23T23:24:13Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**Gestalte die Zukunft von Live-Entertainment-Tech**

Willkommen bei vivenu – dem globalen Vorreiter für Event-Ticketing-Technologie und einem der weltweit schnellst wachsenden Tech-Unternehmen im Live-Entertainment. Wir revolutionieren Ticketing für internationale Größen wie die Grammys, die Golden Globes, die Stanford University und den Hockenheimring – und machen aus einer einfachen Ticketing-Transaktion einen echten strategischen Wettbewerbsvorteil. Mit über 65 Millionen US-Dollar an Finanzierung im Rücken ermöglicht unsere Plattform Veranstaltern, ihre Markenpräsenz selbst zu steuern, tiefgreifende Datenanalysen zu nutzen und Ticketing nahtlos in ihre digitale Infrastruktur zu integrieren.

Mit sechs Standorten weltweit bieten wir eine intuitive, individuell anpassbare Lösung und branchenführenden Support, der selbst die komplexesten Herausforderungen im Ticketing vereinfacht. So helfen wir Veranstaltern, außergewöhnliche Erlebnisse zu schaffen und nachhaltiges Wachstum zu erzielen.

Werde Teil unserer Mission – und gestalte die Zukunft von Live-Entertainment mit.

Als **Office Manager (m/w/d)** in Frankfurt bist du das Herzstück unseres Büros vor Ort. Du sorgst für eine angenehme Arbeitsatmosphäre und reibungslose Abläufe im Büroalltag.

**Als Office Manager (m/w/d) in Frankfurt gehören zu deinen Aufgaben:**

- **Bestellmanagement:** Du kümmerst dich eigenverantwortlich um die Bestellung und Verwaltung von Getränken, Snacks, Verpflegung und allem rund um den Bürobedarf.

- **Büroorganisation:** Du hältst unser Office stets ordentlich und repräsentativ.

- **Events & Meetings:** Du bereitest unsere Räumlichkeiten für interne Team-Sprints, Workshops sowie potenzielle Kundenbesuche vor.

- **Zentraler Ansprechpartner:** Du bist die erste Anlaufstelle vor Ort für Mitarbeiter, Dienstleister, Handwerker, Lieferungen und Post.

**What you will need to succeed in this role:**

- **Qualifikation / Hintergrund:** Du absolvierst aktuell ein Studium (ideal für Werkstudenten) oder hast eine Ausbildung im Bereich Hotellerie oder als Bürokauffrau/Bürokaufmann bzw. eine vergleichbare Qualifikation.

- **Organisationstalent:** Du arbeitest strukturiert, packst gerne mit an, hast einen Blick fürs Detail und setzt effektiv Prioritäten.

- **Eigeninitiative:** Du gehst selbstbewusst an neue Aufgaben heran und hast stets den Anspruch, hochwertige Ergebnisse zu liefern.

- **Teamgeist:** Du bist ein herausragender Teamplayer mit der Bereitschaft, Verantwortung zu übernehmen und proaktiv zu handeln.

- **Sprachkenntnisse:** Fließendes Deutsch sowie sehr gutes Englisch für die tägliche Arbeit im internationalen Team.

- **Verfügbarkeit:** Ca. 10-15 Stunden die Woche, idealerweise geteilt auf dienstags und donnerstags.

**Warum bei vivenu einsteigen?**

**Live-Entertainment-Technologie**

Spiele eine entscheidende Rolle für globale Marken und gestalte das Fan-Erlebnis neu – von Festivals bis hin zu großen Sport Events. Bei uns bist du Teil des Business of Fun – angetrieben von modernster Technologie, die besondere Momente für Millionen greifbar macht.

**Nachhaltiges Wachstum**

Wir wachsen nachhaltig auf einer profitablen, von Investoren unterstützten Basis mit echtem Product-Market-Fit. Das bedeutet kontinuierliche Investitionen in unsere Mitarbeitenden, unsere Produkte und unsere langfristige Vision.

**Top-Tier Team**

Arbeite mit über 160 engagierten Profis zusammen – darunter Führungskräfte von Google, Slack und Salesforce. Gemeinsam gestalten wir die Zukunft der Live-Entertainment-Technologie – Entscheidung für Entscheidung.

**Globale DNA**

Wir sind ein vielfältiges, leistungsorientiertes Team mit sechs Standorten weltweit. Bei uns zählen Talent und Impact – nicht Hierarchie oder Hintergrund.

**Rasantes Wachstum, in jeder Hinsicht**

Sifted zählt uns regelmäßig zu den am schnellsten wachsenden Scale-ups in Europa. Wir werden angetrieben durch konstantes Lernen, gemeinsame Erfolge und kollektives Wachstum.

**Next-Gen-Führungskräfte & Insights**

Arbeite Seite an Seite mit einigen der klügsten Köpfe in Tech – von Forbes 30 Under 30-Gründern bis hin zu „Executive of the Year“-Preisträgern. Bei vivenu setzt du neue Standards für die Zukunft der Ticketing-Branche.

**vivenu Inklusions-Statement**

Bei vivenu glauben wir, dass unsere Mitarbeitenden unseren Erfolg ausmachen – und dass wir mit mutigen, vielfältigen Menschen gewinnen. Die stärksten Teams entstehen durch unterschiedliche Perspektiven, Erfahrungen und Stimmen. Wir setzen uns dafür ein, ein Arbeitsumfeld zu schaffen, in dem sich alle befähigt fühlen, sich einzubringen, zu wachsen und zu gedeihen, um die Zukunft des Live-Entertainments weltweit mitzugestalten.

Schau dir auch [hier](https://vivenu.com/career#mission) unser Mission Statement und unsere Corporate Values an.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
