# Senior DevOps Engineer

Posted: 2026-08-24T05:04:44Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**Want to work on Software-Defined Defense? **

At Apex.AI, we develop safety-certified software for mobility systems and intelligent machines. Our products power applications in automotive, trucking, robotics, aerospace, agriculture, industrial automation, and [defense systems](https://www.apex.ai/defensesystems).

We are hiring a Senior DevOps Engineer to design and scale Apex.AI's build and release systems. You will architect and implement our build and release system solutions, which impact developer productivity company-wide and ensure that customers receive high-quality products in a timely manner.

In this role, you will work directly with European defense customers and internal product teams to design, build, deploy, and Apex.Alan. You will help customers bring real-world systems to production while contributing improvements and features back into our core platform. Find out more about Apex.Alan [here](https://www.apex.ai/apex-alan) and [here](https://www.apex.ai/post/powering-multi-variant-software-at-scale-how-apex-alan-helps-global-oems-tame-complexity-and-accele).

This role is located in our Munich office. Authorization to work in Germany and German language skills are required.

**What You Bring**

- B.S. or higher degree in a technical field with 5+ years of relevant work experience

-

Proven experience working with cloud infrastructure on AWS, Azure, or GCP

- Proven experience maintaining a cross-platform build system

- Proven experience managing CI/CD pipelines

- **Proven ability to script in Python and Starlark**

- **Proven experience building C/C++ projects with Bazel**

- Familiarity with GitLab or GitHub

- Experience navigating Linux-based systems and tools in a terminal

- Excellent troubleshooting skills

- Excellent communication skills

- German language skills

**Nice To Have**

- Experience with infrastructure management tools such as Terraform

- Experience with Bazel internals

- Familiarity with releasing code and binaries to customers

- Familiarity with cross-compilation

- Experience with the usage of CMake

- Experience developing Bazel infrastructure

Apex.AI is an international software company specializing in the development of safety-certified, developer-friendly, and scalable software for mobility systems, aiming to accelerate the transition to software-defined vehicles and mobility. Founded in 2017 by Jan Becker and Dejan Pangercic, the company is headquartered in Palo Alto, California, with additional offices in Munich, Stuttgart, Gothenburg, Tokyo, and Pangyo. To date, Apex.AI has raised over $75 million USD from world-class venture, financial and strategic investors including AGCO, Airbus Ventures, Canaan, Continental AG, Daimler Truck, HELLA Ventures, Jaguar Land Rover’s InMotion Ventures, LG Electronics, Lightspeed, Orillion, Toyota Ventures, Volvo Group Venture Capital and ZF.

The company’s flagship product, Apex.OS, consists of two core components: Apex.Grace and Apex.Ida.

- **Apex.Grace** is an application runtime framework in the form of a software development kit (SDK). It provides a robust framework for developing real-time, reliable, and safe applications. Core APIs are based on ROS 2 APIs with numerous extensions enabling real-time execution, reliable performance, deployment into large fleets, system state management, safety, security, and much more. It is safety-certified to ISO 26262 ASIL D.

- **Apex.Ida** is a communication middleware delivering optimal high-performance data transport across use cases. These use cases range from fully autonomous vehicles with dozens of high-resolution cameras to small signals with ultra-high frequencies in safety-critical domains. Its core is based on a shared memory data transport with connectors into DDS, SOME/IP, MQTT, CAN, and many more protocols, all abstracted into a single application-facing API.

Additionally, Apex.AI offers:

- **Apex.Alan** provides customers with a highly optimized and efficient software integration, development environment, build, test, and delivery process.

- **Apex.OS for V&V** enables record and playback of very large and diverse data streams, both time- and data-deterministically, which is crucial for replay, analysis, and performance evaluation of complex autonomous systems.

Apex.AI’s software solutions are utilized across a diverse range of industries, including automotive, agriculture, medical, and defense sectors. The products enable developers to efficiently create and deploy safe, reliable, and high-performance applications, thereby accelerating the adoption of software-defined mobility systems. Through its innovative software solutions and strategic partnerships, Apex.AI is at the forefront of transforming the mobility industry, facilitating the development of next-generation vehicles and systems.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
