# Senior Product Manager - Markt- & Trendanalyse-Plattform (m/w/d)

Posted: 2026-09-06T16:32:22Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Wir vermitteln dich an ein wachsendes Software-Unternehmen mit Sitz in Frankfurt am Main, das mit einer datengetriebenen Analyse-Plattform den Handel smarter macht. Als Senior Product Manager übernimmst du die strategische Roadmap und sorgst dafür, dass die Plattform Maßstäbe für Markt- und Shopper-Insights im Handel setzt. Du bist die Schnittstelle zwischen Produkt, Go-to-Market, Vertrieb und Entwicklung und arbeitest eng mit Category-Management- und Marktforschungsteams zusammen, um echten Mehrwert für die Anwender zu schaffen.

## Aufgaben

Deine Aufgaben

- Du treibst die strategische Roadmap für unsere datengetriebene

Markt- und Trendanalyse-Plattform voran und stellst sicher, dass sie die

Benchmark für datengetriebene Markt- und Shopper-Insights im Handel

bleibt

- Du orchestrierst funktionsübergreifende Initiativen zwischen

Produkt-, Go-to-Market-, Strategie- und Entwicklungsteams mit Fokus auf

klare Mehrwerte für Category Management und Marktforschung

- Du arbeitest eng mit Vertriebs-, Category-Management- und

Marktforschungsteams auf Kundenseite zusammen, um Anwendungsfälle wie

Trendmonitoring, Sortimentsoptimierung und Kampagnen-Evaluation zu

priorisieren

- Du verantwortest die Feature-Strategie der Plattform und leitest aus

Kundenanalysen, Interviews und Testkunden-Feedback klare Anforderungen

ab

- Du planst gemeinsam mit dem Entwicklungsteam Sprints, pflegst und

priorisierst das Backlog und sorgst für reibungslose, kundenorientierte

Releases

- Du bereitest Produktlaunches und größere Funktionsreleases gemeinsam

mit Sales und Marketing vor — inklusive Storyline, Positionierung und

Enablement für den Vertrieb

## Qualifikation

Fachliche Anforderungen

- Abgeschlossenes Studium im Bereich Wirtschaft,

Wirtschaftsinformatik, Wirtschaftsingenieurwesen, MINT oder

vergleichbare Qualifikation

- Mehrjährige Erfahrung im Produktmanagement, Category Management, in der Marktforschung oder im Business Development

- Praktische Erfahrung im Umgang mit datengetriebenen Analysen und erste Berührungspunkte mit generativer KI

- Vertrautheit mit agilen Methoden (Scrum, Kanban) und Erfahrung in der Steuerung cross-funktionaler Teams

- Sehr gute Deutsch- und Englischkenntnisse in Wort und Schrift

Persönliche Kompetenzen

- Kommunikationsstark und moderationserfahren, sicher im Umgang mit unterschiedlichsten Stakeholdern

Von Vorteil (kein Muss)

- Erfahrung in Handel, Konsumgüterbranche oder Retail-Tech, idealerweise mit SaaS-Produkten im B2C-Kontext

- Grundkenntnisse in einer Programmiersprache, z. B. Python

## Benefits

- 80.000 € – 90.000 € Bruttojahresgehalt

- 30 Urlaubstage plus gesetzliche Feiertage

- Hybrides Arbeitsmodell mit Homeoffice-Anteil

- Modernes Büro im Herzen von Frankfurt am Main

- Direkter Einfluss auf Produktstrategie und Roadmap

- Enge Zusammenarbeit mit Vertrieb, Category Management und Marktforschung

- Kurze Entscheidungswege, viel Gestaltungsspielraum

- Arbeiten an einem Produkt mit echtem Marktimpact im Handel

Arbeitsmodell

Mindestens 2–3 Tage pro Woche vor Ort beim Arbeitgeber in Frankfurt

am Main; bis zu 3 Tage pro Woche im Homeoffice/remote möglich.

Unser Bewerbungsprozess

- Interview (Video-Call) mit uns

- Interview mit dem Arbeitgeber (Video-Call)

- Interview mit dem Arbeitgeber vor Ort in Frankfurt

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
