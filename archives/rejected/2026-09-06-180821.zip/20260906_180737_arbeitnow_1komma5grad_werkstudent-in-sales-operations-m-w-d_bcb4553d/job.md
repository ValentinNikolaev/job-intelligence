# Werkstudent:in Sales & Operations (m/w/d)

Posted: 2026-09-06T17:09:08Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**1KOMMA5°**

Bei **1KOMMA5°** verfolgen wir eine Vision: **Living on wind and sunlight forever for free**. Dafür bauen wir mit Heartbeat AI das Energiesystem der Zukunft. Bist du dabei?

Wir bringen regionales Handwerk und skalierbare Software zusammen: Solar, Speicher, Wärmepumpe und E-Mobilität denken wir nicht einzeln, sondern steuern sie als intelligentes, integriertes Gesamtsystem in unserem virtuellen Kraftwerk. Direkt verbunden mit dem Strommarkt – in Echtzeit, vollautomatisiert. So wird Energie dann genutzt, wenn sie erneuerbar verfügbar und besonders günstig ist. Bis 2030 wollen wir 1,5 Millionen Haushalte auf erneuerbare Energien umstellen. Über 3.000 Menschen arbeiten jeden Tag daran, an mehr als 80 Standorten weltweit, von Finnland bis Australien.

Du willst Verantwortung übernehmen und Lösungen bauen, die wirklich zählen? Bewirb dich jetzt und gestalte mit uns die Energiewelt von morgen.

**Deine Position**

Als Werkstudent/in im Vertrieb übernimmst du vom ersten Tag an Verantwortung im direkten Kundenkontakt und sorgst für reibungslose interne Prozesse:

- Lead-Vorqualifizierung: Du übernimmst den Erstkontakt zu potenziellen Neukunden, qualifizierst Anfragen vor und filterst relevante Leads für unsere Energie-Experten im Sales-Team
- Proaktives Terminmanagement: Du koordinierst und terminierst Kundengespräche (z. B. für digitale Beratungen oder Vor-Ort-Checks) und übernimmst die selbstständige Umplanung bei Terminverschiebungen
- Informationsbeschaffung: Du bist hartnäckig, aber charmant, wenn es darum geht, fehlende Dokumente oder wichtige Fotos (z. B. vom Zählerschrank, Hausdach oder Heizungskeller) von Kunden rechtzeitig einzuholen
- Prozessoptimierung (Sales to Ops): Du stellst sicher, dass alle relevanten Kundeninformationen und technischen Details vollständig vorliegen, um eine saubere und schnelle Übergabe vom Vertrieb an unsere Installations-Teams (Ops) zu garantieren.

**Dein Profil**

Wir suchen niemanden, der nur abarbeitet, sondern jemanden, der mitdenkt und anpackt. Folgende Punkte sind uns wichtig:

-

Kommunikationstalent: Du hast großen Spaß am Telefonieren, bist redegewandt, schlagfertig und triffst im Kundenkontakt stets den richtigen Ton

-

Schnelle Auffassungsgabe: Du durchdringst Problemstellungen in Sekundenschnelle und weißt genau, welche Informationen das Ops-Team für die reibungslose Installation der Energiesysteme benötigt

-

Zielorientierung & Drive: Du arbeitest strukturiert, verlierst das Ziel nie aus den Augen und hakst proaktiv nach, bis alle Unterlagen vollständig sind

-

Studentischer Status: Du bist aktuell an einer Hochschule immatrikuliert (der Studiengang ist zweitrangig, wichtig ist deine Motivation)

Zusätzliche Pluspunkte (Nice-to-have):

-

Passion for Impact: Du brennst für die Themen Klimaschutz, Energiewende und Nachhaltigkeit

-

Branchenwissen: Du hast bereits erste Berührungspunkte oder Vorwissen im Bereich Wärmepumpen, Photovoltaik oder Energiemanagement gesammelt (Kein Muss – wir bringen dir das Wichtigste bei, aber es hilft dir beim Start enorm!)

**Benefits**

-

Sinnstiftende Arbeit: Du bist Teil der Lösung und gestaltest die Energiewende bei einem der innovativsten Climate-Tech-Unternehmen Europas aktiv mit

-

Start-up-Spirit & Professionalität: Ein dynamisches Arbeitsumfeld mit flachen Hierarchien, direkten Entscheidungswegen und einem hochmotivierten Team

-

Steile Lernkurve: Tiefe Einblicke in Vertriebsstrukturen, Verkaufspsychologie und die Zukunftstechnologien der erneuerbaren Energien

-

Flexibilität: Flexible Arbeitszeiten, die sich optimal mit deinem Vorlesungsplan vereinbaren lassen

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
