# Backend Engineer - FinTech

Posted: 2026-09-21T08:40:03Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

## **About Andercore**

Andercore is the AI-native supplier of industrial materials for energy, infrastructure, and construction in wholesale and beyond.

We trade with global suppliers and distribute to European customers on our own account. Our AI runs the full trade and distribution end-to-end: sourcing, quality, pricing, sales, logistics, and embedded financing. For the customer, it feels like buying from their preferred local supplier; for our partners, it is the most convenient and safe way to do business across borders. Behind it, our software and agentic AI do the heavy lifting that used to take an asset-intensive supply chain with four or five intermediaries and weeks of manual coordination.

Where we are today:

-

Strong triple-digit-million euro turnover

-

Seven European markets live

-

80+ people across Berlin (HQ), offices in London, Mumbai, and Shanghai

$40M Series B just closed, $75M raised to date from Atomico, Project A, and Inven Capital, institutional financing from international banks.

We are building the world's first and last industrial-grade AI operating system for materials, redefining how global trade works in one of the largest and most essential industries on earth.

Financial systems demand a different level of precision. You will work on the backend infrastructure that handles payments, financial data, reconciliation, and compliance-critical workflows — systems where correctness and auditability are non-negotiable.

**Tech Stack:** Java 21 (Spring Boot 3), Python, PostgreSQL, AWS, Kinesis, Terraform, GitHub Actions, TypeScript.

## What you will do

-

Design and implement backend services for payment processing, invoicing, reconciliation, and smart financial reporting.

-

Build robust, auditable data pipelines that ensure accuracy and traceability across all financial operations.

-

Develop and maintain integrations with payment gateways, banking APIs, and financial data providers.

-

Enforce data integrity standards and implement patterns for idempotency, retry logic, and failure handling in financial flows.

-

Collaborate with compliance and product teams to translate regulatory requirements into technical implementation.

-

Contribute to fraud detection logic, rate limiting, and access control mechanisms that protect financial operations.

-

Own incidents end-to-end — investigate, resolve, and drive post-mortems to improve system reliability.

## Who you are

-

5-7+ years of backend engineering experience, with meaningful exposure to FinTech, payments, or financial data systems.

-

Strong proficiency in Java (Spring Boot) with a deep understanding of transactional systems and data consistency.

-

Solid experience with PostgreSQL, including schema design, indexing, and query optimization for financial data.

-

Experience integrating with payment processors (Stripe, Adyen, or similar) or open banking APIs.

-

High ownership mindset — you care about correctness as much as you care about delivery speed.

-

Calm under pressure, structured in your thinking, and rigorous in your testing practices.

We are an equal-opportunity employer and welcome applicants from all backgrounds, regardless of race, ethnicity, gender identity or expression, sexual orientation, religion, age, disability, or any other characteristic. We believe that diversity drives innovation, creativity, and collective strength.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
