# Werkstudent:in (m/w/d) Anlagenbau

Posted: 2026-09-21T08:30:38Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Hey! Hast du Lust, ein Teil eines innovativen Startups zu sein, das aus dem Deutschen Zentrum für Luft- und Raumfahrt hervorgegangen ist? Bei NUNOS GmbH dreht sich alles um die smarte Transformation von Gülle und Gärresten zu hochwertigem Dünger – und das auf rein biologische Weise! Als Werkstudent:in (m/w/d) im Anlagenbau bieten wir dir die Chance, in einem kleinen, dynamischen Team mit nur wenigen Kolleg:innen richtig durchzustarten und deine Ideen einzubringen. Gemeinsam mit uns kannst du an der Vision arbeiten, regionale Nährstoffkreisläufe zu optimieren und die organische Düngung neu zu denken. In Zeiten des Klimawandels setzen wir auf nachhaltige und widerstandsfähige Lösungen für die Landwirtschaft. Wenn du Lust hast, mit uns zu wachsen und etwas zu bewegen, dann bist du bei uns genau richtig!

## Aufgaben

- Unterstützung bei der Anlagenentwicklung, theoretisch wie praktisch

- Recherche und Dokumentation von Bauteilen und Prozessschritten

- Erstellung technischer Dokumentationen und Berichte

- Zusammenarbeit mit unserem interdisziplinären Team, um innovative Lösungen zu entwickeln

## Qualifikation

- Du bist aktuell in einem ingenieurwissenschaftlichen Studium eingeschrieben

- Du bringst handwerkliches Geschick oder sogar eine Berufausbildung mit

- Du arbeitest eigenverantwortlich und legst Wert auf die Qualität deiner Arbeit

- Du bringst Interesse an nachhaltigen Technologien und der Agrarindustrie mit.

- Du arbeitest gerne im Team und bist bereit, dich aktiv in unser junges Startup einzubringen.

## Benefits

- Einblick in die Arbeit eines Start-ups, vom Prototypenbau bis hin zur Marktreife

- Breites Themenfeld von der Kunststoffbearbeitung bis hin zu Mechatronik

- Interessante, verantwortungsvolle Tätigkeiten im kleinen Team

- Flexible Arbeitszeiten und Arbeitsgestaltung, abgestimmt auf deinen Stundenplan

- Ein Thema für dein Praxissemester/deine Abschlussarbeit

Sei Teil von NUNOS und gestalte die Zukunft der Landwirtschaft! Werde Werkstudent:in im Anlagenbau und wachse mit uns in einem innovativen Startup. Jetzt bewerben!

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
