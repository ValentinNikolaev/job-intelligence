# Junior Social Media Manager als Werkstudent (m/w/d)

Posted: 2026-09-21T08:57:36Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Du bist Gamer, kennst den Unterschied zwischen Paladin und Priester, hast eine positive K/D und bist bereit unsere Social Media Kanäle ins nächste Level zu bringen? Dann komm zu uns!

Wir suchen zum nächstmöglichen Zeitpunkt einen Junior Social Media Manager als Werkstudent (m/w/d) für unseren Standort in Osnabrück.

## Aufgaben

- Pflege des Social Media Auftritts

- Konzeption und Realisierung von kreativem Content für unsere Social Media Präsenz

- Projektumsetzungen in Zusammenarbeit mit anderen Abteilungen

- Markt- und Branchenrecherchen

## Qualifikation

- Du hast eine ausgeprägte Leidenschaft für Social Media

- Erste operative Kenntnisse in Instagram, TikTok und Co.

- Du zeigst hohe Eigeninitiative und besitzt eine ausgeprägte Hands-on-Mentalität

- Erste Kenntnisse im Umgang mit Schnitt- und Bildbearbeitungsprogrammen

- Ein hohes Maß an Kreativität und Gespür für Trends

- Du bist Gaming-affin, spielst selbst gerne Spiele auf dem PC oder der Konsole

## Benefits

- Arbeit in einem jungen, ambitionierten Team mit Leidenschaft für Gaming

- Flexible Arbeitszeiten und eine offene Unternehmenskultur

- Abwechslungsreiche, kreative Aufgaben und tolle Entwicklungschancen

- Raum, um eigene Ideen und Impulse einzubringen

- Direkte Verantwortung, denn ohne Verantwortung kannst du nicht wachsen

Wir freuen uns auf deine Bewerbung.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
