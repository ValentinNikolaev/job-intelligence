# CEO / Business Co-Founder (f/m/d) role at startup CHROMAMOS

Posted: 2026-09-21T08:58:28Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**CHROMAMOS**

Saarland, Germany | On-site | Co-Founder / Equity | Deep Tech / Analytical Instruments

**About ChromaMOS

**ChromaMOS has built a portable, lab-quality gas analysis device that delivers fast, dependable on-site results at a fraction of the cost of existing lab-based solutions — already validated for freshness assessment of hazelnuts, with applications spanning quality management, leakage monitoring and future breath analysis.

**The opportunity

**Built by Oliver Brieger ([M.Sc](http://M.Sc). Systems Engineering, currently finishing his PhD) and Julian Joppich ([M.Sc](http://M.Sc). Microtechnology and Nanostructures), ChromaMOS now has a validated 2nd-generation prototype at TRL 7 and is in discussions on LOIs with the food industry. The two engineer co-founders need a business partner to turn a validated device into an actual product and company.

## Tasks

**What you will own**

**Company build-up & funding

**- Lead incorporation (not yet founded) and drive the EXIST Research Transfer application and other funding routes for market-ready product development.

- Own the fundraising and grant strategy alongside the two technical co-founders.

Business development & sales

- Convert ongoing food-industry conversations into signed LOIs and paying pilot customers.

- Define target markets beyond food (quality management, leakage monitoring, breath analysis) and prioritize go-to-market.

Operations, marketing & finance

- Set up the commercial, marketing and finance operations the founding engineering team doesn't yet have in place.

## Requirements

**What you bring**

**Core experience

**- Business development, sales, marketing, operations or finance experience — ChromaMOS is open to a generalist business co-founder covering some or all of these.

- Comfort working with a deep-tech hardware product moving from validated prototype to market-ready product.

Especially valuable

- Experience with EXIST or similar German public deep-tech funding programs.

- Existing network in food industry quality management, industrial gas analysis, or analytical instruments.

- Interest in also helping recruit the team's planned 3rd (engineering/electronics) hire.

## Benefits

**Why join ChromaMOS**

- A 2nd-generation prototype already validated at TRL 7 for a real use case (hazelnut freshness), not an early concept.

- Significantly lower cost than existing lab-based gas analysis solutions — a clear commercial wedge.

- Ground-floor equity alongside two technical co-founders who have already built the product.

ChromaMOS welcomes co-founder candidates regardless of gender, age, ethnic origin, religion or belief, disability, sexual identity, or any other characteristic. This is a search for the right partner to build the company with, not a conventional hire.

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
