# Logistics Executive

Posted: 2026-09-21T08:40:03Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

## **About Andercore**

Andercore is the AI-native supplier of industrial materials for energy, infrastructure, and construction in wholesale and beyond.

We trade with global suppliers and distribute to European customers on our own account. Our AI runs the full trade and distribution end-to-end: sourcing, quality, pricing, sales, logistics, and embedded financing. For the customer, it feels like buying from their preferred local supplier; for our partners, it is the most convenient and safe way to do business across borders. Behind it, our software and agentic AI do the heavy lifting that used to take an asset-intensive supply chain with four or five intermediaries and weeks of manual coordination.

Where we are today:

-

Strong triple-digit-million euro turnover

-

Seven European markets live

-

80+ people across Berlin (HQ), offices in London, Mumbai, and Shanghai

$40M Series B just closed, $75M raised to date from Atomico, Project A, and Inven Capital, institutional financing from international banks.

We are building the world's first and last industrial-grade AI operating system for materials, redefining how global trade works in one of the largest and most essential industries on earth.

## What you will do

-

You will coordinate global transportation of goods and ensure prompt deliveries based on our customer needs

-

You will manage communication with third parties to ensure smooth business operations

-

You will open new trade lanes by finding new partners across the globe

-

You will create strong, reliable, and long-term relationships with our customers through quality work and clear communication

-

You will collaborate closely with customer success, procurement, product management, growth and engineering teams

-

You will use cutting-edge technology on Salesforce for logistics management

-

Improve and grow daily on a personal level, push for operational excellence

## Who you are

-

You hold a Bachelor’s degree in a related field

-

You have 3-5 years of experience in supply chain and logistics management

-

You are data-driven with proficiency in using KPIs and CRM systems(Salesforce)

-

You have experience optimizing costs while maintaining operational excellence

-

**You are fluent in German (C1 or above)**

-

You have scaled logistics operations across different countries

**Personality**

-

You have a strong commercial mindset

-

You are independent, collaborative, and able to take significant responsibility

-

You are entrepreneurial and hands-on, fast-paced is in your DNA

-

You are a strong communicator, comfortable with different stakeholders

We are an equal-opportunity employer and welcome applicants from all backgrounds, regardless of race, ethnicity, gender identity or expression, sexual orientation, religion, age, disability, or any other characteristic. We believe that diversity drives innovation, creativity, and collective strength.

Compensation: €50K – €60K

- • Yearly On Target Earnings (Fixed + Bonus) €50K – €60K

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
