# Chief of Staff, Strategy & AI Enablement

Posted: 2026-09-21T08:40:03Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

## **About Andercore**

Andercore is the AI-native supplier of industrial materials for energy, infrastructure, and construction in wholesale and beyond.

We trade with global suppliers and distribute to European customers on our own account. Our AI runs the full trade and distribution end-to-end: sourcing, quality, pricing, sales, logistics, and embedded financing. For the customer, it feels like buying from their preferred local supplier; for our partners, it is the most convenient and safe way to do business across borders. Behind it, our software and agentic AI do the heavy lifting that used to take an asset-intensive supply chain with four or five intermediaries and weeks of manual coordination.

Where we are today:

-

Strong triple-digit-million euro turnover

-

Seven European markets live

-

80+ people across Berlin (HQ), offices in London, Mumbai, and Shanghai

$40M Series B just closed, $75M raised to date from Atomico, Project A, and Inven Capital, institutional financing from international banks.

We are building the world's first and last industrial-grade AI operating system for materials, redefining how global trade works in one of the largest and most essential industries on earth.

We are hiring a Chief of Staff to the CEO. This is not a coordination role. This is a company-building role.

You will operate at the center of how Andercore runs. Across strategy, execution, finance, and operations. With exposure to the board and full proximity to the CEO.

-

Your job is not the product. Your job is the company itself.

-

Starting in the CEO office, you will shape how decisions are made, how priorities are set, and how execution happens across the entire organization. From the CEO level into the C-level layer, and from there into the company.

-

Your mandate is simple: make the company run better, faster, and more intelligently - every single day.

**What You Will Do**

**Run the Company Operating System**

-

Drive the CEO agenda across all functions

-

Build and enforce a clear operating cadence (weekly, monthly, quarterly)

-

Create full transparency on performance: GMV, Net Revenue, margin, working capital

-

Identify bottlenecks early and force resolution

**Translate Strategy into Execution**

-

Break down company strategy into concrete, executable plans

-

Align all CEO direct reports on priorities and timelines

-

Track execution rigorously and intervene where needed

-

Act as sparring partner to senior leadership

**Own Business and Financial Steering**

-

Work closely with Finance on P&L, balance sheet, and liquidity

-

Understand and challenge core drivers: pricing, margin, AR/AP, capital efficiency

-

Support investor communication and board preparation

-

Ensure decision-making is data-driven and fast

**Drive AI in How We Operate**

-

Apply AI to how the company runs - not to the product itself

-

Identify where workflows can be automated or improved

-

Deploy tools that increase speed, quality, and leverage across teams

-

Push for continuous improvement in execution

**Lead High-Impact Projects**

-

Own cross-functional initiatives end-to-end (e.g. M&A, market expansion, funding)

-

Run due diligence and support integration efforts

-

Solve ambiguous, high-stakes problems with speed and clarity

**What We Are Looking For**

-

5+ years at McKinsey & Company, Boston Consulting Group, or Bain & Company
or top-tier investment banking with strong M&A exposure

-

Proven track record of applying AI tools in real operating environments

-

Strong financial understanding (P&L, balance sheet, cash flow)

-

Exceptional structuring and problem-solving skills

-

Ability to operate under pressure in a high-performance environment

**Languages**

-

Native-level English required

-

German strongly preferred

**What Success Looks Like**

-

Decisions are faster, better, and data-driven

-

AI meaningfully improves internal execution

-

The CEO is focused on the highest-leverage topics

-

The company runs on a clear, enforced operating system

-

Leadership is aligned and executes with speed and clarity

**Why Join**

-

Work directly with the CEO on the most critical topics

-

Exposure to board-level thinking and decision-making

-

Full visibility across the company

-

Opportunity to shape how a high-growth company is run

-

Steep learning curve with real responsibility from day one

We are an equal-opportunity employer and welcome applicants from all backgrounds, regardless of race, ethnicity, gender identity or expression, sexual orientation, religion, age, disability, or any other characteristic. We believe that diversity drives innovation, creativity, and collective strength.

Compensation: €90K – €120K

- • Yearly On Target Earnings (Fixed + Bonus) €90K – €120K

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
