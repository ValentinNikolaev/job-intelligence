# Systemadministrator (m/w/d) - Full Remote

Posted: 2026-09-21T08:53:10Z

## Rejection

- Category: language_requirement
- Reason: hard German language requirement without English green light

Du suchst einen sicheren Job als **Systemadministrator (m/w/d)** in Vollzeit mit bis zu 100% Remote-Anteil? Möchtest du die digitale Transformation in Bayern aktiv mitgestalten und auf eine verlässliche, krisenfeste Basis bauen? Suchst du ein eingespieltes Team mit starkem Rückhalt, flachen Hierarchien und individuellen Entwicklungsmöglichkeiten?

**Das bieten wir dir schon ab dem Erstgespräch mit uns:**

- **Gratis Karriereberatung:** Wir zeigen Dir Karriere- und Verdienstmöglichkeiten auf. Ganz ehrlich und objektiv

- **Wertvolles Insider Know-how:** Wir geben Dir schon im Erstgespräch die Insights, die in keiner Stellenanzeige stehen

- **Die schnellste Abkürzung:** Auf dem schnellsten Weg zum Kennenlernen. Wir haben den direkten Draht zu den Verantwortlichen!

- **Maximale Erfolgsquote:** 98% unserer Kandidat*innen werden direkt zum Erstgespräch eingeladen

- **Alternative Jobangebote:** Wenn dieser Job nicht zu dir passen sollte, machen wir uns für dich auf die Suche. Kostenlos!

**Über das Unternehmen:**

- **Etablierter Marktführer:** Als dynamische Ausgründung mit über 1.000 Kunden treibst du als Marktführer in Bayern die Digitalisierung voran

- **Maximale Krisensicherheit:** Ein stabiles, zukunftssicheres Fundament bietet dir auch in unruhigen Zeiten verlässliche Beständigkeit

- **Wertschätzendes Arbeitsumfeld**: Flache Hierarchien, sehr geringe Fluktuation und gelebte Agilität prägen die Zusammenarbeit

- **Strukturierte Entwicklung:** Individuelle Weiterbildungen und eine eigene Online-Lernplattform sichern deine langfristige Perspektive

- Den Namen des Unternehmens und noch vieles mehr erzählen wir dir, sobald du dich bei uns meldest. Versprochen!

## Aufgaben

- **Verlässliche Projektbegleitung:** Du begleitest DMS-Projekte im kommunalen Umfeld partnerschaftlich zum Erfolg

- **Anforderungsanalyse**: Du nimmst fachliche und technische Kundenanforderungen strukturiert auf und analysierst diese präzise

- **Praxisnahe Implementierung:** Du übernimmst die Konfiguration und Migration der bewährten DMS-Lösung komXwork

- **Wissenstransfer:** Du führst zielgerichtete Schulungen sowie Workshops für Anwenderinnen und Projektbeteiligte souverän durch

- **Nahtlose Betreuung:** Du unterstützt bei Tests, Produktivsetzungen und der nachhaltigen Absicherung des laufenden Betriebs

- **Prozessoptimierung:** Du analysierst Herausforderungen und wirkst aktiv an der Weiterentwicklung bestehender Standards mit

## Qualifikation

- **Fundierte Erfahrung:** Mindestens 2 Jahre Berufserfahrung im öffentlichen Dienst, kommunalen Umfeld oder bei einem IT-Systemhaus

- **IT-Verständnis:** Praxis im Umgang mit SQL-Datenbanken und Powershell sowie idealerweise Microsoft-Serverumgebungen

- **Solide Fachkenntnisse:** Erfahrung in der Installation, Implementierung oder Anwendung von DMS- und ECM-Systemen sowie E-Akte sind von großem Vorteil

- **Persönlichkeit:** Eine lösungsorientierte, strukturierte Arbeitsweise mit Mut zum aktiven Hinterfragen und nötigem Biss

- **Kommunikationsstärke:** Zugewandtes Auftreten, fließende Deutschkenntnisse in Wort und Schrift sowie ein Führerschein der Klasse B

## Benefits

- **Sicheres Vergütungspaket:** Attraktives Gehalt von bis zu 75.000 EUR je nach Erfahrung inklusive freiwilliger Ergebnisbeteiligung

- **Maximale Flexibilität**: Auf Wunsch bis zu 100% Homeoffice, 31,5 Urlaubstage sowie 28 Tage Workation im Jahr für beste Work-Life-Balance

- **Verlässliche Zeiterfassung:** Gleitzeit mit transparenter Ausgleichsregelung sichert deine geleisteten Arbeitszeiten verlässlich ab

- **Perfekte Mobilität:** Nach der Probezeit eigener Firmenwagen zur privaten Nutzung, Jobticket sowie JobRad-Leasing

- **Zukunftssicherung:** Betriebliche Altersvorsorge, Kindergartenzuschuss und eine Wellpass-Sportmitgliedschaft

- **Erstklassige Ausstattung:** Top Hardware mit Laptop, Firmenhandy, Headset und zwei Bildschirmen für deinen Arbeitsplatz

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
