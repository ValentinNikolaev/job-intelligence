# Backend Engineer - Supply Chain & Logistics

Posted: 2026-09-21T08:40:03Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

## **About Andercore**

Andercore is the AI-native supplier of industrial materials for energy, infrastructure, and construction in wholesale and beyond.

We trade with global suppliers and distribute to European customers on our own account. Our AI runs the full trade and distribution end-to-end: sourcing, quality, pricing, sales, logistics, and embedded financing. For the customer, it feels like buying from their preferred local supplier; for our partners, it is the most convenient and safe way to do business across borders. Behind it, our software and agentic AI do the heavy lifting that used to take an asset-intensive supply chain with four or five intermediaries and weeks of manual coordination.

Where we are today:

-

Strong triple-digit-million euro turnover

-

Seven European markets live

-

80+ people across Berlin (HQ), offices in London, Mumbai, and Shanghai

$40M Series B just closed, $75M raised to date from Atomico, Project A, and Inven Capital, institutional financing from international banks.

We are building the world's first and last industrial-grade AI operating system for materials, redefining how global trade works in one of the largest and most essential industries on earth.

Our Supply Chain & Logistics domain sits at the core of what we build — handling real-time data flows, complex routing logic, and integrations with a fragmented ecosystem of providers. You will help shape the systems that make operations predictable and scalable for our customers.

**Tech Stack:** Java 21 (Spring Boot 3), Python, PostgreSQL, Kinesis, AWS, Terraform, GitHub Actions, Node.js, TypeScript.

## What you will do

-

Design and build backend services that power supply chain workflows — from order management to LSP integrations and real-time tracking.

-

Develop event-driven pipelines that process high-throughput logistics data reliably and at scale.

-

Build and maintain integrations with third-party logistics providers, ERPs, and warehouse management systems.

-

Own and evolve the data models that represent complex supply chain entities: shipments, inventory positions, fulfillment nodes.

-

Identify performance bottlenecks and lead the engineering effort to resolve them in production systems.

-

Work with LLM APIs (OpenAI, Anthropic, Gemini) to build intelligent workflows and automation.

-

Collaborate closely with Product and domain experts to translate operational complexity into clean technical solutions.

-

Contribute to architecture decisions and raise the engineering bar through rigorous code reviews and documentation.

## Who you are

-

5-7+ years of experience in backend engineering, ideally within logistics, supply chain, or operations-intensive domains.

-

Strong command of Java (Spring Boot) or equivalent JVM-based frameworks; Python a strong plus.

-

Experience designing systems that handle real-time data ingestion and processing (Kafka, Kinesis, or similar).

-

Comfortable with relational databases (PostgreSQL) and modeling complex, interrelated business domains.

-

Pragmatic approach to distributed systems — you understand trade-offs around consistency, availability, and latency.

-

Exposure to third-party API integrations and the messiness that comes with legacy and external systems.

-

Intellectually curious, detail-oriented, and motivated by shipping things that work reliably in the real world.

We are an equal-opportunity employer and welcome applicants from all backgrounds, regardless of race, ethnicity, gender identity or expression, sexual orientation, religion, age, disability, or any other characteristic. We believe that diversity drives innovation, creativity, and collective strength.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
