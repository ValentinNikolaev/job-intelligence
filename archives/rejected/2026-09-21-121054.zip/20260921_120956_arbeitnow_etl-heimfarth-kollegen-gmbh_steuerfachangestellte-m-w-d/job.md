# Steuerfachangestellte (m/w/d)

Posted: 2026-09-21T08:57:36Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**Deine Karriere bei ETL-Heimfarth Gruppe.**

**Wir begleiten dich auf deinem Weg.**

Du begeisterst dich für Zahlen? Teamwork, Zuverlässigkeit und Flexibilität sind für dich kein Fremdwort?

Dann sollten wir uns unterhalten. Wir von der **ETL-Heimfarth Gruppe** suchen eine/n Steuerfachangestellte/n für unseren Standort in Koblenz!

**In Voll- oder Teilzeit**

## Aufgaben

- Erstellung von Jahresabschlüssen und Gewinnermittlungen sowie

Steuererklärungen von Unternehmen, Freiberuflern und Privatpersonen

eines festen Mandantenstamms

- Prüfung von Steuerbescheiden

- Bearbeitung von Rechtsmittel und allgemeine steuerliche Fragestellungen

## Qualifikation

- Erfolgreich abgeschlossene Ausbildung zum/zur Steuerfachangestellte/n

- idealerweise Berufserfahrung in der Steuerberatung

- Erste Berufserfahrung in der Erstellung von Steuererklärungen,

Bilanzbuchhaltungen, Jahresabschlüssen und in der Mandantenberatung

- Verständnis für wirtschaftliche Zusammenhänge

- Gute Kenntnisse der DATEV-Programme im Bereich Steuererklärungen und Jahresabschlusserstellung

- Geübter Umgang mit MS-Office-Paket

## Benefits

- Moderne Kanzlei mit digitalisierter und zukunftsorientierter Arbeitsweise an der Mosel

- Wir unterstützen Ihre Weiterbildungen und Schulungen finanziell sowie operativ

- Teamwork auf Augenhöhe und Zusammenhalt

- Teamevents zur Förderung des Zusammenhalts

- Gute Verkehrsanbindung inkl. ÖPNV-Anschluss sowie Einkaufsmöglichkeiten

- Kostenfreie Mitarbeiterparkplätze, Fahrradstellplätze sowie eine Ladestation für Ihr E-Auto

- Teilnahmemöglichkeit an Jobrad Programm

- Regelmäßige Mitarbeitergespräche und Trainings für Ihre Weiterentwicklung

- Flexible Arbeitszeiten und Homeoffice möglich

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
