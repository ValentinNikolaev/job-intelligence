# M&A Intern (m/w/d) Frankfurt am Main

Posted: 2026-09-21T08:57:36Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Wir suchen ab Januar 2027 für mindestens 4 bis 6 Monate zur Verstärkung unseres Teams in Frankfurt am Main motivierte Studierende, die Praxiserfahrung im M&A in einer international tätigen M&A-Boutique mit einem starken Dealflow sammeln möchten.

Saxenhammer ist eine international tätige M&A-Boutique, die sich auf Mittelstands- und Wachstumsunternehmen spezialisiert hat. Wir beraten in den Bereichen M&A sowie Debt Financing und unterstützen unsere Klienten, maßgeblich Unternehmer, Gesellschafter und Konzerne, bei der Durchführung von Unternehmensverkäufen und -zukäufen, Kapitalerhöhungen und Finanzierungen.

Mit über 450 erfolgreich abgeschlossenen Transaktionen haben wir in sämtlichen Industrien umfangreiches Branchen-Know-how aufgebaut und entwickeln mit unseren Kollegen in Berlin, München, Frankfurt und der Schweiz zielgenaue Lösungen für unsere Klienten.

Im Bereich M&A begleiten wir Konzerne, Unternehmen und Unternehmer bei der Strukturierung und Umsetzung von maßgeschneiderten M&A-Prozessen. Als eine der führenden Boutiquen in Deutschland in diesem Bereich mit einem über 20-jährigen Track Record verbinden wir Investment Banking-Expertise mit notwendigem rechtlichen Know-how, um das bestmögliche Ergebnis für unsere Mandanten zu erzielen. Wir sind leidenschaftliche Dealmaker und Unternehmer mit persönlichem Zugang zu zahlreichen Investoren sowie einem klaren Clients First-Ansatz. Dich erwartet ein dynamisches Team von unternehmerisch agierenden M&A-Professionals in einem modernen Arbeitsumfeld, welche die Kultur der frühen Übernahme von Verantwortung aktiv lebt.

## Aufgaben

- Du unterstützt bei der Erstellung von Pitch-Präsentationen, Teasern, Informationsmemoranda und Management-Präsentationen

- Du wirst aktiv in die tägliche Projektarbeit eingebunden und betreust überwiegend M&A-Prozesse eng mit den Teammitgliedern

- Du unterstützt bei der Erstellung integrierter Finanzmodelle, Finanzanalysen und Unternehmensbewertungen

- Du arbeitest an der Erstellung von Branchen-, Unternehmens- und Wettbewerbsanalysen

- Du unterstützt bei Due-Diligence-Aktivitäten

## Qualifikation

- Du absolvierst aktuell ein Studium der Wirtschaftswissenschaften oder ein vergleichbares Studium mit Corporate Finance-Fokus bzw. hast dein Studium kürzlich mit überdurchschnittlichem Erfolg abgeschlossen

- Erste relevante Erfahrungen in der M&A-Beratung, im Corporate Finance oder Private Equity sind ein Plus

- Du verfügst über eine sehr gute Menschenkenntnis und überzeugst durch Beratungs- und Kommunikationskompetenz sowie sicheres Auftreten

- Du überzeugst durch ausgeprägte analytische, konzeptionelle und kommunikative Fähigkeiten sowie gelebten Teamgeist

- Belastbarkeit und Flexibilität, um mit straffen Zeitplänen und anspruchsvollen Kundenanforderungen umzugehen, sind für dich selbstverständlich

- Du besitzt sehr gute Kenntnisse in Excel und Powerpoint

- Verhandlungssichere Deutsch- und Englischkenntnisse in Wort und Schrift sind bei dir vorausgesetzt

## Benefits

- Eine spannende und abwechslungsreiche Tätigkeit mit umfangreichen Gestaltungsmöglichkeiten und hoher Eigenverantwortung

- Durch das breite Spektrum unserer Beratungstätigkeit im Bereich M&A bieten wir die Möglichkeit, Deals in sehr unterschiedlichen Phasen des Unternehmenslebenszyklus zu begleiten (u.a. Sondersituationen, Wachstum, Nachfolge)

- Aktive Einbindung in unsere M&A Live Deals mit hoher Verantwortung ab dem ersten Tag

- Aktive Personalentwicklung sowie eine gelebte Feedbackkultur mit einem 1:1-Mentoring

- Team Events und ein kollegiales Umfeld

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
