# Data Lead (BI & Analytics)

Posted: 2026-09-21T08:40:03Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

## **About Andercore**

Andercore is the AI-native supplier of industrial materials for energy, infrastructure, and construction in wholesale and beyond.

We trade with global suppliers and distribute to European customers on our own account. Our AI runs the full trade and distribution end-to-end: sourcing, quality, pricing, sales, logistics, and embedded financing. For the customer, it feels like buying from their preferred local supplier; for our partners, it is the most convenient and safe way to do business across borders. Behind it, our software and agentic AI do the heavy lifting that used to take an asset-intensive supply chain with four or five intermediaries and weeks of manual coordination.

Where we are today:

-

Strong triple-digit-million euro turnover

-

Seven European markets live

-

80+ people across Berlin (HQ), offices in London, Mumbai, and Shanghai

$40M Series B just closed, $75M raised to date from Atomico, Project A, and Inven Capital, institutional financing from international banks.

We are building the world's first and last industrial-grade AI operating system for materials, redefining how global trade works in one of the largest and most essential industries on earth.

# **Mission**

Today there is no dedicated owner for business intelligence and analytics. Departments build their own reports directly on Salesforce (CRM and ERP), leading to inconsistent metric definitions and duplicated work. Databricks is in place as the data platform and Metabase is licensed for visualization, but neither is systematically used. The tooling exists; the foundation and ownership do not.

This role builds and owns the data function end to end: a single, trusted data foundation on Databricks, one definition per metric, and reliable financial, controlling, and operational reporting on top of it. It is a player-coach role. The first hire builds hands-on, then grows a small team.

Within 12 months, every financial, controlling, and operational number at Andercore comes from one governed data foundation, and every department can self-serve its core reports without building on raw Salesforce data.

## **Core responsibilities**

-

Own the data platform: ingestion from Salesforce and other sources into Databricks, data modeling, quality, and documentation.

-

Build the metric layer: one definition per KPI (GMV, NRM, OTP, working capital metrics, and others), agreed with Finance and Operations, versioned and documented.

-

Deliver the three core report suites: financial reporting (CEO, CFO, board), controlling (FP&A), and operational reporting (supply, logistics, commercial).

-

Stand up Metabase as the single reporting front end and migrate departments off ad-hoc Salesforce reports.

-

Partner with Finance (FP&A), Operations, and Commercial as the go-to person for data questions; translate business questions into models and reports.

-

Prepare investor and board reporting data packs together with the CEO and CFO function.

-

Hire and manage one Data/BI Analyst once the foundation stands; define the longer-term team shape.

# **Must-have**

-

4-8 years in analytics engineering or data/BI roles, with clear hands-on depth: strong SQL, dbt (or equivalent transformation framework), and a lakehouse or warehouse platform, ideally Databricks.

-

Has built a metric or semantic layer before: can describe a project where they consolidated conflicting KPI definitions into one governed model.

-

Direct experience with the Salesforce data model as a source system, including its object model quirks and API/ETL constraints.

-

Understands the unit economics of a trading, distribution, or marketplace business: gross margin, net revenue margin, working capital, inventory or flow metrics. Physical goods, not pure SaaS.

-

Business-facing communication: comfortable in the room with a CFO or COO, able to push back on metric definitions and prioritize ruthlessly.

-

Player-coach mindset: wants to build hands-on for the first 6-12 months, then lead a small team.

## **Nice-to-have**

-

Metabase experience (or a comparable BI tool such as Looker or Tableau, with willingness to work in Metabase).

-

German language skills (working language is English; German helps with some internal stakeholders).

-

Prior experience in a venture-backed scale-up between Series A and C.

-

Exposure to finance systems integration (ERP, accounting data, bank/payment data) for controlling and cash reporting.

-

First leadership experience (1-3 reports).

We are an equal-opportunity employer and welcome applicants from all backgrounds, regardless of race, ethnicity, gender identity or expression, sexual orientation, religion, age, disability, or any other characteristic. We believe that diversity drives innovation, creativity, and collective strength.

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
