# Information Security (Senior) Manager (m/w/d)

Posted: 2026-09-21T09:00:19Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

It all starts with the mission: NVISO is here to protect European society from potentially devastating cyber attacks! This means we offer cyber security services to private and governmental organizations to help them better prepare for, prevent, detect and respond to cyber security incidents.

All of this is built on four fundamental values that define who we are: We are Proud, We Break Barriers, We Care and No BS!

## Tasks

You have a strong interest in cyber security and believe the following to be applicable to you?

As an **Information Security Manager (m/w/d), located in Germany,** at NVISO, you will lead our team of CISOaaS or GRC consultants while actively contributing to client projects as well as contributing in pre-sales activities for strategic clients. Your role will be key in enhancing our clients’ cybersecurity posture by creating and driving security strategies and their programs throughout the company. Key responsibilities include, but are not limited to:

- Leading and managing a team of CISOaaS/GRC consultants to deliver high-quality services to clients;

- Collaborating closely with clients to understand their business objectives, their risks and their unique security requirements;

- Assessing the security maturity of clients (using of ISO, BSI or NIST standards) to identify gaps and areas for improvement;

- Developing and implementing a fit-for-purpose security program (that aligns with industry standards);

- Driving the security program at clients, where you also act as the security champion, spreading the “gospel” on security;

- Conducting risk assessments, identifying potential vulnerabilities, and recommending risk mitigation strategies;

- Overseeing and supporting with the implementation of the security program, including policies, procedures, and controls;

- Providing updates to management on the ‘state of security’ at their company;

- Holding steering committees at the customer with relevant stakeholders to guide & adapt the security program, where needed.

- Involve yourself actively in the sales process by creating and presenting Statements of Work, project plans, requirements definitions,… for projects running in your team;

- Perform technical account management duties for specific top-tier, strategic clients.

## Requirements

- **You are eligible for NATO Clearance.**

- Bachelor’s degree in Business Administration, Information Security, or a related field;

- Professional certifications such as Certified Information Systems Auditor (CISA), Certified Information Systems Security Professional (CISSP), Certified Information Security Manager (CISM), ISO27001 Implementer/Auditor or equivalent are strongly preferred;

- Proven experience in being a CISO and/or having successfully implemented ISO27k or BSI Grundschutz at clients. This covers, but not limited to: risk assessment, security roadmap creation, CISOaaS and policy development;

- In-depth knowledge of relevant industry standards and frameworks, such as ISO 27001, DORA, NIST, NIS-2, GDPR, etc.;

- Familiarity with risk management methodologies and their application to cybersecurity;

- Quickly grasping the complexity and the business reasons for a company to perform security and adapting your communication style and the security program to make it fit for the client;

- Excellent English and German written and verbal communication skills to effectively convey complex concepts to technical and non-technical stakeholders;

- Leadership skills to manage a team and collaborate with clients and cross-functional teams.

## Benefits

At NVISO, we care. We are committed to offering you a highly competitive remuneration package including financial and non-financial components:

- A training budget of 10,000 EUR plus 10 days paid time off rolling over two years;

- Base salary range (depending on experience and skillset): 90.000 EUR p.a. - 130.000 EUR p.a.

- Working with and learning from the best people in the European cyber security “scene”. We have several SANS Instructors working for us and we are also represented at popular hacking conferences (BlackHat, BruCON, OWASP, etc.). In addition, our employees can take advantage of prestigious continuing education opportunities (GSE, GXPN, CISSP, OSCP, etc.);

- A forward-thinking and agile company that supports you in the creation and implementation of new initiatives;

- Unique team events (most recently e.g. Lisbon, Dubai, Malta, Lapland);

- A sophisticated coaching concept starting on day 1;

- 30 days of vacation;

- Flexible working hours and home office options (+ Working Abroad Option within the EU);

- Cost absorption for Deutschlandticket and the BahnCard50;

- Company bike leasing;

- Company pension scheme;

- A cool office in the heart of Frankfurt and Munich (Roof terrace, table tennis, Playstation, BBQ).

**Disclaimer on the Use of AI Tools in the Application Process**

Please be aware that the creation and submission of application documents (e.g. CV, cover letter, case studies, etc.) using AI-powered tools is only permitted to a **limited extent**.

*Our expectations:*

Application documents must authentically reflect your own qualifications, personality, and motivation.

The use of AI for supportive purposes (e.g. spell-checking, improving wording) is acceptable.

**Fully generated application documents created by AI without personal adaptation or review are not** **permitted.**

Under no circumstances may **NVISO information, data, or documents** be uploaded to or processed by external AI tools.

We reserve the right to exclude applications from the selection and interview process that are clearly created primarily or exclusively by AI and show no recognizable personal input.

The purpose of this policy is to ensure a fair and transparent recruitment process and to obtain an authentic impression of our applicants.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
