# Teamleitung/Trainer Montage & Wartung (m/w/d)

Posted: 2026-09-21T08:58:28Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Unser Auftraggeber ist im internationalen Markt der Maßstab für Saunatechnik der Premium- und Luxusklasse. Expertise bildet die Basis für seinen beständigen Erfolg – gemeinsam mit den Kunden – seit mehr als 80 Jahren.

Das Produktportfolio unseres Kunden umfasst zukunftsweisende und hochwertige elektrische Saunaöfen und Saunasteuergeräte für den Einsatz in privaten und gewerblichen Saunaanlagen sowie Infrarottechnik, Dampftechnik und ein breites Angebot an Zubehör.

Die Saunaöfen zeichnen sich durch ihr modernes Design und ihr großes Leistungsspektrum aus. Die Innovationskraft unseres Kunden gewährleistet die Erfüllung individueller Kundenwünsche auf höchstem Qualitätsniveau. 100 % made in Germany – wird ausschließlich in Deutschland entwickelt und produziert. Benutzerfreundlichkeit, Normenkonformität und höchste Produktsicherheit sind der Standard. Die exzellenten und langlebigen Produkte unseres Kunden sorgen in über 80 Ländern der Welt für Entspannung und Wohlbefinden.

Gestalten Sie mit unserem Kunden innovative Produkte, unterstützen bei Entwicklung und Schulung und tragen so zu nachhaltigen Wellness-Lösungen bei.

Die Teamleitung Montage & Wartung für gasbetriebene Saunaöfen übernimmt die fachgerechte Montage, Inbetriebnahme sowie Wartung der Anlagen beim Kunden vor Ort. Sie stellt dabei die zuverlässige Funktion und Sicherheit der gesamten Systemtechnik sicher – vom Gasbrenner bis zur Steuerung.

Sie sind neugierig und mutig? Sie suchen viel Gestaltungspotenzial und sind „fachlich breit aufgestellt“?

Dann passen Sie super zu uns!

Für den **Standort im Westerwald** suchen wir zum nächstmöglichen Zeitpunkt **Sie** als:

**Teamleitung/Trainer Montage & Wartung (m/w/d)**

## Aufgaben

**Ihre Kernaufgaben:**

- Montage und Inbetriebnahme von gasbetriebenen Saunaöfen inklusive Gasbrenner direkt beim Kunden vor Ort.

- Installation kompletter Abgassysteme einschließlich Kamin und Ventilator.

- Verkabelung sowie Parametrierung der Steuerungstechnik.

- Fachgerechte Inbetriebnahme, Einregulierung und Funktionsprüfung der Anlagen.

- Durchführung von Inspektionen, Wartungen und Serviceeinsätzen an Bestandsanlagen.

- Sorgfältige Dokumentation Ihrer Arbeiten – sowohl auf der Baustelle als auch im Rahmen der Projektnachbereitung.

- Sicherstellung einer hohen Kundenzufriedenheit durch professionelles Auftreten sowie Identifikation potenzieller Folgeaufträge.

- Schulung von ausländischen Partnern, auch in englischer Sprache

- Bei zeitl. Verfügbarkeit gerne auch Unterstützung der Neu-Produktentwicklung

- Betreuung der SHK-Auszubildenden in Vertretung

## Qualifikation

**Das bringen Sie mit:**

- Abgeschlossene Berufsausbildung als Schlosser/in, Elektroinstallateur/in, Gas- und Wasserinstallateur/in oder in einem vergleichbaren technischen Beruf.

- Alternativ: Technisch versierte Quereinsteiger mit hoher Reisebereitschaft im In- und Ausland.

- Idealerweise mehrjährige Erfahrung in der Montage oder im technischen Außendienst.

- Erfahrung im Hartlöten und ein Kälteschein wünschenswert – kann alternativ über unseren Auftraggeber erworben werden.

- Führungserfahrung sowie Erfahrung in der Betreuung und Anleitung von Auszubildenden sind von Vorteil.

- Selbstständige, zuverlässige und teamorientierte Arbeitsweise mit ausgeprägter Kundenorientierung.

- Führerschein der Klasse B.

- Grundkenntnisse in der Elektrotechnik sind von Vorteil.

- Reisebereitschaft im In- und Ausland.

- Sehr gute Deutschkenntnisse, Englischkenntnisse sind von Vorteil.

## Benefits

**Was Sie erwartet:**

- Eine interessante, abwechslungsreiche und zukunftsorientierte Tätigkeit in der Unternehmensgruppe des Marktführers Harvia.

- Einen sicheren Arbeitsplatz in Festanstellung in einer Wachstumsbranche.

- Ein wertschätzendes Betriebsklima und ein motiviertes Team mit starkem Zusammenhalt.

- Eine strukturierte Einarbeitung mit Einblick in verschiedene Abteilungen des Unternehmens.

- Attraktive Mitarbeiter-Benefits: Freuen Sie sich auf eine Vielzahl von Vorteilen wie z. B. Sachbezugskarte, 30 Tage Urlaub, Jobrad und Mitarbeiterevents.

Bei unserem Auftraggeber erwartet Sie ein motiviertes sowie sympathisches Team und vor allem ein interessantes und abwechslungsreiches Aufgabengebiet. Zusätzlich können Sie auf eine unbefristete und zukunftsorientierte Festanstellung in Vollzeit vertrauen.

Sind Sie der oder die Richtige?

Dann bewerben Sie sich jetzt unter Angabe Ihres Gehaltswunsches und frühestmöglichen Eintrittstermins.

**Wir freuen uns auf SIE!**

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
