# Software Engineer Java (m/w/d)

Posted: 2026-09-21T08:57:36Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Sie möchten Software nicht einfach nur entwickeln, sondern mitentscheiden, wie moderne Softwareentwicklung künftig funktioniert?

Dann erwartet Sie eine Position, in der Sie technologische Standards aktiv mitgestalten. Gemeinsam mit Entwicklungsteams, Architekten und Produktbereichen arbeiten Sie an der Weiterentwicklung moderner Software-Engineering-Praktiken von Java und Cloud-native Development über moderne Architekturansätze bis hin zu KI-gestützter und agentenbasierter Softwareentwicklung.

## Aufgaben

- Sie beschäftigen sich mit modernen Software-Engineering-Technologien, Tools und Praktiken – insbesondere im Bereich KI-gestützte Entwicklung, Automatisierung und Developer Productivity.

- Sie unterstützen Entwicklungsteams bei technischen Fragestellungen rund um Java, Softwarearchitektur, APIs, Qualität, Observability und Cloud-native Entwicklung.

- Sie wirken an der Weiterentwicklung moderner Architekturansätze wie Microservices, ereignisgesteuerter Architektur, DDD und API-First-Design mit.

- Sie helfen dabei, die Developer Experience (DevEx) durch optimierte Prozesse, moderne Tools und effiziente Arbeitsweisen kontinuierlich zu verbessern.

- Sie bringen sich aktiv in Workshops, technische Austauschrunden und Entwickler-Communities ein und teilen Ihr Wissen gerne mit anderen.

- Gemeinsam mit Architekten, Produktteams und Entwicklern entwickeln Sie wiederverwendbare Lösungen und treiben die technische Weiterentwicklung kontinuierlich voran.

- Sie wirken an strategischen technischen Initiativen mit und gestalten die Weiterentwicklung der KI-gestützten und agentenbasierten Softwareentwicklung mit.

## Qualifikation

- Abgeschlossenes Studium der Informatik, Wirtschaftsinformatik oder eine vergleichbare IT-Qualifikation.

- Erste Berufserfahrung in der Softwareentwicklung mit Java und Spring

- Kenntnisse in APIs, Datenbanken und modernen Softwarearchitekturen wie Microservices.

- Erste Erfahrungen mit Cloud, Containern, CI/CD oder Kubernetes von VorteilInteresse an KI, LLMs, Automatisierung und modernen Entwicklungsmethoden.

- Freude daran, technische Lösungen mitzugestalten, Wissen zu teilen und sich kontinuierlich weiterzuentwickelnGute Kommunikations- und Teamfähigkeit sowie gute Englischkenntnisse.

## Benefits

- **Technischer Impact**

Arbeiten Sie an geschäftskritischen Systemen, die weltweit eingesetzt werden, und gestalten Sie Engineering-Standards und technologische Entwicklungen aktiv mit.

- **Moderne Technologien**

Java, Spring, Kafka, Kubernetes, Cloud-native Development, moderne APIs, verteilte Systeme sowie KI-gestützte und agentenbasierte Entwicklung.

- **Gestaltungsspielraum**

Bringen Sie eigene Ideen ein, initiieren Sie Verbesserungen und gestalten Sie die technologische Zukunft aktiv mit.

- **Entwicklung & Austausch**

Profitieren Sie von strukturiertem Onboarding, vielfältigen Weiterbildungsmöglichkeiten und einem großen Netzwerk erfahrener IT-Spezialist:innen.

- **Flexibilität**

38,5-Stunden-Woche, flexible Arbeitszeiten, Gleitzeitkonto und mobiles Arbeiten.

- **Sicherheit & Perspektive**

Ein nachhaltig wachsendes, familiengeführtes Unternehmen mit langfristiger Perspektive in einer zukunftsrelevanten Branche.

- **Weitere Vorteile**

Gesundheitsangebote, Sport- und Fitnessprogramme, Corporate Benefits sowie die Möglichkeit eines Dienstfahrrads über Company Bike.

Bereit, Softwareentwicklung neu zu denken?

Lassen Sie uns gemeinsam herausfinden, ob diese Position zu Ihnen und Ihren nächsten beruflichen Zielen passt.

Wir freuen uns auf Ihre Bewerbung.

**Equal Opportunity**

WURAVENTA steht für Chancengleichheit. Wir freuen uns über alle qualifizierten Bewerbungen – unabhängig von Herkunft, Geschlecht, Identität, Alter, Behinderung oder anderen gesetzlich geschützten Merkmalen.

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
