# Quantitative Backend Developer (f/m/d) – Private Capital Analytics Platform

Posted: 2026-09-21T08:09:59Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**Your mission**

As a Quantitative Researcher & Methodology Specialist (f/m/d), you will develop innovative quantitative models for the private capital industry. You will identify new analytical approaches, validate their value, and actively shape the methodological evolution of our products. Your tasks:

**Quantitative Research & Model Development**

- Develop and enhance quantitative models for the valuation, forecasting, risk assessment, and benchmarking of private capital funds and investments
- Analyze complex financial, market, and portfolio data to create new analytical methodologies
- Research and evaluate innovative mathematical and statistical approaches
- Continuously improve existing model logic, assumptions, and calculation methodologies
- Translate research outcomes into prototypes, production-ready code, or implementation specifications
**Model Validation & Quality Assurance**

- Perform regular validation of quantitative models and methodologies
- Ensure the quality, transparency, and explainability of quantitative results
- Support the ongoing quality assurance of production model outputs
- Create audit-ready model and validation documentation
- Develop and maintain quantitative modeling standards and best practices
**Product Innovation & Methodology Strategy**

- Contribute to the development of the analytics product roadmap
- Identify new analytical products, methodologies, and service opportunities
- Evaluate academic, scientific, and technological developments for their relevance to our products
- Drive innovative approaches for future analytics solutions
- Support the prioritization of new methodological developments
**Stakeholder Management & Client Support**

- Act as a subject matter expert for Product Management, Information Systems, Operations, and other business teams
- Support the onboarding of new clients in relation to quantitative models and analytics products
- Communicate complex methodologies and results to technical and non-technical stakeholders
- Translate business challenges into quantitative research and modeling approaches
**Scientific Collaboration**

- Monitor relevant developments in research and academia
- Engage with universities, research institutions, and the broader scientific community
- Support scientific collaborations and academic thesis projects
- Translate research findings into internal and external communication materials

**Your profile**

**How You Work**

- You enjoy solving complex challenges through quantitative methods
- You combine scientific rigor with practical applicability
- You challenge existing approaches and continuously seek improvements
- You think analytically, structurally, and with a long-term perspective
- You communicate complex topics in a clear and understandable manner
- You enjoy interdisciplinary collaboration and independent ownership
- You are motivated by shaping the future of data-driven analytics solutions
**Your Qualifications**

- Degree, ideally including a Master's degree, PhD, or comparable research experience, in Mathematics, Statistics, Physics, Finance, Econometrics, Data Science, or a comparable quantitative discipline
- Strong experience in mathematical and statistical model development
- Experience implementing quantitative models in code
- Experience in model validation and methodology development
- Experience in prototyping, research, or innovation projects
- Exposure to financial markets, investments, or financial analytics
- Knowledge of private capital is an advantage
- Experience with Python and databases is an advantage
**Languages**

- Very good English skills (working language)
- German is a plus

**Our offer**

- Exciting challenges and excellent development opportunities in a constantly growing, international team
- Freedom to develop own ideas and thus make an active contribution to the success of our company
- Attractive remuneration with variable components as part of a total compensation system
- Great colleagues, a friendly working atmosphere and numerous employee events
- Modern workplace in the heart of Munich with view of the Theresienwiese
- Modern employee benefits - bike leasing, meal vouchers, BAV, Deutschlandticket, benefits account & Wellpass Fitness
- Hybrid working model
- Free drinks and fruit as well as a well-filled ice box in summer

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
