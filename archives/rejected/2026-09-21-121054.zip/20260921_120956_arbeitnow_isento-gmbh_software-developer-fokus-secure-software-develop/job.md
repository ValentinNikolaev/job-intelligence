# Software Developer - Fokus Secure Software Development (m/w/d)

Posted: 2026-09-21T08:58:29Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**Deine Rolle**

Sicherheit ist für uns bei isento ein fester Bestandteil exzellenter Software-Architektur: Wir entwickeln geschäftskritische Web- und Cloudanwendungen, die im Alltag zuverlässig funktionieren und von Grund auf geschützt sind.

Als Software Developer mit Fokus Secure Software Development entwickelst Du in unseren Projekten aktiv mit Java, Spring Boot, Python oder Angular. Gleichzeitig übernimmst Du eine tragende Rolle für den internen Wissensaufbau: Du beschäftigst Dich mit modernen Sicherheitsaspekten, teilst Best Practices mit Kolleginnen und Kollegen und wirkst an zukunftsweisenden Themen wie der sicheren Entwicklung und dem Schutz von KI-Systemen und LLMs mit.

Dich erwarten eingespielte isento-Teams, flache Hierarchien und der Freiraum, eigene Ideen einzubringen und das Thema Software-Sicherheit im gesamten Unternehmen aktiv mitzugestalten.

## Aufgaben

**Deine Aufgaben bei isento**

- Du konzipierst und entwickelst im Team moderne und sichere Softwarelösungen im Cloud- und Webumfeld auf Basis von Java, Spring Boot und Angular

- Verständlicher Code, automatisierte Tests, gegenseitige Code Reviews und Pair Programming gehören dabei genauso zu Deinem Alltag wie das gemeinsame Finden der besten technischen Lösung

- In Deinem Team bist Du Ansprechpartner für sichere Softwarelösungen und unterstützt auch andere Teams bei Fragen rund um Secure Coding und Sicherheitsanalysen

- Du bringst Dein Know-how aktiv bei isento ein: Du gestaltest interne Tech-Sessions, sensibilisierst für aktuelle Bedrohungen und etablierst Best Practices im AlltagDu beschäftigst Dich mit modernen Trends rund um Application Security, DevSecOps sowie dem sicheren und datenschutzkonformen Einsatz von KI-Systemen

## Qualifikation

**Das bringst Du mit**

- Mehrjährige Praxiserfahrung in der Softwareentwicklung mit Java sowie ein gutes Verständnis für moderne Web-Architekturen

- Echte Begeisterung für Secure Coding und DevSecOps

- Freude daran, Wissen im Team weiterzugeben, Kolleginnen und Kollegen für Sicherheitsthemen zu begeistern und gemeinsam voneinander zu lernen

- Hilfreich sind Kenntnisse in Spring Boot, Angular, Python, relationalen Datenbanken, Docker, Cloud-Technologien und Generativer KI

- Sichere Deutschkenntnisse (mindestens B2) sowie gutes Englisch für die erfolgreiche Abstimmung im Team und mit Kunden

## Benefits

**Deine Benefits bei isento**

- Flexible Arbeitszeiten, hybrides Arbeiten und Möglichkeiten zu Workation und Sabbaticals für eine gesunde Work-Life-Balance

- Eingespielte isento-Teams mit verlässlichem Rückhalt in allen Kundenprojekten: Unsere Projekte werden überwiegend von unseren eigenen Teams umgesetzt. Du arbeitest mit Deinen isento-Kolleginnen und -Kollegen zusammen und hast gleichzeitig direkten Kontakt zu unseren Kunden

- Volle Unterstützung für Deine persönliche Weiterbildung: Konferenzen und Zertifizierungen, die zu Dir passen (z. B. im Bereich DevSecOps oder Cloud-Architektur)

- Mitarbeiterangebote und Zuschüsse zum JobRad-Leasing, zum ÖPNV und zur betrieblichen Altersvorsorge

- Eine offene Unternehmenskultur mit regelmäßigen internen Open-Space-Events (Duke Days), Teamevents und Grillabenden auf unserer Dachterrasse in Nürnberg

- Ein ausgezeichneter Top-Arbeitgeber mit kurzen Entscheidungswegen und echtem Miteinander

Klingt gut? Dann werde Teil unseres Teams.

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
