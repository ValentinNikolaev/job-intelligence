# Kundenservice & Backoffice (m/w/d) - Photovoltaik

Posted: 2026-09-21T08:57:36Z

## Rejection

- Category: language_requirement
- Reason: hard German language requirement without English green light

Homeoffice | Festanstellung

Du interessierst dich für erneuerbare Energien und bringst bereits Erfahrung im Bereich Photovoltaik mit? Dann werde Teil unseres Teams bei hey contact heroes und unterstütze uns in einem spannenden Projekt rund um die Solarenergie!

Wir suchen engagierte Mitarbeitende, die unsere Kunden und Partner zuverlässig betreuen und administrative Prozesse im Hintergrund begleiten.

## Aufgaben

- Bearbeitung und Pflege von Kundenanfragen und Vorgängen im Backoffice

- Prüfung und Aktualisierung von Kunden- und Auftragsdaten

- Bearbeitung von Anliegen rund um Rechnungen, Angebote und Buchungen

- Unterstützung bei Fehlermeldungen, Kündigungen und Widerrufen

- Telefonische und schriftliche Kundenbetreuung

## Qualifikation

- Erste Berufserfahrung im Bereich Photovoltaik ist Voraussetzung

- Idealerweise Erfahrung im Kundenservice oder in der Sachbearbeitung

- Sicherer Umgang mit dem PC und digitalen Anwendungen

- Strukturierte, sorgfältige und eigenverantwortliche Arbeitsweise

- Sehr gute Deutschkenntnisse in Wort und Schrift

- Freude an der Kommunikation und ein ausgeprägtes Serviceverständnis

## Benefits

- Eine abwechslungsreiche Tätigkeit in einem zukunftsorientierten Projekt

- Arbeiten bequem aus dem Homeoffice

- Eine strukturierte Einarbeitung und Schulung

- Ein unterstützendes Team und feste Ansprechpartner

- Geregelte Servicezeiten von Montag bis Freitag zwischen 08:00 und 18:00 Uhr

Dann freuen wir uns darauf, dich kennenzulernen!

Bewirb dich jetzt bei hey contact heroes und werde Teil unseres Teams. Wir freuen uns auf deine Bewerbung! 💜

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
