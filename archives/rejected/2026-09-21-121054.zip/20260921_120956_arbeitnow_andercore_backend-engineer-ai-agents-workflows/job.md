# Backend Engineer (AI Agents/Workflows)

Posted: 2026-09-21T08:40:03Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

## **About Andercore**

Andercore is the AI-native supplier of industrial materials for energy, infrastructure, and construction in wholesale and beyond.

We trade with global suppliers and distribute to European customers on our own account. Our AI runs the full trade and distribution end-to-end: sourcing, quality, pricing, sales, logistics, and embedded financing. For the customer, it feels like buying from their preferred local supplier; for our partners, it is the most convenient and safe way to do business across borders. Behind it, our software and agentic AI do the heavy lifting that used to take an asset-intensive supply chain with four or five intermediaries and weeks of manual coordination.

Where we are today:

-

Strong triple-digit-million euro turnover

-

Seven European markets live

-

80+ people across Berlin (HQ), offices in London, Mumbai, and Shanghai

$40M Series B just closed, $75M raised to date from Atomico, Project A, and Inven Capital, institutional financing from international banks.

We are building the world's first and last industrial-grade AI operating system for materials, redefining how global trade works in one of the largest and most essential industries on earth.

The Tech team will allow you to work alongside a group of highly ambitious and knowledgeable Engineers, while being faced with complex problems and being exposed to commercial.

**The Tech Stack**: Python, LangGraph, LLM APIs (OpenAI, Anthropic, Gemini), AWS, GitHub Actions, [Node.js](http://node.js), Java 21 (Spring Boot 3), Postgres, Kinesis, Terraform, Typescript, NextJS, React.

#
**What you will do**

-

Design, develop, test, deploy, and maintain backend services that integrate AI/ML capabilities into our products.

-

Build clean, maintainable, and reusable code with a focus on scalability and performance.

-

Develop and optimize APIs that power AI-driven features.

-

Collaborate with frontend engineers to connect user-facing experiences with AI-enabled backend logic.

-

Implement and improve distributed systems and data pipelines.

-

Work with LLM APIs (OpenAI, etc.) to build intelligent workflows and automation.

-

Participate in code reviews, knowledge-sharing sessions, and architecture discussions.

-

Stay current with emerging AI technologies and backend best practices.

#
**Who you are**

-

**Experience Level:** 3–5 years as a backend or full-stack engineer, with exposure to AI/ML integrations.

-

Solid programming skills in Java (Spring Boot) and familiarity with Python for data processing or AI integration.

-

Experience with relational databases (PostgreSQL or BigQuery) and writing efficient queries.

-

Comfortable working with cloud infrastructure (AWS preferred) and CI/CD tooling.

-

Understanding of distributed systems, event-driven architecture, and microservices.

-

Interest or experience in building AI-enabled products (e.g., working with OpenAI API, fine-tuning models, or prompt engineering).

-

Strong communicator who can explain technical ideas to both technical and non-technical stakeholders.

-

Proactive, collaborative, and eager to contribute ideas and improvements.

We are an equal-opportunity employer and welcome applicants from all backgrounds, regardless of race, ethnicity, gender identity or expression, sexual orientation, religion, age, disability, or any other characteristic. We believe that diversity drives innovation, creativity, and collective strength.

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
