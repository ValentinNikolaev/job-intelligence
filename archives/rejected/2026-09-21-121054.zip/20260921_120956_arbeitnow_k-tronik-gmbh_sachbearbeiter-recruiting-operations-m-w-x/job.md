# Sachbearbeiter Recruiting Operations (m/w/x)

Posted: 2026-09-21T08:57:36Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

## Projektbeschreibung:

Technologie begeistert Sie? Uns auch! Zur Verstärkung unseres Expertenteams bei unserem Kunden aus der Messtechnik suchen wir einen Sachbearbeiter Recruiting Operations (m/w/x) in Festanstellung bei K-tronik. Wir freuen uns darauf, Sie persönlich kennenzulernen – und gemeinsam mit Leidenschaft und Teamgeist an spannenden Projekten und zukunftsweisenden Technologien zu arbeiten.

## Aufgaben:

- Du koordinierst und optimierst unsere Recruiting-Prozesse und sorgst für einen reibungslosen Ablauf

- Du betreust und pflegst unser Applicant Tracking System (ATS) und stellst eine hohe Datenqualität sicher

- Du koordinierst Interviews, Feedbackprozesse und weitere Schritte im Recruiting-Prozess

- Du unterstützt Recruiter und Hiring Manager bei organisatorischen und operativen Themen

- Du erstellst Reports und wertest Recruiting-Kennzahlen aus, um Prozesse datenbasiert weiterzuentwickeln

- Du identifizierst Verbesserungspotenziale und setzt gemeinsam mit dem Team neue Prozesse und Tools um

- Du unterstützt bei Projekten rund um Recruiting, Employer Branding und HR Operations

- Du sorgst dafür, dass unsere Candidate Experience über den gesamten Recruiting-Prozess hinweg professionell und positiv bleibt

## Qualifikationen:

- Erfolgreiche angeschlossene kaufmännische Ausbildung

- Berufserfahrung im Bereich HR und Recruiting (Weiterbildung, Studium) wünschenswert

- Dein Durchsetzungsvermögen, deine strukturierte und lösungsorientierte Arbeitsweise und deine Erfahrung im Stakeholdermanagement, auch in angespannten Situationen, zeichnen dich aus

- Verhandlungssichere Deutsch- und Englischkenntnisse in Wort und Schrift runden dein Profil ab

- Sicherer Umgang mit MS-Office und gängigen IT-Tools

- Organisationstalent und freundliches, aufgeschlossenes Auftreten

## Benefits:

- Kollegiales und freundschaftliches Arbeitsklima

- Flexible Arbeitszeiten

- 30 Urlaubstage und flexible Urlaubsplanung

- Regelmäßige Team-Events

- Auszeichnung als Kununu TOP Company

- Corporate Benefits (Mitarbeiterangebote)

- Kostenlose Getränke

- Individuelle Weiterbildungsmöglichkeiten

- 360° Betreuung: Feedbackgespräche, Karriereplanung, Unterstützung bei Umzug, etc.

- Berufseinstieg

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
