# (Senior) Product Manager Energy (m/f/d)

Posted: 2026-09-21T08:58:28Z

## Rejection

- Category: tech_stack
- Reason: role does not mention Go/Golang or PHP

## 1KOMMA5°

At **1KOMMA5°**, we pursue a clear vision: **Living on wind and sunlight forever for free**. To make this a reality, we are building the energy system of the future with Heartbeat AI. Want to be part of it?

We bring together regional craftsmanship and scalable software: We don't think of solar, batteries, heat pumps, and e-mobility as isolated components, but control them as an intelligent, integrated overall system in our virtual power plant. Directly connected to the electricity market – in real time, fully automated. This way, energy is used when it is available from renewables and particularly cost-effective. By 2030, our goal is to transition 1.5 million households to renewable energies. Over 3,000 people are working towards this every day, at more than 80 locations worldwide, from Finland to Australia.

**Want to take responsibility and build solutions that truly matter? Apply now and help us shape the energy world of tomorrow.**

Learn about our Product & Tech team!

## Deine Position

As Senior Product Manager for Energy at Heartbeat AI, you own the software that lets households participate in energy markets. Dynamic energy products, market access, flexibility - and the software roadmap that makes those products real.

You sit with the engineering teams. You decide what gets built, in which order, and where Energy software goes next. Germany is our home market. We already run energy products in other European markets, and this role includes taking that further. How we buy and sell energy well. How flexibility becomes a product households can use. You work with engineering, operations, and the Product Managers already in the domain. You set the direction, stay close to what ships, and help other PMs land against the same vision.

## Your main focus will be to:

- Own the software roadmap for Energy: what engineering builds, and how products evolve

- Work day to day with the development teams

- Set the domain direction and work closely with other Product Managers: aligned roadmaps, guidance, unblocking, a higher quality bar

- Partner with operations so products are valuable and operable

- Write specs, run discovery, prioritize, and ship

- Shape the next energy products: direct marketing, flexibility, and what they need to work

- Translate energy-market and regulatory reality into product requirements — in Germany and in the markets we grow into

- Define product-health metrics: procurement quality, market participation, activation, SLAs

- Align how prices, products, and activation show up for customers

## Dein Profil

You have:

- 7+ years of Product Management, with real exposure to energy, utilities, or similarly regulated platforms

- A track record of owning a product domain across more than one team, and of deciding where it goes next

- Experience guiding other Product Managers in a domain. Line management is a plus, not a requirement.

- Solid understanding of energy markets, tariffs, energy retail, or energy trading

- Experience owning a software roadmap with engineering teams, in a regulated environment

- Comfort with unit economics and product metrics

- Excellent English. German is a plus. Based in Germany or willing to relocate.

## Bonus points for:

- Flexibility, balancing markets, VPP, scheduling, TSO/DSO

- Energy regulation in Germany and other European markets

- Optimization and dispatch systems, and how they meet market products

- Line management of Product Managers

## Benefits

- You are part of an international, dynamic, and highly motivated team of people who have proven to make things happen

- With your work, you accelerate the "energy transition" and hence have a direct impact on our climate

- Work with and learn from other super-smart colleagues

- You will enjoy direct contact with core decision-makers

- You will enjoy the best chances of entering full-time in one of Europe’s most thriving scaleups

- You work remotely (Germany-wide), with offices in Hamburg, Berlin or Munich

- Create a healthy balance alongside your work and enjoy all the benefits of the EGYM Wellpass

- Benefits and discounts are yours with Futurebens

- Whether city bike or e-bike - be flexible with our job bike leasing and do something good for the environment at the same time

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
