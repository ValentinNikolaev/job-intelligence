# Finance Assistant/Accountant (m/w/d)

Posted: 2026-09-21T08:57:36Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**Willkommen bei Frasers Hospitality!**

**International mit familiärem Charakter**

Design, freche Farbakzente, Intuitive Technologie.

Ein modern und zugleich luxuriös ausgestattetes 4* Superior Hotel in bester Lage, ideal für Geschäfts- und Individualreisende, bei dem alles nach dem Motto „Work and play to a different beat“ läuft.

Das Capri by Fraser Berlin verfügt über 143 Zimmer/Apartments, 2 Meeting Rooms, ein Restaurant, eine Bar und natürlich ein Fitness Studio, dass niemals schließt!

**Zur Verstärkung unseres Teams suchen wir eine/n Finance Assistant (m/w/d)**

## Aufgaben

Als Teil einer internationalen Hotelgruppe, überschaust Du alle Finanz-Abläufe in unserem Hotel in Berlin vor Ort und agierst darüber hinaus als Schnittstelle zum Controlling und weiteren Finance-Teams in Deutschland und unserem Headoffice in London.

**Dazu gehört im Detail:**

- Verarbeitung und Buchung von Ein- und Ausgangsrechnungen

- Durchführung und Abstimmung von Zahlungsläufen sowie Kontrolle laufender Buchungen im SAP

- Pflege von Debitoren- und Kreditorenkonten (AR/AP), inkl. Mahnwesen

- Bearbeitung von Kreditkarten- und Online-Zahlungen und Buchung der Kommissionsjournale

- Verwaltung von Bestellprozessen in Zusammenarbeit mit den operativen Abteilungen

- Unterstützung bei Monats- und Jahresabschlüssen in Zusammenarbeit mit dem zentralen Finanzteam

- Erstellung von Reportings für die Hotelleitung und unser Headoffice in London

- Enge Zusammenarbeit mit dem zentralen Accounting- und Controlling-Team der Unternehmensgruppe

- Unterstützung bei CAPEX-Abrechnungen (inkl. Prüfung der Lieferung und Weiterleitung)

- Organisation, Archivierung von Finanzdokumenten sowie Kommunikation mit Lieferanten und internen Abteilungen

## Qualifikation

- Du hast eine abgeschlossene (Kaufmännische) Ausbildung und fundierte Kenntnisse über Finanzabläufe, idealerweise im Hotel

- Erfahrungen in der Buchhaltung und Rechnungswesen (Bestellprozesse, Kostenstellen, Zahlungsprozesse, vorbereitende Monats- und Jahresabschlüsse)

- Gute Deutsch- und Englischkenntnisse in Wort und Schrift

- Erfahrungen im Umgang mit Systemen( z.B. SAP oder Online-Banking)

- Zuverlässigkeit und Genauigkeit bei der Bearbeitung von Finanzdaten

- Strukturierte und selbstständige Arbeitsweise

- Spaß an der Zusammenarbeit im Team und mit Menschen aus unterschiedlichsten Kulturkreisen

## Benefits

- Eine ausführliche und effektive Einarbeitung durch erfahrene Kollegen

- Faires Gehalt sowie Anerkennung und Wertschätzung Deiner Leistungen

- Teilnahme am Frasers-Bonussystem nach KPI

- Deutschlandticket zahlen wir komplett! Für mehr Mobilität auch in der Freizeit

- Angebot zur betrieblichen Altersvorsorge

- Angebot zur betrieblichen Krankenzusatzversicherung nach 2 Jahren Betriebszugehörigkeit

- Digitale und flexible Dienstplanung

- Günstige Mitarbeiterraten in 100 Fraser-Hotels auf 4 Kontinenten

- Flache Hierarchien & ein offenes Miteinander

- Vielfältige Weiterbildungsmöglichkeiten für Deine persönliche und fachliche Entwicklung

- Teamevents - und wenn es manchmal nur eine Kuchenrunde oder ein Feierabendgetränk ist

- Gespräche zu Ihrer Orientierung, Unterstützung und Zukunftsplanung

- Einen modern ausgestatteten Arbeitsplatz in zentraler Lage

- Stark reduzierte Preise und Angebote, ob Online-Shopping, Konzerttickets oder Freizeitangebote in ganz Deutschland

**... und noch viele weitere Vorteile & Vergünstigungen**

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
