# Senior Specialist HR Administration (m/w/d)

Posted: 2026-09-21T08:30:39Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Seit über 75 Jahren entwickeln und produzieren wir bei HUMMEL innovative Lösungen in der Verbindungstechnik – von hochwertigen Komponenten für die Elektrotechnik bis hin zu modernem Zubehör für Heizungs- und Trinkwassersysteme. Als unabhängiges, mittelständisches Familienunternehmen mit Hauptsitz in Denzlingen stehen wir für Qualität, Präzision und Verlässlichkeit.

Heute sind wir international vernetzt mit 9 Niederlassungen und einem starken globalen Partnernetzwerk. Rund 600 engagierte Mitarbeitende bringen bei uns täglich ihr Know-how und ihre Ideen ein – in einem modernen Arbeitsumfeld mit kurzen Wegen, flachen Hierarchien und viel Gestaltungsspielraum. Werde auch du Teil des erfolgreichen HUMMEL-Teams und bewirb dich jetzt für unseren Standort in Denzlingen.

## Aufgaben

Bei uns geht es nicht nur um Technik – sondern darum, Lösungen zu schaffen, die unsere Kunden wirklich weiterbringen. In deiner Rolle als **Senior Specialist HR Administration (m/w/d)** arbeitest du eigenverantwortlich und eng mit deinem Team zusammen. Konkret bedeutet das:

- Du bist fachliche Ansprechperson für das HR-Administration-Team und unterstützt bei dessen Weiterentwicklung

- Du verantwortest die monatliche Lohn- und Gehaltsabrechnung inklusive Prüfung und Bearbeitung relevanter Sonderfälle

- Du berätst Mitarbeitende und Führungskräfte in HR-administrativen sowie arbeits- und sozialversicherungsrechtlichen Fragestellungen

- Du verantwortest die Personalstammdaten, Arbeitszeit- und Urlaubskonten sowie die elektronische Zeiterfassung

- Du bist Ansprechperson für Behörden, Sozialversicherungsträger und den Betriebsrat.

- Du erstellst HR-Reportings, Auswertungen und Kennzahlen und stellst eine hohe Datenqualität sicher

- Du betreust und optimierst HR-Systeme und administrative Prozesse

- Du wirkst bei HR-Projekten mit und unterstützt die Weiterentwicklung unserer Personalarbeit

Und das Beste: Deine Ideen sind nicht nur willkommen - sie sind gewünscht.

## Qualifikation

Du hast eine abgeschlossene kaufmännische Ausbildung und fundierte Berufserfahrung in der HR-Administration.

**Erforderliche Fachkenntnisse:**

- Du verfügst über fundierte Kenntnisse im Arbeits- und Sozialversicherungsrecht sowie in der Entgeltabrechnung

- Du hast Erfahrung mit Abrechnungssoftware, idealerweise DATEV/Lodas

- Du bringst erste Führungserfahrung oder Erfahrung in der fachlichen Anleitung von Mitarbeitenden mit

- Du verfügst über gute MS-Office-Kenntnisse und sehr gute Deutschkenntnisse (C2)

**Wünschenswerte Erfahrung:**

- Analytische Fähigkeiten

- Bereichsübergreifendes, prozessorientiertes Denken

- Industrieerfahrung

**Persönlich überzeugst du uns durch**

- Kommunikations- und Moderationsfähigkeit in unterschiedlichen Hierarchieebenen

- Strukturierte und gewissenhafte Arbeitsweise

- Service- und lösungsorientiertes Denken

- Selbständige Arbeitsweise

- Fehlerbewusstsein & KPI Gedanke

## Benefits

Wir wissen: Gute Arbeit braucht gute Bedingungen. Deshalb bieten wir dir:

- Sicherer und moderner Arbeitsplatz

- Flache Hierarchien, offene Kommunikation und eine gelebte Du-Kultur

- Betriebliche Altersvorsorge mit Arbeitgeberzuschuss

- Vermögenswirksame Leistung

- JobRad-Leasing & Hansefit-Mitgliedschaft

- Firmen-Events wie Sommerfest und Weihnachtsfeier

- Arbeitskleidung, Parkplätze & kleine Aufmerksamkeiten zwischendurch

Lust auf ein Unternehmen, das Werte mit Fortschritt verbindet? Dann freuen wir uns auf deine Bewerbung.

Dann werde Teil unseres HUMMEL-Teams am Standort . Wir freuen uns auf deine Bewerbung über unser Karriereportal unter Angabe deines Gehaltswunsches und deines frühestmöglichen Eintrittstermins. Du hast Fragen zur Stelle? Dann melde dich gern direkt bei unserer HR-Abteilung Tel. 07666/91110-811

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
