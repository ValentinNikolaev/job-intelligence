# Software Engineer, Backend (L. 68/99)

Posted: 2026-07-10T09:17:20.677+00:00

## Rejection

- Category: stale
- Reason: published_at 2026-07-10T09:17:20.677+00:00 is older than 7 days

📢 Championing Diversity: People with disabilities encouraged to apply (L.68/99) 🚀



We Welcome Everyone!

This role is part of our commitment to fostering an inclusive workplace: this is why Satispay mainly dedicates this job opportunity to candidates eligible under specific employment protection laws, including those with disabilities or other protected status, in line with Italian law (L.68/99). We encourage candidates from all backgrounds to apply.

Still willing to apply for the role? This specific application form is dedicated mainly to candidates with disabilities. However, we value diversity and talent in all its forms, and everyone is welcome to apply for a job at Satispay! If you’re interested in the role, but you’re not a candidate with disabilities, visit the following link and apply here https://www.satispay.com/en-it/work-at-satispay/open-positions/f97f126b-a3db-41ce-bf91-63f8f4400cda/



About us

Traditional banking has never really given you control over your financial life. Satispay exists to change that: to empower people through finance. 

That means making financial services easy and accessible for over 6.5M users. We started with payments, then benefits, investing, cards... and we’re not done. Not even close. 

We follow the same logic every time: find a real problem, solve it properly, then look for the next one. The destination? To build the most loved financial platform in the world. 

If you own outcomes rather than tasks, stay close to what users need, and refuse to wait for someone else to fix what's broken — you'll find people here who work exactly in the same way. And together, you'll build something worth being proud of.



What you'll be doing

As our Software Engineer, Backend, you'll play a key role in shaping the future of digital payments by designing and building scalable, high-quality systems, delivering features, gaining deep system context, and growing your technical expertise. 

Here's what that looks like in practice:

 - Own the Story Lifecycle - Complete the entire story lifecycle from intake to production release, standing up product stories and ensuring all requirements are met.

 - Contribute to Technical Excellence - Conduct technical analysis for standard scope stories and implement robust, scalable back-end solutions.

 - Ensure Quality and Stability - Accurately estimate effort and resolve blockers promptly, participating in incident resolution, root cause analysis, and prevention to ensure technical transparency.

 - Document and Communicate - Create comprehensive technical documentation for the features you build and collaborate effectively with stakeholders.



Who we’re looking for

This role needs someone who is a problem solver, eager to learn, owns their work, and is ready to collaborate and take real ownership.

 - Experience & Technical Foundations - At least 3 years of industry experience working with Java and a foundational understanding of cloud platforms (AWS is a plus).

 - Structured Communication - Ability to communicate in a structured and convincing manner, adapting your style to build trust positively and professionally with various stakeholders, including coordinating implementation with other teams.

 - User Focus - Inherent desire to understand and address user needs, ensuring the back-end system supports a great user experience.

 - Passion and Language Skills - Passionate about FinTech or startup environments and fluent in English.

Don't worry if you don't tick every box. We believe in the power of different viewpoints and strengths. Your unique perspective is important as we build something special: if you're passionate and can make a difference, we truly encourage you to apply.



CareAbout: how we support your impact

We move fast, and evolution never stops. It’s a fun ride, but it can be challenging. To make sure our people truly thrive, we’re committed to making their lives easier, both in the office and out in the world. That’s why we created CareAbout:

 - ❤️ Health: private insurance for you and your family, psychological support with Serenis, mental health workshops.

 - 💰 Financial resources: Stock Option Plan, meal vouchers, relocation support if you’re moving countries.

 - ⚙️ Growth and development: professional development programs, internal mobility, language courses with Preply.

 - 🌱 Flexibility: unlimited PTO, hybrid working policy*, flexible working hours.

 - 👨‍👩‍👧 Family: enhanced parental leave, additional leave for child sickness.

*We embrace three days per week in-office (Tuesday and Thursday + 1 of your choice), with the option to request extra remote time.



Salary: starting from €38,000 gross per annum

This range is set using objective, gender-neutral criteria for the role's core requirements. However, we do not believe in putting a ceiling on talent. The final compensation package is tailored according to your unique experience and expertise. If your skills go beyond the standard profile, apply anyway so we can discuss a package that reflects your true value.



Equal opportunity employer
At Satispay, we're proud to be an equal opportunity employer. We celebrate diversity and inclusion, welcoming individuals of all backgrounds. This opportunity is open to everyone, regardless - for instance - of race, colour, religion, sex, gender identity, sexual orientation, and national origin. Join us in a workplace where everyone belongs!



Learn more about us
Curious what it's actually like here? Our values and pillars shape how we work every day: explore them here https://www.satispay.com/en-it/work-at-satispay/.




#LI-HYBRID
#LI-VR1







By submitting this application, I acknowledge that I have read and understood the content of the Privacy Policy https://www.satispay.com/en-it/legal-hub/privacy-policy/candidates/
