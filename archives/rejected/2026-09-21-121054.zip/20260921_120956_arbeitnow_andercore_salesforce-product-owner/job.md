# Salesforce Product Owner

Posted: 2026-09-21T08:40:03Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

## **About Andercore**

Andercore is the AI-native supplier of industrial materials for energy, infrastructure, and construction in wholesale and beyond.

We trade with global suppliers and distribute to European customers on our own account. Our AI runs the full trade and distribution end-to-end: sourcing, quality, pricing, sales, logistics, and embedded financing. For the customer, it feels like buying from their preferred local supplier; for our partners, it is the most convenient and safe way to do business across borders. Behind it, our software and agentic AI do the heavy lifting that used to take an asset-intensive supply chain with four or five intermediaries and weeks of manual coordination.

Where we are today:

-

Strong triple-digit-million euro turnover

-

Seven European markets live

-

80+ people across Berlin (HQ), offices in London, Mumbai, and Shanghai

$40M Series B just closed, $75M raised to date from Atomico, Project A, and Inven Capital, institutional financing from international banks.

We are building the world's first and last industrial-grade AI operating system for materials, redefining how global trade works in one of the largest and most essential industries on earth.

## What you will own

• **Roadmap and backlog: **own the SF backlog end to end. Run intake across Sales, Operations, Finance, and Customer Success and translate business needs into clear requirements with acceptance criteria and priority.

• **Automation delivery: **design, build, and test declarative automation (Flow, validation rules, approval processes, assignment logic) but also manage the AI layer accross the org.

• **Developer partnership: **scope Apex-heavy and integration work with our Salesforce developers, review their output for fit and maintainability, and decide what belongs in configuration versus code.

• **Administration and operations: **own day-to-day administration: users and licenses, the security and sharing model, profiles and permission sets, sandbox and release management, and business-as-usual support. This is the Administrator function.

• **Data quality and governance: **protect the integrity of the data model, prevent one-off requests from fragmenting it, and own deduplication, validation, and reporting hygiene.

• **Stakeholder management: **be the single point of contact for everything Salesforce. Set expectations, communicate tradeoffs, and report progress against the automation targets.

## What you bring

• 5+ years on the Salesforce platform, with real ownership of an org's roadmap or backlog

• Expert in declarative automation: Flow, validation rules, approval processes, and the security model

• Hands-on with day-to-day administration: users and licenses, profiles and permission sets, sandboxes, and release management

• Able to read and scope Apex, comfortable reviewing developer work and drawing the configuration-versus-code line

• A proven record of translating business needs into shipped solutions across multiple departments

• Salesforce Administrator certification; Advanced Administrator or Platform App Builder strongly preferred

• Fluent English, and comfort being the single owner of a business-critical system

We are an equal-opportunity employer and welcome applicants from all backgrounds, regardless of race, ethnicity, gender identity or expression, sexual orientation, religion, age, disability, or any other characteristic. We believe that diversity drives innovation, creativity, and collective strength.

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
