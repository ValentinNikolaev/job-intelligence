# Senior Data Scientist (m/w/d)

Posted: 2026-09-21T08:30:28Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

### Aufgaben

-

Als Senior Data Scientist (m/w/d) **leitest du die Entwicklung und Implementierung fortschrittlicher Datenmodelle und -algorithmen **für unsere kundenspezifischen Lösungen. Dabei identifizierst und analysierst du Probleme in einem analytischen Rahmen

-

Du arbeitest an **hochrelevanten Projekten und großen Datensätzen**. Du arbeitest eng mit hochrangigen Stakeholdern zusammen, um den **Projektumfang und -ziele zu definieren**

-

Du **konzipierst**, entwickelst und führst die Architektur und das Management komplexer Datenpipelines und Dashboards

-

Mitarbeit an einer Vielzahl von **datenbezogenen Komponenten** wie Datenplattformen, Dashboards und Produkten rund um Data und Machine Learning

-

Experte über **verschiedene Technologie-Stacks** hinweg (z. B. Azure, AWS, GCP, DBX, ELK, Spark, Databricks usw.)

-

Du triffst **strategische Entscheidungen** bezüglich Technologiestacks und Methodiken

-

Mentor für Junior- und Mid-Level Data Scientists

-

Du treibst **Innovation und technische Entwicklung** voran und verbesserst Datenwissenschaftsprozesse und -methoden im gesamten Team

### Benefits

-

Regelmäßige und systematische (externe und interne) **Weiterbildungsmöglichkeiten** in den Bereichen Data Engineering, Cloud-Architektur und Data Science

-

Zugang zu **branchenübergreifenden Projekten** (große und mittelständische Unternehmen aus den Bereichen Banken, Versicherungen, Automotive, Einzelhandel usw.)

-

Branchenführenden Kooperationen in den Bereichen Cloud, BI und AutoML

-

Arbeit in einer **offenen, flachen Umgebung**, innerhalb eines breiten Reply-Netzwerks zum Wissensaustausch

-

Preisgekrönte Büroräume in der Münchner Innenstadt mit Zugang zur Stammstrecke

-

Fahrkarte für öffentliche Verkehrsmittel mit Deutschlandticket

-

Zuschuss zu einer Fitnessstudio-Mitgliedschaft in einem Fitnessstudio der Wahl oder die Nutzung von Wellpass

-

**Flexible Arbeitsumgebung **zwischen Kunden, Reply-Büro und Remote-Arbeit

### Über Machine Learning Reply

Machine Learning Reply bietet maßgeschneiderte End-to-End-Lösungen im Data-Science-Bereich an, die den gesamten Projektlebenszyklus abdecken – von der initialen Strategieberatung über die Datenarchitektur und Infrastrukturthemen bis hin zur Datenverarbeitung und Qualitätssicherung unter Verwendung von Machine-Learning-Algorithmen. Machine Learning Reply verfügt über umfassende Expertise im Bereich der Datenwissenschaft in allen Schlüsselindustrien der deutschen HDAX-Unternehmen. Machine Learning Reply befähigt seine Kunden, neue datenbasierte Geschäftsmodelle erfolgreich einzuführen sowie bereits bestehende Prozesse und Produkte zu optimieren – mit einem Schwerpunkt auf Open-Source- und Cloud-Technologien. Mit dem Machine Learning Incubator bietet das Unternehmen ein Programm zur Ausbildung der nächsten Generation von Entscheidungsträgern, Data Scientists und Entwicklern an.

-

Wir freuen uns auf deinen **Studienabschluss mit einem quantitativen oder wirtschaftlichen Hintergrund**, zum Beispiel in Informatik, Wirtschaftsinformatik, Wirtschaftsmathematik oder Betriebswirtschaftslehre

-

Du besitzt ein **tiefes Verständnis fortgeschrittener maschineller Lerntechniken** und deren **Anwendungen in der Produktion** wie **NLP, Recommender-Systeme, Timer Series Analysis und Computer Vision**

-

Mit deiner **umfassenden Erfahrung in Datenwissenschaft** & **Datenmanagement** oder der Entwicklung von Produktionssystemen verfügst du über gute Kenntnisse in **Python, R, Rust, Pyspark oder SQL**

-

Fundierte Erfahrungen mit **Cloud-Plattformen** wie AWS, Google Cloud oder Microsoft Azure

-

Starke **Datenvisualisierungs- und Storytelling**-Fähigkeiten

-

Du kennst dich mit **Datagovernance** und **Compliance **aus

-

Auf **Deutsch und Englisch** kommunizierst du **gut und gerne**

-

Du besitzt hervorragende **Führungskompetenzen **und kannst technische Konzepte klar und überzeugend präsentieren, bringst strategisches Denken und **Problemlösungsfähigkeiten **mit und kannst mehrere **Prioritäten **gleichzeitig managen

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
