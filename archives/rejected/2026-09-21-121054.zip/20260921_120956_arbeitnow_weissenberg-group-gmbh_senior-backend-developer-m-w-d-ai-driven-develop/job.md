# Senior Backend Developer (m/w/d) – AI-Driven Development

Posted: 2026-09-21T08:57:36Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

## Aufgabengebiet

Du willst nicht nur Tickets abarbeiten, sondern die technische Richtung einer Lösung mitprägen? Bei uns verbindest Du langjährige Backend-Erfahrung mit modernen AI Coding Tools. Du entwickelst skalierbare Systeme, triffst belastbare Entscheidungen zur Softwarearchitektur und nutzt Codex, Claude Code, GitHub Copilot oder vergleichbare Coding Agents als produktive Werkzeuge im Entwicklungsalltag.

## Deine Aufgaben:

- Du gestaltest anspruchsvolle Backend-Lösungen von der technischen Idee bis zum produktiven Betrieb. Dabei übernimmst Du Ownership für Softwarearchitektur, APIs, Datenmodelle und Integrationen und hast echten Einfluss auf Technologieentscheidungen und Entwicklungsstandards.

- Du setzt AI Coding Tools und Coding Agents produktiv für Implementierung, Refactoring, Tests und Fehleranalyse ein. Gleichzeitig bringst Du die Seniorität mit, AI-generierten Code kritisch zu bewerten und hinsichtlich Qualität, Security und Wartbarkeit abzusichern.

- Du entwickelst moderne AI-gestützte Anwendungen und Services, bindest LLM APIs und externe Systeme an und arbeitest eng mit Produktverantwortlichen, Fachbereichen und weiteren Entwicklern zusammen, damit aus technologischen Möglichkeiten nutzbare Lösungen entstehen.

## Kenntnisse

- 7 bis 10 Jahre Berufserfahrung in der professionellen Backend-Entwicklung sowie fundierte Erfahrung mit Softwarearchitektur, APIs, Datenbanken, Clean Code und automatisierten Tests.

- Sehr gute Kenntnisse in mindestens einer etablierten Backend-Technologie, beispielsweise Python, Java, C#, TypeScript oder Node.js, ergänzt um einen sicheren Umgang mit Git und CI/CD-Workflows.

- Nachweisbare praktische Erfahrung mit Codex, Claude Code, GitHub Copilot oder vergleichbaren Coding Agents – inklusive Prompt-/Context Engineering und verantwortlicher Qualitätssicherung der Ergebnisse.

- Technische Ownership, Freude an Zusammenarbeit und Wissenstransfer sowie sehr gute Deutsch- und gute Englischkenntnisse.

## Was die Rolle besonders macht:

- Gestaltungsspielraum statt reiner Umsetzung: Du prägst Softwarearchitekturen, Standards und den verantwortlichen Einsatz von AI in der Softwareentwicklung aktiv mit.

- AI-Driven Development als realer Arbeitsansatz: Coding Agents sind kein Zusatzthema, sondern Bestandteil der täglichen Entwicklungsarbeit.

- Abwechslungsreiche interne und externe Projekte, in denen Deine Lösungen sichtbar eingesetzt und weiterentwickelt werden.

## Wir bieten

**Projekte mit Verantwortung** – Gestalte spannende Kundenprojekte selbst.

**Motiviertes Team** – Gemeinsam zum Erfolg.

**Wachstum & Entwicklung** – Deine Karriere, Deine Perspektiven.

## Gesundheit steht bei uns im Fokus:

- **600 € Gesundheitsbudget**– Für Massage, Brille & Co.

- **Top Gesundheitsleistungen**– Auch für Deine Familie.

- **Boni für Fitness**– Werde aktiv und profitiere.

- **Facharzt-Termin in 5 Tagen**– Schnell & unkompliziert.

- **Digitaler Gesundheitscoach**– Europas größter Coach für Dich.

## Unsere Benefits – mehr als nur ein Job:

- **Flexibles Arbeiten**– Homeoffice und 30 Tage Urlaub.

- **Sichere Zukunft**– Unbefristete Festanstellung.

- **Weiterbildung**– Dein Sprungbrett zum Erfolg.

- **Entspannte Atmosphäre**– Coole Team-Events & grüne Büros.

- **Extras**– Rabatte, Parken, Obst & Getränke.

- **Online-Rabatte**– Spare bei über 500 Shops.

- **Dienstwagen** – für berufliche und private Nutzung

- **JobRad-Leasing** – umweltfreundlich mobil

- **EGYM Wellpass** – Zugang zu Fitness- und Gesundheitsangeboten

- **JobCar** – nachhaltig mobil mit E-Car-Leasing in Entgeltumwandlung

- **MeinMPP** - aktuellste Hardware günstig im Leasing

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
