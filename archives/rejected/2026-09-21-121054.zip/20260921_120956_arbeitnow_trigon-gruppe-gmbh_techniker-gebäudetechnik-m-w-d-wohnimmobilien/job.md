# Techniker Gebäudetechnik (m/w/d) - Wohnimmobilien

Posted: 2026-09-21T08:30:39Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Zur Verstärkung unseres Teams suchen wir einen Techniker Gebäudetechnik (w/m/d) für die administrative und organisatorische Betreuung unserer technischen Instandhaltungsprozesse im Bereich Wohnimmobilien.

**Über uns**

Die Trigon Unternehmensgruppe ist ein etabliertes Berliner Immobilienunternehmen mit Fokus auf die Entwicklung, Verwaltung und Vermietung von Wohn- und Gewerbeimmobilien. Der Bestand umfasst rund 4.000 Wohn- und 300 Gewerbeeinheiten sowie Stellplätze.

## Aufgaben

- Technische Betreuung und administrative Unterstützung unserer Technikabteilung

- Erfassung, Bearbeitung und Nachverfolgung von Instandhaltungs- und technischen Aufträgen

- Koordination unserer eigenen Handwerkerteams sowie Terminabstimmung mit Mietern

- Erstellung und Bearbeitung von Aufträgen, Angeboten und technischen Dokumenten

- Erfassung, Prüfung und Abrechnung der durch unsere Handwerkerteams erbrachten technischen Leistungen (Leistungsabrechnung/Fakturierung)

- Prüfung eingehender Rechnungen externer technischer Dienstleister sowie Pflege auftragsbezogener Daten

- Technische Dokumentation der Vorgänge sowie Kommunikation und Abstimmung mit Mietern, Kollegen und externen Dienstleistern

## Qualifikation

- Abgeschlossene technische oder kaufmännische Berufsausbildung (z. B. im Bereich Gebäudetechnik, Bau, Immobilien oder vergleichbar) oder ein Studium mit technischem Schwerpunkt

- Erfahrung in der technischen Sachbearbeitung, Auftragsabwicklung oder im Gebäudemanagement von Vorteil

- Erfahrung in der Leistungsabrechnung, Rechnungsprüfung oder Fakturierung wünschenswert

- Sicherer Umgang mit MS Office (Word, Excel und Outlook)

- Gute Deutschkenntnisse in Wort und Schrift

## Benefits

- Eine unbefristete Festanstellung und Entwicklungsperspektive

- Eine Anspruchsvolle Aufgabe mit hoher Eigenverantwortung

- Ein professionelles und kollegiales Team

- Gleitzeit sowie 30 Tage Urlaub (bei einer 5-Tage-Woche), Weihnachten und Silvester frei

- Deutschlandticket nach Absprache

- Ein modernes Büro mit Klimatisierung in der City West

**Interesse?**

Wir freuen uns auf Ihre Bewerbung!

Wir suchen Sie aus den Bereichen: Technische Gebäudetechnik, Immobilien-, Objekt- und Gebäudemanagement, Technisches Immobilienmanagement, Technische Sachbearbeitung oder Sachbearbeitung Gebäudemanagement (jeweils m/w/d).

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
