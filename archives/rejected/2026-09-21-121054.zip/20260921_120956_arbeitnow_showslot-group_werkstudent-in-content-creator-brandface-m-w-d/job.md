# Werkstudent/in Content Creator / Brandface (m/w/d)

Posted: 2026-09-21T08:58:28Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**Bereit für die ganz große Bühne?**

**ShowSlot** ist das junge, dynamische Entertainment-Label aus Frankfurt am Main, das seit 2017 mit innovativen Live-Produktionen die europäische Musical- und Theaterwelt aufmischt. Wir stehen für legendäre Top-Brands, höchste Produktionsqualität und ein New-Generation Look & Feel. Kurz gesagt: Emotion meets Innovation meets Wow

**Arbeitsbeginn:** ab sofort

**Beschäftigungsverhältnis:** Teilzeit (20h), Werkstudent/in

Als Content Creator / Brandface bist du direkt vor Ort und fängst besondere Momente ein, um das Theatererlebnis auf Social Media für tausende Menschen lebendig zu machen.

## Aufgaben

- Du teilst Einblicke in den Theateralltag und machst das Theater online erlebbar

- Du erzählst Geschichten rund um das Theater, die Shows und seine Menschen

- Du setzt in Abstimmung mit dem Marketingteam im Headoffice die Social Media-Strategie für das BlueMax Theater vor Ort um

- Du entwickelst eigene Content-Ideen und setzt diese um

- Du repräsentierst Social Media im Theater und animierst andere dazu auch Inhalt im Rahmen der Guidelines zu teilen

- Du baust eine Community auf, die immer wieder gerne ins BlueMax Theater geht

## Qualifikation

- Du studierst aktuell im Medien- oder Marketingbereich und begeisterst dich für Theater, Musicals & Shows - oder studierst darstellende Künste und hast eine Affinität für Social Media

- Du hast Spaß an Social Media, ein hohes Plattform-Verständnis v.a. für Instagram und bist immer auf dem aktuellen Stand hinsichtlich Trends

- Du kannst kreativ Denken und authentisch Geschichten erzählen, aber auch den Dreh organisatorisch umsetzen

- Du arbeitest eigenverantwortlich in einem abgestimmten Rahmen

- Du fühlst dich vor der Kamera wohl und kannst andere begeistern, gemeinsam Content umzusetzen

- Nice to have: Du kannst mit den gängigen Apps für Grafik- und Video-Produktion (z.B. Canva, CapCut) sowie Social Media-Management (z.B. Business Suite) umgehen

- Erfahrung mit Grafik- und Video-Apps (z.B. Canva, CapCut) und Social Media-Management-Tools (z.B. Business Suite)

## Benefits

- **Attraktive Vergütung & Extras:** Ein faires, leistungsgerechtes Gehalt von 1.000–1.300€ brutto/Monat (je nach Qualifikation und Erfahrung) sowie attraktive Zusatzleistungen, die deine Arbeit wertschätzen.

- **Start-up-Spirit meets Branchenprofis:** Du bist Teil eines aufstrebenden, schnell wachsenden Entertainment-Labels und profitierst von flachen Hierarchien, kurzen Entscheidungswegen und einer beispiellosen Infrastruktur.

- **Flexibilität, die zu dir passt:** Gestalte deine Arbeitszeit flexibel und nutze die Möglichkeiten zum mobilen Arbeiten, um Job und Freizeit perfekt in Einklang zu bringen.

- **Zukunft mit Applaus:** Wir denken an morgen – du profitierst von einem starken 30%igen Zuschuss zu deiner betrieblichen Altersvorsorge via Entgeltumwandlung.

- **Live-Erlebnisse:** Freue dich auf Mitarbeiterrabatte und Freikarten für unsere eigenen Shows und Produktionen.

Vielfalt ist unsere Stärke

Wir begrüßen Bewerbungen aller Menschen unabhängig von Geschlecht, Alter, ethnischer Herkunft, Religion, Behinderung, sexueller Orientierung oder Identität.

Du brennst für Live-Entertainment und willst mit uns neue Maßstäbe setzen?

Dann wollen wir dich unbedingt kennenlernen! Klicke einfach auf den Bewerben-Button und schicke uns deinen Lebenslauf sowie ein paar Worte dazu, warum du perfekt zu ShowSlot passt.

Wir freuen uns auf dich!

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
