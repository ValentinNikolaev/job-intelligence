# Senior Java Developer for E-Commerce + Accounting SaaS company - remote in EU

Posted: 2026-09-21T08:53:27Z

## Rejection

- Category: tech_stack
- Reason: role does not mention Go/Golang or PHP

At p**athway Solutions GmbH**, we're on a mission to automate accounting for E-Commerce and SaaS companies. Our goal is to free 10,000 entrepreneurs from the burden of manual bookkeeping so they can focus on what they do best: growing their business.

We are a fast-paced, fully remote company experiencing significant customer growth, and we're looking for passionate builders to join us.

**The Opportunity: own the domain of infrastructure**

We are looking for a highly motivated Senior Java Developer to join our team at Pathway. You will be responsible for the development and maintenance of our core application, specifically focusing on our **billing** and **invoice generation systems.** We need someone who is not only a strong coder but also proactive, eager to master new technologies, and capable of solving complex infrastructure and concurrency challenges.

## Tasks

- **Application Development:** Design, develop, and maintain robust billing applications and features (e.g., invoice generation systems) using Java 25.

- **Concurrency & Performance:** Architect and manage highly concurrent, multi-threaded application logic to ensure memory efficiency and system stability.

- **Infrastructure & DevOps:** Take ownership of infrastructure tasks, ensuring our systems are scalable, reliable, and well-maintained.

- **Database Management:** Utilize and optimize both SQL and NoSQL databases (e.g., Bigtable) to handle our evolving data requirements.

- **Integrations:** Design and maintain high-quality API integrations, utilizing modern standards like Swagger/OpenAPI.

- **Cloud Operations:** Implement and manage solutions within cloud environments (GCP preferred)

## Requirements

- **5+ years of professional experience** in backend development, with a strong command of Java. Experience in AI Coding Tools & willingness to further drive AI Adoption in our Development process.

- **A Structured Mindset:** You excel at breaking down complex problems, clarifying requirements with both technical and non-technical stakeholders, and designing clean, well-architected solutions.

- **Concurrency & Multi-threading:** Strong, proven experience in async environments and multi-threaded application logic, as this is fundamental to the core application.

- **DevOps & Infrastructure:** Experience in taking ownership of infrastructure and ensuring system scalability and reliability.

- **Problem-Solving Skills:** Excellent debugging, troubleshooting, and analytical skills. You're comfortable navigating ambiguity and finding the root cause of an issue.

- **Strong Collaboration Skills:** You communicate clearly and work effectively within a team-oriented environment. You have experience with Git, continuous deployment pipelines (like Gitlab), and agile practices like monthly scope planning and regular code reviews.

## Benefits

- **Flexibility:** Remote-first and family-friendly working hours. You decide when you work. No office presence required.

- **Development:** Coaching budget, mentoring, and a diverse team.

- **Vacation:** 30 days off to recharge.

- **Amazing Team events**: last one was Mallorca in 2026

- **Compensation:** An attractive salary package awaits you.

- **Growth Curve:** Take on responsibility and grow with us.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
