# (Senior) Product Manager Heating & Cooling (m/f/d)

Posted: 2026-09-21T08:58:28Z

## Rejection

- Category: tech_stack
- Reason: role does not mention Go/Golang or PHP

## 1KOMMA5°

At **1KOMMA5°**, we pursue a clear vision: **Living on wind and sunlight forever for free**. To make this a reality, we are building the energy system of the future with Heartbeat AI. Want to be part of it?

We bring together regional craftsmanship and scalable software: We don't think of solar, batteries, heat pumps, and e-mobility as isolated components, but control them as an intelligent, integrated overall system in our virtual power plant. Directly connected to the electricity market – in real time, fully automated. This way, energy is used when it is available from renewables and particularly cost-effective. By 2030, our goal is to transition 1.5 million households to renewable energies. Over 3,000 people are working towards this every day, at more than 80 locations worldwide, from Finland to Australia.

**Want to take responsibility and build solutions that truly matter? Apply now and help us shape the energy world of tomorrow.**

Learn about our Product & Tech team!

## Your mission

As Senior Product Manager for Heating & Cooling, you own Heat as a product. What must be true in the household: space heating, hot water, and cooling people can trust, at a cost that makes sense, controlled with Heartbeat.

You decide where Heating & Cooling goes next. Which problems we solve first. How hardware partners, the Energy Management System, and the customer experience add up to one result — in Germany and in the other markets we operate in. You own the problem, the requirements, and the outcomes.

## Your main focus will be to:

- Own the product strategy and roadmap for Heating & Cooling: where the area goes, and how it evolves across markets

- Define the customer outcome (comfort, cost, control, reliability) and the KPIs that prove it

- Turn hardware and field constraints into product requirements. Cut work that does not serve the outcome.

- Drive thermal optimization on our Energy Management System

- Align hardware, the Energy Management System, and the customer experience so households get one heat and cooling experience

- Write specs, run discovery, prioritize, and ship

## Your profile

You have:

- 5+ years of Product Management on hardware-software products, energy, HVAC, or similarly physical systems

- A track record of owning a customer outcome across more than one engineering team

- Comfort at the seam of OEM interfaces, optimization, and customer UX

- Excellent English and German

- Based in Germany or willing to relocate

## Bonus points for:

- Heat pumps, SG Ready, EEBus, Modbus, OEM cloud APIs

- Field or installer experience

- Thermal optimization or HEMS with heat pumps

- Heating and cooling products across more than one country

## Benefits

- You are part of an international, dynamic, and highly motivated team of people who have proven to make things happen

- With your work, you accelerate the "energy transition" and hence have a direct impact on our climate

- Work with and learn from other super-smart colleagues

- You will enjoy direct contact with core decision-makers

- You will enjoy the best chances of entering full-time in one of Europe’s most thriving scaleups

- You work remotely (Germany-wide), with offices in Hamburg, Berlin or Munich

- Create a healthy balance alongside your work and enjoy all the benefits of the EGYM Wellpass

- Benefits and discounts are yours with Futurebens

- Whether city bike or e-bike - be flexible with our job bike leasing and do something good for the environment at the same time

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
