# Heartbeat AI Partnerships Manager (m/f/d)

Posted: 2026-09-21T08:58:28Z

## Rejection

- Category: tech_stack
- Reason: role does not mention Go/Golang or PHP

## 1KOMMA5°

At **1KOMMA5°**, we pursue a clear vision: **Living on wind and sunlight forever for free**. To make this a reality, we are building the energy system of the future with Heartbeat AI. Want to be part of it?

We bring together regional craftsmanship and scalable software: We don't think of solar, batteries, heat pumps, and e-mobility as isolated components, but control them as an intelligent, integrated overall system in our virtual power plant. Directly connected to the electricity market – in real time, fully automated. This way, energy is used when it is available from renewables and particularly cost-effective. By 2030, our goal is to transition 1.5 million households to renewable energies. Over 3,000 people are working towards this every day, at more than 80 locations worldwide, from Finland to Australia.

**Want to take responsibility and build solutions that truly matter? Apply now and help us shape the energy world of tomorrow.**

Learn about our Product & Tech team!

## Deine Position

As part of the Heartbeat Tech domain, you will own our partnerships with hardware manufacturers that connect to Heartbeat AI. You're the person who finds and excites new partners about Heartbeat AI, then negotiates the resulting agreements, and finally makes sure the integration actually gets delivered. But it doesn’t stop there: You will own the relationship long-term and ensure it turns in a true win-win situation.

Key responsibilities include but are not limited to:

- Partnership Sales: Identify and pitch the Heartbeat AI vision to selected hardware manufacturers, get them onboard our vision and carry conversations from first contact through to signed partnership.

- Contract Management: Lead commercial and legal negotiations for all contractual elements to ensure a solid partnership basis with terms that work for both sides.

- Project Management: Coordinate the technical integration to delivery — sequencing work with our development teams, tracking milestones, and unblocking issues on both sides.

- Relationship Management: Own the day-to-day relationship with each partner post go-live — be their primary point of contact, manage escalations, and keep the partnership healthy and growing.

- Portfolio Ownership: Maintain an overview of all Heartbeat AI partnerships, their contractual status, technical maturity and roadmap, and report on the health of the partner portfolio to leadership. In addition identify gaps and pursue opportunites to build the strongest partnership portfolio in the market.

## Dein Profil

The successful candidate will have:

- Proven experience in partnership management, business development, or B2B sales, ideally at the intersection of hardware and software products

- Confidence and skill in pitching a technical/strategic vision to senior stakeholders at manufacturers, and in negotiating commercial and legal agreements

- Experience coordinating complex projects across internal engineering teams and external partners

- Excitement to build and maintain long-term relationships with hardware manufacturer partners while balancing multiple partnerships in parallel

- An agile, structured mindset with strong contract- and project-management instincts, and you consider yourself a team player

- Very strong written and spoken English and German skills
Bonus points for:

- Existing network of contacts in the solar, battery storage, EV charging or HVAC hardware markets

- Experience with technical integration protocols (Modbus, EEBUS, OCPP) — enough to hold your own in a technical conversation, not necessarily to implement them

- Experience negotiating API or data-sharing agreements
We are an ambitious and dynamic company with a talented team. We require our engineers to be imaginative, enthusiastic, and willing to tackle new challenges as we strive to provide everyone with renewable energy technologies.

## Benefits

- You are part of an international, dynamic, and highly motivated team of people who have proven to make things happen

- With your work, you accelerate the "energy transition" and hence have a direct impact on our climate

- Work with and learn from other super-smart colleagues

- You will enjoy direct contact with core decision-makers

- You will enjoy the best chances of entering full-time in one of Europe's most thriving scaleups

- You work remotely (Germany-wide), with offices in Hamburg, Berlin or Munich

- Create a healthy balance alongside your work and enjoy all the benefits of the EGYM Wellpass

- Benefits and discounts are yours with Futurebens

- Whether city bike or e-bike - be flexible with our job bike leasing and do something good for the environment at the same time

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
