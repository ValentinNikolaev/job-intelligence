# Android-Entwickler (m/w/d) mit Schwerpunkt KI-gestützte Entwicklung

Posted: 2026-09-21T08:57:36Z

## Rejection

- Category: role_mismatch
- Reason: title is an obvious mismatch for a backend profile

**Wir suchen keine Mitarbeitenden. Wir suchen Mitgestaltende.**

Bei Narravero mitzugestalten ist mehr als ein Job – es ist echtes Wachstum. Wir starten dort, wo Gesetze den Rahmen setzen – und machen daraus Wege, die Menschen wirklich gehen wollen. Und genau hier beginnt unsere Arbeit.

Wir suchen einen erfahrenen Android-Entwickler (m/w/d), der moderne Softwareentwicklung mit den Möglichkeiten künstlicher Intelligenz verbindet. Du entwickelst hochwertige Android-Anwendungen und nutzt KI-gestützte Werkzeuge selbstverständlich, um schneller, effizienter und qualitativ besser zu arbeiten.

## Aufgaben

**Deine Aufgaben**

- Entwicklung und Weiterentwicklung nativer Android-Apps mit Kotlin

- Konzeption, Implementierung und Optimierung moderner App-Architekturen

- Einsatz KI-gestützter Entwicklungswerkzeuge bei Coding, Refactoring, Testing und Dokumentation

- Bewertung und Integration neuer KI-Tools und Technologien in den Entwicklungsprozess

- Mitgestaltung von Entwicklungsstandards und Best Practices für KI-gestützte Softwareentwicklung

## Qualifikation

**Was du mitbringst:**

- Mehrjährige Erfahrung in der Android-Entwicklung mit Kotlin

- Fundierte Kenntnisse des Android SDK sowie moderner Architekturkonzepte

- Nachweisbare Erfahrung in der KI-gestützten Softwareentwicklung

- Sicherer Umgang mit KI-Coding-Assistenten und generativer KI zur Unterstützung von Entwicklung, Analyse und Qualitätssicherung

- Fähigkeit, KI-generierten Code kritisch zu bewerten, zu testen und sicher in bestehende Systeme zu integrieren

- Ausgeprägtes Qualitätsbewusstsein und Verständnis für Datenschutz, Sicherheit und technische Grenzen von KI

- idealerweise gute Deutsch- und Englischkenntnisse

## Benefits

**Wir bieten**

- Anspruchsvolle Projekte mit hohem Innovations- und Gestaltungsspielraum

- Eine zentrale Rolle beim Ausbau unserer KI-gestützten Entwicklungsprozesse

- Moderne Technologien und aktuelle Entwicklungswerkzeuge

- Flexible Arbeitszeiten und hybride oder vollständig remote mögliche Arbeitsmodelle

- Ein kollegiales Team mit kurzen EntscheidungswegenAttraktive Vergütung und zeitgemäße Zusatzleistungen

Klingt spannend?

Dann freuen wir uns auf deine Bewerbung mit Lebenslauf, relevanten Projekten und einer kurzen Darstellung, wie du KI heute in deinem Entwicklungsalltag einsetzt.

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
