# (Senior) Product Manager Heartbeat (m/f/d)

Posted: 2026-09-21T08:58:28Z

## Rejection

- Category: tech_stack
- Reason: role does not mention Go/Golang or PHP

## 1KOMMA5°

At **1KOMMA5°**, we pursue a clear vision: **Living on wind and sunlight forever for free**. To make this a reality, we are building the energy system of the future with Heartbeat AI. Want to be part of it?

We bring together regional craftsmanship and scalable software: We don't think of solar, batteries, heat pumps, and e-mobility as isolated components, but control them as an intelligent, integrated overall system in our virtual power plant. Directly connected to the electricity market – in real time, fully automated. This way, energy is used when it is available from renewables and particularly cost-effective. By 2030, our goal is to transition 1.5 million households to renewable energies. Over 3,000 people are working towards this every day, at more than 80 locations worldwide, from Finland to Australia.

**Want to take responsibility and build solutions that truly matter? Apply now and help us shape the energy world of tomorrow.**

Learn about our Product & Tech team!

## Deine Position

As Senior Product Manager for Heartbeat, you own our Energy Management System as a product. The energy core households depend on: solar, batteries, heat pumps, AC, and EV charging are controlled and optimized as one system, around the clock, and more value comes out of every kilowatt-hour.

You decide where that system goes next. How those assets are controlled. How it creates more value over time. Which hardware worlds it must work in, in Germany and in the other markets we operate in. Energy, heating and cooling, and mobility products all run on it.

You set the direction, stay close to engineering on reliability, and work closely with the Product Managers in those areas so they can build on one Energy Management System.

## Your main focus will be to:

- Own the product strategy and roadmap for Heartbeat: where the Energy Management System goes, and how it evolves across markets

- Set direction and work closely with other Product Managers: aligned roadmaps, guidance, unblocking

- Make reliability a product outcome: households can depend on the system every day

- Push the system to control and optimize all assets in the home, and create more value from every kilowatt-hour

- Write specs, run discovery, prioritize, and ship

## Dein Profil

You have:

- 7+ years of Product Management on Energy Management Systems, IoT, embedded/edge, or similar control systems

- A track record of owning a system that other product areas depend on, and of deciding where it goes next

- Experience guiding other Product Managers in a domain. Line management is a plus, not a requirement.

- Experience shipping reliability and scale, not only new features

- Enough technical depth to debate protocols, fleet operations, and data pipelines with engineers

- Excellent English. German is a plus. Based in Germany.

## Bonus points for:

- HEMS, inverter/battery/EV control, Modbus, OTA, gateway security

- Optimization, forecasting, or dispatch systems

- Shipping an Energy Management System across more than one country

- Line management of Product Managers

## Benefits

- You are part of an international, dynamic, and highly motivated team of people who have proven to make things happen

- With your work, you accelerate the "energy transition" and hence have a direct impact on our climate

- Work with and learn from other super-smart colleagues

- You will enjoy direct contact with core decision-makers

- You will enjoy the best chances of entering full-time in one of Europe’s most thriving scaleups

- You work remotely (Germany-wide), with offices in Hamburg, Berlin or Munich

- Create a healthy balance alongside your work and enjoy all the benefits of the EGYM Wellpass

- Benefits and discounts are yours with Futurebens

- Whether city bike or e-bike - be flexible with our job bike leasing and do something good for the environment at the same time

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
