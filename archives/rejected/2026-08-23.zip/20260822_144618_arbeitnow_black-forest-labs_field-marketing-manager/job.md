# Field Marketing Manager

Posted: 2026-08-22T11:40:18Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

## **About Black Forest Labs**

We're the team behind Latent Diffusion, Stable Diffusion, and FLUX—foundational technologies that changed how the world creates images and video. We’re creating the generative models that power how people make images and video—tools used by millions of creators, developers, and businesses worldwide. Our FLUX models are among the most advanced in the world, and we're just getting started.

Headquartered in Freiburg, Germany with a growing presence in San Francisco, we're scaling fast while staying true to what makes us different: research excellence, open science, and building technology that expands human creativity.

## **Why This Role**

FLUX gets attention the moment people see it. Your job is to turn that attention into pipeline.

You'll own two motions where FLUX meets enterprises and partners in person: the events where customers experience the models firsthand, and the co-marketing engine with cloud and distribution partners who bring FLUX to the market. You’ll work directly with GTM, Partnerships, and our creative technologists. Our release cadence means there’s always a new reason to show up. Your job is to make sure we show up well and that every appearance has a number attached to it in order to effectively measure impact.

## What you’ll work on

### Events

-

Shape BFL's event calendar end-to-end: tier the opportunities, decide where we show up, and run the full events lifecycle: booths, demos, speaker slots, exec briefings, side events, follow up and more

-

Design event experiences that demonstrate the models, not just talk about them; working with Creative Technologists and FDEs on interactive demos and installations

-

Build the pre/post event machine: target lists for Sales, meeting orchestration on-site, pipeline attribution afterward. Every event has a number attached to measure impact (MQL’s)

-

Run BFL-hosted formats: customer dinners, launch events, and executive roundtables in key markets, plus side events at major moments (GTC, research oriented, etc.)

### Co-marketing with partners

-

Own the co-marketing motion with our distribution and cloud partners; joint announcements, launch-day amplification, case studies, shared event presence

-

Coordinate partner marketing calendars around BFL launches so every major release lands with multiplied reach

-

Build repeatable co-marketing playbooks per partner tier, and negotiate marketing commitments into partnership conversations alongside the Partnerships team

### **GTM Enablement**

-

Pitch decks

-

Solution marketing

### Connecting the motions

-

Co-own the activation calendar with our social marketing team so events, partner moments, and social land together

-

Feed what you learn on the floor (what lands, the questions enterprises actually ask back into GTM and product marketing)

## What We're Looking For

-

3–6 years in field/event marketing, partner marketing, or integrated campaigns at a B2B tech company

-

You've run events end-to-end (from a 10-person exec dinner to a major conference presence) and can show the pipeline they produced

-

You've done co-marketing with large partners

-

You understand enterprise marketing: how buying committees work, what an exec briefing needs to accomplish, why attribution matters

-

80%+ execution. You can build the run-of-show, brief the booth staff, etc.

-

Strong visual taste: our outputs are judged visually, and so are our activations

-

Comfortable with ambiguity, tight timelines, and launch weeks where everything happens at once

### **While not required, it’s an added plus if you also have:**

-

Experience marketing generative AI, creative tooling, or developer-facing infrastructure

-

Existing relationships in the creative AI community

-

Experience working with cloud or platform partners on joint GTM

-

You've built an event or campaign that people in the industry still reference

-

Time spent working in the US, or in a role with significant US market ownership

## **How We Work Together**

**We’re a distributed team with real offices that people actually use. Depending on your location, you’ll either join us in Freiburg or SF at least 2 days a week (or one full week every other week), or work remotely with a monthly in-person week to stay connected. We’ll cover reasonable travel costs to make this possible. We think in-person time matters, and we’ve structured things to make it accessible to all. We’ll discuss what this will look like for the role during our interview process.**

### **Everything we do is grounded in four values:**

-

Obsessed. We are a frontier research lab. The science has to be right, the understanding deep, the product beautiful.

-

Low Ego. The work speaks. The best idea wins, no matter who said it. Credit is shared. Nobody is above any task.

-

Bold. We take the ambitious bet. We ship, we do not wait for conditions to be perfect.

-

Kind. People over politics. We treat each other with genuine warmth. Agency without empathy creates chaos.

If this sounds like work you’d enjoy, we’d love to hear from you.

**Base Annual Salary:**

**US **$160,000- $200,000 + equity
**EU** €105,000- €130,000 + equity

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
