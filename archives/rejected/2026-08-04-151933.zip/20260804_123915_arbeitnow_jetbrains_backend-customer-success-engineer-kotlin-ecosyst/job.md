# Backend Customer Success Engineer (Kotlin Ecosystem) -m/w/d

Posted: 2026-08-04T08:56:00Z

## Rejection

- Category: tech_stack
- Reason: role does not mention Go/Golang or PHP

At JetBrains, code is our passion. Ever since we started, back in 2000, we have strived to make the strongest, most effective developer tools on earth. By automating routine checks and corrections, our tools speed up production, freeing developers to grow, discover, and create.

We’re now looking for a Customer Success Engineer (CSE) to help engineering teams successfully adopt Kotlin on the backend in real-world production environments.

Currently, this role is focused on adoption – helping Java teams introduce Kotlin into existing applications. You’ll work directly with organizations to guide migration, integration, troubleshooting, and scaling, ensuring they move from initial experiments to successful production use.

In addition, you’ll proactively communicate with prospective users to help them understand the Kotlin adoption process, as well as design and implement the migration path.

### **Responsibilities**

- Track and maintain visibility into organizations and their stage of Kotlin adoption (e.g., not started, evaluating, experimenting, production)

- Proactively engage with organizations across different phases of their Kotlin adoption journey

- Develop and recommend high-level adoption strategies tailored to each organization’s context

- Identify and document blockers that hinder progress and propose ways to address them

- Establish and manage feedback loops with development teams to ensure continuous alignment and improvement

### **We will be happy to have you on our team if you have:**

**Technical expertise**

- Extensive hands-on experience with Kotlin, Java, and the JVM ecosystem

- Proven experience migrating Java backend codebases to Kotlin

- Experience with the Spring (Boot) ecosystem or similar frameworks (e.g., Quarkus, Micronaut, Ktor)

- Solid understanding of build tools and project structuring, including Maven and Gradle

**Communication and customer engagement**

- Experience in customer-facing technical roles such as Solutions Engineering, Developer Advocacy, or Technical Consulting

- Strong English communication skills, both written and spoken

- Ability to lead workshops, demos, talks, meetups, and other public-facing activities

- Comfort with outbound engagement, including identifying target companies, articulating value propositions, and building relationships with engineering teams

- Ability to effectively communicate with engineers, tech leads, and business stakeholders

**System design and architecture**

- Ability to design and guide Kotlin adoption strategies for backend applications

- Experience designing backend systems using common architectural patterns (e.g., monolith, modulith, microservices)

**Why join JetBrains? **

- Strong base salary. We offer competitive pay that reflects your skills and experience.

- Flexible work location. Enjoy the freedom to work from home or from the office.

- Remote work. Spend up to 30 days per year working remotely from abroad.

- Extra time off. More days to relax, recharge, and do the things you love.

- Medical insurance allowance. Enjoy peace of mind for you and your family

- Learning and development opportunities. Access to conferences, courses, and language classes.

- Relocation support. We help make your move as smooth and stress-free as possible.

- Language classes. Pick up the local language or sharpen your English skills.

- Fuel your day. Enjoy a hot meal or receive a lunch allowance on workdays.

- Mental health support. To help you feel your best, we provide easy access to professional mental health services.

- Sports benefit. Enjoy an on-site gym or sports club stipend.

- Internal events. Join company-wide celebrations and team gatherings.

*Some benefits may vary depending on location.

#LI-HYBRID
#LI-REMOTE
#LI-JP1

**We are an equal opportunity employer**

We know great ideas can come from anyone, anywhere. That’s why we do our best to create an open and inclusive workplace – one that welcomes everyone regardless of their background, identity, religion, age, accessibility needs, or orientation.

*We process the data provided in your job application in accordance with the [Recruitment Privacy Policy.](https://www.jetbrains.com/legal/docs/privacy/privacy-recruitment/)*

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
