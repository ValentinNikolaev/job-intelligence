# Senior/Staff Robotics Engineer (m/f/d)

Posted: 2026-08-04T09:01:27Z

## Rejection

- Category: location_requirement
- Reason: requires United States location

Join us in reshaping manufacturing with advanced tech like computer vision and AI!

As a **Senior/Staff Robotics Engineer (m/f/d)**, you will be integral in driving our company's next phase of innovation - automating industrial processes to address the scarcity of skilled labor. We have already proven our ability to optimize processes and increase efficiency, and now we are determined to automate tasks within industrial environments. Your main focus will be on R&D and will involve building and showcasing a demonstrator that utilizes industrial robot arms to automate currently manual tasks.

You have a strong background in state of the art in robotic manipulation, extensive experience in modeling, planning, and controlling robotic systems, as well as applying machine learning techniques to enhance robotic manipulation capabilities.

**Your role**

-

Lead R&D efforts to prototype a new robotic manipulator, conducting rigorous testing to validate design specifications and performance criteria.

-

Work with industry-standard hardware platforms (e.g., ROS-compatible robots, specific sensor suites) to develop and deploy robotic manipulators for real world testing.

-

Develop and implement models for hybrid dynamical systems exhibiting both continuous and discrete dynamic behaviors, specifically in robotic manipulators.

-

Design advanced planning algorithms to optimize manipulation tasks such as pick-and-place operations.

-

Experience with supervised learning, unsupervised learning, and reinforcement learning techniques to improve manipulation performance in robots.

-

Previously trained RL models in both simulated and real-world environments with continuous action and state spaces.

-

Design and develop middleware and software solutions tailored for robotic manipulation applications.

-

Optimize software architecture for efficient communication between sensors, processors, and actuators in robotic manipulators.

-

Develop perception algorithms for object pose estimation, matching, and instance segmentation to aid in manipulation tasks.

-

Utilize deep learning techniques for end-to-end and self-supervised grasping, enhancing the robot's autonomous manipulation capabilities.

-

Experience with integration between hardware components, including tactile sensors, force sensors, vision systems (e.g., RGB-D cameras), and depth sensors to optimize communication protocols and data flow for efficient robotic operations.

**Your profile**

-

Ph.D. in Robotics, Mechanical Engineering, Electrical Engineering, Computer Science, or related field, with a strong emphasis on robotics.

-

Minimum of 1-2 years of experience in robotics research or development.

-

Proven experience in modeling, planning, and controlling hybrid dynamical systems for robotic manipulation.

-

Hands-on experience with machine learning techniques applied to robotic manipulation tasks.

-

Experience with robotic perception technologies and deep learning frameworks as applied to manipulation.

-

Strong programming skills in C++, Python, and familiarity with ROS (Robot Operating System).

-

Experience with simulation tools such as Nvidia Isaac SIM, Gazebo, V-REP, CUDA for robotic manipulation.

-

Proficiency with machine learning libraries like TensorFlow or PyTorch.

-

Fluency in English is mandatory.

**What we offer**

Employee Share Options Program for all permanent employees*

An increasing benefits list: currently includes Urban Sports club and quarterly team retreats.

Be on the forefront in defining what artificial intelligence means in manufacturing

Gain hands-on experience in working in an AI-first software company

Supportive and inclusive culture that values diversity and promotes the advancement of underrepresented groups within the company

Collaborate with a diverse (currently more than 10 nationalities) and talented team, working on cutting-edge projects with real-world impact

Network with professionals and leaders in the field, opening doors to potential future career opportunities

We have a very flat hierarchy, open 360° feedback, and flexible working hours

Ethics⚖: We are committed to developing ethical AI software

**Don't meet all the requirements?**

*Almetra is committed to creating a workplace that is diverse, fair, and inclusive. We encourage candidates from all backgrounds, even if they do not meet every qualification, to submit their application. We firmly believe that having a team with diverse perspectives only strengthens our company and drives innovation. Our commitment also extends to providing an accessible environment for everyone, including those with disabilities. Please let us know if you require any accommodations during the application process or while working with us, and we will do our best to support you.*

**Only full-time, permanent roles are eligible for stock options. Part-time roles, contract roles, work-student, internships and freelance roles are not eligible for stock options.*

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
