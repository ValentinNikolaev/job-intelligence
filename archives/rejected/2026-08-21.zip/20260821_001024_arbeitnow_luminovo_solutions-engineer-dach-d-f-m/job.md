# Solutions Engineer - DACH (d/f/m)

Posted: 2026-08-20T14:40:17Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**About the role**

Luminovo builds the software that powers the electronics supply chain — and we're building out the DACH side of our Global Solutions team. As a Solutions Engineer based in Munich or Berlin, you are the technical face of Luminovo at the two moments that decide whether a customer succeeds with us.

The Solutions team is one global team across Europe and the US, deliberately not split by region so knowledge doesn't get siloed. It's a unified team, which means real ownership: you won't inherit a finished playbook, you'll help write it.

**What you'll do**

-

Join AE- and CSM-led sales calls as the technical expert — run tailored demos, technical deep dives, and ROI cases for OEM and EMS prospects, then hand back for the commercial close

-

Own customer onboarding end to end: tenant configuration, ERP and data integrations, end-user training, and driving each account to first value

-

Bring structure into chaos. When an implementation drifts or a customer gets lost, you're the person who rebuilds the plan and gets them back on track

-

Become the go-to expert for at least one Luminovo module, define its onboarding blueprint, and teach the rest of the Solutions team how to run it

-

Build deep expertise in the Luminovo platform and the electronics manufacturing landscape — deep enough that industry experts trust you in the room

-

Spot implementation risk early, escalate to the right people proactively, and keep projects on schedule

-

Turn what you learn into revenue-anchored feature requests and input for the Product team helping them to further improve our software.

**Who you are**

-

You speak **German fluently** and work comfortably in English. You'll be in front of technical buyers every week

-

You have a **technical foundation** and a track record of getting deep into an unfamiliar product fast. A degree in engineering, computer science, physics, or a related field helps — so does hard evidence that you taught yourself something difficult

-

You're **process-driven**. You're at your best when a project has gone sideways and someone needs to draw the map

-

You're comfortable in front of customers: you can hold your own in a technical conversation with a specialist, then explain the same thing simply to a procurement lead

-

You use AI as more than a better search engine. Ideally you've built your own automations, workflows, or tools — we care about what you've actually shipped, not what you've read them

-

**Bonus:** French language fluency

**Work setup**

Hybrid in Munich or Berlin. Munich is our global HQ; we also have a Berlin hub. No strict office policy, but a clear expectation of regular collaboration days with your Solutions teammates and colleagues across multiple departments.

**Travel**

We meet regularly for team retreats and selected industry events, so expect occasional travel. We cover the costs.

**Why Luminovo**

-

Join a well-funded SaaS scale-up with 300+ active customers, in the role that decides whether they succeed with us

-

One global Solutions team across Europe and the US — no EU/US knowledge silos

-

AI at the core of the product and of how we work, not a slide in a deck

-

Real ownership on a young team: define the blueprints the rest of the team runs on

**🤓 Whom you'll be working with**

-

[**Rachel**](https://www.linkedin.com/in/rachel-g-53a573180/), Global Solutions

-

[**Sam**](https://www.linkedin.com/in/sam-mason-15742499/), Global Solutions

-

[**Seba**](https://www.linkedin.com/in/sebastian-schaal/), one of our founders, close to our OEM and go-to-market motion

-

**Our Account Executives and Customer Success Managers across DACH**, who'll pull you into their most technical conversations

-

**Our Product Managers**, so you understand the roadmap and constraints and can feed real customer signal back into it

**⚡️ Skills, knowledge, and expertise**

Just so you know – we purposefully did not create a standard list of minimum qualifications for this role. We care much more about your motivation and ability to help us accelerate technical progress than we care just about your CV. If you're interested to find out more about why we banned requirements from our performance profiles – see [here](https://medium.com/startup-grind/why-we-banned-requirements-from-our-job-descriptions-33a774e1a1c2).

#

# **⚡️ About Luminovo**

Luminovo is the first electronics supply chain platform that unites all data, processes, and stakeholders in the [trillion-dollar electronics industry](https://luminovo.com/resources/blog/a-short-primer-on-the-electronics-industry?utm_campaign=employer_branding&utm_source=candidate-traffic).

We fundamentally believe that technology is the best tool that humankind has developed to tackle the biggest challenges we face as a society today. And we want to do our share in accelerating technological progress.

***We bring innovations to life faster and cheaper by creating a more connected and resilient electronics supply chain.***

To date, over 300 active customers worldwide are working with us towards this shared goal. Supported by leading investors such as Cherry Ventures, General Catalyst/LaFamiglia, Chalfen Ventures, and others, we have [raised more than €20 million](https://luminovo.com/resources/blog/luminovo-raises-eu11-million-in-seed-funding-to-fix-the-broken-electronics-value-chain-with-transformative-software-suite).

**Our core principles: putting people first & building great things**

As a remote-first company headquartered in Munich, our brilliant team is spread across cities including Munich, New York, Austin, Calgary, Berlin, London, Valencia, Nairobi, and Verona, among others. 🌍

Our team includes a mix of product enthusiasts, people advocates, business masterminds, and engineering experts. Among us are graduates from institutions like Stanford University and the University of Cambridge, as well as talented individuals with unconventional CVs. What matters most is their drive to build great things.

We provide an authentic environment based on psychological safety to empower Luminerds from various backgrounds to succeed, grow, and focus on impact. Putting people first means that we deeply care about who our employees are, what makes them unique, and what they excel at.

See what employees and candidates have to say about Luminovo on [kununu](https://www.kununu.com/de/luminovo) and [Glassdoor](https://www.glassdoor.de/Bewertungen/luminovo-ai-Bewertungen-E2039308.htm).

Compensation: €73K – €107.7K • Offers Equity • Offers Commission • Multiple Ranges

- DACH - Tier 2 • On-Target Earnings €73K – €84K • Offers Equity • Offers Commission
- DACH - Tier 3 • On-Target Earnings €93.5K – €107.7K • Offers Equity • Offers Commission

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
