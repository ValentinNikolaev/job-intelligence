# Fachkraft für Arbeitssicherheit / Sicherheitsingenieur (w/m/d) (Präventic)

Posted: 2026-08-20T14:30:21Z

## Rejection

- Category: language_requirement
- Reason: hard German language requirement without English green light

**Du möchtest Unternehmen dabei unterstützen, sichere und gesunde Arbeitsbedingungen zu schaffen, Arbeitsschutz ganzheitlich weiterzuentwickeln und Kunden unterschiedlichster Branchen fachlich zu begleiten? Dann suchen wir genau Dich, zum nächstmöglichen Zeitpunkt als:**

**Fachkraft für Arbeitssicherheit / Sicherheitsingenieur (w/m/d) im Außendienst in Vollzeit oder Teilzeit (80%) für den Großraum Bodensee (z. B. Lindau, Singen oder Konstanz).**

Als Fachkraft für Arbeitssicherheit / Sifa (w/m/d) betreust und berätst Du unsere Kunden gemäß Arbeitssicherheitsgesetz und DGUV Vorschrift 2. Dabei entwickelst Du individuelle Lösungen für unterschiedliche betriebliche Anforderungen, führst Unterweisungen und Seminare durch und begleitest Unternehmen bei der nachhaltigen Umsetzung geeigneter Arbeitsschutzmaßnahmen. Dafür brauchen wir Deine Unterstützung!

Die **Präventic GmbH** ist ein etablierter Dienstleister für Arbeitsmedizin und Arbeitssicherheit. Mit einem interdisziplinären Team aus Arbeitsmediziner, Betriebsärzt, Fachkräften für Arbeitssicherheit und weiteren Expert beraten wir Unternehmen unterschiedlichster Branchen bei der Umsetzung eines modernen Arbeits- und Gesundheitsschutzes. Dabei stehen persönliche Betreuung, praxisnahe Lösungen und eine vertrauensvolle Zusammenarbeit im Mittelpunkt.

**Deine Aufgaben:**

-

**Sicherheitstechnische Beratung & Betreuung**

-

Eigenständige sicherheitstechnische Betreuung und Beratung unserer Kunden gemäß Arbeitssicherheitsgesetz (ASiG) und DGUV Vorschrift 2.

-

Durchführung von Begehungen der Arbeitsstätten sowie Unterstützung bei der Erstellung und Aktualisierung von Gefährdungsbeurteilungen.

-

Beratung zu Themen wie Brandschutz, Erste Hilfe und Betriebsanweisungen sowie Entwicklung praxisnaher Lösungen.

-

Strategische Beratung zur kontinuierlichen Weiterentwicklung des betrieblichen Arbeits- und Gesundheitsschutzes.

-

Kompetente Ansprechperson für Führungskräfte, Beschäftigte und weitere betriebliche Ansprechpartner:innen in allen Fragen des Arbeitsschutzes.

-

**Seminare, Unterweisungen & Konzepte:**

-

Planung und Durchführung von Seminaren, Schulungen und Unterweisungen zu verschiedenen Themen des Arbeits- und Gesundheitsschutzes.

-

Unterstützung bei Maßnahmen der Verhaltens- und Verhältnisprävention zur Förderung sicherer und gesunder Arbeitsbedingungen.

-

Analyse von Betriebsunfällen sowie Ableitung geeigneter Maßnahmen zur nachhaltigen Unfallverhütung.

-

Entwicklung individueller und praxisorientierter Konzepte, abgestimmt auf die Anforderungen unserer Kunden.

-

Einbringung eigener Ideen zur kontinuierlichen Weiterentwicklung unseres Beratungs- und Leistungsangebots.

-

**Kunden- und Projektmanagement:**

-

Verantwortung für eine strukturierte, verlässliche und partnerschaftliche Betreuung der betreuten Kunden.

-

Eigenständige Koordination von Projekten, Terminen und vereinbarten Maßnahmen.

-

Enge Zusammenarbeit mit interdisziplinären Kolleg:innen aus Arbeitsmedizin, Gesundheitsmanagement und Psychologie sowie weiteren internen Fachbereichen.

-

Dokumentation der Beratungsergebnisse und Nachverfolgung vereinbarter Arbeitsschutzmaßnahmen.

**Deine Startvoraussetzungen:**

-

**Das bringst Du mit:**

-

Abgeschlossene Qualifikation als Fachkraft für Arbeitssicherheit / Sicherheitsfachkraft.

-

Fundierte Fachkenntnisse im Arbeits- und Gesundheitsschutz sowie in der sicherheitstechnischen Betreuung von Unternehmen nach ASiG und DGUV Vorschrift 2.

-

Selbstständige, strukturierte und präzise Arbeitsweise, verbunden mit Verantwortungsbewusstsein und einem ausgeprägten Organisationstalent.

-

Sehr gute Deutschkenntnisse in Wort und Schrift (mindestens B2-Niveau) sowie ein kommunikationsstarkes Auftreten.

-

Gültiger Führerschein der Klasse B, Bereitschaft zu regionalen Außendiensteinsätzen sowie gute Kenntnisse in den gängigen Microsoft-Office-Anwendungen.

-

**Das hilft Dir, schneller erfolgreich zu sein:**

-

Von Vorteil wären praktische Erfahrungen in der sicherheitstechnischen Betreuung von Kunden unterschiedlicher Branchen und Unternehmensgrößen.

-

Hilfreich wären Kenntnisse in den Bereichen Gefährdungsbeurteilung, Brandschutz, Erste Hilfe oder Betriebsanweisungen.

-

Von Vorteil sind Erfahrungen in der Durchführung von Seminaren, Schulungen oder Unterweisungen.

-

Hilfreich wären Erfahrungen in der eigenständigen Organisation und Koordination von Arbeitsschutzmaßnahmen sowie Interesse an der kontinuierlichen Weiterentwicklung von Beratungs- und Präventionsmaßnahmen.

**Unsere Benefits:**

-

**Attraktives & familienfreundliches Arbeitsumfeld:** Flexible Arbeitszeiten und eigenverantwortliches Arbeiten unterstützen Dich dabei, Beruf und Privatleben optimal miteinander zu vereinbaren. Zusätzlich erwarten Dich ein unbefristeter Arbeitsvertrag, 30 Tage Jahresurlaub auf Vollzeitbasis sowie eine langfristige Perspektive in einem Unternehmen der Arsipa Gruppe.

-

**Mobilität & Zusatzleistungen:** Je nach Einsatz stehen Dir passende Mobilitätslösungen zur Verfügung. Ergänzt wird unser Angebot durch eine betriebliche Altersvorsorge sowie attraktive Mitarbeitervorteile.

-

**Onboarding & moderne Ausstattung:** Eine intensive Einarbeitung und ein strukturiertes Onboarding sorgen für einen erfolgreichen Start. Für Deine tägliche Arbeit erhältst Du moderne Arbeitsmittel wie Laptop und Smartphone.

-

**Teamkultur & Weiterentwicklung:** Dich erwartet ein kollegiales Arbeitsumfeld mit flachen Hierarchien und kurzen Entscheidungswegen. Individuelle Fort- und Weiterbildungsmöglichkeiten unterstützen Deine fachliche und persönliche Entwicklung.

-

**Starkes Wachstumsumfeld:** Als Teil der Arsipa Gruppe profitierst Du von den Vorteilen einer schnell wachsenden Unternehmensgruppe, unterstützt durch Warburg Pincus.

**Unser Bewerbungsprozess:**

-

**Kurzes Telefonat** mit dem Talent-Acquisition-Team der Arsipa-Gruppe.

-

**Interview** mit den zuständigen Ansprechpartner*innen der Präventic GmbH.

-

**Hospitation/persönliches Kennenlernen** mit dem Team aus dem Fachbereich der Präventic GmbH.

Für weitere Fragen stehen wir Dir gerne jederzeit zur Verfügung!
Du erreichst das Talent-Acquisition-Team der Arsipa-Gruppe unter **

**Werde Teil unserer spannenden Reise bei der Präventic GmbH - Wir freuen uns auf Dich!
**

Die Präventic GmbH ist Teil der Arsipa Gruppe, eine schnell wachsende, Unternehmensgruppe im Bereich Health, Safety & Environment, unterstützt von Warburg Pincus. Mit über 1.000 Mitarbeitenden, 20+ Tochtergesellschaften und 48 Standorten in Deutschland und Österreich bauen wir im Rahmen einer klaren Buy-&-Build-Strategie eine skalierbare Plattform mit nachhaltiger Wertschöpfung. Unser Ziel: eine der führenden Anbieterinnen im deutschsprachigen Markt - unterstützt durch zentrale Funktionen wie Finance, HR, Marketing und IT am Standort Berlin.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
