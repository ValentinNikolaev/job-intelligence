# Technischer Produktdesigner | Bautechnischer Konstrukteur | Bauzeichner (m/w/d) - im Fertighausbau

Posted: 2026-08-20T14:30:38Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Mehr Freiraum am Vormittag. Mehr Fokus am Nachmittag. Mehr Zeit für das, was dir wichtig ist.

**ScanHaus Marlow,** einer der führenden Anbieter moderner und umweltfreundlicher Fertighäuser, wächst weiter und sucht einen Bautechnischen Konstrukteur | Bauzeichner oder Technischen Produktdesigner (m/w/d), der unser Team mit technischem Know-how und guten Ideen verstärkt.

Du liebst es, kreative Ideen in präzise Pläne zu verwandeln und möchtest erleben, wie aus deinen Zeichnungen echte Häuser entstehen? Dann werde Scanhäusler und gestalte mit uns die Zukunft des Bauens.

**Und das Beste:** Du musst deinen Tag nicht früh beginnen. Bei uns hast du am Vormittag Zeit für die Dinge, für die sonst oft der Feierabend zu kurz ist – ob Sport, Familie, Termine, Einkäufe oder einfach ein entspannter Start in den Tag.

Für diese Position suchen wir dich bewusst für die Spätschicht. Du hast die Wahl: 12:00–20:00 Uhr oder 14:00–22:00 Uhr.

So kannst du deinen Arbeitstag an deinen Alltag anpassen – und nicht umgekehrt.

## Aufgaben

- Erstellen von Ausführungszeichnungen für Einfamilienhäuser nach der Baubesprechung

- Erstellen von Detail- und Konstruktionszeichnungen für die Hausproduktion

- Konstruieren von Wandelementen und Dachbindern etc.

## Qualifikation

- Konstruktives Verständnis setzen wir voraus.

- Sicherer Umgang mit AutoCAD Architecture sowie den gängigen MS-Office Programmen

- Eigenständige Bearbeitung von 3D-Planungen

- Kenntnisse im Holzständerbau und in HSB-CAD sowie Mitek Pamir nicht zwingend erforderlich, kann angelernt werden

- fließende Deutschkenntnisse vorausgesetzt

## Benefits

- attraktive Vergütung

- Betriebliche Altersvorsorge (+21% AG-Zuschuss)

- Anwesenheitsbonus

- Urlaubsgeld als Erholungsbeihilfe

- Weihnachtsgeld in Form von Gutscheinen für unser firmeneigenes Recknitztal-Hotel Marlow

- flexible Arbeitszeiten zur Vereinbarkeit von Beruf und Familie

- ganzjähriges und unbefristetes Arbeitsverhältnis

- sichere, beständige Planung & Auslastung

- umfangreiche und systematische Einarbeitung

- angenehme, familiäre Arbeitsatmosphäre

- ständige Produktverbesserung & stetige Weiterentwicklung

- moderner Arbeitsplatz mit modernen Arbeitsmitteln

- kostenlose Getränkeversorgung

- firmeneigene, kostenfreie Parkplätze

Interesse? Wunderbar! - Wir freuen uns auf Ihre Bewerbung unter Angabe Ihrer Gehaltsvorstellungen und Ihres frühestmöglichen Eintrittstermins.

Bei der Auswahl von Bewerberinnen und Bewerbern legen wir Wert auf Chancengleichheit. Bei gleicher Eignung werden Bewerbungen von Menschen mit Behinderungen besonders berücksichtigt.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
