# Working Student - Commercial B2B (m/f/x)

Posted: 2026-08-20T14:30:13Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Ready to become part of the most important mission on this planet?

We are rebuy, pioneers in the reuse of electronics and media. and we are looking for you! Our mission: to make circular living accessible to all, one transaction at a time. By giving products a second chance, we reduce resource consumption and avoid unnecessary e-waste.

Our team of 500 comes from all corners of the world; we drive things forward collaboratively, take personal responsibility, value positive critical thinking, and persistently serve our customers and planet.

### The Role

We’re looking for a motivated and analytical **Working Student to join our B2B team.** This exciting opportunity involves assisting our B2B department, where analytical skills and a passion for working with numbers are highly valued. In this hands-on role, you will bridge the gap between commercial strategy, logistics, and finance. If you're eager to gain hands-on experience in an open-minded and flexible environment and contribute to our team's success, we encourage you to apply and become an integral part of our team.

Your analytical mindset and enthusiasm for numerical data will be instrumental in helping us achieve our goals. Join us and embark on a rewarding journey of professional development.

### **Key Responsibilities:**

-

**B2B Sourcing & Sales Support:** Drives daily operational vendor management, data preparation, and document organization for B2B teams

-

**Order Lifecycle:** Oversees order creation and closing procedures from start to finish

-

**Cross-Functional Liaison:** Supports key business interfaces across Accounting, Operations, and Commercial units throughout procurement

-

**Inventory & Logistics Coordination:** Tracks and manages goods flow between B2B partners and multiple warehouse locations

-

**Sustainable Sourcing:** Contributes to the development of a sustainable accessories product line

### Requirements:

-

Must be a student (Business Administration, Marketing, Economics, Finance or similar) based in Berlin

-

Basic knowledge of Excel/Google Sheets required

-

Strong analytical and problem-solving skills

-

Very good English speaking and writing skills

-

Ease of use with everyday AI tools (e.g., ChatGPT, Copilot) to enhance personal productivity and automate basic tasks

-

Highly organized and detail-oriented, can work autonomously

-

Passionate about sustainability and reducing electronic waste

### **Location:**

-

Berlin (We expect the working student to be in the office at least 2 days in a week).

-

Hybrid model

### **Purpose, a great company culture and incredible benefits - what to expect at rebuy:**

-

Work with a friendly team that is passionate about circularity and wants to make the world a little more sustainable, one transaction at a time.

-

Feel comfortable in an environment where independence and new ideas are welcome.

-

Benefit from flat hierarchies and the greatest possible transparency so that things don't take longer than they have to and you always feel well informed.

-

Enjoy our centrally located office in Berlin (Erkelenzdamm 11 - 13, 10999 Berlin).

-

Benefit from our family-friendly, flexible environment and paid child sick leave.

-

Bring your dog to the office: we love animals and want to cuddle yours, too!

-

Use employee discounts on [rebuy.de](https://www.rebuy.de/), sustainable products at [Futurebens](https://www.futurebens.co/), offers for sustainable micro-mobility and massages directly in our office.

-

Have fun at our legendary team and company events.

-

Use our mental health offers as part of a cooperation with [Nilo](https://nilohealth.com).

-

Take care of your work-life balance with 20 vacation days.

-

Stay active with our own gym located directly in the building, making it easy to fit workouts into your daily routine.

-

Benefit from an on-site daycare in the building, supporting a truly family friendly and flexible working environment.

*At rebuy all people are welcome and supported! We would like to talk, regardless of age, disability, national and social origin, skin color, religion, gender identity and sexual orientation. Just be who you are.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
