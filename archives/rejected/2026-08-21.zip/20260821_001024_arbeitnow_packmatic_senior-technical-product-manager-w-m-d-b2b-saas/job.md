# (Senior) Technical Product Manager (w/m/d) - B2B Saas I Berlin (hybrid)

Posted: 2026-08-20T14:24:38Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

*Wir digitalisieren eine der größten und am stärksten regulierten Branchen Europas.*

*Die Verpackungsindustrie hat ein Marktvolumen von mehreren hundert Milliarden Euro und steht aufgrund neuer Vorschriften wie PPWR, EUDR, EPR und CSRD unter enormem Handlungsdruck.*

*Mit **Packa** haben wir die erste durchgängige SaaS-Plattform für intelligentes Verpackungsmanagement entwickelt – stark nachgefragt, hervorragend finanziert und rasant wachsend.*

**Was dich bei Packa erwartet**

- **Kreative Freiheit:** Du arbeitest direkt mit dem Führungsteam von Packa zusammen – von Anfang an mit echter Gestaltungsfreiheit.

- **Eigenverantwortung:** Du wirst Teil eines hochmotivierten, vielfältigen und erfolgreichen Teams sein und von Tag eins ein hohes Maß an Freiheit und Verantwortung haben.

- **Hybrides Arbeiten:** Du arbeitest in einem großartigen Büro in Berlin-Prenzlauer Berg.

- **Führung:** Du arbeitest in einem Unternehmen mit einer inspirierenden Vision, das von einem erfahrenen Gründungsteam geleitet und von führenden Investoren unterstützt wird.

- **Wertschätzung und Engagement:** Wir glauben an faire Vergütung und bieten dir einen klaren Wachstumspfad mit echter Entwicklungsmöglichkeit.

**Deine Aufgaben**

Als Technical Product Manager (Integrations & Data) verantwortest du die Integrationsschicht und das Datenrückgrat von Packa — von Kundensystemen wie ERPs und PIMs bis zum internen Data Warehouse. Du arbeitest eng mit cross-funktionalen Teams zusammen und gestaltest Lösungen, die echten Kundennutzen schaffen.

- Du verantwortest Roadmap und Strategie für unser **Integrations & Data Domain** — von der mehrjährigen Vision bis zu quartalsweisen OKRs.

- Du gestaltest unser **Integrations-Ökosystem auf funktionaler Ebene** — wie Packas Datenflüsse in Kundensysteme (ERPs, PIMs etc.) reichen, inklusive Multitena ncy sowie Rollen- und Berechtigungslogik.

- Du übersetzt **Integrationsanforderungen unserer Kunden** in klare Produktspezifikationen, User Stories und Akzeptanzkriterien — und stimmst die architektonische Richtung mit den Engineering Leads ab.

- Du verantwortest unser **internes Data Backbone** — Warehouse-Design, Ingestion-Pipelines, Datenverträge zwischen Produkt und Analytics sowie Freshness- und Quality-SLOs.

- Du nimmst an **Integrations- und Scoping-Calls** mit Kunden-IT- und Procurement-Teams teil — scopst Integrationen während Sales und Onboarding mit, verteidigst Machbarkeit und challengst Anforderungen, die nicht skalieren.

- Du **definierst und trackst KPIs für unseren Integrationserfolg** — Time-to-Go-Live, Fehlerquoten, Connector-Adoption, Datenqualität und Partner-Zufriedenheit.

- Du verantwortest die **Developer und Partner Experience** — API-Design-Prinzipien, Versionierungsstrategie, öffentliche Dokumentation und Sandbox-Umgebungen.

- Du arbeitest eng mit **Customer Success rund um den Integrationsworkflow** zusammen — Scoping-Templates, Handover-Playbooks, Post-Launch-Monitoring und Eskalationspfade.

- Du stimmst dich mit dem **Regulatory PM und dem Workflows PM** zu gemeinsamen Datenanforderungen ab — z. B. Material- und Recyclebarkeitsdaten für PPWR-Flows sowie Übergaben für Workflow-Automatisierung.

**Was du mitbringst**

- 3–5 Jahre Berufserfahrung im Produktmanagement, davon mindestens **2 Jahre mit End-to-End-Verantwortung für Integrations-, API- oder Daten-Produkte**.

- Nachweisliche Erfahrung im **Shipping kundenseitiger Integrationen** über mindestens einen vollen Lebenszyklus.

- **Starke technische Fluency** — du liest API-Dokumentationen flüssig, schreibst SQL, verstehst Datenmodellierung und kannst die Lösung eines Engineers fundiert challengen.

- Vertraut mit **B2B-Enterprise-Integrationsmustern** — inkl. Authentifizierung, Datensynchronisationsmodellen, Batch- vs. Event-getriebenen Flows.

- Solides Verständnis des **modern Data Stacks** *(konkrete Technologien — TBD mit Jonas)*.

- **Fließende Deutsch- und Englischkenntnisse** in Wort und Schrift.

**Bonus:**

- Direkte Erfahrung mit **ERP-Ökosystemen** (SAP S/4 HANA, MS Dynamics 365, NetSuite) — Partnerprogramme, zertifizierte Connectors o. Ä.

- **Engineering Background** — CS-Studium, Ex-Developer oder ausgeprägtes Coding-Hobby.

- Erfahrung mit **KI/Automation in Workflows** — LLM-Agents, Document Parsing, automatisierte Order/Quote-Verarbeitung.

- **Regulatory Background** — Erfahrung in oder mit regulierten B2B-Domains.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
