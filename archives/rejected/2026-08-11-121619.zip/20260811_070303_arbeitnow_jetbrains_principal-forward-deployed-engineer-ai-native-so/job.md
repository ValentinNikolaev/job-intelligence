# Principal Forward Deployed Engineer – AI-Native Software Development

Posted: 2026-08-10T20:55:11Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

At JetBrains, code is our passion. Ever since we started, back in 2000, we have strived to make the strongest, most effective developer tools on earth. By automating routine checks and corrections, our tools speed up production, freeing developers to grow, discover, and create.

We just unveiled JetBrains Central, a platform for agent-driven software development that connects tools, agents, and infrastructure. It enables automated AI workflows to run, be monitored, and be managed across teams – with clear visibility into results, costs, and performance.

JetBrains Central provides three core capabilities:
**Governance and control: **Policy enforcement, identity and access management, observability, auditability, and cost attribution for agent-driven work. Some of these functionalities are already available via the [JetBrains Central Console](http://console.jetbrains.cloud/).
**Agent execution infrastructure: **Cloud agent runtimes and computation provisioning that allow agents to run reliably across development environments.
**Agent optimization and context:** Shared semantic context across repositories and projects, enabling agents to access relevant knowledge, and task routing to the most appropriate models or tools.

Inside the Professional Services department, we are building a team of Forward Deployed Engineers to help our customers adopt AI-native development with JetBrains Central and enable JetBrains consulting partners to transform their customers’ AI-native software development lifecycle.

## **About the role**

As a Principal Forward Deployed Engineer, you will work directly with early adopter customers to deploy JetBrains Central platform into complex enterprise environments and help them move from experimental AI usage to governed, scalable AI-native development.

You will act as a trusted advisor to customer engineering teams and consulting partners, while also mentoring other Forward Deployed Engineers and helping with complex deployments. In this role, you will help establish best practices for enterprise AI adoption and influence how organizations implement AI-driven software development.

This role is often a strong fit for engineers who have previously served as Principal or Staff Engineers, Heads of Engineering, CTOs, or Solutions Architects and who enjoy working directly with customers while staying deeply involved with complex technical systems.

This role combines consulting, architecture, and hands-on engineering. Your work in the field will directly influence how our platform evolves and how enterprises adopt AI-driven development.

You will work directly with the world’s most innovative companies — our client base includes 420 of the Fortune 500 — ensuring they maximize the value of their JetBrains investments.

## **What you’ll do**

- Deploy JetBrains Central platform into enterprise development environments, CI/CD systems, and internal developer platforms.

- Help organizations transition from ad-hoc AI experimentation to governed AI-native development workflows.

- Implement enterprise AI governance, including security policies, access management, and data privacy controls.

- Enable observability for AI-driven development to help organizations understand their AI usage and its impact on productivity, as well as their code-generation patterns.

- Design sustainable AI adoption strategies, including usage controls and cost visibility across multiple model providers.

- Integrate our cloud-based agent execution layer, allowing AI agents to run securely and at scale.

- Collaborate closely with JetBrains product teams to shape the platform based on real-world deployments and customer feedback.

- Create delivery frameworks and train JetBrains partners to deliver the desired scope of service.

- Mentor and support other Forward Deployed Engineers, sharing architectural expertise and helping to scale the team’s deployment practices.

## **You will thrive in this role if you are**

- A consultant at heart who can communicate effectively with both engineers and technical leadership.

- Able to see the whole picture of the software development lifecycle across developer tools, infrastructure, APIs, and cloud systems.

- Experienced at integrating complex software systems into enterprise environments.

- Curious about the future of AI agents and AI-native software development.

- Comfortable working with early adopters and overcoming ambiguous technical challenges.

- Motivated to mentor other engineers and contribute to building a new technical discipline.

## **What you will bring**

- Experience in software-related projects, ideally in a customer-facing or consulting environment.

- Familiarity with Java or Python.

- Experience building or integrating developer platforms, infrastructure systems, or software solutions.

- Familiarity with modern development workflows (CI/CD, developer environments, internal developer platforms, etc.).

- Experience working directly with customers or technical stakeholders.

- Strong problem-solving skills and the ability to operate in fast-evolving technical environments.

- Ability and desire to travel to meet customers.

## **These would be a plus, but are not blockers**

- Experience with industry-specific solutions (fintech, telco, retail, etc.)

- Experience with AI/LLM platforms, agent frameworks, or AI-assisted development tools.
Experience in solutions engineering, consulting, or forward-deployed engineering roles.

- Familiarity with the JetBrains ecosystem or developer productivity tooling.

#LI-KP1

**We are an equal opportunity employer**

We know great ideas can come from anyone, anywhere. That’s why we do our best to create an open and inclusive workplace – one that welcomes everyone regardless of their background, identity, religion, age, accessibility needs, or orientation.

*We process the data provided in your job application in accordance with the [Recruitment Privacy Policy.](https://www.jetbrains.com/legal/docs/privacy/privacy-recruitment/)*

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
