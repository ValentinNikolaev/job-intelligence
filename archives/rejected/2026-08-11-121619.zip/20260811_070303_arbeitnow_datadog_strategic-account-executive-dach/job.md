# Strategic Account Executive (DACH)

Posted: 2026-08-11T05:55:06Z

## Rejection

- Category: tech_stack
- Reason: role does not mention Go/Golang or PHP

Our Strategic Account Executives target and close new business with Datadog’s largest, most strategic customers and prospects. In this role you’ll be focused on uncovering the pain points organizations face as they operate in or migrate to a cloud environment at scale as well as delivering the appropriate Datadog solution.

*At Datadog, we place value in our office culture - the relationships and collaboration it builds and the creativity it brings to the table. We operate as a hybrid workplace to ensure our Datadogs can create a work-life harmony that best fits them.*

**What You’ll Do:**

- Prospect into large Fortune 1000 companies while running an efficient sales process

- Maintain, build and own specific relationship maps for your territory including existing relationships and aspirational contacts

- Develop a deep comprehension of customer's business

- Negotiate favorable pricing and business terms with large commercial enterprises by selling value and ROI

- Handle existing customer expectations while expanding reach and depth into assigned territory

- Demonstrate resourcefulness when faced with challenges that defy easy solution

- Have intuitive sense of necessary steps to close business and gain customer validation

- Identify robust set of business drivers behind all opportunities

- Ensure high forecasting accuracy and consistency

**Who You Are: **

- Someone with 5+ years closing experience (mix of field selling within mid-market and enterprise)

- Driven and have met/exceeded direct sales goals of 1M+ and operated with an average deal size of $100k+

- Able to demonstrate methodology to prospect and build pipeline on your own

- Experienced in working for an innovative tech company (SaaS, IT infrastructure or similar preferred)

- Experienced in selling into large Fortune 1000 companies with the ability to win new logos

- Role requires regular travel to client sites, within your area and other regions, using various modes of transportation (car, train, air), depending on business needs.

*Datadog values people from all walks of life. We understand not everyone will meet all the above qualifications on day one. That's okay. If you’re passionate about technology and want to grow your skills, we encourage you to apply.*

**Benefits and Growth: **

- High income earning opportunities based on self performance

- New hire stock equity (RSU) and employee stock purchase plan (ESPP)

- Continuous professional development, product training, and career pathing

- Sales training in MEDDIC and Command of the Message

- Intra-departmental mentor and buddy program for in-house networking

- An inclusive company culture, opportunity to join our Community Guilds

- Generous and competitive medical benefits package

- Retirement savings match

- Pet adoption and insurance program

*Benefits and Growth listed above may vary based on the country of your employment and the nature of your employment with Datadog*

#LI-AK2

#LI-Remote This is a remote position

#LI-Remote

**About Datadog: **

Datadog is the leading observability and security platform for the AI era, providing businesses with unified visibility across the technology stack to manage complexity at scale. It brings applications, infrastructure, data, models, and security into one place, using AI to detect and resolve issues before they impact customers. Trusted globally by Fortune 500 companies and high-growth AI leaders, Datadog enables businesses to move faster with clarity and confidence. Learn more about #DatadogLife on [Instagram](https://www.instagram.com/datadoghq/?hl=en), [LinkedIn,](https://www.linkedin.com/company/datadog) and [Datadog Learning Center. ](https://learn.datadoghq.com/)

**Equal Opportunity at Datadog:**

Datadog is proud to offer [equal employment opportunity](https://www.eeoc.gov/sites/default/files/2023-06/22-088_EEOC_KnowYourRights6.12ScreenRdr.pdf) to everyone regardless of race, color, ancestry, religion, sex, national origin, sexual orientation, age, citizenship, marital status, disability, gender identity, veteran status, and other characteristics protected by law. We also consider qualified applicants regardless of criminal histories, consistent with legal requirements. Here are our [Candidate Legal Notices](https://www.datadoghq.com/legal/candidate-legal-notices/) for your reference.

Datadog endeavors to make our Careers Page accessible to all users. If you would like to contact us regarding the accessibility of our website or need assistance completing the application process, please complete [this form](https://docs.google.com/forms/d/e/1FAIpQLSeoJeduEZ2NdZF_65uZmWUrCM-zee7yADXX1s6Xr9zAGq8iKA/viewform). This form is for accommodation requests only and cannot be used to inquire about the status of applications.

**Privacy and AI Guidelines:**

Any information you submit to Datadog as part of your application will be processed in accordance with Datadog’s [Applicant and Candidate Privacy Notice](https://www.datadoghq.com/legal/applicant-candidate-privacy/). For information on our AI policy, please visit [Interviewing at Datadog AI Guidelines](https://www.datadoghq.com/legal/interviewing-at-datadog-ai-guidelines/).

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
