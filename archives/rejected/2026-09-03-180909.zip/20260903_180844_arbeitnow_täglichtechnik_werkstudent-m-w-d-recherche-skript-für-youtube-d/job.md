# Werkstudent (m/w/d): Recherche & Skript für YouTube-Dokus

Posted: 2026-09-03T13:00:32Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Du studierst Journalismus und verbringst deine Abende auf YouTube? Gut. Genau dich suche ich.

Ich betreibe TäglichTechnik, einen YouTube-Kanal für Tech-Dokus. Ich nehme große Tech-Themen auseinander und erzähle die Geschichte dahinter.

Dafür suche ich niemanden, der nur gut recherchieren kann. Ich suche jemanden, der Zusammenhänge versteht, komplexe Dinge durchdenkt und daraus eine Story schreibt, die packt. Eine Story, die einfach zu verstehen ist, nahbar, emotional, und die Neugier weckt.Neben dem Studium, flexibel, remote.

## Aufgaben

- Du recherchierst Themen tief und sauber, von der ersten Quelle bis zum überraschenden Detail. Alles, was du im Studium über saubere Recherche lernst, wendest du hier direkt an

- Du schreibst aus der Recherche das Skript, in der Stimme des Kanals: kurze Sätze mit Rhythmus, konkrete Bilder statt Adjektive, menschlich, wie ein Freund, der zu viel gelesen hat. Kein Marketing-Sprech, keine Floskeln

- Du baust Spannung, statt Geschichte nachzuerzählen. Du konstruierst die Story und machst es emotional

- Du denkst beim Schreiben mit, wie man das später visuell zeigt. Schau dir die Siemens-Doku oder so an, dann weißt du, wohin die Reise geht

- Ich gebe dir Thema, Kernfrage und Richtung vor, du machst daraus die Story

## Qualifikation

- Du studierst Journalismus, Medien oder etwas Vergleichbares

- Du kannst schreiben. Nicht nur korrekt, sondern mit Rhythmus und Gefühl für Story

- Du verstehst, wie YouTube tickt (Hook, Pacing, Watchtime)

- Du hast Lust, dich in komplexe Tech-Themen reinzudenken und sie einfach zu erklären

- Du arbeitest selbstständig und kommst proaktiv mit Ideen

- Muss: Lernbereitschaft und klare Kommunikation

- Pluspunkt: Du denkst visuell mit oder hast schon für YouTube geschrieben

## Benefits

- Echte Praxis fürs Portfolio: veröffentlichte Dokus mit deinem Skript, gesehen von zehntausenden Menschen

- Flexibles Arbeiten von überall, ob Bib, Café oder Strand. Die Stunden passen sich deinem Stundenplan an, nicht umgekehrt

- Ein klares System aus Skills und Frameworks, mit dem du sofort in der Stimme des Kanals schreiben kannst

- Direkter Einblick, wie ein wachsender YouTube-Kanal wirklich funktioniert

- Schnelle Entscheidungen, keine Abstimmungsschleifen

- Ein Offsite in Österreich alle 6 Monate, gemeinsam brainstormen und arbeiten

🔥 Bock drauf? Schick mir eine Nachricht mit einer Arbeitsprobe. Irgendetwas, das du geschrieben hast: Seminararbeit, Blogpost, egal. Eine Schreibprobe sagt mehr als ein schöner CV. Und erzähl mir auch, warum du Youtube und gerade TäglichTechnik spannend findest. Ich freu mich auf dich! 🚀

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
