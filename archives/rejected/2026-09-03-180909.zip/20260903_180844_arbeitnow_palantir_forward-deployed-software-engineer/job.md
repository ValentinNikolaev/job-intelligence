# Forward Deployed Software Engineer

Posted: 2026-09-03T14:04:29Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**A World-Changing Company**

Palantir builds the world’s leading software for data-driven decisions and operations. By bringing the right data to the people who need it, our platforms empower our partners to develop lifesaving drugs, forecast supply chain disruptions, locate missing children, and more.

**The Role**

Forward Deployed Software Engineers (FDSEs) work directly with customers to quickly understand their greatest problems and design and implement solutions to use data against them. Our customers rely on Palantir’s platforms for some of their most critical operations, and projects often start with an open ended question like “Why are we delaying so many flights?” or “How can we better identify instances of money laundering?” As an FDSE, you’ll apply your problem solving ability, creativity, and technical skills to help organizations use their data to drive a real impact in the world. You’ll have the opportunity to gain rare insight into and contribute to some of the world’s most important industries and institutions.

As an FDSE, your responsibilities look similar to those of a startup CTO: you’ll work in small teams with minimal supervision and own end-to-end execution of high stakes projects. Your day might span discussing architecture with fellow engineers, wrangling massive-scale data, coding a custom web app, speaking with customer executives, or establishing strategy for your team.

Whether you aspire to be an entrepreneur or an engineering leader, we believe Palantir is the best place — with the best colleagues — to learn how. You’ll learn how to unpack a problem and understand the costs and consequences of its solution. You’ll learn new technologies and languages, and even develop them yourself. You’ll work autonomously and make decisions independently, within a community that will support and challenge you as you grow and develop.

**Core Responsibilities**

- Impact: We take on meaningful and challenging projects that change the world for the better.

- Ownership: We see projects through from beginning to end, working through any obstacles we may encounter.

- Collaboration: We work internally with people from a variety of backgrounds — such as other FDSEs, product teams, and Deployment Strategists. We also work externally with our customers, often on site, to understand and solve their problems.

- Trust: We trust each other to effectively manage time and priorities and give people the space to think for themselves.

- Growth: We encourage ourselves and our peers to seek new challenges and opportunities for growth, as well as find new ways to innovate and share knowledge.

- Learning: We often face entirely novel problems where we need to pick up a lot of new knowledge and learn how to use it to make progress. We believe experiential learning is one of the best teachers.

**What We Value**

- Strong engineering background, preferred in fields such as Computer Science, Mathematics, Software Engineering, Physics, and Data Science.

- A highly analytical mindset and eagerness to solve technical problems with data structures, storage systems, cloud infrastructure, front-end frameworks, and other technical tools.

- Experience or interest in working with and using large scale data to solve valuable business problems.

- Strong coder with demonstrated proficiency in programming languages such as Python, Java, C++, TypeScript/JavaScript, or similar.

- Demonstrated ability to collaborate effectively in teams of technical and non-technical individuals, and comfortable working in a rapidly changing environment with dynamic objectives and iteration with users.

- Ability to continuously learn, work independently, and make decisions with minimal supervision.

- Willingness and interest to travel as needed to client sites. Ability to travel 25-50% preferred, but may vary by team and location.

**What We Require**

- Fluency in German

- Security clearance or the ability to obtain a clearance

**Life at Palantir**

We want every Palantirian to achieve their best outcomes, that’s why we celebrate individuals’ strengths, skills, and interests, from your first interview to your longterm growth, rather than rely on traditional career ladders. Paying attention to the needs of our community enables us to optimize our opportunities to grow and helps ensure many pathways to success at Palantir. Promoting health and well-being across all areas of Palantirians’ lives is just one of the ways we’re investing in our community. Learn more at [Life at Palantir](https://www.palantir.com/careers/life-at-palantir/) and note that our offerings may vary by region.

In keeping consistent with Palantir’s values and culture, we believe employees are “better together” and in-person work affords the opportunity for more creative outcomes. Therefore, we encourage employees to work from our offices to foster connectivity and innovation. Many teams do offer hybrid options (WFH a day or two a week), allowing our employees to strike the right trade-off for their personal productivity. Based on business need, there are a few roles that allow for “Remote” work on an exceptional basis. If you are applying for one of these roles, you must work from the city and or country in which you are employed. If the posting is specified as Onsite, you are required to work from an office.

If you want to empower the world's most important institutions, you belong here. Palantir values excellence regardless of background. We are committed to making the application and hiring process accessible to everyone and will provide a reasonable accommodation for those living with a disability. If you need an accommodation for the application or hiring process*, *please and let us know how we can help.

*Please note that you will never be asked to submit a payment or share financial information to participate in our interview process. If you suspect that you've been contacted by a scammer, we recommend you cease all communication with the individual and consider reporting them to the relevant authorities, such as the US [FBI Internet Crime Complaint Center (IC3)](https://www.ic3.gov/).*

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
