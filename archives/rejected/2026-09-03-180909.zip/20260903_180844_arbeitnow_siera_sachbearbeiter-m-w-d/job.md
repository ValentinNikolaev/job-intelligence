# Sachbearbeiter (m/w/d)

Posted: 2026-09-03T13:00:32Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Über SIERA

SIERA gestaltet Zukunft mit verantwortungsvoller Ingenieurleistung, innovativen Ideen und internationaler Zusammenarbeit. Als Unternehmen für Umweltingenieurwesen und Beratung entwickeln wir nachhaltige Lösungen für Klima, Wasser, Umwelt und Infrastruktur.

An über 33 Standorten in Deutschland arbeiten mehr als 800 Mitarbeitende über vier Kontinente hinweg an Projekten mit langfristiger Wirkung.

„Engineering for a Better Tomorrow“ – gemeinsam schaffen wir Fortschritt für Umwelt, Wirtschaft und Gesellschaft.

Über die Position

Für unseren Bereich Versicherungsvermittlung suchen wir Unterstützung in der Administration nach § 34d GewO.

Sie sorgen für eine strukturierte Bearbeitung, vollständige Dokumentation und zuverlässige Kommunikation mit Versicherungsunternehmen, Kunden und internen Ansprechpartnern.

Ihre Aufgaben

- Verwaltung und Pflege von Versicherungsunterlagen und Vertragsdaten

- Unterstützung bei der Bearbeitung von Anträgen, Änderungen und Verträgen

- Sicherstellung einer vollständigen und ordnungsgemäßen Dokumentation

- Kommunikation mit Versicherungsunternehmen und internen Ansprechpartnern

- Pflege der relevanten Daten in unseren Systemen

- Unterstützung bei organisatorischen und administrativen Aufgaben im Bereich § 34d GewO

Ihr Profil

- IHK-Prüfungszeugnis über die erfolgreich abgelegte Sachkundeprüfung für Versicherungsvermittlung gemäß § 34d GewO

- Erfahrung in der Versicherungsvermittlung, Versicherungsbranche oder in der Administration

- Sorgfältige, strukturierte und verantwortungsbewusste Arbeitsweise

- Sicherer Umgang mit vertraulichen Daten sowie regulatorischen Anforderungen

- Sicherer Umgang mit digitalen Anwendungen und Microsoft 365

- Sehr gute Deutschkenntnisse; Englischkenntnisse sind von Vorteil

- Serviceorientierung sowie Freude an einer zuverlässigen Zusammenarbeit

Ihr Arbeitsplatz bei SIERA

Unser Standort in Nürnberg verbindet Tradition mit Fortschritt: Sie arbeiten in besonderen, traditionsreichen Räumlichkeiten, die zugleich modern, zeitgemäß und auf einem hohen digitalen Niveau ausgestattet sind.

Freuen Sie sich auf ein Umfeld, in dem Zusammenarbeit, Kreativität und neue Ideen ihren Platz haben. Wir freuen uns auf Ihre Bewerbung und darauf, SIERA gemeinsam mit Ihnen weiterzuentwickeln.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
