# Personalsachbearbeiter (m/w/d) Arbeitnehmerüberlassung

Posted: 2026-09-03T11:30:53Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Wir sind ein etabliertes Unternehmen der Arbeitnehmerüberlassung (AÜ) und seit vielen Jahren erfolgreich in der Branche Zugbau tätig. Wir überlassen qualifizierte Fachkräfte – u. a. Elektriker, Schlosser und Schweißer – an unsere Kunden im gesamten Bundesgebiet. Zur Verstärkung unseres Teams suchen wir ab sofort eine erfahrene Person für die Verwaltung.

## Aufgaben

- Vorbereitung und Erstellung von Rahmenverträgen mit unseren Kunden

- Erstellung von Einsatzvereinbarungen für unsere überlassenen Mitarbeiter

- Allgemeine administrative und organisatorische Bürotätigkeiten

- Ansprechpartner/in für Kunden und Mitarbeiter in vertraglichen und organisatorischen Fragen

- Unterstützung bei arbeitsrechtlichen Fragestellungen im Tagesgeschäft

## Qualifikation

- Erfahrung in der Verwaltung, im Bereich Arbeitnehmerüberlassung

- Kenntnisse in der Erstellung von Rahmenverträgen und Einsatzvereinbarungen

- Grundkenntnisse im ArbeitsrechtSicherer

- Umgang mit allgemeinen Büro- und Verwaltungsaufgaben

- Sehr gute Deutschkenntnisse (mindestens C1)

- Polnischkenntnisse von Vorteil

- Selbstständige, sorgfältige und strukturierte Arbeitsweise

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
