# Test Manager Communication Management (m/w/d)

Posted: 2026-09-03T13:00:32Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**Driving Digital Technologies.**

Den digitalen Wandel begleiten und aktiv mitgestalten – unsere Mission bei citema. Mit unseren innovativen Ansätzen beraten und unterstützen wir unsere Kunden in den Technologiefeldern Cyber Security, KI und Blockchain. Ebenso gehört die Umsetzung system- und sicherheitsrelevanter Softwareprojekte zu unserem Portfolio. So verbinden wir die neuen Technologien mit der klassischen Softwarewelt. Bei uns wird ein professionelles, kollegiales Miteinander mit Du-Kultur gelebt, denn unser exzellenter Teamgeist und die offene Kommunikation sind der Spirit unseres Unternehmens. Als sehr erfolgreiches und kontinuierlich wachsendes Unternehmen mit solider Basis, bieten wir Dir vielfältige Möglichkeiten in einem hochinteressanten, dynamischen Umfeld. Werde Teil unseres Erfolgs, bring Deine Expertise mit ein und gestalte gemeinsam mit uns die Zukunft verantwortungsvoll.

## Aufgaben

**Deine Mission**

Wir suchen Dich als **Test Manager Communication Management (m/w/d)** am Standort **Berlin (hybrid)**.

Deine Aufgaben dabei sind:

- Du übernimmst die strategische Planung, Steuerung und Überwachung aller Testaktivitäten über den gesamten Software-Lebenszyklus in regulierten Projekten

- Du verantwortest die Erstellung und kontinuierliche Pflege von übergeordneten Testkonzepten, Testplänen, Testfällen sowie aussagekräftigen Testberichten

- Du stellst das anforderungsbasierte Testen sicher und gewährleistest die lückenlose Rückverfolgbarkeit (Traceability) zwischen Anforderungen, Testfällen und den Ergebnissen

- Du bildest die zentrale Schnittstelle zur Projektleitung, dem Entwicklungsteam sowie weiteren Stakeholdern (wie QS und Certification) und stellst die Einhaltung der Vorgaben aus dem Änderungs- und Konfigurationsmanagement sicher

## Qualifikation

**Dein Profil**

Folgende Kenntnisse und Fähigkeiten solltest Du auf jeden Fall mitbringen:

- Du bringst ein erfolgreich abgeschlossenes Studium der Informatik, Elektrotechnik, Nachrichtentechnik oder eine vergleichbare Qualifikation sowie mehrjährige Erfahrung im Softwaretestmanagement im sicherheitskritischen Umfeld mit

- Du besitzt fundierte Kenntnisse im Standard DO-178C (insbesondere DAL-D), ein tiefes Verständnis für luftfahrtspezifische Dokumentationsanforderungen sowie eine strukturierte, qualitätsorientierte Arbeitsweise

- Du bist absolut sicher im Umgang mit gängigen Test- und Requirements-Management-Werkzeugen wie Jama, Jira, Xray und Pytest

- Du hast ein sicheres Know-how im Linux Network Stack, in Layer 3 Routing-Protokollen sowie in gängigen Sicherheitsfunktionen und -architekturen

- Du zeichnest dich durch eine ausgesprochene Kommunikations- und Abstimmungsstärke für die zielgerichtete Zusammenarbeit mit interdisziplinären Teams aus

- Für die effektive Kommunikation im Projektumfeld sowie mit unseren deutschsprachigen Kunden ist ein sehr gutes mündliches und schriftliches Deutsch erforderlich

## Benefits

**Das bieten wir Dir**

Wir sind der Überzeugung, dass folgende Rahmenbedingungen die besten Voraussetzungen für Effizienz und kreative Lösungsfindungen bieten:

- Aktives Mitwirken an innovativen Zukunftstechnologien

- Flexibles New-Work-Modell mit hybriden Arbeitsmöglichkeiten

- Unbefristeter Arbeitsvertrag

- Givve-Card als steuerfreier Unternehmensbenefit

- Maximale Entscheidungs- und Gestaltungsspielräume

- Individuelle Karriereplanung und Entwicklungsperspektiven

- Wissenstransfer und Synergieeffekte durch ein starkes Team

- Technologische Vielfalt mit spannenden Einblicken in sicherheitsrelevante Systeme

Und: Herausforderungen, die wirklich Spaß machen!

Ready to shape the future?

Drive digital technologies with us!

**Wir freuen uns auf Deine Bewerbung!**

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
