# Senior Data Analyst - CRM (m/f/d)

Posted: 2026-09-03T13:45:29Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

At Flix, we offer a dynamic work environment with competitive pay, strong growth opportunities, and a tech-driven approach to making travel more accessible, sustainable, and affordable. 

As a** Senior Data Analyst (m/f/d),** you will join our global CRM team. This is an important role for CRM at Flix as we expand our capabilities, redefine our communication strategy and constantly optimize for maximum growth, as well as scalability and efficiency. We support global market growth with our marketing activities to increase repeated purchases and prevent churn. We always aim for cutting-edge technologies and a high level of innovation. By joining our team, you will be a crucial part of driving the team forward, developing our brands and customer communication throughout the globe.

**About the Role**

- Own CRM analytics and reporting across 45+ markets, delivering clear visibility into performance, customer behavior, and commercial impact

- Build and maintain Power BI dashboards providing real-time tracking of CRM performance, targets, and business trends

- Deliver actionable insights on campaign performance, drivers of customer behavior, value-generating segments, and cross-market differences

- Develop scalable, automated reporting solutions alongside deep-dive analyses and ad hoc business investigations

- Monitor and optimize key CRM KPIs (engagement, conversion, retention, reactivation, communication effectiveness) and customer lifecycle performance

- Partner with CRM, data, and product teams to improve segmentation, personalization, experimentation, tracking quality, and data reliability

- Evaluate A/B tests and proactively identify trends, anomalies, risks, and opportunities, presenting clear recommendations to senior stakeholders

**About You**

- 5+ years of experience in data analytics or BI, ideally within CRM, marketing, or e-commerce environments

- Proven track record of building dashboards and automated reporting solutions for non-technical stakeholders

- Strong SQL expertise (CTEs, window functions, multi-table joins) in a modern cloud data warehouse, preferably Snowflake

- Advanced Power BI skills including data modeling, DAX, and best-practice dashboard design and visualization

- Solid understanding of marketing and CRM KPIs (conversion, engagement, attribution, customer lifetime value)

- Experience working cross-functionally with product, engineering, and marketing/CRM teams; familiarity with marketing automation tools (e.g., Braze is a plus)

- Strong data storytelling, statistical literacy (e.g., significance testing), and a structured, detail-oriented, and autonomous working style

- Proficiency in English

We recognize that everyone carries a unique set of valuable skills and experiences. If you think you could have an impact even though you don't meet 100% of the requirements, we still encourage you to apply. We want to hear from you! 

**What We Offer**

- **Travel perks**: 12 free Flix vouchers + 12 discount vouchers for friends & family.

- **Work from (M)Anywhere**: Depending on your role, work from another location for up to 60 days per year.

- **Hybrid work model**: We are an office-first company, but we offer flexibility to balance work and life.

- **Wellbeing support**: Access confidential 1:1 counselling, courses, and stress management for yourself and up to four family members.

- **Learning & Development**: Take advantage of language classes, training courses, and expert-led sessions to grow your skills.

- **Mentoring Program**: Connect with experienced colleagues to gain insights and accelerate your career.

To view more local benefits specific to each office location, please check out this link: [Locations - Flix Career](https://flix.careers/locations/)

**Why Join Flix?**

At Flix, you'll find teams that rally together to overcome challenges and spark creativity. We believe in ownership culture - giving you the freedom to take initiative, make an impact, and shape your own career path.
As we continue to expand across the globe, you can make a real difference in how we work.

If you're ready to grow and lead your journey, Flix is the place for you!

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
