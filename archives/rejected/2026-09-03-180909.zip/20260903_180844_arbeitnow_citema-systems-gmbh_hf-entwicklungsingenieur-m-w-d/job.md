# HF-Entwicklungsingenieur (m/w/d)

Posted: 2026-09-03T13:00:32Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**Driving Digital Technologies.**

Den digitalen Wandel begleiten und aktiv mitgestalten – unsere Mission bei citema. Mit unseren innovativen Ansätzen beraten und unterstützen wir unsere Kunden in den Technologiefeldern Cyber Security, KI und Blockchain. Ebenso gehört die Umsetzung system- und sicherheitsrelevanter Softwareprojekte zu unserem Portfolio. So verbinden wir die neuen Technologien mit der klassischen Softwarewelt. Bei uns wird ein professionelles, kollegiales Miteinander mit Du-Kultur gelebt, denn unser exzellenter Teamgeist und die offene Kommunikation sind der Spirit unseres Unternehmens. Als sehr erfolgreiches und kontinuierlich wachsendes Unternehmen mit solider Basis, bieten wir Dir vielfältige Möglichkeiten in einem hochinteressanten, dynamischen Umfeld. Werde Teil unseres Erfolgs, bring Deine Expertise mit ein und gestalte gemeinsam mit uns die Zukunft verantwortungsvoll.

## Aufgaben

**Deine Mission**

Wir suchen Dich als **HF-Entwicklungsingenieur (m/w/d)** am Standort **Stuttgart (hybrid)**.

Deine Aufgaben dabei sind:

- Entwicklung, Inbetriebnahme und Verifizierung von HF- und Analogelektronik-Baugruppen, insbesondere von Empfänger- und Senderzügen im Kleinsignalbereich für Funkkommunikationsgeräte

- Schaltungsentwicklung

- Recherche und Evaluierung von Komponenten

- Optimierung und Freigabe von Leiterplattenlayouts in Zusammenarbeit mit der Konstruktion

- Inbetriebnahme von Prototypen

- Durchführung HF-relevanter Tests und Analyse von Testergebnissen der Geräteintegration

## Qualifikation

**Dein Profil**

Folgende Kenntnisse und Fähigkeiten solltest Du auf jeden Fall mitbringen:

- Abgeschlossenes Studium der Elektro- oder Informationstechnik sowie tiefe Kenntnisse in der Hochfrequenztechnik

- Erfahrung in der Entwicklung von Kleinsignalpfaden

- Erfahrung in der Anwendung von AWR Microwave Office, CST Microwave Studio, CR-8000, LT-Spice

- Erfahrung Matlab und Python sind von Vorteil

- Fähigkeit zur Aufarbeitung und Präsentation von Ergebnissen

- Teamfähigkeit

- Für die effektive Kommunikation im Projektumfeld sowie mit unseren deutschsprachigen Kunden ist ein sehr gutes mündliches und schriftliches Deutsch erforderlich

## Benefits

**Das bieten wir Dir**

- Aktives Mitwirken an innovativen Zukunftstechnologien

- Flexibles New-Work-Modell mit hybriden Arbeitsmöglichkeiten

- Unbefristeter Arbeitsvertrag

- Givve-Card als steuerfreier Unternehmensbenefit

- Maximale Entscheidungs- und Gestaltungsspielräume

- Individuelle Karriereplanung und Entwicklungsperspektiven

- Wissenstransfer und Synergieeffekte durch ein starkes Team

- Technologische Vielfalt mit spannenden Einblicken in sicherheitsrelevante Systeme

Und: Herausforderungen, die wirklich Spaß machen!

Ready to shape the future?

Drive digital technologies with us!

**Wir freuen uns auf Deine Bewerbung.**

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
