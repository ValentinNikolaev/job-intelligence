# Projektleiter (m/w/d) R&D für maritime Kommunikationssysteme

Posted: 2026-09-03T13:00:32Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**Driving Digital Technologies.**

Den digitalen Wandel begleiten und aktiv mitgestalten – unsere Mission bei citema. Mit unseren innovativen Ansätzen beraten und unterstützen wir unsere Kunden in den Technologiefeldern Cyber Security, KI und Blockchain. Ebenso gehört die Umsetzung system- und sicherheitsrelevanter Softwareprojekte zu unserem Portfolio. So verbinden wir die neuen Technologien mit der klassischen Softwarewelt. Bei uns wird ein professionelles, kollegiales Miteinander mit Du-Kultur gelebt, denn unser exzellenter Teamgeist und die offene Kommunikation sind der Spirit unseres Unternehmens. Als sehr erfolgreiches und kontinuierlich wachsendes Unternehmen mit solider Basis, bieten wir Dir vielfältige Möglichkeiten in einem hochinteressanten, dynamischen Umfeld. Werde Teil unseres Erfolgs, bring Deine Expertise mit ein und gestalte gemeinsam mit uns die Zukunft verantwortungsvoll.

## Aufgaben

**Deine Mission**

Wir suchen Dich als **Projektleiter (m/w/d) R&D** für maritime Kommunikationssysteme am Standort **Kiel (hybrid)**.

Deine Aufgaben dabei sind:

- Übernahme der fachlichen Verantwortung für ein Entwicklungsprojekt

- Erstellung der Entwicklungsspezifikation in enger Abstimmung mit dem Applikationssegment

- Integration und Qualifizierung neuer Hard- und Softwarekomponenten in ein Gesamtsystem bis hin zur Fertigungsübergabe oder Kundenabnahme

- Unterstützung des Applikationssegments bei der Bewertung von Kundenspezifikationen und der Angebotserstellung

- Enge Zusammenarbeit mit dem organisatorischen Projektleiter und den Teilprojektleitern während des Entwicklungsprojekts

## Qualifikation

**Dein Profil**

Folgende Kenntnisse und Fähigkeiten solltest Du auf jeden Fall mitbringen:

- Abgeschlossenes Studium der Ingenieurwissenschaften

- Erfahrung im Design, in der Integration und in der Qualifizierung komplexer Systeme

- Erfahrung in der Erstellung verständlicher und vollständiger technischer Spezifikationen

- Fähigkeit, sich in komplexen technischen und organisatorischen Umgebungen zu bewegen

- Fähigkeit, Projektmitarbeitenden Aufgaben zur Umsetzung zu übertragen und deren Erfüllung zu kontrollieren

- Für die effektive Kommunikation im Projektumfeld sowie mit unseren deutschsprachigen Kunden ist ein sehr gutes mündliches und schriftliches Deutsch erforderlich

## Benefits

**Das bieten wir Dir**

Wir sind der Überzeugung, dass folgende Rahmenbedingungen die besten Voraussetzungen für Effizienz und kreative Lösungsfindungen bieten:

- Aktives Mitwirken an innovativen Zukunftstechnologien

- Flexibles New-Work-Modell mit hybriden Arbeitsmöglichkeiten

- Unbefristeter Arbeitsvertrag

- Givve-Card als steuerfreier Unternehmensbenefit

- Maximale Entscheidungs- und Gestaltungsspielräume

- Individuelle Karriereplanung und Entwicklungsperspektiven

- Wissenstransfer und Synergieeffekte durch ein starkes Team

- Technologische Vielfalt mit spannenden Einblicken in sicherheitsrelevante Systeme

Und: Herausforderungen, die wirklich Spaß machen!

Ready to shape the future?

Drive digital technologies with us!

**Wir freuen uns auf Deine Bewerbung.**

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
