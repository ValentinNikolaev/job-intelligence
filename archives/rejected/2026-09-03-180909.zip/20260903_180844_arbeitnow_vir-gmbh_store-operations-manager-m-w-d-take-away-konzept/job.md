# Store & Operations Manager (m/w/d) Take-Away Konzept

Posted: 2026-09-03T13:30:40Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

SHAKEROOM ist ein modernes Take-Away-Konzept für Protein Shakes – entwickelt für Menschen, die Wert auf Qualität, Geschmack und Effizienz legen. Hinter dem Konzept steht die VIR GmbH, eine Münchener Agentur mit Fokus auf den Aufbau und die Skalierung eigener Marken.

Für den operativen Betrieb suchen wir eine erfahrene Führungspersönlichkeit, die Store und Team strukturiert und mit echtem Verantwortungsbewusstsein führt. Sie übernehmen eine Schlüsselrolle in einem wachsenden Konzept – mit direktem Einfluss auf Qualität, Abläufe und Kundenerlebnis.

## Aufgaben

- Gesamtverantwortung für den täglichen Storebetrieb: Betriebsabläufe, Qualitätssicherung, Hygienestandards und Gästeerlebnis

- Personalverantwortung: Einsatzplanung, Einarbeitung und Führung des Store-Teams

- Einkauf und Warenwirtschaft: Bestellung und Verwaltung von Roh- und Verbrauchsmaterialien, Bestandskontrolle und Lieferantenmanagement

- Kontinuierliche Optimierung operativer Prozesse zur Steigerung von Effizienz, Kostenkontrolle und Qualität

- Enge Zusammenarbeit mit der Geschäftsführung bei der Weiterentwicklung und Skalierung des Konzepts

## Qualifikation

- Abgeschlossene Ausbildung in der Gastronomie, Hotellerie oder im Einzelhandel (z. B. Restaurantfachfrau/-mann, Hotelfachfrau/-mann, Kauffrau/-mann im Einzelhandel) oder vergleichbare Qualifikation

- (Mehrjährige) Berufserfahrung in der Gastronomie, Systemgastronomie oder im Foodservice-Bereich, idealerweise in leitender Funktion

- Nachgewiesene Erfahrung in der Führung und Motivation kleiner Teams sowie in der Personaleinsatzplanung

- Kenntnisse in Warenwirtschaft, Einkauf und Kostenkontrolle

- Strukturierte, eigenverantwortliche Arbeitsweise mit ausgeprägtem Qualitätsbewusstsein

- Belastbarkeit und Hands-on-Mentalität in einem dynamischen Arbeitsumfeld

- Sehr gute Deutschkenntnisse in Wort und Schrift; Englischkenntnisse von Vorteil

## Benefits

- Verantwortungsvolle Rolle mit echter Gestaltungsmöglichkeit in einem wachsenden Konzept

- Flache Hierarchien und direkte Zusammenarbeit mit der Geschäftsführung

- Attraktiver Standort in München

- Leistungsgerechte, kompetitive Vergütung

- Langfristige Entwicklungsperspektive bei Expansion des Konzepts

Sie möchten operativ Verantwortung übernehmen und aktiv am Aufbau eines Gastrokonzepts mitwirken? Dann freuen wir uns auf Ihre Bewerbung – mit Lebenslauf und frühestmöglichem Eintrittstermin.

Da wir die Position zeitnah besetzen möchten, ist eine kurzfristige Verfügbarkeit wünschenswert. Wir melden uns schnell zurück.

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
