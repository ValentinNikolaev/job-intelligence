# Buchhalter (m/w/d)

Posted: 2026-09-03T14:00:41Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Über SIERA

SIERA gestaltet Zukunft mit verantwortungsvoller Ingenieurleistung, innovativen Ideen und internationaler Zusammenarbeit. Als Unternehmen für Umweltingenieurwesen und Beratung entwickeln wir nachhaltige Lösungen für Klima, Wasser, Umwelt und Infrastruktur.

An über 33 Standorten in Deutschland arbeiten mehr als 800 Mitarbeitende über vier Kontinente hinweg an Projekten mit langfristiger Wirkung.

„Engineering for a Better Tomorrow“ – gemeinsam schaffen wir Fortschritt für Umwelt, Wirtschaft und Gesellschaft.

Über die Position

Für unsere Finanzbuchhaltung in Nürnberg suchen wir einen erfahrenen Buchhalter (m/w/d).

Sie übernehmen eine zentrale Rolle bei der Erstellung, Prüfung und Analyse unserer BWAs sowie bei der Vorbereitung der jährlichen Finanzberichte. Dabei arbeiten Sie eng mit unserem internationalen Team zusammen, bringen Ihre Erfahrung aktiv ein und unterstützen die Weiterentwicklung unserer Finanzprozesse.

Nach dem Wechsel von DATEV zu Microsoft Dynamics 365 Business Central helfen Sie uns dabei, Abläufe sicher, transparent und effizient weiterzuentwickeln.

Ihre Aufgaben

- Bearbeitung, Prüfung und Kontrolle der laufenden Finanzbuchhaltung

- Erstellung und Analyse von BWAs, Finanzreports und Auswertungen

- Unterstützung bei der Vorbereitung von Jahresabschlüssen und Finanzberichten nach HGB

- Abstimmung von Konten, offenen Posten, Banken und Zahlungsprozessen

- Zusammenarbeit mit dem internationalen Finance-Team sowie Steuerberatung und externen Partnern

- Sicherstellung korrekter, fristgerechter und nachvollziehbarer Buchhaltungsprozesse

- Weitergabe von Fachwissen und Unterstützung des Teams bei buchhalterischen Fragestellungen

- Optimierung von Buchhaltungs- und Berichtsprozessen

- in Microsoft Dynamics 365 Business Central

Ihr Profil

- Weiterbildung zum Finanzbuchhalter (IHK), Bilanzbuchhalter (IHK) oder eine vergleichbare IHK-Qualifikation

- Mehrjährige Erfahrung in der Finanzbuchhaltung, insbesondere im Bereich BWA, Reporting und Jahresabschlussvorbereitung

- Gute Kenntnisse im HGB und ein sicherer Umgang mit buchhalterischen Prozessen

- Erfahrung mit ERP- und Buchhaltungssystemen; Kenntnisse in Microsoft Dynamics 365 Business Central sind ein Vorteil

- DATEV-Erfahrung ist willkommen

- Sehr gute Deutsch- und Englischkenntnisse in Wort und Schrift für die tägliche Zusammenarbeit mit unserem internationalen Team

- Sorgfältige, strukturierte und verantwortungsbewusste Arbeitsweise

- Offenheit für die Zusammenarbeit in einem internationalen Team sowie Freude am Teilen von Wissen

Ihr Arbeitsplatz bei SIERA

Unser Standort in Nürnberg verbindet Tradition mit Fortschritt: Sie arbeiten in besonderen, traditionsreichen Räumlichkeiten, die zugleich modern, zeitgemäß und auf einem hohen digitalen Niveau ausgestattet sind.

Freuen Sie sich auf ein Umfeld, in dem Zusammenarbeit, Kreativität und neue Ideen ihren Platz haben. Wir freuen uns auf Ihre Bewerbung und darauf, SIERA gemeinsam mit Ihnen weiterzuentwickeln.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
