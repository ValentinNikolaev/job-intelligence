# AI Automations Engeneer (m/w/d)

Posted: 2026-09-03T12:00:47Z

## Rejection

- Category: tech_stack
- Reason: role does not mention Go/Golang or PHP

**Möchtest du die Welt des E-Commerce revolutionieren und in einem Team aus Spitzenkräften Online-Shops auf sieben- bis achtstellige Umsätze skalieren?**

Werde zum wichtigsten Ansprechpartner für unsere Beratungskunden, die du auf META ganzheitlich strategisch betreust. Du bist kein klassischer Performance-Marketer, der im Admanager herumklickt, sondern arbeitest auf hohem Niveau mit dem Kunden zusammen. Die Umsetzung liegt beim Kunden. Deine Aufgabe ist es, ihn bestmöglich dabei zu unterstützen.

Du arbeitest in einem Team, in dem jeder nach Wachstum strebt und wir uns gegenseitig zu Höchstleistungen anspornen. Du hast ein Team gefunden, mit dem du gemeinsam wachsen kannst.

Klingt fast zu gut, um wahr zu sein? Dann lies jetzt weiter – wir suchen nämlich jemanden wie dich für unser Team.

## Aufgaben

- Du baust Dateninfrastruktur, Integrationen und Automatisierungen für die SPACEDOME - Intelligence. Parallel dazu bringst du KI in bestehende Marketing-Workflows, auf Kundenseite genauso wie in unseren internen Prozessen.

- Du entwickelst LLM-basierte Tools und Agenten, z. B. für Media-Buying, Content und Churn-Prevention.

- Du sorgst dafür, dass Systeme wirklich genutzt werden und direkten Business-Impact liefern.

## Qualifikation

- Mindestens 2 Jahre praktische Erfahrung im Aufbau von Automatisierungen, Integrationen oder technischen Workflows

- Du hast selbst Systeme gebaut, die **produktiv liefen und von anderen Menschen genutzt wurden** — nicht nur Prototypen, Tutorials oder Side-Projects in der Schublade

- Sicher in Python oder Node.js:

- Du schreibst Code, der auch in drei Monaten noch wartbar ist

- Erfahrung mit LLM-APIs (OpenAI, Anthropic o. ä.) und dem Bau von Tools oder Agenten darauf - inklusive der unangenehmen Themen: Fehlerfälle, Kosten, Qualitätssicherung

- Du integrierst souverän gegen fremde APIs: REST, Webhooks, OAuth, Rate Limits, Pagination, auch wenn die Doku lückenhaft ist

- Erfahrung mit Datenpipelines: Daten aus mehreren Quellen zusammenführen, sauber modellieren, für Reporting nutzbar machen

- Du arbeitest eigenständig und findest selbst heraus, was gebaut werden muss - bei uns schreibt dir niemand Tickets

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
