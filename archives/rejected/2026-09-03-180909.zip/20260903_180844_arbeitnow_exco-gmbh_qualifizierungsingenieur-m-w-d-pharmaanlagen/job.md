# Qualifizierungsingenieur (m/w/d) Pharmaanlagen

Posted: 2026-09-03T11:30:52Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Du möchtest anspruchsvolle Projekte in der Pharmaindustrie begleiten und sicherstellen, dass Produktionsanlagen den regulatorischen Anforderungen entsprechen? Dann werde Teil unseres Teams Industrial Solutions am Standort Frankenthal (Pfalz) und unterstütze unsere Kunden bei der Qualifizierung pharmazeutischer Anlagen und Systeme.

## Aufgaben

- Planung, Durchführung und Dokumentation von Qualifizierungsmaßnahmen für pharmazeutische Anlagen und technische Systeme gemäß GMP-Anforderungen

- Erstellung und Pflege von Qualifizierungsdokumenten wie Risikoanalysen, URS, DQ-, IQ-, OQ- und PQ-Plänen sowie den dazugehörigen Berichten

- Vorbereitung, Koordination und Durchführung von Factory Acceptance Tests (FAT) und Site Acceptance Tests (SAT)

- Begleitung von Inbetriebnahmen sowie Sicherstellung einer GMP-konformen Anlagenfreigabe

- Bearbeitung und Nachverfolgung von Abweichungen, CAPA-Maßnahmen und Änderungen im Qualifizierungsprozess

- Übernahme von Verantwortung in Teilprojekten oder eigenständige Leitung von Qualifizierungsprojekten

## Qualifikation

- Erfolgreich abgeschlossenes Studium der Pharmatechnik, Verfahrenstechnik, Medizintechnik, Maschinenbau, Elektrotechnik oder eine vergleichbare Qualifikation

- Mehrjährige Berufserfahrung in der Qualifizierung und Validierung im GMP-regulierten Umfeld

- Fundierte Kenntnisse im Bereich Anlagenqualifizierung (DQ, IQ, OQ, PQ) sowie im Umgang mit Risikoanalysen

- Erfahrung mit pharmazeutischen Produktionsanlagen, Laboranlagen oder Versorgungssystemen von Vorteil

- Sicherer Umgang mit GMP-Anforderungen sowie relevanten regulatorischen Vorgaben

- Strukturierte und selbstständige Arbeitsweise sowie ein hohes Qualitätsbewusstsein

- Sehr gute Deutschkenntnisse (mindestens C1-Niveau) sowie gute Englischkenntnisse (mindestens B2)

## Benefits

**Unbefristete Festanstellung mit Sicherheit:** Uns gibt es seit 1994!

**Flexible Arbeitszeiten:** Du kannst dir deine Arbeitszeit im Rahmen der Gleitzeit frei einteilen.

**Hybrides Arbeiten:** Wir bieten dir einen modern ausgestatteten Arbeitsplatz und geben dir zusätzlich die Möglichkeit zum Mobilen Arbeiten.

**Einstieg mit Onboarding Programm:** Du wirst von einem Paten begleitet, damit du dich rasch bei uns wohlfühlen und zurechtfinden kannst.

**Familienfreundliches Unternehmen:** Wir unterstützen dich und deine Familie, z.B. mit einer Kindergartenbezuschussung und 5 Tagen Kinderkrankengeld bei 100% Lohnausgleich.

**Attraktive Vergütungsmodelle:** Du erhältst ein Jahresgehalt, genießt zusätzliche Urlaubstage und bezahlten Sonderurlaub bei bestimmten Anlässen. Überstunden werden durch Freizeitausgleich, oder, mit einem Zuschlag von 25 % vergütet.

**Individuelles Coaching:** Stillstand ist Rückschritt. Deshalb geben wir dir die Möglichkeit, dich weiterzuentwickeln. Wir organisieren auf dich abgestimmte Weiterbildungen.

**Firmenevents:** In regelmäßigen Abständen veranstalten wir für dich und deine Kollegen Freizeitevents, bei denen Spaß und die Freude am Miteinander im Vordergrund stehen.

**Bike-Leasing-Angebote:** Wir bieten dir die Möglichkeit Fahrräder zu attraktiven Konditionen zu leasen. Die Räder stehen sowohl für private als auch geschäftliche Nutzung zur Verfügung.

**Mitarbeitervorteile und betriebliche Sozialleistungen:** Du genießt viele Corporate Benefits, z. B. eine betriebliche Altersvorsorge mit Arbeitgeberzuschuss, eine Unfallversicherung, die auch privat gültig ist, wechselnde Angebote von Kursen in Kooperation mit der Techniker Krankenkasse, Vergünstigungen bei der Fitnessstudio Pfitzer Gruppe und Firmenzentrale mit Mitarbeiterparkplatz. Unsere Firmenzentrale liegt verkehrsgünstig und ist bequem per Auto oder den Öffentlichen zu erreichen.

**Warum du bei EXCO starten solltest**

EXCO ist ein inhabergeführter technischer Dienstleister für Entwicklung und Qualitätssicherung mit einer mittlerweile **30-jährigen Erfolgs- und Wachstumsgeschichte**. Mit über 150 Mitarbeiterinnen und Mitarbeitern an 8 Standorten realisieren wir innovative Projekte für unsere global agierenden Kunden aus den Branchen Medizintechnik, Pharma, Biotechnologie und Chemie. Wir bieten unseren Mitarbeitenden langfristige Berufsperspektiven und die Möglichkeit, gemeinsam mit uns in einer krisensicheren Branche zu wachsen.

Weitere Informationen über EXCO als Arbeitgeber und deinen Einstiegs- und Entwicklungsmöglichkeiten findest du auf unserer [Karriereseite](https://jobs.exco-solutions.com/de/exco-als-arbeitgeber.html).

**Wir freuen uns darauf dich kennenzulernen!**

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
