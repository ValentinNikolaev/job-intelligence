# Solutions Engineer (m/w/d)

Posted: 2026-09-03T13:00:33Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**Wir sind EC Systems:** Ein wachstumsorientiertes Unternehmen mit Leidenschaft für smarte Technikkommunikation.

Bei uns arbeitest du nicht einfach nur mit du gestaltest aktiv mit. Wir glauben an **Shared Passion with you**, an **Verantwortung für eine digitale Zukunft** und an **echte Zusammenarbeit auf Augenhöhe.**

Wenn du Lust hast, mit deinem Know-how etwas zu bewegen und die Zukunft digitaler Kommunikation mitzugestalten, bist du bei uns genau richtig!

## Aufgaben

- Du unterstützt unsere Solutions-Abteilung bei der Umsetzung und Integration technischer Lösungen für unsere Kund*innen.

- Du entwickelst und berätst REST-API-Schnittstellen und trägst so maßgeblich zur technischen Weiterentwicklung unserer Kund*innen bei.

- Du arbeitest eng mit unseren Entwicklungs- und Beratungsteams zusammen, bist direkte Ansprechperson für unsere Kund*innen und bringst eigene Ideen ein.

- Du analysierst Anforderungen, entwickelst und spezifizierst skalierbare Lösungen und setzt diese eigenverantwortlich um.

## Qualifikation

- Du hast ein abgeschlossenes Studium oder eine Ausbildung mit Programmierschwerpunkt (z. B. Informatik, Software Engineering oder vergleichbarer Hintergrund), aber auch als Quereinsteiger*in mit einschlägiger Erfahrung bist du bei uns herzlich willkommen.

- Du hast bereits praktische Erfahrung in der Softwareentwicklung gesammelt.

- Du bringst gute Kenntnisse in der Webentwicklung mit Node.js/JavaScript, TypeScript oder Python mit.

- Du hast Kenntnisse in XML, HTML und CSS.

- Du bist vertraut mit Codeverwaltung über Git und modernen Entwicklungstools wie Bitbucket und Jira.

- Du hast erste Berührungspunkte mit AWS oder anderen Cloud-Umgebungen gesammelt, oder du hast Lust, dich in diese Themen einzuarbeiten.

- Du hast Interesse oder sogar schon Grundwissen zu Large Language Models und Entwicklung von AI-basierten Tools und Funktionen.

- Du verfügst über sehr gute Deutschkenntnisse (C1) und gute Englischkenntnisse (B2), damit du dich auch in internationalen Projekten sicher bewegst. Spanischkenntnisse sind ein Plus.

- Kommunikation liegt dir: Du kannst Dinge gut erklären, trittst sicher auf und arbeitest gerne mit Menschen zusammen.

- Du arbeitest strukturiert und lösungsorientiert und hast Lust, dich tief in neue Technologien und unsere Produkte einzuarbeiten.

## Benefits

- **Flexibilität, die wirklich gelebt wird:** Entscheide selbst, wann du im Büro oder remote arbeitest.

- **Gestaltungsfreiheit und Eigenverantwortung:** Deine Ideen zählen und deine Impulse machen einen Unterschied.

- **Anspruchsvolle und abwechslungsreiche Aufgaben:** Du arbeitest an Projekten, die technisch spannend sind und einen echten Mehrwert schaffen.

- **Top Ausstattung, damit du produktiv arbeiten kannst:** Moderne Hardware, ergonomische Arbeitsplätze und die Wahl zwischen Mac oder Windows.

- **Wertschätzende Unternehmenskultur:** Mit flachen Hierarchien, kurzen Entscheidungswegen und echtem Teamgeist in einem internationalen Team.

- **Firmenfitness:** Wähle bei uns frei zwischen Wellpass und Hansefit das Angebot, das am besten zu dir passt.

- **Unsere Benefits:** Zusätzliche Benefits, die zu deinem Leben passen: BahnCard, Internetzuschuss, Vermögenswirksame Leistungen – flexibel nutzbar und steuerlich vorteilhaft.

- **Mehr als nur Arbeit:** Wöchentlicher Team-Tag im Büro, regelmäßige Teamevents, gemeinsame Mittagessen und eine offene Feedbackkultur.

- **Unsere Selbstverständlichkeiten**: Kostenlose Getränke und Kaffee im Büro, Gleitzeit und ein Umfeld, in dem du und dein vierbeiniger Begleiter sich wohlfühlen.

- **Persönliches Wachstum:** Fort- und Weiterbildungen, Austausch mit Expert*innen und Raum für Entwicklung mit regelmäßigen Entwicklungsgesprächen.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
