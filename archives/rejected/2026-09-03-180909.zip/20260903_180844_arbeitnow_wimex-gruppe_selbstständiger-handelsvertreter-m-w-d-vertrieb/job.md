# selbstständiger Handelsvertreter (m/w/d) Vertrieb landwirtschaftliche Software

Posted: 2026-09-03T11:30:32Z

## Rejection

- Category: tech_stack
- Reason: role does not mention Go/Golang or PHP

Die **geo-konzept GmbH** (ein Partnerunternehmen der Wimex Group) steht bereits seit 1992 für zuverlässige und robuste Sensorik, GPS- und GIS-Technologien für die Agrar- und Forstwirtschaft sowie die Steinindustrie. Das Unternehmen zählt zu den Marktführern im Bereich der präzisen Landwirtschaft. Dabei stehen besonders Lenk-, Sensor-, Drohnen- und digitale Managementsysteme im Vordergrund. Unser Ziel ist es, dem Kunden durch Komponenten, Sensorik, Automation und auch durch die Integration von Autonomie/Robotik die Arbeit zu erleichtern und umfassende Komplettlösungen an die Hand zu geben. Hierbei stehen der praktische Nutzen sowie die Betreuung im Vordergrund. Dies wird mit Fachwissen und Erfahrung - auch über die Grenzen der eigenen Produkte hinaus - umgesetzt.

Mit cropster bringt geo-konzept nun eine eigene Produktwelt aus Hard- und Software auf den Markt, die miteinander verknüpft ist – und gleichzeitig offen für andere Systeme bleibt.

Werde Teil der deutschlandweiten Bewegung, die Landwirtschaft smarter, effizienter und nachhaltiger macht – und gestalte dabei dein eigenes, flexibles Business.

### **Deine Aufgaben:**

-

Als selbstständiger Handelsvertreter begleitest du landwirtschaftliche Betriebe in die digitale Zukunft

-

Du unterstützt Landwirte bei der Einführung modernster Hard- und Software herstellerunabhängig

-

Du findest passgenaue Lösungen für digitale Herausforderungen

-

Als Tester der cropster-Lösungen bringst du deine praktischen Erfahrungen aktiv ein

### **Dein Profil:**

-

Ob Junglandwirt, Servicetechniker oder Student- Du liebst Landwirtschaft und Technik

-

Du interessierst dich für zukunftsweisende, moderne Software sowie deren Anwendung und möchtest andere dafür begeistern

-

Eine Berufsausbildung oder Studium im landwirtschaftlichen/technischen Bereich sind zu deinem Vorteil

### **Deine Vorteile:**

-

Du bestimmst Zeit, Umfang und Tempo deiner Tätigkeit, haupt- oder nebenberuflich

-

Du gestaltest dein Angebot für deine Kunden völlig selbstständig

-

Auf jeden deiner cropster Abschlüsse erhältst du 25 % Provision

-

Wir stellen dir Infomaterial, Lernvideos und das geo-konzept Kundennetzwerk zur Verfügung

-

Das erfahrene Service-Team steht dir und deinen Landwirten persönlich zur Seite, beantwortet Fragen und bietet technische Hilfe

Du bist interessiert an einem flexiblen Zusatzverdienst in der digitalen Landwirtschaft?

Dann bewirb dich über den Bewerben Button, per E-Mail an: oder ruf uns an unter: 0151 / 543 723 71.

Weitere Informationen findest du hier: [https://geo-konzept.de/lp-cropster-farmcoach/](https://geo-konzept.de/lp-cropster-farmcoach/)

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
