# Platform Engineer - IAM & Compliance

Posted: 2026-09-03T12:30:37Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**Gehaltstransparenz**

Diese Position richtet sich an Kandidat:innen mit mehr als 3 Jahren Berufserfahrung. Das Gehalt variiert je nach Erfahrung und liegt zwischen **80.000 € und 100.000 € brutto pro Jahr**.

**Arbeitsmodell:** Vollzeit, hybrid; 2–3 Tage pro Woche vor Ort.

**Standort:** Hamburg, Deutschland (Eppendorf).

Muxon ist eine kleine, international aktive Recruiting-Agentur und führt diese Suche im Auftrag unseres Partners durch, eines sinnorientierten Health-Tech-Unternehmens, das KI-gestützte klinische Softwarelösungen entwickelt, die in Krankenhäusern eingesetzt werden, um die Patientenversorgung zu verbessern. Das Unternehmen arbeitet in einem sehr kollaborativen, dynamischen Umfeld und sucht eine erfahrene **IT Platform Engineer**-Persönlichkeit, die die Verantwortung für die interne Plattform- und Identity-Landschaft übernimmt.

## Aufgaben

- Verwaltung und Weiterentwicklung der Microsoft Entra ID / Azure AD-Umgebung, einschließlich SSO, Conditional Access, MFA, User Lifecycle und Lizenzmanagement.

- Verwaltung und Konfiguration von Jira, Confluence, GitHub, GitLab und Microsoft 365.

- Implementierung von Zugriffskontrollen, RBAC-Policies und Audit-Trails zur Unterstützung von Sicherheits- und Compliance-Standards.

- Automatisierung wiederkehrender Aufgaben wie User Provisioning, Lizenzzuweisung und Policy Enforcement mittels Scripting oder Infrastructure as Code.

- Monitoring der Plattformverfügbarkeit, Einrichtung von Alerting und proaktive Problemlösung.

- Erste Ansprechperson für interne IT- und Tooling-Anfragen.

- Unterstützung im Vendor-, SaaS- und Lizenzmanagement.

## Qualifikation

- Mehr als 3 Jahre Erfahrung in IT-Administration, Systems Engineering oder Platform Engineering.

- Fundierte praktische Erfahrung mit Microsoft Entra ID / Azure AD.

- Erfahrung in der Administration von Atlassian-Tools und Git-basierten Plattformen.

- Solides Verständnis von IAM-Konzepten wie RBAC, SAML, OIDC und SCIM.

- Erfahrung mit der Administration von Microsoft 365.

- Deutschkenntnisse auf mindestens B2-Niveau.

- Strukturierte, dokumentationsorientierte und sehr eigenverantwortliche Arbeitsweise.

- Erfahrung mit Scripting oder Automatisierung ist ein großes Plus.

## Benefits

- Direkter Impact im Gesundheitswesen durch sinnstiftende Technologie.

- Hohe Eigenverantwortung und Autonomie über interne Plattformen und Tools.

- Kleines Team mit kurzen Entscheidungswegen.

- Hybrides Arbeitsmodell mit flexiblen Arbeitszeiten.

- 30 Urlaubstage.

- Weiterbildungsbudget und Möglichkeiten zur Teilnahme an Konferenzen.

- Klare Entwicklungsperspektive in Richtung IT Security / Compliance Lead.

Wenn diese Position den nächsten passenden Schritt für Sie darstellt, freuen wir uns auf Ihre Bewerbung.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
