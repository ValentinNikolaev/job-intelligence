# Channel Marketing Manager (all genders) - 100& Homeoffice

Posted: 2026-09-03T13:00:32Z

## Rejection

- Category: tech_stack
- Reason: role does not mention Go/Golang or PHP

Ein erheblicher Teil unseres Wachstums entsteht über Steuerberater, Affiliates, Reseller und strategische Partnerschaften. Diese Kanäle haben Potenzial und wir wollen daraus systematisch mehr machen.

Als Channel Marketing Manager verantwortest du das Marketing über unsere Partnerkanäle hinweg. Du arbeitest eng mit den Verantwortlichen für Sales, Business Development und Partner Management zusammen und sorgst dafür, dass aus Partnerschaften nicht nur Kontakte, sondern aktive Partner, qualifizierte Leads und messbarer Umsatz entstehen.

Du bist dabei nicht die Person, die für jeden Kanal einen Marketingplan schreibt und ihn anschließend weiterreicht. Du arbeitest direkt mit den Channel-Ownern, verstehst deren Ziele und entwickelst gemeinsam mit ihnen die Maßnahmen, die tatsächlich etwas bewegen.

## Aufgaben

**Marketing über alle Kanäle**

- Du bist die erste Anlaufstelle für Marketingfragen rund um unsere Partnerkanäle.

- Du vereinbarst mit den Verantwortlichen je Kanal klare Ziele und definierst, welchen Beitrag Marketing dazu leisten kann.

- Du analysierst, welche Maßnahmen funktionieren, und skalierst sie über weitere Partner und Kanäle.

- Du übersetzt Anforderungen aus Sales und Business Development in konkrete Marketingmaßnahmen etwa bei neuen Partnerschaften, neuen Zielgruppen oder beim Eintritt in einen neuen Markt.

- Du entwickelst gemeinsam mit den Channel-Ownern wiederholbare Marketingprozesse statt einzelner Aktionen.

**Steuerberater und Kanzleien**

- Ein wichtiger Teil unseres Partnergeschäfts entsteht über Steuerberater und Kanzleien. Gemeinsam mit den Verantwortlichen entwickelst du Maßnahmen, mit denen wir diese Zielgruppe aktivieren und zu zahlenden Kunden entwickeln.

- Du segmentierst bestehende Kontakte und entwickelst je Segment eine passende Ansprache.

- Du konzipierst Maßnahmen, mit denen Kanzleien unsere Lösungen aktiv an ihre Mandanten weitergeben.

- Du entwickelst Empfehlungsmechaniken, Kampagnen und Materialien, die Kanzleien im eigenen Kundenkontakt einsetzen können.

- Du arbeitest eng mit dem Team rund um unsere Kanzlei-Produkte zusammen und übersetzt Produktnutzen in verständliche Kommunikation für Kanzleien und Mandanten.

**Partner, Affiliates und Reseller**

- Du unterstützt die Gewinnung neuer Partner mit passenden Marketingmaßnahmen von ersten Materialien bis zu konkreten Kampagnen.

- Du entwickelst bestehende Partner weiter und hilfst dabei, aus unterschriebenen Partnerschaften aktive Umsatzkanäle zu machen.

- Du entwickelst wiederkehrende gemeinsame Aktionen mit Fokuspartnern und stimmst diese eng mit den jeweiligen Channel-Ownern ab.

- Du baust Partner-Enablement auf: Präsentationen, One-Pager, Argumentationshilfen, E-Mail-Vorlagen, Kampagnen-Kits, Schulungsunterlagen und weitere Materialien, die Partner selbst verwenden können.

- Du entwickelst Affiliate- und Empfehlungsmaßnahmen weiter und sorgst dafür, dass Partner wissen, wie sie unsere Produkte erfolgreich weitergeben können.

- Bei größeren strategischen Partnerschaften unterstützt du die Marketing-Seite des gesamten Go-to-Market-Prozesses

**Kampagnen und Umsetzung**

- Du planst Channel-Kampagnen und setzt sie gemeinsam mit den Kolleginnen und Kollegen aus E-Mail, Paid Marketing, Content, Design und Website um.

- Du entwickelst E-Mail-Strecken für Partner, deren Kunden und bestehende Kontakte und wertest deren Ergebnisse aus.

- Du briefst Landingpages und Inhalte und arbeitest mit dem Website-Team an Conversion und Nutzerführung.

- Du entwickelst Kampagnen für unterschiedliche Partnersegmente und passt Botschaften, Angebote und Inhalte an die jeweilige Zielgruppe an.

- Du bereitest Webinare, Workshops und Veranstaltungen für Steuerberater und Partner vor und nach.

- Du testest unterschiedliche Ansätze und entscheidest anhand der Ergebnisse, was weitergeführt, verändert oder beendet wird.

**Vertrieb und CRM**

- Du baust gemeinsam mit Sales einen durchgängigen Weg vom ersten Partner- oder Kundenkontakt bis zum Abschluss auf.

- Du definierst gemeinsam mit Sales und Channel-Ownern klare Übergabepunkte zwischen Marketing, Partnern und Vertrieb.

- Du sorgst dafür, dass Kampagnen, Leads und Partneraktivitäten im CRM nachvollziehbar sind.

- Du misst, welche Kanäle und Maßnahmen tatsächlich zu qualifizierten Leads, Abschlüssen und Umsatz beitragen.

- Du berichtest regelmäßig über die relevanten Marketing- und Channel-KPIs und leitest daraus konkrete nächste Schritte ab.

## Qualifikation

- 2–3 Jahre Erfahrung im B2B-Marketing, idealerweise im Partner-, Channel-, Affiliate- oder Vertriebsmarketing.

- Erfahrung darin, Marketingmaßnahmen eigenständig von der Konzeption über die Umsetzung bis zur Auswertung zu steuern.

- Du kannst aus Vertriebs- und Partnerzielen konkrete Marketingmaßnahmen ableiten und diese gemeinsam mit den Verantwortlichen umsetzen.

- Du hast Erfahrung mit Kampagnen über mehrere Kanäle und kannst deren Erfolg anhand von Leads, Conversion und Umsatz bewerten.

- Du bist sicher im E-Mail-Marketing, insbesondere bei Segmentierung, Kampagnenstrecken und Auswertung.

- Du kannst Marketingmaterialien für Partner und Vertrieb erstellen, die andere direkt im Kundengespräch einsetzen können.

- Du hast eng mit Sales, Business Development oder Partner Management gearbeitet und verstehst deren Arbeitsweise.

- Du gehst sicher mit CRM-Systemen und Marketing-Tools um und kannst Daten nutzen, um Maßnahmen und Kanäle zu bewerten.

- Du arbeitest eigenständig, verbindlich und lösungsorientiert und bringst Themen auch ohne detaillierte Vorgaben ins Ziel.

- Deutsch beherrschst du verhandlungssicher. Englisch kannst du sicher für die Zusammenarbeit mit internationalen Partnern einsetzen.

**Von Vorteil**

- Erfahrung im SaaS-, Software-, FinTech- oder Finanzdienstleistungsumfeld.

- Kenntnisse aus Steuerberatung, Buchhaltung oder Rechnungswesen.

- Erfahrung mit Resellern, Affiliates, Empfehlungsprogrammen oder Whitelabel-Partnerschaften.

- Erfahrung im Partner Enablement, z. B. mit Sales-Unterlagen, Partner-Kits oder Schulungsmaterialien.

- Erfahrung mit Landingpages, Conversion-Optimierung oder Marketing Automation.

- Erfahrung mit Webinaren, Events oder gemeinsamen Kampagnen mit Partnern.

## Benefits

**Was wir bieten:**

**Klare Verantwortlichkeiten und Unterstützung:**

Bei uns weißt du genau, was von dir erwartet wird, und du arbeitest in einem Umfeld, in dem Fehler als wertvolle Lernchancen betrachtet werden.

**Gemeinschaftliches Engagement für außergewöhnliche Ergebnisse:**

Unser Team strebt leidenschaftlich nach Spitzenleistungen und sieht deinen Beitrag als unverzichtbar an. Gemeinsam erreichen wir Großartiges.

**Individuelle Entwicklung und Selbstverantwortung:**

Wir fördern Selbstmotivation und deine persönliche Verantwortung, um herausragende Leistungen zu erzielen.

**Dynamisches Feedback für kontinuierliches Lernen:**

Bei uns erhältst du direktes und zeitnahes Feedback, damit du schnell auf Veränderungen reagieren und dich kontinuierlich verbessern kannst.

**Offene Kommunikation und persönliche Entwicklung:**

Wir leben offene Kommunikation und unterstützen dich aktiv bei der Gestaltung deiner persönlichen und beruflichen Entwicklung.

**Lösungsorientierung und Unternehmenserfolg im Fokus:**

Unser Ziel ist es, Ergebnisse zu erzielen, die das Unternehmen voranbringen. Dein Engagement für diesen Erfolg wird bei uns hoch geschätzt.

**Teamtage, Sommer- und Weihnachtsfeiern:** Gemeinsame Events für Teamspirit und Freude am Arbeitsplatz

**Corporate Benefits:** Genieße verschiedene Vergünstigungen.

**Hundefreundliche Arbeitsplätze:** Bring deinen besten Freund mit.

**Bikeleasing:** Genieße die Vorteile eines Bikeleasings, umweltfreundlich und fit zur Arbeit.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
