# Werkstudent Produktentwicklung (m/w/d)

Posted: 2026-09-03T11:30:54Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Du willst nicht nur zusehen, wie Sportprodukte entstehen, sondern sie selbst mitentwickeln? Du suchst ein Umfeld, in dem Ambition zählt, nicht Hierarchie?

Wir sind **GORNATION** - eine Sportmarke aus Münster, gegründet 2015 mit der Mission, den Calisthenics-Sport zu stärken und die Fitness von Menschen weltweit voranzubringen. Heute nutzen hunderttausende Sportler*innen aller Niveaus unsere Produkte in über 100 Ländern. Wir entwickeln eng mit Profis, denken funktional und handeln mit hohen Ansprüchen an uns selbst.

Für unser Produktentwicklungsteam suchen wir einen Werkstudenten, der uns bei der Entwicklung und Weiterentwicklung unserer Sportprodukte unterstützt - von CAD-Skizzen über den Aufbau von Prototypen bis zur Abstimmung mit unseren Herstellern. Zusätzlich bekommst du die Chance, eigene kleine Projekte von der Idee bis zur Bestellung beim Hersteller zu begleiten.

Du arbeitest in einem motivierten Team, bekommst Raum für Eigenverantwortung und die Chance, wirklich Einfluss zu nehmen. Kein Konzern-Blabla. Kein „Das haben wir schon immer so gemacht“. Sondern klarer Pragmatismus, ehrliches Feedback und viel Energie.

**Arbeitsmodell:** 15-20 Stunden/Woche an mindestens 3 Tagen die Woche, vor Ort in Münster.

## Aufgaben

- **Entwicklung & Optimierung:** Du wirkst an der Entwicklung und Weiterentwicklung unserer Sportprodukte mit.

- **Anleitungen:** Du erstellst und überarbeitest Aufbau- und Montageanleitungen.

- **CAD & technische Darstellungen:** Du erstellst CAD-Skizzen und technische Darstellungen für unsere Anleitungen.

- **Prototypenbau:** Du baust Produkte und Prototypen praktisch auf und testest sie.

- **Produkttests:** Du wirkst bei Produkttests mit und identifizierst Verbesserungspotenzial.

- **Technische Daten:** Du bereitest technische Informationen und Produktdaten auf.

- **Abstimmung:** Du kommunizierst mit unserem Produktentwicklungsteam und unseren internationalen Herstellern.

- **Eigene Projekte:** Du übernimmst eigene kleinere Produktentwicklungsprojekte – von der ersten Idee bis zur Bestellung beim Hersteller, zum Beispiel bei kleineren Sportartikeln.

## Qualifikation

- **Studium:** Du studierst Industrial Design, Produktdesign, Maschinenbau oder einen vergleichbaren Studiengang mit Bezug zur Produktentwicklung.

- **Technisches Verständnis:** Du hast bereits praktische Erfahrung mit CAD, kannst technische Zeichnungen verstehen und hast ein Auge fürs Detail.

- **Hands-on-Mentalität:** Du hast Lust, Dinge selbst auszuprobieren, aufzubauen und zu verbessern – auch abseits vom Bildschirm.

- **Schnelle Auffassungsgabe:** Du arbeitest dich schnell in neue Produkte und technische Fragestellungen ein.

- **Arbeitsweise:** Du arbeitest strukturiert, sorgfältig und eigenständig.

- **Kommunikation & Teamwork:** Du arbeitest eng mit unserem Produktentwicklungsteam zusammen - klar und lösungsorientiert.

- **Sprachen:** sehr gute Deutsch- und Englischkenntnisse

- **Calisthenics Bezug:** Ein Bezug zur Calisthenics-Szene ist von Vorteil.

## Benefits

- **Top Arbeits-Equipment:** Du bekommst ein MacBook für deine Arbeit, das dir hilft, produktiv und effizient zu arbeiten.

- **Fitness inklusive:** Wir trainieren regelmäßig gemeinsam nach der Arbeit, entweder in unserem Fitnessraum im Office-Gebäude oder draußen.

- **Steuerfreier Sachbezug:** Du erhältst eine Wellpass Mitgliedschaft, eine betriebliche Krankenversicherung oder eine Tankkarte als steuerfreien Sachbezug.

- **Teamevents & Networking:** Neben tollen Teamevents bekommst du auch die Gelegenheit, mit internationalen Calisthenics-Athleten in Kontakt zu treten und von ihnen zu lernen.

- **Erlebe die FIBO:** Mit deinem 4-Tage-Ticket für die FIBO - der größten Fitnessmesse der Welt - hast du Zugang zur Fitness-Welt in Köln.

- **Komfort bei der Arbeit:** Jeder Arbeitsplatz ist mit einem höhenverstellbaren Schreibtisch ausgestattet, damit du zwischen Sitzen und Stehen wechseln kannst, um produktiv und gesund zu bleiben.

- **Kaffee- & Wasser-Flat:** Genieße erstklassigen Kaffee aus unserer hochwertigen Kaffeemaschine und stets frisches Wasser aus unserer Wasserfilteranlage.

- **Exklusive Rabatte:** Profitiere von Mitarbeiterrabatten auf unsere Equipments und Kleidung für dein Training.

- **Persönliche Zusammenarbeit im Office:** Wir setzen auf echte Begegnungen im Büro in Münster statt endloser Online-Calls. Unser Ziel: Ein Office, in dem man sich wohlfühlt und in das man gerne kommt

- **Hundefreundlicher Arbeitsplatz:** Nach Absprache kannst du deinen Hund mit ins Büro nehmen.

- **E-Auto-Ladestation am Campus:** Du kannst dein E-Auto bequem direkt am Office laden.

Wenn du Lust hast, echte Sportprodukte mitzuentwickeln, eigene Ideen einzubringen und Teil eines motivierten Teams vor Ort in Münster zu werden, dann freuen wir uns auf deine Bewerbung!

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
