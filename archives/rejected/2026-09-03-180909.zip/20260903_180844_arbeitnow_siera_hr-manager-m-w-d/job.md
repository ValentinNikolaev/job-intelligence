# HR Manager (m/w/d)

Posted: 2026-09-03T13:30:39Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Über SIERA

SIERA gestaltet Zukunft mit verantwortungsvoller Ingenieurleistung, innovativen Ideen und internationaler Zusammenarbeit. Als Unternehmen für Umweltingenieurwesen und Beratung entwickeln wir nachhaltige Lösungen für Klima, Wasser, Umwelt und Infrastruktur.

An über 33 Standorten in Deutschland arbeiten mehr als 800 Mitarbeitende über vier Kontinente hinweg an Projekten mit langfristiger Wirkung.

„Engineering for a Better Tomorrow“ – gemeinsam schaffen wir Fortschritt für Umwelt, Wirtschaft und Gesellschaft.

Über die Position

Für unsere Unternehmensgruppe suchen wir einen HR Manager (m/w/d), der unsere Organisation mit einem klaren Blick für Menschen, Zusammenarbeit und Entwicklung unterstützt. Sie erkennen Potenziale, begleiten Teams und Führungskräfte in personalbezogenen Themen und tragen zu einer professionellen, vertrauensvollen Zusammenarbeit über Standorte hinweg bei.

Ihre Aufgaben

- Einschätzung von Kompetenzen, Potenzialen und Entwicklungsfeldern

- Beratung von Führungskräften und Teams bei personalbezogenen Fragestellungen

- Erkennen und Einordnen von Teamdynamiken sowie Entwicklungsbedarfen

- Unterstützung bei einer klaren, verbindlichen und konstruktiven Zusammenarbeit

- Professioneller und diskreter Umgang mit Anliegen von Mitarbeitenden

- Mitwirkung an der Weiterentwicklung von HR- und Organisationsprozessen

Ihr Profil

- Studium oder vergleichbare Qualifikation mit Bezug zu HR, Psychologie, Organisationsentwicklung oder Kommunikation

- Erfahrung im HR-Umfeld, in der Beratung oder Organisationsentwicklung

- Sehr gutes Gespür für Menschen, Zusammenarbeit und unterschiedliche Rollen

- Hohe soziale Kompetenz, Diskretion und sicheres Urteilsvermögen

- Strukturierte, eigenständige und verantwortungsbewusste Arbeitsweise

- Sicherer Umgang mit Microsoft 365

- Sehr gute Deutsch- und Englischkenntnisse in Wort und Schrift

Ihr Arbeitsplatz bei SIERA

Unser Standort in Nürnberg verbindet Tradition mit Fortschritt: Sie arbeiten in besonderen, traditionsreichen Räumlichkeiten, die zugleich modern, zeitgemäß und auf einem hohen digitalen Niveau ausgestattet sind. Freuen Sie sich auf ein Umfeld, in dem Zusammenarbeit, Kreativität und neue Ideen ihren Platz haben. Wir freuen uns auf Ihre Bewerbung und darauf, SIERA gemeinsam mit Ihnen weiterzuentwickeln.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
