# Frontend Developer (all genders)

Posted: 2026-09-03T13:30:40Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

VEXCASH AG is Germany’s leading online provider of short-term loans. We offer our customers a quick and straightforward solution to bridge the gap until their next payday. More than 800,000 customers already rely on our service. Thanks to our innovative approach, they can secure financial liquidity without having to commit to a long-term agreement.

## Aufgaben

We are looking for an experienced Frontend Developer to join our team and help build modern web applications in the FinTech sector.

- Develop clean, maintainable, and reusable frontend applications using JavaScript/TypeScript, HTML5, CSS3 and Bootstrap

- Build modern, responsive, and user-friendly web applications with Angular framework

- Create and maintain reusable UI components based on modern design and architecture principles

- Integrate RESTful APIs and work closely with backend developers on API interfaces

- Ensure high standards of performance, scalability, accessibility, and cross-browser compatibility

- Write and maintain unit, component, and end to end tests

- Work with Git, pull requests, code reviews

- Collaborate with UX/UI designers, Product Owners, backend developers, and other stakeholders

- Troubleshoot technical issues and continuously improve code quality and frontend architecture

## Qualifikation

- Strong knowledge of JavaScript/TypeScript, HTML5, CSS3, Bootstrap and browser compatibility

- Experience with responsive web development and modern UI/UX principles

- Experience with Angular framework

- Good understanding of REST APIs, HTTP, and JSON

- Knowledge of testing and Git

- Frontend performance optimization

- Basic knowledge of backend technologies and API integration

- Azure, C# / [ASP.NET](http://ASP.NET) Core, or SQL Server / Entity Framework Core are a plus

- Excellent written and spoken English and German skills

## Benefits

- We currently offer the Deutschlandticket on a 100% basis (available to employees only)

- We currently offer membership of Urban Sports (available to employees only)

- Fresh fruit baskets, hot and cold drinks in our office

- An international, dynamic, committed and supportive team

- An office located right next to Berlin’s main railway station Hauptbahnhof, designed in the style of a co-working space

- Hybrid Working

- Opportunities for personal and professional development

- A secure job in a company that has enjoyed a steady success story since its foundation in 2011

If you are motivated and want to be part of our success story, then send us your CV right away. If you hesitate, it’s your own fault!

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
