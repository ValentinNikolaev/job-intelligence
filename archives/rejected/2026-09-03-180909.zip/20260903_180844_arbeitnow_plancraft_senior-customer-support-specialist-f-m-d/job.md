# (Senior) Customer Support Specialist (f/m/d)

Posted: 2026-09-03T11:40:09Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**UNSER PURPOSE BEI PLANCRAFT**

**Gemeinsam das Rückgrat des europäischen Handwerks aufbauen – mit moderner Software und smarten AI-Lösungen.**
Wir entwickeln nicht einfach nur Software – wir haben die Mission, Handwerkerinnen und Handwerksbetrieben mehr Raum zu schaffen, indem wir sie mit einer praxisnahen SaaS-Lösung ausstatten, die so arbeitet wie sie: schnell, effizient und ohne unnötigen Admin-Aufwand. Unterstützt durch smarte AI-Funktionen genau dort, wo sie im Alltag wirklich helfen. Mit Tier 1 Investoren aus Europa und den USA wie Headline und Creandum sowie über 20.000 Handwerkerinnen als Kundenbasis skalieren wir europaweit, um aus einzelnen, verstreuten Betrieben vernetzte und erfolgreiche Communities zu machen.
Wir glauben an zero admin, nicht zero personality – und wir entwickeln jede Funktion mit den Menschen im Blick, die die Sicherheitsschuhe tragen, nicht die Anzüge. Wir haben Bock, die Zukunft zu gestalten, zusammen als Team, und sind bodenständig in unserer Mission, die Macherinnen von morgen zu unterstützen.

**DEINE MISSION BEI UNS**

Als **Customer Support Specialist** (f/m/d) bist du verantwortlich dafür, unseren Kund:innen über alle Kanäle hinweg schnellen, präzisen und empathischen Support zu bieten. Du übernimmst ihre Fragen und Probleme vom ersten Kontakt bis zur Lösung, hilfst Handwerker:innen dabei, plancraft erfolgreich im Arbeitsalltag einzusetzen, und bringst wertvolle Erkenntnisse aus dem Support ein, um unser Produkt und die Customer Experience kontinuierlich zu verbessern.

**Deine Verantwortlichkeiten**

-

Du übernimmst den gesamten Lifecycle von Kundenanfragen über E-Mail, Chat und Telefon – von der ersten Einordnung und Analyse bis zur Lösung, Nachverfolgung und dem Abschluss.

-

Du bist die erste Anlaufstelle für Handwerker:innen bei Produktfragen, technischen Problemen und Fragen zu ihren Workflows.

-

Du sorgst für schnelle und qualitativ hochwertige Lösungen, steuerst deinen Backlog eigenständig und behältst First Response und Resolution Times im Blick.

-

Du übernimmst End-to-End-Verantwortung für deine Fälle und arbeitest bei Bedarf eng mit Customer Success, Product und Engineering zusammen.

-

Du dokumentierst und kategorisierst Fälle sauber und nachvollziehbar und lieferst damit wertvolle Informationen für Ursachenanalysen.

-

Du erstellst und pflegst Help-Center-Artikel, Macros und interne Playbooks, um Self-Service-Angebote auszubauen und unseren Support skalierbarer zu machen.

-

Du erkennst wiederkehrende Probleme, UX-Hürden und Wissenslücken frühzeitig und übersetzt diese Erkenntnisse in konkrete Vorschläge für Produkt- und Prozessverbesserungen.

-

Du hilfst Kund:innen dabei, zentrale plancraft Workflows erfolgreich zu nutzen, löst Blocker und vermittelst Best Practices klar und praxisnah.

-

Du unterstützt die Weiterentwicklung unserer Support-Automatisierungen und AI-Workflows durch Tests, Feedback und kontinuierliche Verbesserung.

-

Je nach Erfahrung übernimmst du eigene Spezialisierungsthemen, beispielsweise als Feature Champion oder bei Onboarding Sessions und Webinaren.

**DEIN PROFIL**

**Must-haves**

-

Du hast einen starken Kundenfokus und kommunizierst klar, professionell und empathisch – auch in herausfordernden Gesprächen.

-

Du gehst Probleme strukturiert und analytisch an und findest pragmatische Lösungen.

-

Du übernimmst Verantwortung für Kundenanliegen und treibst sie eigenständig bis zur Lösung.

-

Du arbeitest gerne im Team und bringst eine bodenständige, kooperative Arbeitsweise mit.

-

Du hast ein gutes technisches Verständnis und gehst sicher mit digitalen Tools und Software um.

-

**Deutschkenntnisse auf C1/C2-Niveau sowie Englischkenntnisse auf mindestens B2-Niveau.**

**Nice-to-haves**

-

Du bringst erste Erfahrung im Customer Service, Customer Support oder Customer Success mit.

-

Du hast Erfahrung mit Handwerksbetrieben oder kennst deren Arbeitsalltag und typische Workflows.

-

Du hast bereits mit Tools wie Intercom, HubSpot, Slack, Google Workspace oder Stripe gearbeitet.

-

Du verfügst über zusätzliche Sprachkenntnisse in Spanisch, Italienisch, Polnisch oder Niederländisch.

**WARUM PLANCRAFT?**

-

**Team Spirit:** Mit Leidenschaft, Engagement und echtem Bock setzen wir alles daran, unsere Mission gemeinsam zu verwirklichen. Team Spirit feiern wir regelmäßig: mit 3 großen Team Events im Jahr, 2 monatlichen lockeren Formaten in unserem HQ und einer starken Recognition Culture, in der wir kleine wie große Erfolge sichtbar machen und gemeinsam zelebrieren.

-

**Ownership:** Bei uns übernimmst du Verantwortung ab Tag eins. In einem Umfeld mit flachen Hierarchien und hohem Vertrauen kannst du wirklich etwas bewegen.

-

**Weiterentwicklung:** Wir investieren gezielt in deine Entwicklung – durch eine starke Feedback Kultur, ein persönliches Learning Budget und Enablement Formate. Wir wollen dich bestmöglich unterstützen, damit du dein volles Potenzial entfalten kannst.

-

**AI Enablement:** Unsere internen Tools und Workflows sind von Grund auf KI-gestützt konzipiert. Wir unterstützen jedes Team und jede einzelne Person dabei, KI im Arbeitsalltag auf dem nächsten Level einzusetzen – inklusive einer eigenen Claude-Lizenz, selbstverständlich.

-

**Tech & Tooling:** Du bekommst moderne Hardware wie ein MacBook und hochwertige Over Ear Kopfhörer sowie alle Tools, die du für dein Daily Doing brauchst.

-

**Erholung:** 30 Urlaubstage, der 24.12. frei, ein Zuschuss zum Urban Sports Club sowie interne Sport Meetups unterstützen dich beim Abschalten.

-

**Mobilität:** Du kannst dir ein JobRad holen oder ein bezuschusstes Deutschlandticket bzw. eine BahnCard nutzen.

-

**Internationales Umfeld:** Wir werden stetig internationaler mit Kolleginnen u. a. in Italien, Frankreich, den Niederlanden und Österreich – und kommunizieren intern auf Englisch.

We’re **#stoked** to shape the future,** #together** as a team, and **#humble** in our mission to support the builders of tomorrow. For a first impression of us, take a look at [**our Instagram**](https://www.instagram.com/plancraft.app/reels/) and [**LinkedIn page**](https://www.linkedin.com/company/plancraft-gmbh/?viewAsMember=true).

**Diversity makes us better.
**We welcome people of all backgrounds, identities, abilities, and experiences, and we believe that different perspectives lead to better ideas, stronger products, and a healthier workplace. If you’re excited about our mission but your experience doesn’t align perfectly with every requirement, we encourage you to apply anyway. You might be exactly who we’re looking for.

______

**On the application process
**We want your candidate experience with us to be smooth, transparent, and enjoyable. We aim to get back to you regarding your application within 5 business days. Our interview process typically takes about 4 weeks from start to finish, though this may vary by role. You can learn more about our process [**here**](https://plancraft.com/en-gb/jobs#hiring). If you need adjustments or flexibility at any stage, please don’t hesitate to let us know — we’ll do our best to make it work for you.

**Note on creating a test account:**
If you would like to create a test account as part of the challenge, please enter "Applicant" in the relevant field during registration and select "Other" under Trade. This ensures that our sales team does not mistakenly register you as a craft business and reach out to you unnecessarily.

Compensation: €47.5K – €57.5K

- • €47.5K – €57.5K

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
