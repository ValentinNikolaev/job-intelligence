# IT Infrastructure Administrator (m/w/d)

Posted: 2026-09-03T14:00:40Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

In dieser Rolle als **IT Infrastructure Administrator (m/w/d)** übernimmst Du die Verantwortung für den zuverlässigen Betrieb und die kontinuierliche Weiterentwicklung einer modernen Server-, Storage- und Virtualisierungsinfrastruktur. Du arbeitest in einem vielseitigen IT-Umfeld und stellst gemeinsam mit weiteren Fachbereichen und externen Partnern eine stabile, sichere und leistungsfähige Infrastruktur sicher.

Du kennst jemanden der auf die Stellenausschreibung passt? Dann hole Dir jetzt unseren **Weiterempfehlungsbonus**! Erkundige Dich gleich telefonisch unter **089 998296647** bei mir!

## Aufgaben

- Die Konfiguration, Überwachung und Wartung der Server- und Storage-Infrastruktur liegt in Deinem Verantwortungsbereich

- Du verwaltest, optimierst und entwickelst die virtuelle Serverumgebung auf Basis von VMware ESXi kontinuierlich weiter

- Du führst Backup- und Restore-Prozesse durch und stellst durch regelmäßige Wiederherstellungstests mit Veeam die Verfügbarkeit von Server- und Dateisystemen sicher

- Komplexe Störungen im Server- und Storage-Umfeld analysierst Du eigenständig und leitest geeignete Maßnahmen zur Fehlerbehebung ein

- Installation, Konfiguration und Administration von Windows-Server-Systemen, unter anderem Windows Server 2016, 2019 und 2022, gehören zu Deinem Arbeitsalltag

- Du setzt Sicherheitsmaßnahmen auf Server- und Storage-Ebene um und überwachst diese, insbesondere in den Bereichen Zugriffsschutz, Verschlüsselung und Patch-Management

- Bestehende Prozesse optimierst Du kontinuierlich mit dem Ziel, eine stabile, effiziente und standortübergreifend zuverlässige IT-Infrastruktur sicherzustellen

## Qualifikation

- Mehrjährige Berufserfahrung in der Administration, dem Betrieb und der Weiterentwicklung von Datacenter-, Server-, Virtualisierungs- und Backup-Infrastrukturen bringst Du bereits mit

- Fundierte Kenntnisse im Umgang mit Technologien wie VMware, Veeam, NetApp, Cisco sowie Windows-Server-Umgebungen zeichnen Dich aus

- Du hast eine erfolgreich abgeschlossene Ausbildung im IT-Bereich, ein Studium der Informatik oder eine vergleichbare Qualifikation

- Gute Kenntnisse im Bereich der IT-Infrastruktur, insbesondere in den Bereichen Server, Storage, Netzwerk sowie Windows- und Linux-Systeme, gehören zu Deinem technischen Profil

- Kommunikationsstärke, Teamgeist und ein hohes Maß an Verantwortungsbewusstsein runden Dein Profil ab

## Benefits

- Eine vielseitige Position mit einem hohen Maß an Eigenverantwortung und Gestaltungsspielraum

- Ein attraktiver Standort mit guter Verkehrsanbindung

- Elektro-Tankstellen

- Betriebliche Altersvorsorge und Gesundheitsmanagement

- Work-Life-Balance, Familienleistungen, Flexible Arbeitszeitmodelle

- Jobrad, Firmenwagen

- Empfehle erfolgreich jemanden für die Stelle und Du erhältst eine **Werbeprämie** von **1000 Euro**

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
