# COO/ Managing Director (m/w/d)- Fashion & E-Commerce

Posted: 2026-09-03T14:00:39Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

More Money More Love ist eine schnell wachsende, founder-led Fashion- und Lifestyle-Brand aus Düsseldorf.

Für unsere nächste Wachstumsphase suchen wir eine außergewöhnlich starke operative Führungspersönlichkeit, die direkt mit unserem Founder & CEO zusammenarbeitet und zunehmend die operative Führung des Unternehmens übernimmt.

Deine Mission: Aus einer stark founder-getriebenen Organisation ein skalierbares Unternehmen bauen, das schnell und eigenständig exekutiert – ohne die Kreativität, Geschwindigkeit und Ambition unserer Brand zu verlieren.

Wir suchen keinen klassischen Corporate Manager, sondern einen unternehmerisch denkenden Operator mit Ownership, Leadership und hoher Umsetzungsgeschwindigkeit.

## Aufgaben

* Operative Steuerung des Unternehmens und enge Zusammenarbeit mit dem Founder & CEO

* Übersetzung der Unternehmensstrategie in konkrete Prioritäten, Verantwortlichkeiten, KPIs und Deadlines

* Führung und Weiterentwicklung unserer Department Leads und Teams

* Aufbau einer klaren Management-, Meeting- und Accountability-Struktur

* Identifikation und Lösung operativer Bottlenecks im gesamten Unternehmen

* Optimierung bereichsübergreifender Prozesse und Verantwortlichkeiten

* Sicherstellung einer engen Zusammenarbeit zwischen Marketing, Creative, E-Commerce, Product, Operations und Finance

* Aufbau und Steuerung integrierter Commercial-, Campaign- und Launch-Prozesse

* Verantwortung für die operative Umsetzung großer Projekte und Unternehmensinitiativen

* Weiterentwicklung unserer Organisationsstruktur sowie Identifikation wichtiger Hiring Needs

* Performance Management und Aufbau einer leistungsorientierten Ownership-Kultur

* Steuerung und Bewertung externer Agenturen, Freelancer und Partner

* Enge Zusammenarbeit mit Finance bei Budgetierung, Forecasting, Cash Planning und Kostenkontrolle

* Aufbau eines aussagekräftigen Management Reportings und Steuerung relevanter Unternehmens-KPIs

* Sicherstellung, dass Entscheidungen konsequent umgesetzt und Probleme möglichst eigenständig gelöst werden

Das übergeordnete Ziel: Das Unternehmen soll operativ immer weniger vom Founder abhängig sein, damit dieser sich auf Brand, Product, Creative, Wachstum und langfristige Unternehmensentwicklung konzentrieren kann

## Qualifikation

* Mehrjährige Erfahrung in einer operativen Führungsposition, z. B. als COO, Managing Director, General Manager, Director of Operations oder vergleichbarer Rolle

* Nachweisbare Erfahrung beim Aufbau oder der Skalierung eines schnell wachsenden Unternehmens

* Idealerweise Erfahrung in einem Unternehmen im achtstelligen Umsatzbereich oder auf dem Weg dorthin

* Starkes Verständnis für D2C, E-Commerce und digitale Geschäftsmodelle

* Erfahrung in Fashion, Streetwear, Lifestyle oder Consumer Brands ist ein starkes Plus

* Erfahrung in der Führung von Teams und Führungskräften

* Sehr gutes kommerzielles und finanzielles Verständnis

* Fähigkeit, Strategie konsequent in Execution zu übersetzen

* Ausgeprägtes Ownership-Mindset und hohe Entscheidungsfähigkeit

* Du erkennst Probleme und löst sie, bevor sie eskaliert werden müssen

* Du kannst Strukturen und Prozesse aufbauen, ohne unnötige Bürokratie zu schaffen

* Hohe Standards, starke Kommunikation und die Fähigkeit, andere accountable zu halten

* Erfahrung in einem founder-led Unternehmen ist ein großes Plus

* Sehr gute Deutsch- und Englischkenntnisse

Wir suchen nicht den perfekten Corporate-Lebenslauf. Wir suchen jemanden, der bereits bewiesen hat, dass er Unternehmen, Menschen und Execution auf das nächste Level bringen kann.

## Benefits

* Eine der zentralsten Führungspositionen innerhalb von More Money More Love

* Direkte Zusammenarbeit mit dem Founder & CEO

* Enormer Gestaltungsspielraum und echte Entscheidungsverantwortung

* Möglichkeit, die nächste Wachstumsphase einer etablierten Fashion Brand maßgeblich mitzugestalten

* Keine Konzernstrukturen und kurzen Entscheidungswege

* Hohe Eigenverantwortung und direkter Einfluss auf Unternehmensperformance

* Attraktives Executive Compensation Package aus Fixgehalt und performanceabhängiger Vergütung

* Modernes Office in Düsseldorf

* Mitarbeiterrabatte auf More Money More Love

* Regelmäßige Team Events

* Langfristige Entwicklungsperspektive innerhalb der Geschäftsführung

**More Money More Love steht für Ambition, Geschwindigkeit und den Anspruch, Dinge anders zu machen. Genau diesen Anspruch haben wir auch an unsere Führung.**

Wir suchen eine Persönlichkeit, die Verantwortung auf Unternehmensebene übernimmt, Strukturen schafft und gemeinsam mit unserem Founder & CEO die nächste Wachstumsphase gestaltet.

**Wenn Sie unternehmerisch denken, konsequent umsetzen und eine ambitionierte Brand auf ihrem Weg zum nächsten Level mitprägen möchten, freuen wir uns darauf, Sie kennenzulernen.**

**Let’s build what’s next.**

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
