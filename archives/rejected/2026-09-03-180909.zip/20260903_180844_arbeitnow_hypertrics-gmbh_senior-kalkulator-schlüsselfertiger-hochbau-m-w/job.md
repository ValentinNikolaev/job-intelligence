# Senior Kalkulator – Schlüsselfertiger Hochbau (m/w/d)

Posted: 2026-09-03T11:30:27Z

## Rejection

- Category: tech_stack
- Reason: role does not mention Go/Golang or PHP

#### **Senior Kalkulator / CAD-Konstrukteur Holzbau (m/w/d)
**

**Standort: Neuenkirchen / Rheine | Vollzeit | Unbefristet**

Für unseren Mandanten, ein innovatives, wachstumsstarkes Holzbauunternehmen mit Spezialisierung auf digitale Planung, vorgefertigte 2D-Holzrahmen-Elemente und 3D-Raum-Module – tätig als überregionaler Generalunternehmer für Projektentwickler, öffentliche und private Bauherren sowie Investoren – suchen wir im exklusiven Auftrag zum nächstmöglichen Zeitpunkt einen **Senior Kalkulator (m/w/d)** im Bereich schlüsselfertiger Hochbau. Das Unternehmen steht für modernen, klimafreundlichen Holzbau auf höchstem Niveau und bietet Ihnen eine Schlüsselposition mit echter Gestaltungsverantwortung in einem wachsenden, innovativen Unternehmen.

#### **Ihre Aufgaben**

-

**Kalkulation & Angebotserstellung:** Eigenverantwortliche Erstellung und Koordination von Kalkulationen und Angeboten – unter Einbeziehung interner und externer Fachleute von der ersten Projektbewertung bis zum Abschluss

-

**Digitale Kalkulationsprozesse:** Aktive Mitgestaltung und Weiterentwicklung digitaler Kalkulationsprozesse und relevanter Schnittstellenbereiche

-

**Vertragsmanagement:** Unterstützung des Teams im Vertragsmanagement sowie Begleitung vertraglicher Verhandlungen zwischen Auftraggeber und Auftragnehmer

-

**Preisanfragen:** Einholung und Auswertung von Preisanfragen bei Planungs- und Projektpartnern

-

**Optimierungsvorschläge:** Erarbeitung von Sondervorschlägen und technischen Alternativen zur Optimierung von Kosten, Energieeffizienz und Nachhaltigkeit

#### **Ihr Profil**

-

**Fachliche Qualifikation:** Abgeschlossenes Studium im Bauingenieurwesen oder der Architektur – alternativ eine Weiterbildung zum Bautechniker oder Meister mit einschlägiger Kalkulationserfahrung

-

**Berufserfahrung:** Mehrjährige Praxiserfahrung in der Kalkulation schlüsselfertiger Hochbauprojekte – Sie wissen, was fundierte Kostenschätzung bedeutet

-

**Fachkenntnisse:** Umfassendes Wissen über Hochbaukonstruktionen sowie ausgeprägtes Kostenbewusstsein und Zahlenverständnis

-

**Führungskompetenz:** Fähigkeit, im Zuge der Kalkulation ein Planerteam fachlich zu führen und zu koordinieren

-

**Systemkompetenz:** Gute Anwenderkenntnisse in Kalkulationssoftware – idealerweise RIB iTWO

-

**Arbeitsweise:** Strukturiert, eigenverantwortlich und mit dem Blick für das Wesentliche auch bei komplexen Projekten

#### **Ihre Vorteile**

-

**Flexibles Arbeiten:** Freie Arbeitszeitgestaltung mit der Möglichkeit, einen Teil der Arbeit mobil zu erledigen – standortunabhängig möglich

-

**Work-Life-Balance:** Aktive Unterstützung bei der Vereinbarkeit von Berufs- und Privatleben

-

**Einarbeitung:** Strukturiertes Onboarding mit persönlicher Betreuung von Beginn an

-

**Teamwork:** Enge Zusammenarbeit mit Projekt- und Bauleitern in einem interdisziplinären, engagierten Team

-

**Innovationsumfeld:** Arbeit in einem modernen, zukunftsorientierten Unternehmen mit digitaler Arbeitsweise und echtem Nachhaltigkeitsanspruch

-

**Unternehmenskultur:** Wertschätzendes Arbeitsumfeld mit flachen Hierarchien, kurzen Entscheidungswegen und einer Kultur, in der jede individuelle Geschichte zählt

-

**Stabilität:** Unbefristete Festanstellung in einem wachsenden, wirtschaftlich gesunden Unternehmen

#### **Kontakt**

Hypertrics GmbH
Schürmannstraße 22a
45136 Essen

####

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
