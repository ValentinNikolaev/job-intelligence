# Lead Software Engineer GenAI Enterprise Applications (m/w/d) - Hybrid (deutschlandweite Standorte)

Posted: 2026-09-03T13:30:39Z

## Rejection

- Category: tech_stack
- Reason: Spring Boot is not a target stack

**Vollzeit · bundesweit an mehreren Standorten · hybrid mit 3 Tagen remote pro Woche · Reisebereitschaft zu Kunden ca. 20–30 %**

Du hast schon AI-Features in Produktion gebracht – und weißt, dass die Demo der einfache Teil war? Lust, nicht-deterministische Systeme wirklich enterprise-tauglich zu machen, statt beim PoC stehenzubleiben?

Dein künftiger Arbeitgeber ist eines der führenden IT-Beratungshäuser im deutschsprachigen Raum – technikgetrieben, mittelständisch geprägt und mit GenAI als Top-Priorität des gesamten Unternehmens. Eine offizielle Partnerschaft mit einem der weltweit führenden AI-Labs, ein eigenes Vorgehensmodell für agentische Entwicklung und ein GenAI-Geschäft, das im ersten Halbjahr Auftragseingänge im hohen zweistelligen Millionenbereich von über 70 Kunden gebracht hat: Hier wird nicht experimentiert, hier wird geliefert.

In dieser Rolle bist du der Brückenbauer zwischen Modell und Produktion: Du bringst AI dorthin, wo sie am schwersten und am wertvollsten ist – in geschäftskritische Enterprise-Anwendungen. Zur Ehrlichkeit gehört: Das ist kundengetriebene Projektarbeit mit Workshops, Angebotsunterstützung und wechselnden Einsätzen von drei bis sechs Monaten. Keine Produktentwicklung, keine reine Architektenrolle am Whiteboard – du baust mit.

## Aufgaben

- Du integrierst AI in Enterprise-Software: agentische Systeme, RAG-Architekturen und Tool-Calling – eingebettet in gewachsene Anwendungslandschaften statt auf der grünen Wiese.

- Du machst Nicht-Determinismus beherrschbar: AI-Gateways, deterministische Kontrollschichten und Guardrails – plus Tests und Telemetrie, damit das Verhalten von AI-Komponenten nachvollziehbar, überwachbar und steuerbar bleibt.

- Du reduzierst Medienbrüche in bestehenden Prozessen, indem du AI dort einbaust, wo heute noch manuell übertragen, geprüft und nachgearbeitet wird.

- Du begleitest Lösungen von der Idee bis in die Produktion – inklusive Workshops beim Kunden und technischer Unterstützung in Angebotssituationen.

## Qualifikation

- Du bringst tiefe Erfahrung aus komplexen Enterprise-Projekten mit – idealerweise in Microservice- oder Event-getriebenen Architekturen, mit sehr guten Kenntnissen in Java/Spring Boot/Quarkus und/oder TypeScript/React/Angular/Vue (Docker, Kubernetes und Cloud-Erfahrung sind ein Plus).

- Du hast AI-Lösungen produktiv gemacht: RAG, Tool-Calling oder agentische Systeme – und du trennst AI-Komponenten sauber von der Core-Logik. Separation of Concerns statt Prompt-Zoo im Code.

- Du arbeitest selbst mit AI-Coding-Werkzeugen wie Claude Code, Copilot oder Cursor – produktiv, nicht nur zum Ausprobieren.

- Du sprichst Deutsch auf C1-Niveau und sehr gutes Englisch und willst bewusst kundengetrieben arbeiten – wechselnde Einsätze inklusive.

## Benefits

- AI-Projekte, die zählen: AI-Integration in geschäftskritische Enterprise-Anwendungen und agentische Modernisierung von Legacy-Landschaften – bei Kunden mit echtem Budget und echtem Druck.

- Ein Umfeld mit offizieller AI-Lab-Partnerschaft, über 200 Kolleg:innen in Zertifizierung und der wohl größten AI-Praktiker-Community im deutschsprachigen Raum.

- Kultur mit technischem Anspruch: mittelständisch geprägt, gründernah, Qualität der Arbeit zählt – nicht nur die Marge.

- Ein neues Vergütungsmodell statt altem Deckel: knapp sechsstelliges Grundgehalt, Gesamtpaket bis 120.000–130.000 € erreichbar, variable Komponente an deinem eigenen Hebel.

- Hybrides Set-Up mit 3 Tagen Home-Office je Woche, 20 Bürostandorte innerhalb Deutschlands

**Klingt nach dir?** Dann bewirb dich jetzt!

Sobald ich deine Unterlagen geprüft habe, wäre ein kurzer Austausch der nächste Schritt, damit ich dir verrate, um welchen Kunden es geht.

Der weitere Prozess ist kurz, da bei Interesse alle relevanten Infos aus den Pflichtfragen an den Kunden weitergeleitet werden.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
