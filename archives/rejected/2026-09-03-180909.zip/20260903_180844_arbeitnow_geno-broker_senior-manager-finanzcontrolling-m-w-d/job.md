# Senior Manager Finanzcontrolling (m/w/d)

Posted: 2026-09-03T13:00:33Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Die GENO Broker GmbH ist der Online Broker innerhalb der Genossenschaftlichen FinanzGruppe. Als 100%-ige Tochtergesellschaft der DZ BANK AG kooperieren wir u.a. mit den Volks- und Raiffeisenbanken im Wertpapiergeschäft. Dabei bieten wir den Kunden unserer Kooperationsbanken günstige Depots und eine innovative Handelsplattform an - digital und in der Filiale vor Ort. Auf Grund der Nachfolgeplanung, suchen wir eine engagierte Verstärkung für unser Finanzen- Team.

## Aufgaben

**Deine neuen Herausforderungen**

- Laufende Bearbeitung und Weiterentwicklung des Ertrags- und Kostencontrollings

- Erstellen von regelmäßigen Management-Berichten zum Kosten und Ertrags-Controlling

- Mitarbeit bei der laufenden Buchhaltung, insbesondere im Hinblick auf Kontrolle und Qualitätssicherung

- Abstimmung und Führung von Aufwands- und Ertragskonten der Bank

- Ansprechpartner für Wirtschaftsprüfer sowie die Konzern-Revision der DZ BANK AG

- Unterstützung des Ressortleiters und der Geschäftsführung bei Fragen zur Bilanzierung und zum Controlling der Bank.

## Qualifikation

**Dein Profil**

- Kaufmännische Ausbildung mit entsprechender Fortbildung im Bereich der Buchhaltung

- Fundierte Kenntnisse von den Prozessen im Controlling und Buchhaltung in einer Bank

- Ausgeprägte Hands-On Mentalität und Spaß an der Neukonzeptionierung von Prozessen

- Sehr gute konzeptionelle sowie analytische Fähigkeiten, ausgeprägte Affinität zu Zahlen

- Ausgezeichnete Kenntnisse in den gängigen MS Office Anwendungen insbesondere MS Excel

- Darüber hinaus zeichnen dich Spaß an Teamarbeit und deine gute Kommunikationsfähigkeit aus

## Benefits

**Deine Vorteile**

Neben einer vielseitigen und abwechslungsreichen Tätigkeit im Herzen von Frankfurt wirst Du Teil eines dynamischen und motivierten Teams, das die Umsetzung eines innovativen Geschäftsmodells mit Fokus auf das Wertpapiergeschäft verfolgt. In diesem Rahmen bieten wir Dir Freiraum für Deine persönliche Entwicklung und fördern Dich dabei über gezielte Fortbildungsmaßnahmen. Durch das Leben flacher Hierarchien kannst Du die Entwicklung des GENO Broker mitgestalten.

- Mobiles Arbeiten – gerne stellen wir auch die benötigte Hardware dafür

- Nutzung der DZ BANK Corporate Benefits

- Vermögenswirksame Leistungen

- eGYM-Wellpass für 30 EUR Eigenbeitrag

- Kostenfrei zur Verfügung gestelltes Deutschlandticket

- Nutzung unseres Job Rad-Angebots

- Bezuschusste Mitarbeiterkantine der DZ BANK

- Firmenevents sowie ein kostenloses Angebot an Kaffee und Wasser

- Vorteile eines Mitarbeiters der genossenschaftlichen Finanzgruppe

Bitte richte Deine aussagefähigen Bewerbungsunterlagen (Lebenslauf, Zeugnisse) per E-Mail an:

Leiter Finanzen und Personal

Herr Pascal Seidel

GENO Broker GmbH

Platz der Republik 6

60325 Frankfurt am Main

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
