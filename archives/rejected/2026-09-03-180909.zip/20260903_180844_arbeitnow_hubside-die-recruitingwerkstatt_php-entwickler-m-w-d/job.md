# PHP Entwickler (m/w/d)

Posted: 2026-09-03T14:00:41Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Du bist leidenschaftlicher Softwareentwickler mit Erfahrung in PHP und modernen Web-Technologien? Du möchtest in einem agilen Team innovative Features entwickeln, bestehende Prozesse hinterfragen und aktiv an Weiterentwicklungen mitwirken? Dann bewirb Dich jetzt und wir stellen Dich unserem Kunden nordwestlich von München vor!

Du kennst jemanden der auf die Stellenausschreibung passt? Dann hole Dir jetzt unseren **Weiterempfehlungsbonus**! Erkundige Dich gleich telefonisch unter 089 9982966 47 bei mir.

## Aufgaben

- Du bist als Softwareentwickler das Herzstück und übernimmst bei uns die gesamte Inhouse-Programmierung

- Im Scrum-Team bist Du für die Planung und Entwicklung neuer Features verantwortlich und bringst Deine Expertise ein

- Du arbeitest aktiv an der Weiterentwicklung unseres Shops und bist bei neuen Projekten von der ersten Idee an dabei

- Sauberer Code, Continuous Integration und Automatisierung sind für Dich grundlegende Bestandteile Deiner Arbeit

- Bestehende Arbeitsabläufe hinterfragst Du kritisch, um kontinuierliche Optimierungen unserer Software zu erreichen

- Du bringst eigene Ideen ein, teilst Dein Wissen gerne im Team und trägst so zur weiteren Erfolgsgeschichte bei

## Qualifikation

- Du verfügst über fundierte Kenntnisse in der objektorientierten Softwareentwicklung mit PHP, idealerweise ergänzt durch Erfahrung mit Frameworks wie Zend oder Symfony und Doctrine

- Design Patterns, moderne Web-Frameworks und Datenbanken gehören ebenso zu Deinem Repertoire wie alles, was zur aktuellen Web-Entwicklung zählt

- Du hast bereits Erfahrung in der Entwicklung geschäftskritischer Anwendungen gesammelt und weißt, worauf es dabei ankommt

- Der Umgang mit relationalen Datenbanken und großen Datenmengen liegt Dir und ist fester Bestandteil Deiner Arbeit

- Automatisiertes Testen und Continuous Integration sind Dir vertraut und gehören zu Deinem Werkzeugkasten

- Du schätzt das Start-Up-Feeling und schaust gern über Deinen Tellerrand hinaus, um auch in andere Unternehmensbereiche einzutauchen

## Benefits

- **Coole Team-Events** und spontane Grillabende

- **EGYM WELLPASS** für Fitness und Wellness

- **JobRad**

- **Regelmäßige Feedbackgespräche** und Ziele

- Kostenlos **Kaffee, Getränke und Obst**

- Empfehle erfolgreich jemanden für die Stelle, und **Du erhältst eine Werbeprämie von 1000 Euro**

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
