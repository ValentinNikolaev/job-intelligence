# Testingenieur:in Automation R&S Kommunikationssysteme, Dresden 60.000 - 80.000

Posted: 2026-09-03T14:00:39Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Wir arbeiten exklusiv für diesen Kunden und stellen bei dieser Position direkt auf Entscheiderebene im Fachbereich Kandidaten vor. Unser Kunde entwickelt Technologien für anspruchsvolle technische Systeme und arbeitet dabei an Lösungen, bei denen Software, Elektronik und digitale Hardware eng zusammenspielen. Der Schwerpunkt liegt auf der Entwicklung und Absicherung moderner Kommunikations- und Übertragungstechnologien für komplexe Systeme.

Dich erwartet ein technisch anspruchsvolles Umfeld, in dem Softwareentwicklung nicht isoliert betrachtet wird. Stattdessen arbeitest Du an der Schnittstelle verschiedener Disziplinen und kannst aktiv mitgestalten, wie zuverlässige und robuste Produkte entstehen.

Wenn Du Freude daran hast, technische Zusammenhänge wirklich zu verstehen, gerne selbst Lösungen entwickelst und Dich für die Verbindung von Software und Hardware begeisterst, bietet Dir unser Kunde ein Umfeld mit viel Gestaltungsspielraum und spannenden technischen Fragestellungen.

## Aufgaben

**Deine Mission**

- Du entwickelst und automatisierst Tests für komplexe Kommunikations- und Elektroniksysteme

- Dein Schwerpunkt liegt auf Komponenten- und Gerätetests

- Du entwickelst bestehende Testframeworks kontinuierlich weiter und optimierst deren Zuverlässigkeit und Wartbarkeit

- Du analysierst technische Anforderungen, leitest daraus geeignete Testszenarien ab und überführst diese in automatisierte Testabläufe

- Du integrierst automatisierte Tests in bestehende Entwicklungs- und CI/CD-Prozesse

- Du unterstützt bei der Analyse und Bewertung von Testergebnissen und trägst dazu bei, Fehlerursachen systematisch einzugrenzen

## Qualifikation

- Du hast Spaß daran, komplexe technische Systeme zu analysieren und Lösungen auch dann zu finden, wenn mehrere technische Disziplinen zusammenspielen

- Du entwickelst gerne selbst und bringst Erfahrung in der Softwareentwicklung mit; idealerweise hast Du bereits automatisierte Tests, Testframeworks oder Testsysteme umgesetzt

- Du kennst Dich mit Regressions- und Abnahmetests bestens aus

- Du kannst sicher mit dem Robot Framework arbeiten

- Du bringst tiefgreifendes Know How in Python mit

- Du kannst technische Anforderungen analysieren und daraus nachvollziehbare und systematische Testszenarien ableiten

- Automatisierung ist für Dich ein wichtiger Bestandteil guter Softwareentwicklung: Deine Tests sollen zuverlässig, reproduzierbar und in bestehende Entwicklungsprozesse integrierbar sein

- Bei Fehlern möchtest Du die Ursache verstehen und nicht nur das Testergebnis dokumentieren

- Du arbeitest gerne interdisziplinär und kannst Dich mit Software-, Hardware- und digitalen Hardware-Entwicklern über technische Zusammenhänge austauschen

- Du arbeitest strukturiert und qualitätsbewusst und findest gleichzeitig pragmatische Lösungen für technische Herausforderungen

- Du hast ein Studium der Informatik, Elektrotechnik, Nachrichtentechnik oder einer vergleichbaren technischen Fachrichtung abgeschlossen

- Sehr gute Deutsch- und Englischkenntnisse runden Dein Profil ab

**Bitte schätze Dich ein (1=das Schwächste und 10=das Stärkste)**

- Erfahrung in der Testentwicklung=

- Komponenten- und Gerätetests=

- Python=

- ROBOT Framework=

- Git=

- Continuous Integration=

- Linux Betriebssysteme=

## Benefits

- Strukturierte Einarbeitung mit intensivem Training-on-the-Job: Du wirst von Beginn an praxisnah begleitet, erhältst eine fundierte Einführung in Produkte, Prozesse und Märkte und profitierst von erfahrenen Kolleginnen und Kollegen, die ihr Know-how aktiv weitergeben

- Attraktive Work-Life-Balance: 30 Tage Jahresurlaub sowie klar geregelte Sonderurlaube bieten Planungssicherheit und ausreichend Erholungszeit

- Flexible Arbeitszeitmodelle: Gestaltungsspielraum bei der Arbeitszeit sorgt für eine gute Vereinbarkeit von Beruf und Privatleben

- Individuelle Weiterbildungs- und Entwicklungsmöglichkeiten: Fachliche und persönliche Weiterentwicklung wird aktiv gefördert – durch Schulungen, Trainings und gezielte Entwicklungsprogramme

- Betriebliches Gesundheitsmanagement: Umfassende Angebote wie ein Employee Assistance Program (EAP) sowie Bike-Leasing unterstützen Ihre Gesundheit und Ihr Wohlbefinden

Hast Du Fragen?

Ansprechpartner: Alexander Wuthenow, Tel: 030 2065 84-59

* Gleichberechtigung ist uns wichtig. Diese Stellenanzeige richtet sich an alle Menschen. Bei der Stellenvergabe spielt die ethnische Herkunft, das Geschlecht, das Alter, die sexuelle Identität oder Behinderungen weder mittelbar noch unmittelbar eine Rolle.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
