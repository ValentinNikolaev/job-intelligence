# Account Executive

Posted: 2026-09-03T11:40:10Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

At Almetra, we’re on a mission to reinvent how factories work.

We help manufacturers - one of the most essential and overlooked sectors of our economy - run better. Every car, wind turbine, medical device, and washing machine comes from a factory. But factories today are running out of people. They struggle with efficiency, safety, and quality - and they desperately need better tools to understand what’s happening on the shop floor.

That’s where we come in. Almetra builds AI-powered computer vision systems that give manufacturers deep visibility into how their production lines actually run - and the insights to improve them. We don’t sell ads or marketing software. We help real factories solve real problems.

You’ll be joining at a pivotal moment as we scale from an early-stage startup into a category-defining company.

**Why join us**

-

**Mission with real impact**. You’ll help the world’s most essential companies stay competitive, sustainable, and safe in a world of labor shortages and rising costs.

-

**Category-defining moment. **With global manufacturers already deploying Almetra and fresh funding, we’re scaling fast across Europe and the US.

-

**Big deals, big influence.** You’ll lead 6-digit enterprise sales cycles, shape our go-to-market motion, and be a core driver of our revenue engine.

-

**High bar, high trust**. You’ll work directly with founders, product, and engineering to design solutions and expand strategic accounts.

**What you’ll do**

-

Run full-cycle 6-digit enterprise deals across Europe and North America.

-

Partner with SDRs, Growth, and Almetra Engineers to land and expand high-value accounts.

-

Build trust with leaders in operations, engineering, quality, and IT/OT.

-

Lead sharp discovery and clearly show how Almetra transforms factory performance.

-

Navigate complex, multi-stakeholder enterprise cycles (legal, security, procurement).

-

Drive expansions and help shape our repeatable GTM playbook.

-

Maintain tight pipeline hygiene, forecast accurately, and consistently hit your number.

**What we’re looking for**

-

4+ years of full-cycle enterprise sales with a track record of beating quota.

-

Hungry, gritty, fast - you own deals and outcomes.

-

Proven ability to run complex, multi-stakeholder enterprise cycles.

-

Strong negotiator, confident with redlines, legal, and security reviews.

-

Comfortable visiting plants and learning how factories actually run.

-

Disciplined with CRM, forecasting, and deal management.

-

Team player across Growth, SDRs, Product, CS, and Engineering.

-

Familiar with GDPR and enterprise onboarding requirements.

**Bonus points**

-

Experience selling AI, automation, robotics, or advanced manufacturing solutions.

-

Background in operations, production, or industrial engineering (formally or through customer exposure).

-

Interest in building and operationalizing a repeatable enterprise GTM playbook.

-

German or English fluent speaker.

#LI-SP

**What we offer**

Employee Share Options Program for all permanent employees*

An increasing benefits list: currently includes Urban Sports club and quarterly team retreats.

Be on the forefront in defining what artificial intelligence means in manufacturing

Gain hands-on experience in working in an AI-first software company

Supportive and inclusive culture that values diversity and promotes the advancement of underrepresented groups within the company

Collaborate with a diverse (currently more than 10 nationalities) and talented team, working on cutting-edge projects with real-world impact

Network with professionals and leaders in the field, opening doors to potential future career opportunities

We have a very flat hierarchy, open 360° feedback, and flexible working hours

Ethics⚖: We are committed to developing ethical AI software

**Don't meet all the requirements?**

*Almetra is committed to creating a workplace that is diverse, fair, and inclusive. We encourage candidates from all backgrounds, even if they do not meet every qualification, to submit their application. We firmly believe that having a team with diverse perspectives only strengthens our company and drives innovation. Our commitment also extends to providing an accessible environment for everyone, including those with disabilities. Please let us know if you require any accommodations during the application process or while working with us, and we will do our best to support you.*

**Only full-time, permanent roles are eligible for stock options. Part-time roles, contract roles, work-student, internships and freelance roles are not eligible for stock options.*

Compensation: €70K – €90K • Offers Equity • Uncapped Comission

- • 50/50 OTE €70K – €90K • Offers Equity • Uncapped Comission

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
