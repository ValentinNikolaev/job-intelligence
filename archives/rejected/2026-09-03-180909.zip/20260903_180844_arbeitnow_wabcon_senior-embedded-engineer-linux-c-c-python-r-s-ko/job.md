# Senior Embedded Engineer Linux C/C++, Python, R&S - Kommunikationssysteme, Dresden 70.000 - 95.000

Posted: 2026-09-03T14:00:39Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Wir arbeiten exklusiv für diesen Kunden und stellen bei dieser Position direkt auf Entscheiderebene im Fachbereich Kandidaten vor. Unser Kunde entwickelt Technologien für anspruchsvolle technische Systeme und arbeitet dabei an Lösungen, bei denen Software, Elektronik und digitale Hardware eng zusammenspielen. Der Schwerpunkt liegt auf der Entwicklung und Absicherung moderner Kommunikations- und Übertragungstechnologien für komplexe Systeme.

Dich erwartet ein technisch anspruchsvolles Umfeld, in dem Softwareentwicklung nicht isoliert betrachtet wird. Stattdessen arbeitest Du an der Schnittstelle verschiedener Disziplinen und kannst aktiv mitgestalten, wie zuverlässige und robuste Produkte entstehen.

Wenn Du Freude daran hast, technische Zusammenhänge wirklich zu verstehen, gerne selbst Lösungen entwickelst und Dich für die Verbindung von Software und Hardware begeisterst, bietet Dir unser Kunde ein Umfeld mit viel Gestaltungsspielraum und spannenden technischen Fragestellungen.

## Aufgaben

- Entwicklung von Softwarekomponenten für die Satellitenkommunikation

- Begleitung des kompletten Entwicklungsprozesses von der Prototypenphase bis zur SerienreifeImplementierung von Kommunikationsstandards und Protokollen

- Erstellung von Unit- und Systemtests zur QualitätssicherungFehleranalyse, Diagnose und Debugging von Softwarelösungen

- Entwicklung und Optimierung von Algorithmen für die Datenverarbeitung

- Konfiguration und Anpassung von Betriebssystemen, auch in Echtzeitumgebungen

- Zusammenarbeit in interdisziplinären Teams mit Hardware-, Software-, System- und Testentwicklern

## Qualifikation

- technisches Studium (z. B. Informatik, Ingenieurwesen) oder vergleichbare Qualifikation

- Vertiefte Kenntnisse in der Softwareentwicklung

- Fortgeschrittene Programmierkenntnisse in C/C++, Python

- Praktische und belastbare Erfahrung mit Linux - Betriebssystemen und deren Programmierung

- Kenntnisse in Softwaretests und Testtools

- Grundlegendes Verständnis von Virtualisierungstechnologien von Vorteil

- Erfahrung mit Versionsverwaltung und Continuous Integration wünschenswert

- Kenntnisse in Kommunikationstechnologien von Vorteil

- sehr gute Deutschkenntnisse

**Bitte schätze Dich ein (1=das Schwächste und 10=das Stärkste)**

- Erfahrung im Technologiebereich: Embedded Linux=

- C=

- C++=

- Python=

- Deutschkenntnisse=

- **Kein Must:** Hattest Du schon einmal Berührungspunkte mit dem Bereich der Nachrichtentechnik?=

- **Kein Must:** Hattest Du schon einmal Berührungspunkte mit Modulationsverfahren?=

- **Kein Must:** Hattest Du schon einmal Berührungspunkte mit dem Bereich SNR?=

- **Kein Must:** Hattest Du schon einmal Berührungspunkte im Bereich Embedded ARM?=

## Benefits

- Strukturierte Einarbeitung mit intensivem Training-on-the-Job: Du wirst von Beginn an praxisnah begleitet, erhältst eine fundierte Einführung in Produkte, Prozesse und Märkte und profitierst von erfahrenen Kolleginnen und Kollegen, die ihr Know-how aktiv weitergeben.

- Attraktive Work-Life-Balance: 30 Tage Jahresurlaub sowie klar geregelte Sonderurlaube bieten Planungssicherheit und ausreichend Erholungszeit.

- Flexible Arbeitszeitmodelle: Gestaltungsspielraum bei der Arbeitszeit sorgt für eine gute Vereinbarkeit von Beruf und Privatleben.

- Individuelle Weiterbildungs- und Entwicklungsmöglichkeiten: Fachliche und persönliche Weiterentwicklung wird aktiv gefördert – durch Schulungen, Trainings und gezielte Entwicklungsprogramme.

- Betriebliches Gesundheitsmanagement: Umfassende Angebote wie ein Employee Assistance Program (EAP) sowie Bike-Leasing unterstützen Ihre Gesundheit und Ihr Wohlbefinden.

Hast Du Fragen?

Ansprechpartner: Alexander Wuthenow, Tel: 030 2065 84-59

* Gleichberechtigung ist uns wichtig. Diese Stellenanzeige richtet sich an alle Menschen. Bei der Stellenvergabe spielt die ethnische Herkunft, das Geschlecht, das Alter, die sexuelle Identität oder Behinderungen weder mittelbar noch unmittelbar eine Rolle.

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
