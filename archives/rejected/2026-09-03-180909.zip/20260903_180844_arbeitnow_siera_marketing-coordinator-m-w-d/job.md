# Marketing Coordinator (m/w/d)

Posted: 2026-09-03T14:00:40Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Über SIERA

SIERA gestaltet Zukunft mit verantwortungsvoller Ingenieurleistung, innovativen Ideen und internationaler Zusammenarbeit. Als Unternehmen für Umweltingenieurwesen und Beratung entwickeln wir nachhaltige Lösungen für Klima, Wasser, Umwelt und Infrastruktur.

An über 33 Standorten in Deutschland arbeiten mehr als 800 Mitarbeitende über vier Kontinente hinweg an Projekten mit langfristiger Wirkung.

„Engineering for a Better Tomorrow“ – gemeinsam schaffen wir Fortschritt für Umwelt, Wirtschaft und Gesellschaft.

Ihre Aufgabe

Für unseren Standort in Nürnberg suchen wir eine kreative und kommunikationsstarke Person, die komplexe Inhalte aus unseren Fachbereichen in überzeugende Marketingkommunikation verwandelt. Sie verstehen die Zusammenhänge unserer Dienstleistungen, Projekte und Technologien und machen daraus Inhalte, die informieren, begeistern und die Marke SIERA erlebbar machen. Dabei arbeiten Sie eng mit einem internationalen Team sowie unterschiedlichen Fachbereichen zusammen. Sie gestalten unsere Kommunikation gemeinsam weiter, bringen eigene Ideen ein und können zugleich auf vielfältige Expertise innerhalb von SIERA zurückgreifen.

Ihre Aufgaben

- Sie entwickeln und realisieren kreative Marketing- und Kommunikationsmaßnahmen für SIERA.

- Sie verwandeln unsere Dienstleistungen, Projekte und Technologien in verständliche und überzeugende Inhalte.

- Sie gestalten Präsentationen, Broschüren, Flyer, Webinare, Events und digitale Kommunikationsformate.

- Sie erzählen die SIERA Story über Website, Social Media, Newsletter und Kampagnen weiter.

- Sie sorgen dafür, dass jedes Marketingmaterial die Marke SIERA, unsere Werte und unsere Expertise authentisch widerspiegelt.

- Sie arbeiten eng mit Fachbereichen, Führungskräften, dem SIERA Board und internationalen Teams in deutscher und englischer Sprache zusammen.

- Sie bringen neue Ideen ein und entwickeln Formate, die SIERA sichtbar und erlebbar machen.

Ihr Profil

- Ausbildung oder Studium im Bereich Marketing, Kommunikation, Medien oder eine vergleichbare Qualifikation

- Kreativität, ein gutes Gespür für Gestaltung und Freude an wirkungsvollem Storytelling

- Interesse daran, technische und fachliche Zusammenhänge zu verstehen und klar zu vermitteln

- Sehr gute Kommunikationsfähigkeiten in Deutsch und Englisch, schriftlich wie mündlich

- Selbstständige, strukturierte und ideenreiche Arbeitsweise

- Organisationstalent, Eigeninitiative und Freude an internationaler Zusammenarbeit

Wir bieten

- Eine vielseitige Position mit viel Raum für eigene Ideen und kreative Gestaltung

- Die Möglichkeit, die Kommunikation und Markenidentität von SIERA aktiv mitzuprägen

- Enge Zusammenarbeit mit unterschiedlichen Fachbereichen und internationalen Teams

- Kurze Entscheidungswege und ein offenes, vielfältiges Arbeitsumfeld

- Entwicklungsmöglichkeiten und einen modernen Arbeitsplatz in Nürnberg

Ihr Arbeitsplatz bei SIERA

Unser Standort in Nürnberg verbindet Tradition mit Fortschritt: Sie arbeiten in besonderen, traditionsreichen Räumlichkeiten, die zugleich modern, zeitgemäß und auf einem hohen digitalen Niveau ausgestattet sind. Freuen Sie sich auf ein Umfeld, in dem Zusammenarbeit, Kreativität und neue Ideen ihren Platz haben. Wir freuen uns auf Ihre Bewerbung und darauf, SIERA gemeinsam mit Ihnen weiterzuentwickeln.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
