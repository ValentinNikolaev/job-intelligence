# Recruiter (m/w/d)

Posted: 2026-09-03T14:00:39Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Über SIERA

SIERA gestaltet Zukunft mit verantwortungsvoller Ingenieurleistung, innovativen Ideen und internationaler Zusammenarbeit. Als Unternehmen für Umweltingenieurwesen und Beratung entwickeln wir nachhaltige Lösungen für Klima, Wasser, Umwelt und Infrastruktur.

An über 33 Standorten in Deutschland arbeiten mehr als 800 Mitarbeitende über vier Kontinente hinweg an Projekten mit langfristiger Wirkung.

„Engineering for a Better Tomorrow“ – gemeinsam schaffen wir Fortschritt für Umwelt, Wirtschaft und Gesellschaft.

Über die Position

Für unser Team in Nürnberg suchen wir einen Recruiter (m/w/d) mit Fokus auf die direkte Gewinnung passender Talente. Sie identifizieren qualifizierte Kandidaten, sprechen diese aktiv an und steuern den Auswahlprozess bis zur erfolgreichen Besetzung – in enger Zusammenarbeit mit den Fachbereichen und unserem Recruiting-Team.

Ihre Aufgaben

- Aktive Suche, Identifikation und Direktansprache geeignete Kandidaten (u. a. LinkedIn, Netzwerke, Plattformen)

- Sichtung und Vorauswahl von Profilen und Bewerbungen

- Durchführung strukturierter Erstgespräche inkl. Einschätzung fachlicher und persönlicher Eignung

- Koordination und Begleitung der Interviews mit den Fachbereichen

- Aufbau, Pflege und Entwicklung eines belastbaren Kandidatennetzwerks (Talentpool)

- Sicherstellung einer schnellen, wertschätzenden und professionellen Kommunikation im gesamten Recruiting-Prozess

- Kontinuierliches Monitoring der Pipeline sowie Ableitung von Maßnahmen zur Besetzungsbeschleunigung

Ihr Profil

- Erfahrung im Recruiting, Active Sourcing oder Talent Acquisition

- Nachweisliche Routine in der Direktansprache (z. B. LinkedIn Recruiter oder vergleichbare Tools)

- Treffsicheres Gespür für passende Profile und Anforderungen unterschiedlicher Fachbereiche

- Ausgeprägte Kommunikationsstärke, Eigeninitiative und zielorientierte Arbeitsweise

- Sehr gute Deutsch- und Englischkenntnisse in Wort und Schrift

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
