# Lead Software Engineer GenAI-Engineering / Agentic Coding (m/w/d) - Hybrid (deutschlandweite Standorte)

Posted: 2026-09-03T13:00:33Z

## Rejection

- Category: tech_stack
- Reason: Spring Boot is not a target stack

**Vollzeit · bundesweit an mehreren Standorten · hybrid mit 3 Tagen remote pro Woche · Reisebereitschaft zu Kunden ca. 20–30 %**

***Du arbeitest längst agentisch – während dein Umfeld noch über Autocomplete diskutiert? Was wäre, wenn agentische Entwicklung nicht dein privates Experiment wäre, sondern die erklärte Strategie deines Arbeitgebers?***

Hinter dieser Rolle steht eines der führenden IT-Beratungshäuser im deutschsprachigen Raum: technikgetrieben, mittelständisch geprägt, mit GenAI als Top-Priorität des Konzerns und einer offiziellen Partnerschaft mit einem der weltweit führenden AI-Labs. Bei der internen Vorstellung des eigenen agentischen Vorgehensmodells platzte der Teams-Raum mit über 1.000 Teilnehmenden – das Momentum ist real.

Als Lead bist du der Taktgeber, der Agentic Coding in echten Kundenprojekten etabliert. Damit du das richtig einordnest: Das ist eine operative Hands-on-Rolle im kundengetriebenen Projektgeschäft – keine reine Führungsposition und keine Produktentwicklung. Du gehst für drei bis sechs Monate in ein Team, hebst es auf agentisches Arbeiten, und ziehst dann weiter zum nächsten. Genau dieser Hebel macht die Rolle so wirksam.

## Aufgaben

- Du etablierst agentische Entwicklung in Kundenprojekten – mit Claude Code als Kernwerkzeug, von der ersten Einrichtung bis zur gelebten Team-Praxis.

- Du baust die Infrastruktur drumherum: Review-Agenten, MCP-Server, Test- und Doku-Assistants und AI in der CI/CD-Pipeline, damit agentisches Arbeiten skaliert statt zu improvisieren.

- Du entwickelst Playbooks, die aus deinen Projekterfahrungen wiederverwendbare Standards machen – für dein Team und die Teams danach.

- Du coachst Entwicklerteams on the job – auch in Pair- und Mob-Programming-Sessions – und unterstützt in Workshops und Angebotssituationen als technische Referenz.

## Qualifikation

- Du bist Softwareentwickler:in durch und durch – mit mehrjähriger Erfahrung aus komplexen Enterprise-Projekten, idealerweise mit Verantwortung als Lead Dev, Tech Lead oder Principal, und sehr guten Kenntnissen in mindestens einem Enterprise-Stack (z. B. Java/Spring Boot/Quarkus oder TypeScript/React/Angular/Vue).

- Du arbeitest produktiv agentisch: Claude Code, Copilot oder Cursor sind Teil deines echten Arbeitsalltags, und du kannst konkret belegen, was sich dadurch verändert hat.

- Du kennst moderne Delivery-Praxis: Clean Code, Testing, CI/CD, Microservices und Deployment-Umgebungen wie Docker, Kubernetes und Cloud – und hast Ideen, wo Agenten diese Kette wirklich besser machen.

- Du sprichst Deutsch auf C1-Niveau (plus gutes Englisch) und willst bewusst ins Projektgeschäft mit wechselnden Einsätzen – enablen, weiterziehen, Neues aufsetzen.

## Benefits

- Agentische Entwicklung als Firmenstrategie: eigenes Vorgehensmodell, Entwicklungszyklen von 2–4 Tagen statt Wochen-Sprints – du setzt um, was andere noch ankündigen.

- Offizielle Partnerschaft mit einem führenden AI-Lab und über 200 Kolleg:innen in der Architektur-Zertifizierung – vermutlich die größte AI-Praktiker-Community im deutschsprachigen Raum.

- Projekte mit Substanz: agentische Modernisierung gewachsener Legacy-Landschaften bei Enterprise-Kunden – im zweiten Schritt AI direkt in die Anwendungen.

- Ein Vergütungsmodell ohne alten Deckel: knapp sechsstelliges Grundgehalt, Gesamtpaket bis 120.000–130.000 € erreichbar, variable Komponente an deinem eigenen Hebel.

- Hybrides Set-Up mit 3 Tagen Home-Office je Woche, 20 Bürostandorte innerhalb Deutschlands

**Klingt nach dir?** Dann bewirb dich jetzt!

Sobald ich deine Unterlagen geprüft habe, wäre ein kurzer Austausch der nächste Schritt, damit ich dir verrate, um welchen Kunden es geht.

Der weitere Prozess ist kurz, da bei Interesse alle relevanten Infos aus den Pflichtfragen an den Kunden weitergeleitet werden.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
