# Producer (f/m/d)

Posted: 2026-09-03T11:40:08Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Sunday creates pocket-sized friends for the mass market. We turn idle moments into meaningful connections for millions of users worldwide.

Sunday focuses on the psychology of care, companionship, and empathy. We build accessible worlds where players don't just solve puzzles, they rescue friends. By combining mass-market accessibility with deep emotional hooks, we are defining the next era of digital entertainment.

Sunday creates pocket-sized friends for the mass market. We turn idle moments into meaningful connections for millions of users worldwide.

Sunday focuses on the psychology of care, companionship, and empathy. We build accessible worlds where players don't just solve puzzles, they rescue friends. By combining mass-market accessibility with deep emotional hooks, we are defining the next era of digital entertainment.

### **The Position: What is a Producer at Sunday?**

At Sunday, a Producer is the central operational engine behind our game releases. You sit at the intersection of product, creative, and technical execution, taking full ownership of turning high-level roadmaps into live, polished games that millions of players interact with worldwide. You aren't just tracking tasks, you are driving velocity, clearing friction, and ensuring our cross-functional teams move fast without sacrificing quality.

In this role, you bridge strategy and execution. You manage the full end-to-end delivery cycle, from scoping sprint backlogs and optimizing art/UX asset pipelines to coordinating final store launches. You work daily with Tech Leads, Game Designers, Operations Managers, and Product Managers to align production schedules with key monetization, user acquisition, and live operations milestones. Beyond keeping Jira spotless and leadership informed on risks, you are a hands-on leader who directly manages and develops a team in art and UX production, fostering their growth while continuously scaling and refining studio-wide production processes.

**This role is on fixed term - 1 year contract with the possibility of extension.**

## **Core Responsibilities:**

-

Own the end-to-end delivery of features and releases across the portfolio, from roadmap planning and handover to store release.

-

Plan and run sprint cycle: scoping, capacity, dependencies, and the prioritisation from roadmap into production in alignment with internal stakeholders.

-

Coordinate daily with the Tech Leads, the Operations Managers, Game Designers and Product Managers to keep releases unblocked.

-

Lead, develop and grow a team of three in art and UX production, including performance and career development.

-

Keep the production tracking accurate and current in Jira, and report status, risks and blockers to the senior management.

-

Drive improvements to our production process, tooling and pipelines as the portfolio scales.

-

Align with Product, Growth, Monetization and Marketing on release timing and scope.

## **Fuel for the Adventure: What You Get at Sunday**

-

At least 3 years as a Producer or Project Manager in mobile games, with shipped titles.

-

Experience running an agile delivery cycle with a cross-functional team (engineering, art, design, QA and Product).

-

Experience managing people directly, or a clear readiness to take on line management.

-

Working knowledge of production pipelines and of art and UX asset workflows.

-

Confident with Jira and with release and version management.

-

Strong communication in English, written and spoken. German is a plus.

-

Based in Hamburg or willing to relocate, working hybrid from our Hamburg office.

## **Nice to have**

-

Experience in casual or hybrid-casual free-to-play, including live operations and A/B testing.

-

Background in technical art or a technical production discipline.

-

Experience introducing or improving production processes in a growing studio.

## Fuel for the Journey: Benefits to Support Your Ambitions

-

**Invest in Your Future**: Regular feedback and our development program support your growth, helping you expand your skill set and achieve your career goals.

-

**Easy Arrival to Sunday**: From signing to settling in Hamburg, we’ve got you covered. Need a visa? No problem. Ready to build your new life and career at applike in Hamburg? We support every ambition - from learning German to a relocation bonus that helps you settle in and make Hamburg feel like home.

-

**Live Your Best Life, at Work and Beyond**: We work in a hybrid setup with 3 core office days, plus flexible working hours. Enjoy 30 vacation days, 3 weeks of remote work per year, and free access to an in-house gym with lots of different fitness classes and mental health support through our Employee Assistance Program (EAP).

-

**Thrive Where You Work**: Enjoy the Alster Lake view from our central office with top-notch equipment, fun open spaces, and a large variety of snacks and drinks.

-

**Join the Community!** Participate in regular team and company events, including hackathons and social gatherings. We work together, and we celebrate together, too.

## The Interview Process:

-

1st Interview with TA

-

2nd Director of Operations

-

3rd Managing Directors

If you want to build the future of digital companionship, Sunday is your home. Apply now!

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
