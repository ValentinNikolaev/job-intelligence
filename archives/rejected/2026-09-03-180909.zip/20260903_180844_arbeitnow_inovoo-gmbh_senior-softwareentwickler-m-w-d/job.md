# Senior Softwareentwickler (m/w/d)

Posted: 2026-09-03T14:00:39Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Du brennst für innovative Technologien und willst mit Deiner Arbeit einen echten Mehrwert schaffen? Bei inovoo entwickeln Prozessautomatisierungslösungen auf Basis unserer eigenen KI-unterstützten Plattform. Damit ermöglichen wir unseren Kunden eine intelligente Dokumentenverarbeitung (IDP) und unkompliziertes Business Process Management (BPM).

## Aufgaben

Unsere kreativen Lösungen entstehen im direkten Miteinander. Deshalb ist unsere Arbeitsweise bewusst auf eine überwiegende Präsenz im Büro ausgerichtet. Wir setzen auf kurze Kommunikationswege, spontane fachliche Diskussionen und den kreativen persönlichen Austausch im Team. So entstehen schnelle Entscheidungen, effiziente Prozesse und ein Arbeitsumfeld, in dem Ideen gemeinsam wachsen können. Wenn auch Du diesen Arbeitsstil schätzt, freuen wir uns auf Deine Unterstützung als **Senior Softwareentwickler (m/w/d)** am Standort Augsburg-Haunstetten.

**Deine Aufgaben:**

- Konzeption und Umsetzung von Features in unserer .NET/Blazor-Anwendung

- Mitgestaltung technischer Entscheidungen und Architekturfragen

- Mentoring von weniger erfahrenen Teammitgliedern

- Weiterentwicklung von Datenmodellen und Datenzugriff mit Entity Framework Core

- Sicherstellen von Code-Qualität, Konventionen und guten Engineering-Praktiken im Team

**Tech-Stack:**

Blazor (Frontend) · .NET (Backend) · MS SQL Server & MongoDB · Entity Framework Core · Docker · Git · Azure DevOps · Visual Studio · Claude

## Qualifikation

**Das bringst Du mit:**

- Mehrjährige berufliche Erfahrung in der .NET-Entwicklung (C#), idealerweise inkl. Blazor

- Erfahrung mit relationalen und dokumentenbasierten Datenbanken (MS SQL Server, MongoDB)

- mit Docker, Git und Azure DevOps bist du bestens vertraut

- komplexe Zusammenhänge durchdringst du schnell und kannst diese verständlich vermitteln

- Freude an Verantwortung, Ownership und daran, dich und das Team fachlich voranzubringen

- Sehr gute Deutschkenntnisse sind aufgrund unserer nationalen Kundenstruktur zwingend erforderlich

## Benefits

Gleitzeitmodell rund um unsere Kernarbeitszeit

Möglichzeit zu mobilem Arbeiten an einem Tag pro Woche im Rahmen unserer einheitlichen Regelungen

unterschiedliche Weiterbildungsoptionen für deinen fachlichen Know-How Aufbau

Zugang zu Sonderkonditionen im Rahmen von Corporate Benefits

Kostenfreie Getränke im Büro und regelmäßige Mitarbeiter-Events

Du bist bereit, mit uns das Morgen zu gestalten? Wir freuen uns auf Dich und auf Deine Bewerbung.

Noch Fragen zu inovoo? Auf unserer Website findest du alles über uns und unsere Produkte.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
