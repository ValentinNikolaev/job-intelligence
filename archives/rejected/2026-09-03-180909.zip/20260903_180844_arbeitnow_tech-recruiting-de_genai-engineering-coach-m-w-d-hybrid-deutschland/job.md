# GenAI Engineering Coach (m/w/d) - Hybrid (deutschlandweite Standorte)

Posted: 2026-09-03T12:30:37Z

## Rejection

- Category: tech_stack
- Reason: Spring Boot is not a target stack

**Vollzeit · deutschlandweit · Hybrid mit projektbezogenen Kundenterminen**

Dein künftiger Arbeitgeber ist eines der führenden IT-Beratungshäuser im deutschsprachigen Raum – technikgetrieben, mittelständisch geprägt und mit GenAI als erklärter Top-Priorität des gesamten Unternehmens. Es gibt eine offizielle Partnerschaft mit einem der weltweit führenden AI-Labs, über 200 Kolleg:innen durchlaufen aktuell die zugehörige Architektur-Zertifizierung, und agentische Softwareentwicklung ist hier kein Experiment einzelner Teams, sondern Firmenstrategie mit eigenem Vorgehensmodell.

In dieser Rolle bist du der Zündfunke: Du machst Kundenorganisationen fit im Umgang mit AI-gestützter Entwicklung – und ziehst weiter, sobald das Team läuft. Ehrlich gesagt: Das ist kundengetriebene Beratungsarbeit mit wechselnden Einsätzen von drei bis sechs Monaten, inklusive Workshops und Angebotsunterstützung. Wer eine interne Enablement-Rolle oder Produktentwicklung sucht, wird hier nicht glücklich. Wer aber Wirkung in Serie will, findet kaum ein besseres Spielfeld.

## Aufgaben

- Du coachst Kundenorganisationen bei der Einführung von AI-Coding-Werkzeugen – von der Toollandschaft (Copilot, Cursor, MCP) bis zur gelebten Arbeitsweise im Team.

- Du baust Governance und Guardrails auf, damit AI-gestützte Entwicklung beim Kunden nicht nur schnell, sondern auch sicher und regelkonform läuft.

- Du konzipierst Einführungsprogramme und entwickelst selbst mit – von PoCs bis zu Referenzimplementierungen im Enterprise-Standardstack (z. B. Java/Spring Boot, TypeScript/React). Du bist Coach mit Commit-Historie, kein Folien-Berater.

- Du unterstützt in Workshops und Angebotssituationen als technisches Gesicht des Themas – auf Augenhöhe mit Entwicklern wie mit Entscheidern.

## Qualifikation

- Du bringst einen echten technischen Background aus der Softwareentwicklung mit – du hast selbst jahrelang in komplexen Enterprise-Projekten gebaut, nicht nur darüber gesprochen.

- Du arbeitest produktiv mit AI-Coding-Werkzeugen wie Claude Code, Copilot oder Cursor – im echten Projektalltag, nicht nur im Wochenend-Experiment.

- Du kannst Wissen übertragen: Teams enablen, Widerstände abholen, Arbeitsweisen verändern – und du magst genau diesen Teil der Arbeit.

- Du sprichst Deutsch auf C1-Niveau (plus gutes Englisch) und willst bewusst ins kundengetriebene Projektgeschäft – mit wechselnden Einsätzen statt Dauerprojekt.

## Benefits

- Ein Umfeld mit offizieller AI-Lab-Partnerschaft und der wohl größten Austausch-Community an AI-Praktikern im deutschsprachigen Raum – über 200 Kolleg:innen in Zertifizierung.

- Strategie statt Experiment: eigenes Vorgehensmodell für agentische Entwicklung, Entwicklungszyklen von 2–4 Tagen statt Wochen-Sprints, riesiges internes Momentum.

- Projekte mit Zugkraft: agentische Modernisierung von Legacy-Landschaften und AI-Integration in Enterprise-Anwendungen – bei Kunden, die es ernst meinen.

- Ein neues Vergütungsmodell statt altem Deckel: knapp sechsstelliges Grundgehalt, Gesamtpaket bis zu 120.000–130.000 € erreichbar – die variable Komponente hängt an deinem eigenen Hebel, nicht an Teamzahlen.

- Hybrides Set-Up mit 3 Tagen Home-Office je Woche, 20 Bürostandorte innerhalb Deutschlands

**Klingt nach dir?** Dann bewirb dich jetzt!

Sobald ich deine Unterlagen geprüft habe, wäre ein kurzer Austausch der nächste Schritt, damit ich dir verrate, um welchen Kunden es geht.

Der weitere Prozess ist kurz, da bei Interesse alle relevanten Infos aus den Pflichtfragen an den Kunden weitergeleitet werden.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
