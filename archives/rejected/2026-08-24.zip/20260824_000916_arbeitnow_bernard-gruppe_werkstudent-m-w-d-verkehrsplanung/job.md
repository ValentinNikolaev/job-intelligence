# Werkstudent (m/w/d) Verkehrsplanung

Posted: 2026-08-23T17:30:10Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Die Veränderung ist konstant, ständig stellen wir uns neuen Herausforderungen. Dafür brauchen wir kluge Köpfe, die mit Engagement dabei sind. Die BERNARD Gruppe ist ein familiengeführtes, fachlich spezialisiertes Unternehmen für Ingenieurdienstleistungen. Mit 700 Mitarbeitern liefert die BERNARD Gruppe in den Geschäftsfeldern Energie, Industrie, Infrastruktur und Mobilität innovative, faire und nachhaltige Lösungen aus einer Hand.

Arbeitsort: **Dresden**

Die BERNARD Gruppe erweitert ihr Team und sucht einen

#### **Werkstudent (m/w/d) Verkehrsplanung**

**Aufgaben**

-

Sie unterstützen unsere Projektteams bei der Gestaltung von nachhaltigen Mobilitätsprojekten

-

Sie gestalten aktiv die Verkehrswende mit

-

Sie unterstützten bei der Erstellung modellbasierter Verkehrskonzepte

-

Sie führen Verkehrsbeobachtungen und Ortsbegehungen selbstständig durch

-

Sie wirken bei der Erstellung von Berichten und Präsentationen mit

**Ihr Profil**

-

Studium im Verkehrsingenieurwesen, Bauingenieurwesen oder vergleichbar

-

Grundkenntnisse GIS, CorelDRAW und VISUM von Vorteil

-

Grundkenntnisse in Richtlinien und Empfehlungen der FGSV von Vorteil

-

Führerschein Klasse B von Vorteil

-

Gute Deutschkenntnisse in Wort und Schrift

-

Gute Kenntnisse in Microsoft Office

**Benefits**

-

Flexible Arbeitszeiten

-

Team- und Firmenevents

-

Weiterbildungsangebote

Wir bieten abwechslungsreiche Projekte in einem international tätigen Unternehmen. Für die Zukunft haben wir uns viel vorgenommen. Werden auch Sie Teil der BERNARD Gruppe. Wir freuen uns auf Sie!

**BERNARD Gruppe** | Recruiting Team | Die Entlohnung richtet sich nach Ihrer Qualifikation und Berufserfahrung.

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
