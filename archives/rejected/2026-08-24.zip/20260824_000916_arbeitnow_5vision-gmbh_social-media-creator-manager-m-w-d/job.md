# Social Media Creator & Manager (m/w/d)

Posted: 2026-08-23T19:30:29Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

5VISION ist eine Medienagentur aus Darmstadt. Wir produzieren tagesaktuelle Nachrichten, Reportagen, Kundenprojekte und Livestreams – von der ersten Idee bis zur Multikamera-Produktion. Unter 5VISION NEWS entstehen jedes Jahr rund 1.000 Produktionen für Sender, Medienhäuser und Presseagenturen. Mit 5VISION MEDIA, 5VISION PRODUCTIONS und 5VISION TECH entwickeln wir außerdem Content, führen Produktionen durch und entwickeln Software für die Medienbranche.

Wir suchen keine Person, die einfach nur Vorlagen befüllt. Wir suchen jemanden, der aus starkem Material starke Social-Media-Inhalte macht: schnell, kreativ, zuverlässig und mit einem echten Gefühl dafür, was auf Instagram, TikTok, YouTube, LinkedIn oder WhatsApp funktioniert.

## Aufgaben

Du unterstützt uns dabei, unsere eigenen Marken und ausgewählte Kundenprojekte auf Social Media sichtbar zu machen – mit Ideen, Struktur und Content, den man nicht einfach wegscrollt.

- Du entwickelst aus vorhandenem Video-, Foto- und Nachrichtenmaterial eigenständige Posts, Reels, Shorts und Story-Formate.

- Du erkennst Themen mit Potenzial und schlägst proaktiv Inhalte, Reihen und aktuelle Formate vor.

- Du planst und veröffentlichst Content für unsere Kanäle – insbesondere rund um 5VISION NEWS.

- Du schreibst Captions, Hooks und Texte, die klar, passend zur Zielgruppe und nicht nach Standard-Marketing klingen.

- Du betreust die Social Media Kanäle von 5VISION NEWS und denkst mit, wie wir Reichweite und Relevanz ausbauen.

- Du wertest die Performance unserer Inhalte aus und leitest daraus konkrete Verbesserungen ab.

- Du beobachtest Trends, neue Plattformfunktionen und vergleichbare Accounts – und filterst, was davon für uns wirklich sinnvoll ist.

- Du koordinierst dich direkt mit dem Leitungsteam – ohne unnötige Schleifen und Prozesse.

## Qualifikation

Das solltest du mitbringen

- Du hast ein gutes Auge für Bildsprache, Timing, Schnitte und Formate, die auf Social Media funktionieren.

- Du kannst Kurzvideos sicher schneiden und weißt, warum die ersten Sekunden über Reichweite entscheiden.

- Du kannst Grafiken, Story-Slides und Thumbnails erstellen - die Software ist dir überlassen.

- Du arbeitest sicher mit der Adobe Creative Suite und Canva

- Du formulierst gute Texte: kurz, klar, korrekt und mit einem Gespür für Tonalität.

- Du arbeitest eigenständig, bringst eigene Ideen ein und hältst Deadlines zuverlässig ein.

- Bereitschaft zum regelmäßigem Austausch in unserem Büro in Darmstadt

- Du brauchst keine perfekte Vita – aber Arbeitsproben, ein Portfolio oder eigene Kanäle, an denen man deinen Stil erkennt.

- Du weißt, dass KI mehr kann, als nur erstaunlich professionelle Stellenanzeigen zu schreiben – und setzt sie sinnvoll ein

## Benefits

Das erwartet dich

- Content mit Substanz statt austauschbarer Produktwerbung: Nachrichten, echte Einsätze, Produktionen, Technik und Projekte mit Relevanz.

- Sehr viel aktuelles Nachrichtenmaterial und ein Umfeld, in dem regelmäßig neue Geschichten entstehen.

- Die Möglichkeit, Formate nicht nur umzusetzen, sondern mitzuentwickeln und sichtbar zu prägen.

- Direkter Austausch mit Menschen, die schnell entscheiden und Content verstehen.

- Flexible Arbeitszeiten und vollständig remote möglich.

- Werkstudent:in, Teilzeit, Minijob oder freie Mitarbeit – wir finden eine Vertragsform, die zu deiner Situation passt.

- Bei Interesse und passender Zusammenarbeit: langfristige Perspektive und mehr Verantwortung.

Interesse?

Schick uns keine Standardbewerbung. Zeig uns lieber, was du kannst: ein Portfolio, Links zu Kanälen, Reels, Designs oder Projekten, auf die du stolz bist – plus ein paar Sätze dazu, warum du zu 5VISION passt.

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
