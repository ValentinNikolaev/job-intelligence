# Marketing All-Rounder:in & Content Creator:in (m/w/d)

Posted: 2026-08-23T17:30:26Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Bei Kireyna brechen wir mit dem Standard. Wir kombinieren High-End-Skincare mit japanisch inspirierter Achtsamkeit und einer künstlerisch-grafischen Ästhetik. Unser Ziel: Hautpflege auf das Wesentliche zu reduzieren und die Haut in Balance zu bringen.

Jetzt, wo wir auf dem Markt sind, möchten wir einen Gang hochschalten und unsere Vermarktung von Grund auf aufbauen. Unser Ziel ist es, Kireyna richtig groß zu machen und unsere erste große Marketing-Welle ins Rollen zu bringen.

Dafür suchen wir eine:n motivierte:n, hands-on Marketing All-Rounder:in, der oder die unsere Vision verinnerlicht, die Ästhetik der Marke atmet und unsere Ideen in hochwirksame Content-Pieces und unvergessliche Community-Erlebnisse verwandelt. Du wirst eng mit uns Gründern zusammenarbeiten: Wir brainstormen auf Augenhöhe, unterstützen uns gegenseitig, und du treibst die Umsetzung mit voller Energie eigenverantwortlich voran.

## Tasks

- **Content & Kanäle:** Du sorgst für verlässlichen, regelmäßigen Output über Instagram, Pinterest und Blog (später TikTok), produzierst selbst oder steuerst Zulieferungen.

- **Creator & Influencer:** Du baust Beziehungen zu Nano- und Mikro-Creatorn im DACH-Raum auf, steuerst Seeding-Programme und begleitest Kooperationen.

- **Events & Pop-ups:** Du unterstützt bei der Planung, dem Aufbau und der Durchführung von Community-Events und Pop-ups, die die Marke erlebbar machen.

- **Kollaboratives Brainstorming:** Du bringst frische Energie, Trends und taktische Vorschläge in unseren Alltag ein.

## Requirements

- **“Doer”-Mentalität:** Du liebst es, anzupacken, Dinge von Anfang an mit aufzubauen und Projekte mit hoher Eigeninitiative umzusetzen.

- **Video-Editing-Skills:** Du hast praktische Erfahrung mit gängigen Videobearbeitungs- und Grafikprogrammen (aktuell nutzen wir CapCut und Affinity) und ein starkes Gespür für modernes Social-Media-Storytelling.

- **Mitdenken & Ehrgeiz: Du bringst eigene Ideen ein und willst mit der Rolle wachsen.**

- **Drive & Commitment:** Ob frisch von der Universität (mit starken Side-Projekten) oder mit 1–2 Jahren Berufserfahrung, bei uns zählt dein Hunger, deine Hingabe und dein Ownership-Mindset.

- **Brand-Intuition:** Ein sicheres Auge für Ästhetik, Tonalität und Details; du verstehst intuitiv, was zum Kireyna-Vibe passt.

- **Sprachkenntnisse:** Fließende Deutsch- und Englischkenntnisse in Wort und Schrift.

## Benefits

- **Direkter Impact:** Du gestaltest die Vermarktung von Tag 1 an aktiv mit.

- **Kreative Freiheit:** Kein Standard-Content, du prägst die visuelle Sprache für eine neue Generation von Skincare.

- **Founder-led:** Enge Zusammenarbeit und Sparring auf Augenhöhe mit uns Gründern.

- **Perks:** Deutschlandticket & Urban Sports Club Mitgliedschaft inklusive.

- **Perspektive:** Diese Rolle wächst mit uns und bietet dir echten Raum für persönliche und berufliche Entwicklung.

Vergiss das klassische Anschreiben! Schicke uns neben deinem Lebenslauf (und optionalem Portfolio/Arbeitsproben) **ein 1-minütiges Video.**

**Zum Video:** Sag uns kurz, wer du bist, warum du für diese Rolle brennst, und nenne uns eine Marke oder einen Creator, den du aktuell feierst, und warum.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
