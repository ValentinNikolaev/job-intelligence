# Head of Engineering (m/f/x) @ E-Mobility Startup

Posted: 2026-08-23T17:09:05Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**About Aampere**

You'll be our first Head of Engineering - the most senior technical hire at Aampere and the person who turns our product vision into a shipped, scalable reality. You report directly to our CPO & Co-Founder, Max: he sets the long-term direction, you own how we get there operationally.

Our team comes from the German startup ecosystem, with experience at Autarc, Greenforce, Cardino, Wemolo, Alasco, Porsche, and Mercedes.

**Your Mission**

**Technical leadership, hands-on:** You're the most experienced engineer in the room. You guide architecture decisions, make the calls on scalability and performance, and aren't afraid to jump into the code yourself when it matters.
**Scale the team, deliberately:** You're inheriting a team of 5 - and we're growing up to ~10 this year. You'll design the structure, hire the right people, and build the processes that let a team double in size without losing speed or quality.
**Delivery you can set your watch to:** You bring structure and ownership to delivery - you're accountable for shipping fast and well. Our team already moves fast; you make sure "fast" doesn't mean "chaotic."
**A magnet for talent:** Some of the best engineers we'll ever hire will join because of you. You know how to sell the mission, the team, and the opportunity - and you back it up once they're here.
**Business-minded engineering:** Aampere buys and resells vehicles, not just runs a marketplace - you weigh technical trade-offs against growth, not just code quality.

**What you bring**

**Senior technical leadership:** Deep backend, architecture, and DevOps expertise - you can take a system to scale, not just talk about it. You've successfully led a tech team of 5+ people before.
**AI-native:** You don't just use AI tools - you're rethinking how software gets built from the ground up, with AI as the default way of working, not an add-on. You expect the same from your team, and you're relentless about pushing the boundary of what AI can do for you.
**Structured execution:** Strong project management instincts - you turn ambiguity into a plan people can deliver on, and you have a track record of hitting or beating it.
**Organizational vision:** You've built and scaled a tech team's structure before, not just managed one.
**Startup/growth-stage experience:** You've shipped products under real resource constraints - small team, tight budget, no safety net - and know how to prioritize ruthlessly.
**Business & product understanding:** You grasp the "why" behind the roadmap, not just the "what" and "how" - and you tie every feature back to business impact: revenue and customer satisfaction.
**Language:** Strong in both German English - you can work with German-speaking partners and dealers as well as our English-speaking team.
**Based in Munich, on-site.**
**Bonus points:** full-stack chops, an ex-founder background, native German, automotive experience, or a past exit.

**How we work**

Three values, not slogans on a wall but how we **work**, **hire**, and **grow** every day:

**Aaudacity.** We are brave enough to take risks, fast enough to not half-ass it.
**Aambition to grow.** We are committed to grow, as individuals and as a company.
**Aampact over Hierarchy.** The best idea wins, no matter who brings it. Titles don't decide arguments here.

**Aampere isn't for you if...**

...you want to work mostly remote. We believe the best ideas happen when people are in the same room. That is why you are in our office at least four days a week.
...you want to join a mature engineering org with established playbooks. We're writing ours right now.
...you need a finished plan before you start. Seed stage means a lot is unclear and changes week to week. You have to be comfortable making decisions in the dark and correcting course as you go.
...you want to stay in your lane. "That is not my job" is not a thing here. You jump in where it matters, even when it sits outside your job description.
...you want a classic 9-to-5. We are building something big, and that does not happen on the side.

**Why Aampere?**

**Founding equity:** You're early. That means VSOP.
**Start-up environment:** Ship features instead of waiting for approvals. We move fast - on purpose.
**Urban Sports Club & job-ticket:** Healthy team, happy team.
**Tech:** Apple or Windows, we provide your laptop. You choose what you work best with.
**Coding Evenings:** Working late? Dinner's on us via Uber Eats.
**Offsite:** So far we've been to Lake Maggiore, the Alps and Tegernsee, what's next?
**Living in the Werksviertel:** Co-living option right next to the office, view of the Ferris wheel included.

**A few words at the end**

Apply now! We look forward to receiving your informal application - we will discuss everything else together.

Regardless of your background, origin or gender identity - what matters to us is who you are as a person. We promote a culture of respect and cooperation in which every voice is heard, personal development is possible and appreciation is paramount.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
