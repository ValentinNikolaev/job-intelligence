# Associate Accounting & Controlling (m/w/d)

Posted: 2026-08-25T23:40:23Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

### Deine Rolle

Die meisten mittelständischen Unternehmen bekommen ihre Zahlen Monate zu spät und in einer Form, mit der sie nichts anfangen können. Nicht weil niemand rechnet, sondern weil das Rechnungswesen als Pflichtübung behandelt wird statt als Grundlage für Entscheidungen.

Vogel ist eine der erfolgreichsten mittelständischen Beratungsgesellschaften in Deutschland — mehrere Tausend mittelständische Unternehmen vertrauen uns ihre Steuer-, kaufmännischen und strategischen Themen an. Für diese Unternehmen übernehmen wir das Rechnungswesen vollständig: von der laufenden Verarbeitung über die handelsrechtliche Bilanzierung bis zu Auswertung, Planung und dem Gespräch, in dem der Unternehmer seine Entscheidungen trifft. Du arbeitest von Anfang an auf dieser ganzen Strecke, nicht nur an einem Abschnitt davon.

Du hast dein Studium abgeschlossen oder stehst kurz davor — Betriebswirtschaft, Wirtschaftswissenschaften oder ein vergleichbares Fach, idealerweise mit Schwerpunkt Rechnungswesen, Controlling oder Prüfungswesen. Du willst Unternehmen aus ihren Zahlen verstehen und früh selbst mit den Menschen sprechen, die diese Zahlen produzieren — statt in einer Konzern-Berichtslinie zuzuarbeiten, in der du das Unternehmen nie zu Gesicht bekommst. Bei Vogel findest du beides: Strukturen, die tragen — etablierte Mandanten, lange Erfahrung, starke Wachstumsbasis — und gleichzeitig ein Setup, das jeden Tag nach vorne geht.

Du übernimmst ab Tag eins eigene Mandate: Du klärst, was nicht zusammenpasst, baust die Abschlüsse und bereitest die Analysen auf, über die wir mit dem Unternehmer sprechen. Du arbeitest in der Linie eines erfahrenen Kollegen, der dich fachlich anleitet. Vogel unterstützt dich beim nächsten Qualifikationsschritt — finanziell und zeitlich. Der Weg führt über die fachliche Verantwortung für eigene Mandate in die Führung eines eigenen Teams.

### Deine Verantwortung

Laufendes Rechnungswesen mit hohem Automatisierungsgrad

-

Verantworte das laufende Rechnungswesen deiner Mandate — die Verarbeitung läuft weitgehend automatisiert, deine Arbeit fängt dort an, wo das System an seine Grenze kommt.

-

Geh den Auffälligkeiten nach, die aus dem Zeitverlauf und dem Vergleich mit anderen Mandaten hervortreten — mit dem Blick auf die Ursache im Unternehmen, nicht auf die passende Buchung.

-

Verantworte den Monatsabschluss deiner Mandate und die Umsatzsteuer-Voranmeldung, und erkenne die Fälle, die eine steuerliche Rückfrage brauchen, bevor sie zum Problem werden.

Abschluss, Analyse und Forecast

-

Wirke am handelsrechtlichen Jahresabschluss mit — Abgrenzungen, Rückstellungen, Bestandsveränderungen — und übernimm ihn schrittweise in eigene Verantwortung.

-

Bereite die BWA-Besprechung mit dem Unternehmer vor: Analyse, Kennzahlen, die Punkte, die zur Sprache kommen müssen. Dein Maßstab: Er kann danach eine Entscheidung treffen, nicht nur eine Zahl wiederholen.

-

Entwickle Forecasts, Kosten- und Leistungsrechnung sowie Liquiditätsbetrachtungen für deine Mandate — dort, wo die Zahlen anfangen, unternehmerische Fragen zu beantworten.

Werkzeuge und Automatisierung

-

Arbeite in einer modernen Umgebung: digitale Belegflüsse, automatisierte Verarbeitung, KI-gestützte Plausibilisierung. Wir sind bewusst über DATEV-plus-Excel hinaus.

-

Nutz KI selbstverständlich für Recherche, Analyse, Drafting und die Prüfung von Auffälligkeiten.

-

Bring eigene Ideen ein, wie die Arbeit an deinen Mandaten schneller und besser wird — und setz sie mit um. Wie weit die Automatisierung geht, ist bei uns keine ausgemachte Sache.

### Deine Perspektiven

**Was du nach 6 Monaten geliefert hast:**

-

Du verantwortest das laufende Rechnungswesen mehrerer Mandate und klärst Auffälligkeiten selbstständig mit dem Unternehmen.

-

Du hast die ersten Monatsabschlüsse in deiner Verantwortung abgeschlossen, mit Review durch einen erfahrenen Kollegen.

-

Du hast erste BWA-Besprechungen begleitet — Vorbereitung, eigene Wortmeldungen, Nachbereitung.

**Was du nach 12 Monaten geliefert hast:**

-

Du verantwortest die Monatsabschlüsse mehrerer Mandate eigenständig — selbstständige Vorbereitung, fachliche Erstprüfung, Eskalation nur bei Sonderthemen.

-

Du bereitest die BWA-Besprechung selbst vor und trägst Teile davon beim Unternehmer selbst vor.

-

Du hast am handelsrechtlichen Jahresabschluss mehrerer Mandate mitgewirkt und deinen nächsten Qualifikationsschritt konkret gestartet.

**Was du nach 24 Monaten geliefert hast:**

-

Du trägst einen Teilmandantenstamm eigenständig und baust den handelsrechtlichen Abschluss unter Review.

-

Du hast für mehrere Mandate einen Forecast oder eine Deckungsbeitragsrechnung aufgebaut, die laufend genutzt wird.

-

Du führst die BWA-Besprechung bei deinen Mandaten selbst.

**Wohin sich die Stelle entwickelt:**

Der nächste Schritt führt in die Manager-Stufe in Accounting & Controlling — mit Entwicklungspfad in beide Richtungen, fachliche Expertenlaufbahn oder Führungslaufbahn. Der Weg dorthin entsteht am Beitrag, nicht am Berufsjahr; einen Automatismus „mehr Erfahrung gleich höhere Stufe" kennen wir nicht.

### Das bringst du mit

Erfahrung & Track Record

-

Abgeschlossenes oder kurz vor dem Abschluss stehendes Studium in Betriebswirtschaft, Wirtschaftswissenschaften oder einem vergleichbaren Fach — idealerweise mit Schwerpunkt Rechnungswesen, Controlling oder Prüfungswesen.

-

Erste Praxis in Steuerberatung, Wirtschaftsprüfung oder im Rechnungswesen eines Unternehmens — duales Studium, Praktika oder eine Werkstudententätigkeit. Wenn du schon einmal einen Abschluss von innen gesehen hast, umso besser.

-

Du hast an einer Stelle schon einmal selbst nachgehakt, weil eine Zahl nicht plausibel war — und die Antwort im Unternehmen gesucht, nicht im Buchungssatz.

-

Profile, die nicht in das obige Raster passen, aber substanziellen Zugang zu Unternehmenszahlen mitbringen, sind ausdrücklich eingeladen — wir bewerten am Beitrag, nicht am Etikett. Konkret: Steuerfachangestellte mit nachgeholtem Studium; Berufseinsteiger, die im Familienbetrieb die kaufmännische Steuerung gemacht haben; Absolventen mit eigener Gründungs- oder Werkstudentenerfahrung, in der sie selbst Liquidität geplant haben. Die ausgewiesene Spanne ist kein Verhandlungsspielraum, sondern eine Profil-Skala. Das untere Ende steht für den Einstieg direkt nach dem Studium. Wer das laufende Rechnungswesen und den Monatsabschluss schon selbständig trägt, startet im oberen Drittel. Die oben ausgewiesene Range gilt für das Primärprofil. Wer einen anderen Hintergrund mitbringt, startet zu einem anderen Marktpreis und konvergiert nach zwölf Monaten bewährter Leistung auf das Rollen-Niveau — die Logik dahinter steht in unseren [Vergütungsgrundsätzen](https://www.vogel-beratung.com/culture/verg%C3%BCtungsgrunds%C3%A4tze).

Skills & Arbeitsweise

-

Du arbeitest analytisch und strukturiert — du zerlegst eine Aufgabe in Teilschritte, bevor du loslegst, und lieferst nachvollziehbar aufgebaute Ergebnisse.

-

Du kommunizierst klar und verbindlich — schriftlich wie im ersten Gespräch mit einem Unternehmer. Du hast keine Scheu vor Themen, die du noch nicht voll beherrschst.

-

Du arbeitest mit KI als selbstverständlichem Werkzeug — Recherche, Analyse, Drafting, Plausibilisierung. Repetitive Auswertungen sind dir ein Reiz zur Automatisierung, kein Schicksal.

Mindset & Persönlichkeit

-

Du willst verstehen, wie ein Unternehmen funktioniert — die Zahlen sind für dich der Zugang, nicht das Ziel.

-

Du bringst die Demut mit, von Praktikern zu lernen. Der Unternehmer mit dreißig Jahren am Markt und die Kollegin mit langjähriger Mandatskenntnis wissen Dinge über das Geschäft, die in keinem Modell stehen.

-

Du hast den Anspruch, in allem, was du ablieferst, den höchsten Standard zu setzen — nicht weil jemand es kontrolliert, sondern weil Mittelmaß dich persönlich stört.

-

Du bist bereit, dich auf eigenständige Arbeit am Mandat einzulassen und jeden Tag zu lernen. Wer ausschließlich nach 9-to-5 sucht, sucht woanders.

### Was du bei uns nicht finden wirst

-

**Kein Belegerfassungs-Job.** Die Erfassung läuft weitgehend maschinell. Deine Arbeit fängt dort an, wo das Ergebnis beurteilt werden muss — und geht bis ins Gespräch mit dem Unternehmer.

-

**Kein Controlling im Konzern-Maschinenraum.** Du produzierst keine Reports für ein Management, das du nie triffst. Du sitzt mit dem Unternehmer am Tisch.

-

**Kein steuerlicher Karrierepfad.** Diese Rolle ist wirtschaftlich und bilanziell. Wer das Steuerberater-Examen und die steuerliche Gestaltung sucht, findet das bei uns in der Tax-Linie — mit eigener Ausschreibung.

-

**Kein fertig durchgeplanter Schreibtisch.** Wie weit die Automatisierung geht und wie die Auswertungen aussehen, ist bei uns nicht in Stein gemeißelt — du entwickelst mit, statt eine fertige Maschine zu bedienen.

-

**Kein Konzern-Korsett, in dem du auf Beförderungen wartest.** Wachstum entsteht hier am Beitrag, nicht am Berufsjahr.

# FAQ

### 1. Was ist Vogel — und wo arbeitet ihr?

Vogel ist eine der führenden Mittelstandsberatungen Deutschlands — Familienunternehmen seit 1959, aus Aalen — und baut daraus die führende Beratungsplattform für den Mittelstand. Wir wachsen an mehreren Standorten: in Aalen/Ostwürttemberg als gewachsenem Stammsitz und in München als neuem Hub. An beiden suchen wir quer durch die Funktionen — von Steuerberatung über Beratung bis zu den strategischen Teams, die die Plattform bauen.

### 2. Wie sind die Gehaltsbänder zu verstehen?

Bewusst breit — und an jeder Stelle ausgewiesen. Wir differenzieren nach Track Record und Marktwert, nicht nach Abschluss: knappe, stark gefragte Profile am oberen Ende, weniger knappe am unteren. Wir kalibrieren ausschließlich am Markt — zwei Menschen mit ähnlicher Erfahrung können bei uns unterschiedlich verdienen.

### 3. Wie viel — und wie — wird bei Vogel gearbeitet?

Gemessen wird an dem, was du bewegst, nicht an Stunden. Ehrlich ist aber auch: Wer 9-to-5 sucht, ist bei uns nicht die erste Adresse. Wir suchen Menschen, die aus eigenem Antrieb intensiv arbeiten, weil die Aufgaben es wert sind. Wie du deine Zeit verteilst, ist weitgehend deine Sache. Was wir teilen: Wir arbeiten präsent zusammen — Kultur, Sparring und die besten Ideen entstehen in der täglichen Nähe. Wir sind keine Remote-Company und haben keine großen Home-Office-Policies; einzelne Remote-Tage sind kein Problem.

### 4. Wie läuft die Bewerbung?

Schlank, schnell, transparent — und nach Profil gestaffelt. Für Einstiegsrollen (Praktikum, Werkstudium, Berufseinstieg) genügen in der Regel zwei Gespräche und eine kurze Arbeitsprobe; erfahrene Rollen laufen etwas ausführlicher. Bei ausgewählten Senior-Rollen prüfen wir, künftig einen gemeinsamen Arbeitstag einzubauen, damit beide Seiten sich besser kennenlernen. Immer gilt: getaktete Termine, zügige Entscheidung, substanzielles Feedback — unabhängig vom Ausgang.

### 5. Wie funktioniert die variable Vergütung?

Quartalsweise an Leistung gekoppelt, qualitativ bewertet. Die Skala steigt mit dem Level: bis 20 % Associate, 27,5 % Manager, 35 % Senior Manager, 42,5 % Director, 50 % VP. Erwartungswert bei guter Leistung — du erfüllst die Anforderungen, setzt eigene Akzente, bestehst den Keeper Test — liegt bei rund 50 % des Maximums; der Maximalbonus ist nicht der Normalfall. Im Fokus steht eine ganzheitliche Beurteilung durch deine Führungskraft: Ownership, Qualität, Lernkurve, Zusammenarbeit, Impact.

### 6. Wie entwickle ich mich — welche Karrierewege gibt es?

Zwei aktive Wege: Mastery (fachliche Tiefe, Expertenlaufbahn) und Pioneer (Führung, Management). Die Richtung wählst du nach dem Onboarding, meist in Jahr 1–3. Berufseinstieg ist kein Sonderweg, sondern der frühe Teil derselben Strecke — vom Werkstudenten oder Praktikanten zum Associate, für die Besten ohne erneutes Bewerbungsverfahren.

### 7. Team, Kultur, Urlaub?

Ein gemeinsames Mittagessen ist ein offenes tägliches Angebot — keine Pflicht; wer mag, kommt dazu, essen kann jeder jederzeit. Dazu Abendessen, Social Events und Offsites in regelmäßigem Rhythmus — nicht als Pflichtprogramm, sondern weil ein gutes Team auch abseits der Arbeit Zeit teilt. Benefits: durchdacht und substanziell, nicht symbolisch. Urlaub: 28 Tage.

### 8. Ich kenne jemanden — gibt es einen Empfehlungsbonus?

Ja — 2.500 EUR für jede erfolgreich besetzte Stelle (keine Praktika). Kurzer Kontext reicht: an wen du denkst, für welche Rolle, warum. Muss nicht perfekt sitzen, aber substanziell sein.

Compensation: €61.2K – €79.2K • Fix: €51k – €66k · Bonus: €10,2k – €13,2k · EV: €58,14k – €75,24k

- • OTE €61.2K – €79.2K • Fix: €51k – €66k · Bonus: €10,2k – €13,2k · EV: €58,14k – €75,24k

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
