# Director Tax (m/w/d)

Posted: 2026-08-25T23:40:22Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

## Deine Rolle

Vogel baut die führende Beratungsplattform für den deutschen Mittelstand auf — und Steuerberatung ist ihr Kern, kein Geschäftsfeld unter vielen. Mehrere Tausend Mandanten vertrauen uns heute; die Plattform wächst organisch und durch Konsolidierung. Director Tax heißt: Du trägst einen ganzen Praxis-Bereich der Steuerberatung — Strategie, Output, Aufbau und Wachstum in vollem Umfang.

Du bist Steuerberater mit Führungserfahrung auf Bereichs-Ebene. Du hast eine Sub-Organisation, mehrere Teams oder einen Standort geleitet — und ihn nicht nur verwaltet, sondern wachsen lassen. Du kennst die Mechanik eines Tax-Geschäfts von der Mandatsführung über die Leverage-Struktur bis zum Beitrag zum Ergebnis. Du wechselst, weil du einen Praxis-Bereich als Unternehmer im Unternehmen bauen willst — mit der Linie, dem Mandat und der Verantwortung, die das verlangt.

Du verantwortest das Wachstum deines Bereichs in vollem Umfang: die Strategie, den Output über mehrere Sub-Teams, den Aufbau der Linie und den Beitrag zum Geschäftsergebnis. Du bist Eskalations-Endpunkt für deinen Bereich; an die Geschäftsführung eskalierst du nur, was firmenstrategische Bedeutung hat. Du entwickelst die Bereichsstrategie eigenständig und bringst deine Themen in die Unternehmensstrategie ein.

## Deine Verantwortung

### Bereich & Wachstum

-

Verantworte einen eigenständigen Praxis-Bereich oder Standort in der steuerlichen Mittelstandsberatung in vollem Umfang — Strategie, Output, Aufbau — und seinen Beitrag zum Geschäftsergebnis.

-

Entwickle die Bereichsstrategie eigenständig und bring deine Themen in die Unternehmensstrategie ein; du bist Mit-Setzer, nicht Umsetzer.

-

Treib das Wachstum deines Teams über eigene Akquise, Cross-Sell über alle Vogel-Bereiche und — wo relevant — die Integration zugekaufter Mandatsstämme aus der Buy-&-Build-Pipeline.

### Führung der Linie

-

Führe eine eigene Führungslinie über mehrere kleinere Sub-Teams — drei bis fünf Direct Reports auf Bereichs-Niveau, mit tiefer indirekter Verantwortung über die darunterliegenden Portfolios.

-

Trag die volle Personalverantwortung deines Bereichs — Hiring auf Bereichs-Ebene im mehrstufigen Vogel-Prozess, Entwicklung deiner Senior Manager, Performance und Trennung.

-

Setz die fachlichen Standards und die Methodik deines Bereichs — du bist Methoden-Autorität, bleibst aber operativ kompetent.

### Mandanten & Markt

-

Bleib persönlicher Ansprechpartner für die strategisch wichtigsten Mandanten und Inhaber deines Mandantenportfolios.

-

Repräsentiere Vogel Tax nach außen — Netzwerke, Branchenöffentlichkeit, Verbände — und bau die Reputation des Bereichs auf.

-

Setze die Linie für unsere strategische Positionierung, indem du immer wieder Business-Development-Impulse setzt.

## Deine Perspektiven

**Was du nach 6 Monaten geliefert hast:**

-

Du trägst deinen Praxis-Bereich eigenständig; die Linie läuft über dich, ohne dass die Geschäftsführung in den Standardbetrieb eingreift.

-

Du hast deine Senior Manager übernommen, die Führungslinie verstanden und die ersten Steuerungs-Entscheidungen getroffen.

-

Du hast eine eigene Wachstums- und Strategie-Linie für deinen Bereich vorgelegt.

**Was du nach 12 Monaten geliefert hast:**

-

Dein Bereich wächst messbar — über Akquise, Cross-Sell und, wo relevant, integrierte Mandatsstämme.

-

Du hast deine Führungslinie weiterentwickelt und auf Bereichs-Ebene eingestellt.

-

Deine Bereichsstrategie ist in der Unternehmensstrategie sichtbar verankert.

**Was du nach 24 Monaten geliefert hast:**

-

Dein Bereich trägt einen erkennbaren, eigenständigen Beitrag zum Geschäftsergebnis der Gruppe.

-

Du hast die fachlichen Standards deines Bereichs gesetzt und nach außen Reputation aufgebaut.

-

Du bist als Bereichs-Owner etabliert und auf dem Principal-/VP-Pfad entlang unseres Career Frameworks.

**Wohin sich die Stelle entwickelt:**

Über die Director-Stufe öffnet sich der Principal-/VP-Pfad — die unternehmerische Owner-Verantwortung für eine ganze strategische Säule mit Mitverantwortung für die Unternehmensstrategie. Director Tax ist eine Rolle mit echtem Bereichs-Eigentum: Über die Cash-Vergütung hinaus ist vorgesehen, dass du unternehmerisch am Mehrwert partizipierst, den du mit deinem Bereich schaffst.

## Das bringst du mit

### Erfahrung & Track Record

-

Du hast das Steuerberater-Examen bestanden und danach auf geführt — eine Sub-Organisation, mehrere Teams oder einen Standort.

-

Du hast einen Bereich nicht nur geführt, sondern wachsen lassen — mit nachweisbarem Beitrag zu Output und Ergebnis.

-

Du hast Führungskräfte geführt, fachliche Standards gesetzt und Personalverantwortung in der Tiefe getragen.

-

Profile, die nicht in dieses Raster passen, aber die Substanz mitbringen, sind ausdrücklich eingeladen — wir bewerten am Beitrag, nicht am Etikett. Konkret: Big4-Director oder Partner-Anwärter mit Mittelstands-Wellenlänge; Kanzlei-Führungskraft am Sprung zur eigenen Bereichs-Owner-Rolle. Die ausgewiesene Range kalibriert auf das Primärprofil — die Logik dahinter steht in unseren [Vergütungsgrundsätzen](https://www.vogel-beratung.com/culture/verg%C3%BCtungsgrunds%C3%A4tze).

### Skills & Arbeitsweise

-

Du beherrschst die Mechanik eines Tax-Geschäfts — Mandatsführung, Leverage, Qualität und Ergebnis — und steuerst sie über mehrere Teams hinweg.

-

Du denkst strategisch und führst zugleich operativ kompetent; du verlierst die Mandatsrealität nicht aus dem Blick.

-

Du arbeitest mit AI als selbstverständlichem Hebel und treibst die Automatisierung deines Bereichs, statt sie abzuwarten.

### Mindset & Persönlichkeit

-

Du denkst und handelst wie ein Unternehmer im Unternehmen — der Bereich ist dein Bereich, sein Wachstum deine Verantwortung.

-

Du begegnest mittelständischen Inhabern mit echtem Respekt und auf Augenhöhe.

-

Du hast den Anspruch, in allem, was du und deine Linie abliefern, den höchsten Standard zu setzen — nicht weil jemand es kontrolliert, sondern weil Mittelmaß dich persönlich stört.

-

Vogel ist hierarchisch in der Entscheidung, flach in der Kommunikation, autonom in der Ausführung. Leistung wird gefeiert, nicht versteckt.

## Was du bei uns nicht finden wirst

-

**Keine Partnergesellschaft mit konkurrierenden Eigeninteressen.** Wir sind ein Unternehmen mit One-Firm-Logik — eine Marke, eine Kultur, eine Hiring-Bar. Kein Management-by-Committee.

-

**Kein repräsentativer Titel ohne echte Owner-Verantwortung.** Du trägst Strategie, Output und Ergebnis deines Bereichs — nicht ein Schild an der Tür.

-

**Kein Führen aus der Distanz.** Du bleibst nah an den wichtigsten Mandaten und an deiner Linie; reine Steuerung von oben gibt es bei uns nicht.

-

**Kein Erbhof-Modell.** Dein Auftrag ist Wachstum, nicht Verwaltung des Bestands.

# FAQ

### 1. Was ist Vogel — und wo arbeitet ihr?

Vogel ist eine der führenden Mittelstandsberatungen Deutschlands — Familienunternehmen seit 1959, aus Aalen — und baut daraus die führende Beratungsplattform für den Mittelstand. Wir wachsen an mehreren Standorten: in Aalen/Ostwürttemberg als gewachsenem Stammsitz und in München als neuem Hub. An beiden suchen wir quer durch die Funktionen — von Steuerberatung über Beratung bis zu den strategischen Teams, die die Plattform bauen.

### 2. Wie sind die Gehaltsbänder zu verstehen?

Bewusst breit — und an jeder Stelle ausgewiesen. Wir differenzieren nach Track Record und Marktwert, nicht nach Abschluss: knappe, stark gefragte Profile am oberen Ende, weniger knappe am unteren. Wir kalibrieren ausschließlich am Markt — zwei Menschen mit ähnlicher Erfahrung können bei uns unterschiedlich verdienen.

### 3. Wie viel — und wie — wird bei Vogel gearbeitet?

Gemessen wird an dem, was du bewegst, nicht an Stunden. Ehrlich ist aber auch: Wer 9-to-5 sucht, ist bei uns nicht die erste Adresse. Wir suchen Menschen, die aus eigenem Antrieb intensiv arbeiten, weil die Aufgaben es wert sind. Wie du deine Zeit verteilst, ist weitgehend deine Sache. Was wir teilen: Wir arbeiten präsent zusammen — Kultur, Sparring und die besten Ideen entstehen in der täglichen Nähe. Wir sind keine Remote-Company und haben keine großen Home-Office-Policies; einzelne Remote-Tage sind kein Problem.

### 4. Wie läuft die Bewerbung?

Schlank, schnell, transparent — und nach Profil gestaffelt. Für Einstiegsrollen (Praktikum, Werkstudium, Berufseinstieg) genügen in der Regel zwei Gespräche und eine kurze Arbeitsprobe; erfahrene Rollen laufen etwas ausführlicher. Bei ausgewählten Senior-Rollen prüfen wir, künftig einen gemeinsamen Arbeitstag einzubauen, damit beide Seiten sich besser kennenlernen. Immer gilt: getaktete Termine, zügige Entscheidung, substanzielles Feedback — unabhängig vom Ausgang.

### 5. Wie funktioniert die variable Vergütung?

Quartalsweise an Leistung gekoppelt, qualitativ bewertet. Die Skala steigt mit dem Level: bis 20 % Associate, 27,5 % Manager, 35 % Senior Manager, 42,5 % Director, 50 % VP. Erwartungswert bei guter Leistung — du erfüllst die Anforderungen, setzt eigene Akzente, bestehst den Keeper Test — liegt bei rund 50 % des Maximums; der Maximalbonus ist nicht der Normalfall. Im Fokus steht eine ganzheitliche Beurteilung durch deine Führungskraft: Ownership, Qualität, Lernkurve, Zusammenarbeit, Impact.

### 6. Wie entwickle ich mich — welche Karrierewege gibt es?

Zwei aktive Wege: Mastery (fachliche Tiefe, Expertenlaufbahn) und Pioneer (Führung, Management). Die Richtung wählst du nach dem Onboarding, meist in Jahr 1–3. Berufseinstieg ist kein Sonderweg, sondern der frühe Teil derselben Strecke — vom Werkstudenten oder Praktikanten zum Associate, für die Besten ohne erneutes Bewerbungsverfahren.

### 7. Team, Kultur, Urlaub?

Ein gemeinsames Mittagessen ist ein offenes tägliches Angebot — keine Pflicht; wer mag, kommt dazu, essen kann jeder jederzeit. Dazu Abendessen, Social Events und Offsites in regelmäßigem Rhythmus — nicht als Pflichtprogramm, sondern weil ein gutes Team auch abseits der Arbeit Zeit teilt. Benefits: durchdacht und substanziell, nicht symbolisch. Urlaub: 28 Tage.

### 8. Ich kenne jemanden — gibt es einen Empfehlungsbonus?

Ja — 2.500 EUR für jede erfolgreich besetzte Stelle (keine Praktika). Kurzer Kontext reicht: an wen du denkst, für welche Rolle, warum. Muss nicht perfekt sitzen, aber substanziell sein.

Compensation: €256.5K – €342K • Fix: €180k – €240k · Bonus: €76,5k – €102k · EV: €221,4k – €295,2k

- • OTE €256.5K – €342K • Fix: €180k – €240k · Bonus: €76,5k – €102k · EV: €221,4k – €295,2k

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
