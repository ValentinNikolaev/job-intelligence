# Founders Associate (AI x Greentech) (m/f/d)

Posted: 2026-08-25T23:40:37Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**Are you excited to work directly with founders, drive high-impact projects, and shape a company from the inside?**

If you thrive at the intersection of strategy and hands-on execution, love bringing structure to ambiguity, and want a front-row seat to building a company – then join us and make an impact. We want YOU!

***Please note that for this role, C2 English proficiency is required. This is a full-time, on-site position based in Berlin.***

**What You’ll Do**

-

**Collaborate directly with the co-founders** and leadership team on the execution and development of the company strategy.

-

**Initiate and own strategic and operational projects** from 0 to 1 - taking full responsibility and driving them forward proactively.

-

**Work closely with Product, Sales, Finance, Operations, and Venture Development** to move priority topics forward.

-

**Roll up your sleeves** and work directly on the topics that matter most.

**What Makes You a Great Fit**

-

Experience in a startup environment.

-

Studying at a top university with strong entrepreneurial focus.

-

Strategic thinker with a **hands-on** mentality.

-

Ambitious and ready to go the extra mile when needed.

-

Structured, proactive, and comfortable in fast-paced environments.

-

Curiosity about how tech, operations, and business strategy come together in high-growth companies.

-

Eager to invest time beyond standard hours.

-

C2 in English is obligatory

-

Fluent in German or Italian is a plus.

**Why Join Us?**

-

Be part of one of the fastest growing VC-backed startup in Germany with 3000+ satisfied B2B customers.

-

A vibrant, collaborative office culture where great ideas happen face-to-face - we're a full in-person team (5 days/week) in a beautiful Augsburg or Berlin office.

-

Enjoy opportunities for personal and professional growth.

-

Embrace the freedom to innovate and make quick changes in a dynamic team.

-

Perks include gym membership, coffee, regular team events, MacBook and more.

-

Receive competitive pay.

Even if you don’t meet every requirement, we encourage you to apply! Imposter syndrome shouldn't hold you back - we value talent and passion above all.

**About Reonic**

At Reonic, we’re on a mission to simplify renewable technology with our AI operating system for renewable installers. Backed by top-tier investors and trusted by 3000+ business customers, we’re growing fast - and we need YOU to help us growth.

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
