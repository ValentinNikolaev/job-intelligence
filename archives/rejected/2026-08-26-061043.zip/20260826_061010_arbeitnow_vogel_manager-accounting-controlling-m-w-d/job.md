# Manager Accounting & Controlling (m/w/d)

Posted: 2026-08-25T23:40:23Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

### Deine Rolle

In den meisten mittelständischen Unternehmen erklärt niemand die Zahlen. Sie werden erstellt, verschickt und abgelegt — und der Inhaber entscheidet weiter aus dem Bauch, weil ihm niemand übersetzt, was in seinem eigenen Rechnungswesen steht.

Vogel ist eine der erfolgreichsten mittelständischen Beratungsgesellschaften in Deutschland — mehrere Tausend mittelständische Unternehmen vertrauen uns ihre Steuer-, kaufmännischen und strategischen Themen an. Für diese Unternehmen übernehmen wir das Rechnungswesen vollständig: laufende Verarbeitung mit hohem Automatisierungsgrad, handelsrechtliche Bilanzierung und darauf aufbauend Auswertung, Planung und Controlling. Du führst deinen Mandantenkreis über diese ganze Strecke — und gibst das Gespräch darüber nicht ab.

Du trägst seit einigen Jahren die Verantwortung für Abschlüsse mittelständischer Mandate — in einer Steuerberatungs- oder Prüfungsgesellschaft oder im Rechnungswesen eines Unternehmens. Du kennst die Situation: Der Abschluss ist fertig, sauber und pünktlich — und das Gespräch darüber führt jemand anders, oder es findet gar nicht statt. Bei Vogel findest du das Gegenteil: Strukturen, die tragen — etablierte Mandanten, lange Erfahrung, starke Wachstumsbasis — und gleichzeitig ein Setup, das jeden Tag nach vorne geht. Kein Konzern-Korsett, kein Erbhof ohne Wachstumsanspruch.

Du übernimmst ab Tag eins einen bestehenden Mandantenkreis und führst ab Tag eins drei bis vier Associates fachlich an. Du berichtest an den Senior Manager Accounting & Controlling, der den Standard der Linie verantwortet. Die natürliche Entwicklung führt nach 24 bis 36 Monaten in eine Senior-Manager-Rolle mit eigenständig entwickeltem Mandatsportfolio.

### Deine Verantwortung

Mandantenkreis und Abschluss

-

Übernimm einen bestehenden Mandantenkreis und führe ihn eigenverantwortlich — laufendes Rechnungswesen, Monats- und Jahresabschlüsse, Ansprechpartner für Inhaber und Geschäftsführer.

-

Verantworte den handelsrechtlichen Abschluss deiner Mandate als eigenständiges Ergebnis für den Unternehmer. Du bereitest den handelsrechtlichen Teil vor, unsere Steuerberatung verantwortet den steuerlichen Teil und die Deklaration.

-

Treib den Automatisierungsgrad deiner Mandate weiter, statt Handarbeit zu verwalten. Dein Maßstab ist nicht, dass die Zahlen am Ende stimmen, sondern wie wenig manueller Aufwand dafür nötig war.

Steuerung und Beratung des Unternehmers

-

Führe das BWA- oder Quartalsgespräch bei deinen Mandaten selbst und übersetze die Zahlen in eine Handlungslinie. Dein Maßstab: Er kann danach eine Entscheidung treffen, nicht nur eine Zahl wiederholen.

-

Bau Planung und Steuerung auf dem laufenden Rechnungswesen auf — Forecast, Liquiditätsplanung, Kosten- und Leistungsrechnung, Deckungsbeitrag — und mach daraus Leistungen, die wiederkehrend tragen statt bei jedem Mandat neu erfunden zu werden.

-

Erkenne die Anlässe, bei denen ein anderer Bereich gebraucht wird — steuerliche Gestaltung, Finanzierung, Nachfolge, Bewertung — und führ sie aktiv zusammen, statt zu warten, bis der Mandant fragt.

Team-Führung

-

Führe deine drei bis vier Associates fachlich an — Review ihrer Arbeit, Mentoring, Eskalations-Entscheidungen, Performance-Gespräche in Abstimmung mit dem Senior Manager.

-

Bring die Associates dahin, dass sie das Mandantengespräch selbst führen können — nicht nur die Zahlen liefern.

-

Wirk aktiv im Hiring auf Associate-Stufe mit und setz den Ton im Team: hierarchisch in der Entscheidung, flach in der Kommunikation, autonom in der Ausführung. Leistung wird bei uns gefeiert, nicht versteckt — wer gut ist, findet hier den Raum dafür, ohne politische Tarnung und ohne Konsens-Theater.

### Deine Perspektiven

**Was du nach 6 Monaten geliefert hast:**

-

Du betreust den übergebenen Mandantenkreis in voller Eigenverantwortung, inklusive der Jahresabschlüsse.

-

Du hast die ersten zehn BWA- oder Steuerungsgespräche ohne Senior-Begleitung geführt.

-

Du kennst deine Associates persönlich und hast die ersten Performance-Gespräche selbst geführt.

**Was du nach 12 Monaten geliefert hast:**

-

Du hast mindestens zehn deiner Mandate im laufenden Rechnungswesen messbar effizienter gemacht.

-

Du hast bei mindestens fünf Mandaten eine Steuerungsleistung über die Finanzbuchführung hinaus etabliert — Forecast, Deckungsbeitrag oder Liquiditätsplanung, die der Unternehmer laufend nutzt.

-

Du hast mindestens drei Anlässe in andere Bereiche überführt — steuerliche Gestaltung, Finanzierung, Nachfolge oder Bewertung.

**Was du nach 24 Monaten geliefert hast:**

-

Du hast deinen Mandantenkreis eigenständig entwickelt und um eigene Akquise oder Cross-Sell erweitert.

-

Du hast eine erkennbare eigene Vertiefung aufgebaut — eine Branche, eine Planungsmethodik, ein Automatisierungsthema.

-

Du bist Eskalations-Endpunkt deiner Linie bei Standardfällen und Kandidat für die Senior-Manager-Stufe.

**Wohin sich die Stelle entwickelt:**

Der nächste Schritt ist Senior Manager Accounting & Controlling (Management-Karriere) — das setzt allerdings ein eigenständig entwickeltes Mandatsportfolio voraus, nicht nur zusätzliche Berufsjahre. Wir kennen keinen Automatismus „mehr Erfahrung gleich höhere Stufe". Über die Senior-Manager-Stufe öffnet sich der Director-Pfad entlang unseres Karriere-Frameworks.

### Das bringst du mit

Erfahrung & Track Record

-

Du hast mehrere Jahre Abschlüsse mittelständischer Kapital- und Personengesellschaften erstellt und verantwortet — in einer Steuerberatungs- oder Prüfungsgesellschaft oder im Rechnungswesen eines Unternehmens.

-

Du warst dabei nicht nur im Zahlenwerk, sondern hast Ergebnisse auch selbst beim Mandanten oder bei der Geschäftsführung vertreten.

-

Ein Berufsexamen ist ausdrücklich keine Voraussetzung — diese Rolle ist bilanziell und wirtschaftlich, nicht steuerlich. Wenn du das Wirtschaftsprüfer-Examen anstrebst, unterstützen wir dich dabei.

-

Profile, die nicht in das obige Raster passen, aber eigene Abschlussverantwortung mit Beratungsanteil mitbringen, sind ausdrücklich eingeladen — wir bewerten am Beitrag, nicht am Etikett. Konkret: Bilanzbuchhalter mit mehrjähriger eigener Abschlussverantwortung, der das Mandantengespräch schon führt; Controller aus dem gehobenen Mittelstand mit belastbarer Bilanzierungspraxis; Steuerberater, dessen Arbeit faktisch überwiegend Rechnungswesen ist. Die ausgewiesene Spanne ist kein Verhandlungsspielraum, sondern eine Profil-Skala. Das untere Ende steht für den Wechsel in die erste Rolle mit eigenem Mandantenkreis und Führungsverantwortung. Wer heute schon einen vergleichbaren Mandantenkreis vollständig trägt und ein Team fachlich führt, startet im oberen Drittel. Die oben ausgewiesene Range gilt für das Primärprofil. Wer einen anderen Hintergrund mitbringt, startet zu einem anderen Marktpreis und konvergiert nach zwölf Monaten bewährter Leistung auf das Rollen-Niveau — die Logik dahinter steht in unseren [Vergütungsgrundsätzen](https://www.vogel-beratung.com/culture/verg%C3%BCtungsgrunds%C3%A4tze).

Skills & Arbeitsweise

-

Du beherrschst die HGB-Bilanzierung im Mittelstand mit ihren echten Streitpunkten — Bestandsbewertung, unfertige Leistungen, Rückstellungen, Gesellschafterkonten.

-

Du liest ein Unternehmen aus seinen Zahlen und übersetzt das in eine Handlungslinie, die ein Inhaber versteht und mitgeht.

-

Du beherrschst die Mechanik von Planung und Forecast — Szenarien, Liquidität, Deckungsbeitrag — und kannst sie auch in einem Unternehmen aufbauen, das bisher keine hatte.

-

Du arbeitest mit KI als selbstverständlichem Werkzeug — Plausibilisierung, Analyse von Kontenbewegungen, Aufsetzen von Planungslogiken, Drafting. Repetitive Auswertungen sind dir ein Reiz zur Automatisierung, kein Schicksal.

Mindset & Persönlichkeit

-

Du bist Zahlenmensch und Beziehungsmensch in einer Person — du gewinnst das Vertrauen eines Unternehmers und unterlegst es mit belastbarer Analyse.

-

Du entwickelst jüngere Kollegen gern und siehst deren Fortschritt als Teil deines eigenen Ergebnisses.

-

Du bringst die Demut mit, von Praktikern zu lernen. Der Unternehmer mit dreißig Jahren am Markt weiß Dinge über sein Geschäft, die in keinem Modell stehen.

-

Du hast den Anspruch, in allem, was du ablieferst, den höchsten Standard zu setzen — nicht weil jemand es kontrolliert, sondern weil Mittelmaß dich persönlich stört.

### Was du bei uns nicht finden wirst

-

**Kein Zahlenwerk ohne Gespräch.** Wer den Abschluss baut und dann abgibt, ist hier falsch. Du vertritt deine Zahlen selbst beim Unternehmer.

-

**Kein reines Controlling ohne Bilanzverantwortung.** Du trägst den Abschluss selbst. Zahlen interpretieren, ohne für sie einzustehen, gibt es hier nicht.

-

**Kein Buchhaltungs-Hinterzimmer ohne Gestaltungs-Anteil.** Erfassung und Abstimmung laufen weitgehend maschinell. Was bleibt, ist Beurteilung, Beratung und die Frage, wie weit die Automatisierung noch geht.

-

**Kein Konzern-Korsett, in dem du auf Beförderungen wartest.** Wachstum entsteht hier am Beitrag, nicht am Berufsjahr.

-

**Keine Partnergesellschaft mit konkurrierenden Eigeninteressen.** Wir sind ein Unternehmen mit One-Firm-Logik — eine Marke, eine Kultur, eine Hiring-Bar. Kein Management-by-Committee, kein Konsens als Selbstzweck.

# FAQ

### 1. Was ist Vogel — und wo arbeitet ihr?

Vogel ist eine der führenden Mittelstandsberatungen Deutschlands — Familienunternehmen seit 1959, aus Aalen — und baut daraus die führende Beratungsplattform für den Mittelstand. Wir wachsen an mehreren Standorten: in Aalen/Ostwürttemberg als gewachsenem Stammsitz und in München als neuem Hub. An beiden suchen wir quer durch die Funktionen — von Steuerberatung über Beratung bis zu den strategischen Teams, die die Plattform bauen.

### 2. Wie sind die Gehaltsbänder zu verstehen?

Bewusst breit — und an jeder Stelle ausgewiesen. Wir differenzieren nach Track Record und Marktwert, nicht nach Abschluss: knappe, stark gefragte Profile am oberen Ende, weniger knappe am unteren. Wir kalibrieren ausschließlich am Markt — zwei Menschen mit ähnlicher Erfahrung können bei uns unterschiedlich verdienen.

### 3. Wie viel — und wie — wird bei Vogel gearbeitet?

Gemessen wird an dem, was du bewegst, nicht an Stunden. Ehrlich ist aber auch: Wer 9-to-5 sucht, ist bei uns nicht die erste Adresse. Wir suchen Menschen, die aus eigenem Antrieb intensiv arbeiten, weil die Aufgaben es wert sind. Wie du deine Zeit verteilst, ist weitgehend deine Sache. Was wir teilen: Wir arbeiten präsent zusammen — Kultur, Sparring und die besten Ideen entstehen in der täglichen Nähe. Wir sind keine Remote-Company und haben keine großen Home-Office-Policies; einzelne Remote-Tage sind kein Problem.

### 4. Wie läuft die Bewerbung?

Schlank, schnell, transparent — und nach Profil gestaffelt. Für Einstiegsrollen (Praktikum, Werkstudium, Berufseinstieg) genügen in der Regel zwei Gespräche und eine kurze Arbeitsprobe; erfahrene Rollen laufen etwas ausführlicher. Bei ausgewählten Senior-Rollen prüfen wir, künftig einen gemeinsamen Arbeitstag einzubauen, damit beide Seiten sich besser kennenlernen. Immer gilt: getaktete Termine, zügige Entscheidung, substanzielles Feedback — unabhängig vom Ausgang.

### 5. Wie funktioniert die variable Vergütung?

Quartalsweise an Leistung gekoppelt, qualitativ bewertet. Die Skala steigt mit dem Level: bis 20 % Associate, 27,5 % Manager, 35 % Senior Manager, 42,5 % Director, 50 % VP. Erwartungswert bei guter Leistung — du erfüllst die Anforderungen, setzt eigene Akzente, bestehst den Keeper Test — liegt bei rund 50 % des Maximums; der Maximalbonus ist nicht der Normalfall. Im Fokus steht eine ganzheitliche Beurteilung durch deine Führungskraft: Ownership, Qualität, Lernkurve, Zusammenarbeit, Impact.

### 6. Wie entwickle ich mich — welche Karrierewege gibt es?

Zwei aktive Wege: Mastery (fachliche Tiefe, Expertenlaufbahn) und Pioneer (Führung, Management). Die Richtung wählst du nach dem Onboarding, meist in Jahr 1–3. Berufseinstieg ist kein Sonderweg, sondern der frühe Teil derselben Strecke — vom Werkstudenten oder Praktikanten zum Associate, für die Besten ohne erneutes Bewerbungsverfahren.

### 7. Team, Kultur, Urlaub?

Ein gemeinsames Mittagessen ist ein offenes tägliches Angebot — keine Pflicht; wer mag, kommt dazu, essen kann jeder jederzeit. Dazu Abendessen, Social Events und Offsites in regelmäßigem Rhythmus — nicht als Pflichtprogramm, sondern weil ein gutes Team auch abseits der Arbeit Zeit teilt. Benefits: durchdacht und substanziell, nicht symbolisch. Urlaub: 28 Tage.

### 8. Ich kenne jemanden — gibt es einen Empfehlungsbonus?

Ja — 2.500 EUR für jede erfolgreich besetzte Stelle (keine Praktika). Kurzer Kontext reicht: an wen du denkst, für welche Rolle, warum. Muss nicht perfekt sitzen, aber substanziell sein.

Compensation: €108,375 – €133,875 • Fix: €85k – €105k · Bonus: €23,375k – €28,875k · EV: €99,45k – €122,85k

- • OTE €108,375 – €133,875 • Fix: €85k – €105k · Bonus: €23,375k – €28,875k · EV: €99,45k – €122,85k

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
