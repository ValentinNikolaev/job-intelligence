# Senior Digital Design Engineer (FPGA)

Posted: 2026-08-26T02:24:24Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**Help Build Europe's Hypersonic Capability**

At **Hypersonica**, we’re redefining what’s possible in European defence technology. We exist to deliver speed, resilience, and technological independence at a pace that sets a new standard. We are a small, elite team working on problems that matter, and solving them fast.

By joining **Hypersonica**, you’re not stepping into a predefined role. You’re joining a talent dense environment where every individual shapes the direction of the company. Our philosophy is to hire a small number of exceptional people with broad, deep technical capability, strong judgement, and the ability to operate autonomously.

We hire for talent, not rigid boxes. This role represents a business need, but the way it evolves will be shaped by the individual. If you’ve achieved what others said was impossible, or you bring a unique combination of skills that doesn’t fit a traditional mould, we want to hear from you. The work you do here directly contributes to Europe’s technological independence.

### What you'll do

- Design and implement FPGA architectures using VHDL or Verilog.

- Develop digital signal processing (DSP) algorithms for real-time applications.

- Implement high-speed communication interfaces (PCIe, Ethernet, Aurora, LVDS, etc.).

- Optimize FPGA resource utilization, timing closure, and power consumption.

- Develop simulation environments and verification testbenches.

- Integrate FPGA designs with embedded processors and hardware platforms.

- Debug FPGA designs using laboratory equipment and on-chip debugging tools.

- Collaborate with hardware and software engineers throughout system development.

- Prepare design documentation and maintain version-controlled FPGA projects.

- Contribute to system architecture decisions and provide technical leadership within the FPGA domain.

**Who You Are**

- 8+ years of professional experience in FPGA design and digital system development, with deep VHDL/Verilog expertise.

- Proven track record implementing DSP algorithms for real-time applications and high-speed interfaces (PCIe, Ethernet, Aurora, LVDS).

- Skilled in timing closure, resource optimization, and power-aware FPGA design.

- Experienced building simulation environments and verification testbenches; comfortable with on-chip debugging tools and lab-based validation.

- Able to integrate FPGA designs with embedded processors and hardware platforms.

- Provides technical leadership within the FPGA domain and contributes to system architecture decisions.

- Collaborative, working closely with hardware and software engineering teams across the full development lifecycle.

**What We Offer**

- A mission driven environment with the opportunity to work on one of Europe’s most consequential defence challenges, with direct impact on sovereign capability and security.

- Daily collaboration with top experts across engineering, operations, and defence, with real opportunity to learn from the best, contribute, and grow.

- High ownership and autonomy; no time tracking, no micromanagement, just clear objectives and accountability for outcomes.

- A fast paced environment where good ideas are implemented quickly, and feedback from test and flight drives real decisions.

- A culture that values clarity, integrity, and excellence, and supports people who take initiative and push boundaries responsibly.

- Competitive compensation and real share options aligned to responsibility and impact, not tenure or hierarchy.

At Hypersonica, every hire raises the bar. We are deliberately small, intensely capable, and deeply mission-driven. If this role feels like a strong fit, or if you believe you bring something exceptional that goes beyond the description, we encourage you to apply.

Hypersonica is an equal-opportunity employer and assesses candidates solely on merit, capability, and potential.

You can apply directly to this role or reach out to Nathan Sweeney, Head of Talent. We review every application and aim to respond to all candidates within two weeks, whether the answer is yes or no.

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
