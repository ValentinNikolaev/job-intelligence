# Manufacturing Engineer

Posted: 2026-08-26T02:40:27Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**WHO WE ARE**

Proxima Fusion is Europe’s fastest-growing fusion company and the continent’s best-funded fusion player, as well as the first spin-out from the Max Planck Institute for Plasma Physics (IPP). Backed by over €650M and powered by a growing team across Munich, Zurich, and Oxford, we are developing the hardware and infrastructure needed to deliver the world’s first commercial stellarator fusion power plant.

Our concept advances the most mature fusion technology out there, the Wendelstein 7-X stellarator, through two next-generation machines: Alpha and Stellaris. Our work combines stellarator optimization, advanced computation, machine learning, and high-temperature superconducting magnets to unlock higher-performance designs that were previously out of reach.

Turning these designs into a functioning fusion power plant requires excellence and ownership across every discipline, from physics and engineering to software, manufacturing, law, and business functions.

**BY JOINING OUR TEAM YOU’LL GET TO**

-

**Build the machine that builds the machine**. Join TechOps at the forefront of advanced manufacturing, we’re building the production system that will enable commercial fusion. The Production lines, tooling, and processes are being developed from the ground up; you'll create the ways of working, not inherit them.

-

**Work at the frontier of manufacturing technology**. Bring your creativity to evaluate, qualify, and deploy processes with no industry playbook, every component you build and every process you shape goes directly into the core of the stellarator magnet technology.

-

**Do work that matters, and see it grow**. The hardware you build is the product and your career grows with it, from prototyping and process development through quality and industrialization, alongside exceptional colleagues from around the world.

-

**Make an impact you can point to**. In a small, fast-moving team, your calls on equipment, quality, and process directly shape how a world-class deep-tech company produces superconducting magnets with results visible on the shop floor, not buried in a slidedeck.

**YOUR IMPACT**

Develop and industrialize the manufacturing processes used to build HTS magnet coils.

Translate magnet designs into repeatable, high-yield production processes in collaboration with design, physics, and production teams.

Own the tooling, fixtures, and quality systems required to deliver consistent and reliable manufacturing outcomes.

Lead process development from prototype builds through the transition to full-scale manufacturing.

**WHAT YOU WILL DO**

-

Develop, qualify, and continuously improve manufacturing processes for HTS coil winding, insulation, impregnation, and joining, working closely with magnet design and materials engineers.

-

Drive design-for-manufacturing/design-for-assembly (DFM (Design for Manufacturing)/DFA (Design for Assembly)) collaboration with the design team, acting as the manufacturing voice in design reviews to keep coil designs buildable, scalable, and serviceable.

-

Design, procure, and validate tooling, fixtures, and jigs for precision winding and assembly of non-planar coil geometries, including capability studies where needed.

-

Define assembly sequences, work instructions, SOPs (Standard Operating Procedures), and visual aids for technicians, and maintain this documentation as designs evolve.

-

Define and implement process controls and inspection methods (dimensional, electrical, structural) to catch defects early and protect conductor integrity.

-

Lead NPI (New Product Introduction) campaigns, process trials and pilot builds, and provide hands-on floor support during prototype and early production builds.

-

Lead root-cause analysis and corrective actions (8D (Eight Disciplines problem-solving methodology), 5-Why, fishbone, etc.) for yield, quality, and cycle-time issues, and apply Lean/Six Sigma principles to drive measurable process improvement.

-

Support supplier qualification and incoming inspection criteria for tooling, components, and outsourced subassemblies.

-

Manage engineering/process change control as designs and processes mature.

-

Collaborate cross-functionally with design, quality, supply chain, and test engineering to resolve manufacturability issues early and support the ramp from prototype to serial production.

**WHO YOU ARE**

-

3+ years specifying, procuring, installing, commissioning, and qualifying production equipment and/or automation for component manufacturing lines and/or assembly cells — including RFQ (Request for Quote) ownership, supplier management, FAT (Factory Acceptance Test)/SAT (Site Acceptance Test), and production ramp.

-

Hands-on experience designing tooling and fixtures for low-volume, high-precision production, and proficiency in CAD (Computer-Aided Design) (SolidWorks, CATIA, or similar) plus a solid grasp of GD&T (Geometric Dimensioning and Tolerancing).

-

Track record of writing clear work instructions, SOPs, and process documentation in a production or NPI(New Product Introduction) environment.

-

Working knowledge of process control, statistical methods, and structured root-cause problem solving (SPC (Statistical Process Control), FMEA (Failure Mode and Effects Analysis), 8D).

-

Experience supporting prototype or first-article builds directly on the floor, not just from a desk.

-

Strong communication skills in German or English.

-

Bachelor's or Master's degree in Mechanical Engineering, Manufacturing Engineering, Materials Science, or a related field.

Nice to have:

-

Experience with Product Lifecycle Management (PLM) systems for engineering change control and manufacturing documentation management (e.g. Arena, Enovia).

-

Experience with Manufacturing Execution Systems (MES)/Platforms (e.g. Tulip, Delmia).

-

Experience working in a research-to-product transition environment, where designs and processes evolve rapidly.

-

Experience scaling a process from prototype to serial production in a startup or fast-moving environment.

**INTERVIEW PROCESS**

-

Recruiter Interview (30-60 min)

-

Technical Screening (30 min)

-

Technical Panel (3x60 min)

-

CEO call (30 min)

*This role sits at L2/L3 of our framework, please inquire during the recruitment process for further information*

At Proxima Fusion, our mission is bold: making limitless clean energy a reality. To get there, we need a high-performing, diverse team that brings different perspectives, challenges assumptions, and builds together with purpose. We know that diversity of thought and experience leads to better ideas, stronger execution, and a more resilient team. We don’t look at how you identify, what you look like, who you choose to worship or what ethnicity you are. We care about what you can bring to the table.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
