# Chief E-Commerce Officer (m/w/d)

Posted: 2026-08-26T02:30:08Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

#### **Gestalte die Zukunft der Lederindustrie mit uns bei Gusti Leder 💻🌍✨**

Tauche ein in die Welt von Gusti Leder, wo jede Tasche eine Geschichte erzählt und jedes Produkt mehr als nur ein Accessoire ist – es ist ein Statement für transparente Produktion und Stil. Bei [Gusti Leder GmbH](https://www.gusti-leder.de/uebersichtsseite-philosophie-de-ch-at), einem Unternehmen, das für sein Engagement für Transparenz, Qualität und die Förderung von Slow Fashion bekannt ist, bieten wir Dir mehr als nur einen Job. Wir bieten Dir eine Chance, Teil einer Bewegung zu sein, die darauf abzielt, die Lederindustrie zum Besseren zu verändern.

Du denkst in digitalen Strategien, führst mit Weitblick und willst den E-Commerce eines Unternehmens nachhaltig gestalten und skalieren? Dann suchen wir dich als **Chief E-Commerce Officer (m/w/d)**, um unser digitales Wachstum national wie international auf das nächste Level zu heben.

#### **Deine Mission:**

-

**Strategie & Wachstum: **Du entwickelst und verantwortest unsere unternehmensweite E-Commerce-Strategie – mit einem klaren Fokus auf unsere Kernplattformen **Shopify, Zalando und Amazon.**

-

**Digitale Umsatzverantwortung: **Du steuerst alle Online-Vertriebskanäle, insbesondere Shopify, Zalando und Amazon mit dem Ziel, Umsatz, Marge und Effizienz kontinuierlich zu steigern.

-

**Kundenerlebnis & Conversion: **Du optimierst die digitale Customer Journey entlang aller Touchpoints – von der Traffic-Generierung über die Conversion bis zur Kundenbindung.

-

**Führung & Zusammenarbeit: **Du leitest ein interdisziplinäres E-Commerce-Team und arbeitest eng mit IT, Vertrieb, Logistik, Produkt und Management zusammen.

-

**Innovation & Marktbeobachtung: **Du identifizierst neue Trends, Tools und Technologien, testest innovative Ansätze und entwickelst daraus zukunftsorientierte Maßnahmen.

**
**

#### **Was Dich bei Gusti Leder erwartet:**

-

**Ein wettbewerbsfähiges Gehaltspaket: **Ein attraktives Jahresgehalt von bis zu 100.000 €, inklusive Überstundenvergütung, denn wir schätzen Dein Engagement.

-

**Außergewöhnliche Benefits: **Vom attraktiven Prämiensystem, flexible Arbeitszeiten bis hin zu exklusiven Mitarbeiter-Rabatten, regelmäßigen Massagen und Yoga-Sessions – wir sorgen für Dein Wohlbefinden.

-

**Eine inspirierende Arbeitskultur:** Erlebe flache Hierarchien, offene Kommunikation und regelmäßige Teamevents, die unsere familiäre Atmosphäre stärken.

-

**Energie für den Tag: ﻿**Genieße zweimal pro Woche ein frisch zubereitetes, kostenloses Mittagessen, das dir Energie für den restlichen Tag gibt.

#### **
Was Du mitbringen solltest:**

-

Abgeschlossenes Studium im Bereich Betriebswirtschaft oder Wirtschaftsinformatik sowie nachweisbare Erfahrungen im Bereich E- Commerce.

-

Mindestens 3 Jahre fundierte Shopify-Erfahrung.

-

Du verfügst über umfassende Erfahrung in der Führung von Teams und bringst herausragende Führungs- und Sozialkompetenzen mit.

-

Fundiertes Verständnis von digitalen Vertriebskanälen und -strategien sowie Kenntnisse über die Online-Marktplätze Amazon und Zalando.

-

Hohe IT-Affinität und Lernbereitschaft zeichnen Dich aus.

-

Du kannst an **mind. 3 Tagen in der Woche** im Rostocker Büro anwesend sein.

-

Fließende Deutsch- und Englischkenntnisse in Wort und Schrift runden Dein Profil ab.

#### **Interessiert?**

Wir freuen uns auf Deine Bewerbung über unser Online-Formular. Die Bewerbung dauert nur 5 Minuten.

Solltest Du Fragen haben, ist Deine Ansprechpartnerin **Lea **über** **

__________________________________________________________________________________________________________________________________

####

#### **Über uns**

Wir bei Gusti Leder glauben daran, dass Nachhaltigkeit, Transparenz und Fairness nicht nur Schlagworte sind – sondern die Zukunft der Modeindustrie bestimmen. Seit 2009 designen wir mit Leidenschaft faire Lederprodukte, die weltweit überzeugen. Mit unserem Team in Rostock, unseren internationalen Partnern und einer stetig wachsenden Community sind wir auf dem Weg, Marktführer für nachhaltige Lederprodukte zu bleiben – und noch stärker zu werden.

Werde Teil unserer Mission. Werde Teil von **#TeamGusti**. 💚

Weitere Informationen zur Datenverarbeitung im Bewerbungsverfahren findest Du hier:[ https://gusti-leder.de/policies/privacy-policy](https://gusti-leder.de/policies/privacy-policy)

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
