# Elektroniker (m/w/d)

Posted: 2026-08-26T02:40:32Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

# **Wer wir sind**

Wir sind ein schnell wachsendes Unternehmen im Bereich Embodied AI, das die menschliche Arbeitswelt revolutioniert. Mit modernster Robotik und fortschrittlicher künstlicher Intelligenz entwickeln wir transformative Technologien, die neu definieren, wie Arbeit über verschiedenste Branchen hinweg erledigt wird — und ermöglichen es Unternehmen, Abläufe zu optimieren, die Produktivität zu steigern und neue Möglichkeiten zu erschließen.

# **Überblick**

Wir suchen einen erfahrenen Elektriker, der die elektrische Verkabelung und Steuerungssysteme unserer autonomen Robotersysteme installiert, verkabelt und in Stand hält. In dieser Rolle arbeitest du eng mit unserem Mechanical- und Hardware-Team zusammen, um sicherzustellen, dass alle elektrischen Komponenten zuverlässig funktionieren und nahtlos in die Gesamtsysteme integriert sind.

# **Deine Aufgaben**

***Elektrokonstruktion und Planung:***

-

Elektrokonstruktion gemäß geltenden Richtlinien und Normen.

-

Erstellung von Schaltplänen für unsere Robotersysteme.

***Installation und Verkabelung:***

-

Verkabelung und Installation elektrischer Komponenten und Steuerungssysteme in unseren Robotersystemen.

-

Montage von Schaltschränken, Steckverbindern und Sensorik nach technischen Zeichnungen und Schaltplänen.

-

Verlegung und Anschluss von Kabeln unter Einhaltung geltender Sicherheits- und Qualitätsstandards.

***Test, Wartung und Fehlerbehebung:***

-

Prüfung und Inbetriebnahme elektrischer Systeme vor Auslieferung und Installation beim Kunden.

-

Diagnose und Behebung elektrischer Störungen während der Entwicklung, der Fertigung und im laufenden Betrieb.

-

Durchführung regelmäßiger Wartungs- und Sicherheitsprüfungen an bestehenden Systemen.

***Zusammenarbeit:***

-

Enge Abstimmung mit den Mechanical- und Software-Teams zur Integration elektronischer Komponenten in die physische Struktur der Roboter.

-

Unterstützung bei Vor-Ort-Installationen und Inbetriebnahmen beim Kunden.

-

Reisebereitschaft ~50%

# **Qualifikationen & Anforderungen**

-

Abgeschlossene Ausbildung als Elektriker, Elektroniker für Betriebstechnik, Mechatroniker oder eine vergleichbare Qualifikation.

-

Sicherer Umgang mit Schaltplänen sowie Kenntnisse in Verkabelung, Verdrahtung und Anschlusstechnik.

-

Erfahrung im Umgang mit Mess- und Prüfgeräten (z. B. Multimeter, Oszilloskop).

-

Kenntnisse relevanter elektrischer Sicherheitsnormen und -vorschriften.

-

Erfahrung in der Robotik, Automatisierungstechnik oder im Maschinenbau von Vorteil.

-

Selbstständige, sorgfältige Arbeitsweise sowie Teamfähigkeit.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
