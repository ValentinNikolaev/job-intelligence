# Senior Power Electronics Engineer

Posted: 2026-08-26T02:24:24Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**Help Build Europe's Hypersonic Capability**

At **Hypersonica**, we’re redefining what’s possible in European defence technology. We exist to deliver speed, resilience, and technological independence at a pace that sets a new standard. We are a small, elite team working on problems that matter, and solving them fast.

By joining **Hypersonica**, you’re not stepping into a predefined role. You’re joining a talent dense environment where every individual shapes the direction of the company. Our philosophy is to hire a small number of exceptional people with broad, deep technical capability, strong judgement, and the ability to operate autonomously.

We hire for talent, not rigid boxes. This role represents a business need, but the way it evolves will be shaped by the individual. If you’ve achieved what others said was impossible, or you bring a unique combination of skills that doesn’t fit a traditional mould, we want to hear from you. The work you do here directly contributes to Europe’s technological independence.

### What you'll do

- Design high-power electronic systems for demanding industrial, aerospace, or defense applications.

- Develop schematics and PCB layouts for power electronics using Altium Designer.

- Develop power distribution, protection, and switching circuits operating at high voltage and current levels.

- Design DC/DC converters, power conditioning, and battery interface circuits.

- Perform thermal analysis and optimize designs for efficiency and reliability.

- Select power semiconductors, magnetic components, and protection devices.

- Conduct circuit simulation and validate power electronics performance.

- Support prototype testing, fault analysis, and hardware debugging.

- Ensure compliance with (std), (std), (std), EMC, and reliability requirements.

- Collaborate with mechanical and system engineers on integration and packaging.

- Prepare technical documentation, test reports, and manufacturing support documentation.

**Who You Are**

- 8+ years of professional experience in power electronics design for industrial, aerospace, or defense applications.

- Skilled in schematic capture and PCB layout for high-power electronics using Altium Designer.

- Experienced designing DC/DC converters, power conditioning, battery interface, and high-voltage/high-current protection and switching circuits.

- Proficient in thermal analysis, component selection (power semiconductors, magnetics, protection devices), and reliability-driven design optimization.

- Comfortable validating designs through simulation, prototype testing, fault analysis, and hardware debugging.

- Familiar with the compliance landscape for defense/aerospace power systems (EMC, reliability, and applicable safety standards).

- Collaborative, working closely with mechanical and systems engineering teams on integration and packaging.

**What We Offer**

- A mission driven environment with the opportunity to work on one of Europe’s most consequential defence challenges, with direct impact on sovereign capability and security.

- Daily collaboration with top experts across engineering, operations, and defence, with real opportunity to learn from the best, contribute, and grow.

- High ownership and autonomy; no time tracking, no micromanagement, just clear objectives and accountability for outcomes.

- A fast paced environment where good ideas are implemented quickly, and feedback from test and flight drives real decisions.

- A culture that values clarity, integrity, and excellence, and supports people who take initiative and push boundaries responsibly.

- Competitive compensation and real share options aligned to responsibility and impact, not tenure or hierarchy.

At Hypersonica, every hire raises the bar. We are deliberately small, intensely capable, and deeply mission-driven. If this role feels like a strong fit, or if you believe you bring something exceptional that goes beyond the description, we encourage you to apply.

Hypersonica is an equal-opportunity employer and assesses candidates solely on merit, capability, and potential.

You can apply directly to this role or reach out to Nathan Sweeney, Head of Talent. We review every application and aim to respond to all candidates within two weeks, whether the answer is yes or no.

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
