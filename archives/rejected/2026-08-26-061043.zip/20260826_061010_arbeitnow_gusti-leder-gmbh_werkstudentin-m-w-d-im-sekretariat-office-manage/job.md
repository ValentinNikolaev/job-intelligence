# Werkstudentin (m/w/d) im Sekretariat / Office Management

Posted: 2026-08-26T02:30:08Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

#### **Gestalte die Zukunft der Lederindustrie mit uns bei Gusti Leder🌍✨**

Tauche ein in die Welt von Gusti Leder, wo jede Tasche eine Geschichte erzählt und jedes Produkt mehr als nur ein Accessoire ist – es ist ein Statement für transparente Produktion und Stil. Bei [Gusti Leder GmbH](https://www.gusti-leder.de/uebersichtsseite-philosophie-de-ch-at), einem Unternehmen, das für sein Engagement für Transparenz, Qualität und die Förderung von Slow Fashion bekannt ist, bieten wir Dir mehr als nur einen Job. Wir bieten Dir eine Chance, Teil einer Bewegung zu sein, die darauf abzielt, die Lederindustrie zum Besseren zu verändern.

Als **Werkstudent:in im Office Management** bist du die gute Seele im Hintergrund, die dafür sorgt, dass im Büroalltag alles reibungslos läuft. Dein Ziel: organisieren, strukturieren und mitgestalten. 🚀

### Deine Mission

📬 **Organisation im Griff haben:**
Du verwaltest die ein- und ausgehende Post, bearbeitest Aufträge und sorgst für einen effizienten Büroalltag.
🎉 **Events planen & koordinieren:**
Du unterstützt bei internen und externen Veranstaltungen.
🤝 **Kommunikation & Schnittstellen:**
Du pflegst den Kontakt zu Behörden, Partnern und Dienstleistern und sorgst dafür, dass Projekte reibungslos laufen.
🔍 **Recherchieren & vorausschauen:**
Mit deinem Organisationstalent und analytischem Denken erkennst du Trends, bereitest Informationen auf und hilfst, dass wir immer einen Schritt voraus sind.

### Was du mitbringst

💼 Du verfügst idealerweise über erste praktische Erfahrung in der Büroorganisation bzw. im Office Management – aber auch motivierte Quereinsteiger:innen sind herzlich willkommen.
💡 Dein Organisationsgeschick, Deine Eigeninitiative, Dein Verantwortungsbewusstsein, Deine Flexibilität und Teamfähigkeit sind gefragt.
🗣️ Dein sicheres und eloquentes Auftreten sowie ein gutes Gespür für Menschen zeichnen Dich in der Kommunikation aus.
📝 Sehr gute Kenntnisse in Deutsch und Englisch sind erforderlich, um unsere globale Vision zu kommunizieren.

### Was dich bei Gusti Leder erwartet

🌱 **Nachhaltigkeit first** – Wir leben Slow Fashion und gestalten die Lederindustrie verantwortungsvoll.

💡 **Gestaltungsfreiheit** – Deine Ideen prägen, wie wir arbeiten und wahrgenommen werden.

💪 **Sehr gute Entwicklungsmöglichkeiten **– In dieser Position hast Du die Chance, zunehmend Verantwortung zu übernehmen und Dich innerhalb unseres Unternehmens beruflich weiterzuentwickeln.

🎉 **Teamkultur** – Flache Hierarchien, offene Kommunikation, regelmäßige Teamevents.

🧘 **Work-Life-Balance** – flexible Arbeitszeiten und Yoga-Sessions.
🍽️ **Energie für den Tag** – Zweimal pro Woche frisches Mittagessen.

🍏 **Frisches Extra** – Täglich frisches Obst, Kaffee & Wasser for free.

🚆 **Gute Anbindung** - Hauptbahnhof in unmittelbarer Nähe.

🚗 **Bequem parken **– Stellplätze direkt vor dem Büro.
🎁 **Exklusive Rabatte** – für unsere Produkte & zahlreiche weitere Corporate Benefits.

💰 **Attraktives Gehaltspaket** inklusive Überstundenvergütung.

###

#### 📩**Interessiert?**

Wir freuen uns auf Deine Bewerbung und Dich kennen zu lernen.

#### ❤️Über Gusti Leder

Unsere Produkte sind ein Symbol für bewussten Konsum und nachhaltige Eleganz. Wir sind stolz darauf, unseren Kunden nicht nur hochwertige Naturprodukte zu bieten, sondern auch den Charme und die Eleganz von Vintage-Lederwaren nahezubringen. Vom unverkennbaren Geruch echten Leders bis hin zu unserer vielfältigen Produktpalette, die von Taschen über Rucksäcke bis hin zu Accessoires und Schreibwaren reicht, hat Gusti Leder für jeden etwas zu bieten. Unser Ziel ist es, stilvolle, aber auch funktionale Produkte zu schaffen, die dich auf all deinen Abenteuern begleiten.

Weitere Informationen zur Datenverarbeitung im Bewerbungsverfahren findest Du hier:[ https://gusti-leder.de/policies/privacy-policy](https://gusti-leder.de/policies/privacy-policy)

Im Rahmen des Bewerbungsprozesses übernehmen wir keine dafür anfallenden Reisekosten.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
