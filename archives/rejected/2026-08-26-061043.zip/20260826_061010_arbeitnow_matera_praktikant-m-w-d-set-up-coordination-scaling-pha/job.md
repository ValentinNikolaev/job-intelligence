# Praktikant (m/w/d) Set-Up Coordination | Scaling Phase

Posted: 2026-08-26T02:30:39Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**In a nutshell:**

Als Praktikant (m/w/d) im Bereich Set-Up Coordination bist du bei uns genau richtig, wenn du dafür brennst Kund*innen dank deiner organisatorischen Fähigkeiten glücklich zu machen. Arbeite mit uns in Berlin im Office oder flexibel hybrid, Vollzeit. Starte ab sofort mit einer Dauer ab 6 Monaten.

**Deine Aussichten:**

-

Monatliche Vergütung von 1.200-2.222€

-

Matera Benefits: vergünstigte Mitgliedschaft für den Urban Sports Club, Lunch-Gutscheine und ein monatlicher ÖPNV-Zuschuss

-

Eigenverantwortliches Arbeiten mit Gestaltungsfreiraum

-

Steile Lernkurve in einem aufstrebenden SaaS Start-up

-

Ambitioniertes Team, bei dem der Spaß auch nicht zu kurz kommt:)

**Deine Rolle bei Matera:**

-

Du digitalisierst und archivierst die Unterlagen unserer neuen Kund*innen im Rahmen der Einrichtung ihrer Matera-Plattform – dabei scannst du Dokumente, prüfst sie auf Vollständigkeit und ordnest sie korrekt den jeweiligen Kategorien und Kund*innenkonten zu

-

Du stehst mit den verschiedenen Abteilungen (Buchhaltung, Rechtsabteilung, Sales) im Austausch, um fehlende oder unklare Unterlagen zu klären und eine lückenlose, korrekt zugeordnete Dokumentation sicherzustellen

-

Du trägst durch sorgfältige Qualitätskontrolle der archivierten Unterlagen zur kontinuierlichen Verbesserung unserer internen Archivierungsprozesse bei und gibst Feedback an unser Produkt- und Techteam, um die Ablagestruktur weiterzuentwickeln

**Das bringst du mit:**

-

Du glänzt mit deinen kommunikativen Fähigkeiten

-

Du bist sehr organisiert und behältst immer den Überblick

-

Du hast ein entrepreneurial Mindset und eine hands-on Mentalität

-

Du sprichst Deutsch auf muttersprachlichem Niveau und kannst sicher auf Englisch kommunizieren

*Bei Matera garantieren wir Chancengleichheit und Vielfalt. Hier bist du so willkommen, wie du bist!*

*
*

**Unsere Mission:**

Unsere Mission bei Matera ist es, Wohnungseigentümer*innen glücklich zu machen! Durch uns können sie ihre Immobilie transparent und einfach selbst verwalten, oder die Verwaltung ganzheitlich in unsere Hände legen und dadurch eine Menge Zeit und Geld sparen. Seit 2017 sind wir auf dem französischen Markt aktiv und machen bereits jeden Tag das Leben von mehr als 100.000 Wohnungseigentümer*innen besser. In Deutschland haben wir seit 2021 ebenfalls einen großartigen Start mit einem ambitionierten Team hingelegt.

Hast du Lust die Skalierung des deutschen Marktes mit uns gemeinsam anzugehen? **Dann bewirb dich jetzt!:)**

Um unser Team kennenzulernen und Eindrücke von unserer Kultur zu bekommen, schaue gerne bei uns auf **[LinkedIn](https://www.linkedin.com/showcase/matera-deutschland/)** oder auf **[Instagram](https://www.instagram.com/matera_de/)** vorbei! Hier vorab aber schonmal ein kleiner Einblick von unserem CEO** [Raphaël](https://www.linkedin.com/in/rapha%C3%ABl-di-meglio-15ba5b8a/) **aus Frankreich:

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
