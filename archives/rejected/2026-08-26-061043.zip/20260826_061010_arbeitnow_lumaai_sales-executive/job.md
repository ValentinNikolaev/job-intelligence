# Sales Executive

Posted: 2026-08-25T23:40:34Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

You'll lead sales in the Germany for Luma as the first dedicated sales hire in-region, owning the full cycle and placing our frontier technology at the heart of the UK's creative ecosystem.

As the first German seller, you'll help evolve the playbook rather than just execute it — primarily outbound, targeting brands, agencies, and media across Europe with a focus on Germany, supported by the Head of EMEA. It fits a hunter who's built new business from scratch. If you need an established pipeline and process, this isn't it.

**What You'll Own**

-

Spearhead a primarily outbound strategy to engage decision-makers at target brand, agency, and media accounts across Europe, with a focus on Germany.

-

Own the full-cycle sales process from first contact to close, building the region's foundational pipeline, supported by the Head of EMEA.

-

Develop and execute the sales motion for Luma in Germany.

-

Turn creative agencies, media companies, and brands into flagship customers and advocates.

**First 90 Days**

*One way the first 90 could unfold.*

-

**Days 1–30 — Immerse & Diagnose:** Learn the product and the German/EU market, and start outbound to target accounts.

-

**Days 30–60 — Ship & Validate:** Run full-cycle deals and build a foundational pipeline.

-

**Days 60–90 — Scale & Systemize:** Close early accounts and help shape the Germany sales motion.

**What You Bring**

-

5+ years of full-cycle sales in a fast-paced, high-growth technology environment.

-

A proven hunter who's created new business from scratch through outbound prospecting.

-

Experience in the early and hypergrowth phase of a company, ideally as a founding or early sales hire in a new market.

-

A high-agency, entrepreneurial executor comfortable in ambiguous, resource-light settings.

-

Exceptional communication and the ability to articulate novel technology to creative and business leaders.

**Nice to Have**

-

Selling creative technology, generative AI, or high-growth product-led SaaS.

-

A genuine passion for the creative potential of AI.

-

Experience in a small team scaling rapidly.

*About Luma: Luma's mission is to build unified general intelligence that can generate, understand, and operate in the physical world. We believe multimodality is critical for intelligence — the next step beyond language models comes from vision. Luma is an equal opportunity employer.*

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
