# Senior Buyer

Posted: 2026-08-26T02:24:24Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**Help Build Europe's Hypersonic Capability**

At **Hypersonica**, we’re redefining what’s possible in European defence technology. We exist to deliver speed, resilience, and technological independence at a pace that sets a new standard. We are a small, elite team working on problems that matter, and solving them fast.

By joining **Hypersonica**, you’re not stepping into a predefined role. You’re joining a talent dense environment where every individual shapes the direction of the company. Our philosophy is to hire a small number of exceptional people with broad, deep technical capability, strong judgement, and the ability to operate autonomously.

We hire for talent, not rigid boxes. This role represents a business need, but the way it evolves will be shaped by the individual. If you’ve achieved what others said was impossible, or you bring a unique combination of skills that doesn’t fit a traditional mould, we want to hear from you. The work you do here directly contributes to Europe’s technological independence.

**What you’ll do**

- Build and own Hypersonica’s UK procurement capability from zero, covering direct materials, complex components, tooling, equipment, services, and production requirements.

- Take end-to-end ownership of the buying process, from demand definition and supplier identification through quotation, negotiation, purchase order placement, expediting, delivery, and supplier performance.

- Work closely with engineering, manufacturing, quality, programme, and finance teams to convert incomplete or evolving technical requirements into executable procurement plans.

- Secure long-lead, flight-critical, and schedule-critical items before they become programme constraints.

- Develop sourcing strategies for complex aerospace and defence hardware, including machined components, composites, electronics, sensors, actuators, propulsion-related hardware, specialist materials, tooling, and test equipment.

- Identify, assess, qualify, and onboard suppliers capable of meeting Hypersonica’s technical, quality, security, cost, and schedule requirements.

- Build strong supplier relationships while remaining commercially demanding on price, lead time, quality, responsiveness, and delivery performance.

- Lead RFQ and tender activity, structure commercial comparisons, negotiate terms, and make clear supplier recommendations based on total programme value rather than unit price alone.

- Own purchase-order accuracy, commercial terms, delivery schedules, change control, and supporting documentation.

- Run active expediting and supplier recovery activity, escalating early and driving action when delivery or quality performance threatens the programme.

- Partner with supplier quality and engineering teams to resolve technical issues, nonconformances, substitutions, and manufacturing constraints.

- Support make-versus-buy decisions and help define which capabilities should be retained internally versus placed with external suppliers.

- Build procurement processes, approval routes, supplier records, dashboards, and controls that are robust enough for defence hardware but light enough to support rapid execution.

- Establish clear reporting on commitments, lead times, supplier risk, cost exposure, late deliveries, and material availability.

- Support the implementation of SAP procurement processes, ensuring purchase orders, supplier data, approvals, receipts, and spend information are accurate and usable.

- Build category knowledge and a supplier base that can support progression from prototype builds into repeatable production.

- Contribute to the future procurement organisation, helping define where additional buyers, category specialists, or supplier-development capability will be needed.

**Who you are**

- An experienced buyer, senior buyer, procurement lead, or sourcing professional from aerospace, defence, automotive, motorsport, advanced manufacturing, or another complex hardware environment.

- Proven at owning procurement end to end rather than operating within one narrow stage of an established process.

- Experienced buying technically complex, low-volume, high-value, or mission-critical components and services.

- Comfortable working from incomplete BOMs, evolving designs, and urgent engineering requirements without losing commercial or configuration control.

- Strong at supplier identification, RFQs, commercial analysis, negotiation, contracting, purchase-order management, and expediting.

- Able to distinguish between a supplier that quotes well and one that can actually deliver conforming hardware on time.

- Experienced working closely with engineering and manufacturing teams and able to understand drawings, specifications, tolerances, materials, and manufacturing processes sufficiently to make sound sourcing decisions.

- Commercially sharp but operationally minded. You understand that the best procurement outcome is hardware arriving on time, to specification, at an acceptable cost.

- Confident challenging suppliers, engineers, and internal stakeholders when requirements, lead times, or decisions are putting delivery at risk.

- Experienced in supplier qualification, onboarding, risk assessment, and performance management.

- Familiar with aerospace or defence quality expectations such as AS9100, traceability, first article inspection, configuration control, and supplier nonconformance management.

- Comfortable building processes and supplier structures from zero rather than inheriting a mature category strategy or approved supplier base.

- Hands-on, fast-moving, and highly organised, with the judgement to prioritise the few items that genuinely determine programme velocity.

- Able to operate independently and make decisions with imperfect information while escalating material risks early.

- Experience purchasing for missile systems, propulsion, flight hardware, composites, electronics, special processes, or energetic-material environments would be advantageous but is not essential.

- Motivated by building a procurement function where supplier performance directly determines whether hardware ships, tests, and flies on schedule.

**Security and Eligibility Requirement**

- Due to the nature of the work with the UK MoD, applicants must be a British Citizen, or a dual national holding British citizenship, and eligible for UK Security Clearance and, where required, Developed Vetting.

**What we offer**

- A mission-driven environment with the opportunity to work on one of Europe’s most consequential defence challenges, with direct impact on sovereign capability and security.

- Daily collaboration with top experts across engineering, operations, and defence, with real opportunity to learn from the best, contribute, and grow.

- High ownership and autonomy; no time tracking, no micromanagement, just clear objectives and accountability for outcomes.

- A fast-paced environment where good ideas are implemented quickly, and feedback from build, test, and flight drives real decisions.

- A culture that values clarity, integrity, and excellence, and supports people who take initiative and push boundaries responsibly.

- Competitive compensation and real share options aligned to responsibility and impact, not tenure or hierarchy.

At Hypersonica, every hire raises the bar. We are deliberately small, intensely capable, and deeply mission-driven. If this role feels like a strong fit, or if you believe you bring something exceptional that goes beyond the description, we encourage you to apply.

Hypersonica is an equal-opportunity employer and assesses candidates solely on merit, capability, and potential.

You can apply directly to this role or reach out to Nathan Sweeney, Head of Talent. We review every application and aim to respond to all candidates within two weeks, whether the answer is yes or no.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
