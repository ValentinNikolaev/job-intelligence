# Industrial Designer

Posted: 2026-08-26T02:40:32Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

# Who We Are

We are a rapidly growing embodied AI company revolutionizing human labor. Leveraging cutting-edge robotics and advanced artificial intelligence, we develop transformative technologies that redefine how work is done across multiple industries — empowering businesses to streamline operations, boost productivity, and unlock new possibilities.

# Overview

We're looking for a talented Industrial Designer to shape the look, feel, and usability of our next-generation autonomous robot systems. In this role, you'll translate technical requirements into compelling product designs, working closely with our Mechanical Engineering team to ensure your designs are both visually strong and grounded in engineering reality.

# Your Responsibilities

***Design and Concept Development:***

-

Design housings, enclosures, and user-facing components for autonomous robot systems, balancing aesthetics, ergonomics, and brand identity.

-

Develop concept sketches, renderings, and 3D models to communicate design intent to stakeholders.

-

Translate design concepts into manufacturable geometry in close collaboration with Mechanical Engineers.

***Collaboration and Iteration:***

-

Work hand-in-hand with mechanical, electrical, and software teams to ensure designs integrate seamlessly with internal components.

-

Build and evaluate prototypes (foam, 3D-printed, or CNC) to validate form, fit, and user experience.

-

Iterate designs based on manufacturability, cost, and technical feedback.

# Qualifications & Requirements

-

Bachelor's or Master's degree in Industrial Design, Product Design, Mechanical Engineering, or a related field.

-

Strong portfolio demonstrating both aesthetic sensibility and technical understanding of materials and manufacturing.

-

Proficiency in CAD software (SolidWorks, Rhino, Fusion 360, or similar) and rendering tools (KeyShot, Blender).

-

Solid understanding of manufacturing processes (injection molding, sheet metal, CNC, 3D printing).

-

Ability to work at the intersection of design and engineering, and to communicate design decisions to a technical audience.

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
