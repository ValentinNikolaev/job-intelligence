# Lead Expert Tax (m/w/d)

Posted: 2026-08-25T23:40:23Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

## Deine Rolle

Vogel baut die führende Beratungsplattform für den deutschen Mittelstand auf — und Steuerberatung ist ihr Kern, kein Geschäftsfeld unter vielen. Eine Plattform dieser Größe braucht nicht nur Führungskräfte, die Bereiche steuern, sondern fachliche Autoritäten, vor deren Tiefe auch die schwersten Fälle lösbar werden. Lead Expert Tax ist genau diese Rolle.

Bei Vogel führt der Weg nach oben über zwei gleichwertige Pfade: Mastery für fachliche Tiefe und Pioneer für disziplinarische Führung. Du bist auf dem Mastery-Pfad ganz oben angekommen. Du bist Steuerberater, der in einem Spezialgebiet zur fachlichen Autorität geworden ist — Umwandlungen, internationale Strukturen, Nachfolge, Konzernsteuerrecht oder eine andere anspruchsvolle Materie — und das auch nach außen trägt: Veröffentlichungen, Vorträge, ein Fachberater-Standing, an dem man dich kennt. Du wechselst, weil du dein Gebiet als firmenweite Marke prägen und mitbauen willst, statt als einzelner Spezialist in fremder Struktur zu hängen.

Du bist die firmenweite fachliche Autorität deines Gebiets: Du trägst die schwersten Fälle der Gruppe, prägst die Methoden und Standards über den eigenen Schreibtisch hinaus und befähigst die Berufsträger der ganzen Tax-Linie. Das alles ohne disziplinarische Bereichsführung — deine Wirkung entsteht über fachliche Tiefe und Methodik, nicht über einen Personalapparat. Du arbeitest eng mit der Geschäftsführung und den Bereichs-Ownern an den fachlich anspruchsvollsten Mandanten- und Strategie-Themen.

## Deine Verantwortung

### Fachliche Autorität

-

Trag die schwersten Fälle und Sonderthemen der Gruppe in deinem Gebiet — die Mandate, bei denen die fachliche Tiefe über Erfolg oder Risiko entscheidet.

-

Sei der firmenweite Eskalations-Endpunkt deines Gebiets — die Person, die man bei der wirklich schweren Frage anruft.

-

Halte Vogel in deinem Gebiet auf dem aktuellen Stand von Rechtsprechung, Gesetzgebung und Gestaltungspraxis — und übersetze das in konkrete Mandanten-Konsequenzen.

### Methodik & Befähigung

-

Präge die fachlichen Standards und Methoden deines Gebiets firmenweit — Templates, Prüfschemata, Beratungslinien, die die ganze Tax-Linie nutzt.

-

Befähige Senior Experts und Experts über Standorte hinweg — Sparring, Schulungen, fachliche Führung ohne disziplinarische Linie.

-

Sei fachlicher Sparringspartner der Bereichs-Owner und der Geschäftsführung bei den schwersten Mandanten- und Strukturfragen.

### Marke & Markt

-

Trag dein Gebiet als Vogel-Stärke nach außen — Veröffentlichungen, Vorträge, Fachformate — und mach Vogel für diese Tiefe am Markt sichtbar.

-

Bind die strategisch wichtigsten Mandanten deines Gebiets persönlich an und gewinne die, die genau diese Autorität suchen.

-

Löse die anspruchsvollen Cross-Sell-Themen aus, bei denen dein Gebiet der Türöffner ist (Gestaltungen, M&A-Tax, internationale Strukturen).

## Deine Perspektiven

**Was du nach 6 Monaten geliefert hast:**

-

Du bist firmenweit als fachliche Autorität deines Gebiets etabliert und trägst die schwersten Fälle der Gruppe.

-

Du hast erste firmenweite Methoden oder Standards in deinem Gebiet gesetzt.

-

Die strategisch wichtigsten Mandanten deines Gebiets sind persönlich bei dir angebunden.

**Was du nach 12 Monaten geliefert hast:**

-

Dein Gebiet ist als Vogel-Stärke nach außen sichtbar — Veröffentlichungen, Vorträge, Mandate, die explizit wegen deiner Autorität kommen.

-

Du hast Senior Experts und Experts firmenweit befähigt; die fachliche Linie deines Gebiets trägt deine Handschrift.

-

Deine fachliche Position ist intern wie extern als Vogel-Position erkennbar.

**Was du nach 24 Monaten geliefert hast:**

-

Dein Gebiet ist ein eigenständiger Reputations- und Ergebnis-Beitrag der Gruppe.

-

Die Methoden und Standards der Gruppe in deinem Gebiet sind im Kern deine.

-

Du bist auf dem Principal-/VP-(Fach-)Pfad entlang unseres Career Frameworks.

**Wohin sich die Stelle entwickelt:**

Über die Lead-Expert-Stufe öffnet sich der fachliche Principal-/VP-Pfad — die firmenweite fachliche Linie eines Themenbereichs, gleichwertig zur Owner-Verantwortung der Führungsspur. Lead Expert Tax ist eine Rolle mit echtem fachlichem Gewicht: Über die Cash-Vergütung hinaus ist vorgesehen, dass du unternehmerisch am Mehrwert partizipierst, den deine Autorität und dein Gebiet schaffen.

## Das bringst du mit

### Erfahrung & Track Record

-

Du hast das Steuerberater-Examen bestanden und in einem Spezialgebiet eine firmenweit relevante fachliche Autorität aufgebaut.

-

Du hast dein Gebiet nach außen getragen — Veröffentlichungen, Vorträge, Fachberater-Titel, zitierte Positionen.

-

Du prägst Methoden und Standards über den eigenen Schreibtisch hinaus und befähigst andere Berufsträger.

-

Profile, die nicht in dieses Raster passen, aber echte fachliche Autorität mitbringen, sind ausdrücklich eingeladen — wir bewerten am Beitrag, nicht am Etikett. Konkret: habilitierte/promovierte Steuerrechtler mit Praxis-Standing; ehemalige Big4-Partner-Anwärter, die fachliche Wirkung über Personalapparat stellen; renommierte Fachautoren mit Mandatswunsch. Die ausgewiesene Range kalibriert auf das Primärprofil — die Logik dahinter steht in unseren [Vergütungsgrundsätzen](https://www.vogel-beratung.com/culture/verg%C3%BCtungsgrunds%C3%A4tze).

### Skills & Arbeitsweise

-

Du hast herausragende Tiefe in einem anspruchsvollen Spezialgebiet — und bleibst operativ kompetent in der laufenden Mandantenarbeit.

-

Du machst komplexe Materie greifbar — für Mandanten, für Kolleginnen, für die Fachöffentlichkeit.

-

Du arbeitest mit AI als selbstverständlichem Hebel und prägst, wie deine Linie KI in der fachlichen Tiefe einsetzt.

### Mindset & Persönlichkeit

-

Du verstehst fachliche Wirkung als gleichwertig zur Führung — deine Autorität entsteht aus Tiefe und Befähigung, nicht aus Personalmacht.

-

Du teilst Wissen und prägst Standards, statt dein Gebiet zu hüten.

-

Du hast den Anspruch, in allem, was du ablieferst, den höchsten Standard zu setzen — nicht weil jemand es kontrolliert, sondern weil Mittelmaß dich persönlich stört.

-

Vogel ist hierarchisch in der Entscheidung, flach in der Kommunikation, autonom in der Ausführung. Leistung wird gefeiert, nicht versteckt.

## Was du bei uns nicht finden wirst

-

**Keinen Spezialisten-Track, der heimlich die zweite Liga ist.** Lead Expert ist gleichwertig zum Director — gleiche Vergütung, gleicher Einfluss, gleiche Sichtbarkeit. Fachlaufbahn ist hier kein Trostpreis.

-

**Keine disziplinarische Bereichsführung als Preis für fachliches Gewicht.** Du wirkst über Methoden, Tiefe und Befähigung — nicht über einen Personalapparat, den du nicht willst.

-

**Kein Spezialisten-Dasein in fremder Struktur.** Du prägst dein Gebiet als Vogel-Marke mit, du hängst nicht als Einzelkämpfer in einer Pyramide.

-

**Keine Partnergesellschaft mit konkurrierenden Eigeninteressen.** Wir sind ein Unternehmen mit One-Firm-Logik — eine Marke, eine Kultur, eine Hiring-Bar.

# FAQ

### 1. Was ist Vogel — und wo arbeitet ihr?

Vogel ist eine der führenden Mittelstandsberatungen Deutschlands — Familienunternehmen seit 1959, aus Aalen — und baut daraus die führende Beratungsplattform für den Mittelstand. Wir wachsen an mehreren Standorten: in Aalen/Ostwürttemberg als gewachsenem Stammsitz und in München als neuem Hub. An beiden suchen wir quer durch die Funktionen — von Steuerberatung über Beratung bis zu den strategischen Teams, die die Plattform bauen.

### 2. Wie sind die Gehaltsbänder zu verstehen?

Bewusst breit — und an jeder Stelle ausgewiesen. Wir differenzieren nach Track Record und Marktwert, nicht nach Abschluss: knappe, stark gefragte Profile am oberen Ende, weniger knappe am unteren. Wir kalibrieren ausschließlich am Markt — zwei Menschen mit ähnlicher Erfahrung können bei uns unterschiedlich verdienen.

### 3. Wie viel — und wie — wird bei Vogel gearbeitet?

Gemessen wird an dem, was du bewegst, nicht an Stunden. Ehrlich ist aber auch: Wer 9-to-5 sucht, ist bei uns nicht die erste Adresse. Wir suchen Menschen, die aus eigenem Antrieb intensiv arbeiten, weil die Aufgaben es wert sind. Wie du deine Zeit verteilst, ist weitgehend deine Sache. Was wir teilen: Wir arbeiten präsent zusammen — Kultur, Sparring und die besten Ideen entstehen in der täglichen Nähe. Wir sind keine Remote-Company und haben keine großen Home-Office-Policies; einzelne Remote-Tage sind kein Problem.

### 4. Wie läuft die Bewerbung?

Schlank, schnell, transparent — und nach Profil gestaffelt. Für Einstiegsrollen (Praktikum, Werkstudium, Berufseinstieg) genügen in der Regel zwei Gespräche und eine kurze Arbeitsprobe; erfahrene Rollen laufen etwas ausführlicher. Bei ausgewählten Senior-Rollen prüfen wir, künftig einen gemeinsamen Arbeitstag einzubauen, damit beide Seiten sich besser kennenlernen. Immer gilt: getaktete Termine, zügige Entscheidung, substanzielles Feedback — unabhängig vom Ausgang.

### 5. Wie funktioniert die variable Vergütung?

Quartalsweise an Leistung gekoppelt, qualitativ bewertet. Die Skala steigt mit dem Level: bis 20 % Associate, 27,5 % Manager, 35 % Senior Manager, 42,5 % Director, 50 % VP. Erwartungswert bei guter Leistung — du erfüllst die Anforderungen, setzt eigene Akzente, bestehst den Keeper Test — liegt bei rund 50 % des Maximums; der Maximalbonus ist nicht der Normalfall. Im Fokus steht eine ganzheitliche Beurteilung durch deine Führungskraft: Ownership, Qualität, Lernkurve, Zusammenarbeit, Impact.

### 6. Wie entwickle ich mich — welche Karrierewege gibt es?

Zwei aktive Wege: Mastery (fachliche Tiefe, Expertenlaufbahn) und Pioneer (Führung, Management). Die Richtung wählst du nach dem Onboarding, meist in Jahr 1–3. Berufseinstieg ist kein Sonderweg, sondern der frühe Teil derselben Strecke — vom Werkstudenten oder Praktikanten zum Associate, für die Besten ohne erneutes Bewerbungsverfahren.

### 7. Team, Kultur, Urlaub?

Ein gemeinsames Mittagessen ist ein offenes tägliches Angebot — keine Pflicht; wer mag, kommt dazu, essen kann jeder jederzeit. Dazu Abendessen, Social Events und Offsites in regelmäßigem Rhythmus — nicht als Pflichtprogramm, sondern weil ein gutes Team auch abseits der Arbeit Zeit teilt. Benefits: durchdacht und substanziell, nicht symbolisch. Urlaub: 28 Tage.

### 8. Ich kenne jemanden — gibt es einen Empfehlungsbonus?

Ja — 2.500 EUR für jede erfolgreich besetzte Stelle (keine Praktika). Kurzer Kontext reicht: an wen du denkst, für welche Rolle, warum. Muss nicht perfekt sitzen, aber substanziell sein.

Compensation: €220,875 – €277,875 • Fix: €155k – €195k · Bonus: €65,875k – €82,875k · EV: €190,65k – €239,85k

- • OTE €220,875 – €277,875 • Fix: €155k – €195k · Bonus: €65,875k – €82,875k · EV: €190,65k – €239,85k

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
