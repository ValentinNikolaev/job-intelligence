# Software Engineer – Mission Control Software

Posted: 2026-08-26T02:40:17Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Here at The Exploration Company, we are building innovative aerospace technologies that advance the future of space transportation.

Join us as a Software Engineer – Mission Control Software, where you will develop mission-critical software that powers our integrated testing and mission operations. You will primarily work on our Mission Control Software and build supporting tools used by flight controllers and engineering teams.

-

## Key Responsibilities

In your capacity as a Software Engineer - Ground Segment you will:

-

Develop robust software used in testing and mission operations

-

Contribute across the full software development lifecycle, from design to deployment

-

Build scalable systems that support TEC’s expanding mission activities

-

Collaborate with testing, engineering, and operations teams to understand and meet operational needs

-

Write performant, maintainable, and well-documented code

-

Ensure reliability through automated testing and operational validation

-

Support users and contribute to improving development workflows and tooling

-

Mentor junior engineers and contribute to a strong engineering culture

## What we would love to see from you

The ideal candidate will have:

-

Experience with backend development using Python and/or Ruby (on Rails)

-

Frontend experience with modern JavaScript frameworks (React, Vue.js, or similar)

-

Familiarity with object-oriented programming concepts and design principles

-

Experience with message brokers or event streaming systems (e.g., Redis Streams, Kafka)

-

Experience building systems for real-time data processing and ingestion

-

Familiarity with object storage solutions (e.g., MinIO, AWS S3) for handling large datasets

-

Experience with version control systems such as Git

-

Familiarity with automated testing frameworks

-

Ability to design, build, and maintain scalable distributed systems

-

Solid understanding of software design patterns and engineering best practices

-

Experience working in agile software development environments

-

Strong analytical thinking and problem-solving skills

-

Attention to detail with the ability to balance quality and delivery speed

-

Motivation to thrive in a fast-paced, mission-driven environment

## Bonus qualifications:

-

Experience with relational or time-series database technologies

-

Experience with cloud platforms such as AWS or Azure

-

Familiarity with containerization and CI/CD pipelines

-

Experience in the space industry or other safety-critical domains

**Why you should join us!**

What makes us special here at The Exploration Company and why we think you will enjoy working here is:

-

We’re Agile - we make decisions fast whilst keeping our goals and systems in mind

-

We’re Open and Collaborative - we are transparent about risks and obstacles, so that we can cooperate to overcome them

-

We have a lot of Fun - we refuel our energy knowing we are democratising space. It’s a wonderful and rare opportunity, are YOU up for the challenge?

We'd love to hear from you if you wish to be a part of our journey. Please submit your CV now for immediate consideration and we will be in touch shortly.

*The Exploration Company is an equal opportunity employer and values diversity. We do not discriminate based on race, religion, colour, national origin, gender, sexual orientation, age, marital status or disability status. Relocation assistance is provided for those willing to relocate including visa sponsorship where applicable. *

*
All offers are contingent upon the successful completion of a background check, which will be subject to the country, role, and project you applied for. By submitting your application, you acknowledge and agree that any offer of employment may be conditional upon successful condition of this check. The Exploration Company partners with Zinc Work Limited located in the UK (Zinc), a third-party provider, to ensure this process as efficient and transparent as possible.

If applicable, you will receive an email from Zinc upon acceptance of your offer with a link to a secure portal where you can provide the required information to Zinc. *

Compensation: €65K – €82.5K

- • €65K – €82.5K

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
