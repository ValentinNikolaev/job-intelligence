# Senior Manager Tax (m/w/d)

Posted: 2026-08-25T23:40:23Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

## Deine Rolle

Steuerberatung im Mittelstand ist Beziehungsarbeit — und sie skaliert nur über Menschen, die andere Berufsträger tragen. Mehrere Tausend mittelständische Unternehmen vertrauen uns; wir entwickeln das Modell jetzt in eine deutschlandweite Beratungsplattform weiter. Steuerberatung ist dabei kein Geschäftsfeld unter vielen, sondern der Kern.

Du bist Steuerberater mit mehreren Jahren Erfahrung nach dem Examen — bei einer Big Four, einer Next-6-Kanzlei oder einer gewachsenen Mittelstandspraxis. Du hast deinen eigenen Mandatsstamm über Jahre getragen, eine fachliche Spezialisierung aufgebaut und erste Manager oder Seniors fachlich geführt. Du wechselst, weil du einen Tax-Bereich mitbauen willst — mit eigener Linie, eigener Spezialisierung und echtem Gestaltungsraum — statt in einer Pyramide auf den nächsten Titel zu warten.

Du verantwortest einen Themen- oder Standort-Bereich innerhalb der Steuerberatung: mehrere Mandatsportfolios, die Manager darunter und den Bereichs-Output als Ganzes. Du führst junge Führungskräfte, nicht nur Sachbearbeiter. Du leitest aus der Bereichs- und Firmenstrategie konkrete Handlungslinien für deinen Bereich ab und treibst die strategischen Initiativen, die auf sein Wachstum einzahlen. Du berichtest an die Bereichsleitung Tax und arbeitest eng mit der Geschäftsführung an den strategischen Mandanten- und Wachstumsthemen.

## Deine Verantwortung

### Bereich & Mandatsportfolios

-

Verantworte den Output mehrerer Mandatsportfolios — Qualität, Termintreue, fachliche Tiefe über die ganze Linie, nicht nur im eigenen Mandat.

-

Trag selbst die komplexen und strategisch bedeutsamen Mandate deines Bereichs; sei Eskalations-Endpunkt für deine Manager bei allem, was über den Standardfall hinausgeht.

-

Baue deine fachliche Spezialisierung zur sichtbaren Bereichs-Tiefe aus — eine Branche (z. B. Healthcare, Family Office, Bauwirtschaft) oder ein Spezialgebiet (Nachfolge, internationale Strukturen, M&A-Tax) — und gewinne die Mandanten, die genau diese Tiefe suchen.

### Führung & Entwicklung

-

Führe drei bis fünf Direct Reports inklusive erster Führungskräfte — Führung von Führung. Du trägst die Entscheidungsverantwortung für Performance und, wo nötig, Trennung.

-

Entwickle dein Team aktiv weiter — Sparring, Review, Karrierepfade entlang unseres Career Frameworks.

-

Trag die Hiring-Verantwortung deiner Linie im mehrstufigen Vogel-Prozess — von der Ansprache über die Interview-Stationen bis zur Conviction-Entscheidung.

### Strategie & Wachstum

-

Leite aus der Firmen- und Bereichsstrategie die konkreten Prioritäten für deinen Bereich ab und setz sie um.

-

Treib die Cross-Sell-Logik über die Vogel-Bereiche hinweg (FP&A, M&A-Vorbereitung, Gestaltungen, Digitalisierung) und mach sie in deiner Linie zum Standard.

-

Bring eigene Akquise und Multiplier-Arbeit ein — du erweiterst den Bereich, du verwaltest ihn nicht.

## Deine Perspektiven

**Was du nach 6 Monaten geliefert hast:**

-

Du trägst den Output deines Bereichs eigenständig; die übergebenen Portfolios laufen in voller Tiefe über deine Linie.

-

Du hast deine Manager persönlich übernommen, die ersten Performance-Zyklen selbst geführt und mindestens ein Performance-Signal sauber adressiert.

-

Deine fachliche Spezialisierung ist intern sichtbar verankert.

**Was du nach 12 Monaten geliefert hast:**

-

Dein Bereich ist messbar gewachsen — über eigene Akquise, Cross-Sell und entwickelte Mandate, nicht nur über übergebenen Bestand.

-

Du hast aktiv in deiner Linie eingestellt und mindestens eine Führungskraft weiterentwickelt.

-

Deine Spezialisierung zieht erste Mandanten an, die genau diese Tiefe suchen.

**Was du nach 24 Monaten geliefert hast:**

-

Dein Bereich trägt eigenständig zusätzliche Subsegment-Tiefe und ein erkennbares Wachstumsprofil.

-

Du bist als Bereichs-Owner etabliert und Kandidat für die Director-Tax-Stufe — nicht über Berufsjahre, sondern über einen eigenständig aufgebauten, wachsenden Bereich.

**Wohin sich die Stelle entwickelt:**

Der nächste Schritt ist Director Tax — die Verantwortung für einen ganzen Praxis-Bereich mit eigenem P&L-Beitrag. Das setzt einen eigenständig entwickelten, wachsenden Bereich voraus, keinen Automatismus aus Berufsjahren. Über die Cash-Vergütung hinaus gibt es das Potenzial, unternehmerisch am geschaffenen Mehrwert zu partizipieren.

## Das bringst du mit

### Erfahrung & Track Record

-

Du hast das Steuerberater-Examen bestanden und danach mehrere Jahre Mandantenverantwortung getragen — Big Four, Next 6 oder eine gewachsene Mittelstandspraxis.

-

Du hast einen eigenen Mandatsstamm über Jahre geführt und eine fachliche Spezialisierung aufgebaut, die über das Standard-Spektrum hinausgeht.

-

Du hast bereits geführt — Manager oder Seniors fachlich angeleitet, Performance verantwortet, im Hiring mitgewirkt.

-

Profile, die nicht in dieses Raster passen, aber die Substanz mitbringen, sind ausdrücklich eingeladen — wir bewerten am Beitrag, nicht am Etikett. Konkret: herausragende Manager Tax mit eigenem Portfolio und klarem Führungsanspruch; Berufsträger aus Top-Kanzleien mit Branchenfokus und Wachstumshunger. Die ausgewiesene Range kalibriert auf das Primärprofil — die Logik dahinter steht in unseren [Vergütungsgrundsätzen](https://www.vogel-beratung.com/culture/verg%C3%BCtungsgrunds%C3%A4tze).

### Skills & Arbeitsweise

-

Du hast steuerliche Tiefe in einem klaren Spezialgebiet und bleibst zugleich hands-on über die Breite deines Bereichs.

-

Du führst Führungskräfte souverän — du kannst delegieren, ohne den Output aus der Hand zu geben, und entwickelst Menschen über das reine Fachliche hinaus.

-

Du arbeitest mit AI als selbstverständlichem Werkzeug — Recherche, Drafting, Analyse, Mandantenkommunikation — und machst deine Linie darin besser. Repetitive Arbeit ist dir ein Reiz zur Automatisierung, kein Schicksal.

### Mindset & Persönlichkeit

-

Du denkst unternehmerisch — du übernimmst Verantwortung für das Wachstum deines Bereichs, nicht für deine Stunden.

-

Du verstehst Mandantenarbeit als Beziehungsarbeit und gibst diese Haltung an deine Linie weiter.

-

Du hast den Anspruch, in allem, was du ablieferst, den höchsten Standard zu setzen — nicht weil jemand es kontrolliert, sondern weil Mittelmaß dich persönlich stört.

-

Vogel ist hierarchisch in der Entscheidung, flach in der Kommunikation, autonom in der Ausführung. Leistung wird gefeiert, nicht versteckt.

## Was du bei uns nicht finden wirst

-

**Keine Partnertitel-Warteschleife.** Du wirst Bereichs-Owner, weil du einen Bereich trägst und entwickelst, nicht weil du Jahre absitzt.

-

**Kein Führen ohne fachlichen Boden.** Du bleibst nah an den komplexen Mandaten — Führung ohne eigene Substanz funktioniert bei uns nicht.

-

**Kein Erbhof-Modell ohne Wachstumsanspruch.** Wer einen Bereich nur verwalten will, sitzt hier am falschen Schreibtisch.

-

**Keine Partnergesellschaft mit konkurrierenden Eigeninteressen.** Wir sind ein Unternehmen mit One-Firm-Logik — eine Marke, eine Kultur, eine Hiring-Bar.

# FAQ

### 1. Was ist Vogel — und wo arbeitet ihr?

Vogel ist eine der führenden Mittelstandsberatungen Deutschlands — Familienunternehmen seit 1959, aus Aalen — und baut daraus die führende Beratungsplattform für den Mittelstand. Wir wachsen an mehreren Standorten: in Aalen/Ostwürttemberg als gewachsenem Stammsitz und in München als neuem Hub. An beiden suchen wir quer durch die Funktionen — von Steuerberatung über Beratung bis zu den strategischen Teams, die die Plattform bauen.

### 2. Wie sind die Gehaltsbänder zu verstehen?

Bewusst breit — und an jeder Stelle ausgewiesen. Wir differenzieren nach Track Record und Marktwert, nicht nach Abschluss: knappe, stark gefragte Profile am oberen Ende, weniger knappe am unteren. Wir kalibrieren ausschließlich am Markt — zwei Menschen mit ähnlicher Erfahrung können bei uns unterschiedlich verdienen.

### 3. Wie viel — und wie — wird bei Vogel gearbeitet?

Gemessen wird an dem, was du bewegst, nicht an Stunden. Ehrlich ist aber auch: Wer 9-to-5 sucht, ist bei uns nicht die erste Adresse. Wir suchen Menschen, die aus eigenem Antrieb intensiv arbeiten, weil die Aufgaben es wert sind. Wie du deine Zeit verteilst, ist weitgehend deine Sache. Was wir teilen: Wir arbeiten präsent zusammen — Kultur, Sparring und die besten Ideen entstehen in der täglichen Nähe. Wir sind keine Remote-Company und haben keine großen Home-Office-Policies; einzelne Remote-Tage sind kein Problem.

### 4. Wie läuft die Bewerbung?

Schlank, schnell, transparent — und nach Profil gestaffelt. Für Einstiegsrollen (Praktikum, Werkstudium, Berufseinstieg) genügen in der Regel zwei Gespräche und eine kurze Arbeitsprobe; erfahrene Rollen laufen etwas ausführlicher. Bei ausgewählten Senior-Rollen prüfen wir, künftig einen gemeinsamen Arbeitstag einzubauen, damit beide Seiten sich besser kennenlernen. Immer gilt: getaktete Termine, zügige Entscheidung, substanzielles Feedback — unabhängig vom Ausgang.

### 5. Wie funktioniert die variable Vergütung?

Quartalsweise an Leistung gekoppelt, qualitativ bewertet. Die Skala steigt mit dem Level: bis 20 % Associate, 27,5 % Manager, 35 % Senior Manager, 42,5 % Director, 50 % VP. Erwartungswert bei guter Leistung — du erfüllst die Anforderungen, setzt eigene Akzente, bestehst den Keeper Test — liegt bei rund 50 % des Maximums; der Maximalbonus ist nicht der Normalfall. Im Fokus steht eine ganzheitliche Beurteilung durch deine Führungskraft: Ownership, Qualität, Lernkurve, Zusammenarbeit, Impact.

### 6. Wie entwickle ich mich — welche Karrierewege gibt es?

Zwei aktive Wege: Mastery (fachliche Tiefe, Expertenlaufbahn) und Pioneer (Führung, Management). Die Richtung wählst du nach dem Onboarding, meist in Jahr 1–3. Berufseinstieg ist kein Sonderweg, sondern der frühe Teil derselben Strecke — vom Werkstudenten oder Praktikanten zum Associate, für die Besten ohne erneutes Bewerbungsverfahren.

### 7. Team, Kultur, Urlaub?

Ein gemeinsames Mittagessen ist ein offenes tägliches Angebot — keine Pflicht; wer mag, kommt dazu, essen kann jeder jederzeit. Dazu Abendessen, Social Events und Offsites in regelmäßigem Rhythmus — nicht als Pflichtprogramm, sondern weil ein gutes Team auch abseits der Arbeit Zeit teilt. Benefits: durchdacht und substanziell, nicht symbolisch. Urlaub: 28 Tage.

### 8. Ich kenne jemanden — gibt es einen Empfehlungsbonus?

Ja — 2.500 EUR für jede erfolgreich besetzte Stelle (keine Praktika). Kurzer Kontext reicht: an wen du denkst, für welche Rolle, warum. Muss nicht perfekt sitzen, aber substanziell sein.

Compensation: €162K – €202.5K • Fix: €120k – €150k · Bonus: €42k – €52,5k · EV: €144k – €180k

- • OTE €162K – €202.5K • Fix: €120k – €150k · Bonus: €42k – €52,5k · EV: €144k – €180k

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
