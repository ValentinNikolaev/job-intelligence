# Software Engineer, Backend - Data Layer

Posted: 2026-08-26T02:40:18Z

## Rejection

- Category: tech_stack
- Reason: role does not mention Go/Golang or PHP

[**Register Here!**](https://camunda.com/wb-life-at-camunda/)

Camunda is **the enterprise platform for agentic orchestration**, enabling organizations to coordinate **AI agents, people, and systems **across complex, end-to-end business processes. With built-in governance, auditability, and human oversight, Camunda gives enterprises the control they need to move AI from pilots to production — safely and at scale. **Trusted by over 700 organizations worldwide**, including 9 of top 10 US banks, Camunda helps enterprises boost operational efficiency, accelerate time-to-value, and deliver better customer experiences.

**Fully remote and global,** we are in the middle of something bigger: **transforming into an AI-first organisation, built on our own platform**. We use Agentic AI to automate, orchestrate intelligent processes, and elevate human contribution across every team.

Named [GP Bullhound’s Top 100 Next Unicorn list,](https://www.gpbullhound.com/articles/top-100-next-unicorns-the-uk-france-and-germany-lead-with-the-most-promising-technology-companies-in-europe/) **2025 Great Place to Work certified.** ***Visionary***** **in [**2025 Gartner® Magic Quadrant™**](https://page.camunda.com/wp-2025-gartner-magic-quadrant-for-boat)** **for Business Orchestration and Automation Technologies. ranked **3rd in Flexa's 2026 **[**Most Flexible Companies**](https://flexa.careers/companies/camunda), We’re growing fast and looking for top talent to join our team. **If you want meaningful work, visible impact and put something genuinely rare on your CV, keep reading.**

**About the role:**

** **As a Backend Software Engineer on the Data Layer team, you'll help build and evolve the storage and query layer that keeps Camunda 8's process data fast, accurate, and available at scale. Spanning both relational databases and Elasticsearch/OpenSearch, the data layer and its data pipelines power everything from process monitoring to the new agent-driven automation capabilities we're rolling out.

As part of the Data Layer team, you will work on both technically challenging and rewarding projects, such as reshaping how we store and retain process data, streaming data to external systems, and evolving our secondary storage systems to perform at ever greater scale.

At Camunda, we approach engineering in a holistic manner. As such, you will form strong partnerships with product management, design, QA, and support, and work with your peers to not only deliver but directly influence how our data layer evolves to meet our customers' needs.

*Curious about the kind of challenges you'll work on at Camunda? Watch this quick *[*30-minute talk*](https://www.camundacon.com/event-session/camundacon-amsterdam-2025/one-exporter-to-rule-them-all-exploring-camunda-exporter/?on_demand=true)* from our engineers to learn more about the new Camunda Exporter and how we’re solving complex problems at scale*

**What You’ll Be Doing:**

-

Design, build, and maintain backend services for the data layer that stores and serves Camunda 8's process data, spanning relational databases and Elasticsearch/OpenSearch, with an eye toward correctness, performance, and scale.

-

Own the end-to-end delivery of engineering initiatives, working with Product Management and senior colleagues to break down requirements into concrete solution designs, driving projects to timely and high-quality delivery.

-

Help evolve how we process, retain, and expose process data, so customers can work with their data the way they need to.

-

Invest in making our secondary storage systems more performant and scalable as usage grows, and build tooling that makes it easier to understand, troubleshoot, and safely operate the data layer in production.

-

Participate in L3 support and on-call rotations, partnering with Support and SRE to investigate data layer production issues, and feeding what you learn back into the product.

**What You Bring:**

-

Ability and/or willingness to use [our product](https://accounts.cloud.camunda.io/signup?_ga=2.47330343.127558761.1654184528-504024057.1654184528)

-

At least 4 years of experience as a backend engineer, with a strong focus on backend systems and production data stores

-

Hands-on experience with at least one of PostgreSQL, MySQL, MariaDB, MSSQL, or Elasticsearch/OpenSearch, with a practical understanding of query performance, indexing, and data modeling trade-offs

-

Experience contributing to complex engineering initiatives: breaking down requirements into concrete tasks, writing clear technical designs for your piece of the work, and delivering reliably

-

Comfortable investigating slow queries, execution plans, and index usage to root-cause data-related production issues.

-

Strong communication and collaboration skills in a remote-first environment: you translate requirements into actionable technical work with Product, and give and receive clear, direct feedback in code review.

**Nice-to-haves:**

-

Experience building workflow automation or process orchestration software.

-

Experience working with both relational databases and Elasticsearch/OpenSearch.

-

Experience building or maintaining CI pipelines.

-

Understanding of database migration tooling (e.g. Liquibase, Flyway) and schema evolution in a live system.

***This role is an existing vacancy***

#LI-SK1 #LI-Remote #USEAST

**What We Have to Offer:**

**Compensation**

We offer competitive, fair, and transparent compensation. Salary ranges are location-based, with Standard and Major markets (global tech hubs) reflecting local competition.

**The Annual Total Target Cash **(base salary + 100% variable target, where applicable) shown below spans from the minimum in a Standard market to the maximum in a Major market. Final offers depend on **skills**, **experience**, and **location**, and we typically hire in the first half of the range to allow room for growth:

-

United States: $119,900.00 to $193,200.00

-

United Kingdom: £75,300.00 to £123,800.00

-

Singapore: S$148,900.00 to S$223,300.00

-

Canada: C$127,300.00 to C$209,300.00

If you’re based elsewhere, you’ll be hired via [**Remote.com**](http://Remote.com) (our global employer partner), and your Talent Acquisition Partner will provide a personalized **Total Rewards Calculator** after your first interview.

**Equity: **We also offer equity (where applicable) through our [**Virtual Stock Option Plan (VSOP)**](https://docs.google.com/document/d/1hoyQAPTZ5nV7J47D9n3yqK5hhLj160Xf36iyqEXNOWE/edit?tab=t.0#heading=h.2qon7r4kdfe1).

**Benefits & Perks**

We invest in your wellbeing, growth, and ability to connect, along with perks that support you no matter where you’re based. Our benefits are globally designed and locally delivered where applicable.

-

**Remote & Flexible: **Work from anywhere with the setup that suits you, **home office budget, co-working space support, and flexible time off** to recharge when you need it.

-

**In Person Connection: **We invest in meaningful face time through our **Annual Kickoff **(Vienna in 2025, Madrid in 2026!), **team offsites, and Camundi Connection Budgets**, including contributing to meetups while travelling,, and local gatherings with fellow Camundi.

-

**Health & Wellbeing:** Access locally tailored healthcare, **Modern Health** for global mental wellbeing, and our **Live Well Lifestyle Spending Account (LSA),** a flexible, global benefit that puts you in control of your whole life, not just work, from: **staying active, to caring for family, exploring personal passions, meaningful experiences, and investing in your financial wellbeing.** The Live Well program launches in 2026 and scales to **€1,000 annually from 2027**.

-

**Financial Security:** Retirement and pension plans (often with company contributions), plus life and disability insurance where relevant.

-

**Professional Growth:** Up to $/€/£1,000 per year for self-driven learning: courses, certifications, books, you decide!

**AI in our hiring process**:*** **Camunda may use AI tools to aid the screening of applications and during the interview process. You can *[***learn more here***](https://camunda.com/ai-in-our-interviewing-process/)

*”Everyone is welcome at Camunda” *— *it’s a celebrated component of our culture. We strive to create an inclusive environment that empowers our people. At Camunda, we honour diverse cultures and backgrounds and are proud to be an equal opportunity employer. All qualified applicants will receive consideration without regard to gender, race, ethnicity, religion, belief, sexual orientation, age, disability or any other protected characteristics under applicable law. We are looking forward to your application!*

***Come join us and be part of Camunda’s incredible journey: Make an impact at a pivotal moment in our story!***

***Please be aware that scammers may impersonate Camunda by reaching out about job opportunities. Camunda will only contact candidates from an email address ending in @***[***camunda.com***](http://camunda.com)***. We will never ask candidates for bank account details, checks, payment, or other sensitive financial information as part of our hiring process. If you receive a suspicious message, please do not respond, click any links, or share personal information.***

***Note for recruiting and placement agencies: Camunda does not accept unsolicited agency resumes. Please do not forward resumes to our careers site, employees, or any other Camunda contact unless we have specifically engaged your firm for that search. Camunda will not pay fees related to unsolicited resumes.***

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
