# (Senior) Projektmanager Print (w/m/d)

Posted: 2026-08-25T23:29:49Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**Wer wir sind. **

Eine der führenden Kommunikationsagenturen im deutschen Raum mit mehr als 300 Mitarbeiter*innen. Wir bieten the full monty: Konzeption, Kreation, Redaktion, Organisation, Kampagnen, Social-Media und technologische Plattformen. Wir begleiten Kund*innen aus Wirtschaft, Politik, Gesellschaft und Medien. Und wir entwickeln alles, was diese für eine wirksame Kommunikation brauchen: Social Media-Kampagnen, Magazine, Fernsehspots und Websites. Von der strategischen Kernidee bis zur technischen Umsetzung. Am liebsten für die komplexen Themen unserer Zeit.​​​​

**Was zu tun ist.**

- Übergreifende, selbstständige Projektplanung
- Steuerung des Teams
- Kundenberatung
- Enge Zusammenarbeit mit Redaktion und Kreation
- Steuerung des redaktionellen Printbereichs
- Überwachung und Koordination von internen und externen Arbeitsabläufen
- Ressourcenplanung
- Erstellung von Briefings, Timings und Kosten

**Was du mitbringst.**

- 5 bis 7 Jahre Berufserfahrung im Print-Projektmanagement
- Strukturierte Arbeitsweise
- Macher-Mentalität
- Starken Teamgeist
- Hohe Affinität zur Print- und Magazinproduktion
- Idealerweise Erfahrung im Gesundheitssektor

**Wen wir suchen.**

Eine*n (Senior) Projektmanager (w/m/d) Print. In Berlin. Ab sofort.

**Was wir bieten.**

Du wirst Teil eines festen Teams in einer starken Agentur. In einem Umfeld aus Lehren und Lernen. Wir übergeben Verantwortung. Und zwar in echt. Wenn alle anpacken, wird's besser. Und macht auch gleich mehr Spaß.

**Was, wenn's passt?**

Dann sollten wir uns kennenlernen.

Wir freuen uns über jede Bewerbung von qualifizierten Menschen. Jeder geschlechtlichen und sexuellen Identität. Jeglicher Religionszugehörigkeit. Jeden Alters. Von Bewerbenden mit Migrationshintergrund, People of Colour und/oder Menschen mit Behinderungen. Wiedereinsteiger*innen. Eltern. Quereinsteiger*innen. Alle sind bei uns gleichermaßen willkommen.

Schick uns gerne deine Bewerbungsunterlagen und lass uns wissen wer du bist. Wenn du möchtest, kannst du deine Unterlagen auch anonymisiert als Blind-Bewerbung einreichen – wir stellen einen fairen und transparenten Auswahlprozess sicher. Wir freuen uns auf dich.

Und noch ein Hinweis: Wir nehmen Informationssicherheit ernst – und freuen uns, wenn du diesen Anspruch mit uns teilst.

**Deine Ansprechpartnerin.**

Anette Lezak.

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
