# Senior CRO Specialist

Posted: 2026-08-26T02:30:35Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**About Entyre**

Caregiving is broken. We’re fixing it with technology. Entyre is the holding behind Pflegewegweiser (Switzerland), Entyre Care (United States), and the Pflegewegweiser Shop. We operate as one system across our offices in Berlin, Boston, and Zurich: 450+ people developing the technology, products, and growth strategies that power all three brands. Our platform connects family caregivers with compensation programs through selfonboarding funnels, automated eligibility engines, and digital care management. In the US, families discover Entyre Care through paid and organic channels, land on our landing pages, and move through a multi-step journey in the Hub, our self-service platform, until they are fully enrolled. Hub processes differ by state, and every screen along the journey is a potential drop-off point. Your job is to find those points and fix them.

**The Role**

You will join the Marketing team in our Berlin office and own testing and optimization across the entire funnel, from the first landing page impression to a won customer. Your initial focus is the US market and the Entyre Care funnels, with the technology and learnings you build serving the whole group. This is a senior, high-ownership role with direct impact on how many families we can help and how fast. The Hub is our proprietary self-onboarding app that guides a family caregiver from the first eligibility check through document collection and third-party sign-offs to a completed Medicaid enrollment. Requirements differ by state, so the Hub runs a different flow in every market and there is no single funnel to optimize. You will work across multiple state-specific flows, prioritize the biggest leaks, and choose the right method for each situation. Where traffic supports it, you run clean A/B tests. Where it does not, you design pre/post comparisons, holdouts, or staged rollouts, and you know the statistical limits of each approach

**What You Will Do**

-

Own the full experimentation roadmap from landing page to won customer: identify drop-off points across landing pages and in-Hub flows, size the opportunity, prioritize, test, ship, document learnings.

-

Decide the right methodology per case (A/B test, pre/post, holdout, staged rollout), define success metrics, calculate required sample sizes and runtimes, and call tests honestly, including the losers.

-

Build and ship landing page variants yourself. For in-Hub changes, work side by side with our engineering team in Berlin on a daily basis: write precise specs, sit in their standups and planning, review and QA implementations, and keep a steady flow of experiments in their sprint.

-

Own Mixpanel as our funnel analytics backbone: event tracking quality, funnels, dashboards, cohort analysis. Evaluate, implement, and maintain additional tools where they add value (session recordings, heatmaps, experimentation platforms, survey tools).

-

Use AI as a daily working tool: AI-assisted funnel analysis, variant and copy generation, rapid prototyping with AI coding tools, and automation of recurring analyses and reporting.

-

Apply a continuous improvement mindset: propose adjustments based on user behavior, feedback, and analytics, and maintain a prioritized backlog that the whole team can see.

-

Communicate results clearly to channel and state owners: what we tested, what we learned, what we do next.

**What You Bring**

-

5+ years in CRO, growth, or experimentation roles with proven, measurable conversion wins on real products or funnels. Strong statistical grounding: significance, power, sample size, novelty effects, and the judgment to know when an A/B test is the wrong instrument.

-

Deep hands-on experience with Mixpanel or a comparable product analytics platform, including event taxonomy design and tracking QA.

-

Working knowledge of HTML and CSS, plus basic JavaScript to build or tweak prototypes and landing page variants independently. Experience with design systems built on modern front-end frameworks (e.g., Tailwind, Bootstrap, Material Design) and comfort with Git for reviewing UI code changes.

-

Proven track record of working inside an engineering team day to day: writing specs engineers can build from, joining standups and sprint planning, and QAing what ships.

-

Demonstrated AI fluency: you use LLMs and AI coding tools daily for analysis, prototyping, and automation, and you can show concrete examples of how AI made your work faster or better.

-

Prototyping skills: you can turn a hypothesis into a clickable or coded prototype fast.

-

A clear understanding of UX principles, responsive design, and accessibility, with a mobile-first mindset. Familiarity with fast-paced environments, ideally startups, agencies, or product teams.

-

Fluent English. German is a plus.

**Big Plus**

-

Full UI design capability: you can design conversion-optimized layouts and components yourself, with a portfolio showing modern web and mobile interface work.

-

Experience in healthcare, finance, or another regulated or complex sector.

-

Experience implementing or administering experimentation platforms and CDP or tag management setups.

**Our Stack**

**Analytics and experimentation:** Mixpanel (core), BigQuery-based reporting, AI tooling across the workflow.

**Product:** the Hub, our proprietary self-onboarding app, built on Node.js, TypeScript, Vue.js, Postgres, and Redis. Git for version control. You will have a real say in which tools we add next.

**How We Operate (Non-Negotiable)**

“Insanely great” for families — delivered now Forget mere “satisfaction.” We deliver support that makes caregivers feel seen, understood, and valued. Anticipate their needs and solve problems quickly. The standard is “insanely great,” period. Anything less slows us down and fails our families.

Speed is king — ruthless focus is key Velocity comes from focus. Eliminate distractions. Concentrate all effort on the #1 critical objective until it’s done, then move to the next. Decide what not to do and cut it ruthlessly. Being a mile wide and an inch deep is failure — move the needle now.

Raise the bar — crush mediocrity Mediocrity kills speed, morale, and companies. Hunt it down and eliminate it. Good enough is never good enough. Demand top performance from yourself and everyone around you. Own your work, deliver excellence fast, and accept no excuses.

The speed algorithm — question, delete, simplify, accelerate Build momentum by questioning every requirement: who asked, and why? Delete ruthlessly — parts, processes, bureaucracy. Simplify what remains. Accelerate cycle times relentlessly. “It can’t be done” means “you haven’t figured it out yet — go do it.” Break bottlenecks, find shortcuts, remove friction.

Act like owners — bold bets, fast action This is your company. Own the mission and the results. Take initiative, make bold bets that leapfrog progress, and act decisively. If you stumble, learn faster and go again. Bias for action is everything.

The bottom line: We are building something vital at lightning speed. This requires intensity, focus, and a relentless drive to execute. If reading this makes you want to jump in and build faster, welcome to Entyre!

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
