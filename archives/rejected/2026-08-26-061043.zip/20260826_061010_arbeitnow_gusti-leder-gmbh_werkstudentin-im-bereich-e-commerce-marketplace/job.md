# Werkstudentin im Bereich E-Commerce / Marketplace (m/w/d)

Posted: 2026-08-26T02:30:08Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**Gestalte mit uns die Zukunft des digitalen Handels! 💻🌍✨**

Tauche ein in die Welt von Gusti Leder, wo jede Tasche eine Geschichte erzählt und jedes Produkt mehr als nur ein Accessoire ist – es ist ein Statement für Nachhaltigkeit und Stil. Bei[ Gusti Leder GmbH,](https://www.gusti-leder.de/uebersichtsseite-philosophie-de-ch-at) einem Unternehmen, das für sein Engagement für Transparenz, Qualität und die Förderung von Slow Fashion bekannt ist, bieten wir Dir mehr als nur einen Job. Wir bieten Dir eine Chance, Teil einer Bewegung zu sein, die darauf abzielt, die Lederindustrie zum Besseren zu verändern.

Um unser Online-Geschäft national und international weiter auszubauen, suchen wir dich als **Werkstudent:in (m/w/d)** im Bereich **E-Commerce** **vor Ort in unserem Büro in Rostock**.
In dieser Rolle unterstützt du unser Team im Marktplatz- und Account-Management und trägst dazu bei, dass Gusti Leder online sichtbar, erfolgreich und authentisch bleibt.

**Klingt nach deiner Mission? 🚀 Dann freuen wir uns auf deine Bewerbung! 💚**

###

#### **Was Dich bei Gusti Leder erwartet:**

-

🛒 **Marktplatzmanagement **- Du trägst dazu bei, Artikel für den Online-Auftritt vorzubereiten, indem du Inhalte für unsere Verkaufskanäle erstellst und Bilder sowie Texte austauschst.

-

🚀 **Bringe unsere Online-Shops auf das nächste Level **-** **Unterstütze uns bei der Entwicklung und Vermarktung unseres Produktportfolios über unsere E-Commerce-Plattformen. Auch Preisanpassungen auf den Verkaufskanälen gehören dazu.

-

📈 **Performance & Insights **- Erfasse und erstelle Berichte zu unseren Umsatzzahlen der Verkaufskanäle, um das Wachstum unseres Unternehmens voranzutreiben.

-

📦 **Bestandsmanagement** - Kontrolliere regelmäßig die Lagerbestände für unsere Marktplätze.

-

✨ **Weiterentwicklung **- Eigene Ideen einbringen, Tests fahren, Potenziale heben.

#### **
Was Du mitbringen solltest:**

-

Interesse an der Entdeckung der Bereiche Marketplace und E-Commerce und idealerweise erste Erfahrungen.

-

Du bist organisiert & strukturiert.

-

Du bist IT-affin, selbstständig und lösungsorientiert.

-

Shopify-Kenntnisse sind von Vorteil

-

Du bist ein:e Teamplayer:in, kommunizierst klar und bist zuverlässig im Austausch.

-

Sehr gute Deutsch- und Englischkenntnisse in Wort und Schrift.

#### **Warum Gusti Leder?**

🌱 **Nachhaltigkeit first** - Wir leben Slow Fashion und gestalten die Lederindustrie verantwortungsvoll.

💰 **Fairer Lohn** – 17,00 bis 19,00 € pro Stunde inkl. Überstundenvergütung.
💡 **Gestaltungsfreiheit** - Deine Ideen zählen und prägen, wie unsere Marke wahrgenommen wird.
💪 **Gemeinsam wachsen** - wir fordern & fördern dich, mit Weiterbildung, Feedback und echter Verantwortung.
🎉 **Teamkultur** - flache Hierarchien, offene Kommunikation, regelmäßige Teamevents.
🧘 **Work-Life-Balance** - flexible Arbeitszeiten und Yoga-Sessions.

🚆 **Gute Anbindung **-** **Unser Standort befindet sich in unmittelbarer Nähe zum Rostocker Hauptbahnhof und ist somit bequem mit der S-Bahn oder Straßenbahn erreichbar.

🚗 **Bequem parken **– Stellplätze direkt vor dem Büro.
🍽️ **Energie für den Tag** - zweimal pro Woche frisches Mittagessen.

🍏 **Frisches Plus** - täglich frisches Obst, Kaffee, Tee und Wasser for free.
🎁 **Exklusive Rabatte** - für unsere Produkte & viele weitere Corporate Benefits.

#### Über uns

Unsere Produkte sind ein Symbol für bewussten Konsum und nachhaltige Eleganz. Wir sind stolz darauf, unseren Kunden nicht nur hochwertige Naturprodukte zu bieten, sondern auch den Charme und die Eleganz von Vintage-Lederwaren nahezubringen. Vom unverkennbaren Geruch echten Leders bis hin zu unserer vielfältigen Produktpalette, die von Taschen über Rucksäcke bis hin zu Accessoires und Schreibwaren reicht, hat Gusti Leder für jeden etwas zu bieten. Unser Ziel ist es, stilvolle, aber auch funktionale Produkte zu schaffen, die dich auf all deinen Abenteuern begleiten.

Werde Teil unserer Mission. Werde Teil von **#TeamGusti**. 💚

Bewirb dich jetzt in nur 5 Minuten über unser Online-Formular.

**Deine Ansprechpartnerin ist Lea**:

Weitere Informationen zur Datenverarbeitung im Bewerbungsverfahren findest Du hier:[ https://gusti-leder.de/policies/privacy-policy](https://gusti-leder.de/policies/privacy-policy)

Im Rahmen des Bewerbungsprozesses übernehmen wir keine dafür anfallenden Reisekosten.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
