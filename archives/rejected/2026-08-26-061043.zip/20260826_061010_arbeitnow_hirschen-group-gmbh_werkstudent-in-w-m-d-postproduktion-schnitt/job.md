# Werkstudent*in (w/m/d) Postproduktion / Schnitt

Posted: 2026-08-25T23:29:49Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**Wer wir sind. **

Eine der führenden Kommunikationsagenturen im deutschen Raum mit mehr als 300 Mitarbeiter*innen. Wir bieten the full monty: Konzeption, Kreation, Redaktion, Organisation, Kampagnen, Social-Media und technologische Plattformen. Wir begleiten Kund*innen aus Wirtschaft, Politik, Gesellschaft und Medien. Und wir entwickeln alles, was diese für eine wirksame Kommunikation brauchen: Social Media-Kampagnen, Magazine, Fernsehspots und Websites. Von der strategischen Kernidee bis zur technischen Umsetzung. Am liebsten für die komplexen Themen unserer Zeit.

**Was zu tun ist.**

Als Werkstudent*in unterstützt du unser Videoteam bei allen Aufgaben rund um Postproduktion, Schnitt und Videografie. Deine Tätigkeiten reichen vom Schnitt und der Farbkorrektur über die Tonbearbeitung bis hin zur finalen Aufbereitung von Videoinhalten für Social Media, Kampagnen oder interne Projekte. Auch bei Dreharbeiten, der Organisation von Rohmaterial und der Mitwirkung an Storyboards bringst du dich aktiv ein. Ob kurze Clips für TikTok & Instagram, Imagevideos oder animierte Erklärfilme: Abwechslung ist garantiert.
Ganz schön viel? Stimmt – aber wir nehmen uns Zeit für die Einarbeitung und du hast ein erfahrenes Team an deiner Seite. Wichtig nur: Dein Schwerpunkt ist Postproduktion und Schnitt – und dafür solltest du brennen.

**Was du mitbringst.**

Du studierst etwas im Bereich Bewegtbild oder verwandten Feldern und willst praktische Erfahrung sammeln.
Du willst mitreißende Geschichten mit packenden Bildern und Schnitt erzählen. Du kennst dich mit Premiere aus, bist in After Effects nicht ganz verloren und hast noch weitere Software-Skills, von denen du uns erzählen kannst? Wenn du ein bisschen Kamera kannst, auch cool. Du arbeitest selbstständig und bringst eigene Ideen ein. Du hast ein Auge fürs Detail und schaust bei finalen Abnahmen ganz genau hin. Außerdem interessieren dich politische und gesellschaftliche Inhalte und hast Lust komplexe Themen verständlich, relevant und interessant zu machen? Noch besser!

**Wen wir suchen.**

Eine*n Werkstudent*in (w/m/d) im Bereich Postproduktion / Schnitt für unser Videoteam. Ab sofort in Berlin Kreuzberg für ca. 20h/ Woche. Am liebsten eine Person, die noch länger als ein Jahr eingeschrieben ist.

**Was wir bieten.**

Wir machen gute Inhalte. Also wir können politisch und moralisch hinter dem stehen was wir produzieren. Die Kolleg*innen sind nett. Also wirklich nett. Inklusion und gewaltfreie Kommunikation ist hier wichtig für alle. Das Videoteam ist klein, aber laut, und bietet unterschiedliche Aufgaben in Format, Inhalt und Stilen. Wir begleiten die Kundenarbeit in der Konzeption und Umsetzung von Bewegtbildformaten. Von Imagefilmen, Erklärfilmen, Social Media bis zu Kampagnen, alles dabei. Bei uns sammelst du nicht nur Arbeitserfahrung im professionellen Umfeld, sondern findest auch einen sicheren Rahmen um dich auszuprobieren und weiterzuentwickeln. Dabei gehört nicht nur die Weiterbildung in Software, sondern auch die Nutzung von KI-Tools zum Programm.

**Was, wenn's passt?**

Dann sollten wir uns kennenlernen.

Wir freuen uns über jede Bewerbung von qualifizierten Menschen. Jeder geschlechtlichen und sexuellen Identität. Jeglicher Religionszugehörigkeit. Jeden Alters. Von Bewerbenden mit Migrationshintergrund, People of Colour und/oder Menschen mit Behinderungen. Wiedereinsteiger*innen. Eltern. Quereinsteiger*innen. Alle sind bei uns gleichermaßen willkommen.

Schick uns gerne deine Bewerbungsunterlagen und lass uns wissen wer du bist. Wenn du möchtest, kannst du deine Unterlagen auch anonymisiert als Blind-Bewerbung einreichen – wir stellen einen fairen und transparenten Auswahlprozess sicher. Wir freuen uns auf dich.

Und noch ein Hinweis: Wir nehmen Informationssicherheit ernst – und freuen uns, wenn du diesen Anspruch mit uns teilst.

**Deine Ansprechpartnerin.**

Anette Lezak.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
