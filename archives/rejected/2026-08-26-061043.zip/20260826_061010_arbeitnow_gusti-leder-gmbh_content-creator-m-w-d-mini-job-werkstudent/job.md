# Content Creator (m/w/d) - Mini Job / Werkstudent

Posted: 2026-08-26T02:30:08Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

#### Gestalte mit uns die Zukunft der Lederindustrie! 🌍✨

Bei **Gusti Leder** verbinden wir Nachhaltigkeit, Transparenz und Slow Fashion mit Leidenschaft für Design und Qualität.
Wir sind überzeugt: Leder kann fair, langlebig und verantwortungsvoll sein – und wir zeigen jeden Tag, wie das geht.

Als **Content Creator (m/w/d)** im Mini Job oder als Werkstudent:in tauchst du in die Welt von Social Media, Community und Content ein – und machst unsere Marke erlebbar. Dein Ziel: **Kreativität zeigen, Community begeistern und mitgestalten. 🚀**

#### Deine Mission

📸 **Visuelles Storytelling** – Du erstellst, bearbeitest und gestaltest Fotos & Videos für unsere Social-Media-Kanäle.
🎥 **Botschafter und Authentizität** – Du trittst vor der Kamera auf, gibst Einblicke und stärkst durch Authentizität unsere Community-Bindung.
💬 **Community Management** – Du interagierst mit Follower:innen, beantwortest Fragen und hältst die Community lebendig.
💡 **Content-Ideen entwickeln** – Du bringst kreative Konzepte ein und setzt innovative Formate für unsere Kanäle um.

#### Was du mitbringst

✨ Eine kreative Arbeitsweise, Verantwortungsbewusstsein & Mut für neue Ideen.
👀 Ein Auge für Ästhetik & Details.
📷 Leidenschaft fürs Fotografieren, Filmen & Bearbeiten von Inhalten.
📱 Kenntnisse in Social-Media-Trends und Content-Formaten.
🗣️ Sehr gute Deutsch- und Englischkenntnisse.

#### Was dich bei Gusti Leder erwartet

🌱 **Sinnvolle Arbeit** – Du bist Teil einer Marke, die Slow Fashion lebt und die Lederindustrie verantwortungsvoll gestaltet.
💰 **Fairer Lohn** – 14,00 bis 16,00 € pro Stunde inkl. Überstundenvergütung.
🎉 **Teamkultur** – Flache Hierarchien, offene Kommunikation, Teamevents.
💡 **Kreativer Freiraum** – Deine Ideen finden Platz und können sofort umgesetzt werden.

#### Über uns

Seit 2009 designen wir bei Gusti Leder faire Lederprodukte, die weltweit überzeugen. Mit unserem Team in Rostock, internationalen Partnern und einer stetig wachsenden Community wollen wir Marktführer für nachhaltige Lederprodukte bleiben – und noch stärker werden.

Unsere Produkte stehen für bewussten Konsum, zeitloses Design und Slow Fashion. Wir arbeiten eng mit lokalen Produzenten zusammen und achten auf Qualität, Transparenz und faire Herstellung.

#### So bewirbst du dich

👉 Bewirb dich jetzt in nur **5 Minuten über unser Online-Formular.**
📹 Zusätzlich bitten wir dich, uns ein kurzes kreatives Video per WhatsApp an **+49 1795353513** zu schicken – zeig uns deine Ideen, deine Persönlichkeit & deine Kreativität!

Deine Ansprechpartnerin: **Lea**–

Weitere Infos zur Datenverarbeitung findest du hier: [Datenschutzerklärung](https://gusti-leder.de/policies/privacy-policy)
Bitte beachte: Im Rahmen des Bewerbungsprozesses übernehmen wir keine dafür anfallenden Reisekosten.

💚 **Werde Teil unserer Mission. Werde Teil von #TeamGusti.**

####

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
