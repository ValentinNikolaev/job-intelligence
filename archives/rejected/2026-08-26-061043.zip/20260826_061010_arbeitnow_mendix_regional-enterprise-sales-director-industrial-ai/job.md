# Regional Enterprise Sales Director Industrial AI Transformation DACH (m/f/d)

Posted: 2026-08-26T02:24:35Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**Regional Enterprise Sales Director Industrial AI Transformation DACH (m/f/d)**

**Shape the Future of Industrial AI with Mendix and Intelligence Center X**

At Mendix, a Siemens business, we are redefining how enterprises build, deploy and scale intelligent applications. As the leading low-code platform, Mendix empowers organizations to accelerate digital transformation by combining software development, AI and enterprise collaboration.

With the introduction of **Intelligence Center X**, Siemens is entering the next generation of Industrial AI. Intelligence Center X combines enterprise data, AI agents, knowledge graphs and intelligent applications into a secure and governed ecosystem that enables organizations to move from isolated AI initiatives to enterprise-wide transformation.

To accelerate this vision across Germany, Austria and Switzerland, we are looking for an experienced **Regional Enterprise Sales Director Industrial AI Transformation DACH**.

This executive leadership role combines commercial leadership, strategic market development and executive customer engagement. You will be responsible for scaling the Mendix business while establishing Intelligence Center X as the leading Industrial AI platform for enterprise customers across the region.

**Your Mission**

You will own the commercial strategy, market expansion and business performance for Mendix and Intelligence Center X across DACH.

Working closely with Siemens Digital Industries Software, Siemens Xcelerator, Partner Sales, Customer Success, Product Management and Services, you will build one of Siemens' fastest growing software businesses.

**Your Responsibilities:**

**Commercial Leadership**

- Define and execute the regional growth strategy for Mendix and Intelligence Center X.

- Deliver sustainable Annual Contract Value (ACV), ARR and new-logo growth across the DACH region.

- Lead and develop high-performing Sales Directors, Enterprise Account Executives and cross-functional commercial teams.

- Build a predictable, data-driven sales organization focused on operational excellence and execution.

- Establish executive business reviews, forecasting discipline and performance management frameworks.

**Industrial AI Market Development**

- Position Intelligence Center X as the strategic Industrial AI platform for enterprise customers.

- Help customers evolve from isolated AI pilots toward enterprise-wide AI transformation.

- Drive executive conversations around AI, Digital Engineering, Digital Manufacturing, Digital Thread and Enterprise Transformation.

- Develop strategic industry plays and AI transformation programs for Manufacturing, Automotive, Energy, Life Sciences, Infrastructure and Process Industries.

- Expand Mendix as the preferred platform for intelligent applications, AI copilots and agent-based business processes.

**Executive Customer Engagement**

- Build trusted relationships with CEOs, CIOs, CTOs, Chief Digital Officers and business executives.

- Support strategic enterprise opportunities through executive sponsorship and value-based selling.

- Participate directly in key customer engagements and complex negotiations.

- Position Siemens as a strategic transformation partner beyond traditional software sales.

**Ecosystem Leadership**

- Collaborate across Siemens Digital Industries Software, Siemens Xcelerator, AI Studio, Graph Studio and Partner organizations.

- Build strong relationships with Global System Integrators, consulting partners and technology alliances.

- Develop joint go-to-market initiatives that accelerate Industrial AI adoption.

- Represent Mendix and Intelligence Center X at executive events, customer forums and industry conferences.

**Intelligence-Driven Business Management**

- Leverage customer, market and competitive intelligence to identify growth opportunities.

- Build executive dashboards and business insights to improve forecasting, pipeline health and commercial performance.

- Translate customer feedback into product innovation together with Product Management.

- Establish scalable sales methodologies, industry playbooks and best practices across the region.

**Leadership & Culture**

- Inspire, coach and develop diverse, high-performing teams.

- Foster an inclusive, collaborative and customer-centric culture.

- Encourage innovation, continuous learning and experimentation.

- Build future sales leaders capable of driving the next generation of Industrial AI transformation.

**What You'll Bring:**

- Extensive executive sales leadership experience within Enterprise Software, SaaS or Industrial Software.

- Proven success building and scaling high-growth enterprise businesses across the DACH region.

- Strong experience leading second-line sales organizations.

- Track record of exceeding revenue targets while developing high-performing commercial teams.

- Experience engaging C-level executives on strategic transformation initiatives.

- Deep understanding of Digital Transformation, AI, Enterprise Applications, Cloud Platforms or Industrial Software.

- Strong analytical capabilities with experience leveraging business intelligence and data-driven decision making.

- Experience working within complex matrix organizations and global ecosystems.

- Outstanding executive communication, presentation and negotiation skills.

- Fluent German and English.

**Preferred Experience:**

- Industrial AI

- Low-Code / No-Code Platforms

- Enterprise Applications

- Manufacturing Digitalization

- Siemens Xcelerator Ecosystem

- AI Governance

- Enterprise Architecture

- Platform Business Models

- Digital Engineering

- Digital Manufacturing

- Agentic AI

- Knowledge Graphs

- Enterprise Data Platforms

**What Success Looks Like:**

Within your first 24 months you will have:

- Significantly accelerated Mendix growth across DACH.

- Established Intelligence Center X as a strategic Industrial AI platform within key enterprise accounts.

- Built one of the highest-performing enterprise software organizations within Siemens.

- Expanded strategic relationships with executive customers and partners.

- Created a scalable commercial operating model supporting long-term double-digit growth.

- Positioned Mendix as the application platform connecting AI, enterprise data and business processes across the Siemens Xcelerator ecosystem.

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
