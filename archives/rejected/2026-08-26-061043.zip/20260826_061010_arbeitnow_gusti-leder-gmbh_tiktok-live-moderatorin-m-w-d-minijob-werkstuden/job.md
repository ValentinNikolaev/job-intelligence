# TikTok Live Moderatorin (m/w/d) - Minijob / Werkstudent

Posted: 2026-08-26T02:30:08Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

#### **Gestalte die Zukunft der Lederindustrie mit uns! 🌍✨**

Tauche ein in die Welt von **Gusti Leder**, wo jede Tasche eine Geschichte erzählt und jedes Produkt mehr ist als ein Accessoire – es ist ein Statement für **Nachhaltigkeit und Stil**.
Wir stehen für Transparenz, Qualität und Slow Fashion – und suchen dich als **Gesicht unserer Social Media Lives**. 💚

Du fühlst dich vor der Kamera wie zu Hause, kannst Menschen begeistern und bringst Ideen für interaktive Formate mit? Dann werde Teil unseres Social Media Teams und gestalte unsere TikTok Lives mit! 🚀

#### Deine Mission

🎬 **Live gehen** – Du trittst regelmäßig live auf TikTok auf und gehst direkt in den Austausch mit unserer Community.
👜 **Produkte präsentieren** – Du stellst unsere hochwertigen Lederwaren vor und überzeugst mit Persönlichkeit & Charme.
💡 **Kreativität einbringen** – Du entwickelst spannende Live-Formate und setzt eigene Ideen um.
🤝 **Teamwork** – Gemeinsam mit Content- & Marketing-Team gestaltest du aktiv unseren Markenauftritt.

#### Was du mitbringst

✨ Selbstbewusstes Auftreten vor der Kamera.
🎙️ Klare Stimme & deutliche Aussprache.
😊 Authentische, sympathische Persönlichkeit.
💡 Ideen für kreative Live-Formate.
📹 Erfahrung im Umgang mit Kamera, Licht & Ton.
🛍️ Spaß am Verkaufen & Gespür für unsere Produkte.

#### Was dich bei Gusti Leder erwartet

💰 **Fairer Lohn** – 14,00 bis 16,00 € pro Stunde inkl. Überstundenvergütung.
🎁 **Benefits** – Prämiensystem, flexible Arbeitszeiten, exklusive Mitarbeiterrabatte sowie 15 % Umsatzbeteiligung pro Live.
🎉 **Teamkultur** – Flache Hierarchien, offene Kommunikation & regelmäßige Teamevents.
🚀 **Freiraum zum Mitgestalten** – Deine Ideen zählen, du prägst unseren Live-Auftritt mit.

🍽️ **Energie für den Tag** - zweimal pro Woche frisches Mittagessen.

🍏 **Frisches Plus** - täglich frisches Obst, Kaffee, Tee & Wasser for free.

🚆 **Gute Anbindung** - Unser Standort befindet sich in unmittelbarer Nähe zum Rostocker Hauptbahnhof und ist somit bequem mit der S-Bahn oder Straßenbahn erreichbar.

#### So bewirbst du dich

Bewirb dich jetzt in nur **5 Minuten über unser Online-Formular.**
📹 Zusätzlich bitten wir dich, uns ein kurzes Video per WhatsApp an **+49 17625072023** zu schicken.

Darin solltest du selbst vor der Kamera sprechen und ein Thema kreativ umsetzen – z. B. eine Produktvorstellung, ein Trend-Video oder einen kurzen Social-Media-Clip. Wichtig: **Du bist sichtbar & bringst deine Persönlichkeit ein!**

Deine Ansprechpartnerin: **Alina** –

Weitere Infos zur Datenverarbeitung findest du hier: [Datenschutzerklärung](https://gusti-leder.de/policies/privacy-policy)

Bitte beachte: Im Rahmen des Bewerbungsprozesses übernehmen wir keine dafür anfallenden Reisekosten.

💚 **Werde Teil unserer Mission. Werde Teil von #TeamGusti.**

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
