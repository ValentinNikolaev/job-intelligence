# Production Planner

Posted: 2026-08-26T02:40:27Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**WHO WE ARE**

Proxima Fusion is Europe’s fastest-growing fusion company and the continent’s best-funded fusion player, as well as the first spin-out from the Max Planck Institute for Plasma Physics (IPP). Backed by over €650M and powered by a growing team across Munich, Zurich, and Oxford, we are developing the hardware and infrastructure needed to deliver the world’s first commercial stellarator fusion power plant.

Our concept advances the most mature fusion technology out there, the Wendelstein 7-X stellarator, through two next-generation machines: Alpha and Stellaris. Our work combines stellarator optimization, advanced computation, machine learning, and high-temperature superconducting magnets to unlock higher-performance designs that were previously out of reach.

Turning these designs into a functioning fusion power plant requires excellence and ownership across every discipline, from physics and engineering to software, manufacturing, law, and business functions.

**BY JOINING OUR TEAM YOU’LL GET TO**

-

**Build the machine that builds the machine**. Join TechOps at the forefront of advanced manufacturing, we’re building the production system that will enable commercial fusion. The Production lines, tooling, and processes are being developed from the ground up; you'll create the ways of working, not inherit them.

-

**Work at the frontier of manufacturing technology**. Bring your creativity to evaluate, qualify, and deploy processes with no industry playbook, every component you build and every process you shape goes directly into the core of the stellarator magnet technology.

-

**Do work that matters, and see it grow**. The hardware you build is the product and your career grows with it, from prototyping and process development through quality and industrialization, alongside exceptional colleagues from around the world.

-

**Make an impact you can point to**. In a small, fast-moving team, your calls on equipment, quality, and process directly shape how a world-class deep-tech company produces superconducting magnets with results visible on the shop floor, not buried in a slidedeck.

**YOUR IMPACT**

Build and maintain medium- to long-term production plans that align engineering, procurement, and manufacturing.

Balance capacity, material availability, and evolving engineering requirements to enable predictable execution.

Identify and resolve constraints before they affect day-to-day production on the manufacturing floor.

Support the successful delivery of critical fusion hardware while improving efficiency, coordination, and transparency across manufacturing operations.

**WHAT YOU WILL DO**

-

Translate project milestones into detailed, resourced and executable manufacturing plans.

-

Perform capacity planning and balance workloads across internal and external manufacturing resources.

-

Coordinate with the Procurement & Logistics Department to optimize inventory availability, minimize shortages and support efficient material flow across manufacturing.

-

Anticipate the impact of evolving engineering requirements and material constraints on the production plan and adjust proactively ahead of execution.

-

Work closely with Manufacturing Engineering to incorporate process changes into production plans.

-

Partner with Program Managers to align production priorities with program objectives.

-

Analyze production performance data to identify risks to material availability, capacity and delivery timelines, feeding findings back into the plan.

-

Monitor planning-level metrics such as capacity utilization and lead times and use them to continuously improve the accuracy of the production plan.

-

Support the design, implementation and continuous improvement of production planning systems and processes, contributing to the selection and deployment of future ERP (Enterprise Resource Planning)/MRP (Material Requirements Planning) capabilities.

-

Contribute to the development of scalable production planning processes as Proxima transitions from prototype manufacturing to industrial deployment.

**WHO YOU ARE**

-

You have a degree in Industrial Engineering, Mechanical Engineering, Supply Chain Management, Operations Management or a related field, or equivalent practical experience in production planning, manufacturing operations or supply chain within a complex engineering environment (aerospace, fusion, automotive, energy or other high-tech manufacturing industries).

-

You have experience with production planning systems, MRP/ERP workflows and manufacturing data management and are excited by the opportunity to help implement and shape planning tools in a rapidly growing manufacturing organization.

-

You think in terms of capacity, material flow and constraints and you are comfortable modeling trade-offs before they become execution problems.

-

You thrive in fast-paced, dynamic environments where priorities evolve quickly and planning decisions have a direct impact on manufacturing execution.

-

You communicate effectively across multidisciplinary teams and can balance competing priorities in a fast-paced environment.

-

You are proactive, detail-oriented and comfortable working in an evolving hardware development environment.

**INTERVIEW PROCESS**

-

Recruiter Interview (30-60 min)

-

Technical Screening (30 min)

-

Technical Panel (3x60 min)

-

CEO call (30 min)

*This role sits at L2/L3 of our framework, please inquire during the recruitment process for further information*

At Proxima Fusion, our mission is bold: making limitless clean energy a reality. To get there, we need a high-performing, diverse team that brings different perspectives, challenges assumptions, and builds together with purpose. We know that diversity of thought and experience leads to better ideas, stronger execution, and a more resilient team. We don’t look at how you identify, what you look like, who you choose to worship or what ethnicity you are. We care about what you can bring to the table.

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
