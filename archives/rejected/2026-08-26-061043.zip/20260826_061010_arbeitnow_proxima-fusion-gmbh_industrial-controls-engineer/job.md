# Industrial Controls Engineer

Posted: 2026-08-26T02:40:27Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**WHO WE ARE**

Proxima Fusion is Europe’s fastest-growing fusion company and the continent’s best-funded fusion player, as well as the first spin-out from the Max Planck Institute for Plasma Physics (IPP). Backed by over €650M and powered by a growing team across Munich, Zurich, and Oxford, we are developing the hardware and infrastructure needed to deliver the world’s first commercial stellarator fusion power plant.

Our concept advances the most mature fusion technology out there, the Wendelstein 7-X stellarator, through two next-generation machines: Alpha and Stellaris. Our work combines stellarator optimization, advanced computation, machine learning, and high-temperature superconducting magnets to unlock higher-performance designs that were previously out of reach.

Turning these designs into a functioning fusion power plant requires excellence and ownership across every discipline, from physics and engineering to software, manufacturing, law, and business functions.

**BY JOINING OUR TEAM YOU’LL GET TO**

-

**Build the machine that builds the machine**. Join TechOps at the forefront of advanced manufacturing, we’re building the production system that will enable commercial fusion. The Production lines, tooling, and processes are being developed from the ground up; you'll create the ways of working, not inherit them.

-

**Work at the frontier of manufacturing technology**. Bring your creativity to evaluate, qualify, and deploy processes with no industry playbook, every component you build and every process you shape goes directly into the core of the stellarator magnet technology.

-

**Do work that matters, and see it grow**. The hardware you build is the product and your career grows with it, from prototyping and process development through quality and industrialization, alongside exceptional colleagues from around the world.

-

**Make an impact you can point to**. In a small, fast-moving team, your calls on equipment, quality, and process directly shape how a world-class deep-tech company produces superconducting magnets with results visible on the shop floor, not buried in a slidedeck.

**YOUR IMPACT**

Own the controls engineering for new magnet factory equipment supporting coil winding, impregnation, joining, and end-of-line testing.

Architect control systems and develop PLC (Programmable Logic Controller) software, primarily on Beckhoff platforms.

Commission and validate manufacturing equipment to ensure safe, reliable, and predictable operation.

Partner with mechanical, process, and manufacturing engineers to translate production requirements into robust, well-documented automation solutions.

**WHAT YOU WILL DO**

-

Participate in initial equipment conceptual development for new magnet manufacturing cells, balancing process requirements, layout, cost, and lead time.

-

Architect control system architecture and electrical schematics for new equipment, including sensor/actuator selection and panel layout coordination with electrical designers.

-

Write, debug, and maintain PLC programs (Structured Text, IEC (International Electrotechnical Commission) 61131-3) on Beckhoff TwinCAT, with an emphasis on code that's organized, documented, and reusable.

-

Specify and implement field network topology (e.g., EtherCAT, Profinet, EtherNet/IP, OPC-UA (Open Platform Communications Unified Architecture)) connecting equipment, sensors, and upstream/downstream systems.

-

Set up and tune servo drives and VFDs (Variable Frequency Drives) for precision motion control on winding, handling, and assembly equipment.

-

Design intuitive HMI (Human-Machine Interface)/SCADA (Supervisory Control and Data Acquisition) screens for operator use and troubleshooting.

-

Commission new equipment end-to-end: FAT (Factory Acceptance Test)/SAT (Site Acceptance Test), installation, integration, and initial process validation.

-

Use hand tools and diagnostic instruments (multimeters, oscilloscopes, etc.) for hands-on electrical troubleshooting during build and commissioning.

-

Implement control-reliable safety systems in line with relevant machine safety and electrical standards.

-

Document control architecture, code, and equipment operation to support handover and future sustaining work.

-

Collaborate with manufacturing, mechanical, and process engineers to ensure controls solutions match the realities of magnet coil production.

**WHO YOU ARE**

-

In-depth knowledge of Beckhoff controls systems (TwinCAT 3).

-

Good Structured Text (IEC 61131-3) programming skills.

-

Able to use common hand tools and diagnostic instruments such as multimeters.

-

Proficiency in field network topology, both theory and practical applications.

-

2–5 years of experience in controls engineering for manufacturing or automation equipment, ideally on electromechanical or precision systems.

-

Experience commissioning servo drives/VFDs and integrating sensors, actuators, and safety devices.

-

Familiarity with HMI/SCADA platforms (TwinCAT HMI, WinCC, Ignition, or similar).

-

Bachelor's or Master's degree in Electrical Engineering, Mechatronics, Computer Science, or a related field, or equivalent experience.

Nice to have:

-

Experience with CAD (Computer-Aided Design) electrical drafting tools (e.g., AutoCAD Electrical, EPLAN).

-

Scripting experience (Python, SQL) for data acquisition or MES (Manufacturing Execution System)/database integration.

-

Machine vision experience.

-

Greenfield or startup equipment commissioning experience.

-

Working knowledge of relevant electrical and machine safety standards (e.g., EN (European Norm) 60204-1, IEC 61439, ISO (International Organization for Standardization) 13849).

**INTERVIEW PROCESS**

-

Recruiter Interview (30-60 min)

-

Technical Screening (30 min)

-

Technical Panel (3x60 min)

-

CEO call (30 min)

*This role sits at L2/L3 of our framework, please inquire during the recruitment process for further information*

At Proxima Fusion, our mission is bold: making limitless clean energy a reality. To get there, we need a high-performing, diverse team that brings different perspectives, challenges assumptions, and builds together with purpose. We know that diversity of thought and experience leads to better ideas, stronger execution, and a more resilient team. We don’t look at how you identify, what you look like, who you choose to worship or what ethnicity you are. We care about what you can bring to the table.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
