# Werkstudentin im Bereich Influencer Marketing (m/w/d)

Posted: 2026-08-26T02:30:08Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

*Gestalte mit uns die Zukunft der Lederindustrie! 🌍✨*

Bei **Gusti Leder** verbinden wir Nachhaltigkeit, Transparenz und Slow Fashion mit Leidenschaft für Design und Qualität. Wir sind überzeugt: Leder kann fair, langlebig und verantwortungsvoll sein – und wir zeigen jeden Tag, wie das geht.

Als **Werkstudent:in im Bereich Influencer Marketing** tauchst du in die Welt von Social Media, Kooperationen und Community ein – und hilfst dabei, unsere Marke noch sichtbarer zu machen. Dein Ziel: lernen, wachsen und mitgestalten. 🚀

### **Deine Mission**

🤝 **Kooperationen managen:
** Du initiierst und betreust Kooperationen mit Influencer:innen, die unsere Markenwerte transportieren.

📝 **Creator-Briefings entwickeln:
** Du erstellst Konzepte und Briefings, die Influencer:innen helfen, authentischen Content für unsere Marke zu kreieren.

📊 **Erfolg analysieren:
** Du verfolgst die Performance unserer Kampagnen und leitest Optimierungen daraus ab.

👀 **Trends im Blick behalten:
** Du beobachtest Social-Media- und Influencer-Marketing-Trends und bringst frische Ideen ins Team.

🤗 **Team unterstützen:
** Du arbeitest eng mit unserem Marketing-Team zusammen und unterstützt bei Projekten, Kampagnen und organisatorischen Aufgaben.

### **Was du mitbringst**

🎓 Du bist eingeschriebene:r Student:in im Bereich Marketing, Kommunikation, Medien oder in einem vergleichbaren Bereich.
📱 Du bist organisiert, kreativ und hast ein gutes Gespür für Social Media & Influencer Marketing.
🚀 Du hast Lust, Neues zu lernen und dich im Bereich Influencer Marketing weiterzuentwickeln.
✨ Erste Erfahrung mit Influencer:innen oder Content Creation ist ein Plus – aber kein Muss!
🗣️ Sehr gute Deutsch- und Englischkenntnisse in Wort und Schrift.

### **Was dich bei Gusti Leder erwartet**

🌱 **Sinnvolle Arbeit** – Du bist Teil einer Marke, die Slow Fashion lebt und die Lederindustrie verantwortungsvoll gestaltet.
💡 **Learning by Doing** – Du bekommst echte Verantwortung und entwickelst dich im Influencer Marketing weiter.
🍽️ **Energie für den Tag** – Zweimal pro Woche frisches, kostenloses Mittagessen.
🎉 **Teamkultur** – Flache Hierarchien, offene Kommunikation, regelmäßige Teamevents.
💰 **Fairer Lohn** – Zwischen 14,00 und 16,00 € pro Stunde inkl. Überstundenvergütung.

### **Über uns**

Seit 2009 designen wir bei Gusti Leder faire Lederprodukte, die weltweit überzeugen. Mit unserem Team in Rostock, internationalen Partnern und einer stetig wachsenden Community wollen wir Marktführer für nachhaltige Lederprodukte bleiben – und noch stärker werden.

Werde Teil unserer Mission. Werde Teil von **#TeamGusti**. 💚

👉 Bewirb dich jetzt in nur 5 Minuten über unser Online-Formular.

Deine Ansprechpartnerin ist **Alina**: Weitere Informationen zur Datenverarbeitung im Bewerbungsverfahren findest du hier:[ ](https://gusti-leder.de/policies/privacy-policy)[Datenschutzerklärung](https://gusti-leder.de/policies/privacy-policy).

Im Rahmen des Bewerbungsprozesses übernehmen wir keine dafür anfallenden Reisekosten.

####

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
