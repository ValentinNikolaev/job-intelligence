# Product Designer (m/f/d)

Posted: 2026-08-26T02:40:32Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

# Who We Are

We are a rapidly growing embodied AI company revolutionizing human labor. Leveraging cutting-edge robotics and advanced artificial intelligence, we develop transformative technologies that redefine how work is done across multiple industries — empowering businesses to streamline operations, boost productivity, and unlock new possibilities.

# Overview

We're looking for a Product Designer with a technical background to help define how our autonomous robot systems look, feel, and are experienced by the people who work alongside them. In this role, you'll own the design language of our products end-to-end — from early concept through to a design that's ready to be engineered and manufactured.

# Your Responsibilities

***Product Design:***

-

Define the overall design language and visual identity across our autonomous robot systems product line.

-

Create concept designs, sketches, and high-fidelity renderings for new products and product iterations.

-

Design for usability and human interaction, considering how operators and technicians engage with the hardware day-to-day.

***Technical Integration:***

-

Partner closely with Mechanical and Hardware teams to ensure design concepts are technically feasible and manufacturable.

-

Evaluate trade-offs between form, function, cost, and technical constraints, and make informed design decisions accordingly.

-

Support prototyping and testing to validate design choices before handoff to engineering.

# Qualifications & Requirements

-

Bachelor's or Master's degree in Product Design, Industrial Design, Mechanical Engineering, or a related technical field.

-

Strong portfolio showing shipped or near-shipped physical products.

-

Proficiency in CAD (SolidWorks, Fusion 360, Rhino) and visualization tools (KeyShot, Blender, Adobe Creative Suite).

-

Working knowledge of manufacturing methods and material properties.

-

Comfortable working cross-functionally with mechanical, electrical, and software engineers.

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
