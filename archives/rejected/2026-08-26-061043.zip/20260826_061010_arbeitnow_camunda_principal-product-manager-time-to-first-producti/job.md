# Principal Product Manager- Time to First Production

Posted: 2026-08-26T02:40:18Z

## Rejection

- Category: tech_stack
- Reason: role does not mention Go/Golang or PHP

[**Register Here!**](https://camunda.com/wb-life-at-camunda/)

Camunda is **the enterprise platform for agentic orchestration**, enabling organizations to coordinate **AI agents, people, and systems **across complex, end-to-end business processes. With built-in governance, auditability, and human oversight, Camunda gives enterprises the control they need to move AI from pilots to production — safely and at scale. **Trusted by over 700 organizations worldwide**, including 9 of top 10 US banks, Camunda helps enterprises boost operational efficiency, accelerate time-to-value, and deliver better customer experiences.

**Fully remote and global,** we are in the middle of something bigger: **transforming into an AI-first organisation, built on our own platform**. We use Agentic AI to automate, orchestrate intelligent processes, and elevate human contribution across every team.

Named [GP Bullhound’s Top 100 Next Unicorn list,](https://www.gpbullhound.com/articles/top-100-next-unicorns-the-uk-france-and-germany-lead-with-the-most-promising-technology-companies-in-europe/) **2025 Great Place to Work certified.** ***Visionary***** **in [**2025 Gartner® Magic Quadrant™**](https://page.camunda.com/wp-2025-gartner-magic-quadrant-for-boat)** **for Business Orchestration and Automation Technologies. ranked **3rd in Flexa's 2026 **[**Most Flexible Companies**](https://flexa.careers/companies/camunda), We’re growing fast and looking for top talent to join our team. **If you want meaningful work, visible impact and put something genuinely rare on your CV, keep reading.**

**About the role:**

From the moment a team opens Camunda for the first time, our job is to help them succeed — fast. As Principal Product Manager for Time to First Production, you'll own exactly that experience: the journey from a new team's very first workspace (or first local start) to their first process running confidently in production. Your mission is simple to say and genuinely exciting to build: make that first win happen sooner, more smoothly, and more reliably than ever before.

You'll be the DRI for one of Product Strategy's three company-wide outcome areas, with real license to shape it — define what a great first experience looks like, build the measurement that proves we're delivering it, and set the strategy and priorities that Engineering, Design, and our Experience org build against. It's a founding-type mandate: the outcome area is established and the ambition is clear, and you'll have the room to define the metric, the roadmap, and the experience that gets us there.

You'll work at the intersection of Camunda's push into agentic, AI-first ways of building (AI-assisted modeling, agentic development, ProcessOS-style process re-engineering) and the fundamentals of a great first-run experience (onboarding, guided building, testing, and the path to production). It's a role for someone who loves turning a bold, company-wide ambition — delight customers from day one — into a measurable, funded, and genuinely exciting product

*Curious about the kind of challenges you'll work on at Camunda? Watch this quick *[*30-minute talk*](https://www.camundacon.com/event-session/camundacon-amsterdam-2025/one-exporter-to-rule-them-all-exploring-camunda-exporter/?on_demand=true)* from our engineers to learn more about the new Camunda Exporter and how we’re solving complex problems at scale*

**What You Will Do:**

-

Own the Time to First Production outcome area end to end: define its north-star metric(s), the customer journey they represent, and the roadmap of investments ("rocks" and initiatives) that move them.

-

Partner with the Validation team to build best-in-class, end-to-end measurement of the journey, so we always know exactly how well we're delivering for new teams and where to invest next.

-

Set direction and make prioritization calls across a portfolio of initiatives spanning AI-assisted and agentic building experiences, guided onboarding, testing/validation tooling, the path to production, and human-in-the-loop process experiences — in close partnership with Engineering, Design, and Experience pod leads.

-

Represent this outcome area to SLT, Product Marketing, and GTM, translating fast-moving product work into a clear, evidence-based narrative for internal and external audiences.

-

Collaborate closely with fellow Outcome DRIs (Enterprise Adoption, Production Confidence) to keep the three outcome areas coherent as one product strategy, and to hand work cleanly across the outcome boundaries (e.g., "first process" vs. "the second process and beyond").

-

Bring an outside-in, evidence-based lens — grounding roadmap decisions in real customer needs and feedback, not internal assumptions.

**What You Bring:**

-

Significant experience as a Principal/Staff-level Product Manager owning a cross-cutting, metrics-driven outcome or platform area (not a single feature surface) in B2B or enterprise SaaS.

-

A track record of building measurement and north-star metrics from scratch — comfortable partnering with data/analytics functions to go from "we don't really know" to a credible, trusted number.

-

Strong influence and cross-functional leadership skills: you can align Engineering, Design, GTM, and executive stakeholders around a strategy without relying on formal authority.

-

Excellent written communication — this role's primary tool is the strategy document that others build against, so clear, structured writing matters as much as decision-making.

-

A genuine passion for customer experience, paired with comfort shaping your own remit as the outcome area, its metric, and its roadmap continue to evolve.

-

An interest in (or track record with) AI-native and agentic ways of working — Camunda's product organization is actively building for a world where AI agents build, test, and even help re-engineer processes.

**Nice to Haves:**

-

Background in process automation, workflow orchestration, BPM, or developer platforms.

-

Experience partnering with Product Marketing / Analyst Relations on category or outcome-level positioning.

-

Experience in a company mid-transition to an AI-first product operating model.

***This role is an existing vacancy***

#LI-SK1 #LI-Remote #USEAST

**What We Have to Offer:**

**Compensation**

We offer competitive, fair, and transparent compensation. Salary ranges are location-based, with Standard and Major markets (global tech hubs) reflecting local competition.

**The Annual Total Target Cash **(base salary + 100% variable target, where applicable) shown below spans from the minimum in a Standard market to the maximum in a Major market. Final offers depend on **skills**, **experience**, and **location**, and we typically hire in the first half of the range to allow room for growth:

-

United States: $198,500.00 to $320,000.00

-

United Kingdom: £124,600.00 to £204,900.00

-

Singapore: S$246,500.00 to S$369,700.00

-

Canada: C$210,700.00 to C$346,600.00

If you’re based elsewhere, you’ll be hired via [**Remote.com**](http://Remote.com) (our global employer partner), and your Talent Acquisition Partner will provide a personalized **Total Rewards Calculator** after your first interview.

**Equity: **We also offer equity (where applicable) through our [**Virtual Stock Option Plan (VSOP)**](https://docs.google.com/document/d/1hoyQAPTZ5nV7J47D9n3yqK5hhLj160Xf36iyqEXNOWE/edit?tab=t.0#heading=h.2qon7r4kdfe1).

**Benefits & Perks**

We invest in your wellbeing, growth, and ability to connect, along with perks that support you no matter where you’re based. Our benefits are globally designed and locally delivered where applicable.

-

**Remote & Flexible: **Work from anywhere with the setup that suits you, **home office budget, co-working space support, and flexible time off** to recharge when you need it.

-

**In Person Connection: **We invest in meaningful face time through our **Annual Kickoff **(Vienna in 2025, Madrid in 2026!), **team offsites, and Camundi Connection Budgets**, including contributing to meetups while travelling,, and local gatherings with fellow Camundi.

-

**Health & Wellbeing:** Access locally tailored healthcare, **Modern Health** for global mental wellbeing, and our **Live Well Lifestyle Spending Account (LSA),** a flexible, global benefit that puts you in control of your whole life, not just work, from: **staying active, to caring for family, exploring personal passions, meaningful experiences, and investing in your financial wellbeing.** The Live Well program launches in 2026 and scales to **€1,000 annually from 2027**.

-

**Financial Security:** Retirement and pension plans (often with company contributions), plus life and disability insurance where relevant.

-

**Professional Growth:** Up to $/€/£1,000 per year for self-driven learning: courses, certifications, books, you decide!

**AI in our hiring process**:*** **Camunda may use AI tools to aid the screening of applications and during the interview process. You can *[***learn more here***](https://camunda.com/ai-in-our-interviewing-process/)

*”Everyone is welcome at Camunda” *— *it’s a celebrated component of our culture. We strive to create an inclusive environment that empowers our people. At Camunda, we honour diverse cultures and backgrounds and are proud to be an equal opportunity employer. All qualified applicants will receive consideration without regard to gender, race, ethnicity, religion, belief, sexual orientation, age, disability or any other protected characteristics under applicable law. We are looking forward to your application!*

***Come join us and be part of Camunda’s incredible journey: Make an impact at a pivotal moment in our story!***

***Please be aware that scammers may impersonate Camunda by reaching out about job opportunities. Camunda will only contact candidates from an email address ending in @***[***camunda.com***](http://camunda.com)***. We will never ask candidates for bank account details, checks, payment, or other sensitive financial information as part of our hiring process. If you receive a suspicious message, please do not respond, click any links, or share personal information.***

***Note for recruiting and placement agencies: Camunda does not accept unsolicited agency resumes. Please do not forward resumes to our careers site, employees, or any other Camunda contact unless we have specifically engaged your firm for that search. Camunda will not pay fees related to unsolicited resumes.***

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
