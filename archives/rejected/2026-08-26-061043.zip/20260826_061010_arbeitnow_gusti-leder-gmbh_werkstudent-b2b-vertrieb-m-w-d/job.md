# Werkstudent B2B-Vertrieb (m/w/d)

Posted: 2026-08-26T02:30:08Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**Wachstum, Abschlüsse & Partnerschaften in Deutschland und Europa**

Gestalte mit uns die Zukunft der Lederindustrie – **vertriebsstark, nachhaltig und international!** 🌍✨
Bei **Gusti Leder** treffen Fairness, Qualität und Nachhaltigkeit auf echtes Unternehmertum. Unsere Marke wächst rasant – mit **über 30 Stores in Deutschland und Europa** und einer klaren Vision: nachhaltige Lederprodukte für alle, die Verantwortung leben und Stil schätzen.

Als **Werkstudent:in im B2B-Vertrieb** unterstützt du beim Aufbau unseres B2B-Bereichs. Du hilfst dabei, neue Partner zu gewinnen, bestehende Kontakte zu pflegen und Vertriebsprozesse weiterzuentwickeln. Die Tätigkeit erfolgt vor Ort in unserem Büro in Rostock.

**Klingt nach deiner Mission? **🚀** Dann freuen wir uns auf deine Bewerbung!**

###

#### **Was Dich bei Gusti Leder erwartet:**

📞 **Aufbau & Pflege von Kundenkontakten** -** **Unterstützung beim Aufbau und der Pflege von B2B-Kundenbeziehungen in Deutschland und Europa.

🔎 **Partnerrecherche **-** **Recherche und Identifikation potenzieller Partner und Vertriebskanäle.

💬 **Kundenkommunikation **- Teilnahme an Sales-Calls und Unterstützung bei der Sicherstellung von Kundenzufriedenheit.

📄 **Sales-Unterlagen & Angebote** - Vorbereitung von Präsentationen, Angeboten und Follow-ups.

📊 **Markt- & Wettbewerbsanalyse **- Analyse von Markttrends, Produkten und Wettbewerb.

🚀 **Sales-Projekte **- Mitarbeit an vertriebsrelevanten Projekten und Prozessen.

#### **Was Du mitbringen solltest:**

-

Du studierst im Bereich BWL, Marketing, Vertrieb, Wirtschaft, Mode oder vergleichbar.

-

Interesse an Vertrieb, Handel, Marken & nachhaltigen Produkten.

-

Strukturierte Arbeitsweise und ausgeprägte Kommunikationsfähigkeit.

-

Sicherer Umgang mit MS Office.

-

Sehr gute **Deutsch- und** **Englischkenntnisse**, weitere Sprachen sind ein Plus.

-

Motivation, eigenständig zu arbeiten und Verantwortung zu übernehmen.

#### **Warum Gusti Leder?**

💰 **Faire Vergütung **– Ein attraktiver Stundenlohn zzgl. leistungsorientierter Boni.

**💚 Vertrieb mit Sinn** – nachhaltige Produkte, die Kund:innen begeistern.
🌱 **Nachhaltigkeit first** – Wir leben Slow Fashion und gestalten die Lederindustrie verantwortungsvoll.
💡 **Gestaltungsfreiheit** – Du steuerst deinen Markt aktiv – von der Strategie bis zum Abschluss.
💪 **Gemeinsam wachsen** – wir fordern & fördern dich, mit Weiterbildung, Feedback und echter Verantwortung.
🎉 **Teamkultur** – flache Hierarchien, offene Kommunikation, regelmäßige Teamevents.
🧘 **Work-Life-Balance** – flexible Arbeitszeiten und Yoga-Sessions.

🚆 **Gute Anbindung** – Unser Standort befindet sich in unmittelbarer Nähe zum Rostocker Hauptbahnhof und ist somit bequem mit der S-Bahn oder Straßenbahn erreichbar.
🍽️ **Energie für den Tag** – zweimal pro Woche frisches Mittagessen.

🍏 **Frisches Plus** – Täglich frisches Obst, Kaffee und Wasser for free.
🎁 **Exklusive Rabatte** – für unsere Produkte & viele weitere Corporate Benefits.

#### Über uns

Seit 2009 steht **Gusti Leder** für nachhaltige, faire und langlebige Lederprodukte. Unsere Taschen, Rucksäcke und Accessoires überzeugen weltweit – online, in über **30 Stores** und über ein wachsendes B2B-Netzwerk in ganz **Europa**. **🌿**

Werde Teil von **#TeamGusti** 💚 und bringe unsere Marke durch deinen Vertriebserfolg weiter nach vorne.

Bewirb dich jetzt in nur 5 Minuten über unser Online-Formular.

**Deine Ansprechpartnerin ist Lea**:

Weitere Informationen zur Datenverarbeitung im Bewerbungsverfahren findest Du hier:[ https://gusti-leder.de/policies/privacy-policy](https://gusti-leder.de/policies/privacy-policy)

Im Rahmen des Bewerbungsprozesses übernehmen wir keine dafür anfallenden Reisekosten.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
