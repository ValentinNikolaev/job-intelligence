# Senior Expert Tax (m/w/d)

Posted: 2026-08-25T23:40:23Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

## Deine Rolle

Steuerberatung im Mittelstand ist Beziehungsarbeit — und sie trägt nur, wenn jemand die fachliche Tiefe hat, vor der auch komplexe Fälle nicht mehr groß sind. Mehrere Tausend mittelständische Unternehmen vertrauen uns; wir entwickeln das Modell jetzt in eine deutschlandweite Beratungsplattform weiter. Steuerberatung ist dabei kein Geschäftsfeld unter vielen, sondern der Kern.

Bei Vogel führt der Weg nach oben über zwei gleichwertige Pfade: Mastery für fachliche Tiefe und Pioneer für disziplinarische Führung. Du gehst den Mastery-Weg — und bist darin schon ein Stück. Du bist Steuerberater mit mehreren Jahren Erfahrung nach dem Examen und hast ein ausgewiesenes Spezialgebiet entwickelt: Umwandlungen, internationale Strukturen, Nachfolge, Personengesellschaften oder eine andere klar erkennbare Materie. Du wechselst, weil du dein Spezialgebiet zur sichtbaren fachlichen Autorität ausbauen willst — nicht in einer Pyramide verschenken und nicht im Routinebetrieb verflachen lassen.

Du trägst die komplexesten Mandate des Bereichs und bist die fachliche Anlaufstelle für deine Linie — Eskalations-Endpunkt, Sparringspartner, Methoden-Geber — ohne disziplinarische Führungsverantwortung. Du entwickelst die fachlichen Standards deines Bereichs und befähigst andere Berufsträger, auf deinem Niveau zu arbeiten. Du berichtest an die Bereichsleitung Tax und arbeitest eng mit der Geschäftsführung an den fachlich anspruchsvollsten Mandanten-Themen.

## Deine Verantwortung

### Fachliche Tiefe & Spezialgebiet

-

Trag die komplexesten Mandate und Sonderthemen des Bereichs — Betriebsprüfungen, Umwandlungen, gestaltende Beratung, internationale Strukturen.

-

Bau dein Spezialgebiet zur sichtbaren Bereichs-Tiefe aus — die Materie, für die Mandanten und Multiplier Vogel bei Namen kennen.

-

Verfolge Rechtsprechung und Gesetzesänderungen für dein Gebiet eigenständig und mach die Konsequenzen für unsere Mandanten greifbar.

### Anlaufstelle & Methodik

-

Sei fachlicher Eskalations-Endpunkt für die Tax-Linie bei komplexen Fällen und strittigen Bewertungen.

-

Entwickle Methoden, Templates und fachliche Standards, die andere Berufsträger nutzen — du machst die Linie als Ganzes besser, nicht nur dein eigenes Mandat.

-

Befähige Associates und Expert-Kolleginnen — fachliches Sparring, Review, Onboarding deiner Themen.

### Mandanten & Sichtbarkeit

-

Sei direkter Ansprechpartner für die fachlich anspruchsvollsten Mandanten — auf Augenhöhe, mit echter Tiefe.

-

Trag dein Spezialgebiet nach außen — Vorträge, Veröffentlichungen, Mandanten-Formate — und bau die fachliche Reputation des Bereichs mit auf.

-

Löse Cross-Sell über die Vogel-Bereiche aus, wo dein Gebiet andocken kann (Gestaltungen, M&A-Vorbereitung, FP&A).

## Deine Perspektiven

**Was du nach 6 Monaten geliefert hast:**

-

Du trägst die komplexesten Mandate des Bereichs fachlich eigenständig und bist die fachliche Anlaufstelle deiner Linie.

-

Du hast erste fachliche Sonderthemen vollständig durchgezogen und erste Methoden oder Templates geteilt.

-

Dein Spezialgebiet ist intern sichtbar verankert.

**Was du nach 12 Monaten geliefert hast:**

-

Dein Spezialgebiet zieht Mandate an, die genau diese Tiefe suchen — mit erster externer Sichtbarkeit (Vortrag, Veröffentlichung).

-

Du hast andere Berufsträger befähigt — Schulungen gehalten, fachliche Standards gesetzt.

-

Du bist als fachliche Autorität deines Gebiets im Bereich etabliert.

**Was du nach 24 Monaten geliefert hast:**

-

Die Methoden und Standards deines Bereichs tragen deine Handschrift.

-

Du bist die fachliche Bereichs-Autorität in deinem Gebiet — intern wie bei externen Multipliern.

-

Du bist Kandidat für Lead Expert Tax — über Spezialisierungs-Tiefe und Wirkung, nicht über Berufsjahre.

**Wohin sich die Stelle entwickelt:**

Der nächste Schritt ist Lead Expert Tax — firmenweite fachliche Autorität in deinem Gebiet, gleichwertig zur Director-Stufe auf Managementseite, jedoch ohne disziplinarische Führung. Das setzt eine eigenständig aufgebaute, nach außen sichtbare Spezialisierung voraus, keinen Automatismus aus Berufsjahren.

## Das bringst du mit

### Erfahrung & Track Record

-

Du hast das Steuerberater-Examen bestanden und danach mehrere Jahre Mandantenverantwortung mit fachlicher Tiefe getragen.

-

Du hast ein klar erkennbares Spezialgebiet aufgebaut — und idealerweise schon nach außen getragen (Vortrag, Veröffentlichung, Fachberater-Titel).

-

Du hast gemerkt, dass dein Reiz die fachliche Tiefe und Autorität ist, nicht die disziplinarische Führung.

-

Profile, die nicht in dieses Raster passen, aber substanzielle Tiefe und ein klares Spezialisierungs-Profil mitbringen, sind ausdrücklich eingeladen — wir bewerten am Beitrag, nicht am Etikett. Konkret: promovierte StB mit Praxis-Wunsch; M&A-/TAS-Steuerexperten mit eigener fachlicher Linie; Berufsträger aus Boutiquen mit Mittelstands-Wellenlänge. Die ausgewiesene Range kalibriert auf das Primärprofil — die Logik dahinter steht in unseren [Vergütungsgrundsätzen](https://www.vogel-beratung.com/culture/verg%C3%BCtungsgrunds%C3%A4tze).

### Skills & Arbeitsweise

-

Du hast echte Tiefe in mindestens einem anspruchsvollen Spezialgebiet — und bleibst zugleich über die Breite der Mandantenarbeit hands-on.

-

Du kommunizierst fachlich präzise und zugleich verständlich — im Mandantengespräch wie im Fachbeitrag.

-

Du arbeitest mit AI als selbstverständlichem Werkzeug — Recherche, Drafting, Analyse — und hebelst damit die Tiefe deiner Arbeit. Repetitive Arbeit ist dir ein Reiz zur Automatisierung, kein Schicksal.

### Mindset & Persönlichkeit

-

Du verstehst Mastery als gleichwertigen Karrierepfad, nicht als Hilfslinie für die, die kein Manager werden — dein fachliches Profil ist dein Differenzierer.

-

Du teilst Wissen, statt es zu hüten — deine Autorität entsteht daraus, dass andere mit deinen Methoden besser werden.

-

Du hast den Anspruch, in allem, was du ablieferst, den höchsten Standard zu setzen — nicht weil jemand es kontrolliert, sondern weil Mittelmaß dich persönlich stört.

-

Vogel ist hierarchisch in der Entscheidung, flach in der Kommunikation, autonom in der Ausführung. Leistung wird gefeiert, nicht versteckt.

## Was du bei uns nicht finden wirst

-

**Keinen Spezialisten-Track, der heimlich die zweite Liga ist.** Senior Expert ist gleichwertig zu Senior Manager — gleiche Vergütung, gleicher Einfluss auf strategische Mandanten-Themen, gleiche Sichtbarkeit. Fachlaufbahn ist hier kein Trostpreis.

-

**Kein Routine-Mandat ohne Spezialisierungs-Anspruch.** Wir bauen Themen-Tiefe. Wer nur verwalten will, ist hier nicht richtig.

-

**Keine disziplinarische Führung als Preis für Aufstieg.** Du steigst über fachliche Tiefe und Wirkung, nicht über Personalverantwortung, die du nicht willst.

-

**Keine Partnergesellschaft mit konkurrierenden Eigeninteressen.** Wir sind ein Unternehmen mit One-Firm-Logik — eine Marke, eine Kultur, eine Hiring-Bar.

# FAQ

### 1. Was ist Vogel — und wo arbeitet ihr?

Vogel ist eine der führenden Mittelstandsberatungen Deutschlands — Familienunternehmen seit 1959, aus Aalen — und baut daraus die führende Beratungsplattform für den Mittelstand. Wir wachsen an mehreren Standorten: in Aalen/Ostwürttemberg als gewachsenem Stammsitz und in München als neuem Hub. An beiden suchen wir quer durch die Funktionen — von Steuerberatung über Beratung bis zu den strategischen Teams, die die Plattform bauen.

### 2. Wie sind die Gehaltsbänder zu verstehen?

Bewusst breit — und an jeder Stelle ausgewiesen. Wir differenzieren nach Track Record und Marktwert, nicht nach Abschluss: knappe, stark gefragte Profile am oberen Ende, weniger knappe am unteren. Wir kalibrieren ausschließlich am Markt — zwei Menschen mit ähnlicher Erfahrung können bei uns unterschiedlich verdienen.

### 3. Wie viel — und wie — wird bei Vogel gearbeitet?

Gemessen wird an dem, was du bewegst, nicht an Stunden. Ehrlich ist aber auch: Wer 9-to-5 sucht, ist bei uns nicht die erste Adresse. Wir suchen Menschen, die aus eigenem Antrieb intensiv arbeiten, weil die Aufgaben es wert sind. Wie du deine Zeit verteilst, ist weitgehend deine Sache. Was wir teilen: Wir arbeiten präsent zusammen — Kultur, Sparring und die besten Ideen entstehen in der täglichen Nähe. Wir sind keine Remote-Company und haben keine großen Home-Office-Policies; einzelne Remote-Tage sind kein Problem.

### 4. Wie läuft die Bewerbung?

Schlank, schnell, transparent — und nach Profil gestaffelt. Für Einstiegsrollen (Praktikum, Werkstudium, Berufseinstieg) genügen in der Regel zwei Gespräche und eine kurze Arbeitsprobe; erfahrene Rollen laufen etwas ausführlicher. Bei ausgewählten Senior-Rollen prüfen wir, künftig einen gemeinsamen Arbeitstag einzubauen, damit beide Seiten sich besser kennenlernen. Immer gilt: getaktete Termine, zügige Entscheidung, substanzielles Feedback — unabhängig vom Ausgang.

### 5. Wie funktioniert die variable Vergütung?

Quartalsweise an Leistung gekoppelt, qualitativ bewertet. Die Skala steigt mit dem Level: bis 20 % Associate, 27,5 % Manager, 35 % Senior Manager, 42,5 % Director, 50 % VP. Erwartungswert bei guter Leistung — du erfüllst die Anforderungen, setzt eigene Akzente, bestehst den Keeper Test — liegt bei rund 50 % des Maximums; der Maximalbonus ist nicht der Normalfall. Im Fokus steht eine ganzheitliche Beurteilung durch deine Führungskraft: Ownership, Qualität, Lernkurve, Zusammenarbeit, Impact.

### 6. Wie entwickle ich mich — welche Karrierewege gibt es?

Zwei aktive Wege: Mastery (fachliche Tiefe, Expertenlaufbahn) und Pioneer (Führung, Management). Die Richtung wählst du nach dem Onboarding, meist in Jahr 1–3. Berufseinstieg ist kein Sonderweg, sondern der frühe Teil derselben Strecke — vom Werkstudenten oder Praktikanten zum Associate, für die Besten ohne erneutes Bewerbungsverfahren.

### 7. Team, Kultur, Urlaub?

Ein gemeinsames Mittagessen ist ein offenes tägliches Angebot — keine Pflicht; wer mag, kommt dazu, essen kann jeder jederzeit. Dazu Abendessen, Social Events und Offsites in regelmäßigem Rhythmus — nicht als Pflichtprogramm, sondern weil ein gutes Team auch abseits der Arbeit Zeit teilt. Benefits: durchdacht und substanziell, nicht symbolisch. Urlaub: 28 Tage.

### 8. Ich kenne jemanden — gibt es einen Empfehlungsbonus?

Ja — 2.500 EUR für jede erfolgreich besetzte Stelle (keine Praktika). Kurzer Kontext reicht: an wen du denkst, für welche Rolle, warum. Muss nicht perfekt sitzen, aber substanziell sein.

Compensation: €162K – €202.5K • Fix: €120k – €150k · Bonus: €42k – €52,5k · EV: €144k – €180k

- • OTE €162K – €202.5K • Fix: €120k – €150k · Bonus: €42k – €52,5k · EV: €144k – €180k

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
