# Trainee / Berufseinstieg nach BWL-, Finance- oder Wirtschaftsrecht-Studium (m/w/d)

Posted: 2026-08-25T23:40:23Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

### Deine Rolle

Der Berufseinstieg entscheidet, wie schnell du wirklich etwas kannst. Bei Vogel bekommst du direkt nach dem Studium mehr als Zuarbeit: Du arbeitest von Tag eins an echten Mandaten, kommst früh in den direkten Kontakt mit Geschäftsführern mittelständischer Unternehmen und lernst Beratung dort, wo sie am meisten zählt — nah am Mandanten.

Vogel ist eine der erfolgreichsten mittelständischen Beratungsgesellschaften Deutschlands — mehrere Tausend Unternehmen vertrauen uns ihre Steuer-, kaufmännischen und strategischen Themen an. Unsere Arbeit läuft in drei Linien mit jeweils eigener Verantwortung: Steuerberatung, Accounting & Controlling und Digitalisierungsberatung. Genau deshalb können wir dir etwas anbieten, das sonst kaum jemand hat — du musst dich nicht vorher entscheiden.

Du hast dein Studium abgeschlossen oder stehst kurz davor — Wirtschaftswissenschaften, Finance, Steuerrecht, Wirtschaftsrecht oder ein vergleichbares Fach. Deine ersten zwölf Monate sind bewusst offen: Du arbeitest je rund vier Monate in der Steuerberatung, in Accounting & Controlling und in der Digitalisierungsberatung — jeweils mit eigenen Mandaten und eigener Verantwortung, nicht als Zuschauer. Am Ende dieses Jahres entscheidest du gemeinsam mit uns, wo dein Schwerpunkt liegt. Vogel unterstützt dich anschließend beim passenden Qualifikationsschritt — Master, Führungskarriere oder Berufsexamen, je nach Richtung. Der Weg führt in beiden Linien über eigene Mandate in die Führung eines eigenen Teams.

### Deine Verantwortung

Steuerberatung

-

Beurteile, wo Handelsrecht und Steuerrecht auseinanderlaufen, und bereite die Steuererklärungen für Gesellschaften und Unternehmerfamilien vor — mit eigener Verantwortung und Review durch deinen Anleiter.

-

Begleite Bescheidprüfungen, Rechtsbehelfe und Betriebsprüfungen und lern dabei, wo im Steuerrecht die eigentlichen Streitpunkte liegen.

-

Wirk in gestaltender Beratung mit — Umwandlungen, Nachfolgeplanung, Strukturierung. Hier siehst du, dass Steuerberatung im Kern Denkarbeit ist.

Accounting & Controlling

-

Trag eigene Mandate im laufenden Rechnungswesen, geh den Auffälligkeiten nach und wirk an Monats- und Jahresabschlüssen mit.

-

Bereite die BWA-Besprechung mit dem Unternehmer vor und erklär, was die Zahlen tatsächlich aussagen.

-

Arbeite an Forecasts, Planungs- und Liquiditätsbetrachtungen mit — dort, wo die Zahlen anfangen, unternehmerische Fragen zu beantworten.

Digitalisierungsberatung und eigene Werkzeuge

-

Implementiere beim Mandanten Systeme und richte sie ein — Schnittstellen, Belegflüsse, die Anbindung an sein Vorsystem. Du sitzt beim Unternehmen und bringst die Technik zum Laufen.

-

Betreue Mandanten, die selbst buchen, und schul ihr Personal an den Werkzeugen, mit denen gearbeitet wird.

-

Nutz KI selbstverständlich für Recherche, Analyse, Drafting und Plausibilisierung, und bring eigene Ideen ein, wie Mandantenarbeit schneller und besser wird. Wer KI als Bedrohung sieht, ist hier falsch.

### Deine Perspektiven

**Was du nach 6 Monaten geliefert hast:**

-

Du hast die erste deiner drei Stationen abgeschlossen und steckst in der zweiten — in beiden mit eigenen Mandaten, nicht als Zuschauer.

-

Du hast erste Mandantengespräche aktiv begleitet, mit eigener Vorbereitung und eigenen Wortmeldungen.

-

Du beherrschst unsere Arbeitsumgebung sicher und nutzt KI in deiner täglichen Arbeit.

**Was du nach 12 Monaten geliefert hast:**

-

Du hast alle drei Stationen abgeschlossen und in jeder an echten Mandaten gearbeitet.

-

Du hast deinen Schwerpunkt gewählt und begründen können, warum — auf Basis eigener Arbeit, nicht auf Basis einer Vorstellung.

-

Du hast deinen Qualifikationsschritt konkret gestartet, begleitet von Vogel.

**Was du nach 24 Monaten geliefert hast:**

-

Du hast eine eigene fachliche Vertiefung gefunden — eine Branche, ein Fachgebiet, ein Werkzeug — und baust dort erkennbar Tiefe auf.

-

Du trägst einen Teilmandantenstamm eigenständig; dein Manager ist nur noch Eskalations-Endpunkt für komplexe Sonderthemen.

-

Du bist konkreter Kandidat für die nächste Stufe in deiner Linie.

**Wohin sich die Stelle entwickelt:**

Nach der Schwerpunktwahl führt der Weg in die Manager- oder Expert-Stufe deiner Linie — mit Entwicklungspfad in beide Richtungen, fachliche Expertenlaufbahn oder Führungslaufbahn. Der Weg dorthin entsteht am Beitrag, nicht am Berufsjahr; einen Automatismus „mehr Erfahrung gleich höhere Stufe" kennen wir nicht.

### Das bringst du mit

Erfahrung & Track Record

-

Abgeschlossenes oder kurz vor dem Abschluss stehendes Studium in BWL, VWL, Finance, Wirtschaftsrecht, Steuerrecht oder einem vergleichbaren Fach — idealerweise mit überdurchschnittlichen Leistungen.

-

Idealerweise erste einschlägige Praxiserfahrung — ein Praktikum oder eine Werkstudententätigkeit in Steuerberatung, Wirtschaftsprüfung, Beratung oder einem vergleichbar anspruchsvollen Umfeld. Wenn du noch keine hast, ist das kein Ausschluss — genau dafür ist der offene Einstieg gedacht.

-

Eigeninitiative außerhalb des Lehrplans — ein Projekt, ein unternehmerisches Engagement, eine Initiative, die du nicht nur besucht, sondern mitgeprägt hast.

-

Profile, die nicht in dieses Raster passen, aber substanzielle Fachtiefe mitbringen, sind ausdrücklich eingeladen — wir bewerten am Beitrag, nicht am Etikett. Konkret: ausgebildete Steuerfachangestellte mit nachgeholtem Studium; Jura-Absolventen mit Steuerrechts-Schwerpunkt; ehemalige Gründer mit kaufmännischer Substanz. Die ausgewiesene Spanne ist kein Verhandlungsspielraum, sondern eine Profil-Skala. Das untere Ende steht für den Einstieg ohne einschlägige Station. Wer aus dualem Studium oder mehreren Praxisstationen kommt und die Standardfälle einer der drei Linien von Beginn an selbständig trägt, startet im oberen Drittel. Die oben ausgewiesene Range gilt für das Primärprofil. Wer einen anderen Hintergrund mitbringt, startet zu einem anderen Marktpreis und konvergiert nach zwölf Monaten bewährter Leistung auf das Rollen-Niveau — die Logik dahinter steht in unseren [Vergütungsgrundsätzen](https://www.vogel-beratung.com/culture/verg%C3%BCtungsgrunds%C3%A4tze).

Skills & Arbeitsweise

-

Du arbeitest analytisch und strukturiert — du zerlegst eine Aufgabe in Teilschritte, bevor du loslegst, und lieferst nachvollziehbar aufgebaute Ergebnisse.

-

Du kommunizierst klar und verbindlich — schriftlich wie im ersten Mandantengespräch. Du hast keine Scheu vor Themen, die du noch nicht voll beherrschst.

-

Du arbeitest mit KI als selbstverständlichem Werkzeug — Recherche, Drafting, Analyse, Mandantenkommunikation.

-

Du arbeitest schnell, ohne dass die Qualität leidet — in einem Team ohne Puffer wird das, was du ablieferst, direkt verwendet.

Mindset & Persönlichkeit

-

Du willst dich fachlich festlegen — aber erst, wenn du weißt, worauf. Die Offenheit der ersten zwölf Monate ist für dich eine Chance, keine Unsicherheit.

-

Du bringst die Demut mit, von erfahrenen Praktikern zu lernen — und gleichzeitig den Anspruch, eigene Beiträge zu liefern, die das Team weiterbringen.

-

Du denkst unternehmerisch — du übernimmst Verantwortung für deine Mandate, nicht für deine Stunden.

-

Du hast den Anspruch, in allem, was du ablieferst, den höchsten Standard zu setzen — nicht weil jemand kontrolliert, sondern weil Mittelmaß dich persönlich stört.

### Was du bei uns nicht finden wirst

-

**Kein Trainee-Programm mit Beobachterstatus.** Du rotierst — das ist der Sinn der Sache. Aber in jeder Station trägst du eigene Mandate und lieferst Ergebnisse, die verwendet werden. Keine Hospitation, keine Folien-Aufgaben, kein Warten auf die nächste Station.

-

**Kein Zuarbeiter-Job, bei dem du dem Manager Belege sortierst.** Du arbeitest an echten Mandaten, mit echtem Mandantenkontakt, mit echter Verantwortung.

-

**Keine Big-Four-Pyramide ohne Mandantenkontakt in den ersten Jahren.** Bei uns siehst du Mandanten ab Tag eins.

-

**Kein Erbhof-Mittelstand ohne Wachstumsanspruch.** Wir bauen Spezialisierungen und Branchen-Tiefe, wir verwalten nicht.

-

**Kein Konzern-Korsett, in dem du auf Beförderungen wartest.** Wachstum entsteht hier am Beitrag, nicht am Berufsjahr.

# FAQ

### 1. Was ist Vogel — und wo arbeitet ihr?

Vogel ist eine der führenden Mittelstandsberatungen Deutschlands — Familienunternehmen seit 1959, aus Aalen — und baut daraus die führende Beratungsplattform für den Mittelstand. Wir wachsen an mehreren Standorten: in Aalen/Ostwürttemberg als gewachsenem Stammsitz und in München als neuem Hub. An beiden suchen wir quer durch die Funktionen — von Steuerberatung über Beratung bis zu den strategischen Teams, die die Plattform bauen.

### 2. Wie sind die Gehaltsbänder zu verstehen?

Bewusst breit — und an jeder Stelle ausgewiesen. Wir differenzieren nach Track Record und Marktwert, nicht nach Abschluss: knappe, stark gefragte Profile am oberen Ende, weniger knappe am unteren. Wir kalibrieren ausschließlich am Markt — zwei Menschen mit ähnlicher Erfahrung können bei uns unterschiedlich verdienen.

### 3. Wie viel — und wie — wird bei Vogel gearbeitet?

Gemessen wird an dem, was du bewegst, nicht an Stunden. Ehrlich ist aber auch: Wer 9-to-5 sucht, ist bei uns nicht die erste Adresse. Wir suchen Menschen, die aus eigenem Antrieb intensiv arbeiten, weil die Aufgaben es wert sind. Wie du deine Zeit verteilst, ist weitgehend deine Sache. Was wir teilen: Wir arbeiten präsent zusammen — Kultur, Sparring und die besten Ideen entstehen in der täglichen Nähe. Wir sind keine Remote-Company und haben keine großen Home-Office-Policies; einzelne Remote-Tage sind kein Problem.

### 4. Wie läuft die Bewerbung?

Schlank, schnell, transparent — und nach Profil gestaffelt. Für Einstiegsrollen (Praktikum, Werkstudium, Berufseinstieg) genügen in der Regel zwei Gespräche und eine kurze Arbeitsprobe; erfahrene Rollen laufen etwas ausführlicher. Bei ausgewählten Senior-Rollen prüfen wir, künftig einen gemeinsamen Arbeitstag einzubauen, damit beide Seiten sich besser kennenlernen. Immer gilt: getaktete Termine, zügige Entscheidung, substanzielles Feedback — unabhängig vom Ausgang.

### 5. Wie funktioniert die variable Vergütung?

Quartalsweise an Leistung gekoppelt, qualitativ bewertet. Die Skala steigt mit dem Level: bis 20 % Associate, 27,5 % Manager, 35 % Senior Manager, 42,5 % Director, 50 % VP. Erwartungswert bei guter Leistung — du erfüllst die Anforderungen, setzt eigene Akzente, bestehst den Keeper Test — liegt bei rund 50 % des Maximums; der Maximalbonus ist nicht der Normalfall. Im Fokus steht eine ganzheitliche Beurteilung durch deine Führungskraft: Ownership, Qualität, Lernkurve, Zusammenarbeit, Impact.

### 6. Wie entwickle ich mich — welche Karrierewege gibt es?

Zwei aktive Wege: Mastery (fachliche Tiefe, Expertenlaufbahn) und Pioneer (Führung, Management). Die Richtung wählst du nach dem Onboarding, meist in Jahr 1–3. Berufseinstieg ist kein Sonderweg, sondern der frühe Teil derselben Strecke — vom Werkstudenten oder Praktikanten zum Associate, für die Besten ohne erneutes Bewerbungsverfahren.

### 7. Team, Kultur, Urlaub?

Ein gemeinsames Mittagessen ist ein offenes tägliches Angebot — keine Pflicht; wer mag, kommt dazu, essen kann jeder jederzeit. Dazu Abendessen, Social Events und Offsites in regelmäßigem Rhythmus — nicht als Pflichtprogramm, sondern weil ein gutes Team auch abseits der Arbeit Zeit teilt. Benefits: durchdacht und substanziell, nicht symbolisch. Urlaub: 28 Tage.

### 8. Ich kenne jemanden — gibt es einen Empfehlungsbonus?

Ja — 2.500 EUR für jede erfolgreich besetzte Stelle (keine Praktika). Kurzer Kontext reicht: an wen du denkst, für welche Rolle, warum. Muss nicht perfekt sitzen, aber substanziell sein.

Compensation: €61.2K – €79.2K • Fix: €51k – €66k · Bonus: €10,2k – €13,2k · EV: €58,14k – €75,24k

- • OTE €61.2K – €79.2K • Fix: €51k – €66k · Bonus: €10,2k – €13,2k · EV: €58,14k – €75,24k

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
