# Product Manager, AI Driver

Posted: 2026-08-15T17:55:13Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

## **About us **

Founded in 2017, Wayve is the leading developer of Embodied AI technology. Our advanced AI software and foundation models enable vehicles to perceive, understand, and navigate any complex environment, enhancing the usability and safety of automated driving systems.

Our vision is to create autonomy that propels the world forward. Our intelligent, mapless, and hardware-agnostic AI products are designed for automakers, accelerating the transition from assisted to automated driving.

In our fast-paced environment big problems ignite us—we embrace uncertainty, leaning into complex challenges to unlock groundbreaking solutions. We aim high and stay humble in our pursuit of excellence, constantly learning and evolving as we pave the way for a smarter, safer future.

At Wayve, your contributions matter. We value diversity, embrace new perspectives, and foster an inclusive work environment; we back each other to deliver impact.

Make Wayve the experience that defines your career!

## The role

As Product Manager, AI Driver, based in our Germany office (London also considered), you will independently own a critical work package within Wayve's AI Driver product and lead a cross-functional team to deliver it end-to-end. You'll set the technical direction, drive priorities across engineering, AI research and program management. You will rally the team around clear, ambitious goals. This is a high-ownership, high-impact role for someone who pairs deep AI technical depth with the interpersonal skills to listen, motivate and align brilliant teams toward shared outcomes.

Key responsibilities:

- Independently own a substantial work package end-to-end. Define the problem, set the strategy, sequence the work, and lead the team to ship outcomes that move the AI Driver product forward.

- Lead a cross-functional team of engineers, researchers and PMs without formal authority. Give them clarity, remove blockers, and motivate them through hard, ambiguous problems.

- Engage deeply with technical detail across AI / ML, autonomy and embodied AI. Debate trade-offs credibly with senior researchers and engineers, and bring structured thinking to complex technical decisions.

- Translate R&D progress and customer needs into a clear product roadmap, sequencing capabilities to maximise impact and de-risk delivery.

- Communicate crisply across audiences, from deep technical reviews with engineers, to executive updates with leadership, to customer-facing conversations.

- Listen actively to engineers, partners and customers, and turn what you hear into better decisions and stronger team alignment.

- Set, track and report on clear KPIs and milestones, and establish the operating rhythm the team needs to deliver.

## About you

In order to set you up for success as a Product Manager at Wayve, we’re looking for the following skills and experience.

Essential

- Demonstrated ability to independently own a substantial work package and lead a cross-functional team to deliver it. You take outcomes personally and don't wait to be unblocked.

- Strong technical depth, ideally in AI / ML, autonomy, robotics or another deep-tech domain, with the credibility to engage senior engineers and researchers as a peer.

- Excellent communication and interpersonal skills. A careful listener, a clear writer, and someone who can motivate and energise a team through ambiguity.

- Proven track record in product management, technical program management or a similar role on complex, cutting-edge technical products.

- High autonomy, strong judgment and a bias for action. Comfortable making decisions with imperfect information and adjusting as you learn.

Desirable

- Domain experience in autonomous driving, ADAS, automotive or other safety-critical product areas.

- Hands-on background in AI / ML, for example research, applied ML, or shipping ML-powered products.

- Background working across global teams (UK / EU ↔ US and Japan) in a startup or scale-up environment.

This is a full-time role based in our office in Leonberg. At Wayve we want the best of all worlds so we operate a hybrid working policy that combines time together in our offices and workshops to fuel innovation, culture, relationships and learning, and time spent working from home. We operate core working hours so you can determine the schedule that works best for you and your team.

Wayve is committed to creating an inclusive interview experience. If you require any accommodations or adjustments to participate fully in our interview process, please let us know.

We understand that everyone has a unique set of skills and experiences and that not everyone will meet all of the requirements listed above. If you’re passionate about self-driving cars and think you have what it takes to make a positive impact on the world, we encourage you to apply.

At Wayve we're committed to creating a diverse, fair and respectful culture that is inclusive of everyone based on their unique skills and perspectives, and regardless of sex, race, religion or belief, ethnic or national origin, disability, age, citizenship, marital, domestic or civil partnership status, sexual orientation, gender identity, veteran status, pregnancy or related condition (including breastfeeding) or any other basis as protected by applicable law.

For more information visit [Careers at Wayve. ](https://wayve.ai/careers/)

To learn more about what drives us, visit [Values at Wayve ](https://wayve.ai/careers/)

For US candidates only, please visit [E-Verify Notice](https://drive.google.com/file/d/1N46n3iN0AG8EPEO-hCanyyv7hzz8KgT_/view?usp=sharing) and [Participation and Right to Work](https://www.ussc.gov/sites/default/files/pdf/employment/RightToWork.pdf)

DISCLAIMER: We will not ask about marriage or pregnancy, care responsibilities or disabilities in any of our job adverts or interviews. However, we do look to capture information about care responsibilities, and disabilities among other diversity information as part of an optional DEI Monitoring form to help us identify areas of improvement in our hiring process and ensure that the process is inclusive and non-discriminatory.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
