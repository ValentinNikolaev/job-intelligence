# Cybersecurity Engineer (F/M/D)

Posted: 2026-08-05T05:27:52Z

## Rejection

- Category: tech_stack
- Reason: role does not mention Go/Golang or PHP

Founded in 2025, Omnisent is a Munich-based defense technology company developing fully autonomous, Counter-UAS system. We are a small, high-output team from Cambridge, Imperial College, MIT, and BCG united by a mission to redefine modern airspace security.

## Tasks

We are looking for a Cybersecurity Engineer to secure OmniDome against cyber attacks – protecting our sensors, communication links, and software from adversaries actively trying to jam, spoof, hack, or disable the system in the field. This is a product security role, not a compliance role: you'll be defending what we build, not managing internal IT policy.

- Design and implement security measures across OmniDome's hardware, firmware, and software to defend against cyber attacks

- Conduct threat modeling, vulnerability assessments, and penetration testing on OmniDome systems

- Implement secure boot, encryption, and authentication mechanisms for sensor nodes and edge devices

- Work closely with hardware, RF, and software engineers to build security into the product from the ground up

- Investigate and help defend against real-world attack attempts observed in field deployments

- Track emerging threats relevant to autonomous defense systems and adapt our defenses accordingly

## Requirements

- Strong background in cybersecurity or embedded/product security engineering

- Experience securing embedded systems, IoT devices, or communication protocols against real-world attacks

- Familiarity with encryption, secure boot, and authentication mechanisms for hardware and firmware

- Experience with threat modeling, penetration testing, or red-teaming

- Comfortable working closely with hardware and RF engineers to secure systems end-to-end

**Bonus:**

- Experience securing systems against electronic warfare (jamming, spoofing) or in contested, adversarial environments

- Background in defense, aerospace, or other mission-critical security engineering

- Experience with RF security or software-defined radio (SDR)

## Benefits

- **Competitive Compensation:** Highly competitive cash comp, along with virtual stock options, that reflect your experience and the value you bring

- **Accelerated Learning & Growth:** Join a fast-paced environment where you'll take on real responsibility, overcome meaningful challenges, and grow alongside a driven team

- **Make a Real Impact:** Play a key role in shaping Omnisent's journey and contribute directly to the success of the company

*In your cover letter, we'd love to hear about your personal interests, what drives you, why this role feels like the right fit, and most importantly, why Omnisent.*

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
