# Working Student – Legal Operations & AI Automation

Posted: 2026-08-05T05:05:25Z

## Rejection

- Category: tech_stack
- Reason: role does not mention Go/Golang or PHP

Lovehoney Group is the world’s leading sexual wellbeing company, with the mission to elevate pleasure through innovative technologies, a data-driven approach, and foster creative and fresh perspectives on intimacy. We offer exciting brands with innovative, high-quality sex toys, lingerie, and accessories in a streamlined online shopping experience.

At Lovehoney, we employ over 800 passionate and progressive individuals across 11 global offices, each person contributing a unique blend of talents to our diverse workforce. We are proud to be a company that thrives by doing things differently, challenging expectations and stereotypes while making a positive impact on our customers’ lives.

Join us at Lovehoney, where pleasure combines with creativity, data, and innovation!

We are currently looking for a Working Student – Legal Operations & AI Automation (m/f/d)** **who will be integral to driving efficient and scalable legal processes across Lovehoney Group. Partnering directly with the Legal team, your focus will be on supporting and improving our contract review workflows and helping to shape AI-driven solutions for legal operations.

In this role, you will combine your appreciation for technology and process efficiency with your capacity for creative problem-solving. You will develop skills crucial to advancing in a competitive, fast-paced retail environment, all within a company that values initiative, innovation, and results.

**What you will do**

-

Manage administrative aspects of the contract review process (e.g. ticket creation, e-signatures, filing, deadline tracking).

-

Support the development and improvement of AI-based automation for legal and contract workflows.

-

Collaborate with Legal, IT and other teams to identify and implement practical, scalable solutions.

-

Provide ad hoc administrative support to the Legal team.

**What you should bring **

-

Enrollment at a university for the full duration of the contract (minimum 6 months).

-

Strong interest in AI tools and automation, including hands-on experience with prompting.

-

Affinity for digital tools and structured, detail-oriented working style.

-

Problem-solving mindset with a proactive and curious approach.

-

Good communication skills and ability to work with different teams.

-

Experience in admin, tech, operations or legal is a plus (but not required).

**What we can offer you**

-

A welcoming workplace full of drinks, snacks, friendly faces and fun team-building events.

-

Access to unique discounts at high street retailers, hotels, and service providers, in addition to a 50% discount on all Lovehoney products to explore and discover new ways to have fun.

-

Access to customized training opportunities to support your unique learning journey, complemented by biannual feedback cycles, offering valuable insights into your performance and growth areas, enhancing your development within the company.

-

Recognising the significance of physical and mental health, we proudly provide gym benefits in addition to a mental wellbeing platform, to ensure our employees thrive both professionally and personally.

-

Stay secure at work and at home with a complimentary 1Password Family account. All Lovehoney Group employees can invite up to five family members to join, offering your household a safe and simple way to manage passwords and sensitive information safely and easily.

**Our interview process**

-

CV review

-

Interview with one of Talent Acquisition Team Members

-

Hiring Manager Interview

Lovehoney Group is an equal opportunities employer. We promise that every qualified person will be evaluated according to skills regardless of age, disability, gender reassignment, marriage and civil partnership, pregnancy and maternity, race, religion or belief, sex, or sexual orientation.

If you require accommodations during the interview process due to a disability, please inform your Talent Acquisition Specialist so that we can ensure a smooth and inclusive experience for all candidates.

At Lovehoney Group, we embrace innovative technologies to enhance our recruitment process. We leverage artificial intelligence during screening interviews for CV reviews and note-taking. We prioritize transparency and respect your preferences, so you'll have the option to opt out of recording and AI-driven note-taking while still receiving full and fair consideration for the role.

If we sparked your interest and you are open to embarking on your professional path with us, please visit our Lovehoney careers page to apply: [https://jobs.eu.lever.co/lovehoneygroup](https://jobs.eu.lever.co/lovehoneygroup)

Our privacy policy is available here: [https://www.lovehoneygroup.com/privacy-policy/](https://www.lovehoneygroup.com/privacy-policy/)

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
