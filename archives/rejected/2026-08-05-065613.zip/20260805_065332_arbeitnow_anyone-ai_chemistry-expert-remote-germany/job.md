# Chemistry Expert (Remote - Germany)

Posted: 2026-08-05T00:00:59Z

## Rejection

- Category: tech_stack
- Reason: role does not mention Go/Golang or PHP

-

**Location: **Remote

-

**Type: **Contract / Part-time

-

**Commitment: **10-20 hours per week

-

**Compensation:** Up to 40 USD / hr

-

**Project duration:** **2 months**, with potential extension

## **About the role**

We create high-quality STEM training data for frontier AI models that is directly used in training and evaluation workflows at leading AI labs.

**We are looking for experts in Chemistry** to design advanced, deterministic problems with exactly one verifiable correct answer. These problems should challenge modern AI systems with deep reasoning, domain knowledge, and computational rigor.

Projects may include computational chemistry, physical chemistry, analytical chemistry, chemical engineering-adjacent workflows, and chemistry tasks requiring specialized software tools.

## **What you’ll do**

-

Design difficult chemistry problems that reflect real scientific workflows

-

Create deterministic tasks with one correct answer and full verified solutions

-

Develop reasoning-intensive and computationally grounded problems

-

Use Python and, where appropriate, domain-specific chemistry tools or simulation packages

-

Ensure all tasks are reproducible, technically precise, and clearly documented

-

Write concise and rigorous technical explanations in English

## **What we’re looking for**

-

**Master’s or PhD in Chemistry** or a related field

-

Research or industry experience involving computational or quantitative chemistry workflows

-

Strong Python skills; familiarity with scientific libraries

-

Strong understanding of modeling, numerical approaches, and chemical reasoning

-

Ability to design original, difficult problems that go beyond textbook recall

-

Excellent attention to detail and clear technical writing

## **Nice to have**

-

**Experience with computational chemistry, cheminformatics, spectroscopy analysis, molecular modeling, or specialized chemistry software**

-

Experience with professional chemistry workflows involving simulation or data analysis tools

-

Experience creating technical evaluation content

Compensation: $40 per hour

- • $40 per hour

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
