# Senior Domain Engineering Specialist

Posted: 2026-08-05T02:55:42Z

## Rejection

- Category: tech_stack
- Reason: role does not mention Go/Golang or PHP

Veeam is the Data and AI Trust Company, specializing in helping organizations ensure their data and AI are fully understood, secured, and resilient to enable the acceleration of safe AI at scale. As the market leader in both data resilience and data security posture management, Veeam is built for the convergence of identity, data, security, and AI risk. Headquartered in Seattle with offices in more than 30 countries, Veeam protects over 550,000 customers worldwide, who trust Veeam to keep their businesses running. Join us as we go fearlessly forward together, growing, learning, and making a real impact for some of the world’s biggest brands.

####

#### **About the Role**

The ideal candidate will be naturally collaborative, articulate, extremely organized, have a solid technical understanding of Veeam products, and motivated by maximizing customer success and outcomes. Soft skills combined with technical skills are key in this role. You will partner with Customer Success Engineers (CSEs) and Account Executives (AEs) to drive customer outcomes across security-related products and use cases within the Veeam Data Platform (VDP). You’ll lead readiness checks, data modeling, and risk conversations with CISO/CIO stakeholders, while monitoring telemetry and maturity against the Veeam Data Resilience Maturity Model (DRMM) to optimize posture and identify expansion opportunities.

#### **What You’ll Do**

- Engage customers on security-related products, architectures, and risk topics across the Veeam Data Platform (VDP).

- Run readiness checks and lead data modeling to validate solution design and accelerate decisions.

- Monitor attack surfaces and vulnerabilities (including DRMM scoring), track telemetry or recurring inspection signals, report trends, and capture potential health checks.

- Validate designs to de-risk adoption and accelerate time to value.

- Identify and articulate expansion opportunities; review consumption trends and schedule checkpoint reviews (with or without AE coordination).

- Engage CISO/CIO stakeholders for risk, status, and opportunity discussions; synthesize inputs from account health and CSE-led QBRs.

- Support AEs on security- and AI-driven expansion motions; influence roadmap priorities with CSE counterparts.

- Operate as a pooled resource covering Enterprise and Commercial-Named accounts (generally $100K+ ARR), typically at a 1 Security Success Engineer to 6–8 CSE coverage ratio.

- Note: Not the primary owner for Onboarding motions nor directly responsible for Renewals

#### **What You’ll Bring**

- 5+ years of experience in engineering architecture for cybersecurity-related products (e.g., Security Engineer/Architect, Cloud Solution Architect, MLOps/ML Engineer).

- Bachelor’s degree in Computer Science, Electrical Engineering, or a related technical field; advanced degree is a plus.

- Relevant certifications (e.g., CompTIA Security+, CISSP, or equivalent).

- Expertise in data security and governance, including DSPM/DLP; familiarity with AI/ML architectures.

- Demonstrated ability to engage CISO/CIO stakeholders on risk, resilience, and modernization roadmaps.

- Hands-on experience with solution design, POCs, telemetry monitoring, and maturity modeling (DRMM familiarity is a plus).

- Strong communication, stakeholder management, and cross-functional collaboration skills.

- VMCE certification (can be completed after joining)

#### **What You’ll Get **

- Statutory benefits: healthcare coverage, occupational accident insurance, and unemployment cover included.

- State pension: contributions to the public pension system are covered in line with local rules (18.6% of salary, capped at €5,800/month).

- Accident insurance: 24/7 worldwide coverage, including disability and death benefits and rescue cost coverage.

- Supplementary pension plan: we contribute €302 net per month to a group pension plan; you can top it up, and your contributions are tax-exempt (you can also transfer an existing plan into ours).

- Time off: 30 days of annual leave.

####

#### Please note: If the applicant is permanently located outside of Germany, Veeam reserves the right to decline the application for the position. Remote work is only possible for employees located in Germany.

#LI-MP1

####

**Veeam Software is an equal opportunity employer** and does not tolerate discrimination in any form on the basis of race, color, religion, gender, age, national origin, citizenship, disability, veteran status or any other classification protected by federal, state or local law. All your information will be kept confidential.

Personal data collected during the recruitment process will be processed in accordance with our [Recruiting Privacy Notice](https://www.veeam.com/legal/recruiting-privacy-notice.html), which explains how your information is collected, used, and handled in connection with hiring activities. By applying for this position, you consent to this processing.

By submitting your application, you confirm that the information provided, including any supporting documents, is complete and accurate to the best of your knowledge. Any misrepresentation, omission, or falsification may result in disqualification from consideration or, if discovered after employment begins, termination of employment.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
