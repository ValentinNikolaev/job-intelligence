# Biology Expert - AI Trainer (Germany)

Posted: 2026-08-05T00:01:00Z

## Rejection

- Category: tech_stack
- Reason: role does not mention Go/Golang or PHP

-

**Location: **Remote

-

**Type: **Contract / Part-time

-

**Commitment: **20 hours per week

-

**Compensation:** Up to 40 USD / hr

-

**Project duration:** **2 months**, with potential extension

## **About the role**

We create high-quality STEM training data for frontier AI models used by leading AI labs to improve model reasoning in scientific domains.

**We are seeking experts in Biology to create challenging, deterministic problems with exactly one verifiable correct answer.** Problems should reflect authentic scientific and analytical workflows and be submitted with complete, verified solutions.

Depending on specialization, work may include molecular biology, genetics, systems biology, computational biology, bioinformatics, or adjacent quantitative biology fields.

## **What you’ll do**

-

Design advanced biology problems that challenge frontier AI systems

-

Create deterministic tasks with one correct answer

-

Submit complete, verified solutions

-

Build problems involving experimental reasoning, biological systems, computational analysis, or bioinformatics workflows

-

Use Python and, when relevant, specialized biology or bioinformatics tools

-

Ensure high standards of rigor, reproducibility, and technical clarity

## **What we’re looking for**

-

**Master’s or PhD in Biology** or a related life sciences field

-

Research or industry experience involving computational or quantitative biological analysis

-

Strong Python skills; experience with data analysis or bioinformatics workflows preferred

-

Strong reasoning ability and comfort with multi-step scientific problem solving

-

Ability to create original, difficult problems grounded in real biological practice

-

Clear written English and strong attention to detail

## **Nice to have**

-

Experience with bioinformatics toolkits, genomics workflows, structural biology tools, or computational biology methods

-

Experience designing technical assessments or scientific challenge problems

-

Cross-disciplinary experience spanning biology and computation

Compensation: $40 per hour

- • $40 per hour

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
