# Senior Product Owner – NetSuite

Posted: 2026-08-05T05:05:25Z

## Rejection

- Category: tech_stack
- Reason: role does not mention Go/Golang or PHP

Lovehoney Group is the world’s leading sexual wellbeing company, with the mission to elevate pleasure through innovative technologies, a data-driven approach, and foster creative and fresh perspectives on intimacy. We offer exciting brands with innovative, high-quality sex toys, lingerie, and accessories in a streamlined online shopping experience.

At Lovehoney, we employ over 800 passionate and progressive individuals across 11 global offices, each person contributing a unique blend of talents to our diverse workforce. We are proud to be a company that thrives by doing things differently, challenging expectations and stereotypes while making a positive impact on our customers’ lives.

Join us at Lovehoney, where pleasure combines with creativity, data, and innovation!

We are currently looking for a Senior Product Owner – NetSuite who will be integral to driving high-level performance across Lovehoney Group. Partnering directly with the CTO, Director of Technology Operations and key Finance stakeholders, you will lead the strategy, roadmap, and delivery of our NetSuite OneWorld ecosystem. In this role, you will combine your appreciation for business systems and integration with your capacity for cross-functional collaboration and strategic leadership. You'll thrive in a competitive, fast-paced retail sector, all within a company that prizes dedication and results.

**What you will do**

- Define, develop, and execute the strategic vision for NetSuite and related business systems.

- Collaborate across Finance, Product, Supply Chain, and Tech to prioritise and deliver impactful system enhancements.

- Manage a clear, prioritised backlog aligned with business needs and technical feasibility.

- Guide the design and implementation of robust customisations and integrations with developers, architects, and third-party partners.

- Own delivery processes including sprint planning, reviews, release management, and change adoption.

- Drive user-adoption and training programmes and enforce best practices in system usage and data integrity.

- Use system performance and operational data to guide prioritisation and measure success of delivered solutions.

**What you should bring**

- A degree in Business, Finance, Information Systems, Computer Science, or a related field.

- 5+ years of experience as a Product Owner or Product Manager, with a focus on NetSuite.

- Expertise with SuiteScript, SuiteFlow, SuiteAnalytics, or related NetSuite tools.

- Solid understanding of financial, operational, and supply chain processes in multi-entity environments.

- Proven ability to build product roadmaps and deliver in agile teams.

- Experience designing or contributing to ERP systems architecture in multi-entity environments.

- Preferred qualifications: NetSuite certifications, accounting knowledge or qualifications, project management experience, or a background in SaaS/high-growth environments.

**What we can offer you**

- A welcoming workplace full of drinks, snacks, friendly faces and fun team-building events.

- Access to unique discounts at high street retailers, hotels, and service providers, in addition to a 50% discount on all Lovehoney products to explore and discover new ways to have fun.

- Enjoy a hybrid work model that fosters flexibility and work-life balance, with three days per week in-office and the opportunity to work remotely for up to 4 weeks per year, alongside 25 days’ holiday, plus an additional day for each year you are with Lovehoney, providing ample time for relaxation, rejuvenation, and exploration.

- Access to customized training opportunities to support your unique learning journey, complemented by biannual feedback cycles, offering valuable insights into your performance and growth areas, enhancing your development within the company.

- Recognising the significance of physical and mental health, we proudly provide gym benefits in addition to a mental wellbeing platform, to ensure our employees thrive both professionally and personally.

- Stay secure at work and at home with a complimentary 1Password Family account. All Lovehoney Group employees can invite up to five family members to join, offering your household a safe and simple way to manage passwords and sensitive information safely and easily.

**Our interview process**

- CV review

- Interview with one of our Talent Acquisition Team Members

- Hiring Manager Interview

- Hiring Team Interview

- Leadership Interview

Lovehoney Group is an equal opportunities employer. We promise that every qualified person will be evaluated according to skills regardless of age, disability, gender reassignment, marriage and civil partnership, pregnancy and maternity, race, religion or belief, sex, or sexual orientation.

If you require accommodations during the interview process due to a disability, please inform your Talent Acquisition Specialist so that we can ensure a smooth and inclusive experience for all candidates.

At Lovehoney Group, we embrace innovative technologies to enhance our recruitment process. We leverage artificial intelligence during screening interviews for CV reviews and note-taking. We prioritize transparency and respect your preferences, so you'll have the option to opt out of recording and AI-driven note-taking while still receiving full and fair consideration for the role.

We currently have a hybrid work model supporting a blend of in-office and remote work (3 days per week in-office).

If we sparked your interest and you are open to embarking on your professional path with us, please visit our Lovehoney careers page to apply: [https://jobs.eu.lever.co/lovehoneygroup](https://jobs.eu.lever.co/lovehoneygroup)

Our privacy policy is available here: [https://www.lovehoneygroup.com/privacy-policy/](https://www.lovehoneygroup.com/privacy-policy/)

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
