# Staff Engineer - Data Platform (m|w|d)

Posted: 2026-08-05T02:50:32Z

## Rejection

- Category: tech_stack
- Reason: role does not mention Go/Golang or PHP

Reliable pipelines, resilient infrastructure and a scalable data platform are the foundation of every data-driven decision at idealo. As we accelerate toward real-time analytics, personalization and data monetization, the Data Platform is the engine that makes it possible. As a Staff Engineer, you’ll shape the technical foundation of the platform that thousands of daily data workloads depend on—and drive the strategic initiatives that will define what it can do next.

This role combines platform engineering, cloud architecture and data engineering. You’ll influence how workloads are orchestrated across the platform, how infrastructure scales with demand and how technical decisions support idealo’s long-term data strategy.

You’ll work in a modern engineering environment where state-of-the-art AI tooling—such as Claude Code—is available to accelerate your day-to-day work.

### About your new role

-

Architect and develop cloud-native platform components, infrastructure automation and pipeline frameworks, with a strong focus on performance, security and maintainability.

-

Lead technical initiatives within and across the team to align platform capabilities with business and product needs. Identify technical risks early and keep architecture decisions and technical concepts traceable across project phases.

-

Drive continuous improvements across CI/CD pipelines, infrastructure as code, observability and monitoring. Structure technology choices as clear trade-offs—evaluating performance, cost, maintainability and integration—to inform strategic decisions.

-

You’ll play a key role in shaping two of idealo’s most strategic platform initiatives: Personalization and Data-as-a-Service (DaaS).

-

For Personalization, you’ll define and build a next-generation, privacy-first platform from the ground up, establishing the technical vision, architecture and engineering standards that enable highly relevant experiences across the entire customer journey for millions of users.

-

In parallel, you’ll drive the evolution of our DaaS platform by researching, prototyping and validating new capabilities around real-time data processing, streaming technologies such as Kafka and Kinesis, and ML/AI integration. You’ll build scalable data products that enable data monetization and create new business opportunities.

-

Working across Data Engineering, Software Engineering, Cloud, Platform, Product and Machine Learning teams, you’ll align technical direction, tackle complex cross-functional challenges and turn early concepts into production-ready platforms that will shape idealo’s long-term technology and data strategy.

-

Mentor engineers through technical guidance, architecture discussions and code reviews, fostering a collaborative engineering culture focused on sustainable technical excellence.

### **Skills & Requirements**

-

You have built and operated cloud-native platforms on AWS, with a strong focus on software and infrastructure engineering, distributed systems and operational excellence.

-

You have hands-on experience with AWS services including Glue Catalog, Glue ETL with PySpark, S3, Lake Formation, Kafka, Kinesis, Lambda, ECS or EKS, and CloudWatch.

-

You have used infrastructure-as-code tooling such as Terraform, AWS CDK or CloudFormation, as well as GitHub and GitHub Actions.

-

Familiarity with SageMaker and Bedrock AgentCore is a plus.

-

You have experience with workflow orchestration and data pipeline frameworks, ideally including Airflow or Astronomer.

-

You have worked with PySpark or comparable distributed processing frameworks in Python.

-

You have experience with containerization and orchestration technologies, including Docker and Kubernetes, as well as modern CI/CD practices and DevOps tooling.

-

You understand software quality, security and reliability practices, including authentication, encryption, automated testing and secure software development.

-

You understand data engineering concepts, including pipeline design, data modelling, ETL patterns, ML Ops, data quality and pipeline observability. You can use this knowledge to make sound architectural decisions and collaborate effectively with Data Engineers.

-

You are familiar with data governance and compliance topics, including GDPR, data lineage, metadata management and access control through IAM and RBAC. You can translate these topics into concrete platform requirements.

-

You have led complex technical initiatives, influenced architectural decisions and aligned engineering work across teams without formal people management responsibility.

-

You take ownership and independently drive topics forward. You speak up and challenge ideas constructively while remaining open to diverse perspectives.

### **At idealo you can expect**

-

**You want to further your education?** We take your personal development goals seriously and, in addition to our idealo Learning Hub, eLearning offerings (e.g., Udemy), coaching & mediation, we also offer you the opportunity to benefit individually from additional learning and development budget.

-

**And what about the office? **Our office in the heart of Berlin offers free organic breakfast, excellent free lunch (vegan and vegetarian), as well as free coffee, lemonades and after-work beer, in addition to the "standard foosball". It also has a fabulous rooftop terrace with view of the whole of berlin where you can network with colleagues from our group of companies.

-

**In need of additional support in any areas of your life?** We offer free counseling and support in all areas of life (professional, private, family, health, etc.) in cooperation with the [pme-Familienservice](https://mein.familienservice.de/en/).

-

**You want full flexibility on your way to work and beyond? **No problem with a job bike or Deutschlandticket - and it's environmentally friendly, too!

-

**Want to keep yourself fit?** We offer many different fitness and sports options, such as an Urban Sports or Gympass membership, to suit your personal needs.

-

**And what else is there?** Of course, success must be celebrated! In addition to team events, you can also expect big company events and other moments of organized connection with others in the company and your team throughout the year!

#LI-MR1

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
