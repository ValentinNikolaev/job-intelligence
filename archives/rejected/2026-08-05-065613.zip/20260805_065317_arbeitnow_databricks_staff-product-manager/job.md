# Staff Product Manager

Posted: 2026-08-05T02:56:19Z

## Rejection

- Category: tech_stack
- Reason: role does not mention Go/Golang or PHP

P-1345

You will be the Product Manager for the Databricks Runtime team in **Berlin**. The team works at the intersection of query processing, storage, infrastructure and data governance, all key components of the Databricks data intelligence platform. As the Product Manager, you will develop a deep understanding of modern cloud infrastructure, data governance solutions, and open source components, and gather requirements from customers. You will launch features that will impact how customers process petabytes of data every day and make it simpler for them to draw value from their data.

This role requires coordinating all product activities from vision to implementation, including engaging customers to understand their needs, developing long-term product strategy, defining product roadmaps, working with engineering to build those products, and coordinating with various internal stakeholders (both pre- and post-launch) to ensure product success.

**The impact you will have:**

- Own the end-to-end product management process

- Gather customer requirements, design features and collaborate with engineering to deliver a polished market-ready product

- Drive launches with product marketing through blog posts, release notes, webinars

- Define and measure OKRs for your products

- Drive the prioritization and development of features, measurably making it simpler and more cost effective for customers to govern and process petabytes of data.

**What we look for:**

- 6+ yrs of experience

- Bachelors degree in Computer Science or similar field

- Experience in Product Management (inbound, outbound, cross-functional processes)

- Technical skills

- Solid understanding of cloud infrastructure (AWS, Azure, GCP)

- Strong data analysis and operationalization skills (SQL, rollups, building operational dashboards)

**About Databricks**

Databricks is the Data and AI company. More than 20,000 organizations worldwide — including adidas, AT&T, Bayer, Block, Mastercard, Rivian, Unilever, and 70% of the Fortune 500 — rely on the Databricks Data + AI Platform to build and scale data and AI apps, analytics and agents. Headquartered in San Francisco with 30+ offices around the globe, Databricks offers a unified platform that includes Genie, Lakebase, Agent Bricks, Lakeflow, Lakehouse, and Unity Catalog. To learn more, follow Databricks on [LinkedIn](https://www.linkedin.com/company/databricks), [X](https://x.com/databricks), [YouTube](https://www.youtube.com/@Databricks), and [Instagram](https://www.instagram.com/databricksinc/?hl=en).

**Benefits

**At Databricks, we strive to provide comprehensive benefits and perks that meet the needs of all of our employees. For specific details on the benefits offered in your region click [here](https://docs.google.com/document/d/154un3e8Xav4BceOSlcYFZRGEuQI54xMxVydRwQn54eQ/edit?usp=sharing).

**Our Commitment to Diversity and Inclusion**

At Databricks, we are committed to fostering a diverse and inclusive culture where everyone can excel. We take great care to ensure that our hiring practices are inclusive and meet equal employment opportunity standards. Individuals looking for employment at Databricks are considered without regard to age, color, disability, ethnicity, family or marital status, gender identity or expression, language, national origin, physical and mental ability, political affiliation, race, religion, sexual orientation, socio-economic status, veteran status, and other protected characteristics.

**Compliance**

**If access to export-controlled technology or source code is required for performance of job duties, it is within Employer's discretion whether to apply for a U.S. government license for such positions, and Employer may decline to proceed with an applicant on this basis alone.**

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
