# Social Media Intern

Posted: 2026-08-04T23:40:48Z

## Rejection

- Category: location_requirement
- Reason: requires United States location

**Our mission is to enable everyone to build wealth**

We reinvent how trading and investing work by creating exceptional products people love.

Fostering a culture of excellence and high velocity is the key to our success.

Today, we serve over 5 million clients, with more than €30 billion in assets under management - a testament to the scale and trust we’ve built in just a few years.

We are looking for a Social Media Marketing Intern to support the growth and day-to-day management of our German-language social media presence.

The role is suited to a native German speaker with strong social media taste, an understanding of current platform trends, and practical experience managing corporate social media accounts.

The person will help to create platform-native content, draft and schedule posts, support short-form video production, and coordinate Legal and Compliance review by preparing and submitting content approval tickets.

**What you'll do**

-

Manage and grow Trading 212's German-language social media accounts.

-

Drive growth through creation of social media posts, captions, short-form videos.

-

Analyze social media trends and competitor activity in the fintech space.

-

Engage in video content creation for Instagram and TikTok.

-

Improve account performance, engagement, audience growth, and content learnings.

-

Contribute ideas for organic growth campaigns and community engagement.

**What you need to have**

-

Native German speaker with excellent communication skills.

-

Strong interest in social media, content trends, creator formats, and storytelling.

-

Previous experience in managing (corporate) social media accounts.

-

Good understanding of Instagram, TikTok, LinkedIn, and short-form video formats.

-

Ability to write posts with the right tone for a regulated financial brand.

-

Strong attention to detail.

-

Ability to manage deadlines, review cycles, and multiple content pieces at once.

## **It’s a Bonus If You Have**

-

Experience scaling an Instagram account.

-

Experience creating or supporting "talking head" content for Instagram and TikTok.

-

Experience using social media scheduling, analytics, or project management tools.

## **What we offer**

-

A unique opportunity to be part of the team that builds our presence in Germany from the ground up.

-

Challenging projects with high impact on our international growth.

-

Collaboration with a team of smart, driven, and supportive high-performers.

-

A flexible, idea-friendly culture that values ownership and initiative.

-

Competitive Remuneration package.

Are you ready to accelerate your career with us? We'd love to hear from you!

We process applicant data confidentially and in accordance with applicable data protection laws. We may use AI-powered tools to help review applications, but all hiring decisions are made by our human recruitment team. Where required by law, we rely on your consent to use these tools.
You may withdraw this consent or exercise your data protection rights at any time by contacting us.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
