# AI Engineer

Posted: 2026-08-05T03:00:38Z

## Rejection

- Category: tech_stack
- Reason: role does not mention Go/Golang or PHP

### About the Role

We're a fast-moving, early-stage startup operating in the **AI-powered talent acquisition** space, and we're hiring **AI Engineers** to tackle two of our most critical technical challenges: scaling our backend infrastructure and optimizing the LLM and AI agent flows that power our core product. You'll join a small, high-agency engineering team where your work has direct and immediate impact on platform performance and user experience.

We're looking to bring on **1–2 exceptionally strong, startup-motivated engineers** who are passionate about building reliable, production-grade AI systems.

### What You'll Do

-

Take full ownership of backend scalability — design, build, and maintain services and systems that perform reliably at scale.

-

Tune, iterate on, and optimize LLM integrations and AI agent orchestration pipelines to improve reliability, efficiency, and output quality.

-

Collaborate closely with a fast-moving team, shipping meaningfully and often.

-

Contribute to shaping engineering culture and technical direction as an early team member.

### What We're Looking For

**Requirements (dealbreakers):**

-

Based in Stockholm, or legally eligible to work and willing to relocate to Stockholm — **no visa sponsorship available**.

-

5+ years of backend software engineering experience delivering scalable production systems.

-

Hands-on experience integrating LLMs and optimizing AI agent workflows in live production environments.

**Required skills & experience:**

-

Strong backend engineering fundamentals — you've built systems that scale and you've felt the pain of when they don't.

-

Practical experience shipping AI-driven features in production; you understand the nuances of LLM reliability and performance tuning.

-

Startup experience — you're comfortable with ambiguity, own your work end-to-end, and move fast without waiting for permission.

**Nice to have:**

-

A strong portfolio of side projects that demonstrates technical depth and sustained curiosity.

-

Experience building AI-driven features in a consumer or marketplace product context.

-

Background in fast-growing early-stage startups (pre-seed through Series A/B).

**We value** demonstrated ownership and high agency over formal credentials. A track record of consistently shipping software over time matters more to us than where you studied.

### Compensation & Benefits

-

**Salary:** $80,000 – $120,000 USD (with flexibility for exceptionally senior candidates)

-

**Equity:** Included; salary/equity mix is negotiable

### Location

-

**Stockholm, Sweden** — on-site

-

Candidates must be eligible to work in Sweden; **visa sponsorship is not available**

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
