# Projektentwickler - Westdeutschland (m/w/d)

Posted: 2026-08-05T02:41:02Z

## Rejection

- Category: tech_stack
- Reason: role does not mention Go/Golang or PHP

Q ENERGYs Ziel ist es, eine nachhaltige Welt mit grüner Energie zu ermöglichen. Unsere Unternehmenswerte - Verantwortung, Partnerschaft, Inklusive and "Changemaker" - sind die Grundlage für unser Handeln. Als Europas führender Anbieter von grünen Energielösungen sind wir ein vertrauenswürdiger Partner für das gesamte Spektrum der erneuerbaren Energien. Unser Ziel ist es, die Welt mit Solar-, Wind- und Hybridkraftwerken, innovativen Speicherlösungen und visionären grünen Wasserstoffprojekten neu zu definieren. 

**Begleite uns auf dieser spannenden Reise, um unseren Planeten nachhaltig zu verändern.**

- Du identifizierst potenzielle Standorte für PV, Wind oder Großbatteriespeicherprojekte unter Berücksichtigung von technischen, rechtlichen, umweltbezogenen und wirtschaftlichen Kriterien.
- Du koordinierst und leitest Genehmigungsverfahren und behördliche Genehmigungsprozesse.
- Du arbeitest mit technischen Teams zusammen, um Projektkonzepte und technische Spezifikationen für deine Projekte zu entwickeln.
- Du führst Finanzanalysen durch, unterstützt durch das Projektfinanzierungsteam.
- Du baust Beziehungen zu internen und externen Stakeholdern auf und pflegst sie, einschließlich Regierungsbehörden Netzbetreibern, Gemeinden und Landeignern.
- Du überwachst und analysierst Markttrends, die Wettbewerbslandschaft und regulatorische Entwicklungen im Bereich Erneuerbare Energien.

**Requirements**

- Du hast erfolgreich eine Ausbildung oder ein Studium abgeschlossen.
- Du hast Erfahrung in der Projektentwicklung für PV, Wind oder Energiespeichersysteme.
- Du hast Erfahrung in Genehmigungsverfahren und in der Kommunikation mit Behörden und weiteren Stakeholdern.
- Du verfügst über verhandlungssichere Deutsch- und Englischkenntnisse, weitere Sprachen sind von Vorteil

**Benefits**

- **Flexibler Arbeitsort:** Du hast die Möglichkeit, remote von zu Hause aus zu arbeiten. Zusätzlich steht dir unser modernes und nachhaltiges Büro in Berlin-Südkreuz zur Verfügung, das eine gute Anbindung und eine angenehme Arbeitsumgebung bietet.
- **IT-Ausstattung:** Wir stellen dir einen Laptop, Monitor, Kopfhörer und, falls erforderlich, ein Diensthandy zur Verfügung.
- **Work-Life-Balance:** Deine Zeit ist wertvoll! Gestalte deine Arbeitszeiten flexibel, damit du persönliche Termine wahrnehmen, früher ins Wochenende starten oder einfach das Leben besser mit der Arbeit in Einklang bringen kannst. Du entscheidest.
- **Spendit Card:** Monatlich **50 € zusätzlich zum Gehalt**, die du für dein tägliches Mittagessen nutzen oder unbegrenzt ansparen kannst.
- **Großzügige Urlaubsregelung:** Genieße **31 Urlaubstage** pro Jahr, um dich zu erholen, neue Energie zu tanken und die Welt zu entdecken.
- **Onboarding:** Mit einem strukturierten Onboarding-Prozess sorgen wir für einen reibungslosen Start und begleiten dich von Tag eins an, damit du dich gut aufgehoben fühlst.
- **Betriebliche Altersvorsorge:** Wir leisten einen monatlichen Beitrag von **13,29 €** zu deiner Altersvorsorge.
- **Versicherungsschutz:** Unfall- und Lebensversicherung sind inklusive – für deine Sicherheit und ein gutes Gefühl, sowohl im Job als auch privat.
- **Mitarbeiterrabatte:** Über unser Corporate Benefits-Programm erhältst du exklusive Rabatte auf zahlreiche Marken und Produkte.
- **Firmenwagen:** Falls du berechtigt bist und dein Job es erfordert, steht dir ein Firmenwagen zur Verfügung.
- **Betriebliches Gesundheitsmanagement:** Deine Gesundheit steht an erster Stelle! Profitiere von unserem Gesundheitsmanagement, inklusive Vorsorgeuntersuchungen, um fit und leistungsfähig zu bleiben.

Möchtest du Teil von **Q ENERGY** werden?

Dann freuen wir uns auf deine Bewerbung! Bitte teile uns dabei deine **Gehaltsvorstellung** sowie dein **frühestmögliches Startdatum** mit.

**Hinweis:** Wir akzeptieren keine Bewerbungen per E-Mail. Bitte nutze für deine Bewerbung den **„Jetzt bewerben“-Button**. Vielen Dank!

Bei Fragen steht dir unser Recruiting-Team gerne zur ----- ENERGY** ist ein international tätiges Unternehmen – bei uns arbeiten Menschen aus verschiedenen Nationen, Kulturen und Standorten partnerschaftlich zusammen und tauschen ihre Erfahrungen und Werte in einer offenen und kollegialen Atmosphäre aus.

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
