# Social Media Content Creator:in (m/w/d)

Posted: 2026-08-05T05:27:52Z

## Rejection

- Category: tech_stack
- Reason: role does not mention Go/Golang or PHP

📍 **Köln |** 🎬 **Vor Ort |** ⏱**️ ca. 20 Std./Woc**he

**

Wer wir sind**

fravio ist eine schnell wachsende, kreative Social Media Agentur mit Fokus auf Street Generated Content (SGC), Influencer Marketing und digitale Kampagnen. Wir arbeiten mit Top-Marken wie Wolt, Vodafone, MILES und XING – und mit einigen der bekanntesten Creators Deutschlands.

**Was dich erwartet**

Du arbeitest in unserem Produktionsteam und bist aktiv bei der Umsetzung unserer Street-Content-Formate – vor allem bei Straßenumfragen. Dabei bist du sowohl hinter als auch optional vor der Kamera aktiv: Von Vorbereitungen und Drehplanung bis hin zur Technik von Interviews bekommst du spannende Einblicke in moderne Social Media Produktionen.

## Aufgaben

**Deine Aufgaben**

- Unterstützung bei Straßenumfragen (Organisation, Drehbegleitung, Aufnahme)

- Technischer Support vor Ort (Kamera, Ton – nach Einarbeitung)

- Recherche und Vorbereitung von Interviewfragen & Themen

- Mitwirkung vor der Kamera als Teil unserer Straßenumfragen (z. B. als Interviewer:in oder im Dialog mit Passant:innen)

## Qualifikation

**Was du mitbringen solltest**

- Interesse an Social Media, Video-Content

- Spaß am Umgang mit Menschen & keine Scheu, auf Leute zuzugehen

- Idealerweise erste Erfahrung mit Kamera

- Selbstständige Arbeitsweise, Teamspirit & Zuverlässigkeit

- Du bist aktuell an einer Universität eingeschrieben

## Benefits

**Was wir dir bieten**

- Flexible Zeiteinteilung (nach Absprache mit dem Projektmanagement-Team)

- zentrales Office direkt in Köln

- Praxisnahe Einblicke in aktuelle Social Media Produktionen

- Ein motiviertes, offenes Team mit kreativen Ideen

- Remote-Optionen, moderne Ausstattung & ÖPNV-Zuschuss

**Ready to join fravio?**

Dann schick uns eine kurze Nachricht oder Bewerbung via LinkedIn oder E-Mail – wir freuen uns auf dich!

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
