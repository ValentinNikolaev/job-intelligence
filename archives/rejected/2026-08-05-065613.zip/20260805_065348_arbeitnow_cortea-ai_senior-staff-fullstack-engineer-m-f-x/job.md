# Senior/Staff Fullstack Engineer (m/f/x)

Posted: 2026-08-04T23:40:50Z

## Rejection

- Category: tech_stack
- Reason: role does not mention Go/Golang or PHP

# About us

We’re **Cortea**, a Berlin startup **transforming audits with AI**. Manual, document-heavy audits waste expert time while demand keeps rising. Our **AI-powered software and specialized AI agents** remove the repetitive work so auditors can focus on judgment.

Backed by top-tier VCs with >15m funding, with a working product and paying customers, we’re rapidly scaling.

We value **first-principles thinking, speed, trust, and kindness**. We build side by side **in our Berlin office**.

## Your Role

We're looking for an **experienced engineer who's happy anywhere in the stack** and turns complex audit workflows into product auditors rely on every day. You pick up whatever a problem needs, from the data model to the interface to the agents behind it.

A lot of what we build has no reference implementation. You're **comfortable wading into something nobody has solved yet** and shipping a first version that actually works.

Our engineering team is a **small, flat group of builders**: strong ICs who open a laptop when they see a problem instead of scheduling a meeting. Everyone owns real product and architecture decisions, and that's exactly what we want more of.

## What you'll do

-

Build the interfaces auditors work in, partnering with design to turn complex flows into something that feels effortless

-

Build and improve the agents at the core of the product, plus the harnesses and eval pipelines around them

-

Make the long-running workflows behind the product reliable and debuggable, so failures surface fast instead of silently

-

Use AI heavily in your own workflow to move faster, without ever shipping output you can't stand behind

-

Drive the how in RFCs and technical discussions with other engineers, and partner with product on the what

## Qualifications

You'll fit here if you:

-

Have 5+ years shipping production web applications across the stack

-

Write production APIs and model the data behind them so it holds up under multi-tenancy and load

-

Are strong on the frontend and can build genuinely complex UI

-

Get how LLM agents actually work: agents, harnesses, tool use, and measuring quality with evals

-

Keep up with where AI is moving and bring the latest tools into how you work to make yourself faster

-

Bring a strong product mindset and real ownership of outcomes

-

Make architectural decisions, weigh trade-offs, and build things other engineers can extend

-

Are comfortable with ambiguity and work things out from fundamentals when there's no established answer

Nice-to-haves that are a plus:

-

Hands-on experience building agents, harnesses, or eval pipelines

-

Data-dense or workflow-heavy B2B products

-

Scaling multi-tenant systems as data and traffic grow

-

Audit, finance, compliance, or another domain where being wrong is expensive

-

Early-stage startup or fast-moving engineering environment

**No one checks every box. If you ship across frontend, backend, and data and own what you build, let's talk.**

## Our tech

-

React, TS, Tailwind, TanStack

-

Python, Postgres, Temporal, Kafka, Redis

-

GCP, Azure, k8s

-

GitHub, Linear, Slack, Notion

# **What We Offer**

-

**High impact & growth:** Front-row seat to scaling an AI startup with real ownership from day one

-

**Mission-driven culture:** First-principles thinking, bold ideas, and a supportive team

-

**Attractive compensation:** competitive salary + meaningful equity

-

**Personal development:** Learning budget for courses and conferences

-

**True Berlin startup environment:** Central Berlin office, team lunches, retreats, flexible vacation

# **Interview process**

-

**First Call** — Intro to Cortea with our Founders Associate Liza

-

**Second Call** — Technical interview with our Member of Technical Staff Jendrik

-

**Third Call** — Deep dive into our culture with our Co-Founder Philipp

-

**On-site Half-Day (Berlin) **— Meet the team and work on a real problem together

##

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
