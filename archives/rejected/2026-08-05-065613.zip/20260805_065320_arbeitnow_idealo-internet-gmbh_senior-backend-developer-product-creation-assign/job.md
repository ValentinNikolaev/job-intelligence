# (Senior) Backend Developer – Product Creation & Assignment (m/w/d)

Posted: 2026-08-05T02:50:32Z

## Rejection

- Category: language_requirement
- Reason: hard German language requirement without English green light

Als **(Senior) Backend Developer im Product Creation & Assignment Team** hilfst du uns dabei, die Systeme hinter der automatisierten Erweiterung des idealo Produktkatalogs weiterzuentwickeln.

Bei idealo sind Produkte die vergleichbaren Einheiten, die Nutzer*innen auf unserer Plattform sehen: Produktseiten, auf denen Angebote verschiedener Shops gebündelt, angereichert und vergleichbar gemacht werden. Unser Team baut Systeme, die neue Produkte aus verschiedenen Datenquellen identifizieren und erstellen sowie eingehende Shop-Angebote dem passenden bestehenden oder neu erstellten Produkt zuordnen.

Wir arbeiten mit einem modernen, cloud-nativen Stack, der JVM-basierte Backend-Services mit datenintensiven AWS-Workflows kombiniert: **Java, Kotlin, Spring Boot, Kafka, MongoDB und EKS** sowie **Python-basierte Pipelines** mit **MWAA, Lambda, Step Functions, DynamoDB, Glue Spark und S3**. Außerdem integrieren wir ML-Modelle und GenAI-Komponenten in unsere Produktionssysteme und nutzen aktiv AI-Tools wie **Claude Code** in unserem Entwicklungsworkflow.

### Deine Aufgaben

-

Du entwickelst und betreibst Backend-Services und Data Workflows für die automatisierte Erweiterung des Produktkatalogs und die Offer-Zuordnung – mit Verantwortung über den gesamten Lifecycle hinweg, von der Architektur bis zur Produktion.

-

Du arbeitest an Systemen, die neue Produkte aus verschiedenen Datenquellen identifizieren, erstellen und anreichern, und verbesserst die Matching-Logik, die Shop-Angebote mit den passenden idealo Produkten verknüpft.

-

Du arbeitest mit unserem Core Stack: Java/Kotlin, Spring Boot, Kafka, AWS, Kubernetes/EKS und Python-basierten Pipelines wie MWAA, Lambda, Step Functions und Glue Spark.

-

Du stellst eine hohe Softwarequalität durch automatisierte Tests, Code Reviews und Observability sicher und setzt AI-gestützte Entwicklungstools bewusst und reflektiert ein.

-

Du arbeitest eng mit Engineering, Product und Machine Learning Engineering zusammen und teilst Wissen durch Reviews, Pairing und Dokumentation.

### Das bringst du mit

-

Du bringst mehrjährige Erfahrung in der Backend-, Plattform- oder datenintensiven Softwareentwicklung mit und hast bereits Verantwortung für Produktionssysteme übernommen.

-

Du hast fundierte praktische Erfahrung in der JVM-Backend-Entwicklung mit Java oder Kotlin, idealerweise mit Spring Boot, oder in Python-basierten Data Workflows. Gleichzeitig hast du gutes Arbeitswissen im jeweils anderen Bereich und die Bereitschaft, über beide Stacks hinweg mitzuarbeiten.

-

Du hast Erfahrung im Betrieb von Services in cloud-nativen Umgebungen, idealerweise mit AWS, Kubernetes, Docker oder serverless Komponenten.

-

Du bist vertraut mit eventgetriebenen oder workflow-basierten Architekturen, zum Beispiel Kafka, Step Functions, MWAA/Airflow oder ETL-ähnlichen Pipelines.

-

Du kommunizierst klar, arbeitest effektiv in cross-funktionalen Teams und sprichst fließend Englisch. Deutschkenntnisse sind ein Plus.

-

Du hinterfragst Annahmen respektvoll und nutzt Daten sowie nachvollziehbare Argumente, um Ideen zu diskutieren. Sobald eine Entscheidung getroffen wurde, unterstützt du sie verbindlich, um Alignment und Momentum im Team sicherzustellen.

Du erfüllst nicht alle Kriterien? Keine Sorge, wir suchen Mitarbeiter:innen, die uns mit ihrer Persönlichkeit überzeugen und motiviert sind, gemeinsam mit ihrem Team alles zu geben!

### **Bei idealo erwartet dich**

-

**Du willst dich weiterbilden? **Wir nehmen deine persönlichen Entwicklungsziele ernst und bieten dir neben unserem idealo Learning Hub, eLearning Angeboten (z.B. Udemy), Coachings & Mediation auch die Möglichkeit individuell von unserem Weiterbildungsbudget zu profitieren.

-

**Und was kann das Büro? **Unser Büro, im Herzen Berlins, bietet neben dem “Standard-Kicker” auch hervorragendes kostenfreies Mittagessen, sowie kostenfreien Kaffee, Limonade und Feierabend-Bier. Dabei kannst du auf unserer wunderschönen Dachterrasse mit Kolleg:innen aus unserer Unternehmensgruppe netzwerken.

-

**Du wünschst dir Unterstützung auch außerhalb der Arbeit? **Eine kostenlose Beratung, sowie Unterstützung in allen Lebenslagen (beruflich, privat, familiär, gesundheitlich etc.) bieten wir in Zusammenarbeit mit dem [pme-Familienservice](https://mein.familienservice.de/).

-

**Du willst auch mobil sein?** Mit Job-Bike oder Deutschlandticket kein Problem – und das ist auch noch umweltfreundlich!

-

**Du möchtest dich fit halten? **Hierzu bieten wir dir viele unterschiedliche Fitness- und Sportmöglichkeiten wie zum Beispiel eine Urban Sports oder Gympass Mitgliedschaft für deine ganz persönlichen Bedürfnisse an.

-

**Und was gibt es noch? **Selbstverständlich müssen Erfolge gefeiert werden! Neben Team-Events erwarten dich auch große Company-Events, bei denen wir keine Kosten und Mühen scheuen.

#LI-MR1

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
