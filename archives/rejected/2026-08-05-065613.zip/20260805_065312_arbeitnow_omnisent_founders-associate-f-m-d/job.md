# FOUNDERS ASSOCIATE (f/m/d)

Posted: 2026-08-05T05:27:53Z

## Rejection

- Category: tech_stack
- Reason: role does not mention Go/Golang or PHP

Founded in 2025, Omnisent is a Munich-based defense technology company developing fully autonomous, Counter-UAS system. We are a small, high-output team from Cambridge, Imperial College, MIT, and BCG united by a mission to redefine modern airspace security.

## Aufgaben

We are looking for a **Founders Associate** to work directly with our Co-Founders and Chief of Staff across strategy, business development, operations, and special projects. This is a generalist role for someone who thrives in ambiguity, moves fast, and wants to be at the center of building a category-defining defense technology company.

You will own high-priority projects, from market entry and investor materials to government procurement processes and operational build-out.

- Work directly with the CEO and Chief of Staff on strategic priorities and company-building initiatives

- Drive business development efforts across defense and government markets, including research, outreach, and meeting preparation

- Own and manage cross-functional projects from scoping to execution, export control processes, accelerator applications, partnership development

- Prepare investor materials, pitch decks, and external-facing documents to a high standard

- Conduct market and competitive research to support strategic decisions

- Support operational build-out as we scale, processes, tools, hiring, and internal coordination

- Represent Omnisent professionally in external communications with government bodies, partners, and investors

## Qualifikation

- 1–3 years of experience in consulting, investment banking, venture capital, or a fast-paced startup environment

- Exceptional written and verbal communication skills in English (German a strong plus)

- Structured thinker who can synthesize complex information quickly and turn it into clear outputs

- High ownership mentality, you follow through, hit deadlines, and don't wait to be told what to do

- Comfortable operating with ambiguity and switching between strategic and operational tasks

- Genuine interest in defense technology, deep tech, or hardware startups

- EU work authorization

**Bonus:**

- Prior experience in defense, government, or dual-use technology sectors

- Exposure to export control, procurement, or regulatory processes

- Experience supporting fundraising or investor relations

## Benefits

- Competitive Compensation: Highly competitive cash comp, along with virtual stock options, that reflect your experience and the value you bring

- Accelerated Learning & Growth: Join a fast-paced environment where you’ll take on real responsibility, overcome meaningful challenges, and grow alongside a driven team

- Make a Real Impact: Play a key role in shaping Omnisent’s journey and contribute directly to the success of the company

*In your cover letter, we’d love to hear about your personal interests, what drives you, why this role feels like the right fit, and most importantly, why Omnisent.*

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
