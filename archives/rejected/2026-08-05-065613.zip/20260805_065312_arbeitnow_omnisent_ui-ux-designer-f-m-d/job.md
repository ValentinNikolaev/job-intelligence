# UI/UX DESIGNER (f/m/d)

Posted: 2026-08-05T05:27:53Z

## Rejection

- Category: tech_stack
- Reason: role does not mention Go/Golang or PHP

Founded in 2025, Omnisent is a Munich-based defense technology company developing fully autonomous, Counter-UAS system. We are a small, high-output team from Cambridge, Imperial College, MIT, and BCG united by a mission to redefine modern airspace security.

## Aufgaben

We are looking for a UI/UX Designer to shape how operators interact with OmniDome, translating complex sensor and detection data into clear, intuitive interfaces.

- Design user interfaces for Omnisent's operator dashboards and control systems

- Translate complex technical and sensor data into clear, intuitive visual designs

- Create graphic assets and visual design systems across product and external-facing materials

- Collaborate closely with software and ML engineers to ensure designs are technically feasible and usable in the field

## Qualifikation

- Strong portfolio of UI design work, ideally for technical or data-heavy products

- Skilled in modern design tools (e.g., Figma) and translating designs into implementable specs

- Ability to simplify complex information into clear, usable interfaces

- Comfortable working closely with engineers in a fast-paced startup environment

- EU work authorization

**Bonus:**

- Experience designing defense, industrial, or other mission-critical software

- Experience with motion design or interactive prototyping

## Benefits

- **Competitive Compensation:** Highly competitive cash comp, along with virtual stock options, that reflect your experience and the value you bring

- **Accelerated Learning & Growth:** Join a fast-paced environment where you'll take on real responsibility, overcome meaningful challenges, and grow alongside a driven team

- **Make a Real Impact:** Play a key role in shaping Omnisent's journey and contribute directly to the success of the company

*In your cover letter, we'd love to hear about your personal interests, what drives you, why this role feels like the right fit, and most importantly, why Omnisent.*

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
