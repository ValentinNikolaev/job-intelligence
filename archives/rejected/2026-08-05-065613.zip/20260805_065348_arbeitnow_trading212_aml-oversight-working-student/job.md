# AML Oversight Working Student

Posted: 2026-08-04T23:40:48Z

## Rejection

- Category: location_requirement
- Reason: requires United States location

**Our mission is to enable everyone to build wealth**

We reinvent how trading and investing work by creating exceptional products people love.

Fostering a culture of excellence and high velocity is the key to our success.

Over the past few years, our client base has grown to over 4.5 million and client assets to over €30 billion.

We're now expanding our presence in Germany, and strengthening our AML team. As an AML Oversight Associate, you will help build and maintain a rigorous Oversight, Quality Control and Assurance programme, in fulfilment of our regulatory compliance, internal/external oversight, critical outsourcing, and audit requirements.

**What you'll do**

-

Oversight of the Transaction Monitoring and the screening programme, and completion of alert checking;

-

Undertaking ECDD, OCDD, PEPs, Sanctions and adverse media reviews when directed by MLRO/DMLRO;

-

Creating and maintaining MI data in relation to the oversight programme;

-

Stay informed on any changes to AML/CTF laws, regulations, and best practices;

-

Assist with FIU SAR reporting, as and when required;

-

Assist in updating Trading 212’s AML Program and relevant procedures;

-

Assist drafting periodic compliance reporting for Senior Management, the Risk & Compliance Committee and the Board as required.

**What you need to have**

-

You are currently pursuing a bachelor’s or master’s degree.

-

Interest in Oversight, QC/QA, AFC, AML, Fraud, or related areas within fintech; prior experience is a plus.

-

Analytical Skills: Comfortable with data-driven decision-making and problem-solving, delivering comparable and useful MI to internal and external stakeholders.

-

Stakeholder management: Ability to work with multiple stakeholders, with competing priorities, to ensure alignment of the German oversight programme with the Group.

-

Mindset: Proactive, curious, and structured, with a strong sense of integrity and ownership.

-

Communication: Fluent in English and German; Other European languages are a plus.

-

Tools: Experience with quantitative analysis, familiarity with office software such as Excel/Google Sheets. Knowledge of SQL and experience with self-service BI software are a plus.

-

Availability: Available 20 hours per week, with at least two semesters remaining in your studies

# **What we offer**

-

A unique opportunity to be part of the team that builds our presence in Germany from the ground up.

-

Challenging projects with high impact on our international growth.

-

Collaboration with a team of smart, driven, and supportive high-performers.

-

A flexible, idea-friendly culture that values ownership and initiative.

-

Competitive Remuneration package.

Are you ready to accelerate your career with us? We'd love to hear from you!

We thank all applicants, but only candidates selected for an interview will be contacted.

All personal data of applicants is protected by the law and will be treated with strict confidentiality.

Are you ready to accelerate your career with us? We'd love to hear from you!

We process applicant data confidentially and in accordance with applicable data protection laws. We may use AI-powered tools to help review applications, but all hiring decisions are made by our human recruitment team. Where required by law, we rely on your consent to use these tools.
You may withdraw this consent or exercise your data protection rights at any time by contacting us.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
