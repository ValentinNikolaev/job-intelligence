# FORWARD DEPLOYED ENGINEER (f/m/d)

Posted: 2026-08-05T05:27:52Z

## Rejection

- Category: tech_stack
- Reason: role does not mention Go/Golang or PHP

Founded in 2025, Omnisent is a Munich-based defense technology company developing fully autonomous, Counter-UAS system. We are a small, high-output team from Cambridge, Imperial College, MIT, and BCG united by a mission to redefine modern airspace security.

## Aufgaben

We are looking for a Forward Deployed Engineer to own the technical relationship with our customers on the ground – embedding directly with defense and government customers to integrate, adapt, and evolve OmniDome in real operational environments.

- Own the technical relationship with customers in the field, acting as the primary engineering point of contact on-site

- Integrate OmniDome with customer systems and infrastructure, incl. C2 platforms, and existing sensors

- Rapidly build and adapt software tools and configurations to solve customer-specific problems in the field

- Translate operational feedback and requirements from the field directly into product and engineering priorities

- Debug and resolve technical issues on-site, working directly with hardware, software, and ML teams back at HQ

- Travel to customer sites, including active operational environments, to support deployments and integrations

- Continuously improve OmniDome based on firsthand exposure to real-world deployment conditions

## Qualifikation

- Strong software engineering background – comfortable writing and debugging production-quality code

- Experience working directly with customers in a technical capacity (integration, solutions engineering, or similar)

- Comfortable operating with ambiguity, in the field, without a rigid playbook

- Strong communication skills – able to translate between customer needs and internal engineering priorities

- Willingness to travel extensively, including to demanding or contested environments

- EU work authorization

**Bonus:**

- Experience as a Forward Deployed Engineer, Solutions Engineer, or similar customer-facing technical role

- Background in defense, government, or other high-stakes operational environments

- Experience integrating software with hardware or sensor systems in the field

## Benefits

- **Competitive Compensation:** Highly competitive cash comp, along with virtual stock options, that reflect your experience and the value you bring

- **Accelerated Learning & Growth:** Join a fast-paced environment where you'll take on real responsibility, overcome meaningful challenges, and grow alongside a driven team

- **Make a Real Impact:** Play a key role in shaping Omnisent's journey and contribute directly to the success of the company

*In your cover letter, we'd love to hear about your personal interests, what drives you, why this role feels like the right fit, and most importantly, why Omnisent.*

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
