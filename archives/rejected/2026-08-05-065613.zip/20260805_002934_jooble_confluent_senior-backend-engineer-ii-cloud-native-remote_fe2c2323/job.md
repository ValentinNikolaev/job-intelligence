# Senior Backend Engineer II - Cloud-Native, Remote

Posted: 2026-08-01T00:00:00.0000000

## Rejection

- Category: tech_stack
- Reason: role does not mention Go/Golang or PHP

A leading data streaming platform company is seeking a **Senior **Software **Engineer **II to lead **backend **systems design and implementation. Candidates should have 5+ years of experience and proficiency in major backend programming languages. The role involves mentoring, making...
