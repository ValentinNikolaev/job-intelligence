# Machine Learning Engineer

Posted: 2026-08-05T00:01:58Z

## Rejection

- Category: tech_stack
- Reason: role does not mention Go/Golang or PHP

sensmore automates the world's largest machines with unprecedented intelligence. Our proprietary Physical AI enables heavy machines such as wheel loaders to instantly adapt to dynamic environments and execute new tasks without prior training.

We integrate cutting-edge robotics into a platform powering intelligence and automation products - transforming productivity and safety for customers in mining, construction, and adjacent industries today.

Join us and play a pivotal role in transforming the automation landscape in heavy industries.

**Role Overview:**
We are looking for a skilled Machine Learning Engineer with expertise in perception to strengthen our team. This role requires a strong background in computer vision, deep learning, and multimodal sensor fusion. The successful candidate will lead the development of real-time perception systems that enable autonomous heavy machinery to understand and operate in harsh, unstructured environments.

**Key Responsibilities:**

-

Design and implement deep learning models for 3D perception, including object detection, semantic segmentation, and occupancy prediction.

-

Develop and optimise multimodal networks fusing LiDAR, radar, and camera data for off-highway autonomous vehicles.

-

Contribute to Vision-Language-Action (VLA) models integrating perception and language inputs for physical AI.

-

Optimise training and inference pipelines for real-time deployment on NVIDIA edge GPUs.

-

Lead data initiatives for the perception stack, from data pipelines and curation to model evaluation.

-

Collaborate with interdisciplinary teams to integrate perception systems into the full autonomy stack.

**Required Qualifications:**

-

Master's or PhD in Computer Science, Robotics, Electrical Engineering, or a related field.

-

Proficient in Python; strong experience with PyTorch.

-

Deep expertise in 3D perception and sensor fusion (LiDAR-camera-radar).

-

Practical experience deploying deep learning models in real time on embedded hardware (TensorRT, ONNX, Jetson/Orin).

-

Solid understanding of machine learning, deep learning, and autonomous systems.

**Preferred Skills:**

-

Experience with transformer-based perception architectures or VLA models.

-

Familiarity with BEV perception and multitask learning.

-

Experience with C++, ROS, and mmdetection.

-

Experience with perception in off-road, adverse-weather, or otherwise challenging conditions.

-

Proven track record of publications or significant industry experience in deep learning for autonomous driving or robotics.

## **What We Offer:**

-

Build physical AI for the world's largest off-highway machinery – making them intelligent, safe, and ready for every tough task

-

Join the pioneer in intelligent robotics backed by Point Nine & other Tier 1 investors

-

Combine cutting-edge robotics research in end-to-end learning & Vision Language Action Model with real-world heavy mobile equipment

-

Tailor your own career path, whether you like to become technical specialist or technical team lead

-

Experience a great team culture, beverages, and an amazing office environment

##
**Benefits:**

-

Attractive compensation package and stock options.

-

Beverages on-site and regular social events.

-

Engage with top-tier researchers, engineers, and thought leaders.

-

Influence the future of robotic technologies and tackle significant technological challenges.

-

Assistance with relocation to Berlin.

##
**About Us:**

Heavy machinery, light years ahead.

sensmore automates the world's largest machines with unprecedented intelligence. Our proprietary Physical AI enables heavy machines such as wheel loaders to instantly adapt to dynamic environments and execute new tasks without prior training.

We integrate cutting-edge robotics into a platform powering intelligence and automation products - transforming productivity and safety for customers in mining, construction, and adjacent industries today.

We are proudly backed by Point Nine and other Tier 1 investors.

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
