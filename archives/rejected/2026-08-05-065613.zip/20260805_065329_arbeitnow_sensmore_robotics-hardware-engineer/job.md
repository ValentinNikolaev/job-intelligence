# Robotics Hardware Engineer

Posted: 2026-08-05T00:01:58Z

## Rejection

- Category: tech_stack
- Reason: role does not mention Go/Golang or PHP

sensmore automates the world's largest machines with unprecedented intelligence. Our proprietary Physical AI enables heavy machines such as wheel loaders to instantly adapt to dynamic environments and execute new tasks without prior training.

We integrate cutting-edge robotics into a platform powering intelligence and automation products - transforming productivity and safety for customers in mining, construction, and adjacent industries today.

Join us and play a pivotal role in transforming the automation landscape in heavy industries.

**Role Overview**

We are seeking an innovative Robotics Hardware Engineer specializing in robotics integration, robotic sensors, and electronics for harsh production environments. This role focuses on the design, development, and integration of electrical-mechanical systems that drive advanced robotics. The ideal candidate will have expertise in integrating multiple sensors for autonomy in real machines and efficiency in bridging hardware with software for reliable and scalable robotic systems.

**Key Responsibilities**

-

Integrate and optimize robotic sensors (e.g., LiDAR, Radar, cameras, IMUs) into autonomous systems, ensuring accurate data acquisition and processing.

-

Design the mechanical integration of multiple sensors and compute on the real world machine.

-

Lead the electrical/mechanical engineering efforts in robotics production, focusing on manufacturability and scalability of hardware designs.

-

Develop and validate hardware-electronic integration frameworks to streamline communication between actuators, sensors, and control units.

-

Collaborate with software engineers to design cohesive systems, ensuring compatibility and performance.

-

Troubleshoot and optimize complex systems on the field, addressing EMI, power management, and signal integrity issues.

-

Participate in all product development phases, from initial concept through prototyping, testing, and mass production.

**Required Qualifications**

-

Bachelor’s or Master’s degree in Electrical/Mechanical/Mechatronics Engineering, Robotics, or a related field.

-

Knowledge of deploying electronics hardware in adverse conditions and implementing robust power and data transfer.

-

Experience in designing and integrating robotic sensors with hardware and software.

-

Proficiency in CAD/CAM tools for mechanical and electrical design, including 3D printing & prototyping.

-

Hands-on experience with rugged industrial/automotive connectors and wire harness design.

-

Solid understanding of embedded systems, microcontrollers, and communication protocols (e.g., CAN, I2C, SPI).

-

Strong analytical skills with a proven track record of solving complex electrical and integration challenges.

**Preferred Skills**

-

Familiarity with industrial robotic platforms and autonomy systems.

-

Proficient in programming languages like Python, C++, or firmware development for embedded systems.

-

Practical understanding of actuators, motors, and closed-loop control systems.

-

Knowledge of production techniques, including assembly, testing, and quality assurance.

-

Proven ability to work in agile and fast-paced development environments.
Swiss-knife attitude from hands on tasks to high level designs

## **What We Offer:**

-

Build physical AI for the world's largest off-highway machinery – making them intelligent, safe, and ready for every tough task

-

Join the pioneer in intelligent robotics backed by Point Nine & other Tier 1 investors

-

Combine cutting-edge robotics research in end-to-end learning & Vision Language Action Model with real-world heavy mobile equipment

-

Tailor your own career path, whether you like to become technical specialist or technical team lead

-

Experience a great team culture, beverages, and an amazing office environment

##
**Benefits:**

-

Attractive compensation package and stock options.

-

Beverages on-site and regular social events.

-

Engage with top-tier researchers, engineers, and thought leaders.

-

Influence the future of robotic technologies and tackle significant technological challenges.

-

Assistance with relocation to Berlin.

##
**About Us:**

Heavy machinery, light years ahead.

sensmore automates the world's largest machines with unprecedented intelligence. Our proprietary Physical AI enables heavy machines such as wheel loaders to instantly adapt to dynamic environments and execute new tasks without prior training.

We integrate cutting-edge robotics into a platform powering intelligence and automation products - transforming productivity and safety for customers in mining, construction, and adjacent industries today.

We are proudly backed by Point Nine and other Tier 1 investors.

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
