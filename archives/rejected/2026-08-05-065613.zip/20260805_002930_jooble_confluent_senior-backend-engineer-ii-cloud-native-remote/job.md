# Senior Backend Engineer II - Cloud-Native, Remote

Posted: 2026-08-03T00:00:00.0000000

## Rejection

- Category: tech_stack
- Reason: role does not mention Go/Golang or PHP

A leading data streaming company is seeking a **Senior **Software **Engineer **II to take ownership of **backend **systems critical to their platform. Candidates should have over 5 years of experience and be proficient in major backend languages. Responsibilities include leading complex...
