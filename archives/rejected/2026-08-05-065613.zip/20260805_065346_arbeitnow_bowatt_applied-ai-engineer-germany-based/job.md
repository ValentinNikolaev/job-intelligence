# Applied AI Engineer (Germany-based)

Posted: 2026-08-04T23:41:07Z

## Rejection

- Category: tech_stack
- Reason: role does not mention Go/Golang or PHP

**About BoWatt**

BoWatt is building **agentic requirements and system engineering software for manufacturing**.

We believe AI will reach **PhD-level engineering capability within the next 10 years**.

This will unlock massive value across several complex manufacturing industries.

Cars. Planes. Rockets. Factories. Chips. Medical devices. All will be engineered with agents.

We bootstrapped BoWatt to **€500k+ ARR** before raising our first round.

BoWatt is backed by **tier-1 investors,** including Atlantic Foodlabs, Buildery (CDTM affiliates), and Prequel Ventures, along with angels from Cohere and Luminovo.

You’ll join a small, exceptional team of startup builders, driven by innovation and execution.

Over half the team are former founders across DeepTech AI, psychedelics, and gaming.

We’ve studied and worked at top institutions and companies like **Stanford**, **TUM**, **Google**, **EA**, and **YC**-backed AI startups.

**The role**

Partner with Martin (AI Engineer) on agentic workflows, LLM integrations, and the next generation of AI capabilities at BoWatt.

-

Design and implement AI-powered features using existing large language models

-

Collaborate with stakeholders to identify use cases where AI can improve customer experience

-

Building multi-step agent workflows that reason over requirements documents and system specs

-

Integrate AI systems with internal data sources, expanding agent knowledge

-

Work with the engineering team to deploy AI features into production environments

**You**

-

Have 3+ years of software engineering experience, including at least 1 year working with LLMs

-

Have a strong interest in agentic technologies and techniques

-

Are experienced with integrating AI capabilities in previous roles, preferably having worked with a variety of AI APIs, tools, and frameworks

-

Are comfortable owning your implementations end to end, learning the tools you need for tasks as you go

-

Are knowledgeable about security, data privacy, and data hygiene, especially surrounding agent integration

-

Thrive in a startup environment with a lot of creative freedom

-

Are based in Germany and have the right to work here

**Nice to have**

-

Experience with vector databases like Qdrant, Weaviate, pgvector etc

-

Experience with LLM orchestration frameworks such as LangChain or LlamaIndex

-

Experience in Azure AI Foundry and other Azure products

-

Have experience with React or a similar modern web technology (e.g. Vue, Svelte)

**What we offer**

-

Competitive salary based on experience (€70,000 - €100,000)

-

Equity in the company (0.5 - 1%)

-

Fully remote, hybrid, or onsite? Up to you.

-

Top-tier hardware, as well as any other tools of your choice

**Interview process**

-

20min Intro call

-

Tech test (take-home)

-

90min Technical interview (CTO + Martin)

-

60min Culture fit interview (CEO + CPO)

-

Offer and reference checks

We aim to complete the interview process within 14 days.

Compensation: €70K – €100K • 0.5% – 1%

- • €70K – €100K • 0.5% – 1%

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
