# Junior Applications Engineer

Posted: 2026-08-05T03:01:00Z

## Rejection

- Category: tech_stack
- Reason: role does not mention Go/Golang or PHP

At Rhoda AI, we’re building the next generation of generalist intelligent robots. We own the full robotics stack from high-performance hardware and robot systems to the infrastructure and state-of-the-art foundation world models that control our robots. Our robots are designed to be generalists capable of operating in complex, real-world environments and handling long-tail edge cases, made possible by our cutting edge research and end-to-end system design. We've raised over $450M and are investing aggressively in model research, infrastructure, hardware development, and manufacturing scale-up to make generalist robotics a reality.

# **The Role**

As Junior Application Engineer, you will work hands-on in the field alongside our Senior AE to execute Proof-of-Principle (POP), POC engagements and RaaS deplouments with Rhoda's European strategic partners. This is a practical, execution-focused role: you will be on-site at partner facilities, setting up and integrating Rhoda's robot platform, running test programmes, capturing data, and documenting results.

You will develop rapidly. Working alongside a Senior AE on complex, real-world deployments is one of the fastest paths to deep robotics systems competence. We expect you to grow into an increasingly autonomous AE over 12–18 months.

# **What You'll Do**

## **Field Deployment & POC Execution**

-

Support POP and POC execution, as well as RaaS engagements under Senior AE guidance: design solutions, system setup, sensor bring-up, test execution, and data collection at partner sites

-

Integrate and calibrate sensors (cameras, LiDAR, IMUs, depth sensors) with Rhoda's robot platform

-

Execute test plans defined by the Senior AE; record and validate results methodically

-

Maintain and transport robot platforms, peripherals, and field test kits in good working order

## **Troubleshooting & Documentation**

-

Assist with field troubleshooting — collect logs, reproduce issues, support root cause analysis under Senior AE direction

-

Write clear, structured technical documentation: test logs, configuration notes, sensor calibration reports, and integration guides

-

Contribute to test reports and partner-facing summaries; develop your ability to communicate technical findings clearly

## **Software & Tooling**

-

Operate and monitor Rhoda's onboard software stack in the field; diagnose and resolve common software-side issues

-

Write Python scripts for test automation, data processing, and light tooling tasks

-

Develop proficiency with industrial communication protocols (EtherCAT, CAN) through field exposure

## **Learning & Development**

-

Actively develop expertise in EU functional safety concepts (ISO 26262, IEC 61508, EN ISO 13849) — formal training supported

-

Participate in HQ Engineering knowledge-sharing sessions and apply learnings to field work

-

Take increasing ownership of defined sub-tasks within POC engagements as competence grows

# **What We're Looking For**

## **Must-Have**

-

Bachelor's degree in Mechanical Engineering, Electrical Engineering, Robotics, Mechatronics, or a related field

-

0–3 years of experience with robotic systems; a strong final-year thesis or research project in robotics or mechatronics is fully acceptable

-

Hands-on experience with ROS or ROS2 — you have launched nodes, debugged topics, and understood how a robot software stack fits together

-

Working knowledge of Linux; comfortable at the command line

-

Python scripting ability: you can write a data-analysis or test-automation script independently

-

Structured, thorough approach to testing and documentation — you write it down, you double-check, you close the loop

-

Willingness and ability to travel ~40% across Europe

-

English fluency; German at working level

## **Nice-to-Have**

-

Hands-on experience with robot policy training, model fine-tuning, or deployment

-

Experience with teleoperation systems or remote robot control workflows

-

Hands-on experience integrating or calibrating sensors (cameras, LiDAR, IMU, depth)

-

Exposure to functional safety concepts (ISO 26262, IEC 61508) — even at a conceptual or coursework level

-

Experience with EtherCAT or CAN protocols

-

Embedded Linux, C, or Rust — even at a beginner level

-

MATLAB or Simulink familiarity

# **Why This Role**

-

Rare early-career opportunity to work on real humanoid robot deployments in customer environments — not lab demonstrations

-

Direct mentorship from a Senior AE with deep field and functional safety expertise

-

High ownership from the start: you own your tasks, your documentation, and your learning path

-

Join at founding team stage — contribute to how Application Engineering is built at Rhoda Europe

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
