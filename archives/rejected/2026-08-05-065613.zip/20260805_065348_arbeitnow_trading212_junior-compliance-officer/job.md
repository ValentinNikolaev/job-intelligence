# Junior Compliance Officer

Posted: 2026-08-04T23:40:48Z

## Rejection

- Category: location_requirement
- Reason: requires United States location

**Our mission is to enable everyone to build wealth**

We reinvent how trading and investing work by creating exceptional products people love.

Fostering a culture of excellence and high velocity is the key to our success.

Over the past few years, our client base has grown to over 6 million, and client assets have grown to over €30 billion.

We're now expanding into **Germany** and strengthening our Compliance Team to uphold the company's commitment to integrity and regulatory adherence.

## **What you'll do**

-

Support day-to-day compliance activities aligned with BaFin regulatory requirements.

-

Assist in monitoring investment products and processes.

-

Contribute to the Compliance Monitoring Program (CMP) by preparing reports, collecting data, and following up on findings.

-

Provide compliance input on current and upcoming products and services across the business.

-

Participate in cross-functional compliance projects, gaining hands-on experience and supporting regulatory change implementation.

-

Support senior colleagues in reviewing higher-risk or complex financial promotions to ensure compliance.

-

Help maintain up-to-date compliance policies and procedures, ensuring effective implementation.

## **What you need to have:**

-

Ideally some experience in compliance, preferably within the financial services or investment sector.

-

A degree in Law, Finance, or a related discipline, or an equivalent qualification.

-

A strong interest in regulatory compliance and the financial services industry.

-

Excellent communication and interpersonal skills.

-

Ability to work well under pressure, adapt quickly, and learn on the job.

-

Professional proficiency in English, with German language skills considered a strong advantage.

## **What we offer: **

-

Challenges that will help you grow and realize your potential fast.

-

Opportunity to make a significant impact - you will build innovative services used by millions of investors to build wealth.

-

Work with smart, spirited, helpful, high-performing colleagues with a common goal.

-

An environment where nothing is set in stone.

-

Appreciation for your talent and ideas.

-

Generous remuneration package

Are you ready to accelerate your career with us? We'd love to hear from you!

We process applicant data confidentially and in accordance with applicable data protection laws. We may use AI-powered tools to help review applications, but all hiring decisions are made by our human recruitment team. Where required by law, we rely on your consent to use these tools.
You may withdraw this consent or exercise your data protection rights at any time by contacting us.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
