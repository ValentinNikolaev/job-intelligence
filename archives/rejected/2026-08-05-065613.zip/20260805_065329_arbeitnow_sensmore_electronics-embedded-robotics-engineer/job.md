# Electronics / Embedded Robotics Engineer

Posted: 2026-08-05T00:01:58Z

## Rejection

- Category: tech_stack
- Reason: role does not mention Go/Golang or PHP

sensmore automates the world's largest machines with unprecedented intelligence. Our proprietary Physical AI enables heavy machines such as wheel loaders to instantly adapt to dynamic environments and execute new tasks without prior training.

We integrate cutting-edge robotics into a platform powering intelligence and automation products - transforming productivity and safety for customers in mining, construction, and adjacent industries today.

Join us and play a pivotal role in transforming the automation landscape in heavy industries.

## Role Overview:

We are looking for a skilled Electronics / Embedded Engineer to enhance our team. This role requires a strong background in electronics design, embedded firmware, and hardware deployed in harsh environments. The successful candidate will be instrumental in building the electronic systems and firmware that connect our AI stack to real machines and keep them running reliably in the field.

## Key Responsibilities:

-

Design and bring up custom electronics – schematics, PCB layout, and component selection – for sensor interfacing, power distribution, and machine control.

-

Develop and validate embedded firmware on microcontrollers for sensor acquisition, actuator drive, and safety-relevant functions.

-

Own the electrical architecture of the machine kit, covering power budgeting, protection, grounding, EMC, and rugged wire harness design.

-

Collaborate with interdisciplinary teams to integrate hardware and firmware into the wider robotic system, from prototype through field testing to repeatable production.

## Required Qualifications:

-

Bachelor's or Master's degree in Electrical/Electronic Engineering, Mechatronics, Computer Engineering, or a related field.

-

Proficient in embedded C/C++ on ARM Cortex-M or comparable microcontrollers.

-

Proven experience taking electronics from schematic to working board using tools such as Altium or KiCad.

-

Solid understanding of communication protocols (CAN/CAN FD, I2C, SPI, UART, Ethernet) and the instruments used to debug them.

-

Practical experience deploying electronics and wire harnesses in adverse industrial or automotive conditions, including power protection and signal integrity.

## Preferred Skills:

-

Practical experience with off-highway machinery, automotive, or other safety-relevant platforms.

-

Familiarity with functional safety and EMC standards such as ISO 13849, IEC 61508, or CISPR 25.

-

Knowledge of electrical integration for Linux-based compute platforms such as NVIDIA Jetson or industrial PCs.

-

Experience with motors, actuators, valve drivers, and closed-loop control.

-

Proven track record of shipping hardware into production, from test jigs and bring-up procedures through to field servicing.

## **What We Offer:**

-

Build physical AI for the world's largest off-highway machinery – making them intelligent, safe, and ready for every tough task

-

Join the pioneer in intelligent robotics backed by Point Nine & other Tier 1 investors

-

Combine cutting-edge robotics research in end-to-end learning & Vision Language Action Model with real-world heavy mobile equipment

-

Tailor your own career path, whether you like to become technical specialist or technical team lead

-

Experience a great team culture, beverages, and an amazing office environment

##
**Benefits:**

-

Attractive compensation package and stock options.

-

Beverages on-site and regular social events.

-

Engage with top-tier researchers, engineers, and thought leaders.

-

Influence the future of robotic technologies and tackle significant technological challenges.

-

Assistance with relocation to Berlin.

##
**About Us:**

Heavy machinery, light years ahead.

sensmore automates the world's largest machines with unprecedented intelligence. Our proprietary Physical AI enables heavy machines such as wheel loaders to instantly adapt to dynamic environments and execute new tasks without prior training.

We integrate cutting-edge robotics into a platform powering intelligence and automation products - transforming productivity and safety for customers in mining, construction, and adjacent industries today.

We are proudly backed by Point Nine and other Tier 1 investors.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
