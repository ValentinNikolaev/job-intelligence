# Werkstudent*in (m/w/d) im Bereich Partnerships & Development in München

Posted: 2026-08-05T05:09:31Z

## Rejection

- Category: tech_stack
- Reason: role does not mention Go/Golang or PHP

**Ihre Aufgaben:**

- Unterstützung bei der Betreuung und Koordination der Partnerschaften der MSC
- Mitwirkung bei der Schnittstellenkommunikation mit Partnerorganisationen
- Unterstützung bei der Organisation und Durchführung der Side Events im Rahmen der Münchner Sicherheitskonferenz 2027
- Allgemeine administrative Tätigkeiten des Veranstaltungsmanagements

**Ihr Profil:**

- Interesse an internationaler Außen- und Sicherheitspolitik, sehr gute Kenntnisse des aktuellen Weltgeschehens und der Wille, aktuelle Debatten mitzugestalten
- Ggf. erste Erfahrungen im Projekt- und/oder Veranstaltungsmanagement, in der Zusammenarbeit mit externen Organisationen und im Umgang mit finanziellen Unterstützern (Fundraising)
- Organisations- und Improvisationstalent sowie kreative Problemlösungsfähigkeiten
- Exzellente Kommunikationsfähigkeiten sowie Souveränität und Professionalität
- Hohes Maß an Eigenverantwortung und Selbständigkeit
- Teamfähigkeit, Zuverlässigkeit
- Fließende Deutsch- und exzellente Englischkenntnisse in Wort und Schrift, nachgewiesen durch ein entsprechendes Zertifikat
- Internationale Vorerfahrung
- Gute Kenntnisse in MS Office und Tools zur kollaborativen Arbeit

**Wir bieten:**

Wir bieten Ihnen eine interessante, abwechslungsreiche und anspruchsvolle Tätigkeit mit viel Eigenverantwortung in einem hochmotivierten und dynamischen Team. Der Arbeitsplatz befindet sich in München, mit der Möglichkeit zum Homeoffice.

**Weitere Informationen:**

Zur Verstärkung unseres Partnerships Teams suchen wir **sobald wie möglich eine*n Werkstudent*in **(m/w/d) (20h/Woche).
Als **Werkstudent*in im Bereich Partnerships & Development **unterstützen Sie das Partnerships Team bei der Akquise, Betreuung und Weiterentwicklung von Partnerschaften der Münchner Sicherheitskonferenz. Zusätzlich betreut das Partnerships Team die Konzeption und Durchführung der herausragenden Side Events der Münchner Sicherheitskonferenz.
Wir freuen uns auf Ihre vollständige Bewerbung (Anschreiben & Lebenslauf) per E-Mail. Bitte geben Sie Ihren frühestmöglichen Eintrittstermin an. **Frühzeitige Bewerbungen sind ausdrücklich erwünscht, Bewerbungsschluss ist der**** 16. August (einschließlic**h). **Bewerbungsgespräche werden im Zeitraum vom 17. – 21. August geführt.**

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
