# Resident Solution Architect (Databricks)

Posted: 2026-08-05T03:00:38Z

## Rejection

- Category: location_requirement
- Reason: requires United States location

### About the Role

We are a growing MarTech consultancy and certified Salesforce implementation partner serving clients across banking, healthcare, insurance, and retail. Our team of seasoned technologists delivers end-to-end CRM, marketing automation, and data solutions — and we're looking for a **Resident Solution Architect (Databricks)** to join us.

In this role, you'll be a trusted technical leader who bridges strategy and execution — designing scalable architectures, guiding clients through complex data platform decisions, and collaborating across cross-functional teams to drive measurable outcomes.

### What You'll Do

-

Design and deliver end-to-end solution architectures with a focus on Databricks and modern data platforms

-

Lead technical discovery and architecture discussions with clients, translating complex trade-offs into clear, actionable recommendations for non-technical stakeholders

-

Serve as the primary technical point of contact for client engagements, ensuring solutions align with business goals and compliance requirements (e.g., HIPAA, SOX where applicable)

-

Collaborate with delivery teams to ensure architectural integrity throughout implementation

-

Contribute to internal best practices, reference architectures, and knowledge-sharing initiatives

-

Support pre-sales and scoping activities by providing architectural guidance and effort estimates

### What We're Looking For

**Required:**

-

Hands-on experience designing and delivering end-to-end solution architectures

-

Demonstrated expertise with **Databricks** (e.g., Unity Catalog, Delta Lake, Databricks SQL, MLflow, or Databricks Workflows)

-

Ability to communicate architectural concepts and trade-offs clearly to non-technical stakeholders

-

Proven track record of leading technical discussions with clients and cross-functional teams

-

Experience working in or with consulting, professional services, or client-facing environments

**Nice to Have:**

-

Background in MarTech, CRM, or data cloud ecosystems (e.g., Salesforce Data Cloud, CDP platforms)

-

Familiarity with cloud platforms (AWS, Azure, or GCP) and data lakehouse patterns

-

Experience in regulated industries such as healthcare, financial services, or insurance

-

Prior experience at a large systems integrator or management consultancy

### Compensation & Benefits

-

Competitive compensation (details shared during the interview process)

-

Flexible engagement model with US-based team

-

Work with a high-caliber team and marquee enterprise clients

*Please note: Visa sponsorship is not available for this role.*

### Location

This role is open to candidates based in the **United States**. Work arrangement details will be discussed during the hiring process.

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
