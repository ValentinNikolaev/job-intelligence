# Staff Software Engineer - Backend

Posted: 2026-08-05T02:56:19Z

## Rejection

- Category: tech_stack
- Reason: role does not mention Go/Golang or PHP

P-1328

At Databricks, we are passionate about enabling data teams to solve the world's toughest problems — from making the next mode of transportation a reality to accelerating the development of medical breakthroughs. We do this by building and running the world's best data and AI infrastructure platform so our customers can use deep data insights to improve their business. Founded by engineers — and customer obsessed — we leap at every opportunity to solve technical challenges, from designing next-gen UI/UX for interfacing with data to scaling our services and infrastructure across millions of virtual machines. And we're only getting started.

As a software engineer with a backend focus, you will work with your team to build infrastructure and products for the Databricks platform at scale.

**The impact you'll have:**

Our backend teams span many domains across our essential service platforms. For instance, you might work on challenges such as:

- Problems that span from product to infrastructure including: distributed systems, at-scale service architecture and monitoring, workflow orchestration, and developer experience.

- Deliver reliable and high performance services and client libraries for storing and accessing humongous amount of data on cloud storage backends, e.g., AWS S3, Azure Blob Store.

- Build reliable, scalable services, e.g. Scala, Kubernetes, and data pipelines, e.g. Spark, Databricks, to power the pricing infrastructure that serves millions of cluster-hours per day and develop product features that empower customers to easily view and control platform usage.

**What we look for:**

- BS (or higher) in Computer Science, or a related field

- 7+ years of production level experience in one of: Java, Scala, C++, or similar language.

- Experience developing large-scale distributed systems.

- Experience working on a SaaS platform or with Service-Oriented Architectures.

- Good knowledge of SQL.

**About Databricks**

Databricks is the Data and AI company. More than 20,000 organizations worldwide — including adidas, AT&T, Bayer, Block, Mastercard, Rivian, Unilever, and 70% of the Fortune 500 — rely on the Databricks Data + AI Platform to build and scale data and AI apps, analytics and agents. Headquartered in San Francisco with 30+ offices around the globe, Databricks offers a unified platform that includes Genie, Lakebase, Agent Bricks, Lakeflow, Lakehouse, and Unity Catalog. To learn more, follow Databricks on [LinkedIn](https://www.linkedin.com/company/databricks), [X](https://x.com/databricks), [YouTube](https://www.youtube.com/@Databricks), and [Instagram](https://www.instagram.com/databricksinc/?hl=en).

**Benefits

**At Databricks, we strive to provide comprehensive benefits and perks that meet the needs of all of our employees. For specific details on the benefits offered in your region click [here](https://docs.google.com/document/d/154un3e8Xav4BceOSlcYFZRGEuQI54xMxVydRwQn54eQ/edit?usp=sharing).

**Our Commitment to Diversity and Inclusion**

At Databricks, we are committed to fostering a diverse and inclusive culture where everyone can excel. We take great care to ensure that our hiring practices are inclusive and meet equal employment opportunity standards. Individuals looking for employment at Databricks are considered without regard to age, color, disability, ethnicity, family or marital status, gender identity or expression, language, national origin, physical and mental ability, political affiliation, race, religion, sexual orientation, socio-economic status, veteran status, and other protected characteristics.

**Compliance**

**If access to export-controlled technology or source code is required for performance of job duties, it is within Employer's discretion whether to apply for a U.S. government license for such positions, and Employer may decline to proceed with an applicant on this basis alone.**

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
