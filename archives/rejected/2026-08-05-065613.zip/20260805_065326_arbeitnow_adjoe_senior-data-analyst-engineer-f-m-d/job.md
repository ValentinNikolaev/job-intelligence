# Senior Data Analyst (Engineer) (f/m/d)

Posted: 2026-08-05T02:40:21Z

## Rejection

- Category: tech_stack
- Reason: role does not mention Go/Golang or PHP

adjoe builds the technologies behind mobile apps growth and monetization. **adjoe Ads** is our programmatic in-app advertising platform that seamlessly connects advertisers and publishers through direct integration of our Android and iOS SDKs. Every ad decision happens in under 200ms across 10 million daily users, powered by real-time bidding algorithms and user quality prediction models that match the right ad to the right user at the right moment.

**50 Billion Daily Bid Predictions
**
The User Experience team is the origin point of adjoe Ads. Everything the system knows about a user, every prediction the ML models make, every bid placed in an auction. It all starts with code this team ships.

The team owns two responsibilities. On the SDK side, a native **Kotlin** and **Swift **code runs inside hundreds of publisher apps. It participates in **120 million daily auctions**, renders ad creatives across multiple formats, and captures the behavioral signals that power** 50 billion predictions per day**. The constraint that defines this work: you’re executing inside someone else’s app, on someone else’s device, with zero tolerance for instability. Every ad impression has to feel native and fast to the user.

On the analytics side, the dashboards, investigation tools, and data frameworks that turn raw data into decisions: real-time revenue performance across active campaigns, infrastructure cost visibility, and data quality assessments. If a number matters to the business or to engineering, this team makes it accessible.

**Your Mission & Who We Are Looking For:**

-

**5+ Years Analytics Experience & Senior Leadership:** You bring 5+ years of data analysis experience—supported by a track record of bridging business ideas to technical solutions, spotting operational blind spots, and mentoring junior/mid-level analysts to scale the team’s impact.

-

**Analytics Engineering with dbt & Airflow:** You design and automate reliable, scalable data pipelines and workflows using dbt and Airflow, building automated, cleansed, and governed data layers that drive trusted real-time performance reporting, data quality control, and regulatory compliance.

-

**Massive-Scale SQL & Cost Optimization:** You hold a degree in CS, Data Science, Informatics, or a related math-heavy field, paired with mastery of SQL (Window Functions, CTEs, deeply nested JSON/Map types) to optimize heavy Trino/Athena queries over 5TB+ daily data volumes for speed and infrastructure cost-efficiency.

-

**Memory-Efficient Python Processing:** You possess deep Python expertise for complex, memory-efficient data manipulation and statistical modeling, ensuring analytics pipelines handle massive daily data volumes without degrading performance.

-

**Experimental Rigor & A/B Testing:** You apply Python-driven statistical methods (Power Analysis, P-values, Bayesian frameworks) to rigorously evaluate SDK-side experiments and support the rollout of profitable feature iterations.

-

**Data Storytelling & Stakeholder Execution:** You combine data visualization and strong technical storytelling to translate complex statistical analyses, real-time campaign performance, and operational findings into actionable recommendations for cross-functional stakeholders.

##

## **🌎 We welcome applications from talent worldwide and provide relocation support to Hamburg, Germany for those ready to join our team.**

**What’s in It for You?**

At adjoe, you’re not here to just close JIRA tickets, you’re helping build the infrastructure behind one of the most impactful platforms in adtech. The systems you work on will reach hundreds of millions of users and power billions of decisions every day.

-

**Go Big.** Own projects with impact on 770M users and push adtech boundaries.

-

**Move Fast.** Ship solutions multiple times a day, learn from results, and keep momentum.

-

**Be Direct.** Solve problems openly and collaborate across teams.

-

**Thrive Together.** Grow with a diverse, global team of people from over 40 different countries that learn from each other.

-

**Have Fun.** Celebrate wins, enjoy daily victories, and bring your energy.

We welcome applications from people who will contribute to the diversity of our company.

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
