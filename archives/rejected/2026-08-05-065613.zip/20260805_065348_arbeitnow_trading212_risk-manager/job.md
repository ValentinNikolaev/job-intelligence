# Risk Manager

Posted: 2026-08-04T23:40:48Z

## Rejection

- Category: location_requirement
- Reason: requires United States location

## **Our mission is to enable everyone to build wealth**

We reinvent how trading and investing work by creating exceptional products people love.

Fostering a culture of excellence and high velocity is the key to our success.

Тoday, we serve over 6 million clients, with more than €30 billion in assets under management - a testament to the scale and trust we’ve built in just a few years.

## **What you’ll do**

-

Ensure the organisation’s approach to the treatment of risk is aligned with its Risk Management Framework, Risk Strategy and Risk Appetite.

-

Conduct Risk and Control Self-Assesments and prepare evidence of control framework adherence for senior management and Board.

-

Provide education and training to the rest of the Firm on their responsibilities to ensure adherence to risk requirements.

-

Oversee and challenge risk event/ incident management from initial reporting through to remediation and closure.

-

Demonstrating an understanding of liquidity risk management and stress testing.

-

Provide an overview and challenge of the trading risk to which the Firm is exposed.

-

Provide risk reports and updates on the Firm’s risk profile through risk governance.

-

Participate in the company's new product approval process, ensuring risks are identified early with mitigation strategies applied.

-

Report and track organisational Key Risk / Performance Indicators (KRIs/ KPIs) for evaluating risk management performance, strategy, processes, and controls.

-

Promote the view that risk management is a universal responsibility and acts as a risk champion across the organisation.

## **What you need to have**

-

Knowledge of risk management principles and practices.

-

Strong analytical and strategic thinking abilities.

-

High attention to detail and risk assessment skills.

-

Effective communication capabilities.

-

Experience in financial management, particularly capital and liquidity management and/ or management and understanding of market and credit risk in a retail client base is desirable

-

Experience with risk reporting.

-

Ability to develop and implement risk mitigation strategies.

-

Experience with risk management software and tools.

-

Outsourcing/ Third Party Risk Management experience.

## **What we offer:**

-

Challenges that will help you grow and realize your potential fast.

-

Opportunity to make a significant impact - you will build innovative services used by millions of investors to build wealth.

-

Work with smart, spirited, helpful, high-performing colleagues with a common goal.

-

An environment where nothing is set in stone.

-

Appreciation for your talent and ideas.

-

Generous remuneration package

Are you ready to accelerate your career with us? We'd love to hear from you!

We process applicant data confidentially and in accordance with applicable data protection laws. We may use AI-powered tools to help review applications, but all hiring decisions are made by our human recruitment team. Where required by law, we rely on your consent to use these tools.
You may withdraw this consent or exercise your data protection rights at any time by contacting us.

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
