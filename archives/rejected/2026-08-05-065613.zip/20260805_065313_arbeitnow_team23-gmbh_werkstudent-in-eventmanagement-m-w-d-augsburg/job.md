# Werkstudent:in Eventmanagement (m/w/d) - Augsburg

Posted: 2026-08-05T05:09:15Z

## Rejection

- Category: tech_stack
- Reason: role does not mention Go/Golang or PHP

**Kurzbeschreibung**

Du hast Lust eine der größten Digital-Konferenzen Süddeutschlands - die sparkscon - nicht nur von außen mitzuerleben, sondern aktiv mitzugestalten? Du behältst gerne den Überblick, strukturierst Aufgaben und hast Freude daran, Menschen, Themen und Abläufe zusammenzubringen?

Dann unterstütze uns als Werkstudent:in im Bereich Eventmanagement & Koordination für die sparkscon und werde Teil unseres Teams bei TEAM23.

**Deine Aufgaben**

- Du unterstützt uns bei der Planung, Organisation und Umsetzung der sparkscon - von der Konzeption, Durchführung bis zur Nachbereitung.
- Du bist direkt involviert in die Koordination von externen Dienstleister:innen und Partner:innen, die für den Erfolg der sparkscon entscheidend sind.
- Du agierst als Ansprechpartner:in für unsere Speaker:innen - von der zeitlichen Planung, thematischen Abstimmung bis hin zu sonstigen Anliegen.
- Du bringst eigene kreative Ideen und Impulse ein, um die sparkscon noch nachhaltiger und erlebbarer zu machen.
- Du behältst den Überblick über Aufgaben, Zeitpläne und Budget rund um die sparkscon.
- Du bist in enger Abstimmung mit unserem sparkscon Team und der Geschäftsführung.

**Was dich auszeichnet**

- Du hast ein laufendes Studium im Bereich Eventmanagement, Kommunikation, BWL oder einer vergleichbaren Fachrichtung.
- Du hast idealerweise erste Erfahrungen in der Organisation von Events oder Projekten (z. B. durch Praktika oder Engagements).
- Du hast ein starkes Interesse an Eventmanagement und eine hohe Motivation, praktische Erfahrungen in einem dynamischen Umfeld zu sammeln.
- Du arbeitest strukturiert und kannst gut priorisieren, auch wenn es hektisch wird.
- Du bist kommunikativ stark und hast Freude am Kontakt mit unseren externen Dienstleister:innen und Partner:innen.
- Du zeigst Eigeninitiative und die Fähigkeit, selbstständig und eigenverantwortlich zu arbeiten.
- Du möchtest uns idealerweise längerfristig begleiten und stehst uns mit Beginn des Wintersemesters 2026/27 für 16-20 Stunden pro Woche zur Verfügung.

**Benefits**

- Du arbeitest flexibel - mit einem Gleitzeitmodell und der Möglichkeit auf Homeoffice. So passt Arbeit besser zu deinem Alltag und deinem Stundenplan.
- Du arbeitest mit hochwertiger Apple-Hardware und moderner Ausstattung, damit du dich auf deine Arbeit konzentrieren kannst.
- Du bekommst individuelle Weiterbildungs- und Entwicklungsmöglichkeiten sowie Perspektiven für deinen nächsten Karriereschritt - passend zu deiner Rolle.
- Du bist Teil eines Teams, das auch außerhalb des Projekts gerne Zeit miteinander verbringt - bei Events, Workshops und gemeinsamen Aktivitäten.
- Du profitierst von Angeboten wie Jobticket oder Jobrad und bleibst flexibel unterwegs.
- Du kannst unser Gesundheitsangebot wie z.B. den EGYM Wellpass nutzen.
- Du bekommst kostenlosen Kaffee, Getränke und Snacks aus dem Kiosk - für den kleinen Energieboost zwischendurch.

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
