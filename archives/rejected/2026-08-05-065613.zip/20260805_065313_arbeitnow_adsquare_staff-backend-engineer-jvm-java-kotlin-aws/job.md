# Staff Backend Engineer - JVM (Java/Kotlin) & AWS

Posted: 2026-08-05T05:09:47Z

## Rejection

- Category: tech_stack
- Reason: role does not mention Go/Golang or PHP

**Intro**

At Adsquare, our mission is driven by our core focus: Passion, solving complex challenges with great people, tech, and data; and Niche, location intelligence for programmatic advertisers.

Our core values are integral to everything we do:

-

Drive: We turn ambition into action.

-

Resilience: We adapt, persevere, and grow stronger.

-

No BS: We value honesty, transparency, and clear communication.

-

Humble: We choose modesty over vanity and let results speak for themselves.

-

Moral Compass: We do the right thing with fairness, integrity, and respect.

We seek candidates who not only bring excellent technical expertise but also embody these values in every aspect of their work.

**Your Mission**

As a Staff Backend Engineer, you will own the design and operation of the high-throughput JVM services that turn massive streams of location data into products our partners depend on in real time.

You will operate with a high degree of autonomy and engagement, seeking out the problems worth solving, driving performance and reliability across our services, and making the architectural decisions that shape how the whole organisation builds and scales. You will thrive in ambiguity, turn business-critical challenges into systems that hold up under real-world load, and lift the engineers around you as you go.

**Your Profile**

We are looking for a staff-level engineer with a strong backend and cloud background who is comfortable owning complex systems in production. Our stack is centered on Java, Kotlin, and AWS, and while the specifics are listed below, we don't expect prior experience with every tool we use.

Must-Have Skills

-

8+ years building backend systems in production, with a track record of owning services end to end.

-

Experience mentoring senior engineers and influencing technical direction across teams.

-

Strong expertise in Java or another JVM language (Kotlin, Scala) and the Spring ecosystem.

-

Proven experience designing and operating distributed systems under real-world load.

-

Deep, hands-on AWS experience (for example S3, SQS/SNS, Lambda, IAM), including designing cloud-native architectures.

-

Hands-on experience with Docker and containerised deployment workflows.

-

Practical experience building and maintaining CI/CD pipelines (for example GitHub Actions, GitLab CI, Jenkins).

-

Fluency with AI-assisted development tools (for example Copilot, Cursor, Claude Code), using them to accelerate design, coding, testing, and review while keeping strong judgment over correctness, security, and maintainability.

-

A strong understanding of concurrency, data consistency, and system reliability.

-

Experience with PostgreSQL or other relational/NoSQL databases (for example MongoDB) in high-throughput environments.

-

A proactive approach: you identify problems, take ownership, and drive solutions with a high degree of autonomy.

Nice to Have

-

Experience with systems processing large data volumes or high request throughput.

-

A feel for architectural trade-offs (for example synchronous vs. asynchronous processing) and comfort making decisions with incomplete information.

-

Experience helping a team adopt AI-assisted development practices thoughtfully, balancing speed with quality.

-

Experience with our wider environment: Terraform, MongoDB, Kubernetes, and AWS data tooling (Athena, Glue, Batch, Step Functions).

-

Background in partner integrations or API-driven systems, or evolving systems from monolithic to cloud-native.

**What you will do**

-

Design and evolve distributed backend systems with a strong focus on scalability and correctness.

-

Take services from architecture decisions through deployment and day-to-day operation.

-

Maintain existing partner integrations and build new ones to deliver large-scale data to our partners reliably.

-

Build and operate cloud-native systems on AWS, including migrating services from monolithic to cloud-native architectures.

-

Monitor system health, troubleshoot production issues, and optimise for performance, memory, and latency.

-

Collaborate closely with Product and Data teams to deliver features that move the business.

-

Raise the engineering bar across teams: drive cross-team architecture decisions and grow the engineers around you.

**Why us? **

On top of a competitive package:

-

We are open to flexible work models: we work in a hybrid mode and remotely from anywhere in the world up to 3 months per year.

-

You are entitled to 30 vacation days per year.

-

We offer Urban Sports Club membership and a company pension scheme.

-

Regular team events and company events organised by our People team (trust us, they know how to throw a party!).

-

We equip you with the latest hardware and provide you with all the tools you need to thrive.

**Salary Range (Annual On-Target Earnings)**

90,000 - 100,000 euros per year

**Recruiting Process**

-

Step 1: Intro and values conversation (30 mins) to get to know each other and align on expectations.

-

Step 2: Technical interviews: two conversations covering backend fundamentals and a deeper system-design discussion.

-

Step 3: Final step: meet the team, followed by a decision and offer. We conduct a reference check at this stage.

**Work model**

Hybrid or Remote

**Desired start date**

As soon as possible

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
