# Senior Frontend Engineer (Kotlin) - Frontend Core

Posted: 2026-08-04T23:40:48Z

## Rejection

- Category: location_requirement
- Reason: requires United States location

***Our mission is to enable everyone to build wealth***

*We reinvent how trading and investing work by creating exceptional products people love.*

*Fostering a culture of excellence and high velocity is the key to our success.*

*Today, we serve over 5 million clients, with more than €30 billion in assets under management - a testament to the scale and trust we’ve built in just a few years.*

##

## **What you’ll do**

-

Own and evolve our monorepo, ensuring it stays healthy, performant, and easy to work in as the codebase grows

-

Design, build, and maintain CI/CD pipelines for React Native and web targets, driving reliability and fast feedback loops for the engineering team

-

Author and maintain shared TypeScript libraries — state management patterns, networking layers, error handling utilities — consumed across all frontend products

-

Own the mobile release process end-to-end, including Android build configuration, versioning, and deployment automation

-

Integrate and maintain observability tooling (Sentry, Amplitude) at the platform level, so product teams get reliable instrumentation out of the box

-

Identify and resolve build bottlenecks, dependency issues, and tooling gaps that slow down engineering velocity

-

Collaborate closely with product frontend teams to understand their pain points and translate them into platform improvements

## **What you need to have**

-

At least 4 years of professional experience in frontend or mobile engineering, with a meaningful portion spent on platform, infrastructure, or developer tooling work

-

Production-grade TypeScript - strong typing discipline, not just familiarity

-

Hands-on React Native experience in a production app, including an understanding of the native layer

-

Practical Kotlin experience on Android - native modules, build configuration, or Android-side CI/CD work

-

Direct involvement in CI/CD pipeline ownership or significant contribution — mobile or frontend, any tooling

-

Ability to think in systems and write code for other engineers, not just end users

-

Comfortable working autonomously and making decisions without waiting for full consensus

## **Nice to have (Optional)**

-

Hands-on experience with nx or pnpm workspaces specifically

-

Familiarity with Vite and Expo for tooling or build configuration

-

Exposure to Reanimated or React Native Gesture Handler

-

Background in fintech or a high-scale consumer app where release reliability was business-critical

## **What we offer**

-

Challenges that will help you grow and realise your potential

-

Opportunity to make a big Impact - you will build innovative services used by millions of investors to build wealth

-

Work with smart, spirited, helpful, high-performing colleagues with a common goal

-

An environment where nothing is set in stone

-

Appreciation for your talent and ideas

-

Generous remuneration package including annual bonuses

-

Excellent social benefits package, including private health insurance, sports card and 25 days of paid vacation per year

-

Delicious treats and a spacious game room

Are you ready to accelerate your career with us? We'd love to hear from you!

We process applicant data confidentially and in accordance with applicable data protection laws. We may use AI-powered tools to help review applications, but all hiring decisions are made by our human recruitment team. Where required by law, we rely on your consent to use these tools.
You may withdraw this consent or exercise your data protection rights at any time by contacting us.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
