# Computer Science PhD (Germany)

Posted: 2026-08-05T00:00:59Z

## Rejection

- Category: tech_stack
- Reason: role does not mention Go/Golang or PHP

## Overview

We are looking for experienced **Machine Learning and AI Experts** to help train and evaluate advanced AI models.

In this role, you will apply your domain expertise to assess AI-generated content, create high-quality technical prompts and answers, and evaluate model responses for accuracy, relevance, and clarity.

This is a remote, flexible opportunity for experts who want to contribute to the development of better AI systems.

## Compensation

-

US$150 per hour

## Key Responsibilities

As a **Machine Learning / AI Expert**, you may contribute by:

-

Assessing the factual accuracy, technical quality, and relevance of AI-generated text related to Machine Learning and Artificial Intelligence.

-

Crafting and answering advanced questions across Machine Learning, AI, and adjacent technical domains.

-

Evaluating, comparing, and ranking AI-generated responses based on correctness, reasoning quality, completeness, and clarity.

-

Identifying errors, inconsistencies, hallucinations, or weak reasoning in model outputs.

-

Providing clear feedback that helps improve the performance of AI systems.

## Ideal Qualifications

We are especially interested in candidates with one or more of the following:

-

A PhD in **Machine Learning, Artificial Intelligence**, or an adjacent field, such as Computer Science, Statistics, Applied Mathematics, Computational Neuroscience, Natural Language Processing, Computer Vision, Reinforcement Learning, or Data Science.

-

Experience working as a Machine Learning Engineer, AI Researcher, Applied Scientist, Data Scientist, or in a comparable highly technical or analytical role.

-

Strong understanding of core Machine Learning and AI concepts, including model training, evaluation, optimization, and real-world application.

-

Ability to write clearly, precisely, and fluently in English about complex technical topics.

-

Strong analytical judgment and attention to detail.

##

## Work Arrangement

-

Remote

-

Flexible hours

Compensation: $150 per hour

- • $150 per hour

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
