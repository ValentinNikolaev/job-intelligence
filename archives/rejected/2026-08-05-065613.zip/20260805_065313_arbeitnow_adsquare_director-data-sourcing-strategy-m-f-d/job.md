# Director Data Sourcing & Strategy (m/f/d)

Posted: 2026-08-05T05:09:47Z

## Rejection

- Category: tech_stack
- Reason: role does not mention Go/Golang or PHP

**Intro**

Adsquare's mission is centered on:

-

Passion: Solving complex challenges with exceptional people, technology, and data.

-

Niche: Specializing in Location Intelligence for Programmatic Advertisers.

Our work is guided by our core values, and we look for candidates who embody them:

-

Drive: Turning ambition into action that brings valuable outcomes.

-

Resilience: Adapting, persevering, and growing stronger through challenges.

-

No BS: Upholding honesty, transparency, and clear communication.

-

Humble: Valuing modesty and letting results speak for themselves.

-

Moral Compass: Acting with fairness, integrity, and respect.

**About the team**

Data sits at the heart of everything Adsquare does — it's the raw material behind every product we sell. This role leads our data sourcing function: a small, focused team responsible for the quality, legality, and strategic positioning of the data we bring in. You'll work hand-in-hand with Product, Legal, and Engineering, and grow the function as Adsquare scales.

**Your Mission**

Data is our product. You'll own the data we bring in — what we source, on what terms, to what standard — and grow that into a strategic function as Adsquare scales. A builder's role: you'll lead a small team today and shape what the function becomes.

**Your Profile**

-

6+ years in data acquisition, data partnerships, or strategic partnerships within adtech, martech, or the wider data ecosystem — with real depth, not just deal volume.

-

A track record of both sourcing strategy and execution: deciding what data matters, then securing it on good terms.

-

Direct experience negotiating and managing data partnerships, ideally across multiple markets.

-

Deep grounding in privacy and compliance — GDPR, CCPA, consent frameworks, privacy-enhancing technologies.

-

Strong analytical instinct — able to evaluate data on quality, scale, coverage, and financial viability, not just take a supplier's word for it.

-

A builder — comfortable shaping a function rather than inheriting a finished one, and comfortable in ambiguity.

-

Direct, low-ego, high-integrity. Fits how we work: Drive, Resilience, No BS, Humility, Moral Compass.

**What you will do**

-

Define and execute Adsquare's data sourcing strategy — what to acquire, build, or partner for, and the business case behind it.

-

Identify, evaluate, and negotiate terms with global and local data providers (mobile apps, SDK networks, retail media, telcos, first-party data owners).

-

Set data quality standards and the monitoring to enforce them — catching problems at the provider level, not when a client does.

-

Own the legal and privacy posture on sourced data alongside Legal — consent, GDPR/CCPA and equivalents, licensing compliance.

-

Manage existing data-partner relationships — value, optimisation, renewals.

-

Partner closely with Product and Engineering on technical onboarding and evaluation of new data streams.

-

Build and grow the team as the function scales.

**Nice to Have **

-

Strong knowledge of programmatic advertising, location data, and industry identifiers.

-

Enough technical fluency (APIs, data formats, cloud data transfer) to challenge and guide credibly.

-

Experience intiating first-party data collection or a sourcing capability in a new market.

**Why us? **

- Hybrid + remote from anywhere up to 3 months/year
- €1,200 yearly learning & development budget
- 30 vacation days
- Urban Sports Club membership
- Company pension scheme
- Latest hardware provided
- Regular team & company events

**Salary Range (Annual On-Target Earnings)**

** **€90,000–€110,000 (base salary + performance bonus), depending on experience.

**Recruiting Process**

We value your time and aim to provide a transparent and efficient recruitment experience.

- Values-fit interview - 30 min
- Hiring Managers interview - 60 min
- Case study presentation - 90 min
- Reference check
- Offer

**Work model**

Hybrid

**Desired start date**

As soon as possible

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
