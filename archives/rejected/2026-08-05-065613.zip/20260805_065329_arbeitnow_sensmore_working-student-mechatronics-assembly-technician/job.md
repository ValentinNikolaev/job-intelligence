# Working Student - Mechatronics Assembly Technician (20 hrs)

Posted: 2026-08-05T00:01:58Z

## Rejection

- Category: tech_stack
- Reason: role does not mention Go/Golang or PHP

sensmore automates the world's largest machines with unprecedented intelligence. Our proprietary Physical AI enables heavy machines such as wheel loaders to instantly adapt to dynamic environments and execute new tasks without prior training.

We integrate cutting-edge robotics into a platform powering intelligence and automation products - transforming productivity and safety for customers in mining, construction, and adjacent industries today.

Join us and play a pivotal role in transforming the automation landscape in heavy industries.

As our Working Student – Mechatronics Assembly Technician, you’ll be at the forefront of assembling advanced sensor boxes that integrate sensors, compute units, communication hardware, power systems, and more. Your craftsmanship will set the standard for durability, reliability, and field-ready performance.

# **Responsibilities**

**Assembly Mastery:**
Take ownership of building robust sensor boxes that integrate sophisticated electronics and mechanical systems designed for demanding environments. Apply best-practice assembly methods to ensure long-term stability and ruggedness.

**Quality Assurance:**
Implement, document, and refine quality processes to ensure each assembled unit meets rigorous functional and mechanical standards. Help shape continuous improvement loops across design, assembly, and testing.

**Prototyping & CAD Support:**
Contribute to mechanical prototypes using CAD tools, 3D printing, and basic CNC machining. Assist the hardware team with rapid design iterations, enclosure improvements, and manufacturability feedback.

**Future Growth:**
Grow into a role where you coordinate and oversee external assembly work with trusted suppliers. Work closely with the hardware and supply chain teams to maintain high quality, streamline processes, and scale production.

# **What You Bring**

-

Currently enrolled in Mechatronics, Mechanical Engineering, Electrical Engineering, or a related field.

-

Hands-on experience with mechanical or hardware assembly, with an eye for durability, precision, and build quality.

-

Basic experience with CAD modeling (e.g., SolidWorks, Fusion 360, CATIA, or similar).

-

Practical skills in prototyping, including 3D printing, laser cutting, or CNC machining.

-

Understanding of sensor systems, communication equipment, or embedded electronics is a plus.

-

Strong teamwork and communication skills, with a desire to contribute to a fast-moving hardware development environment.

## **What We Offer:**

-

Build physical AI for the world's largest off-highway machinery – making them intelligent, safe, and ready for every tough task

-

Join the pioneer in intelligent robotics backed by Point Nine & other Tier 1 investors

-

Combine cutting-edge robotics research in end-to-end learning & Vision Language Action Model with real-world heavy mobile equipment

-

Tailor your own career path, whether you like to become technical specialist or technical team lead

-

Experience a great team culture, beverages, and an amazing office environment

##
**Benefits:**

-

Attractive compensation package and stock options.

-

Beverages on-site and regular social events.

-

Engage with top-tier researchers, engineers, and thought leaders.

-

Influence the future of robotic technologies and tackle significant technological challenges.

-

Assistance with relocation to Berlin.

##
**About Us:**

Heavy machinery, light years ahead.

sensmore automates the world's largest machines with unprecedented intelligence. Our proprietary Physical AI enables heavy machines such as wheel loaders to instantly adapt to dynamic environments and execute new tasks without prior training.

We integrate cutting-edge robotics into a platform powering intelligence and automation products - transforming productivity and safety for customers in mining, construction, and adjacent industries today.

We are proudly backed by Point Nine and other Tier 1 investors.

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
