# FULL STACK ENGINEER (f/m/d)

Posted: 2026-08-05T05:27:52Z

## Rejection

- Category: tech_stack
- Reason: role does not mention Go/Golang or PHP

Founded in 2025, Omnisent is a Munich-based defense technology company developing fully autonomous, Counter-UAS system. We are a small, high-output team from Cambridge, Imperial College, MIT, and BCG united by a mission to redefine modern airspace security.

## Aufgaben

We are looking for a Full Stack Engineer to build the APIs and data infrastructure that power OmniDome's software layer, from backend architecture to database design.

- Design, build, and maintain APIs supporting Omnisent's product and internal tools

- Design and manage databases to support our growing product and data needs

- Work across the stack to ship features end-to-end, from backend logic to integration points

- Collaborate with ML, hardware, and UI teams to integrate software with the broader OmniDome system

## Qualifikation

- Strong experience building and maintaining APIs and backend systems

- Solid database design and management experience

- Comfortable working across the full stack and owning features end-to-end

- Pragmatic engineer who can move fast in a small, high-output team

- EU work authorization

**Bonus:**

- Experience building software for hardware-integrated or real-time systems

- Background in defense, dual-use, or other regulated tech sectors

## Benefits

- **Competitive Compensation:** Highly competitive cash comp, along with virtual stock options, that reflect your experience and the value you bring

- **Accelerated Learning & Growth:** Join a fast-paced environment where you'll take on real responsibility, overcome meaningful challenges, and grow alongside a driven team

- **Make a Real Impact:** Play a key role in shaping Omnisent's journey and contribute directly to the success of the company

*In your cover letter, we'd love to hear about your personal interests, what drives you, why this role feels like the right fit, and most importantly, why Omnisent.*

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
