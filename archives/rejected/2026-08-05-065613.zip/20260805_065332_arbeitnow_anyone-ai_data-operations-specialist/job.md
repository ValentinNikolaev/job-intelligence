# Data & Operations Specialist

Posted: 2026-08-05T00:00:59Z

## Rejection

- Category: tech_stack
- Reason: role does not mention Go/Golang or PHP

**Our vision: **Mastering machine learning is difficult, time-consuming, and often frustrating. Meanwhile, the AI industry faces its biggest challenge: a global shortage of skilled talent. At Anyone AI, we close this gap by upskilling the best talent from LatAm through an accelerated, hands-on training program designed and led by AI industry experts.

**Our mission: **We are building the largest hub of AI developers in the region, investing in tens of thousands of developers over the next decade.

We are founding members of Deep Vision AI, one of the first companies in the computer vision / AI space, which was acquired in early 2020 by DFW Capital Partners. Anyone AI is backed by top global investors like GFC -Global Founders Capital- (investors in Facebook, LinkedIn, Slack, etc), Canvas Ventures (early investor in Coursera), Latitud Fund (the largest community of angel investors for LatAm), Magma Partners, Lotux VC, among others.

**Run the race of your life**

This is an opportunity to transform the AI industry and positively impact thousands of lives in Latin America. This position offers self-motivated, collaborative individuals the chance to make a direct impact on Anyone AI’s products and services. You will have the opportunity to challenge yourself while contributing to the development of a revolutionary accelerated training program. This program is designed to invest in people from LatAm, helping them master ML and AI and secure a job in the space.

**About the Role**

We are seeking a Data & Operations Specialist who thrives at the intersection of process automation and data workflows. This role is both highly technical and operationally strategic: you’ll design and maintain automation workflows, manage key processes (admissions, education, career services, billing), and ensure data accuracy across all areas.

You’ll be hands-on with tools like Zapier, Hubspot, Google Sheets, AppScripts, Notion/Airtable, APIs, and ideally Supabase. At the same time, you’ll take ownership of operations, ensuring efficiency, scalability, and reliability. Your work will directly improve operational efficiency, financial accuracy, and the experience of our fellows.

**Responsibilities**

-

Support cross-functional teams (admissions, career, placement, billing) with data and automation needs.

-

Design and maintain automation workflows with Zapier, Typeform, Hubspot, AppScripts, Notion/Airtable, and external APIs.

-

Build and maintain BI dashboards (Looker Studio, Google Sheets).

-

Use lightweight database solutions (e.g., Supabase) to structure and sync data across internal processes.

**Skills & Experience**

-

Technical expertise:

-

Strong hands-on experience with Zapier, Hubspot, Google Sheets, AppScripts, APIs, and process automation tools.

-

Proficiency with Looker Studio (or similar BI tools for dashboarding and reporting).

-

Solid understanding of databases; comfortable working with no-code/low-code structured systems (e.g., Airtable, Notion) and basic SQL (Supabase).

-

Preferred: experience with Python, n8n, Lovable, or similar automation platforms.

-

Operational experience

-

Proven background in workflow automation and operations management.

-

Experience with finance, billing, or HR processes is a strong plus (bonus if in edtech, bootcamps, or online learning).

-

Mindset & skills

-

Analytical, detail-oriented, and highly data-driven.

-

Strong organizational and communication skills; able to manage multiple processes in parallel.

-

Ownership mentality: equally comfortable building technical solutions and running end-to-end operational processes.

-

Entrepreneurial and growth-oriented mindset, thriving in a dynamic, fast-paced environment with an iterative development process.

-

Excellent team player who builds trust internally and with users, customers, and partners, with highly effective communication skills in English and Spanish.

-

Highly analytical, data-driven, and capable of working independently and making real-time decisions, with a strong work ethic and a "get-the-job-done" attitude.

*AnyoneAI is an equal opportunity employer. We do not make hiring, employment or promotion decisions based on race, religion, color, sex, age, national origin, ancestry, sexual orientation, gender or identity or expression, pregnancy or pregnancy-related condition, marital status, height and/or weight.*

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
