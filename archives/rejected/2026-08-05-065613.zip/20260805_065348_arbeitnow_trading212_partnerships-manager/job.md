# Partnerships Manager

Posted: 2026-08-04T23:40:48Z

## Rejection

- Category: location_requirement
- Reason: requires United States location

## **Trading 212’s mission is to enable everyone to build wealth.**

We are reinventing how trading and investing work by creating exceptional products that people love.

Trading 212 is built by highly driven people who strive for excellence and value freedom.

Today, we serve over **5 million clients**, with more than **€30 billion in assets under management** - a testament to the scale and trust we’ve built in just a few years.

## **The role**

We’re looking for a Partnerships Manager to join our Growth team and build high-impact partnerships across media, influencers, and digital platforms. You’ll source new opportunities, negotiate deals, and grow existing relationships through smart collaboration, strong execution, and consistent performance management.

This is a hands-on role for someone who moves fast, communicates clearly, and knows how to turn partnerships into measurable growth.

## **What you’ll do**

-

Source, build, and grow partnerships across media, influencers, websites, and other strategic partners

-

Own end-to-end outreach, negotiation, and deal-closing across the German and international markets

-

Cultivate long-term relationships with partners - pitching fresh campaign ideas, coordinating seamless execution, and managing expectations.

-

Track and analyze partners’ performance and ROI, translating data into actionable insights

-

Ensure partners follow all campaign guidelines, brand requirements, and compliance rules

-

Conduct continuous market research to spot new angles, validate opportunities, and stay ahead of competitor activity and new partnership formats.

## **Skills you need to have**

-

Strong ownership mindset with a bias towards action and results

-

Solid understanding of influencer marketing and partnership-driven growth

-

Excellent verbal and written communication skills in both English and German, with confidence in conducting high stakes presentations and negotiations

-

Comfort working with data and performance metrics (you don’t need to be an analyst, but you do need to be sharp)

-

AI fluency: You automate and integrate AI into your daily workflows, going well beyond basic LLM prompts

-

Genuine interest in finance, investing or the fintech space

## **What we offer**

-

Working with a highly motivated and successful team of high performers - with real ownership and room to grow

-

A culture that values talent, ideas, and execution

-

Real impact - your work will help shape growth for a product used by millions of investors

-

Challenges that will help you grow fast and unlock your potential

Are you ready to accelerate your career with us? We'd love to hear from you!

We process applicant data confidentially and in accordance with applicable data protection laws. We may use AI-powered tools to help review applications, but all hiring decisions are made by our human recruitment team. Where required by law, we rely on your consent to use these tools.
You may withdraw this consent or exercise your data protection rights at any time by contacting us.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
