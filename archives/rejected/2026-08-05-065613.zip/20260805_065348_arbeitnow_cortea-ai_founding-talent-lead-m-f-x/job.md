# Founding Talent Lead (m/f/x)

Posted: 2026-08-04T23:40:50Z

## Rejection

- Category: tech_stack
- Reason: role does not mention Go/Golang or PHP

## About Cortea

We’re **Cortea**, a Berlin startup **transforming audits with AI**. Manual, document-heavy audits waste expert time while demand keeps rising. Our **AI-powered software and specialized AI agents** remove the repetitive work so auditors can focus on judgment.

Backed by top-tier VCs with >15m funding, with a working product and paying customers, we’re rapidly scaling.

We value **first-principles thinking, speed, trust, and kindness**. We build side by side **in our Berlin office**.

## The Role

You build talent foundations. You’ll design a process, that bring in exceptional talent across Tech and Non-Tech, and build a culture we’re proud of.

## What you’ll do

-

**Own the Talent end to end:** job design → scope → JD → sourcing → structured interviews → offer → close

-

**Build a Talent Engine: **attract great people proactively; both inbound and outbound

-

**Raise the hiring bar:** scorecards, trained interviewers, consistent candidate experience

-

**Shape our brand** for Tech/AI talent with content, events, and a strong referral loop

-

**Be culture-positive:** partner with founders on rituals, onboarding handover, and feedback loops

## You’ll be great at this if you

-

Have **5+ years** of TA in a fast environment (startup/scale-up or agency)

-

Have hired **top talent before** and know the difference in how to assess them

-

Communicate clearly, leverage our founding team, and make data driven decisions fast

-

Can show **early-stage track record** you’re proud of

-

Think in systems and improve with data; bonus if you’ve built employer branding for engineers/AI

## How we work

-

We value **kindness + candor + execution**, speed with care, and strong ownership

-

We’re **fully in-office** in Berlin because we like building side by side

-

We hire with **structured interviews and clear scorecards** to reduce bias

-

Non-linear paths welcome. Career breaks welcome. If you’re unsure, apply.

## What we offer

-

**High impact from day one** and a path to Head of Talent/People as we grow

-

**Competitive salary + meaningful equity** (range shared on the first call)

-

**In-office energy**. shared lunches, whiteboard time, fast decisions, real teamwork

-

**Uncapped growth**. Budget for tools, learning, and events you choose

## Interview process

-

**Intro Call (25 min)** with [Liza](https://www.linkedin.com/in/liza-shaban/)

-

**Expert interview (45 min):** with [Valentin](https://www.linkedin.com/in/valentinneumann/) (Co-Founder) - deep dive into: sourcing strategy, process design, quality in decisions)

-

**Cultural interview (45 min):** with [Philipp](https://www.linkedin.com/in/philipp-hoevelmann/) (Co-Founder) - collaboration, judgment, and culture add

-

**On-site day (Berlin):** meet the team and work on a real life assignment

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
