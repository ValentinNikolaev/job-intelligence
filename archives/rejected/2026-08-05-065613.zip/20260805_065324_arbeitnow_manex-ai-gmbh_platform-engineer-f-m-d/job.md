# Platform Engineer (f/m/d)

Posted: 2026-08-05T02:40:35Z

## Rejection

- Category: tech_stack
- Reason: role does not mention Go/Golang or PHP

##

## Who we are

Manufacturing runs on fragmented data: machines, sensors, and decade-old systems that don't speak to each other. Data sits in departmental silos, knowledge lives in people's heads, and AI can not unfold its potential in point solutions that don’t deliver. At Manex AI, we build that missing layer with our platform: It handles manufacturing data at scale, models the factory ontology and builds agentic applications that reason and act across it.

We're a small team in Munich, backed by Lightspeed and BlueYard, with engineers from top companies. We ship fast, work close to the shop floor and we don't ship things we're not proud of.

## The role

You'll build and run our platform infrastructure: from continuous integration and deployment to our Kubernetes and cloud infrastructure. The work spans high-availability systems, PostgreSQL management, networking, Linux, and logging infrastructure with tracing and monitoring - you'll work where your skills count most. You own the infrastructure end-to-end and work directly with founders and customers.

## **You should apply if you**

-

Build reliable continuous delivery systems

-

Operate scalable Kubernetes environments

-

Write maintainable infrastructure as code

-

Understand networking, security, and observability

-

Design and operate reliable storage systems

-

Enjoy improving developer experience and automation

## **Nice to have**

-

Kubernetes, Helm, Terraform, or OpenTofu

-

AWS and GitHub Actions

-

PostgreSQL, graph databases, or S3

-

Backups, replication, and disaster recovery

-

Grafana, Prometheus, and OpenTelemetry

-

On-premise or hybrid-cloud deployments

## What we offer

-

A cooperative team where you own your work, but never solve hard problems alone

-

Competitive salary and equity

-

High trust and ownership from day one

-

Corporate Wellpass membership, subsidized public transport

-

Regular offsites with the greatest team - think austrian mountains, lakeside retreats, or european cities

-

Relocation support, incl. corporate housing offers

Are you willing to start contributing to European autonomy at scale? Apply now!

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
