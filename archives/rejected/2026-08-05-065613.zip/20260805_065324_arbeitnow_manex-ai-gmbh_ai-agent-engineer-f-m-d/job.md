# AI Agent Engineer (f/m/d)

Posted: 2026-08-05T02:40:35Z

## Rejection

- Category: tech_stack
- Reason: role does not mention Go/Golang or PHP

# **AI Agent Engineer (f/m/d)**

# Who we are

Manufacturing runs on fragmented data: machines, sensors, and decade-old systems that don't speak to each other. Data sits in departmental silos, knowledge lives in people's heads, and AI can not unfold its potential in point solutions that don’t deliver. At Manex AI, we build that missing layer with our platform: It handles manufacturing data at scale, models the factory ontology and builds agentic applications that reason and act across it.

We're a small team in Munich, backed by Lightspeed and BlueYard, with engineers from top companies. We ship fast, work close to the shop floor and we don't ship things we're not proud of.

## **The role**

You'll build our AI agent stack: From the tools, skills, and subagents, plus the MCP infrastructure that connects them. The work spans agent workflows, memory and context management, sandboxed execution, and agent observability - you'll work where your skills count most. You own agentic systems end-to-end and work directly with founders and customers.

## **You should apply if you**

-

Have built AI agents or are eager to learn

-

Bring experience with agent workflows, tools, skills and subagents

-

Are interested in MCP, context and memory management at scale

-

Build secure, sandboxed execution environments

-

Care about evaluation, observability, safety, and reliability

-

Write maintainable Python or TypeScript

## **Nice to have**

-

MCP servers and clients

-

Tool design and multi-agent orchestration

-

Containers, code execution, and sandboxing

-

Agent evaluation, tracing, observability (e.g., Langfuse) and guardrails

-

Retrieval, memory, and prompt engineering

-

LLM APIs, open-source models and proxies (e.g., LiteLLM, OpenRouter)

## What we offer

-

A cooperative team where you own your work, but never solve hard problems alone

-

Competitive salary and equity

-

High trust and ownership from day one

-

Corporate Wellpass membership, subsidized public transport

-

Regular offsites with the greatest team - think austrian mountains, lakeside retreats, or european cities

-

Relocation support, incl. corporate housing offers

Are you willing to start contributing to European autonomy at scale? Apply now!

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
