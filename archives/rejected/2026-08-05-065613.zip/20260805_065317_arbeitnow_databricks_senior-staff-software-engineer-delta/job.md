# Senior Staff Software Engineer - Delta

Posted: 2026-08-05T02:56:18Z

## Rejection

- Category: tech_stack
- Reason: role does not mention Go/Golang or PHP

P-1127

At Databricks, we are obsessed with enabling data teams to solve the world's toughest problems, from security threat detection to cancer drug development. We do this by building and running the world's best data and AI infrastructure platform, so our customers can focus on the high value challenges that are central to their own missions.

Our engineering teams build highly technical products that fulfill real, important needs in the world. We develop and operate one of the largest scale software platforms. The fleet consists of millions of virtual machines, generating terabytes of logs and processing exabytes of data per day. At our scale, we regularly observe cloud hardware, network, and operating system faults, and our software must gracefully shield our customers from any of the above.

The Delta DML team owns the core write-path operations for Delta Lake, the open-source storage layer behind the Databricks Lakehouse. Our mission is to deliver industry-leading performance and a seamless user experience at massive scale, with most data written in Databricks flowing through our platform. We drive performance innovations like Low Shuffle Merge and Deletion Vectors and actively contribute to open source efforts to unify Delta and Iceberg formats.

We are seeking a highly skilled and experienced Senior Staff Software Engineer to join our backend team. In this role, you will be instrumental in designing, developing, and maintaining robust backend systems that power Databricks workspaces. You will build the next-generation platform for serving workspace assets, ensuring high QPS, low latency, reliable, and performant systems, proactively addressing the future growth challenges. Additionally, as a senior member of the team, you will provide technical leadership, mentorship, and guidance to junior engineers, contributing to the overall improvement of team coding practices and system designs.

**The Impact you will have:**

- Solve real business needs at large scale by applying your software engineering.

- Low level systems debugging, performance measurement, and optimization on large production clusters.

- Build architecture design, influence product roadmap, and take ownership and responsibility over new projects.

- Introduce tools to allow greater automation and operability of services.

- Use your deep experience to help prevent and investigate production issues.

- Plan and lead complicated technical projects that work with several teams within the company.

- Contribute as a technical team lead by mentoring others, lead sprint planning, delegating work and assignments to team members and participate in project planning.

**What we look for:**

- 15+ years industry experience building and supporting large-scale distributed systems.

- Comfortable working towards a multi-year vision with incremental deliverables.

- Motivated by delivering customer value and impact.

- Strong foundation in algorithms and data structures and their real-world use cases.

- Experience driving company initiatives towards customer satisfaction.

- BS/MS/PhD in Computer Science or related majors, or equivalent experience.

**About Databricks**

Databricks is the Data and AI company. More than 20,000 organizations worldwide — including adidas, AT&T, Bayer, Block, Mastercard, Rivian, Unilever, and 70% of the Fortune 500 — rely on the Databricks Data + AI Platform to build and scale data and AI apps, analytics and agents. Headquartered in San Francisco with 30+ offices around the globe, Databricks offers a unified platform that includes Genie, Lakebase, Agent Bricks, Lakeflow, Lakehouse, and Unity Catalog. To learn more, follow Databricks on [LinkedIn](https://www.linkedin.com/company/databricks), [X](https://x.com/databricks), [YouTube](https://www.youtube.com/@Databricks), and [Instagram](https://www.instagram.com/databricksinc/?hl=en).

**Benefits

**At Databricks, we strive to provide comprehensive benefits and perks that meet the needs of all of our employees. For specific details on the benefits offered in your region click [here](https://docs.google.com/document/d/154un3e8Xav4BceOSlcYFZRGEuQI54xMxVydRwQn54eQ/edit?usp=sharing).

**Our Commitment to Diversity and Inclusion**

At Databricks, we are committed to fostering a diverse and inclusive culture where everyone can excel. We take great care to ensure that our hiring practices are inclusive and meet equal employment opportunity standards. Individuals looking for employment at Databricks are considered without regard to age, color, disability, ethnicity, family or marital status, gender identity or expression, language, national origin, physical and mental ability, political affiliation, race, religion, sexual orientation, socio-economic status, veteran status, and other protected characteristics.

**Compliance**

**If access to export-controlled technology or source code is required for performance of job duties, it is within Employer's discretion whether to apply for a U.S. government license for such positions, and Employer may decline to proceed with an applicant on this basis alone.**

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
