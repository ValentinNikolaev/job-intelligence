# Professor (m/f/d) of Data Science

Posted: 2026-08-05T02:09:15Z

## Rejection

- Category: tech_stack
- Reason: role does not mention Go/Golang or PHP

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
