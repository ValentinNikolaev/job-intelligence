# Junior Fachinformatiker/-in (m/w/d) – Vollzeit

Posted: 2026-09-18T17:30:11Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**Wir sind eine der am schnellstwachsenden Digitalagenturen Hamburgs und suchen zum nächstmöglichen Zeitpunkt neue Mitarbeiter/innen mit Schwerpunkt Wirtschaftsinformatik für den Bereich Business Development
**

**Was macht die Cordes Consulting GmbH genau?**

Wir sind eine Werbeagentur, welche Handwerksunternehmen durch innovative Social-Media-Strategien dabei hilft, mehr Bewerbungen von Fachkräften aus der Region zu erhalten. Wir vermarkten also mittelständische Unternehmen als attraktive Arbeitgeber in den sozialen Netzwerken.

Du hast Erfahrung mit digitalen Themen und kennst dich mit Low-Code-/No-Code-Lösungen sowie API-Tools wie Zapier oder [Make.com](http://Make.com) aus – oder bist in der Lage, dich schnell und eigenständig einzuarbeiten? Dann ist unser Bereich IT und Business Development die richtige Abteilung für dich.

Als Fachinformatiker/-in gestaltest und automatisierst du unsere Prozesse mit modernen Tools. Du sorgst dafür, dass Systeme ineinandergreifen, Datenflüsse reibungslos funktionieren und unsere Abläufe noch effizienter werden.

**Aufgabengebiete:**

-

Automatisierung unserer Geschäftsprozesse mit No-Code / Low-Code Tools wie n8n, Zapier, Make

-

Aufbau, Pflege und Verwaltung von Airtable-Datenbanken

-

Entwicklung von Front-Ends und Interfaces mit No-Code / Low-Code-Tools

-

Management und Weiterentwicklung unseres CRM-Systems (insbesondere HubSpot)

-

Planung, Umsetzung und Implementierung von neuen Geschäftsprozessen

-

Dokumentation & Konzeption von digitalen Geschäftsprozessen

-

Anwenderschulung & -betreuung

**Wenn du weitere Informationen zu unserem Unternehmen und deiner Karriere bei Cordes Consulting haben möchtest, findest du diese auf www.cordes-karriere.de.
**

**Gehalt: Junior Fachinformatiker (m/w/d): 5.000 € brutto im Monat**

**Weiterentwicklungs- und Aufstiegsmöglichkeiten sind vorhanden.**

**Das erwartet Dich bei uns:
**

-

**Eine gute Vergütung** über dem Branchendurchschnitt.

-

**Ausführliche interne Schulung: **Durch unser internes Schulungssystem lernst du alles, was du für deine neue Tätigkeit bei uns im Unternehmen benötigst.

-

**Hervorragende Aufstiegsmöglichkeiten**: Über die nächsten Jahre werden wir weiter stark wachsen.

-

**Einen tollen Firmenstandort** in der Hamburger Innenstadt

-

**Eine tolle Arbeitsatmosphäre:** Uns ist ein positives Umfeld wichtig. Der Umgang untereinander ist sehr kollegial und familiär. Wir ziehen alle am gleichen Strang.

-

**Ein dynamisches Team** und ein motivierendes Arbeitsumfeld.

-

**Einen sicheren Arbeitsplatz:** Jede Person, die wir einstellen, soll langfristig mit uns wachsen. Das Ziel jeder Einstellung ist eine unbefristete Übernahme.

-

**Eine erstklassige Büroausstattung:** Wir arbeiten ausschließlich mit moderner Technik und Arbeitsausstattung.

-

Wir übernehmen die Kosten für dein Deutschlandticket oder einen Tiefgaragenstellplatz in unserem Bürogebäude.

-

**Cordes Consulting Gesundheitssystem: **Profitiere von umfangreichen Gesundheitsleistungen für dich und deine Familienangehörigen (u. a. 900 € jährliches Gesundheitsbudget für Privatleistungen, Facharzt-Terminvereinbarung innerhalb von 5-10 Tagen, ärztliche Zweitmeinung sowie ein 24/7 Gesundheitstelefon)

-

Erfolgreich abgeschlossene Ausbildung als Fachinformatiker/-in (z. B. Fachrichtung Anwendungsentwicklung, Systemintegration, Digitale Vernetzung oder Daten- und Prozessanalyse) oder eine vergleichbare IT-Ausbildung, alternativ erste praktische Erfahrungen im Bereich IT / Automatisierung

-

Analytisch-methodisches und strukturiertes Denken, sehr gute analytische Fähigkeiten und schnelle Auffassungsgabe

-

Erste Erfahrungen im Projektmanagement sowie hohe Disziplin und Organisationsfähigkeit

-

Ergebnis- und lösungsorientierte Arbeitsweise, Fähigkeit bestehenden Prozessen zu folgen, diese zu verstehen und zu verbessern

-

Ausgeprägte Teamfähigkeit, starkes Kommunikationsvermögen und sicheres Auftreten

-

Sehr gute schriftliche Ausdrucksweise in Deutsch

-

Belastbarkeit und ein guter Umgang mit Leistungsdruck

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
