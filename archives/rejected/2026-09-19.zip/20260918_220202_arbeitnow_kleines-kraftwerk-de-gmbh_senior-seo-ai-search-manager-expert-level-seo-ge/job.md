# Senior SEO & AI Search Manager (Expert Level) | SEO, GEO & E-Commerce | Achim, hybrid

Posted: 2026-09-18T20:09:53Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**Kleines Kraftwerk & Du**

**Wir sind Kleines Kraftwerk, ein junges Unternehmen mit großer Ambition. **

Wir sind Kleines Kraftwerk, ein junges Unternehmen mit großer Ambition. In nur drei Jahren sind wir stark gewachsen und noch lange nicht am Ziel. Bei uns erwarten dich Verantwortung, Tempo und echter Gestaltungsspielraum – verbunden mit der Erwartung, dass du ihn nutzt.

Mit unseren Produkten bringen wir die Energie von morgen direkt zu den Menschen nach Hause. Unsere Mission ist es, nachhaltige Energie einfach, zugänglich und alltagstauglich zu machen.

Du verstehst SEO nicht nur als Rankings und Keywords, sondern als strategischen Wachstumskanal? GEO, AI Search und die Sichtbarkeit in KI-basierten Suchsystemen sind für dich schon heute relevante Bestandteile von Search? Dann suchen wir genau dich.

Als unser:e neue:r

Senior SEO & AI Search Manager:in / Expert Level

verantwortest du die strategische und operative Weiterentwicklung unseres SEO-Kanals. Du identifizierst Wachstumspotenziale, setzt klare Prioritäten und verbindest fundierte SEO-Expertise mit Daten, E-Commerce und neuen Entwicklungen rund um GEO & AI Search.

**Wofür du Verantwortung übernimmst**

- Aufbau und Weiterentwicklung einer nachhaltigen SEO-Strategie: Du entwickelst unsere SEO-Strategie kontinuierlich weiter und identifizierst neue Wachstumspotenziale, dabei schaffst du skalierbare Themen- und Content-Strukturen für nachhaltiges organisches Wachstum.
- Weiterentwicklung des technischen SEO: Du entwickelst unsere technische SEO-Architektur gemeinsam mit E-Commerce und externer IT weiter und sorgst so für eine stabile und skalierbare technische SEO-Basis.
- SEO, GEO & AI Search etablieren: Du entwickelst unsere organische Search-Strategie von SEO, Technical SEO und Content bis hin zu GEO und AI Search weiter. Dabei identifizierst du neue Potenziale und sorgst dafür, dass wir dort sichtbar sind, wo Menschen heute und morgen suchen und Kaufentscheidungen treffen.
- Klarheit in unseren Such-Daten schaffen: Du wertest Search Console und GA4 eigenständig aus, trennst organischen von bezahltem Traffic sauber voneinander und erkennst, wo wir uns mit eigenen Seiten oder Keywords selbst kannibalisieren – und leitest daraus konkrete Maßnahmen ab.
- Steuerung und Priorisierung der SEO-Maßnahmen: Du priorisierst SEO-Maßnahmen datenbasiert nach Business Impact und Ressourcen und sorgst für klare Entscheidungsprozesse.
- Synergie zwischen Content & SEO schaffen: Du verzahnst Content-Strategie und SEO, entwickelst Optimierungsprozesse weiter und integrierst die SEO-Anforderungen auf technische und kreative Weise in Content-, Brand- und Kreativprozesse.
- Interdisziplinäre Zusammenarbeit & Funnel-Denken: Du koordinierst bereichsübergreifende SEO-Projekte mit E-Commerce, CRO und dem Visual Design Team und stellst sicher, dass SEO frühzeitig in relevante Prozesse integriert wird. Dabei behältst du im Blick, wie sich Such-Traffic entlang des gesamten Funnels in Conversion übersetzt – SEO-Erfolg heißt für dich nicht nur Sichtbarkeit, sondern Wirkung.
- Abstimmung mit externen Publisher- und Affiliate-Partnern: Du stimmst dich inhaltlich und strategisch mit unseren externen Publisher-/Affiliate-Partnern ab, die im umkämpften Balkonkraftwerk-Markt eine wichtige Rolle für unsere Sichtbarkeit spielen – die operative Partnerpflege liegt extern, die SEO-Logik dahinter bei dir.

**Womit du punkten kannst**

- Mehrjährige Berufserfahrung im Bereich SEO als Expert:in, idealerweise im E-Commerce- oder Agenturumfeld mit strategischer Verantwortung.
- Fundierte Kenntnisse in technischer SEO, Content-SEO und datengetriebener Optimierung.
- Erfahrung in der Entwicklung und Umsetzung nachhaltiger SEO-Strategien.
- Sicherer, eigenständiger Umgang mit Search Console und GA4 – insbesondere zur Trennung von organischem und bezahltem Traffic sowie zur Identifikation von Keyword-/Content-Kannibalisierung.
- Erfahrung oder ausgeprägtes Interesse an GEO und AI Search als festem Bestandteil moderner Search-Strategien.
- Sehr gute analytische Fähigkeiten sowie ein sicherer Umgang mit SEO- und Webanalyse-Tools.
- Erfahrung in der Priorisierung komplexer Projekte und der Zusammenarbeit mit interdisziplinären Teams.
- Verständnis für Funnel- und Conversion-Logik – du denkst über die reine Ranking-Position hinaus.
- Strukturierte, eigenverantwortliche Arbeitsweise sowie ausgeprägte Kommunikationsstärke.
- Hohe Affinität für Daten, Prozesse und kontinuierliche Optimierung.

**Worauf du dich freuen kannst**

08/15-Benefits? Nicht bei uns!

Gestalte mit uns die Zukunft der nachhaltigen Energieversorgung: Bei uns bekommst du Verantwortung, Raum für deine Ideen und die Chance, echten Impact zu erzielen. Deine Arbeit trägt dazu bei, die Welt ein Stück grüner zu machen – und das jeden Tag!

- Gemeinsam möchten wir wachsen: Dabei setzen wir auf ein starkes WIR-Gefühl sowie eine freundschaftliche Teamkultur mit flachen Hierarchien, offener Kommunikation und kurzen Entscheidungswegen, die wir nicht nur im Arbeitsalltag, sondern auch bei Teamevents leben.
- Raum für deine Ideen:Du bist Teil eines Teams, in dem deine Ideen gehört und gebraucht werden, du dich einbringen und richtig mitgestalten kannst.
- Work-Life-Balance ist uns wichtig: du hast flexible Arbeitszeiten, 2 Tage Home-Office pro Woche, 28 Tage Urlaub sowie 5 Tage Workation im Jahr, außerdem hast du an deinem Geburtstag frei!
- Deine Gesundheit und Zukunft liegen uns am Herzen: Wir unterstützen dich dabei, fit und gesund zu bleiben; erhalte einen Zuschuss zu Wellpass sowie zur betrieblichen Altersvorsorge und exklusive Rabatte auf unsere Produkte.
- Ein Arbeitsplatz zum Wohlfühlen: Dich erwarten moderne, lichtdurchflutete Büros und eine phänomenale Dachterrasse, die zum Durchatmen und Austauschen einlädt.

**Du willst Teil der Energiewende werden?**

**Gestalte mit uns die Zukunft der erneuerbaren Energien. Join uns und werde Teil des Teams!**

Wir sind ein **ambitioniertes Start-up **im Bereich **erneuerbare Energien **mit einer klaren Mission:erneuerbare Energie von morgen für alle zugänglich machen. Dafür suchen wir Menschen, die Verantwortung übernehmen, eigene Ideen einbringen und Lust haben, gemeinsam mit uns zu wachsen: in einer dynamischen Umgebung, in der du viel Gestaltungsspielraum hast, Strukturen mit aufbauen kannst, eigene Entscheidungen triffst und direkten Einfluss auf den Erfolg des Unternehmens nimmst.

Dabei ist uns egal, woher du kommst, an was du glaubst, wen du liebst, womit du dich identifizierst, wie alt du bist, ob du neurodivers bist oder eine Behinderung hast – die Welt ist bunt und wir können es kaum erwarten, von dir zu lesen! Alle Geschlechter sind Willkommen!

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
