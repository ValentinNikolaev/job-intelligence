# Field Application Engineer - AI Software & Hardware

Posted: 2026-09-18T17:55:03Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Tenstorrent is leading the industry on cutting-edge AI technology, revolutionizing performance expectations, ease of use, and cost efficiency. With AI redefining the computing paradigm, solutions must evolve to unify innovations in software models, compilers, platforms, networking, and semiconductors. Our diverse team of technologists have developed a high performance RISC-V CPU from scratch, and share a passion for AI and a deep desire to build the best AI platform possible. We value collaboration, curiosity, and a commitment to solving hard problems. We are growing our team and looking for contributors of all seniorities.

We’re looking for a Field Application Engineer who’s wired for AI/ML, fluent in real-world problem-solving, and excited to build with the people actually using what we make. You will collaborate closely with the sales team and enterprise customers, leveraging your deep technical knowledge in AI to drive the adoption of our products and solutions. This is a customer-facing role that requires both technical expertise and excellent communication skills to convey complex technical concepts to non-technical stakeholders.

This role is** remote** based out of Munich, Germany.

*We welcome candidates at various experience levels for this role. During the interview process, candidates will be assessed for the appropriate level, and offers will align with that level, which may differ from the one in this posting.*

**Who You Are**

- You’ve lived in the AI/ML trenches, whether as a field engineer, a solutions architect, or the one tapped in when things needed to “just work.”

- You speak both machine and human. Whether it’s a researcher or a skeptical executive, you know how to break things down and bring them to life.

- You’re fired up about generative models, LLMs, and the edge of what’s possible when software meets purpose-built silicon.

- Work directly with customers in meetings, presentations, and workshops to understand their technical challenges and provide effective solutions.

- Partner closely with sales operations and product teams to provide feedback from customers and help shape future product enhancements.

**What We Need**

- Strong customer-facing skills with 5+ years of relevant technical, enterprise experience (such as Sales Engineer, Solutions Engineer, or Technical Account Manager).

- Your field insight will help shape our roadmap, our features, and the way we show up for developers.

- Proven expertise in AI technologies and frameworks, including machine learning, deep learning, natural language processing (NLP),computer vision, PyTorch or TensorFlow.

- Experience with embedded systems, FPGA Architecture or AI accelerators.

- Good understanding of data center, server architecture and deployment, thermal/power, and infrastructure management.

**What You Will Learn**

- How to explore and push the boundaries of AI performance on custom silicon and help developers do the same.

- What it’s like to build the future from scratch, working alongside teams creating hardware, software, and everything in between.

- To master the craft of fine-tuning LLMs, optimizing vision models, and building AI pipelines that run at scale.

- An understanding of why field roles drive real impact turning on-the-ground insight into product breakthroughs and platform momentum.

*Tenstorrent offers a highly competitive compensation package and benefits, and we are an equal opportunity employer.*

*This offer of employment is contingent upon the applicant being eligible to access U.S. export-controlled technology. Due to U.S. export laws, including those codified in the U.S. Export Administration Regulations (EAR), the Company is required to ensure compliance with these laws when transferring technology to nationals of certain countries (such as EAR Country Groups D:1, E1, and E2). These requirements apply to persons located in the U.S. and all countries outside the U.S. As the position offered will have direct and/or indirect access to information, systems, or technologies subject to these laws, the offer may be contingent upon your citizenship/permanent residency status or ability to obtain prior license approval from the U.S. Commerce Department or applicable federal agency. If employment is not possible due to U.S. export laws, any offer of employment will be rescinded.*

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
