# No-Code / Low-Code Automatisierungsexperte (m/w/d) – Vollzeit (Zapier, Make.com, n8n, AirTable etc.)

Posted: 2026-09-18T17:30:11Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**Wir sind eine der am schnellstwachsenden Digitalagenturen Hamburgs und suchen zum nächstmöglichen Zeitpunkt neue Mitarbeiter/innen mit Schwerpunkt Wirtschaftsinformatik für den Bereich Business Development

**

**Was macht die Cordes Consulting GmbH genau?**

Wir sind eine Werbeagentur, welche Handwerksunternehmen durch innovative Social-Media-Strategien dabei hilft, mehr Bewerbungen von Fachkräften aus der Region zu erhalten. Wir vermarkten also mittelständische Unternehmen als attraktive Arbeitgeber in den sozialen Netzwerken.

Du hast Erfahrung mit digitalen Themen und kennst dich mit Low-Code-/No-Code-Lösungen sowie API-Tools wie Zapier oder Make.com aus – oder bist in der Lage, dich schnell und eigenständig einzuarbeiten? Dann ist unser Bereich IT und Business Development die richtige Herausforderung für dich.

Als No-Code / Low-Code Automatisierungsexperte (m/w/d) gestaltest und automatisierst du unsere Prozesse mit modernen Tools. Du sorgst dafür, dass Systeme ineinandergreifen, Datenflüsse reibungslos funktionieren und unsere Abläufe noch effizienter werden.

**Aufgabengebiete:**

-

Automatisierung unserer Geschäftsprozesse mit No-Code / Low-Code Tools wie n8n, Zapier, Make

-

Aufbau, Pflege und Verwaltung von Airtable-Datenbanken

-

Entwicklung von Front-Ends und Interfaces mit No-Code / Low-Code-Tools

-

Management und Weiterentwicklung unseres CRM-Systems (insbesondere HubSpot)

-

Planung, Umsetzung und Implementierung von neuen Geschäftsprozessen

-

Dokumentation & Konzeption von digitalen Geschäftsprozessen

-

Anwenderschulung & -betreuung

**Gehalt: No-Code / Low-Code Automatisierungsexperte (m/w/d): 5.500 € brutto im Monat**

Weiterentwicklungs- und Aufstiegsmöglichkeiten sind vorhanden.

**Wenn du weitere Informationen zu unserem Unternehmen und deiner Karriere bei Cordes Consulting haben möchtest, findest du diese auf www.cordes-karriere.de.**

**Das erwartet Dich bei uns:
**

-

**Eine gute Vergütung** über dem Branchendurchschnitt.

-

**Ausführliche interne Schulung: **Durch unser internes Schulungssystem lernst du alles, was du für deine neue Tätigkeit bei uns im Unternehmen benötigst.

-

**Hervorragende Aufstiegsmöglichkeiten**: Über die nächsten Jahre werden wir weiter stark wachsen.

-

**Einen tollen Firmenstandort** in der Hamburger Innenstadt

-

**Eine tolle Arbeitsatmosphäre:** Uns ist ein positives Umfeld wichtig. Der Umgang untereinander ist sehr kollegial und familiär. Wir ziehen alle am gleichen Strang.

-

**Ein dynamisches Team** und ein motivierendes Arbeitsumfeld.

-

**Einen sicheren Arbeitsplatz:** Jede Person, die wir einstellen, soll langfristig mit uns wachsen. Das Ziel jeder Einstellung ist eine unbefristete Übernahme.

-

**Eine erstklassige Büroausstattung:** Wir arbeiten ausschließlich mit moderner Technik und Arbeitsausstattung.

-

Wir übernehmen die Kosten für dein Deutschlandticket oder einen Tiefgaragenstellplatz in unserem Bürogebäude.

-

**Cordes Consulting Gesundheitssystem: **Profitiere von umfangreichen Gesundheitsleistungen für dich und deine Familienangehörigen (u. a. 900 € jährliches Gesundheitsbudget für Privatleistungen, Facharzt-Terminvereinbarung innerhalb von 5-10 Tagen, ärztliche Zweitmeinung sowie ein 24/7 Gesundheitstelefon)

-

Erfolgreich abgeschlossenes Bachelor- oder Masterstudium (B.Sc. / M.Sc.) im Bereich Wirtschaftsinformatik, BWL, Business Administration, Business Management, Bankwesen oder eine Ausbildung im IT-Bereich bzw. nachweisbare Erfahrung im Bereich IT / Automatisierung

-

Analytisch-methodisches und strukturiertes Denken, sehr gute analytische Fähigkeiten und schnelle Auffassungsgabe

-

Erfahrung im Projektmanagement sowie hohe Disziplin und Organisationsfähigkeit

-

Ergebnis- und lösungsorientierte Arbeitsweise, Fähigkeit bestehenden Prozessen zu folgen, diese zu verstehen und zu verbessern

-

Ausgeprägte Teamfähigkeit, starkes Kommunikationsvermögen und sicheres Auftreten

-

Sehr gute schriftliche Ausdrucksweise in Deutsch

-

Belastbarkeit und ein guter Umgang mit Leistungsdruck

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
