# Stabstelle Fachkraft für Arbeitssicherheit / Sicherheitsfachkraft / Sicherheitsingenieur (m/w/d)

Posted: 2026-09-14T18:13:53Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Wenn es um Sicherheit geht, bist Du bei KÖGEL der zentrale Ansprechpartner – vom Auszubildenden bis zur Geschäftsleitung. Du übernimmst Verantwortung auf allen Ebenen: strategisch, beratend und operativ. Wir suchen Dich:

## Aufgaben

DEINE MISSION: DIE SICHERHEIT VON ÜBER 350 KOLLEGEN

- **Strategie:** Du verantwortest die nachhaltige Ausrichtung der Unternehmenssicherheit und entwickelst praxisnahe Sicherheitsstrategien. Mit klaren Empfehlungen und eigenen Entscheidungen setzt Du – ganz nach unserem Motto Gemeinsam | Sicher | Stark – Deine Pläne in die Tat um, verfolgst deren Erfolg und nimmst bei Bedarf Nachjustierungen vor.

- **Risikobeurteilung:** Du führst Begehungen auf unseren Baustellen durch. Dabei spürst Du Gefährdungen auf, analysierst Unfälle und sorgst dafür, dass alle Sicherheitsvorgaben eingehalten werden.

- **Schulungen:** Du hebst das Sicherheitsbewusstsein im Team durch regelmäßige Unterweisungen und anschauliche Schulungen auf ein ganz neues Level.

- **Netzwerk**: Du bist unser direkter Draht zu Aufsichtsbehörden und Berufsgenossenschaften – immer bestens vernetzt und up to date.

## Qualifikation

DEIN PROFIL: DU WILLST MEHR ALS NUR BERATEN

- **Qualifikation:** Du hast ein technisches Studium abgeschlossen oder bist Meister/Techniker und verfügst zusätzlich über eine Qualifikation als Fachkraft für Arbeitssicherheit, SiGeKo oder als Sicherheitsingenieur gemäß § 7 ASiG.

- **Berufserfahrung:** Du bringst praktische Erfahrung im Bereich Arbeitssicherheit mit und bist mit den Gegebenheiten und Abläufen auf Baustellen bestens vertraut.

- **Rechtliche Expertise:** Du kennst die relevanten Gesetze und Normen für Arbeits- und Gesundheitsschutz aus dem Effeff.

- **Arbeitsweise:** Du packst Aufgaben selbstständig und lösungsorientiert an, behältst den Überblick und triffst mutig Entscheidungen, wenn es darauf ankommt. Du bist bereit Verantwortung zu tragen.

- **Kommunikationsstil:** Klar, verbindlich und verständlich – Du bringst auch komplexe Themen auf den Punkt, immer kooperativ und auf Augenhöhe.

## Benefits

DEINE VORTEILE: WARUM DU UNS LIEBEN WIRST!

- **Echter Einfluss:** Verantwortung für die strategische Weiterentwicklung des Arbeitsschutzes – mit Entscheidungsfreiheit und Ergebnissen, die Deine Handschrift tragen.

- **Wertschätzende Unternehmenskultur:** Ein respektvolles Miteinander auf Augenhöhe und Zusammenhalt leben wir im Team KÖGEL – bei uns duzt jeder jeden.

- **Finanzielle Benefits:** Bei uns bekommst Du einen Dienstwagen, Urlaubs- und Weihnachtsgeld, vermögenswirksame Leistungen, eine Berufsunfähigkeitsversicherung sowie Zuschüsse zur betrieblichen Altersvorsorge.

- **Gesundheitsboost:** Jährliches Gesundheitsbudget, Zahnzusatzversicherung, Vorsorgeuntersuchungen und der EGYM WellPass für Fitness & Freizeit.

- **Onboarding, das den Unterschied macht:** Kennenlern-Events und Dein persönlicher Einarbeitungspate machen Dir den Start leicht.

- **Wachstum & Weiterentwicklung:** KÖGEL bietet Dir eine Vielzahl an internen und externen Trainings, die Dich nach vorne bringen.

Entdecke auf unserer Karriereseite noch mehr spannende KÖGEL Benefits!

Du willst in einem Unternehmen arbeiten, das Deine Stärken erkennt und Dich wirklich fördert? Dann bewirb Dich jetzt und werde Teil unseres Teams!

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
