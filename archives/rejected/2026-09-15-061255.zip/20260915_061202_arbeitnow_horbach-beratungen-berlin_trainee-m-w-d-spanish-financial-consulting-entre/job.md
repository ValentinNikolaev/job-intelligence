# Trainee (m/w/d) Spanish Financial Consulting & Entrepreneurship

Posted: 2026-09-14T18:13:55Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Willst du in Berlin nur mitspielen oder die Finanzwelt aktiv mitgestalten und Brücken in die internationale Community bauen?

Vergiss staubige Bankfilialen und starre Hierarchien. Bei HORBACH Berlin bieten wir dir den Direkteinstieg in die High-End-Finanzberatung für Akademiker:innen, Expats und Professionals. Wir suchen keine Sachbearbeiter, sondern die nächste Generation von Entrepreneur-Persönlichkeiten. Nutze deine Spanischkenntnisse, um die schnell wachsende spanischsprachige Community sowie internationale Young Professionals exklusiv zu beraten und dir ein einzigartiges Netzwerk aufzubauen. Mit über 40 Jahren Markterfahrung im Rücken geben wir dir das Fundament für dein eigenes Business in der Hauptstadt.

## Aufgaben

**Das Traineekonzept:**

Wir investieren massiv in dich. Dein Weg bei uns ist ein aktiver Karrierestart:

- **Individuelle Qualifizierung:** Wir begleiten dich Schritt für Schritt bei deinem Weg im Consulting und bereiten dich gezielt auf deine Karriere und anerkannte Branchenzertifizierungen vor.

- **Entrepreneurship ab Tag 1:** Du lernst, wie man ein eigenes Business führt. Von der Akquise-Strategie bis zum komplexen Investment-Closing durchläufst du die gesamte Wertschöpfungskette.

- **Networking auf High-Level:** Du erschließt gezielt exklusive Netzwerke (Akademiker, Expats, Gründer) und kommunizierst auf Augenhöhe.

## Qualifikation

**🛠 Dein Profil:**

- **Sprachkompetenz:** Du sprichst Spanisch auf muttersprachlichem Niveau (oder fließend), um unsere internationale Zielgruppe in Berlin perfekt zu betreuen. Grundlegende Deutschkenntnisse für den Büroalltag sind hilfreich, aber kein Hindernis: Deine Persönlichkeit zählt!

- **Hintergrund:** Du hast ein (fast) abgeschlossenes Studium (Richtung ist Nebensache!) oder eine kaufmännische Ausbildung.

- **Mindset & Drive:** Du hast eine „Macher-Mentalität“, bist empathisch und hast Lust, dich fachlich und persönlich auf ein neues Level zu heben.

Quereinsteiger (m/w/d) mit Biss sind ausdrücklich willkommen!

## Benefits

Deine Benefits als Trainee:

- **Leistungsorientierung & Erfolg:** Deine Vergütung hat keinen Deckel. Wir bieten dir ein Provisionsmodell, das Fleiß und Ergebnisse direkt belohnt: Für Einkommenschancen weit über dem Marktdurchschnitt.

- **Entrepreneurship mit Back-up:** Arbeite mit der Freiheit eines Unternehmers (m/w/d) und baue dein eigenes Business in der Hauptstadt auf, während du das Sicherheitsnetz, die IT-Infrastruktur und die Strahlkraft einer etablierten Marke nutzt.

- **Work-Life-Balance & Flexibilität:** Gestalte deine Arbeitszeit und deinen Ort, dank der Remote-Optionen so, wie es zu deinem Leben passt. Bei uns zählt das Ergebnis, nicht die Anwesenheit.

- **Individuelle Karriere-Roadmap:** Ob Top-Consultant oder zukünftige Führungskraft: Wir planen gemeinsam deinen Aufstieg nach deinen Stärken, nicht nach Dienstjahren.

- **High-End Mentoring:** Ein erfahrener Mentor (m/w/d) begleitet dich durch ein strukturiertes Onboarding und sorgt dafür, dass du die steile Lernkurve im internationalen Markt erfolgreich meisterst.

- **Moderne Culture:** Erlebe ein Team in Berlin, das sich gegenseitig pusht, Erfolge gemeinsam feiert und in einem modernen Office im Herzen der Stadt arbeitet.

Kein Anschreiben? Kein Problem. Dein Lebenslauf reicht uns völlig!

**Bewirb dich jetzt und gestalte deine Zukunft als Financial Consultant bei HORBACH in Berlin!**

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
