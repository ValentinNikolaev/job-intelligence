# SAP EWM Consultant

Posted: 2026-09-14T18:14:18Z

## Rejection

- Category: language_requirement
- Reason: hard German language requirement without English green light

SAP EWM Consultant / Senior Consultant (m/w/d)

| **Festanstellung** | Remote / Hybrid | Deutschland

Sie möchten spannende SAP EWM-Projekte begleiten, Kunden bei der Digitalisierung ihrer Logistikprozesse beraten und sich fachlich weiterentwickeln?

Für unseren Mandanten, ein etabliertes SAP-Beratungshaus mit Fokus auf innovative Supply-Chain- und Logistiklösungen, suchen wir einen **SAP EWM Consultant / Senior Consultant (m/w/d)** in **unbefristeter Festanstellung**.

## Aufgaben

- Beratung bei der Konzeption, Einführung und Optimierung von SAP EWM-Lösungen

- Analyse und Optimierung von Lager- und Logistikprozessen

- **SAP EWM Customizing** sowie Umsetzung fachlicher Anforderungen

- Mitarbeit in Implementierungs-, Rollout- und Optimierungsprojekten

- Erstellung von Fachkonzepten und Prozessdokumentationen

- Unterstützung bei Tests, Go-Lives und Anwenderschulungen

- Enge Zusammenarbeit mit Kunden, Fachbereichen und Entwicklungsteams

- Als Senior Consultant übernehmen Sie zusätzlich Teilprojektverantwortung und unterstützen das Team fachlich

## Qualifikation

- Mehrjährige Erfahrung in der SAP-Beratung oder einer vergleichbaren Inhouse-Rolle mit Schwerpunkt SAP EWM

- Sehr gute Kenntnisse in SAP EWM und im Customizing

- Erfahrung mit SAP MM, SD, PP, TM oder QM von Vorteil

- Idealerweise Erfahrung mit SAP S/4HANA, Embedded oder dezentralem EWM

- Strukturierte und lösungsorientierte Arbeitsweise

- **Deutschkenntnisse auf C1-Niveau oder höher** sowie gute Englischkenntnisse

## Benefits

- Unbefristete Festanstellung bei einem etablierten SAP-Beratungshaus

- Anspruchsvolle SAP EWM-Projekte bei namhaften Kunden

- Flexible Arbeitsmodelle mit 100% Remote-Anteil

- Individuelle Weiterbildungs- und Zertifizierungsmöglichkeiten

- Klare Karriereperspektiven bis hin zu Projektleitung oder Solution Architecture

- Attraktive Vergütung und moderne Arbeitsausstattung

- Kollegiales Team mit kurzen Entscheidungswegen und viel Gestaltungsspielraum

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
