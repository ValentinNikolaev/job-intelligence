# Projekt / Office - Management (m/w/d) - Remote

Posted: 2026-09-14T18:14:31Z

## Rejection

- Category: tech_stack
- Reason: role does not mention Go/Golang or PHP

Wir suchen im Auftrag unseres Klienten T. Eilers & Partner Unterstützung im Bereich

**Projekt / Office - Management** und Organisation & Umsetzung

Das Unternehmen berät Unternehmer mit dem Ziel, Einnahmen und Ausgaben

strategisch zu optimieren. Damit aus Strategien konkrete Ergebnisse werden,

braucht es Struktur, klare Prozesse und konsequente Umsetzung. Genau hier

kommen Sie ins Spiel.

Wichtig: Wohnsitz oder Zweitwohnsitz in Deutschland erforderlich. Die

Zusammenarbeit erfolgt vollständig digital über ein strukturiertes Online-Büro mit

Zoom und Microsoft 365.

## Aufgaben

- Planung, Strukturierung und Umsetzung interner Projekte

- Optimierung bestehender Abläufe und Prozesse

- Koordination zwischen Team, Geschäftsführung und externen Partnern

- Termin- und Ressourcenmanagement

- Sicherstellung von Meilensteinen und Ergebnissen

- Vorbereitung von Auswertungen und Entscheidungsgrundlagen

## Qualifikation

- Sie arbeiten strukturiert und lösungsorientiert.

- Sie können mehrere Themen parallel steuern.

- Sie kommunizieren klar und verbindlich.

- Sie sind offen für digitale Tools und moderne Arbeitsweisen.

- Sie haben Interesse, sich in ein bestehendes System einzuarbeiten und sich

kontinuierlich weiterzuentwickeln.

- Erste Erfahrungen im organisatorischen oder projektbezogenen Umfeld sind von

Vorteil, jedoch nicht zwingend erforderlich.

## Benefits

- Rahmenbedingungen und Entwicklung

- Einstieg ab ca. 8 bis 15 Stunden pro Woche möglich, je nach Qualifikation

- Beispielhafte Einkommensspanne: ca. 530 € bis 3.850 € monatlich, abhängig

von Einsatz, Aktivität und Lernfortschritt

- Leistungsorientierte Vergütung mit Entwicklungsperspektive

- Einsatz in Teilzeit, Vollzeit oder auf selbstständiger Basis möglich

- Digitale Infrastruktur mit strukturierten Prozessen

- Weiterbildungsmöglichkeiten in den Bereichen Organisation, Führung und

Projektmanagement

Wenn Sie Verantwortung übernehmen möchten und strukturiert arbeiten, freuen wir

uns auf Ihre Bewerbung.

Ihre Bewerbungsunterlagen werden im Auftrag unseres Klienten an T. Eilers &

Partner weitergeleitet. Nach Eingang Ihrer Bewerbung erfolgt zeitnah eine

persönliche Kontaktaufnahme.

Ihre Ansprechpartnerin

Claudia Meyer

Personalverantwortliche

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
