# Community & Customer Success Manager (m/w/d)

Posted: 2026-09-14T18:13:42Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Gestalte mit uns die Zukunft smarter Katzenklappen

Wir sind **mousebouncer GmbH**, das Team hinter **ZeroMOUSE** – einer KI-gestützten Erweiterung für Katzenklappen, die verhindert, dass Katzen Mäuse und andere Beutetiere ins Haus bringen.

Unsere Produkte werden bereits von über **20.000 Kunden** genutzt und gehören zu den innovativsten Lösungen im Bereich Smart Pet Tech. Unsere Mission ist es, Technologie zu entwickeln, die den Alltag von Haustierbesitzern spürbar verbessert.

Damit unsere Kunden nicht nur ein großartiges Produkt erhalten, sondern auch jederzeit hervorragend betreut werden, suchen wir eine engagierte Persönlichkeit für den Bereich **Online Reputation & Community Management**.

## Aufgaben

Du bist die Stimme von ZeroMOUSE im Internet und sorgst dafür, dass Kunden sich jederzeit gut aufgehoben fühlen.

Zu deinen Aufgaben gehören unter anderem:

- Betreuung unserer Bewertungen auf Trustpilot, Amazon, Google und weiteren Plattformen

- Freundliche und professionelle Beantwortung von Kundenbewertungen

- Beobachtung von Social Media, Foren und Communitys (z. B. Reddit, Facebook, YouTube)

- Unterstützung bei der Lösung von Kundenproblemen gemeinsam mit unserem Support-Team

- Identifikation wiederkehrender Kritikpunkte und Ableitung von Verbesserungsvorschlägen

- Erstellung von monatlichen Reports zur Markenwahrnehmung und Kundenzufriedenheit

- Aufbau und Pflege einer positiven Online-Community

- Sammeln und Aufbereiten von Kundenstimmen, Erfolgsgeschichten und Testimonials

- Unterstützung bei der Erstellung von FAQ-, Hilfe- und Informationsinhalten

- Zusammenarbeit mit Produktentwicklung, Support und Marketing

## Qualifikation

- Ausgeprägte Kommunikationsfähigkeit und sehr gutes schriftliches Deutsch

- Gute Englischkenntnisse in Wort und Schrift

- Freude am Umgang mit Menschen und an kundenorientierten Lösungen

- Empathie, Geduld und diplomatisches Geschick

- Selbstständige und strukturierte Arbeitsweise

- Sicherer Umgang mit digitalen Tools

- Interesse an Technik und KI-Produkten

Idealerweise hast du bereits Erfahrung in einem oder mehreren dieser Bereiche:

- Customer Success

- Customer Support

- Community Management

- Online-Marketing

- E-Commerce

- Amazon oder Shopify

- Trustpilot oder andere Bewertungsplattformen

## Benefits

Das erwartet dich

- Eine sinnstiftende Tätigkeit mit direktem Einfluss auf unsere Kunden

- Ein innovatives KI-Produkt mit internationalem Wachstum

- Flache Hierarchien und schnelle Entscheidungen

- Flexible Arbeitszeiten

- Hybrides Arbeiten oder Remote (nach Absprache)

- Moderne Arbeitsmittel

- Viel Eigenverantwortung und Gestaltungsspielraum

- Ein motiviertes Team mit kurzen Entscheidungswegen

Arbeitszeit

20–30 Stunden pro Woche

Die Arbeitszeiten können flexibel gestaltet werden. Wichtig ist uns lediglich, dass Kundenanfragen und Bewertungen zeitnah bearbeitet werden.

Arbeitsort

Hybrid oder Remote – regelmäßige Abstimmungen mit unserem Team in Unterschleißheim bei München.

Warum diese Stelle besonders ist

Du bist nicht einfach für Bewertungen verantwortlich.

**Du sorgst dafür, dass tausende Katzenbesitzer täglich positive Erfahrungen mit unserer Marke machen. Du erkennst Verbesserungspotenziale frühzeitig, gibst wichtige Impulse an unsere Produktentwicklung weiter und hilfst aktiv dabei, unsere Marke international weiter auszubauen.**

**Bewirb dich jetzt**

Wenn du Lust hast, **Verantwortung zu übernehmen und gemeinsam mit uns eine der innovativsten Marken im Bereich Smart Pet Tech weiterzuentwickeln**, freuen wir uns auf deine Bewerbung.

Sende uns deinen Lebenslauf sowie ein kurzes Anschreiben mit deiner Motivation und deinem möglichen Eintrittstermin.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
