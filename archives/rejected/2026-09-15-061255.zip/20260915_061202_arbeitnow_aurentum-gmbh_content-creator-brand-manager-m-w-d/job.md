# Content Creator & Brand Manager (m/w/d)

Posted: 2026-09-14T18:14:07Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Wir suchen keinen klassischen Social-Media-Manager.

Wir suchen den Menschen hinter unserer Marke.

Du liebst Social Media, Storytelling, Fotografie und Videografie? Du möchtest nicht den ganzen Tag am Schreibtisch sitzen, sondern echte Projekte begleiten und aus dem Arbeitsalltag spannenden Content erschaffen?

Dann bist du bei uns genau richtig.

Wir sind Aurentum Immobilien – eines der modernsten Immobilienunternehmen in Niederbayern und der Oberpfalz. Neben der klassischen Immobilienvermittlung kaufen, entwickeln und sanieren wir selbst Immobilien, begleiten Eigentümer bei wichtigen Entscheidungen und bauen aktuell unseren zweiten Standort in Regensburg auf.

Bei uns passiert jeden Tag etwas Spannendes. Und genau diese Geschichten möchten wir künftig professionell erzählen.

Du arbeitest eng mit unserem Geschäftsführer zusammen und hilfst dabei, Aurentum als starke regionale Marke weiter auszubauen.

Diese Stelle ist nichts für Menschen, die den ganzen Tag am Schreibtisch sitzen möchten. Du begleitest unseren Geschäftsführer regelmäßig zu Baustellen, Besichtigungen, Notarterminen und spannenden Immobilienprojekten und machst daraus Content, der täglich tausende Menschen erreicht.

## Aufgaben

Kein Tag wird wie der andere sein.

Du bist verantwortlich für unseren gesamten Markenauftritt und begleitest unseren Geschäftsführer regelmäßig im Arbeitsalltag.

Deine Aufgaben:

- Planung und Produktion von Content für Instagram, Facebook und weitere Plattformen

- Erstellung von Reels, Storys, Kurzvideos und hochwertigem Bildmaterial

- Begleitung unseres Geschäftsführers bei Besichtigungen, Immobilienbewertungen, Baustellen, Notarterminen und Veranstaltungen

- Filmen, Fotografieren und eigenständige Nachbearbeitung des Contents

- Entwicklung kreativer Content-Ideen und neuer Videoformate

- Pflege und Weiterentwicklung unserer Website (Webflow)

- Erstellung neuer Landingpages, Blogbeiträge und SEO-Inhalte

- Unterstützung bei der Vermarktung unserer Immobilien

- Erstellung von Exposés, Objekttexten und Marketingmaterialien

- Betreuung unseres Google-Unternehmensprofils

- Unterstützung bei Newslettern und E-Mail-Marketing

- Analyse unserer Social-Media- und Website-Performance

- Aufbau und Weiterentwicklung unserer regionalen Markenbekanntheit

Du bist nicht einfach Marketingmitarbeiter.

Du bist aktiv daran beteiligt, unsere Marke sichtbar zu machen.

## Qualifikation

Uns ist wichtiger, was du kannst – nicht welches Zeugnis du besitzt.

Idealerweise bringst du Folgendes mit:

- Erfahrung im Bereich Social Media, Marketing oder Content Creation

- Leidenschaft für Fotografie und Videografie

- Sicherer Umgang mit Canva, CapCut, Adobe Premiere oder vergleichbaren Programmen

- Kreativität und ein Gespür für gutes Storytelling

- Sehr gute Deutschkenntnisse in Wort und Schrift

- Eigenständige und strukturierte Arbeitsweise

- Organisationstalent und Eigeninitiative

- Freude am Umgang mit Menschen

- Führerschein Klasse B

Von Vorteil, aber kein Muss:

- Erfahrung mit Webflow

- Kenntnisse in SEO

- Erfahrung mit Meta Ads

- Grundkenntnisse in Google Analytics oder Search Console

- Erfahrung im Immobilienbereich

## Benefits

Bei uns erwartet dich kein klassischer Bürojob.

✔ Moderne Arbeitsausstattung (iPhone, Kamera, Gimbal & Technik)

✔ Hochwertiges neues Büro

✔ Flexible Arbeitsweise

✔ Viel kreativer Gestaltungsspielraum

✔ Direkte Zusammenarbeit mit der Geschäftsführung

✔ Spannende Immobilien- und Bauprojekte

✔ Eigene Ideen ausdrücklich erwünscht

✔ Weiterbildungsmöglichkeiten

✔ Kurze Entscheidungswege

✔ Ein motiviertes Team mit echter Leidenschaft für Immobilien

✔ Regelmäßige Team-Events

✔ Kostenlose Getränke

✔ Attraktive Vergütung entsprechend deiner Qualifikation

Wir suchen keinen Mitarbeiter, der einfach Beiträge veröffentlicht.

Wir suchen jemanden, der unsere Marke mit Leidenschaft mitgestaltet.

Wenn du Lust hast, Geschichten zu erzählen, Menschen zu begeistern und gemeinsam mit uns eines der modernsten Immobilienunternehmen der Region weiter aufzubauen, dann freuen wir uns darauf, dich kennenzulernen.

**Zeig uns gerne bereits in deiner Bewerbung, was du kannst – zum Beispiel mit deinem Instagram-Profil, einem Portfolio oder eigenen Foto- und Videoprojekten.**

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
