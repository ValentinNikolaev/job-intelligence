# Datenerfasser (m/w/d) | nebenberuflich

Posted: 2026-09-14T21:30:25Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Wir haben uns auf die Optimierung von Kostenstrukturen und die finanzielle Entlastung unserer Mandanten spezialisiert. Zur Verstärkung unseres Teams suchen wir engagierte, zuverlässige und kommunikative Persönlichkeiten, die Freude am Umgang mit Menschen haben und sich eine flexible Nebentätigkeit mit Entwicklungsperspektive wünschen.

## Aufgaben

• Erfassung von Kundendaten

• Unterstützung bei administrativen Tätigkeiten im Kundenmanagement

• Terminvereinbarung und Terminorganisation (keine Kaltaquise)

• Sicherstellung einer sorgfältigen Datenqualität in unseren Systemen

## Qualifikation

• Freundliches und professionelles Auftreten

• Gute Deutschkenntnisse in Wort und Schrift

• Zuverlässige und sorgfältige Arbeitsweise

• Selbstständigkeit und Eigeninitiative

• Freude am Umgang mit Menschen

Vorkenntnisse sind hilfreich, aber nicht erforderlich. Auch Quereinsteiger sind willkommen. Wichtig sind Lernbereitschaft, Engagement und die Motivation, sich persönlich weiterzuentwickeln.

## Benefits

✓ Flexible Zeiteinteilung (ein Bürotag pro Woche ist obligatorisch)

✓ Ca. 6 Stunden pro Woche

✓ Leistungsgerechte Vergütung mit Verdienstmöglichkeiten von ca. 600–800 € monatlich

✓ Strukturierte Einarbeitung

✓ Persönliche und fachliche Weiterentwicklung

✓ Angenehmes Team und langfristige Perspektive

Wir freuen uns auf Ihre Bewerbung. Wir melden uns zeitnah bei Ihnen zurück.

Bewerbungen von Menschen aller Geschlechter und Hintergründe sind ausdrücklich willkommen.

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
