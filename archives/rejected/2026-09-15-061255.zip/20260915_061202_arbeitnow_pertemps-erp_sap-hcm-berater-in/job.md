# SAP HCM Berater:in

Posted: 2026-09-14T18:14:19Z

## Rejection

- Category: language_requirement
- Reason: hard German language requirement without English green light

**Remote (Deutschland) | SAP HCM Berater:in (m/w/d)**

**Anstellungsart**: Festanstellung

**Standort**: Remote / hybrid möglich

Sind Sie ein Spezialist in SAP HCM? Unser Klient, ein international tätiges Beratungshaus, sucht dringend nach Beratern für die Festanstellung.

## Aufgaben

- Analyse, Konzeption und Umsetzung von Anforderungen im SAP-HCM-Umfeld

- Unterstützung bei Customizing, Spezifikation, Test, Fehleranalyse und Go-Live-Begleitung

- Enge Zusammenarbeit mit Kunden, Fachbereichen, Entwicklern und dem Projektteam

- Fachliche Verantwortung in SAP-Projekten – Konzeption und aktive Umsetzung

## Qualifikation

- **Erfahrung:** Mindestens 1-2 Jahre praktische Erfahrung mit SAP HCM als Berater oder Entwickler und mindestens ein abgeschlossenes Projekt

- **Know-how**: Sehr gute Kenntnisse in mindestens einem der folgenden Schwerpunkte: Personaladministration (PA), Entgeltabrechnung (PY), Organisationsmanagement (OM) und/oder Zeitwirtschaft (PT)

- **Kommunikation:** Verhandlungssichere (B2+) Deutschkenntnisse in Wort und Schrift

- **Abschluss:** Abgeschlossenes Studium der (Wirtschafts-)Informatik, Betriebswirtschaft, Ingenieurwesen oder eines vergleichbaren Fachbereichs, kombiniert mit mehrjähriger Berufserfahrung als SAP-Berater

## Benefits

- Wachstum: Ein breites Spektrum an Technologien als Basis für Ihre fachliche Weiterentwicklung

- Gesundheits- und Sportangebote (je nach Standort)

- Familienfreundliche Arbeitszeiten ohne umfassende Reisetätigkeit

- Attraktives Vergütungspaket

- Unbefristete Festanstellung

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
