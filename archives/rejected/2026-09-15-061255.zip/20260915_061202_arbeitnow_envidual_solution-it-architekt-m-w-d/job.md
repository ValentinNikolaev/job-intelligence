# Solution-/IT-Architekt (m/w/d)

Posted: 2026-09-14T18:14:05Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Wir entwickeln Systeme, an denen das operative Geschäft unserer Kunden hängt: Anwendungen für Schadenregulierung, Provisionierung, Vertriebssteuerung, ERP- und Logistikprozesse sowie digitale Kunden- und Partnerportale. Wenn solche Systeme nicht funktionieren, entsteht nicht nur ein schlechtes Nutzererlebnis. Es entstehen Fehler, Verzögerungen, Kosten und im Zweifel echte Geschäftsrisiken.

Solche Systeme entstehen nicht durch zusätzliche Kapazität und sauber verwaltete Übergaben. Sie entstehen durch Teams, die das Problem als Ganzes verstehen und Verantwortung dafür übernehmen. Genau dafür gibt es Envidual als spezialisierte IT-Beratung.

Wir übernehmen Verantwortung von der fachlichen Analyse über UX und Architektur bis zur technischen Umsetzung und Weiterentwicklung. Dabei verstehen wir Softwareentwicklung nicht als Abarbeitung vorsortierter Tickets. Wir durchdringen die Prozesse, hinterfragen Anforderungen und treffen Entscheidungen, die auch langfristig tragen.

Unsere Teams sind bewusst schlank und interdisziplinär aufgestellt. Wer an einem Projekt arbeitet, kennt nicht nur seinen eigenen Ausschnitt, sondern versteht das Projekt, das System, das Produkt als Ganzes.

Diesen Anspruch stellen wir auch an die Menschen, die zu uns kommen: fachliche Neugier, technisches Urteilsvermögen und die Bereitschaft, Verantwortung nicht an der eigenen Rollengrenze abzugeben.

## Aufgaben

- Du entwirfst und verantwortest die Lösungs- und Systemarchitektur geschäftskritischer Anwendungen in komplexen, häufig gewachsenen Systemlandschaften.

- Du übersetzt fachliche Anforderungen und nichtfunktionale Qualitätsziele in tragfähige technische Entscheidungen. Dazu gehören unter anderem Sicherheit, Wartbarkeit, Skalierbarkeit, Verfügbarkeit, Performance und Integrationsfähigkeit.

- Du analysierst bestehende Systeme, identifizierst technische Risiken und Schulden und entwickelst realistische Zielarchitekturen und Modernisierungspfade.

- Du entscheidest nicht nach Technologie-Trends, sondern nach Kontext. Du bewertest Architekturansätze, Cloud-Komponenten, Integrationsmuster und Plattformen anhand ihrer tatsächlichen Vor- und Nachteile.

- Du bleibst nah an der Umsetzung. Durch Prototypen, Architektur-Spikes, Reviews und gemeinsame Arbeit mit den Entwicklungsteams stellst du sicher, dass Architektur nicht nur auf Diagrammen funktioniert.

- Du dokumentierst Entscheidungen verständlich, machst Zielkonflikte transparent und schaffst Orientierung für Entwickler, Fachbereiche und technische Stakeholder.

- Du entwickelst unsere Architektur- und Engineering-Standards weiter und bringst neue Ansätze wie Agentic Engineering kontrolliert in produktive Projektumgebungen.

## Qualifikation

- Du hast mehrere Jahre Erfahrung in der professionellen Softwareentwicklung und bereits Architekturverantwortung für produktive, komplexe Systeme übernommen.

- Du bist technisch weiterhin hands-on und verfügst über fundierte Kenntnisse in Springboot und Angular, sowie modernen Webarchitekturen.

- Du kennst unterschiedliche Architekturansätze und Integrationsmuster – von modularen Monolithen und Microservices über ereignisgetriebene Systeme bis zu API- und Plattformarchitekturen.

- Du kannst fachliche Anforderungen und Qualitätsziele wie Sicherheit, Verfügbarkeit, Skalierbarkeit, Performance und Wartbarkeit strukturiert erfassen und priorisieren.

- Du hast belastbare Erfahrung mit Cloud-Architekturen, Containern, CI/CD und dem Betrieb verteilter Systeme. Idealerweise kennst du Azure/GCP/AWS/OpenShift aus produktiven Projekten.

- Du kannst bestehende Systeme und Codebasen bewerten, technische Risiken transparent machen und daraus realistische Zielbilder und Modernisierungsstrategien ableiten.

- Du hast eine breite Kenntnis betriebsprägender Architekturprinzipien wie u.a. Zero-Trust, Observability, Resilience und Fault Tolerance sowie deren Einfluss auf Sicherheit, Wartbarkeit und Betriebsstabilität.

- Du dokumentierst Architekturentscheidungen präzise und verständlich, beispielsweise mit Architecture Decision Records, C4-Modellen oder vergleichbaren Formaten.

- Du kannst Entwickler fachlich führen, Stakeholder beraten und unterschiedliche Interessen zu einer tragfähigen Entscheidung zusammenbringen.

- Du arbeitest dich tief in neue Fachdomänen ein und gibst dich nicht mit technisch eleganten Lösungen zufrieden, die das eigentliche Geschäftsproblem verfehlen.

## Benefits

- **Projekte, die zählen**: Du arbeitest an Anwendungen, die zentrale Geschäftsprozesse unserer Kunden tragen. Deine Entscheidungen wirken sich nicht auf ein internes Demo-Projekt aus, sondern auf Systeme, die täglich produktiv genutzt werden.

- **Verantwortung mit echtem Einfluss**: Bei uns bekommst du nicht nur Aufgaben, sondern Gestaltungsspielraum. Du kannst technische Entscheidungen, Prozesse und Arbeitsweisen aktiv beeinflussen. Titel entscheiden dabei nicht darüber, wessen Argument zählt.

- **Lernen mit Substanz:** Du arbeitest eng mit erfahrenen Entwicklern, Architekten, Business Analysts und Designern zusammen. Statt eines starren Mentor-Mentee-Programms bekommst du direktes Feedback und Coaching, das zu deiner Rolle und deinen Zielen passt.

- **Flexibilität, die im Team funktioniert:** Wir arbeiten nicht nach starren Anwesenheitszeiten. Du gestaltest deinen Arbeitstag flexibel und stimmst dich so mit deinem Team und dem Projekt ab, dass Zusammenarbeit und Verlässlichkeit nicht darunter leiden.

- **Ein Arbeitsumfeld, das professionelles Arbeiten unterstützt:** Dich erwarten hochwertige Hardware, moderne Arbeitsplätze und ein gut ausgestattetes Büro in München – inklusive zweier Terrassen und einer Küche mit Getränken und Snacks.

- **Eine Vergütung, die deiner Verantwortung entspricht:** Wir vergüten Erfahrung, fachliche Tiefe und übernommene Verantwortung angemessen. Der Satz ist glaubwürdiger als „überdurchschnittliche Bezahlung ist Standard“. Noch stärker wäre er mit transparenten Gehaltsbändern.

- **Ein Team ohne Statusspiele:** Wir kommunizieren direkt, helfen einander und sprechen Probleme offen an. Regelmäßige Team-Events gehören dazu, sind aber nicht der Ersatz für eine gute Zusammenarbeit im Alltag.

Ergänzend bieten wir Corporate Benefits, vergünstigte Fitnessangebote und weitere Mitarbeitervorteile.

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
