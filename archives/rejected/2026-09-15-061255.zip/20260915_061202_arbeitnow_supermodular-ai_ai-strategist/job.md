# AI Strategist

Posted: 2026-09-14T23:40:04Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

## **Who we are**

At Supermodular.ai, we help enterprises navigate AI Transformation. We believe in strategy through execution.

Most organizations understand the potential of AI, but struggle to translate that ambition into real operational change. The challenge is rarely the technology itself. It is how AI fits into complex systems, workflows, and engineering organizations that have evolved over years. We believe AI transformation cannot be designed purely in strategy documents. The real strategy only emerges by building, deploying, and operating AI systems inside the organization.

That's why we work directly with enterprise IT and software teams to design and implement AI systems in real environments. This includes enabling engineering organizations to work in fundamentally new ways by introducing AI-native development practices, frameworks, and technical assets that change how teams build and operate software. It also includes building custom AI systems that unblock difficult modernization or harmonization efforts where traditional approaches have stalled.

Our team has a strong track record of building high-impact AI systems and scaling engineering teams inside complex enterprises. If you enjoy solving hard enterprise problems and turning ambitious ideas into systems that actually run in production, you'll feel at home at Supermodular.ai.

## Your Role — AI Strategy

[supermodular.ai](http://supermodular.ai) operates through three core roles: AI Strategy, Deployment Strategy and Forward Deployed Engineering.

As an AI Strategist, you are responsible for defining the AI thesis inside the account and turning ambiguity into explicit commitments. You determine what problems are worth pursuing, where [supermodular.ai](http://supermodular.ai) should commit, how opportunities are framed and what success looks like.

Most enterprises do not struggle because they lack AI ideas. They struggle because they cannot separate meaningful transformation opportunities from noise, hype and organizational inertia. This role exists to create that clarity.

You work directly with enterprise executives, engineering leaders and operational stakeholders to identify where AI can create material leverage across systems, workflows and organizational structures. You shape the strategic direction of the engagement, define the offer and establish the boundaries of what the team commits to delivering.

Each account is led by a two-person leadership pair consisting of an AI Strategist and a Deployment Strategist. Together, you run the account end-to-end. There are no layers of managers, account coordinators or traditional consulting structures between you and the customer.

You work closely with Deployment Strategy to ensure commitments align with operational reality and can actually be executed inside the organization.

This is not a pure advisory or presentation role. You are expected to exercise strong technical and commercial judgment, drive decisions under uncertainty and create alignment across senior stakeholders in environments that are often politically and operationally complex.

You will frequently make decisions with incomplete information, competing incentives and evolving technical constraints. The role requires clarity of thought, high ownership and the ability to make strong commitments without hiding behind process.

## What you own

-

The AI thesis and strategic direction inside the account

-

Identifying which problems are worth pursuing

-

Defining the offer, scope and success criteria

-

Positioning and executive alignment

-

Commercial shaping and commitment strategy

-

Risk management and scope boundaries

-

Translating ambiguous opportunities into executable engagements

-

Driving decision-making across senior stakeholders

-

Identifying expansion opportunities and shaping long-term account direction

-

Ensuring commitments align with operational and technical reality

## What you bring

-

Strong understanding of modern AI systems and their practical enterprise applications

-

Ability to identify high-leverage transformation opportunities inside complex organizations

-

Strong commercial and strategic judgment

-

Comfort operating in ambiguous, high-stakes enterprise environments

-

Ability to frame complex technical initiatives in ways executives can understand and act on

-

Strong communication and executive presence across technical and non-technical audiences

-

Systems thinking across organizational structure, workflows, engineering and operations

-

Ability to challenge assumptions and drive decisions with clarity

-

High ownership, autonomy and accountability

-

Strong partnership instincts with deployment and engineering teams

-

Comfort making explicit commitments and defining boundaries under uncertainty

**Hiring Process**

Intro Interview > 2 Technical deep-dives > Culture & Offer

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
