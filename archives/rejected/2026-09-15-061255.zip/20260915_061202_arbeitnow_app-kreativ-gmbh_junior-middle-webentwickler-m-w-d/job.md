# (Junior/Middle) Webentwickler (m/w/d)

Posted: 2026-09-14T22:00:29Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Wir sind App Kreativ, ein IT-Unternehmen mit Sitz im Herzen des Paderborner Technologieparks. Seit unserer Gründung im Jahr 2014 haben wir uns auf die Entwicklung von IT-Lösungen im Bereich iOS, Android, Windows und Web spezialisiert. Das App Kreativ-Team besteht aus 9 Mitarbeitenden, die mit viel Teamgeist und Leidenschaft daran arbeiten, ihre Kunden auf dem Weg in die digitale Zukunft zu begleiten. Was dabei stets an erster Stelle steht: Ein angenehmes Arbeitsumfeld, in dem man gerne zur Arbeit kommt!

Zur Unterstützung unseres Entwicklerteams suchen wir zum nächstmöglichen Zeitpunkt einen (Junior-) Webentwickler (m/w/d) in Vollzeit.

## Aufgaben

- Du verstärkst unser Entwicklerteam und entwickelst Lösungen für nationale und internationale Kunden

- Du erarbeitest technisch anspruchsvolle Konzepte und Softwarearchitekturen auf Basis der Kundenanforderungen

## Qualifikation

- Du hast umfassende Erfahrung im Bereich Web-Entwicklung (HTML/CSS, JavaScript, TypeScript, PHP/Laravel, Angular, React..)

- Hohe Anforderung an Code Qualität, Performance, Wartbarkeit und Erweiterbarkeit

- Sicherer Einsatz von Versionskontrollsystemen wie Git

## Benefits

- Verantwortungsvolle und abwechslungsreiche Tätigkeit als Teil eines motivierten Teams

- Individuelle Angebote zur persönlichen und fachlichen Weiterentwicklung

- Flexible Arbeitszeiten und gute Vereinbarkeit von Familie und Beruf

- Homeoffice teilweise möglich

- Moderne IT-Ausstattung und ein attraktives Arbeitsumfeld

- Ein sicherer Arbeitsplatz

- Regelmäßige Teamevents

- Eine Küche mit gefülltem Kühlschrank

- Gemeinsame Mittagspausen mit unserer Lieblingsserie

**Haben wir dich überzeugt?**

Dann überzeuge du auch uns! Wir freuen uns auf deine Bewerbung – lade dazu einfach deine Bewerbungsunterlagen inkl. Lebenslauf, Anschreiben sowie eventueller Arbeits-, Hochschul- und Ausbildungszeugnisse gesammelt als eine PDF-Datei hoch.

**Wir freuen uns auf dich!**

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
