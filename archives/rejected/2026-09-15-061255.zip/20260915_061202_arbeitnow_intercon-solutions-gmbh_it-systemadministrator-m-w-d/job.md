# IT-Systemadministrator (m/w/d)

Posted: 2026-09-14T18:14:07Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Endlich Wertschätzung für Deine Arbeit erfahren, Teil eines stabilen und erfolgreichen Unternehmens sein und Deine Ideen aktiv einbringen?

Du wünschst Dir einen Arbeitgeber, bei dem Du Verantwortung übernehmen, moderne IT-Systeme mitgestalten und Dich fachlich kontinuierlich weiterentwickeln kannst?

Dann solltest Du weiterlesen!

## Aufgaben

- Du administrierst, betreibst und optimierst die Windows-Server-Landschaft sowie Linux-Systeme und sorgst für einen reibungslosen IT-Betrieb.

- Du überwachst die IT-Infrastruktur mithilfe von Monitoring-Tools (z. B. Icinga2), analysierst Störungen und behebst diese nachhaltig.

- Du betreust Netzwerkkomponenten, Datenbanksysteme sowie Microsoft-365-/Azure-Umgebungen und unterstützt bei deren kontinuierlicher Weiterentwicklung.

- Du automatisierst wiederkehrende Administrationsaufgaben mit PowerShell, wirkst an der Verbesserung der IT-Sicherheit mit und entwickelst bestehende Prozesse und Systeme kontinuierlich weiter.

## Qualifikation

- Abgeschlossene Ausbildung als Fachinformatiker (Systemintegration) oder ein erfolgreich abgeschlossenes Hochschulstudium (z. B. Informatik, technisches Studium) oder eine vergleichbare Qualifikation.

- Fundierte Kenntnisse in der Administration von Windows Servern sowie grundlegende Kenntnisse eines Linux-Betriebssystems.

- Erfahrung im Einsatz von Monitoring-Tools, idealerweise Icinga2.

- idealerweise Erfahrung im Netzwerkmanagement (Switches & Firewalls).

- Fließende Deutschkenntnisse (C1)

## Benefits

- Unbefristete Festanstellung in einem stabilen und erfolgreichen Unternehmen.

- Attraktive und leistungsgerechte Vergütung.

- Strukturierte Einarbeitung und individuelle Weiterbildungsmöglichkeiten.

- Modern ausgestatteter Arbeitsplatz mit aktueller IT-Infrastruktur.

- **Hybrides Arbeitsmodell nach erfolgreich bestandener Probezeit.**

- Kurze Entscheidungswege sowie ein kollegiales und wertschätzendes Arbeitsumfeld.

- Spannende und abwechslungsreiche Aufgaben mit Raum für Eigeninitiative und persönliche Weiterentwicklung.

Nutze jetzt die Chance, Deine Erfahrung in einem modernen und wertschätzenden Arbeitsumfeld einzubringen und die IT-Landschaft aktiv mitzugestalten.

Wir freuen uns darauf, Dich kennenzulernen und gemeinsam die Zukunft erfolgreich zu gestalten!

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
