# Trainee (m/w/d) Persian Financial Consulting & Entrepreneurship

Posted: 2026-09-14T18:13:55Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Vergiss staubige Bankfilialen und starre Hierarchien. Bei HORBACH Berlin bieten wir dir den Direkteinstieg in die High-End-Finanzberatung für Akademiker:innen und Professionals. Wir suchen keine Sachbearbeiter, sondern die nächste Generation von Entrepreneur-Persönlichkeiten. Berlin zieht ambitionierte Talente weltweit an und genau hier liegt deine Stärke: Nutze deine Sprachkompetenz und dein kulturelles Verständnis, um die persischsprachige Community, Akademiker:innen und internationale Gründer exklusiv in Finanz- und Investmentfragen zu begleiten. Mit über 40 Jahren Markterfahrung im Rücken geben wir dir das Fundament für dein eigenes Business in der Hauptstadt.

## Aufgaben

**Das Traineekonzept:**

Wir investieren massiv in dich. Dein Weg bei uns ist ein aktiver Karrierestart:

- **Individuelle Qualifizierung:** Wir begleiten dich Schritt für Schritt auf deinem Weg und bereiten dich gezielt auf deine Karriere und anerkannte Branchenzertifizierungen vor.

- **Entrepreneurship ab Tag 1:** Du lernst, wie man ein eigenes Business führt. Von der Akquise-Strategie bis zum Closing durchläufst du die gesamte Wertschöpfungskette.

- **Networking auf High-Level:** Du erschließt gezielt exklusive akademische und wirtschaftliche Netzwerke und kommunizierst auf Augenhöhe mit Entscheidern.

## Qualifikation

**Dein Profil:**

- **Sprachkompetenz:** Du beherrschst Persisch (Farsi/Dari) auf muttersprachlichem Niveau (oder fließend), um deine Community optimal zu beraten. Grundlegende Deutschkenntnisse sind für den internen Austausch gern gesehen, aber wir setzen voll auf deine internationale Stärke.

- **Hintergrund:** Du hast ein (fast) abgeschlossenes Studium (Richtung ist Nebensache!) oder eine kaufmännische Ausbildung.

- **Mindset & Drive:** Du hast eine „Macher-Mentalität“, bist empathisch und hast Lust, dich fachlich und persönlich auf ein neues Level zu heben.

Quereinsteiger (m/w/d) mit Biss sind ausdrücklich willkommen!

## Benefits

Mehr als nur ein Job – Deine Benefits:

- **Einkommensperspektive ohne Deckelung:** Deine Vergütung hat kein Limit. Wir bieten dir ein faires Provisionsmodell, das deinen Fleiß und deine Ergebnisse direkt belohnt, für Einkommenschancen weit über dem Marktdurchschnitt.

- **Entrepreneurship mit Back-up:** Arbeite mit der Freiheit eines Unternehmers (m/w/d), aber nutze das Sicherheitsnetz, die moderne IT-Infrastruktur und die Strahlkraft einer etablierten Marke.

- **Work-Life-Balance & Flexibilität:** Gestalte deine Arbeitszeit und deinen Arbeitsort (flexible Home-Office- und Remote-Optionen) so, wie es zu deinem Leben passt. Bei uns zählt das Ergebnis, nicht die reine Anwesenheit im Büro.

- **Individuelle Karriere-Roadmap:** Ob Top-Consultant oder zukünftige Führungskraft (m/w/d): Wir planen gemeinsam deinen Aufstieg nach deinen persönlichen Stärken, nicht nach Dienstjahren.

- **High-End Mentoring:** Ein erfahrener Mentor (m/w/d) begleitet dich durch ein strukturiertes Onboarding und sorgt dafür, dass du die steile Lernkurve erfolgreich meisterst.

- **Berlin-Vibe & Team-Culture:** Erlebe ein dynamisches Team, das sich gegenseitig pusht, Erfolge gemeinsam feiert und in einem modernen Office im Herzen Berlins arbeitet.

Kein Anschreiben? Kein Problem. Dein Lebenslauf reicht uns völlig!

**Bewirb dich jetzt und gestalte deine Zukunft bei HORBACH in Berlin!**

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
