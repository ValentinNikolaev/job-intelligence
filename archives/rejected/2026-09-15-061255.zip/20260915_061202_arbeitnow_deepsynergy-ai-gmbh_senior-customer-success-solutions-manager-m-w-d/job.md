# Senior Customer Success & Solutions Manager (m/w/d)

Posted: 2026-09-14T18:14:07Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**Standort:** Rosenheim

**Umfang:** Vollzeit, unbefristet

**Start:** ab sofort

**Level:** Senior

**Arbeitsmodell:** Office-first mit hybriden Anteilen

**Reporting:** Direkte Zusammenarbeit mit Gründer & Co-CEO

**Über DeepSynergyAI**

Wir sind auf der Mission, Produktionsplanung neu zu denken.

In vielen produzierenden Unternehmen ist Planung heute noch ein Mix aus Excel, Erfahrung, Bauchgefühl und täglichem Feuerlöschen. Gleichzeitig hängen daran zentrale Entscheidungen: Welche Aufträge werden wann produziert? Welche Ressourcen sind knapp? Welche Liefertermine sind realistisch? Und wie lassen sich bessere Ergebnisse erzielen, ohne jeden Tag alles manuell neu zu planen?

Bei DeepSynergyAI wollen wir genau das verändern.

Wir entwickeln Plan-as-a-Service für produzierende Unternehmen: automatisierte, KPI-orientierte Produktionspläne, die bessere Entscheidungen im operativen Alltag ermöglichen. Unsere Lösungen verbinden Produktionsverständnis, Daten und künstliche Intelligenz – mit dem Ziel, Planung schneller, robuster und wirtschaftlich wirksamer zu machen.

Wir sind ein wachsendes B2B-AI-Unternehmen mit Sitz in Rosenheim. Wir arbeiten schnell, pragmatisch und eigenverantwortlich. Herausforderungen lösen wir gemeinsam, mit direktem Feedback, kurzen Entscheidungswegen und viel Nähe zu Kunden, Prozessen und operativer Realität.

**Warum diese Rolle besonders ist**

Mit unserem Wachstum steigen auch die Zahl und Komplexität unserer Kundenprojekte. Deshalb bauen wir unser Business Team aus.

Als **Senior Customer Success & Solutions Manager** übernimmst Du eine zentrale Rolle zwischen unseren Kunden, dem Business Team und der Produktentwicklung. Du sorgst dafür, dass Kunden mit DeepSynergyAI erfolgreich arbeiten, Projekte fachlich und organisatorisch gut umgesetzt werden und aus guten Kundenbeziehungen langfristige Partnerschaften entstehen.

Du bekommst echten Gestaltungsspielraum, kannst Standards setzen, Methoden weiterentwickeln und gemeinsam mit den Gründern aufbauen, wie Customer Success und Solution Delivery bei DeepSynergyAI künftig funktionieren.

Wir suchen bewusst eine erfahrene Person, die nicht nur umsetzt, sondern eigene Perspektiven einbringt, Risiken früh erkennt und uns auch fachlich challengt.

**Deine Rolle**

Als **Senior Customer Success & Solutions Manager** begleitest Du unsere Kunden von der Configuration & KPI Validation über die Einführung von Plan-as-a-Service bis zur langfristigen Nutzung und Weiterentwicklung der Zusammenarbeit.

Dabei steuerst Du Kundenprojekte nicht nur organisatorisch, sondern arbeitest auch fachlich aktiv mit. Du analysierst Prozesse, strukturierst Anforderungen, entwickelst Konfigurationen mit und validierst gemeinsam mit dem Kunden relevante KPIs und Ergebnisse.

Gleichzeitig betreust und entwickelst Du bestehende Kundenbeziehungen, erkennst Erweiterungspotenziale und unterstützt bei vorhandener Kapazität auch bei der Gewinnung neuer Kunden.

Neukundenakquise ist jedoch nicht der Kern der Rolle. Im Mittelpunkt stehen erfolgreiche Kundenprojekte, langfristiger Kundenerfolg und die Entwicklung bestehender Kundenbeziehungen.

## Aufgaben

- Du betreust anspruchsvolle B2B-Kunden eigenständig und entwickelst die Zusammenarbeit langfristig weiter

- Du bereitest Kundenworkshops vor, moderierst sie und strukturierst Anforderungen, Prozesse und Planungsziele

- Du arbeitest aktiv in Configuration-&-KPI-Validation-Projekten mit - insbesondere bei Prozessanalyse, Konfiguration, KPI-Definition und Validierung

- Du steuerst Kundenprojekte hinsichtlich Scope, Zeitplan, Qualität, Kommunikation, Risiken und Übergabe in Plan-as-a-Service

- Du erkennst Kundenrisiken, fachliche Unklarheiten und Eskalationen frühzeitig und führst sie mit den Beteiligten zu einer Lösung

- Du identifizierst Up-Selling- und Erweiterungspotenziale und entwickelst diese kundenorientiert weiter

- Du entwickelst Standards, Vorlagen und Vorgehensweisen für Customer Success, Kundenprojekte und Solution Delivery

- Du bringst Deine Erfahrung aktiv ein und bist Sparringsperson für Dominik und das Business Team

## Qualifikation

- Mehrjährige Erfahrung in mindestens zwei Bereichen: Customer Success, Solution Consulting, B2B-Consulting, Implementierung, Projektmanagement oder beratender B2B-Vertrieb

- eigenständige Verantwortung für anspruchsvolle B2B-Kunden

- Erfahrung, Kundenprojekte fachlich zu bearbeiten und organisatorisch zu führen

- Fähigkeit, komplexe und unklare Anforderungen in konkrete Entscheidungen und Arbeitspakete zu übersetzen

- souveränes Stakeholder-, Erwartungs- und Eskalationsmanagement

- kommerzielles Verständnis für Kundenentwicklung oder Up-Selling

- hohe Eigenständigkeit und Freude an operativer Aufbauarbeit

- verhandlungssicheres Deutsch mindestens C1 und sehr gutes Englisch

Hilfreich, aber kein Muss, sind Erfahrungen mit Produktionsplanung, Manufacturing, Supply Chain, Operations, SaaS oder Software-Implementierungen.

## Benefits

- Eine zentrale Rolle in einem kleinen, wachsenden B2B-AI-Unternehmen

- Direkte Zusammenarbeit mit den Gründern

- Viel Verantwortung und sichtbaren Einfluss ab dem ersten Tag

- Echten Gestaltungsspielraum beim Aufbau von Customer Success und Solution Delivery

- Anspruchsvolle Kundenprojekte in verschiedenen produzierenden Branchen

- Kurze Entscheidungswege und ein Umfeld, in dem gute Argumente gehört werden

- Flexible Arbeitszeiten

- Eine unbefristete Vollzeitstelle

- Nachhaltiges Wachstum ohne VC-Druck

- Die Möglichkeit, gemeinsam mit dem Unternehmen und dem Verantwortungsbereich weiterzuwachsen

**Du passt gut zu uns, wenn …**

Du eine erfahrene, kundenorientierte und unternehmerisch denkende Person bist.

Du möchtest nicht nur bestehende Prozesse verwalten, sondern selbst Kunden und Projekte übernehmen und gleichzeitig dabei helfen, eine professionelle Kundenfunktion aufzubauen.

Du arbeitest gerne operativ, kannst aber auch einen Schritt zurücktreten, Muster erkennen und Verbesserungsvorschläge entwickeln.

Und Du bist bereit, Verantwortung zu übernehmen, auch wenn noch nicht für jede Situation ein perfekter Prozess existiert.

**Klingt spannend? Dann lass uns reden!**

Schick uns einfach deinen **CV**

Wir freuen uns, dich kennenzulernen!

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
