# SAP Data & Analytics Consultant (m/w/d)

Posted: 2026-09-14T18:14:18Z

## Rejection

- Category: language_requirement
- Reason: hard German language requirement without English green light

SAP Data & Analytics Consultant (m/w/d) – SAP Datasphere

📍 **Remote innerhalb Deutschlands** | Unbefristete Festanstellung

Für ein etabliertes Beratungshaus mit Spezialisierung auf **SAP Data & Analytics** sowie **Enterprise Performance Management** suchen wir einen erfahrenen **SAP Data & Analytics Consultant (m/w/d)** mit Schwerpunkt **SAP Datasphere**.

Du arbeitest an anspruchsvollen Kundenprojekten rund um moderne Data- und Analytics-Plattformen und begleitest Unternehmen bei der Transformation ihrer SAP-Landschaften.

## Aufgaben

- Konzeption und Implementierung moderner Data-&-Analytics-Lösungen auf Basis von **SAP Datasphere**

- Weiterentwicklung und Migration bestehender SAP BW-/BW/4HANA-Landschaften

- Modellierung und Integration von Daten aus unterschiedlichen Quellsystemen

- Entwicklung von Reporting- und Analytics-Lösungen in enger Zusammenarbeit mit den Fachbereichen

- Beratung der Kunden bei Architektur-, Datenmodellierungs- und Transformationsprojekten

- Mitarbeit an innovativen Lösungen im SAP Business Technology Platform (BTP) Umfeld

## Qualifikation

- Mindestens **3 Jahre Berufserfahrung** im SAP Data & Analytics Umfeld

- **Nachweisbare Projekterfahrung mit SAP Datasphere** (mindestens 1–2 erfolgreiche Implementierungsprojekte)

- Gute Kenntnisse in **SAP BW/BW/4HANA** sowie idealerweise SAP Analytics Cloud und SAP BTP

- Erfahrung in einer **Unternehmensberatung** ist ein großer Pluspunkt

- Selbstständige und kundenorientierte Arbeitsweise

- **Deutschkenntnisse auf C1-Niveau** sowie gute Englischkenntnisse

- **Wohnsitz in Deutschland**

## Benefits

- Spannende SAP Data & Analytics Projekte bei namhaften Kunden

- Hoher Remote-Anteil mit flexiblen Arbeitsmodellen

- Moderne Technologien rund um SAP Datasphere, BW/4HANA und SAP BTP

- Individuelle Weiterbildungs- und Zertifizierungsmöglichkeiten

- Flache Hierarchien, kurze Entscheidungswege und ein kollegiales Team

- Attraktives Gehalt sowie langfristige Entwicklungsperspektiven

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
