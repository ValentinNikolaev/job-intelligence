# Senior Berater*in und Programm-Manager*in Kooperationen & Collective Impact (m/w/d)

Posted: 2026-09-15T02:09:19Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**Dein neuer Job**

Unsere Vision ist eine offene, nachhaltige und friedliche Gesellschaft, in der Gutes tun mit Wirkung das gemeinsame Handeln leitet. Um dazu unseren Beitrag zu leisten, haben wir PHINEO als gemeinnützige Plattform für strategisches gesellschaftliches Engagement aufgebaut.

Gesellschaftliche Herausforderungen lassen sich heute nur gemeinsam lösen. Deshalb arbeiten wir mit Unternehmen, Stiftungen, Sozialunternehmen, öffentlichen Institutionen und zivilgesellschaftlichen Organisationen daran, sektorübergreifende Zusammenarbeit zu stärken und mehr Wirkung zu erzielen. Für unser Team in Berlin suchen wir zum nächstmöglichen Zeitpunkt eine erfahrene Persönlichkeit, die Beratungs-, Netzwerk- und Gestaltungskompetenz miteinander verbindet, als **Senior Berater*in und Programm-Manager*in Kooperationen & Collective Impact (m/w/d)**.

**Deine Aufgaben**

- Du bringst Akteur*innen aus Wirtschaft, Zivilgesellschaft, Philanthropie und öffentlichem Sektor gezielt zusammen, um Kooperationen mit gesellschaftlichem Impact anzuregen. Dafür entwickelst du neue Formen der sektorübergreifenden Zusammenarbeit. Parallel gestaltest und moderierst du etablierte Dialogformate im analogen und digitalen Raum.
- Du übernimmst eine zentrale Rolle bei IMPACT COLLECTIVES, unserem neuen Angebot, das Impact Startups mit Unternehmen, Investor*innen und weiteren Enablern aus Wissenschaft, Verwaltung und Zivilgesellschaft themenspezifisch verbinden wird und damit strukturellen Wandel entlang der großen gesellschaftlichen Herausforderungen unserer Zeit vorantreibt.
- Du leitest unsere [Corporate Citizenship Arbeitsgruppe](https://www.phineo.org/corporate-citizenship-arbeitsgruppe), entwickelst sie strategisch weiter, gewinnst neue Unternehmen für die Mitwirkung. Du gestaltest gemeinsam mit Vertreter*innen aus Wirtschaft, Zivilgesellschaft und öffentlicher Hand Impulse für eine wirksame gesellschaftliche Verantwortung von Unternehmen.
- Du konzipierst, akquirierst und verantwortest Beratungs- und Kooperationsprojekte. Beispielsweise berätst du Startups, die wissen möchten, wie sie mehr Impact erzielen oder Investor*innen finden können, oder begleitest Kooperationen zwischen Unternehmen und Nonprofits prozessual wie inhaltlich.
- Du steuerst komplexe Projekte eigenverantwortlich von der Konzeption über das Partnermanagement bis zur Umsetzung und Auswertung. Handlungsleitend sind für dich der angestrebte gesellschaftliche Mehrwert und eine wirtschaftliche Umsetzung.
Bei der Arbeit bist du selbstverständlich nicht auf dich allein gestellt. Vielmehr bist du Teil eines engagierten Teams, das verschiedene Kompetenzen und Perspektiven vereint.

**Das bringst Du mit**

- Du setzt dich mit Leidenschaft für gesellschaftliche Transformation, nachhaltiges Wirtschaften und die Zusammenarbeit von Akteur*innen aus unterschiedlichen gesellschaftlichen Bereichen ein.
- Du bringst die Energie, Überzeugungskraft und Empathie mit, die es braucht, um Vertrauen aufzubauen und Menschen für gemeinsame Ziele zu gewinnen. Auch skeptische Akteur*innen kannst du inspirieren und aktivieren.
- Du bringst Beratungserfahrung mit, idealerweise mit Startups, Investor*innen oder Unternehmen zu Fragen rund um Strategie oder Organisationentwicklung. Daher kannst du Beratungsprozesse konzipieren, eigenständig durchführen und zu belastbaren Ergebnissen führen.
- Du hast in der Vergangenheit bereits Netzwerke aufgebaut oder intensiv betreut, idealerweise mit Beteiligung von Akteuren aus der Wirtschaft und aus dem Startup-Bereich. Du kannst relevante Akteure zeitnah identifizieren und sie mit unseren Zielgruppen vernetzen. Du besitzt Erfahrungen mit Multi-Stakeholder-Prozessen oder Collective-Impact-Ansätzen. Du bewegst dich sicher im Umgang mit Entscheider*innen auf Konzern- beziehungsweise Leitungsebene.
- Du hast nachweisliche Erfahrung in der Entwicklung und Gewinnung von Partner*innen, Kund*innen oder Förder*innen sowie in der eigenverantwortlichen Leitung komplexer Projekte.

**Deine Vorteile bei uns**

Purpose

- Ein sinnstiftender Job mit viel Gestaltungsspielraum.
- Die Möglichkeit, an relevanten gesellschaftlichen Themen wie nachhaltige Wirtschaft, Stärkung von Demokratie und Klimaschutz mitzuarbeiten.
- Eine Organisation, die danach strebt, eine Vielfalt an Identitäten, Erfahrungshintergründen und Perspektiven zusammenzubringen.
- Ein großes Netzwerk an Kontakten aus Politik, Wirtschaft und Zivilgesellschaft.

Konditionen und Entwicklungsmöglichkeiten

- 39 Stunden pro Woche in Vollzeit, Teilzeit bis zu 80% möglich.
- Die Befristung des Arbeitsvertrages (2 Jahre) ist ein Punkt, an dem wir noch einmal gemeinsam reflektieren und eine bewusste Entscheidung treffen – hoffentlich füreinander. Sie ist ein Standard in all unseren neuen Arbeitsverhältnissen, um Achtsamkeit und Bewusstsein auf beiden Seiten der Beziehung zu stärken.
- Diese Position liegt in unserer Stellengruppe 3 und ist beim aktuellen Aufgaben- und Verantwortungsspektrum bei einem Festgehalt zwischen 56.000 und 62.000 EUR verortet, abhängig von Erfahrung und Qualifikation. Mehr Informationen zu unserem Gehaltssystem findest du auf unserer Website: [https://www.phineo.org/jobs](https://www.phineo.org/jobs).
- Ein attraktiver Arbeitgeberzuschuss zur betrieblichen Altersvorsorge und zum Jobticket, Fahrradprämie sowie Mitarbeitendenrabatte.
- Ein umfassendes Onboarding, mit strukturierter Einarbeitung.
- Interne und externe Weiterbildungsangebote.

Arbeitszeitflexibilität und Familienfreundlichkeit

- 30 Tage Urlaub im Jahr.
- Ein flexibles Arbeitszeitmodell mit Gleitzeitkonto.
- Die Möglichkeit, mobil zu arbeiten: sowohl regelmäßig im Inland als auch zwei Mal jährlich als Workation aus dem Ausland.
- Eine Kultur, in der die Vereinbarkeit mit dem Privatleben einen hohen Stellenwert hat.

**Wie wir in Kontakt kommen**

Klingt richtig gut? Dann bewirb dich mit deinen aussagekräftigen Unterlagen über unser Online-Bewerbungsformular. Wir sichten die Bewerbungen fortlaufend.

Als Organisation, die gesellschaftliche Diversität erfolgreich mitgestalten will, freuen wir uns über alle Bewerbungen – unabhängig von Geschlecht, Nationalität, ethnischer und sozialer Herkunft, Religion, Weltanschauung, Behinderung, Alter sowie sexueller Orientierung und Identität. Menschen mit anerkannter Schwerbehinderung werden bei gleicher Eignung bevorzugt eingestellt. Da unsere Büroräume derzeit nicht komplett barrierefrei sind, gehen wir gern mit dir darüber ins Gespräch, was es braucht, um vorhandene Barrieren abzubauen.

Wir bitten um dein Verständnis, dass wir ausschließlich Bewerbungen über unser Online-Formular berücksichtigen können. Bewerbungen per Post oder E-Mail können nicht verarbeitet und in unseren Bewerbungsprozess aufgenommen werden. Originalunterlagen werden nicht zurückgeschickt.

Bei Fragen rund um die Anstellung bei PHINEO oder den Bewerbungsprozess wende dich bitte über

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
