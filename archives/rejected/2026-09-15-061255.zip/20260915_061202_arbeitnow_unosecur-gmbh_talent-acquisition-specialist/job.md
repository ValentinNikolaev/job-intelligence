# Talent Acquisition Specialist

Posted: 2026-09-14T18:13:54Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**About Us**

Unosecur is a comprehensive identity security platform protecting organisations against identity-related threats across multi-cloud and on-premise environments. Backed by leading investors including VentureFriends, DFF, Leo Capital, and Heartfelt, we are scaling rapidly following a $5M seed round. Our mission is to redefine how companies manage human and non-human identities at scale.

**Role Overview**

At Unosecur, we move fast, we think big, and we're just getting started. This means the quality of every hire we make right now shapes what Unosecur becomes. As our first dedicated Talent Acquisition hire, you own the end-to-end recruitment engine, building pipelines, hunting down exceptional talent before our competitors do, and closing candidates who could have gone anywhere but chose us. You'll work directly with our Founder and Operations team to bring in the right people who will define our next chapter, across engineering, sales, and beyond. You'll build the frameworks, the standards, the way Unosecur hires and everything that comes after will run on what you create.

## Tasks

- **End-to-End Recruitment:** Brief, source, screen, interview, close. You run lean and fast processes that respect candidates' time and get to a decision without dragging.

- **Sourcing & Outreach:** Great candidates aren't always looking, yet you know where to find them, through communities, events, referrals, and whatever creative approach gets you in front of the right person.

- **Candidate Experience:** Every person who interviews at Unosecur should leave impressed, hired or not. How we hire says a lot about who we are.

- **Hiring Manager Partnership:** Work closely with the Founder and Operations team to define role requirements, calibrate on what great looks like, and move quickly without cutting corners.

- **Employer Brand:** We are building a people, product, profit company — in that order. People come first, always. You make sure our people-first culture is visible before anyone ever hits apply.

- **Recruitment Operations:** Own our ATS, keep pipelines clean and up to date, and build the reporting that gives leadership a clear view of hiring progress and bottlenecks.

- **People Operations Support:** Contribute to broader HR initiatives as needed such as onboarding and employee experience as we continue to build out our people focused team.

## Requirements

- **Experience:** 2+ years in a talent acquisition or recruitment role, ideally in-house at a startup or scale-up. Agency background considered if you're ready to go in-house.

- **Startup Mindset:** A hunger to make things happen and have a true impact. An understanding of the fast-paced nature of early-stage startups and the ability to remain calm under pressure.

- **Organization Mastery:** Exceptional attention to detail and the ability to manage a high volume of tasks without losing focus.

- **Builder Mindset:** You're energised by building from scratch. Lack of process doesn't frustrate you, instead it motivates you.

- **Instinct for People:** You read people well, communicate with clarity, and know how to sell a vision to a candidate who has other options on the table.

- **Commercial Awareness:** You understand what drives a startup and can credibly represent Unosecur to senior candidates who will ask hard questions.

- **Language:** Native or high level German and fluent English, both are used daily across our hiring activity.

- **Tools:** Comfortable with ATS platforms and LinkedIn Recruiter.

- **Location:** Our new office is located in Hackescher Markt at the heart of Berlin. Drinks, snacks, ping-pong table and positive vibes included.

## Benefits

- **Build It Your Way:** You are the first dedicated TA hire, the recruitment processes at Unosecur are yours to shape.

- **Direct Impact:** Every person you bring in has a measurable effect on the trajectory of the company. Few roles at this stage carry that kind of weight.

- **A Front-Row Seat:** Work directly alongside C-Levels, with full visibility into where the business is going and why each hire matters.

- **Wellness Benefit:** Keep your body and mind healthy with an UrbanSports Club membership.

- **Growth Potential:** Competitive package and the opportunity to grow your role as the company expands.

Join Unosecur's vibrant team as a Talent Acquisition Specialist and help us scale our identity security platform. Be part of our exciting journey!

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
