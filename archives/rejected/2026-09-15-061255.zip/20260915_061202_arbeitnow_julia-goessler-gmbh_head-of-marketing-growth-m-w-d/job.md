# Head of Marketing & Growth (m/w/d)

Posted: 2026-09-14T18:14:06Z

## Rejection

- Category: tech_stack
- Reason: role does not mention Go/Golang or PHP

**Vollzeit | Remote | Hohe Reisebereitschaft**

**Wir suchen keinen Marketingmanager.**

**Wir suchen eine Führungspersönlichkeit.**

**Einen Menschen, der Marketing nicht als Abteilung versteht, sondern als Herzstück eines Unternehmens.**

**Jemanden, der Menschen führen kann.**

**Der Strategien entwickelt.**

**Der Entscheidungen trifft.**

**Der Verantwortung übernimmt.**

**Und der Lust hat, eine der spannendsten Marken im deutschsprachigen Coaching- und Transformationsmarkt aktiv mitzugestalten.**

**Über uns**

**Die Julia Goessler GmbH begleitet jedes Jahr tausende Menschen auf ihrem Weg zu mehr Gesundheit, persönlicher Entwicklung und innerer Transformation.**

**Mit Live Events, Online Programmen und digitalen Produkten schaffen wir Erlebnisse, die Menschen nachhaltig bewegen.**

**Unser Unternehmen wächst kontinuierlich und genau deshalb suchen wir jemanden, der unser Marketing auf das nächste Level hebt.**

**Deine Mission**

**Du verantwortest unser gesamtes Marketing.**

**Du entwickelst Strategien.**

**Du führst Menschen.**

**Du steuerst Agenturen.**

**Du analysierst Kennzahlen.**

**Du sorgst dafür, dass aus vielen einzelnen Maßnahmen ein perfekt funktionierendes Marketing-System entsteht.**

**Gemeinsam mit der Geschäftsführung entwickelst du die Marketingstrategie für die nächsten Jahre und setzt diese mit deinem Team erfolgreich um.**

## Aufgaben

**Deine Aufgaben**

- **Verantwortung für den gesamten Marketingbereich**

- **Entwicklung und Umsetzung unserer Marketing- und Wachstumsstrategie**

- **Führung des internen Marketingteams sowie externer Agenturen und Dienstleister**

- **Planung und Steuerung unserer Launches, Kampagnen und Live Events**

- **Verantwortung für Performance Marketing, CRM, E-Mail-Marketing, Social Media und Content**

- **Analyse relevanter KPIs und Ableitung konkreter Optimierungsmaßnahmen**

- **Entwicklung neuer Marketingprozesse und effizienter Strukturen**

- **Enge Zusammenarbeit mit Geschäftsführung, Sales, Eventmanagement und Fulfillment**

- **Verantwortung für Budgetplanung und Marketingperformance**

## Qualifikation

**Das bringst du mit**

- **Mehrjährige Erfahrung in einer leitenden Marketingposition**

- **Erfahrung im Aufbau und in der Führung leistungsstarker Teams**

- **Strategisches und unternehmerisches Denken**

- **Hohe analytische Kompetenz und Zahlenverständnis**

- **Erfahrung mit Launches, Funnels und digitalen Marketingprozessen**

- **Ausgeprägte Kommunikations- und Führungsstärke**

- **Eigenverantwortliche, strukturierte und lösungsorientierte Arbeitsweise**

- **Reisebereitschaft und Freude daran, regelmäßig bei unseren Veranstaltungen und Produktionen vor Ort zu sein**

## Benefits

**Das solltest du wissen**

**Diese Position ist keine reine Remote-Stelle.**

**Unsere Live Events, Launches, Contentproduktionen und Teamtreffen finden regelmäßig an unterschiedlichen Standorten statt – unter anderem in Deutschland sowie vereinzelt im europäischen Ausland.**

**Deshalb wünschen wir uns eine Persönlichkeit, die gerne reist und den direkten Austausch mit dem Team schätzt.**

**Das erwartet dich**

- **Eine Schlüsselposition mit großem Gestaltungsspielraum**

- **Direkte Zusammenarbeit mit der Geschäftsführung**

- **Ein ambitioniertes Team mit kurzen Entscheidungswegen**

- **Spannende Projekte mit hoher Sichtbarkeit**

- **Regelmäßige Live Events und Produktionen**

- **Flexible Remote-Arbeit kombiniert mit Reisen**

- **Persönliche und fachliche Weiterentwicklung**

- **Die Möglichkeit, eine wachsende Marke aktiv mitzugestalten**

**Das passt zu dir?**

**Dann freuen wir uns auf deine Bewerbung.**

**Bitte sende uns:**

- **Deinen Lebenslauf**

- **Aussagekräftige Referenzen oder Arbeitsproben**

- **Ein kurzes Anschreiben oder Video, in dem du uns zeigst, warum genau du die richtige Person für diese Rolle bist.**

**Wir freuen uns darauf, dich kennenzulernen.**

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
