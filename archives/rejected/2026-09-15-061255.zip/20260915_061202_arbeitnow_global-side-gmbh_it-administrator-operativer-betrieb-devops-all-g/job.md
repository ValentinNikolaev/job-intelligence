# IT Administrator – operativer Betrieb & DevOps (all Genders)

Posted: 2026-09-15T02:09:49Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**DEINE KÜNFTIGE ROLLE.**

Halte Systeme stabil. Mach Komplexität unsichtbar.Du sorgst dafür, dass unsere IT einfach funktioniert – stabil, sicher und ohne unnötige Komplexität.
Bei GLOBAL SIDE geht es nicht um Systeme um ihrer selbst willen. Es geht darum, dass Technologie im Alltag zuverlässig unterstützt. Genau hier setzt Du an: Du betreibst, optimierst und stabilisierst unsere IT-Landschaft – pragmatisch, hands-on und mit klarem Fokus auf Wirkung.
Du arbeitest nah an der Umsetzung statt an theoretischen Konzepten. Du löst Probleme, bevor sie relevant werden, und schaffst Strukturen, die bleiben.

So entsteht das, was uns ausmacht:
Standards, die funktionieren.

Klingt gut? Dann bewirb Dich direkt.

**Mehr Informationen und das Anforderungsprofil für diese Position findest Du auf****
**[https://www.globalside.com/it-administrator-muenchen-operativer-betrieb-devops-global-side](https://www.globalside.com/it-administrator-muenchen-operativer-betrieb-devops-global-side)

**WAS UNS ANTREIBT.**

Welchen Sinn hat Arbeit, wenn sie nicht verändert?Wir bei GLOBAL SIDE sind auf das Gesundheitswesen fokussiert. Hier nehmen wir eine ganz bestimmte Rolle ein. Wir setzen Standards, und das nicht nur durch unsere Software. Unsere Haltung lässt uns Probleme vollumfänglich lösen. Für viele verändert das alles. Wir beenden damit stupide belastende Arbeit und schaffen eine Welt, in der sich jeder kreativ weiterentwickeln kann. Wir wollen Dinge verändern. Du auch?

Deine Benefits am Standort München:

- flexibles Arbeitszeitmodell an unserem Standort München-Arabellapark
- 30 Tage Urlaub pro Jahr
- Deutschland-Ticket
- Regelmäßige Team-Events mit Spaßfaktor
- Jährliche Unternehmenstage an der Algarve in Portugal
- jährlicher Team-Wiesn-Besuch
- Nach der Probezeit:

- Dienstrad-Leasing
- Personalisiertes Ausbildungsbudget für Dein berufliches Wachstum

**EIN NORMALER TAG - UND DOCH SO BESONDERS.**

So arbeiten wir: Offen, echt und voller Teamgeist.Komm mit auf eine Tour durch unsere Offices und Konferenzräume, schau unseren Kollegen bei der Arbeit über die Schulter, erlebe aktive Erholung am Kicker, an unserer Rocket (=Siebträgermaschine) und Teamarbeit in Aktion. Hier zählen **Effizienz, Qualität, Progression und Teamgeist** – Werte, die unsere tägliche Arbeit prägen. Schau rein und finde heraus, ob unser Alltag vielleicht bald Deiner wird!

**Schau dir unser Video an** unter [https://www.globalside.com/it-administrator-muenchen-operativer-betrieb-devops-global-side](https://www.globalside.com/it-administrator-muenchen-operativer-betrieb-devops-global-side)

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
