# SAP Senior CO Berater:in

Posted: 2026-09-14T18:14:18Z

## Rejection

- Category: language_requirement
- Reason: hard German language requirement without English green light

**Remote Deutschlandweit | SAP Senior CO Berater:in dringend gesucht**

**Unbefristete Festanstellung**

**Standort:** Remote, hybrid auch möglich

Sind Sie ein Spezialist für SAP Controlling mit Erfahrung in Datenmigration? Unser Klient, ein marktführendes Beratungshaus, sucht dringend einen Senior Consultant für die Festanstellung, der komplexe Systemlandschaften mit innovativen Technologien in die Zukunft führt.

## Aufgaben

- Technische Begleitung von SAP-Transformationsprojekten vom Kick-off bis zum erfolgreichen Projektabschluss

- Durchführung von technischen Analysen komplexer SAP-Systemlandschaften der Kunden

- Entwicklung, Umsetzung und Test von maßgeschneiderten Transformations- und Datenmigrationslösungen

- Übersetzung von fachlichen Datenmigrationskonzepten und Regelwerken in die technische Umsetzung mit geeigneten Migrations- und Transformationswerkzeugen

- Vorbereitung und Durchführung von Kundenworkshops und Schulungen, um spezifische Anforderungen und Herausforderungen zu adressieren

- Konfiguration und Anwendung von Standardsoftware zur Transformation von SAP-Systemen für vielfältige Szenarien

## Qualifikation

- Mehrjährige Projekterfahrung als SAP-Berater:in oder SAP-Entwickler:in mit betriebswirtschaftlichem Tiefgang im Controlling

- Fundierte Kenntnisse in SAP CO (inkl. Customizing), ergänzt durch ABAP-Grundlagen und sicheren Umgang mit SAP-Tabellen, Datenbanken und Datenelementen

- Sicherer Umgang im gesamten Datenmigrationsprozess – von der Aufbereitung über das Mapping bis zur Validierung mit gängigen Werkzeugen

- Analytisches Denkvermögen, kreative Lösungsfindung und eine selbstständige, eigenmotivierte Arbeitsweise

- Organisationstalent und Freude an der Zusammenarbeit in internationalen Teams

- Begeisterung für neue Technologien und Innovationsprojekte sowie Bereitschaft für projektabhängige Reisen

- Abgeschlossenes Studium mit mehrjähriger SAP-Consulting-Erfahrung

- Sehr gute Deutschkenntnisse (C1) in Wort und Schrift

## Benefits

- **Wachstum:** Ein breites Spektrum an Technologien als Basis für Ihre fachliche und persönliche Weiterentwicklung in einem zukunftssicheren Bereich

- **Flexibilität:** Familienfreundliche Arbeitszeiten mit hohem Remote-Anteil und reduzierter Reisetätigkeit

- **Gesundheit:** Zugang zu Gesundheits- und Sportangeboten (je nach Standort)

- **Sicherheit:** Unbefristete Festanstellung mit einem attraktiven und leistungsgerechten Vergütungspaket

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
