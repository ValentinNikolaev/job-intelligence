# Projektingenieur TGA für Umspannwerke (m/w/d)

Posted: 2026-09-14T18:13:42Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Für ein anspruchsvolles Energieinfrastrukturprojekt im Raum Frankfurt am Main übernehmen Sie die technische Unterstützung bei der Errichtung eines Umspannwerks zur Versorgung eines Rechenzentrums. Im Mittelpunkt der Position stehen die Planung, Koordination und technische Begleitung der technischen Gebäudeausrüstung sowie die Sicherstellung einer reibungslosen Zusammenarbeit aller beteiligten Fachbereiche.

## Aufgaben

- Planung, Prüfung und Koordination der technischen Gebäudeausrüstung (TGA) für Umspannwerks-, Betriebs- und Technikgebäude

- Fachliche Bearbeitung der Gewerke wie z.B. Heizung, Lüftung, Klima/Kälte sowie versorgungstechnischer Anlagen einschließlich der technischen Schnittstellen

- Prüfung und Bewertung von Planungsunterlagen, Leistungsverzeichnissen, technischen Konzepten sowie Unterstützung bei Planungsänderungen und der Ausführungsplanung

- Koordination von Fachplanern, Lieferanten, Gutachtern und ausführenden Unternehmen sowie Unterstützung der Bauleitung bei Qualität, Terminen, Kosten und Arbeitssicherheit

- Begleitung von Abnahmen, Inbetriebnahmen und Mängelverfolgung sowie Sicherstellung einer vollständigen Projekt- und Revisionsdokumentation

## Qualifikation

- Abgeschlossenes Studium der Versorgungstechnik, Gebäudetechnik, Energietechnik oder eine vergleichbare Qualifikation

- Mehrjährige Berufserfahrung in der Planung oder Umsetzung von TGA-Anlagen, idealerweise im Umfeld von Energieinfrastruktur-, Industrie- oder Umspannwerksprojekten

- Fundierte Kenntnisse der TGA-Gewerke sowie relevanter Normen und Richtlinien

- Strukturierte, eigenverantwortliche Arbeitsweise, ausgeprägte Kommunikationsfähigkeit sowie sehr gute Deutschkenntnisse in Wort und Schrift

## Benefits

- Unbefristeter Arbeitsvertrag und 30 Tage Urlaub

- Professionelle Betreuung durch feste Ansprechpartner

- Gezielte Weiterbildungsmöglichkeiten zur fachlichen und persönlichen Weiterqualifizierung

- Umfangreiches Gesundheitsförderungsprogramm (u.a. Firmenfitness und private Krankenzusatzversicherung)

- Zuschuss vermögenswirksame Leistung und betriebliche Altersvorsorge

- Regelmäßige Mitarbeiterveranstaltungen zum Austausch von fachlichen Themen und Erfahrungen

- Individuelle Lösung für moderne Arbeitsausstattung zur Ermöglichung von flexiblem Arbeiten

- Mit JobRad die Möglichkeit zum Fahrrad-Leasing

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
