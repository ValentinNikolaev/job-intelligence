# Senior SAP Consultant (m/w/d) - Real Estate Management (RE, RE-FX)

Posted: 2026-09-15T02:09:09Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**Your mission**

- der Beratung unserer Kundinnen und Kunden bei der Einführung von immobilienwirtschaftlichen Lösungen basierend auf SAP ERP und PROMOS Softwareprodukten,
- Analyse-, Entwicklungs- und Implementierungsaufgaben in SAP-Projekten,
- der Qualitätssicherung unserer SAP- und PROMOS.GT-Lösungen für das Immobilienmanagement (im SAP Modul RE, RE-FX),
- der Planung und Durchführung von Schulungen und Workshops, Betreuung der Key-User,
- der Übernahme von Aufgaben in der (Teil-)Projektleitung,

**Your profile**

- Absolventin, Absolvent der Wirtschaftsinformatik, Wirtschaftswissenschaften idealerweise mit Bezug zum Immobilien- und Projektmanagement, bist oder eine vergleichbare Qualifikation besitzt,
- Know-how oder großes Interesse an der Immobilienverwaltung hegst,
- gute Kenntnisse in mindestens einer der SAP-Komponenten FI oder RE-FX hast,
- offen für die Arbeit mit neuen und innovativen Technologien bist,
- verhandlungssichere Deutschkenntnisse hast, um den reibungslosen Austausch mit unseren deutschsprachigen Kundinnen und Kunden zu ermöglichen,
- von Teamwork begeistert bist und Wert auf ein wertschätzendes Miteinander legst,

**Why us?**

- flexible Arbeitszeiten und die Möglichkeit zu arbeiten, wo du möchtest: entweder in unseren attraktiven Büroräumen, im Home-Office oder mobiles Arbeiten in und außerhalb Deutschlands.
- 30 Tage Urlaub, eine 39 Stunden-Woche bei Vollzeit oder individuelle Teilzeitmodelle.
- ein faires und branchenorientiertes Gehalt, das deiner Erfahrung und Qualifikation entspricht.
- ein ausgewogenes Programm rund um health@PROMOS, wie z.B. eine Urban Sports-Mitgliedschaft, JobRad, monatliche Gesundheitsangebote und Zuschuss zur Arbeitsplatzbrille,
- regelmäßige Teamevents sowie jährliche Sommer- und Weihnachtsfeste.
- weitere Benefits, die PROMOS zum Great Place to Work machen.

**your questions**

Deine Unterlagen sende bitte im PDF-Format vorzugsweise über unser Karriereportal oder per E-Mail an

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
