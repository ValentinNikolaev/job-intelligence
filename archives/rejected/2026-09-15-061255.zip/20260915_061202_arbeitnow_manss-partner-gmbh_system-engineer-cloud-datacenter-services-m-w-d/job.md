# System Engineer Cloud & Datacenter Services (m/w/d)

Posted: 2026-09-14T18:13:42Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Aktuell suchen wir **ab sofort** einen **System Engineer (m(w/d)** für einen unserer

Partner mit **Schwerpunkt Cloud & Datacenter Services.** Es geht um eine **ANÜ-Tätigkeit** im Automobilzuliefer-Umfeld am Standort **Mönchengladbach**.

## Aufgaben

-
Aktive Mitgestaltung der Geschäftsprozessautomatisierung und Unterstützung der weltweiten Zusammenführung und Harmonisierung der IT Infrastruktur

- Beratung und Unterstützung der Fachbereiche bei der Migration der Businessservices in die Cloud

- Verantwortung für die Architektur, Konzeption, Vorbereitung und Umsetzung von IT Lösungen im Cloud und OnPrem Umfeld

- Mögliche Übernahme einer Service Owner Rolle

- Koordination von Releases in Verbindung mit dem Change und dem Configuration Management

- Begleitung von internationalen Projekten von Beginn der Konzeption über die Implementierung bis hin zu Test- und Betriebsphasen (Proof of Concepts)

- 2nd und 3rd Level Support für die verantworteten Produkte samt Steuerung der notwendigen Kommunikation mit dem Hersteller

- Installation, Konfiguration sowie Troubleshooting von internationaler Cloud und OnPrem Data Center Services (z.B. Vmware, Microsoft, HCI)

- Überprüfung und Weiterentwicklung der Sicherheitsanforderungen in Windows Server-Infrastrukturen

- Betreuung des Monitorings und der kompletten Datacenterservices

- Aktive Mitentwicklung bei der Cloud Migration und Mitverantwortung für Cloud Technologien und Lösungen (M365, Azure, IaaS Lösungen, etc.)

## Qualifikation

- Erfolgreich abgeschlossenes Studium der Informatik oder eine vergleichbare Berufsausbildung im IT-Umfeld

- 5 Jahre Berufserfahrung im IT Betrieb mit mehreren Standorten

- Serviceorientierung und fundiertes Know-how im Bereich Cloud Automatisierung

- Ausgeprägte analytische und konzeptionelle Fähigkeiten kombiniert mit Organisations- und Präsentationstalent

- Sicherer Umgang mit Deutsch und Englisch

- hohe Ergebnis-und Kundenorientierung

- Eigeninitiative, Belastbarkeit, Flexibilität sowie Zielstrebigkeit und Zuverlässigkeit

- Bereitschaft zu gelegentlichen Geschäftsreisen

## Benefits

- Work-Life Balance durch flexibles Arbeiten mit Gleitzeitkonten

- 30 Tage Urlaub

- Kostenfreie Mitarbeiterparkplätze

- Internationales Familienunternehmen

- Eigenverantwortliches und eigenständiges Arbeiten

- uvm.

Haben wir dein Interesse geweckt? Dann bewirb dich jetzt! Wir freuen uns auf dich.

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
