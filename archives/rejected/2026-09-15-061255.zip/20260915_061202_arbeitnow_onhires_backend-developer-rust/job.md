# Backend Developer (Rust)

Posted: 2026-09-14T23:40:09Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

# Rust Engineer — Distributed Execution Engine

Berlin (hybrid) or Remote (countries within ~4–5 hours travel of Berlin)

## About our client

Our client is a B2B sourcing platform serving the automotive dealership industry. They're a small, fast-moving engineering team building core infrastructure from the ground up rather than assembling off-the-shelf tools — the kind of environment where a single engineer's technical decisions shape the product for years.

## About the role

You'll join a small engineering team building the client's sourcing platform. Your focus will be their **flowgraph** — a **horizontally scalable, step-based execution engine**, similar in spirit to n8n or Unreal Engine's Blueprints, but **built from the ground up in Rust** with **strong typing** and **production workloads** in mind. It drives their order processing and ETL pipelines.

This isn't a typical backend role. Rather than wiring together managed queues and off-the-shelf orchestration tools, the team **builds its own coordination and fault-tolerance mechanisms from scratch** — because the workloads don't fit neatly into existing solutions. If you enjoy thinking about **graph theory, type systems, parsers and compilers, WASM runtimes, or distributed systems architecture** as part of your everyday work — not just as a personal interest — you'll feel at home here.

## What you'll do

-

Research, design, and build on the client's **bespoke distributed graph execution engine**, written in Rust.

-

Design and implement **graph executor node implementations** to power third-party integrations with partner and supplier systems.

-

Build and maintain infrastructure for the distributed execution engine — **deployment pipelines, observability, and site reliability**.

-

Design and implement **coordination and fault-tolerance mechanisms from scratch** (not by wrapping existing message queues) — handling partial failures, node coordination, and recovery within the engine itself.

-

Develop and maintain **logistics and ETL workflows** within this ecosystem, tied directly to the core business.

## What we're looking for

**Must-have:**

-

**7+ years** of backend development experience.

-

**3+ years** of professional Rust experience.

-

Strong, practical grasp of **distributed systems and fault-tolerant software architecture**.

-

Familiarity with at least some of: **graph theory, type theory, parsers and compilers**, and related CS fundamentals. We don't expect mastery of all of these — most strong candidates bring deep expertise in **3–4 out of 5** core areas, with **distributed systems being the one we weight most heavily**.

-

Real-world **DevOps** experience.

**Nice to have:**

-

A background in **C/C++** before moving to Rust.

-

Experience with key-value stores or distributed databases — **FoundationDB or TiKV** are a big plus.

-

Experience with frontend web development.

-

Experience with existing low-/no-code workflow tools (**n8n, Prefect, AWS Step Functions**).

-

Understanding of **WASM runtimes**.

-

Previous experience with **logistics or process management** systems.

## Location & setup

-

**Berlin / Wildau area:** hybrid, with **1 day per week** in the office.

-

**Elsewhere within ~4–5 hours' travel of Berlin:** **fully remote**, no office requirement.

-

Employment: official employment in Germany, or **B2B contract** elsewhere in Europe.

-

**Full-time**, ~40 hours/week, with meaningful overlap with CEST hours.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
