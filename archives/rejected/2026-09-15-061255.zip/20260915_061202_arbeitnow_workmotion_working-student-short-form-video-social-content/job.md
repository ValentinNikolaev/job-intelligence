# Working Student: Short-Form Video & Social Content

Posted: 2026-09-14T23:20:10Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

### **Working Student – Short-Form Video & Social Content**

**Location:** Berlin, Germany (Hybrid: On-site and Remote)
**Hours:** 16-18 hours/week during the semester, flexible around your lectures and exams
**Contract type:** Working Student
**Salary:** €18/hour Gross

###
Not Your Typical Workplace.

Tired of the 9-to-5 grind? Imagine a world without borders, where opportunities are endless. That's the future of work, and what we are building at WorkMotion. Our remote-first team spans across the world, helping companies hire, onboard, and manage talent internationally through smart, flexible workforce solutions. Fast-paced, people-driven, and globally connected, we empower businesses to build teams without borders.

###
More Than a Role

Can you stop a thumb mid-scroll? Do you watch a Reel and instantly know why it works — the hook, the cut on the beat, or the sound that makes it, or why it fell flat?

At WorkMotion, we're building the future of global work. Now we want the world to actually feel it through Reels, TikToks, and Shorts that don't look like a SaaS company made them.

We're looking for someone who genuinely lives on social platforms, can shoot and edit short-form video quickly, and has strong opinions about what makes content perform. You'll help us build a social presence that's equal parts scroll-stopping and on-brand: casual and funny one day, polished B2B storytelling the next.

You won't be fetching coffee. You'll be behind the camera, in the editing software, and in the room where we decide what's worth filming.

###
Where Responsibility Meets Real Opportunity

- **Shoot & edit short-form content:** Film and edit Reels, TikToks, and Shorts with fast turnaround while staying trend-aware and on-brand.
- **Ride the trends:** Spot what's taking off and move quickly on relevant trends without losing sight of who WorkMotion is.
- **Direct the talent:** Brief teammates, give them direction, and help them feel comfortable in front of the camera.
- **Switch registers:** Generate concepts across two lanes — casual, social-first content that entertains and polished B2B content that builds credibility.
- **Have an opinion:** Challenge ideas that won't perform and sharpen the ones that will, paying close attention to hooks, pacing, sound, and overall execution.
- **Support social content creation:** Contribute to content planning, shoot days, approval rounds, and the ongoing development of WorkMotion's social presence.

###
What It Takes to Make an Impact Here

- You genuinely use platforms like **Instagram and TikTok** and understand them from a user's perspective, not just a marketer's.
- You have something to show for it, a **portfolio, personal channel, side project, or other examples** of short-form videos you've shot and edited yourself.
- You're comfortable using **CapCut or a similar editing tool** and can work quickly enough to keep up with the pace of social media.
- You are **trend-literate and brand-aware**, with a good instinct for which trends are worth jumping on.
- You're comfortable **directing colleagues**, running a mini shoot, and keeping the energy up.
- You can confidently communicate and coordinate with colleagues across the company, including within a distributed team.
- You're reliable, organized, and able to manage deadlines alongside your studies.

###
Bonus Points If You Bring…

- A feel for **short-form copywriting**, including captions, hooks, and on-screen text.
- Some understanding of **platform analytics**, such as watch time, retention, and engagement.
- Experience managing or contributing to a **content calendar**.
- Confidence engaging with an audience in the comments using a brand voice.

###
The Practical Bits

- You must be **enrolled at a university for the full duration of the role**.
- As a Werkstudent, you must be a **matriculated student**.
- You can commit approximately **16 hours per week during the semester**, with flexibility around lectures and exam periods.
- **Start date and duration:** To be confirmed.
- The role is based in **Berlin, Germany**, with a hybrid working setup.

###
Not Your Typical Team

You will join a team of **7 highly talented Marketing minds** who are as obsessed with growth as they are with creating memes. We're a young, motivated, and fully distributed crew that proves "remote" doesn't mean "disconnected."

We don't just "work" together; we create together. Whether we're sharing the weirdest corners of the internet in our #watercooler channel or pushing the boundaries of our strategy in our weekly Thursday Think Tank, we value collective brainpower and high-energy collaboration. If you're looking for a place where your wildest creative ideas are actually encouraged — and then tested against the data — you'll fit right in.

###
The Perks of Being Here…

- **Flexible Around Your Studies:** Part-time hours that flex around your lectures and exam periods.
- **Well-Being First:** A dedicated Well-Being Day every year to help you recharge.
- **Annual Meetups:** Because even distributed teams need to spend some time together in person.
- **Real Portfolio Fuel:** You'll have the opportunity to create and publish short-form content that becomes part of your real-world portfolio.

*Benefits vary depending on location due to local laws and regulations.

At WorkMotion, we're proud to be an equal opportunity employer. If you need any accommodations during the recruitment process, just reach out to our Recruitment Team at

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
