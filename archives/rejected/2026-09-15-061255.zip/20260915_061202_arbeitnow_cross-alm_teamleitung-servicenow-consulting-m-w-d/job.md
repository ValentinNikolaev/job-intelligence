# Teamleitung ServiceNow Consulting (m/w/d)

Posted: 2026-09-14T18:13:53Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

## Ihre Aufgaben

Du möchtest nicht nur spannende ServiceNow-Projekte umsetzen, sondern auch ein Team aufbauen, Menschen entwickeln und die strategische Positionierung eines wachsenden Bereichs aktiv mitgestalten? Dann bist du bei uns genau richtig.

Wir suchen eine engagierte **Teamleitung ServiceNow Consulting (m/w/d)**, die sowohl fachlich als auch organisatorisch Verantwortung übernimmt und gemeinsam mit uns den Ausbau unseres ServiceNow-Portfolios vorantreibt.

- Einführung, Weiterentwicklung und Optimierung von ServiceNow-Lösungen und ITSM-Modulen entsprechend der Kundenanforderungen

- Eigenverantwortliche Steuerung von Kundenprojekten – von der Anforderungsanalyse über Konzeption und Umsetzung bis zum erfolgreichen Go-Live

- Beratung und Unterstützung unserer Kunden bei der Digitalisierung und Optimierung ihrer Service-Management-Prozesse

- Durchführung von Workshops, Schulungen und Präsentationen für Kunden und Endnutzer:innen

- Fachliche und organisatorische Führung des ServiceNow-Teams sowie aktive Unterstützung beim Ausbau und der Weiterentwicklung des Teams

- Förderung einer agilen und kollaborativen Arbeitsweise innerhalb eines interdisziplinären Umfelds

- Unterstützung beim Ausbau unseres ServiceNow-Portfolios sowie aktive Mitgestaltung der strategischen Positionierung am Markt und in Presales-Aktivitäten

## Ihr Profil

- Mehrjährige Erfahrung in der Einführung und Betreuung von ServiceNow-Lösungen, idealerweise im ITSM-Umfeld

- Erfahrung in der Leitung von Projekten und Teams

- Sehr gutes Verständnis von IT-Service-Management-Prozessen (ITIL-Kenntnisse von Vorteil)

- Kommunikationsstärke sowie souveränes Auftreten gegenüber Kunden und Stakeholdern

- Eigenverantwortliche, strukturierte und lösungsorientierte Arbeitsweise

- Erfahrung in agilen Arbeitsmethoden

- Sehr gute Deutsch- und Englischkenntnisse

## Warum wir?

- Spannende Projekte in einem dynamischen Umfeld namhafter Kunden, bei denen ServiceNow, Jira, SAP Solution Manager und Cloud ALM kombiniert eingesetzt werden

- Möglichkeit, die eigene Expertise im Bereich ServiceNow weiter auszubauen und innovative Lösungen zu entwickeln

- Ein motiviertes und engagiertes Team, das gemeinsam an herausfordernden Projekten arbeitet

- 30 Tage Urlaub pro Jahr, um Erholung und Freizeit zu ermöglichen

- Weiterbildungsbudget für individuelle Weiterbildungsangebote

- Remote Arbeiten und flexible Arbeitszeitgestaltung? Bei uns kein Problem!

- Stark vergünstigte Mitgliedschaft im Urban Sports Club, um aktiv zu bleiben und Sport zu treiben

- Zuschuss zum BVG ÖPNV-Ticket, um den Weg zur Arbeit zu erleichtern

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
