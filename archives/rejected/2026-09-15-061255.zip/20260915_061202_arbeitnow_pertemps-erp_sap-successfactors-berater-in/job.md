# SAP SuccessFactors Berater:in

Posted: 2026-09-14T18:14:19Z

## Rejection

- Category: language_requirement
- Reason: hard German language requirement without English green light

**Remote (Deutschland) | (Senior) SuccessFactors Consultant (m/w/d)**

**Anstellungsart:** Festanstellung, Voll- oder Teilzeit

**Standort:** Remote / hybrid möglich

Sind Sie ein Spezialist in SAP SuccessFactors? Unser Klient, ein international tätiges Beratungshaus, sucht dringend nach Beratern für die Festanstellung.

## Aufgaben

- Beratung unserer Kunden in Bezug auf die technische und funktionale Implementierung von SAP SuccessFactors

- Eigenverantwortliche Umsetzung kundenindividueller Konfigurationen sowie die Durchführung von Workshops und Schulungen

- Unterstützung und Beratung bei der Integration von SAP SuccessFactors in bestehende Prozess- und Systemlandschaften für unsere Kunden

- Analyse, Beratung, Konzeption und Implementierung von Anwendungen für festgelegte HR-Geschäftsprozesse

- Unterstützung im Rahmen von Pre-Sales-Aktivitäten

## Qualifikation

- **Erfahrung:** Mindestens 1-2 Jahre praktische Erfahrung in der Konzeption und Konfiguration von SAP-SuccessFactors-Applikationen und mindestens ein abgeschlossenes Projekt

- **Know-how:** Mindestens eine SAP-SuccessFactors-Zertifizierung sowie sehr gute Kenntnisse in gängigen SuccessFactors-Modulen (z. B. Employee Central, Recruiting, Performance & Goals, Compensation, Learning Management)

- **Kommunikation:** B2-Deutschkenntnisse in Wort und Schrift

- **Abschluss:** Abgeschlossenes Studium der (Wirtschafts-)Informatik, Betriebswirtschaft, Ingenieurwesen oder eines vergleichbaren Fachbereichs, kombiniert mit mehrjähriger Berufserfahrung als SAP-Berater

- **Persönlichkeit:** Lernbereitschaft, Eigenständigkeit, ausgeprägter Teamgedanke, starke Kundenorientierung und Kommunikationsstärke

- **Reisebereitschaft:** gelegentlich

## Benefits

- Sehr gute Entwicklungsmöglichkeiten für Sie persönlich und fachlich

- Ein Umfeld geprägt von dem Leitsatz "Fördern und Fordern", in dem Spaß an der Arbeit und Qualität an erster Stelle stehen

- Selbstständiges und eigenverantwortliches Arbeiten mit der Möglichkeit, schnell Verantwortung zu übernehmen und Impact zu haben

- Flexible Arbeitszeiten an flexiblen Arbeitsorten zur optimalen Vereinbarkeit von Familie und Beruf

- Regelmäßige Team- und Firmenevents

- Attraktive Mitarbeiterangebote (z. B. Firmenwagen, subventioniertes Mittagessen, Diensthandy, Jobrad)

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
