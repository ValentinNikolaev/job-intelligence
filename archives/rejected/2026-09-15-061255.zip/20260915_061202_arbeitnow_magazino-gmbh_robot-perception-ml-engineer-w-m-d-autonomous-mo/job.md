# Robot Perception/ML Engineer (w/m/d) Autonomous Mobile Robots

Posted: 2026-09-14T18:14:19Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

## Deine Aufgaben

- Du entwickelst und verbesserst Wahrnehmungsmodelle für autonome mobile Roboter, darunter Objekterkennung, Hindernisklassifizierung und Freiraumerkennung

- Du treibst datengetriebene Machine-Learning-Lösungen voran, indem Du automatisierte Labeling-Prozesse skalierst, Flottendaten nutzt und die Sim2Real-Lücke durch synthetische Daten und simulationsbasierte Evaluierung schließt

- Du verantwortest die Modellperformance, definierst aussagekräftige Benchmarks, verfolgst relevante Metriken und erzielst kontinuierliche Verbesserungen im realen Einsatz sowie auf Benchmark-Ebene

- Du integrierst und validierst Wahrnehmungsmodelle innerhalb unseres ROS-basierten Software-Stacks und stellst eine zuverlässige Performance auf realen Fahrzeugen sicher

- Du arbeitest eng mit den Teams aus Navigation, Regelung und Flottenmanagement zusammen, um robuste Wahrnehmungslösungen für den autonomen Betrieb zu entwickeln

## Dein Profil

- Du verfügst über 2–5 Jahre Berufserfahrung und praktische Erfahrung in den Bereichen Robotik-Perzeption, Computer Vision oder Machine Learning

- Du verfügst über sehr gute Python-Kenntnisse; Erfahrung mit C++ ist ein Plus

- Du hast praktische Erfahrung im Training und der Evaluierung von neuronalen Netzen (z. B. mit PyTorch) und verfolgst einen datenzentrierten Ansatz zur Verbesserung der Modellleistung

- Du bringst Erfahrung mit synthetischen Daten, ML-Simulationen, Auto-Labeling, Active Learning oder Domain Adaptation mit

- Du arbeitest strukturiert und datenbasiert bei der Bewertung von Modellen und verstehst, wie sich reale Performance zuverlässig messen lässt

- Du bist mit ROS sowie Linux-basierten Entwicklungsumgebungen vertraut

- Du denkst pragmatisch, setzt um, misst Ergebnisse und verbesserst Lösungen iterativ

## Was wir bieten

- **Spitzentechnologie**: Als Pioniere der Robotik sind wir in der Lage, ohne Schienen und Leitlinien zu navigieren und zu manipulieren, und bieten Lösungen für Prozesse, die noch nie jemand zuvor automatisieren konnte!

- **Team**: Wir sind ein internationales Team mit mehr als 25 Nationalitäten. Du wirst in einem Team mit sehr smarten, bescheidenen, kooperativen und fleißigen Menschen arbeiten.

- **Kultur**: Sei einfach Du selbst! Werde Teil eines dynamischen, innovativenund vielfältigen Teams, das Zusammenarbeit über Hierarchie stellt. Um innovativ zu sein, muss man ab und zu scheitern – wir lernen und verbessern uns ständig.

- **Arbeitsplatz**: Unser Büro befindet sich in der Nähe der S‑Bahn-Station „Hirschgarten“. Wir arbeiten in einem Büro im Loft-Stil mit toller Ausstattung, eigener Werkstatt und Testbereich.

- **Vollverpflegung**: Du hast keine Lust, darüber nachzudenken, was du morgen zu Mittag essen willst, geschweige denn, es vorzubereiten? Zum Glück verwöhnt uns unser französischer Koch jeden Tag mit einem frisch gekochten kostenlosen Mittagessen! Und als Sahnehäubchen gibt es einen gefüllten Kühlschrank mit Getränken, frischem Obst und natürlich Kaffee!

- **Flexibilitä** **t**: Flexibilität wird bei uns großgeschrieben. Unser hybrides Arbeitsmodell für Positionen, bei denen Anwesenheit verzichtbar ist, trägt zu einer gesunden Work-Life-Balance bei.

- **Benefits**: Wir bieten attraktive Urlaubs‑, Wellpass‑,Gesundheits- und Vergütungsleistungen. Erfahre hier mehr über unsere aktuellen Benefits.

*Für uns bei Jungheinrich Robotics ist die Förderung der Inklusion sehr wichtig. Wir sind daher bestrebt, ein inklusives Umfeld für alle Kandidaten zu schaffen und bieten allen qualifizierten Bewerbern unabhängig von Geschlecht, ethnischer Zugehörigkeit, Alter, nationaler Herkunft, sexueller Orientierung, Kultur oder Bildung gleiche Chancen. Wenn Du gewisse Anpassungen benötigst, um den Rekruitingprozess für Dich zugänglich zu machen, werden wir unser Bestes tun, um Dir entgegenzukommen. Sprich uns gerne darauf an!*

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
