# Head of Engineering (f/m/d)

Posted: 2026-09-14T19:00:34Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

## Unsere Opportunity

Predium hat in den letzten drei Jahren die führende ESG-Intelligence-Plattform für institutionelle Immobilienunternehmen in der DACH-Region gebaut - mit den stärksten Namen der Branche als Kunden: Asset Manager, Wohnungsbaugesellschaften, Banken. Unsere Kundenbasis, die Daten, unsere Glaubwürdigkeit sind wertvolles Kapital für den nächsten Schritt. Investment-, Kredit- und Asset-Management-Entscheidung werden in der Real Estate Branche noch immer in Excel getroffen, Fall für Fall. Wir bauen jetzt den AI-Analysten, der diese Arbeit übernimmt. Direkt auf den Daten des Kunden, skalierbar ohne zusätzliche Köpfe. Wir sind stark finanziert und bringen KI in die Real Estate Branche.

## Deine Mission

Als Head of Engineering übernimmst du die Führung unseres aktuell rund 10-köpfigen Engineering-Teams und baust es weiter aus. Du pushst dein Team, ambitioniert zu liefern: kontinuierliche Verbesserungen für unsere bestehenden Kunden, aber auch neue Prototypen und Innovationen, die unser Geschäftsmodell erweitern. Gleichzeitig sorgst du für Austausch und Zusammenarbeit im Team, damit alle jeden Tag ein Stück besser werden.

Du bist ein starker Sparringspartner und denkst in Systemen: Gemeinsam mit unserem C-Level, dem Product- und Data-Team sowie unseren Kunden entwickelst du unsere Produktstrategie weiter und findest technisch tragfähige, smarte Lösungen. Bei uns gewinnt die beste Idee - egal von wem sie kommt. Mit 40 Leuten gibt's einfach keinen Raum für Politik.

Technisch baust du unsere Architektur so, dass sie mit uns skaliert und Raum für Innovation lässt - etwa bei der Integration von AI-Komponenten und Datenpipelines. Dabei hast du bei uns freie Hand: Neues ausprobieren, den Tech-Stack weiterentwickeln und auch Kapazität für technisches Fundament und Tech Debt einplanen.

So hilfst du auch unseren Sales- und Customer-Success-Teams, neue Kunden zu gewinnen - und baust dir damit deine eigene User- und Fan-Base auf. Und: Jede Zeile Code trägt dazu bei, den CO2-Fußabdruck von Immobilien zu verbessern.

Tech-Stack: TypeScript (Full Stack, React im Frontend, NestJS im Backend), Hasura/GraphQL, PostgreSQL RDS, AWS ECS / Elastic Beanstalk, Claude

## Woran wir Erfolg messen

- Du hast agentische Features erfolgreich entwickelt und live gebracht, die unsere Plattform um eine 360°-Sicht auf die Immobilie erweitern.

- Du hast das Team schneller shippen lassen - indem du es unterstützt, die Can-do-Mentalität stärkst und kritisch hinterfragst, was wir überhaupt bauen.

- Du hast das Team um großartige, lokale Talente erweitert.

- Du weißt, was jede Person in deinem Team antreibt - und hast ihr geholfen, die eigene Performance aufs nächste Level zu heben.

## Was du mitbringst

- Du hast mindestens 5 Jahre Erfahrung in Software-Engineering-Führung und -Architektur, mit einer Erfolgsbilanz beim Skalieren von Engineering-Teams bei gleichzeitig hoher Shipping-Geschwindigkeit - idealerweise in einem non-corporate, schnelllebigen Umfeld.

- Du liebst es, Teams wachsen zu lassen, sie in ihrer Entwicklung zu unterstützen und ihnen gleichzeitig ambitionierte Ziele zu setzen.

- Du hast fundierte Erfahrung mit den genannten Frontend- und Backend-Technologien sowie modernen Tech-Stacks - nicht, indem du alles selbst codest, sondern indem du dein Team befähigst.

- Du denkst in Systemen und löst Probleme konsequent aus einer First-Principles-Perspektive.

- Du sprichst Deutsch auf Muttersprachniveau bzw. C1 und fließend Englisch.

## Warum Predium?

- **Stage:** ~40 Leute, stark finanziert, auf dem Weg die Kategorie zu definieren. Früh genug, dass vieles noch gebaut werden muss. Ja, es ist manchmal messy - aber genau das ist der Punkt. Wenn du einen fertigen Playbook-Job suchst, ist das hier nicht der richtige Fit.

- **Impact:** Du bist nicht Rädchen #100 in einer Company. Was du hier aufbaust - Produkt, das Kunden wirklich nutzen - bleibt. Dein Beitrag ist direkt sichtbar, im Revenue und im Produkt.

- **Ownership:** Wir managen nicht deine Zeit, wir messen deine Ergebnisse. Du bekommst Verantwortung und Freiraum - und die Erwartung, beides zu nutzen.

- **Compensation:** Competitive Salary, Bonus und Equity-Beteiligung. Wir wollen, dass du am Erfolg partizipierst, den du mitaufbaust.

- **Team:** Office-first im Werksviertel München, 4 Tage/Woche.

30 Urlaubstage (inkl. Betriebsurlaub) · Wellpass · Deutschland-Ticket · Jobrad · Team-Events

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
