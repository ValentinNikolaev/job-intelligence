# Projektleitung Versicherungs-Software (all Genders)

Posted: 2026-09-15T02:09:49Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**DEINE KÜNFTIGE ROLLE.**

Steuere innovative IT-Projekte für das Gesundheitswesen.

Als Projektleitung für Versicherungs-IT bei GLOBAL SIDE steuerst Du komplexe IT-Projekte mit sichtbarem Mehrwert für das Gesundheitswesen.

Du koordinierst interdisziplinäre Teams, übersetzt Anforderungen in Lösungen und begleitest Kunden von der Planung bis zur Umsetzung.

Mit Deinem technischen Verständnis und Sinn für effiziente Prozesse hilfst Du, Standards zu schaffen, die Komplexität reduzieren und Digitalisierung voranbringen. Du willst Projekte gestalten, die wirklich etwas bewegen?

Schau Dir unser Video an – und wenn Du den Spirit teilst: Bewirb Dich und werde Teil unseres Teams!

**Mehr Informationen und das Anforderungsprofil für diese Position findest Du auf****
****[https://www.globalside.com/projektleiter-versicherungs-it-health](https://www.globalside.com/projektleiter-versicherungs-it-health)**

**WAS UNS ANTREIBT.**

Welchen Sinn hat Arbeit, wenn sie nicht verändert?Wir bei GLOBAL SIDE sind auf das Gesundheitswesen fokussiert. Hier nehmen wir eine ganz bestimmte Rolle ein. Wir setzen Standards, und das nicht nur durch unsere Software. Unsere Haltung lässt uns Probleme vollumfänglich lösen. Für viele verändert das alles. Wir beenden damit stupide belastende Arbeit und schaffen eine Welt, in der sich jeder kreativ weiterentwickeln kann. Wir wollen Dinge verändern. Du auch?

Unser Arbeitszeitmodell:

- München:

- Flexibles Arbeitszeitmodell mit hybrider Arbeitsweise.
- Regelmäßige Präsenz am Standort München an mindestens zwei bis drei Tagen pro Woche, insbesondere zur Zusammenarbeit im Team und während der Einarbeitungsphase.

- Stuttgart

- Du arbeitest überwiegend remote von Deinem Wohnort aus.
- Für die standortübergreifende Zusammenarbeit treffen wir uns einmal monatlich für zwei bis drei Tage in unserer Zentrale in München, um Projekte voranzutreiben, Wissen auszutauschen und den Teamzusammenhalt zu stärken.

- Kundenprojekte

- Je nach Projektphase und Kundenanforderung sind Vor-Ort-Termine bei unseren Kunden erforderlich.
- Insbesondere während der Implementierungsphase kann die Reisetätigkeit zunehmen. Mehrtägige Kundeneinsätze mit Übernachtungen sind dabei durchaus üblich

Deine Benefits am Standort München:

- 30 Tage Urlaub pro Jahr
- Dienstrad-Leasing
- Deutschland-Ticket
- Personalisiertes Ausbildungsbudget für Dein berufliches Wachstum
- Regelmäßige Team-Events mit Spaßfaktor
- Jährliche Unternehmenstage an der Algarve in Portugal
- jährlicher Team-Wiesn-Besuch

**EIN NORMALER TAG - UND DOCH SO BESONDERS.**

So arbeiten wir: Offen, echt und voller Teamgeist.Komm mit auf eine Tour durch unsere Offices und Konferenzräume, schau unseren Kollegen bei der Arbeit über die Schulter, erlebe aktive Erholung am Kicker, an unserer Rocket (=Siebträgermaschine) und Teamarbeit in Aktion. Hier zählen **Effizienz, Qualität, Progression und Teamgeist** – Werte, die unsere tägliche Arbeit prägen. Schau rein und finde heraus, ob unser Alltag vielleicht bald Deiner wird!

[**Schau dir unser Video an**](https://www.globalside.com/projektleiter-versicherungs-it-health)** unter **[**https://www.globalside.com/projektleiter-versicherungs-it-health**](https://www.globalside.com/projektleiter-versicherungs-it-health)

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
