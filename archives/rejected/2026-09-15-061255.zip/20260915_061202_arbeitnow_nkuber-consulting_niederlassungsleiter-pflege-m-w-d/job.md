# Niederlassungsleiter Pflege (m/w/d)

Posted: 2026-09-14T18:14:31Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**Niederlassungsleiter (m/w/d) 6000 bis 8000 €, Boni**

Wir suchen in Leipzig für einen Personaldienstleister mit sehr gutem Ruf und deutlichen Umsatzsteigerungen in 2025 einen **Niederlassungsleiter** (m/w/d) Pflege**.** Ertragsbeteiligung Obelasse-PKW, Handy uvm.

Wir sind erreichbar unter 01707984774

## Aufgaben

Verantwortung für den Ausbau der Standortes

Führung und Motivierung eines Teams

Erstellung einer Wachstumsstrategie

Organisation der Kundenbetreuung und -akquise

Organisation der Rekrutierung und Betreuung der externen Mitarbeiter

Auf- und Ausbau der Kundennetzwerke

Budgetverantwortung

## Qualifikation

Ausbildung Studium oder kaufmännischer oder gewerblich-technischer Beruf

Führungserfahrung in der Zeitarbeit mind. 3 Jahre

Erfahrung in der Pflege

Zugriff auf ein regionales Kundennetz

Stressresistenz

Soziale Kompetenz

Begeisterungsfähigkeit

## Benefits

Urlaubs- und Weihnachtsgeld

Altersvorsorge

Firmenhandy

Wir freuen uns auf Ihre Kontaktaufnahme und sichern Ihnen 100 % Diskretion und einen professionellen Umgang mit Ihren Daten zu.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
