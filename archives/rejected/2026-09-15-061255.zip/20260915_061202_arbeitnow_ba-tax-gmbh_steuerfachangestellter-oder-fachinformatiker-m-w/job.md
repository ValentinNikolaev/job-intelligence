# Steuerfachangestellter oder Fachinformatiker (m/w/d) Schwerpunkt Kanzleiorganisation & DATEV

Posted: 2026-09-15T02:09:10Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**Das erwartet dich**

Zahlen sind Deine Sprache, DATEV Dein Zuhause und Prozesse dürfen bei Dir gerne auch mal neu gedacht werden? Dann suchen wir genau Dich.

Bei ba tax denken wir Kanzleiarbeit anders: digital, unkompliziert und im Team auf Augenhöhe. Als B Corp-zertifizierte Kanzlei in Hamburg verbinden wir wirtschaftlichen Erfolg mit gesellschaftlicher Verantwortung – und suchen Verstärkung, die unsere DATEV-Welt genauso pragmatisch und zukunftsorientiert mitgestaltet wie wir unsere Mandate.

Die DATEV-Administration liegt bei uns in den Händen eines eingespielten 3er-Teams. Durch die anstehende Cloud-Migration von DATEV und eine stetig wachsende Mandantschaft nehmen Themen und Nachfragen spürbar zu – genug Substanz für eine Rolle mit echter Verantwortung und viel Raum zum Mitgestalten.

**Deine Vorteile**

-

**50 % Homeoffice:** Arbeite flexibel – so, wie es zu deinem Leben passt

-

**Echte Wertschätzung:** Kommunikation auf Augenhöhe, offenes Miteinander

-

**Digital & effizient:** Moderne Tools, papierloses Arbeiten, klare Prozesse

-

**Zentrale Lage:** Kurze Wege, gute Anbindung, schöner Arbeitsplatz

-

**Mehr Freizeit:** 30 Urlaubstage + 6 zusätzliche freie Tage

-

**Mobilität inklusive:** Deutschlandticket übernehmen wir komplett

-

**Finanzielle Extras:** Nettolohnoptimierung & Zuschuss zur Altersvorsorge

-

**Gesund & modern:** Ergonomische Arbeitsplätze & Team-Events mit Spaßfaktor

**Deine Aufgaben**

- Erste Anlaufstelle für unsere Mandanten bei allen Fragen rund um DATEV – von der Rechteverwaltung bis zur Fehlerbehebung im Alltag
- Begleitung des Onboardings neuer Mandanten: Anbindung an DATEV, Einrichtung der Schnittstellen zu deren ERP-Systemen, technische Übergabe
- Interne Beratung unserer Kolleg:innen aus Buchhaltung und Steuerberatung bei DATEV-nahen Fragen und Problemen
- Verantwortung für unsere Kanzleiorganisation im DATEV-Umfeld – Berechtigungen, Updates, Lizenzen, Dokumentation
- Einbringen eigener Ideen, wie wir wiederkehrende Abläufe mit KI oder anderen Tools vereinfachen können – Raum dafür ist da, muss aber nicht dein Haupttreiber sein

**Du bringst mit**

- Eine Ausbildung als Steuerfachangestellte:r mit ausgeprägtem IT-Interesse – oder eine IT-nahe Ausbildung (z. B. Fachinformatiker:in, IT-Systemkaufmann/-frau) mit Erfahrung in DATEV-Umgebungen, idealerweise im Kanzleiumfeld
- Umfangreiche Kenntnisse in DATEV Kanzlei-Rechnungswesen, Unternehmen online oder vergleichbaren DATEV-Anwendungen
- Eine strukturierte, eigenverantwortliche Arbeitsweise – auch wenn mehrere Anfragen gleichzeitig reinkommen
- Klare, geduldige Kommunikation, auch wenn eine Mandantenanfrage zum dritten Mal das gleiche Problem beschreibt
- Idealerweise hast Du die Weiterbildung zum/zur FAIT (Fachassistent IT) schon gemacht – oder Lust, Dich bei uns dahin zu entwickeln
- Sehr gutes Deutsch und gute Englischkenntnisse

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
