# Netzwerk Engineer (m/w/d)

Posted: 2026-09-14T18:13:55Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Wir betreiben und entwickeln hochverfügbare Netzwerk-Infrastrukturen mit eigenem Autonomen System (AS) und mehreren Peering-Standorten. Unser Fokus liegt auf stabilen, sicheren und performanten Backbone-Verbindungen – mit modernen Technologien und Komponenten der Hersteller Juniper, Arista und Dell.

Zur Verstärkung unseres Teams suchen wir einen Netzwerk Engineer (m/w/d) für unseren Standort Wiesbaden, der Verantwortung für Planung, Betrieb und Weiterentwicklung unserer Core- und Backbone-Umgebungen übernimmt.

## Aufgaben

- Planung, Betrieb und Optimierung von Backbone- und Rechenzentrumsnetzwerken

- Administration und Pflege unseres Autonomen Systems (AS), inkl. BGP-Peering und Transit-Verbindungen

- Konfiguration und Troubleshooting von dynamischen Routing-Protokollen (BGP, OSPF, IS-IS)

- Betreuung von Netzwerkkomponenten der Hersteller Juniper, Arista und Dell

- Analyse und Behebung von Netzwerkstörungen (2nd-/3rd-Level-Support)

- Mitarbeit bei der Weiterentwicklung der Netzwerktopologie und Sicherheitskonzepte

- Erstellung und Pflege technischer Dokumentationen

- Teilnahme an fachspezifischer Rufbereitschaft

## Qualifikation

- abgeschlossene Ausbildung oder Studium im IT-Bereich (z. B. Fachinformatiker Systemintegration, Informatik o. ä.)

- Berufserfahrung im Bereich Service Provider oder Rechenzentrumsnetzwerke

- sehr gute Kenntnisse in BGP, OSPF, sowie im Umgang mit Autonomen Systemen (AS)

- Erfahrung mit Hardware der Hersteller Juniper, Arista und Dell von Vorteil

- sicherer Umgang mit IPv4/IPv6, VLANs, Spanning Tree, LACP, EVPN/VXLAN

- strukturierte und selbstständige Arbeitsweise

- Teamgeist und Kommunikationsfähigkeit

- sehr gutes Deutsch in Wort und Schrift, sowie gute Englisch-Kenntnisse

- Wohnort im Rhein-Main-Gebiet oder Bereitschaft zu gelegentlicher Vor-Ort-Arbeit

## Benefits

- Mitarbeiterevents

- Weiterbildung

- subventioniertes Mittagessen

- Möglichkeit zum mobilen Arbeiten

- Mentorenprogramm

- Warm- und Kaltgetränke

- Obstkorb

- Mitarbeiterrabatte

- Fahrtkostenerstattung

- Firmenwagen

- Job-Fahrrad

- Parkplatz

- flexible Arbeitszeit

- Sportangebot

- betriebliche Altersvorsorge

- Job-Ticket

- Notebook und Smartphone

*In unserer Bewerberansprache setzen wir auf das 'Du'. Solltest Du eine andere Ansprache bevorzugen, lass es uns einfach wissen und wir passen uns Deinen Präferenzen an.*

Wir freuen uns auf Deine Bewerbung!

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
