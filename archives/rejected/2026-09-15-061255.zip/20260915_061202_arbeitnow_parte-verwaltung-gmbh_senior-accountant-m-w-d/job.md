# Senior Accountant (m/w/d)

Posted: 2026-09-14T18:13:54Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

## Das bewegen Sie bei uns:

- Sie verantworten eigenständig die Buchführung für Ihr eigenes Portfolio an Gesellschaften in DATEV – inklusive Abgrenzungen, Rückstellungen und Intercompany-Abstimmungen.

- Monats- und Jahresabschlüsse nach HGB erstellen Sie prüfungsbereit und termingerecht und unterstützen bei der Erstellung des Konzernabschlusses.

- Neu erworbene Hausverwaltungen führen Sie in unsere Buchhaltungsstruktur über: Sie prüfen Eröffnungsbilanzen, ordnen den Kontenrahmen zu und klären übernommene Altlasten.

- Die Arbeit unseres Junior Accountants prüfen Sie fachlich und geben Ihr Wissen verständlich weiter.

- Für die Geschäftsführungen Ihrer Gesellschaften sind Sie erste Ansprechperson bei buchhalterischen Fragen; zudem bereiten Sie die Datenexporte für unser Konzernreporting in LucaNet vor.

## Das bringen Sie mit:

- Sie sind Bilanzbuchhalter/-in (IHK), Steuerfachangestellte/-r mit Weiterbildung oder bringen eine vergleichbare Qualifikation mit.

- Mindestens vier Jahre Erfahrung in der deutschen Buchführung und Abschlusserstellung haben Sie bereits gesammelt, idealerweise über mehrere Gesellschaften oder Mandanten hinweg.

- Im HGB bewegen Sie sich sicher – auch bei Rückstellungen, Abgrenzungen und Intercompany-Sachverhalten.

- Mit DATEV arbeiten Sie routiniert; Erfahrung mit Datenexporten ist ein Plus. LucaNet-Erfahrung ist willkommen.

- Auf Deutsch kommunizieren Sie verhandlungssicher auf C1-Niveau; gute Englisch-Kenntnisse helfen Ihnen im Umgang mit unseren internen Tools.

## Das bieten wir Ihnen:

- **Unbefristete Festanstellung** mit sicheren Perspektiven.

- Geregelte Arbeitszeiten, flexible Gleitzeit und Option auf **mobiles Arbeiten**.

- **Flache Hierarchien**, abwechslungsreiche Aufgaben und ein starkes Teamgefühl.

- Gestaltungsspielraum sowie Weiterentwicklung durch **regelmäßige Weiterbildungen**.

- Moderner Arbeitsplatz, zeitgemäße Technik und **Dienstlaptop (auch privat nutzbar)**.

- **Zentrale Bürolage** mit guter ÖPNV-Anbindung.

## Ihre Ansprechpartnerin:

Theresa Jakob, HR Generalist

+49 151 58152451

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
