# Amazon Marktplatz-Manager (m/w/d) remote oder hybrid

Posted: 2026-09-14T21:30:24Z

## Rejection

- Category: tech_stack
- Reason: role does not mention Go/Golang or PHP

Du hast Erfahrung mit Amazon gesammelt und willst jetzt richtig Marken groß machen? Bei EBZ Marketplaces bist du vollumfänglich für unseren Amazon-Hauptaccount verantwortlich – von Listing und Advertising bis zu den Lieferantenbeziehungen - mit echter Verantwortung, einem starken Team im Rücken und persönlichem Mentoring durch erfahrene Unternehmer.

## Aufgaben

- Du verantwortest unseren Amazon-Hauptaccount vollumfänglich in Seller Central – über alle Marken hinweg.

- Du optimierst Listings, Content und Buy-Box und behältst Rankings, Reviews und Wettbewerb im Blick.

- Du steuerst das Amazon-Advertising – Strategie und Ziele kommen von dir, die Umsetzung übernimmt unser spezialisierter PPC-Dienstleister.

- Du managst die Lieferanten- und Markenbeziehungen: Konditionen, Forecasts, Verfügbarkeit, Nachbestellungen.

- Du sicherst die Warenverfügbarkeit mit unserem Fulfillment-Team und verhinderst Out-of-Stocks.

- Für Content und Creatives greifst du nach Absprache auf unser Content-Team

- Du entwickelst deine Accounts strategisch weiter: neue Produkte, neue Märkte, mehr Marge.

## Qualifikation

- Erfahrung im Amazon-Marktplatzgeschäft (Seller, Vendor, Agentur oder Markenseite).

- Sicherer Umgang mit Seller Central: Listing, PPC, FBA/SFP, Cases, Kennzahlen.

- Zahlenaffin und datenbasiert (Excel/Sheets sicher; Helium 10, Sellerboard o. ä. von Vorteil).

- Unternehmerisch und eigenverantwortlich – du siehst Aufgaben, statt auf sie zu warten.

- Souverän in der Kommunikation mit Marken und Lieferanten.

- Sehr gutes Deutsch, gutes Englisch.

- Erfahrung mit strukturiertem, verbindlichem Remote-Arbeiten.

## Benefits

- 100 % Remote in der DACH-Zeitzone, auf Wunsch Hybrid in Berlin oder Frankfurt

- Echte Verantwortung ab Tag eins – deine Accounts, deine Entscheidungen.

- Rückenwind statt Einzelkämpfertum: Content-Team (nach Absprache), ein spezialisierter PPC-Dienstleister und ein eingespieltes Logistik- und Operations-Team nehmen dir die Umsetzung ab – du gibst die Richtung vor.

- Mentoring & Coaching durch erfolgreiche Unternehmer und Manager, auf Wunsch begleitend zum Job.

- Team-Events und ein Büro in Berlin-Mitte oder Frankfurt, das dir auf Wunsch offensteht – remote heißt bei uns nicht allein.

- Flache Hierarchien, kurze Wege, ein Team, das seit 2016 weiß, wie Amazon funktioniert.

- Ein wachsendes Unternehmen mit rund 20 Marken – Raum zum Mitgestalten.

Klingt nach dir? Dann freuen wir uns darauf, dich kennenzulernen. Schick uns einfach deinen Lebenslauf und ein kurzes Anschreiben – erzähl uns darin, welchen Amazon-Account du schon einmal messbar nach vorne gebracht hast und warum EBZ zu dir passt. Wir melden uns schnell bei dir.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
