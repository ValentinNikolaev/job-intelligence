# Senior Solutions Architect - Germany

Posted: 2026-09-14T20:40:03Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**Who we are**

We're Redis. We built the product that runs the fast apps our world runs on. (If you checked the weather, used your credit card, or looked at your flight status online today, you’re welcome.) At Redis, you’ll work with the fastest, simplest technology in the business—whether you’re building it, telling its story, or selling it to our 10,000+ worldwide customers. We’re creating a faster world with simpler experiences. You in?

**Why would you love this job?**

As a Solutions Architect, you will educate and collaborate with customers to create customized Redis powered solutions for their specific business and database needs, helping them increase business value and overcome challenges. You will drive POCs, pilots, challenges and evaluations, working hands-on with our customers using one of the best technologies in the market.

The ideal candidate is a good listener with a talent for creative solutions. You enjoy tackling a wide variety of technical challenges patiently and pragmatically, never losing sight of the customer’s business objectives.

If you are a technology expert, with a desire to provide potential customers with the best customer experience, this is the right challenge for you.

Redis hires for this and similar roles on an ongoing basis, so your application will be collected and kept on file as needs arise, subject to and in accordance with applicable law. Redis may not contact you immediately following receipt of your application.

**What you’ll do:**

-

Help customers meet their technology and business requirements with Redis databases using Redis products, solutions and services.

-

Understand, quantify and verify the business needs of customers and their specific use cases.

-

Work diligently with the customer’s technical teams (architects, developers, PMOs and C-level experts) to ensure the success of all customer POCs and pilots.

-

Collaborate closely with the Sales team to develop effective account strategies and identify new account opportunities, as well as new business with existing accounts.

-

Present the company, its capabilities and technology in a highly professional and exciting way that will engage customers and help them see the business impact and competitive advantages of the Redis offering.

-

Use customer feedback and insights to improve product materials, technical best practice and technical materials, while providing feedback to Product Management teams and R&D.

**What will you need to have?**

-

3+ years of experience in pre-sales engineering (ideally database engineering) for enterprise software

-

Hands-on experience with server-side software development and Linux

-

Experience with scalable and highly available distributed systems

-

BS in Computer Science / B.A. or equivalent work experience

-

A team player with excellent communication and presentation skills

-

Able to travel regularly to visit customer sites

-

Excellent written and spoken English

Compensation: The base salary range for this role is 105 303 EUR to 131 253 EUR. Final compensation will be determined based on objective, job-related factors, including relevant experience, skills, role scope, level, and work location. This role may also be eligible for a comission and Redis benefits.

As a global company, we value a culture of curiosity, diversity of thought, and innovation from our employees, customers, and partners. Redis is committed to a diverse and inclusive work environment where all employees’ differences are celebrated and supported, and everyone feels safe to bring their authentic selves to work. Redis is dedicated to equal employment opportunities regardless of race, color, ancestry, religion, sex, national orientation, sexual orientation, age, marital status, disability, gender identity, gender expression, Veteran status, or any other classification protected by federal, state, or local law. We strive to create a workplace where every voice is heard, and every idea is respected.

Redis is committed to working with and providing access and reasonable accommodation to applicants with mental and/or physical disabilities. If you think you may require accommodations for any part of the recruitment process, please send a request to

Any offer of employment at Redis is contingent upon the successful completion of a background check, consistent with applicable laws.

Redis reserves the right to retain data longer than stated in the [privacy policy](https://redis.com/legal/privacy-policy/) in order to evaluate candidates.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
