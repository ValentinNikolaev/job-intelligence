# 2nd Level Service Desk Agent (m/w/d) - Berlin

Posted: 2026-09-14T18:13:43Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Wir sind SBIT – ein modernes Systemhaus mit rund 60 klugen Köpfen und Fokus auf Managed & Professional Services. Wir bauen Cloud-Lösungen, Netzwerke und Firewalls, die messbar Business-Wert stiften. Für dich heißt das im Support-Bereich: **2nd Level mit echtem Impact – direkt an der Schnittstelle zwischen User, System und Lösung.** Du bekommst Verantwortung, echte Remote-Arbeit, Mentoring durch Seniors, Zertifizierungen und Projekte, die dich fachlich fordern. Wenig Reiserei, viel Wirkung im Professional-Services-Kontext.

## Aufgaben

- **Incidents und Service Requests lösen:** Du nimmst Anfragen über Ticketsystem oder Hotline entgegen und sorgst eigenhändig dafür, dass Probleme schnell und zuverlässig behoben werden.

- **Den Überblick behalten:** Du klassifizierst, priorisierst und dokumentierst Anfragen – und bearbeitest sie selbst oder im Team, immer mit Blick auf unsere SLAs.

- **User & Systeme unterstützen:** Du kümmerst dich um Microsoft Server, Clients und User-Support, inklusive Hardwarebereitstellung via Intune.

- **Kunden vor Ort betreuen:** Durchschnittlich bist du alle zwei Wochen einmal direkt beim Kunden im Einsatz, lernst ihre IT-Landschaften kennen und findest Lösungen, die wirklich passen.

## Qualifikation

- Abgeschlossene Ausbildung zum Fachinformatiker oder eine vergleichbare Qualifikation.

- Gute Kenntnisse in Microsoft 365, Entra und Exchange Online sowie im Support für Windows Clients & Windows Server.

- Erfahrung mit Hardwarebereitstellung via Intune.

- Grundkenntnisse in Microsoft Azure und Antivirus-Lösungen.

- Deutschkenntnisse auf C1-Niveau

- Wohnsitz in der Region unserer Kunden in Berlin

- Idealerweise eine abgeschlossene Microsoft-Zertifizierung oder die Bereitschaft, eine zu erwerben.

## Benefits

- **Remote-First & geringer Reiseanteil:** Homeoffice ist Teil unserer DNA. Außerdem hast du durch die Gleitzeit Freiraum für private Termine, deine Familie oder die morgendliche Sportroutine. Auch Kundentermine sind planbar.

- **Weiterentwicklung & Zertifizierungen:** Herstellertrainings (z. B. von Microsoft, Dell, HP, Lenovo), Technologie-Zertifizierungen (z. B. Azure, Microsoft, Fortinet, Sophos etc.) sowie Mentoring durch Seniors in der Praxis. Du wählst, was du brauchst.

- **Gesundheit & Fitness:** Jobrad und Egym/Wellpass für Sportler. Und natürlich: kostenlose Getränke im Büro.

- **Teamspirit:** Teamwork & Respekt gehören zu unserem Werte-Kodex.

- **Ausstattung & Flex:** Freue dich auf moderne Hardware und Homeoffice-Setup. Klimaanlage im Büro, um der nächsten Hitzewelle zu trotzen.

Dann freuen wir uns auf Deine aussagekräftige Bewerbung inklusive Gehaltsvorstellung. Wenn Du Lust hast, schreibe uns auch Deine Big Five for Life! Wir stehen auf sowas!

Du bist Dir unsicher, ob Du alle Eigenschaften erfüllst? Bewirb Dich trotzdem! Bei uns zählen Deine Motivation und Deine Leidenschaft!

**Ansprechpartner**:

Janik Sohn, 069 695 961 746

**Bewerbungsprozess**:

Sobald dein Lebenslauf bei uns eingeht, melden wir uns innerhalb von drei Tagen bei dir zurück. Im besten Fall laden wir dich direkt zu einem kurzen Video-Interview (ca. 20–30 Minuten) ein – diesmal direkt mit deinem zukünftigen 2nd-Level-Team. Wenn es für beide Seiten passt, folgt ein Fachinterview. Und wenn auch das Match stimmt, erhältst du dein Angebot – ganz ohne langen Bewerbungs-Marathon.

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
