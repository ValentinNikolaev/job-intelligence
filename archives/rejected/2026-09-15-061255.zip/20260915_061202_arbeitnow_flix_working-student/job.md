# Working Student

Posted: 2026-09-14T20:45:29Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

At Flix, we offer a tech-driven environment where innovation meets real-world impact, with competitive pay, strong growth opportunities, and a culture of collaboration and ownership. 

As a Working Student Data Analytics (m/f/d) at Flix, you can make an impact by helping shape the data foundation behind product decisions - writing SQL, building insights from dashboards, and defining the business metrics that drive data-driven feature success. This is a part-time role (20 hours per week), based in Berlin.

**About the Role**

- Write SQL queries to extract and analyze data in Snowflake

- Support the Product Owner in shaping business metrics and measurement approaches for feature success

- Analyze data and extract actionable insights from dashboards and reports

- Support stakeholder feedback loops by translating data findings into clear, understandable outputs

- Contribute to metric documentation to improve data quality and discoverability

- Explore and adopt new data technologies as our stack evolves (e.g., Airflow)

**About You**

- Currently enrolled in an engineering, computer science, mathematics, or related program, with at least 3 semesters completed

- Solid foundational SQL knowledge - able to write and read queries independently

- Working knowledge of Git for version control

- Fluent in English (written and spoken)

- Genuine interest in analytics, data modeling, business metrics, and translating business requirements into data solutions

- Basic Python knowledge is a plus

- A perspective on data products and data mesh concepts, and how they shape the way modern analytics teams work

We recognize that everyone carries a unique set of valuable skills and experiences. If you think you could have an impact even though you don't meet 100% of the requirements, we still encourage you to apply. We want to hear from you! 

**What We Offer**

- **Travel perks**: 12 free Flix vouchers + 12 discount vouchers for friends & family.

- **Work from (M)Anywhere**: Depending on your role, work from another location for up to 60 days per year.

- **Hybrid work model**: We are an office-first company, but we offer flexibility to balance work and life.

- **Wellbeing support**: Access confidential 1:1 counselling, courses, and stress management for yourself and up to four family members.

- **Learning & Development**: Take advantage of language classes, training courses, and expert-led sessions to grow your skills.

- **Mentoring Program**: Connect with experienced colleagues to gain insights and accelerate your career.

To view more local benefits specific to each office location, please check out this link: [Locations - Flix Career](https://flix.careers/locations/)

**Why Join Flix?**

At Flix, we empower our teams to push boundaries and shape the future of mobility. As we continue to scale globally, we harness cutting-edge technology to make mobility smarter, more sustainable, and more affordable.

If you're looking for a place where you can drive change and redefine how millions of people travel, Flix is the place where you can lead your journey!

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
