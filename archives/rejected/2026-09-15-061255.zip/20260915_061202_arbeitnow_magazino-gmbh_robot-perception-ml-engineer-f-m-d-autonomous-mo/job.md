# Robot Perception/ML Engineer (f/m/d) Autonomous Mobile Robots

Posted: 2026-09-14T18:14:19Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

## Your tasks

- You develop and improve perception models for autonomous mobile robots, including object detection, obstacle classification, and free-space estimation

- You drive data-centric machine learning by scaling automated labeling, leveraging fleet data, and closing the sim2real gap through synthetic data and simulation-based evaluation

- You own model performance by defining benchmarks, tracking key metrics, and continuously improving real-world and benchmark results

- You deploy and validate perception models within our ROS-based robot software stack, ensuring reliable performance on real vehicles

- You collaborate closely with navigation, controls, and fleet software teams to deliver robust perception capabilities that enable autonomous operation

## Requirements

- You bring 2–5 years of professional and hands-on experience in robotics perception, computer vision, or machine learning

- You have strong Python skills; experience with C++ is a plus

- You have hands-on experience training and evaluating neural networks (PyTorch or similar) and follow a data-centric approach to improving model performance

- You have practical experience with synthetic data, simulation for ML, auto-labeling, active learning, or domain adaptation

- You apply a rigorous approach to model evaluation and understand how to measure real-world performance effectively

- You are familiar with ROS and Linux-based development environments

- You have a pragmatic engineering mindset and enjoy shipping, measuring, and iterating

## What we have to offer

- **Cutting-edge technology**: As pioneers in robotics we are able to navigate and manipulate without rails and guides and offer solutions to processes that no one could automate ever before!

- **Team**: We are an international team with more than 25 nationalities. You’ll work in a team with exceptionally smart, humble, collaborative and hardworking individuals.

- **Culture**: Come as you are! Join a vibrant, inventive, and diverse team that values collaboration over hierarchy. To innovate you need to fail from time to time — we always learn and improve.

- **Workplace**: Our office is located near the S‑Bahn station “Hirschgarten”. We work in a loft-style office with great equipment, our own workshop and testing area.

- **Full Board**: You don’t feel like thinking about what you want to have for lunch tomorrow, not to mention preparing it? Luckily, our french cook treats us with a freshly cooked free lunch everyday! And as the cherry on top, there is a packed fridge with drinks, fresh fruits and of course coffee!

- **Flexibility**: Flexibility is a top priority for us. Our hybrid working model for positions where presence is dispensable helps to achieve a healthy work-life balance.

- **Benefits**: We offer attractive holiday, Wellpass, health care, and compensation packages. Learn more about our current benefits here.

*At Jungheinrich Robotics, fostering inclusivity is very important to us. We are dedicated to create an inclusive environment for all candidates and provide equal opportunities to all qualified applicants regardless of gender, ethnicity, age, national origin, sexual orientation, culture, or education. If you need any reasonable adjustments to make the application process accessible for you, we’ll do our best to accommodate you. Feel free to approach us for that!*

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
