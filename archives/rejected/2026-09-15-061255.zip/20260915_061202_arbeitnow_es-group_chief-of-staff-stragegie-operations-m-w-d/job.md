# Chief of Staff - Stragegie & Operations (m/w/d)

Posted: 2026-09-15T02:09:39Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**Deine Aufgaben**

Als Chief of Staff (m/w/d) arbeitest du unmittelbar mit unserer Geschäftsführung zusammen und übernimmst eine zentrale Rolle bei der Steuerung und Weiterentwicklung der Eberhardt Service Group. Du bringst Struktur in komplexe Themen, schaffst Transparenz und sorgst dafür, dass strategische Entscheidungen konsequent in die Organisation übersetzt und umgesetzt werden.
Dabei bist du weit mehr als eine Schnittstelle: Du bist Sparringspartner der Geschäftsführung, Impulsgeber und Umsetzungstreiber – mit einem unternehmensweiten Blick auf Performance, Prozesse und Wachstum.

- Du bist die zentrale Kommunikations- und Steuerungsschnittstelle zwischen Geschäftsführung und Führungskräften.
- Du übersetzt strategische Prioritäten gemeinsam mit der Geschäftsführung in konkrete Ziele, Projekte und Maßnahmen.
- Du steuerst und verfolgst unternehmensweite Initiativen und stellst sicher, dass Verantwortlichkeiten, KPIs und Deadlines klar definiert und eingehalten werden.
- Du etablierst und moderierst regelmäßige Management- und Performance-Reviews mit den verantwortlichen Führungskräften.
- Du schaffst Transparenz über die Performance der verschiedenen Unternehmensbereiche und bereitest Management-Reports, Analysen und Entscheidungsgrundlagen vor.
- Du identifizierst Engpässe, Ineffizienzen und Risiken und entwickelst gemeinsam mit den Fachbereichen konkrete Lösungen.
- Du analysierst bestehende Prozesse und Strukturen und treibst deren Standardisierung, Digitalisierung und kontinuierliche Verbesserung voran.
- Du entwickelst Strukturen und Prozesse so weiter, dass sie mit unserem Wachstum effizient und skalierbar bleiben.
- Du übernimmst ausgewählte strategische Sonderprojekte von der Konzeption bis zur Umsetzung.
- Du agierst als Sparringspartner der Geschäftsführung, hinterfragst bestehende Ansätze konstruktiv und bringst eine unternehmensweite Perspektive in Entscheidungen ein.
- Du sorgst dafür, dass aus Entscheidungen konkrete Maßnahmen entstehen – und aus Maßnahmen messbare Ergebnisse.

**Dein Profil**

Für uns ist weniger entscheidend, welchen Jobtitel du bisher hattest. Entscheidend ist, dass du unternehmerisch denkst, komplexe Zusammenhänge schnell verstehst und Verantwortung für Ergebnisse übernimmst.
Idealerweise bringst du mit:

- Abgeschlossenes Hochschulstudium, idealerweise inBetriebswirtschaftslehre, Wirtschaftswissenschaften, Management, Volkswirtschaftslehre, Rechtswissenschaftenoder einem vergleichbaren Studiengang
- Mehrjährige Berufserfahrung in einer strategischen oder operativen Steuerungsrolle, beispielsweise inOperations, Unternehmensberatung, Unternehmensentwicklung, Projekt-/Programmmanagement oder als Chief of Staff
- Ein ausgeprägtes Verständnis für unternehmerische Zusammenhänge, Prozesse und operative Werttreiber
- Sehr gute analytische Fähigkeiten und die Fähigkeit, komplexe Sachverhalte schnell zu strukturieren und auf die entscheidenden Punkte zu reduzieren
- Erfahrung im Umgang mit KPIs, Performance Management und Reporting
- Ausgeprägte Kommunikations- und Durchsetzungsstärke, insbesondere im Austausch mit Führungskräften
- Die Fähigkeit, unterschiedliche Perspektiven zusammenzubringen und gleichzeitig konsequent auf Entscheidungen und Ergebnisse hinzuarbeiten
- Hohe Eigenverantwortung, Pragmatismus und eine ausgeprägte Hands-on-Mentalität
- Einen sicheren Umgang mit Excel und datenbasierten Analysen
- Erfahrung in einem dynamischen Wachstumsumfeld ist von Vorteil
- Erfahrung im Facility Management oder in einer vergleichbaren operativen Dienstleistungsbranche ist ein Plus – aber kein Muss

**Warum wir?**

Bei uns übernimmst du nicht einfach eine neue Position. Du bekommst die Möglichkeit, direkt an der weiteren Entwicklung eines wachsenden Unternehmens mitzuwirken und gemeinsam mit der Geschäftsführung Strukturen, Prozesse und Prioritäten aktiv zu gestalten.
Was dich bei uns erwartet:

- Direkter Einfluss & Verantwortung: Du arbeitest eng mit der Geschäftsführung zusammen, bekommst tiefen Einblick in unsere Unternehmenssteuerung und kannst Entscheidungen aktiv mitgestalten.
- Wachstum & Entwicklung: Vielfältige Karriere- und Entwicklungsmöglichkeiten in einem wachsenden Unternehmen, in dem du Verantwortung übernehmen und mit uns zusammenwachsen kannst.
- Gestaltungsspielraum: Flache Hierarchien, kurze Entscheidungswege und eine Kultur, in der deine Ideen ausdrücklich gefragt sind.
- Moderne Arbeitswelt: Moderne Arbeitsmittel, ein modernes Büro und flexible Arbeitszeiten durch Gleitzeit.
- Attraktive Rahmenbedingungen: Wettbewerbsfähige Vergütung sowie ein Firmenwagen, auch zur privaten Nutzung.
- Gesundheit & Wellbeing: Ein umfangreiches Angebot rund um Gesundheit, Fitness und Mental Health.
- Starkes Miteinander: Eine offene, kollegiale Unternehmenskultur, echte Wertschätzung, regelmäßige Teamevents sowie kostenlose Getränke.
Mehr als wirtschaftlicher Erfolg: Die Chance, mit deiner Arbeit einen echten Beitrag zu Nachhaltigkeit und sozialem Engagement zu leisten.

**KLINGT NACH DIR? **
**Dann freuen wir uns auf deine aussagekräftige Bewerbung unter Angabe deines frühestmöglichen Eintrittstermins sowie deiner Gehaltsvorstellung.
Werde Teil unseres Teams und gestalte mit uns die Zukunft des Facility Managements – nachhaltig, digital und kundenfokussiert.**

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
