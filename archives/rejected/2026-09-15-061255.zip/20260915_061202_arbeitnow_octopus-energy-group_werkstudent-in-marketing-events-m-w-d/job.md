# Werkstudent*in Marketing & Events (m/w/d)

Posted: 2026-09-15T02:04:13Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Wir sind **nicht **der lokale Stromanbieter um die Ecke. Wir sind das **globale EnerTech-Unternehmen**, das den Energiemarkt revolutionieren wird. Wir haben kein geringeres Ziel, als die global benötigte Energie **100%** **nachhaltig** zu gestalten. Global, agil und zukunftsorientiert verändern wir den Energiemarkt mit neuer Technologie zum Besseren.

Dabei sind unsere **Ökostromtarife nur die Basis**. Bereits seit 2022 installieren wir Wärmepumpen-Komplettlösungen mit **eigenen Fachkräften**. Außerdem arbeiten wir aktiv an der flächendeckenden Einführung von Smart Metern, **Elektromobilitätslösungen** und der **eigenen Stromerzeugung aus Wind- und Sonnenenergie**.

Das schaffen wir allerdings nicht alleine, sondern dazu brauchen wir dich! Werde Teil unseres Teams und fordere den Status Quo heraus. Mit Energie, die gut für den Planeten ist und gut für dein Karma. 💚 Finde jetzt deinen Traumjob und werde Teil der Energierevolution von Octopus Energy Germany.

**Deine Aufgaben**

-

**Event- & Projekt-Support:** Du unterstützt das Marketingteam bei der Vor- und Nachbereitung von Events sowie bei laufenden Projekten.

-

**Hands-on Logistik:** Du kümmerst dich um Materialbestellungen, Lieferungen und packst beim Auf- und Abbau von Veranstaltungen mit an.

-

**Lager- & Materialmanagement:** Du hältst Ordnung im Lager, verwaltest Bestände und hast Verfügbarkeiten stets im Blick.

-

**Office & Team-Koordination:** Du übernimmst tägliche Orga-Aufgaben im Büro, stimmst dich mit Dienstleister*innen ab und bringst eigene Ideen ein.

**Dein Profil**

-

**Studienstatus:** Immatrikulation an einer Hochschule/Universität (idealerweise Marketing, Event-/Projektmanagement oder vergleichbar)

-

**Hands-on Mindset:** Erste Orga-Erfahrung von Vorteil, hohe Zuverlässigkeit, Anpack-Mentalität und kühler Kopf in stressigen Momenten.

-

**Sprachen & Tools:** Sehr gute Deutsch- und gute Englischkenntnisse; Erfahrung mit Projektmanagement-Tools ist ein Plus.

-

**Rahmenbedingungen:** Verfügbarkeit von bis zu 20 Std./ Woche sowie Bereitschaft zur regelmäßigen Präsenz im Büro, Lager und bei Events.

Deine Benefits bei uns:

✅ Vergünstigungen & Vorsorge:

- Monatlicher Zuschuss zum Nahverkehrsticket

- Monatlicher Zuschuss zum Mittagessen

✅ Sport & Gesundheit

- Zuzahlungen zu Fitness- Angeboten über Wellpass

- Förderung deines mentalen Wohlbefindens mit unserem Partner Open Up

✅ Lernen & Weiterbildung

- Kostenlose Sprachkurse über Busuu

_________________

Bereit, den Energiemarkt mit uns zu revolutionieren? Erzähle uns, warum genau du uns dabei unterstützen solltest. Schicke uns deinen CV und alles, was wir wissen sollten, über unser Online-Formular. Wir freuen uns auf dich!

Du findest die Stelle super spannend, bist dir aber unsicher, ob du alle geforderten Skills zu 100% erfüllst? Bitte zögere nicht, dich trotzdem zu bewerben!

P.S.: Octopusse gibt es in allen Farben, Formen und Größen. Wir freuen uns auf Mitarbeiter*innen jeden Geschlechts, Alters, jeder sexuellen Identität, Herkunft, Religion, Weltanschauung, mit und ohne Behinderungen. Für uns zählt nur eins: du passt zu uns und brennst darauf, etwas zu verändern.

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
