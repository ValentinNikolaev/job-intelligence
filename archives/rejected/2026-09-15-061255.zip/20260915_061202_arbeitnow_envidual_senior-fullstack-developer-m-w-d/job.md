# Senior Fullstack Developer (m/w/d)

Posted: 2026-09-14T18:14:05Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Wir entwickeln Systeme, an denen das operative Geschäft unserer Kunden hängt: Anwendungen für Schadenregulierung, Provisionierung, Vertriebssteuerung, ERP- und Logistikprozesse sowie digitale Kunden- und Partnerportale. Wenn solche Systeme nicht funktionieren, entsteht nicht nur ein schlechtes Nutzererlebnis. Es entstehen Fehler, Verzögerungen, Kosten und im Zweifel echte Geschäftsrisiken.

Solche Systeme entstehen nicht durch zusätzliche Kapazität und sauber verwaltete Übergaben. Sie entstehen durch Teams, die das Problem als Ganzes verstehen und Verantwortung dafür übernehmen. Genau dafür gibt es Envidual als spezialisierte IT-Beratung.

Wir übernehmen Verantwortung von der fachlichen Analyse über UX und Architektur bis zur technischen Umsetzung und Weiterentwicklung. Dabei verstehen wir Softwareentwicklung nicht als Abarbeitung vorsortierter Tickets. Wir durchdringen die Prozesse, hinterfragen Anforderungen und treffen Entscheidungen, die auch langfristig tragen.

Unsere Teams sind bewusst schlank und interdisziplinär aufgestellt. Wer an einem Projekt arbeitet, kennt nicht nur seinen eigenen Ausschnitt, sondern versteht das Projekt, das System, das Produkt als Ganzes.

Diesen Anspruch stellen wir auch an die Menschen, die zu uns kommen: fachliche Neugier, technisches Urteilsvermögen und die Bereitschaft, Verantwortung nicht an der eigenen Rollengrenze abzugeben.

## Aufgaben

- Du entwickelst geschäftskritische Web- und Backend-Anwendungen, auf die sich unsere Kunden im täglichen Betrieb verlassen.

- Du übernimmst Features Ende zu Ende: von der fachlichen Klärung gemeinsam mit BUsiness Analysten und technischen Konzeption mit Architekten über die Implementierung bis zu automatisierten Tests, Auslieferung und Weiterentwicklung im produktiven Betrieb.

- Du arbeitest eng mit Business Analyse, UX/UI und Architektur zusammen. Dabei setzt du Anforderungen nicht einfach um, sondern hinterfragst sie und bringst deine technische Perspektive frühzeitig ein.

- Qualität ist für dich kein nachgelagerter Schritt. Du sorgst mit automatisierten Tests, Code Reviews, klaren Schnittstellen und wartbarem Code dafür, dass unsere Anwendungen langfristig tragfähig bleiben.

- Du gestaltest Architekturentscheidungen, Entwicklungsstandards, CI/CD-Prozesse und die technische Arbeitsweise deines Teams aktiv mit.

- In internen Initiativen entwickelst du unsere Engineering-Praxis weiter – aktuell unter anderem im Bereich Agentic Engineering. Was sich bewährt, bringen wir kontrolliert in reale Kundenprojekte.

## Qualifikation

- Du hast bereits mehrere anspruchsvolle Anwendungen entwickelt oder modernisiert und kennst sowohl Neuentwicklung als auch den Umgang mit gewachsenen Systemen.

- Du kannst eine fachliche Anforderung in eine technische Lösung übersetzen, sinnvolle Komponenten und Schnittstellen entwerfen und die Auswirkungen deiner Entscheidungen abschätzen.

- Du bist sicher in Java und/oder Kotlin, TypeScript sowie modernen Backend- und Frontend-Frameworks wie Springboot und Angular.

- Du kennst unterschiedliche Architekturansätze – etwa modulare Monolithen, Microservices und ereignisgetriebene Systeme – und kannst begründen, welcher Ansatz zum jeweiligen Problem passt.

- Du kannst die Qualität bestehender Systeme bewerten, technische Risiken benennen und konkrete Verbesserungen priorisieren.

- Du hast Erfahrung mit einer großen Cloud-Plattform wie Azure/GCP/AWS/OpenShift und kannst geeignete Dienste auf Basis fachlicher und technischer Anforderungen auswählen.

- Du kennst Security Best Practices, automatisierte Teststrategien, CI/CD und grundlegende Anforderungen an Observability und stabilen Betrieb.

- Du kannst andere Entwickler bei der Umsetzung anleiten, ohne ihnen jede Entscheidung abzunehmen.

- Du kommunizierst klar mit Teammitgliedern und Stakeholdern und bist bereit, auch schwierige technische Themen offen anzusprechen.

## Benefits

- **Projekte, die zählen**: Du arbeitest an Anwendungen, die zentrale Geschäftsprozesse unserer Kunden tragen. Deine Entscheidungen wirken sich nicht auf ein internes Demo-Projekt aus, sondern auf Systeme, die täglich produktiv genutzt werden.

- **Verantwortung mit echtem Einfluss**: Bei uns bekommst du nicht nur Aufgaben, sondern Gestaltungsspielraum. Du kannst technische Entscheidungen, Prozesse und Arbeitsweisen aktiv beeinflussen. Titel entscheiden dabei nicht darüber, wessen Argument zählt.

- **Lernen mit Substanz:** Du arbeitest eng mit erfahrenen Entwicklern, Architekten, Business Analysts und Designern zusammen. Statt eines starren Mentor-Mentee-Programms bekommst du direktes Feedback und Coaching, das zu deiner Rolle und deinen Zielen passt.

- **Flexibilität, die im Team funktioniert:** Wir arbeiten nicht nach starren Anwesenheitszeiten. Du gestaltest deinen Arbeitstag flexibel und stimmst dich so mit deinem Team und dem Projekt ab, dass Zusammenarbeit und Verlässlichkeit nicht darunter leiden.

- **Ein Arbeitsumfeld, das professionelles Arbeiten unterstützt:** Dich erwarten hochwertige Hardware, moderne Arbeitsplätze und ein gut ausgestattetes Büro in München – inklusive zweier Terrassen und einer Küche mit Getränken und Snacks.

- **Eine Vergütung, die deiner Verantwortung entspricht:** Wir vergüten Erfahrung, fachliche Tiefe und übernommene Verantwortung angemessen. Der Satz ist glaubwürdiger als „überdurchschnittliche Bezahlung ist Standard“. Noch stärker wäre er mit transparenten Gehaltsbändern.

- **Ein Team ohne Statusspiele:** Wir kommunizieren direkt, helfen einander und sprechen Probleme offen an. Regelmäßige Team-Events gehören dazu, sind aber nicht der Ersatz für eine gute Zusammenarbeit im Alltag.

Ergänzend bieten wir Corporate Benefits, vergünstigte Fitnessangebote und weitere Mitarbeitervorteile.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
