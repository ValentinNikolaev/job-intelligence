# Geschäftsführung Vertrieb und Service (m/w/d)

Posted: 2026-09-14T18:14:07Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Technische Dienstleistung im Bereich Mess- und Regeltechnik

Standort: Region Südwestdeutschland, Remote

**die Zukunft gestalten**

Sie sind ein:e leidenschaftliche:r und erfahrene:r Vertriebs- und Serviceleiter:in mit Expertise im Bereich technische Dienstleistung, der Führung eines Vertriebs- und Serviceteams, in der Akquise und im Projektmanagement.

Für Sie bedeuten Spaß und Freude bei der Arbeit, Erfolg und Anerkennung innerhalb eines hochmotivierten Teams. Sie sind gut organisiert und strukturiert. Ihre Fähigkeit andere Menschen zu motivieren und zu begeistern zählen zu ihren Talenten. Wenn Sie ein technisches Umfeld in einem technisch anspruchsvollen Bereich mit einem hohen Maß an Verantwortung und Flexibilität begeistert und diese Eigenschaften auch ausstrahlen, sollten Sie weiterlesen.

Unser Mandant ist eine mittelständische produzierende Unternehmensgruppe. Der Dienstleistungsbereich wird von zwei Standorten in Deutschland aus geführt. Das Unternehmen bietet ein interessantes Aufgabenfeld in Kombination mit einem sympathischen mittelständisch geprägten Führungsteam.

## Aufgaben

Der Geschäftsführer ist gemeinsam mit einem weiteren Geschäftsführer gesamtverantwortlich für den technischen Dienstleistungsbereich der Unternehmensgruppe an 3 Standorten. Er ist fokussiert auf den Vertrieb und die strategische und operative Weiterentwicklung eines von zweien Produkt- und ServicePortfolios. Ziel ist es, die Kundenbasis zu stabilisieren und nachhaltiges Wachstum durch neue Kunden und innovative Dienstleistungen/Produkte zu generieren.

- Gesamtverantwortung für den Bereich Vertrieb/Markt (strategisch & operativ)

- Führung, Motivation und Weiterentwicklung der Teams

- Kundenbeziehungen stabilisieren und Markt aktiv bearbeiten

- Ausweitung bestehender und Identifikation neuer Anwendungsfelder (z. B. Digitalisierung von Mess- und Regeltechnik)

- Analyse von Markttrends, Wettbewerbern und Kundenbedürfnissen

- Verantwortung für Angebotsstrategien, Preisgestaltung und Vertragsverhandlungen

- Teilnahme an Fachmessen, Konferenzen und Branchenveranstaltungen

- Aufbau und Rekrutierung fehlender Schlüsselpersonen im Dienstleistungs- und Servicegeschäft

- Sicherstellung einer hohen Servicequalität, Kundennähe und Marktpräsenz

- Entwicklung und Skalierung des Dienstleistungsportfolios

- Enge Zusammenarbeit mit der Muttergesellschaft

- Verantwortung von Budget, Zielerreichung, Weiterentwicklung & operativer Exzellenz

- Entwicklung und Pflege des Produkt- & Leistungsportfolios

## Qualifikation

**Fachliche Qualifikation**

- Führungserfahrung als Vertriebsleiter, Geschäftsführer / Bereichsleiter im industriellen Umfeld – Fokus Markt, Vertrieb

- Abgeschlossenes Studium im Bereich: Ingenieurwesen (z. B. Maschinenbau, Verfahrenstechnik, Elektrotechnik) oder Wirtschaftsingenieurwesen mit technischem Fokus

- Kenntnisse im Bereich Industrie, Service/Engineering oder MSR-Technik

- Nachweisliche Erfahrung im Aufbau und der Weiterentwicklung von Serviceorganisationen

- Vertriebserfahrung in technisch anspruchsvollen Dienstleistungen

- Erfahrung in der Leitung mehrerer Standorte, heterogener Teams (Teams unterwegs und an mehreren Standorten)

- Sehr gute betriebswirtschaftliche und strategische Fähigkeiten

- Sehr gute Fähigkeiten im Product Management für Dienstleistungen und technische Produkte

- Starke Verhandlungs- und Kommunikationskompetenz (intern wie extern)

- Ausgeprägte Kundenorientierung, Gespür für Marktveränderungen und Trends

**Persönliche Kompetenzen**

- Unternehmerpersönlichkeit mit gesundem Ehrgeiz und Hands-on-Mentalität. Praktiker

- Hört zuerst zu, arbeitet sich ein

- Ausgeprägte Leadership-Fähigkeiten: fordert & fördert, gibt Orientierung, übernimmt Verantwortung und denkt gleichzeitig „mit den Köpfen der Menschen“

- Hohe soziale Kompetenz, Stabilität & Verlässlichkeit – besonders in Veränderungssituationen

- Vorbildfunktion mit sozialer Verantwortung und solider Allgemeinbildung

- Begeisterungsfähig, integrativ und motivierend – kann Menschen für gemeinsame Ziele gewinnen

- Umsetzungsstark, pragmatisch, lösungsorientiert

- Belastbar, entscheidungsstark, verantwortungsbewusst

- Analytische Fähigkeiten und Marktverständnis

- „Easy-to-work-with“ – unkomplizierte, offene und vertrauenswürdige Persönlichkeit. Emphatisch im Umgang mit Kollegen, Kunden und Lieferanten

- „Getting things done“ – starke Resultatorientierung, hohe Leistungsbilanz und Wille, in der gesamten Wertschöpfungskette selbst mit Hand anzulegen

- Hohe Eigeninitiative und Ergebnisorientierung

- Deutsch ist Muttersprache; sehr gute Englischkenntnisse

- Reisebereitschaft >50% (national/international)

## Benefits

Unser Mandant bietet mehr als nur ein gutes Arbeitsklima. Neben spannenden Projekten und interessanten Zukunftsthemen setzt dieses Unternemen auf Offenheit, gegenseitige Wertschätzung, Respekt und ein hohes Maß an Arbeitsplatzsicherheit. Wenn Sie diese Position in einem erfolgreichen Unternehmen interessiert, dann freuen wir uns über die Zusendung Ihrer Bewerbung per Email. Für den vertraulichen Erstkontakt steht Ihnen Herr Michael Schuhmann telefonisch unter +49 1712787415 auch außerhalb der üblichen Geschäftszeiten gerne zur Verfügung.

**Wir freuen uns auf das Gespräch mit Ihnen!**

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
