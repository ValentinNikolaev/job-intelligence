# Senior Growth Marketing Manager (m/w/d)

Posted: 2026-09-15T02:09:57Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**Kurzbeschreibung**

**Growth **ist für dich mehr als ein Buzzword?
Du denkst nicht in einzelnen Kampagnen, **sondern im ganzen Funnel **– von Lead bis Bestandskunde?
Du willst CRM, Sales und Content so verzahnen, dass am Ende **messbare Pipeline** steht, statt nur Aktivität?

Dann suchen wir genau dich als **Senior Growth Marketing Manager (m/w/d) **für unser Team!

**Deine Aufgaben**

- Du **erarbeitest und verantwortest die Lead- und CRM-Strategie** für deinen Bereich - eingebettet in die Marketingstrategie der Gruppe
- Du **baust unser CRM auf und pflegst es kontinuierlich**, inklusive Datenqualität und Automatisierung
- Du **bereitest Sales-Botschaften marketingseitig auf**, von Sequenzen über Assets bis zu Argumentationslinien und entwickelst passenden Funnel-Content für jede Funnelstufe
- Du **verantwortest unsere Outbound-Kampagnen** über Lemlist sowie Inbound-Strecken mit Lead-Nurturing, z. B. für Leads aus unseren Webinaren
- **Bestandskundenmarketing, Upsell sowie Netzwerk- und Partnermanagement** zählen ebenfalls zu deinem Bereich
- Du **steuerst** **CRM- und Outbound-Tooling samt Budget** und reportest entlang klarer KPIs wie Pipeline, MQL, SQL und Upsell-Quote

**Dein Profil**

- Du hast **mind. 3 Jahre Erfahrung als Growth Marketing Manager:in,** CRM Manager:in oder in einer ähnlichen Rolle im Marketing eines Unternehmens oder einer Digitalagentur gesammelt
- Du kennst dich mit **CRM-Strategie, Marketing-Automatisierung und datengetriebener Funnel-Steuerung** von Lead bis Bestandskunde aus
- **Komplexe Vertriebsprozesse** und die enge Zusammenarbeit mit Sales schrecken dich nicht ab, sondern motivieren dich
- Mit deinem **schnellen inhaltlichen Verständnis** und kreativen Schreibstil entwickelst du Botschaften, die im B2B-Vertrieb wirklich ankommen
- Du hast ein **souveränes Auftreten** und agierst gegenüber Sales-Team und Partner:innen beratend und lösungsorientiert
- **Generalistisches Marketing-Know-how** sowie Erfahrung mit Tools wie HubSpot, Salesforce, Lemlist oder vergleichbaren CRM- und Outreach-Lösungen sind von Vorteil
- Du **arbeitest strukturiert**, behältst KPIs wie Pipeline, MQL und SQL stets im Blick und triffst Entscheidungen datenbasiert
- Du verfügst über sehr gute Deutschkenntnisse in Wort und Schrift, sowie sehr gute Englischkenntnisse

**Deine Benefits**

- Friend ist Programm: Wir nennen es zuerst, denn das macht uns aus: Kolleg:innen, die sich Freunde nennen, füreinander einstehen und mit denen es Spaß macht zu arbeiten
- Volle Flexibilität: Bei uns entscheidest du über Arbeitszeit und Arbeitsort – Hybrid-Work und Homeoffice? Wie es für dich gerade am besten passt!
- Zukunftsorientiertes Arbeiten: Wir arbeiten am Puls der Zeit und setzen aktiv auf KI in unserem Leistungsportfolio
- JobRad-Leasing: Ob für den Arbeitsweg oder die Wochenendtour – bei uns kannst du dein Wunschrad ganz einfach leasen
- Mobilität nach Wahl: Wir unterstützen dich bei deinem Arbeitsweg mit einem Zuschuss zum Deutschlandticket und der Option auf einen Tankgutschein
- Work-Life-Balance: Schätzen wir genau wie Du und ist mit unserem flexiblen Arbeitsmodell gesichert.
- Urlaubstage: 28 + 2 * 0,5 freie Tage für Weihnachten und Silvester
- After-Work-Programm: Neben der Urban-Sports-Mitgliedschaft und regelmäßigen Team-Events erwartet dich unsere jährliche Workation
- Weiterentwicklung: Wir bieten spannende Projekte und stetige Weiterentwicklung in einer Organisationskultur, in der der Status Quo auch hinterfragt werden darf
- Drinks & Snacks: In unseren Büros findest du alles für dein Wohlbefinden – Kaffee, Limonade, Bier, frisches Obst und vieles mehr

**Beim Lesen der Stellenanzeige dachtest du dir ****"Hell Yes!"?**

Dann schick uns deinen CV mit deinen Gehaltsvorstellungen und möglichem Startdatum an

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
