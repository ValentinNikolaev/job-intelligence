# Praxissemester BWL Controlling und Buchhaltung

Posted: 2026-09-14T18:14:19Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Die **Rödl & Herdegen Bauunternehmen GmbH** ist ein traditionsreiches, mittelständisches Bauunternehmen mit Sitz im Herzen von Regensburg. Seit über 60 Jahren bauen wir mit Leidenschaft und haben uns dabei zu einem der führenden Unternehmen in der Region entwickelt. Unser Erfolg basiert auf handwerklicher Qualität, unternehmerischem Denken und dem ständigen Anspruch, besser zu werden.

Wir entwickeln uns stetig weiter – und wir suchen Menschen, die diesen Weg aktiv mitgestalten wollen. Bei uns erwarten Sie ein dynamisches Umfeld, spannende Aufgaben und die Möglichkeit, echte Verantwortung zu übernehmen.

## Aufgaben

**Controlling:**

- Bearbeitung von Mahnungen und Rechnungsanfragen

- Mitwirkung im Projektcontrolling

- Unterstützung bei Kostenanalysen

**Buchhaltung:**

- Prüfung und Erfassung von Eingangs- und Ausgangsrechnungen

- Unterstützung bei der Kreditoren- und Debitorenbuchhaltung

- Bearbeitung von Mahnungen und Rechnungsanfragen

**Allgemeine kaufmännische Aufgaben:**

- Erstellung von Statistiken und Auswertungen

- Pflege von Stammdaten

- Mitarbeit an Optimierungsprojekten von Geschäftsprozessen

## Qualifikation

- Laufendes BWL-Studium mit Schwerpunkt Controlling und Rechnungswesen

- Grundkenntnisse in Finanzbuchhaltung und Kostenrechnung

- Sehr gute MS-Office-Kenntnisse, insbesondere Excel

- Hohe Zahlenaffinität und sorgfältiges Arbeiten

- Analytische und strukturierte Arbeitsweise

- Teamfähigkeit sowie selbstständige Arbeitsweise

- Verantwortungsbewusstsein

- Detailgenauigkeit

- Motivation und Engagement

## Benefits

- Offenes, wertschätzendes Team und kurze Entscheidungswege

- Eigenverantwortliche Mitarbeit an spannenden Bauprojekten

- Möglichkeit, theoretisches Wissen direkt in der Praxis anzuwenden

- Ein modernes Arbeitsumfeld mit abwechslungsreichen Aufgaben und viel Praxiserfahrung

- Regelmäßiges Feedback und Unterstützung bei deiner fachlichen Entwicklung

- Gemeinsame Team-Events und Firmenveranstaltungen

Werden Sie Teil eines Teams, das Vertrauen schenkt, Entwicklung fördert und Herausforderungen gemeinsam meistert.

**Bewerben Sie sich jetzt – wir freuen uns darauf, Sie kennenzulernen!**

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
