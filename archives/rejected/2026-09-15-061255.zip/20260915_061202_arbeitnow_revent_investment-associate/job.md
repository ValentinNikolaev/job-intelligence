# Investment Associate

Posted: 2026-09-14T18:13:42Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**Revent is an early stage venture capital firm** backing founders building companies that truly matter. We believe that the best builders of our generation don’t just want to build a unicorn, they want to create and leave a legacy for humanity. As a firm, we work relentlessly hard to earn the right to partner with these outlier individuals - *obsessives on a mission*, as we call them.

We've invested in companies such as **Avelios Medical** (Sequoia-led Series A), **Tem Energy** (Lightspeed just led their Series B), and several yet unannounced rounds with Tier 1 funds, and are currently deploying a **fresh €112M fund**. With this fund, we will invest in ~40 early stage companies all pushing the boundaries in AI and frontier tech to build a better collective future for us all.

## Tasks

We're hiring an **Associate to join us full time in Munich** (with plenty of time spent in Berlin and across Europe) as a core member of the investment team. We deliberately keep our investment team small to sprint faster on opportunities, so this is a rare chance to join the team in a high ownership, high agency position.

**Your job description is simple:** find and partner with the most exceptional founders building companies that truly matter. The day to day is incredibly diverse and will call on your analytical abilities, ingenuity, hustle, emotional intelligence, creativity, energy, and ambition on a regular basis. In a given week, you might:

- **Use agents (that you've built yourself),** your network, research, and creativity to find outlier founders at the start of their journey and push these opportunities through to a potential investment.

- **Figure out exactly what a founder might need** and provide that thing.

- **Go deep on a topic** and come back with a compelling investment thesis that results in our next investment.

- **Use your bias toward action** to build new valuable dimensions of Revent as a firm.

- **Leverage your good taste and judgement** to bring together interesting people in meaningful ways.

Our team is small and we work closely together. You'll have exposure to all parts of the investment process as well as to firm building.

## Requirements

We look for sharp thinkers with genuine curiosity, a builder's mentality, high energy, and a competitive streak. A technical background (e.g. hard sciences, computer science, AI specialization) is highly appreciated and ideally you’ve had previous exposure to startups / tech through internships, projects, or academic work.

You don't need years of experience for this role, but you do need to have an outstanding trajectory. We're looking for people who have genuine streaks of brilliance alongside overall "Swiss Army" skills. Brilliance could look like: an exceptional ability to see patterns where others cannot, true technical prowess, an encyclopedic knowledge of something relevant, extraordinary EQ, or herculean energy levels. Alongside this, we search for people who demonstrate:

- **Curiosity and clarity of thought.** You love to learn, to understand the underlying why, and can articulate ideas, implications, hypotheses, and a point of view with incisiveness.

- **An immense drive and desire to win.** Venture is competitive, and we are looking for people who love to compete. You get energy from a good challenge, lean forward into hard work, and really love winning.

- **A builder's spirit.** We see ourselves as a startup too, early in our journey with some initial wins and yet with much to prove. We look for people with a high degree of agency who are genuinely excited to co-create an exceptional firm.

- **A passion to create a better world.** Revent invests in companies that can become massive by virtue of solving real problems for humanity. We're mission-driven and seek people who want to back positive companies that will change the world.

- **Excellence.** We have a high bar and are constantly striving to get better. We look for people who are dedicated to doing things extremely well and to giving and receiving the feedback that will enable continuous growth.

**Practicalities**

This is a full time role based in Munich as part of a small, high ownership investment team. We are not sponsoring working visas, meaning you must already have the right to work full time in Germany.

Compensation is **between €65,000 and €85,000 annually** depending on experience, plus a performance based bonus and carried interest component which can be a significant part of compensation.

**How to Apply:**

This is an immediate hire. We review applications on a rolling basis and are moving fast, so there is an advantage to applying sooner. Please send:

- Your LinkedIn profile

- A few sentences about why you’d be excited to be an early-stage investor at Revent

- The names of the 1-2 most interesting pre-seed companies or founders you’ve encountered in the past 3 months with a few sentences about why you find them compelling

- From there, the process consists of: cultural fit interview with several team members, a case study, and time spent together in person to ensure mutual fit

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
