# Senior Solution Architect (m/w/d)

Posted: 2026-09-14T18:13:43Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Die QualityMinds GmbH ist ein mittelständisches, agiles Unternehmen mit Schwerpunkt auf Qualitätssicherung und Softwaretest, in dem kontinuierliches Lernen, Selbstorganisation und Eigenverantwortung gelebt werden. Wenn dies auch deine Leidenschaft ist und du außerdem Spaß an Projektarbeit und Beratung von Kund:innen hast, dann haben wir eine gute Basis für ein gemeinsames Kennenlernen.

Wir erweitern unser agiles und crossfunktionales Team und suchen deshalb dich als erfahrenen **Solution Architect (m/w/d)**.

## Aufgaben

- Du analysierst komplexe technische Anforderungen und entwickelst daraus zukunftsfähige Lösungs- und Plattformarchitekturen.

- Du konzipierst und implementierst moderne Cloud-, Kubernetes- und Container-Plattformen – sowohl On-Premises als auch in der Cloud.

- Du entwickelst und optimierst skalierbare CI/CD- und GitOps-Prozesse und treibst die Automatisierung von Entwicklungs- und Betriebsabläufen voran.

- Du berätst Kund:innen zu Plattformstrategien, Betriebsmodellen, Automatisierungslösungen sowie technologischen und architektonischen Fragestellungen.

- Du gestaltest sichere und compliancekonforme Systemarchitekturen unter Berücksichtigung aktueller Security-, Governance- und Best-Practice-Anforderungen.

- Du moderierst Workshops, erarbeitest Architekturkonzepte und unterstützt Entscheidende sowie Entwicklungsteams als technischer Sparringspartner:in.

- Du begleitest Migrationen und Modernisierungsprojekte und setzt die entwickelten Lösungen gemeinsam mit den Projektteams erfolgreich um.

## Qualifikation

- Du bringst mehrjährige Erfahrung in der Architektur und Umsetzung moderner IT-Cloud- und Plattformlösungen mit.

- Du verfügst über fundierte Kenntnisse in Kubernetes und Cloud-Native-Technologien sowie dem Betrieb containerisierter Plattformen.

- Du setzt moderne Cloud-Plattformen (AWS, Azure) ein, beherrscht Infrastructure as Code Methoden und die passenden Tools (Terraform, OpenTofu oder Ansible) und bist routiniert im Aufbau und Betrieb automatisierter CI/CD-Pipelines.

- Du verfügst über ein ausgeprägtes Verständnis für Security-by-Design, Zero Trust, Identity & Access Management, Secrets Management sowie Compliance- und Governance-Anforderungen (z. B. ISO 27001, BSI IT-Grundschutz oder NIS2).

- Du kommunizierst technische Zusammenhänge verständlich und zielgruppengerecht an unterschiedliche Stakeholder.

- Du verfügst über sehr gute Deutschkenntnisse (C1 Level) sowie gute Englischkenntnisse in Wort und Schrift.

- Dich zeichnen Kommunikationsstärke, Freude am direkten Austausch und ein hohes Maß an Flexibilität aus.

## Benefits

- Flexible Arbeitszeiten sowie hybrides Arbeiten.

- Arbeitsmöglichkeiten in unseren modernen Offices.

- Familienfreundliches Umfeld.

- Chancen eigene Themen miteinzubringen.

- Individuelle Weiterbildungsmöglichkeiten.

- Etablierte Communities of Practice und andere kollaborative Formate.

- Du hast die Möglichkeit, für die Ausübung eines Ehrenamtes, fünf Arbeitstage frei zunehmen.

Mit dir möchten wir Spaß und Erfolg in der Qualitätssicherung vorantreiben und weiter eine großartige Organisation sein, in der Menschen gerne arbeiten. Dabei spielt unsere starke Firmenkultur eine tragende Rolle: Wir sind ein agiles Unternehmen, in dem Lernen, Selbstorganisation und Vertrauen die Basis für unser Miteinander ist.

Überzeuge uns mit Deinen vollständigen Bewerbungsunterlagen.

Wir freuen uns auf Dich!

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
