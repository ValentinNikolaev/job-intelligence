# HR Manager (m/w/d) mit technischem Verständnis

Posted: 2026-09-14T18:13:54Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Über uns

Gestalte mit uns die Zukunft des Umweltingenieurwesens. SIERA vereint führende Unternehmen im Umweltingenieurwesen und verbindet technische Exzellenz mit nachhaltiger Entwicklung. Für unsere Unternehmensgruppe suchen wir einen HR Manager (m/w/d) mit technischem Verständnis, organisatorischer Stärke und einem ausgeprägten Gespür für Menschen, Kompetenzen und Strukturen. In dieser Rolle unterstützt du das Management bei personalnahen, organisatorischen und strukturellen Themen und trägst dazu bei, dass fachliche, teambezogene und gruppenweite Fragestellungen effizient und fundiert bearbeitet werden. Idealerweise bringst du einen Hintergrund im Ingenieurwesen – vorzugsweise im Umweltingenieurwesen oder in einem vergleichbaren technischen Umfeld – mit.

## Aufgaben

Deine Aufgaben

- Herausforderungen im Arbeitsalltag unserer Mitarbeitenden und Fachbereiche frühzeitig erkennen, aufnehmen und strukturiert begleiten

- Interne Abläufe und gruppenweite Strukturen koordinieren und weiterentwickeln

- Sicherstellen, dass relevante Themen effizient bearbeitet, sinnvoll priorisiert und nachhaltig weitergeführt werden

- Technische Anforderungen und fachliche Kriterien im Kontext von Projekten, neuen Strukturen und bereichsübergreifenden Themen einordnen

- Beurteilung von Kompetenzen unterstützen – fachlich-technisch (Anforderungen/Expertisen) und persönlich-organisatorisch (Potenzial, Zusammenarbeit, Kontext-Passung)

- Abstimmung zwischen Fachlichkeit, Organisation und Mitarbeitenden innerhalb der Gruppe fördern

- An einer professionellen, klaren und wirksamen Zusammenarbeit über Standorte und Bereiche hinweg mitwirken

## Qualifikation

Dein Profil

- Erfolgreich abgeschlossenes Studium, idealerweise im Ingenieur- oder Umweltingenieurwesen; alternativ Wirtschafts- oder Sozialwissenschaften

- Berufserfahrung in einem technischen, beratenden oder projektbezogenen Umfeld

- Fähigkeit, technische Anforderungen schnell zu erfassen und fachlich fundiert einzuordnen

- Ausgeprägtes Gespür für Menschen, Kompetenzen, Entwicklungspotenziale und teambezogene Dynamiken

- Hohes Organisationsvermögen sowie strukturierte, selbstständige und verantwortungsbewusste Arbeitsweise

- Souveränes Auftreten, klare Kommunikation und sehr gutes Urteilsvermögen

- Fähigkeit, unterschiedliche Themen parallel zu steuern und sicher zu priorisieren

- Sicherer Umgang mit Microsoft 365

- Sehr gute Deutschkenntnisse in Wort und Schrift

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
