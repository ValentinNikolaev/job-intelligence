# (Senior) Innovation Consultant (m/w/d) im Bereich New Business Innovation

Posted: 2026-09-14T18:13:55Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Innovation entsteht dort, wo neue Technologien auf unternehmerische Chancen treffen. Genau hier setzt unsere Arbeit an. Als (Senior) Innovation Specialist (m/w/d) unterstützen Sie führende Unternehmen dabei, Zukunftsthemen zu identifizieren, Innovationsstrategien zu entwickeln und neue Produkte, Services und Geschäftsmodelle auf den Weg zu bringen. Gleichzeitig gestalten Sie die Weiterentwicklung unseres Bereichs New Business Innovation aktiv mit.

## Aufgaben

- Eigenständige Bearbeitung sowie Leitung von Innovations-, Technologie- und Strategieprojekten für Kunden aus unterschiedlichen Branchen

- Durchführung von Markt-, Technologie- und Wettbewerbsanalysen sowie Erstellung von Studien, Management-Reports und Handlungsempfehlungen

- Konzeption, Entwicklung und Vermarktung von Innovations-, Technologie- und Benchmarking-Studien

- Konzeption, Vorbereitung und Durchführung von Workshops, Schulungen und Trainings zu Themen des Innovations- und Technologiemanagements

- Unterstützung bei der Akquise neuer Projekte und Kunden sowie eigenständige Entwicklung und Verfolgung von Geschäftsmöglichkeiten

- Steuerung kleiner Projektteams sowie Übernahme von fachlicher Verantwortung innerhalb größerer Projektvorhaben

- Beobachtung und Bewertung neuer Markt-, Technologie- und KI-Trends sowie Ableitung von Geschäftspotenzialen

- Aktive Mitwirkung an der Weiterentwicklung des Bereichs New Business Innovation durch neue Produkte, Services und Lösungsansätze

- Unterstützung bei Marketing- und Kommunikationsmaßnahmen, z. B. LinkedIn-Beiträgen, Webinaren, Fachartikeln und Veranstaltungen

- Mitwirkung bei Community-Initiativen sowie Organisation und Durchführung von Netzwerkformaten, Events und Expertenaustauschen

## Qualifikation

- Mindestens 3 Jahre relevante Berufserfahrung im Innovations-, Technologie- oder Strategiemanagement

- Abgeschlossenes Studium in Innovations- und Technologiemanagement, Wirtschafts-ingenieurwesen oder Vergleichbares

- Neugier und Entdeckergeist

- Analytisch-strukturierte Arbeitsweise und konzeptionelles Denken

- Ausgeprägte Team- und Kommunikationsfähigkeit

- Hohes Maß an Verantwortungsbewusstsein und Selbstständigkeit

- Fließend in der deutschen Sprache und verhandlungssichere englischen Sprachkenntnisse

## Benefits

- Vollwertige Mitarbeit in einem hochmotivierten Team

- Direkte Projekteinbindung & Kundenkontakt in einem internationalen Umfeld

- Abwechslungsreiche Tätigkeit, in der Sie eigene Ideen umsetzen können

- Ein sehr angenehmes Arbeitsklima mit engagierten Kolleginnen und Kollegen

- Regelmäßige Weiterbildungsmöglichkeiten

- Betriebliche Altersvorsorge & Zusatzkrankenversicherung

- Work-Life-Balance durch flexible Arbeitszeiten zur Verein­bar­keit von Privatleben und Beruf

Wir freuen uns auf eine aussagekräftige Bewerbung (Anschreiben, Lebenlauf, Zeugnisse) mit Gehaltsvorstellung.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
