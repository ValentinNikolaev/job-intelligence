# Account Executive, Enterprise

Posted: 2026-09-01T08:40:03Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

# **About Plane**

Plane's mission is to build the infrastructure the world's work runs on. Every organization runs on three things: the projects it's driving, the knowledge it keeps, and the requests it fields. Plane brings all three into one open, adaptable platform: simple enough for any team to adopt, dependable enough for organizations to build on. And we are building it for a future where humans and AI agents do that work together.

Plane began in public on GitHub at the end of 2022. Since then it has grown into a work management platform used by teams around the world: 55,000+ stars, 5,000+ forks, and a contributor community that reads our code and files our issues. Organizations run Plane as a managed Cloud service, on their own infrastructure, or inside fully isolated environments. Building in the open keeps us close to users and raises the standard for everything we ship.

Plane is the #1 work infrastructure in aerospace, defense, financial services, and other regulated industries: organizations whose requirements for control, auditability, and data residency rule most software out. When the strictest buyers pick a system of record, that choice means something. Adoption is growing fastest on Plane Cloud and in sovereign clouds, deployments that keep everything inside a country's own borders and rules.

Plane is backed by top investors and built across San Francisco, London, and Hyderabad. We work in tightly knit teams, stay close to users, and care about the visible product as much as the unglamorous details that make software dependable. People own problems end to end, and we add process only when it helps the work.

## **Humans and agents**

We believe the next decade of work will be done by humans and AI agents together. Not agents replacing people, and not a chat window bolted onto software built for humans clicking around, but both working in one system of action, where an agent's work is as visible and as accountable as a person's.

Most software treats AI as a feature. We treat agents as a kind of worker, and that changes what the system underneath has to be. Agents are only as good as the context they can see and the state they are allowed to change, so shared context, explicit state, durable history, and accountable action are not items on our roadmap. They are the product. Plane is built so that when an agent acts, the humans responsible can see what happened, why, and on whose authority, and the record survives.

This is what the infrastructure is for: making the future where humans and agents work together useful, legible, and fully within the organization's control. Every role at Plane is some part of building that.

## **About the role**

Plane has over a million users, and Fortune 500 companies deploying Plane. Enterprises in aerospace, defense, healthcare, and finance are running Plane in production — some in air-gapped, classified environments. The commercial demand is real and growing. This role exists to own it.

You'll run full-cycle enterprise deals from first conversation to signed contract. You'll work directly with the CEO and the product team, because at this stage, a deal isn't just a sales process — it's a product feedback loop. You'll sell into technical buyers who already know the product, navigate complex procurement in regulated industries, and help build the playbook as you go.

Plane's sales motion is product-led. The funnel doesn't start with cold outreach — it starts with teams already using Plane and hitting a ceiling where they need enterprise capabilities: compliance, SSO, air-gapped deployment, priority support. Your job is to convert that organic interest into expanding enterprise revenue.

## **What you'll do**

**Run deals end-to-end** — from first enterprise inquiry to signed contract. You own the entire arc: discovery, demo, technical evaluation, security review, procurement, negotiation, close. Full-cycle means full ownership.

**Convert product-led interest into enterprise revenue** — Plane's funnel doesn't start with outbound. It starts with someone self-hosting Plane, hitting a scale or compliance ceiling, and raising their hand. Your job is to recognize those signals, engage at the right moment, and guide the conversation from "we're evaluating" to "we're deploying."

**Navigate complex enterprise procurement **— our buyers sit in aerospace, defense, healthcare, and finance. That means security questionnaires, compliance reviews, legal redlines, multi-stakeholder approval chains, and timelines measured in months, not days. You need to know how to move a deal through that machinery without losing momentum.

**Hold technical credibility in the room** — you'll be talking to VPs of Engineering, DevOps leads, and IT architects about self-hosted deployments, air-gapped environments, SSO configurations, and data residency requirements. You don't need to be an engineer, but you need to hold your own in these conversations and know when to bring one in.

**Build and refine the sales playbook** — document what works. Which objections come up repeatedly? What's the typical deal cycle? Where do deals stall? What collateral is missing? You're not just selling — you're creating the system that the next 3-5 AEs will run on.

**Feed product with deal intelligence** — every deal you run generates signal about what the market wants, what competitors are doing, and where Plane has gaps. You bring that signal back to the product team in a structured, actionable way — not as a feature request list, but as a pattern.

## **What you'll bring**

-

You've closed enterprise software deals in the $500K–$1M ACV range, running the full cycle yourself — not inheriting qualified pipeline from a BDR team or handing off to a solutions engineer for the technical conversation.

-

You've sold into technical buyers — engineering leadership, DevOps, IT — and you can have a real conversation about deployment models, infrastructure, and security without reading from a script. You understand the difference between selling to someone who writes code
and selling to someone who writes checks.

-

You've worked at an early-stage company (Series A or earlier) where the sales infrastructure didn't exist yet. You've built your own pipeline, written your own sequences, created your own collateral, and figured out the motion before it was documented.

-

You understand product-led growth and know how to work with it rather than against it. You don't fight the free tier — you see it as the top of your funnel and know how to identify when a user is ready for an enterprise conversation.

-

You're comfortable with long deal cycles and multi-stakeholder procurement processes. You don't get rattled when a deal takes 4 months and involves legal, security, compliance, and IT all having veto power.

-

You're structured in how you manage your pipeline, your notes, and your follow-ups. Not because someone made you use a CRM, but because you've learned that rigor is what separates someone who closes from someone who's "always about to close."

-

You can write. Not marketing copy — clear, concise follow-up emails, proposals that address the buyer's actual concerns, and internal summaries that help the team understand what the market is telling you.

## **Why Plane?**

Every company says it is different. We will try evidence instead.

**The scope is real.** We are a passion team serving companies of every size, including some of the largest in the world. Something you ship this month will run inside a Fortune 500 company and a 50-person startup in the same week, and you will hear from both.

**The constraints make you better.** Plane runs in our cloud, in customers' clouds, and on machines that will never touch the internet. Much of the work happens in the open, where the issues, the fixes, and the roadmap conversations are public. Building software that survives all of that is harder than building an ordinary SaaS product, and it is a better education than most companies can offer.

**The people-and-agents future is being built here, in production.** We think humans and AI agents will share one system of action for work. We are building that system now, for customers who already depend on it, and you will work on that problem directly whatever your role.

**Your name is on the work.** The teams are deeply connected enough that credit and responsibility both find you fast. That is some pressure. Mostly it is the fun part.

If that sounds like your kind of place, we would like to meet you.

*Plane is an equal opportunity employer. We do not discriminate based on race, color, religion, gender identity or expression, sexual orientation, national origin, age, disability, veteran status, or any other protected characteristic under applicable law.*

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
