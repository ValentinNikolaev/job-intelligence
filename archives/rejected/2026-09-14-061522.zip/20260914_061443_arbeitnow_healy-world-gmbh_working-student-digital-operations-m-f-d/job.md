# Working Student - Digital Operations (m/f/d)

Posted: 2026-09-14T02:09:23Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**JOB DESCRIPTION**

**At Healy, you’re not just an employee—you’re a co-creator.**

Healy World GmbH is an innovative and leading company in the health and wellness industry.

We’re growing, we’re shaping the future, we’re making a difference—and you can be a part of it! We offer an innovative and diverse work environment that’s constantly evolving. In Finance, Legal, Marketing, or Operations, you’ll have the chance to make a real impact with your ideas and actively help shape change.

As a **Working Student – Digital Operations (m/f/d)**, you’ll support our team in analyzing data, creating reports and dashboards, and identifying opportunities to improve our business performance. With your analytical mindset, attention to detail, and proactive approach, you’ll help transform data into actionable insights and contribute fresh ideas to our BI initiatives.

**Be more than just an employee—become a co-creator.**

Where? At our location in Berlin

**YOUR MISSION**

- Handle incoming support tickets related to product rewards and calculations determine whether an issue is a technical bug, a process misunderstanding, or a calculation error, and resolve or escalate accordingly
- Set up new SKUs (products) end-to-end, including:

- Assigning the correct SKU number based on our existing numbering schema
- Creating new products in our CRM with full attribute details (category, item type, activation requirements, etc.)
- Syncing new SKUs into our accounting system(s) and configuring local tax/compliance settings where needed
- Coordinating with our activation/sync systems to ensure new products go live correctly
- Liaising with our Logistics team on warehouse mapping for physical products
- Tagging new SKUs correctly for our internal reporting
- Communicating status and resolving questions with requesters (mainly e-commerce team)

**YOUR PROFILE**

- Currently enrolled at a university in Germany
- Strong attention to detail and comfortable working with structured data and systems
- Good communication skills, you'll coordinate with multiple internal teams
- Prior experience with CRM systems, e-commerce platforms, or similar tools is a plus
- Reliable and able to work independently once onboarded
- Fluency in spoken and written English (additional languages are a a plus)

**THAT'S WHAT WE OFFER YOU!**

**Work Environment**: Innovative office with state-of-the-art technology and ergonomic, height-adjustable desks
**Flexibility**: The option to work remotely (40/60 split) as well as flexible working hours (flex time)
**Culture**: Inspiring corporate culture with an international team, diversity, and flat hierarchies that foster the exchange of ideas and quick decision-making
**Catering**: Free fresh fruit and non-alcoholic drinks (water dispenser, tea, etc.) and a wide selection of coffee options, lunch subsidy
**Shopping benefits**: Corporate benefit program with exclusive offers and discounts
**Mobility**: We subsidize your Germany-wide Jobticket
**Continuous improvement**: We are constantly working to further develop and optimize our benefits to make your daily work life even more enjoyable and rewarding

**ARE YOU READY TO BE PART OF OUR TEAM?**

Then join our team and help us shape the world of tomorrow.

Send us your application, including your earliest possible start date. If you have any questions,

We look forward to getting to know you!

Visit our careers page to explore other open positions you may not have seen yet: https://healy-world-gmbh.jobs.personio.de/?language=de">[https://healy-world-gmbh.jobs.personio.de/?language=de<](https://healy-world-gmbh.jobs.personio.de/?language=de);;/p>

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
