# Planungsingenieur:in Wassernetze

Posted: 2026-09-14T06:00:25Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Du möchtest die Trinkwassernetze von morgen planen und dabei an Projekten arbeiten, die für die sichere Versorgung von Städten, Gemeinden und Unternehmen eine unmittelbare Bedeutung haben? Dann verstärke unser Team als Ingenieur:in für Trinkwassernetze.

Bei uns übernimmst du – abhängig von deiner Erfahrung – eigene Projekte oder Teilprojekte und begleitest diese von der Grundlagenermittlung bis zur Umsetzung.

Du arbeitest eng mit unseren Kunden, Behörden, Versorgungsträgern, ausführenden Unternehmen und den Kolleg:innen aus den anderen Sparten zusammen.

Wir bieten Dir:

- **Eigene Projekte mit echter Verantwortung:** Du bearbeitest nicht nur einzelne Zuarbeiten, sondern kannst Projekte von der Idee bis zur Umsetzung begleiten.

- **Gestaltungsspielraum:** Wir geben dir die Möglichkeit, Abläufe, Standards und die Weiterentwicklung unseres Trinkwasserbereichs und des gesamten Unternehmens aktiv mitzugestalten.

- **Planung aus einer Hand:** Du bearbeitest Aufträge von Anfang bis Ende und bekommst, neben Trinkwasserprojekten, auch Einblicke in Fernwärme, Gas, Strom, 3D-Scan, Vermessung und Bauüberwachung.

- **Strukturierte Einarbeitung:** Eine klare Einarbeitungsliste, ein gepflegtes internes Wiki und feste Ansprechpartner erleichtern dir den Einstieg.

- **Flexibles Arbeiten:** Nach der Einarbeitung sind – abhängig von Projekt und Aufgabe – bis zu vier Tage **Homeoffice** pro Woche möglich.

- **Flexible Arbeitszeit:** Gleitende Arbeitszeiten und ein flexibles Stundenkonto unterstützen dich dabei, Beruf und Privatleben gut zu verbinden.

- **30 Tage Urlaub** und flexible Urlaubsplanung.

- **Moderne Arbeitsmittel:** leistungsstarker Laptop, Diensthandy, ergonomischer Arbeitsplatz sowie höhenverstellbare Schreibtische.

- **Individuelle Weiterbildung:** Wir unterstützen dich fachlich und persönlich durch passende Weiterbildungen und anerkannte Zertifizierungen.

- **Faire und transparente Vergütung** sowie weitere monetäre Benefits (BAV, Probonio, Kitazuschuss)

- **Direkte Kommunikation und kurze Entscheidungswege:** Du arbeitest mit Menschen, die ansprechbar sind und Entscheidungen nicht unnötig verkomplizieren.

- **Team und Kultur:** Duz-Kultur, regelmäßige Feedbackgespräche, Wertschätzung und mehrmals jährlich gemeinsame Teamevents.

- **Dienstwagen nach Absprache und Notwendigkeit**, sofern die Tätigkeit und der regelmäßige Außeneinsatz dies erfordern (z.B. bei überwiegender Arbeit in der Bauüberwachung).

Aufgaben:

- Du planst **erdverlegte Trinkwasserleitungen und Trinkwassernetze** – je nach Projekt und Beauftragung in den **Leistungsphasen 1–9 der HOAI**

- Du erarbeitest Netz- und Trassenkonzepte für Neubau, Erweiterung, Sanierung und Netzverdichtung

- Du führst die Dimensionierung von Rohrleitungen, Armaturen und weiteren Komponenten des Leitungsnetzes aus

- Du führst die Aufstellung und Prüfung von Planungsunterlagen, Lageplänen, Längsschnitten, Querprofilen und technische Details für Leitungsbauvorhaben durch

- Du wertest Bestandsunterlagen, Vermessungsdaten und GIS-Daten aus

- Du koordinierst die Abstimmung von Trassen und Leitungsführungen mit anderen Sparten wie Fernwärme, Gas, Strom, Glasfaser und Straßenbau

- Du erstellst Kostenschätzungen, Kostenberechnungen, Materiallisten und Bauablaufpläne für Leitungsbauprojekte

- Du erstellst Leistungsverzeichnisse und wirkst bei Ausschreibung und Vergabe mit

- Du nimmst gelegentlich an Vor-Ort-Terminen, Abstimmungen und Angebotsterminen teil

- Du erstellst Planungsberichte, Dokumentationen und strukturierte Datenübergaben

- Du kommunizierst klar und professionell mit Auftraggebern und bearbeitest Rückfragen eigenständig

- Du übernimmst Projektverantwortung und leitest eigene Projekte oder Teilbereiche

Qualifikationsprofil:

- Du hast ein abgeschlossenes Studium im Bauingenieurwesen, Umweltingenieurwesen, in der Versorgungstechnik, Siedlungswasserwirtschaft oder einer vergleichbaren Fachrichtung.

- Du hast mindestens zwei Jahre Berufserfahrung in der Planung, Berechnung oder Umsetzung von Trinkwasser- und Infrastrukturprojekten.

- Du hast technisches Verständnis und Freude daran, praktikable sowie langfristig tragfähige Lösungen zu entwickeln.

- Du kennst relevante DIN-Normen

- Du hast ausgeprägte Problemlösungsfähigkeiten

- Du denkst in kosteneffizienten Lösungen

- Du arbeitest selbstständig und eigenverantwortlich, strukturiert und wirtschaftlich

- Du kommunizierst klar und direkt

- Du kannst sicher mit den gängigen Office-Anwendungen umgehen.

- Du hast einen Führerschein der Klasse B und bist bereit, gelegentlich Vor-Ort-Termine wahrzunehmen.

- Du hast sehr gute Deutschkenntnisse in Wort und Schrift – mindestens auf dem Niveau C2.

## Darum Fokus Versorgung

Wir sind groß genug für anspruchsvolle Projekte und klein genug, damit deine Arbeit sichtbar bleibt. Bei uns gibt es kein unnötiges Micromanagement: Du bekommst Vertrauen, klare Ziele und den Freiraum, deine Aufgaben eigenverantwortlich zu lösen.

Du arbeitest in einem jungen, engagierten Team und hast die Möglichkeit, den Aufbau unseres Trinkwasserbereichs aktiv mitzugestalten. Dabei kannst du deine fachliche Tiefe entwickeln oder dich perspektivisch in Richtung Teamleitung weiterentwickeln.

## Bewirb dich jetzt

Du möchtest sichere und zukunftsfähige Trinkwassernetze planen und dabei Verantwortung übernehmen? Dann freuen wir uns auf deine Bewerbung mit Lebenslauf und relevanten Nachweisen.

**Bewerbung an:**

Du kannst dich auch zunächst ganz unkompliziert telefonisch bei uns melden.

Wir freuen uns, dich kennenzulernen.

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
