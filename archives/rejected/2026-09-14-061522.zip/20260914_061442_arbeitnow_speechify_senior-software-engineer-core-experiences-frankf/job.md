# Senior Software Engineer, Core Experiences - Frankfurt, Germany

Posted: 2026-09-14T05:55:12Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**Mission**

**Speechify is the easiest way to listen to the world’s information.** Articles on the web, documents in the cloud, books on your phone. We absorb it all and let you listen to it at your desk, on the go, at your own speed, and with tools that make learning easier, deeper, and faster.

What streaming services have done for audio entertainment, we’re doing for audio information. And whatever we’re doing seems to be working. We’re #1 in our category, and experiencing exponential growth.

**Overview**

We're looking for a Senior Software Engineer to join our Core Experiences Team. This team builds and maintains the foundational services and SDKs that power Speechify’s product experience across platforms. It's a critical role for someone who enjoys working at the intersection of product and infrastructure, thinks strategically, and is passionate about designing clear, reliable APIs and simple systems that directly enhance the user experience.

**What Yo****u’****ll Do**

- Collaborate with Speechify’s Product Teams to scope projects, find ways to reduce scope to get faster feedback from customers, navigate the integration/UX tradeoffs relevant to different product teams, and deliver solutions via our cross-platform SDK

- Optimize existing functionality to ship things like faster loading and more intelligent parsing by designing more efficient abstractions and improving our algorithms

- Ship cloud functions, lightweight backend services, and jobs using Kotlin

**An Ideal Candidate Should Have**

- Systems thinking. You know that optimizing a system requires end-to-end design, and you believe simplicity is valuable.

- Speed. You work quickly to generate ideas and options and know how to decide which things can ship now and what things need time

- Focus. We’re a high-growth startup with a busy, remote team. You know how and when to engage or be heads down

- Collaboration. You know how to inspire, play, and negotiate with opinionated designers, marketers, and PMs

- Preferred Tech Stack:

- Kotlin Multiplatform (Java experience is OK but role is Kotlin Multiplatform)

- Prior experience with GCP is a plus

**What We Offer **

- A fast-growing environment where you can help shape the company and product.

- An entrepreneurial-minded team that supports risk, intuition, and hustle.

- A hands-off management approach so you can focus and do your best work.

- An opportunity to make a big impact in a transformative industry.

- Competitive salaries, a friendly and laid-back atmosphere, and a commitment to building a great asynchronous culture.

- Opportunity to work on a life-changing product that millions of people use.

- Build products that directly impact and support people with learning differences like dyslexia, ADD, low vision, concussions, autism, and more.

- Work in one of the fastest growing sectors of tech, the intersection of artificial intelligence and audio.

**The Germany Based **Salary range for this role is: 30,000-120,000 USD/Year + Bonus + Stock depending on experience.

**Think you’re a good fit for this job? **

Tell us more about yourself and why you're interested in the role when you apply.
And don’t forget to include links to your portfolio and LinkedIn.

**Not looking but know someone who would make a great fit? **

Refer them!

**Speechify is committed to a diverse and inclusive workplace. **

Speechify does not discriminate on the basis of race, national origin, gender, gender identity, sexual orientation, protected veteran status, disability, age, or other legally protected status.

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
