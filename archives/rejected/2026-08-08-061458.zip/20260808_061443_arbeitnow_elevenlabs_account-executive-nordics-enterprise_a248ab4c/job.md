# Account Executive - Nordics - Enterprise

Posted: 2026-08-07T17:40:19Z

## Rejection

- Category: tech_stack
- Reason: role does not mention Go/Golang or PHP

## About ElevenLabs

ElevenLabs is an AI research and product company transforming how we interact with technology.

We launched in January 2023 with the first human-like AI voice model. Today, we serve millions of users and thousands of businesses - from fast-growing startups to large enterprises like Deutsche Telekom and Meta. Our investors are some of the world's most prominent, including Andreessen Horowitz, ICONIQ Growth and Sequoia. We've raised $781M in funding and our last valuation was $11B - multiples of 11, always.

We have expanded from voice into three main platforms:

-

ElevenAgents enables businesses to deliver seamless and intelligent customer experiences, with the integrations, testing, monitoring, and reliability necessary to deploy voice and chat agents at scale.

-

ElevenCreative empowers creators and marketers to generate and edit speech, music, image, and video across 70+ languages.

-

ElevenAPI gives developers access to our leading AI audio foundational models.

Everything we do is the result of the creativity and commitment of our team - builders doing the best work of their lives. We are researchers, engineers, and operators. IOI medalists and ex-founders. If you want to work hard and create lasting positive impact, we want to hear from you.

## How we work

-

**High-velocity: **Rapid experimentation, lean autonomous teams, and minimal bureaucracy.

-

**Impact not job titles: **We don’t have job titles. Instead, it’s about the impact you have. No task is above or beneath you.

-

**AI first:** We use AI to move faster with higher-quality results. We do this across the whole company—from engineering to growth to operations.

-

**Excellence everywhere: **Everything we do should match the quality of our AI models.

-

**Global team: **We prioritize your talent, not your location.

## What we offer

-

**Innovative culture:** You’ll be part of a generational opportunity to define the trajectory of AI, surrounded by a team pushing the boundaries of what’s possible.

-

**Growth paths: **Joining ElevenLabs means joining a dynamic team with countless opportunities to drive impact - beyond your immediate role and responsibilities.

-

**Learning & development**: ElevenLabs proactively supports professional development through an annual discretionary stipend.

-

**Social travel**: We also provide an annual discretionary stipend to meet up with colleagues each year, however you choose.

-

**Annual company offsite: **Each year, we bring the entire team together in a new location - past offsites have included Croatia and Italy.

-

**Co-working**: If you’re not located near one of our main hubs, we offer a monthly co-working stipend.

We're looking for an experienced, driven Enterprise Account Executive to drive ElevenLabs' growth across the Nordics enterprises. Our ideal candidate has a well-established network and a proven track record of selling to C-level and senior decision-makers at major Nordic organizations - and is passionate about the transformative possibilities of AI voice technology.

In this role you'll act as a strategic partner and trusted advisor, enabling clients to leverage our industry-leading models and ElevenAgents - our end-to-end platform for building and deploying AI voice agents - to reimagine their customer experience, internal workflows, and monetization strategies.

In this role you will:

-

Build and manage a growing portfolio of enterprise accounts across The Nordics

-

Identify new business opportunities where ElevenLabs' conversational AI capabilities - including ElevenAgents - can drive customer engagement, contact center automation, and operational efficiency.

-

Lead consultative, multi-stakeholder sales cycles, building compelling business cases that translate AI voice technology into measurable business value for senior executives and economic buyers.

-

Develop and maintain a deep understanding of the conversational AI landscape, including customer use cases, competitive solutions, and emerging trends - particularly as they apply to regulated Nordics industries

-

Demonstrate expertise - or a strong willingness to learn - about conversational AI and how ElevenLabs' voice technology can unlock value across customer support, virtual agents, IVR modernization, and in-app assistants

-

Develop and execute account strategies to expand ElevenLabs' presence within key enterprise verticals, navigating complex procurement and organizational structures.

-

Partner closely with Customer Success, FDEs and Solutions Engineering to ensure smooth onboarding, deployment, and expansion of accounts.

-

Serve as a trusted advisor to clients, educating C-suite and senior operations leaders on emerging trends in generative AI, voice interfaces, and conversational agents.

Requirements:

-

7+ years of quota‑carrying enterprise sales experience in SaaS or technology, ideally with exposure to AI, generative AI, LLM-based products, or API‑driven platforms.

-

Proven success closing deals and managing long, complex sales cycles with multiple stakeholders across business, IT, legal, and procurement.

-

Well-connected in the Nordic enterprise landscape, with an existing network of senior individuals and strong executive presence and ability to build relationships at the C‑suite and board level.

-

Experience selling technical solutions to product and engineering leaders; ability to translate complex technology into business value.

-

Deep understanding of enterprise procurement and legal processes in the Nordics, with the ability to accelerate deal velocity within complex organizational structures

-

Comfort operating in an early‑stage, high‑growth environment, including building new playbooks and iterating quickly.

-

Passion for voice and audio AI and how it can unlock transformative value for customers.

-

A hybrid of customer & product-driven mentality that prioritizes client satisfaction & scale

-

Native or full professional proficiency in English. Swedish preferred language skill; strong English for internal collaboration

Location

This role is remote but Stockholm is preferred.

#LI-remote

We are an equal opportunity employer and do not discriminate on the basis of race, religion, national origin, gender, sexual orientation, age, veteran status, disability or other legally protected statuses.

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
