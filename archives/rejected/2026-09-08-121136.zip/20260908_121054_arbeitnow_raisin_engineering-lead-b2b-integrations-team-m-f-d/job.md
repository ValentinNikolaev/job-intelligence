# Engineering Lead - B2B Integrations Team (m/f/d)

Posted: 2026-09-08T08:55:04Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Raisin is the world’s leading platform for savings and investment products. Founded in 2012, the **FinTech** connects consumers with banks in the EU, the UK and the US. This gives consumers **better interest rates** and banks a **diversified form of refinancing**. Our vision is to offer savings and investments without barriers and thus open up the global 160 trillion euro market.

Raisin currently employs more than 800 people from over 75 countries worldwide. Today, the platform holds over 80 billion euros in assets from **more than one million investors** which have accrued over 5 billion euros in returns.

**Team**

The B2B Integrations Team (BIT) powers Raisin’s core B2B solutions end-to-end, building the applications and services that allow our global partners to sell deposits. We own the full B2B backend ecosystem, ranging from modern services in the Raisin core system to high-impact legacy environments. We are passionate about taking existing, complex systems and elevating them. We partner closely with domain teams to expose new platform capabilities, work alongside B2B Partnership to onboard integration partners, and collaborate with operations to guarantee platform stability. Our team owns the complete service lifecycle: from early architectural design and development to long-term maintenance and 24/7 production runtime support.

**Your Responsibilities**

- You are responsible for the full E2E delivery cycle, from requirements analysis, and effort estimation through design, implementation, QA, delivery, and support.

- You nurture an inspiring environment with open communication and a culture of trust.

- Champion in writing clean, maintainable, and efficient code across the team’s tech stack - mainly Java, but Python as well for backend - adhering to best practices in software development. Implement new features and maintain existing codebases to ensure high performance and availability.

- You proactively resolve impediments and mitigate risks for your team.

- In case you need to escalate delivery and team risks, you do this in a timely fashion, with a well-articulated solution/mitigation plan.

- You collaborate closely with your team’s Product Manager and Tech Lead.

- You facilitate the team’s work on strategy and planning for the delivery.

- With the Product Manager, you drive the OKR process for your team: communication of objectives, Key result definition, team commitment, and pairing OKRs with individual target agreements for your engineers.

- You recruit, hire, and onboard engineers into the team.

- You develop your engineers’ soft- and technical skill sets according to the company’s goals and needs.

- You craft agreements and individual development plans with every team member, aligned to the team's goals.

- You uncover training opportunities as well as provide coaching for your team.

- You recognize high performance and reward accomplishments; you act on low performance in a timely manner.

- You establish and keep strong performance standards for your direct reports.

**Your Profile**

- You have a university degree in Computer Science, Engineering, Information Systems, or related fields or equivalent practical experience.

- You bring at least 2 years of leadership/people management experience in a remote setup and have a strong focus on delivery.

- You have hands-on experience in technical platform transitions within a company.

- You have strong hands-on experience (min. 8 years) as a Backend Software Engineer and want to stay one of the main contributors to your team.

- You know how to manage software projects to a successful delivery in a collaborative fashion.

- You have up-to-date, in-depth knowledge of the software development lifecycle in modern Backend technologies.

- You are comfortable with open code and architecture discussions.

- You bring experience with AWS Services, K8S, and Event-Driven architectures.

- Very good communication skills; Fluency in English; German-language skills are a plus but not mandatory.

**Join our mission, join our team – and grow with us!**

At Raisin, we care about each other and it is one of our top priorities to foster an open and caring environment in which everyone feels welcome and comfortable. Our culture is strongly driven by our ambitious team, which connects more than 75 different nationalities.

As part of our team, you will benefit from:

- Employee Development Budget of €2,000 and four full training days per year.

- Flexible working hours, home office and 30 vacation days.

- A company pension scheme (Betriebliche Altersvorsorge), which we support with 20%.

- Enjoy more than 50+ different sports with Urban Sports Club: We subsidize your membership with more than €20 per month.

- Do you miss being in the office? The Deutschland Ticket gets you there, which we subsidize with €25 per month.

- Love cycling? With JobRad, lease the bike of your choice and enjoy tax savings, plus Raisin covers your monthly insurance costs.

- Hungry all the time? Snacks, daily fresh fruit as well as drinks provided at the office.

- You are moving from another country or city to join us? We may support your relocation.

[*Raisin Applicant Privacy Policy*](https://www.raisin.com/corporate/raisin-applicant-privacy-policy/)

We value diversity and the unique experiences each individual brings. If you’re excited about this role but don’t meet every requirement, we still encourage you to apply.

We are an equal opportunity employer and are committed to creating an inclusive environment for everyone, regardless of race, colour, ancestry, religion, sex, national origin, sexual orientation, age, citizenship, marital status, disability, or gender identity.

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
