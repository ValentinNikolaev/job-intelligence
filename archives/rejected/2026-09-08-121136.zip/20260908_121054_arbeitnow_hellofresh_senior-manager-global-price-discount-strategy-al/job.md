# Senior Manager Global Price & Discount Strategy (all genders)

Posted: 2026-09-08T08:55:13Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

## **About the role: What's in the Box**

As Senior Manager Global Price & Discount Strategy (all genders) you will be part of the Global Price & Discount Strategy Team, shaping pricing and discount strategy across our full global portfolio which includes our core brand, HelloFresh, as well as: Factor, GreenChef, EveryPlate, Chef's Plate, and Youfoodz. You will own the strategy and execution of our global roadmap for active customer & referral incentives, partnering closely with local market leadership, tech, marketing, and more which makes this a unique opportunity to combine analytical depth, strategic thinking, and cross-functional execution.

Please note that this position is a 24-month fixed-term contract (with the aim of converting it to a permanent position afterwards).

## **What you’ll do: The Recipe**

- **Global Referral Strategy: **Own the conceptualization, execution, and optimization of our global referral incentive strategy, ensuring alignment with overall business goals and market conditions and translating strategy into tangible action.

- **Loyalty Program & Retention Economics: **Lead incentive strategy and impact modeling to drive performance of our emerging loyalty program and churn prevention initiatives.

- **Advanced Testing & Analysis:** Own the full AB testing lifecycle from hypothesis generation and test setup to execution and post-test analysis to constantly refine our incentive models.

- **Data-Driven Optimization:** Identify opportunities to improve current global strategies through deep-dive analysis, increasing customer lifetime value while balancing top and bottom-line growth.

- **Stakeholder Engagement:** Partner with and influence senior leadership and global teams (e.g., Lifecycle Marketing, Product, Analytics) in setting strategy roadmaps and sharing recommendations that drive impactful decision-making.

- **Playbook Development:** Establish and refine best practices and playbooks to ensure a consistent, scalable approach to pricing and discount initiatives across all markets.

## **What you’ll bring: The Ingredients **

- Master’s degree in Business/Management, Business Analytics, Economics or any related field.

- 4-6 years of professional experience in pricing strategy, consulting, analytics, or a subscription-based business model.

- Strong analytical skills and advanced command of Excel with the ability to translate complex data into actionable insights, additional SQL-knowledge is a plus.

- Extensive experience devising and measuring the effectiveness of discount strategies (including AB testing), with a proven track record from other data-rich business environments.

- Outstanding written and verbal communication skills including the ability to lead effective meetings and presentations with senior management.

- Track record of end-to-end project ownership in a fast-paced environment.

- Outstanding attention to detail to ensure analysis accuracy.

Above all, we are looking for people who will make HelloFresh better. There are many different ways of developing skills, and we love diverse experiences! So even if you don’t “tick all the boxes” but think you’d thrive in this role, we would really like to learn more about you.

## **What we offer: The Toppings**

Elevate your lifestyle! Join one of Europe's fastest-growing tech powerhouses in a dynamic phase of expansion.

- Immerse yourself in a diverse global community of 90+ nationalities.

- Enjoy a competitive compensation package that goes beyond the norm, with perks like a HelloFresh- subsidized Pension Scheme, Berlin relocation support, and a Hybrid working model.

- Exclusive discounts on your weekly HelloFresh box and office meals.

- Invest in your growth with an annual learning & development budget, German language learning budget, and access to the HelloFresh Academy.

- Plus, we've got your well-being covered with mental health support, transportation perks, and working-parent-friendly benefits. From our 24/7 gym access,wellbeing platforms like Headspace and Spill, to sabbatical leave options, HelloFresh is not just a workplace; it's a lifestyle of perks and possibilities!

## **Are you the missing ingredient? **

If this sounds like a tasty opportunity, we’d be excited to hear from you. We aim to review your profile and respond within 5 business days.

#JD1002

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
