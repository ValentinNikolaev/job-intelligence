# Mitarbeiter*in Presse- und Öffentlichkeitsarbeit (m/w/d) 35 Std./Woche | Unbefristet | Ab 01.10.2026 | Berlin (City West)

Posted: 2026-09-08T08:00:39Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Sie schreiben gern, denken redaktionell und möchten dazu beitragen, dass die Perspektiven von Psychotherapeut*innen in Politik und Öffentlichkeit sichtbar werden? Sie können komplexe gesundheitspolitische Themen präzise, verständlich und mediengerecht aufbereiten? Dann verstärken Sie unser Team in der Presse- und Öffentlichkeitsarbeit.

Der Bundesverband der Vertragspsychotherapeuten e.V. (bvvp) ist der Dachverband von 16 eigenständigen Landesverbänden. Mit rund 6.000 Ärztlichen und Psychologischen Psychotherapeut*innen sowie Kinder- und Jugendlichenpsychotherapeut*innen vertritt der Verband die Interessen seiner Mitglieder und bringt die Perspektive der Psychotherapie in die gesundheitspolitische Debatte ein.

## Aufgaben

Sie arbeiten in einem kleinen Team mit unterschiedlichen Schwerpunkten. Je nach Bedarf übernehmen Sie Aufgaben in den Bereichen Pressearbeit, Redaktion, Website, Social Media sowie im Rahmen von Veranstaltungen und Kampagnen.

- Sie verfassen und redigieren Texte für unser Printmagazin, die Website, für Mitgliederinformationen und fachliche Publikationen. Sie bereiten gesundheitspolitische und fachliche Themen verständlich, präzise und zielgruppengerecht auf

- Sie wirken redaktionell bei Entwürfen für Pressemitteilungen, Stellungnahmen und Positionspapieren mit

- Sie pflegen und aktualisieren die Inhalte unserer Website

- Sie unterstützen Veranstaltungen, Kampagnen und weitere Maßnahmen der Verbandskommunikation

- Sie erstellen Beiträge für LinkedIn, Instagram und Facebook und passen Inhalte an die jeweiligen Kanäle an

## Qualifikation

- Abgeschlossenes Hochschulstudium in PR/Öffentlichkeitsarbeit, Medienmanagement, Journalismus oder eine vergleichbare Qualifikation

- Mehrjährige Berufserfahrung in Redaktion, Journalismus und/oder Presse- und Öffentlichkeitsarbeit (Erfahrung im Verbandsumfeld von Vorteil)

- Hervorragendes sprachliches Ausdrucksvermögen und Redigierkompetenz, Sicherheit in Stil und Orthografie: Sie bringen komplexe Sachverhalte präzise auf den Punkt

- Erfahrung mit Content-Management-Systemen, idealerweise WordPress, sowie sicherer Umgang mit MS Office

- Erfahrung in der Betreuung und Weiterentwicklung von Social-Media-Kanälen (Facebook, Instagram, LinkedIn). Wünschenswert: Canva-Grundkenntnisse

- Strukturierte, selbstständige, zuverlässige und kooperative Arbeitsweise; Bereitschaft, sich in neue Wissensbereiche einzuarbeiten

## Benefits

- Eine unbefristete Beschäftigung mit 35 Stunden pro Woche und eine vielseitige, verantwortungsvolle Tätigkeit

- Vergütung nach Qualifikation und Berufserfahrung

- Betriebliche Altersvorsorge (VBLU)

- Monatlicher Pluxee-Gutschein in Höhe von 50 Euro

- 30 Tage Urlaub (5-Tage-Woche)

- Mobiles Arbeiten in Absprache nach der Einarbeitungszeit

- Zentraler Arbeitsort in City West

- Weiterbildungsmöglichkeiten

- Ein kollegiales, lebendiges Team mit viel Raum für eigene Ideen

- Mitarbeit bei einem bundesweit aktiven Berufsverband im Bereich Gesundheitspolitik/Psychotherapie

Bitte senden Sie uns Ihren Lebenslauf, relevante Zeugnisse und – sofern vorhanden – aussagekräftige Arbeitsproben per E-Mail.

Bei Rückfragen steht Ihnen Frau Anja Manz, Leiterin der Öffentlichkeitsarbeit des bvvp, gerne zur Verfügung: 030-88725954

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
