# (Senior) Inside Sales Specialist (m/w/d) / Technischer Vertriebsinnendienst – Pumpentechnik | Maschinenbau | DACH

Posted: 2026-09-08T08:30:22Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

## **Wir suchen Verstärkung – Willkommen bei MUNSCH!**

**Bringen Sie Technik, Kundenanforderungen und Vertriebserfolg zusammen.**

Die **MUNSCH Chemie‑Pumpen GmbH** steht seit über 60 Jahren für innovative Pumpenlösungen aus Kunststoff für die Chemie- und Industriebranche. Von dem Standort in **Ransbach‑Baumbach bei Koblenz** aus entwickeln und produzieren wir weltweit eingesetzte Pumpen für anspruchsvolle, korrosive und toxische Flüssigkeiten.

Bei uns erwarten Sie spannende Aufgaben in einem **innovativen, internationalen Umfeld** – in einem Familienunternehmen, das hochwertige Produkte, Qualität, moderne Prozesse, kontinuierliche Weiterentwicklung sowie Verbesserung & Teamgeist lebt.

**Werden Sie Teil eines wachstumsorientierten Unternehmens, das Technik begeistert und Lösungen für die Zukunft schafft!**

**Als erfahrener Mitarbeiter (m/w/d) im technischen Vertriebsinnendienst bzw. Backoffice übernehmen Sie bei uns eine zentrale Rolle zwischen Kunden, Außendienst und Produktion. Sie steuern anspruchsvolle Angebots- und Auftragsprozesse für innovative Pumpensysteme und tragen aktiv zum Vertriebserfolg in der DACH-Region bei.**

####

## **Aufgaben**

Sie sind Profi im **technischen Vertriebsinnendienst / Inside Sales** und möchten **Prozesse aktiv steuern** statt nur abzuarbeiten? Dann verstärken Sie unser Backoffice-Team DACH bei **MUNSCH Chemie‑Pumpen GmbH** und übernehmen Sie eine **Schlüsselrolle im Vertriebsprozess unserer Pumpensysteme**.

**Ihr Aufgabengebiet – Verantwortung & Abwechslung**

-

Angebots‑ & Auftragsmanagement für technische Pumpensysteme

-

Bearbeitung kundenspezifischer Lösungen und Sonderanfertigungen

-

Technische Kundenbetreuung im Inside Sales

-

Koordination des Außendienstes

-

Prüfung und Abstimmung von Kauf-, Liefer- und Vertreterverträgen sowie Mitwirkung bei kaufmännischen Verhandlungen

-

ERP-gestützte Prozesssteuerung & Dokumentation

-

Kontinuierliche Optimierung von Vertriebs-, Angebots- und Auftragsprozessen

-

Enge Zusammenarbeit mit Produktion, Logistik und technischem Innendienst

###

## **Qualifikationen**

**Ihr Profil – das zeichnet Sie aus**

-

Mehrjährige Erfahrung im technischen Vertriebsinnendienst / Inside Sales oder Auftragsmanagement eines Industrie- oder Maschinenbauunternehmens

-

Starkes technisches Verständnis für erklärungsbedürftige Produkte oder Anlagen

-

Sicherer Umgang mit ERP‑Systemen, idealerweise APplus

-

Gute Deutsch- und Englischkenntnisse

-

Freude an der engen Zusammenarbeit mit den Kollegen im Außendienst, im technischen Innendienst und in der Produktion

-

Strukturierte, eigenverantwortliche und lösungsorientierte Arbeitsweise in Verbindung mit einer guten Prozessorientierung

-

Persönliche Stärken: strukturiert, verbindlich, zuverlässig – auch bei parallelen Aufgaben behalten Sie den Überblick

###

## **Wir bieten**

**Unser Angebot**

-

Vielseitige (Senior)-Position mit Verantwortung im Kern des Vertriebsprozesses

-

Hochwertige, technisch anspruchsvolle Produkte mit hoher Marktakzeptanz

-

Eingespieltes Team, kurze Entscheidungswege, offene Kommunikation

-

Gestaltungsspielraum und die Möglichkeit sich persönlich mit den eigenen Ideen einzubringen

-

Umfassende, praxisnahe Einarbeitung

-

Sicherheit in einem etablierten und erfolgreichen, inhabergeführten Familienunternehmen

-

Zusätzliche Benefits: flexible Arbeitszeiten, faire Vergütung mit 13. Monatsgehalt, Zuschuss zur Altersvorsorge, Jobrad, kostenlose Getränke und bis zu 30 Urlaubstage

Diese Position eignet sich insbesondere für Bewerber (m/w/d) mit Erfahrung im Technischen Vertriebsinnendienst oder als Inside Sales Specialist, Sales Engineer, Vertriebsmitarbeiter Innendienst, Customer Service Manager Industrie, Auftragsmanager, Export-Sachbearbeiter oder Mitarbeiter Vertriebsinnendienst Maschinenbau.

###

## **So geht es weiter!**

Wenn Sie Interesse haben, die Position (Senior) Inside Sales Specialist (m/w/d) / Technischer Vertriebsinnendienst in diesem dynamischen Unternehmen zu übernehmen, freuen wir uns darauf, Sie persönlich kennenzulernen.

Bewerben Sie sich ganz unkompliziert – im ersten Schritt genügt ein aktueller Lebenslauf mit Angabe Ihrer Gehaltserwartung.

Über ein paar Zeilen zu Ihrer Motivation freuen wir uns, ein Anschreiben ist aber kein Muss.

E-Mail: **

**Ihr Ansprechpartner**

Als langjähriger Partner unterstützen wir, die GiPsy Beratungsgesellschaft, das Unternehmen **MUNSCH** bei der Besetzung dieser Position.

Im Auswahlverfahren sind wir Ihr persönlicher Ansprechpartner und begleiten Sie vom ersten Kontakt bis zu den weiteren Gesprächen. Wir führen die Vorauswahl durch und stimmen die einzelnen Schritte eng mit **MUNSCH** ab.

Die Entscheidung über die Besetzung der Position und die spätere Einstellung erfolgen direkt durch **MUNSCH**.

Für Fragen steht Ihnen **Kathrin Kramer**, Head of Recruiting & Consulting bei der **GiPsy® Beratungsgesellschaft**, gerne zur Verfügung.

-

Telefon: + 49 2683 946 95 19

-

E-Mail: **

Hospitalstraße 2b - D-53567 Asbach

[www.gipsy.de](http://www.gipsy.de/)
[GiPsy Beratungsgesellschaft](https://gipsy.de/Website/consulting/)

D-53567 Asbach

[www.gipsy.de](http://www.gipsy.de/)

**Mehr über uns**

-

[MUNSCH Chemie-Pumpen GmbH](https://www.munsch.de/)

-

[MUNSCH - Linkedin](https://www.linkedin.com/company/munsch-chemie-pumpen-gmbh/posts/?feedView=all)

-

[MUNSCH - Instagram](https://www.instagram.com/munsch_chemie_pumpen/)

-

[MUNSCH Kunststoff-Schweißtechnik GmbH](https://www.munsch-kunststoff-schweisstechnik.de/)

-

[GiPsy Beratungsgesellschaft](https://gipsy.de/Website/consulting/)

-

[Linkedin](https://www.linkedin.com/company/gipsy-beratungsgesellschaft-f%C3%BCr-personal-und-organisation-mbh/)

Die Verwendung der männlichen Sprache dient ausschließlich der besseren Lesbarkeit und ist geschlechtsneutral zu verstehen.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
