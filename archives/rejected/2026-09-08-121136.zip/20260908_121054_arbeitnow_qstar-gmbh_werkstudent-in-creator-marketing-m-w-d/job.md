# Werkstudent:in Creator Marketing (m/w/d)

Posted: 2026-09-08T08:00:39Z

## Rejection

- Category: tech_stack
- Reason: role does not mention Go/Golang or PHP

Qstar ist eine neue Performance-Nutrition-Marke – The Performance Standard – für Menschen, die im Job, im Training und im Alltag viel leisten. Wir bauen die Marke von Anfang an creator-first: Reichweite ist für uns kein Budgetposten, den man mietet, sondern etwas, das wir gemeinsam mit Creatorn aufbauen. Genau daran arbeiten wir gerade – und dafür suchen wir dich.

Du wirst nicht Kaffee kochen und Listen abtippen. Du arbeitest an der Stelle, an der die Marke wächst: beim Finden und Verstehen der Menschen, die Qstar nach außen tragen

## Aufgaben

- Du findest passende Creator-Profile auf Instagram, TikTok und YouTube – über Plattform-Suche, Hashtags, ähnliche Accounts und Discovery-Tools.

- Du prüfst jedes Profil gegen klare Kriterien: Reichweite, echte Video-Performance und Brand Safety. Im Zweifel entscheidest nicht du allein – dafür gibt es das Team.

- Du erfasst und pflegst die Profildaten sauber in unserem CRM. Genauigkeit zählt hier mehr als Tempo.

- Du ordnest Creator ihren Content-Nischen zu – die Grundlage dafür, dass unsere Ansprache persönlich und passend wird, nicht generisch.

- Du wirkst aktiv am Aufbau unserer Creator-Community mit und bringst deine Sicht auf die Creator-Landschaft ein.

## Qualifikation

- Du bist eingeschriebene:r Student:in und hast pro Woche verlässlich ca. 20 Stunden Zeit.

- Du bewegst dich sicher in Social Media und kennst die deutschsprachige Creator-Szene – idealerweise in Fitness, Sport, Healthy Lifestyle, Business, Lifestyle oder Fashion.Du hast ein Gespür dafür, was ein gutes, glaubwürdiges Profil ausmacht – jenseits der reinen Follower-Zahl.

- Du arbeitest gründlich und gewissenhaft mit Daten und behältst auch bei vielen Profilen den Überblick.

- Du bist eigenständig, zuverlässig und kommst mit remote-Arbeit gut zurecht.

- Deutsch fließend, Englisch für Recherche und Tools reicht aus.

Kein Muss, aber ein Plus: erste Berührung mit Influencer-/Creator-Marketing, Affiliate-Programmen oder Social-Analytics sowie Erfahrung mit CRM- oder Recherche-Tools.

## Benefits

- 20 Std./Woche mit flexibler, planbarer Zeiteinteilung rund um dein Studium.

- Hybrides Arbeiten in Hamburg oder Berlin – oder komplett remote, ganz wie es zu dir passt.

- Vergütung nach gesetzlichem Mindestlohn.

- Echte Verantwortung ab Tag 1: Du baust eine Marke mit auf, statt fertige Prozesse zu verwalten.

- Ein junges Unternehmen mit klaren Wachstumsperspektiven – und dem Raum, mitzuwachsen.

- Ein erfahrenes Führungsteam, das sein Handwerk versteht und bei dem Menschlichkeit kein Nice-to-have ist, sondern Haltung.

Ab Oktober. Remote oder hybrides Arbeiten in Hamburg der Berlin.

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
