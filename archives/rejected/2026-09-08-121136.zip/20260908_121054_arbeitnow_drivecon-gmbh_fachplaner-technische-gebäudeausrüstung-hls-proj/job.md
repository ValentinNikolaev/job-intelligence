# Fachplaner technische Gebäudeausrüstung HLS / Projektleiter Versorgungstechnik (m|w|d)

Posted: 2026-09-08T08:00:38Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**Bringe Gebäudetechnik in anspruchsvolle Infrastrukturprojekte!**

Technische Gebäudeausrüstung muss nicht nur funktionieren – sie muss zu den besonderen Anforderungen des jeweiligen Bauwerks passen. Genau dafür suchen wir dich.

Als **Fachplaner Technische Gebäudeausrüstung mit Schwerpunkt HLS** verstärkst du unser Team im Bereich **dc | Infrastrukturplanung**. Du planst Heizungs-, Lüftungs- und Sanitäranlagen, entwickelst technisch durchdachte Lösungen und begleitest unsere Projekte von der ersten Idee bis zur Umsetzung.

## Aufgaben

**Darauf kannst du dich bei uns freuen**

- **Keine 08/15-Projekte**

Du planst nicht die nächste Standard-Heizzentrale für irgendein beliebiges Gebäude. Bei uns entwickelst du HLS-Lösungen für außergewöhnliche Infrastrukturprojekte wie Schleusen, Wehranlagen, Schiffshebewerke und bewegliche Brücken. Das bedeutet: besondere technische Anforderungen, ungewöhnliche Rahmenbedingungen und Projekte, die man nicht jeden Tag auf dem Tisch hat.

- **Projekte von der ersten Idee bis zur Umsetzung**

Du bearbeitest die Leistungsphasen nach HOAI mit Schwerpunkt auf den LPH 1–3 sowie 5–8 und begleitest deine Projekte damit von den ersten Grundlagen bis zur Umsetzung auf der Baustelle.

- **Technische Berechnungen und Auslegung

**Du führst erforderliche Berechnungen durch, legst Anlagen und Komponenten aus und dimensionierst diese entsprechend den technischen Anforderungen des jeweiligen Projekts.

- **Planungs- und Ausschreibungsunterlagen**

Du erstellst Planungsunterlagen, Leistungsbeschreibungen und Leistungsverzeichnisse und schaffst damit eine belastbare Grundlage für Ausschreibung, Vergabe und Ausführung.

- **Abstimmung mit allen Projektbeteiligten**

Du stimmst deine Planung mit Auftraggebern, Architekten, Fachplanern, unseren internen Planungsteams sowie ausführenden Unternehmen ab und sorgst dafür, dass Schnittstellen frühzeitig erkannt und sinnvoll gelöst werden.

- **Begleitung der Bauausführung**

Auch nach Abschluss der Planung bleibst du am Projekt: Du unterstützt bei technischen Fragestellungen während der Ausführung, prüfst die Umsetzung und begleitest Projekte bis zur erfolgreichen Fertigstellung.

- **Eigenständige Projektbearbeitung**

Je nach Erfahrung übernimmst du Schritt für Schritt mehr Verantwortung und bearbeitest deine Projekte perspektivisch eigenständig.

## Qualifikation

**Mit diesem Profil bist du die ideale Ergänzung für unser Team**

- Du hast ein Studium im Bereich Versorgungstechnik, Gebäudetechnik, Energietechnik oder einer vergleichbaren Fachrichtung abgeschlossen oder verfügst als Techniker oder Meister im Bereich HLS / SHK über eine entsprechende Qualifikation.

- Idealerweise hast du bereits Erfahrung in der Planung von Heizungs-, Lüftungs- oder Sanitäranlagen gesammelt.

- Du kommst aus einem ausführenden HLS- oder SHK-Unternehmen und möchtest künftig stärker in die Planung einsteigen? Praktische Erfahrung aus der Ausführung ist für uns eine wertvolle Grundlage. In die planerischen Abläufe, HOAI-Leistungsphasen und unsere Arbeitsweise arbeiten wir dich gezielt ein.

- Du besitzt ein ausgeprägtes technisches Verständnis und suchst Lösungen, die nicht nur planerisch richtig sind, sondern sich auch in der Praxis umsetzen lassen.

- Du arbeitest selbstständig, strukturiert und lösungsorientiert und behältst auch bei technisch anspruchsvollen Aufgaben den Überblick.

- Gleichzeitig kommunizierst du offen und klar und arbeitest gerne mit unterschiedlichen Fachdisziplinen, Auftraggebern und ausführenden Firmen zusammen.

- Kenntnisse in HOAI, VOB sowie einschlägigen Normen und technischen Regelwerken sind von Vorteil. Entscheidend ist für uns aber vor allem, dass du technisch stark bist, pragmatisch denkst und Lust hast, dich fachlich weiterzuentwickeln.

## Benefits

**Das macht Arbeiten bei DriveCon besonders**

Gute Projekte entstehen nicht nur durch Technik, sondern vor allem durch Menschen, die gerne zusammenarbeiten. Deshalb ist uns wichtig, dass du bei DriveCon nicht einfach nur deine Aufgaben abarbeitest, sondern dich fachlich einbringen, weiterentwickeln und auf dein Team verlassen kannst.

**Du bist Teil des Ganzen**

Bei uns verschwindet niemand irgendwo im Organigramm. Deine Arbeit hat direkten Einfluss auf unsere Projekte und deine fachliche Meinung ist ausdrücklich gefragt.

**Projekte, an denen du wachsen kannst**

Unsere Aufgaben sind selten Standard. Unterschiedliche technische Anforderungen und besondere Bauwerke sorgen dafür, dass du immer wieder vor neuen Fragestellungen stehst und dein Wissen kontinuierlich ausbauen kannst.

**Weiterentwicklung, die zu dir passt**

Ob fachliche Vertiefung, neue Software, Normen oder zusätzliche Verantwortung – wir unterstützen Weiterbildungen, die dich in deiner täglichen Arbeit wirklich weiterbringen.

**Kurze Wege statt langer Abstimmungsschleifen**

Wenn eine Frage auftaucht, sprechen wir miteinander. Du kannst jederzeit auf die Erfahrung deiner Kollegen zurückgreifen und musst Probleme nicht allein lösen.

**Unkompliziertes Miteinander**

Bei uns sind alle per Du, ein Dresscode ist überflüssig und offene Kommunikation gehört zum Alltag. Wir arbeiten professionell, ohne dabei unnötig steif zu sein.

**Flexibilität im Arbeitsalltag**

Nicht jeder Arbeitstag läuft gleich – und das muss er auch nicht. Flexible Arbeitszeiten, mobiles Arbeiten und kurzfristige Abstimmungen ermöglichen dir, deinen Arbeitsalltag sinnvoll zu organisieren.

**Langfristig gut aufgestellt**

Ein unbefristeter Arbeitsvertrag, faire Vergütung, 30 Tage Urlaub, betriebliche Altersvorsorge und Überstundenkonten ohne Ablaufdatum sorgen für verlässliche Rahmenbedingungen.

Wir freuen uns auf dich!

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
