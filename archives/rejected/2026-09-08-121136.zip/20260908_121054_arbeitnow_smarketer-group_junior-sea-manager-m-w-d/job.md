# Junior SEA Manager (m/w/d)

Posted: 2026-09-08T09:00:56Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**Du denkst analytisch, verstehst Zielgruppen und liebst Paid Search? Dann bist du bei uns richtig. 🚀**Deine MissionAls (Junior) SEA Account Manager:in bist du operative:r bzw. strategische:r Ansprechpartner:in für Kund:innen. Dein Ziel: messbare Performance & Wachstum durch sauber konzipierte und optimierte Google-Ads-Kampagnen.

## Aufgaben

**Dein Daily Business:**

- Strategische Betreuung und Weiterentwicklung unserer SEA-Kunden

- Eigenständige Betreuung der Kundenaccounts

- Planung, Umsetzung und Optimierung von SEA-Kampagnen

- Laufende Analyse der Kampagnen-Performance

- Ableitung und Umsetzung von Optimierungsmaßnahmen

- Erstellung von Reportings und Präsentation der Ergebnisse

- Beratung der Kunden zu SEA-Strategien und Potenzialen

- Budgetsteuerung und Überwachung relevanter KPIs

- Vorbereitung und Durchführung von Kundenterminen

- Enge Abstimmung mit Kunden und internen Teams

## Qualifikation

Das macht dich aus

- Studium/Ausbildung oder vergleichbare Qualifikation

- Zahlenaffin, technisches Verständnis

- Eigenständig, strukturiert, teamorientiert

- Kommunikativ & kundensicher

- Fließende Deutsch- und gute Englischkenntnisse in Wort und Schrift für die erfolgreiche Kommunikation mit Kolleg:innen und Kund:innen

- Nice to have: Agentur-/Kampagnenpraxis und/oder erste Google-Ads-Erfahrung

## Benefits

Darauf kannst du dich freuen

- **Sicherer Hafen:** Unbefristeter Vertrag in einem innovativen Unternehmen

- **Flexibilität:** Home-Office-Option, flexible Arbeitszeiten und spannende Projekte

- **#Wissenstauscher:** Inhouse Academy mit Google-Ads-Know-how zum Start

- **Weiterentwicklung:** Growth Journey, Fortbildungsbudget, 360°-Feedback und eine Fehlerkultur, in der Lernen wichtiger ist als Stillstand

- **Teamspirit:** Wertschätzung, flache Hierarchien und ein echtes Miteinander

- **Familienfreundlich:** Eltern-Kind-Büro und die Option, in Teilzeit zu arbeiten

- **Tierisch gut:** Bring deinen Hund mit in unser zentrales Office

- **Gesund und Fit:** Coachings, Mental Health Angebote, regelmäßige Gesundheitswochen und Urban Sports Vergünstigungen

- **On Track:** Zuschuss zum Deutschlandticket und ein Jobrad

- **Gemeinsame Erlebnisse:** Regelmäßige Teamevents, Firmenfeiern und kostenlose Snacks & Drinks

Das sind wir

Wir von der **Smarketer GmbH** sind Teil der Smarketer Group – DEM Netzwerk für spezialisierte Agenturen im Online-Marketing. Bei uns dreht sich alles um Google Ads und Microsoft Advertising. Seit 2011 liefern wir messbare Performance – datengetrieben, kreativ und mit einem Team, das zusammenhält und Erfolge gemeinsam feiert. Bei uns kannst du dich auf ein Team freuen, das zusammenhält und einfach Bock hat, gemeinsam Erfolge zu feiern.*Bei uns zählt Talent, Motivation und Persönlichkeit – unabhängig von Geschlecht, Herkunft, Religion, sexueller Orientierung, Behinderung oder Alter. Vielfalt macht uns als Team stärker und erfolgreicher. Unsere Kultur lebt von Fokus, Partnerschaft und Leistungsdenken: wir arbeiten konzentriert an unseren Zielen, ziehen als Team an einem Strang und feiern Erfolge, wenn wir gemeinsam starke Ergebnisse erreichen. Bei uns sollst du nicht nur arbeiten, sondern dich wirklich wohlfühlen.* 🚀

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
