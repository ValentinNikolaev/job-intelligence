# Controller (m/w/d)

Posted: 2026-09-08T10:01:29Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Die STULZ GmbH ist seit 1947 ein inhabergeführtes Familienunternehmen mit 3.500 Beschäftigten weltweit – und einer klaren Mission: energieeffiziente Präzisionsklimageräte und Kühlsysteme „Made in Germany" zu entwickeln, die in kritischen Infrastrukturen wie Rechenzentren weltweit zum Einsatz kommen.

Als globaler Marktführer in diesem Segment vereint STULZ technologischen Anspruch mit echter Stabilität.

n der Hamburger Zentrale suchen wir dich als Controller (m/w/d), der die Finanzsteuerung eines internationalen Unternehmens aktiv mitgestaltet – mit Verantwortung, Gestaltungsspielraum und einem starken Team im Rücken.

## Aufgaben

- Du wirkst aktiv an der Budgetplanung und den Forecast-Prozessen mit und unterstützt damit eine fundierte Unternehmenssteuerung

- Du erstellst termingerecht Monats- und Jahresabschlussunterlagen und sorgst für eine verlässliche Finanzberichterstattung

- Du bereitest das Management Reporting auf, analysierst Kennzahlen und kommentierst Entwicklungen klar und adressatengerecht

- Du führst betriebswirtschaftliche Analysen durch und leitest daraus konkrete Handlungsempfehlungen ab

- Als Finance Business Partner betreust du den Bereich Produktion bei betriebswirtschaftlichen Fragestellungen und vertrittst bei Bedarf den Bereich Global Sales

- Du entwickelst und optimierst KPIs und schaffst damit Transparenz für datenbasierte Entscheidungen

- Du bringst dich proaktiv in Projekte ein und treibst die Weiterentwicklung der Controlling-Prozesse voran – insbesondere im Rahmen der bevorstehenden S/4HANA-Einführung

## Qualifikation

- Abgeschlossenes betriebswirtschaftliches Studium mit Schwerpunkt Controlling, Finanzen oder Rechnungswesen

- Mehrjährige Erfahrung im Controlling, idealerweise mit Fokus auf Produktions-Controlling

- Sichere SAP FICO-Kenntnisse sowie Erfahrung im Umgang mit ERP-Systemen

- Sehr gute MS-Office-Kenntnisse, insbesondere in Excel

- Ausgeprägte analytische und konzeptionelle Fähigkeiten sowie eine selbstständige, strukturierte Arbeitsweise

- Erfahrung mit SAP Analytics Cloud oder anderen BI-Tools ist ein Plus

## Benefits

- Flexible Arbeitszeiten für eine gute Work-Life-Balance

- Betriebsrestaurant direkt am Hamburger Standort

- Arbeitgeberzuschuss zum Deutschlandticket

- Vielfältige Betriebssportangebote

- Persönliche und fachliche Weiterbildungsmöglichkeiten

- Eigenverantwortliche Aufgaben mit echtem Entwicklungspotenzial

- Sicherheit und Perspektive in einem expandierenden, inhabergeführten Familienunternehmen

- Internationales Umfeld mit der Möglichkeit, sich global zu engagieren

- Dynamisches, motiviertes Team mit Freiraum für Eigeninitiative

Du willst deine Controlling-Expertise in einem global führenden Familienunternehmen einbringen und gemeinsam mit uns die Zukunft gestalten?

Dann bewirb dich jetzt direkt über den „Bewerben"-Button – **wir freuen uns auf dich!**

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
