# Product Designer (Experimentation) (f/m/d)

Posted: 2026-09-08T11:09:08Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**Your mission**

We're looking for a designer who decides with evidence. Most design roles stop at the handover. This one does not. You will design a part of the product, form a view about what should change, build the experiment that tests it, and read the results yourself. If you have ever shipped a redesign and never really found out whether it worked, this is the opposite of that.

You will sit inside one product delivery leadership team, working closely with the person accountable for that part of the business and with the engineers building it – not off to one side taking requests. And you will not be doing it alone: you join a group of Product Designers across the company who work the same way and hold each other's standards.

English is our working language. German matters here too: you will be designing flows that German-speaking neighbours read.

Concretely, you will:

-

**Design experiences that fit how people already live.** Our product mirrors real neighbourhood life. Your job is to design flows and screens that feel natural to someone standing on their doorstep with one hand on their phone, not to add features because we can.

-

**Frame the real problem before solving it.** Take a vague ask, find the actual question underneath it, and make it explainable. A well framed problem to solve is half the battle.

-

**Run the experiment, and read it honestly**. Design a testable change, get it instrumented properly, and analyse the outcome with our data team. That includes reporting the tests that did not work, which is most of them, and saying what you would do differently.

-

**Talk to neighbours.** Experiments tell you what happened, not what people needed. You will spend real time with the people who use this, because you cannot A/B test your way to understanding somebody.

-

**Direct AI, and spend your judgment where it counts.** AI produces a lot of our first-pass design. You will brief it, push back on it, and hold the quality bar, so your own hours go to the thinking a model cannot do. Polish goes where it changes behaviour, not onto every surface.

-

**Argue for cutting things.** Adding is easy. You will help decide what earns its place and what should be removed, and be willing to make the case for less.

**Your profile**

-

You practice design, and you are very comfortable with numbers. You might come from an analyst background and bring a love of design and design thinking, or vice versa.

-

You have technical know-how. You need to be able to construct the pipelines and dashboards yourself, use our experimentation platform, and our design system tooling.

-

You get your own numbers. Whether through SQL, AI-assisted querying, or both, you do not wait for someone else to pull data for you.

-

You have run experiments end to end. Hypothesis, design, instrumentation, analysis, decision. Not just handing a mockup to someone who tested it later.

-

You care about craft and are attentive to details. You can tell the difference between good enough and actually good and you design experiences people do not have to think about.

-

You use AI as a tool already or want to. This role allows you to have more control and impact through both design and analysis, but to do this well you'll need to leverage (and at times extend) our AI enablement stack.

-

You present your work clearly, defend your decisions when challenged, and are comfortable in front of a crowd.

-

Excellent English skills for working in our international team.

To apply, share a portfolio that shows your work by impact — at least one project walked through end to end: the hypothesis, what you designed, the result, and what you took from it. Show us how you used data to move your thinking forward, and where experimentation shaped what you built.

Nice to have

-

Experience with a marketplace, community, classifieds, or other network product.

-

Strong German, or the confidence to design in it with support.

-

Experience building or maintaining parts of a design system.

-

Comfortable writing SQL without AI assistance.

**What we offer**

-

Hybrid work model combining office and remote days

-

A meaningful job – we're creating a great product with real added value for the community

-

Work in a cheerful and experienced team that exchanges ideas and learns from each other

-

Insights into the entire work process of our social startup and the nebenan.de foundation

-

Responsibility and great opportunities to actively contribute

-

Your nebenan.de SpenditCard – you'll receive an additional income of 35 Euros per month, which you can use for things of your choice

-

30 days of vacation per year – we also offer the possibility of workation models and a sabbatical

-

A workplace in Berlin-Kreuzberg and regular events like yoga or Lunch & Learn sessions.

If we’ve captured your interest, apply now and let us know why you’re the perfect fit for the job!

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
