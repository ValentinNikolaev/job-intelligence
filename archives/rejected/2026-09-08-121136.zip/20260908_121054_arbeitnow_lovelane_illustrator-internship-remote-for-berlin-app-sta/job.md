# Illustrator Internship (remote) for Berlin App Start-up

Posted: 2026-09-08T09:00:57Z

## Rejection

- Category: tech_stack
- Reason: role does not mention Go/Golang or PHP

Work for an innovative app start-up that want to spread more love!

Our product

We want to bring more love into the world (and especially into relationships). Self-care was yesterday, couple-care is next! We created a game app for couples so that they can deepen their relationship while having a lot of fun.

Our vision is to become a platform for all couple-related topics.

Our app is called Soy & Mochi, check it out in both Appstores.

## Tasks

Create assets we will be using in the App:

- Create cute game and Avatar items to dress up our characters

- Optional: create animations of our Avatars

## Requirements

- You have experience creating cute illustrations

- Optional (not a must): Traditional animation experience

- You have worked with similar styles and should be able to work with our style (more like a Japanese kawaii cartoon style). Check out our gifs so far on Tenor (search account: soyandmochi or soynmochi)

- You are creative and have your own ideas (e.g. for how to illustrate for specific keywords)

## Benefits

- You get to gain first hand experience in a German start-up

- You can increase your portfolio and spread your work

As we are boostrapped, this is an **unpaid internship.**

Only applications with sample work will be considered.

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
