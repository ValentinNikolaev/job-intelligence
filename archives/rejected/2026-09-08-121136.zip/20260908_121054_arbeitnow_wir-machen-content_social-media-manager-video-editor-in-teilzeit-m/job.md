# Social Media Manager & Video Editor in Teilzeit (m/w/d) in München

Posted: 2026-09-08T10:01:29Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Du bist kreativ, organisiert, verstehst Social Media und hast ein gutes Gespür dafür, welche Inhalte Aufmerksamkeit erzeugen und Menschen erreichen?

Dann könnte diese Position genau zu dir passen.

Für unsere Content-Agentur **Wir machen Content** suchen wir eine Teilzeitkraft im Bereich **Social Media Management, Videoschnitt und Projektorganisation**.

Wir entwickeln und produzieren Social-Media-Content für Unternehmen und Marken aus ganz unterschiedlichen Branchen – unter anderem für **Gastronomie, Shoppingcenter, Beauty & Schönheitschirurgie, Kanzleien, Golfclubs, Architektur, Immobilien und weitere spannende Kundenprojekte**.

Dadurch ist dein Arbeitsalltag vielseitig und abwechslungsreich: Du arbeitest an unterschiedlichen Marken, begleitest Content-Projekte von der Organisation bis zur Umsetzung, schneidest Social-Media-Videos und bringst deine eigenen kreativen Ideen aktiv mit ein.

Wir suchen jemanden, der strukturiert arbeitet, Verantwortung übernimmt und Lust darauf hat, gemeinsam mit uns hochwertigen Social-Media-Content zu entwickeln und unsere Kundenprojekte zuverlässig mitzubetreuen.

## Aufgaben

Deine Hauptaufgaben

Ein großer Teil deiner Arbeit dreht sich um unsere Social-Media-Produktionen. Du wirst:

- **Reels, TikToks und Short-Form-Videos schneiden**

- Videomaterial nach unseren Drehs sichten, sortieren und den jeweiligen Projekten zuordnen

- Rohmaterial für den Schnitt vorbereiten

- Untertitel, Musik, Sounds und einfache Animationen einbauen

- unterschiedliche Schnittstile unserer Kunden kennenlernen und umsetzen

- Korrekturen und Kundenfeedback schnell einarbeiten

- fertige Videos kontrollieren und für die Veröffentlichung vorbereiten

- Kundenprojekte planen und koordinieren

- Deadlines und offene Aufgaben im Blick behalten

- Videodrehs organisatorisch vor- und nachbereiten

- Skripte, Dateien, Freigaben und Content organisieren

- mich bei der Kundenbetreuung unterstützen

Mein Ziel ist, dass du mit der Zeit immer mehr Verantwortung übernimmst und Projekte eigenständig organisieren kannst.

## Qualifikation

Für diese Stelle solltest du bereits **Erfahrung im Videoschnitt** haben und sicher mit Social-Media-Content umgehen können.

Wichtig ist mir nicht, wie viele Jahre Berufserfahrung du hast, sondern **wie gut dein Gefühl für Schnitt, Timing, Storytelling und Social Media ist**.

**Sehr gute Deutschkenntnisse in Wort und Schrift sind für diese Stelle zwingend erforderlich.**

Du solltest fließend Deutsch sprechen, grammatikalisch sicher schreiben und ein gutes Sprachgefühl haben. Das ist besonders wichtig, weil du Untertitel, Texte und Inhalte kontrollierst und teilweise auch direkt mit Kunden kommunizierst.

Du solltest außerdem:

- Reels, TikToks und Short-Form-Videos eigenständig schneiden können

- sicher mit einem Schnittprogramm wie CapCut, Premiere Pro oder vergleichbaren Programmen umgehen können

- **sicher mit Canva arbeiten können**

- Social-Media-Grafiken, einfache Präsentationen und Content-Assets in Canva erstellen und anpassen können

- ein gutes Gefühl für Hooks, Schnitttempo, Musik, Untertitel und Spannungsaufbau haben

- Social Media verstehen und Trends schnell erkennen

- sehr strukturiert und organisiert arbeiten

- mehrere Projekte und Deadlines gleichzeitig im Blick behalten können

- auch unter Zeitdruck ruhig, konzentriert und lösungsorientiert arbeiten

- schnell verstehen und Aufgaben zügig umsetzen

- Verantwortung übernehmen und selbstständig mitdenken

- professionell, freundlich und sicher mit Kunden kommunizieren

- zuverlässig sein und Aufgaben wirklich zu Ende bringen

**Damit du weißt, was dich erwartet**

Damit du dir schon vor deiner Bewerbung ein besseres Bild davon machen kannst, welche Art von Videos du bei uns schneiden wirst, haben wir dir hier **vier Beispielvideos** zusammengestellt.

Schau sie dir gerne vorab an und achte besonders auf Schnitt, Tempo, Untertitel, Musik, Hooks und den generellen Stil.

[https://www.instagram.com/reel/DcJXWXuHca9/?stkn=MW5pc2t6NGlrZXNxeg==](https://www.instagram.com/reel/DcJXWXuHca9/?stkn=MW5pc2t6NGlrZXNxeg==)

[https://www.instagram.com/reel/Da5P0z0NwIu/?stkn=MWVmaW81ZzZobHk2Nw==](https://www.instagram.com/reel/Da5P0z0NwIu/?stkn=MWVmaW81ZzZobHk2Nw==)

[https://www.instagram.com/reel/Dc78NVKqDrT/?stkn=MWZvZ2ljaXlhcjQxdw==](https://www.instagram.com/reel/Dc78NVKqDrT/?stkn=MWZvZ2ljaXlhcjQxdw==)

[https://www.instagram.com/reel/DcjO7F0KcS0/?stkn=MXVtemc2bmt5aHF0Mg==](https://www.instagram.com/reel/DcjO7F0KcS0/?stkn=MXVtemc2bmt5aHF0Mg==)

**P.S.: Unsere Videos schneiden wir überwiegend mit CapCut.** Wenn du bisher mit einem anderen Schnittprogramm gearbeitet hast, ist das kein Problem – CapCut ist intuitiv und du kannst dich in der Regel schnell einarbeiten.

## Benefits

Das bieten wir dir

- Einstiegsgehalt: 15 € brutto/Stunde mit Entwicklungsmöglichkeit nach erfolgreicher Einarbeitung und entsprechend übernommener Verantwortung Flexible Arbeitszeiten & gelegentliches Homeoffice

- Laptop & Arbeitshandy werden gestellt

- Abwechslungsreiche Social-Media-Projekte und spannende Kunden

- Kreativer Freiraum für deine eigenen Ideen

- Direkte Zusammenarbeit & kurze Entscheidungswege

- Entwicklungsmöglichkeiten und die Chance, schnell mehr Verantwortung zu übernehmen

- Teilnahme an Videodrehs und Produktionen

Bitte schick uns **kein perfektes KI-Anschreiben voller Standardfloskeln** – uns interessiert viel mehr, wer du bist und wie du arbeitest.

Erzähl uns lieber:

Wie motiviert bist du wirklich? Bist du zuverlässig und flexibel und auch mal bereit, früher anzufangen oder länger zu bleiben, wenn bei einem Projekt eine Deadline ansteht? **Natürlich wird jede geleistete Arbeitsstunde bezahlt.**

Bist du kreativ, lernst schnell und hast Lust, dich ständig weiterzuentwickeln? Kannst du gut mit Feedback und Kritik umgehen? Gerade im Agenturalltag gehören Korrekturschleifen dazu – unterschiedliche Kunden haben unterschiedliche Vorstellungen und manchmal müssen Änderungen auch kurzfristig und schnell umgesetzt werden. Dafür solltest du belastbar sein und auch unter Zeitdruck einen klaren Kopf behalten.

Und vor allem: **Zeig uns, was du kannst.**

Pack gerne ein paar Links zu Videos oder Social-Media-Projekten in deine Bewerbung, an denen du bereits gearbeitet hast. Du kannst uns auch ein kleines Portfolio oder ein kurzes Vorstellungsvideo schicken.

Wir brauchen keine perfekte Bewerbung. Wir möchten sehen, **wie du denkst, wie du arbeitest und ob du wirklich Lust auf diese Position hast.**

Nach einem erfolgreichen ersten Vorstellungsgespräch erhältst du zusätzlich eine praktische Aufgabe mit echtem Videomaterial. Dabei möchte ich sehen, wie du an einen Schnitt herangehst, wie schnell du arbeitest und wie gut du Vorgaben umsetzen kannst.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
