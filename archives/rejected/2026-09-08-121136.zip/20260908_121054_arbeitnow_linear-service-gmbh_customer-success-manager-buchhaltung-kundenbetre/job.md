# Customer Success Manager Buchhaltung & Kundenbetreuung (m/w/d)

Posted: 2026-09-08T09:00:57Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Die Linear Software GmbH entwickelt seit 35 Jahren Software für Vereinsverwaltung und Buchhaltung – für Vereine, Verbände und Schulen. Viele unserer Kunden begleiten wir seit über einem Jahrzehnt. Diese langjährigen Beziehungen und das Vertrauen, das daraus entstanden ist, sind das Fundament, auf dem wir weiter wachsen. Als Teil der CHAPTERS Group AG verbinden wir das Beste aus zwei Welten: die Nähe und kurzen Entscheidungswege eines mittelständischen Softwareunternehmens mit der Stabilität, dem Austausch und den Entwicklungsmöglichkeiten eines wachsenden Verbunds aus Softwareunternehmen.

Neben unserem Produkt für kleinere Vereine betreuen wir größere Vereine und Verbände mit einer individualisierbaren Softwarelösung, die eng an deren Anforderungen angepasst wird. Für diese anspruchsvollen Kunden suchen wir einen Customer Success Manager (m/w/d), der Buchhaltungs-Know-how, technische Affinität und einen exzellenten Kundenumgang verbindet – und Lust hat, Support-Prozesse mit KI aktiv neu zu denken.

Du bist die zentrale Ansprechperson für unsere größeren Bestandskunden: Du begleitest individuelle Umsetzungsprojekte von der Anforderung bis zur Auslieferung, stärkst die Nutzung unserer Software im Alltag der Kunden und bringst deren Feedback strukturiert in unsere Produktentwicklung ein. Du bist kein reiner Support-Agent, sondern Beziehungsgestalter und Wachstumstreiber – mit dem Ziel, dass sich unsere Kunden auch in zehn Jahren bestens betreut fühlen.

## Aufgaben

- **Kundenbetreuung:** Du bist die zentrale Ansprechperson für unsere größeren Vereine und Verbände – vom Tagesgeschäft über Rückfragen zur Buchhaltung bis zur Eskalation, die du souverän und lösungsorientiert moderierst.

- **Umsetzungsprojekte:** Du nimmst individuelle Anforderungen auf, übersetzt sie in klare Spezifikationen für unsere Entwicklung und begleitest die Umsetzung bis zur Auslieferung und Abnahme.

- **Onboarding:** Du führst neue Großkunden strukturiert ein und sorgst dafür, dass sie unsere Software von Anfang an vollständig nutzen.

- **Adoption & Nutzungstiefe:** Du erkennst, wo Kunden Potenzial liegen lassen, befähigst sie aktiv und machst aus zufriedenen Kunden langfristige Partner.

- **Problemanalyse:** Du analysierst und reproduzierst technische und fachliche Probleme – unterstützt durch KI-Tools – und löst sie gemeinsam mit unserem Entwicklungsteam.

- **Wissen & Dokumentation:** Du baust Knowledgebase und Dokumentation so auf, dass sie für Kunden verständlich und für KI-gestützte Workflows nutzbar sind.

- **Prozesse & KI:** Du hinterfragst bestehende Support-Prozesse, automatisierst Wiederkehrendes mit KI und reduzierst so das Ticketvolumen.

- **Stimme des Kunden:** Du sammelst Kundenfeedback strukturiert, priorisierst es und bringst es in unsere Produktentwicklung ein.

## Qualifikation

- **Kaufmännischer Hintergrund:** Kaufmännische Ausbildung oder Studium mit Bezug zu Buchhaltung/Rechnungswesen (z. B. Steuerfachangestellte/r, Bilanzbuchhalter/in, Bürokauffrau/-mann, BWL) und solide Buchhaltungsgrundkenntnisse. Vereinsbuchhaltung bringen wir dir bei.

- **Kundenerfahrung:** Erfahrung im direkten Kundenkontakt – etwa im Customer Success, Account Management, in der Kundenberatung oder in einer Steuerkanzlei mit engem Mandantenkontakt.

- **Kommunikationsstärke:** Du vermittelst komplexe buchhalterische und organisatorische Sachverhalte klar und verständlich – schriftlich wie im Gespräch – und bleibst auch in schwierigen Kundensituationen ruhig und lösungsorientiert.

- **Organisationsgeschick:** Du behältst bei mehreren parallelen Kundenprojekten den Überblick, priorisierst sauber und arbeitest strukturiert und zuverlässig.

- **Technische Affinität:** Du hast Freude an Software und digitalen Tools, arbeitest dich schnell in neue Systeme ein und nutzt KI-Tools selbstverständlich im Arbeitsalltag – oder willst das lernen. Programmierkenntnisse sind nicht erforderlich, aber du kannst technische Zusammenhänge nachvollziehen und mit Entwicklern auf Augenhöhe sprechen.

- **Datenorientiertes Arbeiten:** Du liest Ticket-Trends und Nutzungsdaten, erkennst Muster und leitest daraus Verbesserungen ab.

- **Haltung:** Echte Kundenorientierung statt reinem Support-Mindset – du willst Kunden weiterbringen, nicht nur Tickets schließen.

- **Sprache & Rechtliches:** Verhandlungssicheres Deutsch in Wort und Schrift sowie eine gültige Arbeitserlaubnis für Deutschland.

- **Nice-to-have:** Erfahrung mit Vereinsbuchhaltung oder mit Vereinen/Verbänden als Kunden.

## Benefits

- **Flexibilität:** Gut angebundenes Büro in Berlin Mitte; Homeoffice frei einteilbar.

- **Gestaltungsspielraum:** Kurze Entscheidungswege, direkter Draht zu Entwicklung und Geschäftsführung, echter Einfluss auf Produkt und Prozesse.

- **Entwicklung:** Weiterbildung und Austausch mit Kolleginnen und Kollegen aus anderen Softwareunternehmen der CHAPTERS Group.

- **Sicherheit:** Ein Arbeitgeber mit 35 Jahren Geschichte und einem langfristig orientierten Eigentümer.

- **Mobilität:** Wir übernehmen dein Deutschlandticket – für den Arbeitsweg und darüber hinaus.

- **Sport & Gesundheit:** Geförderte Mitgliedschaft im Urban Sports Club.

- **Mitarbeiterangebote:** Corporate Benefits über die CHAPTERS Group AG.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
