# (Senior) Paid Social Manager (w/m/d)

Posted: 2026-09-08T08:30:52Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**Du kommst aus dem Paid-Social-Umfeld einer Agentur und hast Erfahrung darin, Social-Ads-Strategien für unterschiedliche Kund:innen zu entwickeln und umzusetzen? Dann gestalte mit uns den Aufbau unseres Social-Marketing-Bereichs.** 🚀

## Aufgaben

Du baust den Bereich Paid Social aktiv mit auf und verbindest Business Development, Sales und Account Management in einer Rolle. Dein Ziel: Social Marketing als skalierbares Geschäftsfeld erfolgreich weiterentwickeln und Kund:innen langfristig erfolgreich machen.

**Dein Daily Business**

- Aufbau und Weiterentwicklung des Paid-Social-Bereichs

- Neukundengewinnung über Inbound, Outbound und Empfehlungen

- Entwicklung individueller Kampagnen- und Wachstumsstrategien basierend auf Kundenzielen

- Beratung und Durchführung von Sales-Gesprächen

- Entwicklung, Aufbau und Skalierung von Paid-Social-Kampagnen für unterschiedliche Kund:innen und Branchen

- Strategische Beratung von Kund:innen primär im Meta-Bereich

- Analyse und Optimierung von Kampagnen

- Identifikation von Upsell- und Cross-Sell-Potenzialen

- Zusammenarbeit mit Sales, CSM und Performance-Teams

## Qualifikation

Das macht dich aus

- Du hast nicht nur Social-Media-Kanäle betreut, sondern Paid-Social-Kampagnen entwickelt, aufgebaut und optimiert und verstehst, wie unterschiedliche Strategien auf verschiedene Geschäftsmodelle und Zielgruppen einzahlen

- Ausbildung oder Studium mit Bezug zu Online Marketing

- Mehrjährige praktische Erfahrung im Aufbau und Management von Paid-Social-Konten auf Agentur- oder Beratungsseit (Meta, weitere Plattformen von Vorteil)

- Erfahrung in der strategischen Beratung von Kund:innen und fachlicher Begleitung von Sales- oder Pitch-Prozessen

- Erfahrung in der Entwicklung und Steuerung von Kampagnen für mehrere Kund:innen gleichzeitig

- Unternehmerisches Denken und datengetriebene Arbeitsweise

- Sicheres Auftreten und starke Kommunikationsfähigkeiten

- Fließende Deutsch- und gute Englischkenntnisse in Wort und Schrift für die erfolgreiche Kommunikation mit Kolleg:innen und Kund:innen

- Nice to have: Erfahrung in der Personalführung und Begeisterung für digitale Produkte

## Benefits

Darauf kannst du dich freuen

- **Sicherer Hafen:** Unbefristeter Vertrag in einem innovativen Unternehmen

- **Flexibilität:** Home-Office-Option, flexible Arbeitszeiten und spannende Projekte

- **Weiterentwicklung:** Growth Journey, Fortbildungsbudget, 360°-Feedback und eine Fehlerkultur, in der Lernen wichtiger ist als Stillstand

- **Teamspirit:** Wertschätzung, flache Hierarchien und ein echtes Miteinander

- **Familienfreundlich:** Eltern-Kind-Büro und die Option, in Teilzeit zu arbeiten

- **Tierisch gut:** Bring deinen Hund mit in unser zentrales Office

- **Gesund und Fit:** Coachings, Mental Health Angebote, regelmäßige Gesundheitswochen und Urban Sports Vergünstigungen

- **On Track:** Zuschuss zum Deutschlandticket und ein Jobrad

- **Gemeinsame Erlebnisse:** Regelmäßige Teamevents, Firmenfeiern und kostenlose Snacks & Drinks

Das sind wir

Wir von **AdsXpress** sind Teil der Smarketer Group – DEM Netzwerk für spezialisierte Agenturen im Online Marketing. Mit uns holen Kund:innen mit kleinen und mittleren Budgets das Maximum heraus. Wir lieben Performance-Marketing, kurze Entscheidungswege und eine offene Teamkultur, in der jede Idee zählt.

*Bei uns zählt Talent, Motivation und Persönlichkeit – unabhängig von Geschlecht, Herkunft, Religion, sexueller Orientierung, Behinderung oder Alter. Vielfalt macht uns als Team stärker und erfolgreicher. Unsere Kultur lebt von Fokus, Partnerschaft und Leistungsdenken: wir arbeiten konzentriert an unseren Zielen, ziehen als Team an einem Strang und feiern Erfolge, wenn wir gemeinsam starke Ergebnisse erreichen. Bei uns sollst du nicht nur arbeiten, sondern dich wirklich wohlfühlen.* 🚀

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
