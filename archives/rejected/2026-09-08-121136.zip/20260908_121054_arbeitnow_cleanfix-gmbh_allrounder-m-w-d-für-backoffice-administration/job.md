# Allrounder (m/w/d) für Backoffice & Administration

Posted: 2026-09-08T08:00:38Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Du bist ein Organisationstalent, denkst gerne mit und fühlst dich in einem vielseitigen Aufgabenbereich wohler als in einer klassischen Sachbearbeitungsstelle?

Bei uns erwartet dich eine abwechslungsreiche Allroundposition: Du ergänzt unser bestehendes Innendienstteam, unterstützt bei kaufmännischen und administrativen Aufgaben, bereitest Informationen auf und sorgst dafür, dass offene Vorgänge und wichtige Dokumente nicht aus dem Blick geraten.

Cleanfix entwickelt und produziert seit über 50 Jahren professionelle Reinigungsmaschinen und innovative robotische Reinigungslösungen in Schweizer Qualität. An unserem Standort in Langenselbold arbeiten Vertrieb, Service, Werkstatt, Lager und Administration eng zusammen.

Die Position ist zunächst auf zwei Jahre befristet. Unser klares Ziel ist es jedoch, die Zusammenarbeit anschließend dauerhaft fortzusetzen.

## Aufgaben

- Du unterstützt unser bestehendes Innendienstteam im Tagesgeschäft.

- Du bearbeitest allgemeine kaufmännische und administrative Vorgänge und behältst offene Themen zuverlässig im Blick.

- Du erstellst und überarbeitest Kundeninformationen, interne Mitteilungen, Übersichten und weitere Unterlagen.

- Du bereitest Informationen für Kunden, Kollegen, interne Fachbereiche und die Niederlassungsleitung strukturiert und verständlich auf.

- Du verfolgst offene Angebote nach, dokumentierst den aktuellen Stand und unterstützt den Vertrieb bei der weiteren Bearbeitung.

- Du unterstützt bei der kaufmännischen und technischen Sachbearbeitung und koordinierst Informationen zwischen Kunden, Vertrieb, Service und Werkstatt.

- Du prüfst interne Dokumentationen auf Vollständigkeit und sorgst für deren strukturierte Ablage und Archivierung.

- Du unterstützt bei der Überwachung offener Posten und im Mahnwesen.

- Du erstellst bei Bedarf Auswertungen und Statistiken und bereitest die Ergebnisse übersichtlich auf.

- Du hilfst dabei, bestehende Abläufe, Dokumentationen und administrative Strukturen weiterzuentwickeln und zuverlässig einzuhalten.

- Du bist eine freundliche und verbindliche Ansprechperson für Kunden, Kollegen und interne Fachbereiche.

## Qualifikation

**Wir wünschen uns:**

- eine abgeschlossene kaufmännische Ausbildung

- idealerweise bereits Berufserfahrung in der kaufmännischen Sachbearbeitung, im Backoffice, Vertriebsinnendienst oder in einem ähnlich vielseitigen Aufgabenbereich

- gute Umgangsformen und Freude am Kundenkontakt

- Du arbeitest strukturiert, sorgfältig und zuverlässig und behältst auch bei unterschiedlichen Aufgaben und mehreren offenen Vorgängen den Überblick.

- Teamfähigkeit und eine ausgeprägte Kommunikationsfähigkeit

- Du gehst sicher mit den gängigen Microsoft-Office-Anwendungen um, insbesondere mit Word, Excel und Outlook.

- Erfahrung mit ERP- oder CRM-Systemen ist von Vorteil. Was dich erwartet

## Benefits

**Was Dich erwartet:**

- eine abwechslungsreiche und verantwortungsvolle Allroundposition

- eigenverantwortliches und selbstständiges Arbeiten mit viel Gestaltungsspielraum

- die Möglichkeit, Abläufe und Strukturen aktiv mitzuentwickeln

- eine sorgfältige Einarbeitung in unsere Aufgaben, Produkte und Systeme

- ein vielseitiges Arbeitsumfeld zwischen Administration, Vertrieb und technischem Service

- Einblicke in klassische Reinigungsmaschinen und innovative robotische Reinigungslösungen

- eine enge Zusammenarbeit mit unterschiedlichen Unternehmensbereichen

- ein kommunikatives und hilfsbereites Team

- moderne IT- und Telekommunikationsausstattung

- faire Vergütung und 30 Tage Urlaub

- betriebliche Altersvorsorge auf Wunsch

- eine zunächst auf zwei Jahre befristete Anstellung mit unserem klaren Ziel einer anschließenden langfristigen Zusammenarbeit

Du möchtest mitdenken, Verantwortung übernehmen und dafür sorgen, dass Informationen, Dokumente und offene Aufgaben zuverlässig bearbeitet werden?

Dann freuen wir uns darauf, dich kennenzulernen.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
