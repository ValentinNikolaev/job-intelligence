# Community & Social Media Manager (all genders) - Teilzeit (max. 32 Std./Woche)

Posted: 2026-09-08T07:00:43Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

## Daran solltest Du Freude haben

Du begeisterst Dich für Social Media, Content Creation und den Austausch mit Menschen? Dann werde Teil unseres Teams!

Als Community & Social Media Manager (all genders) hilfst Du dabei, die Sichtbarkeit unserer Marken in den sozialen Medien zu stärken und eine aktive Community aufzubauen. Du entwickelst und veröffentlichst Inhalte, moderierst Diskussionen, erkennst relevante Trends und Themen und sorgst dafür, dass unsere Kanäle nicht nur Inhalte ausspielen, sondern echte Interaktion und Austausch fördern.

Dabei übernimmst Du eine vielseitige, operative Rolle und arbeitest an der Schnittstelle von Social Media, Community Management und digitalem Marketing.

- Du erstellst, bearbeitest und veröffentlichst ansprechende Inhalte für unsere Social-Media-Kanäle, darunter Texte, Karussell-Posts, Kurzvideos und visuelle Inhalte.

- Du verwandelst bestehende Inhalte wie Fotos, Videos, Interviews, Artikel und Podcasts in kreative, Social-Media-taugliche Formate.

- Du interagierst aktiv mit unserer Community, Partnern und relevanten Branchenkontakten und trägst so zum Wachstum unserer Reichweite bei.

- Du analysierst die Performance unserer Kanäle und erkennst, welche Themen und Content-Formate unsere Zielgruppen besonders begeistern.

- Du unterstützt die Kommunikation rund um Events, Partnerschaften, Kampagnen und weitere Marketingaktivitäten.

- Du koordinierst und verantwortest den monatlichen Newsletter-Versand

## Das bringst Du mit

- Du bringst erste relevante Erfahrung im Bereich Social Media, Community Management, Content Marketing oder Digital Marketing mit. Auch Praktika, Werkstudententätigkeiten oder Freelancer-Projekte zählen für uns.

- Du weißt, wie LinkedIn und Instagram funktionieren, kennst die Unterschiede der Plattformen und verstehst, wie Unternehmen dort nachhaltige Reichweite und eine aktive Community aufbauen können.

- Du hast ein gutes Gespür für Storytelling, prägnante Texte und Social-Media-Kommunikation.

- Du verfügst über ein ausgeprägtes visuelles Verständnis und arbeitest sorgfältig und detailorientiert.

- Du kommunizierst fließend auf Englisch und fühlst Dich auch in der deutschen Kommunikation sicher.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
