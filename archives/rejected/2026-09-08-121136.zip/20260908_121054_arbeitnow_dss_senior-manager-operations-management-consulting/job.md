# Senior Manager – Operations Management Consulting- DACH

Posted: 2026-09-08T08:30:05Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**About dss+**

At dss+, you don’t just deliver projects - you help save lives, improve performance, and build a more sustainable future.

We are a purpose-led global consultancy partnering with organisations in high-risk and asset-intensive industries to solve complex operational challenges across safety, operational excellence, and sustainability.

With a heritage rooted in DuPont’s industrial operations, we combine deep expertise, practical problem-solving, and digital innovation to deliver measurable and lasting impact for our clients.

**Why This Role**

This role sits at the centre of delivering large-scale transformation programmes across the DACH region, with a strong focus on Operational Risk (ORM).

You will work with leading organisations to strengthen risk management capabilities, improve operational performance, and build resilience across complex and high-risk operating environments. Partnering closely with senior client stakeholders, you will help organisations embed effective risk-based decision making and sustainable operational practices.

As a Senior Manager, you will play a key role in leading client engagements, developing high-performing teams, and supporting the continued growth of our Operational Risk Management practice across the region.

**Why This Practice – Operational Risk Management (ORM)**

In a complex and fast-changing environment, organisations must manage risk effectively to protect people, assets, and performance.

At dss+, we help clients embed risk-based decision making across their operations by integrating processes, technology, and culture to improve resilience. This enables safer, more productive operations while unlocking greater value.

**Your Impact at dss+**

You will lead the delivery of transformation programmes, partnering with clients to solve complex operational and organisational challenges. You will oversee teams, manage delivery quality, and support clients in achieving sustainable improvements across safety, operational performance, and operational risk management.

**Key Responsibilities**

-

Lead consulting teams and manage delivery across multiple project workstreams

-

Build strong client relationships and act as a trusted advisor throughout engagements

-

Assess operational risks and identify opportunities to improve organisational resilience and performance

-

Design and implement Operational Risk Management frameworks, systems, and improvement programmes

-

Facilitate executive workshops, assessments, and stakeholder engagements

-

Oversee project execution, ensuring quality, impact, and timely delivery

-

Coach and develop consulting teams, building capability and high performance

-

Support account growth through proposal development and client engagement

-

Contribute to business development and the continued expansion of the ORM practice across the DACH region

**What You'll Experience at dss+**

**Deliver on Our Purpose**

Be part of a values-led organisation where your work helps save lives, improve performance, and advance sustainability for our clients and their people.

**Develop Your Trusted Expertise**

Gain autonomy and accountability, working closely with senior clients on complex, high-impact challenges.

**Thrive in a Culture of Respect**

Join an inclusive and collaborative environment where your voice is valued, your curiosity is encouraged, and your wellbeing is supported.

**Shape Your Career**

Accelerate your development through hands-on leadership experience, structured learning, and opportunities to work on international projects.

**Who You Are**

You bring strong analytical thinking, a strategic mindset, and the ability to operate effectively in diverse, international environments. You are comfortable engaging senior stakeholders, leading teams, and driving meaningful improvements in operational risk, safety, and organisational performance.

**Experience**

-

Significant experience in management consulting, ideally Operational Risk Management, Operational Excellence or operational leadership roles

-

Proven track record leading complex consulting engagements and managing teams

-

Experience implementing operational risk, safety, governance, or resilience programmes

-

Experience working within asset-intensive industries such as energy, chemicals, manufacturing, mining, infrastructure, or utilities

-

Strong experience developing and managing senior client relationships

**Capabilities**

-

Strong leadership and stakeholder management capability

-

Deep understanding of Operational Risk Management principles and risk-based decision making

-

Ability to manage multiple workstreams and project teams simultaneously

-

Strong commercial awareness and problem-solving capability

-

Excellent communication, facilitation, and relationship-building skills

-

Ability to influence decision-making at senior leadership and executive levels

**Education & Languages**

-

Bachelor's or Master's degree in Engineering, Business, Risk Management, or a related field

-

Fluency in English and German at C1 level

**Mobility**

-

Willingness to travel across the DACH region and internationally as required

**Growth & Benefits**

We invest in your development and success through:

-

Structured learning and development, including our Consulting Development Academy

-

Mentorship from experienced leaders and industry experts

-

Opportunities to contribute to international projects

-

Competitive salary, performance-based incentives, and comprehensive benefits

-

Flexible working policies

**A Bit More About Us**

We are implementers and change-makers. Our teams work from the boardroom to the shop floor, helping organisations build resilience, improve performance, and sustain results over time.

Our expertise spans industries including metals and mining, energy, chemicals, manufacturing, and private equity — combining deep operational knowledge with transformation and capability-building expertise.

**Diversity & Inclusion**

dss+ is committed to building a diverse workforce and fostering an inclusive culture where everyone is respected, valued, and able to contribute fully.

We believe diversity strengthens our organisation and drives better outcomes for our people, our clients, and the communities we serve.

**Ready to Make an Impact?**

If you're passionate about helping organisations strengthen resilience, improve operational performance, and embed world-class Operational Risk Management practices, we'd love to hear from you.

** **

**Apply today and join dss+ in delivering lasting impact across the DACH region.**

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
