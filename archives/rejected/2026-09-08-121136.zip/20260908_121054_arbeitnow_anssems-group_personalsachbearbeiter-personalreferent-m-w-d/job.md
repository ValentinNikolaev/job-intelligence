# Personalsachbearbeiter / Personalreferent (m/w/d)

Posted: 2026-09-08T09:00:56Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Dein Platz, um Verantwortung zu übernehmen und unsere Personalarbeit mitzugestalten!

Du arbeitest gerne strukturiert, behältst auch bei vielen unterschiedlichen Personalthemen den Überblick und hast Lust, moderne HR-Prozesse aktiv mitzugestalten?

Dann bist du bei uns genau richtig!

**[Anssems.com](http://Anssems.com)** **– Der Fachmarkt für PKW-Anhänger.**

Mit 12 deutschlandweiten Fachmärkten, modernen Showrooms, gut sortierten Lagern und eigenen Serviceabteilungen bieten wir unseren Kunden ein einzigartiges Einkaufserlebnis. Als Teil der Anssems-Gruppe mit rund 180 Mitarbeitenden und über 45 Jahren Erfahrung stehen wir für Qualität, Wachstum und Innovation.

Zur Verstärkung unseres Teams in Bad Bentheim suchen wir einen **Personalsachbearbeiter / Personalreferenten (m/w/d)**, der uns insbesondere in der operativen Personalarbeit unterstützt.

Deine Aufgaben

***Personaladministration***

Du unterstützt uns bei allen administrativen Themen entlang des gesamten Mitarbeiterlebenszyklus – vom Eintritt bis zum Austritt.

Dazu gehören insbesondere:

- Erstellung und Vorbereitung von Arbeitsverträgen, Vertragsänderungen und Zusatzvereinbarungen

- Erstellung und Verwaltung von Bescheinigungen, Arbeitszeugnissen und weiteren personalrelevanten Dokumenten

- Pflege von Personalstammdaten und digitalen Personalakten

- Verwaltung und Nachverfolgung von personalrelevanten Dokumenten und Fristen

- Administrative Begleitung von Eintritten, Veränderungen und Austritten

- Unterstützung bei allgemeinen arbeitsvertraglichen und personaladministrativen Fragestellungen

- Ansprechpartner für Mitarbeitende und Führungskräfte bei administrativen Personalthemen

***Lohn- & Gehaltsabrechnung***

Auch rund um unsere monatliche Lohn- und Gehaltsabrechnung übernimmst du wichtige vorbereitende und unterstützende Aufgaben:

- Vorbereitung und Unterstützung der monatlichen Lohn- und Gehaltsabrechnung

- Pflege von Stamm- und Bewegungsdaten

- Aufbereitung von Informationen zu Arbeitszeiten, Urlaub, Krankheit und sonstigen Abwesenheiten

- Zusammenstellung und Weitergabe aller notwendigen Informationen für die Abrechnung

- Unterstützung bei Rückfragen von Mitarbeitenden rund um ihre Abrechnung

- Zusammenarbeit mit den internen und externen Ansprechpartnern im Rahmen der Entgeltabrechnung

***Einführung unseres neuen HR-Systems***

Du hast Lust, nicht nur bestehende Prozesse zu verwalten, sondern unsere Personalarbeit aktiv mitzugestalten?

Aktuell führen wir mit **Factorial ein neues HR-System** ein, über das wir unsere Personalprozesse zukünftig zentral und digital abbilden möchten.

Dabei kannst du von Anfang an mitwirken:

- Du unterstützt uns bei der Einführung und dem Aufbau unseres neuen HR-Systems Factorial

- Gemeinsam mit uns überführst du bestehende Personalprozesse in eine moderne, digitale Struktur

- Du hilfst dabei, Personalstammdaten, Dokumente und digitale Personalakten sauber aufzubauen und zu pflegen

- Du unterstützt uns dabei, Prozesse rund um Arbeitszeiten, Abwesenheiten, Dokumente und Mitarbeiterdaten sinnvoll im System abzubilden

- Du bringst eigene Ideen ein, wie wir unsere täglichen HR-Prozesse einfacher und effizienter gestalten können

- Nach der Einführung arbeitest du regelmäßig mit Factorial und entwickelst die Nutzung des Systems gemeinsam mit uns weiter

**Wichtig:** ***Vorkenntnisse in Factorial sind nicht erforderlich.*** Entscheidend ist für uns, dass du Interesse an digitalen HR-Prozessen hast, dich gerne in neue Software einarbeitest und Lust darauf hast, das System gemeinsam mit uns aufzubauen und mitzugestalten.

***Recruiting & Bewerbermanagement***

Auch bei der Gewinnung neuer Kolleginnen und Kollegen unterstützt du uns weiterhin:

- Erstellung und Veröffentlichung von Stellenausschreibungen

- Sichtung und Vorauswahl eingehender Bewerbungen

- Kommunikation mit Bewerberinnen und Bewerbern

- Koordination von Vorstellungsgesprächen

- Unterstützung bei der Organisation des Onboardings neuer Mitarbeitender

Der Schwerpunkt deiner Position liegt jedoch klar auf der **operativen Personalarbeit und Personaladministration**.

Das bringst du mit

- Eine abgeschlossene kaufmännische Ausbildung, idealerweise mit Bezug zum Personalwesen, oder eine vergleichbare Qualifikation

- Idealerweise erste Berufserfahrung in der Personalsachbearbeitung, Personaladministration oder einer vergleichbaren HR-Position

- Erfahrung mit der Erstellung und Bearbeitung von Personaldokumenten ist von Vorteil

- Du arbeitest sorgfältig, strukturiert und zuverlässig und behältst auch bei mehreren parallelen Themen den Überblick

- Der vertrauensvolle Umgang mit sensiblen Mitarbeiter- und Personaldaten ist für dich selbstverständlich

- Du arbeitest gerne digital und hast Interesse daran, Prozesse zu verbessern und weiterzuentwickeln

- Du hast keine Scheu davor, dich in neue Programme und Systeme einzuarbeiten

- Du kommunizierst freundlich und professionell mit Mitarbeitenden, Führungskräften und Bewerbern

- Du arbeitest gerne eigenverantwortlich, bist gleichzeitig aber auch ein Teamplayer

- Gute Kenntnisse in MS Office runden dein Profil ab

**Das bieten wir dir**

Mitgestalten statt nur verwalten

Bei uns übernimmst du nicht einfach bestehende Abläufe, sondern kannst unsere zukünftige Personalarbeit aktiv mitgestalten. Mit der Einführung von Factorial schaffen wir aktuell die Grundlage für eine moderne und digitale HR-Organisation – und du kannst von Anfang an dabei sein.

Darüber hinaus erwarten dich:

- Eine abwechslungsreiche Position mit Einblick in nahezu alle Bereiche der operativen Personalarbeit

- Die Möglichkeit, eigene Ideen einzubringen und HR-Prozesse aktiv weiterzuentwickeln

- Ein wachsendes Unternehmen mit kurzen Entscheidungswegen

- Direkter Austausch mit Führungskräften und Geschäftsleitung

- Eine moderne und zunehmend digitalisierte Arbeitsweise

- Eine strukturierte Einarbeitung in deine Aufgaben und unser neues HR-System

- Ein sicherer Arbeitsplatz in einem etablierten, international tätigen Familienunternehmen

- Moderne Arbeitsumgebung

- Kostenlose Getränke und Parkmöglichkeiten

Klingt nach dir?

Dann freuen wir uns darauf, dich kennenzulernen!

Sende uns einfach deine vollständigen Bewerbungsunterlagen und teile uns gerne deinen frühestmöglichen Eintrittstermin sowie deine Gehaltsvorstellung mit.

**[Anssems.com](http://Anssems.com)** **Deutschland GmbH**

Wiener Straße 34

48455 Bad Bentheim

**Der Fachmarkt für PKW-Anhänger – 12× in Deutschland**

**Art der Stelle:** Vollzeit, Festanstellung

**Arbeitsort:** 48455 Bad Bentheim

Gehalt: 3.000,00€ - 3.500,00€ pro Monat

Arbeitsort: Vor Ort

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
