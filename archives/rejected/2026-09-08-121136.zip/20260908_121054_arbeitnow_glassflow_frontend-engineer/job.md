# Frontend Engineer

Posted: 2026-09-08T07:30:29Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**About GlassFlow:**

GlassFlow is the data infrastructure for AI agents in production. It has two products: GlassFlow Tares, which feeds agents correlated data from every system they touch, and GlassFlow Rius, which traces and debugs what agents do once they're running.

We’re a Berlin startup with a Silicon Valley mentality, backed with $5.9m from Upfront Ventures, the CEO of GitHub, the ex-CTO of Aiven, and more world-class investors.

The founders are serial entrepreneurs with more +10y of experience in building and selling data products.

## Tasks

**Your Role**

As one of the first engineers, you'll get to lay the tech foundations of GlassFlow. As a frontend engineer, you will design and implement our web applications in close collaboration Backend Team, and CTO. You will join a small team solving challenging problems in the field of Data engineering and building a product that will be used by developers across the world.

## Requirements

**Previous experience that could be helpful:**

- Fluent in TypeScript and frontend frameworks like React or similar

- Experience with public or private clouds (AWS / GCP / Azure)

- Experience with DevOps (Kubernetes, Docker, GitHub Actions)

- Worked in fast-growing environments or early-stage startups

## Benefits

**What you’ll get**

- Real ownership: competitive equity (everyone at GlassFlow is an owner).

- The chance to build something that changes how the world streams data.

- The opportunity to build for global tech brands from day one.

- A career trajectory that will 10x your skills and network.

**Benefits:**

- Competitive salary with Stock Option Grant

- Ticket for public transportation in Berlin

- Company credit card with a monthly allowance

- Newest tech of your choosing

- Annual Learning budget for personal development

- Generous WFH policy and a budget for home office setup

GlassFlow is an equal opportunity employer that values diversity in the workplace. We encourage applications from all qualified individuals, including those with diverse backgrounds and disabilities.

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
