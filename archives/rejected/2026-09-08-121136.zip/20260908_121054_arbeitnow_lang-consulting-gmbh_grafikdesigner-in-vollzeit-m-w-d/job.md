# Grafikdesigner/- in Vollzeit (m/w/d)

Posted: 2026-09-08T07:30:31Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Wir suchen neue Mitarbeiter (m/w/d) für den Bereich Grafikdesign, um angepasste Logos und Bilder zu kreieren und zu bearbeiten. Du wirst bei der Einarbeitung exklusives Fachwissen in den Bereichen Content Design und Medienbearbeitung erhalten. Um mit diesen Arbeitsprozessen im Grafikdesign arbeiten zu können, brauchst du bereits bestehende Vorkenntnisse.

## Aufgaben

Deine Aufgabenbereiche:

Als Teil des Social Media Teams kreierst du zielgruppengerechten Content für alle unsere Kommunikationskanäle, online wie offline.

- Du orientierst dich dabei an unserem Corporate Design und bringst deine Kreativität ein, um bei der Entwicklung neuer Kampagnen mitzuwirken.

- Erstellung von Social Media Design und Website, Design, Banner, Broschüren und vieles mehr.

## Qualifikation

Stellenanforderungen:

Abgeschlossene Berufsausbildung ist wünschenswert, jedoch nicht erforderlich.

- Schnelle Lernfähigkeit, ein hohes Maß an Disziplin, Kreativität und Eigeninitiative.

- Aktiver Umgang mit Leistungsdruck und Einhaltung von Fristen.

- Gutes Deutsch und Englisch in Form und Sprache.

- Gute technische Fähigkeiten.

- Erfahrung mit Photoshop, Indesign und Illustrator.

- Mindestens 2 Jahre Erfahrung im Bereich Grafikdesign.

## Benefits

Wir bieten:

Sicheres Arbeitsverhältnis: Unser Ziel ist es, mit unseren Mitarbeitern langfristig gemeinsam zu wachsen. Das Ziel jeder Einstellung ist eine unbefristete Übernahme.

- Faire Vergütung: Bei uns beginnst du mit einem Startgehalt von 40.000 € pro Jahr.

- Verantwortung eigener Bereiche: Alle Kolleginnen und Kollegen übernehmen Verantwortung für die Erfolge in ihrer Abteilung. Du wirst von uns speziell für deine Aufgaben von einem Experten aus unserem Team persönlich ausgebildet.

- Tolle Arbeitsatmosphäre: Das kollegiale Verhältnis sowie der Respekt und das Vertrauen untereinander ist uns sehr wichtig. Wir motivieren uns gegenseitig Bestleistungen zu erzielen und persönlich zu wachsen.

- Ein tolles Angebot zusätzlicher Leistungen: Bei uns kommst Du in den Genuss von Zusatzleistungen wie eine betriebliche Altersvorsorge, ein Dienstfahrrad oder eine Hansefit Mitgliedschaft.

- Verpflegung: Auswahl von unternehmenseigener Mittagsgerichte durch Apetito, einen Obstkorb mit saisonalem Obst, kostenloser Wasserspender sowie eine kostenlose Kaffeeauswahl z. B. Cappuccino, Latte Macchiato u. v. m.

- Equipment: Auswahl deines Arbeits-Equipments (MacBook sowie einen höhenverstellbaren Schreibtisch).

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
