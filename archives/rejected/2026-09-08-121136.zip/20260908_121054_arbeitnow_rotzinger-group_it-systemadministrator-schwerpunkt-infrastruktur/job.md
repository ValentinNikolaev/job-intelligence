# IT-Systemadministrator – Schwerpunkt Infrastruktur (m/w/x)

Posted: 2026-09-08T07:20:43Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Zur Verstärkung unseres IT-Teams suchen wir einen engagierten 2nd Level Support Specialist mit Schwerpunkt IT-Infrastruktur. In dieser Rolle übernehmen Sie Verantwortung für den stabilen Betrieb unserer Systemlandschaft und wirken aktiv an deren Weiterentwicklung mit.

**Ihre Aufgaben:**

• Bearbeitung und Lösung von 2nd-Level-Tickets im Infrastruktur-Umfeld

• Analyse, Priorisierung und nachhaltige Behebung komplexer Störungen

• Betrieb, Administration und kontinuierliche Optimierung der IT-Systeme

• Mitarbeit bei Rollouts, Changes sowie IT-Projekten

• Unterstützung bei der Weiterentwicklung unserer IT-Sicherheits- und Infrastrukturstandards

**Ihre fachliche Expertise & Systemkompetenz**

Sie verfügen über fundierte Kenntnisse und Erfahrungen in mehreren der folgenden Bereiche:

• Security & Monitoring: Darktrace (E-Mail), Sophos Firewall & Central, Microsoft Defender, PRTG

• Microsoft / O365 / Azure: Exchange Administration (User, Shared Mailboxes, Verteiler, Ressourcen, Rules, Connectors), O365 Hybrid-Umgebung, MFA, SharePoint, Teams, OneDrive, Azure / Entra

• Server & Virtualisierung: Windows Server, VMware vSphere / ESX, VDI, Veeam Backup, WSUS, Printserver

• Netzwerk & Infrastruktur: VLAN, Switching, DMZ, Active Directory, GPO, DHCP, DNS, GestioIP

• Clients & Systeme: Parallels RAS, Baramundi (inkl. Paketierung), OTRS, LinOTP, Linux

• Datenbanken & Automatisierung: SQL Server (Installation & Troubleshooting), PowerShell-Scripting

• Hardware: Betrieb, Verwaltung und Inventarisierung

**Ihr Profil:**

• Abgeschlossene Ausbildung im IT-Umfeld (z. B. Fachinformatiker: in Systemintegration)

oder eine vergleichbare Qualifikation durch Berufserfahrung

• Quereinsteiger: innen mit nachweisbarem Interesse und praktischer Erfahrung im Bereich IT-Infrastruktur / IT-Support sind ausdrücklich willkommen

• Erste bis mehrjährige Erfahrung im IT-Support (1st/2nd Level) oder im Betrieb von IT-Infrastrukturen von Vorteil

• Fundierte Kenntnisse in mindestens mehreren der genannten Technologien

• Strukturierte, analytische und lösungsorientierte Arbeitsweise

• Teamfähigkeit, Eigeninitiative und Verantwortungsbewusstsein

**Was erwartet Sie bei der Hansella GmbH in Viersen?**

-

Erfahrenes und motiviertes Team, das gemeinsam die nachhaltige Geschäftsentwicklung vorantreibt

-

Freiraum zur eigenständigen Gestaltung der Aufgaben mit offenem Ohr für Veränderungen und Weiterentwicklungen

-

Wir unterstützen aktiv Weiterbildungen und legen großen Wert darauf

-

Kurze Entscheidungswege in einer dynamischen mittelständischen Unternehmenskultur

-

Werteorientiertes Familienunternehmen mit globaler Marktausrichtung

-

Flexibilität durch Home Office und flexible Arbeitszeitgestaltung

-

Attraktives Gesamtpaket mit 30 Tagen Urlaub, betrieblicher Altersvorsorge sowie Urlaubs- und Weihnachtsgeld

-

Corporate Benefits & Job Rad

-

Ausreichende Parkmöglichkeiten bzw. kurzer Weg zu einer S-Bahn Haltestelle

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
