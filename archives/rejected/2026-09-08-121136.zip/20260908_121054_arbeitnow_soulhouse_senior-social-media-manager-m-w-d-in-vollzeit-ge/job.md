# Senior Social Media Manager (m/w/d) in Vollzeit gesucht

Posted: 2026-09-08T08:20:14Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**Senior Social Media Manager (m/w/d) für Selfcare Company in Vollzeit gesucht**

**Standort: Hamburg**

**Über Soulhouse**

Soulhouse ist ein schnell wachsendes Self-Care Scale-up mit der Mission, die #1 für Modern Bodywork in Europa zu werden. Wir bieten Premium Massagen, Assisted Stretching und Facework in stilvollen Studios und helfen monatlich tausenden Menschen, sich rundum wohlzufühlen.

In den nächsten Jahren folgen über 100 weitere Standorte in Europa. Neben unseren Studios wächst auch unser E-Commerce mit eigenen Self-Care-Produkten stark weiter.

### Deine Rolle

Du bist das kreative Herzstück des Soulhouse Social Media Auftritts — und gleichzeitig der methodische Kopf dahinter. Du schneidest Videos, die funktionieren. Du denkst in Formaten, die viral gehen. Du weißt, wie man aus einem Opening, einem Treatment oder einem Wellbeing-Gedanken einen Moment macht, der bleibt.

Du verantwortest nicht nur den täglichen Content — du bist die Person, die das Social Playbook lebt, weiterentwickelt und dafür sorgt, dass alle Standards des Kanals gehalten werden. Was im Playbook steht, kommt durch dich zum Leben.

Und du bist AI-first: gemeinsam mit unserem Tech-Team baust du die Workflows, die Content-Produktion skalierbar machen — von der Trendanalyse bis zur Asset-Auslieferung. Das ist kein Bonus, das ist Teil der Rolle.

### Deine Kernaufgaben

**Creative Excellence:** Konzeption und Produktion von Social Content auf Execution-Niveau: Reels, responsive Ads, virale Formate, Video-Cuts, Carousels, Statics. Du weißt, was auf Instagram und TikTok funktioniert — und kannst es selbst umsetzen.

**Outlet-Verantwortung & Playbook:** Du betreust den Soulhouse Social-Kanal vollständig: Redaktionsplanung, Qualitätssicherung, Markenhygiene. Du verantwortest die Einhaltung und Weiterentwicklung des Social Playbooks — die Standards des Kanals liegen bei dir.

**Kampagnen- & Event-Steuerung:** Eigenverantwortliche Steuerung von Social-Kampagnen und Brand-Momenten — von der Konzeption bis zur Auswertung. Steuerung von Freelancern und externen Dienstleistern.

**AI-First Social Studio:** Mitaufbau und Betrieb eines AI-gestützten Content-Workflows: Trendanalyse, Themenübersetzung in Soulhouse-Sprache, Canva-Integration, Asset-Auslieferung. In enger Abstimmung mit dem Tech-Team.

**Third-Party Content & Community: **Konzeption von Gastformaten, Experten-Kollaborationen und externen Stimmen.

**Requirements**

### Das bringst du mit

**Berufserfahrung:** 4–7 Jahre im Social Media Management oder Content-Bereich, idealerweise mit Brand- oder Agentur-Erfahrung.

**Creative Excellence:** Du schneidest Videos, entwickelst Formate, denkst in Trends — und hast ein Portfolio, das das zeigt. Responsive Ads, Reels, viraler Content sind keine Fremdwörter.

**Playbook- & Prozessdenken:** Du kannst Standards operationalisieren, dokumentieren und kontinuierlich weiterentwickeln. Eigene Systeme und SOPs hast du schon aufgebaut.

**Kampagnenstärke:** Du hast Social-Kampagnen eigenverantwortlich gesteuert — von der Konzeption bis zur Freelancer-Koordination.

**AI-first Mindset:** Du nutzt KI-Tools nicht nur für Texte — du denkst in Workflows und Automatisierungen. Du kannst Konzepte wie Content-Agenten intellektuell durchdringen und mitentwickeln.

**Marken- & Plattformverständnis:** Du weißt, wie eine Premium Wellbeing-Marke klingt und wirkt — auf Instagram, TikTok und darüber hinaus.

**Tools:** CapCut, Captions, Canva, Asana, Confluence, Claude und weitere AI-Tools sind dein Daily Business.

**Sprache:** Fließend Deutsch und Englisch — schriftlich stark und präzise in beiden Sprachen. Du schreibst Captions, Ad-Texte und Campaign-Copy auf Premium-Niveau.

**Gut dazu:** Erfahrung mit Marken aus dem Selfcare-Bereich und/oder FMCG-Bereich, Erfahrung mit Creator-Kollaborationen und Community-Formaten.

**Benefits**

### Das bieten wir dir

**Vergütung:** 52.000 € Fixgehalt p.a. plus bis zu 6.000 € variable Vergütung auf Basis messbarer Ziele.

**Scope:** Echter Gestaltungsspielraum an einer wachsenden europäischen Marke — du baust mit uns das Social Studio der Zukunft.

**Europäischer Wachstum:** Deine Arbeit bespielt Studios in DE, AT, ES und weiteren Märkten — mit Blick auf 100+ Standorte bis 2030.

**AI-First Culture:** Ein Team, das moderne Systeme und AI-Tools konsequent in den Arbeitsalltag integriert.

**Direkter Zugang:** Enge Zusammenarbeit mit Head of Brand, C-Level & Founders, kurze Entscheidungswege.

**Mobilität & Lifestyle:** Wahlweise Deutschlandticket, Urban Sports Club-Mitgliedschaft oder monatliche Shopping-Gutscheine.

**Zusätzliche Vorteile:** Monatliche Soulhouse-Gutscheine, Bike-Leasing-Angebot sowie exklusive Mitarbeiterkonditionen auf weitere Leistungen.

**Umzugsunterstützung:** Soulhouse bezuschusst deinen Umzug, wenn du für die Position in eine andere Stadt ziehst.

**Flexibilität:** Hybrides Arbeiten aus Hamburg mit Flexibilität.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
