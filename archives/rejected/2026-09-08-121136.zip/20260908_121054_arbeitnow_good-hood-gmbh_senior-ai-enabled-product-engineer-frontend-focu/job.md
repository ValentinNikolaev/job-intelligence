# Senior AI Enabled Product Engineer — Frontend Focus (f/m/d)

Posted: 2026-09-08T11:09:08Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**Your mission**

You will own the part of nebenan.de that neighbors actually see and touch. This is a frontend-focused role on a full-stack product team: your depth is in the browser and on mobile web, and you follow a feature all the way through the API and into production. You will work with React and TypeScript on the frontend. Ruby on Rails on the backend, PostgreSQL, and AWS.

Concretely, you will:

**Own your product area****
**

-

Own a product area end to end. From prototype through production to iteration, mobile-first. You decide from usage data what to improve next and keep the area healthy on an ongoing basis.

-

Run what you build. Set and meet performance and reliability targets for your area, instrument before shipping, and handle incidents in your own work.

-

Challenge the plan. You work with a product lead who owns the outcome and a product analyst who designs and validates experiments. If a piece of work won't move the metric it's meant to move, say so early.

**Build the interface**

-

Build React features are accessible, fast, and consistent with our design system.

-

Own and extend the design system. Components, tokens, and patterns that other engineers reuse. You push generic work into shared components early.

-

Work across the client–server boundary. Shape the APIs your screens depend on; make deliberate choices about data fetching, caching, loading, and error states; and understand what's happening on the network.

**Work with AI and evidence**

-

Direct AI and be accountable for what it writes. You set intent, review what comes back, and own everything that ships under your name.

-

Replace manual QA with evidence. Automated tests, visual regression, and instrumentation ground your confidence in data.

**What this role is not**

-

Not a ticket taker. You own working software in production, not merged pull requests.

-

Not pixel-pushing behind a designer. Design and validation of the experience sit with product and design; building it into production software and pushing back on it are yours.

-

Not frontend-only in practice. Depth in the frontend, contribution across the stack.

**Your profile**

-

Strong React in production: component design, state management, rendering behaviour

-

A real grasp of client–server architecture: how the browser and the backend actually talk, what that costs, and how it fails

-

Craft in the fundamentals: modern CSS and layout, semantic HTML, accessibility, web performance, responsive and mobile-first work

-

Solid command of TypeScript

-

Experience building or maintaining a design system, or at least a clear opinion about what makes one work

-

Comfortable owning outcomes, working day to day with non-engineers

-

Uses AI deliberately as leverage: directs and reviews generated code to production quality

-

A maker: ships, validates, then refines on what the evidence shows

-

Cares that the thing works for the person using it, on their phone, on their network

-

A plus: enough backend familiarity (Ruby, or any server-side language) to change an endpoint yourself

-

A plus: data-informed product work, with decisions grounded in data

-

English skills for working in our international team; German is a plus

**What we offer**

-

Hybrid work model combining office and remote days

-

A meaningful job – we're creating a great product with real added value for the community

-

Work in a cheerful and experienced team that exchanges ideas and learns from each other

-

Insights into the entire work process of our social startup and the nebenan.de foundation

-

Responsibility and great opportunities to actively contribute

-

Your nebenan.de SpenditCard – you'll receive an additional income of 35 Euros per month, which you can use for things of your choice

-

30 days of vacation per year – we also offer the possibility of workation models and a sabbatical

-

A workplace in Berlin-Kreuzberg and regular events like yoga or Lunch & Learn sessions.

If we’ve captured your interest, apply now and let us know why you’re the perfect fit for the job!

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
