# Interim Controller (gn) SaaS / Grafana

Posted: 2026-09-08T09:30:42Z

## Rejection

- Category: language_requirement
- Reason: hard German language requirement without English green light

• Unser Kunde ist eine wachsende Unternehmensgruppe aus Logistikumfeld mit mehreren Gesellschaften.

• Ziel ist es, das gruppenweite Controlling und Reporting deutlich zu professionalisieren und in einer zentralen BI-Lösung abzubilden.

• Das Projekt bietet viel Gestaltungsspielraum und direkten Austausch mit Geschäftsführung und interner IT.

## Aufgaben

• Aufbau eines einheitlichen Controlling- und Reporting-Setups über mehrere Gesellschaften hinweg

• Konsolidierung bestehender Daten aus DATEV, Excel und einer eigenentwickelten Plattform

• Konzeption und Weiterentwicklung eines zentralen Dashboards in Grafana

• Definition relevanter KPIs, Reportinglogiken und Datenstrukturen

• Erstellung eines klaren fachlichen Konzepts für die technische Umsetzung durch die interne IT

• Abstimmung und Harmonisierung bestehender Controlling-Prozesse

• Sicherstellung einer konsistenten Datenbasis für Management- und Finanzreporting

• Begleitung der Umsetzung bis zum funktionierenden Reporting-Setup

## Qualifikation

• Mehrjährige Erfahrung im Controlling, Finance oder Group Reporting

• Erfahrung im Aufbau oder in der Weiterentwicklung gruppenweiter Controlling-Strukturen

• Praktische Erfahrung mit Grafana optional

• Erfahrung mit BI-Tools, Reporting-Systemen und Datenkonsolidierung

• Idealerweise Erfahrung im SaaS-, Plattform- oder Logistikumfeld

• DATEV-Kenntnisse von Vorteil

• Sehr gute Excel-Kenntnisse

• Fähigkeit, fachliche Anforderungen strukturiert für IT-Teams aufzubereiten

• Hands-on-Mentalität und selbstständige Arbeitsweise

• Fließende Deutschkenntnisse sowie gute Englischkenntnisse

## Benefits

• Freiberufliches Interim-Mandat

• Auslastung: ca. 20 Stunden pro Woche

• Projektstart: 21. oder 28. September 2026, alternativ Anfang Oktober

• Projektdauer: zunächst ca. 4–6 Wochen

• Zielsetzung: Umsetzung des zentralen Controlling-Setups bis Weihnachten

• Standort: Hamburg

• Zu Projektbeginn einzelne Vor-Ort-Termine zum Kennenlernen von Team und Systemlandschaft

• Anschließend überwiegend Remote-Arbeit möglich

• Direkter Austausch mit Geschäftsführung und interner IT

• Hoher Gestaltungsspielraum und klar definierter Projektauftrag

• Wir freuen uns auf deine Bewerbung mit Angaben zu Verfügbarkeit, Stundensatz und relevanter Projekterfahrung.

• Besonders interessant sind konkrete Erfahrungen mit Grafana sowie mit dem Aufbau gruppenweiter Controlling- und Reporting-Strukturen.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
