# AxiomSL Developer/ Implementation Consultant

Posted: 2026-09-08T09:00:57Z

## Rejection

- Category: tech_stack
- Reason: role does not mention Go/Golang or PHP

We are looking for an experienced **AxiomSL Develpoer/ Implementation Consultant** to support the implementation of an **AxiomSL ControllerView custom solution on RegCloud**.

The consultant will work on implementing standard AxiomSL products for regulatory reporting and support localized customizations required for the European region.

## Tasks

**Key Responsibilities:**

- Implement standard **AxiomSL ControllerView** solutions for regulatory reporting.

- Contribute to the delivery of a custom regulatory reporting solution for the European region.

- Work with stakeholders to understand regulatory reporting requirements.

- Support data analysis, transformations, and data quality activities where required.

- Collaborate with technical, business, and project teams throughout the implementation lifecycle.

- Work within Agile delivery methodologies and support project tracking through Jira.

## Requirements

**Required Skills & Experience:**

- **3–5 years of hands-on experience using AxiomSL.**

- Relevant experience implementing **AxiomSL ControllerView** solutions.

- Experience implementing standard AxiomSL products for **regulatory reporting**.

- Experience supporting localized customizations.

- Strong English communication skills.

- **Must be based in Europe.**

Preferred Skills:

- Experience supporting custom solutions on **RegCloud**.

- Experience within financial institutions.

- Knowledge of regulatory reporting, risk, finance, or data management.

- Experience with ETL, data transformations, data quality controls, and workflow automation.

- Experience working in Agile environments and Jira.

- Strong stakeholder and client-facing skills.

- **Nasdaq certification** is a plus.

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
