# Junior Product Manager - Growth Platform (m/f/d)

Posted: 2026-09-08T08:55:04Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Raisin is the world’s leading platform for savings and investment products. Founded in 2012, the **FinTech** connects consumers with banks in the EU, the UK and the US. This gives consumers **better interest rates** and banks a **diversified form of refinancing**. Our vision is to offer savings and investments without barriers and thus open up the global 160 trillion euro market.

Raisin currently employs more than 800 people from over 75 countries worldwide. Today, the platform holds over 80 billion euros in assets from **more than one million investors** which have accrued over 5 billion euros in returns.

**Team**

The Growth Platform Team is a key part of Raisin’s B2C Experience Tribe, powering the infrastructure behind our growth engine. Our mission is to empower product teams and marketers alike to learn fast and grow smarter. We do this by providing the tools, backend services, and integrations that drive measurable outcomes. From A/B testing infrastructure and user analytics to bonus systems and affiliate tooling, the team enables data-driven growth initiatives across Raisin's B2C platforms.

You’ll work at the intersection of product, marketing, engineering, and data — empowering teams across Raisin to test ideas, measure outcomes, and scale what works. If you thrive on cross-functional collaboration and want to make a measurable impact on how we grow, this is the team for you.

**Your Responsibilities**

- Own and evolve our experimentation and A/B testing infrastructure to support rapid learning across teams.

- Collaborate with Data Engineers and Analysts to instrument tracking and enable granular behavioural insights.

- Drive initiatives like Refer-a-Friend, bonuses, and retention programs, balancing customer incentives with business outcomes.

- Integrate key marketing technologies (e.g. affiliate tracking) into our product and data stack.

- Work with Engineering to prioritise and deliver growth-enabling capabilities with high quality and efficiency.

- Lead backlog refinement and discovery rituals with engineering, ensuring high alignment and focus.

- Contribute to quarterly planning (OKRs) and define clear success metrics for your domain.

**Your Profile**

- 2+ years of experience in a product role, ideally in B2C, and/or in a growth-focused role.

- Experience working with experimentation frameworks and A/B testing setups

- Strong collaboration skills across product, data, marketing, and tech

- Actively using AI in your workflow. You reach for it for research, spec drafts, data exploration, and experiment design, and have a point of view on where it helps and where it doesn't.

- Solid understanding of tracking, analytics, and attribution concepts.

- Strong technical fluency. You can collaborate closely with engineers on backend services and APIs.

- Analytical mindset. You are confident using data to define success and drive decisions

- You are proactive, structured, and outcome-driven

**Join our mission, join our team – and grow with us!**

At Raisin, we care about each other and it is one of our top priorities to foster an open and caring environment in which everyone feels welcome and comfortable. Our culture is strongly driven by our ambitious team, which connects more than 75 different nationalities.

As part of our team, you will benefit from:

- Employee Development Budget of €2,000 and four full training days per year.

- Flexible working hours, home office and 30 vacation days.

- A company pension scheme (Betriebliche Altersvorsorge), which we support with 20%.

- Enjoy more than 50+ different sports with Urban Sports Club: We subsidize your membership with more than €20 per month.

- Do you miss being in the office? The Deutschland Ticket gets you there, which we subsidize with €25 per month.

- Love cycling? With JobRad, lease the bike of your choice and enjoy tax savings, plus Raisin covers your monthly insurance costs.

- Hungry all the time? Snacks, daily fresh fruit as well as drinks provided at the office.

- You are moving from another country or city to join us? We may support your relocation.

[*Raisin Applicant Privacy Policy*](https://www.raisin.com/corporate/raisin-applicant-privacy-policy/)

We value diversity and the unique experiences each individual brings. If you’re excited about this role but don’t meet every requirement, we still encourage you to apply.

We are an equal opportunity employer and are committed to creating an inclusive environment for everyone, regardless of race, colour, ancestry, religion, sex, national origin, sexual orientation, age, citizenship, marital status, disability, or gender identity.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
