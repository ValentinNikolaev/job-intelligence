# Customer Service Agent Scandinavia

Posted: 2026-09-08T08:40:12Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**PERGOLUX** is a rapidly growing e-commerce company in the Home & Garden sector that designs, manufactures and sells Pergolas. Founded in Norway, PERGOLUX is constantly looking for growth opportunities and is already available in more than 15 countries in Europe, Australia, North America and South America.

If you have a passion for outdoor living products and a desire to work in a dedicated environment with amazing colleagues - you've come to the right place!

We make the dream possible. Be part of our dream team!

**What You’ll Do:**

-

Professional advice and support for our customers via phone, email, and (video) chat

-

Processing orders, including all payment related topics, etc

-

Supporting customer for technical product and assembly questions.

-

Resolving customer inquiries, processing returns and complaints, and verifying the accuracy and plausibility of issues.

-

Coordinating and communicating with transport service providers to ensure smooth delivery processes.

-

Data maintenance and process optimization to increase efficiency and service quality.

**What We’re Looking For:**

-

Fluently in any Scandinavian and English Languages to communicate confidently with our customers.

-

Experience in customer service (at least 3 years), ideally in e-commerce or a similar industry.

-

Strong communication skills, along with a solution-oriented and empathetic working style.

-

Enjoyment of working in a dynamic team and a strong customer service mindset.

-

Good self-organization and time management skills to work efficiently.

-

IT affinity and the ability to quickly adapt to new systems and tools.

-

Willingness to occasionally work evening and weekend shifts

-

Residence in Frankfurt or the surrounding area

**What we offer:**

-

A dynamic international work environment in a rapidly growing company with many growth opportunities

-

Hybrid work model (80% on-site | 20% remote)

-

Employee events (summer party, Christmas party, after-work gatherings)

-

Access to the Corporate Benefits portal

-

Employee discounts on PERGOLUX products

-

Strong focus on professional development and skill-building

-

Employee pension plan

-

Bike Leasing benefit

-

Employee referral program

We look forward to receiving your application and resume!

For more exciting insights into the PERGOLUX culture visit our Linkedin page!

[www.linkedin.com/company/pergolux](http://www.linkedin.com/company/pergolux)

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
