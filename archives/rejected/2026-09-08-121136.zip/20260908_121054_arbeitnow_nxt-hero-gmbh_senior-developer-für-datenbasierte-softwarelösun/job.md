# Senior Developer für datenbasierte Softwarelösungen - Region Stuttgart - 90.000€

Posted: 2026-09-08T08:00:39Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Du möchtest Software nicht nur entwickeln, sondern aktiv mitgestalten und Verantwortung übernehmen?

Für ein innovatives Technologieunternehmen suchen wir einen erfahrenen Senior Software Developer (m/w/d), der komplexe Kundenanforderungen in intelligente Softwarelösungen übersetzt und Projekte von der Konzeption bis zum Go-live begleitet.

## Aufgaben

- Entwicklung moderner Backend-Lösungen mit C#/.NET

- Verantwortung für Projekte über den gesamten Entwicklungszyklus hinweg

- Konzeption und Umsetzung individueller Softwarelösungen

- Fachliche Koordination kleiner Entwicklungsteams

- Enge Zusammenarbeit mit Kunden und Fachbereichen

- Gestaltung skalierbarer Architekturen und technischer Konzepte

- Mitwirkung an datengetriebenen Anwendungen und intelligenten Auswertungsprozessen

## Qualifikation

- Mehrjährige Erfahrung in der Softwareentwicklung mit C#/.NET

- Freude daran, Verantwortung zu übernehmen und Dinge voranzutreiben

- Analytische Denkweise sowie Interesse an mathematischen und datengetriebenen Fragestellungen

- Erfahrung im Austausch mit Kunden oder Stakeholdern

- Fähigkeit, komplexe Anforderungen in technische Lösungen zu übersetzen

- Strukturierte und eigenverantwortliche Arbeitsweise

- Hoher Qualitätsanspruch an Code und Softwarearchitektur

## Benefits

- Viel Gestaltungsspielraum statt reiner Ticketbearbeitung

- Anspruchsvolle und abwechslungsreiche Kundenprojekte

- Direkter Einfluss auf technische Entscheidungen

- Kurze Entscheidungswege und hohe Eigenverantwortung

- Arbeit an intelligenten Lösungen rund um die Verknüpfung und Nutzung komplexer Datenlandschaften

Der persönliche Austausch wird hier großgeschrieben. Deshalb ist die Position überwiegend vor Ort ausgelegt.

Interesse? Dann freue ich mich auf deine Nachricht. 🚀

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
