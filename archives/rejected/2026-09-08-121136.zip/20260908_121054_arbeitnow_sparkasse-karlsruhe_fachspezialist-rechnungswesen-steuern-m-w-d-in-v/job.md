# Fachspezialist Rechnungswesen & Steuern (m/w/d) in Vollzeit

Posted: 2026-09-08T08:00:39Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**Mit einer Bilanzsumme von rund 12 Mrd. €, ca. 1.300 Mitarbeitenden und einer über 213-jährigen Unternehmensgeschichte sind wir eines der größten und das älteste selbstständige Finanzdienstleistungsinstitut unserer Region. Gemessen an der Bilanzsumme ist die Sparkasse Karlsruhe die fünftgrößte Sparkasse in Baden-Württemberg und gehört zu den 25 größten Sparkassen in Deutschland. Wir überzeugen unsere Kunden vor Ort und digital mit individueller Beratung und bestem Service. Unser Erfolgsrezept? Der Mensch. Die Nähe zu unseren Kunden und unseren Mitarbeitenden ist unser wichtigstes Ziel.**

In unserem Bereich Rechnungswesen & Steuern arbeiten Sie mit 10 Kolleginnen und Kollegen zusammen. Hier gehört es insbesondere zu Ihren Aufgaben, bei der Konzeption, Umsetzung und Pflege von Fachthemen des internen Rechnungswesens mitzuwirken und zu unterstützen.

Kommen Sie zur Sparkasse Karlsruhe – werden Sie Teil unseres Teams.

## Aufgaben

- Konzeption, Umsetzung, Weiterentwicklung und Pflege von Fachthemen im Bereich des internen Rechnungswesens, insbesondere der Buchführung und der Debitorenbuchhaltung

- Kontrollaufgaben

- Projektmitarbeit

- Ansprechpartner für Führungskräfte und einzelne Unternehmensbereiche

## Qualifikation

- Bankfachwirt oder Bankkaufmann mit vergleichbarer Ausbildung

- idealer Weise Erfahrungen im Rechnungswesen eines Kreditinstituts

- Betriebswirtschaftliches Wissen und Kenntnisse im bankspezifischen Rechnungswesen

## Benefits

- eine krisensichere Anstellung bei einem starken regionalen Arbeitgeber

- Als tarifgebundene Arbeitgeberin wenden wir die einschlägigen tariflichen Regelungen des TVöD-AT sowie des TVöD-BT-S an.

Die Vergütung erfolgt nach Entgeltgruppe TVöD-S 9A. Die Jahresbruttovergütung orientiert sich an der Erfahrung und Qualifikation und liegt in einer Spanne von ca. 51.000€ bis ca. 63.900€ mit 13,83 Monatsgehältern inkl. Höchstbetrag der vermögenswirksamen Leistungen

- 39 Stunden-Woche bei Vollzeit

- Flexible Arbeitszeitgestaltung

- 32 Urlaubstage (ab 2027: 33 Tage) + bezahlte Freistellung am 24.12. und 31.12.

- Betriebliche Altersvorsorge

- Betriebliche Krankenversicherung

- Unterstützung Ihrer beruflichen Aus- und Weiterbildung

- Fahrradleasing

- 50% Zuschuss zum Jobticket

- Weitere Vergünstigungen bei Finanzprodukten sowie exklusive Mitarbeiterangebote zu Top-Konditionen über "corporate benefits" – Mitarbeiterrabatte bei über 1.500 Shops

Weitere Benefits finden Sie auf unserer Homepage.

**Interessiert?**

Wir freuen uns auf Ihre Bewerbung unter Angabe Ihrer Gehaltsvorstellung und Ihres möglichen Eintrittstermins. Bewerben Sie sich bis zum **25.09.2026** über unser Online-Bewerberportal.

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
