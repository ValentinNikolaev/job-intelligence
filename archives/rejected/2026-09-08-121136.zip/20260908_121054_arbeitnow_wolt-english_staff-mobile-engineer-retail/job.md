# Staff Mobile Engineer - Retail

Posted: 2026-09-08T06:45:23Z

## Rejection

- Category: role_mismatch
- Reason: title is an obvious mismatch for a backend profile

## About Wolt

At Wolt, we create technology that brings joy, simplicity and earnings to the neighborhoods of the world. In 2014 we started with delivery of restaurant food. Now we're building the delivery of (almost) everything and you'll find us in over 500 cities in 30 countries around the world. In 2022 we joined forces with DoorDash and together we keep on dreaming big and expanding across the globe.

Working at Wolt isn't always easy, but it's definitely exciting. Here you'll learn more, build more, and ship more than in most other companies. You'll be challenged a lot, but also have a lot of fun on the way. So, if you're a self-starter with drive and entrepreneurial spirit, this could be the ride of your life.

As a Staff Mobile Engineer in Global Retail, you'll shape how customers discover, browse, and buy retail products - apparel, beauty, electronics, auto parts and more - across Wolt, DoorDash and Deliveroo. Retail is a large growth opportunity for the business, and our mission is to be the most trusted and magical way to shop the brands and local stores customers love. You'll play a key role in making that real on mobile - from product discovery through to shopping experience in the apps millions of people use every day.

You'll join an evolving area where we are replacing and improving parts of the existing consumer apps, owning specific retail journeys within large-scale B2C applications. This means working in a complex environment where multiple teams own different parts of the same app, and where strong technical judgment is needed to create consistency, quality and speed across teams.

**This role is primarily iOS-focused, but combined iOS + Android experience is a strong plus.**

# What you'll be doing

- **Leading complex cross-team initiatives through design,** implementation, launch, and operational ownership, partnering with product, design, and business stakeholders to deliver measurable impact.

- Driving and implementing **native iOS and Android** initiatives within shared consumer-facing apps - where retail teams ship alongside teams owning other journeys in the same applications - balancing speed, quality, and long-term maintainability.

- Working within and helping evolve our **server-driven UI (SDUI)** approach, going beyond UI implementation to design configurable, component-based views.

- Anticipating future product and architectural needs while establishing engineering standards across architecture, testing, release processes, observability, and incident management - proactively addressing scalability, performance, and reliability.

- Championing **AI-enabled tooling** and practices that help mobile engineers move faster, without lowering the bar on quality.

- Communicating complex technical decisions to technical and non-technical stakeholders - with clear estimates, timelines, and trade-offs that support predictable delivery.

- **Mentoring engineers** - including those transitioning into mobile - and upholding engineering culture and best practices across teams.

# What we're looking for

- **Deep expertise in mobile development and particularly with the iOS ecosystem**, including modern best practices, performance optimization, observability, modularity, SDK design, server-driven UI, CI/CD, and the navigating the AppStore processes.

- **Experience operating at Staff Engineer level or equivalent scope**, having led cross-team / cross-org initiatives.

- A track record working on **large-scale, native consumer (B2C) applications,** ideally at a company where app ownership is split across multiple teams by vertical or feature area.

- A pragmatic, impact-oriented mindset with a bias for action and simple, effective solutions. Comfortable navigating ambiguity and driving clarity and execution in a fast-changing business environment.

- Ability to influence and align stakeholders through clear communication and technical leadership.

- Experience mentoring engineers and contributing to a culture of continuous learning.

- **Practical experience using AI as part of your engineering toolkit,** with good instincts for validation, quality, and when not to take output at face value.

- Being familiar with Android, along with iOS, is a plus.

# Location

📍This role can be based in one of our tech hubs - **Helsinki or Berlin**

## Our Commitment to Diversity and Inclusion

We're committed to growing and empowering a more inclusive community within our company, industry, and cities. That's why we hire and cultivate diverse teams of people from all backgrounds, experiences, and perspectives. We believe that true innovation happens when everyone has room at the table and the tools, resources, and opportunity to excel.

*Beware of recruitment scams: DASH Brands will never ask you to pay money or share sensitive financial information during hiring — learn more about DASH Brands' legitimate recruiting process at* [*careersatdoordash.com/recruitment-scam-awareness*](http://careersatdoordash.com/recruitment-scam-awareness)*.*

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
