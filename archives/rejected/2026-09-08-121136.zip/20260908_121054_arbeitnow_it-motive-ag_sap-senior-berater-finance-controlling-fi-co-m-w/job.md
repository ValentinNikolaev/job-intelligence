# SAP Senior Berater Finance & Controlling / FI-CO (m/w/d)

Posted: 2026-09-08T07:30:33Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Die it-motive AG zählt seit fast 25 Jahren zu den etablierten IT-Beratungsunternehmen in Deutschland.

Zu unseren Kunden gehören internationale Konzerne sowie große mittelständische Unternehmen aus den unterschiedlichsten Branchen. Die Nähe zu unseren Kunden und Mitarbeitern ist unser höchstes Gut, daher wird das Bild der it-motive AG durch eine solide und partnerschaftliche Zusammenarbeit nach innen und nach außen geprägt.

Für unseren SAP-Bereich suchen wir motivierte Teamplayer, die uns mit ihrem Know-how bereichern und zum weiteren Erfolg der it-motive AG beitragen.

## Aufgaben

Ihre Aufgaben:

- Beratung und Betreuung unserer Kunden im Bereich SAP FI/CO

- Analyse und Optimierung der Geschäftsprozesse im Finanz- und Controlling-Umfeld

- Eigenverantwortliche Konzeptionierung und Implementierung SAP-Lösungen und übernehmen das Customizing

- Umsetzung der S/4 HANA-Implementierungsstrategie

- Durchführung von Schulungen und Workshops für Key-User und Endanwender

- Unterstützung bei Rollouts, Migrationen und Systemintegrationen

## Qualifikation

Das bringen Sie mit:

- Erfolgreich abgeschlossenes Studium der (Wirtschafts-) Informatik/ Betriebswirtschaft oder eine vergleichbare Qualifikation

- Mindestens 3 Jahre Projekterfahrung in der Implementierung und Betreuung von SAP FI/CO

- Fundierte Kenntnisse in SAP FI (z. B. Hauptbuch, Kreditoren, Debitoren) und CO (z. B. Kostenstellenrechnung, Innenaufträge)

- Wünschenswert sind zusätzliche Erfahrungen mit S/4 HANA

- Know-how in der Projektarbeit nach gängigen Projektmanagementstandards, bevorzugt nach der SAP Activate Methodik

- Analytisches Denkvermögen, Kommunikationsstärke und Teamgeist

- Sehr gute Deutschkenntnisse, gute Englischkenntnisse

- Bereitschaft, in den Projektphasen zu reisen

## Benefits

Das bieten wir:

- Unbefristete Festanstellung

- 30 Urlaubstage

- Faires Festgehalt plus variable Gehaltsbestandteile

- Die Möglichkeit für das Alter vorzusorgen

- Abwechslungsreiches Aufgabengebiet

- Flache Hierarchien, Teamarbeit und kurze Entscheidungswege

- Aufstiegsmöglichkeiten mit fachlicher und/ oder disziplinarischer Verantwortung

- Persönliche Einarbeitung und Betreuung

- Möglichkeit, teilweise mobil vom Homeoffice aus zu arbeiten

- Die Chance, Verantwortung mit dem nötigen Handlungsspielraum zu übernehmen

- Ausgeprägte Weiterbildungsmöglichkeiten

- Mitarbeiterangebote über Corporate Benefits

- Kostenlose Mitgliedschaft in ausgewählten Fitnessstudios

- Möglichkeit des Fahrradleasings nach der Probezeit

- Regelmäßige Team- und Firmenevents

Interesse?

**Sie fühlen sich angesprochen?**

Dann freuen wir uns auf Ihre Bewerbung unter Angabe Ihrer Gehaltsvorstellung und Ihres frühestmöglichen Eintrittstermins!

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
