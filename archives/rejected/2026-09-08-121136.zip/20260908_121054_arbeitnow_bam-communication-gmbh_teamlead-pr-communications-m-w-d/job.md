# Teamlead PR & Communications (m/w/d)

Posted: 2026-09-08T11:00:33Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**Starttermin:** Dezember 2026

**Art & Umfang: F**estanstellung, Vollzeit 80 - 100%

**Location:** Berlin (Kreuzberg) oder Hybrid

**Unsere Kultur**

Wir sind **BAM** - ein agiles Team mit Sitz in Berlin, das sich schnell dem Zeitgeist anpassen kann, ohne dabei in starren Prozessen und Abläufen zu verharren. Arbeitsweisen werden fortlaufend hinterfragt, und *challenging the status quo* bedeutet für uns, den Mut zu haben, Dinge auch einmal anders zu machen.

Bei uns packen alle mit an: Jede Stimme zählt, und niemand wird klein gehalten. In unserem Team stehen Respekt und Vertrauen an oberster Stelle. Klassische Karrierestufen oder Titel gibt es nicht – wir wachsen gemeinsam, indem wir individuelle Potenziale fördern.

Wir sind ein Team, in dem wir Probleme offen ansprechen und gemeinsam lösen, viel miteinander lachen und respektvoll miteinander umgehen.

Durch unser Markenportfolio im Lifestyle-Bereich entsteht ein abwechslungsreiches Aufgabenfeld mit einem interdisziplinären Arbeitsansatz. In unserem **BAM-Raum** setzen wir zudem Kreativprojekte eigenständig um – alles unter dem Dach von **BAM PRACTICE.**

Daraus ist in den letzten Jahren eine lebendige **BAM-Community** aus Kunst, Musik, Mode und der Kreativszene entstanden.

## Aufgaben

**Welche Aufgaben warten auf Dich als Team Lead Lifestyle PR?

**

**Teamführung und -entwicklung:**

- Regelmäßige Einzelgespräche mit Teammitgliedern, Festlegung klarer Ziele und Überwachung der Teamleistung.

- Teamcoachings und inhaltliche Weiterentwicklung mit Schwerpunkt PR

- Optimieren von Workflows und Strukturen im PR Bereich.

- Verwaltung und Planung team relevanter Themen in enger Abstimmung mit der Führungsebene und der Personalabteilung (HR).

- Unterstützung bei Personalthemen (z.B. Vorstellungsgespräche, Einarbeitung neuer Teammitglieder, Urlaubsplanung, Kapazitätsplanung).

**Kundenberatung und Strategie:**

- Übernahme einer übergeordneten beratenden Rolle auf allen PR Kunden

- Führende Unterstützung und Beratung der PR Manager auf Projekten, bei Strategien und der täglichen PR Arbeit

- Kundenberatung & teilweise aktive PR Arbeit

- Erstellung von Kostenvoranschlägen und Überwachung und Projektfortschritts

- Aktive Teilnahme an Kundengesprächen.

- Unterstützung bei der Einarbeitung neuer Kunden (Onboarding-Prozesse).

## Qualifikation

**Was solltest Du mitbringen?

**

- Du hast mindestens 5 Jahre Erfahrung in Brand Communications, idealerweise Lifestyle-PR und

- Idealerweise bist du in der deutschen Medienlandschaft gut vernetzt.

- Du hast Erfahrung in der Führung von Teams.

- Du arbeitest sicher und zuverlässig mit PR-Tools und Systemen zur Unternehmenssteuerung.

- Du definierst, analysierst und entwickelst PR-KPIs eigenständig weiter.

- Du planst Budgets und stellst ein ausgewogenes Verhältnis zwischen kreativem Output und finanzieller Performance sicher.

- Du verantwortest die Abrechnung unserer PR-Arbeit und behältst alle Budgetströme im Blick.

- Du legst Wert auf menschliche Beziehungen und Teamzusammenhalt.

- Du führst empathisch und förderst eine lösungsorientierte Arbeitsweise.

- Du etablierst klare, wertschätzende Kommunikation und Feedbackprozesse.

- Du interessierst dich für moderne Führungs- und Arbeitskonzepte (New Work).

## Benefits

**Was bieten wir Dir?

**

- Wir übernehmen deine Urban Sports Mitgliedschaft oder das BVG Deutschlandticket

- Macbook auch zur privaten Nutzung

- Arbeite flexibel im Homeoffice oder in unserem Office in Kreuzberg

- Regelmäßige Team Lunches, Team Events, Workshops und Team Coachings stärken uns und gehören zu unserer Culture

- Coffee, Matcha, Snacks und Obst sind immer da

- Starkes Team und kurze Entscheidungswege

Klingt nach dir? Dann lass uns sprechen. **Wir freuen uns sehr auf deine Bewerbung als Teamlead Lifestyle PR!

We live diversity!** Wir schätzen die Einzigartigkeit und Unterschiedlichkeit unserer Mitarbeitenden und fördern ein inklusives Arbeitsumfeld, in dem alle Menschen – chtigung – gleiche Chancen erhalten.unabhängig von Alter, Geschlecht, sexueller Identität, Herkunft, Religion, körperlicher oder geistiger Beeinträchtigung.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
