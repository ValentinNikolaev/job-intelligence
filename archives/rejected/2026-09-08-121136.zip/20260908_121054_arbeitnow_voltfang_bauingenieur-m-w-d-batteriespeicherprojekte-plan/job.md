# Bauingenieur (m/w/d) Batteriespeicherprojekte - Planung und Baugenehmigungen

Posted: 2026-09-08T07:00:44Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Du legst das Fundament, damit unserer Batteriegroßspeicher-Projekte umgesetzt werden können von Vor-planung bis zur Baugenehmigung. Du bewertest Standorte, entwickelst die Genehmigungsstrategie und erstellst die Bauantragsunterlagen. Mit der Einreichung des Bauantrags übergibst du an die Projektumsetzung.

## Aufgaben

- Du entwickelst die Genehmigungsstrategie je Projekt, erkennst Risiken früh und begleitest B-Plan-, FNP- und immissionsschutzrechtliche Verfahren wo nötig

- Du erstellst die Entwurfs- und Genehmigungsplanung und verantwortest die vollständigen Bauantragsunterlagen bis zur Einreichung

- Du koordinierst alle relevanten Fachgutachten (TA Lärm, Brandschutz, Artenschutz § 44 BNatSchG, Boden) und managst die Schnittstellen zu Fachbehörden auf kommunaler und Landesebene

- Du steuerst externe Planungsbüros und Gutachter fachlich auf Augenhöhe und prüfst deren Ergebnisse kritisch auf Qualität und Plausibilität

## Qualifikation

- Abgeschlossenes Studium im Bauingenieurwesen oder in der Architektur

- Mindestens 5 Jahre Erfahrung in Genehmigungsplanung oder Baurecht für Energie- oder Infrastrukturprojekte

- Fundiertes Know-how in BauGB (inkl. § 35), BauNVO und BImSchG sowie in der Koordination von Fachgutachten (Lärm, Brandschutz, Artenschutz)

- Erfahrung in der eigenverantwortlichen Erstellung und Einreichung von Bauanträgen

- Bauvorlageberechtigung wünschenswert, aber keine Voraussetzung

- Hands-on-Mentalität: Du besitzt den Content selbst, steuerst und hinterfragst externe Büros

- Verhandlungssicheres Deutsch und gute Englischkenntnisse

## Benefits

- Viel Eigenverantwortung und echte Gestaltungsmöglichkeiten — Du baust mit, statt nur zu verwalten. Und das in einem Job, der direkt zur Energiewende beiträgt.

- Ein Team, das brennt: Wir bauen gemeinsam etwas auf — mit flachen Hierarchien, kurzen Entscheidungswegen und einer Kultur, in der man offen sagen kann, was man denkt.

- Flexible Arbeitszeiten, hybrides Arbeiten und 30 Tage Urlaub, weil gute Arbeit und ein gutes Leben kein Widerspruch sind.

- Jobticket-Zuschuss, Urban Sports Club und regelmäßige Team-Events, für den Ausgleich abseits des Schreibtischs.

- Unser Office Dog, für gute Laune und kurze Ausreden vom Schreibtisch.

Bist du bereit, wirklich etwas zu bewegen?

Dann komm zu **Voltfang** und gestalte mit uns die Energiezukunft.

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
