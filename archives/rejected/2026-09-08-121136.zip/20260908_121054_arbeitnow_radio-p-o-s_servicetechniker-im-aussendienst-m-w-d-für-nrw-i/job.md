# Servicetechniker im Außendienst (m/w/d) für NRW in PLZ-Gebieten 4xxxx-5xxxx)

Posted: 2026-09-08T08:30:52Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Die Radio P.O.S. GmbH mit Sitz in Kiel ist seit über 35 Jahren ein Full-Service-Dienstleister rund um den stationären Einzelhandel.

Mit über 150 Kolleg*innen bietet die P.O.S. Gruppe ein breites Leistungsspektrum von Beratung, Software und Contentproduktion bis hin zu Installationsservices. Als Spezialist für Kommunikationskonzepte bieten wir namhaften Kunden europaweit vielfältige digitale Medienlösungen rund um die Handelsfläche.

Wir sind weiter auf Wachstumskurs und suchen Dich für unseren **Bereich Media Service** **ab sofort** und **unbefristet** in Voll- oder Teilzeit (mind. 32 Std.) als

## Aufgaben

***Dieser Aufgabenbereich erwartet Dich:***

- Installation, Reparatur und Wartung von AV-Technik und Sprachalarmanlagen

- Konfiguration und Inbetriebnahme der zugehörigen Ausspiel- und Systemtechnik

- Du startest von Deinem Zuhause mit Deinem Firmenwagen in Deiner Region und arbeitest bei unseren Kunden direkt vor Ort

- Einweisungen und Schulungen unserer Kunden bei Erstinstallationen

- Abstimmung mit unserem Innendienst-Team zur effizienten Auftragsplanung

## Qualifikation

***Das würde uns begeistern:***

- Eine abgeschlossene elektrotechnische oder vergleichbare Berufsausbildung

- Breite Kenntnisse von elektrotechnischen Anlagen, Audio-, TV- oder IT-Produkten

- Bestenfalls erste oder tiefere Erfahrung in Sprachalarmzentralen oder BMZ

- Du trittst professionell und serviceorientiert auf und hast Freude am Kundenumgang

- Dich begeistern Technik, Geräte und echtes Handwerk

## Benefits

***Das können wir Dir bieten:***

- Abwechslungsreiche Aufgaben und intensive Einarbeitung durch unsere Kollegen

- Betriebliche Alters- und Gesundheitsvorsorge sowie weitere Benefits

- Individuelle Entwicklungsmöglichkeiten und regelmäßige Weiterbildungen

- Wir stellen alles, was Du für den Job brauchst, inkl. KFZ für betriebliche Zwecke

- Ein festes Innendienstteam kümmern sich stets um Dich und Deine Aufträge

- Offene Gesprächskultur auf Augenhöhe, eigenverantwortliches Arbeiten und ein starkes, internationales Team hinter Dir – regional, deutschlandweit oder in Europa

***Haben wir Dein Interesse wecken können? Dann freuen wir uns auf Deine Bewerbung!***

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
