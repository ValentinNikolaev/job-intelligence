# Customer Onboarding & Success Manager (m/w/d) 100% Remote möglich

Posted: 2026-09-08T09:30:42Z

## Rejection

- Category: tech_stack
- Reason: role does not mention Go/Golang or PHP

**Wer wir sind**

Wir sind cinify – ein ambitioniertes Health-Tech-Startup mit der Mission, den BI-Markt im Gesundheitswesen zu revolutionieren. Unsere Plattform verbindet Daten aus verschiedensten Systemen, automatisiert Workflows und macht entscheidungsrelevante Insights für Kliniken und Praxen transparent.

Neben etablierten Strukturen skalieren wir aktuell unser Standardprodukt cinify.CORE und cinifyAI im ambulanten Bereich. Immer mehr Praxen und Praxisverbünde kommen dazu – und genau deshalb bauen wir jetzt die Rolle auf, die den Kunden von der Vertragsunterschrift bis in den laufenden Betrieb begleitet.

Wir sind in einer Phase, in der Kundenbetreuung nicht verwaltet, sondern aufgebaut wird. Genau deshalb suchen wir jemanden, der/die von Grund auf mitgestalten will.

## Aufgaben

**Deine Mission**

Ein Kunde wird zweimal gewonnen: einmal im Vertrieb und einmal im Onboarding. Der zweite Teil ist Deine Rolle.

Deine Mission ist es, unseren Kunden ein reibungsloses und schnelles Onboarding zu ermöglichen – von der Vertragsunterschrift über die Anbindung ihrer Systeme bis zum fertigen Dashboard. Du bist von Anfang an Teil der Customer Journey: Du führst den Kickoff, koordinierst die technische Anbindung mit unserem Data-Team, begleitest die Datenvalidierung und sorgst dafür, dass der Kunde sein Dashboard nicht nur bekommt, sondern auch nutzt.

Mit dem Go-Live endet Deine Arbeit nicht. Du bringst unsere Kunden in den laufenden Betrieb und gestaltest mit, wie Customer Success bei cinify künftig aussieht – von den ersten Touchpoints nach dem Onboarding bis zu einem Betreuungsmodell, das mit unserem Wachstum skaliert.

**Deine Aufgaben**

- **Kickoff und Erwartungsmanagement:** Du übernimmst neue Kunden direkt nach dem Vertragsabschluss, führst den Kickoff und schaffst Klarheit über Voraussetzungen, Zeitplan und Zuständigkeiten.

- **Technische Anbindung koordinieren:** Du steuerst die Anbindung der Praxissysteme gemeinsam mit unserem Data-Team. Von der Installation unserer ETL-Software bis zur Abstimmung mit der IT der Praxis oder deren Systemhaus.

- **Dein Draht zur Praxis:** Du kommunizierst proaktiv mit unseren Kunden und bist während des Onboardings ihr zentraler Ansprechpartner.

- **Projektsteuerung:** Du behältst alle laufenden Onboardings im Blick, hältst Zusagen und Termine nach und sorgst dafür, dass unsere Kunden schnell produktiv werden.

- **Onboarding weiterentwickeln:** Du gestaltest mit, wie das Kundenonboarding bei cinify künftig funktioniert - durch Standardisierung, Automatisierung und den Einsatz von KI. Deine Erfahrungen aus den Projekten fließen direkt in bessere Prozesse ein.

- **Customer Success mitgestalten:** Du denkst von Anfang an mit, wie unsere Kunden auch nach dem Go-Live optimal betreut werden. Du hast die Möglichkeit, diesen Bereich bei cinify mit aufzubauen.

## Qualifikation

Das bringst Du mit:

- **Erfahrung in Kundenverantwortung** – z. B. in Onboarding, Implementierung, Customer Success, Account Management oder Projektmanagement mit direktem Kundenkontakt

- **Ownership-Mentalität:** Du übernimmst Verantwortung für Deine Kunden und Projekte und treibst Themen eigenständig bis zum Abschluss

- **Technische Affinität:** Du hast ein gutes Verständnis für Schnittstellen, Datenbanken und IT-Infrastruktur und arbeitest Dich gerne in neue technische Themen ein

- **Selbstständige, strukturierte Arbeitsweise:** Du steuerst mehrere Kundenprojekte parallel und priorisierst eigenständig

- **Kommunikationsstärke** und Freude an direktem Kundenkontakt

Nice-to-have:

- Erfahrung im ambulanten Gesundheitsmarkt, idealerweise mit Praxisverwaltungssystemen

- Erfahrung im SaaS- oder Software-Umfeld

- Erfahrung im Aufbau von Prozessen und Dokumentation

## Benefits

- Zentrale Rolle im Aufbau unseres Kundenonboardings

- Direkte Zusammenarbeit mit dem Gründerteam

- Frühe Verantwortung und hoher Gestaltungsspielraum

- Schnelle Lernkurve an der Schnittstelle von Produkt, Daten und Kunde

- Remote-First (deutschlandweit), optional Büro in Bochum

- Kurze Entscheidungswege und pragmatisches Arbeiten

- Unterstützendes und ambitioniertes Team

- EGYM-Wellpass, USC und Corporate Benefits

- Betriebliche Altersvorsorge mit 20 % Arbeitgeberzuschuss

**Klingt nach Dir?**

Dann schick uns Deinen Lebenslauf und ein paar kurze Zeilen, warum Du diese Rolle übernehmen willst.

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
