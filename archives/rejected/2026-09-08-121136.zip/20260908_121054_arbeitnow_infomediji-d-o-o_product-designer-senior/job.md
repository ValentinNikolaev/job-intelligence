# Product Designer (Senior)

Posted: 2026-09-08T07:20:43Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Join Our Vision: We are building the next generation of Spatial Media - a new way people experience videos through interaction, multi-user presence, haptics, AI, and immersive storytelling.

DeoVR is the leading immersive streaming technology serving multiple enterprise customers and millions of users globally.

We are now expanding the boundaries of what video can be - moving from passive watching to active, interactive, multi-user journeys.

If this excites you more than it scares you, you are in the right place.

#### **The Role**

We're looking for a **Senior Product Designer** to join our team. You'll be instrumental in shaping the design of our VR, web and mobile platforms. It's a hands-on role where your skills will have a direct impact on our products and huge user base.

#### **What You Will Do**

-

Create visually attractive and intuitive user interfaces and experiences for web, mobile, immersive applications and platforms

-

Understand user needs and behaviours, translating them into compelling and user-friendly design solutions

-

Develop interactive prototypes to demonstrate and validate design concepts, working closely with development teams

-

Collaboratively work with cross-functional teams to ensure seamless integration of design into the final product

-

Stay informed about industry trends, emerging technologies, and best practices in design to contribute to ongoing innovation

#### **What We Are Looking For**

-

4+ years of product design experience

-

Skilled in Figma, or similar design tools

-

Strong in developing cohesive, scalable design systems

-

Adept at designing for mobile with a diverse portfolio in UI/UX

-

3D modelling and animation knowledge is a plus

-

Excellent in communication, collaboration, and working with development teams.

-

Fluency in English (B2 and above)

#### **Bonus Points**

-

Experience in Team Lead or higher positions

-

Advanced skills in 3D modelling and animation

-

Experience in immersive projects

#### **Hiring Process**

-

HR Screening (30 min)

-

HM Interview (30 min)

-

Case Task (2-6 hours)

-

Design Interview (1 hour)

-

CEO call (30 min)

**💼[Explore our hiring process](https://realitystream.notion.site/Hiring-Process-at-Infomediji-da4a580b8b7b4fc3a9fc5ea5553dd98b)**

#### **What We Offer**

Please note: fully remote contract role. B2B only - work as an independent contractor with your own legal entity.

-

The chance to be part of a pioneering team in a rapidly evolving industry

-

Direct impact on the future of immersive media

-

Flexible working hours and remote-first culture

-

A team that values initiative, clarity, and collaboration

-

Access to all tools and tech you need

-

Unlimited DeoVR Premium

-

A work environment where ideas matter and people are treated with respect

#### **Stay Connected**

Join [our Facebook community](https://www.facebook.com/groups/deovr/) and follow updates as we advance interactive VR experiences through cutting-edge technology. Join us and step into a role where legal expertise meets innovation.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
