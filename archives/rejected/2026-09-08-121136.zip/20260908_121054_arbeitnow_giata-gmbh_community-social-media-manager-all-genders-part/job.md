# Community & Social Media Manager (all genders) - Part-Time (max. 32h/week)

Posted: 2026-09-08T07:00:43Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

## Your mission

As our Community & Social Media Manager, you will help grow social media presence and build an engaged community around our brands.

You’ll combine hands-on content creation with community management: planning and publishing content, engaging with audiences, identifying conversations and opportunities, and helping turn our social channels into active communities rather than simply publishing platforms.

This is a hands-on role for someone who understands social media, enjoys creating content and communicating with people, and wants to develop further across social media, community building and digital marketing.

- Create, adapt and publish engaging content, including copy, carousels, short-form video and visual assets

- Repurpose existing photography, videos, interviews, articles, podcasts and other materials into social-first formats

- Proactively engage with followers, partners and relevant industry accounts to help grow our community and organic reach

- Track channel and contentperformance and identifywhichtopics and formatsresonatewithouraudiences

- Support social communicationaroundevents, partnerships, campaigns and othermarketing initiatives

- Coordinate the monthly Newletter sendout.

## Your profile

- First professional experience in social media, community management, content marketing or digital marketing – internships, working student roles or relevant freelance experience also count

- A good understanding of LinkedIn and Instagram (the differences & focuses) and how brands can build audiences organically

- Good feeling for storytelling, headlines and social-first communication

- A strong visualeye and attention to detail

- Fluent in English and comfortable communicating in German

## Why us?

- Completetrust in yourabilities and plenty of space for creative and self-directedwork.

- A permanent contract in a stable, dynamic, and future-orientedcompany, as well as flexible workinghours and a hybrid office/remote workmodel.

- Up to 4 weeks of "Work from Anywhere" per year.

- Benefits like a BVG Germany Ticket, an Urban Sports Club membership and mealsubsidies

- Tourismperks like the DRV Card and otherdiscounts.

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
