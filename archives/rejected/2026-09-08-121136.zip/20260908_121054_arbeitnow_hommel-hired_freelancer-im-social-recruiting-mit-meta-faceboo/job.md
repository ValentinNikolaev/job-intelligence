# Freelancer im Social Recruiting mit Meta / Facebook Ad Media Buying Erfahrung (m/w/d) im E-Commerce - 100% remote - von zu Hause

Posted: 2026-09-08T09:00:58Z

## Rejection

- Category: tech_stack
- Reason: role does not mention Go/Golang or PHP

**Hommel Hired** ist eine kleine, vollständig remote arbeitende Agentur, die sich auf Personalvermittlung für remote First Firmen spezialisiert hat.

Unser Ansatz: Wir finden authentische Kandidatinnen und Kandidaten, die nicht nur fachlich überzeugen, sondern auch die **Core Values** unserer Kunden teilen.

In der Folgenden Rolle unterstützt du das Hommel Hired Team bei der Suche nach genau diesen Kandidate:innen.

## Aufgaben

- Aufsetzen von Kampagnene

- Verwaltung des Adbudgets

- Erstellen der Landingpages / Formulare

- Wöchentliches Reporting der KPIs inkl. Handlungsvorschlägen

## Qualifikation

- Mehrjährige Erfahrung im Social Recruiting

- Zuverlässigkeit, Sorgfalt und Eigeninitiative

- Fähigkeit Rechnungen zu schreiben

- **Deutsch & Englisch** fließend

- Idealerweise: Notion & Join (ATS) Erfahrung

Arbeitsaufwand ca. 5-10 Std. pro Woche

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
