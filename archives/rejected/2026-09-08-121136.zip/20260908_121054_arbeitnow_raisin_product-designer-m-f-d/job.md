# Product Designer (m/f/d)

Posted: 2026-09-08T08:55:04Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Raisin is the world’s leading platform for savings and investment products. Founded in 2012, the **FinTech** connects consumers with banks in the EU, the UK and the US. This gives consumers **better interest rates** and banks a **diversified form of refinancing**. Our vision is to offer savings and investments without barriers and thus open up the global 160 trillion euro market.

Raisin currently employs more than 800 people from over 75 countries worldwide. Today, the platform holds over 80 billion euros in assets from **more than one million investors** which have accrued over 5 billion euros in returns.

### **Team
**

The Design team at Raisin brings together product designers and brand & marketing designers; we are united by our shared belief in the power of respect, creativity, and the purpose to give people financial peace of mind.
We’ve built a place where empathy and innovation thrive, where integrity and high quality standards underpin our work. We love our diversity and use the strength of our perspectives to reach our goals. **
**

#### **Product Design ****Principles**

**We are supportive****
**Build confidence by removing the unnecessary and focusing on what matters. Reveal information, features, and controls progressively to create a secure, transparent, accurate, relevant, and consistent experience.

**We create delight****
**Make every design engaging and enjoyable. Use strong visuals, clear data, and thoughtful copy. Treat design quality as essential. Add moments of surprise and joy whenever possible.

**We act universal**
Design smart experiences that adapt to user behavior, use context, and anticipate intent. Keep interfaces familiar, welcoming, and clear yet advanced. Make every interaction simple and intuitive.

**We are authentic
**Bring your whole self and ensure diversity of perspectives. Speak plainly, disagree respectfully, support each other, commit fully, and celebrate progress together.

### **Your Responsibilities**

**Create desirable, usable digital products and features**

- Own design activities to launch and improve features that help customers register, authenticate, manage their accounts, and make payments. Look for places where AI can make complex interactions simpler.

- Own design activities to improve internal customer-service and operations tools to help serve our customer base.

- Lead rapid prototyping activities. Use generative and agentic tools to turn bold concepts into something people can try and share feedback on.

- Support larger end-to-end design discovery and delivery, guided by more senior design peers.

**Hold the bar on quality and ethical guardrails**

- Make quality a habit: validate quickly, and iterate. Use qualitative research, operational metrics, and security and compliance feedback to keep UX guardrails clear and real.

- Run feedback loops so AI-generated work meets a high ethical and quality standard.

**Collaborate across functions**

- Work with product managers, engineers, and data specialists to design and ship high-quality experiences. Be proactive in the way you work together.

- Partner with peers, engineers, and data specialists to experiment and to put in place the UX infrastructure for AI-driven features. Co-create products that are personal and highly secure.

- Tell a clear story. Explain your design intent, choices, and trade-offs to team and stakeholders. Ask for feedback, and give it clearly and openly.

**Turn technical and compliance requirements into usable experiences**

- Translate complex backend and platform capabilities, including AI/ML models and agentic logic, into interfaces that customers and internal teams can easily use.

- Surface compliance requirements, for customers and for internal customer-service teams, and use them to shape experiences that are robust and friendly at the same time.

**Contribute to a living design system**

- Adopt reusable, flexible UX patterns, and add new ones when needed, so we make micro-frontends look - and feel - cohesive.

- Work closely with the team responsible for the Raisin Design System, so components and patterns stay accessible, consistent and well documented across platforms.

- Help the live design system grow: contribute spec-to-code delivery of components and scalable UX patterns when they support the features, services, and experiences you are designing.

**Stay curious, and keep experimenting**

- Keep your craft fresh. Stay current on AI capabilities and on how design work changes when agents are in the loop, so Raisin’s design practice stays sharp.

### **Your Profile**

- 3+ years in product design, ideally in fintech, platform services, or another highly regulated, complex environment (for example healthtech, legaltech, or high-stakes SaaS) where trust, long-term decisions, and compliance really matter.

- A portfolio that shows strong product design experience in complex products and systems: user-centered methods, and real examples of AI/ML-driven features, agentic workflows, or conversational interfaces.

- A clear understanding of how to design for AI: system uncertainty, predictability, user trust, error prevention, and "*human-in-the-loop*" feedback mechanisms.

- Practice with user-driven validation techniques: qualitative, quantitative, and analytics-based.

- A good grasp of how to design with generative and agentic tools, both to explore concepts faster and to build high-fidelity work, for delivery.

- Ability to take active part in cross-functional workshops, including with engineering-heavy partners such as data scientists and AI/ML engineers: ask the deep questions, translate design language into ways other functions will grasp, seek active co-creation and elicit feedback.

- A data-informed mindset. Comfortable working with security, compliance, operational KPIs, and AI system metrics (model accuracy, latency, user feedback loops).

- Strong storytelling that keeps stakeholders and peers with you - as you walk them through your design decisions - including the ability to explain complex AI logic or automated systems in simple, human terms.

- A proactive learner. You already use AI-augmented workflows (research synthesis, copywriting, ideation, delivery) to work faster without lowering the quality bar.

### **Join our mission, join our team – and grow with us!**

At Raisin, we care about each other and it is one of our top priorities to foster an open and caring environment in which everyone feels welcome and comfortable. Our culture is strongly driven by our ambitious team, which connects more than 75 different nationalities.

As part of our team, you will benefit from:

- Employee Development Budget of €2,000 and four full training days per year.

- Flexible working hours, home office and 30 vacation days.

- A company pension scheme (Betriebliche Altersvorsorge), which we support with 20%.

- Enjoy more than 50+ different sports with Urban Sports Club: We subsidize your membership with more than €20 per month.

- Do you miss being in the office? The Deutschland Ticket gets you there, which we subsidize with €25 per month.

- Love cycling? With JobRad, lease the bike of your choice and enjoy tax savings, plus Raisin covers your monthly insurance costs.

- Hungry all the time? Snacks, daily fresh fruit as well as drinks provided at the office.

- You are moving from another country or city to join us? We may support your relocation.

[*Raisin Applicant Privacy Policy*](https://www.raisin.com/corporate/raisin-applicant-privacy-policy/)

We value diversity and the unique experiences each individual brings. If you’re excited about this role but don’t meet every requirement, we still encourage you to apply.

We are an equal opportunity employer and are committed to creating an inclusive environment for everyone, regardless of race, colour, ancestry, religion, sex, national origin, sexual orientation, age, citizenship, marital status, disability, or gender identity.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
