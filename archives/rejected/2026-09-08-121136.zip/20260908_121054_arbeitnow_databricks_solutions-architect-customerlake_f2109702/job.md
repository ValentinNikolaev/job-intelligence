# Solutions Architect - CustomerLake

Posted: 2026-09-08T05:55:17Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**Recruiter: FRANCESCA PATERNOSTER**

**Hiring Manager: MATTHEW THOMSON**

**REQ#: FEQ327R424**

ELIGIBILITY CRITERIA:

- In current role for 12 months+ when applying

- A performance summary assessment at Consistently Meets or better in the most recent PERF cycle

- Must be in good standing (no active performance management)

- Meets qualifications for new role

- Discussed interest with manager prior to onsite interview

Marketing teams are stuck between fragmented customer data and martech stacks that copy that data into proprietary silos while customers expect real-time, personalized experiences. Customer Lake, the agentic Customer Data Platform (CDP) built natively into Databricks, changes that equation. It unifies first- and third-party data into governed Customer 360 profiles, resolves identities, and uses agents to build audiences, recommend next-best actions, and activate campaigns across channels, all without copying data out of the Lakehouse or adding vendor lock-in.

** **

The Solutions Architect (Customer Lake) team is part of a dedicated, global go-to-market organization focused on driving adoption and revenue growth for Customer Lake, Databricks’ agentic Customer Data Platform (CDP) built natively into the Data Intelligence Platform. The Customer Lake SA will engage clients across business units and verticals, build relationships with marketing and data stakeholders, position Customer Lake in depth, and deliver presentations, demos, and POCs that drive informed adoption decisions. They will understand the guardrails and the steps needed to successfully land and expand Customer Lake as clients deliver on their customer engagement and growth objectives.

** **

**The impact you will have**

- Provide technical leadership to guide strategic customers to successful implementations on customer data and marketing projects, ranging from architectural design to data engineering to identity resolution, audience activation, and agent deployment

- Collaborate with GTM leadership and account teams to design and execute high-impact engagement strategies across your territory, driving Customer Lake adoption from initial Customer 360 build-out through full CDP augmentation or replacement.

- As a trusted advisor, serve as an expert Solutions Architect building technical credibility with CMOs, heads of marketing technology (MarTech), data engineering leaders, and marketing and analytics teams to drive product adoption and vision.

- Enable clients at scale through workshops, POC execution, and developing customer-facing collateral that increases technical knowledge and demonstrates the value of an embedded, agentic CDP architecture.

- Influence product roadmap by translating field-derived, data-driven insights into strategic recommendations for Product and Engineering teams.

- Handle the most complex technical challenges in this product line by acting as the tier-3 escalation point for the field, ensuring customer success in mission-critical, customer-facing data environments.

- Establish and refine the sales qualification and POC intake process, ensuring well-scoped engagements that maximize customer success and minimize friction for R&D.

** **

**Competencies & Responsibilities**

- 5+ years of customer data platform (CDP), marketing technology (MarTech), or customer data engineering expertise, with a proven track record of designing and delivering client-facing customer data and activation solutions (of which 3+ years are in a customer-facing, pre-sales or consulting role).

- Experience with design and implementation of data and AI applications for marketing and customer engagement, including identity resolution, segmentation, personalization and next-best-action, and agentic AI workflows for audience building and campaign activation.

- Deep familiarity with CDP and martech/adtech platforms, including composable-CDP architectures (Salesforce Data Cloud, Adobe, Segment, Treasure Data, Braze, or similar), including implementation, identity resolution, audience activation, and migration strategies.

- Strong understanding of the customer data landscape: first-party data (web, app, CRM, POS), third-party and enrichment data, identity graphs, consent and privacy signals, and martech/adtech destinations (ad platforms, email/SMS, CRM, and analytics tools).

- Experience operationalizing customer data as governed data products, including audience and segment definition in SQL or natural language (Genie), reverse-ETL and activation pipelines, and metric, identity, and consent governance in Unity Catalog.

- Experience collaborating with Global System Integrators (GSIs) and third-party consulting organizations to drive customer outcomes in marketing and customer data initiatives.

- Hands-on experience building solutions within major public cloud environments (AWS, Azure, or GCP), with an understanding of cloud-native data ingestion, activation, and governance.

- Undergraduate degree (or higher) in a technical field such as Computer Science, Data Science, Applied Mathematics, Engineering or similar.

**

**

**About Databricks**

Databricks is the Data and AI company. More than 20,000 organizations worldwide — including adidas, AT&T, Bayer, Block, Mastercard, Rivian, Unilever, and 70% of the Fortune 500 — rely on the Databricks Data + AI Platform to build and scale data and AI apps, analytics and agents. Headquartered in San Francisco with 30+ offices around the globe, Databricks offers a unified platform that includes Genie, Lakebase, Agent Bricks, Lakeflow, Lakehouse, and Unity Catalog. To learn more, follow Databricks on [LinkedIn](https://www.linkedin.com/company/databricks), [X](https://x.com/databricks), [YouTube](https://www.youtube.com/@Databricks), and [Instagram](https://www.instagram.com/databricksinc/?hl=en).

**Benefits

**At Databricks, we strive to provide comprehensive benefits and perks that meet the needs of all of our employees. For specific details on the benefits offered in your region click [here](https://docs.google.com/document/d/154un3e8Xav4BceOSlcYFZRGEuQI54xMxVydRwQn54eQ/edit?usp=sharing).

**Our Commitment to Diversity and Inclusion**

At Databricks, we are committed to fostering a diverse and inclusive culture where everyone can excel. We take great care to ensure that our hiring practices are inclusive and meet equal employment opportunity standards. Individuals looking for employment at Databricks are considered without regard to age, color, disability, ethnicity, family or marital status, gender identity or expression, language, national origin, physical and mental ability, political affiliation, race, religion, sexual orientation, socio-economic status, veteran status, and other protected characteristics.

**Compliance**

**If access to export-controlled technology or source code is required for performance of job duties, it is within Employer's discretion whether to apply for a U.S. government license for such positions, and Employer may decline to proceed with an applicant on this basis alone.**

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
