# Abteilungsleiter / Department Manager (m/w/d)

Posted: 2026-09-08T11:00:33Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**​​​​​​​Für unseren Reserved Store in Hamburg suchen wir ab sofort einen Department Manager / Abteilungsleiter (m/w/d) in Vollzeit.**

Du bist eine leidenschaftliche Führungskraft, die etwas bewegen möchte. Du betreust ein motiviertes Team und managst die Herausforderungen deiner Abteilung eines großen Fashion-Stores.

Reserved ist eines der am schnellsten wachsenden Fashion-Unternehmen. Wir kombinieren die neuesten Modetrends mit zukunftsweisenden Technologien.

## Aufgaben

- Als Führungskraft auf der Verkaufsfläche führst du deine Abteilung zum Erfolg

- Du planst und organisierst die Abläufe deiner Abteilung

- Deine Mitarbeitenden führst du fair und engagiert

- Du sorgst für die Einhaltung der Vorgaben und Qualitätsstandards deiner Abteilung

- Mit dem Managementteam arbeitest du vertrauensvoll zusammen

- Du sorgst für eine angenehme Shopping- und Arbeitsatmosphäre

## Qualifikation

-

Erfahrung im (Textil-) Einzelhandel und erste Führungserfahrung

-

Motivierend und inspirierend

-

Bereit Verantwortung zu übernehmen und Entscheidungen zu treffen

-

Actiongeladen und aufgeschlossen

-

Unternehmerisch handelnd und Hands-on

-

Affinität zu modernen Technologien, Software und Systemen

## Benefits

- **Work-Life-Balance:** 30 Urlaubstage für die perfekte Auszeit von der Arbeit

- **Moderne Arbeitswelt im Einzelhandel:** Innovative Systeme und klare Prozesse

- **Attraktive Rabatte für Mitarbeitende:** 25% auf unser Sortiment und Dresscode Budget

- **Benefit Card:** Monatliche Beladung deiner Pluxee Guthaben-Karte (bis zu 520€ im Jahr)

- **Bike Leasing:** Moderne Mobilität mit unserem attraktiven Bike Leasing Angebot

- **Rabatte bei Partnern:** Exklusive Vergünstigungen für deine Freizeitgestaltung

- **Vorsorge für die Zukunft:** Profitiere von unserer betrieblichen Altersvorsorge für Sicherheit im Alter

**GESTALTE DEINE ZUKUNFT MIT UNS**

Bewirb dich jetzt als Department Manager / Abteilungsleiter (m/w/d) in Hamburg! Reserved räumt allen Menschen gleiche Chancen ein, ohne Ausgrenzung oder Diskriminierung.

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
