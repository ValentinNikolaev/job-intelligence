# Senior Backend Engineer - Energy Management Platform (all genders)

Posted: 2026-08-18T02:30:07Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
