# Intern / Working Student Online Training Translation (Korean speaking)

Posted: 2026-08-17T23:55:48Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Celonis is the global leader in Process Intelligence and the pioneer of Process Mining technology. As one of the world’s fastest-growing enterprise SaaS companies, we are changemakers pushing the boundaries of what’s possible. We invest heavily in advanced AI capabilities—specifically our Process Intelligence Graph—to turn data insights into immediate business action. We believe there is a massive opportunity to unlock global productivity and sustainability by placing intelligence at the core of every business process. Join our mission to make processes work for people, companies, and the planet.

**The Team:**

At Celonis Academy, we design and deliver self-paced online training and instructor-led training to a community of more than 200.000 learners around the world. These learners are predominantly Celonis customers and partners. Throughout everything we do, we always strive for excellence for our learners and we are the very proud winners of two 2025 Brandon Hall Gold Awards!

**The Role:
**
With many thousands of learners worldwide consuming the content Celonis Academy creates, we rely on localization experts to identify localization needs and translate courses and exams for our partners and customers. We hope you’ll join us as one of these localization experts, translating content into Korean. This work accelerates the reach of our training and thus the impact of our product into Korean speaking markets.
As a localization expert, you will work with various subject matter experts to create and translate highly interactive online training content on a large variety of topics. In the process of translation, you will ensure that localized training is adapted to specific cultures and user preferences. Through our feedback channel, you will see the direct impact of your work and will analyze qualitative and quantitative data to continually improve the courses.
You will be part of the Celonis Academy team and report to the Team Lead - Online training.

**The work you’ll do:**

- Translate Celonis Academy training materials, such as courses, hands-on exercises and exams, from English to the target language Korean.

- Review and post-edit machine-translated training materials

- Perform linguistic quality and functionality checks based on the feedback from the learners

- Maintain and update language-specific tools such as translation memory, glossary, and other relevant documentation

- Provide input and feedback for the continuous improvement of translation processes

**The qualifications you need:**

- **Native-speaker level **of proficiency in **English and Korean**

- Study in the field of translation, linguistics, communication, or similar

- Ability to work in a structured manner and quickly comprehend new topics and interrelationships

- Ability to put the learner at the center of everything you do

- Experience with authoring tools is a plus (e.g. Articulate Rise, Thought Industries)

- Experience with Translation Management Systems is a plus (e.g. Transifex, Smartling, GlobalLink, SDLX)

- 6+ months of part-time availability from September 2026 onwards

**What Celonis can offer you:**

- Pioneer Innovation: Work with the global leader in Process Mining and the Process Intelligence Graph to shape the future of AI-driven business operations.

- Ownership from Day 1: Every full-time "Celonaut" is an owner, receiving Restricted Stock Units (RSUs) and merit-based refresh grants.

- Unrivaled Family Support: Benefit from our inclusive parental leave policy—24 weeks of fully paid leave for primary carers and 12 weeks for supporting carers, available from your first day of employment.

- Work-Life Integration: Enjoy Unlimited PTO (in applicable regions) and generous PTO globally, as well as a flexible hybrid work model that balances remote focus with vibrant office collaboration.

- Continuous Growth: Elevate your skills through our 70-20-10 learning framework, mentorship programs, and access to a dedicated learning platform.

- Holistic Well-being: Prioritize your health with subsidized Wellhub memberships, mental health counseling, and dedicated "Wellness Weeks" that prioritize work/life balance.

- Drive Sustainability: Participate in annual Impact Days, where you receive paid time off to volunteer for community and environmental causes with your local office, or virtually.

- Global Inclusion & Belonging: Find community through our Inclusion Think Tank and participate in our annual Inclusion Days, ensuring every voice is heard and valued.

- Value-Driven Impact: Join a mission-led organization where our core values—Live for Customer Value, The Best Team Wins, We Own It, and Earth Is Our Future—drive every decision.

**About Us:**

Celonis makes processes work — for people, companies, and the planet. Powered by process mining and AI, the Celonis Process Intelligence Platform integrates process data and business context to create a living digital twin of business operations. We enable thousands of companies worldwide to understand how their business actually runs and, together with their partners, build intelligent solutions that transform and continuously improve the way they operate — unlocking billions in value. Celonis is headquartered in Munich, Germany, and New York City, USA, with more than 20 offices worldwide.

Get familiar with the Celonis Process Intelligence Platform by watching this [video](https://academy.celonis.com/learn/video/discover-the-ems).

**Celonis Inclusion Statement:**

At Celonis, we believe our people make us who we are and that “The Best Team Wins”. We know that the best teams are made up of people who bring different perspectives to the table. And when everyone feels included, able to speak up and knows their voice is heard - that's when creativity and innovation happen.**
**

**Your Privacy:**

Any information you submit to Celonis as part of your application will be processed in accordance with Celonis’ [Accessibility and Candidate Notices](https://www.celonis.com/careers/candidate-notices)

By submitting this application, you confirm that you agree to the storing and processing of your personal data by Celonis as described in our [Privacy Notice for the Application and Hiring Process](https://www.celonis.com/careers/privacy-notice/).

Please be aware of common job offer scams, impersonators and frauds. Learn more [here](https://www.celonis.com/careers/fraud-alert/).

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
