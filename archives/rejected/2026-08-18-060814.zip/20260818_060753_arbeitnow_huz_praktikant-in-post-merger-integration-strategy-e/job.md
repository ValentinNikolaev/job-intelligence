# Praktikant:in Post Merger Integration & Strategy Execution

Posted: 2026-08-17T23:29:59Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**Position**

Du möchtest direkt mit der COO sowie Head of M&A & PMI der H&Z Group arbeiten und dabei bei Unternehmensakquisitionen, Integrationen sowie strategischen Sonderprojekten unterstützen?
Gleichzeitig hast du Freude daran eigenständig vielfältige Aufgaben - von analytischen Fragestellungen bis hin zur operativen Umsetzung - zu übernehmen?

Dann haben wir genau die richtige Stelle für dich:
**
****PRAKTIKANT POST MERGER INTEGRATION & STRAGETY EXECUTION****
**Vollzeit, ab sofort, mindestens 6 Monate, für unser Münchner Büro

**Was gibt es zu tun?**

- Du unterstützt bei bereichsübergreifenden Post Merger Integration- und Transformationsprojekten
- Dabei übernimmst du eigenständig operativer Arbeitspakete – von der Abstimmung mit internen Funktionen bis zur Umsetzung konkreter Integrationsmaßnahmen
- Teil deiner Tätigkeiten ist die Planung, Koordination und Nachverfolgung von Projektmaßnahmen, Workshops und Management-Meetings
- Du verantwortest die Weiterentwicklung von Methoden, Templates und Playbooks für M&A und PMI
- Dein operativer Aufgabenbereich umfasst unter anderem das Erstellen von Management-Präsentationen, Entscheidungsvorlagen und Kommunikationsunterlagen
- Du führst Markt-, Unternehmens- und Wettbewerbsanalysen sowie Datenaufbereitung durch und entwickelst eigenständig KPI-Dashboards, Reportings und Management-Auswertungen
- Du treibst die Identifikation und Umsetzung von AI Use Cases zur Automatisierung von Research-, Analyse- und Projektmanagementprozessen voran und unterstützt bei strategischen Sonderprojekten der H&Z Group

**Was bringst du mit?**

- Du hast ein abgeschlossenes Bachelor-Studium der Wirtschaftswissenschaften, Wirtschaftsingenieurwesen, Wirtschaftsinformatik oder eines vergleichbaren Studiengangs
- Du bringst erste praktische Erfahrungen im Consulting, Corporate Development, M&A, Venture Capital, Start-up oder Projektmanagementmit
- Du kombinierst deine strukturierte und lösungsorientierte Arbeitsweise mit deinen sehr guten analytischen Fähigkeiten und deinem hohen Maß an Pragmatismus
- Deine Freude Verantwortung zu übernehmen und Dinge eigenständig voranzutreiben zeichnen dich aus und du wechselst gerne zwischen Strategie, Analyse und operativer Umsetzung
- Du hast eine hohe Affinität zu AI, Automatisierung und digitalen Tools (wie n8n oder PowerAutomate)
- Der Umgang mit PowerPoint und Excel fällt dir leicht
- Sehr gute Deutsch- und Englischkenntnisse runden dein Profil ab

**Was bieten wir dir?**

- Einblicke in die Planung und Ausführung von Unternehmensstrategien einer führenden Managementberatung.
- Viel Gestaltungsspielraum und die Möglichkeit, Verantwortung zu übernehmen.
- Direkte Zusammenarbeit mit unserem Leadership, sowie Internen Funktionen und Beratungsteams.
- Ein modernes Arbeitsumfeld, in dem Kreativität, Technologie und unternehmerisches Denken zusammenkommen.
- Die Chance, eigene Ideen einzubringen und sichtbar umzusetzen.
- Regelmäßige Mitarbeiterveranstaltungen
- Tolles Büro im Zentrum von München
- Homeoffice-Option
- Schulungen
- Wöchentlicher Firmen-Jour-Fixe mit Frühstück
- Alle zwei Wochen Studierenden-Jour-Fixe mit Einblicken in aktuelle Projekte – für gemeinsames Lernen und frischen Austausch
- Getränke, Obst und Joghurt im Büro

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
