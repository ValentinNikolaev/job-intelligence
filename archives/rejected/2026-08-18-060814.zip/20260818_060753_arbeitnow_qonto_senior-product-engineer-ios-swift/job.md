# Senior Product Engineer - iOS/Swift

Posted: 2026-08-18T02:04:59Z

## Rejection

- Category: role_mismatch
- Reason: title is an obvious mismatch for a backend profile

**Our mission and customers: **We are creating the freedom for SMEs to succeed by delivering Europe's leading finance workspace with banking at its core, augmented by financial tools. We are proud to be [***rated 4.8 on Trustpilot***](https://www.trustpilot.com/review/qonto.com)***[,](https://www.trustpilot.com/review/qonto.com)****** ***based on 55,000+ reviews. [***Our culture***](https://qonto.com/en/careers/culture)*** ***puts customer satisfaction at the core of what we do, as proven by our Net Promoter Score of 75 *(more about our culture **[here](https://medium.com/qonto-way/the-qonto-way-our-culture-is-our-strategy-90defd4895f9)**).*

**Our journey: **Founded in 2017 by** **[***Alexandre***](https://www.linkedin.com/in/aprot/) and [***Steve***](https://www.linkedin.com/in/steveanavi/)***,*** Qonto has grown to 1,600+ Qontoers serving over 600,000+ customers across 8 European countries. We have been profitable since 2023, and we are just getting started.

**Our beliefs: **We hire for skills and potential. With 80+ nationalities, 45% women, of which 56% of women in our leadership team, diversity isn't a program; It's who we are. [***We've built a discrimination-free hiring process***](https://medium.com/qonto-way/a-recruiters-dilemma-confronting-bias-in-hiring-b78acce148eb) because the best teams are built on merit.

**AI at Qonto: **AI is deeply embedded in how we work (**[*here*](https://medium.com/qonto-way/ai-at-qonto-vision-statement-725a7e2f659b)**)* - *Every Qontoer gets unlimited access to the best AI tools. We want people who experiment without waiting for permission, push AI beyond the obvious, know when to trust it, and when to question it.

------------------------------------------------------------------------------------------------------

*Location: You can choose to work at Qonto as long as you're living in (or willing to relocate to) either Germany, France, Italy, Serbia, Portugal, or Spain.*

**Mission**

Join us as an **iOS Engineer** and help us build the most intuitive mobile banking experience for European businesses. You'll be crafting features that directly impact the daily financial operations of **over 600,000 SMEs across Europe**, making their business finance simpler and more efficient.

**As an iOS Engineer at Qonto, you will:**

• **Craft cutting-edge financial features**: Work on critical architectural and UI features that will directly impact our end users.

• **Foster meaningful collaboration**: Work closely with back-end teams, designers, and product managers to create a unified vision.

• **Solve real-time challenges**: Tackle real-time synchronization issues and spearhead new initiatives.

• **Champion quality**: Maintain an exceptional level of quality by implementing continuous refactoring and unit testing to consistently enhance the codebase.

**What you can expect**

• You'll be building for Europe's fastest-growing business banking market, with 600K+ clients across multiple countries and ambitious expansion plans

• Work in an environment that prioritizes quality, comprehensive code reviews, component approach and continuous refactoring as standard practice

• Contribute to a fully Swift-based app using MVP and Coordinators architecture, with modern CI/CD through GitHub, Firebase, and Bitrise

• Access to expert mentorship, Tech Weeklies & Monthlies, and conference opportunities to stay at the forefront of iOS development

Our methodology, the [Qonto Way](https://medium.com/qonto-way/tagged/the-qonto-way)

We value upfront technical design, team reviews, and smart slicing, quality drives the velocity our customers need;

Our org assigns one team lead per project across stacks, giving your team a clear mission and full autonomy on how it operates;

Our **lean toolbox**, [Kaizen](https://medium.com/qonto-way/qonto-way-strong-engineering-culture-prt1-kaizen-spirit-7e6e0a17c07e), PDCA, lets you monitor and drive continuous improvement collaboratively with your peers and manager;

Each engineer gets access to Cursor or Copilot, and we want people who use AI to **raise the bar, not just to go faster.**

**Your future team**

As an IOS Engineer, you will join one of Qonto's **squad teams**, each organised around a clear project mission, with one team lead and full ownership of a product scope. You'll be part of a 140 mobile engineering community within a 500 Product Engineering department, working in focused teams of 5 to 10 people alongside Product, Design, and peers from Frontend and Backend.

**Our stack & practices**

Our app is 100% Swift, built on MVP & Clean Architecture with 35+ independent modules. We use the Coordinator pattern for scalability, and all new screens are built in SwiftUI (MVVM) with async/await — 80+ screens already migrated. Project generation and build optimization run on Tuist. CI/CD covers GitHub Actions, Bitrise, Firebase Test Lab, Sonar, and Fastlane.

We take technical excellence seriously: 30,000+ unit tests, 450+ snapshot tests, SwiftyMocky for mock generation, and LLMs integrated into our dev workflow. Our modular architecture (32 reusable modules + centralized design system) ensures fast builds, clear ownership, and safe iterations.

Want to know more about our mobile performance indicators? Read [this](https://medium.com/qonto-way/mobile-developers-are-you-performing-4f28f927b771).

**
About You**

• **iOS Expertise**: Proven experience as a **Mobile engineer **with strong **Swift** skills and deep understanding of the **iOS ecosystem**, SDK, and development lifecycle

• **Quality-driven development**: Strong commitment to best practices, including unit testing (XCTests, FBSnapshots), Clean code / SOLID principles, and organized workflows

• **Problem-solving approach**: Pragmatic and solution-oriented approach to engineering challenges, with ability to deliver tangible value in a fast-paced environment

• **Collaborative spirit**: Excellent communication skills, **fluent english** and experience working effectively in cross-functional teams with both technical and non-technical colleagues

• **Growth mindset**: Curious and proactive developer who thrives on learning new technologies and contributing to a product serving hundreds of thousands of users

*At Qonto, we understand that true diversity isn’t just about ticking boxes on a hiring checklist. Apply regardless of the boxes you tick — who knows? You may have the missing piece of the puzzle we’ve been searching for all along.*

*By applying, you agree that Qonto processes your personal data to assess your application. Your data is kept for up to 2 years in our candidate pool. Read our [Privacy Notice](https://qonto.com/en/legal-documents/privacy-notice) for full details.*

------------------------------------------------------------------------------------------------------

On average, **our hiring process lasts ****20 working days****. **More information on our candidate journey ***[here](https://qonto.com/en/careers/candidate-journey)***

------------------------------------------------------------------------------------------------------

**🔒 Your security matters to us**

Recruitment scams are on the rise. Keep in mind, we will never work with third-party platforms or agencies that request payment from candidates.

If you receive a suspicious message claiming to be from Qonto, please report it right away (

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
