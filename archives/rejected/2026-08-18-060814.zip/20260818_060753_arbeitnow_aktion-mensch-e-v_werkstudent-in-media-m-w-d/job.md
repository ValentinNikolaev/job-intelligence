# Werkstudent*in Media (m/w/d)

Posted: 2026-08-17T23:29:48Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**WIR suchen dich!**

Du interessierst dich dafür, wie große Werbekampagnen effizient gesteuert werden und kannst gut mit Zahlen und Daten umgehen? In unserem Team dreht sich alles um die performance-getriebene Mediaplanung für verschiedene Angebote der Aktion Mensch. Es erwarten dich datengetriebene, crossmediale Kanäle und die Chance, den Erfolg unserer Kampagnen aktiv mitzugestalten.

**Tu, was du liebst**

- Du begleitest die Mediaplanung von Vorbereitung bis Freigabe unserer crossmedialen Kampagnen (u. a. TV, Digital, Social Media, Out-of-Home, Radio).
- Du unterstützt beim Erstellen von Tabellen, Aufbereiten von Daten und die Vorbereitung von Reportings.
- Du unterstützt bei Recherche-Aufgaben, beobachtest den Markt sowie die Werbeaktivitäten anderer Wettbewerber und leitest daraus erste spannende Impulse für unsere eigenen Platzierungen ab.

**Zeig, was du kannst**

- Du studierst Medien-/Kommunikationswissenschaften, Marketing, BWL oder einen vergleichbaren Studiengang, brennst für digitale Medien und bist noch für mindestens zwei weitere Semester eingeschrieben.
- Du zeichnest dich durch eine hohe Eigeninitiative aus, bist offen, denkst proaktiv mit und arbeitest gerne selbstständig an kleineren Projekten. Deine Motivation, dich in neue Themen einzuarbeiten, treibt dich an.
- Du kennst die gängigen Media-Plattformen nicht nur als Nutzer*in, sondern verstehst auch wie Kampagnen dort funktionieren. Du hast idealerweise schon erste Erfahrungen im Media- oder Marketingbereich sammeln können.
- Du verfügst über ein Grundverständnis des Media-Mix und Begriffe wie Reichweite (Reach), Impressionen, Klicks oder Conversion sollten keine Fremdwörter sein.
- Du arbeitest sorgfältig, zuverlässig und selbstständig.
- Du verfügst über einen sicheren Umgang mit MS Office (insb. Excel und PowerPoint).
Vorwissen ist gut, aber deine Einstellung ist uns wichtiger: Wenn du eine strukturierte Arbeitsweise, eine hohe Eigenmotivation und Lust auf datengetriebenes Media-Management mitbringst, begleiten wir dich von Anfang an intensiv und geben dir gleichzeitig den Freiraum, schnell eigenständig zu wachsen.

**Unser Erfolgsrezept: Das WIR gewinnt**

- Ein Werkstudentenjob, bei dem du mit Spaß und flexibler Zeiteinteilung wirklich etwas Gutes bewegen kannst.
- Flexible Arbeitszeiten (15-20 Stunden die Woche), die sich perfekt mit deinem Studium vereinbaren lassen – du hast auch die Möglichkeit anteilig von zu Hause aus zu arbeiten.
- Faire Vergütung: 14 € pro Stunde.
- Wir stellen dir ein Surface zur Verfügung sowie individuelle Hilfsmittel bereit, damit barrierefreies Arbeiten möglich ist.
- Ein positives, offenes und nachhaltiges Arbeitsumfeld, in dem Teamgeist großgeschrieben wird und dazu eine ♥️-Arbeitsatmosphäre.

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
