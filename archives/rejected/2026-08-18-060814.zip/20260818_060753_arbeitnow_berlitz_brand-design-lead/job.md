# Brand Design Lead

Posted: 2026-08-17T23:40:17Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

We're building a new global Berlitz, and this is your opportunity to help shape it. Nearly 150 years of expertise, meeting the ambition and technology to power a new era of learning.

If you are the kind of person who thrives in a fast-paced environment, isn’t afraid of a blank page, and is excited to help shape the future of a global company undergoing a significant transformation, **you might belong at Berlitz!**

Berlitz's brand hasn't had a dedicated design owner. Guidelines exist, but they haven't kept pace with the business, and different countries and franchise partners have drifted in their own directions for years. At the same time, Berlitz is repositioning: leaning further into B2B, selling to mid-market managers and enterprise HR leaders who evaluate us through formal, multi-region buying processes, alongside the individual learners we've always served. The brand needs to hold its own in both worlds.

There's one hard constraint: the name and logo aren't changing. Everything else, typography, color, imagery, how the brand shows up across product, marketing, and sales, is genuinely open.

As Brand Design Lead, you'll own that work end to end, reporting directly to the VP of Design. You'll partner closely with Marketing on brand strategy, but you'll own how that strategy actually looks and feels everywhere it shows up. You'll also work alongside the product design team to make sure brand and product pull in the same direction, extending our shared design system rather than working apart from it.

## What you'll be doing

-

Own brand guidelines and visual identity end to end: typography, color, imagery, and motion, documented clearly enough that a global, multi-country organization can actually follow them.

-

Partner with Marketing on brand strategy, and own how that strategy translates into what people actually see, feel, and use.

-

Help regional teams and franchise partners stay genuinely on-brand, but with local sensitivity, through guidelines and buy-in, not policing after the fact.

-

Extend Berlitz's shared design system with brand-level tokens and patterns, working directly with the product design team.

-

Make the brand read as credible and premium to enterprise buyers running formal RFPs, not just to individual learners comparing consumer apps.

-

Shape how the brand shows up across product, marketing, and sales, from the product interface to the materials enterprise buyers see over a long buying cycle.

-

Bring real visual craft to a brand that hasn't had a dedicated owner: campaigns, sales materials, internal communications, and whatever else the brand touches.

-

Manage freelancers or agencies where the work calls for it, without losing ownership of quality or direction.

-

Mentor other designers at Berlitz on brand thinking as the design team grows.

## What we're looking for

-

A proven track record building or substantially evolving a brand identity system, not just working within one someone else built.

-

Real experience with B2B or enterprise brand work: brands that need to read as credible and premium to a buying committee, not just appealing to an individual consumer.

-

AI native experience. You're already deep in context engineering, MCP, generative design tools, and thinking in systems that support that. Using AI as a partner, not a substitute.

-

Experience designing guidelines that hold up across a large, distributed, or multi-country organization, including places where local teams have historically gone their own way.

-

Strong typographic, color, and visual craft, with the judgment to hold a fixed constraint, like a name or logo that isn't changing, and make everything else work harder around it.

-

Comfort partnering with Marketing on strategy while owning execution yourself.

-

The confidence to bring structure and taste to a brand that's never had a dedicated design owner before.

-

Fluent English.

## What we offer

-

**Shape the next chapter of a true heritage brand.** Berlitz has almost 150 years of history and no dedicated design owner. You'll set the direction, not maintain someone else's.

-

**Real constraints, real freedom.** The name and logo aren't changing. Nearly everything else is open.

-

**Direct partnership with the VP of Design**, and real influence over how Berlitz shows up everywhere from product to sales.

-

**One global Berlitz.** Join a company actively rebuilding itself, with new products, new systems, and new ways of working across every team.

-

**Remote-first flexibility**, based anywhere in Germany, Switzerland, Hungary, Spain, Portugal, Bulgaria, Cyprus, Estonia, Greece, Italy, Latvia, Lithuania or Malta.

*At Berlitz, connecting people across languages and cultures is at the heart of what we do. Our global workplace reflects the diverse world we serve, bringing together different backgrounds, experiences and perspectives. We create an inclusive environment where everyone has an equal opportunity to belong, contribute and grow.*

Ready to shape what’s next? Join us and help build the future with us.

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
