# Werkstudent ERP-Projektmanagement (m/w/d)

Posted: 2026-08-17T23:29:59Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**Position**

Du möchtest ein ERP-Projekt unterstützen und dabei Verantwortung in einem agilen Umfeld übernehmen? Du arbeitest gerne eigenständig, gehst proaktiv auf interne Ansprechpartner zu und behältst auch bei operativen Themen den Überblick?

Dann haben wir genau die richtige Stelle für dich:
**
****WERKSTUDENT ERP-PROJEKTMANAGEMENT (w/m/d)****
**Teilzeit, ab sofort, mindestens 6 Monate, für unser Münchner Büro

**Was gibt es zu tun?**

- Du unterstützt bei der Pflege von Daten und Informationen im ERP-System und trägst zur Sicherung sowie Verbesserung der Datenqualität bei
- Du übernimmst PMO-Aufgaben und unterstützt die Projektleitung bei administrativen und operativen Themen
- In deiner Rolle stimmst du dich zu laufenden operativen Fragestellungen mit internen Stakeholdern ab
- Teil deiner Verantwortung ist die Unterstützung bei Rückfragen von Usern zum ERP-System, womit du für eine verlässliche Bearbeitung sorgst
- In deiner Rolle begleitest und verantwortest du die Analyse und Lösung technischer Fehler und koordinierst dich dabei bei Bedarf mit unserem Implementierungspartner
- Ein wichtiger Bestandteil deiner Tätigkeit ist die Pflege des zentralen Informationskanals rund um das ERP-System auf SharePoint wobei du sicher stellst, dass relevante Informationen aktuell und auffindbar sind
- Du arbeitest in einem agilen Projektumfeld mit und bringst eigene Ideen zur Verbesserung von Abläufen ein

**Was bringst du mit?**

- Idealerweise bist du in einem wirtschaftsnahen, technischen oder informationstechnologischen Studiengang immatrikuliert
- Du arbeitest proaktiv, eigenständig sowie lösungsorientiert und übernimmst Verantwortung für deine Aufgaben
- Eine strukturierte, zuverlässige und sorgfältige Arbeitsweise zeichnet dich aus
- Du hast Freude daran, mit unterschiedlichen internen Ansprechpartnern zusammenzuarbeiten, und gehst offen auf Menschen zu
- Du bringst eine ausgeprägte Toolaffinität mit und arbeitest dich schnell in neue Systeme und Anwendungen ein
- Du gehst vertrauensvoll und verantwortungsbewusst mit Informationen um
- Erste Erfahrungen mit ERP-Systemen, SharePoint oder Projektmanagement-Tools sind hilfreich, aber keine Voraussetzung
- Du arbeitest gerne im Team und behältst auch bei mehreren parallelen Themen den Überblick

**Was bieten wir dir?**

- Einblicke in die Planung und Ausführung von ERP Lösungen in einer führenden Managementberatung.
- Viel Gestaltungsspielraum und die Möglichkeit, Verantwortung zu übernehmen.
- Direkte Zusammenarbeit mit unserem Projektteam, sowie Internen Funktionen und Beratungsteams.
- Ein modernes Arbeitsumfeld, in dem Kreativität, Technologie und unternehmerisches Denken zusammenkommen.
- Die Chance, eigene Ideen einzubringen und sichtbar umzusetzen.
- Regelmäßige Mitarbeiterveranstaltungen
- Tolles Büro im Zentrum von München
- Homeoffice-Option
- Schulungen
- Wöchentlicher Firmen-Jour-Fixe mit Frühstück
- Alle zwei Wochen Studierenden-Jour-Fixe mit Einblicken in aktuelle Projekte – für gemeinsames Lernen und frischen Austausch
- Getränke, Obst und Joghurt im Büro

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
