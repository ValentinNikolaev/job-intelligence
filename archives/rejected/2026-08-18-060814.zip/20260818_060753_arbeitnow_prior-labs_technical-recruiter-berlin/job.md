# Technical Recruiter (Berlin)

Posted: 2026-08-18T02:40:23Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

## Who we are

Foundation models transformed text and images. Structured data - the largest and most consequential data format in the world - stayed untouched, until now. What LLMs did for language, we're doing for tables.

We pioneered tabular foundation models: TabPFN v2 was a [Nature](https://www.nature.com/articles/s41586-024-08328-6) cover story, has passed 3.5M+ downloads and 7,500+ GitHub stars, and runs in production from [detecting lung disease with Oxford Cancer Analytics](https://www.oxcan.org/news/prior-labs-and-oxford-cancer-analytics-partner-to-advance-liquid-biopsy-and-clinical-decision-making-in-lung-disease) to [preventing train failures with Hitachi](https://siliconangle.com/2025/12/01/prior-labs-debuts-tabular-ai-foundation-model-scales-10-million-rows/). The hardest problems - millions of rows, real-time inference, entirely new modalities - are still open, and no one else is working on them at this level.

We're a [small, highly selective team of 40+](https://priorlabs.ai/about) with backgrounds from Google, DeepMind, Meta, Apple, Amazon, Jane Street, and CERN, led by [Frank Hutter](https://www.linkedin.com/in/frank-hutter-9190b24b/), [Noah Hollmann](https://www.linkedin.com/in/noah-hollmann-668b9010b/), and [Sauraj Gambhir](https://www.linkedin.com/in/sauraj-g/), and advised by Bernhard Schölkopf and Turing Award winner Yann LeCun.

In July 2026, less than 18 months after our €9M pre-seed, we [joined SAP](https://priorlabs.ai/blog-posts/priorlabs-sap) as an independent frontier AI lab - same team, mission, and open-weights models, now backed by more than €1 billion over four years.

### About the Role

We're hiring a technical recruiter to own hiring across Science, Engineering and Data Science. These are three distinct talent markets with three distinct assessment bars, and you'll own all of them end-to-end. We're scaling fast, and competing directly with the best-funded labs in the world for the same people.

### Your Responsibilities

-

Source scarce ML research, infrastructure, and forward-deployed talent globally, exploring mainstream and niche talent pools

-

Position Prior Labs compellingly against other foundation model labs such as OpenAI, Anthropic, DeepMind, and Mistral and against the enterprise AI companies competing for FDE talent

-

Navigate multi-hub hiring across Freiburg, Berlin, and New York (visas, comp bands, notice periods)

-

Screen technical depth quickly across research, engineering, and customer-facing profiles without burning researcher or founder time

-

Run efficient, structured interview loops with clear rubrics and fast debriefs, calibrated separately for research, engineering, and FDE archetypes

-

Manage, negotiate and close offers, including against competing frontier-lab packages

-

Manage the pipeline operationally in the ATS with clean stages and weekly metrics

### The experience we are looking for

-

5+ years in-house technical recruiting at a deep-tech, AI/ML, or research-led startup (Series A and ), or in a frontier lab's talent team

-

Track record closing ML researchers or research engineers against top tier frontier labs (e.g. OpenAI, Anthropic, DeepMind, Mistral)

-

Experience hiring at least one customer-facing engineering profile (forward deployed, solutions, or applied engineering) — the assessment bar is different and you'll need to know why

-

Hands-on hiring across at least two of: Germany, wider EU, and the US (NYC)

-

Fluency in the ML talent landscape: top labs, conferences (NeurIPS, ICML, ICLR, AutoML), and what distinguishes a strong research vs. engineering vs. infrastructure profile

-

Modern ATS architecture (Ashby or equivalent): stage design, rejection taxonomy, funnel reporting

###

### The behaviours we want you to bring everyday to the office

-

High agency and ownership and operates as a full stack recruiter

-

Direct and commercially honest with both candidates and hiring managers

-

Detail-obsessed on pipeline hygiene and weekly metrics; treats the ATS as a source of truth

**Location:** 5 days a week based in our Berlin Office (near Rosa-Luxemburg-Straße U-Bahn Station)

## Life at Prior Labs

You'll work alongside researchers and builders who hold themselves to a very high bar - in the quality of their work and in how they work with each other. We move fast and still take the time to do things right.

Our teams are based in Berlin, Freiburg, and New York - when you're working on something as hard as TabPFN, being in the same room matters. But great people come from everywhere, and in exceptional cases we're open to remote, which usually means frequent travel to one of our offices. Wherever you're based, the whole company comes together regularly for offsites to build and celebrate together.

## Our Commitments

The best products and teams are built by people with a wide range of perspectives and backgrounds. We welcome applications from all identities and walks of life - especially if you've ever felt discouraged by "not checking every box" - and provide equal opportunities regardless of gender, sexual orientation, origin, disability, or any other trait that makes you who you are.

We care about how your data is handled - see our [Recruiting Data Privacy](https://priorlabs.ai/recruiting-data-privacy) page

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
