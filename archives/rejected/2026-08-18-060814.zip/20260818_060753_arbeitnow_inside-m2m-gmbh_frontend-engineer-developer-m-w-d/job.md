# Frontend Engineer, Developer (M/W/D)

Posted: 2026-08-18T02:30:06Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

#### Was wir tun

Als IoT Pioniere entwickeln wir mit mittlerweile über 40 Kollegen*innen an drei Standorten IoT-Komplettlösungen für unsere Kunden.
Aktuell sind weltweit über 500.000 Geräte und Anlagen mit unseren Lösungen für Machine-to-Machine-Kommunikation ausgestattet.

Unsere Kompetenz liegt in der Entwicklung kundenspezifischer IoT-Lösungen, basierend auf unserer Erfahrung, unseren erprobten Software-Bausteinen und einer Vielzahl von bereits realisierten Projekten.

#### Unser Team

Seit der Firmengründung im Jahr 2004 sind wir stetig gewachsen und haben uns in diesem Markt über die Jahre als starker Partner etabliert.
Damit das auch so bleibt, erweitern wir kontinuierlich unser Team mit talentierten und qualifizierten Entwickler*innen.
Durch vielseitige Weiterbildungsmöglichkeiten, Teilnahme an Konferenzen und Workshops sowie eine ausgeprägte Feedback-Kultur heben wir unser Team auf die nächste Stufe.
Zur Verstärkung unseres Frontend-Teams suchen wir zum nächstmöglichen Zeitpunkt eine(n) Frontend Developer (M/W/D) an den Standorten **GARBSEN** (bei Hannover) und **BISSENDORF** (bei Osnabrück).

#### Deine Aufgaben als Frontend Engineer

-

Du planst und entwirfst Anwendungen für unsere Kunden im M2M / IoT-Umfeld

-

Du evaluierst neue Technologien, um unsere eigenen Produkte kontinuierlich zu verbessern.

-

Du entwickelst Software im Team mit Tools wie Node, Docker, GitLab, JIRA, Confluence u.a.

-

Du entwickelst Frontend-Applikationen in Angular

-

Du programmierst hochwertige und gut getestete Software.

-

Du wirkst bei der erfolgreichen Inbetriebnahme der entwickelten Software beim Kunden mit.

-

Du betreust und unterstützt unsere Kunden bei laufenden Projekten.

-

Du verfügst über ein abgeschlossenes Studium oder eine abgeschlossene Berufsausbildung in den Bereichen Informatik, Interface Design, Medien Design, Grafikdesign oder einem vergleichbaren Bereich.

-

Erfahrung in folgenden Gebieten:

-

ausgeprägte Kenntnisse in HTML, CSS

-

ausgeprägte Kenntnisse in Angular

-

E2E Testing mit Cypress oder Playwright

-

gute Kenntnisse in TypeScript

-

Reaktives Statemanagement

-

App Entwicklung mit Ionic

-

Git

-

Docker

-

Grafikdesign, Adobe XD

-

Du arbeitest eigenverantwortlich, ziel- und lösungsorientiert.

-

Teamfähigkeit und Qualitätsbewusstsein zeichnen Dich aus.

-

Du verfügst über fließende Deutsch- und Englischkenntnisse.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
