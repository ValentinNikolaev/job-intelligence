# Channel Director EMEA

Posted: 2026-08-18T02:24:59Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

*FireMon has learned an unknown and unauthorized third party is impersonating FireMon HR as part of a phishing attempt. Communications from FireMon will always originate from the *[*FireMon.com*](http://firemon.com/)* domain. FireMon will never ask for any banking information as part of an interview process. If you are concerned whether a communication from FireMon is legitimate, please contact us at *

As the Channel Director you’ll lead the growth and performance of FireMon’s channel ecosystem. You will recruit, enable, and develop key reseller relationships that drive joint success in the mid-to-large enterprise market. Working closely with partners, you’ll help shape go-to-market strategies, create demand across our cybersecurity solutions, and accelerate revenue growth throughout the region.

**About the role**

- Identify, recruit, and onboard high-performing reseller and distribution partners across UK&I and EMEA.

- Drive joint business plans, enablement initiatives, and pipeline development to achieve territory growth targets.

- Collaborate with partners to deliver impactful end-user engagement — including co-selling, presentations, events, and training sessions.

- Strengthen partner capability and alignment through education, marketing collaboration, and strategic planning.

- Represent FireMon at trade shows, partner summits, and key industry events.

- Gather market and competitive insights to inform product positioning and partner strategy.

- Partner closely with regional sales teams to exceed monthly and quarterly booking goals.

- Must be comfortable with 50% travel.

**Required Skills and Experience **

- Bachelor’s degree in Business, Information Technology, or a related field.

- Proven experience leading channel or territory management in cybersecurity or network security software.

- Established relationships with distributors such as Exclusive Networks (preferred).

- Strong business acumen and a track record of building trusted, revenue-generating partnerships.

- Excellent communication and presentation skills, with the ability to influence both technical and executive stakeholders.

- A self-starter mentality with strong organizational skills — capable of driving results across multiple priorities.

- A collaborative, positive approach to teamwork and partner success.

What it Takes to be Part of the FireMon Team

FireMon provides persistent network security for hybrid environments through a powerful fusion of real-time asset visibility, continuous compliance, and automation. Since creating the first-ever network security policy management solution, FireMon has delivered command and control over complex network security infrastructures for more than 1,700 customers.

Our customers have unique and complex security problems that are difficult to solve. This doesn’t intimidate us, it inspires us. It pushes us to be more creative and find solutions to ensure their success. If this sounds like a movement you'd be interested in joining, we invite you to apply today.

FireMon provides equal employment opportunities to all employees, and applicants for employment, and prohibits discrimination and harassment of any type without regard to race, religion, age, sex, national origin, disability status, genetics, protected veteran status, sexual orientation, gender identity or expression, or any other characteristic protected by federal, state or local laws.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
