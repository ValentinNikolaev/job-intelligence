# Leitung Buchhaltung (m/w/d)

Posted: 2026-08-18T05:00:51Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**Über uns:**

Von **Rettungsfahrzeugen bis zu Bestattungswagen**: MIESEN steht seit Jahrzehnten für **Qualität, Präzision und Zuverlässigkeit „Made in Germany“**. Unsere Sonderfahrzeuge leisten jeden Tag einen wichtigen Beitrag für Gesellschaft, Sicherheit und Würde. Als einer der erfahrensten Aufbauhersteller in Deutschland entwickeln und fertigen wir Fahrzeuge, auf die sich Menschen in besonderen Momenten verlassen können. Wir vermarkten unsere Produkte erfolgreich in Deutschland und weltweit.

**Arbeiten bei MIESEN heißt: Technik zu bauen, die wirklich gebraucht wird.**

**Was uns ausmacht**

- **Sinnstiftende Produkte** mit gesellschaftlicher Relevanz

- **Individuelle Lösungen** statt Seriendenken

- **Ergonomische Konzepte**, die den Arbeitsalltag unserer Kunden spürbar erleichtern

- **Kurze Entscheidungswege** und echte Mitgestaltungsmöglichkeiten

- Ein respektvolles, kollegiales Miteinander

## Aufgaben

Wir suchen einen motivierten Buchhalter (m/w/d), der bereit ist, über das klassische Tagesgeschäft hinauszugehen.

**Ihre Aufgaben:**

- Durchführung präziser Kontenabstimmungen sowie Steuerung des Mahnprozesses

- Erstellung und termingerechte Abgabe monatlicher Umsatzsteuervoranmeldungen sowie weiterer statistischer Meldungen

- Betreuung und Verwaltung der Anlagenbuchhaltung

- Verantwortung für die Debitorenbuchhaltung, die Ausgangsrechnungen sowie die Kontrolle und strukturierte Abwicklung der Verkaufsaufträge in Zusammenarbeit mit dem Vertrieb

- Ausarbeitung von Verbesserungspotentialen in den Abläufen unseres ERP-Systems im Zusammenwirken mit der Kaufmännischen Leitung

- Mitwirkung bei den Vorbereitungen für Jahresabschlüsse

## Qualifikation

**Ihr Profil:**

- Abgeschlossene kaufmännische Ausbildung, idealerweise ergänzt durch eine Qualifikation als Finanzbuchhalter (m/w/d), Bilanzbuchhalter (m/w/d) oder ein vergleichbares betriebswirtschaftliches Studium

- Umfassende Berufserfahrung in der Finanzbuchhaltung – präzise Kenntnisse sind Ihre Stärke

- Sicherer Umgang mit DATEV sowie fundierte Erfahrung im Bereich ERP-Systeme; technisches Verständnis für MS Office-Anwendungen

- Kenntnisse des DATEV-Kontenrahmens SKR 03 und ERP-Systems Tetra T4 von Vorteil, aber nicht zwingend erforderlich

- Affinität zu IT-basierten Prozessen sowie Interesse an digitalen Lösungen zur Optimierung bestehender Systeme

- Strukturierte Arbeitsweise gepaart mit analytischem Denken; Zuverlässigkeit ist selbstverständlich für Sie

- Erste Führungserfahrung oder großes Potenzial, sich in Führungsaufgaben einzubringen

## Benefits

**Was wir Ihnen bieten:**

Unser Unternehmen steht nicht nur für Stabilität, sondern auch für Wachstum: Hier können Sie langfristig Fuß fassen. Wir bieten Ihnen:

- Vielfältige Aufgabenbereiche mit Raum zum Gestalten von Prozessen

- Flexible Arbeitszeiten

- **Mobilität:** Nutzen Sie unser **Jobrad-Leasing** für Ihren Weg zur Arbeit

- **Verpflegung:** In unserer **betriebseigenen Kantine** erwarten Sie täglich frische und vergünstigte Mahlzeiten

- **Zukunftsvorsorge:** Wir unterstützen Sie mit einer **betrieblichen Altersvorsorge,** damit Sie auch langfristig abgesichert sind

- Firmeneigene Parkplätze

Werden Sie Teil unseres engagierten Teams! Bei uns erwarten Sie vielfältige Entwicklungsmöglichkeiten.

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
