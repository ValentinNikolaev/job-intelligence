# Mid Level Cloud Engineer (all genders) - 100 % Remote

Posted: 2026-08-17T20:10:10Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**Über uns**

Wir bei iits bieten unseren Kunden individuelle Softwarelösungen, da jedes Unternehmen einzigartig ist und eigene Ziele und Herausforderungen hat. Dies ermöglichen wir durch die technische Expertise unserer Teams, welche die Geschäftsprozesse der Kunden tagtäglich optimieren und eine maßgeschneiderte Digitalisierung ermöglichen. Wir haben es uns zur Mission gemacht, Visionen zum Leben zu erwecken, einzelne Anforderungen zu verstehen und innovative Software zu entwickeln.

**Deine Aufgaben**

Du hast erste fundierte Berufserfahrung im CloudOps-Umfeld und Kubernetes, Terraform und Pipelines gehören zu deinem Arbeitsalltag? Du willst Verantwortung übernehmen und dich mit Expertise beweisen? Und dabei mit Kolleg*innen arbeiten, die Cloud-Infrastruktur seit Jahren bauen und betreiben?

Dann werde unser neuer **Cloud Engineer (all genders)**! Die Vollzeit-Anstellung ist **ab sofort**, **remote** aus **ganz Deutschland** verfügbar.

**Dein Profil**

- Du hast Cloud Infrastruktur im produktiven Betrieb operativ begleitet, nicht nur in Testumgebungen.
- Du hast Infrastruktur bereits als Code beschrieben und willst darin besser werden.
- Du hast Workloads auf Kubernetes ausgerollt und kannst eigenständig nachvollziehen, was im Cluster passiert.
- Du hast mit bestehenden CI/CD-Pipelines gearbeitet und sie erweitert.
- Du automatisierst lieber, als etwas ein zweites Mal von Hand zu machen.
- Du arbeitest Probleme eigenständig durch und holst dir selbstverständlich eine zweite Meinung aus dem Team, wenn du bei einem Lösungsweg unsicher bist oder nicht weiterkommst.
- Du arbeitest dich gerne in neue Technologien ein, auch wenn sie neben deiner aktuellen Aufgabe liegen auch außerhalb deiner Komfortzone.
- Du bist kommunikativ, teamfähig und hast Spaß an der Kommunikation mit Kunden.
- Du hast sehr gute Englischkenntnisse (mind. C1) und optional erste Deutschkenntnisse.
- Du kennst den Softwareengineering Lifecycle und automatisierst gerne Lösungen um Entwicklern und Agenten auf deiner Plattform die Arbeit zu erleichtern
**
Unser Tech-Stack**

- Wir nutzen hauptsächlich Terraform/OpenTofu.
- Als Cloud-Provider werden aktuell Azure, GCP und Telekom Public Cloud genutzt.
- Für die CI Pipelines nutzen wir unter anderem Gitlab CI, GitHub Actions und gelegentlich Azure DevOps Pipelines.
- Unsere Workload wird hauptsächlich auf Kubernetes betrieben und die Manifeste mittels Helm paketiert und ausgeliefert.
- CD Tools unserer Wahl sind Argo CD und FluxCD.
Nice-To-Have: Du hast Erfahrung mit StackIT und/oder Telekom Public Cloud.

**Warum wir?**

• Professionelle Softwareentwicklung und Architektur

• Flache Hierarchien und agile Denk- & Arbeitsweisen

• Home-Office / ﬂexibler Arbeitsort (inkl. Highend Home-Office Ausstattung)

• Tech-Talks & bezahlte Fortbildungen (u.a. auch Sprachkurse)
• Regelmäßige Firmenevents, Workshops und Teamaktivitäten

• 30 Urlaubstage, Weihnachten & Silvester frei + weitere freie Bildungstage

• Mobilitätsunterstützung (Bahncard 50 + Job Rad)

• Familienpakete (z.B. Zuschuss zu den KITA-Kosten)

• Well-Being Angebote (Yogakurse + Fitness & Wellness Angebote über Wellpass)

**Noch Fragen?**

Dann komm sehr gern auf uns zu! Wende dich sehr gern direkt an unsere Kolleg:innen aus dem Recruiting unter
[**Kununu**](https://www.kununu.com/de/iits-consulting)
** **
**Worth a look! **Auf Kununu bewerten Mitarbeitende sowie Bewerbende Arbeitgeber. Schau gern mal vorbei und überzeug dich selbst.

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
