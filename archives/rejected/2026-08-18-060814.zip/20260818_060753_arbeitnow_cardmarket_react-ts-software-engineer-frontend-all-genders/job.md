# React/TS Software Engineer - Frontend (all genders)

Posted: 2026-08-18T02:29:46Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**Our Vision**

At Cardmarket, people come first.

Our goal is to create a workplace where everyone feels safe, appreciated, and inspired. A place where you enjoy coming to work and feel good about heading home at the end of the day.

Open communication is at the heart of our culture. Only by talking openly about challenges, big or small, can we find solutions together. Cardmarket connects people across continents, regardless of skin colour, origin, religion, nationality, gender, or sexual orientation. We treat everyone equally and expect the same from all applicants. Our strength lies in our diverse perspectives and the shared commitment to move forward together as an inclusive team.

To strengthen our Technology Department, we're currently looking for a dedicated Frontend Developer (React/TypeScript) to join Cardmarket. In this role, you will develop and maintain modern frontend features across our web applications, creating responsive and user-friendly interfaces with React and TypeScript. Working closely with your team, you will improve existing functionality, deliver scalable solutions, and help ensure an excellent user experience for our users.

**Your Responsibilities**

- Participate in the application lifecycle of Cardmarket’s website family

- Design and implement new modules and features
- Develop React+TypeScript components and features
- Maintain and improve existing modules and features

- Implement responsive, user-friendly interfaces that align with UX/UI best practices
- Contribute to improving team processes through regular retrospectives

**Your profile**

- A degree, vocational training, apprenticeship or equivalent experience in software development, programming or related field
- 2+ years of experience building web applications with React and TypeScript
- Solid understanding of modern React development (hooks, component composition, state management and performance considerations)
- Experience developing and maintaining PHP applications is a strong plus
- Good understanding of application architecture and maintainable frontend code structures
- Experience with modern build tools (Vite or similar)
- Knowledge of version control systems (GitLab or similar)
- Experience with the following is a plus:

- Bootstrap
- Docker, CI/CD
- Testing and quality assurance practices

- Fluent in English – verbal and written
- A passion for web applications and an interest in modern digital technologies
- Ability to work independently and carefully, as well as collaboratively within a team, combined with a strong problem-solving attitude
- Creativity, flexibility, quick thinking, and the ability to work effectively in an agile team; experience with Scrum is a plus
- **Presence in Berlin & valid work permit for Germany is required!**

**Why us?**

Imagine a workplace where passion, trust, and personal responsibility are part of everyday working life.
A place where people enjoy coming together, sharing ideas, laughing together, while at the same time working with a high level of professionalism.That’s exactly what you’ll find at Cardmarket.
**
**

- **Your everyday work**
You will work in a full-time position (39 hours per week) at our office in Berlin, a place where creative energy, exchange, and focus come together. At the same time, we offer a hybrid working model and provide you with all the equipment you need for your work.
Thanks to flexible working hours with clearly defined core hours, you can structure your day in a way that allows work and private life to harmonize well.

- **Community & Culture**
We meet each other as equals. An informal, first-name culture is a given, from interns to management. We believe that great results are achieved where people feel seen, heard, and valued.
Our shared passion for trading card games connects us, at work and beyond. It symbolizes what defines us: curiosity, strategy, teamwork, and the drive to continuously challenge ourselves.

- **Vacation & further benefits**
Five weeks of paid vacation as well as a Germany-wide public transport ticket (Deutschlandticket) that supports you flexibly in your everyday life.
A lunch allowance (up to €7.67 per working day) as well as free drinks and snacks are also part of our benefits.

- **Your development matters**
Standing still is not an option for us, at least not in a positive sense.
With a personal annual learning budget of €1,500, we deliberately invest in your development: conferences, courses, books, or new skills. You decide what helps you move forward.

- **Mental & physical health**
We know: Great performance can only happen when people are doing well.
That’s why we support you with an Urban Sports Club membership for your physical balance, our collaboration with DearEmployee, which offers anonymous, professional psychological support, and the Women of Cardmarket & LGBTQIA+ Group, which promotes exchange, visibility, and empowerment.

**In short**
With us, you won’t find anonymous open-plan offices or rigid structures, but a work environment with heart, values, and genuine appreciation, a place where you’re not only allowed to be yourself, but expected to be, take responsibility, and continue developing, professionally and especially personally.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
