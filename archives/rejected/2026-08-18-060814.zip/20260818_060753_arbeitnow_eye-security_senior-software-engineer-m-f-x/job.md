# Senior Software Engineer (m/f/x)

Posted: 2026-08-17T17:40:30Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

## **About Eye Security**

Eye Security is an international scale-up providing cyber security with embedded cyber insurance to SMBs in Europe. Our cyber security innovations, state-of-the-art automation and platforms are being built and maintained by our Product and Engineering Teams. Our engineers and product managers collaborate closely with cyber security experts to ensure that their hacker's mindset is embedded into our platform.

Our platform is a proprietary Open XDR (eXtended Detection Response) system that brings in security data from several market leading cyber security products into our centralised repository. From here cyber security experts can work their magic. This makes sure that our hundreds of customers experience the same value via automated systems, allowing us to scale in Europe.

## **About this role**

We're looking for a Senior Engineer to join one of our stream-aligned engineering teams. At Eye, we organise engineering around streams: mission-driven groups with a clear outcome to drive, not a product area or a section of the codebase. You'll work in a small, full-stack team of 2-3 engineers contributing to your stream's goal, working across whatever systems and layers are needed to deliver it. This is a role for someone who wants real ownership, not a queue of tickets.

## **In this role**

-

Own features end-to-end as Feature Lead: scope the problem, coordinate work within your team, make day-to-day technical decisions, and ship it to production.

-

Deliver high quality features both individually and with other team members, working full-stack across whatever the stream requires.

-

Collaborate with internal stakeholders to design and develop features that deliver real-world value.

-

Contribute to technical decision-making within your stream, including surfacing tradeoffs and risks early.

-

Participate in creating a psychologically safe and happy environment within the team and the company.

-

The role is remote in the Netherlands or in Berlin, but you commit to travelling to the office (The Hague or Berlin) twice per week.

## **What you will need**

-

5+ years of development experience, including meaningful full-stack exposure. You are comfortable working across backend and frontend layers and you pick up new technologies independently.

-

Experience with strongly typed languages (i.e., Typescript, Java, dotnet, PHP). We operate in Go and React, and we back ourselves to get a seasoned engineer with strongly typed experience up to speed in our tech stack quickly.

-

Comfortable using AI coding tools as part of your daily development workflow, and curious about how AI can improve how we build.

-

Excellent communication and collaboration skills, with the ability to influence technical and non-technical stakeholders.

-

Knowledge of secure coding practices and understanding of secure development principles to building safe, trusted systems

-

Fluency in English is a must.

## **What we offer**

-

Work on genuinely hard problems in a complex domain: XDR, security data at scale, and tooling that empowers security analysts to protect hundreds of customers across Europe.

-

Real ownership in a small, autonomous team where every engineer is close to the work, close to the decision-making, and close to the impact.

-

A deliberate bet on AI-augmented engineering: we are building toward small teams that punch well above their weight through smart AI adoption, and you will be part of shaping how that works in practice.

-

Be at the forefront of innovation, shaping the future of our technology infrastructure.

-

Enjoy a competitive compensation package and comprehensive benefits.

-

Join a young and thriving scale-up which is on its way to becoming the category leader in Europe.

-

We are a great place to work, filled with people who enjoy working together.

We are a rapidly growing company and believe in investing in our people. If you're a highly motivated and results-oriented engineer with a passion for building secure, scalable technologies, **we encourage you to apply!**

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
