# Senior Software Engineer / AI Enabler (m/f/d)

Posted: 2026-08-17T20:56:01Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**A career driven by you.** Join AutoScout24 Group and experience life in the fast lane. We’re not just leading the market; we’re creating it. For a career that doesn’t stand still, where you can put your ideas in the driving seat and change the way the world moves, join our global community.

We’re hiring a strong **Software Engineer /** **AI Enabler **to multiply the impact of our Product & Technology organization. This role is for someone who is excited about GenAI’s boosting their own engineering performance and productivity and now wants to influence a large, ambitious organization—raising the bar for how software is delivered in a complex, established and market-leading business, not a greenfield startup.

The engineering world is moving very fast. We are all learning every day. Your core traits should be **curiosity and a strong drive to learn and grow**. We do not expect you to know everything. We expect you to help accelerate our curiosity and learning culture, and to become **AI-first** together with us.

**What you’ll do**

- Join one of our builders’ teams to **build great products** loved by our customers.

- Apply an **AI-first mindset** to every phase of you-build-it-you-run-it: from design and coding to testing, deployment and operations.

- Work **hands-on in real product codebases** (for example TypeScript/Node/Next.js or Java/Spring), using GenAI tools to accelerate development, improve quality and simplify existing systems.

- Build and evolve **AI-powered internal tools** and workflows (assistants for coding, reviews, documentation, testing) that engineers across AutoScout24 can rely on every day.

- Act as a multiplier and culture driver: **coach teams** on effective GenAI usage, share patterns and anti-patterns, and help establish AI-first ways of working across our engineering organization.

- Experiment, measure and improve: run small, data-informed experiments with teams, **learn what works** in our context, and turn successful approaches into repeatable standards and playbooks.

**What you need to succeed**

- Deep, hands-on experience building production systems (we expect you’ve spent at least 5 years doing this, possibly much more), ideally with TypeScript/Node.js/Next.js or Java/Spring Boot on AWS, Azure or GCP.

- Proven experience working in large, existing codebases and delivering well-tested, maintainable features in web or backend services.

- Demonstrated personal excellence in using GenAI coding tools (for example GitHub Copilot, ChatGPT, Cursor, OpenAI Codex) to significantly improve your own development speed and quality: code generation, refactoring, debugging, tests and documentation.

- Experience integrating LLM APIs (such as OpenAI, Anthropic, Azure OpenAI, Vertex AI or similar) into applications or internal tools.

- Strong communication and influencing skills: you can introduce new tools and practices, align stakeholders, handle skepticism and iterate based on feedback.

- A curious, growth-oriented mindset: you actively seek out new practices and tools, you are comfortable learning in public, and you help others do the same.

- A pragmatic view of GenAI: you understand its limitations and risks and know how to put guardrails in place (reviews, tests, policies) to keep usage safe, compliant and sustainable at scale.

With over 50 nationalities represented, we’re proud to welcome people of all backgrounds to our growing community. Here, you’ll have the tools, training and support you need to work in a way that suits you, learn new skills and reach your potential.

**For a career where you can drive our business and shape your future, apply now.**

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
