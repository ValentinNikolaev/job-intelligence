# Senior/Staff Backend Engineer - remote friendly

Posted: 2026-08-18T02:04:59Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**Our mission and customers: **We are creating the freedom for SMEs to succeed by delivering Europe's leading finance workspace with banking at its core, augmented by financial tools. We are proud to be [***rated 4.8 on Trustpilot***](https://www.trustpilot.com/review/qonto.com)***[,](https://www.trustpilot.com/review/qonto.com)****** ***based on 55,000+ reviews. [***Our culture***](https://qonto.com/en/careers/culture)*** ***puts customer satisfaction at the core of what we do, as proven by our Net Promoter Score of 75 *(more about our culture **[here](https://medium.com/qonto-way/the-qonto-way-our-culture-is-our-strategy-90defd4895f9)**).*

**Our journey: **Founded in 2017 by** **[***Alexandre***](https://www.linkedin.com/in/aprot/) and [***Steve***](https://www.linkedin.com/in/steveanavi/)***,*** Qonto has grown to 1,600+ Qontoers serving over 600,000+ customers across 8 European countries. We have been profitable since 2023, and we are just getting started.

**Our beliefs: **We hire for skills and potential. With 80+ nationalities, 45% women, of which 56% of women in our leadership team, diversity isn't a program; It's who we are. [***We've built a discrimination-free hiring process***](https://medium.com/qonto-way/a-recruiters-dilemma-confronting-bias-in-hiring-b78acce148eb) because the best teams are built on merit.

**AI at Qonto: **AI is deeply embedded in how we work (**[*here*](https://medium.com/qonto-way/ai-at-qonto-vision-statement-725a7e2f659b)**)* - *Every Qontoer gets unlimited access to the best AI tools. We want people who experiment without waiting for permission, push AI beyond the obvious, know when to trust it, and when to question it.

------------------------------------------------------------------------------------------------------

🌏 Location: You can choose to work in Qonto as long as you're living in (or willing to relocate to) either Germany, France, Italy, Serbia, or Spain.

Mission: Join us as a Backend Engineer to build the financial infrastructure that 600,000+ European SMEs depend on every day, from highly scalable APIs to robust banking services that handle real money, in real time, with zero room for mistakes.

### ➡️ As a Backend Engineer at Qonto, you will

- Design, build, deploy, and maintain services handling real financial transactions, owning reliability in production, not just at merge time

- Co-own service architecture, resilience, and scalability with respect to Domain-Driven Design principles

- Grow in technical leadership: lead design discussions, anticipate risks, and mentor less experienced engineers

- Drive continuous improvement, from fixing flaky CI to running post-mortems and propagating learnings across the team

Our primary languages are Go and Ruby. Our platform runs on a Kubernetes cluster hosted on AWS, with PostgreSQL as our database of choice. We're also using Kafka for event-driven architecture and ELK for logging and auditing, among many other tools and services.

##

### ➡️ What you can expect: our methodology, the [Qonto Way](https://medium.com/qonto-way/tagged/the-qonto-way)

- We value upfront technical design, team reviews, and smart slicing, quality drives the velocity our customers need

- Our org assigns one team lead per project across stacks, giving your team a clear mission and full autonomy on how it operates

- Our **lean toolbox**, [Kaizen](https://medium.com/qonto-way/qonto-way-strong-engineering-culture-prt1-kaizen-spirit-7e6e0a17c07e), PDCA, lets you monitor and drive continuous improvement collaboratively with your peers and manager

- Each engineer gets access to Cursor or Copilot, and we want people who use AI to **raise the bar, not just to go faster**

### ➡️ **Your future team**

As a Backend Engineer, you will join one of Qonto's **squad teams**, each organised around a clear project mission, with one team lead and full ownership of a product scope.

You'll be part of a 190-strong backend engineering community within a 500- Product Engineering department, working in squad teams of 5 to 10 people alongside Product, Design, and peers from Frontend and Mobile.

##

### ➡️ About You

- **Technical expertise:** Strong backend engineering experience with exposure to large-scale web application architecture and real production constraints

- **Stack fluency:** You don't need to know our exact stack, but you transfer fast and are comfortable with similar technologies

- **Quality-driven:** You write tests, set up monitoring, handle incidents methodically, and do root cause analysis

- **Ownership mindset:** You track impact after release, flag regressions, and improve what's in your scope without being asked

- **Team player:** Comfortable working in squad teams with PMs, Designers, and other stacks; fluent in English

*At Qonto, we understand that true diversity isn’t just about ticking boxes on a hiring checklist. Apply regardless of the boxes you tick — who knows? You may have the missing piece of the puzzle we’ve been searching for all along.*

*By applying, you agree that Qonto processes your personal data to assess your application. Your data is kept for up to 2 years in our candidate pool. Read our [Privacy Notice](https://qonto.com/en/legal-documents/privacy-notice) for full details.*

------------------------------------------------------------------------------------------------------

On average, **our hiring process lasts ****20 working days****. **More information on our candidate journey ***[here](https://qonto.com/en/careers/candidate-journey)***

------------------------------------------------------------------------------------------------------

**🔒 Your security matters to us**

Recruitment scams are on the rise. Keep in mind, we will never work with third-party platforms or agencies that request payment from candidates.

If you receive a suspicious message claiming to be from Qonto, please report it right away (

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
