# Forward Deployed Engineer - Software Engineer - Germany

Posted: 2026-08-17T23:40:19Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

## About ElevenLabs

ElevenLabs is an AI research and product company transforming how we interact with technology.

We launched in January 2023 with the first human-like AI voice model. Today, we serve millions of users and thousands of businesses - from fast-growing startups to large enterprises like Deutsche Telekom and Meta. Our investors are some of the world's most prominent, including Andreessen Horowitz, ICONIQ Growth and Sequoia. We've raised $781M in funding and our last valuation was $11B - multiples of 11, always.

We have expanded from voice into three main platforms:

-

ElevenAgents enables businesses to deliver seamless and intelligent customer experiences, with the integrations, testing, monitoring, and reliability necessary to deploy voice and chat agents at scale.

-

ElevenCreative empowers creators and marketers to generate and edit speech, music, image, and video across 70+ languages.

-

ElevenAPI gives developers access to our leading AI audio foundational models.

Everything we do is the result of the creativity and commitment of our team - builders doing the best work of their lives. We are researchers, engineers, and operators. IOI medalists and ex-founders. If you want to work hard and create lasting positive impact, we want to hear from you.

## How we work

-

**High-velocity: **Rapid experimentation, lean autonomous teams, and minimal bureaucracy.

-

**Impact not job titles: **We don’t have job titles. Instead, it’s about the impact you have. No task is above or beneath you.

-

**AI first:** We use AI to move faster with higher-quality results. We do this across the whole company—from engineering to growth to operations.

-

**Excellence everywhere: **Everything we do should match the quality of our AI models.

-

**Global team: **We prioritize your talent, not your location.

## What we offer

-

**Innovative culture:** You’ll be part of a generational opportunity to define the trajectory of AI, surrounded by a team pushing the boundaries of what’s possible.

-

**Growth paths: **Joining ElevenLabs means joining a dynamic team with countless opportunities to drive impact - beyond your immediate role and responsibilities.

-

**Learning & development**: ElevenLabs proactively supports professional development through an annual discretionary stipend.

-

**Social travel**: We also provide an annual discretionary stipend to meet up with colleagues each year, however you choose.

-

**Annual company offsite: **Each year, we bring the entire team together in a new location - past offsites have included Croatia and Italy.

-

**Co-working**: If you’re not located near one of our main hubs, we offer a monthly co-working stipend.

**About the role**

You’ll use your creativity, problem-solving, and technical expertise to design tailored solutions that make a real impact.

Embedded with our most strategic customers, you’ll get a front-row seat to some of our highest-stakes projects. From brainstorming technical architectures and product features to building full-scale integrations, you’ll take full ownership of complex, high-impact challenges—helping clients achieve their goals and push the limits of what’s possible.

What you will do:

-

Take full ownership of end-to-end execution of major projects for our most strategic partners, working hands-on to deliver high-impact solutions.

-

Collaborate daily with our customer’s engineers and executives teams to ensure the best use of ElevenLabs’ technologies.

-

Drive real innovation by using your coding and technical skills to solve complex problems, making a real difference for our customers.

## **Requirements**

-

Experience working with customers. It’s ok if you only worked with customers in student clubs or side projects, as long as you are interested in working closely with them on a technical capacity

-

Proficiency in Python and strong software development knowledge, inclusive of a deep understanding of software development, software architecture, and APIs integration.

-

Excellent communication and problem-solving skills. Especially in terms of ability to summarize complex technical knowledge and using logic in pursuing optimal solutions.

**Location**

This role is remote-first, so it can be executed from anywhere in Canada, however there is a preference for candidates to be based out of Berlin. Fluency in English and German and a deep understanding of the regional and cultural nuances is required.

#LI-remote

We are an equal opportunity employer and do not discriminate on the basis of race, religion, national origin, gender, sexual orientation, age, veteran status, disability or other legally protected statuses.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
