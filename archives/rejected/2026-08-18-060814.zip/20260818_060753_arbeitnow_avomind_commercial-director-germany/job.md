# Commercial Director - Germany

Posted: 2026-08-18T02:20:20Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

### Role Overview

Our client is a growing European cruise operator known for its no-fly cruises departing from UK and European homeports. Building on this foundation, they are launching a new German-speaking brand — and are seeking a Commercial Director to establish and lead it.

This is a rare opportunity to build a cruise business from the ground up: developing the German market, establishing the local organisation, building distribution partnerships, and leading the brand's launch and long-term growth.

The Commercial Director is the senior representative of the brand in Germany, working closely with Finance, Marketing, Revenue Management, Operations, Customer Service and Legal, with focus on commercial leadership, business development and market growth

The ideal candidate is an entrepreneurial leader who enjoys building businesses and relationships, combines strategic thinking with a hands-on approach, and is comfortable operating within a fast-moving international organisation.

### Key Responsibilities

### Strategic & Launch Leadership

- Develop and execute the German market-entry strategy, business plan and integrated launch programme, ensuring the organisation, proposition and distribution network are ready ahead of ITB Berlin, March 2027.
- Coordinate launch workstreams across commercial, marketing, finance, legal, technology, customer service and operations; identify and mitigate launch risks.
- Represent our client at industry events and trade shows, and act as principal link between the German business and the UK Executive Team.

### Commercial & Sales

- Lead all German sales channels (trade, direct, online) and deliver annual revenue, passenger volume, occupancy and yield targets.
- Build long-term relationships with German travel agency groups, co-operatives, cruise specialists, tour operators and online partners; lead key commercial negotiations.
- Work with UK Digital and Revenue Management teams on the direct sales proposition, pricing, inventory and promotional activity; provide market input into itinerary and product design.

### Business Operations

- Establish and run the German office, ensuring effective governance and communication with UK Head Office.
- Ensure the German customer journey is fully localised (language, documentation, payment, communications) and maintain high service standards pre- and post-cruise.
- Support homeport readiness, embarkation arrangements and local port relationships; manage local suppliers and advisers.

### Financial Leadership

- Deliver agreed commercial and financial objectives; develop annual budgets and forecasts with UK Finance.
- Monitor performance against revenue, profitability and budget targets, and report regularly to the UK Executive Team.

### Regulatory, People & Brand

- Ensure compliance with applicable travel, consumer and employment legislation, including DRSF requirements, working with specialist advisers.
- Recruit, lead and develop a high-performing German team; build a collaborative, entrepreneurial culture aligned with our client's values.
- Act as brand guardian for our client in Germany, shaping market positioning and overseeing local marketing in partnership with central teams.

### Stakeholder Management

- Build trusted relationships with the UK Executive Team, Group functions, key trade partners and industry bodies (e.g. CLIA Germany).
- Act as senior spokesperson with customers, partners and media, protecting and enhancing the reputation of our client's brands.

**Requirements**

### Key Skills and Experience

- Significant senior leadership experience in cruise, tour operating, travel distribution, tourism or premium hospitality; cruise industry experience highly desirable.
- Track record of growing revenue, developing partnerships and delivering profitable growth; experience launching a new business, brand, market or product advantageous.
- Strong understanding of the German travel market and distribution landscape.
- Experience building and leading high-performing, multi-functional teams, with commercial responsibility for budgets and financial performance.
- Excellent negotiation, influencing and stakeholder management skills; experience working with executive leadership teams internationally.
- Fluent German and English, written and spoken.

### Personal Attributes

- Entrepreneurial, commercially driven and passionate about building a successful business.
- Strong leadership presence; comfortable in a start-up environment; decisive, pragmatic and resilient.
- Highly collaborative, hands-on, and an excellent communicator with strong influencing skills.
- Customer-focused with high levels of integrity, professionalism and personal accountability.

### Key Performance Measures

- Delivery of agreed market-entry and launch milestones; successful establishment of the German business and team.
- Readiness of booking, distribution and customer-service operations.
- Revenue, passenger volume, occupancy, yield and profitability performance against budget.
- Development of national travel-trade distribution, brand awareness and customer acquisition.
- Customer satisfaction and repeat-booking measures; employee engagement and retention.
- Successful delivery of the maiden season and subsequent growth plan.

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
