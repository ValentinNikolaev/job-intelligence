# Product Engineer

Posted: 2026-08-18T02:55:07Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

## **About Black Forest Labs**

We’re the team behind Latent Diffusion, Stable Diffusion, and FLUX—foundational technologies that changed how the world creates images and video. We’re creating the generative models that power how people make images and video—tools used by millions of creators, developers, and businesses worldwide. Our FLUX models are among the most advanced in the world, and we’re just getting started.

Headquartered in Freiburg, Germany with a growing presence in San Francisco, we’re scaling fast while staying true to what makes us different: research excellence, open science, and building technology that expands human creativity.

## **Why This Role**

We're looking for a Product Engineer to build the experiences people meet our models through.

You'll work alongside our researchers and infrastructure engineers to turn frontier model capabilities into interfaces that feel fast, considered, and obvious to use.

You'll own the surfaces developers and creatives touch first:

- [Playground](https://dashboard.bfl.ai/playground) - where most developers and creatives experience and test our models

- [Dashboard](https://dashboard.bfl.ai) - where developers manage keys, usage, and billing

- Launch demos for new FLUX models, often built against checkpoints nobody outside the lab has seen

- Reference implementations and starter apps that other developers build on top of

Day to day, that means:

- Shipping high-quality web applications end to end, fast

- Turning research capabilities into product - first prototype through to production

- Owning frontend architecture and the practices the rest of the engineering team builds on

- Setting the visual bar - the shared components, interaction detail, and polish that everything else gets held against

- Designing for genuinely hard interaction problems: long-running generations, iterative editing, large media payloads, real-time inference

- Driving performance for high-volume media processing and latency that users actually feel

- Working with research, infra, growth, and design to decide what's worth building at all

## **What You’ll Work On**

Most of our code is written by agents. The job is deciding what to build, decomposing it so agents can execute well, and reviewing what comes back with enough judgment to catch what's subtly wrong.

We care far more about how quickly you can go from idea to working, reviewed, shipped product than about which frameworks you've memorized.

This is a **frontend-leaning full-stack** role. You'll live in the frontend and own it, but you'll be comfortable following a feature into the API layer, the database, and a migration without waiting for someone else.

## **What We’re Looking For**

- A track record of shipping real products that real users depend on, and the war stories to go with it

- Fluency driving coding agents on non-trivial *existing* codebases, not just greenfield demos — plus the judgment to review generated code critically, catching the plausible-but-wrong, the insecure, and the unmaintainable

- A clear view on where agents should *not* be trusted, and why

- Visual craft — your interfaces look considered, and you can tell the difference between shipped-and-fine and actually good. Comfortable working from a Figma file or from nothing

- Strong product sense: you make UX and technical tradeoffs deliberately, and can explain them to people who don't write code

- Excellent debugging instincts, wherever the bug turns out to live

- Comfort with the ambiguity and pace of an early-stage lab — loose requirements, shifting priorities, and nobody to tell you what to do next

## **Nice to have:**

- Experience with React, TypeScript, and Next.js (we use them - we just don't think they're the hard part)

- A track record of building developer tools or creative applications

- Previous experience building interfaces on top of generative models, and working knowledge of AI/ML concepts

- Instrumentation and experimentation experience: analytics, A/B testing, activation funnels

- Contributions to open-source projects

## **How we interview:**

Expect to build something live, on your own machine, with whatever tooling you normally use. Using coding agents is encouraged rather than merely tolerated - we want to see how you actually work, not how you perform without your tools. The process is four conversations plus a half-day onsite in Freiburg, and we cover travel. We'll share the full process upfront.

## **What we offer you:**

- The chance to put the first interface on frontier image and video models, sometimes before anyone outside the lab has seen them

- Work alongside the researchers who invented much of modern generative media

- Competitive salary, equity and benefits programs

- Hybrid working environment from our HQ in Freiburg (Germany) with regular global off-sites

## **How We Work Together**

We’re a distributed team with real offices that people actually use. Depending on your role, you’ll either join us in Freiburg or SF at least 2 days a week (or one full week every other week), or work remotely with a monthly in-person week to stay connected. We’ll cover reasonable travel costs to make this possible. We think in-person time matters, and we’ve structured things to make it accessible to all. We’ll discuss what this will look like for the role during our interview process.

**Everything we do is grounded in four values:**

- **Obsessed**. We are a frontier research lab. The science has to be right, the understanding deep, the product beautiful.

- **Low Ego**. The work speaks. The best idea wins, no matter who said it. Credit is shared. Nobody is above any task.

- **Bold.** We take the ambitious bet. We ship, we do not wait for conditions to be perfect.

- **Kind.** People over politics. We treat each other with genuine warmth. Agency without empathy creates chaos.

If this sounds like work you’d enjoy, we’d love to hear from you.

**Base Annual Salary:**

**EU €140,000 - €190,000 + Equity**

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
