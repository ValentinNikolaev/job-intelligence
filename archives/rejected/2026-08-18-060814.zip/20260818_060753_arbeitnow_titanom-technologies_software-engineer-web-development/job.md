# Software Engineer, Web Development

Posted: 2026-08-17T20:20:39Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Titanom ist ein KI- und Softwareunternehmen mit Fokus auf digitale Produkte in Bildung, öffentlichem Sektor und angrenzenden Bereichen. Unsere Mission ist es Lösungen zu entwickeln, die nicht nur technisch funktionieren, sondern im Alltag bestehen – langfristig, sicher und nutzerorientiert.

### **Deine Rolle als Software Engineer: Mit Code innovative Lösungen gestalten **

In unserem agilen Team entwickelst du moderne Webanwendungen und KI-Features. Du baust skalierbare Architekturen, integrierst Machine-Learning-APIs und schaffst intuitive User Experiences. Wir arbeiten hauptsächlich mit **TypeScript, Next.js und React** bzw. mit Python und FastAPI – aber neue Ideen und ein cooler TechStack sind immer willkommen.

### Dein Impact bei Titanom:

- **Entwicklung & Optimierung** moderner & nutzerzentrierter Web-Apps (Frontend & Backend) mit Technologien wie z. B. Next.js, TypeScript und Python
- **Integration von** **KI-Technologien** zur Verbesserung der User Experience in enger Zusammenarbeit mit anderen Teams, um innovative Lösungen für reale Probleme zu entwickeln
- **Optimierung von Webanwendungen** für Skalierbarkeit, Geschwindigkeit und Performance und sichern der **Codequalität **durch Tests, Debugging, Optimierung
- **Erstellung von Libraries & Packages**, die echten Mehrwert schaffen
- **Erforschung & Umsetzung** innovativer Use-Cases mit modernsten KI-Technologien von Large Language Models bis zu Vision Transformers
- **Teilnahme an Code-Reviews** und aktive Mitgestaltung der Entwicklungsprozesse
- **Kreative Problemlösung** – auch für Machine-Learning-Aufgaben
- **Lernen & Wachsen**: Teilnahme an wöchentlichen Workshops zu Software Engineering & Machine Learning

**Requirements**

**Wir suchen Entwickler:innen mit Ownership-Mindset & Umsetzungsstärke: **

- Abgeschlossenes Studium der (Wirtschafts-) Informatik, Mathematik oder eine vergleichbare Qualifikation
- Praxiserfahrung in der Web- oder Softwareentwicklung mit Interesse an Fullstack-Entwicklung
- Freude daran, Features von der Idee bis zum sauberen Production-Release zu bringen
- Erfahrung mit CI/CD und automatisierten Tests
- Sehr gute Deutschkenntnisse (min. C1) und gute Englischkenntnisse (min. B2)
- Eigeninitiative, Verantwortungsbewusstsein und Hands-on-Mentalität
- Interesse an KI-Themen wie LLM-APIs, RAG, Vector Search und Motivation, sich in Vision-Modelle einzuarbeiten

### Deine Vergütung

Für diese Position bieten wir ein Fixgehalt im Bereich von **50.000 bis 60.000 EUR pro Jahr**, abhängig von deinen individuellen Stärken und Erfahrungen. Uns ist wichtig, dass du von Anfang an weißt, woran du bist – deshalb kommunizieren wir die Gehaltsrange offen und transparent. Im persönlichen Gespräch finden wir gemeinsam heraus, welche Einstufung am besten zu dir passt. Denn wir glauben daran, dass Transparenz und Wertschätzung mehr sind als Worte.

**Benefits**

- **Faire & flexible Arbeitskultur:** Wir bieten flexible Arbeitszeiten, 30 Tage Urlaub und eine transparente Überstundenvergütung – denn jede Minute deiner Arbeit wird bei uns wertgeschätzt.
- **Erstklassige Ausstattung & Extras:** Arbeite mit Top-Equipment (z.B. MacBooks) und profitiere von steuerfreien Zusatzleistungen wie 50-Euro-Gutscheinen oder einer Urban-Sports-Club-Mitgliedschaft.
- **10%** **Education Time:** Wir unterstützen dich dabei, kontinuierlich zu lernen und zu wachsen!
- **Dein Wachstum ist unser Wachstum:** In einem schnell wachsenden Unternehmen entstehen ständig neue Aufstiegschancen. Du gestaltest deinen Karriereweg aktiv mit.
- **Ein starkes, ambitioniertes Team:** Dich erwartet eine motivierte und dynamische Mannschaft.
- **Ein Büro, das mehr kann:** Freu dich auf ein phänomenales und gut erreichbares Büro mit Gym, Sauna, Nintendo, Tischtennis, Kicker, Ruheraum und Dachterrasse
- **Ein Kühlschrank voll mit deinen Lieblingsgetränken: **Wir bieten eine umfangreiche Getränke-Flat!
- **Legendäre Firmenfeiern und Events: **Wir feiern unsere Erfolge mit unvergesslichen Firmenfeiern und spannenden Teamevents.

### FAQ – Häufige Fragen zur Stelle bei Titanom

***Welche Technologien kommen in dieser Position zum Einsatz? ***

Du arbeitest mit einem modernen Tech-Stack, der unter anderem Next.js, TypeScript, Python und React umfasst. Außerdem setzen wir auf innovative KI-Technologien wie Large Language Models und Vision Transformers.

***Brauche ich Vorerfahrung mit KI-Technologie ***

Nein, Software-Entwicklung-Erfahrung reicht. Wir bieten umfassende Einarbeitung und 10% **Education Time** für kontinuierliche Weiterbildung.

***Welche Qualifikationen sind erforderlich?***

Ein Studium in einem passenden Bereich (z. B. Informatik, Mathematik) ist von Vorteil, aber kein Muss. **Quereinsteiger:innen**, die sauberen Code zu schätzen wissen und praktische Erfahrung in der Softwareentwicklung mitbringen, sind bei uns ebenfalls herzlich willkommen.

***Welche Soft Skills sind wichtig?***

Wir suchen jemanden mit Motivation und Drive, Leidenschaft für Softwareentwicklung, einem hohen Qualitätsbewusstsein, einer Hands-On-Mentalität und der Fähigkeit, kreativ Probleme zu lösen – auch im Bereich Machine Learning. Zudem solltest du Lust auf deine persönliche Entwicklung haben und Lernbereit sein!

***Gibt es Möglichkeiten zur Weiterbildung?***

Ja, absolut! Bildung und Weiterentwicklung haben bei uns höchste Priorität – nicht nur extern, sondern auch intern. Wir bieten dir die Möglichkeit, an wöchentlichen Workshops zu Software Engineering und Machine Learning teilzunehmen, um dein Wissen kontinuierlich zu erweitern und dich persönlich wie fachlich weiterzuentwickeln.

***Wie sieht die Zusammenarbeit im Team aus?***

Du arbeitest eng mit UI/UX-Designern, Product Managern und anderen Entwickler:innen zusammen. Durch regelmäßige Code-Reviews und den Austausch im Team gestalten wir die Entwicklungsprozesse gemeinsam und fördern eine offene Feedback-Kultur.

***Was macht die Arbeit bei Titanom besonders?***

Bei uns hast du die Chance, mit modernsten Technologien an innovativen Bildungsprojekten zu arbeiten, die echten Impact haben. Wir legen großen Wert auf kreative Problemlösungen, Teamarbeit und persönliche Weiterentwicklung.

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
