# Account Executive EdTECH DACH (m/w/d)

Posted: 2026-08-17T23:40:16Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**Account Executive Education TECH DACH (m/w/d)**

**Gehalt: **EUR 60.-65.000 Base, EUR 100-120.000 OTE

**Ort: **Berlin, 4 Tage Onsite/Hybrid Mindspace, Friedrichstraße 68, 10117 Berlin

**About our client magmamath**

Magma Mathe ist eines der am schnellsten wachsenden EdTech-Scale-ups weltweit und verändert den Mathematikunterricht nachhaltig durch den Einsatz von KI. Unsere Plattform ermöglicht individualisiertes, formatives Feedback für Schüler:innen. Lehrkräfte erhalten Rückmeldung zu Wissenslücken in Echtzeit und erhalten wertvollen Einblick in den Lernfortschritt ihrer Schüler:innen; damit sie sich stärker auf echte Lernerfolge konzentrieren können.

Das Ergebnis: ein inklusiverer, motivierenderer und messbar effektiverer Matheunterricht.

Doch wir entwickeln nicht nur Technologie - wir lösen ein globales Bildungsproblem. Weltweit hat etwa jede:r fünfte Schüler:in Schwierigkeiten in Mathematik - einem Fach, das entscheidend für viele Bildungs- und Karrierewege ist. Unsere Mission ist es, Bildungsergebnisse im großen Maßstab zu verbessern.

Wir sind bereits in tausenden Schulen im Einsatz und wachsen rasant in den USA und Europa - jetzt auch in Deutschland. Dafür bauen wir ein ambitioniertes Team auf, das unsere Vision teilt: Millionen von Schüler:innen dabei zu unterstützen, ihr volles Potenzial zu entfalten.

**About the role**

Deutschland ist einer unserer wichtigsten Wachstumsmärkte. Als Account Executive spielst du eine zentrale Rolle beim Aufbau unserer Marktpräsenz - mit viel Verantwortung, Gestaltungsspielraum und direktem Einfluss auf unseren Erfolg.

Dies ist eine klassische Scale-up-Rolle: Prozesse entwickeln sich weiter, nicht alles ist bereits vorgegeben. Wir suchen Menschen, die Ownership übernehmen, strukturiert arbeiten und gerne in einem dynamischen Umfeld wachsen.

Du verantwortest die Gewinnung neuer Kund:innen (Schulen & Schulträger) in ganz Deutschland - von der Leadgenerierung bis zum Vertragsabschluss. Dabei arbeitest du sowohl mit selbst generierten Leads als auch mit qualifizierten Inbound-Anfragen in einem typischen Sales-Zyklus von rund zwei Monaten.

Erfolg bedeutet für dich:

-

Herausforderungen im Schulalltag und der Bildungspolitik zu verstehen

-

langfristige Beziehungen zu Entscheidungsträger:innen aufzubauen

-

klar zu zeigen, welchen messbaren Mehrwert Magma Mathe bietet

Außerdem repräsentierst du uns auf Messen, Konferenzen und Veranstaltungen im Bildungsbereich und trägst aktiv dazu bei, unsere Marke in Deutschland zu etablieren.

**Your tasks**

-

Verantwortung für den gesamten Sales-Cycle: Prospecting, Discovery, Demos, Angebotsphase und Closing

-

Aufbau und Pflege von Beziehungen zu Schulleitungen, Fachbereichsleitungen Mathematik, Schulträgern, Schulämtern und Bildungspolitik

-

Teilnahme an Konferenzen, Messen und Vor-Ort-Terminen

-

Analyse von Kundenbedürfnissen rund um Lernleistung, Finanzierung und Lehrkräfteunterstützung

-

Enge Zusammenarbeit mit Customer Success, Marketing und Produkt

-

Aktive Mitgestaltung von Prozessen und Strukturen in einer wachsenden Organisation

**Your profile**

-

Mindestens 2 Jahre Erfahrung im Vertrieb (idealerweise SaaS, Software oder Tech)

-

Fließende Deutsch- und Englischkenntnisse (mindestens C1)

-

Erfahrung im Outbound-Sales und proaktiver Kundenansprache

-

Selbstständige Arbeitsweise und hohe Eigenmotivation

-

Wettbewerbsorientierte Persönlichkeit mit Teamgeist

**What you can expect from magmamath**

-

Eine Schlüsselrolle in einem international wachsenden PE-backed Scale-up

-

Hohe Eigenverantwortung und echter Gestaltungsspielraum

-

Wettbewerbsfähiges Gehalt + leistungsbasierte Provision

-

Regelmäßige Company Events und jährliche Team-Trips

-

30 Urlaubstage und monatlicher Gesundheitszuschuss

-

Ein internationales, ambitioniertes Team mit starkem Zusammenhalt

-

Die Möglichkeit, einen messbaren Beitrag zur Zukunft der Bildung zu leisten

________

**About pplwise**

pplwise unterstützt führende, schnell wachsende Unternehmen in ganz Europa dabei, ihre Wachstumsziele zu erreichen. Unsere Dienstleistungen umfassen Recruiting as a Service und Executive Search, mit einer Spezialisierung auf Technologieunternehmen in Wachstumsphasen.

Wir arbeiten mit börsennotierten Unternehmen wie Uber und JustEatTakeaway, Unicorns wie Egym, Wellpass, magmamath, box, GetYourGuide und Wolt sowie zahlreichen Startups und Scale-ups zusammen, die von führenden Venture-Capital-Firmen wie Sequoia Capital, HV Capital und Cherry Ventures finanziert werden.

Gegründet im Jahr 2021, ist pplwise in über 20 Ländern in Europa tätig und verfügt über ein Team von mehr als 15 talentierten Talent Partnern, die ehrgeizige Tech-Unternehmen bei der Bewältigung ihrer Wachstumsphasen unterstützen.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
