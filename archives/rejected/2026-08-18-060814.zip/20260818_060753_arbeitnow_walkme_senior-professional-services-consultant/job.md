# Senior Professional Services Consultant

Posted: 2026-08-18T02:05:20Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Industry leader? Well, how about an industry creator?!

At WalkMe, now an SAP company, we’re not just the leader in digital adoption, we started the digital adoption revolution - enabling organizations to pinpoint and resolve digital friction, regain control of their tech stack, and be better equipped to manage future change. With over 1,600 clients, including 55 Fortune 100 companies and 6 Fortune 10 companies working with us daily, we’re transforming how enterprises interact with their technology.

So, if you’re an expert in your field, and looking for an opportunity to work, collaborate, and innovate with some of the most talented people out there, WalkMe is the place for you!

The **Senior Professional Services Consultant** is one of the most impactful roles at WalkMe. You will own the end-to-end implementation of our digital adoption platform for some of the world most complex and high-stakes organisations — including global defence and government primes, where getting user adoption right isn't just a product metric, it's mission-critical.
You'll partner directly with customers to design and build solutions that drive meaningful change in how enterprise users, from commercial software teams to defence programme offices interact with complex platforms. You'll report to the Director of Professional Services, EMEA.

**What You'll Own**

- **WalkMe Implementation:** Design, build, and implement interactive experiences for our customers to drive business impact, such as enhancing their end-user onboarding experience and accelerating feature adoption.

- **Consultation**: Work closely with customer application owners to understand their business objectives, pain points, and end-user needs. Provide expert advice and recommend WalkMe solutions that align with their goals and improve user experiences.

- **Project Management:** Lead end-to-end WalkMe projects, collaborating with customers, internal stakeholders, and the development team to ensure successful delivery within scope, timeline, and budget.

- **Data Analysis: **Monitor and analyze WalkMe usage data and user feedback to identify opportunities for optimization and improvement. Constantly strive to increase WalkMe's effectiveness and user engagement.

- **Knowledge Transfer: **Conduct training sessions for customers on WalkMe best practices, ensuring they can make the most of the product and effectively utilize its features to enhance their applications.

- **Troubleshooting: **Identify and resolve any issues related to WalkMe implementation, ensuring smooth functionality across different platforms and devices.

- **Collaboration:** Foster strong cross-functional collaboration with UX/UI designers, developers, customer success teams, and other stakeholders.

**What You'll Need to Succeed**

- Strong understanding of user behaviour and how to improve user engagement through WalkMe.

- Familiarity with HTML, CSS, and JavaScript to customise and integrate WalkMe elements into web applications.

- Analytical mindset, capable of interpreting data to make data-driven decisions and optimise WalkMe implementations.

- Attention to detail, ensuring WalkMe elements are visually appealing, user-friendly, and aligned with our brand guidelines.

- Problem-solving skills, capable of troubleshooting and resolving issues related to WalkMe implementations.

- Experience working in an agile development environment is a plus.

- 5+ years of experience in Professional Services, Implementation Consulting, or Customer Success.

- 3+ years of SaaS experience.

- Bachelor's degree in a relevant field preferred.

**What Sets Us Apart**

- At WalkMe, we are dedicated to building a workforce that reflects the diversity of our global community and clients we serve through inclusive programs and initiatives including equal pay, employee resource groups, holistic benefits and more. We are committed to fostering an inclusive culture which celebrates the unique experiences and perspectives each Team Member brings to the workplace.

- Hybrid Work Arrangement: We offer a hybrid work schedule to perfectly combine the benefits of remote work and the essential connections and collaborations of onsite work.

- Supportive Culture: We focus on the whole person, celebrating what makes us unique, and create space for community.

- Professional Development: We encourage continuous learning and offer opportunities for career development through our career compass offering.

- Stay healthy and happy with Wellness@WalkMe! Enjoy quarterly wellness reimbursements, daily BrightBreaks to recharge, and WalkMe’s annual Wellness Month every July—because your well-being matters all year long.

- WalkMe provides health coverage options, where applicable, to ensure employees have access to essential medical benefits. Our offerings are designed to support the well-being and diverse needs of our global workforce.

- WalkMe offers a generous annual leave policy tailored to meet regional standards, ensuring all employees enjoy sufficient time off to rest and recharge.

- WalkMe offers RefreshMe Days throughout the year to further strengthen our commitment to work/life balance.

- Robust Retirement Contributions: Ask HR about the specific offerings for your region!

- SAP's acquisition of WalkMe highlights a commitment to enhancing user experience and streamlining software interactions, offering opportunities to work with cutting-edge technology that drives efficiency and innovation in the workplace.

At WalkMe, we approach Diversity, Equity and Inclusion (DEI) with the same level of collaboration, innovation and accountability that we bring to the rest of our business. We believe in the value of diversity and are committed to ensuring an equitable and inclusive workplace where every employee has an equal opportunity to achieve success.

*WalkMe does not discriminate. If a candidate requires a reasonable accommodation to complete a job application, pre-employment testing, or a job interview or to otherwise participate in the hiring process, please contact your Talent Acquisition partner immediately.*

**TO ALL RECRUITMENT AGENCIES: **WalkMe does not accept agency resumes. Please do not forward resumes to WalkMe employees or any other company location. WalkMe is not responsible for any fees related to unsolicited resumes and will not pay fees to any third-party agency or company that does not have a signed agreement with the Company for this specific role.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
