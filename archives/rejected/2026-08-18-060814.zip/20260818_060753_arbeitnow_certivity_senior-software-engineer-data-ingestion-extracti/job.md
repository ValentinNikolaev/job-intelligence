# Senior Software Engineer – Data Ingestion & Extraction (m/f/d)

Posted: 2026-08-17T23:09:42Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
