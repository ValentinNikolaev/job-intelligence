# Senior Backend Software Engineer

Posted: 2026-08-17T00:00:00.0000000

## Rejection

- Category: tech_stack
- Reason: role does not mention Go/Golang or PHP

...**Senior Backend **Software **Engineer **
Join Archy as a Senior Backend Software Engineer and help revolutionize dental practice management with our cutting... ...) 
~ Health, dental, and vision insurance 
~401(k) plan 
~ Flexible vacation policy 
~ **Remote-**friendly culture...
