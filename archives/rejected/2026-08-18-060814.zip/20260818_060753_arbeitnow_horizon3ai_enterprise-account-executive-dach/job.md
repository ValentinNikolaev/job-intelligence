# Enterprise Account Executive, DACH

Posted: 2026-08-17T23:40:04Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**Get to Know Us**

Horizon3 is a fast-growing, remote cybersecurity company dedicated to the mission of enabling organisations to proactively find and fix and verify exploitable attack vectors before criminals exploit them. Our flagship product, the NodeZeroTM platform, delivers production-safe autonomous pentests and other key assessment operations that scale across the largest internal, external, cloud, and hybrid cloud environments. NodeZero has been adopted by organisations of all sizes, from small educational institutions to government agencies and Global 100 enterprises. It is used by ITOps/SecOps teams, consulting pentesters, and MSSPs and MSPs.

We are a fusion of former U.S. Special Operations cyber operators, startup engineers, and formerly frustrated cybersecurity practitioners. We're committed to helping solve our common security problems: ineffective security tools, false positives resulting in alert fatigue, blind spots, "checkbox” security culture, cybersecurity skills shortage, and the long lead time and expense of hiring outside consultants. Collectively, we are a team of learn it alls, committed to a culture of respect, collaboration, ownership, and results.

**What You’ll Do**

The Enterprise Account Executive, DACH is a key role responsible for driving sales growth and expanding the customer base in the cybersecurity technology sector. The focus is on acquiring new accounts, building strong customer relationships, and ensuring customer satisfaction and retention. The successful candidate will have a proven track record in selling cybersecurity technologies, introducing disruptive cyber software solutions, and exceeding sales quotas consistently. They will also be adept at establishing and nurturing Channel Partner relationships, with pre-existing connections with key resellers in the region being a crucial requirement.

-

Sales Experience: Minimum of 5 years of successful sales experience in the cybersecurity technology industry, with a strong track record of achieving sales growth

-

Introduction of New Solutions: Demonstrated success in introducing and selling new disruptive cyber software solutions

-

Quota Achievement: Proven ability to exceed sales quotas consistently quarter over quarter.

-

Channel Partner Management: Experience in establishing and monetizing strong Channel Partner relationships, with existing relationships in the region being essential.

-

Sales Process Management: Proficiency in managing all aspects of the sales process, including qualification, proof of value, forecasting, negotiation, and deal closure.

-

Post-Sales Management: Ability to manage and drive the post-proof of value ROI process.

-

CRM and Pipeline Management: Experience in accurately tracking and managing customer information in company-provided CRM, and maintaining an accurate pipeline and forecasting in Salesforce (SFDC).

-

Product Presentation and Demo: Capability to present and demonstrate Horizon3AI solutions effectively in both virtual and in-person meetings.

-

Independent and Team Player: Demonstrated ability to work independently while also collaborating effectively with distributed sales, support, and success teams.

-

Sales Methodology: Familiarity with Challenger Question-Based Selling type sales methodologies and MEDDPICC.

-

Sales and Marketing Tools: Familiarity with sales enablement tools like Salesforce, CRM, [Outreach.io](http://Outreach.io), Linked-In Sales Navigator, ZoomInfo, and Slack.

**What You’ll Bring**

-

Sales Experience: Minimum of 5 years of experience working in a Sales role in cybersecurity

-

Industry Experience: Minimum of 3 years of experience working in the INFOSEC or SaaS space

-

Education: A college degree or equivalent work experience required

-

Native level fluency in German with excellent English communication skills

**Travel Required**

We are a fully remote company, and this job may require up to 60% of travel within the Southern Germany region and some international travel to Amsterdam.. Job-related travel expenses are reviewed and must be approved by your manager.

**Perks of Horizon3**

-

Inclusive Team: We value diversity and promote an inclusive culture where everyone can thrive.

-

Growth Opportunities: Be part of a dynamic and growing team with numerous career development opportunities.

-

Innovative Culture: Work in a collaborative environment that encourages creativity and out-of-the-box thinking.

-

Hybrid & Remote Work: We embrace a mix of remote and hybrid work models depending on role and location, including our Chicago office, where some roles require regular in-office presence.

-

Competitive Compensation: We offer competitive salary, equity and benefits. Our benefits include health, vision & dental insurance for you and your family, a flexible vacation policy, and generous parental leave.

**Compensation and Values**

At Horizon3, we believe that our people are our greatest asset, and our compensation philosophy reflects this core value. We are committed to fostering an environment where all employees feel valued, respected, and rewarded for their contributions. Our compensation structure is designed to be fair, competitive, and transparent, ensuring that every team member is recognized and compensated equitably across roles, levels, and locations.

In accordance with various State’s transparency regulations, we provide the following salary range information for this position:

-

EUR 240k - EUR 280k OTE 50/50 Split annually. The exact salary will be determined based on the selected candidate’s location, qualifications, experience, and relevant skills.

-

Additional compensation: This role is also eligible for an equity package (in the form of stock options). If any other compensation benefits apply, they will be discussed during the interview process.

**You Belong Here**

Horizon3 is not just an equal opportunity employer - we are a community that values diversity, equity, and inclusion as fundamental principles of our culture and success. We are dedicated to fostering a workplace where everyone feels welcome and respected, regardless of race, colour, religion, sex, national origin, age, disability, veteran status, sexual orientation, gender identity or expression, genetic information, marital status, hair length or any other legally protected status by law.

Our commitment to diversity and inclusion means we strive to attract, develop, and retain a workforce that reflects the varied communities we serve. We believe that diverse perspectives drive innovation and strengthen our ability to create cutting-edge cybersecurity solutions. At Horizon3.ai, every team member is valued and supported in an environment that encourages personal and professional growth.

We welcome candidates from all backgrounds and experiences, and we encourage all qualified individuals to apply. Come be a part of Horizon3.ai, where your unique contributions are recognised, and your potential is limitless.

**Other Duties**

Please note this job description is not designed to cover or contain a comprehensive listing of activities, duties or responsibilities that are required of the employee. Duties, responsibilities, and activities may change at any time with or without notice.

**Application Note**

In any materials you submit, you may redact or remove age-identifying information such as age, date of birth, or dates of school attendance or graduation. You will not be penalized for redacting or removing this information.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
