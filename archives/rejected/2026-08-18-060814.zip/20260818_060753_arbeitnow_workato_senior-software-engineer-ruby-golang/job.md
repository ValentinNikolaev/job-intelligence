# Senior Software Engineer (Ruby / GOlang)

Posted: 2026-08-17T23:55:24Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

# **About Workato**

Workato delivers enterprise infrastructure for the agentic era, redefining iPaaS and helping enterprises unify data, applications, processes, and AI into a single, governed platform. A leader in Enterprise MCP and trusted by 50% of the Fortune 500, Workato’s cloud-native architecture connects every application, data source, and process to power real-time orchestration at scale. With enterprise-grade security and continuous innovation at its core, Workato provides the trusted foundation for organizations to automate with confidence and operationalize AI across the business. To learn more, visit [www.workato.com](http://www.workato.com)

# **Why join us?**

Ultimately, Workato believes in fostering a **flexible, trust-oriented culture that empowers everyone to take full ownership of their roles**. We are driven by **innovation **and looking for** team players **who want to actively build our company.

But, we also believe in **balancing productivity with self-care**. That’s why we offer all of our employees a vibrant and dynamic work environment [along with a multitude of benefits](http://www.workato.com/careers) they can enjoy inside and outside of their work lives.

If this sounds right up your alley, please submit an application. We look forward to getting to know you!

Also, feel free to check out why:

-

[Business Insider](https://www.businessinsider.com/47-enterprise-startups-to-bet-your-career-on-in-2020-2019-12) named us an “enterprise startup to bet your career on”

-

[Forbes’ Cloud 100](https://www.forbes.com/cloud100/#a57477b5f941) recognized us as one of the top 100 private cloud companies in the world

-

[Deloitte Tech Fast 500](https://www2.deloitte.com/us/en/pages/technology-media-and-telecommunications/articles/fast500-winners.html) ranked us as the 17th fastest growing tech company in the Bay Area, and 96th in North America

-

[Quartz](https://qz.com/work/2053446/the-best-companies-for-working-from-home/) ranked us the #1 best company for remote workers

# **Responsibilities**

We are looking for an exceptional Senior Backend Developer (Ruby/Go) to join our growing Engine team. The Engine team develops and maintains most things related to Workato Recipe runtime. Everything related to recipe execution: DSL, pulling events, processing webhooks, executing jobs. There are various aspects to it: performance, scaling, storage, durability, atomicity, concurrency guarantees, data protection, and encryption.

In this role, you will also be responsible to:

-

Build/extend/troubleshot/fix complex heterogeneous GOlang and Ruby applications, Ruby monolith application, as well as small self-contained GOlang microservices.

-

We also consider strong Ruby only candidates, as well as Golang-only candidates who is open to learn some ruby.

-

Improve execution engine of custom third-party code (Ruby DSL, isolation, performance, new features).

-

Write well designed, testable, efficient code in Ruby and GOlang.

-

Integration of data storage solutions Postgres/S3/DynamoDB/Kafka/ClickHouse etc.

-

Contribute in all phases of the development lifecycle.

-

Provide code reviews to your teammates.

-

Evaluate and propose improvements to existing system.

-

Identify bottlenecks and bugs, and devise solutions to these problems.

-

Help maintain code quality, organization and automatization.

-

We always explore new technologies and work with Rust and Wasm can be foreseen.

# **Requirements**

### **Qualifications / Experience / Technical Skills**

-

Strong experience in building scalable distributed backend applications (5+ years).

-

Great understanding of all building blocks of large web applications: databases, load balancers, application servers, message brokers, caching, monitoring, etc.

-

Good understanding of network protocols and stacks.

-

Good understanding of DB technologies: classic databases and modern no-SQL.

-

Knowledge of basic data structures and algorithms and how they are used is a must.

-

Multilingual programming experience: our code base is primarily in Ruby, with trend to migrate to GOlang and Rust.

-

Excellent debugging, analytical, problem solving, and social skills.

-

BS/MS degree in Computer Science, Engineering or a related subject, 7+ years of industry experience.

### **Optional**

-

Background in GO-lang and/or Rust.

-

Background in network programming.

-

Background in application, data security.

-

Deep knowledge of physical DB design.

-

Experience of working with Docker and other isolation technologies.

-

Experience of working with public cloud infrastructure providers(AWS/Azure/Google Cloud).

-

Experience in related fields (DevOps, ML, DBA, Enterprise applications, etc).

-

Experience in building/deploying data processing pipelines is a plus.

-

Experience of working with third-party REST APIs at scale (request throttling, batch processing etc).

-

Familiarity with WASM platform and toolchain.

-

Kotlint-multiplatform

### **Soft Skills / Personal Characteristics**

-

Readiness to work remotely with teams distributed across the world and timezones.

**(REQ ID: 2587)**

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
