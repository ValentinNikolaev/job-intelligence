# Senior Fullstack Entwickler Java / Angular (m/w/d)

Posted: 2026-08-18T02:17:28Z

## Rejection

- Category: tech_stack
- Reason: Spring Boot is not a target stack

Wer wir sind

Rockstardevelopers, gegründet 2015 in Mannheim, weitere Büros in Stuttgart und München. Wir sind ein Software-Entwickler mit Erfahrung aus hunderten von individuellen Projekten für Enterprise- und Mittelstands-Kunden.

Kurze Wege, ehrliches Feedback, keine politischen Spielchen. Keine Hierarchie-Ebenen zwischen dir und den Leuten, die Entscheidungen treffen.

Deine Aufgaben

Du arbeitest in Kundenprojekten bei großen Unternehmen und öffentlichen Auftraggebern, eingebettet in deren Teams, mit voller Verantwortung für deinen Bereich.

- Fullstack-Entwicklung in Enterprise- und regulierten Umgebungen

- Architektur mitgestalten, nicht nur umsetzen

- Code generieren, reviewen und refactoren mit Claude Code, Copilot oder Cursor

- Code Reviews und technisches Mentoring im Team

- Abstimmung mit Product Ownern, UX und DevOps

Die meisten kommen ein bis zwei Tage die Woche in eins der Büros. Zwang ist das aber keiner. Beim Kunden vor Ort bist du nur für einzelne Termine alle paar Wochen.

Wo du landest

Je nach Projekt und deiner Erfahrung:

- Großkonzerne wie Deutsche Bahn / DB Systel (eisenbahnspezifische Domänen: Fahrplanmanagement, Vertrieb, Leit- und Sicherungstechnik)

- Öffentlicher Sektor / Behörden (z. B. Bundesagentur für Arbeit, ITZBund, Bundesdruckerei) – regulierte Umgebungen, Barrierefreiheit, Security by Design

- Enterprise- und Mittelstands-Kunden aus verschiedensten Branchen

Erfahrung in einem dieser Umfelder ist ein starkes Plus – sag uns in den Fragen, wo du herkommst.

Was du mitbringst

Senior-Level. Unsere Kunden brauchen Leute, die ab Tag eins liefern und eigenständig arbeiten.

**Backend-Kern (das erwarten wir):**

- Java (17+) und Spring Boot (Microservices, Domain Driven Design)

- REST-Schnittstellen und relationale Datenbanken, vor allem PostgreSQL

- Docker und Kubernetes

- Testgetriebene Entwicklung (TDD) mit JUnit – Tests gehören bei uns zur Definition of Done, nicht in die Nacharbeit

- Apache Kafka / asynchrone Kommunikation

- CI/CD (Jenkins, GitHub Actions), Git, agiles Arbeiten

**Frontend (das erwarten wir):**

- Angular mit TypeScript

**Von Vorteil (kein Muss):**

- Kotlin, Camunda (BPMN-Prozessautomatisierung)

- AWS oder Azure, JPA/Hibernate

- Monitoring (Grafana, Prometheus), Tests im Frontend (Jest, Playwright, Cypress)

- Barrierefreiheit (BITV 2.0 / WCAG AA), DevSecOps / Security by Design (öffentlicher Sektor)

Du musst nicht alles können. Wichtig ist, dass du auf beiden Seiten sicher bist und dich schnell in neue Stacks reinfindest.

AI-Tools sind Pflicht, kein Bonus

Claude Code, Copilot, Cursor: Damit musst du produktiv arbeiten können. Nicht weil wir hip sein wollen, sondern weil unsere Kunden das erwarten und wir auch so arbeiten. Wenn du AI-Tools für einen Hype hältst und lieber alles selbst tippst: falsche Firma. Intern investieren wir in deine AI-Skills.

Was wir bieten

- Homeoffice, Büro oder Mix, du entscheidest

- MacBook (außer der Kunde stellt eigene Hardware)

- Verschiedene Kunden, verschiedene Projekte

- Die Gründer sind deine direkten Ansprechpartner

- Internes Upskilling in AI-Entwicklung

Bewerbung

Lebenslauf reicht. Kein Anschreiben nötig. Nach einer kurzen Video-Frage-Runde (2×90 Sekunden) melden wir uns innerhalb weniger Tage.

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
