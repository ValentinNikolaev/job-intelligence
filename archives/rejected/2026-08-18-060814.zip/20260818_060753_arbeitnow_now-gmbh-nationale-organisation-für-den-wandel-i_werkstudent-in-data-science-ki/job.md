# Werkstudent*in Data Science & KI

Posted: 2026-08-18T02:10:16Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**Aufgaben**

- Du unterstützt unser zentrales Daten & Cloud Team bei Datenanalysen, BI-Reporting und Cloud Administration.
- Du entwickelst und pflegst ETL-Pipelines für End-to-End-Datenanalysen – mit Python auf AWS.
- Du führst eigenständig Datenanalysen durch und bereitest die Ergebnisse in aussagekräftigen Dashboards und Berichten in Power BI auf.
- Du verantwortest Aufgaben rund um unser Data Warehouse, etwa Datenmodellierung und Sicherstellung der Datenqualität.
- Du identifizierst neue KI-Use-Cases, analysierst deren Potenzial und setzt erste Prototypen um.
- Du trägst aktiv dazu bei, Daten- und KI-Kompetenz im Unternehmen zu stärken.

**Profil**

Unsere Profilbeschreibung enthält eine Vielzahl unterschiedlicher Kompetenzen, welche wir für diese Stelle relevant finden. Bitte bewirb Dich auch, wenn nicht alle Punkte zu 100 % auf Dich zutreffen.

- Du studierst Informatik, Data Science, Wirtschaftsinformatik, Mathematik oder einen vergleichbaren Studiengang (Bachelor oder Master).
- Du bringst Programmierkenntnisse in Python mit.
- Du hast bereits praktische Erfahrung im Umgang mit REST-APIs und Power BI gesammelt.
- Du interessierst dich für unsere Tech-Umgebung: AWS, Power BI, GitHub.
- Idealerweise hast du erste Erfahrung mit Machine Learning oder GenAI gesammelt.
- Kenntnisse in SQL oder Data-Warehouse-Konzepten sind von Vorteil.
- Erste Berührungspunkte mit Terraform oder Infrastructure as Code runden dein Profil ab.
- Du arbeitest strukturiert, eigenständig und verantwortungsbewusst.
- Du hast Freude daran, komplexe Probleme zu analysieren und Lösungen zu entwickeln.
- Teamgeist, Lernbereitschaft und Begeisterung für neue Technologien zeichnen dich aus.
- Empathie, Kommunikationsfreude und Zusammenarbeit auf Augenhöhe sind dir genauso wichtig wie Fachwissen.
- Du verfügst über sehr gute Deutschkenntnisse (mindestens B2-Niveau).

**Wir bieten**

Eine Unternehmenskultur, die einerseits auf Professionalität, Vertrauen und Eigeninitiative, andererseits auf Begeisterung für die Arbeit, Fairness, Chancengleichheit und flachen Hierarchien basiert. Zudem bieten wir:

- Mitgestaltung der Mobilität der Zukunft, d. h. die Mobilitäts- und Antriebswende in ihrer technologischen, gesellschaftlichen und politischen Breite mit voranzubringen.
- Einblick in das Zusammenwirken von Politik, Verwaltung, Wirtschaft und Wissenschaft in der Verkehrswende.
- Selbstbestimmtes Arbeiten, eine wertschätzende und fördernde Arbeitsatmosphäre sowie Zusammenarbeit im interdisziplinären Team.
- Ein bezuschusstes Job-Ticket.
- Moderne Büros und gut ausgestattete Arbeitsplätze in zentraler Lage mit hervorragender ÖPNV-Anbindung.
- Urban Sports Club als zusätzlicher Benefit zur Förderung deiner Gesundheit und Fitness.
- Einen zunächst auf ein Jahr befristeten Arbeitsvertrag.
- Möglichkeit des mobilen Arbeitens: Bis zu 60 % der Arbeitszeit remote.
- Wöchentliche Arbeitszeit nach Vereinbarung: idealerweise 19,5 Stunden/Woche, flexible Gestaltung passend zum Stundenplan deines Studiums.
- Einen Stundenlohn von **15,00 Euro** für Student*innen im Bachelorstudium und **16,00 Euro** für Student*innen im Masterstudium sowie eine Jahressonderzahlung.

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
