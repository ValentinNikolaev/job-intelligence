# IT Infrastructure Architect – Cloud Focus (m/w/d)

Posted: 2026-08-18T02:30:28Z

## Rejection

- Category: tech_stack
- Reason: role does not mention Go/Golang or PHP

Shopware ist ein führendes E‑Commerce‑System, das Unternehmen weltweit ermöglicht, schnell und effizient zu skalieren. Als zukunftsweisende Open‑Source‑Lösung wird Shopware bereits von einigen der größten europäischen Marken, Einzelhändler und Hersteller in B2C und B2B eingesetzt.

Die Position ist im Bereich IT Operations im Team IT Infrastructure angesiedelt, das die **interne IT‑Infrastruktur** der shopware AG verantwortet. Als IT Infrastructure Architect – Cloud Focus (m/w/d) verantwortest du die **Vision und Architektur der internen Infrastruktur von Shopware**. Du planst und steuerst die Cloud‑Migration verbleibender On‑Prem‑Umgebungen, definierst die Netzwerk‑ und Sicherheitsarchitektur und prägst Standards, Governance und Budgetierung. **Mit Gestaltungsspielraum für Konzeption, Umsetzung und Iteration** hilfst du, eine zukunftsfähige interne Plattform aufzubauen – vom Fundament bis zum Betrieb.

Diese Position kann **vor Ort**, **hybrid** oder **vollständig remote innerhalb Deutschlands** besetzt werden. Dein Arbeitsort wird im Voraus abgestimmt und bildet die Grundlage deines Arbeitsvertrags.

-

Du übernimmst die **End‑to‑End‑Verantwortung** für unsere **Infrastruktur‑Vision und Roadmap, **wie die Komponenten heute zusammenspielen und wie sie sich weiterentwickeln sollen.

-

Durch die **Migration von On‑Premise‑Umgebungen in die Cloud (AWS)** modernisierst du unsere interne Infrastruktur und reduzierst Risiken für interne Services. Dabei definierst du **Patterns und Leitplanken**, die andere wiederverwenden können.

-

Du entwirfst und entwickelst unsere **Netzwerkinfrastruktur** weiter und stellst Segmentierung, Resilienz und Betriebsfähigkeit sicher.

-

Du überprüfst und erhöhst den Standard bei **Monitoring, Backup/Restore und Observability** (z. B. PRTG, Datadog, AWS CloudWatch), um Zuverlässigkeit und Wiederherstellbarkeit zu garantieren.

-

Gemeinsam mit unserem IT Security Specialist und dem Information Security Officer **übersetzt du** **Sicherheitsanforderungen** in **praxisnahe Kontrollen** – von Firewall‑Policies bis zu Identity & Access (Azure AD/ID, lokales AD).

-

Du planst und steuerst das **Infrastruktur‑Budget**, optimierst **Cloudkosten** und triffst fundierte Make‑or‑Buy‑Entscheidungen.

-

**Hands‑on** bleibt Teil der Rolle: Du unterstützt Migrationen, arbeitest eng mit Cloud Engineers zusammen und hilfst bei der Lösung komplexer Incidents, bei denen architektonischer Kontext entscheidend ist.

-

Du leitest **Projekte** und führst bei Bedarf kleine Projektteams fachlich, um Meilensteine termingerecht und qualitätsgesichert zu liefern.

-

Du arbeitest eng mit **internen Stakeholdern** (Team Lead IT Administration, gesamtes IT‑Infrastructure‑Team) sowie **bereichsübergreifenden Partnern** innerhalb von Shopware (z. B. Information Security Officer, Product) zusammen, stimmst Pläne ab und sequenzierst Veränderungen sicher.

### Das bringst du mit:

-

Du verfügst über **2–3 Jahre** **in einer** **vergleichbaren Architektur‑/Leitungsrolle** über Cloud‑ und On‑Prem‑Infrastrukturen.

-

Dein **breites technisches Fachwissen **erlaubt es dir, Netzwerk, Identity, Compute, Storage, Backup/DR und Security zusammenzudenken und pragmatische, skalierbare Entscheidungen zu treffen.

-

**Cloud‑Kompetenz** – insbesondere **AWS** – sowie vCenter, Azure AD/ID und lokales AD befähigen dich, Migrationen und hybride Setups souverän zu steuern.

-

Du bewegst dich sicher in **IaC**, **Enterprise‑Networking**, **VPN** und **Monitoring‑Stacks**; wir setzen Terraform, SonicWall, Cisco Meraki, Tailscale sowie PRTG/Datadog/CloudWatch ein – Erfahrung mit vergleichbaren Tools ist ebenso wertvoll.

-

Ausgeprägte **Planungs‑ und Stakeholder‑Management‑Skills** helfen dir, Roadmaps zu koordinieren, Engpässe früh zu antizipieren und Verbindlichkeit sowie termingerechte Umsetzung sicherzustellen.

-

**Security** ist ein integraler Bestandteil deiner Arbeit: Du übersetzt Richtlinien in durchsetzbare, prüfbare Kontrolle**n** über den gesamten Stack.

-

**Kommunikation** zählt zu deinen Stärken: Du **erklärst komplexe Trade‑offs klar**, passt deine Botschaften vom Executive‑Briefing bis zur technischen Spezifikation an und richtest Teams hinter einem Plan aus.

-

**Sehr gutes Englisch** in Wort und Schrift ist erforderlich; **Deutsch** ist ein großer Vorteil, aber keine Voraussetzung.

-

**Reisebereitschaft** für **regelmäßige Termine **auf unserem Campus in Schöppingen rundet dein Profil ab.

### Das bieten wir dir:

-

**Unternehmenskultur:** Offene Kultur, flache Hierarchien, Eigeninitiative wird gefördert.

-

**Arbeitsverträge:** Unbefristete Anstellungen bieten langfristige Sicherheit.

-

**Flexibilität:** Flexible Arbeitszeiten und Optionen für mobiles Arbeiten und Full-Remote-Verträge.

-

**Ausstattung:** Freie Wahl der Arbeits-Hardware.

-

**Onboarding:** Gut strukturiertes Onboarding mit Unterstützung durch einen persönlichen "Buddy".

-

**Arbeitsumfeld:** Inspirierendes Umfeld mit engagierten Kollegen und einer dynamischen Gemeinschaft.

-

**Entwicklungsmöglichkeiten:** Vielfältige Chancen für persönliches Wachstum und Entwicklung.

-

**Zusatzleistungen:** Attraktive Benefits wie betriebliche Altersvorsorge, Gesundheitsprogramme und regelmäßige Teamevents.

... und vieles mehr!
Einen detaillierten Einblick bekommst du auf unserer [Karriereseite](https://careers.shopware.com/de/warum-shopware/bei-shopware-arbeiten/).

**Deine Ansprechperson für diese Stelle ist Josephine Scheffler und steht dir bei Fragen gerne zur Verfügung!**

Der Schutz deiner persönlichen Daten hat für uns oberste Priorität. Unsere Bewerberinformationen findest du [hier](https://www.shopware.com/de/datenschutz/bewerbende/).

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
