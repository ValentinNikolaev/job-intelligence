# Account Executive (all genders)

Posted: 2026-08-17T23:40:16Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

## The Opportunity

AI is fundamentally changing how enterprises operate.

For decades, procurement teams have relied on spreadsheets, emails, and fragmented processes to manage billions of dollars in spend. As AI agents become capable of executing increasingly complex workflows, enterprise buying decisions are becoming increasingly technical.

At Lio, we're building **THE AI workforce for procurement.**

As an **Account Executive**, you're not just closing deals.

You're helping some of the world's largest enterprises understand how AI can transform the way they operate. You'll identify operational challenges, uncover high-impact AI use cases, and work closely with Product and Engineering to design solutions that create measurable business value.

## What You'll Do

In this role, you will:

-

Own complex enterprise opportunities from first conversation to signed agreement

-

Identify customer pain points and uncover high-impact AI use cases across enterprise procurement organizations

-

Lead strategic discovery sessions, workshops, and solution discussions with procurement, IT, and executive stakeholders

-

Translate customer challenges into compelling business value and scalable solution concepts

-

Partner closely with Product and Engineering to solve complex customer problems and shape the future of our platform

-

Navigate complex buying processes across multiple stakeholders and build long-term customer relationships

-

Capture customer feedback and help turn recurring requirements into scalable product capabilities

## Your Profile

You'll thrive in this role if you:

-

**Know how to identify customer problems.** You ask thoughtful questions, quickly understand operational challenges, and uncover where technology can create meaningful value.

-

**Communicate value, not just features.** You connect technical capabilities with business outcomes and help customers build confidence in a new way of working.

-

**Bring experience in enterprise software sales, technical sales, consulting, venture capital, IT consulting, product management, or another customer-facing role involving complex B2B solutions.** You're comfortable working with sophisticated customers and navigating complex business and technical discussions.

-

**Enjoy working closely with Engineering.** You like collaborating across technical and commercial teams to solve complex customer challenges.

-

**Take ownership by default.** You drive opportunities end-to-end and are accountable for outcomes.

-

**Thrive in fast-paced, high-growth environments** and are excited about helping enterprises adopt AI.

### What's not required

You don't need a Computer Science degree or previous experience in procurement.

We're much more interested in curiosity, analytical thinking, technical affinity, commercial instinct, and your ability to solve customer problems than in having the perfect CV.

## Why Join Lio?

Lio is backed by **Andreessen Horowitz (a16z)** and built at **Y Combinator**. We're bringing Silicon Valley ambition and speed to Munich while building one of Europe's leading AI companies.

From day one, you'll work with Fortune 500 companies across Europe and the US, helping define how AI is adopted inside global enterprises. You'll work side by side with Product, Engineering, and our founders, solving real customer problems while shaping both our product and our go-to-market strategy.

If you're excited about combining technology, enterprise sales, and AI to build category-defining customer relationships, we'd love to hear from you.

**Any questions about the role? Feel free to reach out to** [Anika.](https://www.linkedin.com/in/anika-wiegand-2849b4129/?skipRedirect=true)

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
