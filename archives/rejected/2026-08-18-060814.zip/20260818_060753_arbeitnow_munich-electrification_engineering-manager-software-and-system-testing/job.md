# Engineering Manager - Software and System Testing (f/m/d)

Posted: 2026-08-17T20:40:05Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**About Munich Electrification**

Munich Electrification is an innovative company founded with the aim of accelerating the transition to electric and connected mobility. We develop innovative electronic control units for electric vehicles and stationary storage systems for our global customers. Our international team is composed of highly motivated and exceptional engineers. As a small and specialized team we are well-aware of the importance of each individual colleague and support and promote each employee according to their abilities and needs. Our office with adjacent prototype and testing lab is located in the heart of Munich at the Heimeranplatz.

This is what we stand for:

- **Technological Leadership**: We challenge norms, innovate quickly, and anticipate future needs. We take smart risks and learn from outcomes to stay ahead.

- **Sustainability**: We actively drive change for a sustainable future, aware of our impact and inspiring others to build a better world.

-** Team Culture**: We believe work should be enjoyable, fostering a spirit of inspiration, celebration, and teamwork across the globe.

- **Entrepreneurial Spirit**: We embrace change, think big, and push limits with passion.

**Your Role**

As an **Engineering Manager** within our Testing department, you will be the driving force behind the quality and reliability of our innovative software for Electronic Control Units (ECUs) in the energy storage and electric car sectors. You will lead and mentor a dedicated team of test engineers, taking ultimate responsibility for our overall product quality, test strategy, and process compliance as well as the strategic planning, hiring, and team building of your team. Your strong leadership will be instrumental in building a world-class testing organization and ensuring our products meet the highest standards of safety and excellence, making a significant impact on the future of electric energy storage technology.

**As part of your role, you will:**

**Lead, Empower, and Develop Your Team**

-

Take full personnel responsibility for your team, including hiring, onboarding, professional development, and compensation planning.

-

Act as the primary "Go-To" person and mentor, supporting team members to achieve their goals and grow personally and professionally.

-

Foster a collaborative and innovative team environment, facilitating exchange and knowledge sharing.

-

Monitor team workload and health, manage headcount planning, and structure teams for maximum effectiveness and well-being.

**Own Product Quality and Test Delivery**

-

Hold the overall delivery responsibility for the testing processes of the product groups under your supervision.

-

Enable and empower the team to constantly innovate and enhance our test automation frameworks and infrastructure.

-

Make sure the test strategy and efforts are aligned with the product roadmap and customer needs.

**Drive Process Excellence and Compliance:**

-

Ensure team compliance with critical automotive processes and norms such as ISO 26262, ISO 21434, and [ASPICE](http://ASPICE.Serve).

-

Serve as the primary escalation point for any process, quality, or technical concerns from the team.

-

Act as a direct interface for Product and Project Management, Systems and Software Development leadership, and HR to align on strategies and ensure seamless collaboration.

**Your Profile**

**Educational Foundation: **Successfully completed university degree in Computer Science, Electrical Engineering, or a comparable engineering field.

**Professional Experience:**

-

More than 5 years of professional experience in software quality assurance, validation, or testing, preferably in an automotive embedded systems environment.

-

More than 3 years of experience in a technical leadership, test architecture, or management role, with a proven track record of leading testing efforts for complex products.

-

Demonstrable experience with test automation strategies, tools, and frameworks.

**Domain and Standards Expertise:**

-

Deep understanding of quality and safety-critical standards, ideally with hands-on experience applying **ISO 26262** and **ASPICE** in a testing context.

-

Experience in the field of high-voltage (HV) batteries, ECUs, or battery management systems is a significant plus.

-

Familiarity with automotive cybersecurity (ISO 21434) is highly desirable.

**Leadership Qualities:**

-

Eager to assume comprehensive responsibility for a testing team while embracing ownership of product quality.

-

A creative, curious, and enthusiastic mindset for building robust and reliable electronics solutions for electric vehicles.

-

Exceptional communication and interpersonal skills, with a preference for working collaboratively in cross-functional teams (English required; German favorable).

**Our Offer & Benefits**

The chance to be part of a highly innovative, agile, and unique team with prestigious customers in the automotive and battery storage sector. You will gain a deeper knowledge around connected & electric vehicle batteries, battery management and electronics development and strive in an exciting work environment

**Benefits (Full-time Employees):**

- Trust-based working hours and hybrid work

- Adequate and competitive compensation

- Pension Plan/Bonus

- Free access to the fitness center right next to us or subsidized EGYM Wellpass

- Free snacks, coffee, drinks and lunch (freshly cooked by our chef) every day

- Public transport ticket

- Bike-Leasing via Business Bike

- Experience various inspiring and fun team events

- ME-branded clothing

- Option to "work from anywhere" (6 weeks/year)

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
