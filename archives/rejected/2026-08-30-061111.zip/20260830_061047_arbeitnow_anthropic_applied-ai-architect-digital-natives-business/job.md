# Applied AI Architect, Digital Natives Business

Posted: 2026-08-29T23:55:09Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

## **About Anthropic**

Anthropic’s mission is to create reliable, interpretable, and steerable AI systems. We want AI to be safe and beneficial for our users and for society as a whole. Our team is a quickly growing group of committed researchers, engineers, policy experts, and business leaders working together to build beneficial AI systems.

## **About the role**

As an Applied AI team member at Anthropic, you will be a Pre-Sales architect focused on becoming a trusted technical advisor helping large enterprises understand the value of Claude and paint the vision on how they can successfully integrate and deploy Claude into their technology stack. You'll combine your deep technical expertise with customer-facing skills to architect innovative LLM solutions that address complex business challenges while maintaining our high standards for safety and reliability.

Working closely with our Sales, Product, and Engineering teams, you'll guide customers from initial technical discovery through successful deployment. You'll leverage your expertise to help customers understand Claude's capabilities, develop evals, and design scalable architectures that maximize the value of our AI systems.

## **Responsibilities:**

-

Partner with account executives to deeply understand customer requirements and translate them into technical solutions, ensuring alignment between business objectives and technical implementation

-

Serve as the primary technical advisor to enterprise customers throughout their Claude adoption journey, from discovery to initial evaluation through deployment. You will need to coordinate internally across multiple teams & stakeholders to drive customer success

-

Support customers building with both the Claude API and Claude for Work

-

Create and deliver compelling technical content tailored to different audiences. You will need to be able to spread the gamut from technical deep dives for engineering & development teams up to business value focused conversations with executives

-

Guide technical architecture decisions and help customers integrate Claude effectively into their existing technology stack

-

Help customers develop evaluation frameworks to measure Claude's performance for their specific use cases

-

Identify common integration patterns and contribute insights back to our Product and Engineering teams

-

Travel occasionally to customer sites for workshops, technical deep dives, and relationship building

-

Maintain strong knowledge of the latest developments in LLM capabilities and implementation patterns

## **You may be a good fit if you have:**

-

5+ years of experience in technical customer-facing roles such as Solutions Architect, Sales Engineer, or Technical Account Manager

- Native German speaker with fluent English proficiency

-

Experience working with enterprise customers, navigating complex buying cycles involving multiple stakeholders

-

Exceptional ability to build relationships with and communicate technical concepts to diverse stakeholders to include C-suite executives, engineering & IT teams, and more

-

Strong technical communication skills with the ability to translate customer requirements between technical and business stakeholders

-

Experience designing scalable cloud architectures and integrating with enterprise systems

-

Comfortable with python

-

Familiarity with common LLM frameworks and tools or a background in machine learning or data science

-

Excitement for engaging in cross-organizational collaboration, working through trade-offs, and balancing competing priorities

-

A love of teaching, mentoring, and helping others succeed

-

Excellent communication and interpersonal skills, able to convey complicated topics in easily understandable terms to a diverse set of external and internal stakeholders. You enjoy engaging in cross-organizational collaboration, working through trade-offs, and balancing competing priorities

-

Passion for thinking creatively about how to use technology in a way that is safe and beneficial, and ultimately furthers the goal of advancing safe AI systems

**Deadline to apply: **None. Applications will be reviewed on a rolling basis.

## **Logistics**

**Minimum education: **Bachelor’s degree or an equivalent combination of education, training, and/or experience

**Required field of study: **A field relevant to the role as demonstrated through coursework, training, or professional experience

**Minimum years of experience: **Years of experience required will correlate with the internal job level requirements for the position

**Location-based hybrid policy:** Currently, we expect all staff to be in one of our offices at least 25% of the time. However, some roles may require more time in our offices.

**Visa sponsorship:** We do sponsor visas! However, we aren't able to successfully sponsor visas for every role and every candidate. But if we make you an offer, we will make every reasonable effort to get you a visa, and we retain an immigration lawyer to help with this.

**We encourage you to apply even if you do not believe you meet every single qualification.** Not all strong candidates will meet every single qualification as listed. Research shows that people who identify as being from underrepresented groups are more prone to experiencing imposter syndrome and doubting the strength of their candidacy, so we urge you not to exclude yourself prematurely and to submit an application if you're interested in this work. We think AI systems like the ones we're building have enormous social and ethical implications. We think this makes representation even more important, and we strive to include a range of diverse perspectives on our team.

**Your safety matters to us.** To protect yourself from potential scams, remember that Anthropic recruiters only contact you ----- addresses. In some cases, we may partner with vetted recruiting agencies who will identify themselves as working on behalf of Anthropic. Be cautious of emails from other domains. Legitimate Anthropic recruiters will never ask for money, fees, or banking information before your first day. If you're ever unsure about a communication, don't click any links—visit [anthropic.com/careers](http://anthropic.com/careers) directly for confirmed position openings.

## **How we're different**

We believe that the highest-impact AI research will be big science. At Anthropic we work as a single cohesive team on just a few large-scale research efforts. And we value impact — advancing our long-term goals of steerable, trustworthy AI — rather than work on smaller and more specific puzzles. We view AI research as an empirical science, which has as much in common with physics and biology as with traditional efforts in computer science. We're an extremely collaborative group, and we host frequent research discussions to ensure that we are pursuing the highest-impact work at any given time. As such, we greatly value communication skills.

The easiest way to understand our research directions is to read our recent research. This research continues many of the directions our team worked on prior to Anthropic, including: GPT-3, Circuit-Based Interpretability, Multimodal Neurons, Scaling Laws, AI & Compute, Concrete Problems in AI Safety, and Learning from Human Preferences.

## **Come work with us!**

Anthropic is a public benefit corporation headquartered in San Francisco. We offer competitive compensation and benefits, optional equity donation matching, generous vacation and parental leave, flexible working hours, and a lovely office space in which to collaborate with colleagues. **Guidance on Candidates' AI Usage:** Learn about [our policy](https://www.anthropic.com/candidate-ai-guidance) for using AI in our application process.

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
