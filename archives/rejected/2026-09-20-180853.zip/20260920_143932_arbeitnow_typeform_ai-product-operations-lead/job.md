# AI Product Operations Lead

Posted: 2026-09-20T11:55:10Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

### Who we are

Typeform is a refreshingly different form builder. We help over 150,000 businesses collect the data they need with forms, surveys, and quizzes that people enjoy. Designed to look striking and feel effortless to fill out, Typeform drives 500 million responses every year—and integrates with essential tools like Slack, Zapier, and Hubspot.

Typeform is fully remote by design. For this role, we can hire candidates based in the UK, Ireland, Germany, Portugal or The Netherlands

## About the team

Product Operations sits at the center of how our Product and wider R&D teams work. We help create the systems, practices, and connections that allow teams to focus on solving the right problems and delivering great products.

AI is becoming an increasingly important part of that work. Across R&D, teams are already experimenting with tools like Glean and Claude, building automations, testing agents, and finding new ways to use AI throughout the product development lifecycle.

The opportunity now is to turn that energy into something more systematic.That's where you come in.

## About the role

We're looking for an **AI Product Operations Lead** to build and operate the internal AI Operations capability for R&D.

This is a hands-on role for someone who can take an ambiguous opportunity and turn it into a reliable, adopted solution. You'll help us identify the highest-value problems AI can solve, understand how people work today, design the right solution, build or coordinate its delivery, and then stay accountable for how it performs after launch.

One day, you might be working with a team to understand a frustrating workflow and deciding whether a simple prompt, automation, integration, agent, or internal app is the right answer. The next, you could be improving an existing AI workflow, testing its reliability, helping coordinate access to an enterprise AI tool, or working with IT and InfoSec to make sure a new solution can scale responsibly.

You'll own the connective layer between AI strategy and day-to-day execution across R&D.

This isn't a role for someone who only wants to prototype prompts, manage project plans, or write requirements. We're looking for someone who enjoys combining systems thinking, AI fluency, user discovery, technical execution, and operational ownership—and who wants to see things through.

You'll report to our VP of Product Operations and work closely with Product, Engineering, Design, Research, Data Science, IT, InfoSec, and other AI practitioners across Typeform.

## What you'll do

- Build and continuously improve our backlog of AI opportunities across R&D, helping teams identify, prioritize, and sequence the jobs where AI can have the greatest impact.

- Take ambiguous problems from initial discovery through to delivery: understand the user and workflow, explore options and trade-offs, design the right system, build or coordinate implementation, test, document, launch, measure, and improve.

- Design **simple, AI-native solutions** that fit naturally into how people work. You'll know when a prompt is enough—and when the problem calls for a workflow, integration, agent, database, or custom application.

- Help R&D get more value from enterprise AI tools such as Glean and Claude, partnering with IT and InfoSec on areas including access, configuration, connectors, enablement, and support.

- Own the lifecycle of the AI systems within your portfolio, including automations, skills, agents, and internal web applications.

- Establish practical approaches to evaluation, testing, reliability, observability, security, and maintenance—using evidence and feedback to improve systems over time.

- Partner with teams across R&D to uncover needs, unblock delivery, clarify ownership, and bring the right experts into the work.

- Help run and evolve our R&D AI governance and enablement practices, giving leaders better visibility into active work, risks, adoption, and outcomes.

- Participate in Typeform's broader AI governance efforts as an R&D contributor.

- Work with Finance and other partners to improve visibility into AI tool usage, spend, and value, helping inform investment decisions.

- Explore and support the development of autonomous agents that can improve how we plan, discover, design, build, evaluate, and manage work across the product development lifecycle.

## What you'll bring

- Strong practical experience applying AI to real-world problems—not just experimenting with models, but building solutions that people actually use.

- A track record of taking ambiguous problems from discovery through implementation, testing, adoption, and ongoing improvement.

- Excellent systems thinking. You can understand how people, processes, tools, data flows, integrations, permissions, and technical constraints fit together—and make thoughtful trade-offs between different approaches.

- Strong user and workflow discovery skills. You know how to get beyond the initial request, understand the real job to be done, and simplify a solution when the original approach is more complex than it needs to be.

- Hands-on technical fluency and comfort building, modifying, and troubleshooting internal workflows, automations, agents, or applications.

- Practical experience with modern development practices and tools such as GitHub, repositories and pull requests, basic application hosting, deployment, logging, and operational troubleshooting.

- Experience managing work independently: prioritizing a backlog, handling dependencies and risks, documenting decisions, and communicating clearly with stakeholders.

- A strong approach to evaluation and reliability. You think about what "good" looks like, how to test for it, how to collect feedback, and how to improve a system after it goes live.

- The ability to work effectively across technical and non-technical teams. You're comfortable asking questions, challenging assumptions, seeking expert input, and making progress without needing close day-to-day direction.

- Good judgment around responsible AI, security, access, and governance, and an understanding of when to bring in the right partners.

*Typeform drives hundreds of millions of interactions each year, enabling conversational, human-centered experiences across the globe. We **move as one team**, empowering our collective efforts by valuing each individual’s unique perspective. This fosters **strong bonds** grounded in respect, transparency, and trust. We **champion our diverse customer base** by anticipating their needs and addressing their challenges with priority. Committed to excellence, we** hold high expectations **for ourselves and each other, continuously striving to deliver exceptional results.

We are proud to be an equal-opportunity employer. We celebrate diversity and stand firmly against discrimination and harassment of any kind—whether based on race, color, ancestry, religion, sex, national origin, sexual orientation, age, citizenship, marital status, disability, gender identity or expression, or veteran status. Everyone is welcome here.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
