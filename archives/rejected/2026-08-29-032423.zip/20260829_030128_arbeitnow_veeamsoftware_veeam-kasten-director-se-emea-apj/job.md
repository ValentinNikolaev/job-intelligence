# Veeam Kasten, Director SE – EMEA & APJ

Posted: 2026-08-28T20:55:07Z

## Rejection

- Category: tech_stack
- Reason: role does not mention Go/Golang or PHP

Veeam is the Data and AI Trust Company, specializing in helping organizations ensure their data and AI are fully understood, secured, and resilient to enable the acceleration of safe AI at scale. As the market leader in both data resilience and data security posture management, Veeam is built for the convergence of identity, data, security, and AI risk. Headquartered in Seattle with offices in more than 30 countries, Veeam protects over 550,000 customers worldwide, who trust Veeam to keep their businesses running. Join us as we go fearlessly forward together, growing, learning, and making a real impact for some of the world’s biggest brands.

#### **About the Role**

**Veeam Kasten *for Kubernetes*** is Veeam's Kubernetes-native data protection platform, purpose-built for modern cloud-native applications and AI-driven workloads. As enterprises accelerate Kubernetes adoption through container-based application modernization and modern virtualization, Kasten is positioned to be the data resilience standard for cloud-native infrastructure.

Reporting to the leader of Worldwide Kasten Solution Sales, you will partner with regional Kasten and field sales leadership to build territory strategy, raise technical win rates, and scale Kasten expertise across the broader Veeam field organization. You will also own the field-to-product feedback loop, working directly with Kasten Product Management and engineering to represent customer requirements. While Kasten is the primary focus, this leader will also support Veeam Data Platform opportunities where Kubernetes and virtualization workloads converge.

This is a hands-on leadership role. You will inherit an established team of senior specialists, and your mandate is to make them better: sharper technical execution, deeper coverage across both regions, and a higher bar for how Kasten is positioned and proven. You will stay credible in front of enterprise architects and technical executives.

#### **What You’ll Do**

- Lead and develop a distributed team of Kasten Specialist Solutions Engineers/Architects across EMEA and APJ

- Own the technical win across both regions: set the standard for discovery, solution architecture, demonstration, and POC execution, and hold the team accountable to measurable technical win rates

- Partner with regional specialist and field sales leaders on territory planning, pipeline development, and pursuit strategy, and lead regular business reviews on technical pipeline health

- Build Kasten and VDP Proxy technical capability across the wider Veeam field organization through enablement, certification, and repeatable assets

- Develop the ecosystem technical relationships that matter in region, including Red Hat, AWS, SUSE, and regional channel partners and system integrators

- Travel up to 30% across EMEA and APJ, with occasional global travel

#### **What You’ll Bring**

- 8+ years of pre-sales or solutions engineering experience in enterprise software, including 3+ years in a people leadership role

- Track record of leading pre-sales teams, including coaching, development, retention, and performance management across multiple countries, cultures, and time zones

- Hands-on experience with Kubernetes and virtualized environments in production or evaluation, and working knowledge of enterprise data protection and recovery

- Demonstrated success supporting complex, multi-stakeholder enterprise deals with long sales cycles, including channel-led and partner-influenced motions

- Ability to translate complex technical capabilities into business value, and to present credibly to groups of varying size and seniority

#### **Bonus Skills**

- Background selling to enterprise DevOps, Platform Engineering, or IT Operations teams

- Direct experience with Kubernetes data protection, or with container and virtualization platforms such as Red Hat OpenShift, AWS EKS, or VMware vSphere

- Leadership experience in a high-growth environment, launching or scaling a new product or business inside a larger enterprise or a startup

- Experience operating in a specialist overlay model alongside a core field sales organization

- Credibility in the cloud-native community, through CNCF project involvement, conference speaking, or open-source contribution

#### **What You’ll Get **

- Comprehensive Financial Security – Company-sponsored retirement savings, life insurance, and accident coverage to help protect you and your family.

- Generous Time Off – Enjoy 30 vacation days per year, plus company-wide VeeaMe Days dedicated to rest, wellbeing, and self-care.

- Wellbeing & Mental Health Support – Access confidential counseling and professional support services through our Employee Assistance Program for employees and their families.

- Make an Impact Beyond Work – Receive paid volunteer time each year through the Veeam Cares program to support causes that matter to you.

- Healthcare & Wellness Benefits – Benefits include healthcare support and wellbeing-focused programs designed to help you thrive both personally and professionally.

- Additional Lifestyle Perks – Enjoy benefits that support your everyday wellbeing, including lifestyle-focused programs and employee-friendly perks.

Please note: If an applicant is permanently located outside of Germany, Veeam reserves the right to decline the application for this position

#LI-IN1

**Veeam Software is an equal opportunity employer** and does not tolerate discrimination in any form on the basis of race, color, religion, gender, age, national origin, citizenship, disability, veteran status or any other classification protected by federal, state or local law. All your information will be kept confidential.

Personal data collected during the recruitment process will be processed in accordance with our [Recruiting Privacy Notice](https://www.veeam.com/legal/recruiting-privacy-notice.html), which explains how your information is collected, used, and handled in connection with hiring activities. By applying for this position, you consent to this processing.

By submitting your application, you confirm that the information provided, including any supporting documents, is complete and accurate to the best of your knowledge. Any misrepresentation, omission, or falsification may result in disqualification from consideration or, if discovered after employment begins, termination of employment.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
