# Head of Corporate Technology

Posted: 2026-08-12T20:40:10Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

We're building a new global Berlitz, and this is your opportunity to help shape it. Nearly 150 years of expertise, meeting the ambition and technology to power a new era of learning.

If you are the kind of person who thrives in a fast-paced environment, isn’t afraid of a blank page, and is excited to help shape the future of a global company undergoing a significant transformation, **you might belong at Berlitz!**

We're looking for a hands-on (**~**70%) **Head of IT & Security** to lead our internal IT, security, and compliance function as we scale. Reporting to the CPTO, you'll ensure our people, systems, and data remain secure while enabling the business to move quickly. You'll work closely with Engineering, Legal, People, and Technology leadership to build a modern, resilient, and compliant operating environment.

**Your responsibilities**

-

Lead our IT Support, Security, and Compliance teams, creating a reliable and scalable internal technology function.

-

Own security and compliance programmes, including SOC 2 Type II and ISO 27001 certification, ensuring we maintain a strong security posture.

-

Manage Microsoft 365 across a complex, multi-tenant environment, balancing security, identity, and user experience.

-

Oversee key technology vendors, driving contract renewals, licensing optimisation, and commercial negotiations.

-

Partner with Engineering to manage security risks during major platform and legacy system migrations.

-

Work closely with Legal, the DPO, and People teams to ensure compliance, governance, and security practices are embedded across the organisation.

**Who you are**

-

You have significant experience leading IT, Security, or Corporate Technology functions in a growing technology business.

-

You have successfully led or co-led a **SOC 2 Type II** or **ISO 27001** certification programme.

-

You have hands-on experience managing Microsoft 365 in complex or multi-tenant environments.

-

You have managed enterprise technology vendors, software licensing, and contract negotiations.

-

You're familiar with GRC platforms such as **Scytale** or similar compliance automation tools.

-

You've worked closely with Product and Engineering teams and are comfortable operating as a strategic partner rather than a standalone IT function.

-

Experience in EdTech, language services, or a business serving both B2B and B2C customers is highly valued.

**Why you should join**

-

Build and lead the security and IT function supporting the next generation of Berlitz products.

-

Partner directly with the CPTO and Engineering leadership on strategic technology initiatives.

-

Shape security, compliance, and operational standards that will support the company's continued growth.

-

Join a collaborative international team focused on delivering secure, reliable technology that enables better learning experiences worldwide.

-

Remote work but occasional travel may be required for business engagements or events.

*At Berlitz, connecting people across languages and cultures is at the heart of what we do. Our global workplace reflects the diverse world we serve, bringing together different backgrounds, experiences and perspectives. We create an inclusive environment where everyone has an equal opportunity to belong, contribute and grow.*

Ready to shape what’s next? Join us and help build the future with us.

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
