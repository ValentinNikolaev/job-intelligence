# Forward Deployed Engineer – AI (w/m/d) in Voll- oder Teilzeit

Posted: 2026-08-12T20:09:38Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**Unser JobChat**

Als modernes Unternehmen verzichten wir auf Stino-Stellenanzeigen und möchten dich mit einem neuen Format für die CROZ DACH begeistern. Vielen Dank für dein Interesse an uns und viel Spaß beim Lesen des folgenden JobChats!

**Neulich in der Teamküche:**
Linda: “Und wie war’s beim Kundenmeeting letzte Woche?”
Joachim: „Sehr gut und vor allem interessant. Bei den vielfältigen Anforderungen brauchen wir auf jeden Fall Unterstützung im AI-Bereich.“
Linda: „Ok. Also suchen wir noch jemanden für **AI Consultant**, richtig?“
Joachim: „Eigentlich suchen wir einen **Forward Deployed Engineer - AI ****(w/m/d)**. Diese Rolle ist besonders, weil wir eine **BizTech-Beratung **sind: Dieselben Leute, die das Geschäft des Kunden verstehen, bauen auch die Software. Du sitzt mit am Tisch, wenn das Problem definiert wird, und du bist auch die Person, die **die Lösung baut, in Produktion bringt und die Verantwortung dafür übernimmt**."
Linda: „Verstehe. Es geht also darum, **Deployments end-to-end **zu verantworten und nicht nur **'Tickets abzuarbeiten'**?“
Joachim: „Genau. Gute Lösungen entstehen nur aus einem **gemeinsamen Verständnis von Business und Technologie**. Du verantwortest Deployments end-to-end, vom Discovery und Scoping über die Architektur bis hin zum Build und dem **produktiven Rollout**. Wir arbeiten mit dem **deutschen Mittelstand (KMU) und Großunternehmen **zusammen, oft in **regulierten Umgebungen** mit **strenger Datensouveränität**. Das bedeutet auch, dass für diese Rolle eine **EU-Staatsangehörigkeit **zwingend erforderlich ist, damit es uns erlaubt ist, AI-Systeme innerhalb der Realität von **Legacy-Systemen **und **komplexen Prozessen **zu bauen.“
Linda: „Das klingt herausfordernd. Welche technischen Skills suchen wir?“
Joachim: „Wir brauchen jemanden mit einem **soliden Engineering-Hintergrund** und **2+ Jahren Erfahrung in Software Engineering oder ML**. **Production-grade Python** ist ein Muss, ebenso wie Erfahrung in der Auslieferung von Software mit **LLM- oder ML-Komponenten**, wie **RAG-Systemen** oder **Agenten**.“
Linda: „Und es geht nicht nur um Prototypen, oder?“
Joachim: „Definitiv. Prototypen sind der Startpunkt, nicht das Ziel. Wir bauen Systeme, die tatsächlich laufen, egal ob **on-premises oder in der Cloud**. Es geht darum, **echten Mehrwert für unsere Kunden** zu schaffen.“
Linda: „Was ist mit den 'Soft Skills'?“
Joachim: „Du solltest echte **Freude am direkten Kundenkontakt **haben und **in unklaren Situationen die Ruhe bewahren**. Es gibt selten ein fertiges Ticket. Du strukturierst die Unklarheit selbst. Und da unsere Kunden in der gesamten DACH-Region ansässig sind, gehört eine **Reisebereitschaft (ca. 25 %) **zum Job dazu.“
Linda: „Und die üblichen Voraussetzungen? Abschlüsse, Sprachen?“
Joachim: „Ein Abschluss in Informatik oder Ähnlichem ist gut, aber uns ist die Fähigkeit, neue Technologien schnell zu erlernen, wichtiger. **Fließendes Deutsch und Englisch auf C1-Level **sind zwingend erforderlich für die Kommunikation mit unseren Kunden und unserem Hauptsitz in Zagreb. Kroatisch wäre das Sahnehäubchen.“
Linda: „Was kann jemand neues bei uns in Bezug auf Gehalt und Benefits erwarten?“
Joachim: „Für eine Senior-Position zahlen wir **bis zu 90.000 €**. Dazu kommen **Benefits** wie die **betriebliche Altersvorsorge (bAV)**, **Kindergartenzuschuss** und **flexible Arbeitszeiten**.“
Linda: „Wie sieht der Bewerbungsprozess aus?“
Joachim: „Zuerst ein Gespräch mit Peter und mir. Dann folgt eine **Case Study**, bei der wir den Kunden spielen und gemeinsam ein realistisches Problem bearbeiten. Es geht nicht um einen 'Richtig oder Falsch'-Test, sondern um **gemeinsames Problemlösen** und darum, **ob die Chemie zwischen uns stimmt**. Zum Schluss gibt es ein Treffen mit dem Team und den KollegInnen in **Zagreb**, um den **CROZ-Spirit** zu spüren.“
Linda: „Klingt nach einem Plan. Suchen wir jemanden, der zu unserer Persönlichkeit und unserem Teamspirit passt!“

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
