# AI Data Specialist - German

Posted: 2026-08-13T02:04:22Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

We are looking for **AI** **Data Specialists** to support the improvement of AI-generated content in **German.**

**Job Type:** Freelance

**Location:** Work from home

***Work Schedule: ***Part-time - 10+ hours per week. Flexible - work whenever you want.

**Start Date:** Immediately

**Rate:** 18 USD per hour (rates vary per country. If you are based elsewhere, the rates will be different)

**Help Shape the Future of AI**

Are you a student, recent graduate, stay-at-home parent, gig worker, or professional seeking flexible remote work? Are you interested in shaping the development and safety of today’s AI models?

**What You’ll Do**

The role involves performing diverse data-related tasks, including:

- Data collection, evaluation, and annotation.

- Pairwise comparisons.

- Counting tasks.

- Object tagging and labeling across different content types (audio, video, images, or collected data)

**What we’re looking for:**

*- Native-level fluency in German*

*- English Proficiency: *Fluent or advanced proficiency in English (levels B2–C2)

*- AI & Data Capabilities (Preferred):* Experience in one or more of the following areas: machine learning tasks, data collection and preprocessing, data evaluation and quality assurance, and data annotation and labeling.

**What We Offer**

- Flexible schedule

- Opportunity to earn extra income

- Timely payments

- The job is ideal for students, part-timers, or stay-at-home parents

**Vendor Type**

**When applying, please select the option that best describes your working status.**

**Are you a Freelancer or Private Individual?**

A Freelancer is someone who has a business license and may have a VAT number or EIN for tax purposes. A VAT (Value Added Tax) number is a unique identifier assigned to registered businesses in many countries; an EIN (Employer Identification Number) is a similar identifier used in the US. A Private Individual does *not *have a business license. If you aren’t sure, you are probably a private individual.

**RWS embraces DEI** and promotes equal opportunity, we are an Equal Opportunity Employer and prohibit discrimination and harassment of any kind. RWS is committed to the principle of equal employment opportunity for all employees and to providing employees with a work environment free of discrimination and harassment. All employment decisions at RWS are based on business needs, job requirements and individual qualifications, without regard to race, religion, nationality, ethnicity, sex, age, disability, or sexual orientation. RWS will not tolerate discrimination based on any of these characteristics.

#LI-PR15

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
