# Senior DevOps Lead

Posted: 2026-08-12T23:55:38Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**Location:** Berlin, Germany **Remote Status:** Fully Remote (#LI-Remote)

LivePerson (NASDAQ: LPSN) is a leader in trusted enterprise conversational AI and digital transformation. The world's leading brands use our award-winning Conversational Cloud platform to connect with millions of consumers. We power nearly a billion conversational interactions every month, providing uniquely rich data analytics and safety tools to unlock the power of conversational AI for better business outcomes. Fast Company named LivePerson the #1 Most Innovative AI Company in the world.

### **Position Overview**

The Observability Platform team is building a state-of-the-art observability ecosystem for logging, monitoring, and tracing across cloud and on-premises data centers. We’re looking for an experienced** Senior DevOps Lead **to lead our Logging and Monitoring initiatives and drive the development of robust, scalable observability solutions within Google Cloud Platform (GCP).

In this role, you’ll help build systems that give software engineers greater visibility into the health, performance, and reliability of their applications and services. You’ll oversee a modern observability technology stack that includes Elastic Cloud, Loki, Grafana Labs, and the ELK stack for logging, as well as Zabbix, Captain Hook, and Anodot for metrics, monitoring, and anomaly detection.

** **

### **You Will: Key Responsibilities & Impact**

- Lead the design, implementation, operation, and continuous improvement of LivePerson’s observability platforms across logs, metrics, traces, alerting, and synthetic monitoring.

- Own and optimize large-scale observability pipelines processing high volumes of telemetry data daily, leveraging technologies such as Filebeat, Kafka, Logstash, Elastic Cloud, Prometheus, OpenTelemetry, Grafana Labs, Zabbix, Anodot, and related tools.

- Design, build, and maintain scalable, Kubernetes-based observability services using Helm, CI/CD pipelines, GCP, GKE, Docker, and cloud-native best practices.

- Define and establish observability standards, dashboards, alerting frameworks, best practices, and onboarding resources for hundreds of engineering users.

- Partner closely with DevOps, SRE, Engineering, NOC, Security, and vendor teams to deliver reliable, scalable, and actionable observability solutions.

- Evaluate emerging observability technologies and drive adoption of modern practices in areas such as OpenTelemetry, distributed tracing, anomaly detection, and proactive monitoring.

- Lead the design and development of an end-to-end Synthetic Monitoring platform, running hundreds of daily synthetic tests on GCP Spot VMs to enable proactive service validation and help engineering teams identify potential issues before they impact customers.

- Provide technical leadership and mentorship, driving best practices across observability, DevOps, and cloud engineering.

### **You Have: Required Skills & Qualifications**

- **5+ years of experience** in software engineering, DevOps, SRE, or a related discipline, with a strong background in application development and cloud engineering.

- Bachelor’s degree in Computer Science, Engineering, or a related field, or equivalent professional experience.

- Strong experience with Kubernetes and containerization technologies, including Docker.

- Extensive experience with observability and monitoring technologies such as Grafana Labs, Captain Hook, Zabbix, Fluentd, ELK, Kafka, and Prometheus.

- Experience with Infrastructure as Code (IaC) tools such as Terraform, Ansible, or CloudFormation.

- Experience working with cloud platforms such as GCP, AWS, or Azure, including compute, storage, networking, and related cloud services.

- Strong programming and scripting skills in one or more languages, such as Go, Java, JavaScript, or Python.

- Experience designing and operating highly available, scalable, production-grade systems.

- Strong understanding of CI/CD practices and cloud-native development methodologies.

- Experience with OpenTelemetry Collector and Grafana Agent is highly preferred.

- Excellent problem-solving, communication, and collaboration skills, with the ability to influence technical direction across engineering teams.

### **Our Benefits & Perks**

We are committed to supporting the complete well-being, health, financial security, family, and professional growth of our permanent employees.

#### **💰 Financial Security & Growth**

- **Additional Pension scheme**: deferred pension scheme (LivePerson contributes 20%), ESPP and annual bonus depending on achievements

- **Equipment**: Internet and Mobile reimbursement

- **Development:** Access to internal professional development resources.

#### **👨‍👩‍👧‍👦 Time Away & Family Support**

- **Flexible Paid Time Off (PTO):** Personal time off 33 days , vacation (28 days) and care days (5)

- **Paid Public Holidays.**

**Volunteering Days: Use them to make a difference in your community. Whether it's a cleanup, supporting a local initiative or holding an “Ehrenamt”, just let us know! We're here to help you create a meaningful impact.**

#### **💻 Workplace Flexibility**

- **Remote-First Model:** Be flexible, work flexibly and from anywhere - no defined working hours or boundaries with offices in Mannheim and Berlin

- **Monthly Connection:** Join our monthly connection pizza day in the office!

### **Why You’ll Love Working Here**

As leaders in enterprise customer conversations, we celebrate diversity, empowering our team to forge impactful conversations globally. LivePerson is a place where uniqueness is embraced, growth is constant, and everyone is empowered to create their own success. We're very proud to have earned recognition from Fast Company, Newsweek, and BuiltIn for being a top innovative, beloved, and remote-friendly workplace, and recognized by Gartner as a leader in the Conversational AI space.

### **Belonging at LivePerson: Equal Opportunity Employer**

We are committed to fostering an inclusive workplace and are proud to be an **Equal Opportunity Employer (EOE)**. We believe that diverse perspectives drive innovation. All qualified applicants will receive consideration for employment without regard to race, color, religion, sex, sexual orientation, gender identity, national origin, disability, veteran status, or other characteristics protected by US Federal, State, or Local law.

### **Accessibility Commitment**

LivePerson is dedicated to the accessibility needs of our applicants and employees. We provide **reasonable accommodations** to job applicants with disabilities. Applicants who require a reasonable accommodation for any part of the application or hiring process should inform their recruiting contact upon initial connection.

### **Important Candidate Notice**

The talent acquisition team at LivePerson has recently been notified of a phishing scam targeting candidates applying for our open roles. Scammers have been posing as hiring managers and recruiters in an effort to access candidates' personal and financial information. The phishing scam is not isolated to only LivePerson and has been documented in news articles and media outlets.

Please note that any communication from our hiring teams at LivePerson regarding a job opportunity will only be made by a LivePerson employee with an ----- email address. LivePerson does not ask for personal or financial information as part of our interview process, including but not limited to your social security number, online account passwords, credit card numbers, passport information, and other related banking information. If you have any questions and or concerns, please feel free to contact -----

*

*

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
