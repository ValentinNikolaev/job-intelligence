# Senior Product Manager, Payments (all genders)

Posted: 2026-08-12T23:30:15Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**Distribusion** is the world’s leading ground transportation marketplace and gives travelers seamless access to ground transportation online, from search to ticket purchase. We have built a cutting-edge B2B technology platform that connects bus, rail, and ferry operators in 70+ countries with the biggest online retailers, including Google Maps and Booking.com.

We are shaping the future of travel and building the largest global network of transport providers and retailers. Having grown 10x in the past year, we are one of the fastest-growing startups in travel. Backed by four leading VCs (TQ Ventures, Creandum, Northzone, and Lightrock), and now, following our recent $80 m Series C, we are ready to push beyond.

We are looking for a **Senior Product Manager** to build the payment infrastructure behind millions of transactions.

Distribusion is transforming from a marketplace enabler to a global travel infrastructure provider — and Financial Services is our newest, highest-impact department. You'll define the systems that sit between our customers, our merchants, and the global payments ecosystem — building for reliability, conversion, and scale.

**What you will do:**

-

Own the product vision and roadmap for payments, checkout, fraud, and routing

-

Design scalable APIs and tools for internal teams and external merchants

-

Define KPIs and frameworks for PSP performance, fraud rates, and acceptance

-

Lead discovery and delivery in a high-volume, regulated transaction environment

-

Align commercial, technical, and financial stakeholders across markets

-

You’ll turn payments into a growth driver — boosting acceptance, reducing fraud, and improving conversion

-

Define and track KPIs like fraud rates, PSP performance, and routing success

-

Drive real business impact through higher acceptance rates, lower fraud, and improved conversion

**Workplace: **Berlin & Hybrid

We are mainly looking for this role to be based within Germany, preferably in our HQ in Berlin.

We are a remote-first company, with teams located around the Globe and our HQ office in Berlin, where the team often meets in the office.

**Who you are:**

-

You’ve led complex payment or fraud systems, ideally from scratch

-

Skilled in routing efficiency, fraud mitigation, and conversion optimization

-

Hands-on with global PSPs (e.g., Adyen, Stripe, dLocal) and fraud tools (e.g., Sift, Signifyd)

-

Strong in data — you define, analyze, and act on key metrics

-

Technically fluent and comfortable working with engineers on architecture and APIs

-

Experienced in cross-functional alignment (commercial, legal, compliance, finance)

-

Thrive in ambiguity and build clarity and momentum quickly

-

Nice to have: Experience with emerging markets or LATAM, smart routing, or scoring models

**What you can expect:**

-

Make a global impact. Help shape how millions of people discover and book ground transportation worldwide.

-

Own your work. Take responsibility from day one and see the direct impact of your contributions.

-

Build with the best tools. We move fast, continuously evolve our tech stack, and invest in modern, efficient solutions.

-

Work with industry leaders. Our partners include [Booking.com](http://Booking.com), Google Maps, Amtrak, Deutsche Bahn, Renfe, and SNCF.

-

Grow with exceptional people. Join an international team that will challenge, support, and inspire you every day.Work your way.

-

Enjoy flexible and remote-friendly working options, relocation opportunities, and plenty of room to grow.

**Our hiring process for this role:**

Your Talent Partner (TP) and point of contact is Anh Do and the Hiring Manager (HM) is Francesc Ferre.
*For any queries, please contact your Talent Partner at (*Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
