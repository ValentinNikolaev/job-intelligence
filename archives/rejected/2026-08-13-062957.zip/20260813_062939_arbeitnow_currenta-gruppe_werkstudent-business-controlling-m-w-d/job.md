# Werkstudent Business Controlling (m/w/d)

Posted: 2026-08-13T02:30:14Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Die CURRENTA GRUPPE sucht Dich für die Group Function Controlling.

Als Werkstudent*in Controlling bist Du für die folgenden Aufgaben verantwortlich:

-

Unterstützung bei den **Monatsabschlussaktivitäten**, dem kaufmännischen Reporting sowie Forecast- und Mittelfristplanungsprozessen

-

Mitarbeit an der **Optimierung, Weiterentwicklung und Automatisierung von Reportings und Excel-Tools**

-

Erstellung von **PowerPoint-Anleitungen** und Dokumentationen zu Arbeitsabläufen im Controlling

-

Zusammenarbeit mit verschiedenen kaufmännischen Bereichen und **aktive Mitarbeit an bereichsübergreifenden Projekten**

-

Laufendes Studium der **Wirtschaftswissenschaften**, des **Wirtschaftsingenieurwesens** oder eines vergleichbaren Studiengangs

-

Interesse an **Controlling-Prozessen, Reporting und betriebswirtschaftlichen Zusammenhängen**

-

**Analytische Denkweise** sowie eine strukturierte und selbstständige Arbeitsweise

-

Freude an der Zusammenarbeit mit verschiedenen Fachbereichen und eine **offene Kommunikation**

-

Idealerweise **sehr gute Kenntnisse in Microsoft Office 365**, insbesondere Excel und PowerPoint

-

**Engagement, Teamgeist und die Motivation, neue Themen aktiv mitzugestalten**

***Hinweis:***

*Die Gehaltsangabe basiert auf einer Wochenarbeitszeit von 20 Stunden in Teilzeit und je nach Studiengrad (Bachelor / Master). In den vorlesungsfreien Zeiten ist eine Stundenaufstockung möglich.*

*Die Veröffentlichung dieser Anzeige auf Drittanbieter-Portalen ohne unsere ausdrückliche Zustimmung ist untersagt.*

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
