# (Senior) Product Designer (m/f/d)

Posted: 2026-08-12T20:40:20Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

## **YOUR JOB**

We are building the AI-Copilot that makes privacy and security compliance invisible for operators and value unmistakable for executives. Our platform turns ongoing compliance activity into quantified risk intelligence.

Your mandate: Improve the product experience of existing solutions used by our customers, and unite our separate Security & Compliance products into one platform experience for thousands of users. You will do it together with our product design team and stakeholders, using your unification track record and product knowledge to delivery impactful merged experiences, modernize our design system, and embed AI into meaningful customer workflows.

We are looking for a curious, business-focused product designer who has unified separate products before and can show it, measuring design by the business outcomes it moves, while providing the pace and persistence this transformation demands. The design decisions made here define how our customers will experience our platform for years.

##

## **LET'S PROTECT THE PEOPLE BEHIND THE DATA**

We are a fast-growing security and compliance tech company with a clear purpose: we protect the people behind the data. With over 200 team members worldwide and with offices in Munich, Berlin, London, Stockholm, and Vienna, we help more than 4,000 global customers get certified fast and build a strong and scalable risk posture. With AI-powered automation, self-serve capabilities, and additional tailored expert advice, we offer our customers a seamless security and compliance experience to stay ahead of the rapidly evolving security landscape and challenges like the surge in cyber-attacks.

##

## **WHAT YOU'LL BE DOING**

As AI accelerates delivery, this role is less about shipping faster and more about deciding what is worth shipping.

***Platform Unification***

-

Define the information architecture and interaction models that bring two product experiences, each with its own product-market fit, into one platform experience.

-

Evolve the design system across the product line, improving consistency to live products without breaking what our customers rely on today.

-

Decide together with Product, Engineering and design colleagues what unifies now, what waits, and validate those calls with customer evidence.

***Product & AI ***

-

Carry product design for assigned work from early discovery, through to UX flows and high-fidelity UI and handoff assets.

-

Design agent-enabled experiences that change how customers engage with the platform.

-

Bring customer-understanding into every design decision: personas, research, competitive analysis, and product data.

-

Use AI to prototype early and often, with feedback loops that capture decisions, and continually improve decision speed and precision.

***Communication, Documentation and Influence***

-

Document the why behind design recommendations, using annotated flows, decision logs, and UX rationale in design briefs & deliverables in Jira and Confluence systems.

-

Collaborate with Product, Engineering and C-Level leadership on problem framing.

-

Present and demo work confidently and help raise the craft bar of a design culture others want to join.

##

## **WHAT YOU'LL GET IN RETURN**

-

The freedom, trust, and tools to do what you love and make an impact in a purpose-driven company, committed to doing genuine good in the digital world.

-

Enjoy a high degree of flexibility with tailored working hours, choice of work location, and benefits that support your lifestyle, health, and family needs.

-

Join a secure, future-focused role in a dynamic scale-up positioned to make a major impact in the rapidly expanding Security & Compliance market.

-

Grow along expert or leadership paths with support from employee accelerator programs, bi-annual feedback cycles, and a personal training budget.

-

Work in an environment that values autonomy, rapid decision-making, a flat hierarchy, and collaborative, eye-level communication to keep things moving forward.

-

Direct partnership with Product, Marketing, Customers and In-House Experts and AI capability teams on work that matters to real customers.

##

## **THE QUALITIES YOU'LL NEED FOR A SUCCESSFUL CAREER AT DATAGUARD**

-

**5+ years in product design (SaaS and/or B2B)**, with a portfolio that shows strong UX thinking, systemic approaches and high-quality visual craft, and that includes at least one unification (e.g. products merged into one experience, a design system migration on a live product, or an information architecture overhaul at platform scale)

-

**Curiosity about the business** and how we grow with our customers, connecting design decisions to revenue, retention and customer impact.

-

**Drive **to take on ambiguous problem spaces that need discovery, not just feature execution.

-

**Strong product thinking**, actively challenging problem framing and scope to ensure the highest impactful business and customer outcomes get built first.

-

**Confident collaboration **with customers, Product & Engineering and C-Level stakeholders, knowing when to push, adapt or move to execution.

-

**We value** a good sense of humor and the humility of a beginner while having the appetite to grow: Taking on scope, systems of work, while intentionally developing further personal and Team competencies

## **LAST BUT NOT LEAST. FROM THE BOTTOM OF OUR HEARTS:**

No matter your origin, ethnicity, gender identity, religion or individual requirements; at DataGuard, all that counts is the person you are. As Guards and Guardettes, we are united not only by our dedication, but also by our shared belief in our purpose: Protect the people behind the data. Convince us with your personality and your skills – and together we will make great things happen. We are looking forward to meeting you!

#LI-DNI

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
