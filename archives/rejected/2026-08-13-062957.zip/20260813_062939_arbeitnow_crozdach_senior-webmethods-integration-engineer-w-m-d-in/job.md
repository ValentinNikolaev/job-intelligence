# Senior webMethods Integration Engineer (w/m/d) in Teil- oder Vollzeit

Posted: 2026-08-12T20:09:38Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**Unser JobChat**

Als modernes Unternehmen verzichten wir auf Stino-Stellenanzeigen und möchten dich mit einem neuen Format für die CROZ DACH begeistern. Vielen Dank für dein Interesse an uns und viel Spaß beim Lesen des folgenden JobChats!

**Neulich in der Teamküche:**

**Joachim**: Wir brauchen jemanden, der sich mit webMethods auskennt.

**Linda**: Ich habe bereits eine Stellenanzeige vorbereitet – der Titel lautet Senior webMethods Integration Engineer (f/m/d).

**Markus**: Aber bitte kein Silodenken. Wir suchen jemanden, der den gesamten Integrationslebenszyklus verantwortet: Design, Entwicklung, Release und Betrieb. Wer den Flow entwirft, baut ihn auch, deployt ihn und betreut ihn. Ein echter Generalist.

**Peter**: Konkret bedeutet das: Entwurf von Integrationsflows mit Designer – von einfachen Point-to-Point-Verbindungen bis hin zu komplexen Orchestrierungen. Entwicklung von Services in der webMethods Flow-Sprache (BRANCH, MAP, INVOKE, LOOP, SEQUENCE) und in Java, Aufbau von Adapter-Integrationen (SAP, JDBC, Salesforce & Co.) sowie Implementierung von Datentransformationen mit DTL oder XSLT.

**Markus**: Und danach fängt der eigentliche Spaß an: Releases über CI/CD-Pipelines mit Deployer, Command Central und Tools wie Jenkins oder GitLab CI – über DEV, TEST, UAT und PROD hinweg. Im Betrieb: Monitoring mit My webMethods und Optimize, Incident-Behebung, Performance-Tuning – und Ruhe bewahren, wenn eine Broker-Queue volläuft oder der Thread-Pool erschöpft ist.

**Joachim**: Ein weiteres großes Thema bei unseren Kunden ist die Migration von anderen Integrationsplattformen auf webMethods – zum Beispiel von TIBCO, MuleSoft, Oracle SOA Suite, SAP PI/PO oder hauseigenen ESB-Lösungen. Und die webMethods-Welt steht nicht still: Seit der IBM-Akquisition heißt alles IBM webMethods Hybrid Integration – also ist jemand, der auch mit Containern und Cloud-Integration gearbeitet hat, genau richtig für uns.

**Peter**: Was uns wichtig ist, ist ein solides Fundament: Integrationspatterns wie Request-Reply, Pub/Sub, Dead-Letter-Queues und durchdachtes Fehlerhandling – plus ein gutes Verständnis dafür, wie webMethods APIs bereitstellt und konsumiert (REST, SOAP/WSDL).

**Linda**: Und wie viel Erfahrung sollten sie mitbringen?

**Joachim**: Mindestens drei Jahre praktische Erfahrung mit webMethods – Integration Server, Broker oder Universal Messaging, Designer. Jemand, der Integrationsprobleme selbstständig lesen, debuggen und beheben kann. Aber ehrlich gesagt: Wenn die Erfahrung nah dran ist, aber nicht exakt, und wer Integrationslösungen wirklich End-to-End durchdenkt, wollen wir trotzdem sprechen.

**Markus**: Als Bonus freuen wir uns über Erfahrung mit dem webMethods API Gateway, webMethods B2B (Trading Networks), Managed File Transfer mit webMethods MFT (ActiveTransfer), Optimize für SLA- und Prozessmonitoring – oder mit LDAP-Integration, SSL/TLS-Setup sowie Clustering und Hochverfügbarkeit im webMethods-Stack.

**Annabelle**: Genauso wichtig wie die Technik: Jemand, der sich mit Ambiguität wohlfühlt und eine vage formulierte Anforderung in eine funktionierende Integration verwandeln kann, der Probleme nicht weitergibt, sondern löst, der klar kommuniziert – auch mit nicht-technischen Stakeholdern – und der von Tag eins an an Logging, Alerting und Recovery denkt. Und da sich unsere Kolleginnen und Kollegen in Zagreb schon auf einen regelmäßigen Austausch freuen, sind sehr gute Deutsch- und Englischkenntnisse wichtig.

**Peter**: Ob das Wissen aus einem Studium, einer Ausbildung oder Jahren in Enterprise-Projekten stammt, ist für uns sekundär. Wichtig ist, dass es vorhanden ist – zusammen mit der Neugier, mit den webMethods-Releases Schritt zu halten.

**Linda**: Super, dann stelle ich die Anzeige online.

Wenn das auf Sie zutrifft: Wir freuen uns auf Ihre Bewerbung – und auf ein erstes Gespräch bei einem (virtuellen) Kaffee.

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
