# Werkstudent - Partnerships & Influencer Operations (all genders)

Posted: 2026-08-12T20:56:01Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

## **Deine Rolle**

Als Werkstudent Partnerships & Influencer Operations (all genders) erhältst Du Einblicke in zwei spannende Wachstumsbereiche von HelloFresh: Retail Media umfasst unsere vielfältigen Werbe- und Aktivierungsmöglichkeiten entlang der HelloFresh Customer Journey und ermöglicht es Drittmarken, ihre Zielgruppen direkt über unsere Plattform und Produkte zu erreichen, zum Beispiel durch Produktsamples in unseren Boxen. Im Influencer Marketing arbeiten wir mit relevanten Creators zusammen, um unsere Marke authentisch zu positionieren und neue Kunden zu gewinnen.

Was Dich erwartet und woran Du arbeitest: Du übernimmst Verantwortung für operative Prozesse, unterstützt den reibungslosen Ablauf unseres Tagesgeschäftes, sorgst gemeinsam mit dem Team dafür, dass unsere Aktivitäten effizient umgesetzt werden, arbeitest zudem mit unterschiedlichen Stakeholdern und bist die zentrale Ansprechperson für unser Distributionszentrum in Barleben.

## **Dein Verantwortungsbereich**

- Steuerung von Marketingkampagnen im Bereich Retail Media - von der Planung über die Kommunikation und Abstimmung mit dem Lager bis hin zum Reporting

- Operative Kommunikation und Abstimmung mit unseren Retail-Media-Partnern zu Kampagnen, Timings, Materialien und Anforderungen

- Pflege und Aktualisierung unseres CRM-Systems HubSpot sowie unserer Kampagnenübersicht, einschließlich der Anlage und Verwaltung diverser Produkte / Samples

- Koordination von Influencer-Kampagnen und Abstimmungen zwischen unseren internen Teams und externer Agenturen für unsere Märkte in Deutschland und der Schweiz

- Organisation von Muster- und PR-Paketen, Gewinnspielaktionen, Musterlieferungen für Influencer und Partner, sowie Koordination der Zusammenarbeit mit unserem Distributionszentrum in Barleben

- Mitwirkung bei der Umsetzung von Influencer Paid-Social-Kampagnen, inklusive der Aufbereitung und dem Upload von Content bis zur Abstimmung mit dem zuständigen Marketing-Team

- Vorbereitung und Dokumentation wichtiger interner Meetings, sodass relevante Informationen und nächste Schritte für alle Beteiligten transparent festgehalten werden

## **Dein Profil **

- Eingeschriebene/r Student/in, idealerweise im Bereich Marketing, Kommunikation, BWL oder einem vergleichbaren Studiengang

- Strukturierte und zuverlässige Arbeitsweise, Organisationstalent und ein gutes Gespür dafür, Prioritäten zu setzen, um auch bei unterschiedlichen Themen den Überblick zu behalten

- Kommunikationsstärke und ein sicheres Auftreten im Austausch mit internen Teams, externen Partnern und Agenturen

- Eigeninitiative und Freude daran, Verantwortung zu übernehmen, eigene Ideen einzubringen und Themen aktiv voranzutreiben

- Sicherer Umgang mit digitalen Tools; erste Erfahrungen mit HubSpot, Slack oder vergleichbaren Plattformen sind ein Plus

- Fließende Deutsch- und gute Englischkenntnisse

Vor allem suchen wir Menschen, die HelloFresh besser machen. Wir lieben vielfältige Erfahrungen und glauben, dass es viele Wege gibt, Fähigkeiten zu entwickeln. Wenn Du also nicht alle Kriterien erfüllst, aber glaubst, in dieser Rolle überzeugen zu können, möchten wir gerne mehr über Dich erfahren.

## **Das bieten wir Dir**

- **Einen Wohlfühlarbeitsplatz **mit einem tollen Team in Berlin-Kreuzberg

- **Rabatte** auf unsere HelloFresh Kochboxen und Convini-Produkte

- **Ein flexibles Arbeitsumfeld** mit Vertrauensarbeitszeit, Work From Home/Work From Abroad

- **Ein umfassendes Onboarding** inkl. Buddy-Programm

- **Spaß** bei Teamevents, Friday Beers, Company Runs, Buchclub u.v.m.

- **Vergünstigte Fitnessangebote** bei Urban Sports Club bzw. John Reed, regelmäßige Yoga-Sessions

- **Initiativen für das Wohlbefinden** durch Kooperationen mit der Headspace-App und Spill

- **Unterstützungsangebote** bei der Kinderbetreuung

- **Einen monatlichen Zuschuss zum Deutschlandticket**

## **Bist du die fehlende Zutat?**

Wenn diese Gelegenheit für Dich lecker klingt, freuen wir uns darauf, von Dir zu hören. Wir bemühen uns, Dein Profil zu prüfen und Dir innerhalb von 5 Werktagen zu antworten.

#JD1002

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
