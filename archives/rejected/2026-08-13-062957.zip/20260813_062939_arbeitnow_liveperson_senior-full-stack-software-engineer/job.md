# Senior Full Stack Software Engineer

Posted: 2026-08-12T23:55:38Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**Location:** Germany **Remote Status:** Fully Remote (#LI-Remote)

LivePerson (NASDAQ: LPSN) is a leader in trusted enterprise conversational AI and digital transformation. The world's leading brands use our award-winning Conversational Cloud platform to connect with millions of consumers. We power nearly a billion conversational interactions every month, providing uniquely rich data analytics and safety tools to unlock the power of conversational AI for better business outcomes. Fast Company named LivePerson the #1 Most Innovative AI Company in the world.

### **Position Overview**

Welcome to the Agent, Admin and Supervisor Experience team at LivePerson! We are a team of 9 engineers located across 4 countries in Israel, Germany, India and Bulgaria.

We are looking for a** Senior Full Stack Software Engineer** to join our team. In this role, you will lead the evolution of our frontend architecture while contributing to our full-stack ecosystem. You will work in a fast-paced environment on projects spanning different company areas, aiming to enhance, scale, and simplify how brands engage with their customers through messaging.

We are looking for an individual who wants to do more than just manage, but also shape and innovate!

### **You Will: Key Responsibilities & Impact**

- Lead the development and enhancement of our core UI platform, leveraging micro frontend architecture for scalability and maintainability.

- Lead AI-driven engineering practices. Champion the adoption of AI across the engineering organization by defining best practices, evaluating emerging AI-powered development tools, and establishing workflows that improve developer productivity, code quality, and architectural decision-making.

- Mentor teams on effectively leveraging AI while maintaining engineering excellence, security, and maintainability.

- Write high-quality, efficient, and maintainable code, while actively participating in code reviews to improve the overall quality of our codebase.

- Design and implement innovative, user-facing features, including those integrated with generative AI technologies, to elevate user experience.

- Create robust, testable, and performant solutions using Vue.js, Node.js, Java, and other modern technologies.

- Take ownership of features from initial concept and UI design to back-end implementation, testing, and deployment.

- Drive the continuous improvement of product functionality, performance, and scalability, ensuring high availability and responsiveness.

- Mentor and guide junior developers, fostering their professional growth and helping them make impactful contributions to the team.

- Contribute to the development and maintenance of CI/CD pipelines, and work closely on managing Kubernetes and cloud infrastructure to enable fast, reliable deployments.

### **You Have: Required Skills & Qualifications**

- 5+ years of experience with Object-Oriented Programming (Java, C#, etc.) and Node.js

- Bachelor’s or Master’s degree in Computer Science, Software Engineering, or a related field (or equivalent experience).

- Extensive experience with Frontend Web technologies: Vue.js (preferred), or React.js

- Strong experience with Micro Frontend Architecture and its practical implementation.

- Comprehensive knowledge of the entire web development lifecycle, including design, implementation, testing, deployment, and post-deployment support.

- Deep expertise in applying Generative AI throughout the software development lifecycle, from architecture and implementation to testing, debugging, documentation, and automation with a track record of improving engineering productivity and quality while defining best practices for AI adoption.

- Experience with cloud platforms, especially Google Cloud Platform (GCP), or other public cloud providers (AWS, Azure) - Advantage

- Demonstrated success in building and maintaining CI/CD pipelines using modern automation tools.

- Practical experience with Kubernetes and containerization technologies (e.g., Docker).

- Expertise in writing clean, maintainable code that adheres to industry best practices.

- Write unit and integration tests for both front-end and back-end components.

- Strong problem-solving skills, with the ability to analyze complex issues and develop efficient solutions.

- Familiarity with Agile development methodologies, promoting iterative development and quick adaptation to changing requirements

- Excellent organizational and communication skills, with the ability to collaborate effectively with cross-functional teams.

- Proven ability to mentor and support junior developers, fostering a collaborative and growth-oriented team culture.

- A strong sense of quality, personal responsibility, and an unwavering passion for continuous improvement in software development.

- Willingness to participate in paid on-call duty, in alignment with our "You Build It, You Run It" philosophy (One week every second month).

### **Our Benefits & Perks**

We are committed to supporting the complete well-being, health, financial security, family, and professional growth of our permanent employees.

#### **💰 Financial Security & Growth**

- **Additional Pension scheme**: deferred pension scheme (LivePerson contributes 20%), ESPP and annual bonus depending on achievements

- **Equipment**: Internet and Mobile reimbursement

- **Development:** Access to internal professional development resources.

#### **👨‍👩‍👧‍👦 Time Away & Family Support**

- **Flexible Paid Time Off (PTO):** Personal time off 33 days , vacation (28 days) and care days (5)

- **Paid Public Holidays.**

**Volunteering Days: Use them to make a difference in your community. Whether it's a cleanup, supporting a local initiative or holding an “Ehrenamt”, just let us know! We're here to help you create a meaningful impact.**

#### **💻 Workplace Flexibility**

- **Remote-First Model:** Be flexible, work flexibly and from anywhere - no defined working hours or boundaries with offices in Mannheim and Berlin

- **Monthly Connection:** Join our monthly connection pizza day in the office!

### **Why You’ll Love Working Here**

As leaders in enterprise customer conversations, we celebrate diversity, empowering our team to forge impactful conversations globally. LivePerson is a place where uniqueness is embraced, growth is constant, and everyone is empowered to create their own success. We're very proud to have earned recognition from Fast Company, Newsweek, and BuiltIn for being a top innovative, beloved, and remote-friendly workplace, and recognized by Gartner as a leader in the Conversational AI space.

### **Belonging at LivePerson: Equal Opportunity Employer**

We are committed to fostering an inclusive workplace and are proud to be an **Equal Opportunity Employer (EOE)**. We believe that diverse perspectives drive innovation. All qualified applicants will receive consideration for employment without regard to race, color, religion, sex, sexual orientation, gender identity, national origin, disability, veteran status, or other characteristics protected by US Federal, State, or Local law.

### **Accessibility Commitment**

LivePerson is dedicated to the accessibility needs of our applicants and employees. We provide **reasonable accommodations** to job applicants with disabilities. Applicants who require a reasonable accommodation for any part of the application or hiring process should inform their recruiting contact upon initial connection.

### **Important Candidate Notice**

The talent acquisition team at LivePerson has recently been notified of a phishing scam targeting candidates applying for our open roles. Scammers have been posing as hiring managers and recruiters in an effort to access candidates' personal and financial information. The phishing scam is not isolated to only LivePerson and has been documented in news articles and media outlets.

Please note that any communication from our hiring teams at LivePerson regarding a job opportunity will only be made by a LivePerson employee with an ----- email address. LivePerson does not ask for personal or financial information as part of our interview process, including but not limited to your social security number, online account passwords, credit card numbers, passport information, and other related banking information. If you have any questions and or concerns, please feel free to contact -----

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
