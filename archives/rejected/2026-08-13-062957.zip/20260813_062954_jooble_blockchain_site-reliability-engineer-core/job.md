# Site Reliability Engineer - Core

Posted: 2026-08-11T05:33:00.2270000

## Rejection

- Category: tech_stack
- Reason: role does not mention Go/Golang or PHP

...evolving our infrastructure as we develop solutions to complex **technical **problems involving reliability, latency, bandwidth and most importantly... ...based on experience and meaningful equity in an industry-**leading **company 
This is a role based in our Palermo office, with a...
