# SW Testing Automatisierung (m/w/x)

Posted: 2026-08-12T21:30:38Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

## Projektbeschreibung:

Technologie begeistert Sie? Uns auch! Zur Verstärkung unseres Expertenteams bei unserem Kunden aus der Funk- und Kommunikationsbranche suchen wir einen SW Testing Automatisierung (m/w/x) in Festanstellung bei K-tronik. Wir freuen uns darauf, Sie persönlich kennen zu lernen - und gemeinsam mit Leidenschaft und Teamgeist an spannenden Projekten und zukunftsweisenden Technologien zu arbeiten.

## Aufgaben:

- Testdesign und Implementierung:

- Erstellung von detaillierten Testspezifikationen und eigenständige Implementierung in ein GUI-Testsystem.

- Umfassende GUI Tests, sowie analysieren der Ergebnisse

- Kontinuierliche Weiterentwicklung der Testabläufe

- Fehlermanagement:

- Erstellen, dokumentieren sowie Retesting von Fehlerfällen

- Optimierung:

- Verantworten von fortlaufenden Verbesserungen und Optimierungen des GUI-Testsystems, um eine Effiziente und stabile Software Auslieferung sicherzustellen

## Qualifikationen:

- Testautomatisierung:

- Fundierte Erfahrung in der Automatisierung von Testfällen unter Einsatz von Python und Squish (insbesondere GUI-Tests in komplexen Softwareumgebungen).

- CI/CD & Toolchain:

- Sicherer Umgang mit Continuous Integration Tools wie Jenkins und GitLab CI.

- Projektmanagement & Tracking:

- Versiert in der Ticket-Erstellung und dem Lifecycle-Management mittels Jira und IBM RTC.

- Methodik:

- Erprobte Arbeitsweise in agilen Entwicklungsumgebungen (Scrum/Kanban).

- Sprachen:

- Verhandlungssichere Kenntnisse in Deutsch und Englisch.

- Soft Skills:

- Ausgeprägte Kommunikationsfähigkeit und die Bereitschaft, Verantwortung für Testzyklen und Qualitätsstandards zu übernehmen.

## Benefits:

- Kollegiales und freundschaftliches Arbeitsklima

- Flexible Arbeitszeiten

- 30 Urlaubstage und flexible Urlaubsplanung

- Regelmäßige Team-Events

- Auszeichnung als Kununu TOP Company

- Corporate Benefits (Mitarbeiterangebote)

- Kostenlose Getränke

- Individuelle Weiterbildungsmöglichkeiten

- 360° Betreuung: Feedbackgespräche, Karriereplanung, Unterstützung bei Umzug, etc.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
