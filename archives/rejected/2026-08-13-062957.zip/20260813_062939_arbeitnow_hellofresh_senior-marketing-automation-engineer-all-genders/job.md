# Senior Marketing Automation Engineer (all genders)

Posted: 2026-08-12T20:56:01Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

## **The role**

In this role you will join the X-Channel Automation team, a cross-functional team embedded within Performance Marketing whose mission is to enable the Paid Marketing department to achieve its maximum potential by integrating the newest AI-driven technologies and automation into their processes, removing operational friction.

Because the team sits outside the tech tribe and operates without a dedicated product layer, the Senior Marketing Automation Engineer owns the full problem space: translating a marketer's brief into a scoped technical solution, architecting and building it, and shipping it to production. You will be developing tools and technologies for an internal group of 100+ people across Performance Marketing, Partnerships, and Retail.

As a Senior, you are a credible technical voice who works with a high degree of autonomy — leading projects from broadly defined outcomes, challenging the technical output of peers, and mentoring more junior engineers. You are equally comfortable holding a conversation with a marketer about their workflow pain points as you are architecting a backend service.

## **What you’ll do**

- Lead the end-to-end delivery of complex automation and AI projects — from requirement gathering with non-technical stakeholders through design, build, and production release — owning scope and timeline independently

- Act as the primary technical point of contact for Paid Marketing stakeholders, independently translating business problems into clearly scoped technical requirements without a product layer

- Architect and build AI-integrated workflows that reduce manual effort across marketing teams, contributing directly to team KPIs including hours saved and AI adoption rate

- Develop scalable, maintainable solutions in Python and JavaScript/TypeScript, including backend services, automation scripts, and front-end reporting interfaces

- Design and implement integrations with marketing platforms (Google Ads, Meta, TikTok, and others) using RESTful APIs, webhooks, and OAuth2

- Build dynamic ad feeds and campaign-launch technologies that empower marketers to activate campaigns faster and at greater scale

- Set up and maintain monitoring and alerting systems to ensure operational stability across marketing tools, enabling proactive issue resolution

- Define and drive development standards and best practices within the team, challenging peers’ technical output constructively and creating an enabling environment for more junior engineers

- Mentor engineers at earlier career steps, providing technical guidance and feedback

- Participate in sprint refinement — evaluating incoming requests against team scope, applying RICE scoring, and engaging requestors to close requirements gaps before work begins

- Proactively evaluate emerging automation and AI tooling, staying ahead of industry trends and introducing best practices to the team

## **What you’ll bring**

- 4+ years of experience in Software Engineering and the ability to design, implement, and deliver maintainable, high-quality solutions end-to-end with a high degree of autonomy

- Strong full-stack proficiency in Python and JavaScript/TypeScript, including relevant frameworks (e.g. FastAPI, Node.js, React or equivalent)

- Solid experience with cloud platforms (AWS preferred), CI/CD pipelines (e.g. GitHub Actions), and containerisation

- Demonstrated ability to gather requirements independently from non-technical stakeholders, translate them into scoped deliverables, and manage expectations throughout

- A credible communicator who tailors language and framing to both technical and non-technical audiences — essential in a role without a product layer

- Proactive, autonomous, and solution-oriented: you can work from broadly defined outcomes, define your own scope and timeline, and surface blockers early without needing frequent direction

- Data-driven approach to prioritisation and decision-making, comfortable with frameworks such as RICE scoring and impact estimation

- Experience with marketing APIs (Google Ads, Meta, TikTok, etc.)

- Working knowledge of SQL and data tooling (e.g. Snowflake, BigQuery)

- Experience mentoring or technically guiding more junior engineers

## **What we offer**

Elevate your lifestyle! Join one of Europe's fastest-growing tech powerhouses in a dynamic phase of expansion.

- Immerse yourself in a diverse global community of 90+ nationalities.

- Enjoy a competitive compensation package that goes beyond the norm, with perks like a HelloFresh- subsidized Pension Scheme, Berlin relocation support, and a Hybrid working model.

- Elevate your lifestyle with exclusive discounts on your weekly HelloFresh box and office meals.

- Invest in your growth with an annual learning & development budget, German language learning budget, and access to the HelloFresh Academy.

- Plus, we've got your well-being covered with mental health support, transportation perks, and working-parent-friendly benefits. From our 24/7 gym access,wellbeing platforms like Headspace and Spill, to sabbatical leave options, HelloFresh is not just a workplace; it's a lifestyle of perks and possibilities!

## **Are you up for the challenge?**

Please submit your complete application below including your salary expectations and earliest starting date.

After submitting an application our team will review this and get back to you within 5 business days.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
