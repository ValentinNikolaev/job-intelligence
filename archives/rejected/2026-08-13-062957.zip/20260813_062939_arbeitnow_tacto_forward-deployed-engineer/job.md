# Forward Deployed Engineer

Posted: 2026-08-13T02:40:11Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

## Your Impact

Procurement is over 50% of revenue for industrial companies and their biggest lever for profitability. The hard part is not the software, it is that every customer's reality is different: a different ERP, a different data model, decades of undocumented process. Generic platforms stall exactly there, and that is where most enterprise AI value quietly dies.

Forward Deployed Engineering is how we close that gap. You sit inside the customer's environment, build in their production data, and turn what you learn there into product. You are one of the first FDEs at Tacto, so you are not slotting into a playbook, you are writing it while shipping in real accounts.

## Your Tasks

**Build in customer environments.** Data pipelines, agents, and custom logic on top of the Tacto platform, in real production data.

**Own the technical side of a deployment.** Extraction, mapping, validation, enrichment, until the customer's procurement team can actually work with the result.

**Be in the room, on site.** Run data workshops with key users, debug alongside their IT, and see how a company really buys instead of how the process documentation says it buys.

**Turn what you learn at the edge into product.** Document the pattern and push it to Product and Engineering instead of quietly rebuilding the same one-off for the next customer.

**Automate your own job.** If a step in a deployment can be done by an agent, you build the agent and prove it works.

**Make it one team.** Hold the boundary with Solution Engineering and Customer Value so the customer experiences one Tacto, not three.

## Your Profile

-

**You are a builder.** You have shipped software, automations, agents, or technical projects that real users relied on.

-

**You write code yourself.** You are comfortable with Python and SQL and use AI coding tools to move fast.

-

**You are AI-native.** You have built with LLMs against real data and understand where agents work, where they fail, and where humans still matter.

-

**You thrive in messy environments.** Incomplete requirements, undocumented data, and conflicting stakeholder input do not stop you from making progress.

-

**You can earn customer trust.** You explain technical decisions clearly, handle pushback, and do not over-promise.

-

**You have 0-4 years of experience** with evidence of a steep learning curve through strong technical work, ambitious startups, internships, or things you built from zero.

-

**You speak native-level German and fluent English**, are based in Munich, and are willing to travel regularly across DACH.

## Why This Role is Awesome

You get to combine building software with seeing exactly how it creates value in the real world. You will ship into production, work directly with industrial customers, and turn what you learn at the edge into product improvements. Do this well for 12 to 18 months and you are among the people who defined what Forward Deployed Engineering means at Tacto, with a direct line into the product roadmap and an obvious next step, whether that is leading a team, going deeper into product, or owning a segment.

## What This Role Is, and Isn't

We want to be honest about what you are signing up for.

-

This is not an engineering role with customers kept at a safe distance. Customer contact is the job, not a tax on the job. If you want a ticket queue and clean requirements, this is the wrong role.

-

This is not consulting. Nobody here bills days. You are measured on what the customer can do afterwards and on what made it into the platform.

-

It is deliberately broad. If you want to specialise narrowly you will be frustrated here.

-

The deal: prove yourself, deliver real impact, make a strong case for yourself, then we back your next step in every way we can.

## Why Tacto

**We bet on young talent and mean it.** We consistently back smart, hungry, young people with real ownership early. 70%+ of our Leadership Team was promoted internally: you deliver impact and sky is the limit at Tacto.

**Backed to win big.** We are Sequoia and Index-funded with €50M+ behind us. Our founders sit at the same table as the people defining the global AI agenda. We're building Tacto to be the lighthouse for European industrial AI.

**A truly AI-native organization, with every resource you could dream of.** All the leading AI tools and custom agents at your fingertips, plus dedicated people who keep us at the frontier.

**High bar, high speed, genuinely fun.** You'll be surrounded by extremely smart and ambitious people who set the bar high and push you to get better every week. Intense, fast, and the opposite of boring.

**A front-row seat in the European startup ecosystem.** Weekly exposure to leading founders and operators through internal and external events (Lunch & Learns, hackathons, community gatherings). Check out all upcoming and past events here: [https://luma.com/tacto](https://luma.com/tacto)

**You'll build something that lasts and that matters.** You'll help build the company that keeps European industry competitive for the long term.

## **Our Background**

Tacto is building the intelligence layer that connects AI to the physical world of manufacturing, starting with procurement. AI is transforming every industry, but it stops at the factory gate. The knowledge that holds manufacturing together - part costs, suppliers, materials - is scattered across systems and people. Over 50% of a product's cost originates from suppliers, making procurement the single largest cost lever in manufacturing and the missing connection between the digital and the physical world. Yet it still runs on Excel and legacy systems. We're changing that with our Procurement Intelligence Platform, trusted by hundreds of companies running billions of Euros of material.

Based in Munich, we are 100+ passionate builders who are in-office, with high expectations, fast growth, and a lot of fun. We are supported by >€50m from Sequoia, Index, and Europe's leading tech entrepreneurs and industry veterans.

## **Why It Matters**

Manufacturing forms Europe's economic backbone, driving a fourth of Europe's GDP and providing over 30% of jobs. These hidden champions and global market leaders manufacture the physical world around us, from the machines that build our cities to the medical devices that save lives.

But the world is changing. The US dominates the digital world of bits. China is scaling the world of atoms, manufacturing at unprecedented speed and scale. Geopolitics are more uncertain than ever. Europe's strength lies in its deep industrial knowledge through generations of engineering. Manufacturing worldwide runs on European machines and software. But that heritage is only an advantage if we leverage it in the age of AI.

Tacto builds the AI that connects Atoms and Bits, empowering our Industrial Base to Stay Stronger and building a lighthouse for European tech.

## **What We Offer**

The people at Tacto are passionate about building the organization, growing themselves, and our product while having fun and being real. We have high expectations, great talent density, and a culture where your ambition, performance, and agency are what count - not where you come from or how big your ego is. You'll grow at the forefront of AI, have real ownership and impact, and be surrounded by the best people in their field who challenge you and make you better every day. That is demanding and rewarding, but that's where we thrive. Besides that you have:

-

Money: Competitive salary & equity in the company with real upside, so you are invested in our success

-

Workplace: A vibrant in-office culture (> 4 days/week) in a beautiful office in central Munich

-

Development: A development budget and regular exposure to exceptional people, e.g., Lunch & Learns, peer mentoring, external speakers

-

Time off: 26 + 4 vacation days per year (4 fixed “company rest days”) as well as regular off-sites and team events

-

Health: Wellpass membership, of course, a fruit basket (!), and access to Jobrad, for your health

-

Family & Social Security: Voluntary pension contribution, voluntary KITA subsidy for your children

*Tacto is an equal opportunity employer. We are committed to equal employment opportunity regardless of race, religion, sexual orientation, age, marital status, disability, or gender identity. Please do not submit personal data revealing racial or ethnic origin, political opinions, religious or philosophical beliefs, trade union membership, data concerning your health, or data concerning your sexual orientation.*

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
