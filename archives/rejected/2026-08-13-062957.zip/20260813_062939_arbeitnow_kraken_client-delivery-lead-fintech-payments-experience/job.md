# Client Delivery Lead (Fintech/Payments experience preferred) (f/m/d)

Posted: 2026-08-12T23:40:24Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Help us use technology to make a big green dent in the universe!

[Kraken](https://kraken.tech/) powers some of the most innovative global developments in energy.

We create the technology that redefines utilities and unlocks a new energy system of the future. By optimising renewable generation, building a more intelligent grid, and empowering utilities to deliver an exceptional customer experience, our operating system is transforming the industry worldwide.

It’s an incredibly exciting time to work in energy. Join us on our mission to improve the lives of ONE BILLION humans within the decade and shape a cleaner, better future for everyone.

Kraken Customer

What we do: build the most AI-driven, innovative, forward-thinking platform for energy management. From optimizing resources to delivering cost-effective, exceptional customer experiences through advanced Customer Information Systems (CIS), billing, meter data management, CRM, and AI-driven communications, Kraken is powering the next wave of innovation in the energy industry.

Why we do it: future energy will not look like energy as we know it today. We need to not just think about our future, but build for it. Now.

We have been licensing Kraken for over 4 years now, transforming businesses by not only moving their customer base to our Kraken platform but also changing their operating model & ways of working. Throughout this time our team has been at the forefront of industry leading migrations whilst setting a new standard for what business transformation can look like.

**🏠 Where you'll fit in:**

You will be joining the client delivery team with Kraken working to support European clients through their technology transformation journeys, supporting long term migration projects.

The Client Delivery Lead has direct responsibility managing a tech domain (billing, finance, comms..) for our client projects. This is either migrating onto our Kraken platform or managing long term technology requirements. They need to work in partnership with the technology and operational teams at Kraken as well as the client to deliver results for our client’s project or business needs.

The** Client Delivery Lead** has to really understand how Kraken works, understand problems or requests raised by the client and refine solutions in the best way to leverage existing and new capability. They will bring technology, people and processes together to innovate improvements for our clients. You will also support the client in adapting to ways of working that are aligned to Kraken’s development style. You will work closely with Kraken’s product managers and developers to request development needs and act as a link to the client.

**🚀 What you'll own:**

-

-

You will be managing the relationship with client counterparts (often product owners and business owners)

-

You will be the first point of contact for tech development and the escalation and resolution point with customers for specific domain/product issues

-

Being the knowledge base of how Kraken works and how we deliver Kraken Platform

-

Triaging incoming requests and communicating client priorities internally.

-

Summarising and articulating client needs, considerations, timelines internally to enable the ongoing development of the Kraken [platform.](http://platform.supporting/)

-

Supporting the engineering team to deliver product features

-

Challenging the client to think differently about tech development, having full belief in the continuous iteration and deployment approach we have.

This is a hands-on, individual contributor position. The role is European based and your projects could be run from any country, travel is expected as part of this role.

We are a flat and agile organisation and plan to remain this way. We are looking for open minded individuals who are comfortable with ambiguity and an ever changing environment. To thrive here you must be a self-starter and willing to roll your sleeves up to solve any problem, constantly flexing outside of your typical job role to drive progress for our clients and organisation.

You must be committed to the Kraken way of delivering tech based on simplicity, client benefit and efficiency while bringing stakeholders through a journey of change.

You must be willing to challenge beliefs, have the ability to see through multiple viewpoints and, if needed, reach beyond your remit to support the client.

We are building a Kraken for everyone, a universal platform where there is greater benefit in sharing development to enable the green energy transition. Pioneers in this space, we are excited about how Kraken can change the lives of our customers and convinced that Kraken is the best answer, not only for efficiency but as a tool to tackle the climate crisis. If you believe this too then Kraken Tech is the right place for you.

**🧠 What you'll bring to the party:**

-

-

In this position you will be laser focused on satisfying our customer’s needs. We are looking for people with strong problem solving skills and a super positive solutions oriented mindset. If you have a taste for raising up to challenges and a winner mindset, this position is the right fit for you! (“Every problem has a solution, facing new challenges is exciting because that’s what makes us better every day and the bigger the challenge, the bigger the feeling of success”)

-

Strong client delivery and/or product ownership experience

-

Agile delivery experience

-

Experience of product management and customer journeys

-

Solid understanding of technology and associated trends

-

Excellent communications, collaboration and presentation skills

-

Strong influencing skills and ability to challenge traditional ways of thinking

-

Experience of working with significant complex delivery pipelines for clients

-

Patience and initiative - our clients are undergoing huge transformations that take time and require our understanding

-

Time management and a get-stuff-done attitude

-

Consulting experience is a plus

-

Fluent English + German is a plus

-

Previous experience in payments is nice to have for this position

*If this sounds like you then we'd love to hear from you.*

*Are you ready for a career with us? We want to ensure you have all the tools and environment you need to unleash your potential. Need any specific accommodations? Whether you require specific accommodations or have a unique preference, let us know, and we'll do what we can to customise your interview process for comfort and maximum magic!*

*Studies have shown that some groups of people, like women, are less likely to apply to a role unless they meet 100% of the job requirements. Whoever you are, if you like one of our jobs, we encourage you to apply as you might just be the candidate we hire. Across Kraken, we're looking for genuinely decent people who are honest and empathetic. Our people are our strongest asset and the unique skills and perspectives people bring to the team are the driving force of our success. As an equal opportunity employer, we do not discriminate on the basis of any protected attribute. Our commitment is to provide equal opportunities, an inclusive work environment, and fairness for everyone.*

*Are you ready for a career with us? We want to ensure you have the right tools and environment to unleash your potential. If you have any accommodation requests, please contact us at ----- We’ll do our best to tailor the experience to your needs so you can feel comfortable, confident and be at your best!*

*Studies have shown that some groups of people, like women, are less likely to apply to a role unless they meet 100% of the job requirements. Whoever you are, if you like one of our jobs, we encourage you to apply as you might just be the candidate we’re looking for! At Kraken, we're creating a team of genuine, honest, empathetic people. Our people are our strongest asset and the unique skills and perspectives people bring to the team are the driving force of our success. As an equal opportunity employer, we do not discriminate on the basis of any protected attribute. We consider all applicants without regard to race, colour, religion, national origin, age, sex, gender identity or expression, sexual orientation, marital or veteran status, disability, or any other legally protected status.*

*Our (i) [Applicant and Candidate Privacy Notice and Artificial Intelligence (AI) Notice](https://kraken.tech/candidate-privacy-notice), (ii) [Website Privacy Notice](https://kraken.tech/privacy-notice) and (iii) [Cookie Notice](https://kraken.tech/cookie-notice) govern the collection and use of your personal data in connection with your application and use of our website. These policies explain how we handle your data and outline your rights under applicable laws, including, but not limited to, the General Data Protection Regulation (GDPR) and the California Consumer Privacy Act (CCPA). Depending on your location, you may have the right to access, correct, or delete your information, object to processing, or withdraw consent. By applying, you acknowledge that you’ve read, understood and consent to these terms

Please note that, in line with our current recruitment policy, we are unable to offer visa sponsorship for this position; applicants must have the right to work in the country that they're applying to, at the time of application.*

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
