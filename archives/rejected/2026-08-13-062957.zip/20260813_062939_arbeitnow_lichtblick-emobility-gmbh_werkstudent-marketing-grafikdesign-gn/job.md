# Werkstudent Marketing - Grafikdesign (gn)

Posted: 2026-08-13T02:30:14Z

## Rejection

- Category: language_requirement
- Reason: hard German language requirement without English green light

#### **Lade mit uns das Netzwerk der Zukunft in Rottendorf (Bayern) auf!
**

Wir haben eine Mission: **Gemeinsam wollen wir die Mobilität von Morgen gestalten**.

Wir möchten elektrisches Fahren und Laden für alle möglich machen. Ja, genau: für alle. Dabei sind wir sehr ambitioniert. Unser Ziel: LichtBlick zum besten Anbieter von emissionsreduzierten Ladelösungen für E-Autos zu machen. Dank intelligenter Planung können wir ganz Deutschland bedienen. So versorgen wir das Netzwerk der Zukunft mit erneuerbarer Energie von LichtBlick - und bringen die E-Mobilität von Morgen aufs nächste Level.

Genau dafür suchen wir Verstärkung. Denn zu einem ambitionierten Plan gehören motivierte Mitarbeitende. Du suchst nach einer sinnvollen Herausforderung und möchtest eine nachhaltige Zukunft gestalten? Du willst dich mit uns für eine sichere, e-mobile Zukunft einsetzen und sie für alle erfahrbar machen?

Dann starte deine Karriere bei der LichtBlick eMobility GmbH!

#### **Dein Job für gute Energie im Bereich Marketing & Kommunikation:**

-

**Grafiken für Online- & Offline-Werbemittel:** Du erstellst und passt Social-Media-Grafiken, Online-Banner, Ads, Newsletter-Visuals, Präsentationen sowie Print-Materialien wie Flyer, Plakate, Broschüren & Give-Aways an

-

**Kampagnen- & Werbemittel-Design:** Du kreierst zusammen mit dem Marketing- & Kommunikations-Team und externen Agenturen Assets für B2B-Marketingkampagnen (Leadgenerierung, Webinare, Events & Messen)

-

**Foto & Video:** Du bearbeitest und retuschierst Bilder und erstellst Videos gemäß unseres Corporate Designs

-

**Website Design:** Du unterstützt uns bei der Gestaltung von Websites und Klick-Strecken

#### **Was bieten wir?**

Wir sind sehr um das Wohl unserer Mitarbeitenden bemüht und bieten hervorragende Arbeitsbedingungen, damit du deine Batterien in einem anspruchsvollen, sich schnell entwickelnden Arbeitsumfeld immer wieder aufladen kannst. Dabei dürfen neben der Freude an der Arbeit Aspekte wie persönliche Entwicklung, Wertschätzung sowie geistige und körperliche Fitness nicht zu kurz kommen.

-

**Work-Uni-Life-Balance:** 26 Tage Urlaub (bei einer 5-Tage-Woche), flexible Arbeitszeiten passend zu deinem Studienplan und hybrides Arbeiten (40% im Office, 40% in Mobiler Arbeit, 20% flexibel im Office oder mobil innerhalb Deutschlands)

-

**Vitalität: **ein modernes, neues Büro mit vielfältigen ergonomischen Arbeitsplätzen, eine digitale Gesundheitsplattform mit Ernährungsberatung, Achtsamkeits- sowie Sportkursen, Vitality Day(s) sowie frisches Obst & Getränke

-

**Benefits, Sicherheit & Zukunftsplanung: **Vorbereitung auf dein Berufsleben nach der Uni inkl. der Möglichkeit auf eine Übernahme, Fahrtkostenzuschuss, kostenloses e-Laden im Büro, Rabatte & Vergünstigungen auf unsere Produkte (z.B. Mitarbeiter-Stromtarif), monatlicher Gutschein i.H.v. 25 €

-

**Entwicklung & Weiterbildung: **ein modernes eLearning-Tool inkl. Learning-App, regelmäßige interne Schulungen, Coachings & Workshops

-

**Dynamisches Team mit moderner & sinnstiftender Unternehmenskultur:** kollegiales und motivierendes Miteinander, flache Hierarchien, offene und transparente Kommunikation, nachhaltiger Schutz unserer Umwelt

**Was bringst du mit?**

Als Mitarbeitende*r der LichtBlick eMobility GmbH arbeitest du für eine Organisation, die Chancen und Initiativen ergreift. Du bekommst bei uns die Freiheit, zu experimentieren. Du lässt dich gerne auf Abenteuer ein, ergreifst die sich bietenden Initiativen und bist zielorientiert. Und obwohl du ausgezeichnet selbstständig arbeiten kannst, weißt du zugleich, dass du nur gemeinsam mit anderen wirklich etwas auf die Beine stellen kannst.

Kurz und gut:

-

Du bist immatrikulierte*r Student*in im Bereich Grafikdesign, Kommunikationsdesign, Mediengestaltung oder in einer vergleichbaren Studienrichtung

-

Du hast bereits Erfahrung im Bereich Foto- und Videoproduktion

-

Du hast einen sicheren Umgang mit MS Office, insbesondere PowerPoint, sowie Erfahrung in der Adobe Creative Suite (Photoshop, Illustrator, InDesign)

-

Du arbeitest gerne strukturiert, eigenverantwortlich und mit großer Neugierde, Teamfähigkeit sowie Motivation

-

Du bist kommunikationsstark und kannst konversationssichere Deutschkenntnisse vorweisen

-

Nice-to-have: Du hast bereits erste Erfahrungen im Marketing, (UX-)Design, KI-Bildgenerierung oder Branding

-

Deine Uni-Vorlesungen lassen es zu, dass du 15 - 20 Stunden pro Woche und während der Semesterferien bis zu 40 Stunden pro Woche an unserer Reise der E-Mobilität teilhaben kannst

**Klingt gut? Dann freuen wir uns auf deine Bewerbung und dein Interesse, gemeinsam eine nachhaltige und bewusste Zukunft zu gestalten!**

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
