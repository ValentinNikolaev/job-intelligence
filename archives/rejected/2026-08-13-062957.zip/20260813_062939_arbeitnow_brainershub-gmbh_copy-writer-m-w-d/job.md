# Copy Writer (m/w/d)

Posted: 2026-08-12T20:30:31Z

## Rejection

- Category: language_requirement
- Reason: hard German language requirement without English green light

**Copywriter (m/w/d)**

Willst du Texte schreiben, die im Feed sofort auffallen? Willst du mit den richtigen Worten Menschen in gesundheitlichen Fragen erreichen, berühren und weiterbringen? Und willst du dabei modernste KI-Tools nutzen, ohne auf sprachliche Exzellenz zu verzichten?

Dann bist du bei uns genau richtig!

Als Copywriter im Healthcare-Markt bist du die Stimme unserer Marken auf Social Media und darüber hinaus. Du verwandelst komplexe Gesundheitsthemen in Texte, die überraschen, mitreißen und im Kopf bleiben – von kurzen, pointierten Social-Media-Captions über Skripte für Video-Content über überzeugende Landingpages bis hin zu Long-Form-Artikeln, die Patient:innen echten Mehrwert bieten (außerhalb verschreibungspflichtiger Medikamente).

**Arbeiten bei BrainersHub heißt**

- **Drive & Ambition:** Wir leben eine Kultur von High Pace und High Reward: Wer Initiative zeigt und starke Leistung bringt, erhält Raum für Weiterentwicklung, zusätzliche Verantwortung und wird mit einem Excellence-Bonus belohnt.

- **Fokus auf Entwicklung:** Ehrliches Feedback und regelmäßige Schulterblicke sind für uns selbstverständlich. Wir fördern individuelle Entwicklung mit transparenten Entwicklungsplänen und gezieltem Mentoring.

- **Erfolg im Team & gelebte Teamkultur:** Die besten Ideen zählen, unabhängig von deiner Position. Wir schätzen ambitionierte Persönlichkeiten und setzen auf interdisziplinäre Zusammenarbeit, um gemeinsam mehr zu erreichen.

- **Raum für Exzellenz**: Wir suchen Top-Performer:innen mit echtem Gestaltungswillen: Menschen, die Verantwortung übernehmen und mit Eigeninitiative sowie frischen Ideen unsere Zukunft mitprägen wollen.

- **Inspirierendes Arbeitsumfeld:** flexible Arbeitszeiten, Homeoffice-Möglichkeiten, inspirierende Afterwork-Sessions. Bei uns bist du Teil eines ambitionierten, offenen Teams.

**Deine Aufgaben:**

- **Social-Media-Copy mit Wow-Effekt:** Du schreibst Captions, Hooks und Skripte, die in den ersten drei Sekunden fesseln, für Meta, LinkedIn & Co. Du kennst den Unterschied zwischen einem Text, der gescrollt wird, und einem, der hängen bleibt.

- **Kreative Content-Formate entwickeln:** Du denkst dir neue, unverbrauchte Formate aus, von Storytelling-Serien über Community-Posts bis zu witzigen oder emotionalen Kampagnen, und bringst frische Ideen aktiv ins Team ein.

- **Cross-Channel Content Creation:** Du entwickelst Inhalte über alle relevanten Kanäle hinweg: Social Media, Website, Newsletter, Landingpages und Vertriebsmaterialien. Immer mit demselben Anspruch: sprachlich stark, zielgruppengerecht und mit klarer Tonalität.

- **Landingpages & Conversion-Texte:** Du schreibst überzeugende Landingpages und Vertriebstexte, die nicht nur informieren, sondern auch zum Handeln motivieren, mit klarer Struktur, starken Headlines und wirkungsvollem CTA.

- **Trend-Radar:** Du hast ein Gespür für das, was gerade funktioniert, auf Social Media, aber auch in der digitalen Kommunikation insgesamt, und übersetzt aktuelle Trends in Content, der zu unseren Marken passt.

**Was du mitbringen solltest:**

- **Ausgeprägte Schreibexpertise & Kreativität:** Texten ist deine Leidenschaft. Du hast ein feines Gespür für Sprache, Rhythmus und Tonalität und schaffst es, auch trockene Themen spannend zu erzählen – egal ob für Social Media, Newsletter, Landingpages oder Vertriebsmaterialien.

- **Gespür für Social Media & digitale Kanäle**: Du weißt, wie Menschen auf Instagram, TikTok & Co. wirklich lesen, scrollen und reagieren und schreibst genau dafür. Gleichzeitig denkst du kanalübergreifend und passt Ton und Format gezielt an, ob Newsletter, Landingpage oder Vertriebsunterlage.

- **Storytelling-Kompetenz:** Du kannst komplexe Inhalte in einfache, packende Geschichten verwandeln, die im Kopf bleiben, auf jedem Kanal und in jedem Format.

- **Digitalaffinität & SEO-Grundverständnis:** Du verstehst die Mechanismen des digitalen Marketings und bringst idealerweise erste Erfahrung mit Suchmaschinenoptimierung mit.

- **Struktur & Zuverlässigkeit:** Du arbeitest sorgfältig, organisiert und behältst auch bei mehreren Projekten und Kanälen den Überblick.

- **Teamorientierung & Offenheit**: Du tauschst dich gern aus, nimmst Feedback konstruktiv auf und bringst eigene Ideen ein.

- **Exzellente Deutschkenntnisse in Wort & Schrift:** Für Texte, die wirklich überzeugen.

*(Nicht sicher, ob du alles mitbringst? Kein Problem – überzeug uns mit deiner Kreativität, deiner Neugier und deinem Drive!)*

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
