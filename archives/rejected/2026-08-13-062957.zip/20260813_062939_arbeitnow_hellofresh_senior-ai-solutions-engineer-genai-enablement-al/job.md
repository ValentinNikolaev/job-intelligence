# Senior AI Solutions Engineer, GenAI Enablement (all genders)

Posted: 2026-08-12T20:56:01Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

## About the role: What's in the Box

You'll join HelloFresh's GenAI Enablement Squad, a cross-functional team helping teams across the company unlock the practical value of AI. Our mission is simple: identify high-impact problems, build AI-powered solutions that solve them, and scale what works.

As a Senior AI Solutions Engineer, you'll work directly with engineering teams and business functions to understand their workflows, identify high-value opportunities, and build AI-powered solutions that solve real operational problems. You'll act as the bridge between users and technology—embedding with teams, rapidly iterating on prototypes, and turning successful ideas into production systems. This is a highly hands-on engineering role. You'll own projects from discovery through deployment, collaborating closely with product managers, engineers, and non-technical stakeholders. You'll thrive in ambiguous environments, moving quickly to validate ideas while maintaining the engineering quality required for production.

You'll join a team that values pragmatism over hype. We use the best tool for the problem—not the newest one—and measure success by the impact our solutions create.

## **What you’ll do: The Recipe**

- Partner directly with engineering and business teams across HelloFresh to understand their workflows and identify opportunities where AI can create measurable value.

- Embed with teams to rapidly prototype AI-powered solutions, gather feedback, and iterate based on real user needs.

- Design, build, deploy, and operate production-grade AI applications, including agents, workflow automations, retrieval systems, and internal tools.

- Build role-specific AI assistants distributed through our internal plugin marketplace, enabling teams to automate repetitive work and improve productivity.

- Work across the full lifecycle of AI solutions—from discovery and experimentation to production deployment and continuous improvement.

- Balance speed with engineering quality, ensuring solutions are reliable, observable, secure, and cost-effective.

- Collaborate closely with platform engineers to leverage and improve shared AI infrastructure where appropriate.

- Share learnings and reusable patterns that help accelerate future AI initiatives across the organization.

- Mentor teammates through collaboration, code reviews, and technical discussions.

## **What you’ll bring: The Ingredients **

- Experience building and shipping production AI applications using modern LLMs, including agents, RAG, workflow automation, structured generation, and LLM evaluation.

- Strong software engineering skills with experience designing and operating production systems.

- Experience working directly with customers or business stakeholders to translate ambiguous problems into practical software solutions.

- A product mindset with a focus on delivering measurable user and business impact.

- Ability to rapidly prototype ideas while knowing when to invest in scalability, reliability, and long-term maintainability.

- Experience with managed AI platforms such as AWS Bedrock, OpenAI, Anthropic, or Google Vertex AI.

- Strong programming skills in Python or another modern programming language.

- Excellent communication skills and the ability to collaborate effectively across technical and non-technical audiences.

- Curiosity, pragmatism, and a bias toward action.

### **Nice to have**

- Experience building internal developer tools or productivity platforms.

- Experience evaluating AI systems for quality, latency, and cost.

- Familiarity with agent frameworks, MCP, tool calling, or workflow orchestration.

- Experience deploying AI solutions in enterprise environments.

- Experience measuring adoption and business impact of AI products.

## **What we offer**

- You’ll receive a competitive salary package, including a HelloFresh-subsidized pension scheme.

- Enjoy savings on your weekly HelloFresh box.

- Support your mental wellbeing with access to platforms like Headspace and Spill.

- Stay active with 24/7 office gym access, a discounted Urban Sports Club membership, and other wellbeing resources.

- Balance your life with our flexible hybrid model.

- Recharge with sabbatical leave options in addition to standard time off.

- Embrace "Learning Never Stops" with internal training, the HelloFresh Academy, and a dedicated budget for German language courses.

- Enjoy tasty in-office meal deals and fresh food options.

- We support working families with parent-friendly policies, an in-office kids corner, and an on-site babysitter.

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
