# Revenue Operations Analyst - Working Student

Posted: 2026-08-12T23:55:07Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**Welcome to Planet. We believe in using space to help life on Earth.**

Planet designs, builds, and operates the largest constellation of imaging satellites in history. This constellation delivers an unprecedented dataset of empirical information via a revolutionary cloud-based platform to authoritative figures in commercial, environmental, and humanitarian sectors. We are both a space company and data company all rolled into one.

Customers and users across the globe use Planet's data to develop new technologies, drive revenue, power research, and solve our world’s toughest obstacles.

As we control every component of hardware design, manufacturing, data processing, and software engineering, our office is a truly inspiring mix of experts from a variety of domains.

We have a people-centric approach toward culture and community and we strive to iterate in a way that puts our team members first and prepares our company for growth. Join Planet and be a part of our mission to change the way people see the world.

Planet is a global company with employees working remotely world wide and joining us from offices in San Francisco, Washington DC, Germany, Austria, Slovenia, and The Netherlands.

**About the Role: **

The Working Student will join our dynamic Revenue Operations Team (RevOps) to support the quote-to-cash operations of Planet. In this role, you will support the Sales team by reviewing, structuring, and processing deals to ensure alignment with internal policies and pricing guidelines. You will collaborate with Sales, Customer Success, Finance, Accounting and Legal to facilitate deal approvals and ensure smooth execution of contracts. This position is excellent for students interested in Revenue Operations who want to gain experience in quoting and pricing, contracts, deal proposals, and related.

This is a part-time, temporary position working up to 20 hours/week. This is a hybrid position that requires working from our Berlin office 2x/week.

**Impact You’ll Own:**

- Assist the Sales team in reviewing deal proposals to ensure compliance with pricing, discounting, and contract guidelines.

- Create and manage quotes in the CRM system (e.g., Salesforce), ensuring accurate pricing and terms before submission for approval.

- Work closely with Sales, Finance, Legal, and other internal teams to facilitate the deal approval process and resolve any potential roadblocks.

- Assist with reviewing contracts for accuracy, adherence to terms, and proper approvals before sending to customers for execution.

- Help maintain accurate deal data in the CRM and support the sales team in navigating deal approvals and processes.

- Identify areas for improvement within the deal desk process and suggest ways to enhance efficiency and reduce friction for the sales team.

**What You Bring:**

- Currently enrolled in a full-time program at a university

- Experience working with large data sets

- Proficiency in Excel/Google Sheets

- Ability to communicate in both German and English, the working language of the company

- Experience proofreading and editing with attention to detail

- Experience collaborating and working with teams

**What Makes You Stand Out:**

- Experience in an operations role supporting Sales or Quote-to-Cash processes

- Experience with tools such as Salesforce, Clari, Gong, ZoomInfo

**Application Deadline:**

September 14, 2026 by 11:59p / 23:59 CET (Central European Time)

**Benefits While Working at Planet:**

*These offerings are dependent on employment type and geographical location, based upon applicable law or company policy.*

- Generous time off including vacation, holidays and company global days off

- Comprehensive Leave Policies

- Employee Wellness Program

- Home Office Reimbursement

- Monthly benefit to choose from a variety of providers (Urban Sports Club, Groceries, Clothes, Entertainment, Transportation...)*

- Monthly Phone and Internet Reimbursement

- Access to LinkedIn Learning

- Volunteering Benefits

**San Francisco Fair Chance Ordinance
**Pursuant to the San Francisco Fair Chance Ordinance, we will consider for employment qualified applicants with arrest and conviction records.**
**

**Why we care so much about Belonging.
**We’re dedicated to helping the whole Planet, and to do that we must strive to represent all of it within each of our offices and on all of our teams. That’s why Planet is guided by an ultimate north star of Belonging—dreaming big as we approach our ongoing work. If this job intrigues you, but you’re thinking you might not have all the qualifications, please... do apply! At Planet, we are looking for well-rounded people from around the world who can contribute to more ways than just what is listed in this job description. We don’t just fill positions, we aspire to fulfill people’s careers, most excited about folks who are motivated by our underlying humanitarian efforts. We are a few orbits around the sun before we get to where we want to be, so we hope you’re excited to come along for the ride.

**EEO statement:
**Planet is committed to building a community where everyone belongs and we invite people from all backgrounds to apply. Planet is an equal opportunity employer, and committed to providing employment opportunities regardless of race, religious creed, color, national origin, ancestry, physical disability, mental disability, medical condition, genetic information, marital status, sex, gender, gender identity, gender expression, pregnancy, childbirth and breastfeeding, age, sexual orientation, military or veteran status, or any other protected classification, in accordance with applicable federal, state, and local laws. [Know Your Rights.](https://www.eeoc.gov/sites/default/files/2023-06/22-088_EEOC_KnowYourRights6.12.pdf)

**Accommodations:
**Planet is an inclusive community and we know that everyone has their own needs. If you have a disability or special need that requires accommodation during the hiring process, please reach out to ----- or contact your recruiter with your request. Your message will be confidential and we will be happy to assist you.

**Privacy Policy**: By clicking "Apply Now" at the top of this job posting, I acknowledge that I have read the [Planet Data Privacy Notice for California Staff Members and Applicants](https://www.planet.com/privacy/#california), and hereby consent to the collection, processing, use, and storage of my personal information as described therein.

**Privacy Policy (European Applicants):** By clicking "Apply Now" at the top of this job posting, I acknowledge that I have read the [Candidate Privacy Notice GDPR Planet Labs Europe](https://www.planet.com/privacy/), and hereby consent to the collection, processing, use, and storage of my personal information as described therein.

**AI in Our Interviewing Process**: Planet is committed to providing an exceptional interview experience for all candidates. We currently use [Metaview](https://www.metaview.ai/) to better focus on candidates and less on trying to capture notes. As such, with the candidate's consent, select interviews may be recorded and include a "Planet AI Notetaker" for transcription and summarization purposes. Should an interview involve use of AI interview technologies, the candidate will receive notification and have the ability to opt out both in advance and/or real-time. Opting out will not affect one's candidacy.

**Candidate AI Policy**: Planet embraces Artificial Intelligence (AI) tools, and we encourage its responsible use. We understand that candidates may use various resources, including AI tools, to *prepare* for interviews and assessments. However, *during any live interview stage or when actively completing assessments for this position, the use of AI tools—e.g. Large Language Models (LLMs), deep fake technology, etc.—is strictly prohibited unless explicitly prompted by an interviewer or assessment instructions*. If you are unsure about acceptable use, please contact your recruiter for clarification. If an AI tool or similar technology is desired as an accommodation, please contact ----- with your request for assistance. Your message will be confidential, and we will be happy to assist you. Violation of this policy may result in disqualification of your application.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
