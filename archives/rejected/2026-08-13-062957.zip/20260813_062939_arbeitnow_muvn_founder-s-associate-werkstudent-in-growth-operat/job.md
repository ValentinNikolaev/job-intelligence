# Founder's Associate - Werkstudent:in Growth & Operations (all genders)

Posted: 2026-08-12T21:30:38Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Täglich fahren Millionen Autos durch Deutschland und in den meisten davon bleibt Platz ungenutzt. Wir ändern das.

MUVN bringt Fahrer:innen mit freiem Laderaum mit Menschen zusammen, die etwas transportieren müssen. Das ist günstiger, versichert und ohne Umweg. Wir bauen dafür keinen Fuhrpark und keine neue Logistik auf, sondern nutzen einfach besser, was ohnehin schon unterwegs ist.

Du arbeitest 16 bis 20 Stunden pro Woche neben deinem Studium direkt an unserem Wachstum. Du übernimmst eigene Themen und trägst sie über das Semester hinweg.

**Du brennst für Startups**, Business Development und unternehmerisches Denken? Dann bist du bei uns genau richtig! 🚀

## Aufgaben

Was du bei uns machst:

- **Business Development**

Du recherchierst Märkte und Partnerpotenziale, baust und pflegst unsere Zielkundenlisten und bereitest Gespräche vor. Aus deiner Recherche werden konkrete Entscheidungsgrundlagen.

- **Operations & Prozessoptimierung**

Du arbeitest im Tagesgeschäft mit: Du bringst Gegenstände und Fahrten zusammen, erkennst dabei Reibung in unseren Abläufen und machst Vorschläge, wie es besser läuft. Wer selbst im Prozess steht, sieht am meisten.

- **Marketing & Growth**

Du unterstützt bei Kampagnen und Performance Marketing, erstellst Content und wertest aus, was wirklich funktioniert. Bauchgefühl ist ein Anfang. Daten sind das Ziel.

- **Zusammenarbeit mit den Gründern**

Du arbeitest direkt mit Katharina, Massimo und Emre. Du siehst, wie Entscheidungen entstehen, und bringst deine Perspektive ein.

Wo dein Schwerpunkt liegt, hängt von deinen Stärken ab. Wir schauen im Kennenlernen, welcher Bereich zu dir passt.

## Qualifikation

Du studierst BWL, Wirtschaftsingenieurwesen, Management oder etwas Ähnliches und bist während der gesamten Zeit immatrikuliert. Oder du hast einen anderen Hintergrund und kannst trotzdem erklären, warum du genau richtig bist.

Was bei uns funktioniert: Du denkst schnell, arbeitest strukturiert und übernimmst Ownership für dein Thema, ohne dass jemand täglich nachfragen muss. Du willst verstehen, wie Startups wirklich funktionieren, nicht nur wie sie auf LinkedIn klingen.

Du bist verlässlich planbar mit 16 bis 20 Stunden pro Woche und kannst dir vorstellen, länger als ein Semester dabei zu sein.

**Driven people > Degrees.** Dein Mindset zählt mehr als dein Abschluss.

## Benefits

- **Deine eigenen Themen**: abgestimmt auf dein Profil, mit echter Ownership von Tag 1

- **Faire Vergütung**: ein Stundenlohn, der zur Verantwortung passt

- **Gründern**: kein HR-Filter, keine Hierarchie dazwischen

- **Hybrides Arbeiten & Remote**: Flexibilität ist bei uns Programm

- **Offsites mit dem Team**: Gemeinsam erreichen wir mehr

- **Free MUVN Rides**: Für dich entstehen keinerlei Nutzungsgebühren

- **Corporate Benefits**: Rabatte in hunderten Onlineshops

Mehr Infos zu unseren Benefits und unseren Firmenwerten findest du auf unserer Karriereseite.

Schick uns deinen CV und zwei, drei Sätze dazu, welcher Bereich dich am meisten reizt und warum wir bescheuert wären, dich nicht einzuladen.

Oder schick ein kurzes Video. Macht uns ehrlich gesagt noch neugieriger als jedes Anschreiben.

Fragen? Direkt an Katharina.

**Let's get it muvn.** 🚀

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
