# Accounts Payable Manager EMEA

Posted: 2026-08-12T20:40:10Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

We're building a new global Berlitz, and this is your opportunity to help shape it. Nearly 150 years of expertise, meeting the ambition and technology to power a new era of learning.

If you are the kind of person who thrives in a fast-paced environment, isn’t afraid of a blank page, and is excited to help shape the future of a global company undergoing a significant transformation, **you might belong at Berlitz!**

**What You'll Do**

-

Train, mentor, and evaluate AP staff. Manage task delegation and monitor department performance metrics (KPIs)

-

Oversee invoice processing, expense reports, and payment runs to ensure disbursements are timely and avoid late fees

-

Build and maintain strong supplier relationships, negotiate payment terms, and resolve escalated discrepancies or disputes

-

Ensure accurate vendor statement reconciliations, balance sheet accounts, and month-end closing activities.

-

Ensure compliance with company policies, tax requirements and regulatory standards. Support audits by providing requested documentation

-

Standardize and automate workflows using modern ERP tools – like Netsuite, Tipalti, Emburse.

**What You'll Bring**

-

You bring specialized knowledge and at least 5 years of professional experience in an Accounting or Accounts Payable department.

-

You have a strong understanding of business processes and how they connect across the organization, combined with strong analytical and logical thinking skills.

-

You're comfortable with change, take ownership of your work and look for better ways of doing things.

-

You communicate openly, bring people together and believe the best ideas come through collaboration.

-

Experience working in an international organization or a startup/scale-up environment is highly valued.

-

Most importantly, you care about helping your team succeed while raising the bar for yourself and those around you.

## Why Join Berlitz?

-

Be part of an exciting global transformation that is truly rare

-

Work alongside talented colleagues across the world

-

Have the opportunity to make a meaningful impact to help Berlitz connect the world through language and culture.

-

Enjoy a collaborative, inclusive, and supportive work environment.

*At Berlitz, connecting people across languages and cultures is at the heart of what we do. Our global workplace reflects the diverse world we serve, bringing together different backgrounds, experiences and perspectives. We create an inclusive environment where everyone has an equal opportunity to belong, contribute and grow.*

Ready to shape what’s next? Join us and help build the future with us.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
