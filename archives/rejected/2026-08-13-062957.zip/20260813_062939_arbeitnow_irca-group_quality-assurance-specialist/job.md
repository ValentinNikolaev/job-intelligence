# Quality Assurance Specialist

Posted: 2026-08-12T20:04:37Z

## Rejection

- Category: role_mismatch
- Reason: title is an obvious mismatch for a backend profile

**Who we are: **IRCA Group, an Advent portfolio company, was founded in Italy in 1919, and it is a leading international B2B provider of high-quality semi-finished ingredients such as chocolate, decorations, creams, inclusions, nuts and pistachios, pastry mixes, gelato ingredients, and other essential solutions for industrial clients or other independent artisanal producers.With more than 2.400 employees, 22 production facilities worldwide, and €1.3 billion in revenues, IRCA Group has a solid track record of growth and international expansion.

**What do we offer: **

- An international and inclusive environment, with opportunities to work on global projects and collaborate with colleagues worldwide

- Career growth opportunities, including possibilities abroad

- Free company parking

- Company laptop

- Holidays 30 days per year

- WellPass: A health program offering access to gyms, courses, and wellness facilities

- Jobticket: A discounted public transportation ticket subsidized by the employer

- JobRad: A bicycle and e-bike leasing model via the employer with tax advantages

**The role:**

The **Quality Assurance Specialist** is responsible for ensuring compliance with food safety, quality, and regulatory requirements across the organization. This role supports the development, implementation, and continuous improvement of quality management systems by overseeing hygiene programs, HACCP implementation, allergen management, audit activities, and documentation control. Acting as a key point of contact for internal and external stakeholders, the Quality Assurance Specialist contributes to maintaining high standards of product quality, food safety, and operational excellence while fostering a strong quality culture throughout the business.

**What will you do:**

- Manage and monitor hygiene, food safety, and allergen control programs

- Implement and maintain the HACCP system, including leading the HACCP Team

- Conduct internal audits, inspections, and compliance monitoring activities

- Coordinate pest control management and oversee external service providers

- Deliver food safety and quality training to employees

- Support customer audits, certification audits, and customer inquiries

- Manage quality documentation within the GQMS framework

- Drive continuous improvement initiatives and support quality projects

**Requirements:**

- **Education: **Bachelor’s degree in Food Technologies or a related field.

- **Professional Skills/Experience: **+2 years in a similar role, preferably in B2B companies. Depth knowledge of food analysis and technology, hygiene and IFS, HACCP

- **Language Skills: **Fluent German and English

- **Computer Skills: **MS Office, SAP

- **Behavioral Requirements: **Attention to Detail; Analytical Thinking; Problem-Solving; Communication Skills; Leadership and Team Coordination; Collaboration and Teamwork; Organizational Skills; Proactivity; Adaptability; Continuous Improvement Mindset; Accountability; Customer Focus

**Details:**

- **Location**: Hochheim am Main

- **Working hours**: Full time, 38h/week, from Monday to Friday

***Working / Environmental Conditions:***

*The IRCA Group Code of Etichs outlines our policy on human and labour rights. Six sites in Italy have achieved ISO 45001 certification for health and safety. Globally, 20 IRCA Group plants have undertaken a SEDEX self-assessment (low-risk), and all IRCA Sweet sites have undergone SMETA four-pillar audits, covering labour, health & safety, environmental assessment and business ethics. In Vietnam, our plant is SA8000-certified. Currently, 10 sites have ISO 14001 which covers environmental management. *

IRCA fosters a dynamic environment, valuing different perspectives and international experiences, offering a stimulating context. We promote professional growth and career opportunities locally and internationally. With locations worldwide, we offer the chance to work on international projects, collaborate across cultures, and gain a global perspective. If you are looking for stimulating challenges and the chance to contribute your ideas for process improvement in an ever-growing company, IRCA is the right place.

* *

*We welcome applications from candidates of all genders, backgrounds, identities, nationality, ethnic origin, sexual orientation, marital status, disability, parental responsibilities, age, religion, or belief. We believe in equal opportunities for all and ensure that our hiring process complies with the highest standards of non-discrimination and inclusivity. IRCA Group is dedicated to fostering a diverse and inclusive work environment where everyone can be their authentic selves, reach their full potential, and feel a true sense of belonging. Join us in creating a workplace where diversity is valued, and everyone can thrive.*

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
