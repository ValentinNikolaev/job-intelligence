# Manager Operational Excellence & Prozessoptimierung (Food) - (m/w/d) | Raum: Ostschweiz

Posted: 2026-08-12T20:00:29Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Ein produzierendes Unternehmen in der Ostschweiz stellt seine operative Leistungsfähigkeit auf ein neues Fundament – und sucht dafür die erste Person, die OPEX im Werk auf- und ausbaut. Die Rolle ist neu geschaffen, berichtet direkt an das C-Level.

## Aufgaben

**Worum es geht**

- Sie verschaffen sich ein präzises Bild davon, wo im Werk Leistung und Effizienz verloren gehen – in der Produktion wie in den vor- und nachgelagerten Bereichen – und leiten daraus eine belastbare Roadmap ab.

- Verbesserungsinitiativen treiben Sie eigenständig voran: von der Analyse über die Umsetzung bis zur dauerhaften, messbaren Verankerung im Tagesgeschäft.

- Als Bindeglied zwischen Produktion, Technik, Qualität und Supply Chain sorgen Sie dafür, dass Abläufe nicht in Silos, sondern über die gesamte Kette hinweg gedacht und verbessert werden.

- Direkt an der Linie sind Sie Sparringspartner der Teams: Sie stabilisieren Abläufe, räumen wiederkehrende Störgrössen aus dem Weg und sorgen für einen verlässlichen Takt.

- Sie definieren die Kennzahlen, an denen sich operative Leistung ablesen lässt, und formen daraus ein Steuerungsinstrument, das Entscheidungen schneller und faktenbasiert macht.

- Über Training, Coaching und gelebtes Vorbild bringen Sie Lean-Denken und strukturierte Problemlösung ins Haus – so, dass Verbesserung nicht Ihr Einzelprojekt bleibt, sondern zur Haltung der Organisation wird.

## Qualifikation

**Was Sie mitbringen**

- Einen technischen oder wirtschaftlich-technischen Hintergrund – etwa ein Studium in Ingenieurwesen, Wirtschaftsingenieurwesen oder eine gleichwertige Qualifikation.

- Mehrere Jahre Verantwortung für Operational Excellence bzw. kontinuierliche Verbesserung in der Produktion – idealerweise in der Lebensmittelherstellung, alternativ in einem ähnlich regulierten Umfeld wie Pharma oder FMCG.

- Lean, TPM und KVP sind für Sie kein Vokabular, sondern Handwerkszeug – eine Six-Sigma-Zertifizierung ist willkommen, ein Black Belt ein klares Plus.

- Sie steuern über Zahlen, sind aber am Shopfloor zuhause: Sie kennen den Alltag an der Linie und übersetzen ihn in aussagekräftige Kennzahlen.

- Projekte und Veränderungsprozesse führen Sie souverän – auch dort, wo Sie Menschen ohne disziplinarische Weisungsbefugnis für Neues gewinnen müssen.

- Ihre Arbeitsweise ist strukturiert, analytisch und lösungsorientiert, Ihr Naturell hands-on – Sie bleiben nicht am Schreibtisch, sondern gehen dorthin, wo die Wertschöpfung entsteht.

- Sie kommunizieren klar, treten überzeugend auf und haben das Talent, Menschen für Veränderung zu gewinnen und mitzunehmen.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
