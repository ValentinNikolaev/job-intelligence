# Senior Product Manager, Intelligent Platforms (m/f/x)

Posted: 2026-08-12T20:56:01Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

## The role

Foundations Alliance's mission is to accelerate the delivery of high-quality, scalable, and highly available digital products at HelloFresh. We do this by providing services and platforms that improve our internal builders' productivity and the reliability of our applications and our data.

We're looking for a Senior Product Manager to own the vision, strategy, and execution for our Operational Data Platform — the systems that create, transport, and store data at the point of origin, and makes it available to reach analytics or AI. You'll own a well-defined, high-leverage layer of our data ecosystem: the streaming and database infrastructure that product engineering teams rely on to get data flowing reliably from day one.

Your core mission is to ensure operational data is created, delivered, and shared downstream reliably, cost-efficiently, and with the quality guarantees that everything downstream depends on — so the analytics layer receives quality data, ready to turn into governed assets. You'll define the roadmap for your squad's platform (event streaming, relational and NoSQL databases), partner closely with the Engineering Lead for the Operational Data Platform, and work cross-functionally with the data producer teams and the analytical teams consuming it.

You'll join at a pivotal moment: your squad is essential for a cost-efficiency push and a reliability push on our critical-path systems — real, visible wins you can own from day one.

## What you'll do

- Own the product vision and roadmap for the Operational Data Platform — low-latency data creation, transport, storage, and availability for downstream analytics — partnering closely with the Engineering Lead for the platform.

- Drive your squad's cost-efficiency roadmap, owning cost savings as a core KPI.

- Own the reliability of critical-path systems — streaming and core databases — setting uptime targets and feeding incident learnings back into the roadmap.

- Champion data-contract and schema standards at the point of data creation, working with data-producing engineering teams to close adoption gaps, so higher-quality data flows downstream from day one.

- Guide tooling decisions as the platform evolves, consolidating around the right tool for the job rather than accumulating redundant options.

- Own the handover contract with the Analytical Data Platform, ensuring the data they receive is consistently trustworthy and ready for governance and certification.

- Act as the primary interface between the Operational Data Platform and the data producers, translating their needs into roadmap priorities.

- Define, track, and report your squad's KPIs (cost efficiency, critical-path reliability, data-quality adoption) against Foundations' quarterly goals.

## What you'll bring

- Experience as a Product Manager with a solid grounding in data infrastructure, data engineering, or backend platforms — comfortable with streaming/messaging and database concepts.

- Working familiarity with event streaming and relational/NoSQL database technologies — enough to partner credibly with engineers on technical trade-offs.

- A track record of owning the roadmap and KPIs for a single team in a well-understood problem space, defining metrics like cost, reliability, or data quality and driving them to target.

- Comfort using data to inform prioritization and roadmap decisions, with a growing quantity/quality toolkit and openness to guidance from senior peers.

- Strong collaboration skills — you build trust and alignment with engineering leads and key stakeholders, backed by clear written and verbal communication.

- A pragmatic, execution-oriented approach — you drive day-to-day delivery with minimal guidance once direction is set, and you're comfortable navigating cost, reliability, and tech-debt trade-offs in a live production environment.

## What we offer

Compensation & Financial Wellbeing

- You’ll receive a competitive salary package, including a HelloFresh-subsidized pension scheme.

- Enjoy savings on your weekly HelloFresh box.

- Save with discount schemes with corporate benefits and Vorteile.

Health & Wellbeing

- Support your mental wellbeing with access to platforms like Headspace and Spill.

- Stay active with 24/7 office gym access, a discounted Urban Sports Club membership, and other wellbeing resources.

Flexibility & Work-Life

- Balance your life with our flexible hybrid model.

- Recharge with sabbatical leave options in addition to standard time off.

- Get to work with ease through sustainable travel perks and transportation benefits.

Career & Development

- Embrace "Learning Never Stops" with internal training, the HelloFresh Academy, and a dedicated budget for German language courses.

Culture & Environment

- Enjoy tasty in-office meal deals and fresh food options.

- We support working families with parent-friendly policies, an in-office kids corner, and an on-site babysitter.

#Product

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
