# Senior Machine Learning Engineer

Posted: 2026-08-12T20:40:10Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

We're building a new global Berlitz, and this is your opportunity to help shape it. Nearly 150 years of expertise, meeting the ambition and technology to power a new era of learning.

If you are the kind of person who thrives in a fast-paced environment, isn’t afraid of a blank page, and is excited to help shape the future of a global company undergoing a significant transformation, **you might belong at Berlitz!**

We're looking for a Senior Machine Learning Engineer to build the AI services behind our global online learning platform, giving learners real-time speech practice, conversation, and feedback. You'll own the models and AI integrations powering our speaking-practice and evaluation features: classical and fine-tuned small models, edge models, cloud-based models, and integrations with external providers. This is a coding role: you'll write, maintain, and update the ML services that ship to production, using AI coding tools as part of your daily workflow.

You'll work cross-functionally with the mobile and platform teams, providing model-serving APIs, evaluation harnesses, and AI architecture guidance, with high autonomy and low bureaucratic friction. You'll work across the full perception stack (speech, text, CV ), with room to go deep on the modalities most relevant to what we're building next.

**Core Responsibilities**

-

**Modeling & evaluation.** Build, evaluate, and productionize models across the ML lifecycle, from classical/statistical approaches to fine-tuning small, edge-friendly transformers. Evaluation is metric-driven, not just accuracy, with human-agreement baselines where applicable.

-

**GenAI & LLM integration. **Design and operate integrations with hosted LLM providers: prompt and evaluation design, LLM -as-judge patterns, provider routing/failover, and cost/latency tradeoffs.

-

**Edge & cloud models.** Build and run models both on-device and in the cloud, and choose deliberately between the two based on latency, privacy, and cost.

-

**Multimodal perception. **Work across speech ( ASR / TTS ), NLP , and CV pipelines as the product requires. Deep expertise in every modality isn't required; the judgment to reason about tradeoffs across all of them is.

-

**Production engineering. **Set up, maintain, and update ML services in production: serving constraints, monitoring, drift, and connecting offline model scores to real learner outcomes. This is hands-on coding work, not just modeling.

-

**Data pipelines. **Build and maintain the ETL pipelines that feed these models: pulling from storage and databases, cleaning and transforming data, and reducing noise in real-world learner data.

**Required Skills & Qualifications**

-

Experience: 5+ years building and shipping machine learning systems to production, spanning classical ML and applied deep learning.

-

Languages: Rust or Go preferred; C++ also valued. Python (or Julia ) for data science, modeling, and exploratory analysis.

-

ML frameworks: framework-agnostic ( PyTorch , JAX , TensorFlow ); real production experience in at least one is what matters.

-

Tools: Git for version control, code review, and collaborating across parallel teams.

-

Daily, hands-on use of AI coding tools/agents as part of how you build and ship, not an occasional aid.

-

Hands-on experience integrating hosted LLM providers into production systems: prompting, evaluation, cost/latency tradeoffs, multi-provider routing.

-

Comfortable building models from scratch and fine-tuning pretrained ones, choosing rigorously between them based on the problem's actual constraints.

-

Strong communication: explaining modeling tradeoffs to engineers and product impact to non-technical stakeholders.

**Nice to have**

-

Model compression, quantization, or distillation for on-device deployment.

-

Hands-on experience in a couple of NLP , speech ( ASR / TTS ), or CV ; full expertise in every modality is not expected.

-

Data ETL and manipulation experience: S3 or similar object storage, Postgres or other databases, data transformation, noise reduction.

**Why This Role**

-

Full-stack perception. Speech, text, and CV all live under one small team: broad exposure rather than a narrow lane.

-

Greenfield. No legacy ML pipelines or technical debt; you help design the model-serving architecture from scratch.

-

Real constraints, real judgment. Edge deployment and multi-provider LLM routing mean the job is about tradeoffs, not just model accuracy.

*At Berlitz, connecting people across languages and cultures is at the heart of what we do. Our global workplace reflects the diverse world we serve, bringing together different backgrounds, experiences and perspectives. We create an inclusive environment where everyone has an equal opportunity to belong, contribute and grow.*

Ready to shape what’s next? Join us and help build the future with us.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
