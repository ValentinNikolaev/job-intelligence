# Senior Software Engineer (Mobile / React Native)

Posted: 2026-08-12T20:40:10Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

We're building a new global Berlitz, and this is your opportunity to help shape it. Nearly 150 years of expertise, meeting the ambition and technology to power a new era of learning.

If you are the kind of person who thrives in a fast-paced environment, isn’t afraid of a blank page, and is excited to help shape the future of a global company undergoing a significant transformation, **you might belong at Berlitz!**

We are seeking a Senior Frontend Engineer to help build the mobile client for our next generation global online learning platform, empowering users worldwide to master languages and new skills through interactive courses. In this role, you will take ownership of the mobile app end to end: the screens learners use, and the path that gets them there, code, package, and distribution to the App Store and Google Play. You will work in an agile, parallel engineering environment with Claude Code woven into your daily workflow.

You will work cross-functionally with backend and platform teams (consuming typed API contracts and the mobile CI pipeline) while enjoying high autonomy and low bureaucratic friction. Best of all, you will work primarily on a greenfield app, building a modern, clean client with no legacy debt.

**Core Responsibilities**

-

**App Architecture:** Design and build learner-facing features in React Native (Expo), from screens and navigation to state management, within a shared TypeScript layer also consumed by other client surfaces.

-

**Core Tech Stack:** Utilize React Native and TypeScript as your primary stack, building on Expo’s managed workflow and the team’s shared design-system package.

-

**Mobile Delivery:** Own the path from code to store: build configuration, versioning, code signing, and submission to the App Store and Google Play.

-

**CI Integration:** Trigger and consume the platform team’s mobile CI/CD pipeline (EAS Build via GitHub Actions) to ship signed builds without owning the underlying infrastructure.

-

**AI-Assisted Engineering:** Actively integrate advanced tools like Claude Code into your daily GitHub and development workflow to maximize code quality and speed.

-

**Clean Code Standards:** Champion and apply best practices for type safety, testing, and accessibility across the app.

**Required Skills & Qualifications**

-

**Experience:** 5+ years of professional mobile development experience, with a proven track record shipping production React Native (or equivalent native) apps to real users.

-

**Deep Tech Skills:** Strong, production-proven experience with React Native, ideally on Expo’s managed workflow, including the New Architecture.

-

**Release Ownership:** Hands-on experience owning mobile release engineering end to end: signed builds, app versioning, and store submission (TestFlight/Play internal tracks, review, staged rollout).

-

**Modern Workflow:** Proficiency with GitHub for version control, code reviews, and collaborating across parallel teams.

-

**Architectural Knowledge:** Working knowledge of iOS and Android code signing, shared design-system consumption, and client-side state management patterns.

-

**Collaboration:** Excellent communication skills to mentor peers and align with parallel engineering teams.

**What Makes This Role Great**

-

**AI-Native by Default:** We build with Claude (code generation, API design, code reviews, architectural documentation, and debugging). You get first-class AI tooling that takes the boilerplate off your plate, so your time goes to product craft, judgment, and the genuinely hard client problems.

-

**Pure Greenfield:** No legacy code, no technical debt, you own the design of the mobile experience for our global EdTech platform.

-

**Infrastructure Support:** A dedicated Platform Engineering team owns the underlying CI/CD pipeline and cloud infrastructure, so you focus on the app and the release craft that gets it to users.

-

**100% Remote:** Work from anywhere in Germany

*At Berlitz, connecting people across languages and cultures is at the heart of what we do. Our global workplace reflects the diverse world we serve, bringing together different backgrounds, experiences and perspectives. We create an inclusive environment where everyone has an equal opportunity to belong, contribute and grow.*

Ready to shape what’s next? Join us and help build the future with us.

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
