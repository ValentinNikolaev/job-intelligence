# Client Data & Analytics Lead (f/m/d)

Posted: 2026-08-12T23:40:24Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Help us use technology to make a big green dent in the universe!

[Kraken](https://kraken.tech/) powers some of the most innovative global developments in energy.

We create the technology that redefines utilities and unlocks a new energy system of the future. By optimising renewable generation, building a more intelligent grid, and empowering utilities to deliver an exceptional customer experience, our operating system is transforming the industry worldwide.

It’s an incredibly exciting time to work in energy. Join us on our mission to improve the lives of ONE BILLION humans within the decade and shape a cleaner, better future for everyone.

**Kraken Customer**

What we do: build the most AI-driven, innovative, forward-thinking platform for energy management. From optimizing resources to delivering cost-effective, exceptional customer experiences through advanced Customer Information Systems (CIS), billing, meter data management, CRM, and AI-driven communications, Kraken is powering the next wave of innovation in the energy industry.

Why we do it: future energy will not look like energy as we know it today. We need to not just think about our future, but build for it. Now.

**🏠 Where you'll fit in:**

We’re looking for a brilliant senior Data & Analytics Client Delivery Lead to help clients fully leverage Kraken data and transform their data team and capabilities. You should bring extensive experience doing analytics on a strong, modern data team (e.g., data analytics, business intelligence, or related field -- analytics manager, lead data analyst, analytics or data consultant or similar); a love of working with clients; and a passion for driving the clean energy transition – energy sector experience is a plus!

**The role**

You’ll work directly with Kraken clients to help them develop modern, transformative data and analytics capabilities as part of their broader Kraken transformation. You’ll train them on Kraken data and support them in building critical reporting & insightful analytics, sometimes getting hands-on with query writing or demo analytics.

You’ll also leverage your experience leading strong analytics teams to advise senior client data leadership on how to build a high-performing, business-centric data organization and leverage data as a strategic asset to unlock ambitious business and clean energy goals.

We are a flat and agile organisation and plan to remain this way. We are looking for a hands-on Data & Analytics Client Delivery Lead that can support both directly and indirectly - sometimes jumping in and writing queries or solving data challenges and other times advising or upskilling both clients and colleagues.

You will play a critical role in ensuring the clients’ reporting and analytics transition to Kraken goes smoothly - and ensuring that clients build the transformative data capabilities needed to get full value from Kraken data and power aspirational business goals.

**🚀 What you'll own:**

-

-

Guide clients in redefining critical reporting and analytics to use new Kraken data and concepts, through hands-on query writing, working sessions, and trainings

-

Advise clients, including senior leadership, on topics like how to develop a high-performing data organization, how to build a modern tech stack, and how to pursue a data strategy and priorities that drive their core business objectives.

-

Strategically define and prioritize client data needs to influence the data product roadmap, ensuring product understands the core, shared client needs and that solutions achieve clients’ desired business outcomes

-

Partner with engineering to deliver new data features and requirements aligned to client use cases

-

Train Kraken’s broader client delivery team on how to help their respective business domains ask effective data questions and leverage data directly to drive business impact

**🧠 What you’ll bring to the party:**

-

-

Degree qualified equivalent, with strong client delivery and/or product ownership experience

-

Several years of experience as a data analytics, business intelligence, or related field -- analytics manager, lead data analyst, analytics or data consultant or similar

-

Strong familiarity with modern data practices and tools

-

Strong facility with SQL and modern BI toolsFamiliar with agile product development practices and experience collaborating with engineering

-

Excellent communications, collaboration and presentation skills

-

Strong influencing skills and ability to challenge traditional ways of thinking

-

Patience – our clients are undergoing huge transformations that take time and require our understanding

-

Experience in the energy sector a plus

**Kraken is a certified Great Place to Work in France, Germany, Spain, Japan, Australia, and USA. In the UK we are one of the Best Workplaces on Glassdoor with a score of 4.5. Check out our Welcome to the Jungle site (**[**FR**](https://www.welcometothejungle.com/en/companies/kraken)**/**[**EN**](https://app.welcometothejungle.com/companies/kraken-tech?_gl=1*1nh9ctu*_gcl_aw*R0NMLjE3NDU5MzIyNTAuQ2owS0NRanc4Y0hBQmhDLUFSSXNBSm5ZMTJ5SHlSWldxeDM4NHRIanZOMWNmNEJxSzJkRnhNdnZBX3JMcUpkLVVSSEtRQjJlWERKNkNaVWFBaWlURUFMd193Y0I.*_gcl_au*MTQwNjI1NDA2Mi4xNzQ1MzM3MTcz#company-mission-section)**) to learn more about our teams and culture.**

*Are you ready for a career with us? We want to ensure you have all the tools and environment you need to unleash your potential. If you have any specific accommodations or a unique preference, please contact us at ----- and we'll do what we can to customise your interview process for comfort and maximum magic!*

*Studies have shown that some groups of people, like women, are less likely to apply to a role unless they meet 100% of the job requirements. Whoever you are, if you like one of our jobs, we encourage you to apply as you might just be the candidate we hire. Across Kraken, we're looking for genuinely decent people who are honest and empathetic. Our people are our strongest asset and the unique skills and perspectives people bring to the team are the driving force of our success. As an equal opportunity employer, we do not discriminate on the basis of any protected attribute. We consider all applicants without regard to race, colour, religion, national origin, age, sex, gender identity or expression, sexual orientation, marital or veteran status, disability, or any other legally protected status.
*

*Our (i) *[*Applicant and Candidate Privacy Notice and Artificial Intelligence (AI) Notice*](https://kraken.tech/candidate-privacy-notice)*, (ii) *[*Website Privacy Notice *](https://kraken.tech/privacy-notice)*and (iii) *[*Cookie Notice*](https://kraken.tech/cookie-notice)* govern the collection and use of your personal data in connection with your application and use of our website. These policies explain how we handle your data and outline your rights under applicable laws, including, but not limited to, the General Data Protection Regulation (GDPR) and the California Consumer Privacy Act (CCPA). Depending on your location, you may have the right to access, correct, or delete your information, object to processing, or withdraw consent. By applying, you acknowledge that you’ve read, understood and consent to these terms

Please note that, in line with our current recruitment policy, we are unable to offer visa sponsorship for this position; applicants must have the right to work in the country that they're applying to, at the time of application.
*

*Are you ready for a career with us? We want to ensure you have the right tools and environment to unleash your potential. If you have any accommodation requests, please contact us at ----- We’ll do our best to tailor the experience to your needs so you can feel comfortable, confident and be at your best!*

*Studies have shown that some groups of people, like women, are less likely to apply to a role unless they meet 100% of the job requirements. Whoever you are, if you like one of our jobs, we encourage you to apply as you might just be the candidate we’re looking for! At Kraken, we're creating a team of genuine, honest, empathetic people. Our people are our strongest asset and the unique skills and perspectives people bring to the team are the driving force of our success. As an equal opportunity employer, we do not discriminate on the basis of any protected attribute. We consider all applicants without regard to race, colour, religion, national origin, age, sex, gender identity or expression, sexual orientation, marital or veteran status, disability, or any other legally protected status.*

*Our (i) [Applicant and Candidate Privacy Notice and Artificial Intelligence (AI) Notice](https://kraken.tech/candidate-privacy-notice), (ii) [Website Privacy Notice](https://kraken.tech/privacy-notice) and (iii) [Cookie Notice](https://kraken.tech/cookie-notice) govern the collection and use of your personal data in connection with your application and use of our website. These policies explain how we handle your data and outline your rights under applicable laws, including, but not limited to, the General Data Protection Regulation (GDPR) and the California Consumer Privacy Act (CCPA). Depending on your location, you may have the right to access, correct, or delete your information, object to processing, or withdraw consent. By applying, you acknowledge that you’ve read, understood and consent to these terms

Please note that, in line with our current recruitment policy, we are unable to offer visa sponsorship for this position; applicants must have the right to work in the country that they're applying to, at the time of application.*

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
