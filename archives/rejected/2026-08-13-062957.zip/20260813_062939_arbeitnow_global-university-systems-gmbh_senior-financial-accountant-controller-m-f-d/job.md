# Senior Financial Accountant & Controller (m, f, d)

Posted: 2026-08-13T02:09:18Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
