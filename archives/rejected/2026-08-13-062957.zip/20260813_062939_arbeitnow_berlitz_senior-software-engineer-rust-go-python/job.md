# Senior Software Engineer (Rust/Go/Python)

Posted: 2026-08-12T20:40:10Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

We're building a new global Berlitz, and this is your opportunity to help shape it. Nearly 150 years of expertise, meeting the ambition and technology to power a new era of learning.

If you are the kind of person who thrives in a fast-paced environment, isn’t afraid of a blank page, and is excited to help shape the future of a global company undergoing a significant transformation, **you might belong at Berlitz!**

We are seeking a **Senior Backend Developer** to help design and build the next generation of our global online learning platform, empowering users worldwide to master languages and new skills through interactive courses. In this role, you will take ownership of core services, designing resilient, high-performance microservices. You will work in an agile, parallel engineering environment with **Claude Code** woven into your daily workflow.

You will work cross-functionally with mobile and web teams - providing backend services, API contracts, and architectural guidance - while enjoying high autonomy and low bureaucratic friction. Best of all, you will work primarily on greenfield services, building modern, clean backend systems with no legacy debt.

**What you'll do**

-

Architecture: Design and implement highly performant, scalable, and resilient microservices from scratch using PostgreSQL and AWS.

-

Core Tech Stack: Utilize Rust as your primary language, while strategically integrating Go and Python for specific services or data workloads.

-

API Design: Build robust, clean APIs (gRPC, REST) to ensure seamless integration for parallel mobile and web engineering teams.

-

AI-Assisted Engineering: Actively integrate advanced tools like Claude Code into your daily GitHub and development workflow to maximize code quality and speed.

-

Clean Code Standards: Champion and apply best practices for type safety, concurrency, and high test coverage in a distributed system.

**Who you are**

-

Experience: 5+ years of professional backend development experience, with a proven track record in microservices and relational databases (PostgreSQL).

-

Deep Tech Skills: Strong, production-proven experience with Rust (including ownership model, lifetimes, and the async ecosystem like Tokio).

-

Polyglot Mindset: Solid proficiency in Go and/or Python to build complementary services where needed.

-

Modern Workflow: Proficiency with GitHub for version control, code reviews, and collaborating across parallel teams.

-

Architectural Knowledge: Deep understanding of distributed systems, AWS services, messaging patterns, and database optimization.

-

Collaboration: Excellent communication skills to mentor peers and align with parallel engineering teams.

**Why you should join us**

-

AI-Native by Default: We build with Claude - code generation, API design, code reviews, architectural documentation, and debugging. You get first-class AI tooling that takes the boilerplate off your plate, so your time goes to system design, judgment, and the genuinely hard backend problems.

-

Pure Greenfield: No legacy code, no technical debt - you own the design of core services and domains for our global EdTech platform.

-

Infrastructure Support: A dedicated Platform Engineering team handles provisioning and CI/CD so you can build on AWS services directly.

*At Berlitz, connecting people across languages and cultures is at the heart of what we do. Our global workplace reflects the diverse world we serve, bringing together different backgrounds, experiences and perspectives. We create an inclusive environment where everyone has an equal opportunity to belong, contribute and grow.*

Ready to shape what’s next? Join us and help build the future with us.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
