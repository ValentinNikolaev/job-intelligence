# (Junior) Consultant Privacy - Enterprise (m/f/d)

Posted: 2026-08-12T20:40:20Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

## **YOUR JOB**

Do you enjoy turning complex data protection requirements into clear, practical solutions? Are you excited about working where privacy, technology and AI truly intersect? As a (Junior) Compliance Consultant, you advise customers hands-on, take ownership of outcomes and think beyond pure theory to deliver real impact. If you want responsibility, autonomy and a steep learning curve in a fast-growing environment, then join us on our journey.

##

## **WE PROTECT THE PEOPLE BEHIND THE DATA**

We are a fast-growing security and compliance tech company with a clear purpose: we protect the people behind the data. With over 200 team members worldwide and with offices in Munich, Berlin, London, Stockholm, and Vienna, we help more than 4,000 global customers get certified fast and build a strong and scalable risk posture. With AI-powered automation, self-serve capabilities, and additional tailored expert advice, we offer our customers a seamless security and compliance experience to stay ahead of the rapidly evolving security landscape and challenges like the surge in cyber-attacks.

##

## **WHAT YOU'LL BE DOING**

-

You advise and support Enterprise customers on data protection, combining privacy expertise with smart use of our AI-powered platform.

-

You build trusted long-term customer relationships, understand your customers’ business and strategic priorities, and help them navigate evolving privacy and compliance requirements while supporting customer retention, expansion, and long-term value creation.

-

You recommend and implement appropriate compliance measures, guiding clients to use DataGuard as their central privacy hub.

-

You design and roll out data protection policies, procedures and controls that are efficient, scalable and sustainable.

-

You conduct data protection impact and risk assessments, leveraging automation to improve speed, clarity and consistency.

-

You use AI tools beyond basic prompting to optimise workflows and improve consulting outcomes.

-

You contribute to platform and service development by sharing customer feedback and collaborating across teams.

##

## **WHAT YOU'LL GET IN RETURN**

-

Steep learning curve with hands-on responsibility from day one

-

Close mentoring and strong support from experienced privacy consultants

-

Ownership of long term customer relationships and exposure to complex privacy and compliance challenges across different organisations

-

Structured onboarding and continuous learning opportunities

-

Training budget and support for relevant certifications

-

High visibility across teams and insights into Product and Engineering

-

A collaborative, supportive team that values curiosity and growth

-

The chance to shape your career path as you grow with the company

##

## **THE QUALITIES YOU'LL NEED FOR A SUCCESSFUL CAREER AT DATAGUARD**

-

First experience with privacy, compliance, consulting or other customer-facing environments, having practical experience advising on privacy and compliance topics in real customer environments is a plus

-

Pragmatic, customer-first mindset with a focus on workable, scalable solutions

-

Confident and thoughtful use of AI tools to improve quality, speed, and impact

-

Strong organisational and project management skills with the ability to manage multiple customer initiatives in parallel.

-

Clear, confident communication and strong stakeholder management paired with high ownership and proactivity

-

Excellent German and English skills

**LAST BUT NOT LEAST. FROM THE BOTTOM OF OUR HEARTS:**

No matter your origin, ethnicity, gender identity, religion or individual requirements; at DataGuard, all that counts is the person you are. As Guards and Guardettes, we are united not only by our dedication, but also by our shared belief in our purpose: Protect the people behind the data. Convince us with your personality and your skills – and together we will make great things happen. We are looking forward to meeting you!

#LI-DNI

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
