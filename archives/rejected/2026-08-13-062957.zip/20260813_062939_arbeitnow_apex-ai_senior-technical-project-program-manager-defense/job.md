# Senior Technical Project/Program Manager — Defense and Public Programs

Posted: 2026-08-13T05:05:12Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Apex.AI is building the software foundation for a new generation of sovereign, software-defined defense systems.

We are looking for a Senior Technical Project Manager to lead software projects with the German Armed Forces, public-sector defense organizations, and industrial partners, while supporting the expansion of our activities into NATO and allied European programs.

You will work at the intersection of customer, technical sales, engineering, and external partners. Your role is to continuously shape and prioritize project scope, align operational needs with technical feasibility, and keep delivery moving across multiple organizations.

Our projects focus on Software-Defined Defense, C2/C4ISR/MDO, autonomous systems, and collaborative software development environments — contributing directly to stronger European technological sovereignty and interoperability across allied defense ecosystems.

The position is based in Munich and includes regular travel within Europe.

**What You’ll Do**

-

Lead defense and public-sector software projects from project initiation through iterative delivery

-

Define and continuously refine project scope together with customers and engineering teams

-

Translate operational needs into actionable technical work packages and delivery priorities

-

Balance customer value, technical feasibility, budget, timing and engineering capacity

-

Coordinate engineering execution across internal teams and external partners

-

Manage schedules, budgets, risks, dependencies and contractual commitments

-

Translate operational requirements into actionable technical priorities

-

Represent Apex.AI in customer reviews, demonstrations and steering committees

**What You Bring**

-

Several years of experience leading technically complex, iterative projects

-

Diplomatic and collaborative working style, combined with the confidence to challenge assumptions and drive decisions

-

Proven experience in defense, public-sector technology, robotics, embedded software, aerospace, or comparable environments

-

Proven experience working with the Bundeswehr ecosystem or NATO / allied defense customers

-

Strong technical understanding of distributed software systems spanning embedded, edge, networking and cloud environments

-

Ability to work effectively with software architects, system engineers, developers and integration teams

-

Sound judgment when balancing scope, technical complexity, budget, timing and customer priorities

-

Experience coordinating multiple projects, organizations and technical disciplines

-

Comfortable driving projects forward despite evolving requirements and technical uncertainty.

-

Fluent German and English; willingness to travel

-

Eligibility to obtain security clearance (existing clearance is a plus).

**Nice to Have**

-

Existing German security clearance

-

Experience working in classified environments

-

Familiarity with Software-Defined Defense, C2/C4ISR, Multi-Domain Operations, tactical communications or AI-enabled defense systems

-

Familiarity with DevSecOps, CI/CD, software integration, verification & validation or distributed systems

-

Experience with public procurement or multi-partner defense projects

**Why Apex.AI**

You will help build the software foundations that allow NATO and allied nations to develop and field defense capabilities faster, with greater technological sovereignty and control over their systems.

You will work directly with customers, engineers, public-sector organizations and industrial partners on technically demanding programs with operational relevance.

Apex.AI brings modern software engineering, deterministic middleware, safety-critical AI systems, continuous integration, verification and validation into defense — shortening the path from requirement to deployable capability.

If you want to work on technically demanding programs with direct relevance for our security and resilience — and help change how defense software is developed and delivered — this is the place to do it.

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
