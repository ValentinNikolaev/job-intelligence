# Senior Business Transformation Analyst - Commercials

Posted: 2026-08-12T23:30:14Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

#### **Why This Role Matters**

** **

As a Business Transformation Advisor, you will lead sub-projects or workstreams within the Transformation Management sub-department, providing expertise across multiple functional areas. You will apply deep knowledge in project management, functional specifications, and process improvements, mentor junior team members, and drive the implementation of process enhancements and IT solutions for end-to-end processes.

As part of the Commercials team, you will contribute to driving projects that optimise marketing, product development, sales, and quality management processes. You will help innovate and streamline customer engagement, sales effectiveness, product lifecycle, and quality assurance.

#### **Your Role at Intersnack**

-

Independently manage sub-projects or components of larger transformation projects, ensuring alignment with Business Transformation’s strategic goals and methodologies

-

Represent Business Transformation in discussions with Management Units, Group Functions, or external partners, providing subject-matter expertise in at least two areas (e.g., process design, IT systems, change management)

-

Lead the development of functional specifications, process improvements, or organizational designs, ensuring adherence to Business Transformation’s standards

-

Mentor junior team members and contributes to their professional development

#### Your profile

-

University degree in Business Administration, Science, Technology, Engineering, Computer Science, Mathematics, or a related field

-

**Strong industry background** in **Food & Beverage** is required, with hands-on experience in **Food Quality Management**, Food Safety, Quality Assurance, and/or Food Processing. **Candidates must have worked in a food quality**-related function previously or possess significant experience within food manufacturing and production environments.

-

**Experience** in highly regulated industries such as **Food & Beverage, Pharmaceuticals, or Automotive**.

-

**Proven involvement** in large-scale business transformation initiatives, including **ERP implementations, system rollouts, digital transformation programs, or other complex cross-functional projects**.

-

Several years of relevant experience and a proven track record in project management, business transformation, or consulting

-

Strong analytical, problem-solving, and stakeholder engagement skills

-

Ability to mentor junior team members

-

Collaborative and client-centric approach

-

Experience in developing functional specifications and process improvements

-

Proficiency in project management tools (e.g., JIRA, SharePoint)

-

Fluency in English; additional languages are a plus

-

Willingness to travel approximately **4 days per week across Intersnack locations.**

####
Working with us

Intersnack has become one of Europe’s leading savory snacks producers by ‘creating happy snacking moments’ in people’s lives. Being privately owned, we operate with a long-term view and commit ourselves to a more sustainable world.

Successful and sustainably growing, we generated sales of more than 4.6 billion euros in 2025. We now have 12 regional Management Units with more than 40 production sites in Europe, Asia, Australia and New Zealand and a total workforce of more than 15,000 people.

#### What we will offer

An enjoyable, broad and fulfilling role with one of Europe’s biggest savory snacks producers. The chance to grow in an environment that values teamwork and collaboration, as well recognized to your individuality, welcoming your views, and celebrating your growth. Naturally we offer a competitive salary and benefits package, but also the opportunity to stand out for your professionalism and performance, moving forward in a challenging environment that supports each individual team member to achieve their very best. And a place to securely develop your career as part of a business that cares about the wellbeing of all its people and understands that work-life balance is fundamental to success. At Intersnack, we value and cherish diversity for the power and potential it creates. We have extraordinary team spirit, empower our people to take ownership for what they do and challenge each other to improve. Because we know that, to become a big player, you need to master being a team player first.

#### **Your application**

Please ensure that all application documents are submitted **in English only**.

**Are you excited about shaping the future with us? Then apply now - we look forward to getting to know you!**

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
