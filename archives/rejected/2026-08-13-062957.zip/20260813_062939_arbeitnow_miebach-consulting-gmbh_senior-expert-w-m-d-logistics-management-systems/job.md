# Senior Expert (w/m/d) - Logistics Management Systems

Posted: 2026-08-12T23:30:16Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Bei Miebach Consulting erwarten dich **anspruchsvolle Aufgaben entlang der gesamten Supply Chain**. Von Anfang an übernimmst du Verantwortung in spannenden Beratungsprojekten, unterstützt durch ein fundiertes, individuelles Trainingsprogramm.

Du arbeitest **analytisch** und lösungsorientiert an komplexen Fragestellungen und entwickelst** gemeinsam** mit deinem Team **innovative Lösungen** für unsere Kunden.

In einem dynamisch wachsenden Umfeld entwickelst du dich fachlich und persönlich weiter und findest bei uns den richtigen Platz, wenn du** Leidenschaft** für komplexe Fragestellungen und smarte Lösungen mitbringst.

**Diese Aufgaben erwarten Dich:**

**WMS-Implementierung & Systemintegration:** Du unterstützt die Implementierung und Weiterentwicklung von Warehouse Management Systemen wie SAP EWM, Blue Yonder (JDA) oder vergleichbaren Lösungen und sorgst für eine nahtlose Integration zwischen WMS und WCS-Systemen

**Logistikprozessanalyse:** Bestehende Prozesse in Distribution und Warehouse Operations analysierst Du ganzheitlich, identifizierst Optimierungspotenziale und entwickelst nachhaltige digitale Lösungen für moderne Lagerumgebungen

**Automatisierung & Digitalisierung:** In hochautomatisierten Logistikzentren arbeitest Du mit Technologien wie AS/RS, Shuttle-Systemen, Sortern sowie AMR-/AGV-Lösungen und begleitest deren erfolgreiche Einbindung in die Systemlandschaft

**Projektarbeit & Kundenberatung:** In nationalen und internationalen Projekten unterstützt Du Kunden bei der Konzeption, Auswahl und Implementierung von WMS-Lösungen und begleitest Transformationsprojekte entlang der gesamten Projektlaufzeit

**Schnittstellenmanagement:** Du arbeitest eng mit Kunden, IT-Teams, Automatisierungsanbietern sowie Stakeholdern aus Logistik und Operations zusammen und stellst eine strukturierte Kommunikation sicher

**Service- & Methodenentwicklung:** Gemeinsam mit dem Team entwickelst Du Best Practices, Methoden und standardisierte Ansätze für WMS- und WCS-Projekte weiter und unterstützt beim Ausbau des Serviceportfolios

**Presales & Marktbearbeitung:** Du bringst Dich aktiv in Angebotsentwicklungen und Presales-Aktivitäten ein und unterstützt die Positionierung der Warehouse-IT- und Automatisierungskompetenzen im Markt

**Wissensaustausch & Kompetenzaufbau:** Durch die enge Zusammenarbeit mit internen Experten trägst Du zum Wissensaustausch sowie zum Aufbau und zur Weiterentwicklung der digitalen Logistikkompetenzen innerhalb der Organisation bei

**Das bringst Du mit:**

-

**Berufserfahrung & WMS-Know-how:** Du verfügst über mindestens 5–6 Jahre Berufserfahrung im Bereich Warehouse Management Systems, idealerweise in der Beratung oder in einem Industrieunternehmen mit komplexen Logistikstrukturen

-

**Systemexpertise:** Du bringst tiefgehende Kenntnisse in führenden WMS-Lösungen wie SAP EWM, Blue Yonder (JDA) oder vergleichbaren internationalen Warehouse-Management-Systemen mit

-

**Automatisierungskompetenz:** Du hast Erfahrung in hochautomatisierten Logistikzentren und kennst Technologien wie AS/RS, Shuttle-Systeme, Sorter sowie AMR-/AGV-Umgebungen aus der Praxis

-

**Projekt- & Transformationserfahrung:** Du hast bereits WMS-Implementierungs- oder Transformationsprojekte begleitet und kennst die Herausforderungen moderner Warehouse-IT-Projekte

-

**Logistikverständnis:** Du verfügst über fundierte Kenntnisse der Logistikprozesse in Distribution und Warehouse Operations und verstehst die Zusammenhänge zwischen IT, Automation und operativen Abläufen

-

**Kunden- & Stakeholdermanagement:** Du arbeitest souverän mit Kunden, IT-Teams, Fachbereichen und Automatisierungspartnern zusammen und überzeugst durch ein professionelles Auftreten auf allen Stakeholder-Ebenen

-

**Analytische & strukturierte Arbeitsweise:** Du gehst komplexe Aufgabenstellungen strukturiert und lösungsorientiert an und behältst auch in internationalen Projektumfeldern den Überblick

-

**Service- & Teamorientierung:** Du bringst Dich aktiv in die Weiterentwicklung von Methoden, Best Practices und Services im Bereich Warehouse IT ein und teilst Dein Wissen gerne im Team

-

**Kommunikationsstärke:** Du kommunizierst sicher und professionell mit internen und externen Ansprechpartnern und kannst komplexe technische Inhalte verständlich vermitteln

-

**Sprachkenntnisse:** Du verfügst über sehr gute Deutsch- und Englischkenntnisse in Wort und Schrift für die Arbeit in internationalen Projekten

**Das bieten wir Dir:**

-

**Offene, dynamische Unternehmenskultur** mit flachen Hierarchien, kurzen Entscheidungswegen und Zusammenarbeit in kleinen, leistungsstarken Teams – geprägt von gegenseitiger Wertschätzung und konstruktivem Feedback

-

**Strukturiertes Onboarding** sowie kontinuierliche fachliche und persönliche Weiterentwicklung durch anspruchsvolle Projekte bei renommierten Unternehmen in einem internationalen Umfeld

-

**Attraktives Vergütungs- und Karrieremodell** mit Entwicklungspfaden und vielfältigen Aufstiegsmöglichkeiten

-

**Internationales Trainingsprogramm** zur gezielten Förderung fachlicher, methodischer und persönlicher Kompetenzen

-

**Moderne Büros in attraktiver City-Lage** in Frankfurt am Main, Berlin oder München – sehr gute Verkehrsanbindung, kostenfreie Parkplätze sowie Obst und Getränke inklusive

-

**Flexible Arbeitszeiten** mit ausgewogenem Mix aus Arbeit beim Kunden, im Büro und in Mobilarbeit

-

**Umfassendes Benefit-Paket:** 24/7-Unfallversicherung, Wertkontomodell, JobRad, Mobilitätsbudget, Internetkostenzuschuss, Edenred Karte, Gesundheitsförderung mit machtfit sowie betriebliche Altersversorgung

**Wer wir sind:**

Miebach Consulting berät seit 1973 Unternehmen vom Mittelstand bis zum globalen Konzern im **Supply Chain Management, in Logistik und Produktion**. Mit 26 Büros weltweit und über 600 Mitarbeitenden zählen wir zu den führenden Beratungen in diesem Bereich.

Als globaler, integrierter Supply-Chain-Partner verbinden wir Strategie, Engineering und digitale Expertise, um Lieferketten sowie Produktions- und Logistikstrukturen effizient, resilient und nachhaltig zu gestalten. **Unsere Lösungen** gehen über das Operative hinaus: Sie** **stärken unsere Kunden, fördern Innovationen und** helfen Unternehmen, ihre Ziele zu erreichen und ihr volles Potenzial zu entfalten**.

**Werde Teil von Miebach und gestalte gemeinsam mit uns die Supply Chains von morgen!**

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
