# Senior Frontend Engineer – Sell Online

Posted: 2026-08-12T20:45:25Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

## **About the team**

You'll join the Sell Online Tribe, the group shaping how merchants bring their businesses to life online. We design and build tools that help millions of entrepreneurs, from barbers to bakers, sell their products and services anywhere.

You'll be working on some of SumUp's biggest merchant-facing online products as part of the Bifrost team, contributing to growing and scaling critical products like Payment Links and Gift Cards, while also working on integration products that provide essential features used across many other SumUp products. They're high-traffic, high-responsibility products that other SumUp teams depend on too.

You'll join a small, cross-functional team and take on genuine ownership of the frontend - not just executing tickets, but shaping how the products evolve. With new features to ship and integration products to keep secure and current, there's real, meaningful work to get stuck into from day one.

## **What you'll do**

- Build and maintain frontend features across payment links, gift cards, and online checkout products, writing clean, testable, and maintainable code

- Contribute to the development and upkeep of our integration products and SDKs, used by both internal teams and external partners

- Take part in technical planning, design reviews, and sprint ceremonies - bringing your perspective on estimations, trade-offs, and improvements

- Help reduce tech debt and improve application performance, observability, and accessibility as a foundation for future delivery

- Monitor live services and respond to issues, providing redundancy for customer support requests reaching the team

## **You'll be great for this role if…**

- You have 5+ years of experience in TypeScript and JavaScript, with hands-on experience building production-grade React and Next.js applications (including SSR and app router patterns)

- You have experience writing unit, integration, and end-to-end tests using tools like Jest, Vitest, or React Testing Library

- You're comfortable working within CI/CD workflows and collaborating in agile environments (Scrum or Kanban)

- You have experience with UI libraries such as Radix or shadcn, and a solid understanding of accessibility and UX best practices

- You have a product mindset - someone who cares about the value delivered to merchants, not just the code written to get there, and who can work autonomously to drive complex features end-to-end

## **Why you should join SumUp**

🌎 Opportunity to work in a truly global, multicultural team from our open, vibrant Cologne office, located in the heart of the city. This involves an office-first setup
🌈 Commitment to Diversity and Inclusion: be part of a workplace that values and promotes diversity, fostering an inclusive environment where everyone's perspectives are respected and embraced
🚀 Enrolment onto our Virtual Stock Option programme: you will own a stake in SumUp's future success
📚 A dedicated annual L&D budget of €2000 for your individual development, which can be used to attend conferences and/or advance your career through further education
🏖 Generous time off: enjoy 28 days of paid leave plus public holidays and special leave days
🚗 Commute made easy: subsidised mobility options like discounted transport tickets or bike leasing
💪 Stay active: access to fitness via Urban Sports Club, mostly covered by SumUp
💰 Financial health: a corporate pension scheme with SumUp contributing an extra 20% on top of your contribution
🎁 Employee perks: get discounts across products and services via our Corporate Benefits platform
🌴 Break4me: 1-month sabbatical after 3 years of service
🔗 Referral Bonus: earn additional rewards by referring talented individuals to join the SumUp team

## **About SumUp**

Be empowered to do more that matters.

At SumUp, we're on a mission to empower small businesses across the globe by providing simple and affordable tools that allow them to thrive. Today, over 4 million businesses in 37 markets rely on SumUp as their financial partner to manage payments, finance and customer relationships.

Our commitment to small businesses is reflected in[ our diverse team](https://youtu.be/9DG64C3moeQ?si=YpcWuBNBTOQPzeLI) of over 3,000 SumUppers from over 90 nationalities, united by global collaboration and an innovative mindset.[ Our core values](https://www.sumup.com/careers/culture/) lay the foundation for who we are and what we stand for, shaping our work culture and driving our success. We foster inclusivity and a continuous learning culture, providing a safe space for personal and professional growth. Our differences make us unique and strong as we strive to create an environment where everyone belongs and feels supported, no matter how they identify.

SumUp is proud to be an Equal Employment Opportunity employer, actively seeking and embracing diversity in our workforce. We don't make hiring or employment decisions based on race, colour, religion or religious belief, ethnic or national origin, nationality, sex, gender, gender identity, sexual orientation, disability, age or any other basis protected by applicable laws or prohibited by company policy. Our commitment extends beyond recruitment to creating a safe and respectful workplace where harassment of any form is strictly prohibited. Discover more about our culture and opportunities on our[ careers website](https://www.sumup.com/careers/), and follow our journey on[ LinkedIn](https://www.linkedin.com/company/sumup/),[ Instagram](https://www.instagram.com/insidesumup/), and[ TikTok](https://www.tiktok.com/@insidesumup).

**Job Application Tip**

We recognise that candidates feel they need to meet 100% of the job criteria in order to apply for a job. Please note that this is only a guide. If you don't tick every box, it's ok too because it means you have room to learn and develop your career at SumUp.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
