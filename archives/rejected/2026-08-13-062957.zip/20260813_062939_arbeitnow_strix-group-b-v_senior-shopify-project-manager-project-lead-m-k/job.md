# Senior Shopify Project Manager / Project Lead (m/k/d)

Posted: 2026-08-12T23:30:13Z

## Rejection

- Category: tech_stack
- Reason: role does not mention Go/Golang or PHP

### **Senior Shopify Project Manager / Project Lead (m/k/d)**

**Praca zdalna, Bochum | Pełny etat | Umowa na czas nieokreślony**

#### **Cześć :)**

Lubisz brać odpowiedzialność, podejmować konkretne decyzje i w uporządkowany oraz niezawodny sposób prowadzić złożone projekty do celu? W takim razie szukamy właśnie Ciebie — **Senior Project Managera**, który kompleksowo poprowadzi projekty Shopify dla klientów, od początku do końca, dbając o przejrzystość, stabilność i jakość realizacji.

#### **Twoja misja**

-

Prowadzenie złożonych projektów Shopify dla klientów end-to-end — od kick-offu do go-live

-

Jako Project Lead przejęcie odpowiedzialności za jakość, zakres i rezultat projektu

-

Jasne strukturyzowanie projektów, ustalanie priorytetów oraz zapewnianie transparentnego procesu podejmowania decyzji

-

Wczesne identyfikowanie ryzyk, rozwiązywanie konfliktów celów oraz bezpieczne prowadzenie projektów przez wymagające etapy decyzyjne

-

Moderowanie spotkań decyzyjnych i uzgodnień ze stakeholderami w sposób zapewniający jasność i konkretne zobowiązania

-

Na wybranych wczesnych lub kluczowych etapach projektu strukturyzowanie wymagań oraz współpraca z zespołami UX i Tech w celu przygotowania solidnych podstaw do podejmowania decyzji dotyczących projektów Shopify

-

Wykorzystywanie doświadczenia koncepcyjnego przy przygotowywaniu ofert dla dużych zapytań ofertowych (RFP)

#### **Czego od Ciebie oczekujemy**

-

5–7+ lat doświadczenia w zarządzaniu złożonymi projektami cyfrowymi lub technologicznymi (mile widziane doświadczenie w agencji lub środowisku projektowym)

-

**Must-have:** Bardzo dobre doświadczenie w realizacji projektów Shopify, najlepiej również Shopify Plus (np. ekosystemy aplikacji, migracje, integracje, bardziej złożone konfiguracje)

-

Doświadczenie w prowadzeniu projektów i ponoszeniu odpowiedzialności za ich realizację — nie wyłącznie w zakresie koordynacji operacyjnej

-

Bardzo dobre umiejętności komunikacyjne i facylitacyjne

-

Uporządkowany i zdecydowany sposób działania

-

Wysoka samodzielność, odpowiedzialność i niezawodność

-

Bardzo dobra znajomość języka niemieckiego oraz dobra znajomość języka angielskiego

#### **Co oferujemy?**

-

**Bądź częścią czegoś większego:** Jako jedna z wiodących agencji Shopify w Niemczech chcemy być niezawodnym partnerem dla naszych klientów i dobrym pracodawcą. Wspieramy Cię w efektywnej pracy i promujemy zdrowy sposób jej organizacji

-

**Nieograniczone możliwości rozwoju:** Jesteś u nas kimś więcej niż tylko „trybikiem w maszynie”. Masz możliwość ciągłego uczenia się, testowania nowych rozwiązań i rozwijania swoich kompetencji, a Twój zespół zawsze Cię wspiera

-

**Prawdziwe wartości i autentyczność:** Cenimy komunikację, empatię i rozwój. Tworzymy inkluzywną kulturę, w której wspieramy różnorodność

###

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
