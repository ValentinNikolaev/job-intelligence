# Senior FSQA Manager - PHF (all genders)

Posted: 2026-08-12T20:56:01Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**About The Team:**

Are you passionate about building food safety standards and driving product quality? We are looking for someone with technical experience to drive food safety and quality compliance.

Our Food Safety & Quality Assurance team is recruiting and we are looking for an experienced and highly driven Food Safety professional to join our international team. You will work within a team based across Europe to drive food safety and quality compliance with our Produce, Herbs & Fruit (PHF) suppliers, and work collaboratively with our procurement, sourcing, supply chain and distribution centre teams. The role will share best practice, create standardized ways of working, drive improvement in food safety & quality and lead on various strategic projects to ensure we delight our customers.

**What You Will Be Doing:**

You will...

- Perform on-site supplier visits and audits to manage their approval and drive strategic improvements in quality to decrease complaints and increase customer satisfaction

- Use your expertise and knowledge from industry and the supply base to develop best practice ways of working with your suppliers and internally

- Strategically manage supplier product quality and performance. Delivering focussed error (complaint) reduction initiatives and identifying projects that will improve our quality and safety standards

- Develop and maintain strong relationships with internal and external stakeholders to ensure optimal performance

- Investigate and manage quality issues with suppliers to ensure customer availability and quality is not compromised with thorough root cause analysis and corrective action

- Own your category area to achieve key performance indicators relating to out of specification deliveries, customer complaints, and compliance metrics

- Manage and coordinate the onboarding of new suppliers and products ensuring compliance to food safety, legal and quality standards

**Who You Are:**

- 4+ years of experience in quality and food safety management, ideally within the produce industry

- Experience in auditing food manufacturers; additional food safety qualifications (e.g. HACCP, internal auditing) are highly desirable

- Willingness to travel, including some international trips; 50% of time spent at suppliers, distribution centres and the base office

- Excellent English communication and negotiation skills; pragmatic in solving time-sensitive issues - German skills are a big plus

- Confident decision-maker who remains calm under pressure and in challenging situations

- Thrives in a fast-paced environment with the ability to multitask across competing priorities

- Comfortable working with cross-functional and international teams across HelloFresh markets (UK, DACH, France, Nordics, BNL)

- intermediate to advanced skills in Google Suite / MS Office

**What you will get in return:**

● 70% off HelloFresh or Green Chef boxes
● Company pension scheme
● Gym membership
● Bupa private medical insurance (including dental & family cover options)
● Mental health first aiders and an employee assistance programme
● Dog friendly office!
● Nursery support scheme
● Cycle to work scheme
● Group Life Assurance

**Location**: The HelloFresh Farm, 60 Worship Street, EC2A 2EZ, London

**To be considered for this role, you’ll need to have the independent right to work in the UK, as we're unfortunately unable to provide sponsorship at this time.**

**Hybrid Working Policy**
We offer a hybrid working policy for eligible roles, allowing flexibility to work from home and in the office. For more details on eligibility and how this applies to the role you're applying for, please consult with your recruiter.

**Next steps**: Your application will be reviewed and if successful, a member of the Talent Acquisition Team will be in touch within 2 weeks.

You are required to cooperate with HelloFresh in all health and safety matters. You are responsible for ensuring you take reasonable care of your own health, and safety as well as others who may be affected by the work activities you undertake. You must report incidents immediately and actively raise health and safety-related concerns to your Line Manager. As part of our commitment to maintaining a safe and secure environment, we will process Disclosure and Barring Service (DBS) checks to the successful individual. Failure to disclose relevant information at application or throughout the process could affect your employment with the company.

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
