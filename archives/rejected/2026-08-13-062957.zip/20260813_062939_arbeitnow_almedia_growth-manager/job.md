# Growth Manager

Posted: 2026-08-12T23:40:15Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

This isn’t your regular job. Almedia is a place where those who want to push harder can accelerate their careers faster than anywhere else. We’re aiming to become Germany’s second bootstrapped unicorn. Almedia is already Europe’s #3 fastest-growing company in 2025 (FT1000).

We are building the future of marketing by rewarding our community of over 70 million users for engaging with our advertisers’ products. We are offering a new way to acquire users for the biggest companies in the world.

## **At Almedia, you’ll:**

-

**Own way more, way earlier** — you’ll be trusted with responsibility fast.

-

**Push harder, get further** — this isn’t a 9–5. We highly reward intensity.

-

**Join a rare environment** — you will work with ambitious high-speed, high-ownership people.

-

**Fully present** — we’re 5 days a week in the office to build the energising momentum we need.

## **Senior Growth Manager**

**Salary Range:** €45K – €75K • Offers Equity • Offers Bonus

## At a Glance

You'll own a real book of business. There is a sales and account-management motion. The size of the responsibility comes from top-line ownership. Quota chasing is not the job. You shape the work and execute it.

## **What You’ll Do **🎯

-

**Own a book of 5–15 advertiser accounts** end-to-end. You'll be the person behind the growth. The one advertisers ask when something breaks. The one our Director checks in with when an account spikes.

-

**Grow the revenue line.** You are measured on the top-line you grow, not on activity. You communicate clearly, you drive yourself without being managed, and you stay open-minded when the data proves you wrong.

-

**Run the ROAS dial.** With guidance from senior team members, tune Almedia's internal ROAS (Return on Ad Spend) targets per offer, geo, and OS, often hourly. Use Hex (or comparable SQL-notebook tool), Amplitude, Looker Studio, and Almedia's internal Freecash AI every working day.

-

**Develop a proactive account instinct.** You'll work toward spotting issues before they become problems, push budget increases, geo expansions, and format tests on a rhythm. You'll learn to intervene before a metric becomes a complaint.

-

**Bridge commercial and technical teams.** When partners flag issues, you'll debug, coordinate with engineering, and communicate back clearly to the partner.

-

**Contribute to the playbook.** Help document process improvements as you learn. Your fresh perspective is an asset.

## What your first 90 days look like

-

**Days 1–30:** Shadow our Senior Growth Managers on their account calls. Take over 2 small accounts (sub-€10K daily spend) and learn the backbone of our growth engine hands-on.

-

**Days 31–60:** Take over a full book of 5–10 accounts. Own your first KPI review with our a senior team member. Contribute with your first written process improvement.

-

**Days 61–90:** Operating with increasing independence. You've caught at least one issue before it escalated and proposed a test or lever on your book.

-

**Beyond 90 days:** A clear path from Growth Manager to Senior Growth Manager to Strategic Growth Lead and beyond. Salary and equity scale with each step.

## **What You’ll Bring **💡

-

**You're hungry and looking for a challenge.** You want to build and own real outcomes, not collect a title. You have some professional experience, have had to figure things out independently and you liked it.

-

**You tell stories with data.** You read the numbers, then you tell their story. You don't need to be a data scientist, but you should be able to open a dashboard, spot something off, and ask the right questions.

-

**You're bilingual in the best sense**, equally fluent and comfortable talking commercial with advertisers and technical with algorithm teams in the same day.

**Bonus points if you:**

-

Have some exposure to performance marketing metrics like ROAS, LTV, retention, or ARPU. If not, we'll get you there by week 2.

-

Have managed a book of advertiser or partner accounts in performance marketing, mobile gaming UA, or rewarded UA. If not, we're more than willing to develop you into that role.

-

Have used tools like AppsFlyer, Adjust, or Singular, or want to learn.

-

Have built and grown a book of business in a measurable way.

-

**Top-tier consulting (MBB) or scale-up background.** We hire the for right thoughts. Rewarded-UA depth comes in your first 60 days.

-

Have actually used Hex, worked inside the admin of a rewarded UA platform, or been on the advertiser side of one.

## **What Makes You a Great Fit **🌟

-

**Own Everything: Get It Done.** When an advertiser drops 28 action items into your channel on Monday, you don't escalate. You triage, batch, and ship the 10 that matter by Friday. You don't ask for permission to fix obvious things.

-

**Take Initiative: Be Proactive.** You spot the geo where the cap consistently under-fills. You ask the algo team why. You propose the test. You don't wait for someone to assign it.

-

**Move Fast: Start Simple, Iterate Quickly.** You'd rather change the ROAS target today on incomplete data, watch for 7–14 days, and learn. Not wait two weeks for a perfect read. You know the stabilisation window. You don't tune at hour 3. You also don't drift past day 14 without a verdict.

-

**Focus on Impact: Deliver What's Most Important.** You'd rather move €500K of monthly spend on the top account than €50K across five small ones. You know which accounts are load-bearing.

-

**Raise the Bar: Have High Standards.** When something is sub-optimal, you fix it AND document it, so the next person inherits a better one. You hold the line on quality even when it would be easier not to.

## Why Almedia? 🎁

-

**Own Our Growth:** We offer all Berlin-based employees equity in Almedia to truly be a part of our success.

-

**Scale With Almedia:** Grow alongside a startup that has been profitable from day one.

-

**Central Berlin Office:** Work from a fully-stocked modern office built for collaboration, accessible from all around Berlin.

-

**Other Benefits:** Transport subsidy, breakfasts and lunches, language learning, Urban Sports Club, and more.

We believe in fostering talent, evaluating all skill levels during the hiring process, and providing a clear path for growth. Almedia is an equal opportunity employer. We embrace and celebrate diversity, and encourage individuals from all backgrounds to apply.

Compensation: €45K – €75K • Offers Equity • Offers Bonus

- • €45K – €75K • Offers Equity • Offers Bonus

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
