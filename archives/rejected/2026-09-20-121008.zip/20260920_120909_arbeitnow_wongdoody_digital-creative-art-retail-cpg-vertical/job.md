# Digital Creative Art - Retail & CPG Vertical

Posted: 2026-09-20T08:55:25Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

WongDoody – that’s over 2,000 colleagues across 22 design studios on four continents. In Germany, around 300 colleagues work with us at our locations in Berlin, Stuttgart, Düsseldorf, and remotely. Our service areas include Experience Design, Immersive Experiences, Influencer Marketing, and future-proof, holistic Digital Marketing. As part of Infosys, a global technology leader, we develop customer-centric solutions at the intersection of creativity, technology, and artificial intelligence.

We combine deep industry expertise in FMCG, retail, automotive, mechanical engineering, and technology. For brands such as dm, Otto, Porsche, Bosch, TRUMPF, and Mercedes-Benz, we create user-centric strategies, distinctive brand presences, digital products, and influencer campaigns that seamlessly integrate creativity, data, and media.

**Our local Benefits**

- Flexible working hours
- Work where it works for you. At home or in the office, or any mix you like
- Working for strong brands and clients we believe in
- 30 days' vacation per year
- Urban Sports Club
- Nice people in welcoming teams

**What you can expect**

- Design campaigns that start in digital, not end there: develop visual concepts, image worlds, and creative territories built natively for feeds, platforms, and digital formats — work that’s designed to perform where audiences actually are
- Brainstorming and further developing innovative designs and exciting image concepts, with a strong instinct for what works on a screen first.
- Independent and responsible work in interdisciplinary project teams — alongside account management, conception, UX, social media, and clients
- Bring a digital-first idea to life across formats: from a single hero visual to a full campaign system that scales seamlessly across touchpoints

﻿­­**What we'd love to see**

- A degree in graphics or design or a comparable education 
- 3 years of work experience in an agency or similar work environment 
- A clear track record of growing through art direction roles
- A portfolio rooted in digital-native work: campaigns, visuals, or content built for digital and social from the first sketch, not adapted after the fact
- A particularly good feel for target group-oriented design, for creative campaigns, social media content and innovative advertising 
- Excellent knowledge in Adobe Creative Suite applications 
- Passion for your profession combined with a high design and quality standard and conceptual skills 
- A digital-first mindset: you think in formats and platforms before print or classic media, with a sharp eye for what’s next in digital culture
- Real curiosity for AI: comfortable weaving it naturally into your workflow, and excited to use it for bold, unexpected creative ideas — not just faster production
- Team player mentality and strong communication skills 
- Very good knowledge of English is is required

We care about your personality and professional skills. We don't care about your gender, age, nationality or appearance and are open to working with everyone.

Please note: This is a job ad by WongDoody GmbH based in Germany. Through our website or other sources, you may find job ads published by one of our WongDoody sister companies around the globe with whom we act jointly under the band “WongDoody”. For each job offer, only the entity is responsible, which has published the ad. Contact persons, required information and applicable terms may differ. You can inform yourself how WongDoody GmbH is processing your personal data provided in the application process [here](https://www.wongdoody.com/wongdoody-germany-privacy).

If you have any questions about the application process, feel free to contact our People & Culture Team directly under ----- style="font-size: 12px;">We care about your personality and professional skills. We don't care about your gender, age, nationality or appearance and are open to working with everyone.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
