# Senior Projektleiter (m/w/d) Großprojekt

Posted: 2026-09-20T08:09:04Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**Firmenprofil**

Unser Mandant ist ein erfolgreiches und wirtschaftlich stark aufgestelltes Bauunternehmen. Das Unternehmen realisiert anspruchsvolle Großprojekte im Hochbau und überzeugt durch höchste Qualitätsstandards, innovative Bauprozesse und eine langfristig stabile Auftragslage. Moderne Strukturen, kurze Entscheidungswege und ein wertschätzendes Arbeitsumfeld schaffen optimale Voraussetzungen für nachhaltigen Erfolg. Zur Verstärkung des Teams suchen wir einen erfahrenen Senior Projektleiter (m/w/d), der Großprojekte mit hoher Eigenverantwortung steuert und maßgeblich zum Projekterfolg beiträgt.

**Ihre Aufgaben**

- Gesamtverantwortliche Leitung und Steuerung anspruchsvoller Großprojekte im Hochbau
- Führung und Koordination von Projektteams sowie Steuerung aller internen und externen Projektbeteiligten
- Sicherstellung der Einhaltung von Kosten-, Termin- und Qualitätszielen über alle Projektphasen hinweg
- Verantwortung für Vertrags-, Nachtrags- und Risikomanagement sowie wirtschaftliche Projektsteuerung
- Ansprechpartner für Bauherren, Fachplaner, Behörden und Nachunternehmer auf Managementebene

**Ihr Profil**

- Abgeschlossenes Studium im Bauingenieurwesen, der Architektur oder eine vergleichbare technische Qualifikation
- Mehrjährige Berufserfahrung in der Leitung komplexer Hochbau- oder Großprojekte
- Fundierte Kenntnisse in der wirtschaftlichen und technischen Projektsteuerung sowie im Vertragsrecht (VOB)
- Ausgeprägte Führungs- und Kommunikationsstärke sowie unternehmerisches Denken
- Selbstständige, strukturierte und lösungsorientierte Arbeitsweise mit hohem Qualitätsanspruch

**Benefits**

- Unbefristete Festanstellung in einem wirtschaftlich erfolgreichen und zukunftssicheren Unternehmen
- Verantwortung für anspruchsvolle und prestigeträchtige Großprojekte mit hoher Eigenverantwortung
- Attraktive Vergütung inklusive zusätzlicher finanzieller Benefits
- Firmenfahrzeug, auch zur privaten Nutzung
- Individuelle Weiterbildungs- und Entwicklungsmöglichkeiten sowie langfristige Karriereperspektiven
- Moderne Arbeitsmittel, digitale Prozesse und ein professionelles Projektumfeld

**Kontakt**

Möchten Sie Ihre Erfahrung in der Leitung komplexer Großprojekte in einem erfolgreichen Unternehmen einbringen und die Zukunft anspruchsvoller Bauvorhaben aktiv mitgestalten? Dann freuen wir uns auf Ihre aussagekräftige Bewerbung unter Angabe Ihres frühestmöglichen Eintrittstermins. Nach Eingang Ihrer Unterlagen melden wir uns zeitnah bei Ihnen und informieren Sie transparent über die weiteren Schritte im Bewerbungsprozess.

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
