# Retail Sales Manager (m/w/d) | Remote | Region Munich

Posted: 2026-09-20T08:55:27Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

## About Wolt

At Wolt, we create technology that brings joy, simplicity and earnings to the neighborhoods of the world. In 2014 we started with delivery of restaurant food. Now we’re building the delivery of (almost) everything and you’ll find us in over 500 cities in 30 countries around the world. In 2022 we joined forces with DoorDash and together we keep on dreaming big and expanding across the globe.

Working at Wolt isn’t always easy, but it’s definitely exciting. Here you’ll learn more, build more, and ship more than in most other companies. You’ll be challenged a lot, but also have a lot of fun on the way. So, if you’re a self-starter with drive and entrepreneurial spirit, this could be the ride of your life.

## Own the Market. Build the Future of Retail.

At Wolt, we're transforming how people shop.

What started as restaurant delivery has evolved into one of Europe's fastest-growing commerce platforms, connecting millions of customers with everything from groceries and pharmacy products to flowers, electronics, and everyday essentials.

Now we're accelerating our retail expansion across Germany, and we're looking for ambitious sales professionals who want to build something meaningful, own a territory, and make a visible commercial impact.

As a Retail Sales Manager, you'll be responsible for bringing Munich's most exciting retailers onto the Wolt platform, helping them unlock new revenue streams and reach customers in entirely new ways.

If you're energized by winning new business, meeting decision-makers, and building partnerships that drive real growth, this is your opportunity.

## What You'll Do

### Win the Best Retail Partners

Identify, engage, and sign high-potential retail partners across Munich, from leading supermarket chains and specialty retailers to innovative local businesses.

### Own Your Territory

Take full ownership of your market, build a strong pipeline, and execute a winning acquisition strategy to drive Wolt's retail growth.

### Build Strategic Relationships

Meet business owners, regional managers, and decision-makers face-to-face, understand their challenges, and position Wolt as their growth partner.

### Create Commercial Impact

Negotiate mutually beneficial partnerships and help shape how retailers connect with customers through technology.

### Drive Successful Launches

Work closely with onboarding and operational teams to ensure every new partner gets off to a strong start and achieves success on the platform.

## Who We're Looking For

- 3+ years of sales, business development, or partnership experience

- Proven success in acquiring and closing new business

- Comfortable prospecting, cold outreach, and meeting customers in person

- Strong communication and relationship-building skills

- Highly self-motivated, competitive, and results-oriented

- Excellent organizational and pipeline management skills

- Fluent **German **and** good English** skills

Experience in retail, hospitality, marketplace businesses, SaaS, payments, or technology sales is a plus.

## Why Join Wolt?

### Build Something Bigger

Play a direct role in shaping the future of retail commerce in Germany.

### Accelerate Your Career

Join one of Europe's leading technology companies and gain exposure to high-growth commercial operations.

### Real Ownership

Take responsibility for your market, your results, and your success.

### **What we offer**

**Remote Role & Company Car:** This is a remote field sales role based within a **50 km radius of Munich**. You'll receive a company car to support your customer visits and field activities.

**Shape the future of retail:** We're changing the way people shop. Your mission is to make local commerce so efficient that our customers can spend their time on what matters most—instead of waiting in supermarket queues.

**Growth & Impact:** Benefit from the steep learning curve of a global tech company and help take our market in Munich to the next level.

**Ownership:** Work independently in a dynamic team with flat hierarchies and have a direct impact on the success of the business.

**Equipment:** You'll receive top-of-the-line hardware, including an iPhone and MacBook, to help you succeed.

**Wolt Benefits:** Enjoy discounts on Wolt orders, a public transportation subsidy, and wellness benefits (e.g. Urban Sports Club).

**Work-Life Balance:** 30 days of annual leave, flexible working hours, and access to our modern office in the heart of Munich whenever you need it.

Compensation for this role starts at €67,000 OTE, structured with a 60/40 base-to-variable pay split.

## Ready to Make Your Mark?

We're looking for ambitious sales professionals who enjoy building relationships, winning new business, and creating long-term commercial impact.

Apply now and help redefine how people shop in Munich.

## Our Commitment to Diversity and Inclusion

We’re committed to growing and empowering a more inclusive community within our company, industry, and cities. That’s why we hire and cultivate diverse teams of people from all backgrounds, experiences, and perspectives. We believe that true innovation happens when everyone has room at the table and the tools, resources, and opportunity to excel.

*Beware of recruitment scams: DASH Brands will never ask you to pay money or share sensitive financial information during hiring — learn more about DASH Brands' legitimate recruiting process at* [*careersatdoordash.com/recruitment-scam-awareness*](http://careersatdoordash.com/recruitment-scam-awareness)*.*

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
