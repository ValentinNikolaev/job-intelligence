# Account Executive (m/w/d)

Posted: 2026-09-20T08:09:59Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**HERAUSFORDERUNG UND PERSPEKTIVE**

Du liebst es, Deals zu jagen statt Leads zu verwalten? Dann lies weiter.

JUNE ist die Plattform, auf der Rechtsabteilungen und Kanzleien komplexe und hochvolumige Verfahren führen – weitgehend automatisiert, durchgängig KI-gestützt: von der Erfassung eingehender Post und Falldaten über Fristen und Dokumentenerstellung bis zur gemeinsamen Fallarbeit. Dabei sind wir Vorreiter darin, KI und Case Management zu verbinden – im Einsatz bei Rechtsabteilungen wie Lufthansa und Swiss Life sowie bei Kanzleien wie CMS und Pinsent Masons. Ein echter Markt-Disruptor in einer Branche, die viel zu lange stillstand – und dafür brauchen wir Menschen, die Verantwortung nicht suchen, sondern einfach übernehmen. Als Senior Account Executive führst du den gesamten Sales-Cycle – von der ersten Ansprache bis zum unterschriebenen Vertrag – eigenständig, mit klarem Kopf für Pipeline, Forecast und die Menschen auf der anderen Seite des Tisches.

**Was dich erwartet:
**

- End-to-End Ownership deiner Deals – Steuerung, Forecasting, Zielerreichung liegen bei dir
- Eigene Verticals, die du strategisch aufbaust statt nur abzuarbeiten
- Direkter Draht zu Tech & Customer Success, sobald es technisch wird – du bleibst der Owner der Beziehung
- Ein Produkt, das du wirklich verstehst und erklären kannst, statt es nur zu verkaufen
- Messen, Events und Kundentermine live vor Ort statt nur Zoom-Kacheln

**PERSÖNLICHKEIT UND QUALIFIKATION**

**Was du mitbringst:**

- Erfahrung im Vertrieb erklärungsbedürftiger SaaS-Lösungen und ein sicheres Gespür für komplexe Sales-Zyklen
- Die Fähigkeit, dich souverän zwischen Fachabteilung und Entscheidungsebene zu bewegen
- Analytisches Verständnis für Geschäftsprozesse – du leitest Mehrwert und ROI her, statt nur Features aufzuzählen
- Drive: Du treibst deine Deals aktiv voran und lässt kein Follow-up liegen
- Eine strukturierte, verbindliche Arbeitsweise – dein CRM ist bei dir immer sauber, nicht nur vor dem Forecast-Call
**Warum JUNE?**
Weil Arbeit sich gut anfühlen soll, wenn großartige Dinge entstehen: Remote-Arbeit an erster Stelle, 30 Tage Urlaub, Family-First-Politik, keine Kleiderordnung, technische Wahlfreiheit. Unser Culture Code: Real Connections, Own Your Impact, Disruptive By Default, Serious Fun.

**Klingt nach deinem nächsten Kapitel? Dann lass uns reden.**

**UNTERNEHMENSKULTUR UND UMFELD**

Wir sind ein founder-led AI-Scale-up mit kurzen Wegen, hoher Geschwindigkeit und dem Anspruch, eine ganze Branche neu zu denken. Bei uns arbeitest du in einem Team, das sich gegenseitig vertraut, unterstützt und gemeinsam wächst #RealConnections.
Jeder übernimmt Verantwortung, gestaltet aktiv mit und kann echten Einfluss auf unseren Erfolg nehmen #OwnYourImpact. Wir lieben es, Bestehendes herauszufordern, neue Ideen auszuprobieren und mit modernster Technologie Grenzen zu verschieben #DisruptiveByDefault.
Wir arbeiten fokussiert, feiern Erfolge gemeinsam und verlieren dabei nie die Freude am Aufbau von etwas Großem. Denn die besten Ideen entstehen dort, wo Neugier, Teamgeist und der Mut zum Ausprobieren aufeinandertreffen #SeriousFun.
Weitere Informationen zu June und unserem Arbeitsumfeld findest du auf unserer Karriereseite:
[https://www.june.tech/de/karriere/](https://www.june.tech/de/karriere/)

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
