# Supply Chain Analyst (WM)

Posted: 2026-09-20T08:55:27Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

## About Wolt

At Wolt, we create technology that brings joy, simplicity and earnings to the neighborhoods of the world. In 2014 we started with delivery of restaurant food. Now we’re building the delivery of (almost) everything and you’ll find us in over 500 cities in 30 countries around the world. In 2022 we joined forces with DoorDash and together we keep on dreaming big and expanding across the globe.

Working at Wolt isn’t always easy, but it’s definitely exciting. Here you’ll learn more, build more, and ship more than in most other companies. You’ll be challenged a lot, but also have a lot of fun on the way. So, if you’re a self-starter with drive and entrepreneurial spirit, this could be the ride of your life.

Wolt is a Finnish technology company on a mission to make cities better places to live by empowering local commerce. Since 2014, we've grown from food delivery in Helsinki into a platform spanning groceries, retail, and more, operating in 30+ countries and 800+ cities together with DoorDash. Wolt Market is our own grocery concept, bringing everyday essentials to customers' doors in minutes, and our Wolt Market business in Germany is growing fast. We're looking for a Supply Chain Analyst to help keep our stores stocked, our operations efficient, and our customers happy.

## What you’ll be doing

As a Supply Chain Analyst, you'll be the person who keeps our Wolt Market stores in Germany running smoothly behind the scenes, making sure the right products are on the shelf at the right time. You'll dig into data to spot trends and risks early, and work closely with store operations, category management, and central supply chain teams to keep availability high and waste low.

### **Day-to-day in this role you’ll:**

- Monitor and analyze inventory levels, stock availability, and replenishment across our Wolt Market dark stores in Germany, flagging risks before they become problems

- Build and maintain demand forecasts to guide ordering decisions, working closely with store teams and category managers to balance availability against waste

- Identify and troubleshoot supply chain bottlenecks, from supplier delays to warehouse capacity issues, and drive process improvements to fix them

- Build reports and dashboards that give visibility into key supply chain KPIs, such as stock-outs, waste, and on-time delivery, and share insights with stakeholders across the business

## Our humble expectations

We don't expect you to tick every box below, but we think you'll thrive in this role if you have most of the following:

- 1-3 years of experience in supply chain, logistics, retail operations, or a similarly analytical role, ideally in grocery, e-commerce, or quick commerce

- Strong Excel/Google Sheets skills,

- A structured, data-driven approach to problem solving, with the ability to turn numbers into clear recommendations

- Fluent in English and German, both written and spoken, to work effectively with local teams, suppliers, and stores across Germany

**Nice to haves: **

- Experience with WMS/ERP systems, demand forecasting tools, or a background in FMCG/grocery supply chain is a big plus, though not required

- Solid grasp of SQL or similar tools to pull and analyze your own data

- Comfortable using AI tools and prompting to work smarter, automate repetitive tasks, and get the most out of AI in your day-to-day work

## What we offer

Joining Wolt Market Germany means real ownership over an area that directly shapes what thousands of customers see on their doorstep every day. You'll work alongside sharp, supportive colleagues across Germany and the wider Wolt/DoorDash organization, with plenty of room to grow as our Wolt Market business scales. On top of that, expect a competitive salary, employee discounts on Wolt orders, and the flexibility and trust of a company that still moves like a startup.

## Next steps

If you are excited about working in a high-growth environment, taking ownership, and being part of an extremely ambitious team, then click below to apply, make sure to add your CV and get the conversation going!

We will be reviewing applications on an on-going basis. If this sounds like an opportunity you want to pursue, apply today! 💙

## Our Commitment to Diversity and Inclusion

We’re committed to growing and empowering a more inclusive community within our company, industry, and cities. That’s why we hire and cultivate diverse teams of people from all backgrounds, experiences, and perspectives. We believe that true innovation happens when everyone has room at the table and the tools, resources, and opportunity to excel.

*Beware of recruitment scams: DASH Brands will never ask you to pay money or share sensitive financial information during hiring — learn more about DASH Brands' legitimate recruiting process at* [*careersatdoordash.com/recruitment-scam-awareness*](http://careersatdoordash.com/recruitment-scam-awareness)*.*

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
