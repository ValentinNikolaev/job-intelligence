# Intern AI & Data Engineering (m/f/d)

Posted: 2026-09-20T08:09:27Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**What we look for:**

- You support client projects in turning AI opportunities into practical, valuable, and scalable solutions.
- You contribute to the development and implementation of AI and automation use cases, from the initial idea to technical prototypes.
- You help build software components, interfaces, and prototypes for concrete client applications.
- You prepare, integrate, and process data for AI applications and support the connection of different data sources.
- You contribute to the development and continuous improvement of data pipelines and technical foundations for scalable solutions.
- You work closely with AI specialists, data scientists, engineers, and consultants in interdisciplinary client projects.
- You evaluate new AI tools, models, and methods, assess their potential for relevant use cases, and document your findings.

**What we require:**

- You are currently pursuing a degree in Computer Science, Data Science, Artificial Intelligence, Software Engineering, or a related field with excellent academic performance.
- You have gained initial hands-on experience in software development, ideally with Python.
- You have a strong interest in generative AI, machine learning, data engineering, and modern software architectures.
- Ideally, you have basic knowledge of databases, APIs, cloud technologies, or version control systems such as Git.
- You demonstrate strong analytical and solution-oriented thinking, with a structured, independent working style and high standards for quality.
- You are able to communicate technical topics clearly and enjoy collaborating with clients and multidisciplinary project teams.
- You have good German and English skills.

**What you can expect:**

- **Your impact is crucial:** You develop solutions that connect AI strategy and technical implementation, creating tangible value for our clients.
- **Your hard work pays off!** You benefit from attractive salary packages, participation in sales success, and exclusive investment opportunities. In addition, we promote our top talents through the “Digital Leaders of Tomorrow” program.
- **Your development – our concern:** From day one, you will be supported through a wide range of development opportunities, take on responsibility quickly, and have the opportunity to shape your individual career path.
- **Your working environment:** You will be immersed in a diverse and family-friendly environment with a strong team spirit, benefiting from a flexible and hybrid working model in one of our offices.
- **Your view into the future:** You will work at the cutting edge and gain valuable practical experience with modern AI models, data platforms, and scalable digital solutions.
- **Your benefits on top:** You can look forward to regular team events and sports sessions, an attractive company pension scheme, Wellpass membership, mobility and meal allowances, and a wide range of additional company benefits.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
