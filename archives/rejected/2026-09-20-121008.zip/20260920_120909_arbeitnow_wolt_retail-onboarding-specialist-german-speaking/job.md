# Retail Onboarding Specialist - German Speaking

Posted: 2026-09-20T08:55:27Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

## About Wolt

At Wolt, we create technology that brings joy, simplicity and earnings to the neighborhoods of the world. In 2014 we started with delivery of restaurant food. Now we’re building the delivery of (almost) everything and you’ll find us in over 500 cities in 30 countries around the world. In 2022 we joined forces with DoorDash and together we keep on dreaming big and expanding across the globe.

Working at Wolt isn’t always easy, but it’s definitely exciting. Here you’ll learn more, build more, and ship more than in most other companies. You’ll be challenged a lot, but also have a lot of fun on the way. So, if you’re a self-starter with drive and entrepreneurial spirit, this could be the ride of your life.

Du bist äußerst detailorientiert und verfügst über exzellente Kommunikationsfähigkeiten? Du arbeitest gerne in funktionsübergreifenden Umfeldern, übernimmst Verantwortung und löst komplexe Herausforderungen strukturiert und proaktiv? Wenn das nach Dir klingt, würden wir uns sehr gerne mit Dir austauschen!

## **Hintergrund der Rolle**

Unser Retail Onboarding Team (ReOB) ist das Herz und die Seele von Wolt. Wir stellen sicher, dass wir alle unsere Retail-Partner*innen durch ein nahtloses, skalierbares Onboarding-, Menü- und Katalogerlebnis nachhaltig auf Erfolgskurs bringen. Dabei vereint ReOB operative Exzellenz in Onboarding & Kommunikation mit datengetriebener Menüpflege sowie Elementen des Category Managements.**
**Mit dem kontinuierlichen Wachstum von Wolt steigt auch die Komplexität unserer Prozesse und Anforderungen. Als Senior-Mitglied des Retail Onboarding Teams übernimmst Du eine Schlüsselrolle in der Steuerung, Optimierung und Skalierung unserer Onboarding Engine im deutschen Markt. Du arbeitest eng mit internen Teams sowie großen Retail-Partner*innen (z. B. Key Accounts wie Edeka) zusammen und stellst sicher, dass wir sowohl Geschwindigkeit als auch Qualität im Onboarding maximieren.

## **Was wir bieten:**

Die Möglichkeit, in einem internationalen Umfeld maßgeblich an etwas Außergewöhnlichem mitzuwirken
Eine steile Lern- und Entwicklungskurve in einem global agierenden Technologieunternehmen
Ein attraktives Gehalt sowie flexible Arbeitszeiten
Hohe Eigenverantwortung und Gestaltungsspielraum in einem dynamischen Team
Flache Hierarchien in einer skalierenden Start-up-Atmosphäre
Rabatt auf Wolt-Bestellungen
ÖPNV-Zuschuss
Wellness-Zuschuss (Urban Sports Club)
Wöchentliche (virtuelle) All-Hands-Meetings und regelmäßige Teamevents

Flexible Arbeitszeiten + 30 Tage bezahlter Urlaub

## **Bist Du begeistert von dieser Gelegenheit, denn Du wirst…**

Die End-to-End-Verantwortung für das Onboarding von Retail-Partner*innen übernehmen – von der ersten Kommunikation bis zum erfolgreichen Go-Live**
**Partner*innen aktiv onboarden, trainieren und auch vor Ort schulen, um ihren langfristigen Erfolg auf Wolt sicherzustellen
Fotoshootings koordinieren sowie externe Ressourcen für Dateneingabe und Katalogerstellung steuern
Menüs und Sortimente pflegen, strukturieren und optimieren – mit einem starken Fokus auf Datenqualität und Effizienz (Excel ist ein zentraler Bestandteil Deiner täglichen Arbeit)
Die Qualität von Produktdaten und Katalogen sicherstellen und kontinuierlich verbessern
Eng mit Sales, Account Management und weiteren Stakeholdern zusammenarbeiten, um Engpässe im Onboarding-Funnel zu identifizieren und zu beseitigen
Als zentrale Schnittstelle proaktiv Hindernisse adressieren und die Onboarding-Geschwindigkeit maßgeblich steigern Prozesse analysieren, verbessern und durch den Einsatz neuer Technologien skalierbarer gestalten

## **Unsere Erwartungen**

Du bringst eine ausgeprägte Ownership-Mentalität sowie unternehmerisches Denken mit und arbeitest eigenständig mit minimaler Anleitung
Du bist strukturiert, detailorientiert und gehst Aufgaben proaktiv und lösungsorientiert an
Du bist kommunikationsstark (Deutsch & Englisch, schriftlich und mündlich) und fühlst Dich im Austausch mit unterschiedlichen Stakeholdern – auch auf Senior-Level – sicher
Du hast keine Scheu, zum Hörer zu greifen, Stakeholder zu challengen und Themen aktiv voranzutreiben
Du verfügst über mehrere Jahre Erfahrung (idealerweise 4+ Jahre) in Sales, Account Management, Operations oder Customer Support
Du arbeitest gerne datengetrieben und sicher mit Excel und/oder Google Sheets – und hast Lust, Deine Fähigkeiten weiter auszubauen
Du besitzt ausgeprägte analytische Fähigkeiten und eine “bias for action”-Mentalität mit Fokus auf Impact
Du arbeitest effektiv in funktionsübergreifenden Teams und treibst Zusammenarbeit aktiv voran**

**

## English:

Are you highly detail-oriented, with outstanding communication skills? Do you thrive in cross-functional environments, take ownership, and approach complex challenges in a structured and proactive way? If this sounds like you, we'd love to connect!

## **Background of the role**

Our Retail Onboarding Team (ReOB) is the heart and soul of Wolt. We ensure that all our retail partners are set up for long-term success through a seamless, scalable onboarding, menu, and catalog experience. ReOB combines hands-on onboarding & communication with data-driven menu management and elements of category management.
As Wolt continues to grow, so does the complexity of our operations. As a Senior member of the Retail Onboarding team, you will play a key role in driving, optimizing, and scaling our onboarding engine in the German market. You will work closely with internal teams as well as major retail partners (e.g. key accounts like Edeka), ensuring we maximize both speed and quality.

## **What we offer**

The opportunity to play a key role in shaping something exceptional in an international environment
A steep learning and growth curve in a global technology company
An attractive salary and flexible working hours
High ownership and autonomy within a dynamic team
A flat hierarchy in a scaling start-up environment
Discount on Wolt orders
Public transport allowance
Wellness allowance (Urban Sports Club)
Weekly (virtual) all-hands meetings and regular team events
Flexible working hours + 30 days paid holiday

## **Are you excited about this opportunity because you will…**

Own the end-to-end onboarding of retail partners – from first contact to successful go-live
Actively onboard, train, and support merchants, including conducting on-site training when needed
Coordinate photoshoots and manage external workforce for data entry and catalog creation
Edit, structure, and optimize menus and assortments, with a strong focus on data quality (Excel is a core part of your daily work)
Ensure high-quality product data and continuously improve catalog standards
Collaborate closely with Sales, Account Management, and other stakeholders to remove bottlenecks across the onboarding funnel
Act as a central driver of onboarding velocity by proactively identifying and resolving roadblocks
Analyze and improve workflows, leveraging new technologies to scale operations

## **Our expectations**

You demonstrate strong ownership and an entrepreneurial mindset, working independently with limited guidance
You are structured, detail-oriented, and proactive in solving problems
You have excellent communication skills in German and English (written and verbal), and are confident working with senior stakeholders internally and externally
You are not afraid to pick up the phone, challenge stakeholders, and drive execution
You bring several years of experience (ideally 4+ years) in sales, account management, operations, or customer support
You are comfortable working with data and Excel/Google Sheets, and are eager to further develop these skills
You have strong analytical and problem-solving skills with a clear bias for action and impact
You thrive in cross-functional environments and actively drive collaboration

## Our Commitment to Diversity and Inclusion

We’re committed to growing and empowering a more inclusive community within our company, industry, and cities. That’s why we hire and cultivate diverse teams of people from all backgrounds, experiences, and perspectives. We believe that true innovation happens when everyone has room at the table and the tools, resources, and opportunity to excel.

*Beware of recruitment scams: DASH Brands will never ask you to pay money or share sensitive financial information during hiring — learn more about DASH Brands' legitimate recruiting process at* [*careersatdoordash.com/recruitment-scam-awareness*](http://careersatdoordash.com/recruitment-scam-awareness)*.*

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
