# Manager Digital & AI Strategy - Automotive (m/f/d)

Posted: 2026-09-20T08:09:27Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**What we look for:**

- You lead internal and external strategy projects in the automotive industry as a Manager and Project Lead, from planning and implementation to monitoring and review.
- You lead the strategic planning and implementation of digital marketing and AI strategies for national and international automotive clients, aligned with their overall strategy.
- You manage workshops, meetings, research, business analysis, and process development for internal and external projects.
- You take the lead on customer pitches and projects and support management from preparation through follow-up.
- You are the main point of contact for internal and external stakeholders, coordinate communication, and support decision-making.
- You ensure that projects stay on budget, on schedule, and aligned with customer needs.
- You contribute to customer reports.
- You collaborate across functions with colleagues from different departments.
- You mentor team members and support their career development.
- You support new business development in the automotive industry by contributing to pitches and identifying opportunities.

**What we require:**

- You hold an excellent university degree in business administration, economics, computer science, automotive engineering, or a related field.
- You have at least four years of relevant professional experience in digital strategy or digital marketing in the automotive industry; additional qualifications are a plus.
- You have strong analytical skills, a strong interest in technology, and a creative, conceptual mindset.
- You have very good Excel and PowerPoint skills and are comfortable using AI tools.
- You have excellent verbal and written communication skills.
- You are client-focused, communicative, and a team player, with strong self-motivation and passion for your work.
- You are fluent in English; additional local language skills are a plus.

**What you can expect:**

- **Your impact is crucial: **You actively shape the digital future in a highly motivated & smart team in direct cooperation with the founders & partners, creating real added value by linking strategy and implementation.
- **Your hard work pays off! **You benefit from attractive salary packages, participation in sales success and exclusive investment opportunities. In addition, we promote our top talents through the 'Digital Leaders of Tomorrow' program and thus offer you further exciting benefits.
- **Your development - our concern: **From day one, you will be supported on your journey through a wide range of development opportunities, quickly take on responsibility and have the opportunity to shape your individual career at OMMAX - with us you will become a digital leader!
- **Your working environment:** You will be immersed in a diverse and family-friendly environment with a strong team spirit, benefitting from a flexible and hybrid working model in one of our offices in Munich, Paris, London, Amsterdam, Milan and Berlin. 
- **Your view into the future:** You will work at the cutting edge and gain valuable insights and practical experience with a focus on digital business models and data-driven value creation in eight forward-looking industries.
- **Your benefits on top: **You can look forward to regular team events and joint sports sessions, an attractive company pension scheme, access to local fitness and wellness partnerships as well as mobility and meal allowances and a wide range of other company benefits.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
