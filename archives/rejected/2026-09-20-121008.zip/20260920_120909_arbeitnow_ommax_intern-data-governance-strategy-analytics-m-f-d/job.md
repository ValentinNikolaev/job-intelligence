# Intern Data Governance, Strategy & Analytics (m/f/d)

Posted: 2026-09-20T08:09:27Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**What we look for:**

- You support client projects that strengthen data governance, data strategy, and analytics capabilities across organizations.
- You analyze and document data processes, standards, roles, responsibilities, and business requirements at the interface of business and IT.
- You contribute to the development of practical data governance frameworks, operating models, data-quality initiatives, and data-driven transformation roadmaps.
- You help translate business priorities into actionable data use cases, reporting concepts, and decision-support solutions.
- You create and further develop reports and dashboards, particularly in Power BI, and support the definition of meaningful KPIs.
- You research developments in data management, business intelligence, analytics, and AI, turning findings into concise and practical insights.
- You collaborate with consultants, data specialists, engineers, and client stakeholders, contributing reusable templates, analyses, and knowledge to our Data & AI offerings.

**What we require:**

- You are currently pursuing a degree in Business Informatics, Business Administration, Data Science, Computer Science, Mathematics, Statistics, or a related field.
- You have a strong interest in data management, business processes, analytics, and digital transformation.
- You have gained initial practical experience in data analysis, visualization, reporting, or dashboarding; experience with Power BI is a plus.
- Ideally, you have basic knowledge of SQL, Python, data modeling, or data integration concepts.
- You demonstrate strong analytical and structured thinking, with a careful and independent working style and high standards for quality.
- You are able to communicate complex topics clearly and enjoy collaborating with clients and multidisciplinary teams.
- You have good time-management skills and can reliably deliver high-quality results within deadlines.
- You are fluent in German and have good English skills.

**What you can expect:**

- **Your impact is crucial: **You actively shape the digital future in a highly motivated & smart team in direct cooperation with the founders & partners, creating real added value by linking strategy and implementation.
- **Your hard work pays off!** You benefit from attractive salary packages, participation in sales success and exclusive investment opportunities. In addition, we promote our top talents through the 'Digital Leaders of Tomorrow' program and thus offer you further exciting benefits.
- **Your development - our concern: **From day one, you will be supported on your journey through a wide range of development opportunities, quickly take on responsibility and have the opportunity to shape your individual career at OMMAX - with us you will become a digital leader!
- **Your working environment:** You will be immersed in a diverse and family-friendly environment with a strong team spirit, benefitting from a flexible and hybrid working model in one of our offices in Munich, London, Amsterdam, Milan and Berlin. 
- **Your view into the future:** You will work at the cutting edge and gain valuable insights and practical experience with a focus on digital business models and data-driven value creation in eight forward-looking industries.
- **Your benefits on top:** You can look forward to regular team events and joint sports sessions, an attractive company pension scheme, an exclusive Wellpass membership as well as mobility and meal allowances and a wide range of other company benefits. 

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
