# Manager Digital & AI Strategy - Pharma & Healthcare (m/f/d)

Posted: 2026-09-20T08:09:27Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**What we look for:**

- You lead end-to-end strategy and transformation engagements for pharmaceutical and healthcare clients, from problem definition and analysis through implementation and measurable impact.
- You lead projects in Go-to-Market transformation, commercial model transformation, AI strategy, and digital transformation.
- You advise senior executives on growth strategy, commercial transformation, customer strategy, operating models, AI-enabled business models, and digital transformation roadmaps.
- You turn complex analysis into clear management decisions, prioritized initiatives, and practical roadmaps.
- You lead transformation workstreams and larger programs, ensuring clear governance, milestones, stakeholder alignment, and delivery against business objectives.
- You design and lead executive workshops, manage senior stakeholder relationships, and act as a trusted advisor to client leadership teams.
- You build and manage high-performing teams, coach team members, and support their professional development.
- You drive business development by identifying opportunities, shaping client propositions, developing pitches, and building long-term senior client relationships.
- You help strengthen OMMAX’s capabilities and market position in AI strategy, digital transformation, commercial transformation, and pharma and healthcare strategy.

**What we require:**

- You hold an excellent university degree in business administration, economics, strategy, computer science, or a related field; a master’s degree or MBA is a plus.
- You have 5+ years of relevant experience, ideally in top-tier strategy or management consulting, digital strategy, transformation, or corporate strategy.
- You have a strong track record of developing strategies and executing transformations, ideally including Go-to-Market or commercial model transformation.
- You ideally have experience in pharma, healthcare, or life sciences; experience in other regulated industries is also a plus.
- You have experience advising senior executives and managing complex transformation programs with multiple stakeholders and workstreams.
- You have strong expertise in AI strategy, digital business models, customer transformation, Commercial Excellence, or operating model transformation.
- You combine strong analytical and conceptual skills with sound commercial judgment and a pragmatic, execution-oriented mindset.
- You communicate with confidence, present clearly, and manage stakeholders effectively.
- You are entrepreneurial, commercially minded, and motivated to create impact for both clients and OMMAX.
- You are fluent in German and English; additional language skills are a plus.

**What you can expect:**

- **Your impact is crucial: **You actively shape the digital future in a highly motivated & smart team in direct cooperation with the founders & partners, creating real added value by linking strategy and implementation.
- **Your hard work pays off! **You benefit from attractive salary packages, participation in sales success and exclusive investment opportunities. In addition, we promote our top talents through the 'Digital Leaders of Tomorrow' program and thus offer you further exciting benefits.
- **Your development - our concern: **From day one, you will be supported on your journey through a wide range of development opportunities, quickly take on responsibility and have the opportunity to shape your individual career at OMMAX - with us you will become a digital leader!
- **Your working environment:** You will be immersed in a diverse and family-friendly environment with a strong team spirit, benefitting from a flexible and hybrid working model in one of our offices in Munich, Paris, London, Amsterdam, Milan and Berlin. 
- **Your view into the future:** You will work at the cutting edge and gain valuable insights and practical experience with a focus on digital business models and data-driven value creation in eight forward-looking industries.
- **Your benefits on top: **You can look forward to regular team events and joint sports sessions, an attractive company pension scheme, access to local fitness and wellness partnerships as well as mobility and meal allowances and a wide range of other company benefits.

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
