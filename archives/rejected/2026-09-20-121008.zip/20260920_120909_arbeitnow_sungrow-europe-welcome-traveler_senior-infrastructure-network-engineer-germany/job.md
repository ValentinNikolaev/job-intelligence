# Senior Infrastructure & Network Engineer - Germany

Posted: 2026-09-20T08:09:35Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**Your mission**

Servus und hallo bei uns in Sungrow! Join our Munich IT team and help keep the infrastructure behind Europe’s clean-energy growth secure, reliable, and ready for what comes next. Curious what this is all about? Let’s dive right in:

- Own the daily operation, maintenance, and continuous improvement of Sungrow Europe’s data center infrastructure, networks, servers, storage, and virtualization platforms.
- Manage and optimize enterprise network services across European locations, including routing, resilience, performance, capacity, and high-availability design.
- Take dedicated responsibility for Munich office connectivity, including switches, Wi-Fi, firewalls, VPNs, internet services, and meeting-room networks.
- Lead technical troubleshooting, incident response, root-cause analysis, and sustainable corrective actions for complex infrastructure issues.
- Support modernization, expansion, migration, disaster recovery, and technology-refresh initiatives across infrastructure platforms.
- Strengthen security, compliance, and operational excellence through robust documentation, change management, vulnerability remediation, SOPs, and runbooks.

**Your profile**

All right, that was intriguing, wasn’t it? To thrive in this role and enjoy building reliable services for the long term, your background could look like this:

- You hold a degree in Computer Science, Network Engineering, Information Technology, or a related field, along with at least three years of relevant infrastructure or enterprise network engineering experience.
- You bring hands-on experience with Fortinet firewalls, SD-WAN, Cisco Firepower FTD, Cisco Nexus 9000, and Cisco enterprise switching environments.
- You have strong knowledge of routing, switching, and security technologies, including BGP, OSPF, VRF, ACLs, QoS, STP, NAT, link aggregation, and high-availability architectures.
- You are comfortable operating VMware, Nutanix, and KVM-based virtualization platforms, with knowledge of VMware NSX-T and its security capabilities.
- You have worked with monitoring and observability tools such as Zabbix, Prometheus, and Grafana, and can use Python, Shell, PowerShell, or Perl for automation.
- You combine structured problem-solving with a proactive mindset for capacity planning, service improvements, documentation, implementation plans, and rollback procedures.
- You communicate confidently in English at C1 level; German at B2 level is an advantage, and Mandarin Chinese at B2 level or above is a strong advantage for collaboration with global technical teams.
- Certifications such as VMware VCP, CCNA or CCNP, Microsoft Azure Administrator, ITIL Foundation, Fortinet NSE, or Nutanix Certified Professional are welcome.

**Why us?**

Join a collaborative IT department where your work directly supports Sungrow Europe’s growth and operational resilience. You will have real ownership of a diverse infrastructure landscape, work closely with international technical teams, and contribute to the systems that enable colleagues across Europe to stay connected, productive, and secure.
At Sungrow, you will help modernize enterprise infrastructure in a fast-moving greentech environment, while building practical solutions across data centers, networks, cloud platforms, and workplace technology.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
