# Einkäufer (m/w/d) Ingenieurbau - Frankfurt (Main)

Posted: 2026-09-20T08:09:04Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**Firmenprofil**

Unser Mandant ist ein erfolgreiches und etabliertes Bauunternehmen mit langjähriger Erfahrung in der Umsetzung anspruchsvoller Infrastruktur- und Ingenieurbauprojekte. Das Unternehmen steht für technische Kompetenz, wirtschaftliche Stabilität und eine professionelle Projektabwicklung. Besonders im Bereich komplexer Bauvorhaben bietet sich Mitarbeitern ein abwechslungsreiches und verantwortungsvolles Arbeitsumfeld. Zur Verstärkung des Teams wird ein Einkäufer (m/w/d) mit Schwerpunkt Ingenieur- und Brückenbau für den Standort Frankfurt am Main gesucht.

**Ihre Aufgaben**

- Eigenverantwortliche Beschaffung von Nachunternehmerleistungen, Baustoffen und Dienstleistungen für anspruchsvolle Ingenieurbauprojekte
- Einholung, Prüfung und Bewertung von Angeboten sowie Durchführung von Preis- und Vertragsverhandlungen
- Auswahl, Betreuung und Weiterentwicklung eines leistungsfähigen Nachunternehmer- und Lieferantennetzwerks
- Enge Zusammenarbeit mit Kalkulation, Bauleitung und Projektteams während der gesamten Projektabwicklung
- Identifikation von wirtschaftlichen Optimierungspotenzialen und Weiterentwicklung bestehender Einkaufsprozesse

**Ihr Profil**

- Abgeschlossenes Studium im Bauingenieurwesen, Wirtschaftsingenieurwesen oder eine vergleichbare technische bzw. kaufmännische Qualifikation
- Berufserfahrung im Einkauf, der Kalkulation oder Bauleitung, idealerweise im Ingenieur- oder Brückenbau
- Gutes technisches Verständnis sowie Interesse an komplexen Infrastrukturprojekten
- Verhandlungsgeschick, wirtschaftliches Denken und ein sicheres Auftreten
- Selbstständige, strukturierte und lösungsorientierte Arbeitsweise

**Benefits**

- Unbefristete Festanstellung in einem wirtschaftlich stabilen Unternehmen
- Attraktive und leistungsgerechte Vergütung
- Spannende und technisch anspruchsvolle Projekte im Ingenieur- und Brückenbau
- Hoher Gestaltungsspielraum und eigenverantwortliches Arbeiten
- Moderne Arbeitsmittel und professionelle Unternehmensstrukturen
- Individuelle Weiterbildungs- und Entwicklungsmöglichkeiten
- Kollegiales Arbeitsumfeld mit kurzen Entscheidungswegen und langfristiger Perspektive

**Kontakt**

Sie möchten Ihre Erfahrung im technischen Einkauf einbringen und an anspruchsvollen Infrastrukturprojekten mitwirken? Dann freuen wir uns auf Ihre aussagekräftige Bewerbung unter Angabe Ihres frühestmöglichen Eintrittstermins. Nach Eingang Ihrer Unterlagen melden wir uns zeitnah bei Ihnen und informieren Sie über die weiteren Schritte im Bewerbungsprozess.

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
