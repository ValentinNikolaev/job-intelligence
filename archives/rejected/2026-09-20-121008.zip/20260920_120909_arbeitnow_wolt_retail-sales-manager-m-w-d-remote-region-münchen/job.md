# Retail Sales Manager (m/w/d) | Remote | Region München

Posted: 2026-09-20T08:55:27Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

## About Wolt

At Wolt, we create technology that brings joy, simplicity and earnings to the neighborhoods of the world. In 2014 we started with delivery of restaurant food. Now we’re building the delivery of (almost) everything and you’ll find us in over 500 cities in 30 countries around the world. In 2022 we joined forces with DoorDash and together we keep on dreaming big and expanding across the globe.

Working at Wolt isn’t always easy, but it’s definitely exciting. Here you’ll learn more, build more, and ship more than in most other companies. You’ll be challenged a lot, but also have a lot of fun on the way. So, if you’re a self-starter with drive and entrepreneurial spirit, this could be the ride of your life.

Wolt ist im August 2020 als Land Nr. 23 offiziell in Deutschland an den Start gegangen! Was in Berlin mit der Gastronomie begann, hat sich rasant zu einer umfassenden Plattform für den lokalen Handel entwickelt.

Mittlerweile vernetzen wir zehntausende Kunden nicht nur mit großartigem Essen, sondern bringen den gesamten Einzelhandel direkt an die Haustür – von Lebensmitteln und Drogerieartikeln bis hin zu Non-Food-Sortimenten. Da wir den täglichen Bedarf unserer Kunden immer ganzheitlicher abbilden, freuen wir uns sehr, nun den nächsten Schritt zu gehen: Wir bauen unsere Aktivitäten im Retail-Segment deutlich aus und suchen Partner, die gemeinsam mit uns den Standard für modernen Quick Commerce definieren wollen.

## Deine Hauptaufgaben bei Wolt

- **Identifikation & Akquise:** Du bist verantwortlich für das Sourcing der besten Retail-Partner der Stadt. Dein Ziel ist es, Supermärkte und führende Non-Food-Einzelhändler in München als Partner zu gewinnen und zu optimalen Konditionen auf die Wolt-Plattform zu bringen.

- **Pipeline-Management:** Du steuerst deine Sales-Pipeline eigenständig und baust belastbare Netzwerke zu Inhaber:innen sowie Geschäftsleiter:innen im Einzelhandel auf.

- **Überzeugende Präsentation:** Du positionierst Wolt als führende E-Commerce-Lösung. Dabei hörst du potenziellen Partnern aktiv zu, stellst die richtigen Fragen und überzeugst Entscheidungsträger durch passgenaue Mehrwerte.

- **Präsenz vor Ort:** Dein Fokus liegt auf dem Außendienst. Deine Woche besteht aus ca. 1–2 Tagen strategischer Planung und Kaltakquise (Home Office) sowie 3–4 Tagen im Außendienst in München (inkl. gelegentlicher Hotelübernachtungen).

- **Schnittstellenarbeit:** Du arbeitest eng mit dem Onboarding-Team zusammen, um eine perfekte Abbildung deiner Partner – vom Supermarkt bis zum Blumenladen – auf unserer Plattform sicherzustellen.

## Das bringst du mit

- **Vertriebsprofi im Außendienst:**Du bringst bereits 3+ Jahre Erfahrung im Sales mit und liebst die Kaltakquise. Es motiviert dich, Partner proaktiv vor Ort zu besuchen und zu überzeugen.

- **Hohe Anpassungsfähigkeit:** Du kommunizierst souverän auf Augenhöhe – vom Blumenladen bis zum C-Level-Entscheider. Dabei bleibst du immer authentisch und zielorientiert.

- **Performance-Drive:** Du willst der Beste sein und die Top-Retail-Partner der Stadt für Wolt gewinnen, um unseren Marktanteil signifikant auszubauen.

- **Selbstorganisation:** Du planst deine Walk-in-Routen effizient, trackst deine Aktivitäten eigenständig und steuerst deine Pipeline absolut zuverlässig.

- **Positives Mindset:** Du bist hartnäckig, denkst lösungsorientiert und behältst auch bei Gegenwind deine positive Ausstrahlung.

- **Qualifikation & Sprache:** Studium oder Ausbildung, fließendes Deutsch und gute Englischkenntnisse.

## Was wir dir anbieten

- ****Remote-Arbeit & Firmenwagen:** **Diese Position ist als Remote-Rolle ausgeschrieben. Dein Einsatzgebiet befindet sich innerhalb eines 50-km-Radius rund um München. Für deine Außendiensttätigkeit erhältst du einen Firmenwagen.

- **Gestalte die Zukunft des Handels:** Wir verändern, wie Menschen einkaufen. Dein Job ist es, den lokalen Handel so effizient zu machen, dass unsere Kunden Zeit für Wichtigeres gewinnen, anstatt sie in Warteschlangen im Supermarkt zu verbringen.

- **Wachstum & Impact:** Nutze die steile Lernkurve eines globalen Tech-Unternehmens und entwickle unseren Markt in München auf das nächste Level.

- **Eigenverantwortung:** Arbeite selbstständig in einem dynamischen Team mit flachen Hierarchien und direktem Einfluss auf den Markterfolg.

- **Mobilität & Equipment:** Du erhältst Top-Hardware (iPhone & MacBook) sowie die Option auf einen Firmenwagen für deine Einsätze im Außendienst.

- **Wolt-Benefits:** Rabatte auf Wolt-Bestellungen, ÖPNV-Zuschuss sowie Wellness-Angebote (z. B. Urban Sports Club).

- **Work-Life-Balance:** 30 Tage Urlaub, flexible Arbeitszeiten und ein modernes Office im Herzen von München.

***Die Vergütung für diese Position beginnt bei einem On-Target-Earnings (OTE) von 67.000 € und ist in einem Verhältnis von 60 % Fixgehalt zu 40 % variabler Vergütung strukturiert.***

## Bereit, mit uns Geschichte zu schreiben?

Wir verändern nicht nur den Handel – wir geben den Menschen Zeit für das zurück, was sie wirklich lieben. Wenn du in einem High-Growth-Umfeld Verantwortung übernehmen willst und ein Team suchst, das Ambition mit Spaß verbindet, dann bist du bei uns genau richtig.

Bewirb dich jetzt und lass uns gemeinsam den Markt revolutionieren!

*Wichtiger Hinweis: Um deine Daten bestmöglich zu schützen (GDPR), akzeptieren wir keine Bewerbungen per E-Mail. Bitte nutze ausschließlich unsere Karriereseite für deine Bewerbung. Wir freuen uns auf dich!*

**

## Our Commitment to Diversity and Inclusion

We’re committed to growing and empowering a more inclusive community within our company, industry, and cities. That’s why we hire and cultivate diverse teams of people from all backgrounds, experiences, and perspectives. We believe that true innovation happens when everyone has room at the table and the tools, resources, and opportunity to excel.

*Beware of recruitment scams: DASH Brands will never ask you to pay money or share sensitive financial information during hiring — learn more about DASH Brands' legitimate recruiting process at* [*careersatdoordash.com/recruitment-scam-awareness*](http://careersatdoordash.com/recruitment-scam-awareness)*.*

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
