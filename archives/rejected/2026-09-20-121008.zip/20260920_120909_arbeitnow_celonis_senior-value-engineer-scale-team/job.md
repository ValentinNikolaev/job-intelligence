# Senior Value Engineer - Scale Team

Posted: 2026-09-20T08:55:37Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Celonis is the trusted platform to industrialize Enterprise AI. At our core is the Celonis Context Model — which combines process data, business knowledge, and intelligence into a living digital twin of the enterprise that AI can actually understand, turning AI's operational blind spots into operational clarity. World's leading companies trust Celonis and its global ecosystem of partners to make their AI agents, people, systems, and processes work together, achieving transformational outcomes. We believe there's a massive opportunity to unlock global productivity and sustainability by giving AI the context to understand how every business process really works. Join our mission to make processes work for people, companies, and the planet.

#### **Value Engineer (Scale team) **

**The Team:** The position of Senior Value Engineer (Scale team) is a trusted advisor responsible for driving value, adoption, and customer success across a portfolio of accounts. In this role, you will collaborate closely with customers, partners, and internal teams to strengthen customer engagement and ensure long-term success with the Celonis Process Intelligence Platform. Your responsibilities include building scalable engagement strategies, handling critical touchpoints, identifying expansion opportunities, and mitigating renewal risks, all while fostering a strong relationship with partners and driving value realization across your accounts. All while fostering strong partner relationships, customer self-sufficiency and driving consistent value realization across our entire customer base.

**The Role:** As a Senior Value Engineer (Scale team), you will play a key role in helping our customers achieve their strategic goals and realize significant value by leveraging the Celonis Process Intelligence Platform. You will collaborate with regional partners and customers, strengthening their position in the market while ensuring that they receive the guidance and tools needed for long-term success. Your role will involve driving the coordination of account activities, building structured governance at both the account and portfolio levels, and fostering value-driven relationships. In this highly collaborative position, you will work closely with our partners, customers, and internal teams to provide innovative solutions, manage escalations, and ensure the delivery of value at scale. Through the integration of AI solutions into your daily operations you will drive highly efficient, scalable portfolio management.

**Native-level German proficiency is required for this role. Candidates must be able to lead customer workshops and manage stakeholder interactions in German.**

### **The Work You’ll Do:**

- **Drive value, adoption and sponsorship **serving as the trusted advisor to customers and partners, ensuring successful adoption and value realization across a portfolio.

- **Establish robust Centre of Excellence (CoEs) and coach customers to own their value journey and provide them with self-service offerings.****Strategic Partner management orchestrating and coaching partners to deliver operational account work driving customer health. ****1:N program management and scalable motions to generate impact across a community of customers (value bootcamps, 1:1 sprint motions, POV development, Value Sprints and new asset and innovation deployments).**

- **Build stakeholder trust** and drive success across a broad portfolio of stakeholders, maximizing your impact through highly efficient, scaled interactions rather than traditional, high-touch 1:1 relationships.

- **Maintain cross-industry fluency** to remain conversant across multiple business sectors, leveraging AI-curated industry briefs to accelerate rapid context-switching across a diverse book of accounts.

- **Drive AI-orchestrated account plans **which leverage platform best practices and partner applications within AI-powered solution designs.

- **Utilize auto-generated programmatic content **including targeted industry briefs and customer-specific presentations, to manage the portfolio efficiently.

- **Work with AI-driven tools **to monitor portfolio health using AI-driven tools to proactively surface renewal risks and health signals across all accounts in parallel.

- **Operate AI agents** to continuously track value realization, adoption signals, and expansion opportunities across the entire portfolio.

- **Deploy automated value reports** and strategic nudges that empower customers to drive their own business outcomes.

- **Act as an AI-fluent operator**, utilizing copilots and intelligent agents to produce necessary technical outputs on demand.

- **Focus on the big-picture** **value **while partnering with our internal technical teams (CoE and Applied Value Engineers) to tackle the highly complex builds.

**The qualifications you need:**

- **Experience: **3-5 years of strong programmatic execution and the ability to execute complex products efficiently. You will have worked on end to end post sales customer journeys and value realization for a portfolio of customers

- **Broad Industry & Domain expertise:** Understanding of industry-specific business processes and a proven ability to identify opportunities for improvement, with the agility to context-switch and cross-pollinate best practices across industries.

- **AI & Technical Fluency: **High AI fluency, leveraging copilots and intelligent agents to accelerate workflows, craft business cases, and monitor portfolio health and drive high volume of activities.

- **Strong Stakeholder Management**: Able to quickly build trust and inspire action across both technical users and C-level executives.

- **Scaled Engagement: **An experienced 1:N speaker with proven experience hosting high-energy webinars, leading cohort enablement, and driving community engagement. Passionate about empowering both customers and partners through training, support, and strategic insights.

- **Degree:** Engineering, Computer Science, Mathematics, Business Analytics, comparable technical degree or a Business/Economics degree paired with a technical minor

- **Native-level German proficiency is required for this role. Candidates must be able to lead customer workshops, conduct executive presentations, and manage stakeholder interactions in German.**

**What Celonis can offer you:**

- Pioneer Innovation: Work with the global leader in Process Mining and the Process Intelligence Graph to shape the future of AI-driven business operations.

- Ownership from Day 1: Every full-time "Celonaut" is an owner, receiving Restricted Stock Units (RSUs) and merit-based refresh grants.

- Unrivaled Family Support: Benefit from our inclusive parental leave policy—24 weeks of fully paid leave for primary carers and 12 weeks for supporting carers, available from your first day of employment.

- Work-Life Integration: Enjoy Unlimited PTO (in applicable regions) and generous PTO globally, as well as a flexible hybrid work model that balances remote focus with vibrant office collaboration.

- Continuous Growth: Elevate your skills through our 70-20-10 learning framework, mentorship programs, and access to a dedicated learning platform.

- Holistic Well-being: Prioritize your health with subsidized Wellhub memberships, mental health counseling, and dedicated "Wellness Weeks" that prioritize work/life balance.

- Drive Sustainability: Participate in annual Impact Days, where you receive paid time off to volunteer for community and environmental causes with your local office, or virtually.

- Global Inclusion & Belonging: Find community through our Inclusion Think Tank and participate in our annual Inclusion Days, ensuring every voice is heard and valued.

- Value-Driven Impact: Join a mission-led organization where our core values—Live for Customer Value, The Best Team Wins, We Own It, and Earth Is Our Future—drive every decision.

**About Us:**

Celonis is the trusted platform to industrialize Enterprise AI, empowering organizations to analyze, design, and operate AI-driven processes. The Celonis Platform is powered by the Celonis Context Model, which combines process data, business knowledge, and intelligence to create a living digital twin of the enterprise that AI can understand — turning AI’s operational blind spots into operational clarity. Industry-leading companies around the world trust Celonis and its global ecosystem of partners to make their AI agents, people, systems, and processes work together, achieving transformational outcomes. Celonis is headquartered in Munich, Germany, and New York City, USA, with more than 20 offices worldwide.

Get familiar with the Celonis Process Intelligence Platform by watching this [video](https://www.youtube.com/watch?v=YR5oRJGhJYg&list=PLuVor-ZUD4pnM6G33C5D0tjXUvlTPYBRe).

**Celonis Inclusion Statement:**

At Celonis, we believe our people make us who we are and that “The Best Team Wins”. We know that the best teams are made up of people who bring different perspectives to the table. And when everyone feels included, able to speak up and knows their voice is heard - that's when creativity and innovation happen.**
**

**Your Privacy:**

Any information you submit to Celonis as part of your application will be processed in accordance with Celonis’ [Accessibility and Candidate Notices](https://www.celonis.com/careers/candidate-notices)

By submitting this application, you confirm that you agree to the storing and processing of your personal data by Celonis as described in our [Privacy Notice for the Application and Hiring Process](https://www.celonis.com/careers/privacy-notice/).

Please be aware of common job offer scams, impersonators and frauds. Learn more [here](https://www.celonis.com/careers/fraud-alert/).

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
