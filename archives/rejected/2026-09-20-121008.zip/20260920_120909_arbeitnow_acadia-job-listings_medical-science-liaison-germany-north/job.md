# Medical Science Liaison – Germany North

Posted: 2026-09-20T05:55:14Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**About Acadia Pharmaceuticals**

Acadia is committed to turning scientific promise into meaningful innovation that makes the difference for underserved neurological and rare disease communities around the world. Our commercial portfolio includes the first and only FDA-approved treatments for Parkinson’s disease psychosis and Rett syndrome. We are developing the next wave of therapeutic advancements with a robust and diverse pipeline that includes mid- to late-stage programs in Alzheimer’s disease psychosis and Lewy body dementia psychosis, along with earlier-stage programs that address other underserved patient needs. At Acadia, we’re here to be their difference.

**Position Summary:**

The Medical Science Liaison (MSL) for Germany plays a pivotal role in advancing our mission in rare pediatrics diseases, with a core focus on Rett syndrome. This field-based role serves as a trusted scientific partner to healthcare professionals, researchers, advocacy groups, and decision makers across Germany. The MSL drives scientific exchange, supports evidence generation, and helps ensure patients, caregivers, and clinicians have access to high-quality scientific and medical information about Acadia’s therapeutic innovations.

**Scope:**

- **Scientific Engagement & Stakeholder** **Partnership –** Serve as Acadia’s field-based scientific expert, building trusted relationships with healthcare professionals, key opinion leaders, centers of excellence, and patient advocacy organizations across Germany.

- **Medical Strategy & Insight Generation** – Generate actionable field insights, identify unmet needs, and contribute to evidence generation, launch readiness, and lifecycle management initiatives in rare neurological diseases.

- **Scientific Leadership & Medical Education** – Lead scientific exchange and execute high-impact medical activities, including advisory boards, expert meetings, congress engagements, publications, and educational programs.

- **Cross-Functional Collaboration & Execution** – Act as a trusted scientific partner to internal stakeholders, driving aligned, compliant, and patient-focused initiatives in a dynamic and growing organization

**Key Responsibilities:**

- Serve as Acadia’s primary field-based scientific expert and trusted partner for healthcare professionals and key opinion leaders (KOLs)

- Drive launch excellence and lifecycle management by engaging key stakeholders, generating actionable insights, and identifying opportunities to optimize patient care and access

- Build and cultivate strategic relationships with national and regional experts in rare pediatric neurological diseases, creating and fostering long-term scientific partnerships and collaboration opportunities

- Lead scientific exchange on Acadia’s marketed products and pipeline assets, delivering fair, balanced, and compliant medical information to external stakeholder

- Identify, initiate, and drive impactful medical collaborations, including investigator-initiated studies (IIS), publications, educational initiatives, and speaker development programs.

- Plan, lead, and execute scientific advisory boards, expert meetings, symposia, and educational programs, ensuring meaningful scientific exchange and stakeholder engagement

- Represent Acadia at national and international congresses and scientific meetings, proactively identifying scientific trends, emerging data, and partnership opportunities, and communicating insights to internal stakeholders

- Gather, analyze, and communicate actionable field insights on clinical practice, unmet needs, emerging evidence, competitor activities, and stakeholder perspectives to inform medical strategy and evidence generation.

- Partner with Medical Affairs leadership and patient advocacy organizations to advance disease awareness, education, and patient-centered initiatives across Germany.

- Provide timely, accurate, and compliant responses to unsolicited medical information requests.

- Deliver impactful medical training and ongoing scientific support to cross-functional teams, strengthening disease knowledge, clinical understanding, and strategic execution

- Collaborate closely with Commercial, Market Access, Regulatory Affairs, Pharmacovigilance, Clinical Development, and international Medical Affairs teams to drive aligned and compliant execution of strategic objectives, demonstrating ownership, adaptability, and a proactive, hands-on approach within a dynamic and growing organization

- Maintain deep expertise in the rare disease and neuroscience landscape, continuously monitoring treatment paradigms, clinical guidelines, emerging therapies, and stakeholder needs while maintaining the highest standards of medica governance.

**Education / Experience / Skills**.

- A advanced scientific or medical degree or a related field is required; The ideal candidate will have 2-4 years of relevant industry experience, including 1-2 years field-based MSL roles in CNS/neuroscience or rare disease.

- Proven ability to present complex scientific data clearly and effectively.

- Highly organized, self-motivated, and quick to learn, with the ability to work independently and manage competing priorities effectively.

- Collaborative, adaptable, and entrepreneurial, embracing diverse perspectives and thriving in cross-cultural teams and a fast-growing organization

- Readiness to travel up to 70%. Travel commitments will include participation at international Medical Affairs meetings, team meetings, and attendance at both national and international congresses.

#LI-REMOTE #NC1

In addition to a competitive base salary, this position is also eligible for discretionary bonus and equity awards based on factors such as individual and organizational performance. Actual amounts will vary depending on experience, performance, and location.

Salary Range

€83.000—€103.300 EUR

**What we offer US-based Employees:**

- Competitive base, bonus, new hire and ongoing equity packages

- Medical, dental, and vision insurance

- Employer-paid life, disability, business travel and EAP coverage

- 401(k) Plan with a fully vested company match 1:1 up to 5%

- Employee Stock Purchase Plan with a 2-year purchase price lock-in

- 15+ vacation days

- 13 -15 paid holidays, including office closure between December 24th and January 1st

- 10 days of paid sick time

- Paid parental leave benefit

- Tuition assistance

**EEO Statement (US-based Employees): **Studies have shown that women and people of color are less likely to apply for jobs unless they believe they meet every one of the qualifications in the exact way they are described in job postings. We are committed to building a diverse, equitable, inclusive, and innovative company, and we are looking for the BEST candidate for the job. That candidate may be one who comes from a less traditional background or may meet the qualifications in a different way. We strongly encourage you to apply, especially if the reason you are the best candidate isn’t exactly what we describe here.

It is the policy of Acadia to provide equal employment opportunities to all employees and employment applicants without regard to considerations of race, including related to hairstyle, color, religion or religious creed, sexual orientation, gender, gender identity, gender expression, gender transition, country of origin, ancestry, citizenship, age, physical or mental disability, genetic information, legally-protected medical condition or information, marital status, domestic partner status, family care status, military caregiver status, veteran or military status (including reserve status, National Guard status, and military service or obligation), status as a victim of domestic violence, sexual assault or stalking, enrollment in a public assistance program, or any basis protected under federal, state or local law.

As an equal opportunity employer, Acadia is committed to a diverse workforce. If you are a qualified individual with a disability or a disabled veteran, you have the right to request a reasonable accommodation. Furthermore, you may request additional support if you are unable or limited in your ability to use or access Acadia’s career website due to your disability, along with any accommodations throughout the interview process. To request or inquire about your reasonable accommodation, please complete our [Reasonable Accommodation Request Form](https://app.smartsheet.com/b/form/43db301ada19415fa7ab365633993f33) or contact us at Please note that reasonable accommodations granted throughout the recruiting process are not guaranteed to be the same accommodations given if hired. A new request will need to be submitted for any ADA accommodations after starting employment.

**California Applicants: **Please see [Additional Information for California Residents](https://acadia.com/en-us/legal-policies/privacy#18) within our Privacy Policy.

**Canadian Applicants: **Please see [Additional Information for Canadian Residents](https://acadia.com/en-gb/legal-policies/privacy#17) within our Privacy Policy.

**Applicants in the European Economic Area, Switzerland, the United Kingdom, and Serbia: **Please see [Additional Information for Individuals in the European Economic Area, Switzerland, the United Kingdom, and Serbia](https://acadia.com/en-gb/legal-policies/privacy#16) within our Privacy Policy.

**Notice to Search Firms/Third-Party Recruitment Agencies (Recruiters): **The Talent Acquisition team manages the recruitment and employment process for Acadia Pharmaceuticals Inc. (“Acadia”). Acadia does not accept resumes from recruiters or search firms without an executed search agreement in place. Resumes sent to Acadia employees in the absence of an executed search agreement will not obligate Acadia in any way with respect to the future employment of those individuals or potential remuneration to any recruiter or search firm. Candidates should never be submitted directly to our hiring managers or employees.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
