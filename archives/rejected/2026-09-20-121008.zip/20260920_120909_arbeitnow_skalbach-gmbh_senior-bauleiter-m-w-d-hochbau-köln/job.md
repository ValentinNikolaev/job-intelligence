# Senior Bauleiter (m/w/d) Hochbau - Köln

Posted: 2026-09-20T08:09:04Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**Firmenprofil**

Unser Mandant ist ein erfolgreiches und renommiertes Bauunternehmen mit langjähriger Erfahrung in der Realisierung anspruchsvoller Hochbauprojekte. Das Unternehmen steht für Qualität, Innovationskraft und eine partnerschaftliche Zusammenarbeit auf allen Ebenen. Dank einer hervorragenden Auftragslage und einer nachhaltigen Unternehmensstrategie werden spannende Projekte im Wohnungs-, Gewerbe- und Bürobau erfolgreich umgesetzt. Zur weiteren Verstärkung des Teams suchen wir einen Senior Bauleiter Hochbau (m/w/d), der Verantwortung übernimmt und Projekte mit Leidenschaft zum Erfolg führt.

**Ihre Aufgaben**

- Eigenverantwortliche Leitung und Steuerung anspruchsvoller Hochbauprojekte von der Baustelleneinrichtung bis zur Übergabe
- Führung und Koordination von Bauleitern, Polieren, Nachunternehmern und weiteren Projektbeteiligten
- Sicherstellung der Einhaltung von Termin-, Kosten- und Qualitätsvorgaben
- Durchführung von Baubesprechungen sowie Abstimmung mit Bauherren, Planern und Fachingenieuren
- Verantwortung für Nachtragsmanagement, Baustellendokumentation und wirtschaftliche Projektsteuerung

**Ihr Profil**

- Abgeschlossenes Studium im Bauingenieurwesen, in der Architektur oder eine vergleichbare Qualifikation
- Mehrjährige Berufserfahrung in der Bauleitung von Hochbauprojekten
- Fundierte Kenntnisse in der Projektabwicklung sowie im Vertrags- und Baurecht (VOB)
- Ausgeprägte Führungs- und Kommunikationsstärke
- Strukturierte, eigenverantwortliche und lösungsorientierte Arbeitsweise

**Benefits**

- Unbefristete Festanstellung in einem wirtschaftlich starken und zukunftssicheren Unternehmen
- Attraktive Vergütung mit zusätzlichen Benefits und Entwicklungsperspektiven
- Firmenwagen, auch zur privaten Nutzung
- Anspruchsvolle und abwechslungsreiche Hochbauprojekte mit hoher Eigenverantwortung
- Moderne Arbeitsmittel und digitalisierte Prozesse
- Individuelle Weiterbildungs- und Karrieremöglichkeiten

**Kontakt**

Sie möchten den nächsten Schritt in Ihrer Karriere gehen und anspruchsvolle Hochbauprojekte aktiv mitgestalten? Dann freuen wir uns auf Ihre aussagekräftige Bewerbung unter Angabe Ihres frühestmöglichen Eintrittstermins. Nach Eingang Ihrer Unterlagen melden wir uns zeitnah bei Ihnen und informieren Sie transparent über die weiteren Schritte im Bewerbungsprozess.

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
