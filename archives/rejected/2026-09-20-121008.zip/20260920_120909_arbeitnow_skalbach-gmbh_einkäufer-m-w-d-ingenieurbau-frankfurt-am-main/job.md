# Einkäufer (m/w/d) Ingenieurbau – Frankfurt am Main

Posted: 2026-09-20T08:09:04Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**Firmenprofil**

Unser Mandant ist ein sehr erfolgreiches und wirtschaftlich stabiles Bauunternehmen mit Schwerpunkt im anspruchsvollen Ingenieurbau. Besonders im Bereich Brückenbau realisiert das Unternehmen technisch komplexe und infrastrukturell bedeutende Projekte in ganz Deutschland. Das Unternehmen zeichnet sich durch eine moderne Organisation, kurze Entscheidungswege und eine langfristig gesicherte Auftragslage aus. Zur Verstärkung des Teams wird ein Einkäufer (m/w/d) für den Ingenieurbau mit Fokus auf den Brückenbau gesucht, der den Einkauf strategisch und operativ mitgestaltet.

**Ihre Aufgaben**

- Eigenverantwortliche Durchführung des Einkaufs für Ingenieurbau- und Brückenbauprojekte
- Einholung, Prüfung und Bewertung von Angeboten sowie Durchführung von Preis- und Vertragsverhandlungen
- Auswahl und Betreuung von Nachunternehmern sowie Lieferanten im Bauumfeld
- Enge Zusammenarbeit mit Bauleitung, Projektleitung und Kalkulation während der Projektabwicklung
- Entwicklung und Umsetzung von Einkaufsstrategien zur Optimierung von Kosten und Prozessen

**Ihr Profil**

- Abgeschlossenes Studium im Bauingenieurwesen, Wirtschaftsingenieurwesen oder eine vergleichbare Qualifikation
- Erfahrung im Einkauf, in der Bauleitung oder Kalkulation im Bauwesen von Vorteil
- Idealerweise Kenntnisse im Ingenieurbau oder Brückenbau
- Verhandlungsgeschick, analytisches Denken und wirtschaftliches Verständnis
- Strukturierte, selbstständige und teamorientierte Arbeitsweise

**Benefits**

- Unbefristete Festanstellung in einem wirtschaftlich starken und erfolgreichen Bauunternehmen
- Spannende und technisch anspruchsvolle Projekte im Brücken- und Ingenieurbau
- Attraktive Vergütung mit zusätzlichen Sonderleistungen
- Firmenwagen, auch zur privaten Nutzung möglich
- Individuelle Weiterbildungs- und Entwicklungsmöglichkeiten
- Langfristige Perspektive in einem zukunftssicheren Unternehmen

**Kontakt**

Haben wir Ihr Interesse geweckt und möchten Sie Ihre Erfahrung im Einkauf im Bereich Ingenieurbau weiter ausbauen? Dann freuen wir uns auf Ihre aussagekräftige Bewerbung unter Angabe Ihres frühestmöglichen Eintrittstermins. Nach Eingang Ihrer Unterlagen melden wir uns zeitnah bei Ihnen und informieren Sie über die nächsten Schritte im Bewerbungsprozess.

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
