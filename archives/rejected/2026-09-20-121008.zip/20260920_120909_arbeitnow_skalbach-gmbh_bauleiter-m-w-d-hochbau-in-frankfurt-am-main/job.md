# Bauleiter (m/w/d) Hochbau in Frankfurt am Main

Posted: 2026-09-20T08:09:04Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**Firmenprofil**

Unser Mandant ist ein erfolgreiches und wirtschaftlich stark aufgestelltes Bauunternehmen mit langjähriger Erfahrung in der Realisierung anspruchsvoller Bauprojekte. Ein besonderer Schwerpunkt liegt auf der Modernisierung, Revitalisierung und dem Ausbau von Bestandsimmobilien im gewerblichen und öffentlichen Umfeld. Das Unternehmen überzeugt durch hohe Qualitätsstandards, moderne Arbeitsweisen und eine partnerschaftliche Zusammenarbeit mit Kunden und Projektbeteiligten. Zur Verstärkung des Teams wird ein Bauleiter (m/w/d) gesucht, der Umbau- und Ausbaumaßnahmen eigenverantwortlich steuert und erfolgreich umsetzt.

**Ihre Aufgaben**

- Eigenverantwortliche Leitung und Koordination von Projekten in Bestandsimmobilien
- Steuerung und Überwachung der Nachunternehmer sowie aller am Projekt beteiligten Gewerke
- Sicherstellung der termin-, qualitäts- und kostengerechten Projektabwicklung
- Abstimmung mit Auftraggebern, Planern, Mietern und weiteren Projektbeteiligten
- Durchführung von Baustellenbegehungen, Abnahmen sowie Nachtrags- und Mängelmanagement

**Ihr Profil**

- Abgeschlossenes Studium im Bauingenieurwesen, in der Architektur oder eine vergleichbare technische Qualifikation
- Mehrjährige Berufserfahrung in der Bauleitung, idealerweise im Bereich Umbau, Ausbau oder Bauen im Bestand
- Gute Kenntnisse der VOB sowie der relevanten Bauabläufe
- Organisationsgeschick, Durchsetzungsvermögen und wirtschaftliches Denken
- Selbstständige, strukturierte und lösungsorientierte Arbeitsweise

**Benefits**

- Unbefristete Festanstellung in einem erfolgreichen und zukunftssicheren Unternehmen
- Spannende Projekte im Bereich Bauen im Bestand mit hoher Eigenverantwortung
- Attraktive Vergütung sowie zusätzliche finanzielle Benefits
- Firmenfahrzeug auch zur privaten Nutzung
- Moderne Arbeitsmittel und digitalisierte Prozesse
- Individuelle Weiterbildungs- und Entwicklungsmöglichkeiten

**Kontakt**

Haben wir Ihr Interesse geweckt? Dann freuen wir uns auf Ihre aussagekräftige Bewerbung unter Angabe Ihres frühestmöglichen Eintrittstermins. Nach Eingang Ihrer Unterlagen setzen wir uns zeitnah mit Ihnen in Verbindung und informieren Sie über die weiteren Schritte im Bewerbungsprozess.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
