# Praktikant:in Policy & Regulatory Affairs (m/w/d)

Posted: 2026-09-20T08:09:31Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**1KOMMA5°**

Bei **1KOMMA5°** verfolgen wir eine Vision: **Living on wind and sunlight forever for free**. Dafür bauen wir mit Heartbeat AI das Energiesystem der Zukunft. Bist du dabei?
Wir bringen regionales Handwerk und skalierbare Software zusammen: Solar, Speicher, Wärmepumpe und E-Mobilität denken wir nicht einzeln, sondern steuern sie als intelligentes, integriertes Gesamtsystem in unserem virtuellen Kraftwerk. Direkt verbunden mit dem Strommarkt – in Echtzeit, vollautomatisiert. So wird Energie dann genutzt, wenn sie erneuerbar verfügbar und besonders günstig ist. Bis 2030 wollen wir 1,5 Millionen Haushalte auf erneuerbare Energien umstellen. Über 3.000 Menschen arbeiten jeden Tag daran, an mehr als 80 Standorten weltweit, von Finnland bis Australien.

**Du willst Verantwortung übernehmen und Lösungen bauen, die wirklich zählen? Bewirb dich jetzt und gestalte mit uns die Energiewelt von morgen.**

**Deine Position**

- Du verfolgst laufende Gesetzgebungsverfahren auf Bundes- und EU-Ebene und analysierst, was sie für unser Produkt und unsere Kund:innen bedeuten
- Du übernimmst eigenständig das Monitoring einzelner Dossiers und hältst das Team auf aktuellem Stand
- ⁠Du recherchierst und schreibst an Positionspapieren und Stellungnahmen mit – von der Prüfung des Gesetzestextes bis zur fertigen Formulierung
- Du bereitest Gespräche mit Abgeordneten, Ministerien und Verbänden vor, bist bei Terminen dabei und dokumentierst sie
- Du unterstützt unsere Bündnisarbeit mit anderen Unternehmen der Branche
- Du baust unsere Stakeholder-Datenbank aus und entwickelst unsere Monitoring-Tools weiter

**Dein Profil**

- Du absolvierst im Rahmen deines Masterstudiums ein Pflicht- oder freiwilliges Praktikum von mindestens sechs Monaten in Vollzeit oder möchtest nach Abschluss deines Studiums ein Praktikum absolvieren.
- Du hast erste Erfahrung in der politischen Interessenvertretung gesammelt und weißt, wie ein Gesetzgebungsverfahren abläuft
- Du hast Lust, dich in komplexe Gesetzestexte und Regulierung einzuarbeiten – und interessierst dich dabei auch für die technische und wirtschaftliche Seite der Energiewende, nicht nur für die politische
- Du arbeitest strukturiert, zuverlässig und eigenständig. Bei Recherche und Quellenarbeit prüfst du, woher eine Zahl kommt, bevor sie in einem Positionspapier landet
- Du schreibst klar und gerne auf Deutsch und arbeitest dich problemlos durch englische EU-Dokumente.
- Du hast Spaß daran, mit Tools und Automatisierungen zu arbeiten, statt Dinge dreimal manuell zu machen
- Selbstsicheres und verhandlungssicheres Auftreten auf Deutsch und Englisch; verhandlungssichere Sprachkenntnisse in Niederländisch, Spanisch oder Schwedisch sind ein Plus

**Benefits**

- Du hast die Möglichkeit in unserem **brandneuen** Büro in **Berlin** zu arbeiten und auch **remote**
- Nutze dein **technisches Equipment **auch abseits der Arbeit in deiner **Freizeit**
- Du bist Teil eines **schnell wachsenden Unternehmens** mit viel **Entwicklungspotenzi****al**, wo du **eigenständig** etwas aufbauen kannst und deinen Impact spürst
- Bewege dich in **flachen Hierarchien**, übernimm schon während deiner Einarbeitung **Verantwortung** und arbeite direkt mit Teilen des Managements zusammen
- Mit deiner Arbeit unterstützt du den Megatrend **“Energie- und Mobilitätswende”** und leistest einen **konkreten Beitrag** zum **nachhaltigen** Umbau unserer Energie-Infrastruktur
- Sei aktiv und nutze das Angebot von über 7.600 Sportpartnern mit dem **EGYM-Wellpass****
**
- Profitiere von **Benefits & Rabatten** durch Futurebens

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
