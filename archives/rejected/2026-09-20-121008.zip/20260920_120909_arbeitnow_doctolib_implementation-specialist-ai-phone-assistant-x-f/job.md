# Implementation Specialist -AI Phone Assistant (x/f/m)

Posted: 2026-09-20T05:55:11Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Als **Implementation Specialist- AI Phone Assistant** begleitest Du Arztpraxen und Krankenhäuser bei der technischen Einführung unseres KI-basierten Telefonassistenten. Du richtest die Lösung ein, begleitest Datenmigrationen und sorgst dafür, dass unsere Kund:innen den Telefonassistenten zuverlässig im Praxisalltag einsetzen können. Nach Deinen ersten sechs Monaten hast Du eigenständig Onboardings umgesetzt, technische Herausforderungen gelöst und dazu beigetragen, unsere Prozesse weiter zu verbessern.

##

## Deine Aufgaben

- Du planst und begleitest die technische Implementierung unseres KI-basierten Telefonassistenten bei Arztpraxen und Krankenhäusern.

- Du prüfst technische Voraussetzungen, konfigurierst die Lösung und stellst die erfolgreiche Inbetriebnahme sicher.

- Du koordinierst Datenmigrationen aus externen Praxisverwaltungssystemen und prüfst die Qualität und Vollständigkeit der übertragenen Daten.

- Du führst technische Gespräche mit Praxen, IT-Ansprechpersonen und internen Teams und erklärst komplexe Sachverhalte verständlich.

- Du dokumentierst technische Lösungen, entwickelst Trainingsmaterialien und automatisierst wiederkehrende Aufgaben.

## Dein Profil

Du bist der festen Überzeugung, dass Du genau das mitbringst, was es für die Position braucht? Dann ermutigen wir Dich, Dich zu bewerben. Selbst wenn Du nicht jede Anforderung erfüllst, bist Du vielleicht genau die oder der richtige zukünftige Doctoliber:in für diese oder andere Stellen!

### Um Teil unseres Teams zu werden, bringst Du Folgendes mit:

- Du hast erste Erfahrung im technischen Onboarding, in der technischen Implementierung, im IT-Support, Technical Customer Success oder in einer vergleichbaren Rolle.

- Du verfügst über ein gutes Verständnis von APIs, IT-Infrastrukturen, Netzwerken und VPNs.

- Du arbeitest sicher mit Daten, beispielsweise in Excel, SQL oder vergleichbaren Tools.

- Du kommunizierst sehr gut auf Deutsch auf mindestens C1-Niveau und auf Englisch auf mindestens B2-Niveau.

- Du analysierst technische Probleme strukturiert und entwickelst eigenständig pragmatische Lösungen.

### Besonders interessant sind für uns außerdem:

- Programmiererfahrung mit JavaScript und/oder Python.

- Erfahrung mit SQL-Datenbanken.

- Kenntnisse in Praxisverwaltungssystemen, Krankenhausinformationssystemen oder EHR-Systemen.

- Erfahrung mit SaaS-Lösungen, technischen Implementierungen oder KI-Tools.

- Erfahrung in der Erstellung von Trainingsmaterialien oder in der Prozessautomatisierung.

## **Was wir Dir bieten**

- Ein von Doctolib gesponsertes Deutschlandticket, wenn Du aus dem Büro oder im Hybridmodus arbeitest

- 28 Urlaubstage + 1 Tag zusätzlich für jedes volle Beschäftigungs-Kalenderjahr (max. 30 Tage)

- Die Möglichkeit, 10 Tage im Jahr aus dem Ausland zu arbeiten

- Eine betriebliche Krankenzusatzversicherung mit individuellen Zusatzleistungen (u.a. Zahnreinigung u.v.m.)

- Eine betriebliche Altersvorsorge (bAV) mit einem Arbeitgeberzuschuss von 40 % (15 % während der Probezeit)

- Teilnahme an Doctolibs langfristigem Mitarbeiterbeteiligungsprogramm DoctoGrowth

- Das Doctolib Parent Care Programm, das extra Elternzeit (1 Monat) u.v.m. enthält

- Kostenlose Mental Health- und Coaching-Sessions über einen externen Partner

- Zusätzlich zu gesunden Snacks und einem regelmäßigen Frühstücksbuffet, bieten wir Essensgutscheine

- Ein gefördertes Sportangebot mit unserem Partner Urban Sports Club

- Für pflegende Betreuungspersonen und Beschäftigte mit Behinderungen gibt es ein Angebot, das flexiblere Arbeitszeiten, zusätzliche Freistellung aus medizinischen Gründen und psychologische Unterstützung beinhaltet

- Teilnahme an Doctolibs langfristigem Mitarbeiterbeteiligungsprogramm DoctoGrowth

## **Der Interviewprozess**

- Interview mit dem Talent-Team

- Interview inkl. Livecase mit den Hiring Manager:innen

- Mindestens eine Referenzprüfung

## **Job Details**

- Festanstellung

- Vollzeit

- Berlin

- Hybride Arbeitsweise (3 Tage Office/Woche)

- Ab sofort

*Wir verfolgen die Vision, die Gesundheit aller zu verbessern. Dies spiegelt sich auch im Recruiting wider. Wir evaluieren Bewerbungen ausschließlich auf der Grundlage von Qualifikation und Motivation. Diskriminierung wird bei uns nicht toleriert.*

*Je diverser unser Team und die Ideen sind, desto mehr wird unser Produkt die Gesundheit unserer Nutzer:innen verbessern können. Deshalb laden wir Dich ein, Dich bei uns zu bewerben, unabhängig von Geschlecht, Religion, Alter, sexueller Orientierung, ethnischer Herkunft oder Behinderung.*

*Um Chancengleichheit zu gewährleisten, kannst Du in Deiner Bewerbung auf Angaben wie Fotos, Alter, etc. verzichten. Lass uns bitte wissen, welche Vorkehrungen wir treffen können, um Dich bestmöglich zu unterstützen. Wir freuen uns, mit Dir das Gesundheitswesen zu digitalisieren!*

*Alle bereitgestellten Informationen werden von Doctolib für das Bewerbungsmanagement verarbeitet. Für Details zur Datenverarbeitung klicke bitte [hier](https://doctolib.legal/B2C-Privacy-Policy-Career-DE).*

*Bei Fragen oder wenn Du Deine Rechte wahrnehmen möchtest, wende Dich bitte an hr.dataprivacy(at)doctolib.com.*

###

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
