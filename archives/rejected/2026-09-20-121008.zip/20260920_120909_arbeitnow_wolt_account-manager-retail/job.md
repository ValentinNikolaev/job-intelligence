# Account Manager Retail

Posted: 2026-09-20T08:55:27Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

## About Wolt

At Wolt, we create technology that brings joy, simplicity and earnings to the neighborhoods of the world. In 2014 we started with delivery of restaurant food. Now we’re building the delivery of (almost) everything and you’ll find us in over 500 cities in 30 countries around the world. In 2022 we joined forces with DoorDash and together we keep on dreaming big and expanding across the globe.

Working at Wolt isn’t always easy, but it’s definitely exciting. Here you’ll learn more, build more, and ship more than in most other companies. You’ll be challenged a lot, but also have a lot of fun on the way. So, if you’re a self-starter with drive and entrepreneurial spirit, this could be the ride of your life.

At Wolt, you can grow your sales career with a fun and fast-scaling global business. Part of the DoorDash team, we’re building a global logistics platform that can deliver (almost) everything in your city, to your door in minutes. Today, our products are used by 55+ million registered users who can now order from 200,000+ restaurants and retail stores across 30+ countries around the world.

Our Sales teams create and build our relationships with merchants. Together, we’ve helped big brands, local stores and neighborhood restaurants do over €15 billion’s worth of business through our platform. We’re constantly launching new cities and products, so there are always new opportunities to expand your skills and progress your career.

As our new Account Manager you’ll manage and develop a portfolio of retail partners, focusing on building strong relationships, using data to drive performance, and delivering results for Wolt, our partners, and our customers.

## What you’ll be doing

### **Day-to-day in this role you’ll:**

- Develop and foster partner relationships with your portfolio of key accounts

- Conduct quarterly business reviews with partners to deepen relationships, review performance, and develop forward-looking strategies

- Determine the needs and wants of merchants, prioritize them by impact on the business, and co-create solutions

- Strategically introduce and execute on new Wolt product opportunities to broaden partnerships and increase partner revenue streams

- Drive revenue growth of Wolt and partners in your portfolio by improving venue performance through a data-based approach

- Act as a key communicator between our operations, support, marketing, and partners

- Work closely with the marketing team to plan and execute promotional campaigns that increase user acquisition and retention, drive our growth, and support partner performance

- Bring structure and hands-on contribution in a still-developing environment

## Our humble expectations

- 3 to 5 years of success in account management or B2B sales with clear commercial impact.

- Strong relationship builder with excellent interpersonal skills

- Analytical mindset with experience using tools like Looker

- High ownership and a team-first attitude. You manage your pipeline and seek guidance only on new or more complex work.

- Fluent in **German** and English

- CRM and sales experience are a plus

## Why you’ll love it

- **🚀Global and growing fast: **Be part of a fast-moving scaleup

- **🤩Ride of a lifetime: **Accelerate your career and build your sales skills

- **💪Instant impact: **Take ownership and make a difference

- **💙Big hearts and small egos: **Surround yourself with smart, friendly people

## Next steps

If you are excited about working in a high-growth environment, taking ownership, and being part of an extremely ambitious team, then click below to apply, make sure to add your CV and get the conversation going!

We will be reviewing applications on an on-going basis. If this sounds like an opportunity you want to pursue, apply today! 💙

## Our Commitment to Diversity and Inclusion

We’re committed to growing and empowering a more inclusive community within our company, industry, and cities. That’s why we hire and cultivate diverse teams of people from all backgrounds, experiences, and perspectives. We believe that true innovation happens when everyone has room at the table and the tools, resources, and opportunity to excel.

*Beware of recruitment scams: DASH Brands will never ask you to pay money or share sensitive financial information during hiring — learn more about DASH Brands' legitimate recruiting process at* [*careersatdoordash.com/recruitment-scam-awareness*](http://careersatdoordash.com/recruitment-scam-awareness)*.*

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
