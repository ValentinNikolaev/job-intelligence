# Senior Medical Content Manager (x/f/m)

Posted: 2026-09-20T05:55:11Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

## Werde Teil unserer Mission, werde Teil von Doctolib!

Wir suchen Dich **als Senior Medical Content Manager (x/f/m) **als Unterstützung für das Patient Content Factory Team in Berlin.

Doctolib ist Europas führender Health Companion und begleitet Millionen von Patient:innen und Gesundheitsfachkräften auf dem gesamten Kontinent. Wir transformieren die Gesundheitsversorgung, indem wir unsere Plattform mit innovativen Lösungen rund um Prävention und Patient:innen-Empowerment bereichern.

Unser nächster Schritt: Doctolib zur vertrauenswürdigsten Gesundheitskontent-Destination in Europa zu machen. Dafür haben wir das Patient Content Factory Team ins Leben gerufen — ein dediziertes Team, das für alle Inhalte innerhalb der Doctolib-App verantwortlich ist. Dies umfasst Präventionskampagnen sowie personalisierte Gesundheitsinformationen (Artikel, Videos, interaktive Inhalte), die auf verifizierten medizinischen Kenntnissen basieren.

Du verantwortlich für das Verfassen und die Verwaltung von Inhalten für den Health Companion der App — und stellst dabei höchste Qualitätsstandards sicher. Du koordinierst funktionsübergreifende Stakeholder, sorgst für End-to-End-Qualität an allen Touchpoints und steuerst die gesamte Content-Produktion.

## **Deine Aufgaben**

- Du hilfst beim Aufbau und der Pflege des Redaktionskalenders für alle deutschen Gesundheitsinhalte und identifizierst Content-Möglichkeiten basierend auf Patient:innen-Bedürfnissen und öffentlichen Gesundheitsprioritäten

- Du schreibst und erstellst verständliche medizinische Inhalte für Patient:innen und übersetzt komplexe medizinische Informationen in klare, handlungsorientierte Artikel für das deutsche Publikum

- Du managst den gesamten Content-Workflow von der Idee bis zur Veröffentlichung und koordinierst interne sowie externe Content-Writer:innen für eine termingerechte Umsetzung

- Du verwaltest Inhalte und Redaktionskalender über ein CMS und treibst die Optimierung von Content-Prozessen durch Automatisierung und KI voran

- Du sorgst dafür, dass alle Inhalte höchste Standards in Bezug auf Genauigkeit, Klarheit und Healthcare-Compliance erfüllen, und koordinierst strenge Review-Prozesse mit medizinischen Gutachter:innen und Expert:innen

- Du trägst zum Aufbau eines Netzwerks aus glaubwürdigen Partner:innen (Institutionen, Expert:innen, medizinische Fachgesellschaften) bei, um die Autorität von Doctolibs Gesundheitsinhalten zu stärken

## **Dein Profil**

*Du bist der festen Überzeugung, dass Du genau das mitbringst, was es für die Position braucht? Dann ermutigen wir Dich, Dich zu bewerben. Selbst wenn Du nicht jede Anforderung erfüllst, bist Du vielleicht genau die/der richtige zukünftige Doctoliber:in für diese oder andere Stellen!*

### **Um Teil unseres Teams zu werden, bringst Du Folgendes mit:**

- Abschluss in Kommunikation, Journalismus oder Lebenswissenschaften (Biomedizin, Public Health o.ä.)

- Mindestens 4 Jahre nachgewiesene Erfahrung im Bereich Medical Content Writing, Gesundheitskommunikation oder verwandten Feldern

- Erfahrung im Management digitaler Kampagnen und in der Arbeit mit CMS-Systemen

- Starker Projektmanagement-Hintergrund mit der Fähigkeit, mehrere Stakeholder zu koordinieren

- Herausragende schriftliche Kommunikationsfähigkeiten auf Deutsch sowie sehr gute Englischkenntnisse

### **Besonders interessant sind für uns außerdem:**

- Neugier und Interesse an multiformat-Storytelling (Video, interaktive Inhalte) — praktische Erfahrung ist ein Plus, aber kein Muss

- Ausgeprägte analytische Fähigkeiten und Erfahrung mit Performance-Measurement-Tools

- Starke zwischenmenschliche Fähigkeiten und die Fähigkeit, in einem dynamischen, funktionsübergreifenden Umfeld zu navigieren

## **Was wir Dir bieten**

- Ein von Doctolib gesponsertes Deutschlandticket, wenn Du aus dem Büro oder im Hybridmodus arbeitest

- 28 Urlaubstage + 1 Tag zusätzlich für jedes volle Beschäftigungs-Kalenderjahr (max. 30 Tage)

- Die Möglichkeit, 10 Tage im Jahr aus dem Ausland zu arbeiten

- Eine betriebliche Krankenzusatzversicherung mit individuellen Zusatzleistungen (u.a. Zahnreinigung u.v.m.)

- Eine betriebliche Altersvorsorge (bAV) mit einem Arbeitgeberzuschuss von 40 % (15 % während der Probezeit)

- Teilnahme an Doctolibs langfristigem Mitarbeiterbeteiligungsprogramm DoctoGrowth

- Das Doctolib Parent Care Programm, das extra Elternzeit (1 Monat) u.v.m. enthält

- Kostenlose Mental Health- und Coaching-Sessions über einen externen Partner

- Zusätzlich zu gesunden Snacks und einem regelmäßigen Frühstücksbuffet, bieten wir Essensgutscheine

- Ein gefördertes Sportangebot mit unserem Partner Urban Sports Club

- Für pflegende Betreuungspersonen und Beschäftigte mit Behinderungen gibt es ein Angebot, das flexiblere Arbeitszeiten, zusätzliche Freistellung aus medizinischen Gründen und psychologische Unterstützung beinhaltet

## **Der Interviewprozess**

- Interview mit dem Talent Team (auf Englisch)

- Interview mit der Hiring Managerin (auf Deutsch)

- Case Study (auf Deutsch)

- Abschlussgespräch

- Referenzprüfung oder Arbeitszeugnis

- Angebot

## **Job Details**

- Festanstellung

- Vollzeit

- Standort: Berlin

- Hybride Arbeitsweise (3 Tage Office/Woche)

- Startdatum: Zum nächstmöglichen Zeitpunkt

*Wir verfolgen die Vision, die Gesundheit aller zu verbessern. Dies spiegelt sich auch im Recruiting wider. Wir evaluieren Bewerbungen ausschließlich auf der Grundlage von Qualifikation und Motivation. Diskriminierung wird bei uns nicht toleriert.*

*Je diverser unser Team und die Ideen sind, desto mehr wird unser Produkt die Gesundheit unserer Nutzer:innen verbessern können. Deshalb laden wir Dich ein, Dich bei uns zu bewerben, unabhängig von Geschlecht, Religion, Alter, sexueller Orientierung, ethnischer Herkunft oder Behinderung.*

*Um Chancengleichheit zu gewährleisten, kannst Du in Deiner Bewerbung auf Angaben wie Fotos, Alter, etc. verzichten. Lass uns bitte wissen, welche Vorkehrungen wir treffen können, um Dich bestmöglich zu unterstützen. Wir freuen uns, mit Dir das Gesundheitswesen zu digitalisieren!*

*Alle bereitgestellten Informationen werden von Doctolib für das Bewerbungsmanagement verarbeitet. Für Details zur Datenverarbeitung klicke bitte*[* **hier*](https://doctolib.legal/B2C-Privacy-Policy-Career-DE)*.*

*Bei Fragen oder wenn Du Deine Rechte wahrnehmen möchtest, wende Dich bitte an hr.dataprivacy(at)doctolib.com.*

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
