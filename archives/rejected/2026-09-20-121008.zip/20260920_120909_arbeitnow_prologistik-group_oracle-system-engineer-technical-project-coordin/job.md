# Oracle System Engineer & Technical Project Coordinator (m/w/d)

Posted: 2026-09-20T08:09:50Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**Es freut uns, dass du da bist!**

Du liebst es, anspruchsvolle IT-Umgebungen zu analysieren, zu betreiben und weiterzuentwickeln? Als **Oracle System Engineer & Technical Project Coordinator (m/w/d)** stellst du den reibungslosen Betrieb unserer Systeme sicher, arbeitest an Virtualisierung, Cloud-, Netzwerk- und Storage-Lösungen und unterstützt unsere Kunden und Teams mit deinem technischen Know-how.

Wir, die proLogistik Group, sind Marktführer für Systemlösungen in der Supply Chain. Mit rund 800 erfahrenen Mitarbeitenden entwickeln wir innovative Soft- und Hardware-Lösungen für die Logistik. Mit Leidenschaft arbeiten wir in einem starken Miteinander und einer Zusammenarbeit auf Augenhöhe neue Ideen aus. Um dein Potenzial bestmöglich zu fördern, legen wir großen Wert auf selbstbestimmtes Arbeiten und bieten dir vielfältige Entwicklungsmöglichkeiten, weil wir deinen täglichen Einsatz und Beitrag zu unserem Erfolg schätzen.

Wachse mit uns als

**Oracle System Engineer & Technical Project Coordinator (m/w/d) **

**Deine Aufgaben bei uns**

- Du übernimmst die technische Projektkoordination und sorgst als Schnittstelle zwischen Entwicklung, Projektleitung und weiteren Fachbereichen für einen reibungslosen Informationsfluss.
- Du bist technischer Ansprechpartner für unsere Kunden und externen Dienstleister und begleitest Projekte zuverlässig von der Abstimmung bis zur Umsetzung.
- Du unterstützt bei der Kalkulation und Erstellung technischer Angebote und bringst dein Know-how in die Bewertung von Aufwänden und Lösungsansätzen ein.
- Du verantwortest die Installation, Konzeption, Analyse und Wartung von Oracle-Datenbanken inklusive Backup- und Recovery-Themen.
- Du administrierst und betreust Umgebungen rund um Cloud, Virtualisierung, Linux-Server und Monitoring und unterstützt im 2nd- und 3rd-Level-Support.
- Du implementierst und optimierst IT-Systeme in Kundenumgebungen, führst Migrationen und OS-Modernisierungen durch und stellst den stabilen Betrieb bestehender Systeme sicher.
- Du erstellst technische Dokumentationen, unterstützt bei der Ausarbeitung von Pflichtenheften und begleitest Systemübergaben an den Support.
- Du bringst dich aktiv in Kundenpräsentationen, Workshops sowie den internen Wissenstransfer ein und unterstützt Kolleginnen und Kollegen bei technischen und organisatorischen Fragestellungen.

**Das bringst du mit**

- Du hast ein abgeschlossenes Studium der (Wirtschafts-)Informatik oder eine vergleichbare IT-Ausbildung, z. B. als Fachinformatiker:in für Systemintegration, und bringst relevante Berufserfahrung mit.
- Du verfügst über fundierte Kenntnisse in Oracle-Datenbanken – von Installation und Konzeption über Performance-Analyse und Wartung bis hin zu Backup- und Recovery-Strategien.
- Du hast Erfahrung mit Cloud-Umgebungen, Virtualisierung (z. B. VMware, Proxmox, Hyper-V) sowie der Administration von Linux-Servern (z. B. SLES, RHEL).
- Du kennst dich im 2nd- und 3rd-Level-Support aus und arbeitest sicher mit Monitoring-Tools und Ticketsystemen wie z. B. Jira Service Management.
- Du hast bereits Migrations- und Modernisierungsprojekte begleitet und gehst dabei strukturiert und lösungsorientiert vor.
- Du erstellst sicher technische Dokumentationen; Erfahrung mit Pflichtenheften sowie der Kalkulation und Erstellung von Kundenangeboten ist von Vorteil.
- Du kommunizierst souverän mit Kunden, Dienstleistern und internen Teams und fühlst dich auch in Workshops und Präsentationen wohl.
- Du arbeitest selbstständig und strukturiert, bringst dich gerne ins Team ein und teilst dein Wissen aktiv mit anderen.
- Du verfügst über sehr gute Deutschkenntnisse (C1), gute Englischkenntnisse (B2) sind von Vorteil, und besitzt einen Führerschein Klasse B für gelegentliche Kundentermine vor Ort.
- Dein Wohnort befindet sich in Deutschland.

**Deine Benefits – Mehr als nur ein Job!**

​Wir wissen: Ein guter Job bedeutet mehr als nur spannende Aufgaben. Bei uns profitierst du von zahlreichen Vorteilen, die dein Berufs- und Privatleben optimal in Einklang bringen:

- Work-Life-Balance at its best: 30 Urlaubstage, flexible Arbeitszeitmodelle und Gleitzeitkonto – du entscheidest, wie es für dich am besten passt!
- Individuelle Arbeitsmodelle: vor Ort, hybrid oder remote.

- Du wohnst 0 - 50 km vom zugeordneten Standort entfernt: 2x die Woche Office
- Du wohnst 51 - 150 km vom zugeordneten Standort entfernt: 2x im Monat Office
- Du wohnst über 150 km vom zugeordneten Standort entfernt: 2x im Quartal Office

- Attraktives Gehalt mit steuerfreiem Sachbezug und optionalem Kindergartenzuschuss.
- Vermögenswirksame Leistungen & betriebliche Altersvorsorge mit 20 % Arbeitgeberzuschuss – weil Zukunft wichtig ist!
- Fahrrad- & E-Bike-Leasing (bis zu 10.000 €) – auf Wunsch sogar für Partner:innen oder Kinder.
- Corporate Benefits mit Rabatten bei vielen Marken & Herstellern.
- Gesundheitsprävention: Gesundheitstage, ergonomische Ausstattung und Bildschirmarbeitsplatzbrille inklusive.
- Kostenlose Snacks, Obst, Gemüse sowie warme & kalte Getränke – für die extra Portion Energie im Arbeitsalltag.
- Top-Ausstattung: Arbeitslaptop, Bildschirme, Headset, höhenverstellbarer Schreibtisch und mehr – alles, was du für deinen Job brauchst.
- Moderne Büros mit kostenfreien Parkplätzen und guter Verkehrsanbindung.
- Duz-Kultur & flache Hierarchien – schnelle Prozesse und ein offenes Miteinander sind bei uns selbstverständlich.
- Onboarding mit Plan: Intensive Einarbeitung mit Onboarding-Buddy, damit du von Anfang an gut durchstarten kannst.
- Lernen & Weiterentwickeln: Interne & externe Weiterbildungen, Seminare und Kurse (z. B. über Udemy oder andere namhafte Anbieter).
- Team & Firmenevents: Ob Biertasting, Children Days, Grillfest oder Wichtel-Event – wir freuen uns immer über neue Ideen!
- Klingt nach einem Arbeitsumfeld, in dem du dich wohlfühlen könntest? Dann freuen wir uns auf dich!

**Dein Ansprechpartner**

Du willst uns kennenlernen und mehr über uns und den Job erfahren?

Dann schick uns deine Bewerbungsunterlagen über den Button oder ganz klassisch per E-Mail an ----- Bei Fragen vor oder während des Bewerbungsprozesses kannst du dich jederzeit unter derselben E-Mail bei uns melden.

**Unser Bewerbungsverfahren**

Nachdem wir deine Bewerbungsunterlagen erhalten haben, erhältst du von uns eine Eingangsbestätigung. Im Anschluss daran nehmen wir uns in der Regel etwa eine Woche Zeit, um deine Unterlagen sorgfältig zu prüfen. Wenn dein Profil zu unseren Vorstellungen passt, melden wir uns anschließend bei dir, um ein gemeinsames Gespräch zum Kennenlernen (telefonisch, per Teams oder vor Ort) zu vereinbaren. Nach unserem Kennenlernen beraten wir uns intern. Wenn alles passt, melden wir uns bei dir, um ein vertiefendes Folgegespräch (online oder vor Ort) zu vereinbaren. Vor Ort hast du die Möglichkeit unsere Räumlichkeiten und die Kolleg*innen kennenzulernen. Innerhalb von sieben Tagen nach deinem Gespräch hörst du dann wieder von uns. Bei einem Match bekommst du dein Vertragsangebot im Normalfall innerhalb von 2 Tagen per E-Mail und das Original im Anschluss per Post. Wir freuen uns jetzt schon!

**Hier findest du deinen neuen Arbeitgeber**

proLogistik GmbH
Fallgatter 1
44369 Dortmund
Nordrhein-Westfalen (NRW)
Deutschland

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
