# Rust Engineer (m/f/d)

Posted: 2026-09-20T05:40:11Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

# Rust Engineer

**Location:** Remote or Berlin (Office available)

At Deepslate, we are building Speech to Speech Voice AI models that sound and act indistinguishably from a human. And we believe everyone should be able to use them.

With its endless languages, dialects, accents, subtle intonations, and speech melodies, **voice** remains a highly complex unsolved frontier.

That is exactly why we started Deepslate.

Backed by top-tier investors from the Tech and AI sectors, as well as a major German VC fund, we are incredibly well-funded and moving fast.

**We are building the future of communication.**

We aren't trying to build another standalone platform; instead, we are the intelligence engine powering countless other applications. Whether it's integrated as a module by a CRM provider, plugged into another Voice AI platform, or directly embedded into an enterprise system by our integration partners, our model is built to work wherever it is needed.

## Your Role

Many core parts of our model stack are written in Rust. At the heart of it is our inference engine, written entirely in Rust.

Your mission is to build and improve these systems. You will work on the inference engine, take ownership of other Rust projects, and help decide how everything fits together. We need someone who enjoys writing good Rust code and can design software that stays understandable and maintainable as it grows.

Our models need to respond in real time. The software you build will directly influence how fast and reliable they are in an actual conversation.

### What You'll Do

-

**Build in Rust:** Develop our inference engine and other core components of the model stack. Take projects from the first architectural decisions to running in production.

-

**Design the Architecture:** Decide how components and services communicate, where responsibilities belong, and how we can extend the system without making it harder to work on.

-

**Work on Real-Time Systems:** Build async Rust systems that handle concurrent workloads and streaming audio with low latency.

-

**Improve Performance:** Find bottlenecks, understand what's causing them, and improve latency, throughput, and resource usage.

-

**Write Production-Ready Code:** Build software that we can test, debug, and operate reliably. Help improve our tooling, documentation, and development practices along the way.

### What We're Looking For: Must-Haves

-

Strong hands-on experience with **Rust**, including ownership, borrowing, composition, and idiomatic Rust design patterns.

-

Solid experience with **async Rust**. You know how to structure concurrent applications and deal with synchronization, cancellation, and backpressure.

-

Experience building and working with **microservice architectures**.

-

**A true startup mindset:** You are comfortable navigating the glorious chaos of an early-stage codebase. Inconsistent structures, missing docs. You name it, you'll help fix it.

-

**Drive and Vision:** You aren't just looking to blindly process Jira tickets. You want to actively shape the product, architect solutions, and take complete project ownership.

### Ideally, You Also Bring

-

Knowledge of **actor systems** and experience using actors to structure concurrent applications.

-

Experience with **real-time systems**, whether in embedded environments or the cloud. Both are relevant to us.

-

Experience with **C/C++ interoperability**, including generating Rust bindings with **bindgen**.

### Nice-to-Haves

-

Experience with **CUDA or GPU computing**.

-

Contributions to **open-source projects**.

-

**Python** knowledge.

-

Experience with lower-level performance engineering, such as debugging memory leaks or understanding performance at the machine instruction level.

-

**German**, spoken and written.

### What We Offer

-

**Technical Ownership:** Our Rust stack is central to the company. You'll have the trust and freedom to make architectural decisions and see them through.

-

**True R&D Freedom:** We give you the time, resources, and trust to research and build technology that simply doesn't exist yet. There are difficult problems here, and room to try different approaches.

-

**Competitive Compensation:** We are well-funded by top-tier VCs. We offer a highly competitive salary. We are looking for top talent, and we are ready to pay for it.

-

**Serious Compute:** You will have access to the hardware and cloud infrastructure necessary to build, test, and optimize the systems running our models.

-

**Absolute Flexibility:** Fully remote work, asynchronous communication, and zero micromanagement. We care about your output and impact, not your schedule.

Deepslate is an equal opportunity employer. We welcome applications from all qualified candidates regardless of gender, nationality, ethnic origin, religion, disability, age, or sexual orientation.

Compensation: €75K – €120K • Offers Equity

- • €75K – €120K • Offers Equity

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
