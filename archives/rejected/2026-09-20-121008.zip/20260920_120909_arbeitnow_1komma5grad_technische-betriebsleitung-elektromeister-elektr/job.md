# Technische Betriebsleitung & Elektromeister / Elektroinstallateurmeister (m/w/d) - Photovoltaik, Wärmepumpen & Energiesysteme - 1KOMMA5° Augsburg

Posted: 2026-09-20T08:09:31Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**1KOMMA5°**

Bei **1KOMMA5°** verfolgen wir eine Vision: **Living on wind and sunlight forever for free**. Dafür bauen wir mit Heartbeat AI das Energiesystem der Zukunft. Bist du dabei?
Wir bringen regionales Handwerk und skalierbare Software zusammen: Solar, Speicher, Wärmepumpe und E-Mobilität denken wir nicht einzeln, sondern steuern sie als intelligentes, integriertes Gesamtsystem in unserem virtuellen Kraftwerk. Direkt verbunden mit dem Strommarkt – in Echtzeit, vollautomatisiert. So wird Energie dann genutzt, wenn sie erneuerbar verfügbar und besonders günstig ist. Bis 2030 wollen wir 1,5 Millionen Haushalte auf erneuerbare Energien umstellen. Über 3.000 Menschen arbeiten jeden Tag daran, an mehr als 80 Standorten weltweit, von Finnland bis Australien.

**Du willst Verantwortung übernehmen und Lösungen bauen, die wirklich zählen? Bewirb dich jetzt und gestalte mit uns die Energiewelt von morgen.**

**Deine Position**

- Eigenverantwortliche Planung und Umsetzung der dir übertragenen Projekte im Bereich Photovoltaik
- Fachgerechte AC-seitige Installation von PV-Anlagen, Stromspeichern und Ladeinfrastruktur direkt bei unseren Kund*innen vor Ort
- Sicherstellung der ordnungsgemäßen Inbetriebnahme der Anlagen und aller zugehörigen Komponenten
- Verantwortung für das vollständige Ausfüllen und fristgerechte Einreichen relevanter Messprotokolle sowie Abnahmedokumente
- Analyse und Behebung von Fehlern sowie Durchführung von Wartungs- und Instandsetzungsarbeiten an bereits installierten Anlagen

**Dein Profil**

- Erfolgreich abgeschlossene Prüfung als Elektromeister*in mit fundiertem Fachwissen
- Erfahrung im Bereich Photovoltaikanlagen und ein sicherer Umgang mit entsprechenden Installationsprozessen
- Eigenständige, qualitäts- und sicherheitsbewusste Arbeitsweise mit hohem Verantwortungsbewusstsein
- Teamfähigkeit sowie ein freundliches und souveränes Auftreten gegenüber Kundinnen und Kolleginnen
- Führerschein der Klasse B und fließende Deutschkenntnisse für eine reibungslose Kommunikation

**Benefits**

- Gesund & fit: Profitiere vom eGym Wellpass und bleibe in Bewegung
- Zukunft sichern: Wir bieten eine betriebliche Altersvorsorge für deine finanzielle Absicherung
- Genuss am Arbeitsplatz: Freue dich auf kostenlose Getränke sowie frisches Obst und Gemüse
- Teamspirit: Erlebe regelmäßige Teamevents und werde Teil einer großartigen Gemeinschaft

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
