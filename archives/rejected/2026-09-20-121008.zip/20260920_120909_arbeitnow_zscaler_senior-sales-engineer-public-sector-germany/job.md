# Senior Sales Engineer, Public Sector - Germany

Posted: 2026-09-20T08:55:33Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Zscaler (NASDAQ: ZS) accelerates digital transformation so customers can be more agile, efficient, resilient, and secure. The Zscaler Zero Trust Exchange™️ platform protects thousands of customers from cyberattacks and data loss by securely connecting users, devices, and applications in any location. Distributed across 160+ public exchanges globally and thousands of private exchanges at the edge, the SASE-based Zero Trust Exchange is the world’s largest in-line cloud security platform.

We believe the future of work is Human + AI and are building an AI-native enterprise where human potential is amplified by machine intelligence to solve the world’s hardest security challenges. Driven by deep customer obsession, we are committed to the mission, outcome, and to each other. We bring these commitments to life through three core behaviors: ownership and collaboration, trust through outcomes and impact, and a challenge culture with ongoing feedback. Ready to make an impact at the company pioneering security transformation in the AI era? Join us at Zscaler.

We are looking for a Senior Sales Engineer to join our team. This is a remote role, reporting to the Sales Engineering Manager in the Public Sector Sales Engineering department. As a trusted technical partner to the account team, you will co-own customer engagement strategies and design secure Network Security and Cloud solutions tailored specifically to the German Public Sector. Your mission is to drive technical wins by translating complex requirements into clear, measurable outcomes like risk reduction and compliance.

**What you’ll do (Role Expectations)**

- Operate as a true “two-in-a-box” team with the Account Executive (AE) to jointly build and execute the account plan and customer engagement strategy, ensuring tight alignment from discovery through close

- Lead high-impact customer engagements by running discovery, workshops, demos, and architecture sessions to translate complex user needs into secure Network Security & Cloud solution designs

- Clearly articulate measurable outcomes such as risk reduction, regulatory compliance, and operational efficiency to both technical and non-technical stakeholders

- Drive technical win plans and proof points, creating and executing the technical strategy for opportunities, defining success criteria, and coordinating internal resources to guide deals to clear decisions

**Who You Are (Success Profile)**

- You thrive in ambiguity. You're comfortable building the path as you walk it. You thrive in a dynamic environment, seeing ambiguity not as a hindrance, but as the raw material to build something meaningful.

- You act like an owner. Your passion for the mission fuels your bias for action. You operate with integrity because you genuinely care about the outcome. True ownership involves leveraging dynamic range: the ability to navigate seamlessly between high-level strategy and hands-on execution.

- You are a problem-solver. You love running towards the challenges because you are laser-focused on finding the solution, knowing that solving the hard problems delivers the biggest impact.

- You are a high-trust collaborator. You are ambitious for the team, not just yourself. You embrace our challenge culture by giving and receiving ongoing feedback—knowing that candor delivered with clarity and respect is the truest form of teamwork and the fastest way to earn trust.

- You are a learner. You have a true growth mindset and are obsessed with your own development, actively seeking feedback to become a better partner and a stronger teammate. You love what you do and you do it with purpose.

**What We’re Looking for (Minimum Qualifications)**

- Foundational understanding of AI/ML technologies and experience leveraging, securing, or positioning AI-driven solutions to optimize outcomes within your functional domain

- Senior Sales Engineering track record in the German Public Sector with a proven ability to support complex deals end-to-end and a solid understanding of public procurement and tender processes across Federal, State, or Municipal segments

- Deep technical expertise in Network Security and Cloud, including architecture-level understanding, relevant security controls, and seamless integration into customer environments

- Value- and outcome-oriented communication skills, with the ability to deliver executive-ready presentations in German and collaborate effectively internally in English

- High learning agility to quickly master new security technologies combined with a collaborative, professional cross-functional presence

**What Will Make You Stand Out (Preferred Qualifications)**

- Experience advising public sector clients on securing AI workloads or implementing AI-forward security operations that align with sovereign cloud frameworks

- Public-sector security and compliance expertise, with hands-on experience mapping solutions to German and EU compliance frameworks such as BSI IT-Grundschutz, C5, and KRITIS/NIS2

- Presales excellence at scale, including demonstrated use of qualification or deal frameworks like Value Selling or MEDDICC alongside a track record of building repeatable technical assets

#LI-LS2 #LI-Remote

Zscaler’s salary ranges are benchmarked and determined by role and level. The range displayed on this job posting reflects the minimum and maximum target for new hire base salaries for this position across all Germany locations. Individual pay placement within this range is determined based on objective, gender-neutral criteria including job-related skills, relevant experience, and education or training. The base salary range listed for this full-time position excludes commission/bonus/equity (if applicable) and benefits.

Base Pay Range

€86.625—€123.750 EUR

At Zscaler, we are committed to building a team that reflects the communities we serve and the customers we work with. We foster an inclusive environment that values all backgrounds and perspectives, emphasizing collaboration and belonging. Join us in our mission to make doing business seamless and secure.

Our Benefits program is one of the most important ways we support our employees. Zscaler proudly offers comprehensive and inclusive benefits to meet the diverse needs of our employees and their families throughout their life stages, including:

- Various health plans

- Time off plans for vacation and sick time

- Parental leave options

- Retirement options

- Education reimbursement

- In-office perks, and more!

Learn more about Zscaler's hybrid working model and benefits [here](https://www.zscaler.com/candidate-resource-hub).

By applying for this role, you adhere to applicable laws, regulations, and Zscaler policies, including those related to security and privacy standards and guidelines.

Zscaler is committed to providing equal employment opportunities to all individuals. We strive to create a workplace where employees are treated with respect and have the chance to succeed. All qualified applicants will be considered for employment without regard to race, color, religion, sex (including pregnancy or related medical conditions), age, national origin, sexual orientation, gender identity or expression, genetic information, disability status, protected veteran status, or any other characteristic protected by federal, state, or local laws. *See more information by clicking on the *[*Know Your Rights: Workplace Discrimination is Illegal *](https://www.eeoc.gov/sites/default/files/2023-06/22-088_EEOC_KnowYourRights6.12ScreenRdr.pdf)*link.*

Pay Transparency

Zscaler complies with all applicable federal, state, and local pay transparency rules.

Zscaler is committed to providing reasonable support (called accommodations or adjustments) in our recruiting processes for candidates who are differently abled, have long term conditions, mental health conditions or sincerely held religious beliefs, or who are neurodivergent or require pregnancy-related support.

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
