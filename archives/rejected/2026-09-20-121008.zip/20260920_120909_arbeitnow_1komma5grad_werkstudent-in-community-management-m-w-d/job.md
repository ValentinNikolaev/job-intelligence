# Werkstudent:in Community Management (m/w/d)

Posted: 2026-09-20T08:09:31Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**1KOMMA5°**

Bei **1KOMMA5°** verfolgen wir eine Vision: **Living on wind and sunlight forever for free**. Dafür bauen wir mit Heartbeat AI das Energiesystem der Zukunft. Bist du dabei?
Wir bringen regionales Handwerk und skalierbare Software zusammen: Solar, Speicher, Wärmepumpe und E-Mobilität denken wir nicht einzeln, sondern steuern sie als intelligentes, integriertes Gesamtsystem in unserem virtuellen Kraftwerk. Direkt verbunden mit dem Strommarkt – in Echtzeit, vollautomatisiert. So wird Energie dann genutzt, wenn sie erneuerbar verfügbar und besonders günstig ist. Bis 2030 wollen wir 1,5 Millionen Haushalte auf erneuerbare Energien umstellen. Über 3.000 Menschen arbeiten jeden Tag daran, an mehr als 80 Standorten weltweit, von Finnland bis Australien.

**Du willst Verantwortung übernehmen und Lösungen bauen, die wirklich zählen? Bewirb dich jetzt und gestalte mit uns die Energiewelt von morgen.**

**Deine Position**

Ob in den Kommentaren unserer Social-Media-Kanäle oder in Bewertungen auf Trustpilot und Google – überall dort entsteht ein Stück öffentliches Bild von 1KOMMA5°. Damit wir dort schnell, passend und im Sinne unserer Marke reagieren, suchen wir dich als Verstärkung für unser Community- und Bewertungsmanagement – mit Gespür für Sprache, Plattformen und den Menschen dahinter.

Community Management & Bewertungsmanagement (dein Hauptfokus)

-

Du unterstützt das Team bei der Community-Betreuung auf Instagram, Facebook, YouTube und LinkedIn in der zeitnahen Beantwortung von Kommentaren und Nachrichten im Ton von 1KOMMA5°

-

Du unterstützt im operativen Bewertungsmanagement: Du screenst neue Bewertungen auf Trustpilot und Google, reportest Auffälligkeiten und hilfst bei der Implementierung entsprechender Maßnahmen

-

Du behältst wöchentlich das relevante Video-Umfeld auf YouTube im Blick, sichtest ausgewählte Kanäle und Beiträge rund um 1KOMMA5° und gibst deine Beobachtungen strukturiert ans Team weiter, damit bei Bedarf schnell die richtigen nächsten Schritte eingeleitet werden können

-

Du unterstüzt unsere Organic Traffic Machine: Direkt nachdem neue Inhalte auf unseren Kanälen live gehen, gehst du aktiv in die Kommentare unserer eigenen Posts, stößt Diskussionen an und sorgst so mit dafür, dass unsere Inhalte zusätzlich an Reichweite und Sichtbarkeit gewinnen

-

Du behältst die Logiken der einzelnen Plattformen im Blick – was auf LinkedIn funktioniert, funktioniert nicht automatisch auf Instagram – und kommunizierst dabei immer im Sinne von 1KOMMA5°

-

Du platzierst unsere Inhalte auch dort, wo sich Gespräche über Energiewende, PV, Wärmepumpen & Co. sowieso schon abspielen – zum Beispiel durch passende, wertstiftende Kommentare auf anderen Accounts

Dein Signature-Projekt: GEO

-

Du übernimmst bei uns das Thema GEO (Generative Engine Optimization) als eigenes kleines Projekt und bringst dich inhaltlich aktiv ein: Du entwickelst mit, wie unsere Social-Media- und Community-Inhalte so formuliert und aufbereitet werden, dass sie auch in KI-gestützten Suchergebnissen und Antworten gut sichtbar sind

-

Du bringst eigene Ideen ein, testest neue Formulierungsansätze und hilfst dabei, GEO nach und nach fest in unsere Content-Erstellung einzubauen

**Dein Profil**

- Du bist noch mindestens **zwei Semester ****an einer deutschen Hochschule**** im Bereich ****Marketing, Kommunikation, Medien, BW****L**** o**der in einem vergleichbaren Studiengang immatrikuliert
-

Du bist selbst viel auf Social Media unterwegs und verstehst intuitiv, wie sich Instagram, Facebook, YouTube und LinkedIn jeweils unterscheiden – in Ton, Format und Zielgruppe

-

Erste Erfahrung im Community- oder Social-Media-Management ist ein Plus, aber kein Muss – wichtiger ist uns dein Gespür für Sprache und Menschen.

-

Du schreibst sicher und stilsicher auf Deutsch, Englischkenntnisse sind von Vorteil

-

Erfahrung mit Social-Media-Management-Tools wie Agorapulse (oder vergleichbaren Tools) ist hilfreich

-

Ein Grundverständnis von SEO bzw. GEO (Generative Engine Optimization) ist ein Plus – vor allem aber hast du Lust, dich in dieses Thema als eigenes kleines Projekt einzuarbeiten und es aktiv mitzugestalten

-

Du interessierst dich für die Energiewende und hast Lust, dieses Thema jeden Tag ein Stück greifbarer zu machen

**Benefits**

- Du hast die Möglichkeit in unserem schicken Showroom in der **Hamburger Innenstadt** zu arbeiten und/oder remote
- Einblicke in das **Community Managemen****t **eines der am schnellsten wachsenden CleanTech-Startups Europas
-

Ein Team, das dir Fragen beantwortet, **Feedback** gibt und dich in die Plattform- und Tool-Logiken einarbeitet

-

**Flexible Arbeitszeiten**, die sich mit deinem Studium vereinbaren lassen

- Nutze dein **technisches Equipment **auch abseits der Arbeit in deiner **Freizeit**
- Du bist Teil eines **schnell wachsenden Unternehmens** mit viel **Entwicklungspotenzi****al**, wo du **eigenständig** etwas aufbauen kannst und deinen Impact spürst
- Bewege dich in **flachen Hierarchien**, übernimm schon während deiner Einarbeitung **Verantwortung** und arbeite direkt mit Teilen des Managements zusammen
- Mit deiner Arbeit unterstützt du den Megatrend **“Energie- und Mobilitätswende”** und leistest einen **konkreten Beitrag** zum **nachhaltigen** Umbau unserer Energie-Infrastruktur
- Sei aktiv und nutze das Angebot von über 7.600 Sportpartnern mit dem **EGYM-Wellpass**
- Ob Citybike oder E-Bike – mit unserem **Jobrad-Leasing** bleibst du flexibel und bist umweltfreundlich unterwegs**
**
- Profitiere von **Benefits & Rabatten** durch Futurebens

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
