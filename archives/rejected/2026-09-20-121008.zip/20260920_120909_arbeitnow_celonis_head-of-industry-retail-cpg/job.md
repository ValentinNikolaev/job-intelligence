# Head of Industry - Retail & CPG

Posted: 2026-09-20T08:55:36Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Celonis is the trusted platform to industrialize Enterprise AI. At our core is the Celonis Context Model — which combines process data, business knowledge, and intelligence into a living digital twin of the enterprise that AI can actually understand, turning AI's operational blind spots into operational clarity. World's leading companies trust Celonis and its global ecosystem of partners to make their AI agents, people, systems, and processes work together, achieving transformational outcomes. We believe there's a massive opportunity to unlock global productivity and sustainability by giving AI the context to understand how every business process really works. Join our mission to make processes work for people, companies, and the planet.

**The team:**

The Celonis Retail & CPG Industry Practice is at the forefront of solving the industry’s most critical business challenges. With +100 Celonauts operating across our footprint of global accounts, the Industry practice combines GTM, product and engineering into a cohesive ambition and strategy to help our clients achieve unparalleled value through our software. Tasked with scaling outcomes from the account level to the industry level, the team is defining, building and scaling products that are transforming how the most influential Retail & CPG companies run their business.

**The role:**

As the Head of Industry - Retail & CPG, you will be responsible for leading the vision, strategy and execution of our Retail & CPG Industry Practice. You will own the outcome of the Industry Practice - working with GTM, product, AI, engineering teams, and external partners to build and scale software solutions that are at the heart of the Retail & CPG industry’s processes.

You will be the face of our Retail & CPG industry internally and externally, and responsible for the success of the global community of clients, Celonauts, and partners.

**The work you’ll do:**

An extremely high level of autonomous leadership and entrepreneurship is required to succeed in this role. You must thrive as a leader within a nebulous problem space, moving seamlessly between sales, scoping, product and customer interactions and bringing the wide range of stakeholders along this journey. A bias towards action and build-first approach will be needed to lead in this fast-paced environment.

**You will be expected to:**

- Define the vision for Celonis Retail & CPG industry practice and translate this into a strategy and prioritised set of actions for the team.

- Build and lead a cross-functional industry team across Value Engineering, Sales, AI Builders and define the processes/structure required to accelerate our impact within the industry.

- Work side-by-side with customers to align our Retail & CPG solutions against their business strategy

- Closely collaborate with leaders from our Product, Engineering & GTM organizations to inform future product development based on customer feedback.

- Identify and package scalable use cases across the Celonis platform, driving innovation and expanding our offerings

- Enable internal teams and partners to help them position and deploy Retail & CPG solutions

**The qualifications you need:**

-

- Proven record of building and leading a cross-functional team building software solutions against strategic Retail & CPG industry problems

- High degree of entrepreneurship with experience of building in a 0 -> 1 environment

- Excellence in public speaking and external presentation

- Proven experience developing software solutions for enterprises, with a strong portfolio showcasing successful use cases solving real-world problems.

- Strong communication and collaboration skills, with the ability to translate complex concepts into actionable insights for a wide array of stakeholders (from the board room to the end user).

**What Celonis can offer you:**

- Pioneer Innovation: Work with the global leader in Process Mining and the Process Intelligence Graph to shape the future of AI-driven business operations.

- Ownership from Day 1: Every full-time "Celonaut" is an owner, receiving Restricted Stock Units (RSUs) and merit-based refresh grants.

- Unrivaled Family Support: Benefit from our inclusive parental leave policy—24 weeks of fully paid leave for primary carers and 12 weeks for supporting carers, available from your first day of employment.

- Work-Life Integration: Enjoy Unlimited PTO (in applicable regions) and generous PTO globally, as well as a flexible hybrid work model that balances remote focus with vibrant office collaboration.

- Continuous Growth: Elevate your skills through our 70-20-10 learning framework, mentorship programs, and access to a dedicated learning platform.

- Holistic Well-being: Prioritize your health with subsidized Wellhub memberships, mental health counseling, and dedicated "Wellness Weeks" that prioritize work/life balance.

- Drive Sustainability: Participate in annual Impact Days, where you receive paid time off to volunteer for community and environmental causes with your local office, or virtually.

- Global Inclusion & Belonging: Find community through our Inclusion Think Tank and participate in our annual Inclusion Days, ensuring every voice is heard and valued.

- Value-Driven Impact: Join a mission-led organization where our core values—Live for Customer Value, The Best Team Wins, We Own It, and Earth Is Our Future—drive every decision.

**About Us:**

Celonis is the trusted platform to industrialize Enterprise AI, empowering organizations to analyze, design, and operate AI-driven processes. The Celonis Platform is powered by the Celonis Context Model, which combines process data, business knowledge, and intelligence to create a living digital twin of the enterprise that AI can understand — turning AI’s operational blind spots into operational clarity. Industry-leading companies around the world trust Celonis and its global ecosystem of partners to make their AI agents, people, systems, and processes work together, achieving transformational outcomes. Celonis is headquartered in Munich, Germany, and New York City, USA, with more than 20 offices worldwide.

Get familiar with the Celonis Process Intelligence Platform by watching this [video](https://www.youtube.com/watch?v=YR5oRJGhJYg&list=PLuVor-ZUD4pnM6G33C5D0tjXUvlTPYBRe).

**Celonis Inclusion Statement:**

At Celonis, we believe our people make us who we are and that “The Best Team Wins”. We know that the best teams are made up of people who bring different perspectives to the table. And when everyone feels included, able to speak up and knows their voice is heard - that's when creativity and innovation happen.**
**

**Your Privacy:**

Any information you submit to Celonis as part of your application will be processed in accordance with Celonis’ [Accessibility and Candidate Notices](https://www.celonis.com/careers/candidate-notices)

By submitting this application, you confirm that you agree to the storing and processing of your personal data by Celonis as described in our [Privacy Notice for the Application and Hiring Process](https://www.celonis.com/careers/privacy-notice/).

Please be aware of common job offer scams, impersonators and frauds. Learn more [here](https://www.celonis.com/careers/fraud-alert/).

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
