# Ausbildung Fachinformatiker für Anwendungsentwicklung (m/w/d)

Posted: 2026-09-20T08:09:17Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**Dein Job bei uns:**

Starte deine Ausbildung zum Fachinformatiker für Anwendungsentwicklung (m/w/d) bei uns und werde Teil eines unserer Entwicklerteams.

Was du bei uns machst:

- Du entwickelst Software in C# und SQL für unsere Kunden aus der Transportlogistik.
- Du liebst Apps? Perfekt! Unsere Software läuft auf tausenden Android-Geräten in Lkw-Cockpits.
- Dein Code sorgt dafür, dass Lkw schneller und ressourcenschonender ans Ziel kommen.
- Du lernst alle Seiten des Softwaregeschäfts kennen: Von Beratung über Programmierung und Qualitätssicherung bis hin zu Support.
Neugierig, was unsere Azubis dazu sagen? Dann klick dich mal in unseren **Azubi-Blog**!
Und das Beste: Nach der Ausbildung hast du super Übernahmechancen und viele Möglichkeiten, dich weiterzuentwickeln.

**Das bringst du mit:**

- Du hast dein Abitur in der Tasche – mit guten Noten in Mathe und/oder Informatik.
- Du hast schon Erfahrungen mit Programmieren, Datenbanken oder Informatik-Projekten gesammelt.
- Du arbeitest gerne eigenständig, aber auch im Team, und hast richtig Bock aufs Coden.
- Du bist neugierig, motiviert und suchst spannende Herausforderungen.

**Deine Aussichten bei uns:**

Bei uns erwartet dich ein lockeres, freundschaftliches Arbeitsklima. Wir duzen uns alle, helfen einander und haben Spaß an dem, was wir tun.

Außerdem bekommst du:

- Flexible Arbeitszeiten
- Kostenlose Getränke & Obst + Smoothie-Station
- Kickertisch, Tischtennis & großer Pausenraum
- Regelmäßige Teamevents
- Deutschlandticket & BenefitCard & Corporate Benefits
- Starter Kit mit RaspberryPi & Arduino für deine eigenen Projekte

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
