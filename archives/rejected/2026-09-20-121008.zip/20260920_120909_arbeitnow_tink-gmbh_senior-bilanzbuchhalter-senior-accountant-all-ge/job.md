# Senior Bilanzbuchhalter / Senior Accountant (all genders)

Posted: 2026-09-20T08:09:09Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**Deine Aufgaben**

-

Erstellung von Monats, Quartals und Jahresabschlüssen: Eigenverantwortliche Vorbereitung und Erstellung der Abschlüsse nach HGB für die tink GmbH und verbundene Gesellschaften

-

Haupt und Nebenbuchhaltung: Überwachung und Durchführung der Debitoren, Kreditoren, Anlagen und Bankbuchhaltung sowie Sicherstellung ordnungsgemäßer Abgrenzungen und Rückstellungen

-

Steuerrecht und Compliance: Erstellung und Übermittlung von Umsatzsteuervoranmeldungen, ZM Meldungen und statistischen Meldungen. Ansprechpartner für steuerliche Fragestellungen im Tagesgeschäft

-

Ansprechpartner für externe Partner: Erste Schnittstelle für Wirtschaftsprüfer, Steuerberater, Betriebsprüfer und Banken

-

Prozessoptimierung und Digitalisierung: Aktive Mitgestaltung und Automatisierung von Finanz und Buchhaltungsprozessen in Zusammenarbeit mit ERP und BI Teams

-

Intercompany Abstimmung: Verantwortung für die Abstimmung und Verrechnung von Geschäftsvorfällen zwischen den Konzerngesellschaften

-

Mentor und Sparringspartner Rolle: Fachliche Unterstützung und Weiterentwicklung von Junior Kollegen im Accounting Team

**Diese Position ist als Senior Rolle mit Aussicht auf eine Führungsposition im Accounting Team angelegt. Mit wachsender Verantwortung besteht die Perspektive, das Team fachlich und organisatorisch zu leiten.**

**Dein Profil**

-

Qualifikation: Erfolgreich abgeschlossene kaufmännische Ausbildung oder Studium mit Schwerpunkt Finanzen und Rechnungswesen sowie eine erfolgreich absolvierte Weiterbildung zum Geprüften Bilanzbuchhalter (IHK) oder eine vergleichbare Qualifikation.

-

Berufserfahrung: Mindestens 4 bis 5 Jahre fundierte Berufserfahrung in der Bilanzbuchhaltung, idealerweise im E Commerce, Retail oder Tech Umfeld.

-

Fachwissen: Exzellente Kenntnisse im HGB Bilanzrecht und deutschen Steuerrecht. Kenntnisse in IFRS von Vorteil.

-

Software und Systeme: Erfahrener Umgang mit gängigen ERP Systemen (z. B. DATEV, SAP, Microsoft Dynamics NCV/Business Central) sowie sehr gute Excel Kenntnisse.

-

Arbeitsweise: Ausgeprägtes analytisches Denkvermögen, hohe Zahlenaffinität, Präzision sowie eine selbstständige und zielorientierte Arbeitsweise.

-

Sprachen: Verhandlungssichere Deutschkenntnisse (C2) sowie sehr gute Englischkenntnisse in Wort und Schrift.

**Warum wir?**

**tink Kultur:**

- tink Mission: Wir verbinden ein erfolgreiches Geschäftsmodell mit der Mission, allen Haushalten einen Zugang zu einem nachhaltigeren und smarten Zuhause zu ermöglichen
- Expertise: Ein erfahrenes Management-Team mit langjährigem Hintergrund im Startup-, Industrie- und Beratungsgeschäft
- International: Unser Team kommt aus über 30 verschiedenen Nationen
- Diversität: Wir freuen uns über Bewerber:innen jeglicher Nationalität, ethnischer Herkunft, religiöser Zugehörigkeit, sexueller Orientierung und jeglichen Geschlechts. Bei uns zählen Persönlichkeit und Performance.
- Persönliche Weiterentwicklung: Regelmäßige Feedback Runden und Reviews - Deine professionelle und persönliche Weiterentwicklung liegt uns am Herzen!
- Faire Kommunikation: Wir haben eine offene und transparente Feedback-Kultur.
**tink Benefits: **

- Ein wunderschönes helles Office direkt im Herzen von Berlin-Mitte am Hackeschen Markt mit vielen Meeting Räumen, Loungebereich, Küche, Tischtennisplatte, Bar und umgeben von vielen Restaurants und Cafés
- Top Kaffeemaschine, Müsli und frisches Obst
- Internationale Kultur mit über 30 Nationen
- Regelmäßige Teamevents & eine stets gut bestückte Bar
- Bis zu 20 Urlaubstage
- Urban Sports Zuschuss

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
