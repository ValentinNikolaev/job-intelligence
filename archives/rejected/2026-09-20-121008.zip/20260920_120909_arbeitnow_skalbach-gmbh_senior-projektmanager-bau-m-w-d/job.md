# Senior Projektmanager Bau (m/w/d)

Posted: 2026-09-20T08:09:04Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**Firmenprofil**

Unser Mandant ist ein international agierendes Unternehmen, das sich auf Projektsteuerung, Baumanagement und die erfolgreiche Realisierung komplexer Bauvorhaben spezialisiert hat. In vielseitigen Projekten unterschiedlichster Größenordnungen werden Bauherren von der ersten Projektidee bis zur Fertigstellung professionell begleitet. Dabei stehen Qualität, Wirtschaftlichkeit und Terminsicherheit stets im Mittelpunkt. Durch die enge Zusammenarbeit interdisziplinärer Teams entstehen nachhaltige und zukunftsfähige Lösungen für anspruchsvolle Bauprojekte. Das Unternehmen bietet seinen Mitarbeitenden moderne Arbeitsbedingungen, flache Hierarchien und vielfältige Entwicklungsmöglichkeiten in einem dynamischen Umfeld. Zur Verstärkung des Teams suchen wir einen engagierten Senior Projektmanager Bau (m/w/d).

**Ihre Aufgaben**

- Ganzheitliche Steuerung und Koordination anspruchsvoller Bauprojekte über sämtliche Projektphasen hinweg
- Führung und Abstimmung aller Projektbeteiligten, von Planungsbüros über Fachingenieure bis hin zu ausführenden Unternehmen
- Verantwortung für die Einhaltung von Qualitäts-, Kosten- und Terminvorgaben im Rahmen der Projektabwicklung
- Ansprechpartner für Auftraggeber, Behörden, Fachplaner und weitere Stakeholder während des gesamten Projektverlaufs
- Vorbereitung, Moderation und Nachbereitung von Projektbesprechungen sowie Entwicklung geeigneter Lösungsstrategien bei projektbezogenen Herausforderungen

**Ihr Profil**

- Erfolgreich abgeschlossenes Studium im Bauingenieurwesen, der Architektur oder einer vergleichbaren Fachrichtung
- Mehrjährige Berufserfahrung in der Projektsteuerung, im Projektmanagement oder im Baumanagement anspruchsvoller Bauvorhaben
- Fundierte Kenntnisse der HOAI, VOB sowie der relevanten technischen und rechtlichen Rahmenbedingungen
- Sicherer Umgang mit MS Office sowie gängigen Projektmanagement- und Steuerungstools
- Strukturierte, kommunikationsstarke und lösungsorientierte Persönlichkeit mit ausgeprägtem Organisationsgeschick

**Benefits**

- Verantwortungsvolle Position mit großem Gestaltungsspielraum und direktem Einfluss auf anspruchsvolle Bauprojekte
- Flexible Arbeitszeitmodelle und moderne Arbeitsstrukturen zur optimalen Vereinbarkeit von Beruf und Privatleben
- Individuelle Weiterbildungs- und Entwicklungsmöglichkeiten mit klaren Perspektiven für die weitere Karriere
- Moderne technische Ausstattung sowie digitale Arbeitsumgebungen für ein effizientes und zukunftsorientiertes Arbeiten
- Zusammenarbeit in einem internationalen Umfeld mit spannenden Projekten und interdisziplinären Teams
- Attraktive Zusatzleistungen im Bereich Mobilität, Gesundheit und Mitarbeiterförderung
- Langfristige Perspektive in einem wirtschaftlich erfolgreichen Unternehmen mit nachhaltigem Wachstum

**Kontakt**

Als Recruiting-Partner begleiten wir diesen Besetzungsprozess exklusiv und stehen Ihnen während des gesamten Bewerbungsverfahrens persönlich und vertraulich zur Seite. Gerne informieren wir Sie in einem ersten Gespräch über weitere Details zur Position, zum Projektumfeld sowie zu den Entwicklungsmöglichkeiten bei unserem Mandanten. Nach Eingang Ihrer Bewerbung erhalten Sie zeitnah eine qualifizierte Rückmeldung zum weiteren Ablauf. Wir freuen uns darauf, Sie kennenzulernen und Sie bei Ihrem nächsten Karriereschritt zu unterstützen.

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
