# GEO & AI Search Consultant (f/m/d) German-speaking

Posted: 2026-09-20T05:55:15Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**Purpose of Position**

This is an exciting opportunity for an analytical and forward-thinking GEO & AI Search Consultant to join Awin's growing Client Services team. In this role, you will help leading brands improve their visibility across AI-powered search environments, Large Language Models (LLMs), search engines, AI assistants, and emerging generative platforms.

Combining deep SEO expertise with a consultative approach, you will be responsible for developing and executing GEO strategies, advising clients on AI search best practices, and translating business objectives into actionable growth plans. Working closely with Client Services Teams, Product, and external partners, you will play a key role in shaping Awin's GEO offering, supporting new business opportunities, and establishing best practices for succeeding in the era of AI-driven search.

Please note: This is a fixed-term position with a contract duration of two years.

**Key Tasks**

- Develop and implement GEO strategies to improve client visibility across AI-powered search environments, AI assistants, and emerging generative platforms

- Onboard new GEO clients and support the successful adoption of Awin's GEO methodology, tools, and reporting framework

- Analyse AI visibility, citation sources, sentiment, Share of Voice (SOV), and ranking performance using GEO monitoring tools such as Peec AI

- Translate performance insights into clear, actionable recommendations and implementation of media plans for clients

- Manage GEO campaign budgets and investment allocations, working closely with Client Services teams to develop data-driven budget recommendations and ensure resources are allocated effectively to maximize AI visibility and client performance outcomes.

- Monitor GEO performance, identify trends, and proactively recommend opportunities to improve

- Create client-facing reports, presentations, case studies, and performance reviews

- Deliver GEO recommendations and implementation guidance during regular client meetings and business reviews

- Support strategic new business opportunities and client pitches by providing GEO analysis, insights, and recommendations

- Collaborate closely with Sales, Client Services, and Product teams to ensure successful delivery of GEO initiatives and consistent client experience

- Contribute to the development of GEO playbooks, processes, best practices, and training materials

- Share GEO knowledge across the business through internal training sessions and workshops

**Skills & Expertise**

- 3-5 years of experience in SEO, organic growth, content strategy, digital marketing, or a related client-facing consulting role

- Understanding of the Affiliate market and landscape is an advantage

- Solid understanding of technical SEO, content optimization, authority-building strategies, and organic search performance

- Knowledge of AI search, Large Language Models (LLMs), retrieval systems, and generative search trends

- Experience working with SEO, analytics, AI visibility, or performance monitoring platforms, ideally including Peec AI or similar solutions

- Ability to analyse data, identify opportunities, and convert insights into practical recommendations and action plans

- Experience managing client relationships including budget allocation and presenting performance results and recommendations to stakeholders

- Strong project management and organisational skills, with the ability to manage multiple clients and priorities simultaneously

- Comfortable working cross-functionally with sales, product, and customer-facing teams

- Strong written and verbal communication skills with the ability to explain technical concepts in a clear and understandable way

- Excellent German and English language skills

**Our Offer **

-

**Flexi-Week**: We prioritise your mental health and wellbeing by offering you a four-day Flexi-Week (with one lighter or completely disconnected day per week) at full pay, with no reduction to your annual holiday allowance.

-

**Flexi-Office**: We offer an international culture and flexibility through our hybrid working model, designed to foster collaboration, trust, and autonomy.

-

**Work Expense Contribution & Remote Working Furniture**: You will receive a monthly allowance to cover part of your running costs, as well as a furniture package to support you in setting up a comfortable workspace at home.

-

**Pension: **Awin offers access to an additional pension insurance to all employees in Germany and contributes regularly to your retirement savings.

-

**Business Bike Leasing**: Take advantage of our bike leasing scheme and support a more sustainable way of commuting.

-

**Benefit Selection Scheme**: After 3 years of service, you can choose from a range of benefits up to a value of €900 per year.

*In addition, you’ll benefit from our global offering, including health and wellbeing initiatives, learning and development via Awin Academy, and peer-to-peer recognition programmes.*

Established in 2000, Awin is proud of our dynamic, social and inclusive culture.

Like all businesses, we’ve had to adapt and nurture our culture in a virtual environment. Our virtual ‘Life @ Awin’ hub brings our colleagues from across the globe together for various social activities.

Diversity & Inclusion are paramount to us, and we proudly pursue and hire diverse team members. We champion uniqueness and authenticity; this is who we are at our core. Our network of affiliate partnerships are diverse and transparent, as are the employees powering our vision to build the world’s leading open partner ecosystem. We welcome all backgrounds, identities, and experiences. If you need support at any point in the application or interview process, please let us know.

Awin is part of the Axel Springer group. Learn more at [axelspringer.com/en/](https://www.axelspringer.com/en/), and explore the Axel Springer Essentials here: [axelspriger.com/en/inside/the-essentials-what-we-have-adapted-and-why](https://www.axelspringer.com/en/inside/the-essentials-what-we-have-adapted-and-why)

Apply now to begin the next stage of your career at a progressive company that supports both your professional and personal development.

#LI-AM1

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
