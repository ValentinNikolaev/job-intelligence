# Senior Bauleiter (m/w/d) Hochbau in Stuttgart oder Karlsruhe

Posted: 2026-09-20T08:09:04Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**Firmenprofil**

Unser Mandant ist ein erfolgreiches und wirtschaftlich stark aufgestelltes Bauunternehmen, das seit vielen Jahren anspruchsvolle Hochbauprojekte realisiert. Mit einem hohen Qualitätsanspruch, innovativen Bauprozessen und einer partnerschaftlichen Unternehmenskultur zählt das Unternehmen zu den etablierten Akteuren der Branche. Durch spannende Neubauprojekte sowie langfristige Entwicklungsperspektiven bietet unser Mandant ein attraktives Arbeitsumfeld für erfahrene Bauprofis. Zur Verstärkung des Teams suchen wir einen Senior Bauleiter Hochbau (m/w/d) für den Standort in Stuttgart sowie auch einen Senior Bauleiter Hochbau (m/w/d) für den Standort in Karlsruhe, der anspruchsvolle Bauvorhaben eigenverantwortlich zum Erfolg führt.

**Ihre Aufgaben**

- Eigenverantwortliche Leitung und Steuerung anspruchsvoller Hochbauprojekte von der Baustelleneinrichtung bis zur erfolgreichen Übergabe
- Koordination und Führung der Nachunternehmer sowie aller am Bau beteiligten Gewerke
- Sicherstellung der Einhaltung von Termin-, Qualitäts- und Kostenvorgaben
- Ansprechpartner für Bauherren, Architekten, Fachplaner und Behörden während der gesamten Bauphase
- Überwachung des Baufortschritts einschließlich Dokumentation, Nachtragsmanagement und Abnahme der Bauleistungen

**Ihr Profil**

- Abgeschlossenes Studium im Bauingenieurwesen, der Architektur oder eine vergleichbare Qualifikation
- Mehrjährige Berufserfahrung als Bauleiter im Hochbau, idealerweise in der eigenverantwortlichen Abwicklung komplexer Bauprojekte
- Fundierte Kenntnisse der VOB sowie ein sicheres Verständnis für Bauabläufe und Projektsteuerung
- Ausgeprägtes Organisationsgeschick, Durchsetzungsvermögen und unternehmerisches Denken
- Kommunikationsstärke, Teamfähigkeit und eine selbstständige, strukturierte Arbeitsweise

**Benefits**

- Unbefristete Festanstellung bei einem wirtschaftlich erfolgreichen Bauunternehmen mit langfristiger Perspektive
- Anspruchsvolle und abwechslungsreiche Hochbauprojekte mit viel Eigenverantwortung
- Attraktives Vergütungspaket inklusive Firmenwagen zur privaten Nutzung
- Moderne Arbeitsmittel sowie digitalisierte Prozesse für eine effiziente Projektabwicklung
- Individuelle Weiterbildungs- und Entwicklungsmöglichkeiten mit klaren Karriereperspektiven

**Kontakt**

Haben wir Ihr Interesse geweckt? Dann freuen wir uns auf Ihre Bewerbung mit Angabe Ihres frühestmöglichen Eintrittstermins und Ihrer Gehaltsvorstellung. Nach Eingang Ihrer Unterlagen setzen wir uns zeitnah mit Ihnen in Verbindung und besprechen gemeinsam die nächsten Schritte im Bewerbungsprozess. Selbstverständlich behandeln wir Ihre Bewerbung jederzeit vertraulich.

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
