# Projektmanager (m/w/d) Revitalisierung/Hochbau in Frankfurt am Main

Posted: 2026-09-20T08:09:04Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**Firmenprofil**

Unser Mandant ist ein erfolgreiches und wirtschaftlich stark aufgestelltes Unternehmen mit langjähriger Erfahrung in der Entwicklung, Planung und Umsetzung anspruchsvoller Bauprojekte. Der Fokus liegt auf der Revitalisierung, Modernisierung und nachhaltigen Weiterentwicklung von Bestandsimmobilien. Durch innovative Lösungen, hohe Qualitätsstandards und eine partnerschaftliche Zusammenarbeit hat sich das Unternehmen einen hervorragenden Ruf am Markt erarbeitet. Zur Verstärkung des Teams wird ein Projektmanager (w/m/d) gesucht, der Umbau- und Ausbauprojekte eigenverantwortlich steuert und aktiv zum Projekterfolg beiträgt.

**Ihre Aufgaben**

- Eigenverantwortliche Steuerung von Projekten
- Koordination und Führung aller internen und externen Projektbeteiligten
- Sicherstellung der Einhaltung von Kosten-, Termin- und Qualitätsvorgaben
- Steuerung von Planungs-, Ausschreibungs- und Vergabeprozessen
- Ansprechpartner für Bauherren, Mieter, Fachplaner und ausführende Unternehmen während der gesamten Projektlaufzeit

**Ihr Profil**

- Abgeschlossenes Studium im Bereich Bauingenieurwesen, Architektur, Immobilienwirtschaft oder eine vergleichbare Qualifikation
- Mehrjährige Berufserfahrung im Projektmanagement von Bau- oder Bestandsimmobilienprojekten
- Fundierte Kenntnisse in der Planung, Steuerung und Umsetzung von Umbau- und Ausbauprojekten
- Ausgeprägtes Organisationsgeschick sowie wirtschaftliches Denken und Handeln
- Kommunikationsstärke, Durchsetzungsvermögen und eine strukturierte Arbeitsweise

**Benefits**

- Unbefristete Festanstellung in einem erfolgreichen und zukunftsorientierten Unternehmen
- Anspruchsvolle Projekte mit hoher Eigenverantwortung und Gestaltungsspielraum
- Attraktive Vergütung sowie zusätzliche finanzielle Benefits
- Moderne Arbeitsmittel und flexible Arbeitsmodelle
- Individuelle Weiterbildungs- und Entwicklungsmöglichkeiten
- Kollegiales Arbeitsumfeld mit langfristiger Perspektive

**Kontakt**

Sie möchten anspruchsvolle Umbau- und Ausbauprojekte in Bestandsimmobilien eigenverantwortlich begleiten und aktiv mitgestalten? Dann freuen wir uns auf Ihre aussagekräftige Bewerbung unter Angabe Ihres frühestmöglichen Eintrittstermins. Nach Eingang Ihrer Unterlagen setzen wir uns zeitnah mit Ihnen in Verbindung und informieren Sie über die weiteren Schritte im Bewerbungsprozess.

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
