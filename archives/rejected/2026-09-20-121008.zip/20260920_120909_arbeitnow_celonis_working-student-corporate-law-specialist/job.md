# Working Student Corporate Law Specialist

Posted: 2026-09-20T08:55:37Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Celonis is the trusted platform to industrialize Enterprise AI. At our core is the Celonis Context Model — which combines process data, business knowledge, and intelligence into a living digital twin of the enterprise that AI can actually understand, turning AI's operational blind spots into operational clarity. World's leading companies trust Celonis and its global ecosystem of partners to make their AI agents, people, systems, and processes work together, achieving transformational outcomes. We believe there's a massive opportunity to unlock global productivity and sustainability by giving AI the context to understand how every business process really works. Join our mission to make processes work for people, companies, and the planet.

**The Team:**

The Celonis legal team partners with the business team to help drive the company’s growth and provide strategic guidance.

**The Role:**

As a Working Student-Corporate specialist, you will support our corporate legal team. This role offers a unique opportunity to gain hands-on experience while balancing your studies. You will assist in legal research, general contract review and negotiation, support for global real estate and insurance programs, corporate governance, general corporate and transactional work, assistance with the development of departmental processes and policies and general legal support. You will have a strong academic background in law, excellent research skills, and a keen interest in corporate legal matters.

**The work you’ll do:**

- Corporate Law Support:

- Assist with research and analysis of corporate law and regulatory requirements

- Help review and interpret legal documents and regulations

- Corporate Governance Assistance:

- Support the development and implementation of corporate governance policies

- Contribute to the preparation of governance-related documents and reports

- General Contract Review and Negotiation

- Review and negotiate various types of commercial agreements

- Support internal stakeholders

- Support for Global Real Estate and Insurance Programs

- Assist with management of global liability insurance programs

- Support day-to-day insurance tasks and queries

- Support legal management of global real estate portfolio

- Assistance with Development of Departmental Processes and Policies

- Assist with development of legal workflows and other processes within the legal team

- Assist with development of departmental policies for contract review and related matters

- Legal Research:

- Conduct legal research on various legal issues under the guidance of senior team members

- Summarize findings and provide practical advice on implementation

- General Legal Support:

- Provide support for general legal tasks and projects, including administrative duties as required

- Collaborate with the legal team on various initiatives and tasks

**The qualifications you need:**

- Education: Currently enrolled in a Bachelor’s or Master’s program in Law with a focus on German corporate law or related field

- Experience: Previous internship or practical experience in a legal environment is a plus but not required

- Skills:

- Strong academic background

- Excellent research and analytical skills with attention to detail

- Strong communication and organizational skills

- Ability to manage time effectively and balance work with academic commitments

- Desire to work across diverse practice areas

- Experience with AI is a plus but not required

- Language Skills: Proficiency in **German and English**, both written and verbal

**What Celonis can offer you:**

- Pioneer Innovation: Work with the global leader in Process Mining and the Process Intelligence Graph to shape the future of AI-driven business operations.

- Ownership from Day 1: Every full-time "Celonaut" is an owner, receiving Restricted Stock Units (RSUs) and merit-based refresh grants.

- Unrivaled Family Support: Benefit from our inclusive parental leave policy—24 weeks of fully paid leave for primary carers and 12 weeks for supporting carers, available from your first day of employment.

- Work-Life Integration: Enjoy Unlimited PTO (in applicable regions) and generous PTO globally, as well as a flexible hybrid work model that balances remote focus with vibrant office collaboration.

- Continuous Growth: Elevate your skills through our 70-20-10 learning framework, mentorship programs, and access to a dedicated learning platform.

- Holistic Well-being: Prioritize your health with subsidized Wellhub memberships, mental health counseling, and dedicated "Wellness Weeks" that prioritize work/life balance.

- Drive Sustainability: Participate in annual Impact Days, where you receive paid time off to volunteer for community and environmental causes with your local office, or virtually.

- Global Inclusion & Belonging: Find community through our Inclusion Think Tank and participate in our annual Inclusion Days, ensuring every voice is heard and valued.

- Value-Driven Impact: Join a mission-led organization where our core values—Live for Customer Value, The Best Team Wins, We Own It, and Earth Is Our Future—drive every decision.

**About Us:**

Celonis is the trusted platform to industrialize Enterprise AI, empowering organizations to analyze, design, and operate AI-driven processes. The Celonis Platform is powered by the Celonis Context Model, which combines process data, business knowledge, and intelligence to create a living digital twin of the enterprise that AI can understand — turning AI’s operational blind spots into operational clarity. Industry-leading companies around the world trust Celonis and its global ecosystem of partners to make their AI agents, people, systems, and processes work together, achieving transformational outcomes. Celonis is headquartered in Munich, Germany, and New York City, USA, with more than 20 offices worldwide.

Get familiar with the Celonis Process Intelligence Platform by watching this [video](https://www.youtube.com/watch?v=YR5oRJGhJYg&list=PLuVor-ZUD4pnM6G33C5D0tjXUvlTPYBRe).

**Celonis Inclusion Statement:**

At Celonis, we believe our people make us who we are and that “The Best Team Wins”. We know that the best teams are made up of people who bring different perspectives to the table. And when everyone feels included, able to speak up and knows their voice is heard - that's when creativity and innovation happen.**
**

**Your Privacy:**

Any information you submit to Celonis as part of your application will be processed in accordance with Celonis’ [Accessibility and Candidate Notices](https://www.celonis.com/careers/candidate-notices)

By submitting this application, you confirm that you agree to the storing and processing of your personal data by Celonis as described in our [Privacy Notice for the Application and Hiring Process](https://www.celonis.com/careers/privacy-notice/).

Please be aware of common job offer scams, impersonators and frauds. Learn more [here](https://www.celonis.com/careers/fraud-alert/).

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
