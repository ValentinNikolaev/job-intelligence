# Founders' Associate - Business Development & Growth (m/w/d)

Posted: 2026-09-20T08:30:28Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

SenPrima baut das erste Seniors' Universe: ein skalierbares Ökosystem für Senior Care, Digital Services und modernes Altern zuhause. Dafür suchen wir dich als Founders' Associate für Business Development & Growth. Keine Zuarbeit, sondern echte Verantwortung von Tag eins in einem High-Growth-Healthcare-Startup.

## Aufgaben

- **Strategische Projekte**: Du übernimmst komplexe Projekte eigenverantwortlich – etwa Markt-Entry in neue Regionen, Aufbau neuer Vertriebs-Kanäle oder Launch neuer Service-Modelle. Du erstellst Data-driven Entscheidungsgrundlagen und setzt Ergebnisse um. 🚀

- **Process Building & Skalierung**: Du optimierst interne Prozesse sowie Customer Acquisiton und Experience. Du baust skalierbare Frameworks, Playbooks und Tools auf.

- **Growth & Markt-Strategie**: Du analysierst Markttrends und Kund:innen-Feedback. Du führst datengestützte Pricing-, Positioning- und Expansions-Analysen durch und startest schnelle Tests für neue Angebote.

- **Business Development & Partnerschaften**: Du identifizierst neue strategische Kooperationen (Pflege-Netzwerke, Krankenkassen, Digital-Health-Partner) und leitest Go-to-Market-Strategien ab.

## Qualifikation

- **Berufserfahrung**: 1–2 Jahre relevante Erfahrung aus Top-Beratung (Big4), Venture/Startup-Umfeld oder Growth-Teams sind erforderlich. Relevante Praktika während deines Studiums sind genau so wertvoll.

- **Mindset:** Du hast Lust Selbst anzupacken und Prozesse (neu) zu gestalten; bist analytisch stark, arbeitest eigenständig und bist mit hoher Umsetzungsgeschwindigkeit unterwegs. Du verbindest Startup-Mentalität mit Ownership und echtem Drive.

- **Fähigkeiten & Tools**: Du bist datenaffin, strategisch UND praxisorientiert zugleich, sicher im Umgang mit modernen Tools (CRM, Analytics, Automation). Komfortabel mit Unsicherheit. Sehr gute Deutsch- und Englischkenntnisse runden dein Profil ab.

- **Nice-to-have**: Kenntnisse aus Healthcare, Pflege oder Medtech; Erfahrung mit B2C-SaaS oder Plattformgeschäftsmodellen; Verständnis von Growth-Marketing (Acquisition, Retention, Expansion) und Unit-Economics. Erfahrung mit Venture Capital oder VC-backed-Startups.

## Benefits

- **Echte Verantwortung**: Ab Tag eins übernimmst du eigene Projekte end-to-end: von der Analyse bis zur Umsetzung.

- **Echter Purpose**: Du arbeitest an einem Unternehmen, das modernes Altern neu denkt und konkret verbessert.

- **Arbeiten an den strategischen Themen**: statt enger Teilaufgaben.

- **Direkter Zugang zum Founder Team**: und tiefe Einblicke in unternehmerische Entscheidungen.

- **Flexibles, modernes Arbeitsumfeld**: Remote-freundlich, flexibel, mit MacBook und den Tools, die gutes Arbeiten wirklich möglich machen.

- **Schneller Aufstieg & Skill Development**:: **Du formst die nächste Phase:** wir skalieren jetzt.

Klingt nach dir? Dann schick uns einfach deinen Lebenslauf – ein CV reicht für den Start.

Wir melden uns innerhalb einer Woche bei dir.

**Bewerbungsprozess:** Teams-Call → Case Study mit dem Founder Team → Lunch & Angebot.

**Fragen vorab?** Schreib uns oder ruf kurz an:

📧 k a r r i e r e @ s e n p r i m a . d e

📞 0152 56091542

#SeniorenFürSenPrima_

SenPrima steht für Vielfalt und Chancengleichheit. Wir freuen uns auf deine Bewerbung – unabhängig von Geschlecht, Herkunft, Alter, Religion, Behinderung oder sexueller Identität._

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
