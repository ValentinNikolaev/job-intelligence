# Senior Projektsteuerer (m/w/d) – Bauprojekte & Projektmanagement

Posted: 2026-09-20T08:09:04Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**Firmenprofil**

Unser Mandant ist ein etabliertes und zukunftsorientiertes Unternehmen im Bereich der Planung, Steuerung und Realisierung anspruchsvoller Bauprojekte. Mit einem interdisziplinären Team begleitet das Unternehmen Projekte über verschiedene Leistungs- und Projektphasen hinweg und verbindet dabei fachliche Expertise mit einer partnerschaftlichen Zusammenarbeit. Ein modernes und offenes Arbeitsumfeld bietet erfahrenen Fachkräften die Möglichkeit, Verantwortung zu übernehmen und ihre Expertise gezielt einzubringen. Individuelle Weiterentwicklung, fachlicher Austausch und eigenständiges Arbeiten haben dabei einen hohen Stellenwert. Zur Verstärkung des Teams wird eine erfahrene Persönlichkeit im Bereich Projektsteuerung gesucht.

**Ihre Aufgaben**

- Sie übernehmen die Projektsteuerung anspruchsvoller Bauprojekte und verantworten dabei insbesondere die Bereiche Termine, Kosten und Qualität
- Sie klären gemeinsam mit den Projektbeteiligten die Aufgabenstellung und koordinieren die Anforderungen der Nutzer und Bauherren
- Sie übernehmen eigenverantwortlich einzelne Handlungsbereiche der Projektsteuerung, beispielsweise die Erstellung und Überwachung von Termin-, Organisations- und Zahlungsplänen
- Sie koordinieren die unterschiedlichen Projektbeteiligten und stellen eine strukturierte Kommunikation sowie transparente Dokumentation sicher
- Sie begleiten Genehmigungsverfahren und stimmen sich hierzu mit Behörden und weiteren relevanten Ansprechpartnern ab
- Sie überprüfen die Leistungen der Planungsbeteiligten hinsichtlich Qualität, Vertragserfüllung und Einhaltung der definierten Projektziele
- Sie vertreten die Projektleitung bei Besprechungen und übernehmen eine aktive Rolle in der Abstimmung mit Bauherren und Projektpartnern
- Sie begleiten die Qualitätssicherung in der Ausführung durch regelmäßige Baustellenbegehungen
- Sie unterstützen bei der Fortschreibung der Planungsziele, der Lösung von Zielkonflikten sowie bei der frühzeitigen Vorbereitung notwendiger Entscheidungen
- Sie wirken bei der Akquise und Bearbeitung neuer Projekte mit und bringen Ihre fachliche Erfahrung bereits in der Projektanbahnung ein

**Ihr Profil**

- Abgeschlossenes Studium im Bereich Architektur, Bauingenieurwesen, Baumanagement oder eine vergleichbare Qualifikation
- Mindestens 3–5 Jahre Berufserfahrung in der Planung, Projektsteuerung oder im Bauprojektmanagement
- Erfahrung in der Koordination und Steuerung komplexer Bauprojekte
- Gute Kenntnisse im Planungs-, Bau- und Werkvertragsrecht, insbesondere HOAI, VOB und BGB
- Sicherer Umgang mit MS Office und MS Project
- Ausgeprägtes Organisationsvermögen sowie eine strukturierte und eigenständige Arbeitsweise
- Kommunikationsstärke, Durchsetzungsvermögen und Verhandlungsgeschick im Umgang mit unterschiedlichen Projektbeteiligten
- Freude daran, komplexe Aufgabenstellungen zu analysieren und gemeinsam tragfähige Lösungen zu entwickeln
- Hohes Verantwortungsbewusstsein sowie ein professionelles und verbindliches Auftreten

**Benefits**

- Verantwortung für anspruchsvolle Projekte: Sie übernehmen eine zentrale Rolle in vielseitigen Bauprojekten und können Ihre Erfahrung direkt in deren erfolgreiche Steuerung einbringen.
- Gestaltungsspielraum statt Routine: Sie arbeiten eigenverantwortlich, treffen Entscheidungen und gestalten Abläufe sowie Projektstrukturen aktiv mit.
- Breites Aufgabenspektrum: Von Kosten und Terminen über Qualitätssicherung bis zur Kommunikation mit Bauherren und Projektbeteiligten erwartet Sie eine abwechslungsreiche Tätigkeit.
- Fachliche Weiterentwicklung: Regelmäßige Schulungen und individuelle Weiterbildungsmöglichkeiten unterstützen Sie dabei, Ihre Expertise kontinuierlich auszubauen.
- Interdisziplinärer Austausch: Sie arbeiten eng mit verschiedenen Fachbereichen und erfahrenen Projektpartnern zusammen und profitieren von einem vielseitigen fachlichen Umfeld.
- Moderne Arbeitskultur: Ein offenes und kollegiales Arbeitsumfeld schafft kurze Kommunikationswege und ermöglicht eine unkomplizierte Zusammenarbeit.
- Persönliche Entwicklungsperspektive: Ihre individuellen Stärken und beruflichen Ziele werden berücksichtigt und bieten Ihnen langfristige Entwicklungsmöglichkeiten.
- Attraktive Rahmenbedingungen: Neben einer attraktiven Vergütung erwarten Sie zusätzliche Mitarbeiter-Benefits.
- Langfristige Perspektive: Sie werden Teil eines etablierten Unternehmens, in dem Eigeninitiative, Expertise und nachhaltige Zusammenarbeit geschätzt werden.

**Kontakt**

Sie möchten anspruchsvolle Bauprojekte aktiv steuern und Ihre Erfahrung in einem vielseitigen Projektumfeld einbringen? Dann freuen wir uns darauf, Sie kennenzulernen und Ihnen die Position sowie die Rahmenbedingungen persönlich vorzustellen. Im gesamten Bewerbungsprozess begleiten wir Sie transparent, professionell und persönlich – von der ersten Kontaktaufnahme bis zur erfolgreichen Vermittlung.

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
