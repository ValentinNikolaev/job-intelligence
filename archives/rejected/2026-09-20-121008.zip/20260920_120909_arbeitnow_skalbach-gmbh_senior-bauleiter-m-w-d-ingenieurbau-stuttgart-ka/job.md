# Senior Bauleiter (m/w/d) Ingenieurbau – Stuttgart / Karlsruhe

Posted: 2026-09-20T08:09:04Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**Firmenprofil**

Unser Mandant ist ein erfolgreiches und etabliertes Bauunternehmen mit langjähriger Erfahrung im Ingenieurbau und realisiert anspruchsvolle Infrastrukturprojekte. Das Unternehmen steht für Qualität, Innovation und nachhaltige Bauweise und überzeugt durch eine moderne Unternehmenskultur sowie langfristige Entwicklungsperspektiven. Aufgrund der sehr guten Auftragslage suchen wir für unseren Mandanten jeweils einen Senior Bauleiter Ingenieurbau (m/w/d) für den Standort Stuttgart sowie für den Standort Karlsruhe. Sie betreuen Projekte wohnortnah an Ihrem jeweiligen Einsatzstandort und übernehmen dabei verantwortungsvolle Bauvorhaben mit großem Gestaltungsspielraum.

**Ihre Aufgaben**

- Eigenverantwortliche Leitung anspruchsvoller Ingenieurbauprojekte von der Arbeitsvorbereitung bis zur erfolgreichen Fertigstellung
- Steuerung und Koordination von Nachunternehmern, Lieferanten sowie den internen Baustellenteams
- Verantwortung für die Einhaltung von Kosten-, Termin- und Qualitätsvorgaben
- Ansprechpartner für Bauherren, Planungsbüros und weitere Projektbeteiligte während der gesamten Bauphase
- Durchführung des Nachtragsmanagements sowie Sicherstellung einer vollständigen Baustellendokumentation

**Ihr Profil**

- Erfolgreich abgeschlossenes Studium im Bauingenieurwesen oder eine vergleichbare Qualifikation
- Mehrjährige Berufserfahrung als Bauleiter im Ingenieurbau
- Fundierte Kenntnisse der VOB sowie im Bauvertrags- und Nachtragsmanagement
- Ausgeprägte Führungs- und Organisationskompetenz sowie unternehmerisches Denken
- Selbstständige, strukturierte und lösungsorientierte Arbeitsweise

**Benefits**

- Unbefristete Festanstellung in einem wirtschaftlich erfolgreichen Bauunternehmen
- Verantwortungsvolle Großprojekte im Ingenieurbau mit langfristiger Perspektive
- Attraktive Vergütung inklusive zusätzlicher Sozialleistungen
- Dienstwagen zur privaten Nutzung
- Individuelle Weiterbildungs- und Entwicklungsmöglichkeiten
- Moderne Arbeitsmittel und digitalisierte Bauprozesse

**Kontakt**

Haben wir Ihr Interesse geweckt? Dann freuen wir uns auf Ihre Bewerbung mit Angabe Ihres frühestmöglichen Eintrittstermins und Ihrer Gehaltsvorstellung. Nach Eingang Ihrer Unterlagen setzen wir uns zeitnah mit Ihnen in Verbindung und besprechen gemeinsam die weiteren Schritte im Bewerbungsprozess. Selbstverständlich behandeln wir Ihre Bewerbung während des gesamten Prozesses vertraulich.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
