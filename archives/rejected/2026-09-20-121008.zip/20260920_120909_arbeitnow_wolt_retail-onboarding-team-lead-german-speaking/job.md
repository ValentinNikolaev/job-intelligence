# Retail Onboarding Team Lead - German speaking

Posted: 2026-09-20T08:55:27Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

## About Wolt

At Wolt, we create technology that brings joy, simplicity and earnings to the neighborhoods of the world. In 2014 we started with delivery of restaurant food. Now we’re building the delivery of (almost) everything and you’ll find us in over 500 cities in 30 countries around the world. In 2022 we joined forces with DoorDash and together we keep on dreaming big and expanding across the globe.

Working at Wolt isn’t always easy, but it’s definitely exciting. Here you’ll learn more, build more, and ship more than in most other companies. You’ll be challenged a lot, but also have a lot of fun on the way. So, if you’re a self-starter with drive and entrepreneurial spirit, this could be the ride of your life.

As part of our Onboarding Operations team, the **Retail Onboarding Team Lead** plays a key role in ensuring that our Retail partners are seamlessly and efficiently onboarded onto the Wolt platform. Reporting to the Country Lead Onboarding Operations, you will lead a dynamic team focused on onboarding new Retail partners while driving continuous process improvements and collaborating cross-functionally to ensure high-quality results.

The ideal candidate has a mix of leadership, operational, and onboarding experience, combined with a proactive, problem-solving approach to lead the team to success. If you are passionate about operational excellence, love working with data, and enjoy driving cross-functional projects, this role is for you.

## **What you’ll be doing**

- **Team Leadership**: Manage a team of 8 people, ensuring the seamless onboarding of Retail partners, focusing on quality, efficiency, and adherence to regulations.

- **Drive Retail Onboarding**: Ensure timely onboarding of Retail partners and maintain high-quality standards. Be responsible for meeting KPIs while maintaining excellent customer experiences.

- **Process Optimization**: Continuously improve and streamline onboarding processes, particularly for large product assortments (e.g. supermarkets) and grocery partners, to increase efficiency and reduce operational bottlenecks.

- **Cross-Functional Projects**: Collaborate with Product, Sales, Account Management and Catalog teams on projects aimed at improving the Retail onboarding process and overall operational excellence.

- **Retail Onboarding Advocate**: Act as the main point of contact (POC) for the Retail department, representing Retail Onboarding in discussions about product changes and other key decisions.

- **KPI Monitoring**: Set, track, and analyze KPIs to ensure optimal team performance

- **Data Quality Focus**: Ensure data accuracy and quality, especially in relation to large product assortments in the supermarket and grocery segments, ensuring that all product information is reliable, up to date, and complete.

- **LMIV Expertise: **Become an expert in LMIV (Lebensmittelinformationsverordnung) regulations, ensuring that all processes, particularly in grocery and supermarket onboarding, comply with these legal standards.

## **What’s in it for you**

- A key role in shaping the Retail Onboarding operations at Wolt.

- A fast-growing and dynamic environment with opportunities for career growth in the retail and e-commerce sectors.

- Attractive salary package and benefits.

- Discounts on Wolt orders.

- Comprehensive internal education and training.

- Flexible working hours and 30 days of paid vacation.

## **Our humble expectations**

- **Leadership Experience**: Minimum of 3 years of leadership experience, ideally with a focus on change management and team leadership.

- **Work Experience**: 3-5 years of relevant work experience, preferably in a marketplace, e-commerce, or similar fast-paced environment operational leadership role.

- **Onboarding Experience**: Experience in onboarding processes is highly desirable.

- **Educational Background**: A bachelor’s degree in Business, Economics, Engineering or a related field.

- **Analytical Skills**: Strong analytical capabilities to monitor KPIs, assess team performance, and drive improvements using data-driven insights.

- **Communication Skills**: Excellent interpersonal and communication skills for effective cross-functional collaboration and stakeholder management.

- **Detail-Oriented**: Strong attention to detail, with the ability to maintain high-quality standards in all onboarding processes.

- **Proactive and Ownership Mindset**: Ability to work in a fast-paced environment, proactively identify areas for improvement, and drive changes independently.

## **About You**

- You are a proactive leader who takes initiative and drives results.

- You have experience managing a team of 5+ people.

- You thrive in a dynamic environment and can handle multiple tasks simultaneously, particularly in the fast-paced e-commerce or retail marketplace space.

- You have excellent communication skills and can work effectively with various stakeholders.

- You are detail-oriented and committed to maintaining high standards of quality.

- You love tackling complex operational challenges and are quick to jump into the details to improve key processes or systems.

- You have a bias for action and are eager to use the best available data and insights to make concrete decisions.

- You are excited to work in a fast-paced, constantly evolving, growth company.

- You are driven to constantly improve, challenge the status quo, and deliver exceptional results, especially in supermarket and grocery onboarding.

## Our Commitment to Diversity and Inclusion

We’re committed to growing and empowering a more inclusive community within our company, industry, and cities. That’s why we hire and cultivate diverse teams of people from all backgrounds, experiences, and perspectives. We believe that true innovation happens when everyone has room at the table and the tools, resources, and opportunity to excel.

*Beware of recruitment scams: DASH Brands will never ask you to pay money or share sensitive financial information during hiring — learn more about DASH Brands' legitimate recruiting process at* [*careersatdoordash.com/recruitment-scam-awareness*](http://careersatdoordash.com/recruitment-scam-awareness)*.*

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
