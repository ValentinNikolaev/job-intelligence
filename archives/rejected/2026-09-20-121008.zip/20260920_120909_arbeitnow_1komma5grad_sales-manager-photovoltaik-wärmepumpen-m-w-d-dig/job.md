# Sales Manager Photovoltaik & Wärmepumpen (m/w/d) – Digital Sales

Posted: 2026-09-20T08:09:31Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**1KOMMA5°**

**Werde Teil des CleanTech Unicorns und gestalte den größten Energiemarkt der Welt!
**
Bei 1KOMMA5° verfolgen wir eine klare Vision: Living on wind and sunlight forever for free.

Mit unserer KI-basierten Softwareplattform Heartbeat AI und Premium-Hardware bauen wir das Energiesystem der Zukunft.

Solar, Speicher, Wärmepumpe und E-Mobilität denken wir nicht einzeln, sondern steuern sie als intelligentes, integriertes Gesamtsystem. Direkt verbunden mit dem Strommarkt – in Echtzeit, vollautomatisiert. So wird Energie dann genutzt, wenn sie erneuerbar verfügbar und besonders günstig ist. Bis 2030 wollen wir 1,5 Millionen Haushalte auf erneuerbare Energien umstellen. Über 3.000 Menschen arbeiten jeden Tag daran, an mehr als 80 Standorten weltweit, von Finnland bis Australien.

**Wir wachsen rasant – und suchen Vertriebstalente, die nicht nur beraten, sondern Kunden begeistern und erfolgreich zum Abschluss führen wollen.**

**Deine Position**

- **High-Tech Sales statt Kaltakquise: **Als Sales Manager bist du die zentrale Ansprechperson für private Hausbesitzer, die ihre Energieversorgung mit Photovoltaik, Speicher und Wärmepumpe neu denken wollen. Du analysierst ihre individuellen Anforderungen, entwickelst die passende Energielösung und begleitest sie vollständig digital bis zum Vertragsabschluss.
- **Qualifizierte Leads statt Kaltakquise: **Du führst Beratungs- und Verkaufsgespräche mit vorqualifizierten, warmen Leads, die aktiv über unsere Website auf uns zukommen. Darüber hinaus reaktivierst du Interessenten, die bereits mit uns in Kontakt standen.
- **Beratung mit echtem Mehrwert: **Du verkaufst keine Standardlösung, sondern ein intelligentes Energiesystem mit konkretem wirtschaftlichem und ökologischem Mehrwert. Du verstehst die Bedürfnisse deiner Kunden und zeigst ihnen verständlich, wie Photovoltaik, Speicher, Wärmepumpe und Heartbeat AI optimal zusammenspielen.
- **Verantwortung für den gesamten Sales Cycle: **Vom ersten Videocall über die Bedarfsanalyse und Angebotserstellung bis zur digitalen Vertragsunterschrift steuerst du den gesamten Vertriebsprozess eigenständig. Dabei behältst du deine Pipeline im Blick, fasst konsequent nach und führst deine Kunden strukturiert zum Abschluss.
- **100 % digitaler Vertrieb: **Deine Beratung findet vollständig digital über moderne Videokonferenz-Tools statt. Kein klassischer Außendienst, keine langen Fahrtzeiten und kein Führerschein erforderlich – stattdessen kannst du dich vollständig auf deine Kunden und deine Abschlüsse konzentrieren.

**Dein Profil**

- **Vertriebserfahrung & Sales-Mindset: **Du bringst Erfahrung im Vertrieb mit – idealerweise im B2C-Vertrieb, Inside Sales oder Telesales. Du hast Freude am Verkaufen, arbeitest zielorientiert und willst deinen Erfolg aktiv selbst beeinflussen.
- **Ausgeprägte Abschlussstärke: **Du erkennst Kaufsignale, gehst souverän mit Einwänden um und bleibst konsequent am Ball. Dabei schaffst du die richtige Balance aus überzeugender Beratung, Verbindlichkeit und Abschlussorientierung.
- **Interesse an Technologie und Energie: **Erfahrung im Bereich erneuerbare Energien ist ein Plus, aber kein Muss. Entscheidend ist, dass du Lust hast, dich intensiv mit Photovoltaik, Wärmepumpen, Energiemanagement und dem Strommarkt auseinanderzusetzen. Mit unserem strukturierten Onboarding vermitteln wir dir das notwendige Produkt- und Branchenwissen.
- **Starke Kommunikation: **Du kommunizierst fließend auf Deutsch und schaffst es, auch komplexe technische Zusammenhänge verständlich, überzeugend und auf Augenhöhe zu erklären.
- **Team vor Ort: **Du wohnst in Berlin oder Umgebung und hast Lust, regelmäßig mit deinem Team in unserem Berliner TechLab zusammenzuarbeiten.

**Benefits**

**Top-Bedingungen für deinen Vertriebserfolg**

- **Attraktives Vergütungsmodell ohne Provisionsdeckel: **Dich erwarten ein starkes Fixgehalt, ein unbefristeter Arbeitsvertrag und eine ungedeckelte Provision. Überdurchschnittliche Leistung zahlt sich bei uns unmittelbar aus.
- **Ein Produkt mit echtem Wettbewerbsvorteil: **Mit Heartbeat AI und unserem integrierten Energiesystem verkaufst du eine technologisch führende Lösung, die Photovoltaik, Speicher, Wärmepumpe und dynamischen Stromtarif intelligent miteinander verbindet.
- **Moderne Arbeitsumgebung & Apple Equipment: **MacBook und iPhone gehören ebenso zu deiner Ausstattung wie eine moderne Arbeitsumgebung in unserem Berliner TechLab.
- **Echte Entwicklungsmöglichkeiten: **1KOMMA5° wächst international und entwickelt sich schnell weiter. Damit entstehen kontinuierlich neue Verantwortungsbereiche und Entwicklungsmöglichkeiten – fachlich wie persönlich.
- **Wellpass: **Für nur 10 € monatlich erhältst du Zugang zu mehr als 10.000 Fitness- und Wellnessangeboten, darunter zahlreiche Premium-Studios und Sportangebote.
- **Weitere Benefits: **Flexible Arbeitszeiten, hybride Arbeitsmöglichkeiten, regelmäßige Team- und Company-Events sowie attraktive Corporate Benefits über FutureBens.

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
