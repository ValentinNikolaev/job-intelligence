# Associate Applied (AI) Value Engineer (DACH) - Orbit Program

Posted: 2026-09-20T08:55:36Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Celonis is the trusted platform to industrialize Enterprise AI. At our core is the Celonis Context Model — which combines process data, business knowledge, and intelligence into a living digital twin of the enterprise that AI can actually understand, turning AI's operational blind spots into operational clarity. World's leading companies trust Celonis and its global ecosystem of partners to make their AI agents, people, systems, and processes work together, achieving transformational outcomes. We believe there's a massive opportunity to unlock global productivity and sustainability by giving AI the context to understand how every business process really works. Join our mission to make processes work for people, companies, and the planet.

**Location: Madrid for an onboarding period of 2 years and a possible relocation to Munich after. Customer base will be in Germany/DACH area, involving travel to meet clients in person.**

### **Role Description**

As an Applied (AI) Value Engineer you are pushing the envelope in solving business-critical problems for our customers. You are part of our Value Engineering team and are the trusted advisor for customers working on the intersection of technology and business. You will be working with our most strategic customers, understanding their objectives and key challenges, and building Celonis solutions using the world’s leading Process Intelligence (PI) platform in combination with the largest AI and ML technology partners, such as Microsoft, OpenAI and Databricks. With Celonis’ Process Intelligence (PI) platform we feed operational context to AI so it understands our customers’ business and enables them to industrialize AI unlocking real ROI on AI deployments and at scale. There is no AI without PI. You will prototype these solutions, demonstrate their value to Executives and ensure successful implementation, adoption and value realization in order to increase the footprint of Celonis at those customers.

### **Launch Your Enterprise Software Career - Orbit Graduate program**

Kickstart your career in enterprise software through our immersive 12-month Orbit Program.

During the Orbit Graduate program, you will be joining the Global VE Center of Excellence which is an international, diverse, and dynamic organization at the core of the Celonis Value Engineering team supporting our local field teams. As a team, we enjoy working in a fast-paced environment and share a sense of belonging to an international community that wants to learn and grow together. The team culture is one based on building trust, continuous development, and improvement through coaching & mentoring.

This program offers a unique blend of client engagements, dedicated mentorship, and a strong team culture where collaboration and shared success are paramount. You'll leverage your technical background to develop essential skills, build lasting client relationships, and establish yourself as a trusted advisor, paving the way for significant career growth within Celonis.

Your journey begins with comprehensive onboarding and enablement, followed by hands-on experience in customer engagements and targeted training. You will gain expertise in:

- Discovery & AI Solutioning

- Building and coding within the Celonis platform (SQL, PQL and Python)

- Scoping business and technical requirements

- Effectively handling objections

- Developing industry domain knowledge

- Delivering impactful presentations and demos

- Understanding value selling and realization

- Managing customer accounts

### **What You'll Do:**

- **AI Discovery & Solutioning:** Understand customers AI strategy and business critical challenges. As Celonis product & domain expert, find the best problem-solution fit and translate customer requirements into innovative solutions that move the needle

- **Hackathons & Prototyping:** Think out of the box, have a “can-do“ attitude and don’t shy away from complex problems. Leverage cutting edge AI technologies to rapidly build creative prototypes in customer hackathons solving business critical problems

- **Agentic Process Transformation:** Support our customers in achieving real ROI out of AI deployments at scale enabling a fundamental shift in business operations from traditional, rule-based automation to the use of autonomous AI agents empowered by our Celonis Process Intelligence Platform

- **Proof Projects: **End-to-end execution of business-critical Proof-of-Value projects showcasing the value of Celonis Process Intelligence tailored to customers and align our solutions with their AI strategy.

- **Specialize in Domains or Industries:** To scale knowledge across the organization specialize in domains (e.g. supply chain) and industries

- **Business Impact Presentations:** Articulate and quantify strategic business value for customers, delivering impactful presentations to senior executives to ensure successful value realization for customers.

- **Ensure Successful Project Outcome: **AI Solution Consultants stay involved with projects until agreed value & adoption thresholds are reached

- **Best Practice Modeling:** Contribute to the Global Value Engineering Center of Excellence by creating reusable collateral, best practices, and tools.

### **What You Need:**

- Degree in Engineering, Data Analytics/Science, Computer Science, Mathematics, or a related STEM field.

- Excellent academic performance

- Extensive internship experience or 1-2 years of full-time work experience. Ideally at the intersection of business and technology.

- Understanding of generative AI techniques like RAG, few shot learning, prompt/context engineering, multi-agent orchestration, multimodal understanding, or fine-tuning that are used to build high-impact use cases like intelligent chatbots and automated text processors.

- Good knowledge of Python and common ML libraries (such as LangChain, pandas, pydantic, sklearn, PyTorch) as well as data engineering tools and technologies.

- Excellent analytical and creative problem-solving skills, with the ability to apply technology to business challenges.

- A customer-centric mindset with a focus on delivering value.

- Confidence in presenting to diverse audiences.

- A proactive approach to problem-solving, with a willingness to learn from mistakes.

- Curiosity, self-motivation, a commitment to continuous learning, and the desire to thrive in a fast-paced, high-growth environment.

- Strong organizational skills with the ability to prioritize and execute on deadlines.

- Excellent communication skills and** fluency in German and English (must). **

- Foundational business acumen and domain understanding, e.g. in areas such as Supply Chain.

**Bonus Points:**

- Degrees combining technical (e.g., Computer Science, Data Science) and business (e.g., Economics, Marketing) skills.

- Customer-facing, customer success/service, or sales experience.

- Hands-on experience with technical Proof of Concept projects

- Hands-on experience building agentic systems using LLM orchestration, RAG, function calling, and prompt engineering

- Working knowledge of tools in the LLM ecosystem such as LangChain, LlamaIndex, or other OSS packages.

- Supply Chain process experience (Procurement, Order Management, Inventory Management, Production).

- Experience modeling ROI and TCO for business case justification.

- Experience with ERPs such as SAP and/or Oracle

**What Celonis can offer you:**

- Pioneer Innovation: Work with the global leader in Process Mining and the Process Intelligence Graph to shape the future of AI-driven business operations.

- Ownership from Day 1: Every full-time "Celonaut" is an owner, receiving Restricted Stock Units (RSUs) and merit-based refresh grants.

- Unrivaled Family Support: Benefit from our inclusive parental leave policy—24 weeks of fully paid leave for primary carers and 12 weeks for supporting carers, available from your first day of employment.

- Work-Life Integration: Enjoy Unlimited PTO (in applicable regions) and generous PTO globally, as well as a flexible hybrid work model that balances remote focus with vibrant office collaboration.

- Continuous Growth: Elevate your skills through our 70-20-10 learning framework, mentorship programs, and access to a dedicated learning platform.

- Holistic Well-being: Prioritize your health with subsidized Wellhub memberships, mental health counseling, and dedicated "Wellness Weeks" that prioritize work/life balance.

- Drive Sustainability: Participate in annual Impact Days, where you receive paid time off to volunteer for community and environmental causes with your local office, or virtually.

- Global Inclusion & Belonging: Find community through our Inclusion Think Tank and participate in our annual Inclusion Days, ensuring every voice is heard and valued.

- Value-Driven Impact: Join a mission-led organization where our core values—Live for Customer Value, The Best Team Wins, We Own It, and Earth Is Our Future—drive every decision.

**About Us:**

Celonis is the trusted platform to industrialize Enterprise AI, empowering organizations to analyze, design, and operate AI-driven processes. The Celonis Platform is powered by the Celonis Context Model, which combines process data, business knowledge, and intelligence to create a living digital twin of the enterprise that AI can understand — turning AI’s operational blind spots into operational clarity. Industry-leading companies around the world trust Celonis and its global ecosystem of partners to make their AI agents, people, systems, and processes work together, achieving transformational outcomes. Celonis is headquartered in Munich, Germany, and New York City, USA, with more than 20 offices worldwide.

Get familiar with the Celonis Process Intelligence Platform by watching this [video](https://www.youtube.com/watch?v=YR5oRJGhJYg&list=PLuVor-ZUD4pnM6G33C5D0tjXUvlTPYBRe).

**Celonis Inclusion Statement:**

At Celonis, we believe our people make us who we are and that “The Best Team Wins”. We know that the best teams are made up of people who bring different perspectives to the table. And when everyone feels included, able to speak up and knows their voice is heard - that's when creativity and innovation happen.**
**

**Your Privacy:**

Any information you submit to Celonis as part of your application will be processed in accordance with Celonis’ [Accessibility and Candidate Notices](https://www.celonis.com/careers/candidate-notices)

By submitting this application, you confirm that you agree to the storing and processing of your personal data by Celonis as described in our [Privacy Notice for the Application and Hiring Process](https://www.celonis.com/careers/privacy-notice/).

Please be aware of common job offer scams, impersonators and frauds. Learn more [here](https://www.celonis.com/careers/fraud-alert/).

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
