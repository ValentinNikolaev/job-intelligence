# (Sr.) Medical Scientific Liaison Germany - South

Posted: 2026-09-20T05:55:14Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**About Acadia Pharmaceuticals**

Acadia is committed to turning scientific promise into meaningful innovation that makes the difference for underserved neurological and rare disease communities around the world. Our commercial portfolio includes the first and only FDA-approved treatments for Parkinson’s disease psychosis and Rett syndrome. We are developing the next wave of therapeutic advancements with a robust and diverse pipeline that includes mid- to late-stage programs in Alzheimer’s disease psychosis and Lewy body dementia psychosis, along with earlier-stage programs that address other underserved patient needs. At Acadia, we’re here to be their difference.

**Position Summary:**

Medical Science Liaison (MSL) for Germany plays a pivotal role in advancing our mission in rare pediatric diseases, with a core focus on Rett syndrome. This field-based role serves as a trusted scientific partner to healthcare professionals, researchers, advocacy groups, and decision makers across Germany. The MSL drives scientific exchange, supports evidence generation, and helps ensure patients, caregivers, and clinicians have access to high-quality scientific and medical information about Acadia’s therapeutic innovations.

**Scope:**

- **Scientific Engagement & KOL Management** – Build and maintain trusted relationships with key opinion leaders and rare disease networks.

- **Insight Generation & Evidence Support** – Gather field insights and support clinical research, IIS, and real-world evidence initiatives.

- **Cross-Functional Collaboration** – Act as an internal scientific expert, supporting cross-functional national teams

- **Medical Governance & Compliance** – Ensure adherence to local and global standards in all medical activities and communications.

**Primary Responsibilities:**

- Act as the primary point of contact for scientific exchange in Germany, building trusted relationships with thought leaders, centers of excellence, and advocacy groups.

- Identify and maintain impactful collaborations opportunities, including publications, advisory boards, IIS, educational initiatives, speaker programs.

- Support Key Account Managers in engaging influential experts while ensuring compliance with local regulations.

- Collect and communicate field insights to inform medical strategy, publications, and messaging.

- Respond to unsolicited medical information requests in line with global standards.

- Support Phase IV studies, IIS, registries, and real-world evidence projects by identifying sites and acting as a liaison.

- Represent Acadia at congresses and scientific events; contribute to planning and execution of symposia and programs.

- Partner closely with Medical Affairs leadership to support patient advocacy initiatives, build fruitful relationships with German patient advocacy groups

- Deliver internal medical training and scientific support to cross-functional teams.

- Collaborate with Commercial, Market Access, Regulatory, and international teams to ensure consistent medical strategy and compliant communication.

- Ensure medical governance in field activities, including documentation and process improvement.

**Education / Experience / Skills**.

- A advanced scientific or medical degree or a related field is required; an MD or PhD, PharmD is preferred.The ideal candidate will have 6-8 years of relevant industry experience, including 3-5 years field-based MSL roles in CNS/neuroscience or rare disease.

- Proven ability to present complex scientific data clearly and effectively.

- Fluency in German and English.

- Clear organizational skills, independent working style, and fast learning mindset, with a collaborative approach.

- Strong interpersonal skills with an open, collaborative mindset; embraces diversity and different cultural perspective

- Readiness to travel up to 70%. Travel commitments will include participation at international Medical Affairs meetings, team meetings, and attendance at both national and international congresses.

**What we offer US-based Employees:**

- Competitive base, bonus, new hire and ongoing equity packages

- Medical, dental, and vision insurance

- Employer-paid life, disability, business travel and EAP coverage

- 401(k) Plan with a fully vested company match 1:1 up to 5%

- Employee Stock Purchase Plan with a 2-year purchase price lock-in

- 15+ vacation days

- 13 -15 paid holidays, including office closure between December 24th and January 1st

- 10 days of paid sick time

- Paid parental leave benefit

- Tuition assistance

**EEO Statement (US-based Employees): **Studies have shown that women and people of color are less likely to apply for jobs unless they believe they meet every one of the qualifications in the exact way they are described in job postings. We are committed to building a diverse, equitable, inclusive, and innovative company, and we are looking for the BEST candidate for the job. That candidate may be one who comes from a less traditional background or may meet the qualifications in a different way. We strongly encourage you to apply, especially if the reason you are the best candidate isn’t exactly what we describe here.

It is the policy of Acadia to provide equal employment opportunities to all employees and employment applicants without regard to considerations of race, including related to hairstyle, color, religion or religious creed, sexual orientation, gender, gender identity, gender expression, gender transition, country of origin, ancestry, citizenship, age, physical or mental disability, genetic information, legally-protected medical condition or information, marital status, domestic partner status, family care status, military caregiver status, veteran or military status (including reserve status, National Guard status, and military service or obligation), status as a victim of domestic violence, sexual assault or stalking, enrollment in a public assistance program, or any basis protected under federal, state or local law.

As an equal opportunity employer, Acadia is committed to a diverse workforce. If you are a qualified individual with a disability or a disabled veteran, you have the right to request a reasonable accommodation. Furthermore, you may request additional support if you are unable or limited in your ability to use or access Acadia’s career website due to your disability, along with any accommodations throughout the interview process. To request or inquire about your reasonable accommodation, please complete our [Reasonable Accommodation Request Form](https://app.smartsheet.com/b/form/43db301ada19415fa7ab365633993f33) or contact us at Please note that reasonable accommodations granted throughout the recruiting process are not guaranteed to be the same accommodations given if hired. A new request will need to be submitted for any ADA accommodations after starting employment.

**California Applicants: **Please see [Additional Information for California Residents](https://acadia.com/en-us/legal-policies/privacy#18) within our Privacy Policy.

**Canadian Applicants: **Please see [Additional Information for Canadian Residents](https://acadia.com/en-gb/legal-policies/privacy#17) within our Privacy Policy.

**Applicants in the European Economic Area, Switzerland, the United Kingdom, and Serbia: **Please see [Additional Information for Individuals in the European Economic Area, Switzerland, the United Kingdom, and Serbia](https://acadia.com/en-gb/legal-policies/privacy#16) within our Privacy Policy.

**Notice to Search Firms/Third-Party Recruitment Agencies (Recruiters): **The Talent Acquisition team manages the recruitment and employment process for Acadia Pharmaceuticals Inc. (“Acadia”). Acadia does not accept resumes from recruiters or search firms without an executed search agreement in place. Resumes sent to Acadia employees in the absence of an executed search agreement will not obligate Acadia in any way with respect to the future employment of those individuals or potential remuneration to any recruiter or search firm. Candidates should never be submitted directly to our hiring managers or employees.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
