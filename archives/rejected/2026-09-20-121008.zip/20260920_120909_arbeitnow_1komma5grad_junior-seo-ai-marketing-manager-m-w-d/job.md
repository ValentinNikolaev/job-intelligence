# (Junior) SEO & AI Marketing Manager (m/w/d)

Posted: 2026-09-20T08:09:31Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**1KOMMA5°**

Bei **1KOMMA5°** verfolgen wir eine Vision: **Living on wind and sunlight forever for free**. Dafür bauen wir mit Heartbeat AI das Energiesystem der Zukunft. Bist du dabei?
Wir bringen regionales Handwerk und skalierbare Software zusammen: Solar, Speicher, Wärmepumpe und E-Mobilität denken wir nicht einzeln, sondern steuern sie als intelligentes, integriertes Gesamtsystem in unserem virtuellen Kraftwerk. Direkt verbunden mit dem Strommarkt – in Echtzeit, vollautomatisiert. So wird Energie dann genutzt, wenn sie erneuerbar verfügbar und besonders günstig ist. Bis 2030 wollen wir 1,5 Millionen Haushalte auf erneuerbare Energien umstellen. Über 3.000 Menschen arbeiten jeden Tag daran, an mehr als 80 Standorten weltweit, von Finnland bis Australien.

**Du willst Verantwortung übernehmen und Lösungen bauen, die wirklich zählen? Bewirb dich jetzt und gestalte mit uns die Energiewelt von morgen.**

**Deine Position**

Wir suchen einen (Junior) SEO & AI Marketing Manager, der*die mit analytischem Scharfsinn und technologischer Neugier unsere Sichtbarkeit aufs nächste Level hebt. Du verstehst modernes SEO nicht als statische Optimierung, sondern als dynamisches Ökosystem, das du durch automatisierte Workflows und KI aktiv skalierst. In dieser Rolle bist du die Schnittstelle zwischen Strategie, Technik und Content. Du stellst die Website-Hygiene sicher und steuerst unsere internationalen Teams mit präzisen Briefings.

Deine Aufgaben umfassen:

-

**GEO & AEO (Modern Search): **Optimierung unseres Contents für Generative Engine Optimization und Answer Engine Optimization, um in KI-gestützten Suchergebnissen (ChatGPT, Perplexity etc.) maximale Präsenz zu erzielen.

-

**Automation & KI-Workflows:** Eigenständige Konzeption und Weiterentwicklung von automatisierten SEO-Prozessen (z.B. automatisierte Briefing-Erstellung) unter Einsatz moderner KI-Tools.

-

**Website-Hygiene & Monitoring: **Aufsetzen und Überprüfen automatisierter Sanity-Checks und technischer Crawls (z.B. mit Screaming Frog) sowie das direkte Ableiten operativer Maßnahmen.

-

**Keywordrecherche & Content-Implementierung:** Durchführung von Keyword- und Wettbewerbsrecherchen sowie Qualitätssicherung (UX, Struktur, Scannbarkeit für KI) bei der Implementierung auf der Website.

- **Internationale Steuerung:** Standortübergreifende Zusammenarbeit mit globalen Teams, um strategische Vorgaben in operative Briefings zu übersetzen und lokale Markt-Insights effizient zu nutzen.

**Dein Profil**

- Berufserfahrung: Mindestens 2-5 Jahre relevante Erfahrung im Bereich SEO (Agentur oder Inhouse).
-

Ausbildung: Abgeschlossenes Studium (BWL, Medienwissenschaften, Wirtschaftsinformatik, Marketing) oder vergleichbare Qualifikation.

-

Tech-Stack & AI-Affinität: Sicherer Umgang mit gängigen SEO-Tools (Search Console, Ahrefs, SISTRIX, Screaming Frog) sowie erste Erfahrung mit Automatisierungen mittels LLMs, n8n, Make oder Zapier.

-

Analytisches Denken & UX-Auge: Du liebst Daten, erkennst komplexe Zusammenhänge selbstständig, wandelst sie in Action-Items um und bringst ein starkes Gespür für User Intent und Content-Layouts mit.

-

Modern Search Mindset: Du verfolgst die Entwicklung von LLMs und AI Search.

-

Hands-on-Mentalität: Du packst Projekte proaktiv an, arbeitest lösungsorientiert und behältst auch bei vielen parallelen Tasks den Überblick. Strategischem Wandel (AI Movement) gegenüber bist du besonders resilient.

-

Kommunikation & Sprache: Fließendes Deutsch und Englisch. Du hast keine Scheu vor internationalen Stakeholdern und kannst komplexe SEO-Themen für Laien verständlich herunterbrechen. Weitere Sprachen sind ein Plus.

**Benefits**

- Du hast die Möglichkeit in unserem **brandneuen** Büro in **Berlin** zu arbeiten und **hybrid**
- Nutze dein **technisches Equipment **auch abseits der Arbeit in deiner **Freizeit**
- Du bist Teil eines **schnell wachsenden Unternehmens** mit viel **Entwicklungspotenzi****al**, wo du **eigenständig** etwas aufbauen kannst und deinen Impact spürst
- Bewege dich in **flachen Hierarchien**, übernimm schon während deiner Einarbeitung **Verantwortung** und arbeite direkt mit Teilen des Managements zusammen
- Mit deiner Arbeit unterstützt du den Megatrend **“Energie- und Mobilitätswende”** und leistest einen **konkreten Beitrag** zum **nachhaltigen** Umbau unserer Energie-Infrastruktur
- Sei aktiv und nutze das Angebot von über 7.600 Sportpartnern mit dem **EGYM-Wellpass**
- Ob Citybike oder E-Bike – mit unserem **Jobrad-Leasing** bleibst du flexibel und bist umweltfreundlich unterwegs**
**
- Profitiere von **Benefits & Rabatten** durch Futurebens

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
