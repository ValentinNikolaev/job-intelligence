# Senior Backend Engineer

Posted: 2026-08-04T07:55:27.3230000

## Rejection

- Category: tech_stack
- Reason: role does not mention Go/Golang or PHP

...About the Role 
As a **Senior Backend Engineer **at Quo, you will spend a majority of your time coding, architecting, and owning moderate to... ..., and a flexible PTO policy. 
Who we are 
As a fully **remote **company, we thrive as a team. We are curious, ambitious, and...
