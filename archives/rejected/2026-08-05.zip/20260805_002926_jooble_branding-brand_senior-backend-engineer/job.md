# Senior Backend Engineer

Posted: 2026-08-04T07:29:43.0930000

## Rejection

- Category: tech_stack
- Reason: role does not mention Go/Golang or PHP

...**Senior Backend Engineer **
Branding Brand is hiring a Senior Backend Engineer for a 12-week contract engagement (June 2026 to August 2026) to... ...delivery, and scaling under burst load. 
This is a fully **remote **contract position. The candidate must be located in the United...
