# Social Media Manager (f/m/d)

Posted: 2026-08-24T11:40:28Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

## **Über uns:**

Zenjob ist eine KI-gestützte Plattform für flexible Personallösungen, die seit 2015 Unternehmen und temporäre Arbeitskräfte effizient miteinander verbindet. Unternehmen buchen über unsere Plattform kurzfristig einsatzbereite Mitarbeitende in Echtzeit, während Studierende unsere App nutzen, um Nebenjobs zu finden, die sich optimal mit ihrem Studium vereinbaren lassen. Über 40.000 Studierende und 1.000 Partnerunternehmen aus Logistik, Einzelhandel und Gastronomie in allen großen deutschen Städten teilen unseren Glauben daran, dass gute Arbeit kein Zufall ist. Gute Arbeit beginnt hier.

Als Social Media Manager (w/m/d) verantwortest du unsere organischen Social-Kanäle und unser Influencer Marketing end-to-end. Du übersetzt unsere Markenstrategie in platform-native Formate, die Gen Z tatsächlich erreichen, und baust Zenjob als die verlässliche Adresse für Studierende auf, die einen Nebenjob suchen. Für viele Talents ist Social der erste Kontakt mit Zenjob, du gestaltest diesen Moment und bindest die Talente dauerhaft an die Marke. Gleichzeitig machst du Zenjob auf der B2B-Seite sichtbar und lieferst dem Growth-Team die Creatives und Insights, die auch bezahlt funktionieren.

## **Deine Aufgaben:**

-

Du entwickelst, **optimierst und verantwortest **unsere organische Social Media -Strategie für Talents (B2C) und Business Kunden (B2B)

-

Du definierst pro Plattform Rolle, Zielgruppe und Formatlogik (TikTok, Instagram, LinkedIn)

-

Du erstellst den Redaktionsplan und die Produktion zusammen mit dem Inhouse Studio hands-on: Konzept, Skript, Shooting, Schnitt, Copy und Publishing mit schnellen Turnarounds

-

Du entwickelst gemeinsam mit dem Brand Lead innovative, platform-native Kampagnenideen und übersetzt sie in wiederholbare Formate

-

Du betreust und verantwortest das Community Management über alle Kanäle, etablierst Guidelines und einen Eskalationspfad für kritische Themen und spielst wiederkehrende Fragen an Operations, Support und Product zurück

-

Du verantwortest unser Influencer Marketing end-to-end: Identifikation und Auswahl passender Creator, Verhandlung und Vergütungslogik, Briefings und Freigaben sowie die Bewertung der Performance gegen klare Ziele. Dabei steuerst du dein Influencer-Budget eigenständig und setzt auf glaubwürdige Stimmen statt auf reine Reichweite

-

Du managst ein Netzwerk aus Creators und Zenjobbern, die authentisch aus der Nutzerperspektive erzählen, nutzt User-Generated Content systematisch als Content- und Testing-Quelle und steuerst Freelancer sowie Agenturen

-

In enger Zusammenarbeit mit Analytics schaffst du die Grundlagen für die Messbarkeit deiner Aktivitäten (Reach, Engagement, Follower-Growth, Beitrag zu organischen Sign-ups)

-

Du führst Trendanalysen für unsere Social Media Channels durch und beobachtest somit aktuelle Social-Media-Trends

-

Du betreust und managst eine Werkstudentin und berichtest an den Brand Lead, der Teil des Marketing Teams ist

## **Dein Profil**

-

2 Jahre Erfahrung im organischen Social Media Management, idealerweise für eine Consumer-App, einen Marktplatz oder eine Gen-Z-Zielgruppe

-

Nachweisbarer Track Record im Aufbau und Wachstum von TikTok- und Instagram-Kanälen mit Beispielen, nicht nur Vanity-Metriken

-

Starke Hands-on-Produktionsfähigkeiten: Skript, Shooting mit dem Smartphone, Schnitt (Cap Cut, Premiere o. ä.), Copywriting

-

Sehr gutes Gespür für Plattform-Mechaniken und Trends + inklusive der Fähigkeit, Trends zu bewerten statt nur zu kopieren

-

Erfahrung im Community Management, auch in kritischen Situationen

-

Datenaffin: du liest Kanal-Analytics, bildest Hypothesen und leitest daraus Content ab

-

Ownership, hohe Umsetzungsgeschwindigkeit und Wohlfühlen in einem schnellen Scale-up-Umfeld

## **Wir bieten**

🏖️ Zeit zum Abschalten & Auftanken

-

28 Urlaubstage (steigen alle zwei Kalenderjahre um 1 auf max. 30 Tage)

-

1 bezahlter Sonderurlaubstag pro Jahr für ehrenamtliche Arbeit

-

5 Tage bezahlter Bildungsurlaub

-

Möglichkeit für unbezahlten Urlaub

-

10 bezahlte Tage beim krankheitsbedingten Ausfall deines Kindes

🚀 Weiterentwicklung & Lernen

-

750 € jährliches Weiterbildungsbudget pro Mitarbeiter:in

-

Zusätzliches Team-Trainingsbudget & interne Workshops

-

Mentoring, Karrierecoachings & Zenjob University

🏠 Arbeit, die zu deinem Leben passt

-

Hybrides Arbeitsmodell: bis zu 2 Tage/Woche remote (1 Tag in den ersten 6 Monaten für bestmögliches Onboarding)

-

Flexible Arbeitszeiten

-

Modernes, lichtdurchflutetes Büro in Prenzlauer Berg

-

Hundefreundliches Arbeitsumfeld

💪 Gesundheit & Wohlbefinden

-

30 € monatlicher Zuschuss für Urban Sports Club

-

25 % Rabatt auf Mitgliedschaften bei FitX

-

Eigener kleiner Meditationsraum im Büro

🥗 Verpflegung & Office-Life

-

Monatliches Monday Lunch, kostenlose Getränke, Obst- & Gemüsekorb

-

Bis zu 115,05 €/Monat steuerfreier Essenszuschuss über Circula

-

Snacks & Drinks nach unseren All Hands Meetings

🚲 Nachhaltige Mobilität

-

40 € monatliches Guthaben bei NAVIT (ÖPNV, Bike-Sharing u.v.m.)

💼 Finanzen & Vorsorge

-

Betriebliche Altersvorsorge über Finsurancy zu attraktiven Gruppenkonditionen

-

Übertragungsservice für bestehende betriebliche Rentenverträge

🎉 Kultur & Teamspirit

-

Vierteljährliche Teamevents, Sommer- & Winterparty

-

Budget für Geburtstage & Firmenjubiläen

-

Unsere Werte werden gelebt: *Humble, Helpful, Hungry & Honest*

**Bewirb dich und schicke uns deine Unterlagen. Wir freuen uns auf dich!**

**Wir laden dich ein, unsere**[** Karriereseite**](https://career.zenjob.com/en/)** zu besuchen, unserer**[** LinkedIn**](https://www.linkedin.com/company/zenjob/)** Seite zu folgen und mit uns auf**[** Instagram**](https://instagram.com/insidezenjob?igshid=OGQ5ZDc2ODk2ZA%3D%3D&utm_source=qr)** in Verbindung zu setzen.**

*Wir sind stolz ein Arbeitgeber zu sein, der Chancengleichheit bietet. Wir verpflichten uns, jede qualifizierte Person nach ihren Fähigkeiten zu beurteilen, unabhängig von Alter, Geschlechtsidentität, ethnischer Zugehörigkeit, sexueller Orientierung, Behinderungsstatus oder Religion. Es ist nicht erforderlich, dein Foto und dein Alter der Bewerbung hinzuzufügen.*

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
