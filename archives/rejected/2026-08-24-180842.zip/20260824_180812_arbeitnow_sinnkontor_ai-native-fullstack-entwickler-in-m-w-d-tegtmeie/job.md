# AI Native Fullstack Entwickler:in (M/W/D) - Tegtmeier Internet Solutions GmbH

Posted: 2026-08-24T15:47:26Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

*Im Auftrag unseres Mandanten Tegtmeier Internet Solutions GmbH suchen wir – Sinnkontor – eine:n* *AI Native Fullstack Entwickler:in (M/W/D).*

Warum wir?

Tegtmeier Internet Solutions: Qualität & Leidenschaft. Seit über 20 Jahren liefern wir zuverlässige Softwarelösungen – anything but ordinary.

Bei uns fühlen sich Entwickelnde wohl, die gerne in einem starken Team auf Augenhöhe gemeinsam wachsen. Mit hanseatisch bodenständigem Geist bringst du dein Wissen ein und entdeckst gleichzeitig Neues.

Wir schaffen einen Raum, der ebenso fördernd und fordernd wie familiär ist – A Place That Benefits You.

DAS ERWARTET DICH

Gerade starten wir eine Reihe neuer, langfristiger Projekte auf der grünen Wiese, bei denen wir von Anfang an AI-first denken – von der Entwicklung bis zur Produktidee. Themen wie Tourismus, mentale Gesundheit und Musikbranche treffen auf moderne Software-Stacks und agentische Entwicklung. Wenn du Lust hast, mit uns Dinge zu bauen, die nicht nach 08/15-Enterprise riechen, sondern richtig was bewegen, dann suchen wir dich!

## Aufgaben

- Du entwickelst gemeinsam mit deinem Team Software, die wirklich etwas bewegt

- Du bist im direkten Austausch mit Nutzern und Kunden und übersetzt echte Probleme in saubere Lösungen

- Du tauchst tief in Geschäftsprozesse ein und baust Software, die sie besser macht

- Du nutzt AI-Coding-Tools wie Claude Code oder Codex als festen Bestandteil deiner Arbeit

- Du hast Lust, Dinge zu hinterfragen und neue Ansätze auszuprobieren

## Qualifikation

- Abgeschlossene Ausbildung oder Studium mit fachlichem Bezug

- Mind. 3 Jahre Full-Stack-Erfahrung mit Gespür für saubere Architektur, wartbaren Code und sinnvolle Abstraktionen

- Erfahrung mit echten Nutzern und Kunden

- AI-gestützte Entwicklung ist für dich zentrales Werkzeug

- Git, CI/CD und agile Entwicklung sind Alltag

- Erste DevOps-Erfahrungen

- Eigenverantwortlich, strukturiert, lösungsorientiert

- Deutsch C1, Englisch B2

- Nobody is perfect – melde dich auch, wenn nicht alles passt!

## Benefits

- Arbeitsplatz mit bester Ausstattung in modernem Büro nahe Hamburg Hauptbahnhof

- Regelmäßige IT-Konferenzen, Weiterbildungen, Hackathons und Team-Events

- Persönliches Weiterbildungsbudget plus 5 bezahlte Weiterbildungstage

- Offene Unternehmenskultur, die Innovation, Nerdigkeit und Kreativität fördert

- Enthusiastisches Team mit Leidenschaft für Technik

- Abwechslungsreiche Tätigkeit mit flachen Hierarchien

- EGYM-Wellpass Mitgliedschaft

- Kostenlose Getränke / Obst / Gemüse / Snacks

- Mittagessens-Zuschüsse

**Tegtmeier Internet Solutions GmbH**

**Burchardstr. 14**

**20095 Hamburg**

**Germany**

Eingetragen im Handelsregister:

Amtsgericht Hamburg HRB 137948

Vertretungsberechtigte Personen: Jan Tegtmeier

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
