# Werkstudent:in IT / AI (m / w / d), 8-16 Std. / Woche

Posted: 2026-08-24T15:47:26Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Du willst die digitale und KI-gestützte Transformation eines führenden Impact-Venture-Capital-Fonds aktiv mitgestalten? Willkommen bei BONVENTURE! Wir finanzieren und begleiten als führender High-Impact Fund wirkungsorientierte Startups rund um Climate Tech, Bildung, Gesundheit und Zirkularität. Wir suchen ab sofort in München eine/n Werkstudent:in IT / AI. In der vielseitigen und praxisnahen Rolle als IT / AI Werkstudent:in arbeitest du an der Schnittstelle zwischen **IT-Administration, KI-Implementierung, IT-Koordination und interner Team-Befähigung**. Deine Arbeit ist essenziell, um unsere internen Prozesse effizient und zukunftsfähig zu gestalten und dem gesamten Team den Rücken freizuhalten – damit wir uns auf das konzentrieren können, was zählt: Investitionen mit True Impact!

## Aufgaben

**Deine Aufgaben umfassen:**

***IT- und Systemadministration***

- Administration und Mitarbeit an der Weiterentwicklung unseres internen Task- und CRM-Systems, basierend auf dem Team-Kollaborationstool ClickUp (Nutzerverwaltung, Automatisierungen, Datenpflege, etc.)

- Kommunikation und Koordination mit externen IT-Dienstleistern, z. B. bei technischen Anfragen und Systemintegrationen

***KI-Implementierungen, Automatisierung und Team-Enablement***

- Konzeption und Implementierung von KI-Agenten, KI-Anwendungen und Automatisierungen (Claude, ChatGPT) für interne Prozesse

- Durchführung von Trainings und Schulungen und individuelle Begleitung für das Team zur praktischen Anwendung von AI im Arbeitsalltag und lösen von Fragestellungen im Dialog

- Unterstützung bei der Evaluierung neuer Tools und Technologien sowie Mitarbeit an Digitalisierungsprojekten nach Bedarf

## Qualifikation

**Dein Profil:**

- Du studierst einen naturwissenschaftlichen oder technischen Studiengang

- Du hast Erfahrung oder großes Interesse am praktischen Einsatz von LLMs (z. B. Claude, ChatGPT) und an Entwicklung sowie technischer Umsetzung von eigenen Workflows, Automatisierungen und AI-Agenten

- Erste Erfahrung mit CRM-Systemen

- Idealerweise Erfahrung im Umgang mit dem Produktivitätstool ClickUp

- Du arbeitest strukturiert und eigenständig und hast Freude daran, Wissen im Team zu vermitteln

- Dein Deutsch und Englisch ist sehr gut. Eine deutsche Aufenthaltsgenehmigung oder Staatsbürgerschaft liegt vor.

- Du bist für ca. 8-16 Std. / Woche in München verfügbar, idealerweise für mindestens 6–8 Monate

## Benefits

**Wir bieten dir:**

- Tiefen Einblick in die Digitalisierung und KI-Strategie beim führenden Impact-VC-Fonds Deutschlands

- Gelegenheit, IT- und AI-Prozesse von Grund auf mitzugestalten und Verantwortung zu übernehmen

- Ein erfahrenes, engagiertes Team mit Hintergrund in Venture Capital, Beratung und Startups

- Purpose für dich durch die direkte oder indirekte Unterstützung sozialer und ökologischer Startups

**Dein Weg zu uns:** Willst du mit uns eine bessere Zukunft schaffen? Dann freuen wir uns auf deine Bewerbung mit Lebenslauf und einem kurzen Anschreiben, in dem du uns erzählst, warum dich die Position bei BONVENTURE interessiert. Bitte gib außerdem dein frühstmögliches Startdatum an. Wir freuen uns auf deine Bewerbung!

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
