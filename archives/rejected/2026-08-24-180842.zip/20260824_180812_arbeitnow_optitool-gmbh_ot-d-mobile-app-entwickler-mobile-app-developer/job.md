# OT-D Mobile-App-Entwickler / Mobile-App-Developer (m/w/d) für Android

Posted: 2026-08-24T12:00:38Z

## Rejection

- Category: role_mismatch
- Reason: title is an obvious mismatch for a backend profile

Wir sind ein mittelständisches, modernes Software-unternehmen und bieten Lösungen für die Tourenplanung und -Optimierung an. Zu unseren Kunden zählen bekannte nationale und internationale Kunden. Wir verstehen uns als dynamisches Unternehmen mit kurzen Dienstwegen und guten Entfaltungsmöglichkeiten.

## Aufgaben

- Entwicklung & Weiterentwicklung unserer mobilen Warenwirtschaft (Front- und Backend)

- Umsetzung projektbezogener Aufgaben im Bereich Android Entwicklung

- Weiterentwicklung von Features und Funktionen unserer App OPTI4Driver

- Erschaffen und umsetzen neuer Lösungswege

- Entwerfen, implementieren und testen moderner Systemarchitekturen

## Qualifikation

Abgeschlossene Ausbildung in einem der folgenden Berufe:

- Abgeschlossenes Studium (z.B. Informatik)

- Vergleichbare Ausbildung / Berufserfahrung

- Kenntnisse & Erfahrungen mit: AAE sowie in JAVA und/oder Kotlin

- Analytisches und logisches Denken

- Ein Auge für hochwertiges Design, gute Usability und sauberen Code

- Freude an Teamarbeit und Spaß an neuen Herausforderungen

- Hohes Maß an Eigeninitiative zur Einarbeitung in neue Aufgabenbereiche

- Kreativität und Qualitätsbewusstsein gehört für Dich bei der Problemlösung mit dazu

Wünschenswert:

- Erfahrung mit der Integration von Backend-Diensten (z.B. REST APIs, JSON) und mit gängigen Android-Frameworks (z.B. Dagger)

## Benefits

- Attraktive Vergütung

- Viele Zusatzleistungen wie betriebliche Altersvorsorge, kostenfreie Getränke, klimatisierte Büroräume, Firmenveranstaltungen

- Verschiedene Arbeitsmodelle wählbar

- Individuelle Karriereplanung, flexible Arbeitszeiten

- Eine ausgewogene Work-Life-Balance

- Deine eigenen Ideen finden hier stets offene Ohren und einen Rahmen zur Umsetzung

**Bewirb Dich jetzt!**

Weitere Jobs findest du auch auf unserer Homepage.

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
