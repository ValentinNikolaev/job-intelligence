# Director of Product Management

Posted: 2026-08-24T11:40:24Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

### **Your turn to start the conversation.Write the future at Rasa.**

Conversation. It’s the thread between our product and our people. The tool that enables us to forge relationships through compassion and expertise. To find the connection between our differences. It keeps us close together across borders and backgrounds and helps us create our shared vision.

Rasa means tight-knit. We get to the point and have the courage to ask ‘why?’. Because through relentless experimentation, passion, and vision, we’re transforming the way people interact with organizations through AI.

That’s Rasa. That’s our message.

**Join us and add yours.**

### **SUMMARY**

We're a startup, so you'll have to be comfortable rolling up your sleeves and doing whatever is required to support our mission. We're seeking an exceptional Director of Product Management to lead our product organization and shape the future of conversational AI experiences. You'll drive product strategy across our platform while building and leading a high-performing team of product managers. This role requires someone who can balance strategic vision with hands-on execution in our fast-paced, technical environment.

**Full-time - 100% Remote - UK, Germany, or Serbia [Preferred location: Berlin, Germany]**

-

***This is a remote position, but we cannot hire anybody outside of the UK, Germany, or Serbia for this position.***

-

***Rasa can assist with work authorization (visa sponsorship) for candidates located in Germany only.***

### **ABOUT YOU**

-

8+ years of product management experience, with 2+ years leading or mentoring others.

-

Strong background in B2B, developer tools, or technical products.

-

Proven ability to connect product decisions to business strategy and bring cross-functional partners along.

-

Collaborative, pragmatic leader with a genuine passion for AI innovation.

-

Hands-on track record managing products across the full lifecycle — concept, launch, and sunset.

-

Product management experience in enterprise environments, (ideally enterprise-licensed software, on-prem, or private/virtual cloud deployments), preferably with a technically minded product.

-

Experience identifying, defining, packaging, pricing, and shipping software within a cloud service, infrastructure product, and/or open-source product with machine learning at its core.

-

Experience engaging and enabling large developer communities.

-

Comfortable in a fast-growth startup: limited resources, imperfect information, fast-shifting markets and competition, and little existing structure.

### **ABOUT THIS ROLE**

As Director of Product, you’ll play a pivotal role in elevating Rasa’s platform experience—guiding how our products look, feel, and work for both developers and business users. You’ll shape the product direction, collaboration, and innovation across the company.

-

Recruit, develop, and retain outstanding talent and lead a high-impact team of product professionals.

-

Partner with engineering, sales, and marketing to shape go-to-market, pricing, and packaging, and bring your products to market successfully.

-

Monitor the market and competitive landscape for AI solutions to build a comprehensive product strategy.

-

You translate requirements from product, domain, and business teams into clear, actionable requirements and platform solutions that enable teams effectively.

-

Own the roadmap and product definition for your area, and contribute to the broader product strategy — grounded in research, customer feedback, competitive analysis, and market needs.

-

Actively seek internal and external feedback to iterate quickly on early prototypes, and help foster a healthy ecosystem around your products (developers, partners, customers, and community).

*Please keep in mind that we are describing the background that would best fit the role. Even if you don’t meet all the requirements, yet you are confident that you are up for the task, we absolutely want to get to know you!*

### **MEET YOUR TEAM**

The product team currently consists of 4 Product Managers. We also have 1 Director of Design with 2 Product Designers who collaborate closely. Both Directors report to [Björn](https://www.linkedin.com/in/bminkmar/), our Chief Product Officer.

### **FREQUENTLY ASKED QUESTIONS**

You can find answers to FAQs about this role specifically on our [**Director of Product Management - FAQ.**](https://rasa.notion.site/Director-of-Product-Management-Candidate-Deck-2b7b9c0d544a80deae07c397560425c7)

### **WHAT YOU CAN EXPECT FROM US**

-

Flexible hours and a dedicated remote budget

-

A stipend for professional development & 6 paid education days to help you grow within your role

-

26 days of PTO + paid sick leave + paid public holidays

-

A Macbook, and other tech to help you do your job

-

We have regular remote team events, as well as an annual company-wide offsite

-

Vitality Health (UK only) // Private Health optional (Serbia Only)

-

Equity options

You can find more information about our benefits per location here:[ **Rasa Perks & Benefits**](https://rasa.notion.site/External-Rasa-Benefits-Perks-5bf7e7e5380240bf9aa5bb6ae488aec9?pvs=74)

### **ABOUT US**

Rasa is an enterprise platform for building and operating AI agents across chat and voice channels. Organizations use Rasa to orchestrate complex, multi-step conversations, integrate AI agents with core business systems, and run them reliably in production environments.

Rasa supports long-running interactions that span channels and systems. The platform enables consistent agent behavior as conversations evolve, including escalation, recovery, and coordination across workflows. This allows enterprises to deploy AI agents that align with operational requirements rather than isolated use cases.

Designed for large-scale deployments, Rasa supports secure operation across cloud and on-prem environments and integrates with existing data, APIs, and tooling. Enterprises adopt Rasa when they need control, scalability, and governance for AI agents supporting critical customer and employee interactions.
Rasa was founded in 2016 and is privately held. The company is backed by Accel, Andreessen Horowitz, Basis Set Ventures, PayPal Ventures, and StepStone Group.

## **Please be mindful of the hiring location(s) listed. **

You must be located in and a resident of the location(s) listed for us to proceed with your application.

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
