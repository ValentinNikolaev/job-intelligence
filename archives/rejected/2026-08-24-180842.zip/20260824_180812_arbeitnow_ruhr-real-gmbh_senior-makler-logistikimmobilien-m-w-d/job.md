# Senior Makler Logistikimmobilien (m/w/d)

Posted: 2026-08-24T11:20:16Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

## Du interessierst Dich für die Immobilien hinter Lieferketten, Produktion und Wachstum?

**Dann werde Teil von RUHR REAL.**

Dann gestalte mit uns den Markt für Logistik- und Industrieimmobilien. Bei RUHR REAL verantwortest Du komplexe Mandate, bringst Eigentümer und Nutzer zusammen und entwickelst Lösungen für Flächen, die für den Erfolg unserer Kunden entscheidend sind.

## **DAS SIND DEINE BENEFITS**

**Modernes Arbeitsumfeld mit Hightech-Ausstattung**

Unsere Büros überzeugen durch eine verkehrsgünstige Lage und ein modernes Arbeitsumfeld.

**Flache Hierarchien & echtes Teamwork**
Kurze Entscheidungswege, direkte Kommunikation und ein Team, das gemeinsam an einem Ziel arbeitet.

**Abwechslungsreiche Aufgaben mit Verantwortung**
Kein Tag ist wie der andere. Du arbeitest eigenverantwortlich an spannenden Immobilienprojekten und betreust anspruchsvolle Kunden.

**Motiviertes Team mit starkem Zusammenhalt**
Bei RUHR REAL arbeitest Du in einem engagierten und hochmotivierten Umfeld mit echtem Teamspirit.

**Regelmäßige Teamevents**
Gemeinsame Aktivitäten und Events stärken den Zusammenhalt und sorgen für eine starke Unternehmenskultur.

**Attraktiver Unternehmensstandort**
Unser Büro überzeugt durch eine verkehrsgünstige Lage und ein modernes Arbeitsumfeld.

**Kostenfreie Parkplätze direkt am Haus**
Keine stressige Parkplatzsuche – Du parkst bequem direkt vor Ort.

## **DAS IST DEIN JOB**

**Vermietung und Verkauf von Logistikimmobilien**
Du betreust spannende Immobilienprojekte und bringst passende Unternehmen und Flächen zusammen.

**Akquisition von Objekten und Neukunden**
Du baust aktiv neue Kundenbeziehungen auf und gewinnst interessante Immobilienmandate.

**Erstellung von Exposés und Angeboten**
Du entwickelst professionelle Vermarktungsunterlagen und präsentierst Immobilien überzeugend am Markt.

**Entwicklung von Vermarktungskonzepten**
Du arbeitest kreative und zielgerichtete Strategien zur Vermarktung von Gewerbeimmobilien aus.

**Ganzheitliche Beratung unserer Kunden**
Du begleitest Eigentümer und Interessenten professionell durch den gesamten Vermittlungsprozess.

**Organisation und Durchführung von Besichtigungen**
Du koordinierst Termine, führst Besichtigungen durch und überzeugst mit professionellem Auftreten.

## **CHECKLISTE**

[ ] Mehrjährige Erfahrung im Gewerbeimmobilienmarkt, idealerweise mit Schwerpunkt Logistik, Industrie oder B2B-Immobilienvertrieb

[ ] Ein belastbares Netzwerk oder die Motivation, dieses konsequent auszubauen

[ ] Gute Kenntnisse in MS Office

[ ] Loyalität, Verlässlichkeit und professionelles Auftreten gehören zu Deinen Stärken

[ ] Struktur und ein hoher Qualitätsanspruch in der Kundenberatung

[ ] Engagement, Belastbarkeit und Eigeninitiative zeichnen Dich aus

Bitte ignoriere diese Stelle, wenn Du …

… eine normale 9-to-5-Stelle suchst. Diese Rolle ist herausfordernd und erfordert eine Alles-geben-Mentalität.

… wenn Du keine Kritik akzeptieren kannst und mit Stress sowie Ergebnisdruck nicht umgehen kannst.

Das klingt spannend für Dich? Dann bewirb Dich jetzt!

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
