# Praktikant - Strategy & Operations (m/w/d)

Posted: 2026-08-24T11:55:27Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Die meisten Praktika geben dir Aufgaben. Dieses gibt dir Verantwortung. Als Praktikant in der Logistik bei **CarOnSale** übernimmst du echte End-to-End-Projekte mit messbaren OKRs — und arbeitest an der Logistikstrategie einer Plattform, die jährlich über 130.000 Fahrzeuge quer durch Europa bewegt. Wenn du verstehen willst, wie Supply-Chain-Strategie im echten Maßstab funktioniert — und sie aktiv mitgestalten willst — dann fängst du hier an.

**Standort:** Berlin Schöneberg – Du arbeitest vor Ort in unserem Büro, hybrid mit 3 Tagen Office und 2 Tagen Homeoffice.

**Dauer:** 5–6 Monate (Idealerwise)· Start: nach Vereinbarung

### Über uns

CarOnSale ist das KI-gestützte System für den B2B-Gebrauchtwagenhandel in Europa. Über 40.000 Käufer aus mehr als 20 Ländern handeln auf unserer Plattform – und 85 % des Inventars ist exklusiv bei uns. Wir verbinden Software, Pricing-Intelligenz, Logistik und Finanzierung in einer Schicht – als Betriebssystem für eine ganze Branche.

***One Platform. One Profit Engine.***

### Deine Aufgaben

- Du entwickelst unsere Logistikstrategie weiter und stellst sicher, dass sie auf die Unternehmensziele einzahlt.

- Du erstellst Management-Präsentationen zu Logistik-Performance und strategischen Initiativen.

- Du optimierst interne Logistikprozesse auf Basis von Datenanalysen und leitest konkrete Verbesserungsmaßnahmen ab.

- Du entwickelst Tools und Dashboards zur operativen Steuerung und zur Auswahl effizienter Lager- und Transportoptionen.

- Du arbeitest eng mit angrenzenden Teams zusammen, übernimmst Dokumentation und Reporting und unterstützt beim Onboarding neuer Transportunternehmen.

### Was du mitbringst

- Eingeschriebene/r Student/in der Wirtschafts-, Ingenieur- oder Naturwissenschaften — Schwerpunkt Logistik, Supply Chain oder vergleichbar

- Sehr gute Deutsch- und Englischkenntnisse (mind. C1, schriftlich und mündlich)

- KI-affine Arbeitsweise — du nutzt Tools wie ChatGPT, Claude, Gemini oder Cursor aktiv im Alltag

- Strukturiertes, analytisches Denken und eine lösungsorientierte Herangehensweise

- Sicherer Umgang mit Daten und Dashboards

- Proaktive Eigenverantwortung — du bringst Projekte selbstständig von der Idee zur Umsetzung

### Was dich bei uns erwartet

- Strukturiertes Onboarding mit Buddy-Programm

- Regelmäßige Feedbackzyklen

- Frisches Obst und Getränke im Büro

- Freie Tech-Wahl: Windows oder Apple

**Bewirb dich jetzt – dein Lebenslauf reicht.**

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
