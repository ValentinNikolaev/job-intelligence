# Director of Business Development

Posted: 2026-08-24T11:24:27Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

At **CesiumAstro**, we are developers and pioneers of out-of-the-box communication systems for satellites, UAVs, launch vehicles, and other space and airborne platforms. We take pride in our dynamic and cross-functional work environment, which allows us to learn, develop, and engage across our organization. If you are looking for hands-on, interactive, and autonomous work, CesiumAstro is the place for you. We are actively seeking passionate, collaborative, energetic, and forward-thinking individuals to join our team.

We are looking to add a **Director of Business Development **to our team. In this position, you will be responsible for developing business opportunities and relationships with potential CesiumAstro customers in the European space market. 

Working with the Senior Director of Business Development you will be responsible for developing business opportunities and relationships with potential CesiumAstro customers. The area of responsibility for this role is broad and requires a wide range of knowledge about the space industry, telecommunication and RF electronic products, technology commercialization, market analysis, relationship management, and strategic planning.

Daily responsibilities include developing and continuously updating the commercial and defense aerospace telecommunication electronics market potential and trends, identifying opportunities, writing and submitting RFI and RFP responses, visiting existing and potential customers, interfacing with engineering and product development staff to articulate market gaps and demands, assisting in the strategic and R&D roadmaps for the company, and ultimately leading the top line revenue growth for the company. 

The successful candidate will have a successful track record in aerospace sales, is extremely organized, articulate, flexible, quick to grasp business needs, a team player, an excellent written and oral communicator, and eager to learn.

**JOB REQUIREMENTS AND MINIMUM QUALIFICATIONS**

- Bachelors degree in a technical or business-related discipline from an accredited college or university.

- Minimum 10 years of relevant business development experience in space or aerospace industry segments.

- Prior experience developing business with government, institutional and defense customers. 

- Track record of identifying and capturing new business development opportunities to improve the company’s business portfolio to include marketing and customer call plans.

- Experience contributing to and supporting opportunity captures including developing overall win strategy; shaping deals with customers; developing teaming strategies; identifying and closing with teammates; and understanding pricing and assist in developing winning proposals.

- Demonstrated background in solution selling and developing new markets with proven leadership from inception to successful engagement of a strategic campaign.

- Knowledge of Government contracting and current acquisition trends and customer buying behaviors.

- Support the identification and pursuit of new business opportunities within the space and aerospace sectors with both commercial and governmental entities.

- Contribute to business development strategies to expand CesiumAstro’s presence in the European space market.

- Facilitate strong relationships with key stakeholders, including government agencies, commercial clients, research institutions, and industry partners.

- Coordinate the proposal and negotiation processes for new contracts and partnerships.

- Collaborate with internal teams to understand business development initiatives with product offerings, capabilities, and organizational goals.

- Represent the company at industry events, conferences, and forums to increase visibility and create networking opportunities.

- Provide regular reports and updates on business development activities.

- Excellent communication, negotiation, and presentation skills.

- Ability to develop and execute business plans.

- Strong oral and written communication skills.

- Proficiency with Microsoft Word, Excel, PowerPoint, etc.

- Strong interpersonal and professional skills.

- A positive, team-player attitude.

- Effective presentation skills and experience leading customer meetings.

**PREFERRED EXPERIENCE**

- Prior experience identifying new business opportunities and building relationships with key stakeholders.

- Ability to think strategically and drive initiatives that align with company objectives.

- Proficiency in German and English (both written and spoken).

- Self-motivated with the ability to work independently and as part of a collaborative team.

- Knowledge of market analytics and technology planning and commercialization.

- Experience with the aerospace telecommunications industry.

- Experience with startups.

- Ability to obtain relevant Security Clearance.

**WHAT WE OFFER**

- The opportunity to help establish CesiumAstro’s first European office and grow our Munich team.

- High-impact role with direct exposure to leading EU space programs.

- Competitive compensation and benefits package.

- A collaborative, innovative environment shaping the future of space communications.

CesiumAstro considers several factors when extending an offer, including but not limited to, the role and associated responsibilities, a candidate’s work experience, education/training, and key skills.

Please be aware that many roles will be subject to both security and export control restrictions. These restrictions mean that factors including new starter’s nationality, any previous or dual nationalities held, place of birth and country of residence may limit those roles that you can perform for the organization.

*Please note: CesiumAstro does not accept unsolicited resumes from contract agencies or search firms. Any unsolicited resumes submitted to our website or to CesiumAstro team members not through our approved vendor list or Talent Acquisition will be considered property of CesiumAstro, and we will not be obligated to pay any referral fees.*

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
