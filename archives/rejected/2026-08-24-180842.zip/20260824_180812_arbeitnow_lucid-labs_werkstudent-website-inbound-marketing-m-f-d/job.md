# Werkstudent - Website & Inbound Marketing (m/f/d)

Posted: 2026-08-24T11:30:37Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**Warum es diese Rolle gibt**

Bei unseren Kunden laufen KI-Agenten im operativen Tagesgeschäft. Sie prüfen Dokumente, ordnen Anfragen ein und bereiten Entscheidungen vor. Nicht im Pitch-Deck, sondern produktiv im deutschen Mittelstand.

Aufmerksamkeit haben wir inzwischen: Über LinkedIn, Keynotes und Messen kommen Terminwünsche von Geschäftsführungen, Vortragsanfragen und Nachrichten herein. Was danach passiert, ist heute bei niemandem verankert. Genau diese Strecke von der ersten Anfrage bis zum Termin im Kalender gehört dir.

Deshalb heißt die Rolle nicht Social Media. Sie wird nicht an Reichweite gemessen, sondern an Antwortzeiten und Terminen.

**Für wen du schreibst**

Geschäftsführer:innen, Bereichsleitungen und Directors mittelständischer Unternehmen aus den FEldern Maschinenbau, Versicherung, Logistik, Handel. Sie haben viel über KI gehört und wenig gesehen, das im Alltag funktioniert. Sie lesen keine englischen Buzzwords und sie haben zehn Minuten. Für diese Menschen zu schreiben ist eine eigene Disziplin: Ein Ton daneben kostet den Termin.

## Aufgaben

**40 % Website**

Der Kanal, über den die Anfragen tatsächlich hereinkommen.

- Relaunch operativ begleiten: Inhalte, Struktur, Testing

- Referenzen und Cases einpflegen, damit greifbar wird, was wir bauen — und nicht nur, worüber wir sprechen

- Karriereseite aktuell halten; wir stellen laufend ein

- Landingpages für Lead Magnets und Webinare bauen

- eingehende Anfragen triagieren und nachfassen

- Der Website-Anteil ist während unseres anstehenden Relaunchs real 40 % und sinkt danach auf etwa 20 % Pflege. Die frei werdende Zeit geht zurück in Inbox und Mid Funnel.

**30 % LinkedIn-Inbox**

Du betreibst unsere LinkedIn-Inbox mit unserem bestehenden KI-Reply-Skill. Qualifizierte Gespräche gehen mit Kontext an unseren Gründer, alles andere führst du selbst weiter. In den ersten sechs Wochen baust du den bestehenden Rückstand auf null ab und hältst HeyReach und HubSpot sauber, damit die tägliche Morgenroutine trägt.

Mit sechs Stunden pro Woche ist das nicht per Hand zu schaffen. Es funktioniert, weil unser Reply-Skill Entwürfe vorlegt und du prüfst, schärfst und sendest — und weil du diesen Skill selbst weiterbaust.

**20 % Mid Funnel**

Alles zwischen erstem Kontakt und esten Termin.

- **Newsletter:** die Strecke in ConvertKit aufsetzen und takten

- **Webinare:** den Funnel drumherum betreiben — Einladung, Erinnerungen, Aufzeichnung, Nachfassen

- **Lead Magnets:** Reifegrad-Check und AI Benchmark Engine am Laufen halten und optimieren

- **Follow-ups:** Kontakte von Messen und Events systematisch nachfassen statt versanden lassen

**10 % Content**

Du bist die Gegenstelle zu unserer Content-Agentur: Themen abstimmen, Rohmaterial liefern, Entwürfe gegenlesen, Freigaben einholen. Der Takt läuft über dich.

- Carousels und Infografiken aus unserem eigenen Material bauen , z.B. ROI-Rechner, Priorisierungsmatrix, Agent Autonomy Matrix

- nach jedem Speaking-Auftritt die dazugehörige Serie erstellen

**Struktur**

Drei feste Vormittage, die wir gemeinsam nach deinem Stundenplan festlegen. Uns geht es um Planbarkeit, nicht um bestimmte Wochentage: Ohne verlässliche Anwesenheit im Kernzeitfenster sind die Antwortzeiten nicht zu halten.

## Qualifikation

**Was du mitbringst**

- Du bist in einem laufenden Studium, Fachrichtung zweitrangig. Die Rolle ist auch als Teilzeit für Berufseinsteiger:innen denkbar.

- Du schreibst auf muttersprachlichem Niveau Deutsch. Klar, knapp und du triffst den Ton, wenn eine Geschäftsführerin antwortet.

- Du arbeitest agentisch statt händisch: Aus wiederkehrenden Aufgaben baust du eigene Skills. Unsere interne Erwartung liegt bei zwei Skills pro Person und Monat, und sie gilt hier ab Tag eins.

- Du verträgst Vertrieb. Diese Rolle ist Erstkontakt zu echten Kaufinteressenten, nicht Content-Produktion mit Abstand zum Kunden.

- Du kommst im CMS selbst zurecht: Seiten anlegen, Inhalte pflegen, sauber testen.

- Du bringst Tempo statt Perfektion. Einen Rückstand löst niemand mit einer Konzeptphase.

- Du kannst 20 Stunden pro Woche arbeiten, davon drei feste Vormittage, die wir gemeinsam nach deinem Stundenplan festlegen. Dein Englisch ist fließend.

**Was du nicht brauchst**

Kein Marketingstudium, keine Agenturerfahrung, kein Portfolio, keine Designausbildung, keine Programmierkenntnisse und keine Erfahrung mit Mittelstandskunden. Tools, Zielgruppe und Methoden lernst du in den ersten Wochen bei uns.

Nice to have: Erfahrung mit Canva oder Figma, mit E-Mail-Marketing, CRM oder Outbound-Tools, oder Berührung mit klassischem Mittelstand aus Praktikum, Familienbetrieb oder Ausbildung.

**Du passt besonders gut zu uns, wenn …**

- … du eine offene Anfrage als etwas empfindest, das heute beantwortet gehört.

- … du beim dritten Mal derselben Handgriffe anfängst, sie zu automatisieren, statt sie zu ertragen.

- … du bei einem schlechten Text sofort siehst, was ihn schlecht macht und ihn umschreibst, statt darüber zu diskutieren.

- … du dich für Branchen interessieren kannst, über die niemand auf LinkedIn spricht: Schadenregulierung, Ersatzteillogistik, Angebotskalkulation.

- Wir arbeiten ambitioniert, nehmen uns dabei aber nicht zu ernst. Wer offen kommuniziert und über eigene Fehler lachen kann, passt meist besser zu uns als jemand, der nur professionell wirken möchte.

**Diese Rolle ist nichts für dich, wenn …**

- … du der klassische Marketing-Werkstudent sein willst, der Redaktionspläne baut.

- … du für die Startup- und Tech-Bubble schreiben willst. Unsere Gegenüber sitzen in Unternehmen, die es seit vierzig Jahren gibt.

- … dir direkter Kontakt zu Kaufinteressenten unangenehm ist.

- … du feste Vormittage nicht verlässlich einhalten kannst.

- … du lieber ein Konzept & Strategien schreibst, als eine Inbox leer zu machen.

## Benefits

- **Ownership statt Zuarbeit.**Dir gehört die Strecke von der Anfrage bis zum Termin. Kein Marketingteam über dir, keine Hierarchieebene zwischen dir und den Entscheidern — und keine Anleitung für jeden Schritt. Bei uns hat nicht automatisch die seniorste Person recht.

- **Nähe zu echten Kunden.** Du schreibst nicht über eine Persona. Du antwortest Geschäftsführungen, hörst ihre Fragen zuerst und benutzt danach ihre Worte statt unserer.

- **KI-natives Arbeiten, bevor es alle können.** Du betreibst deine Arbeit nicht nur mit KI, du baust die Werkzeuge dafür selbst — mit demselben Stack, den wir unseren Kunden verkaufen: Claude, OpenAI, Cursor, n8n. Die meisten deiner Kommiliton:innen lernen das im ersten Job nach dem Studium. Oder auch nicht.

- **Der Rahmen.** Berlin als Basis mit modernem Büro im Edge Co-working am Hauptbahnhof, flexibel remote außerhalb der festen Vormittage. In Klausurenphasen lässt sich reduzieren, in den Semesterferien aufstocken.

- **Perspektive.** Wir betrachten Werkstudierende als langfristige Talent-Pipeline, nicht als günstige Zusatzkapazität. Wenn es passt, gibt es nach dem Studium eine realistische Perspektive in Marketing, Demand Generation oder Sales bei uns.

**Wer wir sind**

Lucid Labs ist ein AI-first Studio für angewandte KI im deutschen Mittelstand. Wir beraten nicht nur bei der Auswahl von Anwendungsfällen, sondern entwickeln und betreiben Lösungen, die produktiv in echten Prozessen laufen. Gründer Marek Janetzke hat zuvor Flightright mit aufgebaut und bis zum erfolgreichen Exit begleitet.

Unsere Kultur in einem Satz:

Mitdenken statt abarbeiten. Klartext statt Buzzwords. Umsetzen statt Folienschlacht.

**Bewerbung und Auswahl**

**Schritt 1.** Lebenslauf und ein kurzes Beispiel von maximal zwei Absätzen. Kein Anschreiben nötig.

Beschreibe darin eine Aufgabe, bei der du mit KI zu einem besseren Ergebnis gekommen bist, als du es allein geschafft hättest: wie du vorgegangen bist, was beim ersten Versuch nicht funktioniert hat, was du geändert hast und woran du gemerkt hast, dass es besser war. Das Beispiel ist uns wichtiger als der Lebenslauf.

**Schritt 2.** Erstes 30 Minuten Kennenlernen mit dem Team.

**Schritt 3.** Arbeitsprobe mit rund zwei Stunden Umfang, bewusst nah an der tatsächlichen Arbeit.

**Schritt 4.** Gespräch mit dem Gründer.

Bitte teile keine vertraulichen Daten früherer Arbeitgeber oder Kunden.

**Wir freuen uns auf dich.**

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
