# Project Manager - KI-Beratung (m/w/d)

Posted: 2026-08-24T11:30:36Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**Warum diese Rolle**

Lucid Labs ist eine spezialisierte Beratung für den deutschen Mittelstand. Wir automatisieren operative Entscheidungen, mit angewandter KI und einer eigenen Plattform, die bei Kunden produktiv läuft. Unsere Pipeline wächst schneller als unser Team. Wir suchen jemanden, der unsere Kundenprojekte übernimmt und in den nächsten zwölf Monaten in die volle Verantwortung für eigene Kunden hineinwächst.

Dabei sind wir besonders stolz auf unsere Geschwindigkeit. Von der Idee bis zum Piloten beim Kunden dauert es bei uns rund eine Woche. Den Hebel, den du im Workshop identifizierst, testet der Kunde nächste Woche als Prototyp. Direkt mit der Geschäftsführung und ohne Layer dazwischen.

Der eigentliche Grund für diese Rolle ist aber ein anderer: Hier wirst du AI-native. Du lernst, KI-Lösungen nicht nur theoretisch zu empfehlen und auf Folien aufzuzeigen, sondern selbst zu bauen, und berätst Unternehmen genau dabei. Das ist der Skill, der in den nächsten Jahren entscheidet, welche Berater gefragt sind. Und kaum ein Ort bringt ihn dir schneller bei als ein Team, das jede Woche selbst baut, was es berät.

Wenn du heute Rollouts, Implementierungen oder Digitalisierungsprojekte betreust und dabei mehr verwaltest als gestaltest: Genau dafür ist diese Rolle gedacht.

## Aufgaben

Du übernimmst Kundenprojekte: Discovery, Workshops, laufende Implementierung. In den ersten Wochen gemeinsam mit jemandem, der das schon kann, danach allein. Mehrere Kunden parallel, mit deutlich mehr Tiefe pro Kunde als im klassischen Beratungsgeschäft. Du berichtest direkt an den Gründer und arbeitest eng mit unserem Engineering-Team. Das heißt Entscheidungswege von Minuten, nicht von Wochen.

**70 % Kundenarbeit:** Du bist Ansprechperson für deine Projekte, meist direkt für die Geschäftsführung unserer Kunden. Workshops vorbereiten und leiten, wöchentliche Calls, Demos, Scoping, Anforderungen ins Engineering übersetzen. Dein Maßstab: Deine Kunden arbeiten nach wenigen Wochen messbar anders.

**20 % Prototyping:** Erste Prototypen baust du selbst, mit modernen AI-Tools und ohne Programmierung. Das ist die Folie, die funktioniert. Wie das geht, lernst du bei uns — und es ist der Teil der Rolle, in dem du am schnellsten wächst.

**10 % Pre-Sales & Scoping:** Workshops sind bei uns auch ein Sales-Tool. Du bereitest Opportunities mit vor, bist in Angebotsgesprächen dabei und übernimmst mit der Zeit die Folgepotenziale bei deinen eigenen Bestandskunden.

Und weil wir in der Aufbau-Phase sind: Was du in deinen Projekten an Vorlagen, Checklisten und Abläufen entwickelst, wird zum Standard, nach dem das Delivery-Team danach arbeitet.

**Deine ersten Monate**

In den ersten 6–8 Wochen läufst du in laufenden Projekten mit, übernimmst schrittweise einzelne Workshops und Calls und lernst unsere Tools - nicht in einer Schulung, sondern an echten Kunden, mit jemandem daneben. Nach etwa drei Monaten führst du 2–3 Kundenprojekte selbst, mit einem Sparringspartner im Rücken. Nach sechs Monaten trägst du deine Kunden allein und kannst Dinge, die du am Anfang nicht konntest: einen Prozess auseinandernehmen, einen Prototyp bauen, eine Geschäftsführerin durch eine Entscheidung führen.

## Qualifikation

- 2–4 Jahre Berufserfahrung mit Kundenkontakt, zum Beispiel als Implementation oder Onboarding Consultant im B2B-SaaS, in der Rollout- oder ERP-Beratung, in einer Digital- oder Prozessberatung, oder als Projektmanager:in / Chief of Staff für Digitalisierungsprojekte im Mittelstand

- Mindestens ein Kundenprojekt von Kick-off bis Go-Live getragen, mit deinem Namen am Ergebnis.

- Erfahrung damit, selbst vorne zu stehen: Workshops, Schulungen, Anforderungsrunden oder Demos, die du vorbereitet und geleitet hast

- Strukturierte Arbeitsweise, auch dann, wenn dir niemand vorgibt, wie die Struktur aussehen soll

- Verhandlungssicheres Deutsch und eine Arbeitserlaubnis für Deutschland in Vollzeit. Unsere Kunden sind deutscher Mittelstand, Workshops und Calls laufen auf Deutsch.

- Englisch brauchst du auf solidem Arbeitsniveau, weil Tools und Dokumentation englisch sind

- Technische Neugier: Du probierst neue Tools selbst aus. ChatGPT oder Claude nutzt du bereits regelmäßig

**Was du nicht mitbringen musst:** Kein Informatikstudium, keine Coding-Erfahrung, kein abgeschlossenes KI-Projekt, keine Beratungsmarke im Lebenslauf.

Was wir nicht beibringen können: dass du einen Raum hältst, wenn du vorne stehst. Und die Neugier, KI aktiv und wertstiftend einzusetzen. Uns interessiert weniger, wo du startest, als wie schnell du dich bewegst.

**Plus, kein Muss:** Eigene kleine Builds mit AI-Tools (Claude, n8n, Lovable), Erfahrung mit Kunden aus dem Mittelstand, Pre-Sales-Erfahrung, Change Management.

**Diese Rolle ist nichts für dich, wenn:** du Projekte am liebsten über Monate durchplanst, bevor etwas beim Kunden ankommt. Wenn du Beratung als Analyse verstehst und die Umsetzung anderen überlässt. Wenn du eine fertige Rollenbeschreibung und einen definierten Prozess brauchst, um loszulegen. Oder wenn du Kundengespräche eher meidest als suchst.

## Benefits

- **AI-native werden.** Du baust den Skill auf, den gerade jede Beratung und jedes Unternehmen sucht, und wendest ihn jede Woche bei echten Kunden an. Neue Tools landen bei uns nicht in einer Roadmap, sondern noch in derselben Woche in einem echten Projekt.

- **Lernen als Teil der Arbeit, nicht daneben.** Du arbeitest von Anfang an neben Leuten, die das schon können — im Projekt, nicht im Seminar. Was du fragst, wird beantwortet. Was du baust, bekommt Feedback.

- **Direkter Impact.** Du arbeitest unmittelbar mit den Entscheidern: mit der Geschäftsführung beim Kunden, mit dem Gründer bei uns. Deine Empfehlungen werden umgesetzt, nicht archiviert, und du siehst das Ergebnis innerhalb von Wochen.

- **Planbare Intensität.** Wir arbeiten fokussiert, aber berechenbar: keine Pitch-Wochenenden, keine Sonntag-Final-Edits. Kundenworkshops finden überwiegend remote statt, Reisen sind die Ausnahme.

- **Ein klarer Entwicklungspfad.** Aus dieser Rolle wächst in 12–18 Monaten die volle Verantwortung für eigene Kunden — und danach die Möglichkeit, das Delivery-Team mit aufzubauen.

- **Ein Gründer, der es schon einmal gemacht hat.** Marek war Mitgründer von Flightright, bis zum erfolgreichen Exit.

- **Remote mit Berlin als Basis.** Du arbeitest, wo du willst. Mittwochs treffen wir uns als Team im EDGE Coworking am Hauptbahnhof. Wer weiter weg wohnt, kommt nach Absprache seltener, und wer gern im Office arbeitet, kann jederzeit häufiger da sein.

**Wer wir sind**

Lucid Labs ist ein AI-first Studio, gegründet von Marek Janetzke. Wir arbeiten selbst so, wie wir beraten: mit Cursor, Claude und den jeweils besten Tools im Alltag. Unsere Kultur: Ownership statt Micromanagement. Lieber in zwei Wochen eine smarte Wette machen und daraus lernen, als drei Monate etwas polieren, das niemand validiert hat. Wir teilen unser Wissen und lernen gleichzeitig gemeinsam als Team. Wir suchen Leute, die mitdenken, nicht nur mitarbeiten.

**Bewerbung**

Schick uns einfach deinen Lebenslauf, ein Anschreiben brauchst du nicht. Wenn du schon mal etwas mit AI-Tools gebaut hast, freuen wir uns über einen Link oder Screenshot — Pflicht ist es nicht.

Wir freuen uns auf dich!

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
