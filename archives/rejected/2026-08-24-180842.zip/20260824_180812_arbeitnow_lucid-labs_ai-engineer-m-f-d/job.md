# AI Engineer (m/f/d)

Posted: 2026-08-24T15:47:26Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**What this role is about**

AI has arrived in the German Mittelstand. The distance between a convincing demo and a system a department trusts every single day is still large — and it gets closed by work that almost nobody does properly: defining what "good" concretely means, building the system toward it, measuring whether it hits, and iterating until it holds.

**That is what you do:**

You don't start from zero. You usually get a real starting point, often a golden data set from the department of a German Mittelstand company: real cases, each with the result an experienced expert would deliver. Your job is to build a system that reaches that result reliably, to bring it into people's working day through an interface they can actually use, and to be able to prove that it works.

## Tasks

You typically work on two to three customer projects in parallel.

**80% Building: The core of the role**

- Derive a defensible definition of "correct" from reference data, and build an eval that measures it

- Design and build the AI system itself: model and provider choice, context and prompt design, structured outputs, tool calling, agent/workflow logic, retrieval where it earns its place — and deterministic logic where an LLM isn't needed.

- Do error analysis and iterate deliberately instead of guessing — and demonstrate the improvement

- Build guardrails, escalation paths and monitoring, so the system doesn't fail loudly and confidently

- Build the production interface that goes with it: review screens, approvals, human-in-the-loop — in Next.js and TypeScript, not a throwaway prototype

- Roll the solution out and keep it running + improve it as AI advances

**20% Communication: Mostly internal**

- Capture and pass on your state in a structured way: what is built, what was measured, what is still open — in writing, without anyone having to ask

- Explain complex technical matters so that the project lead and colleagues without an AI background can decide on a sound basis

- Raise questions, blockers and wrong assumptions early instead of collecting them until the next meeting

- Occasionally demonstrate or explain a result at the customer yourself

Your standard is not "it's built". Your standard is: it is demonstrably good, it gets used, and it creates real value for the customer.

**What this role is not**

Three boundaries and all three exist to protect your build time.

- You don't own the customer. The relationship, the workshops and the conversations with management sit with the project lead. You see customers occasionally — when a result needs to be demonstrated or explained — not weekly.

- You don't run the project — and it does get run. We work with structured project management: scope and deadlines are defined up front and actively managed, so you know what you're delivering and by when, and your work stays plannable instead of absorbing whatever shifted this week. Very little ticket boards, no worklogs, no status lists on your side. What we do need: that your state is legible to everyone else at any time, without anyone having to ask.

- You don't work inside our customers' infrastructure — no SAP customizing, no system administration, no legacy integration as your core work.

**Your first 90 days**

- Weeks 1–3: You work inside two running projects, get to know our stack and our eval practice, and take over your first AI ise case of your own.

- Weeks 4–8: You own a complete use case — from the reference data set through the evals to the production interface — and you record results and measurements so that the project lead can represent them without you.

- After three months: You build your use cases independently, decide on approach and scope, and are the person on the project team who translates technical topics for everyone else.

## Requirements

**Important**

- You have built an AI solution that real users used in production — not just a prototype, not just a concept.

- You know how to engineer production LLM systems: context and prompt design, model selection, structured outputs, tool calling, failure handling, latency/cost trade-offs — and you know when a deterministic component beats an LLM.

- You work eval-driven: you define up front what a good result is, you measure systematically, and you don't ship on gut feeling. Whether that runs on Langfuse, Promptfoo, Arize Phoenix or your own spreadsheet is up to you; that you do it at all is not.

- You have built a system in which AI agents plan and execute tasks: tool calling, structured outputs, human-in-the-loop.

- You build production frontend: React and Next.js (App Router, Server Components), TypeScript. Not just demos, but error states, permissions, and the edges where prototypes fall apart.

- You can ship and operate your own solution: Docker, deployment, logging, cost control.

- You can explain a complex technical topic so that someone without an AI background can decide soundly afterwards — in writing just as well as in conversation.

- You work in a structured way internally: your status, your measurements and your open points are written down and findable, without anyone having to chase you.

- Coding agents (Claude Code, Cursor) as part of your daily work

- English at working level. The working language on this role is English, meaning Slack, meetings, code, PRs, and the write-ups that go with them.

- You can work in Germany full-time. A student visa with a day limit doesn't cover this role.

- 3+ years of professional experience in delivery projects.

**Highly valuable**

- German. Our customers are German Mittelstand, and the occasional demo there runs in German. Without it, the project lead covers that part — but it makes life easier, for you and for us.

- Experience with a production AI SDK layer (e.g. Vercel AI SDK), streaming architectures, several providers (OpenAI, Anthropic, Gemini, Mistral)

- Evaluation pipelines and feedback loops as a topic in their own right, not a by-product

- Using retrieval where it earns its place — and recognising when you don't need it

- Experience with customers or business departments in the German Mittelstand

- Confidence on GDPR and EU hosting questions

- Workflow orchestration with n8n or something comparable

**Not required**

- A computer science degree

- Model training, fine-tuning, classical machine learning

- MLOps, Kubernetes, data engineering pipelines

- Ten years of experience with a three-year-old framework ;)

**What matters to us more than a perfect CV**

We're not looking for the most elegant architecture, the most impressive stack, or the solution that demos best. We're looking for the simplest solution that demonstrably solves the use case — and for someone who knows the difference and holds it even when the more elaborate option would be more fun.

If your first question on a new project is what infrastructure we should set up, we're probably not a fit. If your first question is what we actually want to measure this thing against: then we are.

**You'll fit here particularly well if …**

- … you'd rather ship something demonstrably useful in two weeks than something complete in three months.

- … you can sink your teeth into an error rate until you understand where it comes from.

- … you say when a use case isn't worth it, even when it already sounds sold.

## Benefits

**What you can expect**

- Delivery that doesn't end at slides. You see projects from discovery through to go-live, and you build the solution yourself.

- Ownership without micromanagement. Clear goals, no step-by-step instructions. Good arguments change decisions, regardless of who makes them.

- Visible impact. Short paths, flat structure, no sign-off loops for the sake of form. Within a few weeks you see whether something works.

- Becoming genuinely AI-native. Agents in production, not in a notebook — and evaluating what actually holds up, on systems with real users. Full AI stack: Claude, OpenAI, Cursor, Claude Code, n8n, and whatever else your project needs.

- Remote, but not anonymous. Our team works mostly out of Berlin, with a team day every Wednesday at the EDGE Coworking by Hauptbahnhof. Otherwise flexible remote, with occasional appointments at customers.

**Who we are**

Lucid Labs is an AI-first studio for applied AI in the German Mittelstand. We don't just advise companies on which use cases to pick — we build and operate the solutions that run in their processes. Founder Marek Janetzke previously co-built Flightright and stayed with it through to the exit.

**Who you'll work with**

You won't be the only AI engineer here. You work alongside colleagues who build the same kind of systems you do — people to think a hard problem through with, to have an approach reviewed before you commit to it, and to borrow a solution from when someone has already solved it once. Technical decisions get argued out, not handed down.

**Our stack**

- **Frontend:** Next.js (App Router), React, TypeScript, Tailwind CSS, shadcn/ui

- **AI:** for example Vercel AI SDK, provider-flexible (OpenAI, Anthropic, Gemini, Mistral), Claude Skills, agentic workflows, n8n

- **Data & deployment:** PostgreSQL with Drizzle ORM, Docker, Vercel, Elestio on EU servers

- **Day-to-day:** Cursor, Claude Code, pnpm, Node.js, GitHub Actions

**How to apply**

Please send us two things:

- your CV

- one example, in two paragraphs at most: an AI solution you built that real users used.

Briefly describe:

- what you used to decide the result was good enough

- how you measured it

- what didn't work on the first attempt, and why

- what you changed as a result

Please don't include confidential information from previous employers or customers. The second part matters more to us than the first. You don't need a cover letter.

**We're looking forward to hearing from you.**

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
