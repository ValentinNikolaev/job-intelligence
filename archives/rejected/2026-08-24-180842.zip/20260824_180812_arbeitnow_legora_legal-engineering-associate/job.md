# Legal Engineering Associate

Posted: 2026-08-24T11:40:28Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

## About Us

Legora is redefining how legal work gets done. Not built for lawyers, built with them. We work alongside the world’s best legal teams, who expect excellence, precision, and speed, and we hold ourselves to the same bar.

Our AI-native workspace lets legal professionals move faster, think more clearly, and operate with sharper precision. By analysing thousands of documents in minutes and powering end-to-end workflows, we cut through complexity, teams can focus on what matters: judgment, strategy, and outcomes.

1,000+ customers across 50+ countries trust us, including Cleary Gottlieb, Goodwin, Linklaters, White & Case, Dentons, and Barclays. We’ve scaled to** $100M+ in ARR**, with teams across Europe, North America and APAC, and continue to expand through acquisitions including Qura, Walter AI and Graceview.

We partner with world-class performers: including Aaron Judge and the New York Yankees, Ludvig Åberg (and his caddie), and campaigns featuring Jude Law.

Joining Legora means three things.

-

We **lean in: **ownership over titles, outcomes over intentions.

-

We **fight for excellence:** high standards, direct, ego-free feedback.

-

We** grow together:** as a team and with our customers.

Mission before ego. Everyone contributes. No one coasts.

If you’re driven by impact, pace, and raising the bar. This is the place.

### **The Role**

This role sits at the intersection of law, technology, and product—supporting SMB clients across EMEA. You’ll help lean legal teams (often without large innovation/ops functions) adopt and scale Legora in a way that delivers real outcomes quickly.

You’ll work closely with Legal Engineers, Customer Success, Product, and Go-To-Market to help clients move from first value to repeatable workflows—while feeding what you learn back into how the product evolves.

### **What you’ll be doing**

-

**Support SMB client onboarding, pilots, and adoption** across EMEA—helping clients get to value quickly and confidently.

-

**Configure and run standard use cases end-to-end** using templates (e.g. contract review, document analysis, drafting workflows), then refine based on user feedback.

-

**Deliver clear, tailored demos and training** to different audiences—from day-to-day users to decision-makers—focusing on why each feature matters, not just how it works.

-

**Capture user insights and translate them into actionable product feedback**, helping shape improvements that make the platform more scalable and intuitive.

-

**Document best practices and contribute to playbooks** so we can deliver consistently excellent outcomes across a growing SMB client base.

-

**Own discrete workstreams on wider client programmes**, managing timelines, dependencies, and stakeholder expectations with increasing autonomy.

### **Who you are**

You’ll thrive in this role if you’re curious, structured, and comfortable operating in ambiguity—while still delivering high-quality outcomes.

-

**Exposure to and interest in law**: you’ve completed an LLB (2:1) or equivalent, with some legal work experience (e.g. paralegal, trainee, intern, in-house placement).

-

**Experience level**: 0–2 years.

-

**Tech-curious and product-minded**: you don’t need to code, but you enjoy experimenting with AI tools, learning product features quickly, and iterating on workflows (including basic prompt engineering).

-

**Strong communicator**: you can translate between lawyers and technologists clearly and confidently, adapting your style to the room.

-

**Analytical and detail-oriented**: you can evaluate outputs, spot issues, and propose pragmatic improvements.

-

**Proactive and reliable**: you follow through, manage expectations, and know when to escalate risks or blockers.

-

**Comfortable with SMB dynamics**: you understand that SMB clients value speed-to-impact, clarity, and practical guidance over long change programmes.

### **What success looks like (Associate level)**

-

You execute defined client deliverables with growing autonomy, supporting multiple pilots simultaneously.

-

You independently configure standard use cases using templates, explain the setup to users, and capture feedback in crisp notes.

-

You deliver strong demos (especially to existing clients on new features), and follow up with clear summaries and next steps.

-

You manage specific workstreams on broader programmes—owners, dependencies, deadlines—adjusting quickly when constraints change.

-

You build trust with stakeholders through responsiveness, clarity, and reliable delivery.

-

You can speak credibly about how AI is impacting legal work, and connect those implications to Legora’s capabilities.

### **A few more things**

Legora is fast-growing, and this is a role with real autonomy and responsibility. If you’re excited by building from first principles, learning quickly, and helping SMB legal teams transform how they work—this is the moment.

**Ready to join us in building the intelligent future of law?**

**Legora is an Equal Opportunity Employer**

At Legora, we believe great teams are built on diversity of thought and experience. We’re proud to be an equal opportunity employer and committed to creating an inclusive, high-performance culture where everyone can do their best work. We welcome people of all backgrounds and don’t discriminate based on race, color, religion, national origin, gender, gender identity or expression, sexual orientation, age, disability, veteran status, or any other characteristic protected by law.

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
