# Senior MVNO Manager

Posted: 2026-09-18T02:20:18Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**About Us**

1GLOBAL is a technology-driven global mobile communications provider helping enterprises and consumer brands deliver seamless connectivity worldwide. Powered by a best-in-class telecom platform, proprietary eSIM technology, and its own mobile core network across 15 countries, 1GLOBAL operates as a fully regulated telecommunications provider in 43 countries.

Founded in 2022, 1GLOBAL has rapidly become one of Europe's fastest-growing telecom technology companies, connecting more than 80 million people and devices globally. Our customers include leading banks, multinational enterprises, global retailers, travel companies, payment service providers, and digital-first businesses.

Headquartered in the Netherlands, with R&D hubs in Lisbon, Berlin, and São Paulo, 1GLOBAL employs over 550 professionals across 16 countries. With annual revenues exceeding US$200 million and a strong track record of profitability, we continue to invest in innovation, infrastructure, and international expansion as we redefine the future of global mobile connectivity.
**
About the Team**

1GLOBAL’s Wholesale team is a fundamental enabler for the 1GLOBAL business and this is a critical and high profile role at the heart of Wholesale’s activities. The Wholesale team is responsible for the establishment and management of relationships with mobile operators who provide 1GLOBAL with connectivity into our global core network from which we serve not just our own IoT and business customers but also important channel partners who we are enabling to set up their own MVNOs. We’re working with brands like Revolut and LIDL to enable them to offer domestic service across Europe. And there’s more coming! The Senior MVNO Manager will act as the account manager for all our MVNO relationships to ensure we have the most effective commercial structure in place to meet the future requirements of the business. This role will be vital not just for the expansion of 1GLOBAL’s own MVNO footprint but also to ensure that the we have the right MNO partnerships to enable the likes of Revolut to keep growing their global footprint too.

We’re a global team and are open to hiring candidates based in Berlin, London, Lisbon, or Amsterdam.
**
About the Role**

- Working across the business to ensure the existing MVNO businesses are maximized and opportunities for growth are realized, reducing the Minimum Revenue Guarantee (MRG) shortfalls in key countries.
- Looking at how we get MVNO-type access into additional countries outside the existing MVNO base, both for the 1GLOBAL footprint and for the new rollouts we’ll be doing with Revolut and other partners. Working cross-functionally in order to drive and oversee implementation.
- Advising the business of the correct country structure for each of our MVNO countries e.g. identifying whether an MVNO remains appropriate to achieving our business goals.
- Owning operational performance against contract, including service level measures, escalations, and change requests.
- Negotiating all MVNO agreements/addendums – including ensuring the timely implementation of all new technologies including VoLTE, 5G & LPWAN as part of the MVNO agreements

**Requirements**

**About You**

**Must Have**

- Good experience in mobile wholesale (ideally MVNO/MVNE and/or roaming)
- Strong understanding of the mobile sector and technology
- Excellent commercial skills and a strong analytical ability
- Excellent communicator; highly organised; forthright; able to work independently with minimal supervision.
- Driven, energetic, and resilient, able to thrive under pressure in a fast-paced, high-growth environment
- Ability to think creatively and strategically and translate strategic thinking into solid deliverables and plans
- Able to form strong relationships both with our partners and internal stakeholders

**
Nice to Have**

- A solid base of industry contacts
- Track record launching an MVNO from scratch or scaling one across new markets
- Knowledge of telecom regulatory environments (Ofcom, FCC, national regulators) across relevant markets
- Experience in fintech or telecom-adjacent sectors

**Benefits**

**Why 1GLOBAL?**

- **Growth Opportunities:** Advance your career in one of the fastest growing telecommunications companies, expanding over 50% year-on-year under the leadership of successful tech entrepreneurs.
- **Major Transaction Exposure:** Be in the driver’s seat for transactions that will have an impact on the future telco industry.
- **Work with a Talented Team:** From the Board and the Founders to the Senior Management Team, you will collaborate daily with the most capable and renowned external advisors and constantly being exposed to talented and driven individuals.
- **Dynamic Work Environment:** Thrive in a collaborative, fast-paced workplace where innovation is encouraged, and every contribution counts.
- **Professional Development: **Work alongside industry experts to enhance your skills and knowledge in a cutting-edge field.
- **International Experience:** Gain opportunities to work in different 1GLOBAL offices around the world as you grow within the company.
- **Open Communication Culture:** Join a team where your ideas are heard, and open dialogue is encouraged, fostering a supportive and transparent work environment.
- **Get Things Done Attitude:** Be part of a results-driven team that values efficiency, creativity, and the drive to make a tangible impact in the industry.

*
1GLOBAL is an equal opportunity employer, we value your character as much as your talent. Diversity drives our innovation, and we offer a collaborative, dynamic, and international work environment. We are excited for you to join our mission to revolutionise connectivity globally.*

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
