# Partner Solutions Architect - MSP

Posted: 2026-09-18T02:55:20Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Come join the organization that is redefining security for the AI era. As one of the[ fastest-growing startups ever,](https://www.wiz.io/blog/100m-arr-in-18-months-wiz-becomes-the-fastest-growing-software-company-ever) we enable teams to secure cloud and AI applications by connecting code, cloud, and runtime into a single shared context. Trusted by security teams all over the world, we have a proven[ track record of success](https://www.g2.com/products/wiz-wiz/reviews) and a culture that values world-class talent. Not to mention, we're now[ powered by Google](https://cloud.google.com/blog/products/identity-security/google-completes-acquisition-of-wiz), meaning we offer our customers an AI-powered platform that harnesses Google’s Threat Intelligence and Security Operations to better detect, prevent, and respond to threats across all environments, allowing for further innovation.

Our Wizards from all over the globe work together to protect the infrastructure of our customers, including over 65% of the Fortune 100, who trust us to scan and secure over 230 billion files daily. We’re honored to be a leading player in a massive and growing market, and we continue to look for exceptional Wizards who are eager to make a significant impact on our team. At Wiz, you’ll have the freedom to think creatively, dream big, and use your full range of skills to contribute to our momentous growth. Come join our team and help us create secure cloud environments that allow even the best companies to move faster, all while having some fun!

## Role Description

As a Partner Solutions Architect, you'll be a key member of our EMEA Partner team, focusing on MSP partners. Reporting to the Manager, Partner Solutions Architecture, you'll work closely with partner-facing account reps and directly with partners to build and execute the MSP technical strategy for Wiz + Partner solutions from the ground up.

You'll be the go-to technical expert, helping partners rethink cloud security and position the Wiz + Partner solution with customers. You'll be the trusted technical advisor for all things related to cloud security across AWS, Azure, GCP, and other strategic CSPs.

At Wiz, we're passionate about technical sales and helping our partners and their customers achieve maximum value. This starts with a team effort, collaborating with all available Wiz resources and teaming with the best partners in the world.

## Responsibilities

-

Drive technical strategy and solution development with MSP Partners in EMEA.

-

Build and deliver world-class demos and technical enablement experiences for our partners.

-

Architect and integrated solution and messaging in EMEA, aligning with the MSP global team.

-

Deeply engage with MSP Partner technical teams to build champions and identify opportunities to leverage technical integrations to drive deal acceleration.

-

Serve as a technical evangelist and trusted advisor for cloud security, representing Wiz at partner and industry events.

-

Assist partners in building a strong technical business delivery model around Wiz.

-

Travel up to 40% of the time as needed.

## Minimum qualifications

-

Cloud security expertise with a strong understanding of CSPM, CIEM, IaC security, container security, and serverless security.

-

Deep hands-on experience with AWS, GCP, and/or Azure.

-

Strong operating system, virtual machine, and container knowledge.

-

DevOps experience and familiarity with CI/CD processes.

-

Understanding of cloud identity, access, certificates, and keys.

-

Experience in a sales engineering role delivering solutions to C-level executives at Technology Partners.

-

Experience with MSP Programs.

## Preferred qualifications

-

Experience with traditional CSPM tools.

-

SaaS selling experience.

-

CSP Certifications (e.g., AWS, Azure, GCP).

-

Knowledge of risk-based security assessments and frameworks.

*Applicants must have the legal right to work in the country where the position is based, without the need for visa sponsorship. This role does not offer visa sponsorship.*

Wiz is an equal opportunity employer. We do not discriminate based upon race, religion, color, national origin, sex (including pregnancy, childbirth, reproductive health decisions, or related medical conditions), sexual orientation, gender identity, gender expression, age, status as a protected veteran, status as an individual with a disability, genetic information, political views or activity, or other applicable legally protected characteristics.

By submitting your application, you acknowledge that Wiz will process your personal data in accordance with [Wiz's Privacy Policy.](https://www.wiz.io/legal/privacy)

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
