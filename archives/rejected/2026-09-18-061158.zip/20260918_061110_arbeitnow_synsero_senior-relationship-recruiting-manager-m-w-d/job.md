# (SENIOR) Relationship & Recruiting Manager (m/w/d)

Posted: 2026-09-18T02:09:04Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**Kurzbeschreibung**

Du liebst es, Menschen und Unternehmen erfolgreich zusammenzubringen? Dann bist Du bei uns genau richtig.

Als (Senior) Relationship & Recruiting Manager (m/w/d) verantwortest Du die Besetzung anspruchsvoller Fach- und Projektpositionen im Industrie- und Energiesektor. Dabei begleitest Du Freelancer von der ersten Ansprache bis zur erfolgreichen Vermittlung und arbeitest eng mit unserem Account Management zusammen.
Mit Deinem Gespür für Menschen, Deinem Blick auf den Markt und Deiner Leidenschaft für Recruiting identifizierst Du die besten Experten, führst Interviews, entwickelst nachhaltige Talentpools und berätst Kunden sowie Kandidaten als vertrauensvoller Ansprechpartner. Gleichzeitig bringst Du eigene Ideen ein, optimierst Prozesse und trägst aktiv zum Wachstum unseres Geschäfts bei.

**Deine Aufgaben**

- Du verantwortest den gesamten Recruiting-Prozess zur Besetzung spannender, nationaler und internationaler Positionen in Unternehmensübergreifenden Bereichen – von Projektmanagern, über SAP und PLM Spezialisten, bis hin zu Engineering Rollen – und arbeitest dabei eng mit unserem Account Management im 180°- Modell zusammen.
- Du beobachtest den aktuellen Kandidatenmarkt und trittst bei unseren Kunden und Beratern als Experte rund um das Thema Recruiting auf.
- Du gehst auf unterschiedlichen Businessportalen aktiv auf die Suche nach Experten, pitchst die zu besetzende Position und begeisterst potenzielle Kandidaten für uns und unsere Kunden.
- Du analysierst CV´s und führst Interviews, um einen optimalen Fit sicherzustellen und die beste Vorauswahl für Deine Projekte zu treffen.
- Du begleitest deine Experten entlang des gesamten Besetzungsprozesses vom Erstkontakt bis zur erfolgreichen Vermittlung, verhandelst Konditionen und stehst beratend zur Seite.
- Du sorgst für eine nachvollziehbare und gute Struktur in unserem CRM und baust den Kandidatenpool weiter aus
- Du arbeitest eng mit dem Account Management zusammen und betreust mehrere Großkunden

**Dein Profil**

- Du hast idealerweise erste Berufserfahrungen im Recruiting von bereichsübergreifenden Positionen im Industrie und Energiesektor oder verwandten Berufsfeldern und kennst die Personaldienstleistungsbranche.
- Du kannst erste Erfolge in der Entwicklung effektiver Recruitingstrategien nachweisen und verstehst es, eine Kandidatenpipeline aufzubauen.
- Du bist versiert im Umgang mit den gängigen Tools und bist bereit, neue Wege zu gehen, um die besten Experten zu finden.
- Du hast Erfahrung im Datenmanagement von CRM Daten.
- Du hast eine Leidenschaft für das Peoplebusiness, gehst proaktiv auf Menschen zu und hast Spaß an der Kommunikation mit unterschiedlichen Stakeholdern.
- Du hast Spaß daran Prozesse zu verbessern und aktiv mitzugestalten
- Du lebst eine ergebnisorientierte Arbeitsweise mit einem hohen Maß an Eigeninitiative und Durchhaltevermögen.
- Du verfügst idealerweise über einen Hochschulabschluss aus dem Bereich Wirtschaft
- Du verfügst über sehr gute Deutschkenntnisse (mind. C1 Niveau) und sprichst fließend Englisch (mind. B2-C1 Niveau).

**Was wir Dir bieten**

- **Attraktives Gehaltspaket** mit zusätzlichen Benefits
- **Individuelle Entwicklung**: Mentor ab Tag 1, interne & externe Trainings
- **Modernste Technik** und Ausstattung um sich auf die wesentlichen Dinge zu konzentrieren
- **Work-Life-Balance**: 30 Urlaubstage zzgl. 24.12. und 31.12., Homeoffice & flexible Arbeitszeiten
- **Teamtag:** Mittwochs treffen wir uns alle im Büro um die Gemeinschaft zu stärken und werden auch mit einem Team-Lunch gestärkt
- **Mobilität & Familie**: MVV-Zuschuss (bis 100 €/Monat), Kinderbetreuungszuschuss
- **Extras**: Spendit-Karte (47 €/Monat), Zugang zu Wellhub, betriebliche Altersvorsorge, kostenlose Getränke & frisches Obst
- **Modernes Büro** im Herzen Münchens mit Dachterrasse, welche zum verweilen einlädt
- **Teamspirit**: Regelmäßige Events & ein motiviertes Umfeld sowie ein modernes Büro mit bester technischer Ausstattung

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
