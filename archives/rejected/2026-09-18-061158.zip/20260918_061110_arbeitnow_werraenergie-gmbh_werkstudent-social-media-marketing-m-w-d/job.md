# Werkstudent Social Media | Marketing (m/w/d)

Posted: 2026-09-17T17:30:32Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
