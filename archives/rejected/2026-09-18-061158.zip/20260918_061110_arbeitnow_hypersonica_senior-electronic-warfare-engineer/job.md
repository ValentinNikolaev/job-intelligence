# Senior Electronic Warfare Engineer

Posted: 2026-09-18T05:04:51Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**Help Build Europe's Hypersonic Capability**

At **Hypersonica**, we’re redefining what’s possible in European defence technology. We exist to deliver speed, resilience, and technological independence at a pace that sets a new standard. We are a small, elite team working on problems that matter, and solving them fast.

By joining **Hypersonica**, you’re not stepping into a predefined role. You’re joining a talent dense environment where every individual shapes the direction of the company. Our philosophy is to hire a small number of exceptional people with broad, deep technical capability, strong judgement, and the ability to operate autonomously.

We hire for talent, not rigid boxes. This role represents a business need, but the way it evolves will be shaped by the individual. If you’ve achieved what others said was impossible, or you bring a unique combination of skills that doesn’t fit a traditional mould, we want to hear from you. The work you do here directly contributes to Europe’s technological independence.

**What you'll do **

-

Own the system architecture of Hypersonica's Electronic Warfare (EW) capability, ensuring electronic support (ES), electronic attack (EA), and electronic protection (EP) functions operate as a coherent and mission-effective system.

-

Define, maintain, and manage EW system requirements, ensuring full traceability from operational needs through system architecture, subsystem allocation, verification, and validation.

-

Lead the development of EW system architectures, performance budgets, interface definitions, and mission integrations across airborne platforms and payloads.

-

Conduct threat, signal, and electromagnetic environment analyses to assess system effectiveness against representative adversary capabilities and operational conditions.

-

Lead the integration of RF sensors, receivers, transmitters, antenna systems, signal processing functions, mission computers, and platform interfaces into a coherent operational capability.

-

Define and oversee system-level modelling, simulation, laboratory testing, ground trials, and flight trials, using evidence-based analysis to drive design improvements and risk reduction.

-

Produce and maintain critical systems engineering artefacts including system specifications, interface control documents (ICDs), verification strategies, test plans, and design review materials.

-

Apply model-based systems engineering (MBSE) principles to ensure traceability between requirements, architectures, analyses, verification activities, and operational outcomes.

-

Identify and mitigate system-level risks, particularly around electromagnetic performance, interoperability, survivability, cybersecurity, verification, and platform integration.

-

Act as the technical authority for EW system engineering, working across RF, software, hardware, mission systems, cybersecurity, safety, and platform engineering disciplines to deliver robust operational capability.

**Who you are **

-

An experienced Systems Engineer with 8+ years of experience delivering complex Electronic Warfare, RF, mission systems, avionics, aerospace, defence, or other mission-critical systems.

-

Strong background in systems architecture, requirements development, requirements decomposition, verification, and validation throughout the engineering lifecycle.

-

Deep understanding of Electronic Warfare concepts, including electronic support (ES), electronic attack (EA), electronic protection (EP), threat systems, and electromagnetic spectrum operations.

-

Experience integrating RF sensors, receivers, transmitters, antennas, signal processing systems, and mission computers into operational platforms.

-

Strong knowledge of electromagnetic environments, system performance analysis, modelling, simulation, and test methodologies.

-

Familiar with MBSE approaches and capable of applying systems engineering rigour to complex, multidisciplinary defence programmes.

-

Experienced supporting major design reviews, platform integration activities, flight trials, qualification programmes, and operational capability development.

-

Technically credible across multiple disciplines, capable of influencing decisions, challenging assumptions, and driving technical direction confidently.

-

Comfortable operating within fast-moving, high-accountability environments where ambiguity is high and execution speed matters.

-

Motivated by solving nationally significant defence challenges and building capabilities that directly contribute to European security and technological independence.

**Security and Eligibility Requirement **

Due to the nature of the work done at Hypersonica, applicants must be an EU/Nato/German citizen and be eligible for Security Clearance.

**What we offer **

-

A mission-driven environment with the opportunity to work on one of Europe’s most consequential defence challenges, with direct impact on sovereign capability and security.

-

Daily collaboration with top experts across engineering, operations, and defence, with real opportunity to learn from the best, contribute, and grow.

-

High ownership and autonomy; no time tracking, no micromanagement, just clear objectives and accountability for outcomes.

-

A fast-paced environment where good ideas are implemented quickly, and feedback from testing and operational activities drives real decisions.

-

A culture that values clarity, integrity, and excellence, and supports people who take initiative and push boundaries responsibly.

-

Competitive compensation and real share options aligned to responsibility and impact, not tenure or hierarchy.

At Hypersonica, every hire raises the bar. We are deliberately small, intensely capable, and deeply mission-driven. If this role feels like a strong fit, or if you believe you bring something exceptional that goes beyond the description, we encourage you to apply.

Hypersonica is an equal-opportunity employer and assesses candidates solely on merit, capability, and potential.

You can apply directly to this role or reach out to Nathan Sweeney, Head of Talent. We review every application and aim to respond to all candidates within two weeks, whether the answer is yes or no.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
