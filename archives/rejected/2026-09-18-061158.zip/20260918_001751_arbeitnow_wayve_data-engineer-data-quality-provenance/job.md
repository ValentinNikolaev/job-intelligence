# Data Engineer, Data Quality & Provenance

Posted: 2026-09-17T20:55:25Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

## **About us **

Founded in 2017, Wayve is the leading developer of Embodied AI technology. Our advanced AI software and foundation models enable vehicles to perceive, understand, and navigate any complex environment, enhancing the usability and safety of automated driving systems.

Our vision is to create autonomy that propels the world forward. Our intelligent, mapless, and hardware-agnostic AI products are designed for automakers, accelerating the transition from assisted to automated driving.

In our fast-paced environment big problems ignite us—we embrace uncertainty, leaning into complex challenges to unlock groundbreaking solutions. We aim high and stay humble in our pursuit of excellence, constantly learning and evolving as we pave the way for a smarter, safer future.

At Wayve, your contributions matter. We value diversity, embrace new perspectives, and foster an inclusive work environment; we back each other to deliver impact.

Make Wayve the experience that defines your career!

## **The role**

As a Data Engineer focused on Data Quality & Provenance, you will build the data foundation that enables Wayve’s autonomous-driving development. You’ll turn vast volumes of fleet and simulation data into trusted, discoverable and reproducible datasets that ML, autonomy, simulation and safety teams can use with confidence. This is a high-impact opportunity to define the data products, standards and operating model behind embodied intelligence at petabyte scale.

Key responsibilities:

- Design, build and operate scalable batch and streaming pipelines for multimodal fleet and simulation data.

- Create data models, catalogs, indexes and query capabilities that make sensor, vehicle-state, map and event data easy to discover and use.

- Build versioned, reproducible datasets for training, evaluation, replay, scenario mining and safety analysis.

- Develop robust workflows for data ingestion, synchronisation, transformation, curation, labelling and data-quality validation.

- Partner with autonomy, ML, simulation and safety engineers to define schemas, APIs and data contracts.

- Establish strong standards for lineage, observability, access controls, retention and cost management across the data platform.

- Improve the performance, reliability and unit economics of large-scale storage and compute workloads.

## **About you**

In order to set you up for success as a Data Engineer, Data Quality & Provenance at Wayve, we’re looking for the following skills and experience.

Essential

- Strong hands-on Python and SQL skills, with solid production software-engineering fundamentals.

- Experience designing and operating large-scale distributed data systems, beyond small-scale analytics or reporting pipelines.

- Hands-on experience with distributed processing and workflow orchestration technologies, such as Spark, Flyte, Airflow or equivalent tools.

- Experience building and operating cloud-based data platforms using object storage, including data organisation, versioning, querying, governance and cost management.

- Proven ownership of data quality, lineage, observability, reproducibility and incident response for production data workflows.

- Experience translating ambiguous requirements from ML, data-science, robotics or similarly technical teams into durable, reusable platform capabilities.

- Comfort operating in ambiguity and helping define the boundaries, standards and ways of working for a growing data platform.

Desirable

- Experience in autonomous vehicles, ADAS, robotics, mapping, drones or another sensor-rich domain.

- Familiarity with time-synchronised sensor data, geospatial data, or multimodal datasets.

- Understanding of ML training, evaluation, simulation or closed-loop development workflows.

This is a full-time role based in our office in Leonburg, Germany. At Wayve we want the best of all worlds so we operate a hybrid working policy that combines time together in our offices and workshops to fuel innovation, culture, relationships and learning, and time spent working from home.

Wayve is committed to creating an inclusive interview experience. If you require any accommodations or adjustments to participate fully in our interview process, please let us know.

We understand that everyone has a unique set of skills and experiences and that not everyone will meet all of the requirements listed above. If you’re passionate about self-driving cars and think you have what it takes to make a positive impact on the world, we encourage you to apply.

At Wayve we're committed to creating a diverse, fair and respectful culture that is inclusive of everyone based on their unique skills and perspectives, and regardless of sex, race, religion or belief, ethnic or national origin, disability, age, citizenship, marital, domestic or civil partnership status, sexual orientation, gender identity, veteran status, pregnancy or related condition (including breastfeeding) or any other basis as protected by applicable law.

For more information visit [Careers at Wayve. ](https://wayve.ai/careers/)

To learn more about what drives us, visit [Values at Wayve ](https://wayve.ai/careers/)

For US candidates only, please visit [E-Verify Notice](https://drive.google.com/file/d/1N46n3iN0AG8EPEO-hCanyyv7hzz8KgT_/view?usp=sharing) and [Participation and Right to Work](https://www.ussc.gov/sites/default/files/pdf/employment/RightToWork.pdf)

DISCLAIMER: We will not ask about marriage or pregnancy, care responsibilities or disabilities in any of our job adverts or interviews. However, we do look to capture information about care responsibilities, and disabilities among other diversity information as part of an optional DEI Monitoring form to help us identify areas of improvement in our hiring process and ensure that the process is inclusive and non-discriminatory.

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
