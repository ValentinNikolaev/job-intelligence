# Working Student – Invoice Checking (d/f/m)

Posted: 2026-09-18T02:09:35Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**About us**

Since 2000, [ITA Logistics Group](https://www.italogistics.com/) has been making shipping simpler, more transparent, and more efficient for businesses. With our platforms [LetMeShip](https://www.letmeship.com/) and [ParcelParcel](https://www.parcelparcel.com/nl_EN/en-home/)/ [LMS Next](https://www.letmeship.com/lms-switch/), companies can quickly compare and directly book their daily shipping needs. By bringing together a wide range of carriers on our platforms, we combine modern technology with personal service.

Across several locations in Europe, our teams work every day to simplify shipping processes in a sustainable way. We believe in open collaboration and fast decision-making. That’s why we are looking for people who take ownership, contribute ideas, and want to actively shape the future with us.

**Your mission**

As a Working Student (d/f/m) in our Invoicing Team, you will join us at the earliest possible date and support us with reviewing carrier invoices, contributing to efficient and reliable billing processes. You will be part of an international team of seven colleagues, based across Hamburg, Naarden, Nantes, and Madrid.

You can look forward to a working environment where mutual support, team spirit, and positive collaboration are at the heart of how we work.

**Your Key Responsibilities**

-

You are responsible for reviewing and checking carrier invoices across different brands and countries.

-

You handle related invoice claims and clarify any discrepancies.

-

You review carrier rates and ensure they are correctly reflected in the invoice checks.

-

You gather the information required for invoice checks from relevant stakeholders and coordinate with them.

-

As part of the invoice checking process for LMS Next, you also support the posting of carrier invoices.

-

You support the testing of improvements to the invoice checking process before they are implemented.

-

You support the implementation of our new accounting system, Microsoft Dynamics 365 Business Central.

**What you need to succeed**

-

You are currently enrolled at a university and would like to gain practical experience in invoice checking, accounts payable/receivable, and an international working environment.

-

You enjoy working with numbers and have a careful and accurate approach to your work.

-

You approach your tasks in a structured, efficient, and independent manner.

-

You are open-minded, curious, and enjoy working as part of a team.

-

You have good to very good proficiency in German and English, enabling you to communicate confidently within our international team.

-

Initial knowledge or experience in the transport and logistics sector is an advantage, but not a requirement.

**Why ITA Logistics Group?**

You can expect a work environment where new ideas are genuinely welcomed and feedback is not just accepted, but actively encouraged. We challenge the status quo, embrace agile ways of working, and continuously evolve. This also means making use of modern digital tools and AI-driven solutions that support your day-to-day work and help make processes more efficient.

-

30 days of vacation

-

Flexible working hours and hybrid work

-

Time tracking and overtime compensation

-

Subsidized HVV/Deutschlandticket or parking

-

SpenditCard with a monthly credit of €50

-

Corporate Benefits Program

-

Counseling and support services through the Fürstenberg Institute

**Join the ITA Crew**

You feel addressed and are interested in joining our team as a Working Student – Invoice Checking (d/f/m) in beautiful Hamburg?
Please apply stating your earliest possible starting date! Ulrike Le Quéré is looking forward to your application.

We welcome applications from people of all genders, backgrounds, ages, disabilities, sexual orientations, and religions.

Applicants with severe disabilities will be given preferential consideration if equally qualified.

You can find more information at[ www.letmeship.com](http://www.letmeship.com).

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
