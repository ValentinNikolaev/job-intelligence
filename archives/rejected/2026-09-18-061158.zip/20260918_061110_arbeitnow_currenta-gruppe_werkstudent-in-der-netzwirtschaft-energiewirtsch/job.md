# Werkstudent in der Netzwirtschaft / Energiewirtschaft (m/w/d)

Posted: 2026-09-18T02:30:10Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Die CURRENTA GRUPPE sucht **Dich** für die Business Unit **Energy**.

Als **Werkstudent*in in der Netzwirtschaft / Energiewirtschaf**t bist du für die folgenden Aufgaben verantwortlich:

-

Du hilfst bei der Bearbeitung von energiewirtschaftlichen & regulatorischen Grundsatzfragen.

-

Im Rahmen der Anwendung gesetzlicher Neuerungen sammelst du praxisnahe Einblicke in die Energiewirtschaft und kannst so neben der Vertiefung deiner Fachkenntnisse deine Ideen in die weitere Umsetzung mit einbringen.

-

Du hilfst uns bei der Datenerfassung und Datenanalyse rund um den Netzbetrieb.

-

Du hast die Möglichkeit an übergreifenden Projekten wie beispielsweise Redispatch 2.0 oder dem Ausbau erneuerbarer Energien mitzuwirken.

-

Du absolvierst Dein Studium im Bereich der Ingenieurs-, Natur- oder Wirtschaftswissenschaften oder einen vergleichbaren Studiengang mit einem Schwerpunkt der Energiewirtschaft.

-

Du hattest idealerweise bereits erste Berührungspunkte mit einem Unternehmen aus der Industrie (Studium, Beruf oder privat).

-

Deine strukturierte und lösungsorientierte Arbeitsweise zeichnet dich aus.

-

Du zeigst Teamfähigkeit und Kommunikationsstärke.

-

Du bist motiviert die Welt der regulierten Netzwirtschaft näher kennenzulernen und mit den Besonderheiten eines Chempark-Betreibers zu verknüpfen.

**Hinweis:**

Die Gehaltsangabe basiert auf einer Wochenarbeitszeit von 20 Stunden in Teilzeit und je nach Studiengrad (Bachelor / Master). In den vorlesungsfreien Zeiten ist eine Stundenaufstockung möglich.

*Die Veröffentlichung dieser Anzeige auf Drittanbieter-Portalen ohne unsere ausdrückliche Zustimmung ist untersagt.*

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
