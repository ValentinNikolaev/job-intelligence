# Sr Agent Architect (Germany)

Posted: 2026-08-30T23:55:18Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

## **About Parloa**

Parloa’s mission is to make every customer conversation feel effortless for both customers and the companies serving them. As agentic AI accelerates, Parloans are shaping the foundation of a new era in customer experience - one where customer support is no longer transactions, but meaningful exchanges. It is not just a vision; Parloa has powered over ONE BILLION interactions between global enterprise brands and their customers, with companies like Booking.com, HealthEquity, Allianz, SAP, BarmeniaGothaer, and TUI already deploying Parloa at scale.

## **About the role**

As a **Sr Agent Architect** at Parloa, you will act as a solution architect for enterprise AI Agent deployments. You will design end-to-end system architectures that connect Parloa's platform to complex enterprise environments, solve multi-system integration challenges, and apply systems thinking to build reliable, scalable AI solutions for global enterprise clients.

You will also shape the conversational experience layer, using prompt engineering and your knowledge of LLMs to translate customer requirements into agent behavior. Architecture and integration depth are the core of this role. Conversational design skills are valued and can be developed on the job.

## **Areas of ownership**

- Design end-to-end solution architectures for AI Agent deployments, mapping how Parloa's platform integrates into customers' enterprise systems (CRMs, ERPs, ticketing systems, contact center platforms).

- Build and configure integrations using integration platforms and APIs, applying systems thinking to solve complex, multi-system data flows.

- Collaborate with Forward Deployed Engineers on complex or custom integration scenarios that go beyond standard integration capabilities.

- Apply structured testing approaches to validate architecture, integration reliability, and AI agent performance under real-world conditions.

- Identify and resolve blockers together with other departments at Parloa (e.g., Product, Solution Engineering, Sales) and the customer.

- Scope AI Agent deployments, providing strategic architecture advice and execution support to customers and partners.

- Use your knowledge of LLM internals (e.g., embeddings) to analyze customer requirements and design prompts for reliable, user-aligned agent behavior.

- Translate complex customer workflows into structured conversational components that LLMs can execute reliably.

- Fine-tune conversational flows and voice output (e.g., SSML, Lexicons, Regex) to align with customer brand standards.

- Document best practices, how-to guides, and product capabilities for internal and external audiences, representing the expertise of the Agent Architect team.

## **Who you are**

- 3+ years of experience in enterprise customer-facing roles, with proven expertise in solution architecture, systems architecture, or enterprise integration.

- Strong systems thinking, with a track record of solving complex technical problems across multiple systems and data sources.

- Experience with complex SaaS implementations at scale (CRMs, ERPs, contact center platforms, ticketing systems).

- Proficiency in REST API design, JSON/XML data structures, API testing tools (e.g., Postman), and API authentication patterns (OAuth, API keys, JWT).

- Experience reading and consuming API documentation across enterprise SaaS platforms, including data transformation and field mapping logic.

- Analytical and critical thinker with expertise in risk assessment and problem-solving.

- Strong project and stakeholder management skills, with a passion for meeting milestones and effective communication.

- Entrepreneurial mindset with initiative, results orientation, and ability to identify opportunities for impact.

- Ability to analyze customer requirements and translate them into LLM prompts and conversational flows, with attention to subtle conversational nuance and A/B testing to assess agent performance.

- Prior conversation design, prompt engineering (e.g., chain-of-thought, few-shot learning), or A/B testing experience is a plus, not a requirement - we will train this.

- Excellent written and spoken German and English skills are required.

## **Our Recruiting Process:**

Talent Acquisition → Hiring Manager → Technical Interview(s) → Bar Raiser

### Why Parloa?

We're at the beginning of a new era in customer experience, one where AI doesn't just respond, but understands, reasons, and takes action. We're building agentic AI that enterprises trust with their most important customer moments: complex questions, high volumes, real stakes. When millions of people reach out to a brand, those interactions aren't just support tickets; they're defining experiences. We're here to raise the standard: making every conversation seamless, intelligent, and genuinely helpful. If you care about shaping how businesses and customers connect at scale and want your work to matter in real, everyday moments, this is where you do it.

At Parloa, ownership isn't a buzzword; it means being accountable for outcomes, not just tasks. We operate in a category that's evolving fast, where the bar is high, and the problems are complex. We hire people who think in solutions, communicate with clarity, and follow through. People who are comfortable making decisions, taking responsibility, and raising the standard for themselves and those around them.

We've grown beyond the earliest startup phase, but we've kept the intensity: fast execution, direct feedback, and a strong expectation to contribute meaningfully from day one.

Backed by leading global investors like General Catalyst, EQT Ventures, and Altimeter Capital, we're scaling with a clear ambition: to become the global category leader in enterprise-grade conversational AI.

Parloa is committed to upholding the highest data protection standards for our clients' and employees' data. All our employees are instrumental in ensuring the utmost care, GDPR, and ISO compliance, including ISO 27001, in handling sensitive information.

Parloa is an e-verify employer in the USA. [Please click here to learn more](https://www.e-verify.gov/about-e-verify/what-is-e-verify).

*** ****We provide equal opportunities to all qualified applicants regardless race, gender, sexual orientation, age, religion, national origin, disability status, socioeconomic background and other characteristics.**

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
