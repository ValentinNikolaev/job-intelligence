# Werkstudent Elektrotechnik / Energietechnik (m/w/d)

Posted: 2026-08-30T17:30:03Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
