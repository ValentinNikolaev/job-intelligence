# Informationssicherheitsbeauftragter (ISB) (m/w/d) | Kritische Infrastruktur | Ruhrgebiet

Posted: 2026-08-31T02:04:47Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

## DAS UNTERNEHMEN

Unser Mandant ist eine etablierte Organisation der kritischen Infrastruktur im Ruhrgebiet.

Das Unternehmen steht für hohe Versorgungsrelevanz, komplexe Betriebsstrukturen und einen starken gesellschaftlichen Auftrag. Mehrere tausend Mitarbeitende tragen täglich zur Stabilität und Sicherheit zentraler Dienstleistungen bei.

Aktuell befindet sich die Organisation in einer Phase erhöhter Anforderungen an:

- Cyber-Resilienz und Informationssicherheit

- regulatorische Compliance (u. a. KRITIS, NIS2)

- Digitalisierung geschäftskritischer Prozesse

- Professionalisierung von Governance-Strukturen

Informationssicherheit ist dabei ein zentraler Bestandteil der Unternehmensstrategie und gewinnt zunehmend an Bedeutung auf Geschäftsleitungsebene.

**DIE HERAUSFORDERUNG**

Der Informationssicherheitsbeauftragte (ISB) übernimmt die zentrale Verantwortung für den Aufbau, die Weiterentwicklung und die nachhaltige Verankerung der Informationssicherheit im Unternehmen.

Zu den Kernaufgaben gehören:

- Steuerung und Weiterentwicklung des ISMS (z. B. nach ISO 27001 / BSI-Grundschutz)

- Sicherstellung der Einhaltung regulatorischer Anforderungen im KRITIS-Umfeld

- Beratung von Geschäftsführung und Führungskräften in sicherheitsrelevanten Fragestellungen

- Durchführung von Risikoanalysen sowie Ableitung geeigneter Maßnahmen

- Sensibilisierung und Schulung der Organisation im Bereich Informationssicherheit

- Koordination von Audits sowie Zusammenarbeit mit internen und externen Prüfinstanzen

- Schnittstellenmanagement zu IT, Datenschutz, Compliance und operativen Einheiten

Der Kontext ist geprägt von:

- hoher regulatorischer Dynamik

- steigender Bedrohungslage im Cyberraum

- gewachsenen IT- und Prozesslandschaften

- Spannungsfeld zwischen Sicherheit, Betrieb und Wirtschaftlichkeit

- zunehmender strategischer Relevanz von Informationssicherheit

**IHR PROFIL**

- Mehrjährige Erfahrung im Bereich Informationssicherheit, idealerweise als ISB oder in vergleichbarer Funktion

- Fundierte Kenntnisse relevanter Standards und Regularien (z. B. ISO 27001, BSI, NIS2, KRITIS)

- Erfahrung im Aufbau und Betrieb von Informationssicherheitsmanagementsystemen

- Fähigkeit, komplexe Sachverhalte adressatengerecht aufzubereiten – vom operativen Bereich bis zur Geschäftsleitung

- Strukturierte, analytische und risikoorientierte Arbeitsweise

- Souveränes Auftreten sowie ausgeprägte Kommunikations- und Durchsetzungsfähigkeit

- Erfahrung in regulierten Umfeldern oder Organisationen mit kritischer Infrastruktur ist von Vorteil.

**WAS DIE ROLLE BESONDERS MACHT**

Diese Position bietet die Möglichkeit, Informationssicherheit nicht nur operativ umzusetzen, sondern strategisch zu gestalten.

Gesucht wird keine rein koordinierende Funktion, sondern eine Persönlichkeit, die:

- Sicherheit als integralen Bestandteil der Organisation verankert

- zwischen regulatorischen Anforderungen und operativer Realität vermittelt

- Strukturen schafft, die langfristige Resilienz ermöglichen

- als vertrauensvoller Sparringspartner für das Top-Management agiert

**ÜBER VALPEO**

VALPEO ist eine internationale Leadership-Boutique mit Fokus auf Executive Search, Nachfolgeplanung und Leadership Dynamics.

Wir arbeiten mit Eigentümern, Geschäftsführern und Investoren zusammen, um Führungsfähigkeit sichtbar zu machen und Organisationen in komplexen Phasen nachhaltig zu stärken.

Unser Ansatz verbindet strukturierte Diagnostik, strategisches Verständnis und tiefgehende Auseinandersetzung mit Führung und Entscheidungsreife.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
