# Senior Product Designer

Posted: 2026-08-27T05:40:32Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Taktile empowers financial institutions to transform into truly AI-native organizations. We’re growing rapidly with enterprise customers across banks and insurance companies, and we’re looking for a Senior Product Designer.

**About the role**

We are building the world's leading software platform for running critical and highly-automated decisions. Our customers use our product to catch fraudsters, prevent money laundering, and expand access to credit for small businesses, among many other use cases. Taktile is making millions of such decisions across the globe every day.

We do this through a powerful suite of tools that combine ML/AI with heuristics and logic, flexible data integrations, and an overlay of data analytics. We see a high degree of usability as a key differentiator and have been investing in a world-class UI/UX from day one. To help us deliver our vision, we are seeking talented and experienced Senior Product Designers.

As a Senior Product Designer, you will be responsible for translating highly technical and complex problems into clean and understandable solutions. You will be the voice of user experience and design standards in a cross-functional setting, and responsible for the end-to-end design process for your team. You’ll join a diverse design team and work closely with engineers, marketing and sales to create products that make it easy for our users to make smarter and safer decisions at scale.

**Please not that this role is not open to full remote and is Berlin or London based only*

**What You'll Do**

-

Independently lead all design efforts for a cross functional team within Taktile.

-

Apply design thinking to complex technical problems

-

Continuously learn from user research and be the voice of our customers in product development

-

Conduct competitive analysis of existing products in the marketplace to identify opportunities for improvement

-

Connect business strategies, available technologies, and design solutions to deliver great experiences that impact our users and our business goals

-

Actively validate and iterate to ensure our product concepts are aligned with the business needs and stakeholder expectations

-

Collaborate closely with engineers and ensure that designs are implemented effectively in code

-

Contribute to and work with our Design System

-

Collaborate with other designers to create a coherent user experience across Taktile’s product

**Required Experience**

-

5+ years of experience in Product Design, ideally with B2B SaaS, fintech, or similarly complex technical domains.

-

Proven experience leading design for a product area or cross-functional team.

-

Strong systems thinking and ability to design complex workflows and data-heavy interfaces

-

Ability to translate complex technical and business requirements into clear, scalable user experiences.

-

Experience driving discovery and shaping problem definitions with Product and Engineering

-

Excellent communication skills

**Ideal, But Not Required**

-

Experience designing agentic interfaces and interest in AI-powered products

-

Strong technical understanding that allows you to engage in discussions with the Engineering Team

-

Experience in working in a fast-paced start-up/scale-up environment

-

An interest in fintech and financial services

**Our Offer**

-

Work with colleagues that lift you up, challenge you, celebrate you and help you grow. We come from many different backgrounds, but what we have in common is the desire to operate at the very top of our fields. If you are similarly capable, caring, and driven, you'll find yourself at home here.

-

Experience a truly flat hierarchy and communicate directly with founding team members. Having an opinion and voicing your ideas is not only welcome but encouraged, especially when they challenge the status quo.

-

Learn from experienced mentors and achieve tremendous personal and professional growth. Get to know and leverage our network of leading tech investors and advisors around the globe.

-

Receive a top-of-market equity and cash compensation package.

-

Get access to a self-development budget you can use to e.g. attend conferences, buy books or take classes.

-

Receive a new Apple MacBook Pro, as well as meaningful home office set-up.

**Our Stance**

-

We're eager to meet talented and driven candidates regardless of whether they tick all the boxes. We're looking for someone who will add to our culture, not just fit within it. We strongly encourage individuals from groups traditionally underestimated and underrepresented in tech to apply

-

We seek to actively recognize and combat racism, sexism, ableism and ageism. We embrace and support all gender identities and expressions, and celebrate love in its many forms. We won't inquire about how you identify or if you've experienced discrimination, but if you want to tell your story, we are all ears

**About Us**
Taktile enables financial institutions to transform into AI-native organizations that are increasingly powered by autonomous agents. With our modular Agentic Decision Platform, customers combine AI agents, rules, relevant context, and human oversight to safely automate and optimize their decisions—approving more customers, reimbursing claims instantly, stopping fraud before it spreads, and financing every business worth funding. Founded in 2020, Taktile powers millions of decisions daily for institutions including Mercury, Monzo, Faire, and Pleo. With offices in New York, Berlin, London, São Paulo, and Iași, the company has raised $184M from Growth Equity at Goldman Sachs Alternatives, Index Ventures, Tiger Global, Balderton Capital, and Y Combinator. Learn more at [taktile.com](http://taktile.com)

***About Your Employment.** Taktile operates through regional entities worldwide. Depending on the location of this role, your employment or engagement will be with Taktile LLC (US), Taktile GmbH (Germany), Taktile Ltd (UK), or Taktile SRL (Romania). The applicable entity will be confirmed during the offer process.*

***Your Privacy**. Taktile (“we” or “us”) is the controller of the personal data you provide during this*

*application process. We collect and process your name, contact details, resume/CV, work history, education, and any other information you submit or that we obtain from publicly available sources or references.*

***How we use your data**: We process your personal data to evaluate your candidacy, communicate with you about the recruitment process, comply with legal obligations (such as right-to-work verification), and, with your consent, to consider you for future opportunities.*

***Legal basis (EU/UK applicants):** We rely on (i) pre-contractual steps at your request (GDPR/UK GDPR Art.6(1)(b)), (ii) legal obligations (Art. 6(1)(c)), and (iii) our legitimate interest in evaluating candidates (Art.6(1)(f)).*

***Retention:** If your application is unsuccessful, we retain your data for 12 months after the recruitment process concludes, unless you consent to longer retention. Successful candidates’ data becomes part of their employment records.*

***Your rights: **Depending on your location, you may have the right to access, correct, delete, or restrict the processing of your personal data, to data portability, and to withdraw consent.*

***Automated decision-making:** We use automated tools to assist in screening applications. No hiring decision is made solely by automated means without human review.*

***International transfers:** Your data may be transferred to and processed in the United States, Germany, the United Kingdom, or Romania. Where required, transfers are protected by Standard Contractual Clauses or other approved mechanisms.*

*By submitting your application, you acknowledge that you have read and understood Taktile’s Applicant Privacy Policy. To exercise your rights or ask questions, contact -----

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
