# Data Protection Specialist – Energy, Customer Service (m/w/d)

Posted: 2026-08-27T05:04:53Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Wir sind **nicht **der lokale Stromanbieter um die Ecke. Wir sind das **globale EnerTech-Unternehmen**, das den Energiemarkt revolutionieren wird. Wir haben kein geringeres Ziel, als die global benötigte Energie **100% nachhaltig** zu gestalten. Global, agil und zukunftsorientiert verändern wir den Energiemarkt mit neuer Technologie zum Besseren.

Dabei sind unsere **Ökostromtarife nur die Basis**. Bereits seit 2022 installieren wir Wärmepumpen-Komplettlösungen mit **eigenen Fachkräften**. Außerdem arbeiten wir aktiv an der flächendeckenden Einführung von Smart Metern, **Elektromobilitätslösungen** und der eigenen **Stromerzeugung aus Wind- und Sonnenenergie**.

Das schaffen wir allerdings nicht alleine, sondern dazu brauchen wir dich! Werde Teil unseres Teams und fordere den Status Quo heraus. Mit Energie, die gut für den Planeten ist und gut für dein Karma. 💚 Finde jetzt deinen Traumjob und werde Teil der Energierevolution von Octopus Energy Germany.

**Worum es bei der Rolle geht**

Datenschutz ist für uns kein reines Compliance-Thema. Er ist ein zentraler Bestandteil von gutem Kundenservice. Wir wachsen schnell, arbeiten datengetrieben und stehen täglich in engem Kontakt mit unseren Kundinnen und Kunden. Dafür brauchen wir eine Person, die Datenschutz **operativ denkt, pragmatisch umsetzt und im Alltag verankert**.

Als Data Protection Specialist verantwortest du den Datenschutz in unserem Operations- und Customer-Service-Umfeld. Als erste Anlaufstelle für alle datenschutzrechtlichen Fragen klärst du diese selbstständig oder ziehst bei Bedarf das Legal-Team oder den externen Datenschutzbeauftragten hinzu. Diese unterstützen dich als Sparringspartner bei komplexen Sachverhalten. Dein Fokus liegt auf einer schnellen, lösungsorientierten Bearbeitung, um aus Einzelfällen standardisierte Lösungen für die Bereiche Operations und Customer Service zu entwickeln. Um das sicherzustellen, arbeitest du eng mit unserem Kundenservice Team zusammen und unterstützt das Team bei Bedarf auch operativ im Kundenkontakt.

**Deine Aufgaben**

- Datenschutzrechtliche Prüfung, Aufarbeitung, Beratung sowie Koordination aller Fälle im Bereich Operations und Customer Service.

- Schnittstelle zwischen dem Bereich Operations und Customer Service, dem Legal-Team und unserem externen Datenschutzbeauftragten.

- **Beratung interner Teams** (Customer Service Operations, IT / Technologieplattform, Produkt, Marketing) zu datenschutzrelevanten Fragestellungen.

- Weiterentwicklung und Umsetzung von **Prozessen, Richtlinien und Arbeitsweisen** im Umgang mit Kundendaten.

- **Aufbau und Dokumentation von Datenverarbeitungsprozessen** (Verzeichnis von Verarbeitungstätigkeiten), Datenschutzverletzungen sowie, Datenschutz-Folgenabschätzungen.

- **Aktive Mitarbeit im Kundenservice**, um Abläufe, Systeme und reale Use Cases aus erster Hand zu verstehen.

- Frühzeitige Identifikation von Risiken, Ableitung und Implementierung klarer, umsetzbarer Maßnahmen.

- Gezielter Ausbau von Datenschutz-Know-how im Team durch praxisnahe Schulung und Beratung.

- Zusammenarbeit mit unserem **Technologiepartner** sowie **Abstimmung datenschutzrechtlicher Anforderungen mit Softwareentwicklungsteams**.

**Das bringst du mit **

- **Abgeschlossenes Studium Bachelor of Law (LL.B.), idealerweise mit (Zusatz-)Qualifikation im Datenschutz**, z. B. zertifizierter Datenschutzbeauftragter (TÜV, IHK oder vergleichbar), oder gleichwertige anerkannte Datenschutz-Weiterbildung.

- Mehrjährige **praktische Datenschutz Erfahrung im Customer Service Umfeld**, idealerweise in einem **Wachstumsunternehmen oder Scale-up**.

- Fundierte Kenntnisse der **DSGVO, TDDDG sowie ISO 27001**.

- Erfahrung in der **operativen Umsetzung von Datenschutzanforderungen** in kunden- und datenintensiven Prozessen.

- Fähigkeit, komplexe rechtliche Anforderungen **verständlich und praxisnah** zu übersetzen.

- Erfahrung in der **Zusammenarbeit mit Technologiepartnern und Softwareentwicklungsteams**.

- Pragmatische, lösungsorientierte Arbeitsweise mit Fokus auf Umsetzbarkeit.

- Hohe Eigenständigkeit und Sicherheit im Umgang mit Prioritäten in einem dynamischen Umfeld.

- Ausgeprägte Teamfähigkeit und Freude an der Zusammenarbeit mit Menschen.

- Fließende Deutsch- und Englischkenntnisse.

**Was uns wichtig ist**

- Klare, verständliche Kommunikation ohne unnötige Komplexität.

- Verantwortungsbewusstsein und Hands-on-Mentalität.

- Bereitschaft, Dinge aktiv mitzugestalten.

- Freude an einem Umfeld mit hoher Veränderungsgeschwindigkeit.

Deine Benefits bei uns:

✅ Vergünstigungen & Vorsorge:

- Aktienoptionen der Octopus Energy Group Ltd.

- Vergünstigte Konditionen für unsere Strom- und Gastarife

- Monatlicher Zuschuss zum Nahverkehrsticket

- Monatlicher Zuschuss zum Mittagessen

- Vergünstigtes Fahrradleasing

- Betriebliche Altersvorsorge
- Nachhaltig unterwegs mit unserem E-Auto-Leasing

✅ Familie

- Beratungsangebote und Unterstützung bei Kinderbetreuung über HeyNanny

- Monatlicher Zuschuss zur Kinderbetreuung

- Elterngeld-Bonus: Wir stocken dein Elterngeld für** 3 Monate** auf, damit du deine Elternzeit entspannter genießen kannst

✅ Sport & Gesundheit

- Zuzahlungen zu Fitness- Angeboten über Wellpass

- Förderung deines mentalen Wohlbefindens mit unserem Partner Open Up

✅ Lernen & Weiterbildung

- Attraktive Weiterbildungsmöglichkeiten und Aufstiegsmöglichkeiten

- Kostenlose Sprachkurse über Busuu

✅ Extra Goodies

- Gutschein zu deinem Geburtstag

_________________

Bereit, den Energiemarkt mit uns zu revolutionieren? Erzähle uns, warum genau du uns dabei unterstützen solltest. Schicke uns deinen CV und alles, was wir wissen sollten, über unser Online-Formular. Wir freuen uns auf dich!

Du findest die Stelle super spannend, bist dir aber unsicher, ob du alle geforderten Skills zu 100% erfüllst? Bitte zögere nicht, dich trotzdem zu bewerben!

P.S.: Octopusse gibt es in allen Farben, Formen und Größen. Wir freuen uns auf Mitarbeiter*innen jeden Geschlechts, Alters, jeder sexuellen Identität, Herkunft, Religion, Weltanschauung, mit und ohne Behinderungen. Für uns zählt nur eins: du passt zu uns und brennst darauf, etwas zu verändern.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
