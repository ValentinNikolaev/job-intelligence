# Data Scientist & ML Engineer - Predictive Analytics & Agentic AI

Posted: 2026-08-27T02:30:21Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

#### We Want You to Grow With Us

Data tells stories, and this role is responsible for turning those stories into decisions. As our Data Scientist & ML Engineer, you will develop the predictive, prescriptive, and optimisation models that give Intersnack the analytical foresight to act confidently across procurement, manufacturing, and sales. You will report into the AI Programme and work alongside AI engineers and data engineers to integrate your models into the knowledge and agentic AI frameworks being built across the organisation, combining classical machine learning rigour with the emerging capabilities of large language models and intelligent agents. Intersnack is committed to growing its people as it grows its capabilities, and this role offers a unique vantage point from which to shape how AI reasoning is embedded into a global business.

#### What We Can Offer

You will have the opportunity to work across a wide and commercially meaningful range of modelling challenges, from demand forecasting and process optimisation in manufacturing, to procurement analytics and scenario modelling, with direct access to the business stakeholders whose decisions your models will inform. This is not a role where models sit in notebooks; your work will be operationalised, monitored, and iterated upon in production environments. You will collaborate with AI architects and engineers to integrate predictive logic into agentic workflows, giving your models a reach and impact that scales beyond individual use cases. Dusseldorf is your home base, with flexibility for remote working, and Intersnack's international footprint ensures your models will operate at genuine scale.

#### How You Will Spend Your Time as Our Next Data Scientist & ML Engineer - Predictive Analytics & Agentic AI

You will divide your time between developing new models and improving existing ones, integrating machine learning outputs into agentic and analytical systems, and actively enabling business stakeholders to understand and trust what those models produce. Your work connects the technical rigour of statistical modelling and ML engineering with the commercial intent of a business that wants AI to create real, measurable value.

**What You Will Do**

-

Develop, validate, and deploy predictive, prescriptive, and optimisation models for core business domains including procurement, manufacturing, and sales, translating data into actionable foresight and recommendations

-

Build, fine-tune, and adapt large language models (LLMs) and specialised language models for business-specific NLP tasks, including analysis of unstructured operational data

-

Design and implement simulation and scenario-modelling frameworks that enable business teams to explore trade-offs and plan under uncertainty

-

Integrate machine learning and predictive logic into agentic AI workflows, combining model outputs with agent reasoning to support automated and semi-automated decision-making

-

Own the full ML lifecycle for your models, from feature engineering and training through to deployment, versioning, and ongoing monitoring, applying MLOps best practices throughout

-

Apply NLP techniques to unstructured business data, extracting structured signals from documents, communications, and operational records to support analytics and AI use cases

-

Communicate model outputs, limitations, confidence levels, and underlying assumptions clearly to business stakeholders, fostering understanding, trust, and appropriate adoption of AI-generated insights

-

Embed security and governance considerations into model design, including protections against prompt injection, data leakage, and adversarial inputs, in line with Intersnack's AI security standards

-

Support colleagues in developing AI and data literacy, actively contributing to the cultural change programme that accompanies Intersnack's broader AI adoption journey

#### **Essential Skills & Experience**

-

Demonstrated experience developing and deploying predictive and prescriptive machine learning models in large-scale production environments, with a strong foundation in statistical modelling and model evaluation

-

Hands-on experience with large language models (LLMs), including prompt engineering, fine-tuning, and domain adaptation for business NLP and unstructured data tasks such as classification, entity extraction, summarisation, and embedding-based retrieval

-

Proficiency in Python and relevant ML frameworks (e.g., scikit-learn, PyTorch, TensorFlow, or equivalent), including experience with experiment tracking and model versioning tools

-

Experience with feature engineering, feature stores, or data preparation pipelines for model training and serving

-

Solid understanding of MLOps practices, including model deployment, monitoring, and lifecycle management in cloud environments (Microsoft Azure ML, AWS SageMaker, or equivalent)

-

Practical experience integrating machine learning outputs into agentic AI workflows, combining model reasoning with agent orchestration frameworks for automated or semi-automated decision-making

-

Familiarity with simulation and scenario-modelling techniques, enabling business teams to explore trade-offs and plan under uncertainty

-

Clear and confident communication of model behaviour, limitations, and outcomes to non-technical business stakeholders, fostering understanding and appropriate adoption of AI-generated insights

-

Awareness of AI security risks, including prompt injection, data leakage, and adversarial attacks, with experience applying mitigations in model or system design

-

Understanding of GDPR, the EU AI Act, and Responsible AI principles, with the ability to apply them to model selection, training data governance, and deployment decisions

-

A strong command of spoken and written English is required; knowledge of German is considered an advantage

**Valuable Experience**

-

Experience in FMCG, manufacturing, supply chain, or procurement analytics, with familiarity with the data patterns and modelling challenges common in these domains

-

Exposure to agentic AI frameworks and integration of ML model outputs into multi-agent orchestration systems

-

Experience with optimisation techniques (e.g., linear programming, constraint optimisation, simulation) applicable to supply chain or operational planning

-

Familiarity with Microsoft Azure ML, Azure AI Foundry, or AWS SageMaker for end-to-end model development and deployment

**Important: **Please note that a valid work and residence permit is required for non-EU applicants for this position.

**About Intersnack IT**
Intersnack IT KG is a member of the Pfeifer & Langen Industrie- und Handels-KG’s group of companies and a sister company to Intersnack Group. Established from the international harmonization and centralization of Intersnack Group’s IT estate, we are responsible for all group-wide IT services for and within Intersnack Group. It’s our target to provide the common IT infrastructure, aligned IT services and business solutions according to Intersnack’s requirements. Based on a solid digital foundation, Intersnack IT KG acts as a partner to all Intersnack functions, actively contributing to Intersnack’s business strategy. Explore exciting career opportunities and learn more by visiting our website at **[Intersnack IT KG](http://intersnack-it.com/)**[
](http://intersnack-it.com/)**
About Intersnack Group**
Intersnack has become one of Europe’s leading savory snacks producers by ‘creating happy snacking moments’ in people’s lives. Being privately owned, we operate with a long-term view and commit ourselves to a more sustainable world. Successfully and sustainably growing, our turnover in 2024 was more than €4.5 bn. We are now present in more than 30 countries across Europe and beyond. We have 12 regional Management Units, 45 production sites, and a total workforce of approximately 15,000 people worldwide. For further company insights, please visit the following link: **[Intersnack Group Overview](https://www.intersnackgroup.com/about-us/overview)**

*If you want to become part of our dynamic food industry success story, you’ll find all sorts of opportunities at Intersnack.*
***Join our team and help us to grow and celebrate our successes together!***

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
