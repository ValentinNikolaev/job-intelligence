# Manager Compensation & Benefits (m/w/d)

Posted: 2026-08-27T06:30:56Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Unser Mandant ist ein international erfolgreiches Services-Unternehmen (B2B) mit Hauptsitz in Frankfurt/Main. Das stetige Wachstum erfordert auch die stetige Weiterentwicklung der Strukturen im Bereich Total Reward. Wir suchen Persönlichkeiten, die mit Herz und Hand die Dinge konzipieren und dann auch umsetzen!

## Aufgaben

- Entwicklung, Pflege und Implementation von Vergütungsstrategien und -Richtlinien (inkl. fixer und variabler Vergütung)

- Führung und Weiterentwicklung des Teams

- Aufbau und Weiterentwicklung eines Job-Grading / Stellenbewertungssystems

- Sicherstellung der Einhaltung von nationalen gesetzlichen Vorgaben, Tarifverträgen, Betriebsvereinbarungen

- Laufende Marktstudien / Benchmarking sowie Analyse interner Daten, Gap-Analysen, Trends identifizieren

- Initiieren und leiten von Projekten, z. B. Vereinheitlichung , Einführung oder Optimierung von C&B Systemen

## Qualifikation

- Sie bringen eine mehrjährige Berufs- und gerne einige Führungserfahrung mit

- Sie haben Erfahrung mit Job-Grading / Stellenbewertungssystemen

- Sie greifen auf Erfahrung mit Tarifverträgen, Betriebsvereinbarungen, Vergütungs- und Bonusmodellen zurück

- Sie haben Erfahrung mit HR-Systemen / Tools: z. B. SAP HCM, SuccessFactors, Excel/Power BI usw.

- Sie agieren mit der Fähigkeit, Stakeholder zu integrieren und zu überzeugen

- Sehr gute Deutsch- und Englischkenntnisse in Wort und Schrift lassen Sie überzeugend auftreten

## Benefits

- Sie erhalten ein Fixum, einen Bonus und weitere interessante Benefits (u.a. Mobilität)

- Sie freuen sich auf Entwicklung & Perspektiven: Flache Hierarchie, internationaler Kontext, langfristige Führungschancen, Teamausbau, Duz-Kultur

- Sie bekommen Zusatzleistungen: Risikoabsicherung, JobRad, Gastro-Benefits, Mitarbeiterrabatte u.v.m.

- Sie arbeiten in Flexibilität & geeigneter Infrastruktur: Gleitzeit, Homeoffice, sehr gute Verkehrsanbindung, Parkplätze

- Sie gestalten die Arbeitskultur & das Wachstum: Vielfalt, Eigenverantwortung & Innovation in einem dynamischen Umfeld

Wir benötigen kein Anschreiben und melden uns zeitnah bei Ihnen zurück.

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
