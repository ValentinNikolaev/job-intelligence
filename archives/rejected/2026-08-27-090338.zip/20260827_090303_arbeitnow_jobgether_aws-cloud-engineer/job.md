# AWS Cloud Engineer

Posted: 2026-08-27T02:24:27Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**This position is listed on behalf of a partner company, who manages all applications and next steps. Our partner is looking for an AWS Cloud Engineer based in Germany.**

This is a mid-level cloud engineering role focused on designing, deploying, and optimizing AWS environments for diverse client needs.
You’ll work across a variety of cloud engagements, adapting solutions to different business requirements and technical challenges.
The role combines hands-on infrastructure engineering with client advisory responsibilities, giving you the opportunity to influence cloud architecture and implementation.
You’ll leverage infrastructure-as-code, CI/CD, containerization, and automation to build reliable and scalable cloud environments.
You’ll also identify infrastructure issues, improve performance and costs, and apply strong security practices throughout project delivery.
The environment is dynamic and technology-focused, with opportunities to work across modern AWS services and evolving cloud technologies.
This role is well suited to an engineer who enjoys solving complex infrastructure problems and delivering practical cloud solutions for clients.

**Accountabilities**

- Deploy, configure, and maintain modular cloud-based systems and infrastructure within AWS environments.

- Advise clients on the design, architecture, and implementation of modern AWS cloud technologies aligned with their business requirements.

- Analyze, troubleshoot, and resolve infrastructure and application deployment challenges across cloud environments.

- Automate infrastructure provisioning and configuration using Infrastructure-as-Code and configuration management practices.

- Implement and maintain CI/CD processes using tools such as GitLab, CircleCI, and GitHub Actions.

- Configure Kubernetes clusters and support application deployments within containerized environments.

- Design and maintain secure AWS networking environments, including VPC configurations and related security controls.

- Optimize cloud operations by identifying opportunities to improve system performance, scalability, reliability, and cost efficiency.

- Ensure data storage and processing solutions meet client requirements, policies, and operational standards.

- Apply AWS security best practices throughout architecture, deployment, configuration, and ongoing operations.

- Stay current with emerging AWS services, cloud engineering practices, automation technologies, and industry standards.

- Collaborate with engineering teams and clients to deliver effective solutions and adapt quickly to changing project requirements.

## Requirements

- Demonstrated experience working as a Cloud Engineer, AWS Engineer, DevOps Engineer, or in a closely related infrastructure role.

- Hands-on experience deploying and configuring AWS cloud resources in production or client environments.

- Strong Infrastructure-as-Code experience with **Terraform and/or CloudFormation**.

- Practical experience building or supporting CI/CD pipelines using **GitLab, CircleCI, GitHub Actions**, or comparable platforms.

- Experience configuring Kubernetes clusters and deploying applications in containerized environments.

- Solid understanding of AWS networking, VPC architecture, and cloud security principles.

- Ability to troubleshoot infrastructure and application deployment issues using structured analytical and problem-solving approaches.

- Experience identifying opportunities for AWS performance, scalability, reliability, and cost optimization.

- Strong understanding of cloud infrastructure automation and configuration management practices.

- Ability to communicate technical concepts clearly and provide practical recommendations to clients and internal stakeholders.

- Strong adaptability and willingness to work across varied client environments and business requirements.

- An **AWS Associate- or Professional-level certification** is preferred.

- Strong commitment to cloud security, industry standards, and infrastructure best practices.

## Benefits

- Expected base salary of **$105,000–$120,000 USD annually**, depending on experience, skills, and location.

- Eligibility for an **annual performance bonus**.

- Comprehensive **medical, dental, and vision coverage**.

- **Paid time off**.

- Opportunity to work on varied AWS cloud engagements and solve diverse technical challenges.

- Exposure to modern cloud technologies, Infrastructure-as-Code, CI/CD, Kubernetes, and automation.

- Client-facing opportunities that allow you to contribute to cloud architecture and technology decisions.

- A dynamic engineering environment with opportunities to develop your cloud expertise and certifications.

**How Jobgether works:**

We use an **AI-powered matching process** to ensure your application is reviewed quickly, objectively, and fairly against the role's core requirements. Our system identifies the top-fitting candidates, and this shortlist is then shared directly with the hiring company. The final decision and next steps (interviews, assessments) are managed by their internal team.

We appreciate your interest and wish you the best!

[ Why Apply Through Jobgether?](https://jobgether.com/how-jobgether-works)

**Data Privacy Notice:** By submitting your application, you acknowledge that Jobgether will process your personal data to evaluate your candidacy and share relevant information with the hiring employer. This processing is based on legitimate interest and pre-contractual measures under applicable data protection laws (including GDPR). You may exercise your rights (access, rectification, erasure, objection) at any time.

#LI-CL1

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
