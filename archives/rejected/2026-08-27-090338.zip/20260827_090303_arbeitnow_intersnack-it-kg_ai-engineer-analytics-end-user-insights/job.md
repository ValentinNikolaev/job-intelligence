# AI Engineer - Analytics & End-User Insights

Posted: 2026-08-27T02:30:21Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

#### **We Want You to Grow With Us**

Intersnack is building a next-generation AI and data foundation and this role is at the heart of making that foundation meaningful for the people who rely on it every day. As our AI Engineer for Analytics & End-User Insights, you will bridge the gap between enterprise data architecture and the business users who depend on trustworthy, actionable intelligence to make decisions. You will report into the AI Programme and collaborate across procurement, manufacturing, and sales to deliver AI-powered reporting that business teams can understand, trust, and act on.

#### **What We Can Offer**

You will join a collaborative, internationally minded team building something genuinely new: a modern, AI-grounded analytics capability that complements existing reporting and serves real business decisions. This role offers significant autonomy to shape how AI is introduced into the daily workflows of colleagues across multiple functions and countries. The impact of your work will be visible and measurable, from the moment a business user receives an AI-generated insight they trust, to the gradual reduction of manual reporting steps that once dominated their week. Dusseldorf serves as your home base, with flexibility for remote working, and the broader Intersnack network gives you exposure to a truly international operating environment.

#### **How You Will Spend Your Time as Our Next AI Engineer - Analytics & End-User Insights**

You will operate at the intersection of data engineering, AI, and business enablement: designing the data supply chain and semantic infrastructure that makes AI-driven analytics possible, while ensuring that the people who consume those analytics are equipped to use them with confidence. Your focus spans architecture and adoption in equal measure, working closely with business stakeholders to define what good looks like and then building the pipelines and models to get there.

**What You Will Do**

-

Design and implement decoupled data supply chains, spanning landing zones, quality and transformation layers, and consumption layers, to ensure consistently high-quality data reaches analytics and AI systems

-

Implement and document business KPIs as defined by business stakeholders, ensuring full metric traceability; define, implement, and document technical KPIs for AI application performance in collaboration with the data architect, ensuring explainability and observability across all AI-driven outputs

-

Build and maintain a semantic layer that enables AI-based insight generation, bridging structured data assets with natural-language querying and large language model (LLM) integration

-

Lead the expansion of existing BI reporting with AI-supported, RAG-driven analytics, progressively complementing manual report runs with dynamic, contextual insight delivery

-

Develop and maintain data models, transformations, and pipelines using industry-standard tooling, complementing existing data infrastructure and ensuring data quality, lineage, and observability throughout

-

Expose data assets and AI services via well-designed APIs, supporting consumption by both technical and non-technical consumers

-

Act as a frontline coach and enabler for business users and citizen analysts, building AI and data literacy across the organisation and supporting adoption of AI-assisted workflows

-

Embed security-by-design principles into all analytics and AI assets, including protections against prompt injection, data leakage, and model misuse

-

Collaborate across IT, data, security, and business functions to ensure analytics outputs are governed, compliant with EU AI Act and GDPR requirements, and aligned to Intersnack's data sovereignty standards

#### **Essential Skills & Experience**

-

Proven experience designing and implementing multi-layer data architectures, including landing zones, transformation layers, and consumption layers

-

Strong proficiency in SQL and at least one scripting or transformation language (e.g., Python, dbt) for data modelling and pipeline development

-

Hands-on experience with prompt engineering, vector stores, and RAG patterns, including the ability to build semantic layers and design LLM-integrated workflows using frameworks such as LangChain or LangGraph

-

Experience with BI and analytics platforms (e.g., Qlik, Power BI, or equivalent) and a clear understanding of how to complement existing reporting with AI-assisted delivery

-

Working knowledge of Microsoft Azure and/or AWS data and AI services (e.g., Azure Data Factory, Azure ML, AWS Glue, SageMaker, or equivalent)

-

Demonstrated ability to engage with and understand non-technical business users, translating AI and data concepts into business language with clarity and confidence

-

Solid understanding of AI security fundamentals, including risks such as prompt injection, data leakage, and chain-reaction errors in AI pipelines

-

Awareness of relevant regulatory frameworks, including GDPR, the EU AI Act, and data sovereignty principles applicable in the EU context

-

A strong command of spoken and written English is required; knowledge of German is considered an advantage

**Valuable Experience**

-

Familiarity with Microsoft Fabric, Azure Purview, or OneLake for unified data governance and discovery, and with Microsoft Foundry for building and deploying LLM-integrated workflows and AI applications

-

Experience in FMCG, manufacturing, or procurement environments, with an understanding of the data and reporting challenges specific to these domains

-

Knowledge of Responsible AI principles and practical application of AI ethics frameworks

**Important: **Please note that a valid work and residence permit is required for non-EU applicants for this position.

**About Intersnack IT**
Intersnack IT KG is a member of the Pfeifer & Langen Industrie- und Handels-KG’s group of companies and a sister company to Intersnack Group. Established from the international harmonization and centralization of Intersnack Group’s IT estate, we are responsible for all group-wide IT services for and within Intersnack Group. It’s our target to provide the common IT infrastructure, aligned IT services and business solutions according to Intersnack’s requirements. Based on a solid digital foundation, Intersnack IT KG acts as a partner to all Intersnack functions, actively contributing to Intersnack’s business strategy. Explore exciting career opportunities and learn more by visiting our website at **[Intersnack IT KG](http://intersnack-it.com/)**[
](http://intersnack-it.com/)**
About Intersnack Group**
Intersnack has become one of Europe’s leading savory snacks producers by ‘creating happy snacking moments’ in people’s lives. Being privately owned, we operate with a long-term view and commit ourselves to a more sustainable world. Successfully and sustainably growing, our turnover in 2024 was more than €4.5 bn. We are now present in more than 30 countries across Europe and beyond. We have 12 regional Management Units, 45 production sites, and a total workforce of approximately 15,000 people worldwide. For further company insights, please visit the following link: **[Intersnack Group Overview](https://www.intersnackgroup.com/about-us/overview)**

*If you want to become part of our dynamic food industry success story, you’ll find all sorts of opportunities at Intersnack.*
***Join our team and help us to grow and celebrate our successes together!***

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
