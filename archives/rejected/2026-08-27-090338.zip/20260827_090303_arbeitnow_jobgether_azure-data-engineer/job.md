# Azure Data Engineer

Posted: 2026-08-27T02:24:27Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**This position is listed on behalf of a partner company, who manages all applications and next steps. Our partner is looking for an Azure Data Engineer based in Germany.**

This role offers the opportunity to strengthen cybersecurity operations by engineering reliable, scalable security data pipelines across cloud and on-premises environments.
You will work with high volumes of security telemetry and help ensure critical data is available for threat detection, incident response, compliance, and cyber risk visibility.
The position combines hands-on data engineering with cybersecurity, cloud technologies, automation, and data quality management.
You’ll collaborate with application, infrastructure, security, governance, and vendor teams to onboard and optimize diverse data sources.
The role is well suited to an engineer who enjoys troubleshooting complex ingestion challenges and improving system reliability and efficiency.
You’ll operate in a highly regulated financial services environment where data integrity, security, and operational excellence are essential.
This is an opportunity to make a direct impact on the organization’s ability to detect, investigate, and respond to cyber threats.

**Accountabilities:**

- Design, build, and maintain scalable security data ingestion pipelines for SIEM and cloud data platforms, including Azure Data Explorer and Log Analytics.

- Parse, normalize, transform, enrich, and validate structured and unstructured security telemetry using regex, JSON parsing, schema mapping, and other data-processing techniques.

- Partner with application owners, infrastructure and cloud teams, vendors, security stakeholders, and other internal groups to onboard new log sources and validate end-to-end data flows.

- Ensure the integrity, completeness, timeliness, and quality of security telemetry used for monitoring, detection, incident response, reporting, and risk management.

- Align security data with established schemas, naming conventions, governance standards, and organizational requirements to support downstream analytics and automation.

- Troubleshoot ingestion, parsing, transformation, schema, and data-quality issues across diverse platforms and environments.

- Maintain clear documentation covering log onboarding procedures, source requirements, data mappings, pipeline configurations, and operational support processes.

- Collaborate with detection engineering and security operations teams to ensure telemetry supports investigation, threat detection, response, and cyber risk use cases.

- Conduct telemetry gap analyses, identify missing or incomplete data sources, and recommend priorities for improving security coverage.

- Support logging practices that meet regulatory, audit, compliance, retention, and data-integrity requirements.

- Improve ingestion frameworks, automation, and onboarding processes to increase scalability, repeatability, reliability, and cost efficiency.

- Support infrastructure-as-code, scripting, and automation initiatives that streamline deployment and ongoing pipeline maintenance.

- Monitor pipeline performance and work with stakeholders to optimize ingestion reliability, throughput, and operational costs.

- Stay current with emerging cybersecurity telemetry formats, logging standards, data engineering practices, and cloud security data-platform capabilities.

## Requirements:

- 3+ years of relevant experience in cybersecurity, data engineering, log management, security operations, or a related technology discipline.

- Hands-on experience onboarding, managing, and validating log sources within SIEM, cloud data platforms, or security analytics environments.

- Strong understanding of data parsing, normalization, transformation, and validation, including experience with regex, JSON, XML, CSV, and both structured and unstructured data.

- Familiarity with security telemetry from network, endpoint, identity, application, cloud, and infrastructure environments.

- Experience working with cloud platforms and associated logging, monitoring, and analytics services, particularly within the Azure ecosystem.

- Strong troubleshooting and analytical skills, with the ability to diagnose pipeline, ingestion, schema, and data-quality problems.

- Understanding of compliance and regulatory requirements related to logging, retention, auditability, and data integrity.

- Experience with scripting or automation technologies such as Python, PowerShell, or similar tools is preferred.

- Familiarity with query languages used to validate, investigate, and analyze ingested security data.

- Ability to coordinate complex onboarding initiatives across internal teams, vendors, and multiple stakeholders.

- Strong organizational skills and the ability to balance operational support, project delivery, and continuous improvement.

- Exceptional attention to detail and a strong sense of ownership for data quality and technical outcomes.

- Broader cybersecurity experience in areas such as threat detection, incident response, vulnerability management, or cloud security is an advantage.

- Strong communication, collaboration, judgment, and accountability, with the ability to work effectively within global teams.

## Benefits:

- Remote work opportunity from anywhere.

- Opportunity to work on cybersecurity data engineering within a highly regulated financial services environment.

- Exposure to large-scale security telemetry, SIEM platforms, Azure data services, cloud environments, and security operations.

- Hands-on opportunities to develop scalable pipelines, automation, infrastructure-as-code, and data-quality solutions.

- Cross-functional collaboration with cybersecurity, cloud, infrastructure, application, governance, and vendor teams.

- Opportunity to contribute directly to threat detection, incident response, compliance, and cyber risk visibility.

- Professional growth through exposure to evolving cloud security, telemetry, and data engineering technologies.

- A collaborative global working environment with opportunities to solve complex technical challenges.

**How Jobgether works:**

We use an **AI-powered matching process** to ensure your application is reviewed quickly, objectively, and fairly against the role's core requirements. Our system identifies the top-fitting candidates, and this shortlist is then shared directly with the hiring company. The final decision and next steps (interviews, assessments) are managed by their internal team.

We appreciate your interest and wish you the best!

[ Why Apply Through Jobgether?](https://jobgether.com/how-jobgether-works)

**Data Privacy Notice:** By submitting your application, you acknowledge that Jobgether will process your personal data to evaluate your candidacy and share relevant information with the hiring employer. This processing is based on legitimate interest and pre-contractual measures under applicable data protection laws (including GDPR). You may exercise your rights (access, rectification, erasure, objection) at any time.

#LI-CL1

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
