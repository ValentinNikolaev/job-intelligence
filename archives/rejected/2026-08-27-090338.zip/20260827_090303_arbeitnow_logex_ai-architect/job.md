# AI Architect

Posted: 2026-08-27T05:30:14Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**Our mission**

At LOGEX, we help healthcare providers improve outcomes by transforming complex data into actionable insights. Our datasets span financial, operational and clinical domains across Europe and AI is becoming central to how we unlock value from this data.

We are building our AI capability in a deliberate, controlled way, aligned with the expectations of a regulated healthcare environment. As AI Architect, you will play a key role in shaping this journey.

**This role shapes LOGEX’s AI journey — and makes sure AI capabilities are delivered into our products, with the teams, not just designed.**

**The role**

As AI Architect, you define how AI is applied across LOGEX — from architecture and standards to real-world implementation. You ensure AI is not just designed, but **successfully delivered into products and workflows**.

This is a **hands-on architecture role** with a strong focus on execution. You will work closely with product, engineering, data and platform teams to bring AI capabilities into production and into the hands of customers.

**Your impact and responsibilities**

-

Shape LOGEX’s AI strategy, architecture and adoption roadmap

-

Define scalable AI patterns, standards and reference architectures

-

Ensure AI capabilities are embedded into products and actually shipped

-

Design AI solutions across retrieval, orchestration, model serving and evaluation

-

Establish AI governance, including monitoring, evaluation and human-in-the-loop

-

Define and implement MLOps / LLMOps practices for production reliability

-

Select tools, frameworks and make pragmatic build-vs-buy decisions

-

Prototype solutions to accelerate decision-making and de-risk delivery

-

Ensure AI solutions meet security, privacy and compliance standards (e.g. GDPR)

-

Identify and prioritise high-impact use cases across products and operations

-

Act as a senior AI voice towards leadership and engineering

**Your profile**

-

Strong experience in AI/ML engineering or AI architecture, including production deployments

-

Hands-on expertise with applied AI and modern LLM approaches (RAG, evaluation, orchestration)

-

Experience with MLOps / LLMOps, model serving and lifecycle management

-

Solid programming skills (e.g. Python) and strong data/software engineering fundamentals

-

Experience defining platforms, standards or architectures used by multiple teams

-

Understanding of AI governance, responsible AI and compliance requirements

-

Experience in regulated industries (e.g. healthcare, finance) is a plus

-

Strong communication skills and ability to bridge technical and business stakeholders

**Why LOGEX?**

-

25 vacation days (based on full-time employment) to recharge, with the option to purchase additional days

-

An informal working environment with motivated colleagues

-

The possibility to work in a hybrid setup

-

A laptop and everything you need to set up a comfortable and ergonomic home office

-

Personal and professional development opportunities through our LOGEX Academy

-

Access to our mental health partner, OpenUp

-

Regular after-work drinks and many more social events

**Contact us!**

You can apply via the button below and upload your CV. For more information, or in case you have any
questions, you can contact Wesley Schreuder at wesley.schreuder@

Our company is dedicated to building a workplace that promotes equity, diversity, and inclusion, and we believe that a diverse workforce is essential to our success. As we strive to create a workplace where everyone feels valued and respected, regardless of their race, gender, sexual orientation, age, religion, or any other characteristic, we encourage everyone to apply.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
