# Ausbildung zum*r Fachinformatiker*in Anwendungsentwicklung in der Spieleentwicklung 2027

Posted: 2026-08-27T02:04:54Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Programmieren ist Deine Leidenschaft, die Du zu Deinem Beruf machen möchtest? Du willst hautnah bei der Spieleentwicklung dabei sein? Lerne bei uns verschiedene Programmiersprachen, Tools und Teams in einem spannenden und abwechslungsreichen Umfeld kennen und verbessere stetig Deine Fähigkeiten. Im Rahmen der Ausbildung erlernst Du das Handwerkszeug für Deine professionelle Zukunft im Bereich **Software Development**. Du wirst während der Ausbildung in verschiedenen Entwicklungsteams arbeiten und dabei aktuelle Technologien und agile Arbeitsweisen erlernen und das Spielerlebnis von Millionen von Spielenden positiv beeinflussen.

Unsere Ausbildung findet in **Hamburg **statt. Profitiere von unserer starken Career Starter Gemeinschaft und dem direkten Austausch mit deinen Mentor*innen vor Ort in unserem Büro in Hamburg-Hammerbrook. Gleichzeitig kannst du dich über die Vorteile des hybriden Arbeitens freuen.

Haben wir Dein Interesse geweckt? Bewirb Dich jetzt für den Ausbildungsbeginn im **August 2027**. Wir bieten Dir aktive Unterstützung durch ein engagiertes Team sowie modernste Arbeitsbedingungen in einem von Deutschlands erfolgreichsten Entwickler und Publisher von Online Games.

**Dein Skillset**

- **Klasse Leistung.** Du wirst Dein Abitur oder Deine Fachhochschulreife mit guten Noten absolvieren.

- **Programmieren.** Du bringst Vorkenntnisse in einer objektorientierten Skript- oder Programmiersprache mit (z.B. Java, C# oder PHP).

- **Spaß.** Du hast Spaß an der Mathematik und den Naturwissenschaften.

- **Erste Praxis.** Idealerweise hast Du bereits in einem kleineren Software-Projekt gemeinsam mit anderen gearbeitet.

- **Zukunftsgestalter*in.** Du siehst in der Künstlichen Intelligenz die Chance, die Zukunft unserer Spiele mitzugestalten und freust dich, Deine Begeisterung und ersten KI-Erfahrungen in realen Projekten anzuwenden.

- **Eigenverantwortung. **Du arbeitest gerne eigenverantwortlich und zeigst hohe Leistungsbereitschaft, Teamfähigkeit und Flexibilität.

- **Deutschkenntnisse. **Für eine erfolgreiche Teilnahme an unserem Ausbildungsprogramm verfügst Du mindestens über ein B2-Niveau in Deutsch, da der Berufsschulunterricht ausschließlich in deutscher Sprache stattfindet.

- **Unsere Unternehmenssprache ist Englisch.** Du freust Dich darauf im Betrieb Deine sehr guten Englischkenntnisse täglich in Wort und Schrift anzuwenden.

- **Gaming. **Idealerweise hast Du eine Affinität für (Online) Games.

**Deine Power-Ups**

- **Ein Team von Spezialist*innen.** Werde Teil eines großartigen, internationalen Teams von Spezialist*innen und arbeite und lerne bei einem der führenden Spieleentwickler und Publisher in Deutschland.

- **Optimales Lernumfeld.** Wir bieten dir ein äußerst interessantes technisches Umfeld und modernste Arbeitsbedingungen.

- **Überdurchschnittliche Vergütung. **Finanzielle Unabhängigkeit ermöglichen wir Dir mit unserer überdurchschnittlichen Ausbildungsvergütung: [1.270](http://1.270) EUR brutto im 1. Lehrjahr, [1.500](http://1.500) EUR brutto im 2. Lehrjahr, [1.715](http://1.715) EUR brutto im 3. Lehrjahr.

- **Weiterentwicklung. **Wir fördern Deine fachliche aber auch persönliche Weiterentwicklung mit einer optimalen Betreuung durch eine Ansprechperson aus der Fachabteilung sowie aus der Personalabteilung.

- **Kostenübernahme.** Wir unterstützen Dich bei der Aus- und Weiterbildung, auch über die normalen Ausbildungsinhalte hinaus, wir übernehmen die Kosten für Deine Fach- und Schulbücher und beteiligen uns an Deinem DeutschlandTicket.

- **Herausragende Ausstattung.** Du arbeitest mit einem MacBook Pro in herausragender Ausstattung und wir stellen Dir zusätzlich ein Smartphone oder Tablet Deiner Wahl zur Verfügung.

- **Agiles Arbeiten. **Dich erwarten flexible Arbeitszeiten sowie agile, cross-funktionale Teams mit kurzen Entscheidungswegen.

- **Teamwork **ist uns wichtig: Wir legen viel Wert auf ein Arbeitsklima, in dem Kommunikation und Interkulturalität großgeschrieben werden; wir feiern unsere Erfolge in wöchentlichen Afterworks sowie regelmäßigen Team- und Unternehmensevents wie die [InnoConf](https://youtu.be/UpcpmS41jbU?si=7ssAlPojio3-jBbJ).

- **Modernes und gemütliches Büro.** Wir bieten Dir diverse Möglichkeiten Arbeit und Wohlbefinden miteinander zu vereinbaren: frisches Obst und kostenlose Getränke, hauseigenes Fitnessstudio, Gaming-Bereich, Dachterrasse mit BBQ, Relaxing-Rooms und vieles mehr.

InnoGames ist einer der führenden deutschen Entwickler und Publisher von Mobile- und Browsergames und ein zertifizierter Great Place to Work®. Das Unternehmen mit Sitz in Hamburg wurde 2007 gegründet und gehört heute zur Modern Times Group (MTG). Zusammen mit ca. 350 Mitarbeitern aus 40 Nationen entwickeln die Unternehmensgründer einzigartige Games, die Millionen von Spielern auf der ganzen Welt jahrelangen Spaß bieten. Bekannt ist InnoGames vor allem für Forge of Empires, Elvenar und Die Stämme, aber das Unternehmen vergrößert sein mittlerweile 10 Spiele umfassendes Portfolio kontinuierlich über Plattformen und Genres hinweg. Die letzten Neuzugänge waren Heroes of History, ein neuartiger Mix aus City Builder und Hero Collection RPG und Cozy Coast, ein Strandabenteuer zum Wohlfühlen mit ausgefeiltem Merge-2-Gameplay und einer packenden Story.

Du bist bereit Deine Reise mit InnoGames zu beginnen und Teil unseres Teams zu werden? Dann freuen wir uns auf Deine Bewerbung inkl. Anschreiben, Lebenslauf, Zeugnissen und deine Codebeispielen ausschließlich als Onlinebewerbung über [innogames.com/career](http://innogames.com/career). Deine Ansprechpartnerin ist **Saara Harris**.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
