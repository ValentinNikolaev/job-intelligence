# Werkstudent Business Development (m/w/d)

Posted: 2026-08-27T05:30:15Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Die Mission von Nomios ist es, eine „sichere und vernetzte Zukunft” zu schaffen – mit einem konsequenten Fokus auf erstklassige Cybersicherheitsdienstleistungen. Unternehmen weltweit vertrauen uns, wenn es um die Absicherung ihrer digitalen Infrastruktur geht.

Nomios Germany befindet sich in einer entscheidenden Wachstumsphase.
In diesem Zuge suchen wir **mehrere Werkstudenten (m/w/d)** für den **Bereich Sales/Business Development.**

**Du willst nicht nur zuschauen, sondern echten Impact haben?**
Dann bist Du hier richtig! Als Werkstudent (m/w/d) im Sales/Business Development bist Du ganz vorne dabei: Du sprichst mit potenziellen Kunden, öffnest Türen und legst den Grundstein für unseren Vertriebserfolg.

Kaltakquise ist für Dich kein notwendiges Übel, sondern eine Challenge, an der Du wachsen willst.

**Deine Rolle bei uns**

-

Du identifizierst spannende Zielunternehmen und die richtigen Ansprechpartner

-

Du gehst aktiv in die Ansprache: Calls, E-Mails, LinkedIn – Du findest Wege durchzukommen

-

Du weckst Interesse und vereinbarst Termine für unser Sales-Team

-

Du testest neue Ansätze, formulierst Messages und optimierst unsere Outreach-Strategie

-

Du hältst deine Aktivitäten sauber im CRM fest und behältst den Überblick

**Das erwartet Dich:**

-

Steile Lernkurve im Vertrieb – hands-on, kein Theorie-Blabla

-

Direkter Einfluss auf unseren Wachstumserfolg

-

Viel Eigenverantwortung und Raum, Dinge auszuprobieren

-

Arbeiten vor Ort im Team, ein Tag pro Woche remote möglich

-

Ein Team, das Dich fordert, fördert und ehrlich Feedback gibt

-

Laufendes Studium – Fachrichtung ist zweitrangig

-

Lust auf Vertrieb, Kommunikation und Performance

-

Du bist hartnäckig, lässt Dich von einem „Nein“ nicht stoppen und bleibst dran

-

Du kannst klar und überzeugend kommunizieren (Deutsch fließend, Englisch ein Plus)

-

Du arbeitest eigenständig und willst Ergebnisse sehen

Wenn Du Vertrieb wirklich lernen willst, gibt es keinen besseren Einstieg als Kaltakquise. Hier entwickelst Du Skills, die Dich in jeder Business-Rolle nach vorne bringen: Kommunikation, Resilienz und Abschlussstärke.

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
