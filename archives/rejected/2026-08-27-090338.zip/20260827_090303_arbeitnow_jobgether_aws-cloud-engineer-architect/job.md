# AWS Cloud Engineer/Architect

Posted: 2026-08-27T02:24:27Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**This position is listed on behalf of a partner company, who manages all applications and next steps. Our partner is looking for an AWS Cloud Engineer/Architect based in Germany.**

This is an opportunity to design and deliver modern cloud solutions that solve complex business challenges for organizations across Europe.
You’ll work across AWS architecture, cloud-native development, infrastructure automation, migrations, and modernization initiatives.
The role combines hands-on engineering with architectural thinking, giving you the opportunity to influence both technology decisions and client outcomes.
You’ll collaborate closely with engineers, technical teams, and customers to simplify complexity and deliver scalable, secure, and effective solutions.
Your work will span infrastructure as code, CI/CD, observability, application performance, security, and cloud cost optimization.
You’ll also have the opportunity to mentor teams and share practical expertise around AWS architecture and DevOps best practices.
With a fully remote setup and a strong culture of collaboration and continuous learning, this role offers meaningful technical ownership and flexibility.

**Accountabilities:**

- Design and architect scalable, secure, highly available cloud solutions on AWS using cloud-native architecture and DevOps best practices.

- Build and implement cloud infrastructure and applications that address complex customer requirements and deliver measurable business value.

- Develop infrastructure as code using tools such as Terraform, CloudFormation, or AWS CDK to enable consistent, repeatable deployments.

- Automate infrastructure and application deployment, configuration, and management through CI/CD pipelines using GitHub Actions or comparable technologies.

- Collaborate with internal engineering teams and customers to understand business objectives, progressively deliver solutions, reduce unnecessary complexity, and demonstrate the impact of technology decisions.

- Develop and implement effective monitoring, logging, alerting, and operational strategies using AWS CloudWatch or third-party observability platforms.

- Optimize cloud applications and infrastructure for performance, scalability, security, reliability, and cost efficiency.

- Evaluate and integrate third-party cloud tools and services where they can improve automation, security, performance, or operational efficiency.

- Work with development and operations teams to establish effective cloud deployment and operational practices.

- Provide technical guidance and mentorship on AWS architecture patterns, DevOps methodologies, cloud-native development, and operational best practices.

- Translate complex technical concepts into clear, accessible recommendations for both technical and non-technical stakeholders.

- Make informed architectural trade-offs by balancing business objectives, technical requirements, scalability, performance, security, complexity, and cost.

## Requirements:

- 2+ years of professional experience building and/or architecting distributed applications and solutions on AWS.

- Strong software development skills with experience building or supporting cloud-based applications.

- Solid understanding of AWS cloud architecture and hands-on experience with services such as ECS, Lambda, EC2, API Gateway, IAM, and S3.

- Practical experience with infrastructure as code and automation tools such as Terraform, CloudFormation, or AWS CDK.

- Experience designing and managing CI/CD pipelines using GitHub Actions or comparable tools.

- Familiarity with monitoring, logging, and observability platforms such as AWS CloudWatch, Datadog, Prometheus, Grafana, or the ELK Stack.

- Demonstrated ability to design solutions that balance technical and business requirements with performance, scalability, security, reliability, and cost considerations.

- Strong understanding of cloud-native and DevOps principles, including automation, continuous delivery, infrastructure management, and operational excellence.

- Ability to evaluate different technical approaches, understand their advantages and limitations, and make pragmatic architectural trade-offs.

- Strong communication and stakeholder-management skills, with the ability to listen carefully, understand business needs, and communicate solutions effectively.

- Ability to explain complex technology in clear, accessible language without relying unnecessarily on technical jargon.

- Comfortable working collaboratively with customers and multidisciplinary engineering teams.

- Passion for cloud technology, continuous learning, and solving complex problems in practical and effective ways.

- Experience mentoring engineers or guiding teams on cloud architecture and DevOps practices is a plus.

## Benefits:

- Fully remote position within Europe.

- Flexible working hours designed to support a healthy work-life balance.

- 25 days of annual leave in addition to public holidays.

- Company-provided MacBook.

- Co-working allowance to support flexible working environments.

- Regular team meetups, with opportunities to connect in person throughout the year.

- Opportunity to work on cutting-edge AWS cloud, serverless, migration, and modernization projects.

- Exposure to diverse customer challenges and the opportunity to deliver measurable business outcomes.

- Strong emphasis on continuous learning, knowledge sharing, and professional development.

- Collaborative culture that values respect, inclusion, open communication, and team performance.

- Opportunity to work alongside experienced cloud engineers and architects while taking meaningful technical ownership.

- Inclusive environment that welcomes people from diverse backgrounds and supports individual growth and career development.

- Fully remote, trust-based working culture with autonomy over how you organize your work.

**How Jobgether works:**

We use an **AI-powered matching process** to ensure your application is reviewed quickly, objectively, and fairly against the role's core requirements. Our system identifies the top-fitting candidates, and this shortlist is then shared directly with the hiring company. The final decision and next steps (interviews, assessments) are managed by their internal team.

We appreciate your interest and wish you the best!

[ Why Apply Through Jobgether?](https://jobgether.com/how-jobgether-works)

**Data Privacy Notice:** By submitting your application, you acknowledge that Jobgether will process your personal data to evaluate your candidacy and share relevant information with the hiring employer. This processing is based on legitimate interest and pre-contractual measures under applicable data protection laws (including GDPR). You may exercise your rights (access, rectification, erasure, objection) at any time.

#LI-CL1

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
