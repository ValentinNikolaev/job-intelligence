# Backend Engineer – API Integrationen, Connectoren, Worker/Jobs, Mailer Service, QA

Posted: 2026-08-27T02:24:27Z

## Rejection

- Category: role_mismatch
- Reason: title is an obvious mismatch for a backend profile

**This position is listed on behalf of a partner company, who manages all applications and next steps. Our partner is looking for a Backend Engineer – API Integrationen, Connectoren, Worker/Jobs, Mailer Service, QA based in Germany.**

This role is an opportunity to build robust backend systems and integrations that connect critical business platforms and services. You’ll work across APIs, connectors, background jobs, messaging, email delivery, persistence, and quality assurance. The position requires an engineering mindset focused on reliability, traceability, and handling real-world failure scenarios rather than relying on happy-path implementations. You’ll design integrations that remain resilient through rate limits, webhooks, timeouts, retries, and other operational challenges. Working on a project basis, you’ll have significant ownership over technical deliverables and architecture decisions. This is a strong fit for a backend engineer who enjoys solving complex integration problems and building dependable production systems.

**Accountabilities**

- Build and maintain production-ready API integrations and connectors, prioritizing Box and HubSpot, followed by Microsoft Graph, Asana, and billing-related systems.

- Implement reliable authentication and integration patterns using OAuth, webhooks, pagination, rate limits, retries, and robust error handling.

- Design and develop queue-driven, stateful, and replayable workers and background jobs.

- Build and maintain a mailer service supporting PDF attachments, structured logging, retry mechanisms, delivery checks, and deduplication/idempotency.

- Design database schemas and implement clean, reliable migrations using PostgreSQL or comparable technologies.

- Implement audit events and persistent traceability mechanisms, including correlation IDs and observability across distributed processes.

- Develop comprehensive QA coverage, including contract tests, integration tests, and end-to-end regression testing for critical workflows such as document delivery and deadline-related processes.

- Use Docker, queue/eventing technologies, and observability practices to support reliable deployment and operation of backend services.

- Proactively identify failure modes and strengthen systems against timeouts, webhook failures, rate limiting, retries, duplicate events, and other production scenarios.

### **Requirements**

- Strong professional track record in backend engineering, with proficiency in Python, Node.js, Go, or a comparable backend technology.

- Proven experience building and maintaining production API integrations, including OAuth, webhooks, pagination, rate limits, authentication, and error handling.

- Solid understanding of relational databases, schema design, data persistence, and safe database migrations.

- Strong testing mindset with experience implementing contract, integration, unit, and/or end-to-end tests.

- Experience developing asynchronous, queue-based, or event-driven systems and background workers.

- Understanding of reliability engineering principles, including idempotency, retries, replayability, deduplication, observability, and failure-mode analysis.

- Experience working with Docker and modern backend development and deployment workflows.

- Familiarity with PostgreSQL, queue/eventing systems, and application monitoring or observability tools.

- Strong problem-solving skills and the ability to design systems that remain reliable outside of ideal or “happy path” scenarios.

- Ability to work independently, take ownership of technical deliverables, and communicate clearly in a remote project environment.

- Availability to work remotely, ideally aligned with Central European Time (CET) or European working hours.

- Freelance or project-based experience is suitable for this engagement.

### **Benefits**

- 100% remote working arrangement.

- Flexible project-based engagement with workload agreed upon according to availability and project needs.

- Full-time or part-time engagement options.

- Freelance contract structure.

- Opportunity to work on technically challenging API integrations, worker systems, messaging infrastructure, and QA automation.

- Significant ownership over backend architecture, implementation, reliability, and delivery.

- Opportunity to start as soon as possible.

- Collaboration within an international and digitally focused professional environment.

**How Jobgether works:**

We use an **AI-powered matching process** to ensure your application is reviewed quickly, objectively, and fairly against the role's core requirements. Our system identifies the top-fitting candidates, and this shortlist is then shared directly with the hiring company. The final decision and next steps (interviews, assessments) are managed by their internal team.

We appreciate your interest and wish you the best!

[ Why Apply Through Jobgether?](https://jobgether.com/how-jobgether-works)

**Data Privacy Notice:** By submitting your application, you acknowledge that Jobgether will process your personal data to evaluate your candidacy and share relevant information with the hiring employer. This processing is based on legitimate interest and pre-contractual measures under applicable data protection laws (including GDPR). You may exercise your rights (access, rectification, erasure, objection) at any time.

#LI-CL1

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
