# AI Data Architect - Knowledge & Governance

Posted: 2026-08-27T02:30:21Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

#### We Want You to Grow With Us

The intelligence of any AI system is only as good as the knowledge it is built upon, and this role is responsible for making that knowledge trustworthy, structured, and enduring. As our AI Data Architect for Knowledge & Governance, you will design and build the enterprise-grade knowledge backbone that powers Intersnack's AI programme: knowledge graphs, semantic models, vector spaces, and the RAG architectures that connect them to agentic workflows. You will report into the AI Programme and act as a key voice in shaping not just the technical architecture, but the governance and security frameworks that ensure AI is deployed safely, explainably, and in full compliance with applicable regulation. This is a role for someone who wants to build something that lasts: a change-resilient knowledge infrastructure that scales across procurement, manufacturing, sales, and beyond.

#### What We Can Offer

This role sits at the architectural heart of Intersnack's AI transformation, giving you the rare opportunity to define the knowledge foundation from the ground up rather than inherit a legacy system. You will have significant design authority, shaping ontologies, graph architectures, and governance frameworks that will influence how AI operates across a business present in more than 30 countries. Working alongside data engineers, AI engineers, and business stakeholders, you will contribute to a collaborative environment where architecture decisions have visible, measurable impact. Flexibility between Dusseldorf and remote working supports a working model that suits your needs, while the international scope of the programme ensures continuous exposure to complex, real-world challenges at scale.

#### How You Will Spend Your Time as Our Next AI Data Architect - Knowledge & Governance

You will spend your time designing the structural intelligence layer that makes enterprise AI possible: building knowledge graphs, semantic models, and vector spaces that ground AI outputs in trusted, governed organisational knowledge. Alongside the technical build, you will lead the governance and security-by-design practices that ensure every data asset, model, and AI use case meets Intersnack's standards for explainability, traceability, and regulatory compliance.

**What You Will Do**

-

Design and build AI-ready knowledge graphs, semantic models, and vector spaces that form the trusted knowledge backbone for analytics and agentic AI across the enterprise

-

Architect RAG (Retrieval-Augmented Generation) pipelines and agent grounding frameworks, defining the design vision for how agentic AI systems access and reason over organisational knowledge

-

Develop and maintain data governance frameworks, including access management policies, metadata generation, data classification standards, and ethical-by-design principles aligned to Intersnack's security and sovereignty requirements

-

Embed AI TRiSM (AI Trust, Risk, and Security Management) principles into architecture and governance design, ensuring explainability, auditability, and compliant AI usage across all use cases

-

Define and implement ontology models and entity-relationship structures that enable consistent, context-aware knowledge retrieval across structured and unstructured data sources

-

Ensure data lineage, observability, and traceability across the knowledge architecture, enabling stakeholders to trace AI-generated outputs back to their source data

-

Drive change resilience into the data architecture, designing systems that adapt to evolving business requirements, data sources, and AI model updates without structural rework

-

Collaborate with AI engineers, data engineers, and security teams to ensure knowledge infrastructure is secure by design, with protections against prompt injection, data leakage, and model exploitation

-

Coach and enable colleagues on data governance, knowledge architecture principles, and responsible AI usage, contributing to the broader AI literacy programme across Intersnack

#### **Essential Skills & Experience**

-

Proven track record in data architecture or knowledge engineering, with hands-on delivery of knowledge graphs, semantic models, or graph database solutions (e.g., Neo4j, Amazon Neptune, or equivalent), and the ability to translate dynamically shifting business requirements into future-proof architectural designs

-

Deep familiarity with enterprise data landscape patterns including Data Mesh, layered, and centralised architectures and warehousing paradigms such as DWH and Lakehouse, with the ability to select and justify the right approach for the context

-

Hands-on experience designing RAG architectures, vector databases, and embedding models, with the ability to build grounding frameworks for agentic AI systems

-

Experience designing and implementing data governance frameworks, covering metadata management, access control, data classification, and ethical-by-design principles in cloud environments

-

Practical knowledge of AI TRiSM (AI Trust, Risk, and Security Management) and its application to AI system design, including explainability, auditability, and compliant usage

-

Working knowledge of Microsoft Azure and/or AWS services relevant to data cataloguing, lineage, and knowledge management (e.g., Azure Purview, AWS Lake Formation, or equivalent)

-

Grounding in ontology modelling, entity resolution, and knowledge representation techniques applicable to enterprise data environments

-

Clear understanding of AI security risks, including prompt injection, data leakage, and chain-reaction errors, with the ability to design mitigations into architecture from the outset

-

Awareness of GDPR, the EU AI Act, and EU data sovereignty requirements, with the ability to apply these to architecture and governance decisions

-

A strong command of spoken and written English is required; knowledge of German is considered an advantage

**Valuable Experience**

-

Experience with Microsoft Fabric, Azure Purview, or OneLake in a data governance or knowledge management context

-

Background in FMCG, manufacturing, or supply chain environments, providing familiarity with the data complexity typical of these domains

-

Exposure to agentic AI frameworks and multi-agent orchestration patterns

-

Knowledge of Responsible AI principles and their practical application to model selection, deployment, and monitoring

**Important: **Please note that a valid work and residence permit is required for non-EU applicants for this position.

**About Intersnack IT**
Intersnack IT KG is a member of the Pfeifer & Langen Industrie- und Handels-KG’s group of companies and a sister company to Intersnack Group. Established from the international harmonization and centralization of Intersnack Group’s IT estate, we are responsible for all group-wide IT services for and within Intersnack Group. It’s our target to provide the common IT infrastructure, aligned IT services and business solutions according to Intersnack’s requirements. Based on a solid digital foundation, Intersnack IT KG acts as a partner to all Intersnack functions, actively contributing to Intersnack’s business strategy. Explore exciting career opportunities and learn more by visiting our website at **[Intersnack IT KG](http://intersnack-it.com/)**[
](http://intersnack-it.com/)**
About Intersnack Group**
Intersnack has become one of Europe’s leading savory snacks producers by ‘creating happy snacking moments’ in people’s lives. Being privately owned, we operate with a long-term view and commit ourselves to a more sustainable world. Successfully and sustainably growing, our turnover in 2024 was more than €4.5 bn. We are now present in more than 30 countries across Europe and beyond. We have 12 regional Management Units, 45 production sites, and a total workforce of approximately 15,000 people worldwide. For further company insights, please visit the following link: **[Intersnack Group Overview](https://www.intersnackgroup.com/about-us/overview)**

*If you want to become part of our dynamic food industry success story, you’ll find all sorts of opportunities at Intersnack.*
***Join our team and help us to grow and celebrate our successes together!***

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
