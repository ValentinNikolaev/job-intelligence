# FinOps Data Analyst & Consultant (m/w/d)

Posted: 2026-08-27T05:30:46Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Behind every optimisation decision is data. As a **FinOps Data Analyst & Consultant** at Cortex Reply, you'll transform millions of billing line items into forecasts, dashboards, and insights that executives can act on - across cloud, AI, SaaS, and on-prem environments.

This is an analytical consulting role at the intersection of data science, financial modelling, and business intelligence. You'll build cost models, design KPI frameworks, and deliver the transparency that makes technology spend predictable and optimisable.

### Your tasks

**Data Analysis & Cost Investigation**

-

Analyse commitment usage, reservation coverage, and cost trends across cloud, AI/ML, SaaS, and on-prem

-

Derive optimisation recommendations incorporating rightsizing, discounts, and usage anomalies

**Forecasting & Predictive Modelling**

-

Perform spend forecasts and variance analyses to prevent budget surprises

-

Validate cloud-native forecasting tools and contribute to internal ML-based forecast models

**Reporting, Visualisation & KPIs**

-

Design dashboards and reports for technical and executive audiences

-

Define FinOps KPIs and integrate them into live reporting systems aligned with business goals

**Automation & Scaling**

-

Automate reporting, alerting, and data pipelines (PowerAutomate, Python, SQL)

-

Streamline workflows and scale analytics capabilities across clients

**Cost Allocation & Transparency**

-

Drive tagging strategies, taxonomy design, and showback/chargeback models

-

Combine technical and business metrics for full-picture cost transparency

**Thought Leadership**

-

Develop FinOps blueprints and playbooks

-

Contribute trainings, talks, and publications

-

Expand offerings into FinOps for AI, FinOps for SaaS, or sustainability tracking

**Client Advisory & Consulting**

-

Engage directly with client stakeholders to understand business context, translate analytical findings into strategic recommendations, and present results in workshops and steering committees

-

Support proposal development, scoping of new engagements, and client relationship management as a trusted advisor on data-driven cost decisions

### What We Offer

-

Competitive compensation

-

Professional development through challenging projects and training opportunities

-

A diverse, international team with a strong knowledge-sharing culture

-

Opportunities for thought leadership: conferences, publications, certifications

-

A collaborative, supportive team environment

-

Degree in Data Analytics, Finance, Business Administration, Informatics, IT Management, or related field

-

Proficiency in English and German (min. B2 each)

-

Residence in Germany with work eligibility

-

Willingness to travel occasionally

-

Strong analytical skills with focus on financial data interpretation

-

Excellent communication and presentation skills

-

Understanding of agile frameworks and consulting/project management experience

-

Experience with at least one major cloud provider (AWS, Azure, or GCP)

-

Experience with SQL, Python, or R for data analysis and automation

-

Experience with BI tools (Power BI, Apptio BI / TBM Studio, or Tableau)

-

Excel & PowerQuery proficiency

-

Understanding of cloud billing data structures (AWS CUR, Azure Cost Export, GCP BigQuery billing)

-

Proactive, self-organised mindset

### Nice to Have

-

Cloud certifications or FinOps Practitioner certification

-

Familiarity with cloud cost management tools (e.g. Cloudability, Flexera, Kubecost, Infracost)

-

Exposure to ML frameworks or cloud-native forecasting tools

-

Experience with SaaS management, on-prem licence optimisation, or AI cost management

-

Interest in community building, public speaking, or content creation

[Here](https://www.reply.com/cortex-reply/en) you can find more information about Cortex Reply and how we process your [data](https://www.cortexreply-deutschland.de/datenschutz).

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
