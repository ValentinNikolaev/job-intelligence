# AI Engineer

Posted: 2026-08-27T05:30:14Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**Our mission**

Better healthcare outcomes depend on turning data into intelligence that can be trusted and acted on. LOGEX holds financial, operational, clinical and pathway data for healthcare providers across Europe, and AI is becoming central to how we turn that data into value — in our products and in how we work. We are building that capability deliberately, with the rigour a regulated healthcare-data business demands.

**This is a hands-on building role — you will help shape LOGEX’s AI journey and deliver AI capabilities into our products, with the teams.**

**The role**

As AI Engineer, you will help shape and deliver LOGEX’s AI journey — building applied AI capabilities into our products and, where useful, into how we work. You will turn AI use cases into working, reliable software: integrating LLMs and applied AI, building pipelines, and applying machine learning where it fits the problem. The emphasis is on delivering dependable, in-product AI capabilities with the teams, and making sure what you ship is tested, monitored and dependable enough for healthcare data.

You will work closely with the AI Architect, data engineers, platform and product teams, and play a central part in turning the AI direction into real features customers use — moving capabilities from prototype to production.

**
What you will own**

**In-product AI capabilities. **Design, build and ship AI capabilities into LOGEX’s products with the teams — from idea through to integrated, working features that customers use.

**LLM and applied AI development. **Build with modern AI approaches — LLM integration, retrieval-augmented generation, prompt and evaluation design — and apply machine learning where it fits the problem.

**Production reliability (MLOps / LLMOps). **Make AI dependable in production — deployment, monitoring, evaluation, versioning and continuous improvement of the capabilities you build.

**Quality, safety and compliance. **Build AI that is tested, evaluated, secure and privacy-preserving, appropriate to a regulated healthcare-data environment.

**Your impact and responsibilities**

• Build and ship in-product AI capabilities with the product and engineering teams

• Integrate LLMs and applied AI — RAG, prompting, evaluation — into real product features

• Help turn LOGEX’s AI direction into working, reliable software

• Build evaluation, testing and monitoring into AI capabilities so they are reliable and observable

• Deploy and operate AI in production (MLOps / LLMOps), and improve it over time

• Prepare and work with data for AI, in partnership with data engineering

• Apply machine learning where it fits the problem, alongside LLM-based and applied-AI approaches

• Write clean, well-tested code and take part in code reviews

• Build AI capabilities that are secure, privacy-preserving and compliant (GDPR and similar)

• Work with the AI Architect to follow shared patterns, standards and guardrails

• Apply AI to internal engineering, QA and operational workflows where it adds value

**Your profile**

We are looking for a hands-on AI engineer who can build reliable AI capabilities and bring them into production.

**Experience**

• Solid experience building AI capabilities and shipping them into products or production

• Experience integrating modern AI (LLMs, RAG) into real applications

• A strong software / data engineering background, with hands-on AI delivery

• Experience with building and deploying ML models is relevant and valued, though not the primary focus

• Experience working in regulated environments (healthcare, financial services or similar) is an advantage

**Technical depth**

• Strong coding ability (for example Python) and solid software engineering fundamentals

• Hands-on experience with LLM-based and applied-AI development — frameworks, cloud AI services and orchestration

• Practical experience with RAG, prompting and evaluation, and with integrating AI into real products

• Working knowledge of MLOps / LLMOps — deployment, monitoring, evaluation and versioning

• Good data engineering skills — preparing and working with data for AI

• Working knowledge of machine learning — training, tuning and serving models — where it fits the problem

• Awareness of AI safety, privacy and responsible-AI practice

**Delivery and execution**

• Strongly outcome-driven — measured by reliable AI capabilities shipped into production, not prototypes

• Hands-on and pragmatic, with strong attention to quality, evaluation and reliability

• Comfortable working where AI approaches and ways of working are still forming

**Personal style**

• Collaborative and a strong communicator, equally effective with engineers and data practitioners

• Pragmatic about AI — focused on real value and reliability over hype

• High standards, but pragmatic; comfortable operating with pace and ambiguity

• Willing to travel moderately across LOGEX’s locations

**Why LOGEX?**

-

25 vacation days (based on full-time employment) to recharge, with the option to purchase additional days

-

An informal working environment with motivated colleagues

-

The possibility to work in a hybrid setup

-

A laptop and everything you need to set up a comfortable and ergonomic home office

-

Personal and professional development opportunities through our LOGEX Academy

-

Access to our mental health partner, OpenUp

-

Regular after-work drinks and many more social events

**Contact us!**

You can apply via the button below and upload your CV. For more information, or in case you have any
questions, you can contact Wesley Schreuder at

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
