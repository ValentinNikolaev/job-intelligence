# Senior Full Stack Developer (m/w/d)

Posted: 2026-08-27T02:30:23Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

At TechBiz Global, we’re more than just a recruitment and software development company — we’re aGerman based global partner dedicated to your business success. With a diverse, distributed team, we specialize in IT recruitment, outstaffing, outsourcing, software development, and consulting services for more than 100 clients around over 20 countries.
We are providing recruitment service to our TOP clients from our portfolio. We are currently seeking a Senior Full Stack Developer to join one of our **clients**' teams. If you're looking for an exciting opportunity to grow in a innovative environment, this could be the perfect fit for you.

**AI Development**: Build and optimize AI agents using LangChain and other cutting-edge technologies.
**Full Stack Development**: Work with the MEAN Stack (MongoDB, Express, Angular, Node.js), with experience in React being a plus.
**API Development & Maintenance**: Design, implement, and maintain APIs to support AI-powered platforms and tools.
**Database Management**: Utilize MongoDB and ChromaDB to efficiently manage large datasets. You will work closely with a senior data engineer in this area.
**Innovation & Collaboration**: Collaborate with our team to develop AI-driven solutions and brainstorm ways to further enhance the platform.
**Bonus Points**: Experience with Retrieval-Augmented Generation (RAG) is highly desirable.

#### **Qualifications**:

-

Bachelor’s or Master’s degree in Computer Science, Software Engineering, or a related field.

-

5+ years of experience as a Full Stack Developer or in a similar role, ideally within AI or tech start-ups. We are open to this being your first senior position if you can demonstrate strong experience and determination.

-

Proven experience in building and managing AI agents, particularly using LangChain.

-

Strong background in full-stack development, with expertise in the MEAN Stack.

-

Solid experience with API design, development, and maintenance.

-

Familiarity with Angular, and ideally some experience with React.

-

Experience with RAG is a significant advantage.

-

High agency, self-motivation, and a hands-on approach to problem-solving. We place a strong emphasis on agency when hiring.

-

Excellent communication skills and the ability to work in a fast-paced, collaborative environment.

-

Fluent in English.

#### **Benefits**:

-

**Salary**: Competitive base salary based on experience, with the potential for a significant increase after our next fundraising round.

-

**Equity Options**: A generous equity program that ensures you have a stake in the company's success, aligning your goals with ours.

-

**Remote Work**: Hybrid position offering the flexibility to work remotely, with the option to use our office at Humboldt University or at K.I.E.Z. in Berlin. Some in-person attendance is required for team meetings and occasional start-up or industry events.

-

**Location**: Candidates should be located in Berlin or within close proximity.

-

**Growth Opportunity**: Gain deep insights into all aspects of the business and take your career to the next level. You will be part of a fast-growing start-up, making a tangible impact. This could be your first senior role, with the possibility of expanding into managerial positions, or you can focus on data if you prefer.

-

**Supportive Culture**: We foster a safe, inclusive, and supportive work environment where everyone's ideas are valued. We avoid micromanagement.

-

**Learning Environment**: We believe in continuous learning and growth, offering opportunities to explore new technologies, methodologies, and approaches in data engineering.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
