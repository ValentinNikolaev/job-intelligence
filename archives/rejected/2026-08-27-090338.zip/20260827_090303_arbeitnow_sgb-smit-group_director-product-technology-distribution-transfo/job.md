# Director Product Technology Distribution Transformer (m/f/d)

Posted: 2026-08-27T02:30:27Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

### **Transform with us the future of energy ⚡**

The **SGB‑SMIT Group** is an international transformer manufacturer with locations in **Europe, Asia** and **America**. With reliable transformer technology, the company actively supports the global energy transition in areas such as renewable energy, industry and urban energy infrastructure.

As a key link between power generation, transmission and distribution, **SGB‑SMIT Group** develops and manufactures **power transformers, distribution transformers, cast‑resin transformers** and custom solutions for data centers, industrial applications and e‑mobility. These products ensure efficient, stable and secure energy flows worldwide.

With more than **3,800 employees** worldwide, the **SGB‑SMIT Group** stands for quality, innovation and sustainability and offers a stable environment to work on technologies that shape the energy systems of the future.

#### What sets the SGB-SMIT Group apart**: 🌍**

We combine the strength of an **international technology company** with an **employee-oriented corporate culture**:

-

Meaningful work at the heart of the energy transition

-

Short decision-making processes and direct cooperation

-

Stable, growing company with long-term prospects

Your contribution counts – **both professionally and personally**.

#### **Your benefits at SGB-SMIT Group: 🚀**

-

Stable, growing company with long-term prospects

-

Attractive salary and social benefits

-

Flexible working hours and hybrid working models

-

30+1 vacation days plus special leave

-

Training and development opportunities

-

Company pension plan and employee insurance

-

Health and fitness offers (HanseFit)

-

Company restaurant, free drinks, and e-charging parking spaces

-

Bicycle and IT leasing

-

Subsidy for Germany/RVV ticket

-

Employee discounts via Benify

#### **Your tasks: 📌**

-

Define and execute the global Technology & Engineering strategy for Liquid-Immersed Distribution Transformers, ensuring alignment with overall business objectives and long-term growth plans.

-

Lead and develop a global Engineering organization across Operational Engineering and R&D, fostering a culture of innovation, technical excellence, collaboration and continuous improvement.

-

Establish scalable organizational structures, engineering governance models and global operating frameworks to drive efficiency and engineering performance across multiple locations.

-

Drive technology roadmaps, product development initiatives and engineering transformation programs to strengthen competitiveness and accelerate innovation.

-

Build and leverage global synergies across Distribution Transformer technologies, engineering teams and product platforms to maximize knowledge sharing and standardization.

-

Own engineering standards, design governance and compliance with international regulations, quality requirements and industry best practices.

-

Lead strategic engineering investments, resource allocation and budget planning to ensure effective execution of business and technology priorities.

-

Champion digital engineering, design automation and global engineering platforms to enhance productivity, scalability and product quality.

-

Partner closely with Operations, Product Management, Manufacturing and Executive Leadership to translate market demands into sustainable engineering solutions and product innovations.

-

Establish a high-performance engineering culture through talent development, succession planning, technical capability building and strong leadership across a global matrix organization.

#### **Your profile: 🔎**

-

Degree in Electrical Engineering (Power Engineering, High Voltage Engineering) or Physics, combined with a strong track record in engineering leadership within industrial or energy-related environments.

-

Extensive experience leading global Technology & Engineering organizations, ideally within the power transformer, electrical equipment or energy infrastructure industry.

-

Proven success in defining and executing technology, innovation and engineering strategies that drive business growth, operational excellence and product competitiveness.

-

Deep technical expertise in power and distribution transformer technologies, product development, operational engineering and international industry standards.

-

Strong leadership capabilities with experience managing global matrix organizations, developing high-performing teams and leading cross-functional stakeholders across multiple locations.

-

Strategic and entrepreneurial mindset with the ability to translate market, customer and technology trends into sustainable business and engineering solutions.

-

Solid understanding of the end-to-end value chain, including engineering, manufacturing, quality, project management and commercial requirements.

-

Excellent communication and influencing skills, executive presence, international mindset and willingness to travel globally.

If you value a dynamic, growing, and intercultural environment and enjoy hands-on work, then become part of the **SGB-SMIT Group** - **transform with us the future of energy**. ⚡

We look forward to receiving your application! ⚡

Learn more about the SGB-SMIT Group as an employer, our values, and career opportunities on our careers page:

[https://www.sgb-smit.com/career-jobs/sgb-smit-group#/](https://www.sgb-smit.com/career-jobs/sgb-smit-group#/)

*The terms used in this text refer to all genders in accordance with the General Equal Treatment Act (AGG).*

.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
