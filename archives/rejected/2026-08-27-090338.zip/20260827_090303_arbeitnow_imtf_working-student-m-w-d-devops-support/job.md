# Working Student (m/w/d) - DevOps Support

Posted: 2026-08-27T05:20:12Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

As a leading global software product company in the field of Compliance & Automation, ITMF Group develop cutting-edge RegTech solutions with a focus on Anti-Money Laundering and Anti-Fraud. We are dedicated to automating manual processes through the use of Machine Learning and Data Science, ensuring our clients have the most efficient and effective compliance solutions in the market.

We value innovation, excellence, and continuous learning at IMTF Group. We provide a dynamic, collaborative work environment where your ideas will be heard and your skills will be put to the test.

As a Working Student, you will support the team in ensuring the reliability, scalability, and performance of our cloud-based applications and infrastructure.

**Responsibilities**

- Assist in managing SaaS environments within the Plattform Deployment & Operations team
- Ensure the security, cost-efficiency, and stability of systems
- Support the implementation of our DevOps strategy, from driving the non-functional needs from the application micro-service to all operational aspects
- Contribute to building a modern cloud-inspired company culture that enhances software development and delivery processes
- Help architect and implement cloud solutions, focusing on deployment and monitoring for modern cloud products (PaaS)
- Collaborate with product and engineering teams to create scalable solutions addressing financial crime
- Stay up-to-date with technology trends related to Compliance and Risk solutions
- Support implementing and manage our CI/CD pipeline, customized to meet the needs of our customers and the nature of our business
- Collaborate with the IMTF Software Operations team to brainstorm ideas, provide feedback, and share best practices

**Requirements**

- Currently enrolled in a relevant degree program in Computer Science, Engineering, or a related field
- Basic understanding of cloud infrastructure, preferably with Azure or AWS
- Familiarity with services including VMs, K8s, storage, networking, and security
- Interest in infrastructure-as-code, containerization, and container orchestration
- Willingness to learn about implementing security measures during the design phase
- Exposure to at least one major cloud provider (e.g., Azure, AWS, GCP)
- Strong problem-solving skills and a creative approach to technical challenges
- Ability to quickly grasp current technology trends
- Very good command of both German and English (written and spoken)

**Benefits**

**We'll keep you engaged as you’ll have the opportunity to: **

- **Make the World Safer**: Contribute to preventing financial crime and help our customers create a safer world.
- **Be Part of an Established RegTech**: Make a difference at a leading RegTech company in Switzerland.
- **International Exposure**: Expand your horizons by working with international customers on various challenging projects and markets in a dynamic, multicultural team.
- **Ownership and Development**: Make an impact and develop yourself by taking on significant ownership and responsibility from the beginning.
- **Paid Further Education**: Take advantage of opportunities for paid further education to enhance your skills and career growth.

The anticipated salary for a Working Student - DevOps in Bensheim, Germany is EUR 18.000 gross per year based on a 20 hours working week (50 % employment level).

At IMTF, we are committed to treating all candidates with respect and equality, regardless of gender, religion, nationality, or any other characteristic. We embrace diversity and inclusion as integral components of our organizational culture, and we welcome candidates from all backgrounds to apply and contribute to our team.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
