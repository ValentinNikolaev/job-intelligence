# Senior Agentic AI Engineer

Posted: 2026-08-27T02:40:21Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

CUBE are a global RegTech business defining and implementing the gold standard of regulatory intelligence for the financial services industry. We deliver our services through intuitive SaaS solutions, powered by AI, to simplify the complex and everchanging world of compliance for our clients.

** **

**Why us?**

🌍 CUBE is a globally recognized brand at the forefront of Regulatory Technology. Our industry-leading SaaS solutions are trusted by the world’s top financial institutions globally.

🚀 In 2024, we achieved over 50% growth, both organically and through two strategic acquisitions. We’re a fast-paced, high-performing team that thrives on pushing boundaries—continuously evolving our products, services, and operations. At CUBE, we don’t just keep up we stay ahead.

🌱 We believe our future is built by bold, ambitious individuals who are driven to make a real difference. Our “make it happen” culture empowers you to take ownership of your career and accelerate your personal and professional development from day one.

🌐 With over 700 CUBERs across 19 countries spanning EMEA, the Americas, and APAC, we operate as one team with a shared mission to transform regulatory compliance. Diversity, collaboration, and purpose are the heartbeat of our success.

💡 We were among the first to harness the power of AI in regulatory intelligence, and we continue to lead with our cutting-edge technology. At CUBE, You will work alongside some of the brightest minds in AI research and engineering in developing impactful solutions that are reshaping the world of regulatory compliance.

**Role: **

We are looking for an experienced LLM Engineer for our new Berlin AI lab who is passionate about agentic AI - systems where models reason, act, and learn autonomously. You should have a proven track record of building scalable, production-grade AI systems and a strong grasp of how to translate cutting-edge research into real-world impact. The ideal candidate combines deep technical expertise with creativity and a bias for shipping practical, elegant solutions.

Your role sits at the intersection of our data and backend teams. You will design and implement advanced, (multi-)agentic AI systems that apply LLMs not just as tools, but as autonomous collaborators - reasoning over data, orchestrating workflows, and driving decisions. You’ll combine solid backend engineering with a deep understanding of how LLMs can act, learn, and adapt to solve complex user problems at scale.

This role is perfect for someone who loves turning cutting-edge AI and NLP research into scalable systems, thrives on end-to-end ownership and autonomy, an experimentation-welcoming setting, and wants to shape how agentic AI transforms enterprise software.

You will be working closely with the Head of Agentic AI Engineering and our compact high-performance team of LLM engineers, software engineers, and data scientists. The team is part of recently acquired Berlin startup Kodex AI and works hybrid from an amazing office (great location, gym, rooftop pool & sauna, many events), and from home.

Our evolving tech stack:

-

Core: python (fastAPI, langchain), Typescript (React)

-

Infra & storage: MySQL, Pinecone, GCP, AWS, Azure, Firebase, Docker, github

**Qualifications:**

-

4+ years of experience in software or LLM engineering, ideally with Python

-

Strong foundation in backend or data systems, and experience deploying LLM-based applications to production

-

Familiarity with LLM orchestration frameworks (e.g. LangChain, LlamaIndex, OpenDevin, or custom agentic architectures)

-

Understanding of prompt engineering, retrieval-augmented generation (RAG), tool-use / agent frameworks, LLM evaluation, NLP methods

-

Experience with most of our tech stack (as listed above)

-

Bonus: experience building B2B SaaS or AI workflow products

-

Bonus: experience in an early-stage startup environment

-

Bonus: experience in FinTech / RegTech / Finance / Regulatory / Compliance domains

-

Great problem-solving skills, a pragmatic mindset, and a bias toward fast iteration

-

Curiosity and ability to learn new technologies quickly

-

Strong English communication skills and comfort working in a small, startup-like, tech-driven team

**Interested?**

If you are passionate about leveraging technology to transform regulatory compliance and meet the qualifications outlined above, we invite you to apply. Please submit your resume detailing your relevant experience and interest in CUBE.​

CUBE is an equal opportunity employer. We celebrate diversity and are committed to creating an inclusive environment for all employees.

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
