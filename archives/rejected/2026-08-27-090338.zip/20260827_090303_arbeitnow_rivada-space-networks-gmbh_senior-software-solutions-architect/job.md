# Senior Software Solutions Architect

Posted: 2026-08-27T05:09:55Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**Who we are**

Welcome to one of Europe’s most exciting New Space companies, creating the world's first fully connected mesh network in the sky. We are an international team of experts and engineers who have spent their careers expanding the boundaries and potential of space, now united in pursuit of a single vision. We value trust, open communication and collaboration to achieve the best results together. Now we are looking for the best talents for our locations in Munich and Berlin to help us make our vision come true.

**Your mission**

We are seeking a highly skilled and experienced Senior Software Solutions Architect for the Software Solutions to join our dynamic and innovative team. You will be responsible for the design and the engineering solution as well as the technical management of the Digital Twin software, ensuring it meets our business needs. The Digital Twin includes the end-to-end simulation and virtual models of physical assets, processes and systems of Rivada constellation.

This includes

- Defining the Digital Twin strategic vision and ensuring enterprise alignment including e.g.:

- Software road map: Defines the multi-year strategy with a realistic and progressing approach to integrate the different building blocks of the Digital Twin.
- Vendor management: Evaluates between in-house developed solutions and 3rdparty software providers, integration tools to get the best value and avoid vendors lock-in.

- Designing and specifying the software technical architecture including e.g.:

- Architectural design: Develop and maintain the overall software architecture, ensuring it aligns with the strategic goals and technical standards.
- Model development: Define behavioural models, simulations, and visual environments for physical assets, processes and systems.
- Systemintegration: Oversee the integration of various software components and3rdparty systems, ensuring seamless interoperability.
- Dataand AIanalytics:Assessment of scalablearchitectureto supportmassivedatamanagement,workflowsandprocesses, including the use of AIframeworks.

- Continuous technology evaluation with emerging technologies and industry trends, including the use of AI tooling and modern tech stacks for optimal performance and cost efficiency.
- Implementing proof of concepts to design and prototype solutions (including AI) to validate technical feasibility and demonstrate value before full-scale production.
- Providing technical leadership and guidance to development teams, ensuring projects are implemented effectively and efficiently.
- Preparing financial engineering for cost optimisation and budget forecasting.

**What you bring on the table**

- Bachelor’s degree in computer science, engineering, or related field.
- At least 10 years of professional experience and 5 years with a focus on simulations and digital twin domains, defining technical architecture sand deployment solutions.
- Valuable experience as a software solutions architect or in the space sector.
- Good knowledge in programming languages such as Python, C++,C #,Java, etc.
- Goodunderstanding of mathematicalmodelling, simulation techniques, and algorithms.
- Experience with user interface design for simulation software applications.
- Familiarity with software development methodologies, such as Agile or Scrum.
- Very goodcommunication and soft skills to coordinate and interact with internal teams.
- Able to travel and work in a very dynamic environment.
- Fluency in English.

**Why you should join us**

We are an international team of space enthusiasts, following one great vision. We value equality in our work environment where different opinions, backgrounds and experiences are not only welcomed but also necessary to achieve the best result collaboratively. This permanent position was created recently and thus offers a lot of creative freedom. Our approach is to create a modern work environment with hybrid working model. We offer an attractive salary depending on your experience. Rivada Space Networks is an equal opportunity employer with the approach to create a diverse and inclusive working environment. We therefore welcome applications from all qualified candidates irrespective of race, color, religion, gender, sexual orientation, ethnicity, age, disability, or other individual characteristics.

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
