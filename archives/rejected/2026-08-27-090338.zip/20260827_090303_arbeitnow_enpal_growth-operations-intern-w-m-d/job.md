# Growth & Operations Intern (w/m/d)

Posted: 2026-08-27T02:40:28Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Unser Ziel ist eine Solaranlage auf jedem Dach, ein Speicher in jedem Haus und ein E-Auto in jeder Garage. Enpal macht das möglich mit einer integrierten Gesamtlösung für dezentrale Energie – von Solaranlage und Batteriespeicher über Wallbox, Smart Meter bis zur Wärmepumpe. Herzstück ist unsere KI-gestützte Plattform [Enpal.One](http://Enpal.One)+, die tausende Systeme intelligent vernetzt und Strombezug sowie -einspeisung effizient am Energiemarkt optimiert.

Bist Du bereit für Lösungen, die mehr als nur ein Versprechen sind und täglich echte Lebensqualität in tausende Haushalte bringen? Was du bei Enpal gestaltest, liefert morgen sauberen Strom und verändert nachhaltig, wie wir Energie nutzen.

### **Deine Aufgaben**

-

Du arbeitest eng mit unseren externen Vertriebspartnern sowie internen Teams zusammen und sorgst für eine reibungslose Zusammenarbeit.

-

Du begleitest das Onboarding neuer Vertriebspartner und unterstützt sie dabei, schnell erfolgreich zu werden.

-

Du bist erste Ansprechperson für operative und organisatorische Fragen unserer Vertriebspartner und unterstützt sie im Tagesgeschäft.

-

Du arbeitest eng mit verschiedenen Teams zusammen und bringst eigene Ideen ein, um unsere Prozesse kontinuierlich weiterzuentwickeln.

-

Du analysierst Prozesse, identifizierst Verbesserungspotenziale und unterstützt bei der Umsetzung von Optimierungsmaßnahmen.

-

Du wertest relevante Kennzahlen aus, erstellst Auswertungen und leitest Handlungsempfehlungen ab.

-

Du leitest Daily-Meetings, koordinierst offene Themen und sorgst dafür, dass Projekte effizient vorankommen.

-

Du übernimmst Verantwortung für eigene Projekte und treibst diese selbstständig voran.

### **Dein Profil**

-

Du studierst Wirtschaftswissenschaften, Wirtschaftsingenieurwesen oder einen vergleichbaren Studiengang, oder hast dein Studium bereits erfolgreich abgeschlossen.

-

Du hast Freude am Umgang mit Menschen und kommunizierst sicher mit unterschiedlichen Stakeholdern.

-

Du verfügst über ein gutes analytisches Verständnis und kannst datenbasierte Entscheidungen unterstützen.

-

Du übernimmst gerne Verantwortung und gehst Themen eigenständig und proaktiv an.

-

Du arbeitest strukturiert, organisiert und behältst auch bei mehreren Themen gleichzeitig den Überblick.

-

Erste praktische Erfahrungen durch Praktika, Werkstudententätigkeiten oder eigene Projekte sind ein Plus, aber kein Muss.

-

Hervorragende Deutschkenntnisse in Wort und Schrift runden dein Profil ab.

*Du bist interessiert, auch wenn du nicht alle Anforderungen erfüllst? Bewirb dich trotzdem! Wir freuen uns darauf, dein Potenzial zu entdecken - unabhängig davon, ob deine Erfahrung jede einzelne Voraussetzung erfüllt. *☀️

###
**Darauf kannst Du Dich freuen**

-

**Arbeite in Deutschlands erstem grünen Unicorn** - Gestalte aktiv die solare Energiewende mit.

-

**Die Sonne scheint auf der ganzen Welt** - Bei Enpal arbeitest du mit einem hochmotivierten, diversen Team aus über 65 Nationalitäten.

-

**Grown-up Business & Startup Spirit** - In unserem modernen Office in Berlin-Friedrichshain findest du von höhenverstellbaren Tischen, Tischtennisplatte bis gefüllten Getränkekühlschränken und Barista-Coffee alles was das Herz begehrt.

-

**Dein Kick-start bei Enpal** - Onboarding-Tag mit Welcome Bag, Buddy-Programm und einem Team, das dich wirklich abholt.

-

**Bleib auf dem Laufenden & gestalte mit** -** **Transparente All-Hands, kurze Entscheidungswege und eine offene Feedback-Kultur, denn ohne Fehler gibt es keinen Fortschritt.

-

**Energiewende geht nur gemeinsam** - Bei Enpal erwartet dich ein legendärer Teamspirit und unvergessliche Team- und Companyevents.

-

**Dein Extra-Boost** -** **29 Urlaubstage + je ein freier Tag an Heiligabend und Silvester, vergünstigte Mitgliedschaft bei Wellhub und Corporate Benefits. Alles, was dir hilft, Arbeit und Leben gut zu verbinden.

*Wir bei Enpal sind stolz auf die Vielfältigkeit unseres Teams. Weder bei der Einstellung noch während des Beschäftigungsverhältnisses werden Entscheidungen auf Basis von Hautfarbe, Religion oder religiösen Glaubens, ethnischer oder nationaler Herkunft, Nationalität, Geschlechteridentität, sexuelle Orientierung, Behinderung oder Alter getroffen. Enpal steht für einen sicheren Arbeitsplatz und geht gegen Diskriminierung und Belästigung jeglicher Art vor.*

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
