# Senior Cloud Architect

Posted: 2026-08-27T05:09:55Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**Who we are**

Welcome to one of Europe’s most exciting New Space companies, creating the world's first fully connected mesh network in the sky. We are an international team of experts and engineers who have spent their careers expanding the boundaries and potential of space, now united in pursuit of a single vision. We value trust, open communication and collaboration to achieve the best results together. Now we are looking for the best talents for our locations in Munich and Berlin to help us make our vision come true.

**Your mission**

We are seeking a highly skilled and experienced Senior Cloud Architect to join our dynamic and innovative team. You will be responsible for the design and the engineering solution, as well as the technical management of the RSN Cloud Infrastructure, ensuring it meets our business needs.

This includes

- Defining the CI strategic vision and ensuring enterprise alignment including e.g.:

- Cloud road map: Defines the multi-year cloud strategy, choosing between public, private, hybrid, or multi-cloud approaches based on company goals.
- Vendor management: Evaluates cloud providers, third-party software, and integration tools to get the best value and avoid vendor lock-in.

- Designing and specifying the CI technical architecture including e.g.:

- High availability &disaster recovery: Designs systems with automated failovers and multi-region replication so business services never go down.
- Modern paradigms: Champions microservices, containerization (Docker, Kubernetes), and serverless architectures to maximize application agility.
- AI tooling & tech stack: Evaluateand govern modern AI tools and frameworks (e.g., LLMs, RAG pipelines, vector databases, and orchestration tools) foroptimalperformance and cost.
- Data &analyticsinfra: Architectures scalable data pipelines, data warehouses, and data lakes capable of handling massive telemetry or business data.

- Promoting DevSecOps and automation including e.g.:
- Infrastructure as Code (IaC): Ensures that entire environments can be spun up or torn down automatically via code,eliminatingmanual configuration errors.
- Security-first mindset: Integrates continuous security monitoring, automated vulnerability scanning, and strict encryption into the core design.
- CI/CD integration: Collaborates with DevOps teams to build smooth software deployment pipelines, accelerating how fast new features hit production.
- Executing proof of concepts to design and prototype solutions(including AI)to validate technical feasibility and demonstrate value before full-scale production.
- Preparing financial engineering for cost optimisation and budget forecasting.

**What you bring on the table**

- Bachelor’s degree in computer science, Information Technology, or related field.
- 10+ years of professional experience in CI with5+ years specifically as a cloud architect defining and specifying technical architecture and deployment solutions.
- Valuable experience in setting up a CI from scratch.
- Holistic understanding of cloud infrastructure building blocks: compute, storage, networking, monitoring, security ,automation and inventory.
- Very strong with CICD, pipeline automation and DevOps, particularly with Terraform, GitLab and operational use case designs (like backup, application upgrade).
- Experience in the following technologies and domains would be desired:

- Expert knowledge of major cloud providers (AWS and GCP)and desirable experience in OpenStack ,hybrid and/or multi-cloud environments.
- Expert knowledge in automation tools like Terraform or Ansible.
- Expert knowledge in OS software such as Kubernetes, Kafka, ElasticSearch, Prometheus, Grafana, Kibana.
- Knowledge in security management and IT Service Management processes.
- Very good communication and soft skills to coordinate and interact with other internal teams.

- Able to travel and work in a very dynamic environment.
- Fluency in English.

**Why you should join us**

We are an international team of space enthusiasts, following one great vision. We value equality in our work environment where different opinions, backgrounds and experiences are not only welcomed but also necessary to achieve the best result collaboratively. This permanent position was created recently and thus offers a lot of creative freedom. Our approach is to create a modern work environment with hybrid working model. We offer an attractive salary depending on your experience. Rivada Space Networks is an equal opportunity employer with the approach to create a diverse and inclusive working environment. We therefore welcome applications from all qualified candidates irrespective of race, color, religion, gender, sexual orientation, ethnicity, age, disability, or other individual characteristics.

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
