# Senior SAP Logistics Developer - Vollzeit (m/w/d)

Posted: 2026-09-05T05:30:01Z

## Rejection

- Category: tech_stack
- Reason: role does not mention Go/Golang or PHP

ÜBER** UNS:**

Wir sind die 24 Log GmbH, ein innovatives und wachsendes Unternehmen im Bereich der SAP Logistik. Unsere Mission ist es, die komplexen Herausforderungen der modernen Logistik mit intelligenten, zielstrebigen und benutzerfreundlichen Lösungen zu meistern. Von der Konzeption über die Realisierung und Implementierung bis hin zum flächendeckenden, internationalen Rollout und Betrieb begleiten wir Ihre Projekte gewissenhaft und zielorientiert.

Mit unseren SAP-basierten IT-Logistiklösungen und Systemintegrationen sichern wir den reibungslosen Ablauf Ihrer logistischen Prozesse und tragen dazu bei, dass Ihre Projekte erfolgreich und termingerecht abgeschlossen werden.

WIR** BIETEN:**

-

**Sicherer Arbeitsplatz:** Jede Person, die wir einstellen, soll langfristig mit uns wachsen. Das Ziel jeder Einstellung ist eine unbefristete Übernahme.

-

**Firmenwagen:** Für die Ausübung deiner Tätigkeiten stellen wir dir einen Firmenwagen zur Verfügung, damit du flexibel und komfortabel unterwegs bist - auch privat. Du hast **freie Fahrzeugauswahl**!

-

**BIKELEASING:** Du leistest dir dein Wunschfahrrad günstig über unser "Jobrad"-Programm. Umweltfreundlich und fit unterwegs – wir unterstützen dich dabei!

-

**Vielfältige Mitarbeitervorteile:** Profitiere von vermögenswirksamen Leistungen (VWL) und betrieblicher Altersvorsorge (BAV). Wir bieten dir zudem flexible Arbeitszeiten und freie Zeitgestaltung.

-

**Tolle Arbeitsatmosphäre:** Unsere Arbeit lebt von einem positiven und kundenorientierten Umfeld. Nur wer selbst positiv eingestellt ist, kann auch andere begeistern.

-

**Gute Vergütung & Karrierechancen:** Unsere Mitarbeitenden erhalten ein marktgerechtes Gehalt und können von zahlreichen weiteren Leistungen profitieren. Du hast zudem die Möglichkeit, über unser partizipatives Modell fortlaufend von den Erfolgen in der Umsetzung persönlich zu profitieren.

-

**Individuelle Entfaltungsmöglichkeiten:** Spannende Projekte mit viel Potenzial für die eigene Entwicklung und ein persönliches Weiterbildungsbudget, das individuell eingesetzt werden darf.

DEINE** AUFGABENBEREICHE:**

-

Leitung von Projekten im Rahmen der S/4HANA-Transformation.

-

Entwicklung und Anpassung von komplexen SAP-Logistikmodulen nach spezifischen Kundenanforderungen.

-

Führung und Coaching von Junior Consultants und Teammitgliedern zur erfolgreichen Durchführung der Kundenprojekte.

-

Eigenständige Umsetzung und Einführung von innovativen SAP-Technologien wie FIORI/UI5 und ABAP-Entwicklung.

-

Beratung und Unterstützung unserer Kunden bei der Optimierung ihrer Logistikprozesse und der Implementierung neuer SAP-Lösungen.

DEIN** PROFIL:**

-

Abgeschlossene Berufsausbildung zum Informatiker oder vergleichbares Studium.

-

Mindestens 5 Jahre Berufserfahrung im SAP-Logistik-Umfeld.

-

Tiefgehende Erfahrung in der ABAP-Entwicklung und/oder mit FIORI/UI5.

-

Hervorragende analytische Fähigkeiten und eine lösungsorientierte Denkweise.

-

Ausgeprägte Kommunikationsstärke und Teamfähigkeit.

-

Führungsqualitäten und die Fähigkeit, Projekte und Teams erfolgreich zu managen.

-

Selbstständige und strukturierte Arbeitsweise.

-

Sehr gute Deutsch- und Englischkenntnisse.

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
