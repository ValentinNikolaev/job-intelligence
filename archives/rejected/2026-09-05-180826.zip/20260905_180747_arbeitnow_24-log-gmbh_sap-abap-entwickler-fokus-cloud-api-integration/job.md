# SAP ABAP Entwickler – Fokus Cloud & API Integration (REST, OData, BTP) – Vollzeit (m/w/d)

Posted: 2026-09-05T05:30:01Z

## Rejection

- Category: tech_stack
- Reason: role does not mention Go/Golang or PHP

ÜBER** UNS:**

Wir sind die 24 Log GmbH, ein innovatives und wachsendes Unternehmen im Bereich der SAP Logistik. Unsere Mission ist es, die komplexen Herausforderungen der modernen Logistik mit intelligenten, zielstrebigen und benutzerfreundlichen Lösungen zu meistern. Von der Konzeption über die Realisierung und Implementierung bis hin zum flächendeckenden, internationalen Rollout und Betrieb begleiten wir Ihre Projekte gewissenhaft und zielorientiert.

Mit unseren SAP-basierten IT-Logistiklösungen und Systemintegrationen sichern wir den reibungslosen Ablauf Ihrer logistischen Prozesse und tragen dazu bei, dass Ihre Projekte erfolgreich und termingerecht abgeschlossen werden.

WIR** BIETEN:**

-

**Sicherer Arbeitsplatz:** Jede Person, die wir einstellen, soll langfristig mit uns wachsen. Das Ziel jeder Einstellung ist eine unbefristete Übernahme.

-

**Firmenwagen:** Für die Ausübung deiner Tätigkeiten stellen wir dir einen Firmenwagen zur Verfügung, damit du flexibel und komfortabel unterwegs bist - auch privat. Du hast **freie Fahrzeugauswahl**!

-

**BIKELEASING:** Du leistest dir dein Wunschfahrrad günstig über unser "Jobrad"-Programm. Umweltfreundlich und fit unterwegs – wir unterstützen dich dabei!

-

**Vielfältige Mitarbeitervorteile:** Profitiere von vermögenswirksamen Leistungen (VWL) und betrieblicher Altersvorsorge (BAV). Wir bieten dir zudem flexible Arbeitszeiten und freie Zeitgestaltung.

-

**Tolle Arbeitsatmosphäre:** Unsere Arbeit lebt von einem positiven und kundenorientierten Umfeld. Nur wer selbst positiv eingestellt ist, kann auch andere begeistern.

-

**Gute Vergütung & Karrierechancen:** Unsere Mitarbeitenden erhalten ein marktgerechtes Gehalt und können von zahlreichen weiteren Leistungen profitieren. Du hast zudem die Möglichkeit, über unser partizipatives Modell fortlaufend von den Erfolgen in der Umsetzung persönlich zu profitieren.

-

**Individuelle Entfaltungsmöglichkeiten:** Spannende Projekte mit viel Potenzial für die eigene Entwicklung und ein persönliches Weiterbildungsbudget, das individuell eingesetzt werden darf.

DEINE** AUFGABENBEREICHE:**

-

**API-Entwicklung & Design:** Du konzipierst und entwickelst moderne Schnittstellen (REST, OData) für die nahtlose Integration von SAP- und Non-SAP-Systemen (Cloud & On-Premise).

-

**Backend for Frontend:** Du baust hochperformante Backend-Services mittels ABAP RESTful Application Programming Model (RAP) und Core Data Services (CDS) als Basis für moderne SAP Fiori Anwendungen.

-

**Datenformate & Protokolle:** Du arbeitest tagtäglich mit modernen Web-Standards wie JSON, XML und HTTP-Protokollen und stellst einen sicheren und effizienten Datenaustausch sicher.

-

**SAP BTP & Clean Core:** Du bist aktiv an der Erweiterung unseres ERP-Systems über die SAP Business Technology Platform (BTP) beteiligt und hilfst uns dabei, eine "Clean Core"-Strategie umzusetzen.

-

**Architektur & Code-Qualität:** Du evaluierst neue SAP-Technologien, treibst architektonische Entscheidungen voran und stellst durch Code Reviews und Unit Tests eine hohe Softwarequalität sicher.

DEIN** PROFIL:**

-

**Fundament:** Erfolgreich abgeschlossenes Studium in der (Wirtschafts-)Informatik oder eine vergleichbare Ausbildung mit entsprechender Berufserfahrung.

-

**SAP-Erfahrung:** Sehr gute Kenntnisse in der objektorientierten ABAP-Entwicklung (ABAP OO).

-

**Tech-Stack:** Fundierte praktische Erfahrung mit Web-Technologien und Schnittstellen-Design (REST, OData, JSON, API-Management).

-

**Moderne SAP-Welt:** Know-how in aktuellen SAP-Technologien wie SAP RAP, CDS-Views und idealerweise erste Berührungspunkte mit der SAP BTP oder dem Cloud Application Programming Model (CAP).

-

**Mindset:** Du hast Lust auf neue Technologien, denkst über den Tellerrand hinaus und arbeitest gerne agil im Team.

-

**Sprachen:** Fließende Deutsch- und gute Englischkenntnisse runden dein Profil ab.

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
