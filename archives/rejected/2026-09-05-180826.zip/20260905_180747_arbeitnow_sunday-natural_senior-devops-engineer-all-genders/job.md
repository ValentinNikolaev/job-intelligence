# Senior DevOps Engineer (all genders)

Posted: 2026-09-05T05:40:10Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Sunday Natural is one of Germany’s fastest-growing natural health brands, and our eCommerce platform is growing with it – today it serves **7 million monthly active users**, runs on **€400k of AWS per year**, and supports a **development organization of 30+ engineers**. Every one of those numbers has moved sharply upward in the last few years, and all of them will keep moving.

You would be our first dedicated in-house** Senior DevOps Engineer** – and the two biggest engineering projects of the next two years are yours to help define and drive: bringing our entire infrastructure under Terraform, and strengthening the scalability, security and compliance posture across our cloud environments.

## **Your role**

-

**You shape the infrastructure vision.** How we run, deploy, monitor and scale is yours to define, propose and defend.

-

**You work alongside our two external partners** as the in-house technical counterpart – building the architecture and standards together, and bringing the deep platform knowledge back into the company. As the platform grows, taking the technical direction of that group is a natural next step, and one we would actively support.

-

**You own our AWS spend** – €400k a year that currently has no dedicated owner, including where it goes and how we bring it down.

-

**You are the escalation point.** When production is at risk, you decide.

-

**You report directly to the Head of eCommerce Platforms**, with direct access to leadership for the decisions that need it.

### **What you'll own**

-

**AWS infrastructure** – EC2, RDS, Fargate, CloudFront, S3, IAM – plus Cloudflare, DNS and WAF

-

**Security & compliance** – DevSecOps practices, system audits, patching and access reviews, and GDPR-compliant data handling across every environment

-

**Infrastructure as code** – taking us from manually managed to fully Terraform-defined

-

**Data layer** – MySQL under production load: tuning, replication, and backups you have actually restored from

-

**Cloud economics** – a €350k annual AWS budget with real headroom for optimisation

-

**Delivery for 30+ developers** – Bitbucket Pipelines, environments, and how fast and safely code reaches production

-

**Reliability at 7M MAU** – monitoring, logging, alerting and incident response (New Relic, Sentry, CloudWatch, PagerDuty)

## **Your profile**

-

**7+ years running production infrastructure**, with deep hands-on AWS as the person accountable when it breaks

-

**Security-conscious infrastructure operations** – DevSecOps practices, system audits and access reviews, comfortable being accountable for GDPR-relevant data handling

-

**Infrastructure as code at scale** – Terraform as your default way of working, on an estate of comparable size

-

**Deep Linux** (Debian/Ubuntu) – you can trace a slow system from the kernel up and explain what you found

-

**MySQL under real load** – slow-query analysis, replication, indexing, tested recovery

-

**Ownership of monitoring and incident response at scale** – you have built the alerting that catches problems before customers report them, using tooling like New Relic, Datatog, etc. and run the on-call and post-incident process around it

-

**Experience defining standards that other engineers work to**, whether with in-house teams or external partners, and holding the line on them

### **Nice to have**

-

PHP-FPM / Magento 2 performance tuning, or Varnish and Redis at scale

-

Cloud cost optimisation at six-figure annual spend

-

AWS architecture certification

-

Experience with SIEM tooling (e.g. Wazuh) or similar security monitoring

-

Background in direct-to-consumer eCommerce or other high-traffic system operations

## Our stack

Magento 2 · PIM · PHP · MySQL · Redis · Varnish · Docker · AWS · Terraform · Bitbucket Pipelines · New Relic · Sentry · CloudWatch · PagerDuty · Cloudflare

## **What we offer**

-

An appealing discount on all of our products – from essential oils to vitamins & nutrients

-

We offer 28 days of paid time off per year plus up to 5 days off between Christmas and New Year

-

The Urban Sports Club membership and either Swapfiets bike rental or a subsidy for the Deutschlandticket

-

We believe great things happen when we meet in person, which is why we embrace a hybrid model with one home office day per week – up to two depending on the area you are working in – and up to two weeks per year working from abroad

-

Receive various discounts of up to more than 50 percent on attractive brands such as Flaconi, Bosch, Apple or Expedia

-

You will be given real ownership and plenty of room for new initiatives, as well as the opportunity to contribute your expertise and implement your great ideas

-

We like to celebrate each other! Regular tea & office parties, Christmas and summer feasts and various influencer events such as Women's Day

We are looking forward to your application!

**Sunday Natural **emerged from a long-standing passion and research in the fields of health, healing, and personal growth. The lack of natural, high-quality products on the market was the original motivation for founding Sunday Natural in 2013. We aim to produce the products we ourselves would love to buy – as natural as possible, absolutely pure, free from any additives, and of the highest quality. In a strategic partnership with CVC, Sunday Natural is now one of Germany's most renowned quality manufacturers, with its own research and development department in Berlin. For the continuous improvement of our products, we collaborate with selected research institutes, scientists, therapists, farmers, and professional associations.

**We take our ecological responsibility very seriously:** that’s why the majority of our product range is vegan. We also take an innovative approach to packaging: most of our products are packaged in glass, making them almost entirely recyclable.

Our diverse team in Berlin consists of over 400 employees from more than 45 nationalities and continues to grow – but at a sustainable pace. Our goal is to foster a collaborative, supportive, and inclusive work environment with a diverse group of motivated, talented, and visionary team members.

*We highly value equality of opportunity and inclusivity, and we would like to particularly encourage women and candidates from under-represented backgrounds to apply, even if you don’t match with 100% of the requirements.*

[Legal Notice](https://www.sunday.de/impressum/)

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
