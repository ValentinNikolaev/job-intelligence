# Senior Software Engineer / AI Enabler (m/f/d)

Posted: 2026-08-26T14:55:18Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**A career driven by you. **At LeasingMarkt.de, we bring customers and dealers together to make car leasing more accessible, transparent, and efficient. With over 1,000 partner dealerships and nearly 2 million users across the DACH region and the Netherlands, we’ve become Germany’s #1 leasing platform. To keep growing and driving innovation in the mobility space, we’re looking for a Senior Software Engineer to join our high-performance team at our Düsseldorf office.

As a Senior Software Engineer, you will play a key role in designing and developing robust, scalable applications that power one of the largest automotive leasing marketplaces in Europe. You’ll collaborate with a cross-functional team to build and evolve solutions that are architecturally sound, easy to maintain, and built for long-term impact. You’ll help shape technical direction while raising the bar for software quality and stability across the platform.

**What you’ll do:**

- Join one of our builders’ teams to** build great products** loved by our customers.

- Apply an AI-first mindset to every phase of you-build-it-you-run-it: from design and coding to testing, deployment and operations.

- Work hands-on in real product codebases (for example TypeScript/Node/Next.js or Java/Spring), using GenAI tools to accelerate development, improve quality and simplify existing systems.

- Build and evolve AI-powered internal tools and workflows (assistants for coding, reviews, documentation, testing) that engineers across AutoScout24 can rely on every day.

- Act as a multiplier and culture driver: coach teams on effective GenAI usage, share patterns and anti-patterns, and help establish AI-first ways of working across our engineering organization.

- Experiment, measure and improve: run small, data-informed experiments with teams, learn what works in our context, and turn successful approaches into repeatable standards and playbooks.

**What you’ll bring:**

- Experience leveraging AI and Generative AI (GenAI) to enhance engineering productivity — including code generation, debugging, reviews, documentation, and decision support — with a proactive mindset toward adopting tools that streamline development and drive innovation.

- Deep, hands-on experience building production systems (we expect you’ve spent at least 5 years doing this, possibly much more), ideally with PHP and Laravel as well as TypeScript/Node.js/Next.js on AWS, Azure or GCP.

- Demonstrated personal excellence in using GenAI coding tools (for example GitHub Copilot, ChatGPT, Claude Code, Cursor, OpenAI Codex) to significantly improve your own development speed and quality: code generation, refactoring, debugging, tests and documentation.

- Experience integrating LLM APIs (such as OpenAI, Anthropic, Azure OpenAI, Vertex AI or similar) into applications or internal tools.

- Strong communication and influencing skills: you can introduce new tools and practices, align stakeholders, handle skepticism and iterate based on feedback.

- A curious, growth-oriented mindset: you actively seek out new practices and tools, you are comfortable learning in public, and you help others do the same.

- A pragmatic view of GenAI: you understand its limitations and risks and know how to put guardrails in place (reviews, tests, policies) to keep usage safe, compliant and sustainable at scale.

- Experience with performance optimization, caching strategies, and system observability is a plus.

**A culture of growth **

With over 50 nationalities represented, we’re proud to welcome people of all backgrounds to our growing community, and we’re always finding new ways to help people feel welcomed and included. Here, you’ll have the tools, training and support you need to work in a way that suits you, learn new skills and reach your potential.

**For a career where you can drive our business and shape your future, apply now.**

[https://www.leasingmarkt.de/karriere](https://www.leasingmarkt.de/karriere)

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
