# Senior Security Consultant

Posted: 2026-08-09T23:55:25Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**Who is Tenable?**

Tenable® is the Exposure Management company. Over 40,000 organizations around the globe rely on Tenable to understand and reduce cyber risk. Our global employees support 65 percent of the Fortune 500, 50 percent of the Global 2000, and large government agencies. Come be part of our journey!

**What makes Tenable such a great place to work?**

Ask a member of our team and they’ll answer, “Our people!” We work together to build and innovate best-in-class cybersecurity solutions for our customers; all while creating a culture of belonging, respect, and excellence where we can be our best selves. When you’re part of our #OneTenable team, you can expect to partner with some of the most talented and passionate people in the industry, and have the support and resources you need to do work that truly matters. We deliver results that exceed expectations and we win together!

**Your Role:**

The Security Consultant plays a key role in implementing and enabling Tenable’s Exposure Management solutions to help organizations effectively manage and reduce cyber risks. This role onboards Tenable technologies, following industry standards and best practices, to deliver customized solutions that address vulnerabilities across a client’s attack surface. This role's primary focus will be on client billable work, where you will ensure the efficient identification and mitigation of vulnerabilities. Additionally, the role will have the chance to broaden your knowledge across the Tenable portfolio through hands-on experience and learning opportunities facilitated by the Professional Services Organization.

**Organisation Structure:**

- Reports to: Professional Services Delivery Manager/ Director
- Direct reports: None

**Security Consultant Accountabilities:**

*Client Engagement & Relationship Management:*

- Develop a deep understanding of the client’s business and unique security needs to deliver tailored engagements that exceed expectations.
- Build and maintain positive relationships with clients, ensuring ongoing satisfaction and partnership.
- Provide clients with continual insights and consultative advice based on experience with Tenable products, their industry, established standards, and best practices.

*Subject Matter Expertise and Solution Implementation & Enablement:*

- Support clients with the installation, configuration, and operation of Tenable solutions, ensuring they are effectively implemented to meet business and security goals.
- Oversee upgrades and migrations to new hardware or software, facilitating smooth transitions with minimal disruption.
- Offer expert guidance on implementing best practices with Tenable solutions to optimize security workflows and operational efficiency.
- Assist clients in developing and maintaining security policies, standards, and procedures, ensuring they align with industry standards and regulatory requirements.
- Provide ongoing value through insights and consultative advice on Tenable products, tailored to client needs and industry best practices.
- Share thought leadership on effective deployment and utilization of Tenable One solutions.
- Guide clients in implementing best practices and developing Exposure Management Programs.
- Assess user needs and customer requirements to advance the maturity of their Exposure Management program.

*Value Delivery and Best Practices:*

- Deliver additional value through continual insights and consultative advice based on Tenable products, client needs, industry standards, and best practices.
- Provide thought leadership on methods and best practices for deploying and using Tenable One solutions.
- Advise clients on process best practices and assist in developing Exposure Management Programs.
- Research user needs and assess customer requirements to enhance the maturity of their Exposure Management program.

*Customer Engagement and Satisfaction:*

- Ensure overall customer satisfaction while supporting delivery revenue objectives.
- Execute large customer engagements, understanding client business and unique needs to exceed expectations.
- Independently manage client escalations on assigned projects, coordinating with the delivery team and other Tenable departments as needed.
- Develop and maintain positive client relationships and train client staff on the implementation, configuration, and best practices of the Tenable suite.

*Additional Responsibilities:*

- Perform other duties as assigned to support the success of the Professional Services team and the overall organization.

**Knowledge, Skills and Experience:**

- 5+ years of experience in the Information Technology/Cyber Security field and professional services experience.
- Bachelor’s degree in a related technical field such as Information Technology, Computer Science, or equivalent work experience.
- Strong written and verbal communication skills in English + another Language preferably Italian, Dutch or French. Must be comfortable leading 3+ hour calls and keeping up the progression of tasks on the call while assuring that all relevant topics are addressed.
- Strong analytical skills and troubleshooting skills, with the ability to diagnose and resolve complex security issues.
- Proficiency in assessing and identifying threats and risks related to Exposure Management, including vulnerabilities and weaknesses in host or network configurations.
- Recent experience performing vulnerability scans, configuration audits, and security monitoring with core Tenable products, or other industry solutions.
- Familiarity with Metasploit and related tools commonly used to exploit vulnerabilities.
- Familiarity with application security testing, OWASP and common exploitable web application threats in Exposure Management.
- Knowledge of auditing and configuration frameworks such as ISO 17799, CIS, PCI, GLBA, and HIPAA is preferred.
- Proven experience managing client expectations, building relationships and delivering consultative advice to ensure successful outcomes.
- Understanding of IT security principles associated with networks, operating systems, firewalls, databases, cloud infrastructure, identity and access management with experience in one or more of the fields.
- Familiar with developing integrations via REST API using known coding languages such as Python.
- Knowledge and understanding of SCADA and OT systems is a plus.
- Industry-recognised technical certifications preferred.

**Working Environment and Conditions:**

- Ability to work remotely in a self-directed manner.
- Ability to sit and work at a computer for extended periods.
- Physically able to participate in training sessions, presentations and meetings.
- Client-facing travel may be required.
- Some Client site & Tenable office travel may be required.

#LI-AV1

#LI-Remote

This is the expected salary range for this position in the primary job location, depending on experience and qualifications. Compensation for the role will depend on a number of factors, including the candidate's qualifications, skills, competencies, location and experience, and may fall outside of the range shown. Employees are also eligible for variable compensation in addition to base pay (commission for sales roles, bonus for non-sales roles), depending on company and individual performance. Tenable also offers a variety of Competitive wellness and financial benefits.

EU Pay Range

€51.500—€68.833,33 EUR

*We’re committed to promoting Equal Employment Opportunity (EEO) at Tenable - through all equal employment opportunity laws and regulations at the international, federal, state and local levels. If you need a reasonable accommodation due to a disability during the application or recruiting process, please contact* *

**Tenable Data Consent Statement**

Tenable is committed to protecting the privacy and security of your personal data. Depending on your location, one or more of the following notices may apply to you:

[General Applicant Privacy Notice](https://static.tenable.com/marketing/hr/Tenable_General_Applicant_Privacy_Notice_FINAL_4-29-2026_branded.pdf)
[California Applicant Privacy Notice](https://static.tenable.com/marketing/hr/Tenable_CCPA_Notice_Applicants_FINAL_4-29-2026_branded.pdf)
[EU/EEA/UK Applicant Privacy Notice](https://static.tenable.com/marketing/hr/Tenable_EEA_UK_Applicant_Privacy_Notice_FINAL_6-4-2026_branded.pdf)

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
