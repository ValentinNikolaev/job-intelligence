# Senior Market Manager, Luxe

Posted: 2026-08-09T23:55:37Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Airbnb was born in 2007 when two hosts welcomed three guests to their San Francisco home, and has since grown to over 5 million hosts who have welcomed over 2 billion guest arrivals in almost every country across the globe. Every day, hosts offer unique stays and experiences that make it possible for guests to connect with communities in a more authentic way.

**The Difference You Will Make:**

As a Luxe Senior Market Manager, you will drive supply growth for Airbnb Luxe in your assigned geographies — acquiring new listings and cultivating host relationships that define Luxe. You will serve as the on-the-ground market expert, combining deep knowledge of luxury real estate and travel landscape with a consultative, relationship-first approach to acquisition and account management.

You will work with Luxe Guest Services, Content & Quality, and cross-functional teams to ensure every home meets Airbnb Luxe's standards. This role is equally focused on strategic growth and day-to-day excellence - you'll be equally comfortable prospecting net-new hosts, conducting business reviews, and rolling up your sleeves to solve host challenges.

**A Typical Day: **

#### **Supply Acquisition & Pipeline Development**

- Lead net-new host and listing acquisition in assigned markets, moving qualified leads through the funnel to meet and exceed quarterly supply goals

- Prospect and identify high-quality homes through external research, networking, and partnerships with luxury real estate professionals, property managers, and operators

- Qualify incoming leads and deliver fully vetted hosts and listings to the onboarding team with clear handoff documentation

- Compellingly articulate Airbnb Luxe's value proposition across all formats — phone, email, in-person — tailored to the luxury audience

#### **Market Development & Launches**

- Own new market launches end-to-end, including lead generation, host recruitment, coordination with Home Quality and Guest Services, and post-launch performance monitoring

- Develop a nuanced understanding of your markets: desirable neighborhoods, architectural styles, design aesthetics, pricing trends, seasonality, and the competitive landscape

- Build and maintain localized pitches that resonate with luxury homeowners and real estate professionals in your region

#### **Host Account Management & Optimization**

- Manage a portfolio of Luxe hosts, serving as their primary point of contact and trusted advisor

- Conduct regular business reviews and optimization calls to uncover challenges, identify growth opportunities, and provide data-driven recommendations

- Support onboarding of new listings for assigned hosts, ensuring a seamless experience

- Design and deploy strategies to manage and optimize long-tail hosts across your markets

- Improve listing bookability through performance analysis and targeted host education

#### **Cross-Functional Collaboration & Escalations**

- Act as the primary liaison between assigned hosts and internal teams (Guest Services, Content & Quality, Product, Policy) for escalated issues and strategic initiatives

- Serve as an effective "air traffic controller" — routing host requests to the right internal resources while maintaining direct host accessibility

- Cascade host feedback to relevant stakeholders to inform product and policy decisions

- Educate hosts on significant product updates, policy changes, and platform best practices

**Your Expertise:**

#### **Experience**

- 8+ years of relevant experience in sales, account management, business development, or strategic partnerships — ideally within luxury travel, hospitality, or real estate

- Demonstrated track record of hitting or exceeding acquisition and/or revenue targets in a fast-paced, metrics-driven environment

- Experience working cross-functionally across teams to influence change and drive results

- Familiarity with CRM tools and the ability to maintain rigorous pipeline hygiene and reporting

#### **Skills & Competencies**

- Strong executive presence with the ability to build credibility and influence senior decision-makers both internally and within the luxury industry

- Excellent negotiation skills and the ability to close complex, high-value partnerships

- Sharp market instincts — you can quickly assess a neighborhood, identify a trend, and translate that into actionable strategy

- Exceptional written and verbal communication skills; able to craft compelling pitches and maintain polished host-facing correspondence

- Highly organized with the ability to manage multiple priorities, projects, and stakeholder relationships simultaneously

- Comfortable operating with ambiguity and adapting quickly in an ever-evolving environment

#### **Mindset**

- Deep alignment with Airbnb's mission and a passion for the luxury travel and homes space

- A consultative, relationship-first approach — you build trust before you close deals

- Proactive, solutions-oriented, and self-directed; you don't wait for problems to escalate

- Collaborative by nature — you understand that success in this role is a team sport

**Location Specific Requirements:**

*This role is based out of European Ski (France, Italy, Switzerland, Austria, Germany) overseeing European ski destinations. It requires up to 50% travel to markets across European ski, as well as occasional team off-sites.*

*English and French or Italian proficiency required. Additional languages (French/Italian/German) nice to have*

**Our Commitment To Inclusion & Belonging:**

Airbnb is committed to working with the broadest talent pool possible. We believe diverse ideas foster innovation and engagement, and allow us to attract creatively-led people, and to develop the best products, services and solutions. All qualified individuals are encouraged to apply.

**How We'll Take Care of You:**

Our job titles may span more than one career level. The actual base pay is dependent upon many factors, such as: training, transferable skills, work experience, business needs and market demands. The base pay range shown below is annualized, is subject to change and may be modified in the future. This role may also be eligible for bonus, equity, benefits, and Employee Travel Credits.

France Annual Pay Range

€74.000—€92.000 EUR

**How We'll Take Care of You:**

Our job titles may span more than one career level. The actual base pay is dependent upon many factors, such as: training, transferable skills, work experience, business needs and market demands. The base pay range shown below is annualized, is subject to change and may be modified in the future. This role may also be eligible for bonus, equity, benefits, and Employee Travel Credits.

Germany Annual Pay Range

€84.000—€105.000 EUR

**How We'll Take Care of You:**

Our job titles may span more than one career level. The actual base pay is dependent upon many factors, such as: training, transferable skills, work experience, business needs and market demands. The base pay range shown below is annualized, is subject to change and may be modified in the future. This role may also be eligible for bonus, equity, benefits, and Employee Travel Credits.

Italy Annual Pay Range

€65.000—€80.000 EUR

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
