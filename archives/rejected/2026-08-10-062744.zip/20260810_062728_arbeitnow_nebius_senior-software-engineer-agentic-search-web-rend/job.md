# Senior Software Engineer (Agentic Search) – Web Rendering Engineer

Posted: 2026-08-09T23:55:34Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**About Nebius:**

Nebius is leading a new era in cloud infrastructure for the global AI economy. We are building a full-stack AI cloud platform that supports developers and enterprises from data and model training through to production deployment, without the cost and complexity of building large in-house AI/ML infrastructure.

Built by engineers, for engineers. From large-scale GPU orchestration to inference optimization, we own the hard problems across compute, storage, networking and applied AI.

Listed on Nasdaq (NBIS) and headquartered in Amsterdam, we have a global footprint with R&D hubs across Europe, the UK, North America and Israel. Our team of 1,500+ includes hundreds of engineers with deep expertise across hardware, software and AI R&D.

### **The Product**

In a rapidly evolving world, trust in AI depends on AI agents being grounded in fresh, verified real-world data. Search is the foundation that makes this possible. We are building an agent-native search platform designed specifically for AI systems rather than human users. Our product provides programmatic, low-latency, and observable search APIs that AI agents use to retrieve, filter, and reason over real-world information at scale.

### **The Role**

We are looking for a Senior Software Engineer to build the rendering infrastructure behind a novel search engine designed for agentic AI. In this role, you will design systems that transform modern web applications into high quality structured content for search and AI. You will work on browser rendering, JavaScript execution, and large-scale rendering infrastructure capable of processing billions of pages efficiently. Modern websites increasingly rely on client-side rendering, dynamic data loading, and complex application frameworks. Your work will ensure we can reliably render, understand, and extract valuable information while minimising cost and latency.

**In this position, your responsibility will be to:**

- Design and build large-scale rendering systems for modern web applications

- Develop browser-based rendering infrastructure capable of executing complex JavaScript applications reliably

- Research how modern frontend frameworks render and deliver content

- Improve rendering quality, completeness, and performance across diverse websites

- Optimise rendering cost, latency, resource utilisation, and throughput at internet scale

- Translate rendering research into reliable production systems

**You may be a good fit if you:**

Have 5+ years of experience as a software engineer working on production backend or infrastructure systems and are an expert in several of the following areas:

- Browser Rendering

- Chromium rendering pipeline — DOM, Layout, Paint, and Compositing

- JavaScript execution inside browsers and rendering lifecycle and page readiness

- Headless browser execution and browser instrumentation

- Chrome DevTools Protocol (CDP)

- Playwright, Puppeteer, Selenium, or similar frameworks Modern Web Applications

- React, Vue, Angular, Svelte, and modern frontend architectures

- Server-side rendering (SSR), client-side rendering (CSR), and streaming rendering

- Single-page applications (SPA) and Progressive Web Apps (PWA)

- Resource loading, lazy loading, and modern JavaScript bundles

**Strong candidates may also have experience with:**

- Building and operating high-throughput content processing pipelines at internet scale

- Distributed systems design and performance optimisation

- Open-source contributions or active involvement in the engineering community

- Conference talks or technical publications

*We conduct coding interviews as part of the process.*

**Benefits & Perks:**

- Competitive compensation

- Career growth and learning opportunities

- Flexibility and ownership

- Collaborative and innovative culture

- Opportunity to work on impactful AI projects

- International environment and talented teams

**What's it like to work at Nebius:**

Fast moving - Bold thinking - Constant growth - Meaningful impact - Trust and real ownership - Opportunity to shape the future of AI

**Equal Opportunity Statement:**

Nebius is an equal opportunity employer. We are committed to fostering an inclusive and diverse workplace and to providing equal employment opportunities in all aspects of employment. We do not discriminate on the basis of race, color, religion, sex (including pregnancy), national origin, ancestry, age, disability, genetic information, marital status, veteran status, sexual orientation, gender identity or expression, or any other characteristic protected by applicable law.

Applicants must be authorized to work in the country in which they apply and will be required to provide proof of employment eligibility as a condition of hire.

If you need accommodations during the application process, please let us know.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
