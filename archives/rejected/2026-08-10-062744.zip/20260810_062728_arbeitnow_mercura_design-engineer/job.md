# Design Engineer

Posted: 2026-08-10T02:40:12Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Mercura (**YC W25**) helps the companies that build the real world move at software speed, automating the back-office work that runs the **$12 trillion industry** behind every hospital, school, and power plant. We started with one of their biggest bottlenecks - turning messy technical requests into accurate quotes - and grew to **$2M ARR in our first year**. With a team of 16, we're now targeting $10M by the end of 2026 as well as our expansion into the US.

## **About the role**

We're hiring our first Design Engineer to own the look, feel, and implementation of our product. You'll work closely with our CPO and engineers to design clean, intuitive interfaces for non-technical users and ship them to production yourself. In this role, you will bridge design and engineering end-to-end - speaking directly to customers, turning insight into interfaces, and building them with code.

## **What you will be working on**

-

Talk directly to customers, understand their problems, and translate findings into clean product requirements and interface designs

-

Build prototypes with AI tools and in code to test product hypotheses with customers fast

-

Create and implement intuitive, AI-first interfaces that make complex B2B workflows effortless

-

Own the full journey from design to production - working closely with engineers to ship new features

## **What we're looking for**

-

You have 2-5 years of experience as a design engineer, product designer, or frontend engineer with a strong portfolio in AI & complex B2B SaaS products

-

You love speaking to customers directly to identify pain points and problems

-

You are highly proficient in AI-tools (Lovable, Cursor, Claude, ...) and Figma to design and prototype fast

-

You are comfortable shipping code (React, Typescript, Python) to production - this is as much an engineering role as it is a design role

-

You are comfortable working in a fast-paced startup environment and want to build something from the ground up

-

You want to work in-person from our Munich office or are willing to relocate

-

Fluent in German and English (our users are mostly German-speaking only)

## **About the Founders**

We are **Lukas, Stefan & Sean**, the co-founders of Mercura.

We share a deep commitment to excellence and the discipline to pursue what others might consider impossible.

Two of us come from non-academic families, and we all know what it means to create our own paths and overcome barriers. This experience shapes our belief in equal opportunity and fuels our dedication to social mobility.

**Lukas** (left) is responsible for business development at Mercura. With his background as a Data Scientist at Allianz and at Google in Silicon Valley, he brings extensive expertise in data and AI.
Lukas’ family has been active in the construction industry for over 100 years, giving him a deep understanding and passion for the sector's specific needs.

**Sean** (middle) is responsible for technical development at Mercura. As a top 0.01% physicist, Sean earned a Silver medal for Germany at the International Physics Olympiad (IPhO), began researching with the Max Planck Institute at the age of 16, and has since published at leading machine learning conferences.

**Stefan** (right) leads product development at Mercura. Previously, he worked in management consulting at Bain & Company, where he helped manufacturers improve their operations.
Stefan leverages his research experience at the Massachusetts Institute of Technology (MIT) and Harvard Business School to develop innovative solutions for the industry.

At Mercura, we believe that the best ideas emerge when people from different backgrounds collaborate together. We hire based on ability, mindset, and values, and we live by one simple rule: the best idea wins.

Beyond Mercura, we actively support initiatives that promote diversity and gender equity and commit a portion of our personal income each year to organizations expanding opportunity for others.

## **Our company values**

**Customer first. **We stay close to our customer’s reality and use their feedback to build what truly matters and earn their lasting trust.

**Ownership. **We take responsibility end-to-end and act proactively to pursue the most ambitious goals.

**Enjoy the ride. **We build a culture where people can be themselves, have fun doing meaningful work, and celebrate wins along the way.

**Let the best ideas win. **We challenge each other respectfully and judge ideas by merit, not who said it.

**Down-to-earth. **We are approachable, humble, and hands-on, bringing both heart and mind to everything we do.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
