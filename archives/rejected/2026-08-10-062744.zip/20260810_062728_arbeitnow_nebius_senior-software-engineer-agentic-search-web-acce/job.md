# Senior Software Engineer (Agentic Search) - Web Access Engineer

Posted: 2026-08-09T23:55:34Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**About Nebius:**

Nebius is leading a new era in cloud infrastructure for the global AI economy. We are building a full-stack AI cloud platform that supports developers and enterprises from data and model training through to production deployment, without the cost and complexity of building large in-house AI/ML infrastructure.

Built by engineers, for engineers. From large-scale GPU orchestration to inference optimization, we own the hard problems across compute, storage, networking and applied AI.

Listed on Nasdaq (NBIS) and headquartered in Amsterdam, we have a global footprint with R&D hubs across Europe, the UK, North America and Israel. Our team of 1,500+ includes hundreds of engineers with deep expertise across hardware, software and AI R&D.

### **The Product**

In a rapidly evolving world, trust in AI depends on AI agents being grounded in fresh, verified real-world data. Search is the foundation that makes this possible.

We are building an agent-native search platform designed specifically for AI systems rather than human users. Our product provides programmatic, low-latency, and observable search APIs that AI agents use to retrieve, filter, and reason over real-world information at scale.

### **The Role**

We are looking for a Senior Software Engineer to build the web access infrastructure behind a novel search engine designed for agentic AI.

In this role, you will investigate how modern websites communicate with browsers and translate that understanding into production systems operating at internet scale. You will build browser infrastructure and tooling that enables reliable, efficient access to web content across a rapidly changing web.

**Your responsibilities will include:**

- Research and analyse how modern websites communicate with browsers across the complete request lifecycle

- Investigate browser fingerprinting, client verification mechanisms, and modern web technologies to enable reliable web access

- Build tooling for browser instrumentation, debugging, observability, and large-scale experimentation

- Translate technical research into production systems operating at internet scale

**Requirements**

You have 5+ years of experience as a software engineer working on production backend or infrastructure systems, and are an expert in several of the following areas:

*Browser Technologies*

- Chromium architecture and browser internals

- Browser lifecycle and navigation

- Chrome DevTools Protocol (CDP)

- Playwright, Puppeteer, Selenium, or similar browser automation frameworks

- Browser instrumentation and debugging

*Web Platform*

- HTTP/1.1, HTTP/2, HTTP/3 — TLS, DNS, and browser networking

- Cookies, browser storage, caching, redirects, and session management

- JavaScript execution and modern client-side rendering

- Resource loading, page lifecycle, and browser networking

- Browser fingerprinting concepts and browser characteristics

**Nice to Have**

- Experience working on browser engines or browser infrastructure

- Experience reverse engineering browser or web application behaviour

- Experience building internet-scale distributed systems

- Go, C++, Rust, or Python

- Kubernetes and cloud infrastructure

*We conduct coding interviews as part of the process.*

**Benefits & Perks:**

- Competitive compensation

- Career growth and learning opportunities

- Flexibility and ownership

- Collaborative and innovative culture

- Opportunity to work on impactful AI projects

- International environment and talented teams

**What's it like to work at Nebius:**

Fast moving - Bold thinking - Constant growth - Meaningful impact - Trust and real ownership - Opportunity to shape the future of AI

**Equal Opportunity Statement:**

Nebius is an equal opportunity employer. We are committed to fostering an inclusive and diverse workplace and to providing equal employment opportunities in all aspects of employment. We do not discriminate on the basis of race, color, religion, sex (including pregnancy), national origin, ancestry, age, disability, genetic information, marital status, veteran status, sexual orientation, gender identity or expression, or any other characteristic protected by applicable law.

Applicants must be authorized to work in the country in which they apply and will be required to provide proof of employment eligibility as a condition of hire.

If you need accommodations during the application process, please let us know.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
