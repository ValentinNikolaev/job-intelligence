# Senior Solutions Engineer, Germany

Posted: 2026-08-09T23:55:28Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Join the company that’s building the telemetry infrastructure for the AI era. At Cribl, we partner with IT and Security teams at many of the world’s biggest enterprises, including half of the Fortune 100, to bridge the gap between AI ambition and infrastructure reality. As the AI Platform for Telemetry, we give customers the choice, control, and flexibility to manage and analyze telemetry for both humans and agents, so they can build what’s next.

We’re one of the fastest‑growing private companies and a leading player in a massive, fast‑moving market. With a global workforce, we’re remote‑first and grounded in a simple idea: software is a people business. Cribl is the place where curious, collaborative people can do their best work, grow fast, and bring their full selves to the herd.

Location: Germany

**Why You'll Love This Role****
**

As a Solutions Engineer, you'll get to flex your technical chops and storytelling skills by helping customers uncover the full potential of Cribl in real-world environments. With the freedom of remote work and the excitement of solving unique data challenges, every day brings something new and impactful.

**As An Active Member Of Our Team, You Will…****
**

- Help customers understand the value of Cribl during the sales process

- Demo the product and answer customer questions during initial sales calls

- Support customers during proof of concept sessions

- Document interesting use cases in blog posts and product documentation

- Up to 30% Travel

- We are a remote-first company and work happens across many time-zones – you may be required to occasionally perform duties outside your standard working hours

**If You’ve Got It - We Want It****
**

- Experience with Logs, Metrics, IT Operations and Security

- Background in Sales Engineering, Professional Services, or Support

- Play with the product, be prepared to give us feedback

- You live in Germany (Note: While Cribl is a remote-first company, this role requires residency in Germany)

- Fluent English & German is required, both written and spoken.

- Experience working remotely

- **Bonus Points**
** -**Polish language proficiency is a plus

#LI-GV1
#LI-Remote

The salary for this role is dependent on country of employment and will be based on the individual candidate's job-related knowledge, skills, and experience.

In addition to base salary, for sales and some sales-adjacent roles, employees are eligible to earn incentive compensation (commission). For all other roles, employees are eligible to participate in the Cribl Corporate Bonus Program.

In addition to a competitive salary, Cribl offers a benefits package that may include retirement/pension support, paid holidays and paid time off, remote office setup support, equity, and other wellness and support programs. Benefits vary by country in accordance with local requirements and market practice.

Base Salary Range

€126.000—€157.000 EUR

**Bring Your Whole Self
**
Diversity drives innovation, enables better decisions to support our customers, and inspires change for the better. We’re building a culture where differences are valued and welcomed, and we work together to bring out the best in each other. All qualified applicants will receive consideration for employment without regard to race, color, religion, sex, sexual orientation, gender identity, national origin, or any other applicable legally protected characteristics in the location in which the candidate is applying.

Interested in joining the Cribl herd? Learn more about the smartest, funniest, most passionate goats you’ll ever meet at [cribl.io/about-us](https://cribl.io/about-us/).

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
