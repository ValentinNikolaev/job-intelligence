# Senior HPC Engineer, GPU Compute

Posted: 2026-08-09T23:55:33Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**About Nebius:**

Nebius is leading a new era in cloud infrastructure for the global AI economy. We are building a full-stack AI cloud platform that supports developers and enterprises from data and model training through to production deployment, without the cost and complexity of building large in-house AI/ML infrastructure.

Built by engineers, for engineers. From large-scale GPU orchestration to inference optimization, we own the hard problems across compute, storage, networking and applied AI.

Listed on Nasdaq (NBIS) and headquartered in Amsterdam, we have a global footprint with R&D hubs across Europe, the UK, North America and Israel. Our team of 1,500+ includes hundreds of engineers with deep expertise across hardware, software and AI R&D.

### **The role**

We’re looking for a Senior HPC Cluster Engineer to join our team and play a key role in the development of our cutting-edge hyperscaler platform. The GPU & InfiniBand team is responsible for enhancing and optimizing the core components of our Cloud platform, with a specific focus on GPU computing, InfiniBand networks, and the KVM/QEMU stack. You’ll work closely with hardware virtualization and device emulation technologies, ensuring high performance and security in multi-GPU, HPC environments. The role involves analyzing, troubleshooting, and improving infrastructure to support new hardware, fine-tuning system performance, and automating fault detection and resolution in a complex system.

**In this position, you will be responsible for:**

- **Tuning the performance** of GPU clusters and InfiniBand networks to ensure optimal operation in HPC and GPU-based environments. 

- **Analyzing and troubleshooting** the root cause of issues related to GPUs and InfiniBand networks, and proposing corrective actions. 

- **Integrating new hardware** into the existing infrastructure, including support for new GPU hardware through software stacks like Kubernetes, QEMU, and KVM. 

- **Enhancing automation systems **for proactive monitoring, detecting, and resolving issues in GPU and InfiniBand environments. 

- **Configuring and managing GPU devices** and InfiniBand fabrics, ensuring efficient and reliable operation.**
**

**We expect you to have:**

- 5+ years of professional experience in **system-level software development** (focused on performance optimization, low-level programming). 

- 3+ years of hands-on experience with **Linux systems** (administration, troubleshooting, and performance tuning). 

- **In-depth understanding** of server architecture, including PCIe devices, NICs, Linux OS/Kernel, and high-performance computing (HPC) systems. 

- Strong proficiency in one or more **performance-oriented programming languages** (C/C++, Go, Python).

**It would be a plus if you have:**

- Experience with **GPU end-to-end testing** in a **cluster environment** using InfiniBand networking. 

- Proven track record of analyzing and optimizing the performance of **HPC workloads** (e.g., simulations, data analysis, AI/ML workloads). 

- Familiarity with **RDMA, RoCE, and InfiniBand** protocols for high-performance communication. 

- Background in **Software-Defined Networking** (SDN) and experience with **HPC cluster networking**. 

- Understanding of **QEMU/KVM virtualization** and managing virtualized environments. 

- Experience with **deep learning frameworks** such as **PyTorch** and **TensorFlow**, and their integration with HPC systems. 

- Familiarity with **collective communication libraries** like **MPI** and **NCCL** for distributed computing.

*We conduct coding interviews as part of the process.*

*#LI-LH2*

**Benefits & Perks:**

- Competitive compensation

- Career growth and learning opportunities

- Flexibility and ownership

- Collaborative and innovative culture

- Opportunity to work on impactful AI projects

- International environment and talented teams

**What's it like to work at Nebius:**

Fast moving - Bold thinking - Constant growth - Meaningful impact - Trust and real ownership - Opportunity to shape the future of AI

**Equal Opportunity Statement:**

Nebius is an equal opportunity employer. We are committed to fostering an inclusive and diverse workplace and to providing equal employment opportunities in all aspects of employment. We do not discriminate on the basis of race, color, religion, sex (including pregnancy), national origin, ancestry, age, disability, genetic information, marital status, veteran status, sexual orientation, gender identity or expression, or any other characteristic protected by applicable law.

Applicants must be authorized to work in the country in which they apply and will be required to provide proof of employment eligibility as a condition of hire.

If you need accommodations during the application process, please let us know.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
