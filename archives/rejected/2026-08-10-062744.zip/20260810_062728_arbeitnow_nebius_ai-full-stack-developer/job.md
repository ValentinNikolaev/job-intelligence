# AI Full-Stack Developer

Posted: 2026-08-09T23:55:32Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**About Nebius:**

Nebius is leading a new era in cloud infrastructure for the global AI economy. We are building a full-stack AI cloud platform that supports developers and enterprises from data and model training through to production deployment, without the cost and complexity of building large in-house AI/ML infrastructure.

Built by engineers, for engineers. From large-scale GPU orchestration to inference optimization, we own the hard problems across compute, storage, networking and applied AI.

Listed on Nasdaq (NBIS) and headquartered in Amsterdam, we have a global footprint with R&D hubs across Europe, the UK, North America and Israel. Our team of 1,500+ includes hundreds of engineers with deep expertise across hardware, software and AI R&D.

**Summary:**

We are seeking an AI Full-Stack Developer to build and scale automation solutions across internal company processes using AI, LLMs, and agent-based systems. This role focuses on delivering practical automation solutions, integrating AI capabilities with internal tools, and orchestrating workflows across multiple systems, with a dynamic range of tasks that offer both quick wins and complex challenges.

**Responsibilities:**

- Build AI-driven automation solutions using LLMs, APIs, and agent frameworks.

- Develop systems to automate document processing, data extraction, and operational workflows.

- Design and implement multi-step automated workflows connecting AI models and internal services.

- Integrate automation solutions with internal systems such as HR, finance, legal, dashboards, and ticketing tools.

- Deliver and iterate practical automation solutions swiftly, from simple GPT/AI integrations to complex workflows.

- Train and support internal teams on newly built or optimized systems for strong adoption and self-sufficiency.

- Collaborate with Technical Team Lead, Product Manager, and IT teams on architecture and system integration.

- Communicate clearly with internal stakeholders and external partners or vendors.

**Required Skills:**

- 5+ years of experience working as a Full-Stack Developer

- Strong programming skills in Python, TypeScript, JavaScript, and React.

- Experience building backend services and API integrations.

- Practical experience with LLM APIs or AI-based services.

- Strong familiarity with AI developer ecosystems.

- Proven ability to use AI-assisted coding tools effectively.

- Ability to work independently and efficiently.

- Familiarity with workflow automation systems or distributed architectures.

**Preferred Qualifications:**

- Experience building AI agents or multi-step AI workflows.

- Experience with prompt engineering or LLM orchestration frameworks.

- Experience integrating with enterprise systems or internal business tools.

- Familiarity with event-driven architectures, queues, and task orchestration systems.

- Experience in teaching non-technical users how to utilize developed systems effectively.

**Benefits & Perks:**

- Competitive compensation

- Career growth and learning opportunities

- Flexibility and ownership

- Collaborative and innovative culture

- Opportunity to work on impactful AI projects

- International environment and talented teams

**What's it like to work at Nebius:**

Fast moving - Bold thinking - Constant growth - Meaningful impact - Trust and real ownership - Opportunity to shape the future of AI

**Equal Opportunity Statement:**

Nebius is an equal opportunity employer. We are committed to fostering an inclusive and diverse workplace and to providing equal employment opportunities in all aspects of employment. We do not discriminate on the basis of race, color, religion, sex (including pregnancy), national origin, ancestry, age, disability, genetic information, marital status, veteran status, sexual orientation, gender identity or expression, or any other characteristic protected by applicable law.

Applicants must be authorized to work in the country in which they apply and will be required to provide proof of employment eligibility as a condition of hire.

If you need accommodations during the application process, please let us know.

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
