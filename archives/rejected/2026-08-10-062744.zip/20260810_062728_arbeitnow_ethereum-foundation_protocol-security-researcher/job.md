# Protocol Security Researcher

Posted: 2026-08-09T23:40:08Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

## The Ethereum Foundation

The Ethereum Foundation (EF) is a global non-profit organization dedicated to supporting Ethereum. Our mission is to help Ethereum remain secure, decentralized, and resilient over the long term by supporting critical protocol work and the broader ecosystem.

## The role

The Protocol Security team helps prevent vulnerabilities from reaching Ethereum mainnet.

We work across the execution layer, consensus layer, networking, specifications, testing, and client implementations to identify security issues before they become production incidents. Our work combines deep protocol knowledge with security research, manual review, fuzzing, AI-assisted analysis, audits, and coordinated disclosure.

We're looking for engineers who already understand Ethereum deeply.

The strongest candidates are already active in Ethereum protocol development. Ideally you have deep experience with the execution layer, consensus layer, specifications, testing infrastructure, or other protocol-critical components.

## What you'll work on

Examples include:

-

AI-assisted security research and automated bug discovery.

-

Reviewing upcoming hardforks.

-

Finding vulnerabilities across Ethereum protocol implementations.

-

Building and improving fuzzers.

-

Improving the team's automation and security tooling.

-

Manual security review of Ethereum protocol changes.

-

Working closely with Protocol DevOps, Specifications, researchers, and protocol implementers.

-

Coordinating responsible disclosure.

-

Supporting external audits and audit competitions.

## What we're looking for

We're primarily looking for people with deep Ethereum protocol experience.

Ideal backgrounds include:

-

Deep familiarity with the execution layer or consensus layer.

-

Deep familiarity with EL or CL specifications.

-

Experience implementing or reviewing protocol changes.

-

Strong understanding of Ethereum networking, consensus, or execution internals.

Security experience should include one or more of:

-

AI-assisted security workflows.

-

Protocol security research.

-

Fuzzing.

-

Vulnerability research.

-

Manual application security review.

-

Building security tooling.

Languages commonly used include Go, Rust, Java, C#, Nim, and Python.

We're much less concerned with a specific number of years than with demonstrated technical depth.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
