# Senior Site Reliability Engineer (SRE)

Posted: 2026-08-09T23:55:34Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**About Nebius:**

Nebius is leading a new era in cloud infrastructure for the global AI economy. We are building a full-stack AI cloud platform that supports developers and enterprises from data and model training through to production deployment, without the cost and complexity of building large in-house AI/ML infrastructure.

Built by engineers, for engineers. From large-scale GPU orchestration to inference optimization, we own the hard problems across compute, storage, networking and applied AI.

Listed on Nasdaq (NBIS) and headquartered in Amsterdam, we have a global footprint with R&D hubs across Europe, the UK, North America and Israel. Our team of 1,500+ includes hundreds of engineers with deep expertise across hardware, software and AI R&D.

### The Role

**Y****our responsibilities will include:****
**

- Ensure fault-tolerance, scale, and uninterrupted operations for the service.

- Use cutting-edge cloud technology to solve a variety of infrastructure problems.

- Implement and improve CI/CD processes.

**We expect you to have:**

- Solid experience with programming languages (like Go, Python, or C++);

- Solid understanding of classic algorithms and data structures;

- Commercial experience with and deep understanding of Unix systems and network technology;

- Experience with systems for containerization and configuration management (Ansible, Salt, Terraform, Docker, K8s, Helm).

**It will be an added bonus if you have:**

- Desire to be involved in backend development;

- Experience designing, developing, and running high-load distributed systems;

- Commercial experience with a variety of cloud platforms.

*We conduct coding interviews as part of the process.*

**Benefits & Perks:**

- Competitive compensation

- Career growth and learning opportunities

- Flexibility and ownership

- Collaborative and innovative culture

- Opportunity to work on impactful AI projects

- International environment and talented teams

**What's it like to work at Nebius:**

Fast moving - Bold thinking - Constant growth - Meaningful impact - Trust and real ownership - Opportunity to shape the future of AI

**Equal Opportunity Statement:**

Nebius is an equal opportunity employer. We are committed to fostering an inclusive and diverse workplace and to providing equal employment opportunities in all aspects of employment. We do not discriminate on the basis of race, color, religion, sex (including pregnancy), national origin, ancestry, age, disability, genetic information, marital status, veteran status, sexual orientation, gender identity or expression, or any other characteristic protected by applicable law.

Applicants must be authorized to work in the country in which they apply and will be required to provide proof of employment eligibility as a condition of hire.

If you need accommodations during the application process, please let us know.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
