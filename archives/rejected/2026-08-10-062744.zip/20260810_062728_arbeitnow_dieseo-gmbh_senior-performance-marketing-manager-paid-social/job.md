# (Senior) Performance Marketing Manager – Paid Social / Meta Ads (m/w/d)

Posted: 2026-08-10T02:09:34Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**Stellenbeschreibung**

Du skalierst nicht einfach Kampagnen – du skalierst Unternehmen.

Du denkst in ROAS, MER, Contribution Margin und Profitabilität. Du weißt, dass nachhaltiges Wachstum nicht durch einzelne Gewinner-Creatives entsteht, sondern durch systematisches Testing, Daten und schnelle Entscheidungen.

Genau dafür suchen wir dich.

Pammys gehört zu den am schnellsten wachsenden E-Commerce-Unternehmen Europas. Innerhalb von vier Jahren haben wir über **1 Million Kundinnen und Kunden** aufgebaut und wurden von der **Financial Times & Statista** ausgezeichnet.

Heute arbeiten über **150 Mitarbeitende** an unseren Standorten in Hamburg, Kiel und unserem eigenen Logistikzentrum in Lensahn daran, aus Pammys eine globale Footwear Brand zu machen.

Unser nächstes Ziel ist klar:
Wir wollen international skalieren und unsere Performance-Marketing-Strukturen auf das nächste Level bringen.

Dafür suchen wir einen **Senior Performance Marketing Manager – Paid Social / Meta Ads (m/w/d)**, der Verantwortung übernimmt, große Budgets steuert und Performance messbar verbessert.

**Deine Aufgaben**

- Du verantwortest unsere Meta-Advertising-Strategie und steuerst siebenstellige Monatsbudgets.
- Du entwickelst skalierbare Kampagnen zur profitablen Neukundengewinnung.
- Du analysierst Performance-Daten und leitest daraus konkrete Optimierungsmaßnahmen ab.
- Du steuerst Creative-Testing entlang einer klaren Testing-Roadmap und entwickelst neue Skalierungsansätze.
- Du arbeitest eng mit Creative Strategy, UGC, Design, Data Analytics und dem Marketing-Team zusammen.
- Du entwickelst bestehende Kampagnen-, Tracking- und Reporting-Strukturen kontinuierlich weiter.
- Du identifizierst neue Wachstumspotenziale und setzt diese eigenverantwortlich um.
- Du unterstützt den Ausbau unserer internationalen Paid-Social-Aktivitäten.

**Dein Profil**

- Mindestens **5 Jahre Erfahrung** im Performance Marketing mit Schwerpunkt Meta Ads.
- Nachweisbare Erfolge beim Management großer Werbebudgets (idealerweise siebenstellig pro Monat).
- Erfahrung im DTC-, E-Commerce- oder schnell wachsenden Consumer-Umfeld.
- Sehr gutes Verständnis von Attribution, Tracking, Conversion-Optimierung und datengetriebenem Marketing.
- Sicherer Umgang mit KPIs wie ROAS, CPA, MER, CAC, LTV und Contribution Margin.
- Erfahrung im strukturierten Creative Testing und der Skalierung erfolgreicher Werbekampagnen.
- Hohe Eigenverantwortung, analytisches Denken und eine ausgeprägte Hands-on-Mentalität.
- Sehr gute Deutsch- oder Englischkenntnisse.

**Deine Vorteile bei Pammys**

Arbeite mit echtem Impact.

Du verantwortest Budgets in Millionenhöhe und beeinflusst direkt das Wachstum eines der erfolgreichsten E-Commerce-Unternehmen Europas.

Wachstum statt Stillstand.

Mit unserem starken Unternehmenswachstum entstehen kontinuierlich neue Entwicklungsmöglichkeiten – fachlich und perspektivisch auch in Richtung Team Lead oder Head of.

Schnelle Entscheidungen.

Keine langen Abstimmungsschleifen. Gute Ideen werden getestet und umgesetzt.

Office First.

Wir glauben an Zusammenarbeit vor Ort. Deshalb arbeiten wir überwiegend gemeinsam in unserem modernen Office in Hamburg.

Lerne von starken Teams.

Marketing, Data, Creative, Brand und Product arbeiten eng zusammen und verfolgen ein gemeinsames Ziel: nachhaltiges Wachstum.

Weitere Benefits

- Attraktive Vergütung
- Corporate Benefits
- Zuschuss zum Deutschlandticket
- Regelmäßige Teamevents
- Kostenlose Getränke & Snacks
- Mitarbeiterrabatte
- Moderne Arbeitsausstattung
- Individuelle Weiterbildungsmöglichkeiten

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
