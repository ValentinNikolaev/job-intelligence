# Praktikant:in Marketing & Patient Experience (m/w/d)

Posted: 2026-08-10T02:20:20Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Als Praktikant:in im Bereich** Marketing & Patient Experience (m/w/d)** unterstützt du unser Marketing Team dabei, **Cara Care **sichtbar zu machen, relevante Zielgruppen zu erreichen und unsere Kommunikation mit Patient:innen weiterzuentwickeln.

Du arbeitest an der Schnittstelle zwischen** Marketing, Product und unserem Care Team** und erhältst spannende Einblicke darin, wie wir unsere Patient:innen verstehen, ihre **Bedürfnisse analysieren und unsere Marketingmaßnahmen kontinuierlich verbessern.**

Dabei kombinierst du** Kreativität mit analytischem Denken**: Du unterstützt bei Kampagnen, erstellst patientenorientierte Inhalte, analysierst Feedback und Nutzerverhalten und leitest daraus wertvolle Insights für unsere Kommunikation und die Patient:innen Experience ab.

Die Rolle ist bewusst sehr **praxisnah** gestaltet: Du übernimmst eigene Aufgaben, bringst deine Ideen ein und unterstützt unser Team dort, wo deine Arbeit einen echten Mehrwert schafft.

**🎯 Was du bei uns machen wirst:**

**Marketing & Patient Engagement**

- Unterstützung bei der Planung und Umsetzung von Marketing- und Growth-Initiativen
- Erstellung und Weiterentwicklung von patientenorientierten Kommunikationsmaterialien und Content
- Du unterstützt bei Kampagnen, Marketingprojekten und verschiedenen Initiativen zur Steigerung des Patient:innen Engagements
- Analyse von Nutzer- und Patient:innen Feedback zur Identifikation von Verbesserungspotenzialen
- Entwicklung eines besseren Verständnisses für Patient:innen Bedürfnisse, Verhalten und Customer Journeys

**Commercial & Analytics**

- Unterstützung bei Commercial- und Business-Development-Projekten
- Durchführung von Analysen zu Patient:innen Bedürfnissen, Markttrends und Nutzerverhalten
- Aufbereitung von Erkenntnissen in Präsentationen, Reports und internen Dokumentationen

**Requirements**

**🤓 Was du mitbringen solltest:**

- Du suchst ein Pflicht- oder freiwilliges Praktikum für** 3–6 Monate**
- Du bist aktuell in einem Studium eingeschrieben, idealerweise in **Marketing, Psychologie, Kommunikationswissenschaften, oder einem vergleichbaren Studiengang**
- Du verfügst über **Deutschkenntnisse auf muttersprachlichem Niveau und sehr gute Englischkenntnisse **in Wort und Schrift
- Du wohnst in** Berlin **oder Umgebung und kannst regelmäßig aus unserem Berliner Office arbeiten
- Du möchtest **Prozesse im Bereich Marketing neu gestalten**, sie verbessern und in die Umsetzung zu bringen
- Du hast Spaß daran, **Zielgruppen zu verstehen und Inhalte sowie Kommunikation an deren Bedürfnisse anzupassen**
- Du arbeitest **strukturiert, eigenständig und lösungsorientiert**
- Du übernimmst gerne **Verantwortung** und bringst eigene Ideen aktiv ein
- Du fühlst dich sowohl bei **analytischen Aufgaben als auch bei kreativen Marketing-Themen wohl**

**Nice-to-Haves:**

- Erste praktische Erfahrungen im **Bereich Marketing, Content, Social Media, Research oder Customer Experience**
- Erfahrung mit **Analysen, Präsentationen oder der Erstellung von Kommunikationsmaterialien**
- Interesse an** Gesundheit, Technologie oder digitalen Produkten**
- Erste Erfahrungen mit Tools wie **Canva, Adobe, Figma, HubSpot** sind ein Plus

**Hinweis für Psychologie-Studierende:**
Auch Studierende der Psychologie können ihr Pflichtpraktikum bei Cara Care absolvieren und dabei wertvolle Einblicke in den Bereich Digital Health gewinnen. Du lernst, wie psychologische Erkenntnisse genutzt werden können, um Patient:innen besser zu erreichen, zu unterstützen und langfristig zu begleiten.

**🚀 Warum diese Rolle?**

Du bekommst Einblicke in verschiedene Bereiche wie** Marketing, Product, dem Care Team** und arbeitest eng mit erfahrenen Kolleg:innen aus unterschiedlichen Teams zusammen.

Dabei übernimmst du nicht nur unterstützende Aufgaben, sondern kannst **eigene Ideen einbringen, Verantwortung übernehmen** und aktiv dazu beitragen, unsere Kommunikation und Patient:innen Experience weiterzuentwickeln.

Wenn du eine **abwechslungsreiche Marketingrolle** suchst, in der du Kreativität mit analytischem Denken verbinden und an einem sinnstiftenden Produkt arbeiten kannst, freuen wir uns darauf, dich kennenzulernen.

**Benefits**

- **💸 Faire Bezahlung**
Du bekommst bei uns eine faire Vergütung, regelmäßige Gehaltschecks und natürlich die Technik, die du brauchst, um richtig gut arbeiten zu können.
- **🫶 Tolles Team**
Dich erwartet ein lebendiges, interdisziplinäres Team sowie eine freundliche und unterstützende Arbeitsatmosphäre - inklusive regelmäßiger Team-Events vor Ort.
- **👨‍💻 Remote-first**
Du willst von zu Hause arbeiten? Kein Problem. Du willst ins Büro in Berlin? Auch super. Wir sind remote-first – du arbeitest da, wo es für dich am besten passt.
- **🏝️ 30 Tage frei**
Erholung ist wichtig. Bei uns bekommst du 30 freie Tage im Jahr: 26 Urlaubstage und 4 extra Mental Health Days für deine Pause zwischendurch.
- **🦉 Flexible Arbeitszeiten**
Egal ob du morgens direkt loslegen willst oder lieber später startest – du gestaltest deinen Tag so, wie es zu dir passt.
- **🚀 Du machst den Unterschied**
Bei uns bist du nicht nur dabei, sondern mittendrin. Deine Ideen zählen und du kannst wirklich etwas bewegen.

**Über Cara Care**

Cara Care ist ein digitales Gesundheitsunternehmen mit der Mission, ganzheitliche, wissenschaftlich fundierte Unterstützung für Menschen mit Magen-Darm-Beschwerden anzubieten. Über unsere Apps können Betroffene Symptomauslöser identifizieren, personalisierte Empfehlungen erhalten und auf digitale Therapieprogramme zugreifen für:

- Reizdarmsyndrom (Cara Care für Reizdarm)
- Sodbrennen (Cara Care für Reflux und Reizmagen)

Unser Reizdarm-Programm ist offiziell vom Bundesinstitut für Arzneimittel und Medizinprodukte (BfArM) als erstattungsfähige digitale Gesundheitsanwendung (DiGA) zugelassen.

**Unterstützt von Bayer**

Wir freuen uns, dass Cara Care kürzlich Teil der Bayer-Gruppe geworden ist. Dieser Schritt stärkt unsere Mission und ermöglicht es uns, unseren Impact noch weiter auszubauen. Mit Bayers globaler Expertise im Gesundheitswesen und unserem innovativen digitalen Ansatz sind wir bereit, die Versorgung im Bereich Verdauungsgesundheit neu zu definieren.

**Arbeiten bei uns**

Bei Cara Care arbeitest du mit einem Team aus Ärzt:innen, Forschenden, Entwickler:innen, Produkt- und People-Expert:innen, die leidenschaftlich daran arbeiten, das Leben der Menschen zu verbessern. Wir lassen uns von unseren Patient:innen inspirieren und werden vom realen Impact angetrieben. Wir arbeiten schnell, eng zusammen und verlieren dabei nie die Bedeutung von Wohlbefinden – sowohl für unsere Nutzer:innen als auch für uns selbst.

**Vielfalt ist uns wichtig**

Wir glauben, dass diverse Teams bessere Produkte entwickeln. Deshalb setzen wir uns dafür ein, ein inklusives Umfeld für alle zu schaffen – unabhängig von Rasse, Religion, Hautfarbe, nationaler Herkunft, Geschlecht, sexueller Orientierung, Geschlechtsidentität, Alter oder Behinderung.

Wir wissen, dass die Bewerbung für einen neuen Job ein großer Schritt ist, und wir schätzen deine Zeit und Mühe sehr. Wir freuen uns darauf, dich kennenzulernen!

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
