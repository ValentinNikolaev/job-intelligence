# Chief of Staff (m/f/d)

Posted: 2026-08-09T23:09:07Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**The Mission**

OroraTech is a global intelligence-as-a-service company leveraging thermal data from space. As we continue to grow, expand our activities, and develop our organization, the effective execution of our most important company priorities becomes increasingly critical.

We are looking for a highly structured and proactive Chief of Staff to work closely with our CEO and support the execution of selected strategic and cross-functional initiatives.

You will help translate company priorities into clear projects, responsibilities, and next steps. You will independently own assigned projects end-to-end, prepare strategic decisions, and coordinate initiatives involving different functions and senior stakeholders. You will act as a trusted thought partner to the CEO while working closely with the Executive Team and leaders across OroraTech. You will report directly to the CEO.

**What you’ll be doing**

This is the first Chief of Staff role at OroraTech. The areas below are where we expect you to start. Which of them matter most, and what else belongs in the role, is something you and the CEO will shape together over your first months.

**Launching Strategic Projects & Company Priorities**

- Own selected company-level initiatives from initial scoping through to a delivered result.
- Turn broad priorities into a plan with clear owners, milestones, and a defined outcome, then bring the right people from across the company together to deliver it.
- Do the thinking yourself where it matters: structure the problem, run the analysis, and form a view.
- Spot the risks and dependencies others are not tracking, and come to the CEO with a recommendation rather than an open question.
- Stay with an initiative after the decision is made, through the part where momentum sometimes fades.
- Establish clear follow-up mechanisms and ensure that agreed actions and decisions are implemented.

**Mission control: Strategy and operating cadence**

- Support the company’s strategic planning cycle and coordinate the OKR process end to end.
- Prepare and facilitate Executive meetings, leadership reviews, and strategy sessions: agenda, pre-reads, and decisions recorded with an owner.
- Maintain a clear view of what the company has committed to and where each commitment stands.

**Executive communication and external stakeholders**

- Prepare board materials, investor updates, and decision papers for the CEO and Executive Team, drawing input from relevant stakeholders.
- Prepare with the CEO ahead of board meetings, partnership discussions, and external engagements, and make sure the follow-ups are picked up.
- Support investor relations and board processes as they arise.
- Contribute to selected initiatives in governmental and regulated markets, working with the internal experts who own the content.

**CEO & Executive Team Support**

- Prepare briefings, analyses, and recommendations for important meetings and decisions.
- Act as an interface between the CEO, Executive Team, and key internal stakeholders.
- Help ensure that the CEO’s involvement is focused on the topics where it creates the greatest value.
- Take ownership of urgent and important special projects that do not clearly sit within one function.
- Build trusted relationships across the organization and influence progress without relying on formal authority.

**Relevant Skills**

**Required**

- Experience in strategy, business operations, management consulting, corporate development, venture capital, a founder’s office, or a comparable role.
- Strong experience independently managing complex projects involving multiple functions and senior stakeholders.
- Strong business judgment and a good understanding of how strategy translates into operational execution.
- Excellent project management, stakeholder management, and organizational skills.
- Strong analytical and presentation skills, including the ability to create concise decision and management materials.
- Confidence working with executives while remaining pragmatic, hands-on, and execution-oriented.
- Ability to build trust and influence across the organization without formal authority.
- High level of discretion, reliability, and personal ownership.
- Excellent communication skills in English.

**Preferred**

- Experience in a fast-growing technology company, scale-up, or similarly dynamic environment.
- Experience supporting fundraising, investor relations, or board-related processes.
- Experience establishing or coordinating strategy, OKR, governance, or operating-cadence processes.
- Exposure to space, aerospace, defence, government technology, climate technology, or other complex technical industries.

**Our Benefits**

At OroraTech, you can expect a down-to-earth, yet high-caliber work environment. You will become an integral part of the OroraTech satellite development - a talented, international, open-minded team that is highly motivated to create impact. OroraTech gives you the opportunity to grow on a professional and personal level. Be part of the solution to climate change.
Our Benefits include:

- A responsible position with individual autonomy and design freedom
- Company pension scheme (bAV = Betriebliche Altersversorgung)
- Company accident insurance (supplementary insurance for accidents during work and leisure time around the world 24/7)
- Company international travel health insurance (supplementary insurance covering worldwide travel for business or leisure)
- Flexible working hours and home office option (including working from other countries within the EU)
- Corporate health benefit via discounted EGYM Wellpass subscription
- Corporate mental health benefit via nilo
- Corporate mobility benefit via supplementary payment for the DB Deutschland Ticket
- Corporate lunch benefit via hrmony
- Corporate bike leasing program via JobRad
- Modern office at Neue Balan with a wonderful pool and campus area

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
