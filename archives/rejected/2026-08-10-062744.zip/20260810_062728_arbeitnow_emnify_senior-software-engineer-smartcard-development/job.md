# Senior Software Engineer (SmartCard Development)

Posted: 2026-08-10T02:55:06Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

1

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
