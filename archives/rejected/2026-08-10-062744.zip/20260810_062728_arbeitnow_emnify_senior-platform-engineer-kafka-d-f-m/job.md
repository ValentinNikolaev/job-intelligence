# Senior Platform Engineer - Kafka (d/f/m)

Posted: 2026-08-10T02:55:06Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

#### The team and your Role:

As a part of the larger Engineering department, the Platform team plays a crucial role in enhancing emnify’s competitive edge by improving developer experience to increase development efficiency and scale productivity. You will join a growing team, fostering empathy and a collaboration mindset to ensure continuous improvement of development experience at emnify. The Platform team provides, in addition to the centrally managed infrastructure used by all the teams for observability and CI/CD, consultation and hands-on support to the engineering teams. As a platform engineer with Kafka expertise, you’ll take ownership of the Kafka clusters and their supporting infrastructure. You’ll support the team with the maintenance of our managed infrastructure

[Emnify technology radar](https://emnify.github.io/tech-radar/)

The position is a hybrid position based in emnify’s office in Berlin.

#### Your Impact:

-

You’ll take part in designing, building, and maintaining the company’s multi-region, highly available, and performant Kafka infrastructure. Further, improve the developer experience of cross-functional teams to integrate their services using an event-driven architecture.

-

You’ll manage and maintain the underlying infrastructure for our Kafka clusters.

-

As part of the Platform team, you’ll continuously improve our CI/CD systems and concepts, enabling product teams to safely and efficiently deploy their applications on AWS-managed services and Kubernetes.

-

You’ll collaborate with the product teams and take an active part in implementing new infrastructure and services, providing valuable insights and implementation recommendations to ensure the successful and timely delivery of the projects.

#### Your Skills:

- Strong hands-on experience with managed and self-hosted Kafka services (streams, broker, connect). With priority to Strimzi operator and AWS MSK.

-

Good experience with managing Kubernetes clusters (EKS) with emphasis on performance and cost optimization.

-

Strong understanding of event-driven architecture.

-

Solid experience with CI/CD tools and pipelines (Jenkins, GitHub Actions, Argo suite).

-

Expertise in monitoring, alerting, observability (metrics, logs, traces), and performance tuning.

Why emnify?

emnify is a global **IoT connectivity platform provider**, enabling enterprises and OEMs to build, deploy, and operate connected products at scale across 180+ countries. Our cloud-native SuperNetwork powers mission-critical use cases in industries such as mobility, logistics, energy, and industrial IoT.
We are a **Series-B scale-up** with a strong growth trajectory and a clear focus on upmarket and enterprise customers. emnify’s technology and innovation have been recognized repeatedly by the industry, including:

- **eSIM Provider of the Year** at the *MVNOs World Awards 2025*

- **Platinum Award** for *eSIM Management Platform Innovation* by *Juniper Research (2025)*

- **IoT Innovator Award** by *Compass Intelligence* for aviation connectivity

- **Deloitte Technology Fast 50 Germany**, recognizing emnify as one of the country’s fastest-growing tech companies

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
