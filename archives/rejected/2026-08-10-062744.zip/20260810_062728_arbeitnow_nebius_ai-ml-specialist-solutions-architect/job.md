# AI/ML Specialist Solutions Architect

Posted: 2026-08-09T23:55:32Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**About Nebius:**

Nebius is leading a new era in cloud infrastructure for the global AI economy. We are building a full-stack AI cloud platform that supports developers and enterprises from data and model training through to production deployment, without the cost and complexity of building large in-house AI/ML infrastructure.

Built by engineers, for engineers. From large-scale GPU orchestration to inference optimization, we own the hard problems across compute, storage, networking and applied AI.

Listed on Nasdaq (NBIS) and headquartered in Amsterdam, we have a global footprint with R&D hubs across Europe, the UK, North America and Israel. Our team of 1,500+ includes hundreds of engineers with deep expertise across hardware, software and AI R&D.

### **The role**

We seek an experienced Specialist Solutions Architect to support AI-focused customers leveraging Nebius services. In this role, you will be a trusted advisor, collaborating with clients to design scalable AI solutions, resolve technical challenges and manage large-scale AI deployments involving hundreds to thousands of GPUs.

You’re welcome to work on-site in Amsterdam or remotely from any other EU country.

**Your responsibilities will include:**

- Designing customer-centric solutions that maximize business value and align with strategic goals.

- Building and maintaining long-term relationships to foster trust and ensure customer satisfaction.

- Delivering technical presentations, producing whitepapers, creating manuals and hosting webinars for audiences with varying technical expertise.

- Collaborating with engineering and product teams to effectively prioritize and relay customer feedback.

**We expect you to have:**

- 3+ years of experience with cloud technologies in MLOps engineering, Machine Learning engineering or similar roles.

- Strong understanding of ML ecosystems, including models, use cases and tooling.

- Proven experience in setting up and optimizing distributed training pipelines across multi-node and multi-GPU environments.

- Hands-on knowledge of frameworks like PyTorch or JAX.

- Excellent verbal and written communication skills.

**It will be an added bonus if you have:**

- Expertise in deploying inference infrastructure for production workloads.

- Ability to transition ML pipelines from POC to scalable production systems.

**Preferred tooling:**

- Programming Languages – Python, Go, Java, C++

- Orchestration – Kubernetes (K8s), Slurm

- DevOps Tools – Git, Docker, Helm

- Infrastructure as Code (IaC) – Terraform

- ML Frameworks and Libraries – PyTorch, TensorFlow, JAX, HuggingFace, Scikit-learn

**Benefits & Perks:**

- Competitive compensation

- Career growth and learning opportunities

- Flexibility and ownership

- Collaborative and innovative culture

- Opportunity to work on impactful AI projects

- International environment and talented teams

**What's it like to work at Nebius:**

Fast moving - Bold thinking - Constant growth - Meaningful impact - Trust and real ownership - Opportunity to shape the future of AI

**Equal Opportunity Statement:**

Nebius is an equal opportunity employer. We are committed to fostering an inclusive and diverse workplace and to providing equal employment opportunities in all aspects of employment. We do not discriminate on the basis of race, color, religion, sex (including pregnancy), national origin, ancestry, age, disability, genetic information, marital status, veteran status, sexual orientation, gender identity or expression, or any other characteristic protected by applicable law.

Applicants must be authorized to work in the country in which they apply and will be required to provide proof of employment eligibility as a condition of hire.

If you need accommodations during the application process, please let us know.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
