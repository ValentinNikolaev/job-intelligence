# Senior Software Engineer (Managed PostgreSQL)

Posted: 2026-08-09T23:55:34Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**About Nebius:**

Nebius is leading a new era in cloud infrastructure for the global AI economy. We are building a full-stack AI cloud platform that supports developers and enterprises from data and model training through to production deployment, without the cost and complexity of building large in-house AI/ML infrastructure.

Built by engineers, for engineers. From large-scale GPU orchestration to inference optimization, we own the hard problems across compute, storage, networking and applied AI.

Listed on Nasdaq (NBIS) and headquartered in Amsterdam, we have a global footprint with R&D hubs across Europe, the UK, North America and Israel. Our team of 1,500+ includes hundreds of engineers with deep expertise across hardware, software and AI R&D.

### **The role**

We're looking for a Senior Software Engineer to help us build the best Managed PostgreSQL for AI workloads. The service is already in production; the mission now is to make it the obvious choice for teams running AI applications on Postgres — first-class vector search, painless migrations from RDS / Cloud SQL / self-managed clusters, and the operational quality of a mature managed database.

You'll work across the stack: control plane and lifecycle automation in Go, Postgres internals and performance, migration tooling, and the customer escalations where it actually matters.

You're welcome to work from our offices in Amsterdam or London, hybrid or remotely from EU timezones.

**Your responsibilities:**

- Develop the control plane and lifecycle automation for Managed PostgreSQL — provisioning, HA, failover, backups, PITR, version upgrades, zero-downtime maintenance.

- Tune and harden PostgreSQL itself — replication, WAL, vacuum, query planner, connection pooling, extensions — and turn that into product features and sane defaults customers don't have to think about.

- Build migration tooling that gets customers off AWS RDS, Google Cloud SQL, Azure Database for PostgreSQL, and self-managed clusters with minimal downtime.

- Drive the AI-Postgres story end to end — vector search (pgvector, pgvectorscale), hybrid retrieval, integration with the wider Nebius AI Cloud stack.

- Run the service like an SRE — define SLOs, build observability, lead incident response, feed every postmortem back into the platform.

- Work directly with customers on architecture reviews, performance escalations, and the production problems that don't fit a ticket template.

**Must-haves:**

- 5+ years of professional software engineering experience, with significant time spent building or operating production PostgreSQL at scale (TB+ datasets, replication topologies, real failure modes you've debugged in production).

- Strong software engineering skills in Go or another backend/systems language, with a willingness to work primarily in Go.

- Deep knowledge of PostgreSQL internals: MVCC, WAL, replication (physical and logical), vacuum, query planning, extensions, partitioning.

- Hands-on experience with the surrounding ecosystem: Patroni / Stolon / pg_auto_failover, pgBackRest / WAL-G, pgBouncer / PgCat, logical replication tooling.

- The instincts of an ex-DBA — you can read EXPLAIN ANALYZE fluently, reason about lock behaviour, and know how to handle database corruptions.

- Ability to write reliable code and dig into complex problems.

- Teamwork-oriented approach.

**Nice-to-haves:**

- Experience with pgvector and pgvectorscale — vector search at scale, index choice, recall vs. latency trade-offs.

- Background building managed-database control planes at a cloud provider (RDS, Cloud SQL, Aiven, Crunchy, Timescale, Supabase, Neon, or similar).

- Experience writing Kubernetes operators (Go + controller-runtime / kubebuilder).

- Contributions to PostgreSQL itself, popular extensions, or the surrounding OSS ecosystem.

- AI/ML workload experience — RAG pipelines, embedding stores, GPU-resident workloads.

*We conduct coding interviews as part of the process.*

**Benefits & Perks:**

- Competitive compensation

- Career growth and learning opportunities

- Flexibility and ownership

- Collaborative and innovative culture

- Opportunity to work on impactful AI projects

- International environment and talented teams

**What's it like to work at Nebius:**

Fast moving - Bold thinking - Constant growth - Meaningful impact - Trust and real ownership - Opportunity to shape the future of AI

**Equal Opportunity Statement:**

Nebius is an equal opportunity employer. We are committed to fostering an inclusive and diverse workplace and to providing equal employment opportunities in all aspects of employment. We do not discriminate on the basis of race, color, religion, sex (including pregnancy), national origin, ancestry, age, disability, genetic information, marital status, veteran status, sexual orientation, gender identity or expression, or any other characteristic protected by applicable law.

Applicants must be authorized to work in the country in which they apply and will be required to provide proof of employment eligibility as a condition of hire.

If you need accommodations during the application process, please let us know.

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
