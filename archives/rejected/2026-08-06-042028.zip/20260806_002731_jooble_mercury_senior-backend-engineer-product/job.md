# Senior Backend Engineer - Product

Posted: 2026-08-03T00:00:00.0000000

## Rejection

- Category: tech_stack
- Reason: role does not mention Go/Golang or PHP

...Francisco, CA, New York, NY, Portland, OR, or **Remote **within Canada or United States
Since... ...embodies the elegance of simplicity in **engineering,** transforming the demanding task of... ...group is growing and we’re looking to hire **senior backend **engineers . We’re a team of pragmatic,...
