# Senior Backend Software Engineer - Core Domain

Posted: 2026-05-06T07:35:01.695+00:00

## Rejection

- Category: stale
- Reason: published_at 2026-05-06T07:35:01.695+00:00 is older than 7 days

About us

Traditional banking has never really given you control over your financial life. Satispay exists to change that: to empower people through finance. 

That means making financial services easy and accessible for over 6.5M users. We started with payments, then benefits, investing, cards... and we’re not done. Not even close. 

We follow the same logic every time: find a real problem, solve it properly, then look for the next one. The destination? To build the most loved financial platform in the world. 

If you own outcomes rather than tasks, stay close to what users need, and refuse to wait for someone else to fix what's broken — you'll find people here who work exactly in the same way. And together, you'll build something worth being proud of.



What you'll be doing

As our Senior Backend Software Engineer, you'll own the engineering backbone of our payment platform, ensuring high-performing and scalable core systems. 

Here's what that looks like in practice:

 - Engineer core platform domains - Design and evolve our most sensitive systems—such as the Transaction Ledger, Identity & Access Management (IAM), or Payment Orchestration—ensuring they remain functional for product teams.

 - Scale risk & financial engines - Optimize and implement services dedicated to bank integrations, credit risk, and real-time fraud detection to protect our "source of truth."

 - Cross-team technical leadership - Drive technical analysis for projects that span across multiple services and produce high-quality documentation (Smart Papers) for stakeholders.

 - Foster engineering excellence - Ensure technical quality through rigorous testing strategies and safe rollouts, promoting a culture of simplicity and maintainability.

 - Mentor & develop - Provide technical guidance to junior and mid-level engineers, helping the team adopt the best tools to accelerate development cycles.



Who we're looking for

This role needs someone who is a problem-solver, loves teamwork, and gets things done with a high degree of curiosity and readiness for real ownership.

 - Extensive experience - At least 5 years of related experience in back-end software engineering, with a track record in microservices and cloud environments (AWS preferred).

 - Technical depth - Deep experience with Java and Spring Boot, alongside a strong understanding of distributed systems.

 - Structured communication - Ability to communicate complex technical concepts clearly and coordinate implementations across different teams.

 - Impact mindset - Focus on delivering software that meets evolving user needs, avoiding analysis paralysis to optimize systems beyond initial requirements.

 - Passion & language proficiency - Passionate about FinTech and fluent in English.

Don't worry if you don't tick every box. We believe in the power of different viewpoints and strengths. Your unique perspective is important as we build something special: if you're passionate and can make a difference, we truly encourage you to apply.



CareAbout: how we support your impact

We move fast, and evolution never stops. It’s a fun ride, but it can be challenging. To make sure our people truly thrive, we’re committed to making their lives easier, both in the office and out in the world. That’s why we created CareAbout:

 - ❤️ Health: private insurance for you and your family, psychological support with Serenis, mental health workshops.

 - 💰 Financial resources: Stock Option Plan, meal vouchers, relocation support if you’re moving countries.

 - ⚙️ Growth and development: professional development programs, internal mobility, language courses with Preply.

 - 🌱 Flexibility: unlimited PTO, hybrid working policy*, flexible working hours.

 - 👨‍👩‍👧 Family: enhanced parental leave, additional leave for child sickness.

*We embrace three days per week in-office (Tuesday and Thursday + 1 of your choice), with the option to request extra remote time.



Salary: €51,000 - €66,500 gross per annum
This range is set using objective, gender-neutral criteria for the role's core requirements. However, we do not believe in putting a ceiling on talent. The final compensation package is tailored according to your unique experience and expertise. If your skills go beyond the standard profile, apply anyway so we can discuss a package that reflects your true value.

 

Equal opportunity employer

At Satispay, we're proud to be an equal opportunity employer. We celebrate diversity and inclusion, welcoming individuals of all backgrounds. This opportunity is open to everyone, regardless - for instance - of race, colour, religion, sex, gender identity, sexual orientation, and national origin. 
Join us in a workplace where everyone belongs!



Learn more about us

Curious what it's actually like here? Our values and pillars shape how we work every day: explore them here https://www.satispay.com/en-it/work-at-satispay/.

 





#LI-VR1

#LI-Hybrid







By submitting this application, I acknowledge that I have read and understood the content of the Privacy Policy https://www.satispay.com/en-it/legal-hub/privacy-policy/candidates/
