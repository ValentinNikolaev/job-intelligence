# Software Engineer III, Backend - Consumer Payment & Services Domain

Posted: 2026-06-16T08:03:41.109+00:00

## Rejection

- Category: stale
- Reason: published_at 2026-06-16T08:03:41.109+00:00 is older than 7 days

About us

Traditional banking has never really given you control over your financial life. Satispay exists to change that: to empower people through finance. 

That means making financial services easy and accessible for over 6.5M users. We started with payments, then benefits, investing, cards... and we’re not done. Not even close. 

We follow the same logic every time: find a real problem, solve it properly, then look for the next one. The destination? To build the most loved financial platform in the world. 

If you own outcomes rather than tasks, stay close to what users need, and refuse to wait for someone else to fix what's broken — you'll find people here who work exactly in the same way. And together, you'll build something worth being proud of.



What you'll be doing

As our Software Engineer III, Backend in the Consumer Payment & Services Domain, you'll play a key role in building and scaling the services that our users interact with daily, driving app engagement and simplifying money management for millions. 

Here's what that looks like in practice:

 - Own the End-to-End Lifecycle - Design, build, test, and operate mission-critical consumer features—from technical design to production—using Java, Spring Boot, and PostgreSQL.

 - Build & Scale High-Impact Features - Develop and maintain core user functionalities such as BNPL ("Pay in 3"), Gift Cards, Mobile Top-ups, and Personal IBAN transfers.

 - Enhance Payments Mechanics - Improve the backend logic and reliability of budget mechanisms and scheduled top-ups, ensuring payment mechanics are clear and scalable.

 - Master a Modern Tech Stack - Take ownership of our AWS-based infrastructure (EC2/ECS, S3, Lambda, Kinesis) and drive architectural improvements across microservices.

 - Work in an AI-Powered Environment - Leverage AI tools daily to write and optimize code, speed up root cause analysis, and generate documentation to raise engineering efficiency.

 - Solve Complex & Ambiguous Problems - Turn vague user needs into scalable technical solutions, balancing delivery speed with technical quality and maintainability.

 - Collaborate & Lead Quality - Work cross-functionally with Product and UX/UI teams while contributing to code reviews and refactoring initiatives to promote best practices.

 - Drive System Reliability - Debug complex issues across services and investigate production incidents to continuously improve system health.



Who we're looking for

This role needs someone who is a problem-solver, loves teamwork, and gets things done with a high degree of curiosity and readiness for real ownership.

 - Experience - At least 3 years of experience as a Backend Engineer in fast-paced environments, with a strong track record of building and maintaining scalable microservices.

 - Technical Foundations - Solid expertise in Java & Spring Boot, with exposure to cloud environments (AWS is a plus) and relational databases.

 - User Focus - Deep care for performance, reliability, and clean business logic to ensure a high-quality product.

 - Teamwork and Communication - Excellent cross-functional collaboration skills and ability to communicate complex technical ideas clearly to both technical and non-technical peers.

 - Passion and language proficiency - Passionate about FinTech and/or startup environments and fluent in English.

Don't worry if you don't tick every box. We believe in the power of different viewpoints and strengths. Your unique perspective is important as we build something special: if you're passionate and can make a difference, we truly encourage you to apply.



CareAbout: how we support your impact

We move fast, and evolution never stops. It’s a fun ride, but it can be challenging. To make sure our people truly thrive, we’re committed to making their lives easier, both in the office and out in the world. That’s why we created CareAbout:

 - ❤️ Health: private insurance for you and your family, psychological support with Serenis, mental health workshops.

 - 💰 Financial resources: Stock Option Plan, meal vouchers, relocation support if you’re moving countries.

 - ⚙️ Growth and development: professional development programs, internal mobility, language courses with Preply.

 - 🌱 Flexibility: unlimited PTO, hybrid working policy*, flexible working hours.

 - 👨‍👩‍👧 Family: enhanced parental leave, additional leave for child sickness.

*We embrace three days per week in-office (Tuesday and Thursday + 1 of your choice), with the option to request extra remote time.



Salary: €45,000 - €53,000 gross per annum
This range is set using objective, gender-neutral criteria for the role's core requirements. However, we do not believe in putting a ceiling on talent. The final compensation package is tailored according to your unique experience and expertise. If your skills go beyond the standard profile, apply anyway so we can discuss a package that reflects your true value.



Equal opportunity employer

At Satispay, we're proud to be an equal opportunity employer. We celebrate diversity and inclusion, welcoming individuals of all backgrounds. This opportunity is open to everyone, regardless - for instance - of race, colour, religion, sex, gender identity, sexual orientation, and national origin. Join us in a workplace where everyone belongs!



Learn more about us

Curious what it's actually like here? Our values and pillars shape how we work every day: explore them here https://www.satispay.com/en-it/work-at-satispay/.









#LI-VR1
#LI-Hybrid







By submitting this application, I acknowledge that I have read and understood the content of the Privacy Policy https://www.satispay.com/en-it/legal-hub/privacy-policy/candidates/
