# Serviceberater (m/w/d)

Posted: 2026-08-27T19:30:28Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Serviceberatung im Autohaus ist ein fordernder Job – wir wissen das. Deshalb sagen wir dir vorab ehrlich, wie es bei uns läuft: Samstagsdienst nur alle vier Wochen, geregelte Arbeitszeiten, 31 Tage Urlaub. Wir sind das Autohaus Freier in Heilbronn, familiengeführt, zwei Standorte, Hyundai und Peugeot. Für unseren Standort in der Karl-Wüst-Straße suchen wir eine Serviceberaterin oder einen Serviceberater. In unserem Serviceteam sind Frauen ausdrücklich willkommen – wir freuen uns über eure Bewerbungen.

## Aufgaben

Du bist die Schnittstelle zwischen Kunde und Werkstatt: Du nimmst Aufträge an, planst Termine, erstellst Kostenvoranschläge und gibst die Fahrzeuge nach der Reparatur wieder an die Kunden zurück. Du berätst ehrlich und sorgst dafür, dass der Kunde versteht, was gemacht wird und warum. Kurze Wege, schnelle Entscheidungen – bei uns musst du nicht durch drei Abteilungen fragen.

## Qualifikation

Du hast Erfahrung in der Serviceberatung – oder du bist Kfz-Mechatroniker/in oder Kfz-Meister/in und willst raus aus der Halle, rein in den Kundenkontakt. Beides passt. Die Hyundai-Zertifizierung machst du bei uns: Wir bilden dich aus und übernehmen die Schulungen. Wichtig sind uns Zuverlässigkeit und ein freundlicher, klarer Umgang mit Kunden. Du musst nicht jeden Punkt zu 100 Prozent erfüllen – melde dich gerne trotzdem.

## Benefits

31 Tage Urlaub. Samstagsdienst nur alle vier Wochen. Geregelte Arbeitszeiten. Bezahlte Weiterbildung inklusive Herstellerzertifizierung. Jobrad. Mitarbeiterkonditionen auf Fahrzeuge und Teile. Private Werkstattnutzung.

Bewirb dich in zwei Minuten – Lebenslauf reicht, kein Anschreiben nötig. Wir melden uns schnell zurück.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
