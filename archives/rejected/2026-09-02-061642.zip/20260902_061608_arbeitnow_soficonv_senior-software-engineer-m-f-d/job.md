# Senior Software Engineer (m/f/d)

Posted: 2026-09-01T23:55:05Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

## **About the job**

As a Software Engineer, you’ll contribute to the development of ERP software for the automotive finance,
leasing, fleet, and mobility management industries. You’ll be part of a multidisciplinary team, collaborating
closely with developers, analysts, testers, and consultants to deliver solutions tailored to our customers’
needs. The focus varies depending on the kind of software engineer (e.g., front-end, back-end, and database).

## **Your responsibilities will include:**

- Building, improving, and customizing software modules to enhance the current application or
develop new features.

- Generic product development and/or specific customer-oriented projects.

- Working in an agile environment using Scrum methodologies, participating in Scrum ceremonies,
stand-ups, backlog refinement, and retrospectives.

- Collaborating with business analysts, testers, and product owners to understand requirements
and address challenges.

- Sharing knowledge and best practices within the global developer community to enhance coding
standards and innovation.

- Analyzing existing code and designing technical solutions based on functional requirements.

## **Your skills and interests:**

- You design and develop efficient, scalable software solutions within both microservices and monolithic architectures.

- You leverage your expertise in Java 17, Java EE7, and modern Java frameworks to build high-quality applications.

- You manage and optimize relational databases such as Oracle, MSSQL, or Postgres to ensure high performance.

- You collaborate effectively with diverse, international teams in a dynamic and agile environment.

- You take full ownership of your projects with a proactive mindset, from technical design to final implementation.

- You apply a structured and analytical approach to solve complex technical challenges and improve the broader system architecture.

- You contribute to the continuous improvement of software products while growing professionally through challenging tasks.

- You communicate clearly and effectively in English to coordinate with global stakeholders and team members.

## **What we offer:**

At Sofico, you’ll join an international, multicultural company with over 30 years of success. We double in size every five years, staying true to our open and collaborative culture even as we grow.

We believe you should be in control of your own career. That’s why we put your personal development first. With an extensive onboarding program, you’ll spend six months learning our products and getting to know the organization with the support of a dedicated job coach. Your learning doesn’t stop there; we’ll continue to offer opportunities for growth and development throughout your career.

You’ll work in a modern, accessible office with flexible and hybrid work options that allow you to balance work and life. In addition, we offer:

- Flexible working hours and the option to work from home. 

- Employee discounts, eGym Wellpass, Bike Leasing and a subsidized Jobticket for public transportation. 

- Company pension scheme with optional additional occupational disability insurance.

- Growth potential through personalized learning and development plans.

- A vibrant team culture with regular team events and a company weekend. 

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
