# Senior Software Engineer, Toolkit

Posted: 2026-09-02T02:40:09Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

At Tiger Data, formerly Timescale, we empower developers and businesses with the fastest PostgreSQL platform designed for transactional, analytical, and agentic workloads. Trusted globally by thousands of organizations, Tiger accelerates real-time insights, drives intelligent applications, and powers critical infrastructure at scale. As a globally distributed, remote-first team committed to direct communication, accountability, and collaborative excellence, we're shaping the future of data infrastructure, built for speed, flexibility, and simplicity.

# **Toolkit Engineer**

As a toolkit Engineer, you'll own one of the most important touchpoints developers have with TimescaleDB. TimescaleDB [toolkit](https://github.com/timescale/timescaledb-toolkit) provides an additive set of hyperfunctions enabling users to offload complex calculations into the database, transforming raw time-series data into production-ready insights. You'll shape the roadmap, identify what should be built next, and deliver developer experiences that help engineers solve increasingly complex problems across industrial IoT, manufacturing, observability, financial markets, and beyond.

This isn't a feature factory role. We're looking for an engineer who enjoys identifying patterns across customer problems, making thoughtful technical tradeoffs, and building developer tools that feel intuitive, reliable, and built to last.

📍 **Location:** This role is fully remote and open globally. English language fluency is required. We welcome candidates across time zones, and overlapping collaboration hours with a globally distributed engineering team are preferred rather than required.

**What you will be responsible for in this role**

-

Own the long-term evolution of the TimescaleDB toolkit, balancing customer needs, technical excellence, and product strategy.

-

Define and prioritize toolkit’s roadmap by identifying emerging customer needs across IoT, industrial systems, observability, financial markets, and other time-series applications.

-

Partner closely with Product, Sales, and customers to understand real-world workflows and translate those insights into intuitive developer experiences.

-

Improve reliability, testing, documentation, performance, and maintainability so new capabilities are production-ready from day one.

-

Maintain a healthy balance between shipping new functionality and improving long-term code quality.

**You could be a great fit if you...**

-

At least 2+ years of experience with Rust.

-

Have strong software engineering fundamentals and contributed to Open Source projects.

-

Have experience building SDKs, client libraries, developer tooling, APIs, or platforms used by other engineers.

-

Basic knowledge of statistical functions, e.g. last observation carried forward.

-

Understand database fundamentals including indexing, query execution, transactions, partitioning, and performance tradeoffs.

-

Enjoy working across product discovery and implementation rather than waiting for fully defined requirements.

-

Are naturally curious about how customers use your software and use that curiosity to influence what gets built.

-

Work effectively in a highly collaborative, globally distributed engineering organization.

### **Nice to have**

-

Experience building databases, query engines, or data infrastructure products.

-

Familiarity with time-series databases, observability platforms, or analytics systems.

-

Experience working with physical IoT systems, industrial software, manufacturing, or similar data-intensive domains.

-

Experience contributing to open-source software.

### **Our Commitment:**

-

We respond to every applicant.

-

We review applications fairly and objectively, and shortlist based on relevant skills and experience.

-

We ensure clear and timely communication throughout your candidate journey.

-

We maintain a rigorous interview process with a high bar, designed to give you the opportunity to meet various team members you'll collaborate with across our organization.

### [**About Tiger Data🐯**](https://www.tigerdata.com/about)

Tiger Data, formerly Timescale, sets the standard as the fastest PostgreSQL platform for modern workloads. Trusted by more than 2,000 customers across 25+ countries and powering over 3 million active databases, we enable developers and organizations to build real-time, intelligent applications at scale. Backed by $180 million from top-tier investors, Tiger Data is building the new standard for data infrastructure, built on PostgreSQL, designed for the future.

*👉 *👉 Want to get a feel for how we work and what we value? Check out our blog post:[ **What It Takes to Thrive at Tiger Data**](https://www.timescale.com/blog/what-it-takes-to-thrive-at-timescale)

We embrace diversity, curiosity, and collaboration. Whether debating the perfect chicken nugget crunch 🍗, sharing workout routines 💪, or discussing your favorite plants 🌱 and pets 🐾, you'll find your community here.

### **Our Tech Stack:**

We don't require previous experience with our tech stack, but enthusiasm for learning is key. Our technologies include PostgreSQL, Tiger Cloud, AWS, Go, Docker, Kubernetes, Python, and innovative features like Hypertables, Hypercore, vector search, and real-time analytics.

Learn more at[ ](https://www.tigerdata.com)[www.tigerdata.com](http://www.tigerdata.com) or follow us on Twitter[ ](https://twitter.com/TigerData)[@TigerDatabase](https://x.com/TigerDatabase)

### **What We Offer:**

(Please note that benefits may vary based on country.)

-

Flexible PTO and comprehensive family leave

-

Fridays off in August 😎

-

Fully remote opportunities globally

-

Stock options for long-term growth

-

Monthly WiFi stipend

-

Professional development and educational resources 📚

-

Premium insurance options for you and your family (US-based employees)

Ready to join the future of PostgreSQL? We can’t wait to meet you. 🚀🐯

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
