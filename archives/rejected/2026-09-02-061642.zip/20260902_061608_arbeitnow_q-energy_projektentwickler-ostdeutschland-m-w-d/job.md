# Projektentwickler - Ostdeutschland (m/w/d)

Posted: 2026-09-01T23:20:12Z

## Rejection

- Category: language_requirement
- Reason: hard German language requirement without English green light

Q ENERGYs Ziel ist es, eine nachhaltige Welt mit grüner Energie zu ermöglichen. Unsere Unternehmenswerte - Verantwortung, Partnerschaft, Inklusive and "Changemaker" - sind die Grundlage für unser Handeln. Als Europas führender Anbieter von grünen Energielösungen sind wir ein vertrauenswürdiger Partner für das gesamte Spektrum der erneuerbaren Energien. Unser Ziel ist es, die Welt mit Solar-, Wind- und Hybridkraftwerken, innovativen Speicherlösungen und visionären grünen Wasserstoffprojekten neu zu definieren. 

Begleite uns auf dieser spannenden Reise, um unseren Planeten nachhaltig zu verändern.

Für unser Team suchen wir eine engagierte Projektmanager (m/w/d), die die erfolgreiche Entwicklung und Umsetzung von Wind-, PV- und BESS-Projekten von der ersten Standortidee bis zur Genehmigungsreife und Übergabe in die Realisierung verantwortet.

Ziel der Rolle ist es, wirtschaftlich attraktive, genehmigungsfähige und technisch umsetzbare Projekte zu identifizieren und gezielt voranzutreiben. Dabei übernimmst Du die ganzheitliche Steuerung der Projekte sowie die Koordination aller relevanten internen und externen Stakeholder und stellst die Einhaltung von Zeit-, Kosten-, Qualitäts- und Entwicklungszielen sicher.

**Ihre Aufgaben**

- **Projektakquise und Standortentwicklung:** Identifikation, Bewertung und Sicherung geeigneter Standorte und Flächen für Wind-, PV- und BESS-Projekte einschließlich Machbarkeitsanalysen und Flächensicherung.
- **Projektentwicklung und Genehmigung:** Entwicklung und Optimierung von Projekten, Steuerung der Genehmigungs- und Planungsverfahren sowie Koordination von Gutachtern, Planern, Behörden und weiteren Projektpartnern.
- **Technische und wirtschaftliche Entwicklung:** Bewertung von Netzanschlussmöglichkeiten, Projektlayouts und Wirtschaftlichkeit sowie Steuerung von Kosten, Terminen, Risiken und Projektbudgets.
- **Stakeholder- und Projektmanagement:** Aufbau und Pflege von Beziehungen zu Grundstückseigentümern, Kommunen, Behörden, Netzbetreibern und Geschäftspartnern sowie Koordination der internen und externen Projektbeteiligten.
- **Projektabschluss und Übergabe:** Vorbereitung der Projekte für Finanzierung, Vermarktung, Verkauf oder Übergabe in die Bau- und Realisierungsphase.

**Requirements**

- Abgeschlossenes Studium oder vergleichbare Qualifikation im technischen oder energiewirtschaftlichen Umfeld.
- Berufserfahrung in der Projektentwicklung im Bereich erneuerbare Energien, der Netzintegration oder der Netzanschlussplanung.
- Gute Kenntnisse regulatorischer- und Grundkenntnisse netztechnischer Anforderungen.
- Analytische, strukturierte und eigenverantwortliche Arbeitsweise.
- Sehr gute Kommunikationsfähigkeiten und starkes Schnittstellenmanagement.
- Deutschkenntnisse auf professionellem Niveau sowie fortgeschrittene Englischkenntnisse werden vorausgesetzt.

**Benefits**

- **Flexibler Arbeitsort:** Du hast die Möglichkeit, remote von zu Hause aus zu arbeiten. Zusätzlich steht dir unser modernes und nachhaltiges Büro in Berlin-Südkreuz zur Verfügung, das eine gute Anbindung und eine angenehme Arbeitsumgebung bietet.
- **IT-Ausstattung:** Wir stellen dir einen Laptop, Monitor, Kopfhörer und, falls erforderlich, ein Diensthandy zur Verfügung.
- **Work-Life-Balance:** Deine Zeit ist wertvoll! Gestalte deine Arbeitszeiten flexibel, damit du persönliche Termine wahrnehmen, früher ins Wochenende starten oder einfach das Leben besser mit der Arbeit in Einklang bringen kannst. Du entscheidest.
- **Spendit Card:** Monatlich **50 € zusätzlich zum Gehalt**, die du für dein tägliches Mittagessen nutzen oder unbegrenzt ansparen kannst.
- **Großzügige Urlaubsregelung:** Genieße **31 Urlaubstage** pro Jahr, um dich zu erholen, neue Energie zu tanken und die Welt zu entdecken.
- **Onboarding:** Mit einem strukturierten Onboarding-Prozess sorgen wir für einen reibungslosen Start und begleiten dich von Tag eins an, damit du dich gut aufgehoben fühlst.
- **Betriebliche Altersvorsorge:** Wir leisten einen monatlichen Beitrag von **13,29 €** zu deiner Altersvorsorge.
- **Versicherungsschutz:** Unfall- und Lebensversicherung sind inklusive – für deine Sicherheit und ein gutes Gefühl, sowohl im Job als auch privat.
- **Mitarbeiterrabatte:** Über unser Corporate Benefits-Programm erhältst du exklusive Rabatte auf zahlreiche Marken und Produkte.
- **Firmenwagen:** Falls du berechtigt bist und dein Job es erfordert, steht dir ein Firmenwagen zur Verfügung.
- **Betriebliches Gesundheitsmanagement:** Deine Gesundheit steht an erster Stelle! Profitiere von unserem Gesundheitsmanagement, inklusive Vorsorgeuntersuchungen, um fit und leistungsfähig zu bleiben.

Möchtest du Teil von **Q ENERGY** werden?

Dann freuen wir uns auf deine Bewerbung! Bitte teile uns dabei deine **Gehaltsvorstellung** sowie dein **frühestmögliches Startdatum** mit.

**Hinweis:** Wir akzeptieren keine Bewerbungen per E-Mail. Bitte nutze für deine Bewerbung den **„Jetzt bewerben“-Button**. Vielen Dank!

Bei Fragen steht dir unser Recruiting-Team gerne zur ----- ENERGY** ist ein international tätiges Unternehmen – bei uns arbeiten Menschen aus verschiedenen Nationen, Kulturen und Standorten partnerschaftlich zusammen und tauschen ihre Erfahrungen und Werte in einer offenen und kollegialen Atmosphäre aus.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
