# Working Student Supply Planning (all genders)

Posted: 2026-09-01T23:40:09Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

In this role, you will support our Supply Planning team in translating demand forecasts into feasible production and replenishment plans. You will help ensure that materials are available, production schedules remain on track, and key stakeholders stay aligned.

This position offers a great opportunity to gain hands-on experience in supply and production planning within a fast-growing FMCG environment, while working closely with experienced planners and cross-functional teams.

## **What you'll do**

-

Support the creation and maintenance of production and supply schedules in alignment with demand forecasts

-

Assist in coordinating with Demand Planning and Purchasing to help ensure timely availability of raw materials and components

-

Help track production performance versus plan and support the team in identifying variances or risks

-

Prepare reports, analyses, and planning data in Excel or ERP systems to support decision-making

-

Contribute to cross-functional coordination by supporting communication with operations, purchasing, and marketing teams

-

Assist with ad-hoc analyses, data checks, and process improvements within the planning team

## **Your profile**

-

Currently enrolled in a Bachelor’s or Master’s program in Supply Chain Management, Business Administration, Industrial Engineering, or a related field, ideally with a focus on operations, production, or planning

-

Availability: Ideally available for around 20 hours per week and able to commit for at least 8 months, so you can grow into the role and gain meaningful hands-on experience

-

Strong analytical mindset and genuine interest in how supply chains, production flows, and forecasting processes work in practice

-

Confident working with data and Excel; experience with ERP or planning tools is a strong plus

-

Structured, detail-oriented, and reliable working style with the ability to prioritize tasks and meet deadlines

-

Proactive, curious, and eager to learn in a fast-paced, cross-functional environment

-

Fluent in English; German is a plus

Nice to have / strong advantage:

-

First practical experience (internship working student role) in Supply Planning or Production Planning

-

Exposure to FMCG, food, supplements, cosmetics, or other high-volume production environments

## **What we offer**

-

An attractive discount on our full product range – from essential oils to vitamins and minerals

-

Ownership and plenty of room for new initiatives, with the opportunity to contribute your expertise and turn your own ideas into action

-

Hands-on experience in a dynamic Operations environment and insight into the operational and strategic sides of Suppy Planning

-

Opportunities to contribute to real projects and make an impact

-

Inviting office spaces with a wide selection of organic teas and superfoods from around the world to taste and enjoy

-

We love to celebrate together! Regular tea and office parties, Christmas and summer events, and numerous influencer events, such as Women’s Day

**Sunday Natural **emerged from a long-standing passion and research in the fields of health, healing, and personal growth. The lack of natural, high-quality products on the market was the original motivation for founding Sunday Natural in 2013. We aim to produce the products we ourselves would love to buy – as natural as possible, absolutely pure, free from any additives, and of the highest quality. In a strategic partnership with CVC, Sunday Natural is now one of Germany's most renowned quality manufacturers, with its own research and development department in Berlin. For the continuous improvement of our products, we collaborate with selected research institutes, scientists, therapists, farmers, and professional associations.

**We take our ecological responsibility very seriously:** that’s why the majority of our product range is vegan. We also take an innovative approach to packaging: most of our products are packaged in glass, making them almost entirely recyclable.

Our diverse team in Berlin consists of over 400 employees from more than 45 nationalities and continues to grow – but at a sustainable pace. Our goal is to foster a collaborative, supportive, and inclusive work environment with a diverse group of motivated, talented, and visionary team members.

*We highly value equality of opportunity and inclusivity, and we would like to particularly encourage women and candidates from under-represented backgrounds to apply, even if you don’t match with 100% of the requirements.*

[Legal Notice](https://www.sunday.de/impressum/)

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
