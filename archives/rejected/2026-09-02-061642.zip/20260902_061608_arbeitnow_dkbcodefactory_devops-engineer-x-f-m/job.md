# DevOps Engineer (x/f/m)

Posted: 2026-09-02T02:55:05Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**Welcome to DKB AG…. **

We’re excited to share that our hiring process is now led by Code Factory (CoFa), DKB’s sister tech company, bringing a more agile and collaborative approach to building our cross-functional teams. While you’ll go through the hiring journey with CoFa, your employment will be with DKB, combining the stability of a leading bank with the speed and innovation of a tech-driven environment. Join us to be part of a team where collaboration and impact come first.

**{ { … a_place_to_stay_curious: [**

Technology is a key driver of our continued growth. With modern architecture, a high-performance cloud infrastructure, and a robust data and AI foundation, we are constantly evolving our platform—serving as the foundation for new digital products and services. Our standards are high: security, reliability, and the responsible use of AI are integral components of every solution from the very beginning.

**} } ; **

***{ your_responsibilities: [***

- Develop and operate our AWS-based cloud platform with a focus on stability, scalability and security

- Operate and optimize our Kubernetes/EKS environment, including namespaces, RBAC, ResourceQuotas and NetworkPolicies

- Build and maintain reusable CI/CD components, especially with GitLab CI/CD

- Design GitOps-based deployment processes using Flux, Helm and Kustomize

- Automate infrastructure and AWS resources with Terraform and Crossplane

- Manage secrets and sensitive configuration securely, for example with SOPS and AWS KMS

- Improve monitoring, alerting and observability with Prometheus, Grafana and OpenSearch

- Analyze and resolve issues across CI/CD, Kubernetes, GitOps and cloud environments

- Enable development and project teams to manage deployments, platform usage and CI/CD processes independently

**] ****} ;**

**{ following_qualifications_would_be_in_line_with_our_desired_profile_for_this_position: [**

- Experience in DevOps, platform engineering, cloud infrastructure or SRE

- Good hands-on knowledge of AWS, especially EKS, IAM/IRSA, S3, KMS, RDS/Aurora and networking

- Production experience with Kubernetes

- Experience with CI/CD, ideally GitLab CI/CD and reusable pipeline templates

- Understanding of GitOps principles and tools such as Flux, Helm or Kustomize

- Practical experience with Infrastructure as Code, especially Terraform and/or Crossplane

- Good understanding of monitoring, observability, alerting and performance optimization

- Enjoyment of creating standards, sharing knowledge and enabling product teams

- Structured, independent and solution-oriented working style

- Confident communication in **German and English**, ideally at **C1 level or above**

**] ****} ;**

**{ nice_to_have: [**

- Experience in regulated environments, audit requirements or controlled release processes

- Experience with on-call, incident response, runbooks or post-incident improvements

- Certifications such as CKA, AWS Solutions Architect Associate or comparable credentials

***] } ;***

**You don’t match every single requirement? No worries! We encourage you to apply anyways, even if your qualifications do not align perfectly. You might still be just the right candidate for us!**

**{ { …how_to_start_your_career_at_DKB: [**

We want you to feel good about working with us, to feel valued, and to be able to contribute fully. You can find out what makes us tick and whether DKB is the right employer for you even before you apply by following [this link](https://www.dkb.de/karriere/arbeitgeber#unternehmenskultur).**} } ;**

*By the way: At our company, every person matters. We embrace fairness and diversity—no matter where you’re from, how old you are, or your sex, gender identity, sexual orientation, or religion, whether you have a disability or not—we genuinely look forward to every application!*

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
