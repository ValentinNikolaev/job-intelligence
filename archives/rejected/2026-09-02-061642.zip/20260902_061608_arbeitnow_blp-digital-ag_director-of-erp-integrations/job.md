# Director of ERP Integrations

Posted: 2026-09-02T02:40:08Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**Join BLP Digital — The #1 Solution for ERP Automation**

BLP Digital is redefining ERP automation with agentic AI. Spun out of ETH Zurich and HSG, we build AI agents that automate finance, procurement, logistics, sales, and more for some of the world's largest enterprises. We solve real enterprise problems with cutting-edge technology and a strong sense of ownership.

Our solution is live in 40+ countries, used by 550+ customers, and automates 70,000+ processes every day, including for Fortune 500 companies. As one of Switzerland's fastest-growing SaaS scaleups, our success stems from deep expertise in technology and business processes, delivering a product with outstanding product-market fit, proven by a growing global customer base.

We've recently welcomed Goldman Sachs Alternatives as a growth investor, and we're now expanding into the UK with the launch of our London office. We are just getting started. Ready to build the future? *Join BLP Digital today.*

**The Team and the Challenge**

BLP runs two ERP integration teams: one focused on SAP and the team you would lead, which owns every other ERP. Your team builds and maintains the integrations that carry live ERP data into the BLP platform and back, all mapped to our canonical data model.

**The ERP landscape you own**

The team already runs a mature portfolio of more than 30 live ERP integrations, so you would own and extend an established base rather than start from scratch. It spans Microsoft Dynamics NAV and Business Central (on-premise and cloud), Microsoft Dynamics 365 Finance & Operations, Infor LN, Infor M3, Abas, Oracle NetSuite, and Oracle JD Edwards with new systems added as the customer base grows.

**The integration patterns you own**

The work spans on-premise connectors, customer-exposed REST APIs, locally hosted REST APIs, and file-based exchanges. No two customers look the same, and the US mid-market in particular is deeply fragmented. Turning that variety into a reliable, repeatable, well-documented product is the core of the role.

**What You Will Do**

**Build and scale the team**

· Grow the team from roughly 10 to 50 engineers, hiring, structuring squads, and developing team leads beneath you.

· Design a team model that scales sustainably, including distributed and near-shore delivery where it makes sense.

**Own the technical direction**

· Set the architecture and standards for connectors across on-premise, cloud, REST, and file-based patterns.

· Drive reusability and a consistent approach to mapping ERP data onto the BLP data model.

· Uphold BLP's bar for enterprise-grade reliability, governance, and full audit trails.

**Drive documentation and process**

· Establish the documentation, playbooks, and engineering processes that let a 50-person team move fast without losing quality.

· Build onboarding and knowledge-sharing so new engineers reach productivity quickly.

**Engage senior customer stakeholders**

· Represent BLP in technical conversations with senior stakeholders at enterprise customers, including CIOs, IT directors, and enterprise architects.

· Scope integration solutions, set expectations, and build trust through delivery.

**Master the US market**

· Be the person who understands the fragmented US ERP landscape and turns it into a competitive advantage for BLP.

· Partner closely with our US go-to-market and delivery teams.

**What You Bring**

**Must have:**

· 8+ years in software or integration engineering, including several years leading engineering teams, with a proven track record of scaling a team well beyond 20 people.

· Deep, hands-on ERP integration experience, with direct exposure to several of: Microsoft Dynamics (NAV, Business Central, D365 F&O), Infor LN or M3, Oracle NetSuite or JD Edwards, Abas.

· Fluency across integration patterns: on-premise connectors and agents, REST APIs, and file or EDI exchange, with strong instincts for data mapping to a canonical model.

· Direct experience with the US mid-market ERP landscape and its fragmentation.

· Excellent stakeholder management: comfortable and credible with senior customer technical leaders.

· A demonstrated record of building documentation, standards, and repeatable processes, not just shipping features.

· Fluent English and willingness to travel to customers and BLP sites.

**Nice to have:**

· Background at an integration platform (iPaaS), AP or finance automation, or another B2B SaaS company that integrates broadly with ERPs.

· .NET / C# familiarity, common in the Dynamics connector world, and exposure to EDI standards.

· Experience building and leading distributed or near-shore engineering teams.

· German is a plus.

**Location, Reporting and What We Offer**

This role can be based onsite at a BLP office or worked fully remotely. Some travel to customers and BLP sites is expected. The role reports directly to the Founder & CTO.

· Direct ownership of a high-visibility function at a fast-growing enterprise AI company.

· The mandate and resources to build a 50-person team and shape how it works.

· A collaborative, senior peer group and direct access to leadership.

· Competitive compensation aligned with the hiring location.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
