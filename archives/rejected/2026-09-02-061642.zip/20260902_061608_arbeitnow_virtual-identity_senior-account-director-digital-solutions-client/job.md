# Senior Account Director Digital Solutions / Client Partner (m/f/x)

Posted: 2026-09-02T02:30:18Z

## Rejection

- Category: tech_stack
- Reason: role does not mention Go/Golang or PHP

Read this first: What this role is about
This is a client-lead role. You own client relationships and the commercial growth that comes with them. No disciplinary responsibility. At VI leading isn’t about hierarchy or reporting lines. You set direction and get people pulling towards it, but you don’t manage them on paper. Not an operational project role. You do not manage or run projects or manage delivery day-to-day. If what energizes you is owning the client and growing the business - rather than carrying disciplinary responsibility or running project operations - you are in the right place!

**What you will do:**

-

The Client Relationship. You build close, trusting partnerships with a portfolio of clients and are their primary point of contact.

-

The Business Value. You do not just process briefings. You actively help client to uncover and solve their real business challenges.

-

The Order Volume. You turn business challenges of your clients into signed offers. Together with the Client Partner team you are accountable for the agency’s annual order volume.

-

The Account Rituals. You shape the account team rituals to create the right atmosphere, ambition and dedication to deliver outstanding results that win the clients’ hearts and minds.

**What we expect:**

-

A genuine pull towards owning client relationships, commercial growth and energizing the team around the client.

-

At least 6 years** **in client service, account management or consulting (agency side or in-house).

-

A completed university degree (engineering, economics or similar) or a comparable qualification.

-

A strategic mindset and real enthusiasm for digital topics.

-

Curiosity about people: You connect easily, listen closely and quickly see what matters.

-

Proficient English and very good written and spoken German is Mandatory.

**Contact**
Marion Huwatscheck
Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
