# Future Enterprise Account Executive Opportunities

Posted: 2026-09-01T23:55:11Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**About Mirakl:**

Founded in 2012, Mirakl has been at the forefront of marketplace innovation, empowering every business to compete in the platform economy.

Today, Mirakl’s operating system combines an enterprise marketplace solution (Mirakl Platform) that enables retailers and B2B organizations to launch, scale, and operate marketplaces and dropship, AI-powered multichannel selling (Mirakl Connect), retail media (Mirakl Ads) and an agentic commerce infrastructure (Mirakl Nexus).

With dual headquarters in Boston and Paris, Mirakl helps a global ecosystem of 450+ marketplaces (B2C and B2B) and a network of over 100k third-party marketplace sellers. Brands like Macy’s, Decathlon, Carrefour, Asos, and Airbus Helicopters use Mirakl to grow their businesses in new and remarkable ways.

For more information, visit [www.mirakl.com](http://www.mirakl.com).

**Mirakl in Numbers:**

- 🗓️ Founded in 2012 | Member of French Tech Next40

- 👥 750+ employees in 9 offices worldwide: Paris, Barcelona, Bordeaux, Boston, London, Munich, New York, Sydney, Tokyo

**Our Values:**

Working at Mirakl means accelerating your career alongside ambitious, passionate, and supportive colleagues. We're proud of the diversity of backgrounds, perspectives, and experiences that make our teams unique.

Our 5 values guide how we collaborate:

- 💡** Work Hard Together:** Teamwork and collaboration are the foundation of our success

- 🏆 **Get Things Done: ** We prioritize action and efficiency for impactful results

- 🚀 **Go Above & Beyond:** We tackle challenges proactively and always aim for excellence

- 🎓 **Succeed Through Expertise:** Knowledge sharing and continuous learning are core to our culture

- 🤝 **Satisfy & Empower Clients:** We're committed to our clients' success

## Interested in being considered for a future Enterprise Account Executive role at Mirakl?

Tell us a little bit about yourself so we start here first. **This is not a live job opening. **We’re building a talent pool for future opportunities on our US Platform Sales team and will keep your information on file for consideration.

**What You’ll Do at Mirakl**

- Define and execute a territory-based sales strategy to consistently meet and exceed quarterly and annual revenue targets.

- Identify and engage net-new enterprise clients aligned with Mirakl's go-to-market strategy, driving platform adoption across retail and B2B markets.

- Build and nurture executive-level relationships with VP, EVP and C-suite stakeholders, positioning Mirakl as a transformative platform partner.

- Own the full sales cycle from initial outreach through to contract signature, while navigating technical, legal and financial complexities with confidence.

- Drive revenue growth across new logos and existing accounts through strategic upselling and cross-selling, while contributing to Mirakl's market presence and professional network.

**What We’re Looking For**

Experience

- 8+ years in a closing role in software/SaaS/eCommerce.

- A consistent track record of exceeding quota and managing complex, multi-stakeholder enterprise sales processes.

- Proven experience selling to Fortune 500 companies and engaging with C-suite executives.

Skills

- Strong executive presence and the ability to influence stakeholders at the highest levels.

- Strategic territory-planning skills paired with sharp tactical execution.

- The ability to compellingly pitch disruptive technology to large enterprises.

- Confidence navigating long, complex sales cycles involving multiple stakeholders.

- Willingness and ability to travel as needed.

**What Happens Next**

- Your information will remain on file with our US Talent team for consideration for future Account Executives opportunities.

- If a relevant role opens and your experience is a strong fit, a recruiter may contact you.

- All active opportunities are always posted on our [Careers Page](https://www.mirakl.com/company/careers/). If you see a current role that aligns with your experience, we encourage you to apply directly.

Thank you for your interest in Mirakl!

*We welcome collaborators with their diverse perspectives and experiences to power us forward. These often far exceed conventional job requirements and help us create a culture of continuous learning. If you’re ready to join a global leader powering digital transformation for 450+ of the world’s most innovative retailers and B2B organizations.*

*As part of our recruitment process, Mirakl processes your personal data to review and manage your application and, where appropriate, to consider your profile for future opportunities. You can exercise your data protection rights at any time, and as further detailed in our policies. For more information about how we process your personal data and your rights, please consult our Recruitment Privacy Notice, [here](https://www.mirakl.com/recruitment-privacy-notice) in English and [here](https://www.mirakl.com/fr-FR/recruitment-privacy-notice) in French. *

*We may use Artificial Intelligence (AI) solutions to help streamline our hiring process, including screening applications, analyzing resumes, and assessing responses. While AI helps us work efficiently, all final hiring decisions are made by humans. For more information, visit our *[*AI Guidelines for Candidates and Interviews*](https://info.mirakl.com/ai-guidelines-for-candidates-and-interviews)*.*

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
