# SAP Integration Architect

Posted: 2026-09-01T23:55:09Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

## **About Parloa**

Parloa’s mission is to make every customer conversation feel effortless for both customers and the companies serving them. As agentic AI accelerates, Parloans are shaping the foundation of a new era in customer experience, one where customer support is no longer transactions, but meaningful exchanges. It is not just a vision; Parloa has powered over ONE BILLION interactions between global enterprise brands and their customers, with companies like [Booking.com](http://booking.com), HealthEquity, Allianz, SAP, BarmeniaGothaer, and TUI already deploying Parloa at scale.

## **About the role:**

As Parloa continues to grow rapidly within the SAP ecosystem, we're hiring an **SAP Integration Architect **to join our SAP Center of Excellence (CoE). This unique role sits at the intersection of enterprise SAP orchestration and high human-touch cutting edge conversational AI. You will be the field-facing SAP SME who architects, builds and deploys technical bridges and extensions between Parloa’s conversational AI platform and the SAP ecosystem, spanning SAP CX and other SAP SaaS applications, SAP BTP and SAP Business AI, as well as digital core systems, such as SAP S/4HANA and ECC. As one of our foundational SAP CoE hires, you will also participate in building and deploying Parloa's global SAP delivery practice from the ground up, creating the reference architectures, accelerators, best practices and playbooks that make Parloa’s SAP integrations repeatable at scale.

## **Areas of ownership:**

This role is a blend of architecture and hands-on delivery and centers on SAP integration and orchestration as the core area of ownership and conversational AI as a secondary skillset.

- **Own SAP integration and orchestration architectures:** design and architect SAP integration and orchestration solutions spanning Parloa's AI platform, cloud and on-premise SAP estates, and non-SAP applications around digital SAP core.

- **Deliver across the full project lifecycle: **drive** **discovery, build, test, and go-live, by implementing integrations and automation workflows in cloud-native and hybrid environments over SAP state-of-the-art platforms such as SAP BTP (Integration Suite incl. SAP CI, Event Mesh, API Management, Integration Advisor, Open Connectors) and on-demand over legacy ESB such as SAP PI/PO.

- **Master SAP interfacing technologies:** Apply deep hands-on knowledge of SAP OData and REST APIs, SOAP WebServices, RFMs / BAPIs, and ALE/IDocs, including extensibility, monitoring, troubleshooting, connectivity configuration and performance tuning.

- **Leverage your foundational SAP AI knowledge: **apply your first** **hands-on experience with SAP Business AI and it's underlying components such as SAP AI Core and Launchpad, SAP Joule agents and skills to support AI-powered integration scenarios and extensibility.

- **Lead customer conversations on demand**: Run discovery workshops and architecture discussions as the trusted SAP integration expert.

- **Collaborate across functions when needed**: Work in tandem with Parloa's Agent Architects and FDEs, and provide technical guidance and enablement to non-SAP team members.

- **Contribute to global SAP practice:** Turn field experience and lessons learned into accelerators, reference architectures and playbooks that improve delivery repeatability.

## **Who you are:**

- 5+ years of hands-on experience in SAP integration development and architecture incl. technical consulting, and delivering scalable integrations in live enterprise environments.

- Strong hands-on experience with SAP BTP Integration Suite: analyzing and applying standard integration packages as well as designing, building, and operating end-to-end custom solutions interacting across all SAP IS services, such as SAP CI, Event Mesh, API Management, Open Connectors etc.

- First experience in the field with SAP’s AI stack (e.g., SAP AI Core, SAP AI Launchpad, SAP Joule) and interoperability standards like MCP

- Foundational SAP ABAP knowledge and solid Groovy scripting skills

- Consulting or advisory affinity: experience guiding enterprise customers, partners, or systems integrators through solution discovery, architecture discussions, or implementation trade-offs

- Project and stakeholder management skills, with passion for meeting milestones and effective communication

- Entrepreneurial mindset with initiative, results orientation, and the ability to identify opportunities for impact

- Ability to travel and to be on demand on-site with customers and partners for key moments like discovery workshops, architecture reviews, and go-lives

- Fluent business English and German is required

## **Nice to Have**

- Exposure to Large Language Models (LLMs) and conversational design to craft effective prompts that align with desired outcomes

- Exposure to customer contact center technologies, telephony and enterprise CX platforms

- Familiarity with SAP architecture frameworks (Clean Core, ISA-M, Extensibility Framework)

- Familiarity with the SAP CX and CRM solutions, such as SAP Service Cloud, SAP Sales Cloud etc.

- Familiarity developing extensions on SAP BTP using CAP is an important, though not core, differentiator

- Experience integrating non-SAP ERPs (MS Dynamics 365, Oracle NetSuite) and CRM/HCM systems (Salesforce, Workday, ServiceNow).

- Foundational knowledge of a cloud platform (AWS, Azure, or GCP) and Kubernetes; programming in Python, SQL, or TypeScript/Node.js.

- Foundational knowledge of SAP data and analytics (SAP BW/4HANA, SAP Datasphere, SAP Analytics Cloud).

- Experience working with or for SAP system integrators or within the broader SAP partner ecosystem

- Experience operating in fast-paced startup or high-growth enterprise software environments.

## **Our recruiting process:**

TA Screen → Hiring Manager Call → Case Study & Expert Interview(s) → Bar Raiser

Parloa is committed to upholding the highest data protection standards for our clients' and employees' data. All our employees are instrumental in ensuring the utmost care, GDPR, and ISO compliance, including ISO 27001, in handling sensitive information.

Parloa is an e-verify employer in the USA. [Please click here to learn more](https://www.e-verify.gov/about-e-verify/what-is-e-verify).

*** ****We provide equal opportunities to all qualified applicants regardless race, gender, sexual orientation, age, religion, national origin, disability status, socioeconomic background and other characteristics.**

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
