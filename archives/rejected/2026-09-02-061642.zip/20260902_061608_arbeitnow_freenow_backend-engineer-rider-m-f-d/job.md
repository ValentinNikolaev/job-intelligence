# Backend Engineer – Rider (m/f/d)

Posted: 2026-09-01T23:55:06Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

***Location****: Come and join us in Hamburg!*

As of now, we are looking for a highly motivated Backend Engineer to join one of our Teams that builds the backend of the Platform.

Our teams are cross functional with backend and frontend engineering and work on various systems such as our Rider application or Rider & Marketplace related backend. This includes driving automation across critical processes and enhancing internal user experiences with data-driven, reliable solutions.

*Be ready to join a multinational, diverse, and collaborative team that strives for excellence while having fun and growing together.*

## **YOUR DAILY ADVENTURES WILL INCLUDE:**

- Designing, developing, and maintaining robust backend services for our internal operations and automation platforms.

- Taking end-to-end ownership of feature development—from ideation through deployment, monitoring, and iteration.

- Working closely with engineers, product managers, and operations teams to deliver high-impact tools that reduce friction and accelerate issue resolution.

- Maintaining system reliability through thoughtful monitoring, alerting, and continuous delivery practices.

- Exploring the application of AI and foundational models (e.g. Gemini, Claude) to enhance operational efficiency and support intelligent automation across internal processes.

- Participating in knowledge sharing and collaboration within our technical domain, helping shape practices and ways of working.

- Being part of a culture that values quality, pragmatism, transparency, and continuous learning.

## **TO BE SUCCESSFUL IN THIS ROLE:**

- You have solid experience with backend development and feel comfortable working with technologies like Kotlin, Java, Spring, PostgreSQL, and Kafka—or you're confident in picking them up.

- You take ownership of your work and seek opportunities to improve code quality, system design, and delivery processes.

- You enjoy working in collaborative, cross-functional teams and value knowledge sharing and open communication.

- You're curious and adaptable, and enjoy solving both technical and product-related challenges.

- You thrive in a mission-driven environment, where your contributions have clear impact and your strengths are nurtured.

- You're excited about being part of a team that continuously evolves, reflects, and celebrates wins together.

- You have a clear, confident communication style in English, both written and verbal.

- Bonus: You have experience building backend systems that leverage AI or foundational models to drive operational efficiency and automation.

## **BENEFITS & PERKS IN A NUTSHELL:**

- Flexible working arrangements

- LinkedIn Learning

- Sabbatical & special leave policies

- WeRoad partnership

- Birthday, 24th + 31st December off

- Short term EU work policy

- Mobility Credit

- Health Insurance

- Employee assistance program

## **DIVERSITY, EQUITY & INCLUSION:**

Freenow is an equal opportunity employer and we consider qualified applicants regardless of race, religion, national origin, gender, gender identity, sexual orientation, disability or age.
We want you to grow and evolve, bring your true self to work.

## **ABOUT FREENOW:**

We are Freenow, the European taxi app with the broadest multi-mobility offering, available in 9 markets and over 180 cities. Our app gives millions of passengers the freedom to move with a wide choice of services including taxis, private hire vehicles, carsharing, car rental, e-scooters, e-bikes, e-mopeds and public transport.Headquartered in Hamburg and led by our CEO Thomas Zimmermann, we are on a mission to make urban mobility more efficient, sustainable and inclusive.Since July 2025 we have been part of Lyft, a global mobility platform connecting riders and drivers for billions of rides across North America and Europe. Together we are building a more caring and connected world, creating new opportunities for innovation, growth and impact.

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
