# Solutions Architect, Pre-Sales - German Defense & Intelligence

Posted: 2026-09-02T02:55:10Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**Welcome to Planet. We believe in using space to help life on Earth.**

Planet designs, builds, and operates the largest constellation of imaging satellites in history. This constellation delivers an unprecedented dataset of empirical information via a revolutionary cloud-based platform to authoritative figures in commercial, environmental, and humanitarian sectors. We are both a space company and data company all rolled into one.

Customers and users across the globe use Planet's data to develop new technologies, drive revenue, power research, and solve our world’s toughest obstacles.

As we control every component of hardware design, manufacturing, data processing, and software engineering, our office is a truly inspiring mix of experts from a variety of domains.

We have a people-centric approach toward culture and community and we strive to iterate in a way that puts our team members first and prepares our company for growth. Join Planet and be a part of our mission to change the way people see the world.

Planet is a global company with employees working remotely world wide and joining us from offices in San Francisco, Washington DC, Germany, Austria, Slovenia, and The Netherlands.

**About the Role: **

As a Pre-Sales Solutions Architect, you'll design complex solutions to demonstrate the value of Planet's data and services to help organizations within the German Defense and Intelligence community overcome their earth data challenges. You'll collaborate with internal cross-functional teams, including Customer Success, Product Management, and Business Development, to act as the voice of the customer and enhance Planet's industry offerings.

Ideal candidates are dedicated to earth observation and enabling customer success across complex technical projects.

This is a full-time, hybrid role which will require you to work from our Berlin, Germany office 3 days per week.

**Impact You’ll Own:**

- Build and deliver presentations and product demonstrations highlighting technical capabilities of Planet’s platform and our ability to fulfill customer’s business needs.

- Build relationships with customers’ technical and management staff as a trusted advisor to their business.

- Act as a technical advisor to the customer to recommend a solutions architecture that fits their business challenges.

- Craft the technical response to tenders, RFI’s/RFP’s, and unsolicited proposals with respect to Planet’s products and solutions.

- Partner with your sales team colleagues to architect and drive the technical strategy across customer and prospect account plans.

- Collaborate with internal cross-functional teams including Customer Success, Product Management, and Business Development to act as the voice of the customer, assist with RFP and RFI preparation and submissions.

- Attain quarterly and annual sales and operational objectives assigned by management.

- Represent the needs of Planet's Defense and Intelligence customers to Sales leadership by communicating forecasts, pipeline opportunities, deal reviews, CRM data, and customer feedback.

- Present to key executive Government stakeholders within the German Government

- Mentors junior team members and contributes to team training materials.

**What You Bring:**

- 4+ years of experience supporting the German Defense and Intelligence community in a technical capacity.

- Bachelor's degree in a relevant field.

- Ability to travel, including internationally, up to 25%.

- Excellent verbal and written communication skills in the German language.

- Professional working proficiency in English, the language of the company.

- Experience working with GIS and Remote Sensing users within the Defense industry.

- Experience in IMINT, ISR, and related fields.

- Experience with QGIS, SocetGXP, ArcGIS, GDAL, Python, and other geospatial software packages and programming languages.

- Experience designing and presenting complex systems and solutions that bridge the gap between business problems and technology to meet organizational goals, budget, and scalability needs.

- Ability to communicate and coordinate effectively with both technical and non-technical stakeholders.

- Ability to process imagery, manipulate geospatial data, interact with APIs, and build data pipelines.

- Obtaining and maintaining eligibility for a German security clearance (Sicherheitsüberprüfung) is required.

**What Makes You Stand Out:**

- Ability to multitask, prioritize, and manage time effectively in a fast-paced environment.

- Experience leading technical customer engagements and leading workshops or training sessions with users.

**Application Deadline:**

November 24, 2026 at 11!:59p PT

**Export Control Requirements:**

*Planet Labs Germany GmbH is authorized to receive U.S. export-controlled information at Planet under an export license issued by the Bureau of Industry and Security. This position requires access to U.S. and German/EU export-controlled information, and as such, employment (or hiring of a contractor) is contingent upon the candidate’s ability to access all applicable export-controlled information without additional export licensing being required by German, EU, or U.S. authorities.*

**Benefits While Working at Planet:**

*These offerings are dependent on employment type and geographical location, based upon applicable law or company policy.*

- Paid time off including vacation, holidays and company-wide days off

- Employee Wellness Program

- Home Office Reimbursement

- Monthly Phone and Internet Reimbursement

- Tuition Reimbursement and access to LinkedIn Learning

- Equity

- Volunteering Paid Time Off

**Compensation:**

The expected starting gross salary range for this role is listed below. Individual placement within this range is determined objectively based on gender-neutral criteria such as your skills, qualifications, and professional experience. This position may also be eligible for discretionary bonuses, commission, and/or equity.

This role is eligible for commission.

Germany Salary Range

€63.910—€79.870 EUR

**San Francisco Fair Chance Ordinance
**Pursuant to the San Francisco Fair Chance Ordinance, we will consider for employment qualified applicants with arrest and conviction records.**
**

**Why we care so much about Belonging.
**We’re dedicated to helping the whole Planet, and to do that we must strive to represent all of it within each of our offices and on all of our teams. That’s why Planet is guided by an ultimate north star of Belonging—dreaming big as we approach our ongoing work. If this job intrigues you, but you’re thinking you might not have all the qualifications, please... do apply! At Planet, we are looking for well-rounded people from around the world who can contribute to more ways than just what is listed in this job description. We don’t just fill positions, we aspire to fulfill people’s careers, most excited about folks who are motivated by our underlying humanitarian efforts. We are a few orbits around the sun before we get to where we want to be, so we hope you’re excited to come along for the ride.

**EEO statement:
**Planet is committed to building a community where everyone belongs and we invite people from all backgrounds to apply. Planet is an equal opportunity employer, and committed to providing employment opportunities regardless of race, religious creed, color, national origin, ancestry, physical disability, mental disability, medical condition, genetic information, marital status, sex, gender, gender identity, gender expression, pregnancy, childbirth and breastfeeding, age, sexual orientation, military or veteran status, or any other protected classification, in accordance with applicable federal, state, and local laws. [Know Your Rights.](https://www.eeoc.gov/sites/default/files/2023-06/22-088_EEOC_KnowYourRights6.12.pdf)

**Accommodations:
**Planet is an inclusive community and we know that everyone has their own needs. If you have a disability or special need that requires accommodation during the hiring process, please reach out to ----- or contact your recruiter with your request. Your message will be confidential and we will be happy to assist you.

**Privacy Policy**: By clicking "Apply Now" at the top of this job posting, I acknowledge that I have read the [Planet Data Privacy Notice for California Staff Members and Applicants](https://www.planet.com/privacy/#california), and hereby consent to the collection, processing, use, and storage of my personal information as described therein.

**Privacy Policy (European Applicants):** By clicking "Apply Now" at the top of this job posting, I acknowledge that I have read the [Candidate Privacy Notice GDPR Planet Labs Europe](https://www.planet.com/privacy/), and hereby consent to the collection, processing, use, and storage of my personal information as described therein.

**AI in Our Interviewing Process**: Planet is committed to providing an exceptional interview experience for all candidates. We currently use [Metaview](https://www.metaview.ai/) to better focus on candidates and less on trying to capture notes. As such, with the candidate's consent, select interviews may be recorded and include a "Planet AI Notetaker" for transcription and summarization purposes. Should an interview involve use of AI interview technologies, the candidate will receive notification and have the ability to opt out both in advance and/or real-time. Opting out will not affect one's candidacy.

**Candidate AI Policy**: Planet embraces Artificial Intelligence (AI) tools, and we encourage its responsible use. We understand that candidates may use various resources, including AI tools, to *prepare* for interviews and assessments. However, *during any live interview stage or when actively completing assessments for this position, the use of AI tools—e.g. Large Language Models (LLMs), deep fake technology, etc.—is strictly prohibited unless explicitly prompted by an interviewer or assessment instructions*. If you are unsure about acceptable use, please contact your recruiter for clarification. If an AI tool or similar technology is desired as an accommodation, please contact ----- with your request for assistance. Your message will be confidential, and we will be happy to assist you. Violation of this policy may result in disqualification of your application.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
