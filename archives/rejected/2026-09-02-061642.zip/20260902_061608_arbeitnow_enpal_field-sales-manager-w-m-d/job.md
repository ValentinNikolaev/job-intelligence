# Field Sales Manager (w/m/d)

Posted: 2026-09-02T02:40:07Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Unser Ziel ist eine Solaranlage auf jedem Dach, ein Speicher in jedem Haus und ein E-Auto in jeder Garage. Enpal macht das möglich mit einer integrierten Gesamtlösung für dezentrale Energie – von Solaranlage und Batteriespeicher über Wallbox, Smart Meter bis zur Wärmepumpe. Herzstück ist unsere KI-gestützte Plattform [Enpal.One](http://Enpal.One)+, die tausende Systeme intelligent vernetzt und Strombezug sowie -einspeisung effizient am Energiemarkt optimiert.

Bist Du bereit für Lösungen, die mehr als nur ein Versprechen sind und täglich echte Lebensqualität in tausende Haushalte bringen? Was du bei Enpal gestaltest, liefert morgen sauberen Strom und verändert nachhaltig, wie wir Energie nutzen.

Deine Aufgaben

-

Du berätst Kund:innen direkt im OBI Partner-Markt in Offenbach zu unseren innovativen Energielösungen und begeisterst sie für eine nachhaltige Zukunft.

-

Du sprichst aktiv Kund:innen an, identifizierst ihren Bedarf und vereinbarst Beratungstermine.

-

Nach der Erstberatung im Markt besuchst du Kund:innen auch vor Ort, um ihre individuelle Situation besser zu verstehen und die Voraussetzungen für unsere Lösungen aufzunehmen.

-

Technische Eckdaten der Kund:innen erfasst du sowohl im Markt als auch beim Vor-Ort-Termin, um die grundsätzliche Umsetzbarkeit der Lösung zu prüfen.

-

Du begleitest Interessent:innen vom ersten Kontakt bis zum erfolgreichen Abschluss und sorgst dabei für eine herausragende Customer Experience.

-

Durch deine offene und serviceorientierte Art baust du langfristige Kundenbeziehungen auf und repräsentierst Enpal als starke Marke vor Ort.

-

In regelmäßigen Feedbackgesprächen mit deiner Führungskraft entwickelst du deine Verkaufs- und Beratungskompetenzen kontinuierlich weiter.

-

Gemeinsam mit deinem Team unterstützt du dabei, die Energiewende voranzutreiben und das größte Energieunternehmen des 21. Jahrhunderts aufzubauen.

### Dein Profil

-

Du kannst bereits mehrjährige Erfahrung im Vertrieb von komplexen Lösungen idealerweise im Außendienst vorweisen.

-

Eine sympathische, aufgeschlossene und kommunikationsstarke Persönlichkeit zeichnet dich aus, ebenso wie deine Loyalität als Teamplayer.

-

Erfolgs- und lösungsorientiertes Denken sowie eine positive Ausstrahlung prägen dein Auftreten.

-

Du legst Wert auf persönliche Weiterentwicklung und gute Karrierechancen.

-

Mit einer ausgeprägten, proaktiven Eigenmotivation brennst du voller Begeisterung für deine Ziele und Abschlüsse.

-

Du verfügst über einen Führerschein der Klasse B und bist bereit, Kund:innen in der Region Offenbach auch persönlich vor Ort zu besuchen.

-

Deine verbalen und schriftlichen Deutschkenntnisse sind auf einem verhandlungssicheren Niveau.

### Darauf kannst Du Dich freuen

-

Erhalte ein attraktives Gehaltspaket inklusive unbegrenztem Provisionsmodell, um deinen Erfolg und deinen Beitrag zum Unternehmenserfolg zu belohnen.

-

Arbeite in Deutschlands erstem grünen Unicorn und gestalte aktiv die solare Energiewende mit.

-

Die Sonne scheint auf der ganzen Welt - Bei Enpal arbeitest du mit einem hochmotivierten, diversen Team aus über 65 Nationalitäten.

-

Du hast einen echten Impact und gestaltest aktiv die Entwicklung eines zukunftsorientierten und wachsenden Unternehmens mit.

-

Energiewende geht nur gemeinsam - Bei Enpal erwartet dich ein legendärer Teamspirit und unvergessliche Team- und Companyevents.

-

Bleib auf dem Laufenden & gestalte mit - Transparente All-Hands, kurze Entscheidungswege und eine offene Feedback-Kultur, denn ohne Fehler gibt es keinen Fortschritt.

*Wir bei Enpal sind stolz auf die Vielfältigkeit unseres Teams. Weder bei der Einstellung noch während des Beschäftigungsverhältnisses werden Entscheidungen auf Basis von Hautfarbe, Religion oder religiösen Glaubens, ethnischer oder nationaler Herkunft, Nationalität, Geschlechteridentität, sexuelle Orientierung, Behinderung oder Alter getroffen. Enpal steht für einen sicheren Arbeitsplatz und geht gegen Diskriminierung und Belästigung jeglicher Art vor.*

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
