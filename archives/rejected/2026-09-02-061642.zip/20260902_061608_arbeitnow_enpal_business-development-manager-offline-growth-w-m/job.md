# Business Development Manager - Offline Growth (w/m/d)

Posted: 2026-09-02T02:40:07Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Unser Ziel ist eine Solaranlage auf jedem Dach, ein Speicher in jedem Haus und ein E-Auto in jeder Garage. Enpal macht das möglich mit einer integrierten Gesamtlösung für dezentrale Energie – von Solaranlage und Batteriespeicher über Wallbox, Smart Meter bis zur Wärmepumpe. Herzstück ist unsere KI-gestützte Plattform [Enpal.One](http://Enpal.One)+, die tausende Systeme intelligent vernetzt und Strombezug sowie -einspeisung effizient am Energiemarkt optimiert.

Bist Du bereit für Lösungen, die mehr als nur ein Versprechen sind und täglich echte Lebensqualität in tausende Haushalte bringen? Was du bei Enpal gestaltest, liefert morgen sauberen Strom und verändert nachhaltig, wie wir Energie nutzen.

###

### **Deine Aufgaben**

-

Du übernimmst ab Tag 1 End-to-End-Verantwortung für bestehende Offline-Vertriebskanäle zur erfolgreichen Leadgenerierung und entwickelst sie konsequent weiter.

-

Du steuerst deine Kanäle eigenständig und entwickelst skalierbare Strategien für Agenturaufbau, Incentivierung, Training, Qualitätskontrolle und stetige Performance-Optimierung – von der Idee über den Test bis zur Skalierung.

-

Du pflegst und vertiefst die Zusammenarbeit mit bestehenden Partneragenturen, bindest neue Partner an und baust belastbare, langfristige Beziehungen auf.

-

Du arbeitest proaktiv, hands-on und lösungsorientiert, bist kommunikationsstark und behältst auch bei operativen Aufgaben den Überblick.

-

Du kommunizierst souverän intern wie extern mit Stakeholdern auf allen Ebenen und sorgst für klare Abstimmung, schnelle Entscheidungen und saubere Umsetzung.

-

Du bist ein integraler Teil unseres Growth Teams und prägst die Skalierung eines strategischen Geschäftsbereichs mit enormer Bedeutung für Enpals zukünftiges Wachstum.

-

Du arbeitest eng mit Sales, Tech, Brand und Product, um alle Hebel für massives Wachstum zu nutzen.

### **Dein Profil**

-

Abgeschlossenes Studium an einer Top-Universität oder vergleichbarer Leistungsnachweis.

-

0-2 Jahre relevante Erfahrung im Bereich Venture Development, Business Development, Vertrieb, Partnermanagement, strategische Skalierung oder in der Beratung mit Fokus auf Growth / Commercial Excellence.

-

Unternehmerisches Mindset, absolute Ownership und die Fähigkeit, Dinge von 0 auf 1 und von 1 auf 100 zu bringen.

-

Ausgeprägtes Verhandlungsgeschick, starke Kommunikationsfähigkeit und ein natürlicher „Closer“-Spirit.

-

Hohe Zahlenaffinität, strukturiertes Vorgehen und Erfahrung im Performance-gesteuerten Arbeiten.

-

Du denkst groß, liebst Geschwindigkeit, probierst unkonventionelle Ansätze aus – und bist bereit, echte Verantwortung für ein hochstrategisches Wachstumsfeld zu übernehmen.

Du bist interessiert, auch wenn du nicht alle Anforderungen erfüllst? Bewirb dich trotzdem! Wir freuen uns darauf, dein Potenzial zu entdecken - unabhängig davon, ob deine Erfahrung jede einzelne Voraussetzung erfüllt. ☀️

### **Darauf kannst Du Dich freuen**

-

**Arbeite in Deutschlands erstem grünen Unicorn** - Gestalte aktiv die solare Energiewende mit.

-

**Die Sonne scheint auf der ganzen Welt** - Bei Enpal arbeitest du mit einem hochmotivierten, diversen Team aus über 65 Nationalitäten.

-

**Das ideale Setup für deinen Fokus - **Wir sind überzeugt, dass exzellente Ergebnisse dort entstehen, wo die Bedingungen stimmen. Deshalb setzen wir auf ein hybrides Arbeitskonzept, das dir die Freiheit gibt, immer genau so zu arbeiten, wie es am besten zu deinen Aufgaben passt. Du brauchst neue Impulse auf internationalem Niveau? Mit Workflex bieten wir, abhängig von deiner Verantwortung, die Möglichkeit, deine Tätigkeit bis zu 30 Tage im Jahr ins Ausland zu verlegen.

-

**Grown-up Business & Startup Spirit** - In unserem modernen Office in Berlin-Friedrichshain findest du von höhenverstellbaren Tischen, Tischtennisplatte bis gefüllten Getränkekühlschränken und Barista-Coffee alles was das Herz begehrt.

-

**Dein Kick-start bei Enpal** - Onboarding-Tag mit Welcome Bag, Buddy-Programm und einem Team, das dich wirklich abholt.

-

**Bleib auf dem Laufenden & gestalte mit** -** **Transparente All-Hands, kurze Entscheidungswege und eine offene Feedback-Kultur, denn ohne Fehler gibt es keinen Fortschritt.

-

**Energiewende geht nur gemeinsam** - Bei Enpal erwartet dich ein legendärer Teamspirit und unvergessliche Team- und Companyevents.

-

**Dein Extra-Boost** -** **29 Urlaubstage + je ein freier Tag an Heilig Abend & Silvester, vergünstigte Mitgliedschaft bei Wellhub und Corporate Benefits. Alles, was dir hilft, Arbeit und Leben gut zu verbinden.

*Wir bei Enpal sind stolz auf die Vielfältigkeit unseres Teams. Weder bei der Einstellung noch während des Beschäftigungsverhältnisses werden Entscheidungen auf Basis von Hautfarbe, Religion oder religiösen Glaubens, ethnischer oder nationaler Herkunft, Nationalität, Geschlechteridentität, sexuelle Orientierung, Behinderung oder Alter getroffen. Enpal steht für einen sicheren Arbeitsplatz und geht gegen Diskriminierung und Belästigung jeglicher Art vor.*

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
