# Senior Rust Developer

Posted: 2026-09-01T23:55:08Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

# **About Workato**

Workato is the leading Control and Execution Platform for Enterprise AI — the neutral platform enterprises trust to put AI to work across their business. Workato unifies data, applications, and processes into a single platform so AI can reliably orchestrate business processes in production at enterprise scale. Built on more than a decade of running mission-critical processes for over half the Fortune 500 — including Nasdaq, Amazon, Cisco, Vodafone, Atlassian, and Lucid Motors — Workato turns over 14,000 enterprise systems AI needs to act on into one governed execution layer. For more information, visit [workato.com](https://www.workato.com/).

# **Why join us?**

Ultimately, Workato believes in fostering a **flexible, trust-oriented culture that empowers everyone to take full ownership of their roles**. We are driven by **innovation **and looking for** team players **who want to actively build our company.

But, we also believe in **balancing productivity with self-care**. That’s why we offer all of our employees a vibrant and dynamic work environment [along with a multitude of benefits](http://www.workato.com/careers) they can enjoy inside and outside of their work lives.

If this sounds right up your alley, please submit an application. We look forward to getting to know you!

Also, feel free to check out why:

-

[Business Insider](https://www.businessinsider.com/47-enterprise-startups-to-bet-your-career-on-in-2020-2019-12) named us an “enterprise startup to bet your career on”

-

[Forbes’ Cloud 100](https://www.forbes.com/cloud100/#a57477b5f941) recognized us as one of the top 100 private cloud companies in the world

-

[Deloitte Tech Fast 500](https://www2.deloitte.com/us/en/pages/technology-media-and-telecommunications/articles/fast500-winners.html) ranked us as the 17th fastest growing tech company in the Bay Area, and 96th in North America

-

[Quartz](https://qz.com/work/2053446/the-best-companies-for-working-from-home/) ranked us the #1 best company for remote workers

# **Responsibilities**

We are looking for a Senior Rust Software Developer. In this role, you will also be responsible to:

-

Building new products inside the company.

-

Develop new code with Rust, and deal with existing Go/Ruby code

-

Create PoC in the new areas and drive them to production or drop them away.

# **Requirements**

### **Qualifications / Experience / Technical Skills**

- Strong experience writing, shipping, and maintaining Rust code (2+ years), and experience with other languages (Ruby, Python, Go, JS, Java, etc.)

- Knowledge of basic data structures and algorithms, multiprocessing, memory management.

- Experience developing high-performance asynchronous applications with Rust (preferably tokio).

- Good understanding of network protocols and stacks.

- Good understanding of DB technologies: classic databases and modern no-SQL.

- Basic knowledge of DevOps practices and tools

- Understanding of Linux environment

- Golang/Ruby knowledge is a plus

- Experience working with WASM is a plus

- Open Source contributions is a plus

### **Soft Skills / Personal Characteristics**

- Readiness to work remotely with teams distributed across the world and timezones

- Spoken English (at the level enough to pass the technical interview and later work with colleagues)

- Being a result-oriented problem solver.

- Prefers coming up with proposals in problematic areas, rather than being passive.

- Being open to new technologies and switching between projects.

- Readiness to travel for business

**(REQ ID: 2682)**

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
