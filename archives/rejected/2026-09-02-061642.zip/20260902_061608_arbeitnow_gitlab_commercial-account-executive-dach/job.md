# Commercial Account Executive - DACH

Posted: 2026-09-02T02:55:04Z

## Rejection

- Category: language_requirement
- Reason: hard German language requirement without English green light

GitLab is the intelligent orchestration platform for DevSecOps. GitLab enables organizations to increase developer productivity, improve operational efficiency, reduce security and compliance risk, and accelerate digital transformation. More than 50 million registered users and more than 50% of the Fortune 100* trust GitLab to ship better, more secure software faster.

The same principles built into our products are reflected in how our team works: we embrace AI as a core productivity multiplier, with all team members expected to incorporate AI into their daily workflows to drive efficiency, innovation, and impact. GitLab is where careers accelerate, innovation flourishes, and every voice is valued. Our high-performance culture is driven by our values and continuous knowledge exchange, enabling our team members to reach their full potential while collaborating with industry leaders to solve complex problems. [Co-create the future with us](https://www.youtube.com/watch?v=OuZIb5zszQI) as we build technology that transforms how the world develops software.

**Fortune 500® is a registered trademark of Fortune Media IP Limited, used under license. Claim based on GitLab data. Fortune 100 refers to the top 20% ranked companies in the 2025 Fortune 500 list, published in June 2025. Fortune and Fortune Media IP Limited are not affiliated with, and do not endorse products or services of GitLab.*

## An overview of this role

As a Commercial Account Executive, you’ll be the primary connection between GitLab and mid-market customers, working with organizations of up to 4,000 team members to help them adopt and expand the world’s most comprehensive AI-powered DevSecOps platform. You’ll own a broad book of business across a wide range of opportunity sizes, guiding small, fast-growing teams as well as more complex projects as they modernize their software delivery with GitLab. Reporting to an Area Sales Manager and partnering closely with business development, marketing, and technical teams, you’ll run the full sales process: shaping the customer’s journey, documenting buying criteria and processes, ensuring accurate pipeline based on evidence, and sharing root-cause insights on wins and losses. In your first year, you’ll focus on building trusted relationships, delivering meaningful business outcomes for customers, and being the voice of the customer internally by contributing ideas to our public issue tracker and improving our sales handbook.

## What you’ll do

- Report to an Area Sales Manager and own a broad book of Enterprise business, from new prospects to growing existing accounts.

- Manage the full sales cycle for Enterprise prospects, from discovery and solution alignment through negotiation and close.

- Support GitLab for Enterprise prospects by clearly articulating our DevSecOps value proposition and aligning it to customer business outcomes.

- Analyze wins and losses, contribute to root cause analyses, and share lessons learned with account managers, marketing, and technical teams.

- Document and maintain accurate buying criteria, buying processes, next steps, and owners to ensure a reliable, evidence-based pipeline.

- Contribute to improving our sales handbook and processes by documenting best practices and opportunities for refinement.

- Provide account leadership and direction across pre- and post-sales, partnering closely with technical teams and customer success.

- Represent the voice of the customer by contributing product feedback and ideas to our public issue tracker.

## What you’ll bring

- Proven success in software sales, ideally in a Enterprise market context, managing a varied book of business.

- Ability to guide customers through the full buying journey, including defining buying criteria, mapping buying processes, and driving clear next steps.

- Effective communication and interpersonal skills to collaborate with business development, marketing, technical teams, and sales management.

- Experience documenting and maintaining accurate pipeline data and account plans based on evidence rather than assumptions.

- Skill in conducting and contributing to win/loss and root cause analyses, and sharing insights to improve team performance and processes.

- Proficiency in negotiation, presenting to customer stakeholders, and leading commercial discussions to close opportunities.

- Interest in GitLab, open source software, and preferably familiarity with Git, software development tools, or application lifecycle management.

- Alignment with GitLab’s values and an interest in contributing from diverse or transferable sales backgrounds, with willingness to travel in line with company policy.

- Fluent German language skills (required).

## About the team

The Commercial & Enterprise Sales team focuses on helping growing organizations adopt and expand GitLab’s AI-powered DevSecOps platform across their software delivery lifecycle. You’ll join a distributed group of Account Executives, sales managers, and business development team members who collaborate asynchronously across regions to manage a broad book of business in the mid-market segment. We partner closely with marketing, sales development, and technical teams to run an efficient, transparent sales process, document what works in our sales handbook, and represent the voice of the customer back into GitLab. We focus on opportunities like supporting customers through toolchain consolidation, driving platform adoption, and sharing learnings from wins and losses to continuously improve how we sell and support GitLab.

#LI-CW1

#### **How GitLab Supports Full-Time Employees**

- [Benefits to support your health, finances, and well-being](https://about.gitlab.com/handbook/total-rewards/benefits/general-and-entity-benefits/)

- [Flexible Paid Time Off ](https://handbook.gitlab.com/handbook/people-group/time-off-and-absence/time-off-types/#flexible-paid-time-off-pto)

- [Team Member Resource Groups](https://handbook.gitlab.com/handbook/company/culture/inclusion/tmrg-tmag/)

- [Equity Compensation & Employee Stock Purchase Plan](https://handbook.gitlab.com/handbook/total-rewards/stock-options/)

- [Growth and Development Fund](https://handbook.gitlab.com/handbook/people-group/learning-and-development/growth-and-development/)

- [Parental Leave](https://about.gitlab.com/handbook/total-rewards/benefits/general-and-entity-benefits/#parental-leave)

Please note that we welcome interest from candidates with varying levels of experience; many successful candidates do not meet every single requirement. Additionally, studies have shown that people from [underrepresented groups](https://about.gitlab.com/company/culture/inclusion/#examples-of-select-underrepresented-groups) are less likely to apply to a job unless they meet every single qualification. If you're excited about this role, please apply and allow our recruiters to assess your application.

**Country Hiring Guidelines: **GitLab hires new team members in countries around the world. All of our roles are remote, however some roles may carry specific location-based eligibility requirements. Our Talent Acquisition team can help answer any questions about location after starting the recruiting process.

**Privacy Policy: **Please review our [Recruitment Privacy Policy.](https://handbook.gitlab.com/handbook/hiring/candidate-faq/recruitment-privacy-policy/) Your privacy is important to us.

GitLab is proud to be an equal opportunity workplace and is an affirmative action employer. GitLab’s policies and practices relating to recruitment, employment, career development and advancement, promotion, and retirement are based solely on merit, regardless of race, color, religion, ancestry, sex (including pregnancy, lactation, sexual orientation, gender identity, or gender expression), national origin, age, citizenship, marital status, mental or physical disability, genetic information (including family medical history), discharge status from the military, protected veteran status (which includes disabled veterans, recently separated veterans, active duty wartime or campaign badge veterans, and Armed Forces service medal veterans), or any other basis protected by law. GitLab will not tolerate discrimination or harassment based on any of these characteristics. See also [GitLab’s EEO Policy](https://about.gitlab.com/handbook/people-policies/inc-usa/#equal-employment-opportunity-policy) and [EEO is the Law](https://about.gitlab.com/handbook/labor-and-employment-notices/#eeoc-us-equal-employment-opportunity-commission-notices). If you have a disability or special need that requires [accommodation](https://about.gitlab.com/handbook/people-policies/inc-usa/#reasonable-accommodation), please let us know during the [recruiting process](https://about.gitlab.com/handbook/hiring/interviewing/#adjustments-to-our-interview-process).

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
