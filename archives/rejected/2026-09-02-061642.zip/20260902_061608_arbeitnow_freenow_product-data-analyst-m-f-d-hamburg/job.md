# Product Data Analyst (m/f/d) - Hamburg

Posted: 2026-09-01T23:55:06Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

***Location****: We are flexible! Come and join us either in Hamburg, Berlin or Barcelona. *

Freenow empowers smarter mobility decisions helping people to move freely and cities to thrive.

We are looking for a **Product Data Analyst (m/f/d) **to collaborate with our product squads, using data to build a flawless product experience. You will join the Product Data Team and work closely with PMs, designers, UX researchers, developers, and other data functions to discover new product opportunities, validate hypotheses, and launch valuable features to our users.

Be ready to work in a multinational, diverse, highly motivated and collaborative team of passionate analysts who strive for excellence and like to have fun. Are you ready for your next ride?

## **YOUR DAILY ADVENTURES WILL INCLUDE:**

- Providing expertise and collaborating with stakeholders to generate new product feature ideas and improvements, and also estimating the potential impact of planned projects.

- Continuously engaging with the product squads to gain an understanding of the problems that need to be solved, gathering requirements, and defining the best deliverables to match the business needs.

- Having full ownership of your analysis, from ideation to communication of results and making recommendations to all levels of the company including senior management and prioritization committees.

- Developing and evaluating A/B test experiments or other analyses to measure and report the performance of released features, ensuring that we are launching the correct changes and features in our apps.

- Working closely with our developers and data engineers to create and capture data that is aligned with the business logic and allows modeling and analysis.

- Being involved throughout the complete product lifecycle in order to guarantee a data-driven process.

- Bringing new insights and championing them using your analyses, dashboards, and good storytelling! We value ideas over hierarchy, and there's always a new path to follow if your idea is convincing and well-backed with data.

- You will have the opportunity to steer our products, which kind of features should be developed, and which changes should be made to solve hundreds of thousands of users' daily needs.

## **TO BE SUCCESSFUL IN THIS ROLE:**

- You **have curiosity in your essence**, which motivates you to** answer WHY things happened**, not only scratching the surface, but aiming for well-founded actionable results

- Degree in Mathematics, Statistics, Economics, Computer Science, Engineering, or other fields with a strong mathematical-statistical background

- **3+ years experience in working as a Data Analyst in a data-driven analytics environment**, preferably within tech product organizations, having direct contact with stakeholders.

- **Exceptional analytical skills**, lateral thinking, and proven experience in solving highly challenging problems.

- **Very good knowledge of SQL, **databases, and statistical programming tools (e.g. Python, R) so that exploratory analyses can be performed, reports created and ETLs maintained

- Good understanding and hands-on experience in **analyzing and interpreting A/B test results**, backed by statistical knowledge.

- **Experience in working with data visualisation tools** (e.g.Tableau, Qlikview) and event tracking (e.g. Mixpanel, GA, Firebase)

- **You are able to communicate findings in a concise and clear manner **to a wide variety of stakeholders to support data-driven decision making by using data visualisation and storytelling and have excellent English communication skills.

## **BENEFITS & PERKS IN A NUTSHELL:**

- Flexible working arrangements

- LinkedIn Learning

- Sabbatical & special leave policies

- WeRoad partnership

- Birthday, 24th + 31st December off

- Short term EU work policy

- Mobility Credit

- Health Insurance

- Employee assistance program

**Plus more local benefits depending on your work location!**

## **DIVERSITY, EQUITY & INCLUSION:**

Freenow is an equal opportunity employer and we consider qualified applicants regardless of race, religion, national origin, gender, gender identity, sexual orientation, disability or age.
We want you to grow and evolve, [bring your true self to work](https://www.youtube.com/watch?v=dOUL_n8pSGQ).

## **ABOUT US:**

Freenow by Lyft empowers smarter mobility decisions, helping people to move freely and cities to thrive. Through our multi-mobility app, we feature broad options for everyone across 9 European markets and over 180 cities. Millions of passengers can access services including taxis, private hire vehicles, carsharing, car rental, e-scooters, e-bikes, e-mopeds, and public transport within a single app.

In July 2025 Freenow was acquired by Lyft, a global mobility platform, which connects riders and drivers for billions of rides across North America and Europe. Together, Freenow and Lyft are creating a more caring and connected world, with transportation for everyone. We are a global, diverse, highly motivated, and collaborative team that strives for excellence and likes to have fun. Ready for your next ride?

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
