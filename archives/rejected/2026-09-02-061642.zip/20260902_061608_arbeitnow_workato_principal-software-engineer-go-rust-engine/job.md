# Principal Software Engineer, GO & Rust (Engine)

Posted: 2026-09-01T23:55:08Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

# **About Workato**

Workato is the leading Control and Execution Platform for Enterprise AI — the neutral platform enterprises trust to put AI to work across their business. Workato unifies data, applications, and processes into a single platform so AI can reliably orchestrate business processes in production at enterprise scale. Built on more than a decade of running mission-critical processes for over half the Fortune 500 — including Nasdaq, Amazon, Cisco, Vodafone, Atlassian, and Lucid Motors — Workato turns over 14,000 enterprise systems AI needs to act on into one governed execution layer. For more information, visit [workato.com](https://www.workato.com/).

# **Why join us?**

Ultimately, Workato believes in fostering a **flexible, trust-oriented culture that empowers everyone to take full ownership of their roles**. We are driven by **innovation **and looking for** team players **who want to actively build our company.

But, we also believe in **balancing productivity with self-care**. That’s why we offer all of our employees a vibrant and dynamic work environment [along with a multitude of benefits](http://www.workato.com/careers) they can enjoy inside and outside of their work lives.

If this sounds right up your alley, please submit an application. We look forward to getting to know you!

Also, feel free to check out why:

-

[Business Insider](https://www.businessinsider.com/47-enterprise-startups-to-bet-your-career-on-in-2020-2019-12) named us an “enterprise startup to bet your career on”

-

[Forbes’ Cloud 100](https://www.forbes.com/cloud100/#a57477b5f941) recognized us as one of the top 100 private cloud companies in the world

-

[Deloitte Tech Fast 500](https://www2.deloitte.com/us/en/pages/technology-media-and-telecommunications/articles/fast500-winners.html) ranked us as the 17th fastest growing tech company in the Bay Area, and 96th in North America

-

[Quartz](https://qz.com/work/2053446/the-best-companies-for-working-from-home/) ranked us the #1 best company for remote workers

# **Responsibilities**

We are looking for an exceptional System Architect to lead the design and evolution of our platform architecture. This is a hands-on role requiring deep technical expertise in building secure, scalable, and cost-efficient systems. You will be responsible for critical architectural decisions affecting system performance, security, reliability, and modularity across our entire platform.

In this role, you will also be responsible to:

-

Architecture & Design

-

Design microservices and platform features from concept to production-ready specifications

-

Create technical designs for complex system components and develop proof-of-concepts in Golang

-

Architect secure, fault-tolerant systems with automated failover, circuit breakers, and end-to-end encryption

-

Analyze existing system architecture to understand current implementations and plan gradual replacement of legacy components

-

Plan implementation phases, migration strategies, and feature deprecation timelines

-

Architectural Governance & Collaboration

-

Review and approve architectural designs from engineering teams with detailed feedback

-

Lead architecture review sessions and facilitate technical decision-making across teams

-

Partner with Product Managers, Dev Leads, Security, SRE and Infrastructure teams to establish platform-wide standards

-

Lead threat modeling exercises and drive technical consensus for platform-wide initiatives

-

Mentor engineers on architectural best practices and resolve complex technical challenges

-

Documentation & Planning

-

Write comprehensive technical documentation including ADRs, design documents, runbooks, and API specifications

-

Create visual system diagrams and research technical solutions from diverse sources

-

Design zero-downtime migration strategies and define acceptance criteria for architectural changes

# **Requirements**

### **Qualifications / Experience / Technical Skills**

-

8+ years building scalable distributed systems, with 3+ years in System/Platform Architect roles

-

Proven experience architecting both large microservice environments (100+ services) and monolithic applications

-

Strong hands-on Golang coding skills - must write production-quality code

-

Communication & Data: Protocol Buffers, gRPC, WebSockets, Kafka event streaming, PostgreSQL (partitioning, replication, HA)

-

Security & Authentication: OAuth 2.0/OIDC, JWT, mTLS, data encryption, public key cryptography, zero-trust architecture

-

Infrastructure & Operations: Working knowledge of Kubernetes, Docker, CI/CD pipelines, Infrastructure as Code (Terraform), distributed systems patterns (Saga, circuit breakers, retries)

-

Scale: Experience with systems handling millions of requests/events per day

-

Exceptional technical writing and communication abilities for diverse audiences

-

Experience planning phased implementations and leading complex cross-team projects

-

Proven track record with feature flags, gradual rollouts, and zero-downtime deployments

-

Ability to facilitate architectural decision-making and create technical roadmaps

-

Mentorship mindset and cost analysis capabilities

-

Experience with AI-assisted workflows, particularly in system analysis and hunting for inconsistencies and corner cases.

### **Nice to Have**

-

Additional Languages: Ruby, **Rust**, Python, Java, C++, Kotlin-multiplatform

-

Advanced Security: Key Management Systems (HSM, AWS KMS), Secrets Management (Vault), specific crypto algorithms

-

Extended Infrastructure: Service mesh (Istio, Linkerd), NoSQL databases, Redis clustering, stream processing (Flink, Spark)

-

Cloud & Compliance: AWS/GCP/Azure expertise, PCI-DSS, HIPAA, SOC2

-

Community: Open source contributions, conference speaking, technical writing

**(REQ ID: 2885)**

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
