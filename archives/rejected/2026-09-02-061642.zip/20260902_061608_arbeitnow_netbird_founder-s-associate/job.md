# Founder’s Associate

Posted: 2026-09-01T23:40:04Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

## 🏢 Who we are

A team from Germany with the vision to make advanced network security accessible for everyone

We are a software company developing an open source zero-trust network security platform that is both easy to use and affordable for teams of all sizes and budgets. Our mission is grounded in a simple yet powerful belief: secure private networking is a fundamental right of every modern company.

Since our launch on GitHub in 2021, we have gained trust among thousands of companies seeking secure and seamless solutions for connecting remote employees and infrastructure. By replacing traditional centralized VPNs, NetBird has become a trusted choice for modern network security, connecting today hundreds of thousands of users and machines worldwide. Our open source, community-driven approach has been a key driver of our success. We listen to our users, and their input helps us make network security better for everyone.

Want to see what we're working on? Check out our GitHub repo at [https://github.com/netbirdio/netbird](https://github.com/netbirdio/netbird) or [https://netbird.io/knowledge-hub](https://netbird.io/knowledge-hub)

## ✏️ What you will do

As Founder's Associate at NetBird, you'll work directly with our founders and Chief of Staff as a sparring partner and execution engine on the topics that matter most to the company. This is a high-trust, high-ownership role for someone who wants to see, and shape, how a fast-growing open source startup is built, from strategy to day-to-day execution.

Specifically, you will:

-

Own strategic projects across growth, product, operations, and fundraising end to end, from first analysis to shipped result

-

Help grow the team, from running recruiting operations to winning exceptional people for NetBird

-

Research markets, competitors, and customer needs to identify new opportunities and risks before they become obvious

-

Drive cross-team initiatives and keep Product, Growth, and Engineering aligned on critical company milestones

-

Design and improve the internal processes that keep a scaling company running, and take ownership of whatever matters most right now, from testing new GTM ideas to unblocking the founders

## 🔎 What we are looking for

We're looking for an exceptional generalist: highly motivated, analytical, and hands-on, with the ambition to help build and scale a tech startup from the inside.

What you bring

-

A track record of excellence and real ownership, for example through top academic results from a top tier university or internships in high-caliber startups, venture capital, investment banking, or strategy consulting

-

You're highly structured, organized, and able to drive multiple topics in parallel without losing your eye for detail

-

You enjoy working with data, building models, and turning insights into action, but also have a hands-on mentality

-

You're comfortable taking a vague problem, defining it, and driving it to a result

## 🌟 What makes you a great fit

These are the values we work by as a team, and what they mean for this role:

-

Own the outcome: Small team, real scope. You take problems end to end and ship something that works today instead of polishing a plan for weeks.

-

Default to candor: Direct, kind, and specific, whether you're challenging a colleague's assumption or receiving feedback yourself. The best argument wins.

-

Stay close to the user: You don't have to be an engineer, but you're genuinely curious about our product and the open source community behind it.

## 😌 What's in for you

We know that happy and supported team members build the best products. That's why we offer:

-

Competitive salary and equity: everyone at NetBird owns a piece of what we're building

-

Close collaboration with our co-founders: work with them day to day and learn how a startup is really built

-

High impact: your projects directly shape NetBird's trajectory

-

Hybrid setup: a centrally located Berlin office with flexibility for remote days

-

The essentials done well: team lunches, team events, health and fitness programs (e.g., Wellpass), and dinner on us when you're working late

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
