# Flowmanager:in | Home Office | (w/m/d)

Posted: 2026-09-02T02:40:07Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Unser Ziel ist eine Solaranlage auf jedem Dach, ein Speicher in jedem Haus und ein E-Auto in jeder Garage. Enpal macht das möglich mit einer integrierten Gesamtlösung für dezentrale Energie – von Solaranlage und Batteriespeicher über Wallbox, Smart Meter bis zur Wärmepumpe. Herzstück ist unsere KI-gestützte Plattform [Enpal.One](http://Enpal.One)+, die tausende Systeme intelligent vernetzt und Strombezug sowie -einspeisung effizient am Energiemarkt optimiert.

Bist Du bereit für Lösungen, die mehr als nur ein Versprechen sind und täglich echte Lebensqualität in tausende Haushalte bringen? Was du bei Enpal gestaltest, liefert morgen sauberen Strom und verändert nachhaltig, wie wir Energie nutzen.

###

### **Deine Aufgaben**

-

Du begleitest unsere Kunden nach Vertragsabschluss bis zum erfolgreichen Abschluss der Montage.

-

Du koordinierst Montagetermine und stimmst dich mit Kunden, Montageteams und internen Abteilungen ab.

-

Du stellst sicher, dass alle Voraussetzungen für eine reibungslose Montage erfüllt sind.

-

Du erkennst mögliche Verzögerungen frühzeitig, koordinierst Lösungen und eskalierst offene Risiken.

-

Du bist zentraler Ansprechpartner für den Kunden und sorgst für eine positive Kundenerfahrung während des gesamten Projekts.

### **Dein Profil**

-

Du hast Erfahrung in der Kundenbetreuung, Projektkoordination oder Disposition.

-

Du kommunizierst sicher, professionell und kundenorientiert – auch in anspruchsvollen Situationen.

-

Du arbeitest strukturiert, organisiert, zuverlässig und eigenverantwortlich.

-

Du hast eine ausgeprägte Problemlösungskompetenz und behältst auch unter Zeitdruck den Überblick.

-

Du bist sicher im Umgang mit digitalen Tools und MS Office und arbeitest dich schnell in neue Systeme ein.

Du bist interessiert, auch wenn du nicht alle Anforderungen erfüllst? Bewirb dich trotzdem! Wir freuen uns darauf, dein Potenzial zu entdecken - unabhängig davon, ob deine Erfahrung jede einzelne Voraussetzung erfüllt. ☀️

### **Darauf kannst Du Dich freuen**

-

**Arbeite in Deutschlands erstem grünen Unicorn** - Gestalte aktiv die solare Energiewende mit.

-

**Die Sonne scheint auf der ganzen Welt** - Bei Enpal arbeitest du mit einem hochmotivierten, diversen Team aus über 65 Nationalitäten.

-

**Das ideale Setup für deinen Fokus - **Wir sind überzeugt, dass exzellente Ergebnisse dort entstehen, wo die Bedingungen stimmen. Deshalb setzen wir auf ein hybrides Arbeitskonzept, das dir die Freiheit gibt, immer genau so zu arbeiten, wie es am besten zu deinen Aufgaben passt. Du brauchst neue Impulse auf internationalem Niveau? Mit Workflex bieten wir, abhängig von deiner Verantwortung, die Möglichkeit, deine Tätigkeit bis zu 30 Tage im Jahr ins Ausland zu verlegen.

-

**Grown-up Business & Startup Spirit** - In unserem modernen Office in Berlin-Friedrichshain findest du von höhenverstellbaren Tischen, Tischtennisplatte bis gefüllten Getränkekühlschränken und Barista-Coffee alles was das Herz begehrt.

-

**Dein Kick-start bei Enpal** - Onboarding-Tag mit Welcome Bag, Buddy-Programm und einem Team, das dich wirklich abholt.

-

**Bleib auf dem Laufenden & gestalte mit** -** **Transparente All-Hands, kurze Entscheidungswege und eine offene Feedback-Kultur, denn ohne Fehler gibt es keinen Fortschritt.

-

**Energiewende geht nur gemeinsam** - Bei Enpal erwartet dich ein legendärer Teamspirit und unvergessliche Team- und Companyevents.

-

**Dein Extra-Boost** -** **29 Urlaubstage + je ein freier Tag an Heilig Abend & Silvester, vergünstigte Mitgliedschaft bei Wellhub und Corporate Benefits. Alles, was dir hilft, Arbeit und Leben gut zu verbinden.

*Wir bei Enpal sind stolz auf die Vielfältigkeit unseres Teams. Weder bei der Einstellung noch während des Beschäftigungsverhältnisses werden Entscheidungen auf Basis von Hautfarbe, Religion oder religiösen Glaubens, ethnischer oder nationaler Herkunft, Nationalität, Geschlechteridentität, sexuelle Orientierung, Behinderung oder Alter getroffen. Enpal steht für einen sicheren Arbeitsplatz und geht gegen Diskriminierung und Belästigung jeglicher Art vor.*

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
