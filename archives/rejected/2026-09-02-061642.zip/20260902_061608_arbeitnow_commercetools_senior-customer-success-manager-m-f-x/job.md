# Senior Customer Success Manager (m/f/x)

Posted: 2026-09-01T23:55:07Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

#### **About commercetools**

Real innovation starts with a strong foundation, and at commercetools, that comes from the perfect balance of our product and our people.

Behind every leap forward is a collective of builders, explorers, doers, makers, and problem-solvers. The kind of people who not only created composable commerce but also shaped the culture of experimentation that idea unlocked. Together they are the engine of commerce innovation today.

At commercetools, we power the next era of commerce for our customers. Whether it’s AI-driven solutions that help enterprises make smarter business decisions, bridging digital and physical shopping experiences, or enabling entirely new ways for industries to connect with their customers, we help the world’s most ambitious companies experiment, scale, and grow without limits.

Here the best idea wins, not the loudest voice. You will have the tools, trust, and space to not only build the future of commerce, but to build your own.

**About our Customer Success team**

Hello, I am [Gareth](https://www.linkedin.com/in/gareth-rea-4b764a21/), the Head of Customer Success UK/Ire & Nordics here at commercetools. My team is dedicated to building deep, consultative partnerships within the Enterprise space.

Our Customer Success Team is passionate about shaping and scaling an exceptional upmarket customer experience across the Enterprise Segment. We’re thrilled to be hiring our next Senior CSM in EMEA as we continue to grow the team.

In this role, you’ll serve as the vital link between our customers and the most modern commerce products on the market. You will partner with our largest and most complex enterprise accounts, from high-growth brands to public companies, focusing on account health, post-sales adoption, and positioning commercetools as a trusted, strategic partner.

You’ll work closely with our internal support, product development, and sales teams to pave the best path forward for our clients. Because commercetools is powerful, modern, and highly flexible, you’ll leverage your deep technical understanding, sales affinity, and top-tier communication skills to help major brands architect exceptional commerce workflows and achieve long-term value. Beyond account management, you’ll actively contribute to shaping and growing our Customer Success practice both regionally and globally.

If you are ready to drive great solutions for big brands, manage multi-channel customer communications, and thrive in a high-impact role, we’d love to meet you!

#### **Your Impact**

- Guide enterprise clients in maximizing the value of our agentic commerce architecture, including Composable Commerce, Frontend, and Connect, helping them build flexible, future-proof tech stacks

- Translate new product features and capabilities into clear business outcomes, aligning them directly with each customer's strategic goals and core ROI metrics

- Proactively drive account engagements, leading high-impact Strategic Business Reviews (SBRs) to retain clients, boost platform consumption, and accelerate long-term growth

- Partner closely with Product Management to advocate for customer needs, providing critical feedback to shape the roadmap for our latest product innovations

- Collaborate seamlessly across Sales, Product, and Support to deliver deep technical and commercial expertise that keeps enterprise accounts thriving

- Represent commercetools in webinars, customer case studies, and advisory working groups, showcasing customer success and driving community engagement

- Play a pivotal role in refining global Customer Success frameworks, driving internal process improvements, and shaping the department’s long-term operational strategy

- Act as a recognized domain expert internally and externally, mentoring team members, fostering cross-functional collaboration, and elevating collective CS practice standards

***This role is hybrid, with three days a week spent in our** Berlin** office. ***

#### **What Sets You Apart**

- 5+ Years in High-Touch Tech with proven success in CS, pre-sales, or technical consulting, ideally within e-commerce or retail

- Technical depth in modern API-first/headless tech, paired with the business acumen to turn complex tech into high-impact ROI

- A bold, trusted advisor who navigates C-suite discussions, shapes client strategy, and drives expansion effortlessly

- A structured, agile approach to managing complex accounts independently and across global, cross-functional squads

- A collaborative team player ready to thrive in a fast-scaled, international tech culture, willing to travel up to 50% to build high-value client connections

**Nice to Have: **

- Additional European language skills

#### **Our Benefits**

Because work and life are connected, our benefits are too. We’ve designed them to give you the security, flexibility, and opportunities you need to focus on what matters most.

🩺 **Comprehensive health benefits** for you and your dependents, including access to OpenUp for personalized mental health support

📚 **Learning and development **opportunities including an annual learning budget, access to self-paced learning platforms and language training, personalized coaching, mentorship, and leadership programs

🍼 **Family Leave Plus** gives you additional fully paid weeks of parental leave on top of government-provided leave, so you can spend more time with your new addition

📈 **Our equity participation program** allows you to share in our success

For more information on our benefits, [visit this page.](https://commercetools.com/careers/our-benefits)

**Come as you are. Build with us.**

Your unique perspective is essential to our success. We are committed to building a team that reflects the world around us because we know it’s the only way to build the future. We celebrate our differences and have created a hiring process that’s fair, inclusive, and designed to let your talent shine.

We proudly welcome applicants of every race, color, religion, gender identity, sexual orientation, age, and any other part of your identity that makes you who you are. As an equal opportunity employer, we believe that our strength lies in our diversity, and we invite you to be a part of our global community.

For more information on our diversity, equity, inclusion, and belonging practices, [visit this page](https://commercetools.com/careers/dei-esg).

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
