# Account Executive, Enterprise

Posted: 2026-09-02T02:55:14Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

About **Zscaler**

Zscaler accelerates digital transformation to ensure our customers can be more agile, efficient, resilient, and secure. As an **AI-forward enterprise**, we are constantly pushing the envelope, leveraging the world’s largest security data lake to power our cloud-native Zero Trust Exchange platform. This innovation protects our customers from cyberattacks and data loss by securely connecting users, devices, and applications in any location.

Here, **impact in your role matters more than title** and trust is built on results. We say, impact over activity. We seek innovators who actively use AI to amplify their impact and who thrive in an environment where we leverage intelligent systems to stay ahead of evolving threats. We believe in transparency and value **constructive, honest debate**—we’re focused on getting to the best ideas, faster. We build high-performing teams that can make an impact quickly and with high quality. To do this, we are building a culture of execution centered on **customer obsession**, collaboration, ownership, and accountability.

We value high-impact, high-accountability with a sense of urgency where you’re enabled to do your best work and embrace your potential. If you’re driven by purpose, thrive on solving complex challenges, and want to be part of the team that’s helping to secure the AI age, we invite you to bring your talents to Zscaler and help shape the future of cybersecurity.

[ ](https://share.synthesia.io/35a0c2a2-c772-4d2a-b571-808b7462c25f)

**Role**

We are looking for an Account Executive to join our team. This is a hybrid role based in Germany, reporting to the Sales Director in the Enterprise sales department. The Zscaler Sales and Go-to-Market team is a global group of professionals who are passionate about delighting our customers and driving a secure, cloud-enabled digital future. In this role, you will take ownership of an assigned territory to demonstrate the power and agility of Zscaler cloud transformation and further cement our position as the world leader in cloud security.

**What you’ll do (Role Expectations)**

- Take ownership of an assigned territory in Germany focused on net new logo and up-sell opportunities with Enterprise prospects and customers

- Demonstrate expertise in building business cases that clearly show value and differentiation at all levels of your customer and prospect organizations

- Generate pipeline using new techniques, tools, joint field marketing initiatives, and top-tier channel partners including VAR, SI, and SP

**Who You Are (Success Profile)**

- You thrive in ambiguity. You're comfortable building the path as you walk it. You thrive in a dynamic environment, seeing ambiguity not as a hindrance, but as the raw material to build something meaningful.

- You act like an owner. Your passion for the mission fuels your bias for action. You operate with integrity because you genuinely care about the outcome. True ownership involves leveraging dynamic range: the ability to navigate seamlessly between high-level strategy and hands-on execution.

- You are a problem-solver. You love running towards the challenges because you are laser-focused on finding the solution, knowing that solving the hard problems delivers the biggest impact.

- You are a high-trust collaborator. You are ambitious for the team, not just yourself. You embrace our challenge culture by giving and receiving ongoing feedback—knowing that candor delivered with clarity and respect is the truest form of teamwork and the fastest way to earn trust.

- You are a learner. You have a true growth mindset and are obsessed with your own development, actively seeking feedback to become a better partner and a stronger teammate. You love what you do and you do it with purpose.

**What We’re Looking for (Minimum Qualifications)**

- Foundational understanding of AI/ML technologies and experience leveraging, securing, or positioning AI-driven solutions to optimize outcomes within your functional domain

- 3+ years of sales experience with a revenue quota, selling to Enterprise accounts in Germany

- History of net new logo accomplishments and a clear understanding of how to leverage channel partnerships

- Willingness to be coached and the discipline to work a proven sales process from beginning to end

- Evidence of successful "team sales" and the ability to leverage internal resources and partners

- Fluency in German

**What Will Make You Stand Out (Preferred Qualifications)**

- Experience leveraging AI-powered sales intelligence, predictive forecasting, or conversational AI platforms to optimize enterprise territory planning and pipeline acceleration

- Proficiency in strategic sales planning with experience closing net new logos

- A consistent track record of winning business in Enterprise accounts

#LI-Hybrid #LI-MM5

Zscaler’s salary ranges are benchmarked and determined by role and level. The range displayed on this job posting reflects the minimum and maximum target for new hire base salaries for this position across all Germany locations. Individual pay placement within this range is determined based on objective, gender-neutral criteria including job-related skills, relevant experience, and education or training. The base salary range listed for this full-time position excludes commission/bonus/equity (if applicable) and benefits.

Base Pay Range

€82.250—€117.500 EUR

At Zscaler, we are committed to building a team that reflects the communities we serve and the customers we work with. We foster an inclusive environment that values all backgrounds and perspectives, emphasizing collaboration and belonging. Join us in our mission to make doing business seamless and secure.

Our Benefits program is one of the most important ways we support our employees. Zscaler proudly offers comprehensive and inclusive benefits to meet the diverse needs of our employees and their families throughout their life stages, including:

- Various health plans

- Time off plans for vacation and sick time

- Parental leave options

- Retirement options

- Education reimbursement

- In-office perks, and more!

Learn more about Zscaler's hybrid working model and benefits [here](https://www.zscaler.com/candidate-resource-hub).

By applying for this role, you adhere to applicable laws, regulations, and Zscaler policies, including those related to security and privacy standards and guidelines.

Zscaler is committed to providing equal employment opportunities to all individuals. We strive to create a workplace where employees are treated with respect and have the chance to succeed. All qualified applicants will be considered for employment without regard to race, color, religion, sex (including pregnancy or related medical conditions), age, national origin, sexual orientation, gender identity or expression, genetic information, disability status, protected veteran status, or any other characteristic protected by federal, state, or local laws. *See more information by clicking on the *[*Know Your Rights: Workplace Discrimination is Illegal *](https://www.eeoc.gov/sites/default/files/2023-06/22-088_EEOC_KnowYourRights6.12ScreenRdr.pdf)*link.*

Pay Transparency

Zscaler complies with all applicable federal, state, and local pay transparency rules.

Zscaler is committed to providing reasonable support (called accommodations or adjustments) in our recruiting processes for candidates who are differently abled, have long term conditions, mental health conditions or sincerely held religious beliefs, or who are neurodivergent or require pregnancy-related support.

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
