# Staff Software Engineer (Ruby or GOlang)

Posted: 2026-09-01T23:55:08Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

# **About Workato**

Workato is the leading Control and Execution Platform for Enterprise AI — the neutral platform enterprises trust to put AI to work across their business. Workato unifies data, applications, and processes into a single platform so AI can reliably orchestrate business processes in production at enterprise scale. Built on more than a decade of running mission-critical processes for over half the Fortune 500 — including Nasdaq, Amazon, Cisco, Vodafone, Atlassian, and Lucid Motors — Workato turns over 14,000 enterprise systems AI needs to act on into one governed execution layer. For more information, visit [workato.com](https://www.workato.com/).

# **Why join us?**

Ultimately, Workato believes in fostering a **flexible, trust-oriented culture that empowers everyone to take full ownership of their roles**. We are driven by **innovation **and looking for** team players **who want to actively build our company.

But, we also believe in **balancing productivity with self-care**. That’s why we offer all of our employees a vibrant and dynamic work environment [along with a multitude of benefits](http://www.workato.com/careers) they can enjoy inside and outside of their work lives.

If this sounds right up your alley, please submit an application. We look forward to getting to know you!

Also, feel free to check out why:

-

[Business Insider](https://www.businessinsider.com/47-enterprise-startups-to-bet-your-career-on-in-2020-2019-12) named us an “enterprise startup to bet your career on”

-

[Forbes’ Cloud 100](https://www.forbes.com/cloud100/#a57477b5f941) recognized us as one of the top 100 private cloud companies in the world

-

[Deloitte Tech Fast 500](https://www2.deloitte.com/us/en/pages/technology-media-and-telecommunications/articles/fast500-winners.html) ranked us as the 17th fastest growing tech company in the Bay Area, and 96th in North America

-

[Quartz](https://qz.com/work/2053446/the-best-companies-for-working-from-home/) ranked us the #1 best company for remote workers

# **Responsibilities**

We are looking for an exceptional Staff Backend Developer (Ruby/Go) to join our growing Engine team. The Engine team develops and maintains most things related to Workato Recipe runtime. Everything related to recipe execution: DSL, pulling events, processing webhooks, executing jobs. There are various aspects to it: performance, scaling, storage, durability, atomicity, concurrency guarantees, data protection, and encryption.

In this role, you will also be responsible to:

-

We also consider strong Ruby-only candidates, as well as Golang-only candidates who are open to learning new languages.

-

Be a key contributor to the architecture and design of distributed applications with strict requirements for performance and resilience.

-

Build/extend/troubleshoot/fix complex heterogeneous Golang/Ruby applications, as well as small self-contained Golang microservices.

-

Write well-designed, testable, efficient code in Ruby and Golang.

-

Integration of data storage solutions Postgres/S3/Redis/Kafka/ClickHouse etc.

-

Contribute in all phases of the development lifecycle.

-

Provide code reviews to your teammates.

-

Provide technical leadership. Work with other teams on shared projects.

-

Evaluate and propose improvements to existing systems.

-

Identify bottlenecks and bugs, and devise solutions to these problems.

-

Help maintain code quality, organization and automatization.

# **Requirements**

### **Qualifications / Experience / Technical Skills**

-

Strong experience in building scalable distributed backend applications (7+ years).

-

Excellent understanding of distributed systems patterns and algorithms.

-

Great understanding of all building blocks of large web applications: databases, load balancers, application servers, message brokers, caching, monitoring, etc.

-

Excellent understanding of network protocols and stacks.

-

Excellent understanding of DB technologies: classic databases and modern no-SQL.

-

Knowledge of all common basic data structures and algorithms and how they are used is a must.

-

Multilingual programming experience: our code base is primarily in Ruby, with a trend to migrate to GOlang and Rust. At least two languages are required.

-

At least basic understanding of cloud deployments (k8s, Terraform, ArgoCD)

-

Experience of working with public cloud infrastructure providers(AWS/Azure/Google Cloud).

-

Excellent debugging, analytical, problem solving, and social skills.

-

BS/MS degree in Computer Science, Engineering or a related subject, 7+ years of industry experience.

### **Soft Skills / Personal Characteristics**

-

Background in GOlang, Rust, WASM, Kotlin-multiplatform.

-

Background in network programming.

-

Background in application, data security.

-

Deep knowledge of physical DB design.

-

Experience of working with Docker and other isolation technologies.

-

Experience in related fields (DevOps, ML, DBA, Enterprise applications, etc).

-

Experience in building/deploying data processing pipelines is a plus.

-

Experience of working with third-party REST APIs at scale (request throttling, batch processing etc).

### **Soft Skills / Personal Characteristics**

-

Ability to technically lead projects. Work with requirements, cost analysis.

-

Readiness to work remotely with teams distributed across the world and timezones.

**(REQ ID: 2582)**

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
