# Chief of Staff

Posted: 2026-09-01T23:40:12Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**About BoWatt**

BoWatt is building **agentic requirements and system engineering software for manufacturing**. We believe AI will reach **PhD-level engineering capability within the next 10 years**. This will unlock massive value across several complex manufacturing industries. Cars. Planes. Rockets. Factories. Chips. Medical devices. All will be engineered with agents.

We bootstrapped BoWatt to** €500k+ ARR** before raising our first round. BoWatt is backed by** tier-1 investors**, including Atlantic Foodlabs, Buildery (CDTM affiliates), and Prequel Ventures, along with angels from Cohere and Luminovo.

You’ll join a small, exceptional team of startup builders, driven by innovation and execution. **Over half the team are former founders** across DeepTech AI, psychedelics, and gaming. We’ve studied and worked at top institutions and companies like** Stanford, TUM, Google, EA**, and** YC**-backed AI startups.

**The role**

-

Partner with our CEO, Steven, to set priorities, make trade-offs, and ensure the company stays focused on the work that matters most

-

Take on whatever's breaking, slowing us down, or the bottleneck to our growth

-

Drive important projects from definition through execution, working across fundraising, product, engineering, sales, customer success, people, and operations

-

Own and improve key people operations, including hiring plans, recruiting processes, onboarding, team development, and company culture

-

Impactful culture and energy setter across the company. Build deep relationships with everyone, be an "always on" context connector across the company.

-

Take ownership wherever the company most needs it. The scope of the role will evolve alongside BoWatt

**You**

-

**Exceptional** **Generalist**: you are an exceptional generalist who can quickly understand unfamiliar problems and turn ambiguity into a clear plan

-

**Clear communicator**: you write clearly, speak confidently, and know how to get to the point

-

**High judgment**: you have strong judgment and know how to prioritize when everything feels important

-

**Speed**: you thrive in a fast-moving startup environment where responsibilities are broad, priorities can change, and there is significant freedom to shape how the company operates

-

**Team-oriented**: you build trust across different teams and can align people without relying on formal authority

-

**Ambitious:** You set a high bar for yourself and care deeply about outcomes

**What we offer**

-

Competitive salary based on experience

-

5–10% virtual equity package

-

25 vacation days/per yr, plus public holidays

-

Company retreats

-

WellPass membership

**Interview process**

-

20 min Screening interview

-

90 min Case interview

-

60 min Culture fit interview

-

Reference calls

-

Offer

We aim to complete the interview process within 14 days.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
