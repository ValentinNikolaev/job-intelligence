# Product

Posted: 2026-09-02T02:40:10Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

## About Atira

**Atira builds the commercial brain for industrials.** Our agents 10x the sales engineers of today by offering the complete toolbox of tasks needed in complex environments. They handle everything from extracting and classifying requirements from incoming RFQs, to orchestrating communication and information retrieval across multiple stakeholders and systems, to generating outcomes like documentation, production system inputs, or configuration recommendations. **CRM. Atira. ERP.**

We are one of the fastest growing teams in Munich and are looking for you to join us!

## Why Product is the only role that sees the whole thing

*"If I had asked people what they wanted, they would have said faster horses.” - Henry Ford*

Our FDEs go deeper into a single customer than anyone else at Atira. What nobody can see from inside one account is the shape that all the accounts share. You hold the version of the problem that is bigger than any single customer's description of it, and you break it into steps small enough to ship every month.

Then you defend it. Every deployment produces requests: A few are the next platform feature, most are a customer-specific detour that should never be touched. You are the person who cares the most about consolidating solutions and has the technical depth to do something about it, which means you decide what comes in and what does not.

As Atira scales we build industry-specific pods: FDE, AE, BDR and Product Marketer, led by a GTM Engineer. Pods go deep. Product goes wide. Everything a pod learns has to end up in one platform, and you are the reason it does. Make sure we do not chase faster horses.

## What you will do

-

**Own the problem, not the request.** You understand which customer's ask is part of which bigger problem and you hold the maximum version of where this goes. Then you do the more challenging half: turning it into opinionated steps that ship, each one compounding into the next, so what we build becomes a staircase instead of a pile of features

-

**Decide what scales and what doesn't.** You sit at the boundary between customer work and the core engineering team. You turn recurring patterns into features and you kill the rest. In an ideal world you are opinioonated on every FDE PR that touches shared code or introduces a customer-specific path

-

**Build the agents that make Atira work.** You go deep on each customer's technical sales process, understanding it in all its details. You extend our harness to solve the most complex job functions of our users: how to configure machines according to the engineering experts, how to price large service agreements for billion dollar infrastructure projects, or how to automate the multi-stakeholder internal communication. And you can translate that into code

-

**Ship the platform end to end.** Full-stack feature conceptualization and execution, from the harness through the UI a sales engineer actually uses

-

**Collect Feedback** in front of the users that ultimately are your sounding board

## What we are looking for

Taste, ownership, and systems thinking. You can build almost anything now, which makes judgment about what to build the bottleneck. You see the problem behind the request, you decide in the absence of a brief, you say no to founders and to customers with reasoning that survives the room, and you own the outcome including the downside.

**Your profile**

-

**Systems thinking, in both directions.** Upward: you find the problem behind the request and can hold a version of it bigger than what any single customer describes. Downward: you see the second-order effects, that one per-customer config field means a migration on every future deployment and one more thing every FDE explains in onboarding.

-

**Taste you can point at.** You can show us things you have built and shipped that you are proud of, and a clear opinion on what you deliberately left out.

-

**Deep software engineering fundamentals underneath a native use of agents.** Strong Python, TypeScript or a related language. You judge and ship production-grade code, and you can review someone else's. Practical exposure to AI engineering (agents, harnesses, evals, RAG), deeper system design understanding or infra knowledge

-

**Demonstrated ownership and initiative:** a company you started, a leading role in a student initiative, an open-source project, a serious side build, or a role where you owned an outcome others would have delegated

-

**You get excited by complex hardware.** You can explain in your own words why an agentic sales engineer at an ETO manufacturer is a business worth building, and what Atira is trying to become

## What you'll get

-

**Real ownership:** you'll be one of the early team members and shape both product and architecture as well as work closely with customers

-

**Strong peers:** work with people who have built and shipped AI systems in industrial environments at scale before, and the chance to learn directly from them

-

**Impactful work:** your code is deployed all across Europe's and US industrial backbone, affecting how complex products and services are sold and configured worldwide

-

**Competitive salary & equity package** and additional benefits including Wellpass, JobRad and company dinners

-

**Most importantly:** collaborate & thrive in a high-performing but caring culture. We will own the industrial sales function, but we will do so with modesty and integrity

## What success looks like after a few months

-

Someone new can hear you describe what we are building and walk away with the same picture the founders have, plus a clear view of which step comes next

-

You have contributed your own thoughts to our general product vision and conceptualized a clear path forward to implement high prio features

-

You have shipped full-stack features and agents into production that are used across multiple accounts, and every one of them came from a request that showed up at more than one customer

-

The FDEs say the platform got easier to deploy, not harder

-

Your no's carry as much weight as your yes's, with the founders and with customers

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
