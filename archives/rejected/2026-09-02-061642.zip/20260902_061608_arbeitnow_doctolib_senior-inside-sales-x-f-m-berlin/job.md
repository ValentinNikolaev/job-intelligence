# (Senior) Inside Sales (x/f/m) Berlin

Posted: 2026-09-01T23:55:04Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

## Job Description

### Großer Markt, perfektes Timing: Deine Verantwortung

Der deutsche Gesundheitsmarkt befindet sich an einem entscheidenden Wendepunkt – und Du digitalisierst ihn, Praxis für Praxis. Als (**Senior) Inside Sales (x/f/m) in Berlin** verantwortest Du Deinen Vertriebsbereich wie ein eigenes Business und bringst mit unserer KI-gestützten All-in-One-Lösung echten Mehrwert direkt in den Praxisalltag.

Du führst Deine Kund:innen strukturiert und souverän durch den gesamten Vertriebsprozess – digital, telefonisch und per Video. Dabei nutzt Du Deine Vertriebserfahrung, um Entscheider:innen im Gesundheitswesen zu beraten, nachhaltige Kundenbeziehungen aufzubauen und aktiv zum weiteren Wachstum von Doctolib beizutragen.

Die Chance, die vor uns liegt, ist noch weit größer als das, was wir bisher aufgebaut haben.

###

### Deine Aufgaben

- **Eigenverantwortlicher Vertrieb:** Du begleitest den gesamten Sales-Prozess – von der ersten Kontaktaufnahme über die Bedarfsanalyse und Produktpräsentation bis zum erfolgreichen Abschluss.

- **Umsatz & Wachstum:** Du verantwortest Deine Pipeline, den Umsatz (MRR), Deine Kundenbeziehungen und das Wachstum in Deinem Vertriebsbereich.

- **Kundenzentrierte Beratung:** Du analysierst die Bedürfnisse von Ärzt:innen und medizinischen Einrichtungen, verstehst ihre Herausforderungen und überzeugst sie von unserer digitalen Lösung.

- **Inside-Sales-Ansatz:** Du führst Deine Kundentermine telefonisch sowie per Video durch und sorgst für eine professionelle und persönliche Beratung über digitale Kanäle.

- **Datengetriebene Erfolgsmessung:** Du trackst Deine Performance regelmäßig in Salesforce und nutzt Daten, um Deine Vertriebsstrategie gezielt weiterzuentwickeln.

- **Seniorität & Verantwortung:** Du bringst Deine Erfahrung aktiv ins Team ein, teilst Best Practices und unterstützt bei der Weiterentwicklung unserer Sales-Prozesse.

- **Cross-funktionale Zusammenarbeit:** Du arbeitest eng mit internen Teams wie Marketing, Customer Success und Operations zusammen, um eine optimale Customer Experience sicherzustellen.

###

### Dein Profil

- **Sales ist Deine Welt:** Du verfügst über mindestens 1**–3 Jahre Erfahrung im Vertrieb**, idealerweise im B2B- oder SaaS-Umfeld.

- **Proaktivität und Akquise-Talent:** Du überzeugst durch exzellente Akquise-, Discovery- und Pitching-Skills.

- **Erfahrung im Abschluss:** Du hast nachweisbare Erfolge im eigenständigen Management eines Sales Funnels und im erfolgreichen Abschluss von Vertriebsprozessen.

- **Energie & Überzeugungskraft:** Du verkaufst mit Leidenschaft, trittst sicher und professionell auf und kannst unterschiedliche Gesprächspartner:innen für Deine Lösung begeistern.

- **Entrepreneurial Mindset:** Du bist ergebnisorientiert, verfügst über ein hohes Organisationsgeschick und behältst auch bei Herausforderungen den Fokus.

- **Kommunikation auf Top-Niveau:** Du kannst Dich **sehr gut mündlich und schriftlich auf Deutsch (C1-Niveau oder höher)** ausdrücken.

- Für unsere internen Trainings, All-Hands und den Austausch mit internationalen Kolleg:innen ist es hilfreich, wenn Du Englisch gut verstehen kannst. Falls Du Dich sprachlich noch weiterentwickeln möchtest, unterstützen wir Dich gerne mit entsprechenden Lernangeboten. Perfektes Englisch ist keine Voraussetzung. Deine Kundentermine finden auf Deutsch statt.

- **Teamorientierung & Eigenverantwortung:** Du arbeitest selbstständig, strukturiert und zuverlässig und hast Freude daran, Verantwortung zu übernehmen und Dein Wissen mit anderen zu teilen.

Du bist der festen Überzeugung, dass Du genau das mitbringst, was es für die Position braucht? Dann ermutigen wir Dich, Dich zu bewerben. Selbst wenn Du nicht jede Anforderung erfüllst, bist Du vielleicht genau die/der richtige zukünftige Doctoliber:in für diese oder andere Stellen!

###

### Was wir Dir bieten

- Ein gefördertes Sportangebot mit unserem Partner Urban Sports Club

- Eine private Krankenzusatzversicherung mit individuellen Zusatzleistungen, unter anderem Zahnreinigung

- 28 Urlaubstage plus 1 zusätzlicher Urlaubstag für jedes volle Beschäftigungs-Kalenderjahr, maximal 30 Tage

- Eine betriebliche Altersvorsorge mit einem Arbeitgeberzuschuss von 40 %

- Die Teilnahme an Doctolibs langfristigem Mitarbeiterbeteiligungsprogramm DoctoGrowth

- Das Doctolib Parent Care Programm, das unter anderem einen zusätzlichen Monat Elternzeit enthält

- Kostenlose Mental-Health- und Coaching-Sessions über unseren externen Partner [moka.care](http://moka.care/)

- Unterstützung für pflegende Betreuungspersonen und Beschäftigte mit Behinderungen, unter anderem durch flexiblere Arbeitszeiten, zusätzliche Freistellung aus medizinischen Gründen und psychologische Unterstützung

Wir sind ein ambitioniertes Team, das gewinnen will. Du auch? Dann bewirb Dich jetzt und werde Teil der Doctolib-Erfolgsgeschichte! Weitere Informationen zum Arbeitsalltag im Sales bei Doctolib findest Du [hier](https://careers.doctolib.de/sales/).

## Der Interview-Prozess

- Interview mit unserem Talent Team – remote, 25 Minuten

- Interview mit der/dem Regional Manager:in bzw. Teamlead – remote, 60 Minuten

- DoctoDay: Verbringe einige Stunden mit Deinem zukünftigen Team und erhalte einen ersten Einblick in den Job als Senior Inside Sales

- Mindestens eine Referenzprüfung

## Job Details

- Festanstellung

- Vollzeit

- Berlin

- Zum nächstmöglichen Zeitpunkt

## Unsere Philosophie

*Wir verfolgen die Vision, die Gesundheit aller zu verbessern. Dies spiegelt sich auch im Recruiting wider. Wir evaluieren Bewerbungen ausschließlich auf der Grundlage von Qualifikation und Motivation. Diskriminierung wird bei uns nicht toleriert.*

*Je diverser unser Team und die Ideen sind, desto mehr wird unser Produkt die Gesundheit unserer Nutzer:innen verbessern können. Deshalb laden wir Dich ein, Dich bei uns zu bewerben – unabhängig von Geschlecht, Religion, Alter, sexueller Orientierung, ethnischer Herkunft oder Behinderung.*

*Um Chancengleichheit zu gewährleisten, kannst Du in Deiner Bewerbung auf Angaben wie Fotos, Alter etc. verzichten. Lass uns bitte wissen, welche Vorkehrungen wir treffen können, um Dich bestmöglich zu unterstützen. Wir freuen uns, mit Dir das Gesundheitswesen zu digitalisieren!*

*Alle bereitgestellten Informationen werden von Doctolib für das Bewerbungsmanagement verarbeitet. Für Details zur Datenverarbeitung klicke bitte [hier](https://media.doctolib.com/image/upload/v1678356494/legal/Career-Privacy-Policy-Feb-23-EN.pdf).*

*Bei Fragen oder wenn Du Deine Rechte wahrnehmen möchtest, wende Dich bitte an hr.dataprivacy(at)[doctolib.com](http://doctolib.com/).*

###

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
