# Data Scientist (m/w/d)

Posted: 2026-09-19T08:30:28Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

***Make impact. Be human. Stay curious.***

#### **Who we are**

Founded in 2006, Rewire is an applied AI company helping organizations reinvent how they work with data and AI. We partner with leading organizations across industries to create scalable business impact by solving complex challenges through data, AI, and technology. Our team of 100+ data scientists, engineers, and change agents operates across Europe from offices in the Netherlands and Germany. Strategic in intent and pragmatic in execution, we combine deep Data & AI expertise with close, committed collaboration.

Collaboration, knowledge sharing, and continuous learning are at the heart of our culture. Through topic communities, expert colleagues, and our internal academy, GAIN, you'll have plenty of opportunities to develop your skills in areas such as Agentic AI, Data Strategy, AI Product Development, and Technology Platforms, while helping clients achieve measurable results.

Join a team that loves learning, solving challenges together, and having fun along the way. **Ready to join the ride?**

#### **Where you’ll make a difference**

-

**Drive** data & AI projects forward – analyze data, build models, and deliver insights that create real business impact

-

**Apply** cutting-edge machine learning techniques – solve complex, real-world problems with innovative approaches

-

**Develop** algorithmic solutions – take ownership of your work and help transform high-impact business processes

-

**Contribute** to organizational change – implement data & AI innovations supported by GAIN®, our certified education and training portfolio

-

**Use** technical expertise and communication skills – build scalable data & AI solutions that drive value across the organization

-

**Collaborate **with cross-functional teams – contribute from day one while learning from experienced leaders

#### **What makes us the right choice for you**

-

**Be part of groundbreaking change **as we scale a business in a fast-evolving industry with a dedicated international growth strategy, a team of experts, and the support of an experienced investor

-

**Step into a role **where you contribute ideas, support innovation, and help shape how organizations use data & AI to create real impact

-

**Deepen your skills in data & AI** – gain exposure to diverse industries, tackle real-world challenges, and grow through hands-on projects and expert mentorship in a future-focused environment

-

**Join a vibrant, multidisciplinary team **that’s ambitious, collaborative, and just the right amount of nerdy – where learning and laughter go hand in hand

-

**Work alongside clients as a valued team member **– building relationships based on trust, shared goals, and face-to-face collaboration whenever it matters most

-

**Thrive in a culture **that values autonomy, curiosity, and bold thinking – where your voice matters, ideas turn into action, and your impact is genuinely recognized and rewarded

#### **What makes you shine**

You’re a motivated problem solver and a curious learner – with a passion for turning data & AI into real business impact. You’ll thrive with us if you bring:

-

**A Master’s degree** with excellent results in a **quantitative or STEM field** (e.g., Data Science, Statistics, Computer Science, Mathematics, Physics)

-

**Practical experience** through internships, projects, or research – demonstrating your ability to work with data, build models, and extract actionable insights

-

**A hands-on, growth mindset** – you take ownership of your tasks, embrace challenges, and contribute to solutions that create real value

-

**Strong communication skills** and a **collaborative spirit** – you enjoy working in teams, explaining technical concepts clearly, and supporting a positive, inclusive work environment

-

**Sharp analytical and technical skills** – you excel at both problem-solving and implementing solutions that bridge business and technology

-

**Fluency** in both **English and German** (written and spoken), and **willingness to travel** regularly to client sites

***If you're hesitating because you don't meet every requirement, don't let that hold you back. Strong candidates often underestimate how well they fit a role. If this opportunity excites you, we encourage you to apply!***

#### **Where you’ll work**

Many projects require working **onsite at client locations** throughout Germany (and occasionally Europe) for **several days per week**. Travel requirements vary **depending on the project and client needs**.

While our main office is located in Heidelberg, many of our team members are based across various cities in Germany. This reflects our flexible and distributed team structure, which means that relocation is not required.
At the same time, as we continue to grow our Heidelberg office, being located within reasonable travel distance is an advantage and helps facilitate collaboration.

#### **In their own words**

*“At Rewire, I have the opportunity to learn how to translate my theoretical knowledge into impactful applications across multiple industries and purposes. It is always exciting to engage in stimulating conversations with my colleagues and gain exposure to different analytical perspectives on how to tackle the same problem!” – ****Alex Lucchini, Data Scientist at Rewire***

** **

#### **Sound like your kind of team?**

Perfect! If you’re ready to kick-start your career and want to make real impact with data & AI, we’d love to hear from you.

**Apply now! **And let’s see where this journey takes us.

**Questions?** Feel free to ask them via ----- – we’re happy to chat.

** **

#### **Who you are matters to us!**

We welcome all applicants – regardless of gender, background, or LGBT+ identity – because diversity and inclusion are core values for us. We are convinced that a diverse and inclusive workplace fosters creativity, innovation, and success. 

We believe diverse teams build better solutions. We are committed to building a more diverse engineering team and particularly encourage women and other underrepresented groups in technology to apply. 

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
