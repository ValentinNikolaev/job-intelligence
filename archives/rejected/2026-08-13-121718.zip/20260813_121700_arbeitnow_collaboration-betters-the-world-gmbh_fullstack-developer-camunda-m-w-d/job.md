# Fullstack Developer Camunda (m/w/d)

Posted: 2026-08-13T08:00:29Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Willkommen bei CBTW! Wir sind ein innovatives Team mit über 3.000 Mitarbeitern in 21 Ländern und führend in den Bereichen Strategie & Governance, Software-Engineering, Datenanalyse & KI und mehr.

Als Mitglied unseres Teams bei CBTW arbeitest Du in einem inspirierenden Umfeld an anspruchsvollen Projekten. Wir fördern die Entwicklung der Experten von morgen und schätzen Deine Ideen. Wenn Du bereit bist, die Zukunft der datengetriebenen Transformation mit einem hochmotivierten Team zu gestalten, bewirb Dich jetzt bei CBTW! Zusammen schaffen wir Großartiges.

## Aufgaben

- Entwicklung und Implementierung komplexer Anwendungen als Fullstack Developer mit Schwerpunkt auf Java / J2EE, Spring Boot und modernen Frontend-Technologien (z. B. Angular, React)

- Integration und Modellierung von Prozessen mit Camunda BPM sowie deren Einbettung in bestehende Systemlandschaften

- Evaluierung und Einführung neuer Technologien, Frameworks und Best Practices

- Konzeption und Umsetzung neuer Features zur Lösung anspruchsvoller Kundenanforderungen

- Arbeit mit modernen Technologien und Cloud-Architekturen

- Enge Zusammenarbeit mit Kund:innen zur Analyse und Spezifikation individueller Anforderungen.

Dieses Wissen bietet unseren Kund:innen echten Mehrwert. Du bist das Bindeglied zwischen IT und Business. Du konzipierst. Du realisierst. Du treibst voran.

## Qualifikation

- Abgeschlossenes Studium in Informatik, Wirtschaftsinformatik oder vergleichbarer Fachrichtung

- Mehrjährige Erfahrung in der Java-Entwicklung sowie fundierte Kenntnisse in Spring Boot

- Erfahrung mit Camunda BPM (Modellierung, Implementierung und Deployment von Prozessen)

- Kenntnisse in Frontend-Technologien wie Angular oder React

- Erfahrung mit SQL- und NoSQL-Datenbanken sowie idealerweise mit Messaging-/Streaming-Plattformen (z. B. Apache Kafka)

- Reisebereitschaft innerhalb der DACH-Region.

- Verhandlungssichere Deutsch- und Englischkenntnisse (C1).

- Gehaltsspanne für diese Position (Medior-Level): 62.000 € – 72.000 € brutto/Jahr. Die finale Einstufung erfolgt abhängig von Erfahrung und Skillset

Es ist unwahrscheinlich, dass jede:r Kandidat:in all diese Anforderungen erfüllt. Wenn Deine Erfahrungen anders sind und Du glaubst, dass Du einen Mehrwert für die Position bieten kannst, lass uns gerne darüber sprechen!

## Benefits

Bei CBTW erwartet Dich mehr als nur ein Job – wir bieten Dir ein Umfeld, in dem Du wachsen, mitgestalten und ganz Du selbst sein kannst. Unsere Kultur lebt von Vertrauen, Eigenverantwortung und echter Zusammenarbeit – egal ob remote oder vor Ort. Wir treiben Innovation gemeinsam voran, feiern Erfolge und leben Vielfalt. Dass wir bereits fünf Jahre in Folge als „Top Company“ von kununu ausgezeichnet wurden, bestätigt uns in unserem Weg.

Das erwartet Dich bei uns:

🏁 **Onboarding & Teamspirit**

- Willkommenstag, Hello Drink & Newbie Lunch

- Mentoring-Programm für Deinen idealen Einstieg

- Afterwork-Events, Summer-Tech-Event & festliche Weihnachtsfeier

- Gemeinsames soziales Engagement bei Spendenaktionen

🚀 **Entwicklung & Karriere**

- Individuelle Karrierepfade & regelmäßige Feedbackgespräche

- Vielfältige Inhouse-Trainings, Online-Kurse & externe Weiterbildungen

- Internationale Zusammenarbeit mit Kolleg:innen aus ganz Europa

🧘‍♀️ **Work-Life-Balance & Flexibilität**

- Remote Work & Workation – innerhalb der EU und darüber hinaus

- Sabbatical-Möglichkeiten & flexible Arbeitszeitmodelle

- Feiertagskalender Baden-Württemberg plus die Feiertage Deines Bundeslands – doppelter Benefit

- 30 Urlaubstage im Jahr

💼 **Ausstattung & Mobilität**

- Guthaben zur Ausstattung Deines mobilen Arbeitsplatzes

- Deutschlandticket oder Fahrradleasing – Du hast die Wahl

- Optional: BahnCard für noch mehr Reise-Flexibilität

🛡️ **Sicherheit & Vorsorge**

- Unterstützung bei Altersvorsorge & Vermögensaufbau

- Vielfältige Optionen zur finanziellen Absicherung

💡 **Wellbeing & Gesundheit**

- Zugang zum Employee Assistance Program (EAP) – auch für Angehörige

🎁 **Weitere Goodies**

- Prämien für besonderes Engagement

- Exklusive Vorteile über unsere Corporate Benefits-Plattform

- Unsere CBTW-Spotify-Playlist für einen musikalischen Eindruck vom Team 🎧

**Jetzt fehlst nur noch Du – wir freuen uns darauf, Dich kennenzulernen!**

🎵 Schau Dir unsere CBTW-Spotify-Playlist an: [CBTW auf Spotify hören](https://open.spotify.com/playlist/44kgWZRt5jmmgppH0qGszg?si=L312ch_9SMKsCKBcN-EB_A)

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
