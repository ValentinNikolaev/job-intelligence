# Technische Planung (m/w/d) Wärmepumpen & Heiztechnik - 1KOMMA5° Dortmund

Posted: 2026-08-13T09:00:41Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

## 1KOMMA5°

Bei **1KOMMA5°** verfolgen wir eine Vision: **Living on wind and sunlight forever for free**. Dafür bauen wir mit Heartbeat AI das Energiesystem der Zukunft. Bist du dabei?

Wir bringen regionales Handwerk und skalierbare Software zusammen: Solar, Speicher, Wärmepumpe und E-Mobilität denken wir nicht einzeln, sondern steuern sie als intelligentes, integriertes Gesamtsystem in unserem virtuellen Kraftwerk. Direkt verbunden mit dem Strommarkt – in Echtzeit, vollautomatisiert. So wird Energie dann genutzt, wenn sie erneuerbar verfügbar und besonders günstig ist. Bis 2030 wollen wir 1,5 Millionen Haushalte auf erneuerbare Energien umstellen. Über 3.000 Menschen arbeiten jeden Tag daran, an mehr als 80 Standorten weltweit, von Finnland bis Australien.

**Du willst Verantwortung übernehmen und Lösungen bauen, die wirklich zählen? Bewirb dich jetzt und gestalte mit uns die Energiewelt von morgen.**

## Deine Position

- Auswertung von Heizlastberechnungen für Wohnhäuser zur Beurteilung der Machbarkeit von Wärmepumpen, inklusive Erstellung von Hydraulikschema, Schalldämm- und JAZ-Berechnungen

- Technische Planung und Visualisierung von Wärmepumpensystemen mithilfe moderner Softwaretools, um eine korrekte technische Erfassung und Machbarkeit sicherzustellen

- Sicherstellung höchster Qualitätsstandards direkt vor Ort sowie technische Abnahme der Anlagen gemeinsam mit dem Kunden

- Unterstützung des Vertriebs und Auftragsmanagements bei technischen Fragen, Feedback zur Umsetzung und Durchführung technischer Produktschulungen

- Projektdokumentation einschließlich Erfassung, Organisation und Pflege technischer Spezifikationen, Installationsberichte und weiterer auftragsspezifischer Dokumente

- Enge Zusammenarbeit mit Expertenteams aus unterschiedlichen Fachbereichen für eine ganzheitliche Energieplanung

- Regelmäßiges Reporting an die Bereichsleitung über Status, Qualitätskennzahlen, Herausforderungen und Erfolge laufender Aufträge

## Dein Profil

- Ausgeprägtes „Customer First“-Mindset und Freude daran, Kunden bestmöglich zu unterstützen

- Abgeschlossene Meister- oder Technikerausbildung im Heizungsbereich oder eine vergleichbare Qualifikation, z. B. in der Versorgungstechnik

- Erfahrung in der technischen Planung von Wärmepumpen, Heizungshydraulik und konventionellen Heizungssystemen von Vorteil

- Strategisches und analytisches Denkvermögen sowie Begeisterung für technische Themen

- Hohe Zuverlässigkeit, Verantwortungsbewusstsein und Lust auf die Energiewende

## Benefits

- Unbefristeter Arbeitsvertrag mit attraktiver Vergütung

- Moderne Arbeitsausstattung für effizientes Arbeiten

- Kommunikation auf Augenhöhe und kurze Entscheidungswege

- Möglichkeit, aktiv mitzugestalten und einen Beitrag zur Energiewende zu leisten

- Vergünstigter Zugang zu Fitnessstudios, Schwimmbädern und Sportangeboten über Wellpass

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
