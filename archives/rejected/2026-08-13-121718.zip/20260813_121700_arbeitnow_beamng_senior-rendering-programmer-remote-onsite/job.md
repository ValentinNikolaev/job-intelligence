# Senior Rendering Programmer (Remote/Onsite)

Posted: 2026-08-13T08:20:15Z

## Rejection

- Category: tech_stack
- Reason: role does not mention Go/Golang or PHP

**Role description**

BeamNG is an independent game & software development studio, established in 2013 in Bremen, Germany. We are an international, remote-first team of almost 90 people. Our development focuses on state-of-the-art soft-body physics vehicle simulation, currently available as an early access videogame - [BeamNG.drive](https://www.beamng.com/game/), and as a stand-alone research platform - [BeamNG.tech](https://beamng.tech/)

To support our ongoing and future development plans, we are looking for an experienced Rendering Programmer with strong C++ expertise and a solid background in real-time rendering. This person should be comfortable working independently within a proprietary engine environment and capable of taking ownership of complex, long-term development projects from concept through to completion.

**Technical Responsibilities:**

- Immerse yourself in our proprietary C++ game engine and renderer, improving its internals in ways that are typically out of reach when using common engines.
- Work across our graphics backends, including DirectX 11, DirectX 12, Vulkan, and console APIs, ensuring features remain consistent, correct, and performant on every platform we support.
- Implement and improve rendering features end to end.
- Optimize GPU and CPU frame time and memory usage.
- Write simple, maintainable code designed for long-term sustainability.
- Quickly learn new areas of the codebase independently, as required for each task.
- Apply knowledge of linear algebra, vectors, and geometric principles.
- Investigate and resolve GPU vendor-, driver-, and hardware-specific issues reported across a wide range of player hardware.
- Assist with build scripts, library integrations, and continuous integration.

**Non-Technical Responsibilities:**

- Be active and participate in internal chat conversations, keeping track of those that may affect engine and renderer development.
- Take full ownership of the advancement of your assigned projects with minimal oversight.
- Work closely with artists and technical artists to turn visual goals into something that runs in real time.
- Assist and guide other developers in the right direction, occasionally doing minor code reviews.

**Requirements**

- Proven track record of creating or modifying rendering code in a custom or proprietary engine.
- Solid foundation in C++ programming and real-time rendering, with at least 5 years of experience.
- Experience with fundamental multithreading primitives and parallel command recording.
- Hands-on experience with at least one modern graphics API, such as DirectX 12, Vulkan, or a console equivalent, as well as shader authoring in HLSL or GLSL, including compute shaders.
- Strong understanding of the real-time rendering pipeline and GPU hardware, including rasterization, lighting and shadowing, materials, post-processing, synchronization, and resource lifetimes.
- Comprehensive understanding of memory management and optimization strategies for both CPU and GPU.
- Strong mathematical knowledge required for real-time rendering, including linear algebra, vectors and matrices, coordinate spaces, geometry, and color spaces.
- Knowledge of GPU and CPU performance profiling and debugging tools, such as RenderDoc, PIX, Nsight, or vendor profilers.
- Proven ability to take ownership of projects and drive initiatives to successful completion.
- Excellent written and spoken English communication skills; additional languages are a plus

**Nice to have**

- Experience developing your own custom engine or renderer as a personal or hobby project.
- Experience supporting multiple graphics backends through a shared abstraction layer.
- Console development experience.
- Familiarity with shader compilation toolchains and cross-compilation, such as DXC and SPIR-V, as well as shader permutation systems.
- Willingness to provide programming mentorship and conduct code reviews.
- Proficiency in Linux programming and scripting.
- Knowledge of CI, troubleshooting build issues, and integrating new libraries and platforms.
- VR rendering experience.

**Benefits**

- Flexible working hours
- Language courses
- Talent development program (training budget, participation in seminars/conferences, etc)
- Personal development program (feedback, leadership, conflict engagement, etc)
- Parental leave
- Employee assistance program
- Relocation assistance (if applicable)

**Our recruitment process**

Our recruitment process starts with an introductory call with our HR team, continues with a technical interview with Lead Game Engine Programmer and the Lead Rendering Programmer, and finally a stakeholder interview

**About us**

Our journey began in 2013 and we've continued to expand as an independent studio since then. We are a team of over 90 employees of 26 nationalities with a headquarters in Bremen, Germany, and we are always on the lookout for expert talent to join us!

We consider our employees to be our most valuable assets, and all of them play a vital role in helping us establish and nurture the company's culture and values. We are a guild of innovators, artists, engineers, and designers, who appreciate and embrace the diversity of our perspectives and know-how to apply them to grow together as a community and foster a healthy work environment.

Together, we are building a safe and inclusive atmosphere, with transparent processes to amplify individuality, empathy, respect, creativity, and continuous learning for all employees. Regardless of your identity or background, we would be happy to welcome your application if you feel inspired and want to become a part of our team! Skip writing lengthy cover letters and tell us more about your passion for gaming and why specifically BeamNG. Do not be discouraged if you don’t meet all the criteria for a specific role, feel free to submit an unsolicited application.

To minimize bias throughout the hiring process, please submit your application in English.

#LI-Remote

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
