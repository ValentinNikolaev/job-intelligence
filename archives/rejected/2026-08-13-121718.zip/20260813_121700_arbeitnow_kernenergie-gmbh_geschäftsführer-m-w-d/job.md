# Geschäftsführer (m/w/d)

Posted: 2026-08-13T10:00:39Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Als Deutschlands exklusiver Anbieter für Premium-Nüsse, Trockenfrüchte, Schokoladen- und Genussprodukte begeistern wir seit vielen Jahren Unternehmen, Premiumhotels und Endkund:innen gleichermaßen. Mit unserer Kombination aus hochwertigen Produkten, eigener Produktion, E-Commerce-Kompetenz und starken Kundenbeziehungen haben wir uns erfolgreich im Markt etabliert.

Nun möchten wir die nächste Wachstumsphase gestalten.

**Wir suchen einen Geschäftsführer (m/w/d) – B2B, Wachstum & Unternehmensentwicklung**

KERNenergie verfügt über eine starke Marke, hochwertige Produkte, langjährige Kundenbeziehungen und ein engagiertes Team.

Die Grundlage ist geschaffen.

Die zentrale Aufgabe dieser Rolle besteht darin, daraus die nächste Wachstumsphase zu entwickeln.

Insbesondere sehen wir erhebliches Potenzial im weiteren Ausbau unseres B2B-Geschäfts – von Premiumhotels über Firmenkunden bis hin zu neuen Geschäftsfeldern, Vertriebskanälen und Partnerschaften.

Für diese Aufgabe suchen wir eine unternehmerische Persönlichkeit als Geschäftsführer (m/w/d), die Verantwortung übernimmt, Wachstum gestaltet und gemeinsam mit den Gesellschaftern die Zukunft von KERNenergie entwickelt.

## Aufgaben

Du übernimmst gemeinsam mit den Gesellschaftern die Verantwortung für die Weiterentwicklung von KERNenergie und gestaltest aktiv die nächste Wachstumsphase unseres Unternehmens.

Der Schwerpunkt dieser Rolle liegt auf Wachstum, Geschäftsentwicklung und dem Ausbau unseres B2B-Geschäfts.

Du entwickelst neue Kunden, neue Geschäftsfelder und neue Umsatzpotenziale. Dabei verbindest du strategisches Denken mit operativer Umsetzung und sorgst dafür, dass aus Ideen messbare Ergebnisse werden.

- Du gewinnst neue Kunden und baust langfristige Geschäftsbeziehungen auf

- Du entwickelst bestehende B2B-Kunden strategisch weiter

- Du erschließt neue Geschäftsfelder, Marktsegmente und Vertriebskanäle

- Du identifizierst neue Umsatzpotenziale und setzt diese konsequent um

- Du entwickelst unsere vertrieblichen Prozesse, CRM-Strukturen und digitalen Lead-Prozesse weiter

- Du arbeitest eng mit Produktion, Einkauf, Marketing, E-Commerce und Vertrieb zusammen

- Du sorgst dafür, dass alle Bereiche gemeinsam auf profitables Wachstum ausgerichtet sind

- Du erkennst Marktchancen frühzeitig und übersetzt diese in konkrete Ergebnisse

Kurz gesagt:

Du übernimmst die Geschäftsführung eines etablierten Unternehmens mit dem klaren Auftrag, die nächste Wachstumsphase von KERNenergie zu gestalten.

## Qualifikation

- Mehrjährige Erfahrung in einer Geschäftsführungs-, Vertriebs-, Business-Development- oder Wachstumsverantwortung mit nachweisbaren Ergebnissen

- Nachweisbare Erfolge im Aufbau von B2B-Umsätzen, Neukunden und Geschäftsfeldern

- Unternehmerisches Denken und die Fähigkeit, Strategie und operative Umsetzung miteinander zu verbinden

- Freude daran, selbst aktiv Kunden zu gewinnen, Chancen zu erkennen und neue Wege zu gehen

- Erfahrung im Aufbau und in der Weiterentwicklung von Vertriebsorganisationen, Vertriebsprozessen und CRM-Strukturen

- Verständnis für digitale Lead-Generierung und moderne Vertriebsansätze

- Hohes Maß an Eigenverantwortung, Umsetzungsstärke und Entscheidungsfreude

- Wertschätzender Führungsstil und die Fähigkeit, Menschen für gemeinsame Ziele zu begeistern

Erfahrung in den Bereichen Food, Hospitality, Premiumprodukte, Markenartikel oder E-Commerce ist von Vorteil, aber keine Voraussetzung.

## Benefits

- Die Möglichkeit, die Zukunft eines etablierten mittelständischen Unternehmens aktiv mitzugestaltn

- Eine unternehmerische Rolle mit großem Gestaltungsspielraum und kurzen Entscheidungswegen

- Direkte Zusammenarbeit mit den Gesellschaftern

- Ein erfahrenes Team mit hoher Identifikation und viel Know-how

- Eine starke Marke mit hervorragender Reputation bei Kunden und Partnern

- Die Chance, neue Geschäftsfelder, Vertriebskanäle und Wachstumstreiber aufzubauen

- Hochwertige Produkte, hinter denen man mit Überzeugung stehen kann

- Corporate Benefits, Gesundheitsangebote und natürlich viele leckere Nüsse

Du fühlst Dich angesprochen? Dann freuen wir uns auf Deine Bewerbung unter Angabe deiner Gehaltsvorstellung und des Starttermins!

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
