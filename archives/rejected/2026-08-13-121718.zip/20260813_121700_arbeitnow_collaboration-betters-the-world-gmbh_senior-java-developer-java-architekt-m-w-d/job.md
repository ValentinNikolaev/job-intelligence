# Senior Java Developer / Java Architekt (m/w/d)

Posted: 2026-08-13T08:00:29Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Willkommen bei CBTW! Wir sind ein innovatives Team mit über 3.000 Mitarbeitern in 21 Ländern und führend in den Bereichen Strategie & Governance, Software-Engineering, Datenanalyse & KI und mehr.

Als Mitglied unseres Teams bei CBTW arbeitest Du in einem inspirierenden Umfeld an anspruchsvollen Projekten. Wir fördern die Entwicklung der Experten von morgen und schätzen Deine Ideen. Wenn Du bereit bist, die Zukunft der datengetriebenen Transformation mit einem hochmotivierten Team zu gestalten, bewirb Dich jetzt bei CBTW! Zusammen schaffen wir Großartiges.

## Aufgaben

- Du konzipierst und entwickelst **skalierbare Softwarearchitekturen** für komplexe Enterprise-Anwendungen im Java-Umfeld.

- Du programmierst anspruchsvolle Anwendungen mit **Java / J2EE, Spring oder Spring Boot** und nutzt moderne Entwicklungsstandards.

- Du analysierst fachliche Anforderungen unserer Kunden und übersetzt diese in **technische Architektur- und Lösungsdesigns**.

- Du entwickelst neue Features und Plattformlösungen zur Umsetzung komplexer Kundenanforderungen.

- Du evaluierst neue Technologien, Frameworks und Tools und bringst diese aktiv in unsere Projekte ein.

- Du übernimmst eine **technische Führungsrolle** in Projekten und unterstützt Entwickler:innen bei Architekturentscheidungen und Best Practices.

- Du arbeitest eng mit unseren Kund:innen zusammen und bist gelegentlich vor Ort bei Projekten. **Dein Wohnort innerhalb Deutschlands spielt dabei keine Rolle – entscheidend ist lediglich deine Reisebereitschaft.**

- Du bist das **Bindeglied zwischen Business und IT** und sorgst dafür, dass technische Lösungen echten Mehrwert für unsere Kunden schaffen.

## Qualifikation

- Abgeschlossenes Studium in **Informatik, Wirtschaftsinformatik, Wirtschaftsmathematik** oder einer vergleichbaren Studienrichtung.

- Mehrjährige Erfahrung in der **Java-Softwareentwicklung**, idealerweise auch in einer **Senior- oder Architekturrolle**.

- Fundierte Kenntnisse in **Java, J2EE, Spring / Spring Boot** sowie modernen Softwarearchitekturen.

- Erfahrung mit Frameworks und Technologien wie **Hibernate, Angular oder vergleichbaren Frontend-Technologien** von Vorteil.

- Erfahrung mit **SQL- und NoSQL-Datenbanken oder Streaming-Plattformen** (z. B. PostgreSQL, MongoDB, Apache Cassandra, Apache Kafka).

- Erfahrung mit **Microservices-Architekturen, Cloud-Umgebungen oder containerisierten Anwendungen** ist ein Plus.

- Sehr gute analytische Fähigkeiten und eine strukturierte Arbeitsweise.

- Verhandlungssichere **Deutsch- und Englischkenntnisse**.

- Reisebereitschaft innerhalb der DACH-Region.

- **Gehaltsspanne für diese Position (Senior-Level):** 72.000 € – 95.000 € brutto/Jahr. Die finale Einstufung erfolgt abhängig von Erfahrung und Skillset

Es ist unwahrscheinlich, dass jede:r Kandidat:in all diese Anforderungen erfüllt. Wenn Deine Erfahrungen anders sind und Du glaubst, dass Du einen Mehrwert für die Position bieten kannst, lass uns gerne darüber sprechen!

## Benefits

Bei CBTW erwartet Dich mehr als nur ein Job – wir bieten Dir ein Umfeld, in dem Du wachsen, mitgestalten und ganz Du selbst sein kannst. Unsere Kultur lebt von Vertrauen, Eigenverantwortung und echter Zusammenarbeit – egal ob remote oder vor Ort. Wir treiben Innovation gemeinsam voran, feiern Erfolge und leben Vielfalt. Dass wir bereits fünf Jahre in Folge als „Top Company“ von kununu ausgezeichnet wurden, bestätigt uns in unserem Weg.

Das erwartet Dich bei uns:

🏁 **Onboarding & Teamspirit**

- Willkommenstag, Hello Drink & Newbie Lunch

- Mentoring-Programm für Deinen idealen Einstieg

- Afterwork-Events, Summer-Tech-Event & festliche Weihnachtsfeier

- Gemeinsames soziales Engagement bei Spendenaktionen

🚀 **Entwicklung & Karriere**

- Individuelle Karrierepfade & regelmäßige Feedbackgespräche

- Vielfältige Inhouse-Trainings, Online-Kurse & externe Weiterbildungen

- Internationale Zusammenarbeit mit Kolleg:innen aus ganz Europa

🧘‍♀️ **Work-Life-Balance & Flexibilität**

- Remote Work & Workation – innerhalb der EU und darüber hinaus

- Sabbatical-Möglichkeiten & flexible Arbeitszeitmodelle

- Feiertagskalender Baden-Württemberg plus die Feiertage Deines Bundeslands – doppelter Benefit

- 30 Urlaubstage im Jahr

💼 **Ausstattung & Mobilität**

- Guthaben zur Ausstattung Deines mobilen Arbeitsplatzes

- Deutschlandticket oder Fahrradleasing – Du hast die Wahl

- Optional: BahnCard für noch mehr Reise-Flexibilität

🛡️ **Sicherheit & Vorsorge**

- Unterstützung bei Altersvorsorge & Vermögensaufbau

- Vielfältige Optionen zur finanziellen Absicherung

💡 **Wellbeing & Gesundheit**

- Zugang zum Employee Assistance Program (EAP) – auch für Angehörige

🎁 **Weitere Goodies**

- Prämien für besonderes Engagement

- Exklusive Vorteile über unsere Corporate Benefits-Plattform

- Unsere CBTW-Spotify-Playlist für einen musikalischen Eindruck vom Team 🎧

**Jetzt fehlst nur noch Du – wir freuen uns darauf, Dich kennenzulernen!**

🎵 Schau Dir unsere CBTW-Spotify-Playlist an: [CBTW auf Spotify hören](https://open.spotify.com/playlist/44kgWZRt5jmmgppH0qGszg?si=L312ch_9SMKsCKBcN-EB_A)

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
