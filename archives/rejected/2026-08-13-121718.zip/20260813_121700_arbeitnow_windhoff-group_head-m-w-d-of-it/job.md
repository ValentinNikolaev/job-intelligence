# Head (m/w/d) of IT

Posted: 2026-08-13T09:00:42Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**Sich. Gemeinsam. Entwickeln.**

Als Head of IT (m/w/d) führst du unsere interne IT mit strategischem Weitblick und operativer Nähe zum Tagesgeschäft. Du entwickelst Menschen, Prozesse und Technologien weiter und stellst sicher, dass unsere Systeme, Anwendungen und digitalen Innovationen nachhaltig zum Unternehmenserfolg beitragen.

Hier verwaltest du nicht nur Systeme, sondern prägst die digitale Zukunft einer Unternehmensgruppe mit direktem Einfluss auf Strategie, Innovation und Geschäftserfolg.

Neben unserer fachlichen Expertise sind wir ein Arbeitgeber, der Vielfalt fördert und sicherstellt, dass alle Mitarbeitenden fair behandelt werden. Teile

uns mit, wenn wir auf etwas besonders Rücksicht nehmen sollen - wie zum

Beispiel auf bestimmte Arbeitszeiten oder andere Rahmenbedingungen, deine

Situation im Privatleben oder besondere Bedürfnisse bei der Arbeit.

**Klingt nach einem Traumjob? Dann jetzt Teil des Teams werden!**

## Aufgaben

- Du führst unser vierköpfiges IT Team, setzt Prioritäten, triffst Entscheidungen und unterstützt dein Team operativ im Tagesgeschäft, wenn es darauf ankommt.

- Du verantwortest unsere IT, von der Server und Netzwerklandschaft über Microsoft 365 und Azure bis zu unseren zentralen Business Anwendungen (Dynamics 365, Sage, D.3 Dokumentenmanagement).

- Du bist Ansprechpartner für die Fachbereiche, bewertest Anforderungen und findest Lösungen, die im Alltag funktionieren.

- Du steuerst unser IT Budget, Lizenzen und externe Dienstleister und entscheidest, welche Lösungen für Windhoff sinnvoll sind.

- Gemeinsam mit der Geschäftsleitung entwickelst du die IT und KI Agenda weiter und setzt Projekte rund um Infrastruktur, Informationssicherheit, Datenschutz um.

- Du entwickelst unsere interne Daten- und Reportingplattform auf Basis von Microsoft SQL mit SAP BO, Power BI und Fabric weiter.

## Qualifikation

- Du hast ein Studium im IT Umfeld abgeschlossen oder dir vergleichbare Kenntnisse in der Praxis in vergleichbarer Position angeeignet.

- Du bringst mehrere Jahre Erfahrung im IT Betrieb mit und hast bereits Teams, Projekte oder größere IT Themen verantwortet.

- Du kennst dich mit Microsoft Technologien wie Windows Server, Active Directory, Microsoft 365 und Azure aus und fühlst dich auch in hybriden IT Umgebungen zu Hause.

- Business-Applikationen wie Dynamics 365 oder Sage schrecken dich nicht ab. Du musst sie nicht im Detail customizen können, solltest aber verstehen, wie solche Systeme im Unternehmen zusammenspielen und welche Daten darin stecken.

- Du hast bereits Berührungspunkte mit Informationssicherheit und Datenschutz, idealerweise auch mit ISO 27001 oder TISAX.

- Du arbeitest strukturiert, denkst wirtschaftlich und kannst technische Themen verständlich erklären.

- Deutsch-Kenntnisse auf C-Niveau und gute Englisch-Kenntnisse runden dein Profil ab.

## Benefits

**Das erwartet dich:**

Eine Führungsrolle mit echtem Gestaltungsspielraum und direkter Anbindung an die Geschäftsleitung

- Verantwortung für unsere gesamte Systemlandschaft: von der hybriden Infrastruktur (Hyper-V, Windows AD) über Microsoft 365 und Azure bis zu unseren Business-Applikationen (Dynamics 365, Sage, D3)

- Ein festes Budget für Weiterbildungsmöglichkeiten sowie persönliche und fachliche Entwicklungsperspektiven

- Eine gute Work-Life-Balance durch flexible Arbeitszeiten, Überstundenausgleich sowie bis zu 40 Tagen Urlaub

- Zukunftsthemen wie unsere interne Windhoff-KI und Microsoft Copilot gestaltest du aktiv mit.

Du verfügst über die gewünschten Erfahrungen und suchst eine neue Herausforderung? Du bist flexibel, lösungsorientiert und kommunikationsfähig?

Nutze deine Chance: Wir bieten das passende Umfeld für deine Karriere.

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
