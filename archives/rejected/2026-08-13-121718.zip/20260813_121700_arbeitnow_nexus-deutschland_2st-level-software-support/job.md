# 2st Level Software-Support

Posted: 2026-08-13T07:30:29Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Wer wir sind

Hier bei NEXUS entwickeln Menschen mit Leidenschaft einige der innovativsten Softwareprodukte im Gesundheitswesen. Wir sind einer der europaweit führenden Anbieter für eHealth-Lösungen und tragen dazu bei, dass Ärzte und medizinisches Personal sich auf das Wesentliche konzentrieren können.

Unser Ziel, Prozesse im Gesundheitswesen zu vereinfachen, zu beschleunigen und effizienter zu gestalten, motiviert uns und treibt uns an. Auf der Suche nach bahnbrechenden Technologien entwickeln wir uns fortlaufend weiter und werden dabei durch Vorschläge sowie Impulse unserer Mitarbeiter unterstützt. Wir gestalten gemeinsam mit unseren Kunden die Zukunft des Gesundheits- und Sozialwesens und sorgen für reibungslose Abläufe im Krankenhaus!

**Wir suchen für unseren Standorte in Jena/Berlin/Ismaning großartige Menschen im Software-Support ! (m/w/d)**

Individuelle Förderung statt Schema F – wir entwickeln neue Kolleginnen und Kollegen gezielt und persönlich in ihre Rolle, unabhängig vom Lebenslauf.

Chancen für Quereinsteiger und Ungewöhnliche Lebensläufe wir setzen auf Potenziale und begleiten den Weg ins neue Aufgabenfeld aktiv.

## Aufgaben

- Du bist direkter Ansprechpartner unserer Kunden und begleitest deren Anliegen vom Eingang bis zum erfolgreichen Abschluss der Bearbeitung

- Du übernimmst den Support für unsere Softwarelösungen im Krankenhaus-Umfeld

- Du bearbeitest Anfragen sowie Störungsmeldungen und priorisierst, klassifizierst und dokumentierst diese in einem Ticketsystem

- Du unterstützt bei der aktiven Fehlerbehebung in Hardware- und Softwarethemen

- Du dokumentierst und pflegst unsere Wissensdatenbank

## Qualifikation

- Du bringst Kenntnisse der Windows Betriebssysteme mit

- Du legst Wert auf eine selbständige Arbeitsweise gepaart mit analytischem Denkvermögen

- Du verfügst über freundliches und kundenorientiertes Auftreten sowie Team- und Kommunikationsfähigkeiten

- Du hast idealerweise erste Erfahrungen mit Jira und Confluence

- Du bist ein Organisationstalent in Verbindung mit hoher Kunden- und Serviceorientierung

- Du kannst eine abgeschlossene Ausbildung im IT-Bereich, eine vergleichbare oder eine höhere Qualifikation nachweisen

- Du bist als Quereinsteiger ebenfalls sehr willkommen

- Du sprichst Deutsch und bringst gute Englischkenntnisse mit

## Benefits

- Eine interessante und vielseitige Tätigkeit in einem komplexen Umfeld

- Hohe Eigenverantwortung und eine kreative Arbeitsatmosphäre

- Persönliche Entfaltung in einem eingespielten Team mit gutem Betriebsklima

- Einen sicheren und attraktiven Arbeitsplatz

- Flache Hierarchien mit kurzen Kommunikationswegen sowie schnelle und direkte Entscheidungen

- Weiterentwicklungsmöglichkeiten entsprechend Ihren Fähigkeiten und Leistungen

- Eine attraktive und leistungsorientierte Vergütung

Mach den Unterschied im 2nd Level Software-Support bei Nexus Deutschland! Werde Teil eines leidenschaftlichen Teams, das innovative E-Health-Lösungen für die Gesundheitsbranche entwickelt. Bewirb dich jetzt!

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
