# Teamleiter Kundenservice (m/w/d)

Posted: 2026-08-13T09:20:32Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Für unseren Standort** Avedo Schutterwald **suchen wir dich als** Teamleiter (m/w/d)** in **Vollzeit**.

**Deine Benefits**

-

sicherer Arbeitsplatz und unbefristete Festanstellung in Vollzeit (40h)

-

professionelle Einarbeitung und Coachings für deine persönliche Weiterentwicklung

-

offene Kommunikation und regelmäßiges Feedback

-

bei Avedo hast du’s gut: Rabatte u.a. für Onlineshops und Reiseportale, Firmenevents, Tischkicker, Snackautomat

-

kostenfreier Parkplatz

**
Deine Aufgaben**

-

Führen eines Teams im Sinne der qualitativen und quantitativen Projektvorgaben

-

Führen von regelmäßigen Mitarbeitergesprächen zu allgemeinen, fachlichen und disziplinarischen Angelegenheiten

-

Organisation und Durchführung von regelmäßigen Teammeetings

-

Monitoring, Screening und Coaching der Mitarbeiter*innen

-

konstruktive Mitarbeit und Optimierung im Projekt

-

Steigerung der Produktivität und Rentabilität

**Dein Profil**

-

abgeschlossene technische oder kaufmännische Berufsausbildung

-

mehrjährige Berufserfahrung im Call Center

-

idealerweise erste Führungserfahrung

-

sicherer Umgang mit PC Anwendungen (z.B. MS-Office)

-

hohes Maß an Beurteilungsvermögen und Durchsetzungsstärke

-

Leistungs- und umsatzorientierte sowie selbständige Arbeitsweise

-

hohes Maß an Loyalität, Diskretion, Zuverlässigkeit und Eigeninitiative

Du suchst einen neuen Job? Dann ist **Avedo Schutterwald **dein neuer Arbeitgeber! Wir sind Spezialisten im Dialogmarketing und betreuen mit unseren über 40 Call Centern in Deutschland und Europa den direkten Kontakt zwischen Unternehmen und Kunden. Haben wir dein Interesse geweckt? Dann sollten wir uns unbedingt kennenlernen. Wir freuen uns auf deine **Online-Bewerbung**.

*
Sämtliche Bezeichnungen richten sich an alle Geschlechter.*

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
