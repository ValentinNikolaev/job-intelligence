# Ausbildung zum Fachinformatiker digitale Vernetzung (m/w/d)

Posted: 2026-08-13T07:00:40Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Ausbildung zum Fachinformatiker dgitale Vernetzung (m/w/d) – Fokus Cloud-Native, SaaS & AI

**Starte deinen Weg zum Cloud- & KI-Spezialisten bei uns!**

Wir entwickeln und betreiben im Managed-Services-Bereich eigene SaaS-Dienste und moderne Cloud-Infrastrukturen. Dabei verändert KI bereits heute, wie wir Software entwickeln, Systeme betreiben und technische Probleme lösen.

Für unser Team suchen wir eine neugierige Persönlichkeit mit schneller Auffassungsgabe, die nicht nur wissen möchte, **wie man IT-Systeme benutzt, sondern wie sie tatsächlich funktionieren**. Wenn Du gerne tüftelst, Dinge ausprobierst, Systeme auseinandernimmst und Dich in technische Probleme verbeißt, möchten wir Dir mit dieser Ausbildung ein Sprungbrett in die Cloud-Native-Welt bieten.

Während Deiner Ausbildung wirst Du strukturiert an den stabilen Betrieb und die Weiterentwicklung unserer Cloud-Native-Umgebung herangeführt. Gleichzeitig lernst Du, KI als Werkzeug für Deine eigene Arbeit einzusetzen und zunehmend auch KI-gestützte und autonome Systeme zu betreiben, zu überwachen und sicher zu kontrollieren.

## Aufgaben

**Deine Ausbildungsschwerpunkte. Hier wächst Du hinein:**

Gemeinsam mit Deinen Ausbildern und Mentoren meisterst Du Schritt für Schritt diese Kernbereiche:

- **Cloud-Infrastruktur**: Du lernst den Aufbau, die Automatisierung und den Betrieb unseres modernen Cloud-Native-Stacks kennen.

- **Vom Code zum Live-System**: Du begleitest den Weg neuer Software-Releases vom Code bis zum produktiven System, überwachst die Performance und lernst, Systeme stabil zu halten.

- **Automatisierung**: Du erfährst, wie man wiederkehrende manuelle Aufgaben durch Code und Automatisierung effizienter macht – und warum wir Dinge, die Maschinen zuverlässig erledigen können, nicht dauerhaft von Hand machen wollen.

- **KI & autonome Systeme**: Du lernst, KI für Entwicklung, Analyse, Troubleshooting und Automatisierung einzusetzen. Mit wachsender Erfahrung beschäftigst Du Dich auch damit, wie KI-Agenten selbstständig Aufgaben übernehmen und wie solche autonomen Systeme sicher betrieben, überwacht und kontrolliert werden.

- **Team-Support**: Du unterstützt uns bei der Entwicklung und dem Betrieb neuer Produkte und wirst im Laufe Deiner Ausbildung zum kompetenten Ansprechpartner für Cloud-, Plattform- und Automatisierungsthemen.

**Das erwartet Dich. Dein Tech-Stack zum Lernen:**

Erste Erfahrungen mit IT sind ein Plus, aber keine Voraussetzung. Ob durch eigene Projekte, in der Schule oder während eines Praktikums, wenn Du bereits erste Berührungspunkte mit IT hattest, kannst Du bei uns darauf aufbauen und lernst, wie daraus Praxis wird.

- **Kubernetes**: Einblicke in das Design und den Betrieb moderner SaaS-Workloads.

- **Infrastructure as Code**: Einstieg in moderne Infrastrukturverwaltung mit Terraform/OpenTofu und Helm.

- **GitOps**: Kontinuierliche Bereitstellung von Software mit Argo CD oder Rancher Fleet.

- **CI/CD-Pipelines**: Mitarbeit beim Aufbau und bei der Pflege automatisierter Build-, Test- und Deployment-Pipelines.

- **Observability**: Verstehen und Nutzen von Logs, Metriken und Alerting zur Systemüberwachung und Fehleranalyse.

- **AI & Agents**: KI-gestütztes Arbeiten, Large Language Models, Tool-Calling und autonome Agenten als Bestandteil moderner IT-Systeme.

- **Security & Backups**: Grundlagen der Cloud-Sicherheit sowie das Testen von Backup- & Restore-Strategien.

- **Incident-Handling**: Lernen, wie man professionell und strukturiert mit Systemstörungen umgeht und sich Schritt für Schritt bis zur eigentlichen Ursache eines Problems vorarbeitet.

## Qualifikation

**Das bringst du mit:**

- **Schulische Basis**: Du hast die (Fach-)Hochschulreife oder einen Realschulabschluss in der Tasche. Gerne auch Studienabbrecher, die festgestellt haben, dass sie lieber praktisch an echten Systemen arbeiten möchten. Für uns zählt dabei nicht nur Dein Zeugnis, sondern vor allem Dein technisches Interesse und Deine Lernfähigkeit.

- **Erste IT-Berührungspunkte**: Du bringst theoretische oder praktische Grundkenntnisse mit – zum Beispiel Linux-Basics, erste Skripte oder Programmiererfahrung, Docker, Netzwerke, Hardware oder andere Erfahrungen aus Freizeit, Praktikum oder Schule.

- **IT-Begeisterung**: Du hast keine Angst vor Code-Zeilen, tüftelst gerne am PC und bleibst hartnäckig dran, bis Du verstanden hast, warum etwas funktioniert – oder warum eben nicht.

- **Technische Neugier**: Vielleicht hast Du schon einmal einen eigenen Server aufgesetzt, ein Homelab gebaut, Linux installiert, mit Docker oder virtuellen Maschinen experimentiert, Hardware zusammengeschraubt, einen Raspberry Pi zweckentfremdet, ein kleines Tool geschrieben oder ein System einfach aus Neugier auseinandergenommen.

****Solche Dinge interessieren uns. Erzähle uns davon.****

- **KI als Werkzeug**: Du möchtest KI nicht nur benutzen, um Dir fertige Antworten geben zu lassen. Du willst verstehen, wie Du sie als Werkzeug einsetzen kannst, um schneller zu entwickeln, Probleme zu analysieren und neue Dinge zu bauen. **Wir suchen Menschen, die mit KI mehr bauen können als ohne sie.**

- **Lernbereitschaft**: Du hast Lust, Fehler als Lernchancen zu sehen, selbstständig nach Ursachen zu suchen und Dich kontinuierlich weiterzuentwickeln.

Uns ist dabei wichtiger, **wie Du denkst, lernst und technische Probleme angehst, als wie gut Du Dich verkaufen kannst.**

Denn die IT, für die wir Dich ausbilden, verändert sich gerade grundlegend, denn KI wird unsere Arbeit zunehmend unterstützen und dabei immer mehr Aufgaben selbstständig übernehmen. Dadurch verschwinden technische Herausforderungen nicht, sondern sie verschieben sich.

Wir wollen Dich darauf vorbereiten, **die Cloud-Plattformen, Automatisierungen und autonomen Systeme von morgen zu verstehen, zu bauen, zu betreiben und unter Kontrolle zu halten**

## Benefits

**Das bieten wir Dir für Deinen Start:**

- **Strukturierte Ausbildung**: Ein festes Mentoring-Modell, bei dem Dir ein erfahrener Ausbilder im Arbeitsalltag zur Seite steht.

- **Hohe Übernahmechancen**: Wir bilden für den eigenen Bedarf aus und möchten Dich nach erfolgreichem Abschluss gerne fest übernehmen.

- **Gezielte Weiterentwicklung**: Wir unterstützen Dich bei Prüfungsvorbereitungen und nützlichen Cloud-Zertifizierungen (z. B. CKA/CKAD).

- **Moderne Arbeitsweise**: KI gehört für uns zum Werkzeugkasten moderner IT. Du lernst, sie sinnvoll einzusetzen, ihre Ergebnisse kritisch zu hinterfragen und mit ihrer Hilfe Dinge zu bauen und zu automatisieren, die vorher deutlich mehr manuellen Aufwand benötigt hätten.

- **Teamkultur**: Flache Hierarchien, direkter technischer Austausch auf Augenhöhe und kurze Entscheidungswege.

- **Flexibilität**: Planbare Flexibilität in Deinen Arbeitszeiten und moderne Optionen für mobiles Arbeiten nach der Einarbeitung.

Wir freuen uns auf Deine Bewerbung!

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
