# Creative Director Design - for dm-drogerie markt

Posted: 2026-08-13T08:55:20Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Wir sind WongDoody, mehr als 2.000 Kolleg:innen in 24 Designstudios auf vier Kontinenten – ein hochgradig kollaboratives Team aus Expert:innen für Produkterlebnisse, digitales Marketing und immersive Technologien. Unsere Lösungen entstehen dort, wo Kreativität und Technologie zusammentreffen – mit einem klaren Fokus auf die Bedürfnisse und Erlebnisse der Nutzer:innen. Ob Augmented Reality, Digital Twins, KI-Ökosysteme, Omnichannel-Commerce oder integrierte Kampagnen: Wir schaffen Verbindungen zwischen Menschen und Marken – im B2B- ebenso wie im B2C-Bereich.

Als Teil des globalen Technologieinnovators Infosys verfügen wir über die nötige Skalierung und Expertise, um große Ideen Wirklichkeit werden zu lassen – und sie weltweit umzusetzen.

**WongDoody x dm**

Dein Spielfeld: dm-drogerie markt. Für dm-drogerie markt, Deutschlands beliebtesten Einzelhändler, sind wir seit 2010 die digitale Lead-Agentur und haben das Unternehmen bei jedem Schritt der Transformation vom stationären Handel zum Omni-Channel begleitet.

In enger Zusammenarbeit mit den dm-Niederlassungen in Deutschland, Österreich und Osteuropa betreuen und entwickeln mehr als 50 kreative Köpfe die Strategie und E-Commerce-Plattformen für dm in diesen Ländern und kümmern sich gleichzeitig um alle anderen Online-Aktivitäten wie Social Media, CRM, Digital Branding, Kampagnen und Content Marketing.

**Deine Rolle**

Du führst und inspirierst ein interdisziplinäres Kreativteam – und bist gleichzeitig ein:e starke:r Vernetzer:in.

- Du entwickelst Designer:innen, Art Directors und Kreative fachlich und konzeptionell weiter
- Du schaffst ein Umfeld, in dem starke Ideen entstehen können – schnell, kollaborativ und auf Augenhöhe
- Du bringst Klarheit in kreative Prozesse, ohne sie unnötig zu verkomplizieren
- Du setzt Qualitätsmaßstäbe und gibst konstruktives, inspirierendes Feedback
- Du vernetzt dich aktiv innerhalb der Agentur – insbesondere mit Tech-, Data- und Strategy-Teams
- Du arbeitest eng und partnerschaftlich mit den dm-Teams zusammen und wirst als integraler Teil des Setups wahrgenommen

**Das erwartet Dich**

Du übersetzt Marke in visuelle Kultur – und verbindest Kreation mit Technologie.

- Du entwickelst starke, konzeptionelle Ideen, die aus der Marke dm heraus entstehen – nicht aus generischen Kampagnenmustern
- Du gestaltest visuelle Systeme, Designs und kreative Leitideen, die auf digitalen Plattformen relevant sind
- Du denkst Design nicht statisch, sondern im Kontext von Nutzung, Bewegung, Plattformlogik und technologischen Möglichkeiten
- Du bringst ein feines Gespür für kulturelle Strömungen mit und übersetzt diese in markengerechte visuelle Ausdrucksformen
- Du verbindest kreative Exzellenz mit Technologie – z. B. durch den Einsatz von KI, Automatisierung und skalierbaren Designsystemen
- Du denkst Designsysteme weiter: als lebendige Systeme, die kulturelle Nuancen aufnehmen und sich dynamisch anpassen lassen
- Du arbeitest eng mit Strategie, Tech, Data und Produktion zusammen, um Ideen ganzheitlich zu entwickeln und skalierbar zu machen
- Du stellst sicher, dass kreative Qualität und Markenkonsistenz auf höchstem Niveau bleiben
- Du entwickelst die visuelle Sprache der Marke kontinuierlich weiter – mit Blick auf neue Formate, Technologien und Plattformen

**Das bringst Du mit**

- Mehrjährige Erfahrung in einer kreativen Leitungsrolle mit starkem Fokus auf Design und Konzept
- Ein herausragendes Gespür für Marken, visuelle Sprache und kulturelle Relevanz
- Die Fähigkeit, Ideen zu entwickeln, die für Menschen wirklich Bedeutung haben
- Erfahrung in der Gestaltung für digitale Plattformen und ein Verständnis dafür, wie sich Design dort verhält
- Interesse und Neugier für neue Technologien – insbesondere für KI, Automatisierung und deren Einfluss auf Design
- Erfahrung oder Motivation, Designsysteme weiterzudenken und skalierbar zu machen
- Ein starkes Portfolio, das konzeptionelle Tiefe und visuelle Exzellenz zeigt
- Erfahrung in der Führung und Entwicklung von Kreativteams
- Freude an Zusammenarbeit, Vernetzung und interdisziplinärem Arbeiten
- Sehr gute Deutsch- und Englischkenntnisse

**Unsere lokalen Benefits**

- Flexible Arbeitszeiten
- Arbeiten von wo es für dich passt. Zu Hause oder im Büro, ganz nach deinem Geschmack
- Die Möglichkeit, eine der spannendsten Marken Deutschlands kreativ mitzugestalten
- Raum für echte konzeptionelle und gestalterische Arbeit
- Ein Umfeld, das Kreativität, Technologie und Kultur verbindet
- Zuschuss beim Urban Sports Club
- ﻿Mitarbeitervorteile & Rabatte über Corporate Benefits
- aufgeschlossene & nette Menschen in allen Teams

Klingt nach Dir? Dann schnapp Dir Deinen Laptop und bewirb Dich - Mit Arbeiten, die zeigen, wie du denkst - Nicht nur, was du gemacht hast. Wir freuen uns, Dich auf unserer kreativen Reise dabei zu haben!

Für uns zählt allein Deine Persönlichkeit und Deine beruflichen Fähigkeiten. Dein Geschlecht, Alter oder Aussehen, Deine Herkunft oder sexuelle Orientierung spielen für uns keine Rolle – wir sind offen für die Zusammenarbeit mit jeder Person.

Beachte bitte: Dies ist eine Stellenanzeige der WongDoody GmbH mit Sitz in Deutschland. Über unsere Website oder andere Quellen kannst Du zu Stellenanzeigen gelangen, die von einer unserer WongDoody-Schwesterfirmen veröffentlicht wurden, mit denen wir weltweit gemeinsam unter der Marke "WongDoody" auftreten. Für jedes Stellenangebot ist ausschließlich das Unternehmen verantwortlich, das die jeweilige Anzeige veröffentlicht hat. Ansprechpartner:innen, erforderliche Angaben und geltende Bedingungen können jeweils abweichen. [Hier](https://www.wongdoody.com/wongdoody-germany-privacy) kannst Du Dich darüber informieren, wie die WongDoody GmbH Deine im Bewerbungsprozess angegebenen personenbezogenen Daten verarbeitet.

Wenn Du Fragen zum Bewerbungsprozess hast, wende Dich gerne direkt an unser People & -----

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
