# Arzthelferin/ MFA (m/w/d) für Sprechstunden, OP und Ästhetik-Assistenz

Posted: 2026-08-13T09:31:30Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Zur Verstärkung unseres Teams suchen wir in unserer privaten Hautarztpraxis eine/n engagierte/n **Arzthelfer/in/ (MFA) (m/w/d)** in Vollzeit, die/der mit Präzision und Organisationsfähigkeit unsere Abläufe in der Praxis effizient unterstützt und unseren Praxisalltag mitgestaltet.

## Aufgaben

🔹 **Sprechstundenassistenz** – Du begleitest und unterstützt die Ärzt:innen während der Sprechstunde und assistierst bei ästhetischen Behandlungen.

🔹 **OP-Assistenz** - Du assistierst bei kleinen ambulanten Eingriffen

🔹 **Praxisorganisation** – Du behältst den Überblick über die Abläufe, koordinierst die Übergänge zwischen Anmeldung, Arzt, OP und Laser und sorgst für einen reibungslosen Ablauf.

🔹 **Behandlungsassistenz** – Du übernimmst und dokumentierst die Vor- und Nachbereitung der Behandlungen.

🔹 **Medizinische Tätigkeiten** – Du führst eigenständig Behandlungen wie Abstriche, Wundversorgung, Fäden ziehen und weitere Behandlungen durch.

🔹 **Patientenbetreuung** – Du stehst den Patienten zur Seite und sorgst für einen reibungslosen Ablauf.

🔹 **Empfang & Terminorganisation** – Du vertrittst bei

Engpässen die Anmeldung, bist der erste Kontakt für unsere Patienten an

der Anmeldung, begrüßt die Patienten

freundlich und koordinierst Termine präzise, kommunizierst per E-Mail

und Telefon und arbeitest mit unserer neuen cloudbasierten

Praxissoftware.

## Qualifikation

✔ Abgeschlossene Ausbildung als Medizinische Fachangestellte (MFA) oder vergleichbare Qualifikation.

✔ Interesse an dermatologischen und ästhetischen Behandlungen sowie an der Arbeit mit modernen Technologien.

✔ Eine selbstständige, strukturierte Arbeitsweise.

✔ Zuverlässigkeit, Präzision und Verantwortungsbewusstsein.

## Benefits

✨ **Attraktive Sozialleistungen** – inklusive betrieblicher Altersvorsorge, Gesundheitsbonus & Jobticket.

✨ **Strukturierte Einarbeitung & Weiterentwicklung** – durch gezielte Schulungen und Weiterbildungen.

✨ **Modernes Arbeitsumfeld** – mit KI-gestützter Diagnostik, effizientem Praxismanagement und klaren Abläufen.

✨ **Eine unbefristete Vollzeitstelle** mit langfristiger Perspektive

✨ **Vielfältige Aufgaben**

Unsere Hautarztpraxis verbindet medizinische Expertise mit modernster Technologie. Wir setzen auf innovative und fortschrittliche Behandlungsmethoden und schaffen eine vertrauensvolle Atmosphäre für unsere Patienten.

Lust auf neue Herausforderungen in einer modernen Hautarztpraxis? Dann freuen wir uns auf deine Bewerbung!

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
