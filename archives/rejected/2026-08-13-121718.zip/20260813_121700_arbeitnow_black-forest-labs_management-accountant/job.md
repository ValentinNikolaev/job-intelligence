# Management Accountant

Posted: 2026-08-13T08:40:22Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

## About Black Forest Labs

We're the team behind Latent Diffusion, Stable Diffusion, and FLUX—foundational technologies that changed how the world creates images and video. We’re creating the generative models that power how people make images and video—tools used by millions of creators, developers, and businesses worldwide. Our FLUX models are among the most advanced in the world, and we're just getting started.

Headquartered in Freiburg, Germany with a growing presence in San Francisco, we're scaling fast while staying true to what makes us different: research excellence, open science, and building technology that expands human creativity.

## **Why This Role**

We're seeking a bilingual Management Accountant to serve as the cornerstone of our German accounting operations. This role combines hands-on accounting execution with strategic financial operations, ensuring seamless coordination between our German and US entities while maintaining compliance with both German and US GAAP standards.

You'll work at the intersection of day-to-day financial operations and cross-border business requirements, partnering closely with our Head of Finance, People Operations, external payroll providers, and local German accounting advisors to maintain accurate, timely financial reporting across our dual-entity structure.

## **What You’ll Work On**

### Core Accounting Operations

-

Manage full-cycle billing, collections, and accounts payable for German entity

-

Execute treasury and cash management functions, including inter-company settlements

-

Process and reconcile inter-company transactions between German and US entities

-

Partner with People Operations and external payroll agencies across Europe to ensure accurate and timely payroll accounting entries

-

Review payroll outputs from external providers and post journal entries to the general ledger

-

Reconcile payroll-related balance sheet accounts (accruals, statutory deductions, benefits) each month

-

Maintain accurate books and records in accordance with German GAAP (HGB)

-

Maintain dual bookkeeping across DATEV (German statutory books) and Rillet (global ERP), ensuring both systems remain accurate, aligned, and reconciled on an ongoing basis

### Tax & Compliance

-

Coordinate with external German accountants (Steuerberater) to ensure accurate VAT returns and filings

-

Support annual tax compliance including Körperschaftsteuer and Gewerbesteuer

-

Maintain documentation for tax audits and statutory requirements

-

Monitor regulatory changes affecting German accounting and tax obligations

### US GAAP Reporting Support

-

Assist in reconciling German GAAP accounts to US GAAP basis

-

Provide monthly financial data and schedules for consolidated US GAAP reporting

-

Support quarter-end and year-end close processes for global consolidation

-

Help maintain documentation for US GAAP accounting policies and procedures

### Process & Systems

-

Implement and improve accounting processes and internal controls

-

Work with ERP and financial systems to enhance efficiency and accuracy

-

Support integration of German operations into global financial infrastructure

-

Maintain organized documentation for internal and external stakeholders

## **What We’re Looking For:**

-

**Education**: Completed Ausbildung as Steuerfachangestellter/ Steuerfachwirt or similar accounting qualification; Bachelor's degree in Finance/Accounting preferred

-

**Experience**: 3 plus years experience in accounting role(s), preferably in fast-growing companies or startups

-

**Language**: Full fluency in both German and English is a core requirement

-

**Technical**: Strong proficiency with accounting software and Excel; experience with ERP systems

-

**Location**: Based in or willing to relocate to Freiburg, Germany

### **While not required, it’s an added plus if you also have:**

-

Experience with DATEV and/or modern cloud ERP systems (e.g., Rillet, NetSuite)

-

Familiarity with both German GAAP (HGB) and US GAAP principles

-

Experience working in dual-entity or international company structures

-

Prior work with German Steuerberater and understanding of VAT compliance

-

Experience coordinating with People Operations and third-party payroll providers (rather than running payroll directly)

-

Experience in technology or SaaS companies

-

Knowledge of intercompany accounting and transfer pricing basics

### **How We Work Together**

We’re a distributed team with real offices that people actually use. Depending on your role, you’ll either join us in Freiburg or SF at least 2 days a week (or one full week every other week), or work remotely with a monthly in-person week to stay connected. We’ll cover reasonable travel costs to make this possible. We think in-person time matters, and we’ve structured things to make it accessible to all. We’ll discuss what this will look like for the role during our interview process.

### **Everything we do is grounded in four values:**

-

Obsessed. We are a frontier research lab. The science has to be right, the understanding deep, the product beautiful.

-

Low Ego. The work speaks. The best idea wins, no matter who said it. Credit is shared. Nobody is above any task.

-

Bold. We take the ambitious bet. We ship, we do not wait for conditions to be perfect.

-

Kind. People over politics. We treat each other with genuine warmth. Agency without empathy creates chaos.

If this sounds like work you’d enjoy, we’d love to hear from you.

**Base Annual Salary: **EU €70,000- €100,000 + Equity

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
