# Brand & Marketing Manager (m/w/d) in Teilzeit - Fokus Markenstrategie & Bekanntheit

Posted: 2026-08-13T10:00:27Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Du liebst Sport, gesunde Ernährung und nachhaltige Snacks? Du weißt, wie man aus einer guten Geschäftsidee eine Marke macht, die im Gedächtnis bleibt und im Regal auffällt?

Bei TZAMPAS stehen wir vor dem nächsten großen Schritt: Wir haben ein starkes Produkt, aber unsere Markenbotschaft muss noch schärfer, konsistenter und bekannter werden. Wenn du Lust hast, unser Markenprofil auf den Punkt zu bringen und mit kreativen Kampagnen für echte Reichweite zu sorgen, bist du bei uns genau richtig.

Wir suchen eine Teilzeitkraft für 20-25 Std./Woche mit der Option auf Vollzeit in der Zukunft.

## Aufgaben

Als Brand & Marketing Manager:in bist du das Sprachrohr und das strategische Gewissen unserer Marke. Deine Hauptaufgabe ist es, TZAMPAS eine glasklare Identität zu verleihen und die Markenbekanntheit spürbar zu steigern.

- **Markengeschichte & Botschaft schärfen:** Du entwickelst unsere Core Message und ein klares Brand Playbook (Tone of Voice, Wording, Design-Leitplanken), damit TZAMPAS auf allen Kanälen - von der Verpackung über Social Media bis zum POS - wie aus einem Guss kommuniziert.

- **Bekanntheit aufbauen:** Du konzipierst und steuerst kreative Kampagnen (z. B. Influencer-Kooperationen, Event-Sponsoring im Outdoor-/Sportbereich, PR und Social-Media-Aktionen) mit Fokus auf Reichweite und Markenaufbau.

- **Kanalübergreifende Konsistenz:** Du achtest darauf, dass sowohl D2C (Onlineshop) als auch der B2B-Auftritt (Supermärkte/Handel) dieselbe starke Markensprache sprechen.

## Qualifikation

**Das bringst du mit**

- **Erfahrung im Branding:** Mindestens 3-5 Jahre Erfahrung im Brand Management, Marketing oder einer Agentur (bevorzugt FMCG, Food oder Lifestyle).

- **Fokus auf klare Kommunikation:** Du kannst komplexe oder vielschichtige Themen (z. B. Nachhaltigkeit, pflanzliche Ernährung) auf einfache, prägnante und mitreißende Botschaften herunterbrechen.

- **Macher-Mentalität:** Du denkst strategisch, hast aber genauso Freude daran, Ideen eigenständig und pragmatisch umzusetzen (Hands-on-Mentalität).

- **Leidenschaft für das Thema:** Du lebst gesunde Ernährung, Nachhaltigkeit oder Sport und verstehst die Sprache unserer Zielgruppe intuitiv.

- **Grafische Skills:** Du hast ein gutes Auge für Design und kannst kleinere Grafik-Tasks auch selbst umsetzen.

- **Strukturierte Arbeitsweise:** Du behältst auch bei einer Vielzahl unterschiedlicher Aufgaben die Übersicht.

- **Deutschkenntnisse:** Deutschkenntnisse auf Muttersprachenniveau in Wort und Schrift sind unabdingbar für deine Aufgaben.

- *Ein Plus, kein Muss:* Erfahrung im Aufbau von Communitys oder der Zusammenarbeit mit Influencern aus dem Outdoor-/Fitnessbereich.

## Benefits

Darum TZAMPAS

- **Echter Einfluss:** Du übernimmst direkt die Verantwortung für das Gesicht und die Stimme einer aufstrebenden Food-Marke.

- **Flexibilität:** Flexible Arbeitszeiten und Homeoffice nach Absprache

- **Sinnstiftendes Produkt:** Ein Produkt, hinter dem man zu 100 % stehen kann, faire Arbeitsbedingungen und ein motiviertes, unkompliziertes Team.

Schicke uns deinen Lebenslauf, deine Gehaltsvorstellungen bezogen auf eine 20 - Stundenwoche sowie 2-3 Beispiele von Marken oder Projekten, deren Botschaft du geschärft oder deren Bekanntheit du gesteigert hast (z. B. als kurzes PDF oder Link).

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
