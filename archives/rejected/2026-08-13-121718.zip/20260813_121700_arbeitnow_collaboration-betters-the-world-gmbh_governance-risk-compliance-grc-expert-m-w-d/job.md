# Governance, Risk & Compliance (GRC) Expert (m/w/d)

Posted: 2026-08-13T08:30:39Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Willkommen bei CBTW! Wir sind ein innovatives Team mit über 3.000 Mitarbeitern in 21 Ländern und führend in den Bereichen Strategie & Governance, Software-Engineering, Datenanalyse & KI und mehr.

Als **Governance, Risk & Compliance (GRC) Expert** verstärkst Du unsere **Cybersecurity Service Line**. Gemeinsam schützen wir Unternehmen vor sich ständig weiterentwickelnden Cyberbedrohungen, stellen regulatorische Compliance sicher und stärken die Sicherheit digitaler Assets.

Bei CBTW arbeitest Du an spannenden Kundenprojekten und bringst gleichzeitig Deine Expertise in unsere interne Security-Community ein. Wenn Du daran interessiert bist, Sicherheitsstrategien zu gestalten, Risiken zu analysieren und Organisationen resilienter zu machen, freuen wir uns darauf, Dich kennenzulernen!

## Aufgaben

**Strategie & Governance**

- Du unterstützt unsere Kunden bei der Definition und Umsetzung ihrer Informationssicherheitsstrategie.

- Du organisierst, strukturierst und steuerst Sicherheitsprojekte.

- Du implementierst und entwickelst Informationssicherheits-Managementsysteme (ISMS) weiter.

- Du arbeitest an der Erstellung und Weiterentwicklung von Sicherheitsrichtlinien und -prozessen (z. B. Incident Response, Security Policies).

**Risikomanagement**

- Du analysierst und bewertest Sicherheitsrisiken anhand etablierter Frameworks (z. B. ISO 27005, EBIOS RM).

- Du identifizierst und überwachst operative, Compliance- und Sicherheitsrisiken.

- Du definierst und implementierst Sicherheits-KPIs zur Messung der Sicherheitsperformance.

**Compliance & Regulierung**

- Du unterstützt Kunden bei der Einhaltung relevanter Cybersecurity- und Datenschutzregularien (z. B. NIS2, DORA, GDPR, NIST).

- Du analysierst den Sicherheitsstatus von Organisationen und identifizierst Verbesserungsmaßnahmen.

- Du führst interne Audits durch und begleitest Compliance-Prozesse.

**Incident Management**

- Du koordinierst die Reaktion auf Sicherheitsvorfälle und begleitest deren Analyse.

- Du überwachst Maßnahmenpläne nach Vorfällen oder Audits und stellst deren Umsetzung sicher.

- Du entwickelst Maßnahmen zur Verbesserung der Sicherheitslage.

**Training & Awareness**

- Du führst Trainings und Awareness-Maßnahmen zu Informationssicherheit und GRC-Richtlinien durch.

- Du förderst die Einführung von Sicherheitsstandards und Best Practices in Organisationen.

Neben Deiner Arbeit in Kundenprojekten bringst Du Deine Erfahrung auch in unsere **interne Security-Community bei CBTW** ein und teilst Wissen sowie Best Practices mit Kolleg:innen.

## Qualifikation

**Dein Talent**

- Abgeschlossenes Bachelor- oder Masterstudium im Bereich Cybersecurity, Informationssicherheit oder eine vergleichbare Qualifikation.

- Mindestens **5 Jahre Erfahrung** in einer vergleichbaren Rolle im Bereich Governance, Risk & Compliance oder Informationssicherheit.

- Fundierte Kenntnisse der **ISO-2700X-Standards** (ISO 27001, ISO 27002, ISO 27005).

- Erfahrung mit **Risikomanagement-Methoden** wie EBIOS RM.

- Kenntnisse relevanter regulatorischer Anforderungen wie **NIS2, DORA oder GDPR**.

- Erfahrung in der Implementierung oder Weiterentwicklung eines **ISMS**.

- Sehr gute analytische Fähigkeiten und eine strukturierte Arbeitsweise.

- Fließende **Deutsch - und Englischkenntnisse**.

- Zertifizierungen wie **ISO 27001 Lead Implementer / Lead Auditor** oder **ISO 27005 Risk Manager** sind von Vorteil.

- Weitere Zertifizierungen wie **CISM, CISSP, CRISC oder CISA** sind ein Plus.

- Reisebereitschaft innerhalb der DACH-Region.

- Gehaltsspanne für diese Position (Medior-Level): 65.000 € – 75.000 € brutto/Jahr. Die finale Einstufung erfolgt abhängig von Erfahrung und Skillset

## Benefits

Bei CBTW erwartet Dich mehr als nur ein Job – wir bieten Dir ein Umfeld, in dem Du wachsen, mitgestalten und ganz Du selbst sein kannst. Unsere Kultur lebt von Vertrauen, Eigenverantwortung und echter Zusammenarbeit – egal ob remote oder vor Ort. Wir treiben Innovation gemeinsam voran, feiern Erfolge und leben Vielfalt. Dass wir bereits fünf Jahre in Folge als „Top Company“ von kununu ausgezeichnet wurden, bestätigt uns in unserem Weg.

Das erwartet Dich bei uns:

🏁 **Onboarding & Teamspirit**

- Willkommenstag, Hello Drink & Newbie Lunch

- Mentoring-Programm für Deinen idealen Einstieg

- Afterwork-Events, Summer-Tech-Event & festliche Weihnachtsfeier

- Gemeinsames soziales Engagement bei Spendenaktionen

🚀 **Entwicklung & Karriere**

- Individuelle Karrierepfade & regelmäßige Feedbackgespräche

- Vielfältige Inhouse-Trainings, Online-Kurse & externe Weiterbildungen

- Internationale Zusammenarbeit mit Kolleg:innen aus ganz Europa

🧘‍♀️ **Work-Life-Balance & Flexibilität**

- Remote Work & Workation – innerhalb der EU und darüber hinaus

- Sabbatical-Möglichkeiten & flexible Arbeitszeitmodelle

- Feiertagskalender Baden-Württemberg plus die Feiertage Deines Bundeslands – doppelter Benefit

- 30 Urlaubstage im Jahr

💼 **Ausstattung & Mobilität**

- Guthaben zur Ausstattung Deines mobilen Arbeitsplatzes

- Deutschlandticket oder Fahrradleasing – Du hast die Wahl

- Optional: BahnCard für noch mehr Reise-Flexibilität

🛡️ **Sicherheit & Vorsorge**

- Unterstützung bei Altersvorsorge & Vermögensaufbau

- Vielfältige Optionen zur finanziellen Absicherung

💡 **Wellbeing & Gesundheit**

- Zugang zum Employee Assistance Program (EAP) – auch für Angehörige

🎁 **Weitere Goodies**

- Prämien für besonderes Engagement

- Exklusive Vorteile über unsere Corporate Benefits-Plattform

- Unsere CBTW-Spotify-Playlist für einen musikalischen Eindruck vom Team 🎧

**Jetzt fehlst nur noch Du – wir freuen uns darauf, Dich kennenzulernen!**

🎵 Schau Dir unsere CBTW-Spotify-Playlist an: [CBTW auf Spotify hören](https://open.spotify.com/playlist/44kgWZRt5jmmgppH0qGszg?si=L312ch_9SMKsCKBcN-EB_A)

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
