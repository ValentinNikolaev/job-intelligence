# Senior Marketing Designer (m/f/d)

Posted: 2026-08-13T09:00:41Z

## Rejection

- Category: tech_stack
- Reason: role does not mention Go/Golang or PHP

## Deine Aufgaben

​​​​​Onepage GmbH is an AI-first SaaS company dedicated to making it incredibly easy for every entrepreneur to build modern, fast, and high-converting websites and landing pages.

With Onepage AI 2.0, we’re bridging the gap between Vibe Coding and no-code: sections and layouts are created via prompts—and remain fully controllable in the visual editor afterward. No lock-in, no “generate once and never touch it again.” That’s what we’re working on—and we’re looking for people who find this problem just as exciting as we do.

**Your responsibilities**

- **Develop creatives for social ads:** Design and develop appealing and effective creatives for various social media channels (Facebook, Instagram, LinkedIn, etc.).

- **Collaborate with our marketing team:** Work closely with our marketing team to ensure consistency of brand messages and C.I. and increase the effectiveness of advertising campaigns.

- **Design and execute:** Develop creative concepts and translate them into visually appealing designs that engage the target audience and help achieve marketing objectives.

- **Optimize our ads:** Continuously analyze and improve the performance of social ads by adjusting and optimizing creatives based on feedback and performance data.

- Create visual concepts and assets for landing pages, and execute them using our own AI-assisted page builder software.

- Create reports, infographics and presentation designs.

- Develop creatives for Google display ads, image extensions.

## Dein Profil

- **Experience:** You have at least 3-5 years of graphic design experience, preferably in social media advertising and marketing.

- **Design Tools:** You have in-depth knowledge of common design tools such as Figma and the Adobe Creative Suite (Photoshop, Illustrator, InDesign).

- **Ad-Creation:** You have experience in creating static and motion ads (Meta, Instagram, LinkedIn).

- **AI Proficiency:** You have first experience in working with AI assistants to draft out concepts and visuals, and are generally open to explore the possibilities of AI.

- **User Empathy:** You have the ability to understand the needs of our users and create engaging and functional designs based on this.

- **Aesthetics:** You have a strong sense of aesthetics and the ability to quickly develop creative and innovative design solutions.

- **Communications:** You have excellent communication skills and the ability to work effectively in a remote team.

- **Organization:** You have a structured approach to your work and the ability to manage multiple priorities effectively.

## Worauf du dich freuen kannst:

- **Long-term Perspective:** Become part of a modern, innovative company with a promising future.

- **Remote-First:** Work 100% remotely and enjoy maximum flexibility in your day-to-day work life.

- **Flat Hierarchies:** Benefit from short decision-making paths and direct communication.

- **Health:** Your health is important to us – we support you with supplemental health insurance and a subsidy for the Wellhub health program.

- **Sustainable Benefits:** Receive attractive employee discounts across many categories via FutureBens.

- **Collaboration & Growth:** Actively contribute your ideas, help shape processes, and expand your skills through continuous learning and development.

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
