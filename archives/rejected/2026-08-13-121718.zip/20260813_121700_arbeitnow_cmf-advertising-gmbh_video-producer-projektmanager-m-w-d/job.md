# Video Producer & Projektmanager (m/w/d)

Posted: 2026-08-13T07:30:31Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**Tuning ideas into impact.**

Wir machen aus „How?" ein „Wow!" mit kreativer Strategie, innovativer Technologie und messbarem Impact. Wir sind eine Full-Service-Agentur und vereinen alle Disziplinen unter einem Dach, ob digital oder analog, klassisch oder crazy, und entwickeln seit über 42 Jahren für namhafte Kunden wie Allianz, Coca-Cola, BMW, Nestlé und Rewe Kampagnen, die begeistern. Verstärke unser rund 100-köpfiges Team am Standort Oberursel als:

**Video Producer & Projektmanager (m/w/d)**

Deine Mission

Mit deinem Organisationstalent bringst du Struktur in kreative Videoprojekte und sorgst dafür, dass Produktionen vom Briefing bis zur finalen Ausspielung zuverlässig laufen. Als Schnittstelle zwischen Kreation, Beratung, Kunden, Produktion und externen Partnern gehst du offen auf Menschen zu und hältst alle Fäden zusammen. Vor Ort am Set hast du ein feines Gespür dafür, wenn etwas nicht nach Plan verläuft. In solchen Momenten bringst du mit Ruhe und Lösungsorientierung alles wieder in die Spur.

## Aufgaben

- Du steuerst Video- und Content-Produktionen vom Briefing bis zur finalen Veröffentlichung

- Du koordinierst vor dem Dreh Konzepte, Skripte, Manuskripte, Shotlists, Timings und Zuständigkeiten

- Du erstellst Produktionspläne, Ablaufpläne und Briefings und stellst sicher, dass alle Beteiligten rechtzeitig über die relevanten Informationen verfügen

- Du organisierst interne und externe Ressourcen, Locations, Technik, Protagonisten, Dienstleister und weitere Produktionspartner

- Du übernimmst bei Drehs die Aufnahmeleitung, sorgst für einen strukturierten und reibungslosen Ablauf am Set

- Du behältst Zeitplan, Qualität und Produktionsziele im Blick und reagierst souverän auf kurzfristige Änderungen

- Du koordinierst nach dem Dreh die Sichtung, den Videoschnitt, Korrekturschleifen und die weitere Postproduktion

- Du bündelst Feedback aus Kreation, Beratung und Kundenteams und sorgst für klare, umsetzbare Abstimmungen

- Du begleitest die Finalisierung, Freigabe und Adaption der Inhalte für unterschiedliche Plattformen, Kanäle und Formate

- Du führst abschließende Qualitätschecks durch und stellst sicher, dass alle finalen Assets vollständig, korrekt benannt, dokumentiert und distribuiert werden

- Du entwickelst bestehende Produktionsprozesse weiter und bringst neue Tools, Workflows und KI-Anwendungen sinnvoll in die Zusammenarbeit ein

## Qualifikation

- Ausgeprägtes Organisationstalent und Freude daran, viele Fäden gleichzeitig zusammenzuhalten

- Berufserfahrung in der Organisation und Steuerung von Video-, Film- oder Content-Produktionen, idealerweise im Agentur-, Produktions- oder Marketingumfeld

- Gutes Verständnis für die Abläufe einer Videoproduktion von Konzeption und Pre-Production über den Dreh bis zur Postproduktion und Ausspielung

- Grundverständnis für Videoschnitt und Postproduktion, zum Beispiel mit Adobe Premiere Pro, DaVinci Resolve oder vergleichbaren Tools

- Du bist offen, gehst aktiv auf Menschen zu und hast Freude an der Zusammenarbeit mit unterschiedlichen Gewerken

- Offene, verbindliche und lösungsorientierte Kommunikation im Team und im Kundenkontakt

- Strukturierte, eigenverantwortliche und zuverlässige Arbeitsweise

- Du behältst auch unter Zeitdruck einen kühlen Kopf und findest pragmatische Lösungen

- Kreatives und filmisches Verständnis sowie ein gutes Auge für Qualität, Dramaturgie und Markenwirkung

- Erfahrung im Einsatz von KI-Tools zur Unterstützung von Konzept-, Produktions- oder Postproduktionsprozessen ist von Vorteil

- Sehr gute Deutschkenntnisse und gute Englischkenntnisse

## Benefits

- Ein modernes, klimafreundliches Büro in Oberursel

- Attraktive Vergütung plus End-of-Year-Bonus

- Betriebliche Altersvorsorge mit bis zu 50 Prozent Arbeitgeberzuschuss

- Vermögenswirksame Leistungen

- 28 Tage Urlaub

- Hybrides Arbeiten und flexible Arbeitszeiten

- Laptop und Firmenhandy bei Bedarf

- Kostenlose alkoholfreie Getränke und eine firmeneigene Bar

- Regelmäßige Team-Events

**Ready to make an impact?**

Dann freuen wir uns auf deine Bewerbung!

Bitte sende deine vollständigen Unterlagen inklusive Gehaltsvorstellung und möglichem Eintrittstermin als PDF an unsere Ansprechpartnerin Bettina Reiner

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
