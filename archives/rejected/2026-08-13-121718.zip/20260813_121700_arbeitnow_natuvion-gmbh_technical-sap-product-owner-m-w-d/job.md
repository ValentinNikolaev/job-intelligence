# Technical SAP Product Owner (m/w/d)

Posted: 2026-08-13T08:30:12Z

## Rejection

- Category: tech_stack
- Reason: role does not mention Go/Golang or PHP

Als **Technical SAP Product Owner (m/w/d)** übernimmst du eine Schlüsselrolle in der Weiterentwicklung unseres Natuvion DCS Produktportfolios. Du arbeitest eng mit internen Stakeholdern, Partnern, Kunden sowie funktionsübergreifenden Delivery-Teams zusammen, um sicherzustellen, dass unsere Produkte echten Mehrwert schaffen und Natuvion strategisch voranbringen.

**Deine Aufgaben:**

-

Verantwortung für die Produktvision, Strategie und Zielerreichung eines oder mehrerer Produkte innerhalb des Natuvion DCS Portfolios rund um den Themenkomplex SAP Datenmigration & -transformation (inkl. Anonymisierung, Validierung und Vervielfältigung von Daten)

-

Definition, Verwaltung und Priorisierung des Product Backlogs mit starkem Fokus auf Kundennutzen und Business Impact

-

Zentrale Ansprechperson für Service Owner, Kunden, funktionsübergreifende Delivery-Teams, Vertrieb, Marketing und Partnerunternehmen

-

Enge Zusammenarbeit mit dem Technical Lead, um Prioritäten in skalierbare, qualitativ hochwertige und technisch umsetzbare Lösungen zu übersetzen

-

Aufbereitung von Initiativen in Epics und User Stories sowie Anforderungsklärung in Zusammenarbeit mit technischen und fachlichen Stakeholdern

-

Sicherstellen, dass Backlog‑Items der Definition of Ready entsprechen und ausgelieferte Features die Definition of Done erfüllen

-

Interne und externe Repräsentation des Produkts sowie selbstbewusste Kommunikation von Fortschritten, Prioritäten und Ergebnissen

#### Dein Profil:

-

Studium der (Wirtschafts‑) Informatik, oder eine vergleichbare Qualifikation

-

5+ Jahre Erfahrung im SAP/ABAP‑Umfeld, idealerweise mit praktischem Entwicklungs‑Background

-

Nachweisbare Erfahrung in Product Thinking, Backlog‑Management, Requirements Engineering und Priorisierung

-

Ausgeprägte Kommunikationsfähigkeiten mit der Fähigkeit, zwischen fachlichen und technischen Perspektiven zu vermitteln

-

Strukturierte Arbeitsweise kombiniert mit analytischem, lösungsorientiertem Denken

-

Teamorientierte Arbeitsweise sowie Bereitschaft zur persönlichen Weiterentwicklung

-

Erfahrungen als Product Owner oder Technical Lead von Vorteil

-

Sehr gute Deutsch- und Englischkenntnisse

**Falls du denkst, dass du nicht alle Anforderungen erfüllst: Bei uns sind deiner Entwicklung „keine Grenzen gesetzt“! Geh mit uns gemeinsam deinen Weg – Wir unterstützen dich dabei! Zeige uns einfach wer du bist.**

#### **Was dich bei uns erwartet:**

Ein Umfeld, dass jederzeit offen für Veränderungen und Optimierungen ist. Ein „das war schon immer so“ gibt es bei uns nicht. Du hast die Chance dein Wissen einzubringen, Prozesse zu gestalten, vorhandenen Themen zu standardisieren oder Abläufe zu optimieren. Sei Impulsgeber und bringe uns mit deiner Expertise noch weiter nach vorne!

#### Wir schaffen Rahmenbedingungen, in denen du dich wohlfühlst:

-

Home-Office Verträge & absolute Flexibilität durch freie Gestaltung der Arbeitszeit

-

Unbefristete Festanstellung und 30 Tage Urlaub

-

FlexWork: Bis zu 3 Monate pro Jahr remote aus dem europäischen Ausland arbeiten

-

Monatliches Budget für individuell wählbare Benefits aus über 50 möglichen Angeboten über emplu, verschiedene Angebote über Corporate Benefits, sowie Fahrrad- und Autoleasing per Gehaltsumwandlung

-

Mental Health Benefit 'Nilo' – 10 kostenlose Sessions mit Psycholog:innen jährlich sowie Zugang zu Meditationen und Kursen

-

Wir unterstützen dich gezielt bei deiner fachlichen und persönlichen Entwicklung bei Natuvion

-

Mentorenprogramm für eine strukturierte und persönliche Einarbeitung

-

**Werde Teil des #teamgreen - **Bei Natuvion arbeitest du an innovativen Projekten als Teil eines Teams, das füreinander einsteht. Wir setzen auf Zusammenarbeit, Offenheit und Vertrauen

-

Modernes Equipment und zentrale Büros in Walldorf, Berlin, München und Leipzig

-

Uns ist deine langfristige Perspektive wichtig, deshalb bezuschussen wir deine betriebliche Altersvorsorge sowie vermögenswirksame Leistungen

**Join #teamgreen **- Natuvion ist ein digitales Umzugsunternehmen.

Unser Team bewegt keine Tische, Aktenschränke oder Stühle. Natuvion transportiert geschäftskritische Daten und Prozesse von einer Technologieplattform auf eine andere. Typische Natuvion „Umzugsdienstleistungen“ umfassen Datenmigration, Datentransformation, Datenintegration, Datenschutz, Datensicherheit und Datenqualität.

Unsere >400 BeraterInnen und EntwicklerInnen in Deutschland, Österreich, Slowakei, USA und Australien verfügen über weitreichendes Knowhow bei (SAP®-)Projekten und ein profundes Prozessverständnis über Branchengrenzen hinweg. Mit viel Erfahrung, Engagement und Einsatz begleiten sie unsere Kunden mit Beratung, Dienstleistung und eigener Softwaretechnologie. So ermöglichen wir Unternehmen, ihre Daten und Prozesse immer auf den modernsten und innovativsten Plattformen zu nutzen.

Du bist interessiert? Wir freuen uns auf deine Bewerbung und darauf, dich kennenzulernen!
Sende uns gerne deinen Lebenslauf zu, ein Anschreiben benötigen wir nicht.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
