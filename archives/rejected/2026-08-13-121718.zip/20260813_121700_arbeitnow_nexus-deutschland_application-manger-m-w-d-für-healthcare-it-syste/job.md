# Application Manger (m/w/d) für Healthcare IT-System

Posted: 2026-08-13T08:00:27Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Bei Nexus Deutschland bist du als Application Manager (m/w/d) für Healthcare IT-Systeme Teil eines leidenschaftlichen Teams, das an der Spitze der E-Health-Innovation steht. Unsere Mission ist es, Prozesse im Gesundheitswesen zu vereinfachen und effizienter zu gestalten. Mit deinem Know-how und deiner Kreativität unterstützt du Reha-Kliniken und Gesundheitseinrichtungen dabei, sich auf das Wesentliche zu konzentrieren. Wenn du Herausforderungen liebst und Wert auf Kommunikation, Fairness und Innovation legst, passt du perfekt zu uns. Wir schätzen Eigenverantwortung und gegenseitigen Respekt, während wir mit den neuesten Technologien arbeiten. Sei ein Teil unserer Vision und trage dazu bei, die Gesundheitsversorgung in Europa nachhaltig zu verbessern!

## Aufgaben

- Beratung unserer Krankenhauskunden zu der Gestaltung klinischer Prozesse

- Anwenderbetreuung

- Parametrierung unserer Software mit den Schwerpunkten elektronische Patientenakte

- Anwenderschulungen und Präsentationen

## Qualifikation

- Sie haben eine pflegerische, pharmazeutische oder therapeutische Ausbildung bzw. entsprechende Berufserfahrung in diesen Bereichen

- IT-Kenntnisse sind von Vorteil

- Sie besitzen ein sicheres und souveränes Auftreten

- Sie haben Interesse an einer abwechslungsreichen Tätigkeit

- Sie sind Kommunikationsstark

## Benefits

- Eine strukturierte Einarbeitung und Betreuung durch einen Mentor

- Vielfältige Entwicklungsmöglichkeiten durch Einbettung in die NEXUS-Gruppe

- Flache Hierarchien und ein offenes, unkompliziertes Arbeitsumfeld

- Echte Teamarbeit bei kollegialer und Atmosphäre und gegenseitiger Unterstützung

- Eine ausgeglichene Work-Life-Balance durch flexible Arbeitszeiten und Home Office Option

Werde Teil unseres Teams als Application Manager (m/w/d) für Healthcare IT-Systeme und gestalte die Zukunft der digitalen Gesundheit mit innovativen Lösungen. Bewirb dich jetzt und mach den Unterschied!

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
