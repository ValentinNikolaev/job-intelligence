# Senior Software Developer: Python (m/w/d)

Posted: 2026-08-13T09:00:42Z

## Rejection

- Category: tech_stack
- Reason: role does not mention Go/Golang or PHP

Du arbeitest strukturiert, behältst auch in komplexen Situationen den Überblick und willst deine Handschrift in einem Produkt hinterlassen, das täglich im Einsatz ist, vom Mittelständler bis zum Konzern? Dann passt du zu uns.

Wir sind ein dynamisches, hoch motiviertes Team mit familiärem Umgang. Als Ausgleich zur Remote-Arbeit treffen wir uns einmal pro Monat in Dülmen und zweimal pro Jahr für Team-Events an besonders spannenden Orten dieser Welt.

## Aufgaben

- Du **verantwortest neue Features end-to-end**: Du hinterfragst Anforderungen, entwirfst tragfähige Architekturen, implementierst sie und begleitest sie bis in den Produktivbetrieb.

- Du setzt **technische Standards**: Du prägst unsere Test- und Review-Kultur, gibst im Code-Review fundiertes Feedback und sorgst mit klarer Dokumentation dafür, dass unsere Plattform langfristig wartbar bleibt.

## Qualifikation

- **Mehrjährige Berufserfahrung in der Softwareentwicklung**: du hast bereits Features eigenverantwortlich von der Konzeption bis in den Betrieb gebracht und Systeme über längere Zeit weiterentwickelt.

- Technisches Verständnis von **Python-basierten Webanwendungen** (z. B. Django, Vue.js, Docker, Kubernetes, REST-APIs, Linux).

- Erfahrung im Umgang mit **Code-Reviews**, Qualitätssicherung und sauberen Entwicklungsprozessen.

- **Grundverständnis für IT-Security**, sichere Softwareentwicklung, Datenschutz und den Umgang mit sensiblen Daten.

- Strukturierte Arbeitsweise, ausgeprägtes analytisches Denken sowie hohe Sorgfalt beim **Testen** und **Dokumentieren.**

- Hilfsbereitschaft, Teamorientierung und sehr gute Kommunikationsfähigkeiten.

- **Deutsch auf Muttersprachenniveau** sowie sehr gute Englischkenntnisse.

## Benefits

- **Flexibles Arbeiten:** Unsere sehr flexiblen Arbeitszeitmodelle geben dir maximale Freiheit.

- **Remote-Arbeitsplatz:** Du kannst vollständig remote arbeiten – unabhängig vom Ort.

- **Work-Life-Balance:** Durch flexible Arbeitszeiten und die Möglichkeit, im **EU-Ausland zu arbeiten (Workation)**, findest du den passenden Ausgleich zwischen Beruf und Privatleben.

- **Persönliche Freiheit & Eigenverantwortung:** Bei uns kannst du eigenständig arbeiten, Entscheidungen treffen und Ideen direkt umsetzen. Du gestaltest Produkt, Prozesse und Technik aktiv mit.

- **Teamkultur:** Dich erwarten ein hilfsbereites, unkompliziertes Team, **Offsites zweimal im Jahr** und regelmäßige **Team-Events** für echten Austausch.

- **Individuelle Unterstützung:** Wir unterstützen dich im Alltag – sei es bei Hardware-Wünschen (MacBook der neuesten Generation) oder zusätzlichen Tools, die dir das Arbeiten erleichtern.

- **Karriere & Weiterentwicklung:** Durch kurze Wege und ein wachsendes Umfeld bieten sich dir **schnelle Aufstiegsmöglichkeiten.**

- **Stabilität & Sicherheit:** Du erhältst einen **unbefristeten Arbeitsvertrag** und arbeitest an einem etablierten SaaS-Produkt mit echter Marktpräsenz.

- **Top Arbeitgeber:** Wir freuen uns über **5,0 Sterne auf Kununu** und eine **100 % Weiterempfehlungsquote.** Ein starkes Signal für unsere Teamkultur und Arbeitsweise.

Wenn du Lust auf moderne Technologien und ein Umfeld hast, in dem deine Arbeit wirklich zählt, freuen wir uns darauf, dich kennenzulernen.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
