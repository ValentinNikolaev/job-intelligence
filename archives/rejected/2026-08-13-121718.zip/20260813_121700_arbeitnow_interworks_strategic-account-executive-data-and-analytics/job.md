# Strategic Account Executive - Data and Analytics

Posted: 2026-08-13T05:55:40Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

InterWorks is seeking an experienced Enterprise Account Executive to drive new data and analytics consultancy revenue with mid‑market and enterprise clients. This is a quota‑carrying, full‑cycle role focused on new logo acquisition and expansion, selling complex data solutions across multiple stakeholders (IT, data, and business leadership). Success in this role requires 7+ years of B2B SaaS or consulting sales, including closing six‑figure deals with enterprise or upper mid‑market accounts. You will focus on UK and EMEA mid‑market and enterprise clients across industries such as financial services, retail, and manufacturing, partnering with a highly skilled team of data consultants to position differentiated solutions, not just products.

## **What You’ll Do**

- Own the full sales cycle from prospecting to close for mid‑market and enterprise accounts in your territory.

- Consistently build and manage a qualified pipeline to meet and exceed an annual quota on data and analytics consulting services.

- Lead complex, multi‑stakeholder sales cycles with technical and business buyers, including C‑level and VP‑level executives.

- Originate and develop trusted relationships with prospects by understanding their business objectives and presenting relevant data service offerings.

- Collaborate with solutions architects and consulting teams to shape, propose, and position InterWorks’ data and analytics solutions and services.

- Negotiate commercial terms, structure six‑figure services engagements, and manage procurement and legal processes through to signature.

- Represent InterWorks at industry events and through targeted outreach to create and progress new opportunities.

- Maintain accurate pipeline, forecasting, and account plans in Salesforce, ensuring all activities and next steps are clearly documented.

### What You’ll Need

- 7+ years of B2B sales experience in technology, SaaS, or consulting services.

- 3+ years in a quota‑carrying Account Executive role (not SDR/BDR).

- Proven track record of meeting or exceeding annual quota.

- Experience closing deals of at least 50,000 - 100,000+ ACV or services value.

- Experience selling into mid‑market or enterprise accounts with multiple stakeholders and complex decision processes.

### What We’d Like You to Have

- Experience selling data, analytics, BI, or cloud solutions.

- Experience working with or selling around Salesforce and modern data platforms.

- Prior experience in a consultancy or professional services environment.

Skills & Attributes

- Strong written and oral communication skills, with a consultative, outcome‑focused selling style.

- Business acumen, technical acumen, and the ability to translate complex data concepts into clear business value.

- Ability to clarify a prospect’s challenge, articulate the problem, propose a solution, coordinate across departments, and follow through on architecting the sales effort.

- Ability to build and maintain a robust sales pipeline while delivering accurate forecasting to sales leadership.

- Creative problem‑solving and analytical skills, with high attention to detail and the ability to work under pressure.

- Curiosity, resilience, and a positive, collaborative attitude.

**What We Offer**

- €90,000-180,000 - final compensation will be commensurate with experience and performance, including the scope and success of services closed.

- A collaborative and supportive team culture focused on ongoing learning and growth.

- Access to leading vendor training, certifications, and industry events.

- Opportunity to work with cutting-edge enterprise clients on transformational data and AI projects.

- InterWorks is committed to a diverse, inclusive work environment. We encourage qualified candidates from all backgrounds to apply.

InterWorks sucht eine erfahrene Enterprise Account Executive Person, um neue Umsätze im Bereich Data‑ und Analytics‑Consulting mit Mid‑Market‑ und Enterprise‑Kund:innen im DACH‑Raum vorantreibt. Diese Rolle ist quota‑tragend, umfasst den vollständigen Vertriebszyklus und fokussiert sich auf die Gewinnung neuer Kund:innen (New Logo Acquisition) sowie die Erweiterung bestehender Kundenbeziehungen, indem komplexe Datenlösungen an mehrere Stakeholder (IT, Data und Business‑Führungskräfte) verkauft werden.

Erfolg in dieser Rolle setzt mindestens 7 Jahre Erfahrung im B2B‑Vertrieb von SaaS‑Lösungen oder Beratungsleistungen voraus, einschließlich des Abschlusses von Deals im sechsstelligen Bereich mit Enterprise‑ oder Upper‑Mid‑Market‑Accounts. Es handelt sich um eine Senior‑Individual‑Contributor‑Position mit wettbewerbsfähigem Grundgehalt zuzüglich variabler Vergütung, abhängig von Erfahrung und Leistung. Ihr Fokus liegt auf Mid‑Market‑ und Enterprise‑Kund:innen in der DACH‑Region in Branchen wie Health & Life Science, Retail und Manufacturing, in enger Zusammenarbeit mit einem hochqualifizierten Team von Data‑Consultants, um differenzierte Lösungen statt reiner Produkte zu positionieren.

Diese Position ist in Berlin, Deutschland, angesiedelt, und wir suchen in erster Linie Kandidat:innen aus Berlin, die unsere Unternehmenskultur im Büro bereichern.

## Ihre Aufgaben

- Eigenverantwortliche Steuerung des gesamten Sales‑Zyklus von der Neukundenakquise bis zum Abschluss für Mid‑Market‑ und Enterprise‑Accounts in Ihrem Gebiet.

- Kontinuierlicher Aufbau und aktive Steuerung einer qualifizierten Pipeline, um das jährliche Umsatzziel im Bereich Data‑ und Analytics‑Consulting‑Services zu erreichen und zu übertreffen.

- Führung komplexer, mehrstufiger Verkaufszyklen mit technischen und fachlichen Entscheider:innen, einschließlich C‑Level‑ und VP‑Ebene.

- Aufbau und Entwicklung vertrauensvoller Beziehungen zu Interessent:innen durch Verständnis ihrer Geschäftsziele und Präsentation relevanter Data‑Service‑Angebote.

- Zusammenarbeit mit Solution Architects und Consulting‑Teams, um InterWorks Data‑ und Analytics‑Lösungen und ‑Services zu gestalten, anzubieten und optimal zu positionieren.

- Verhandlung kommerzieller Konditionen, Strukturierung von Service‑Engagements im sechsstelligen Bereich sowie Steuerung von Einkaufs‑ und Rechtsprozessen bis zur Unterschrift.

- Repräsentation von InterWorks auf Branchenveranstaltungen und durch zielgerichtete Outreach‑Aktivitäten zur Generierung und Weiterentwicklung neuer Opportunities.

- Pflege einer präzisen Pipeline, Forecasts und Account‑Pläne in Salesforce und Sicherstellung, dass alle Aktivitäten und nächsten Schritte klar dokumentiert sind.

Mindestanforderungen

- Mindestens 7 Jahre B2B‑Vertriebserfahrung im Technologie‑, SaaS‑ oder Consulting‑Umfeld.

- Mindestens 3 Jahre Erfahrung in einer quota‑tragenden Account‑Executive‑Rolle (nicht SDR/BDR).

- Nachweisbare Erfolgsbilanz in der Erreichung oder Übererfüllung jährlicher Vertriebsziele.

- Erfahrung im Abschluss von Deals mit einem jährlichen Vertragswert (ACV) bzw. Service‑Volumen von mindestens 50.000–100.000+.

- Erfahrung im Vertrieb an Mid‑Market‑ oder Enterprise‑Kund:innen mit mehreren Stakeholdern und komplexen Entscheidungsprozessen.

Bevorzugte Erfahrungen

- Erfahrung im Vertrieb von Data‑, Analytics‑, BI‑ oder Cloud‑Lösungen.

- Erfahrung in der Arbeit mit oder im Umfeld von Salesforce und modernen Datenplattformen.

- Vorerfahrung in einem Beratungs‑ oder Professional‑Services‑Umfeld.

Fähigkeiten & Eigenschaften

- Ausgezeichnete schriftliche und mündliche Kommunikationsfähigkeiten mit einem beratenden, ergebnisorientierten Vertriebsstil.

- Ausgeprägtes Business‑ und Technologieverständnis sowie die Fähigkeit, komplexe Data‑Konzepte in klaren Geschäftsnutzen zu übersetzen.

- Fähigkeit, Herausforderungen von Interessent:innen klar herauszuarbeiten, Probleme zu formulieren, Lösungen vorzuschlagen, bereichsübergreifend zu koordinieren und den gesamten Vertriebsprozess strukturiert zu steuern.

- Fähigkeit, eine robuste Sales‑Pipeline aufzubauen und zu pflegen und gleichzeitig präzise Forecasts gegenüber der Vertriebsleitung zu liefern.

- Kreative Problemlösungs‑ und Analysefähigkeiten, hohe Detailorientierung und Belastbarkeit unter Zeit‑ und Leistungsdruck.

- Neugier, Resilienz sowie eine positive, kollaborative Arbeitshaltung.

**Was wir bieten **

- € 90.000–180.000 Gesamtvergütung – die finale Vergütung richtet sich nach Erfahrung und Leistung, einschließlich Umfang und Erfolg der abgeschlossenen Services.

- Eine kollaborative und unterstützende Teamkultur mit Fokus auf kontinuierlichem Lernen und Wachstum.

- Zugang zu führenden Herstellertrainings, Zertifizierungen und Branchenveranstaltungen.

- Die Möglichkeit, mit führenden Enterprise‑Kund:innen an transformativen Data‑ und KI‑Projekten zu arbeiten.

- InterWorks steht für ein diverses, inklusives Arbeitsumfeld. Wir ermutigen qualifizierte Kandidat:innen aller Hintergründe, sich zu bewerben.

Warum InterWorks

InterWorks ist eine menschenorientierte Tech‑Beratung, die Kund:innen mit maßgeschneiderten, kollaborativen Lösungen befähigt, und wir lieben es, Innovation gemeinsam mit Menschen voranzutreiben, die uns inspirieren. Unser Ansatz für Arbeit und Gemeinschaft ist einzigartig und unkonventionell – genau wie wir – und das soll auch so bleiben. Das Einzige, was noch fehlt, sind Sie. Bei InterWorks schätzen wir individuelle Beiträge; unsere Mitarbeitenden sind das Bindeglied, das unser Unternehmen zusammenhält. Wir sind immer auf der Suche nach den richtigen Menschen – vielleicht sind wir genau Ihr Perfect Fit.

**Why InterWorks**

InterWorks is a people-focused tech consultancy that empowers clients with customized, collaborative solutions, and we love pursuing innovation alongside people who inspire us. Our approach to work and community is unique and unconventional—just like us—and that’s the way we want it. The only thing missing is you. At InterWorks, we value unique contributions, our people are the glue that holds our business together. We’re always looking for the right people, and we could be your perfect fit.

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
