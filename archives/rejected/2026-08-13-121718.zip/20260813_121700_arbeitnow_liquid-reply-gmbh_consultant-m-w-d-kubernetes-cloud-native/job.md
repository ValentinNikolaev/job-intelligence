# Consultant (m/w/d) Kubernetes & Cloud Native

Posted: 2026-08-13T07:30:29Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Liquid Reply ist der Partner für cloud-agnostische Lösungen, Kubernetes Platform Engineering & Cloud Native Development. Mit unseren Ansätzen entwerfen wir skalierbare Umgebungen und migrieren komplexe und schnelllebige Anwendungen. Plattform-Engineering ist die Grundlage und Denkweise, die wir unseren Kunden mit auf den Weg geben, um sie bei der gesamten Cloud Native Transformation zu begleiten.

## Aufgaben

- Beratung unserer Kund:innen bei der technologischen Weiterentwicklung ihrer Kubernetes- und Cloud-Plattformen sowie Unterstützung in Presales-Aktivitäten

- Weiterentwicklung bestehender Kubernetes-Plattformen und Konzeption neuer Self-Service-Funktionen für Entwicklungsteams

- Entwicklung und Optimierung automatisierter Bereitstellungsprozesse mithilfe von CI/CD-Pipelines und GitOps-Workflows

- Verwaltung und Weiterentwicklung moderner Cloud-Infrastrukturen sowie Umsetzung von Cloud-Native-Strategien

- Enge Zusammenarbeit mit Entwicklungs- und Plattformteams zur Integration moderner DevOps-Praktiken in den Softwareentwicklungsprozess

- Übernahme fachlicher Verantwortung im Projektumfeld sowie die Möglichkeit, dich perspektivisch in Richtung Team Lead weiterzuentwickeln

## Qualifikation

- Erfolgreich abgeschlossenes Studium der (Wirtschafts-)Informatik, Informatik oder einer vergleichbaren Fachrichtung

- Mehrjährige praktische Erfahrung im Aufbau und Betrieb von Kubernetes-Plattformen sowie Freude an der Zusammenarbeit mit Kund:innen

- Fundierte Kenntnisse in Kubernetes sowie idealerweise Erfahrung mit Self-Service-Konzepten für Entwicklerteams

- Sehr gute Kenntnisse in CI/CD-Pipelines, GitOps-Workflows (z. B. Argo CD oder Flux), Infrastructure as Code mit Terraform sowie Automatisierung mit Bash/Shell

- Erfahrung mit Observability-Lösungen wie Prometheus, Grafana und Loki sowie Interesse an modernen Cloud-Native-, Platform-Engineering- und AI-nahen Technologien

- Ausgeprägte Kommunikationsfähigkeit, sehr gute Deutsch- und Englischkenntnisse sowie Bereitschaft zu gelegentlichen Reisen im Rahmen von Kundenprojekten

- Interesse daran, fachliche Verantwortung zu übernehmen und dich perspektivisch in Richtung Team Lead weiterzuentwickeln

## Benefits

Zusätzlich zu einem attraktiven Gehalt unterstützen wir deine berufliche Entwicklung. Wir bieten einzigartige Weiterbildungsmöglichkeiten und vergüten Fortbildungen und Zertifizierungen. Als vielfältiges und internationales Team teilen wir unser Wissen und arbeiten zusammen. Das hilft dir, dich weiterzuentwickeln und neue Kenntnisse und Fähigkeiten zu erwerben. Wenn du unsere Leidenschaft für neue Technologien teilst und auf der Suche nach einer spannenden beruflichen Herausforderung bist, werden Teil von Reply!

Vergünstigungen und andere Vorteile:

- Bezahlte Schulungen und Zertifizierungen

- Firmenkreditkarte

- BahnCard 50

- Home-Office-Budget

- Beitrag zu Mitgliedschaften in Fitnessstudios und ähnlichen Sportarten

- Bücher und Online-Kurse

- JobRad

Was uns auszeichnet, ist unsere Expertise bei Cloud-agnostischen Implementierungen und die Fähigkeit, unsere Kunden mit zukunftsweisenden Technologien zu begeistern und innovative Lösungen schnell einzuführen. Wir sind immer auf der Suche nach Enthusiasten, die den Status quo in Frage stellen, neue Ideen ausprobieren und gemeinsam spannende Ziele erreichen wollen.

Bist du bereit?

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
