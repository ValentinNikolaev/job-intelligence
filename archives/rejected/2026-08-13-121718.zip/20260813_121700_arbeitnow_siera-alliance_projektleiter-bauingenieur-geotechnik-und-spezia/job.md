# Projektleiter Bauingenieur Geotechnik und Spezialtiefbau (m/w/d)

Posted: 2026-08-13T07:00:43Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**Über uns

**Rund 800 Mitarbeiterinnen und Mitarbeiter arbeiten in der SIERA Alliance an der Vision einer besseren Zukunft – in den Bereichen Umweltschutz und Klima, Wasser und Ökosysteme, Kreislaufwirtschaft, städtische Nachhaltigkeit, Infrastruktur sowie Impact-Technologie.

Zur Verstärkung unseres Teams in der Abteilung „Geotechnik & Spezialtiefbau“ suchen wir dich als Projektleiter Bauingenieur (m/w/d).

## Tasks

**Deine Aufgaben:**

- Baugrund- und Gründungsberatung sowie Planung und Durchführung geotechnischer Untersuchungen

- Konstruktive und statische Planung geotechnischer Konstruktionen des Erd- und Spezialtiefbaus (z. B. Fundamentierungen, Baugruben, Stützwände, Erdbauwerke) mit GGU- oder DC-Software

- Erstellung geotechnischer Berichte gemäß DIN 4020, Standsicherheitsnachweise und Setzungsberechnungen

- Erarbeitung von Konzepten und Objektplanungen für innerstädtische Baugruben

- Ausschreibung von Baumaßnahmen und Übernahme der Fachbauleitung

- Akquisition, Kundenbetreuung sowie Verhandlungen mit Auftraggebern und Fachbehörden

- Eigenverantwortliche, fachliche, terminliche und wirtschaftliche Abwicklung von Projekten

## Requirements

**Das bringst du mit:**

- Abgeschlossenes Studium des Bauingenieurwesens (TH/FH/HS) mit Schwerpunkt Geotechnik und/oder Statik

- Mehrjährige Berufserfahrung in der eigenverantwortlichen Beratung von Kunden in Baugrundfragen in Deutschland

- Fundierte Kenntnisse der einschlägigen technischen Regelwerke im Bereich Baugrund

- Erfahrung in der Durchführung erdstatischer Berechnungen

- Idealerweise Erfahrung in der Ausschreibung von Baumaßnahmen des Spezialtiefbaus

- Zusätzliche Kenntnisse in Altlastenerkundung, -sanierung, Rückbau oder Geländeherrichtung von Vorteil

- Sicherer Umgang mit gängigen Grundbauprogrammen und MS Office; idealerweise Erfahrung mit GGU-Software

- Sehr gute Deutschkenntnisse in Wort und Schrift (Muttersprachenniveau)

- PKW-Führerschein (Klasse B)

## Benefits

**Was wir dir bieten:**

- Sinnstiftende Aufgaben: Du arbeitest an vielseitigen und herausfordernden Projekten unterschiedlicher Größe mit und trägst damit aktiv zum Umwelt- und Klimaschutz bei

- Familienfreundlicher Arbeitgeber: Flexible Arbeitszeiten, mobiles Arbeiten ist möglich

- Tolles Büro: Gute Verkehrsanbindung und modernste technische Ausstattung (Smartphone, Tablet, Laptop, Monitore); ein engagiertes, junges und professionelles Team freut sich auf dich

- Super Teamspirit: Regelmäßige Team-Events und starkes Miteinander

- Weiterentwicklung: Beste Karriereaussichten sowie attraktive Entwicklungs- und Weiterbildungsmöglichkeiten in einem stabilen Arbeitsumfeld

- Echte Benefits: Leistungsgerechte Bezahlung, arbeitgeberfinanziertes Jobticket, betriebliche Altersvorsorge, Mitarbeiter-werben-Mitarbeiter-Programm, Preisnachlässe über Corporate Benefits, freie Getränke und frisches Obst

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
