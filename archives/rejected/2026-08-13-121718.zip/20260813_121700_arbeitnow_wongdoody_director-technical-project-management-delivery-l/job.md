# Director Technical Project Management / Delivery Lead

Posted: 2026-08-13T08:55:20Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

WongDoody creates human experiences at 24 studios across 4 continents. We believe the future can be molded. And by shaping human experiences through creativity and tech, we work to build a future we believe in.

For us, this starts with our own culture. We strive to create an inclusive environment where every human can bring their whole self to work. Our clients are brands we believe in, from global big players to local heroes to startups we love. With each of our partners, we embark on a journey of co-creation, pushing the boundaries of what's possible and exploring the space where creativity and tech meet.

Our team of fun, welcoming, values-driven and collaborative problem solvers has one focus at the heart of everything we do: human experience. Human experiences are the touchpoints where brands connect with customers. And we transform businesses by creating engaging, inspiring moments using strategy, creativity, data and technology—all backed by the global technological power of Infosys.

**Experience & Tech**

We are a cross-unit and cross-location tech and experience team. With more than 50 developers, UX designers and consultants working directly with other WongDoody teams, we are team players and specialists—both in frontend and backend. As part of Infosys, we belong to a leading global technology company with access to solutions and extensive know-how in the fields of commerce, marketing automation and AI, among others.

**Our local benefits**

- Flexible working hours and 100% overtime compensation
- Work where it works for you. At home or in the office, or any mix you like
- Working for strong brands and clients we believe in
- 30 days' vacation per year
- Company Benefits
- Urban Sports Club
- Nice people in welcoming teams

**What you can expect**

We are looking for you to lead our team in Germany as Director of Technical Project Management and Project Delivery, working on exciting international projects within interdisciplinary teams.

You will be responsible for planning and managing the Technical Project Management Team (approx. 5–10 people) and its activities, as well as for the professional and personal development of team members.

Your tasks and responsibilities will also include:

- Implementing strategies to improve team and delivery performance, and providing regular reports.
- Assisting with the recruitment of new team members and relevant partners.
- Strategic and operational management of complex development and AI projects, including independent management of pitches, presentations and workshops
- Analyzing new project enquiries and deriving recommendations for action — with a focus on feasibility, staffing, efficiency and potential.
- Leading interdisciplinary project teams (including backend, frontend and full-stack developers, AI engineers, and UI/UX designers) within the WongDoody Group and Infosys service lines — both nationally and internationally.
- Supporting the development of AI-driven solutions in close collaboration with experts.
- Contributing to the strategic development of the business unit in collaboration with management.

**What we'd love to see**

- You have at least 5 years’ professional experience as a Technical Project Manager or Delivery Manager in an agency or services environment.
- Experience in team leadership and development.
- Strong experience in client relations and consulting, as well as scaling digital processes.
- Excellent skills in coordinating complex digital, AI and development projects, including leading interdisciplinary teams.
- Familiarity with common PM tools (Jira, Confluence, Salesforce, etc.).
- Curiosity about new technologies, workflows, and digital trends.
- Advantage: experience with CGI, real-time workflows and MarTech solutions.
- You work independently and are characterized by a positive, solution-oriented and hands-on mindset.
- Flexibility to travel within Germany and internationally to collaborate with clients and global delivery teams when required.
- Fluent German (C1/C2) and good English skills (B2+) are essential.

You’ll shape how complex digital and AI projects are delivered at scale — building high-performing teams, creating efficient delivery structures, and turning ambitious ideas into reliable, high-quality outcomes for clients.

We care about your personality and professional skills. We don't care about your gender, age, nationality or appearance and are open to working with everyone.

Please note: This is a job ad by WongDoody GmbH, based in Germany. Through our website or other sources, you may find job ads published by one of our WongDoody sister companies around the globe with whom we act jointly under the brand “WongDoody”. For each job offer, only the entity which published the ad is responsible. Contact people, required information and applicable terms may differ. Read more about how WongDoody GmbH processes your personal data in the application process [here](https://www.wongdoody.com/de-privacy).

If you have any questions about the application process, please feel free to contact our People & Culture Team directly at -----

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
