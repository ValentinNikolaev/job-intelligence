# Senior Social Consultant

Posted: 2026-08-13T08:55:20Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Wir sind mehr als 2.000 Kolleg:innen in 24 Designstudios auf vier Kontinenten – ein hochgradig kollaboratives Team aus Expert:innen für Produkterlebnisse, digitales Marketing und immersive Technologien. Unsere Lösungen entstehen dort, wo Kreativität und Technologie zusammentreffen – mit einem klaren Fokus auf die Bedürfnisse und Erlebnisse der Nutzer:innen. Ob Augmented Reality, Digital Twins, KI-Ökosysteme, Omnichannel-Commerce oder integrierte Kampagnen: Wir schaffen Verbindungen zwischen Menschen und Marken – im B2B- ebenso wie im B2C-Bereich.

Als Teil des globalen Technologieinnovators Infosys verfügen wir über die nötige Skalierung und Expertise, um große Ideen Wirklichkeit werden zu lassen – und sie weltweit umzusetzen.

**Retail & CPG Vertical **

Unser Team aus über 50 Personen ist auf FMCG und Einzelhandel spezialisiert. Gemeinsam mit starken, einzigartigen Marken wie OTTO, dm- drogerie markt, Bosch sowie eines der führenden Unternehmen der Entertainmentbranche entwickeln wir neue Markenstrategien, kundenzentrierte Kampagnen und digitale Produkte. Wir finden neue Wege, Kreation, Daten und Medien zu kombinieren.

**Dein Rolle als Senior Social Consultant**

Du kennst Social Media nicht nur – du lebst es. Trends erkennst du, bevor sie viral gehen. Du weißt, wie große Entertainment-Brands auf TikTok, Instagram & Co. klingen müssen, um nicht cringe zu wirken.

Der Großteil deiner Zeit gehört einer der bekanntesten Entertainment-Brands der Welt – einem Kunden, bei dem Social Media täglich in Echtzeit stattfindet. Den Rest nutzt du, um agenturintern neue Standards im Social-First-Thinking zu setzen: auf Bestandskunden, im New Biz, überall dort, wo Social noch nicht auf dem Level ist, auf dem es sein sollte.

**Unsere lokalen Benefits**

- Flexible Arbeitszeiten und Arbeitszeitkonto mit 100 % Überstundenausgleich
- Arbeiten, von wo es dir passt – im Homeoffice, in einem unserer Büros (Stuttgart & Berlin) oder sogar befristet im EU-Ausland
- Kostenlose Snacks und Getränke in unseren Büros
- Ein innovatives Arbeitsumfeld mit moderner, technischer Ausstattung – MacBook, dienstliches iPhone zur Erstellung von Content (17 Pro Max) sowie alle für deine Arbeit relevanten Tools
- Weiterbildungsangebote, um stets up-to-date zu bleiben
- 30 Urlaubstage jährlich & je ½ zusätzlicher freier Tag an Weihnachten und Silvester
- Zuschuss beim Urban Sports Club
- ﻿Mitarbeitervorteile & Rabatte über Corporate Benefits
- Ein inspirierendes Team, mit welchem die Zusammenarbeit für starke Marken Spaß macht

**Das erwartet Dich**

- Social-Direktive: Du gibst vor, wie eine Brand auf den relevanten Plattformen auftreten soll und stellst sicher, dass das Team das konsequent umsetzt
- Du verantwortest die Qualität des Social-Outputs: Du reviewst Content, gibst Feedback und sorgst dafür, dass nichts rausgeht, was nicht in Balance mit Plattformlogik, aktuellem Zeitgeist und der Positionierung der Marke steht
- Du arbeitest selbst auch hands-on: Du verstehst den gesamten Content-Zyklus – von der kreativen Umsetzung bis zum analytischen Reporting – und kannst mit unseren Expert:innen auf Augenhöhe darüber sprechen
- Kundenberatung auf Senior-Level: Du führst Meetings mit Klarheit und Haltung, kannst Entscheidungen fachlich begründen und auch mal pushback geben, wenn etwas nicht nach Social-Logik funktioniert
- Hand-in-Hand mit deinen Social-Kolleg:innen und allen weiteren Teams stellst du sicher, dass alle Disziplinen in die gleiche Richtung ziehen – ohne deren Ownership zu übernehmen

**Das bringst Du mit**

- Du bist genuinely chronically online: Plattformen, Zeitgeist und Trends – das ist dein natürlicher Lebensraum, kein Arbeitsaufwand
- Du hast ein ausgeprägtes Qualitätsbewusstsein und gibst gerne klar und konstruktiv Feedback
- Du bist es gewohnt, in komplexen Strukturen zu arbeiten: viele Ansprechpartner:innen, hoher Output und schnelles Tempo schrecken dich nicht ab
- Erfahrung mit großen Brands, die social-first groß schreiben
- Entertainment und Popkultur sind dein Ding – du weißt, wie dieser Space auf Social tickt und leitest daraus Human Insights ab
- Grundverständnis von Paid Social, Creator Marketing und Reportings helfen dir, fundierte Aussagen zu treffen

Klingt nach Dir? Dann schnapp Dir Deinen Laptop und bewirb Dich – wir freuen uns, Dich auf unserer kreativen Reise dabei zu haben!

Für u﻿ns zählt allein Deine Persönlichkeit und Deine beruflichen Fähigkeiten. Dein Geschlecht, Alter oder Aussehen, Deine Herkunft oder sexuelle Orientierung spielen für uns keine Rolle – wir sind offen für die Zusammenarbeit mit jeder Person.

Beachte bitte: Dies ist eine Stellenanzeige der WongDoody GmbH mit Sitz in Deutschland. Über unsere Website oder andere Quellen kannst Du zu Stellenanzeigen gelangen, die von einer unserer WongDoody-Schwesterfirmen veröffentlicht wurden, mit denen wir weltweit gemeinsam unter der Marke "WongDoody" auftreten. Für jedes Stellenangebot ist ausschließlich das Unternehmen verantwortlich, das die jeweilige Anzeige veröffentlicht hat. Ansprechpartner:innen, erforderliche Angaben und geltende Bedingungen können jeweils abweichen. [Hier](https://www.wongdoody.com/wongdoody-germany-privacy) kannst Du Dich darüber informieren, wie die WongDoody GmbH Deine im Bewerbungsprozess angegebenen personenbezogenen Daten verarbeitet.

Wenn Du Fragen zum Bewerbungsprozess hast, wende Dich gerne direkt an unser People & Culture-Team -----

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
