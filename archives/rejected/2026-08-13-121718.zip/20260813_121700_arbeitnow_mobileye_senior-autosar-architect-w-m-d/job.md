# Senior Autosar Architect (w/m/d)

Posted: 2026-08-13T08:25:28Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Mobileye’s Automotive Software development team is looking for SW developers to work on the cutting-edge of technologies bringing to market Mobileye Autosar self driving platforms.

We are looking for experienced MCU architect who are passionately motivated by challenges and excel in troubleshooting complex problems.

**What will you job look like ?**

- Design and develop and communicate the SW architecture.

- Support the SW detailed design, SW integration and SW architecture verification.

- Support SW execution PM in defining work packages and assigning them to deliveries.

- Apply methods to analyze a SW architectural model w.r.t functional safety (SW event tree analysis) or cybersecurity.

**All you need is:**

- SW engineering qualification\ [B.SC](http://B.SC) in information technology

- 7+ years experience in embedded SW development

- knowledge in various application domains, including HW and SW

- 7+ years experience in code based automation

- Training and experience in applying methods for: SW design, Requirements Management, Automotive SPICE, Autosar, Functional Safety Implementation

- Knowledge about architecture and design patterns (layering, pipes, error handling, structure patterns)- a Must

Mobileye changes the way we drive, from preventing accidents to semi and fully autonomous vehicles. If you are an excellent, bright, hands-on person with a passion to make a difference come to lead the revolution!

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
