# Growth Marketing Manager (m/w/d) in Vollzeit

Posted: 2026-08-13T10:00:42Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**marswalk macht Unternehmen Zukunftssicher - indem wir sie für zukünftige Generationen relevant machen.**

Wir sind halb Agentur, halb Start-up. Gestartet als TikTok Agentur unterstützen wir heute Unternehmen vollumfänglich dabei Relevanz in jungen Zielgruppen zu gewinnen:

mit Social Media Services, GEO, Marktforschung, Strategie, Events, E-commerce und umfangreichen in-House Softwarelösungen.

Wir transformieren die Agentur geradie in ein Agency as a Software konzept mit dem Ziel zur relevantesten AI-enabled Agentur in Europa zu skalieren.

Wir pushen Exzellenz in unserer Arbeit, sind ambitioniert und sorgen dafür, dass jede Person aus unserem jungen Team persönlich über sich hinauswachsen kann.

So haben wir es geschafft jedes Jahr um 100% zu wachsen - heute sind wir ein +50-köpfiges Team und das soll erst der Anfang sein 🚀

Du hast Lust mit uns ein europäisches Powerhouse aufzubauen, und zu skalieren wie ein Software Produkt?

## Aufgaben

- Verantwortung für die Entwicklung und Umsetzung des marswalk Marketings

- Aufbau, Optimierung und Skalierung von Multichannel B2B Marketing

- Aufsetzen und Umsetzen einer agilen Strategie zum generieren von Inbound Kunden

- Tracking, Analyse und Reporting relevanter KPIs (z. B. ROAS, CAC, LTV)

- Zusammenarbeit mit Produkt-, Sales- und Customer Success-Teams zur kontinuierlichen Optimierung der Customer Journey

- Aufbau von Automatisierungs- und Lead-Nurturing-Prozessen

- Erstellen und koordinieren von Content, alleine oder in Unterstützung durch das Videoteam

- Problemsolving und ständiges improven

## Qualifikation

- Fundierte Erfahrung im Performance Marketing und Growth Management

- Praktische Erfahrung in der Erstellung und Optimierung von Funnels

- Analytische Fähigkeiten zur Ableitung von Maßnahmen aus Performance-Daten

- Erfahrung in der Skalierung von Marketingmaßnahmen

- Selbstständige, strukturierte Arbeitsweise und Fähigkeit, Verantwortung für Ergebnisse zu übernehmen

- Wünschenswert: Erfahrung im SaaS-Bereich oder im B2B-Sektor

## Benefits

- Wachstum mit marswalk. Wir wachsen rasant - und du wächst mit. Dabei warten ständig neue Chancen und Gestaltungsspielräume auf dich. Deiner Entwicklung sind keine Grenzen gesetzt.

- Unsere Anforderungen sind hoch - dafür gibt es viel Verantwortung, eine steile Lernkurve und das richtige Umfeld für Wachstum.

- Du bekommst viel Ownership, kannst eigene Ideen einzubringen und die Entwicklung von großen Social Media Kampagnen aktiv mitzugestalten.

- Regelmäßige Team-Events, ein offenes Arbeitsumfeld und die Möglichkeit, von den Besten in der Branche zu lernen.

Du hast Lust mit uns das genialste Social Media Powerhouse Europas aufzubauen? Dann bewirb dich jetzt und werde Teil unseres Teams!

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
