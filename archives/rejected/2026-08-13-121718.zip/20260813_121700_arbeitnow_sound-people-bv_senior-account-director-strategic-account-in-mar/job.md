# Senior Account Director - Strategic Account in Maritime Logistics for SITA

Posted: 2026-08-13T07:20:14Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**Senior Account Director - Strategic Account in Maritime Logistics for SITA**

** **

**Executive summary:** A senior international key account role for a professional who excels in relationship management, stakeholder engagement, and strategic account development. In this position, you will be responsible for retaining, deepening, and further strengthening the partnership with one of SITA’s ( https://www.sita.aero/about-us/ ) most strategic clients.

**Highlights: Senior Account Director - Strategic Account in Maritime Logistics | SITA**

· End-to-end responsibility for a strategic international key account

· Strong focus on relationship management, retention, and deepening the partnership with C-level, IT directors, Enterprise architects, both on the IT organization of the client as well the Business organization.

· International sales and stakeholder management role with high visibility in the customer environment

· Significant impact on client satisfaction, continuity and commercial development, including revenue management

· Strong focus on managed IT and Connectivity services (infrastructure) and differentiated value propositions, based on the portfolio of SITA

· Key position within an international team and complex IT enterprise and Business environment

· Operational / dotted leadership of a highly skilled IT team of 6 FTE at client site

**Purpose of the role**

For SITA, we are looking for a Senior Account Director who will take international responsibility for the strategic international key account. In this role, the emphasis is on retaining, deepening, and future-proofing an existing client relationship with significant commercial and operational value. The focus is not on aggressive revenue growth, but on stability, continuity and additional commercial opportunities within an established international account.

**About the role, building future proof relationships**

As Senior Account Director, you will be responsible for managing and further developing the strategic international key account within SITA. You will operate in an international environment where relationship development focusing on account retention, you understand the complexity of enterprise. IT, data and connectivity sales and know how to create structural value within an existing client relationship.

The ideal candidate is an experienced sales professional with proven knowledge of strategic international key account as an organization, for example from a previous role as a supplier or strategic partner. IT knowledge and experience with managed services are important, but deep client knowledge, insight into decision-making structures, and an understanding of international stakeholder dynamics are even more critical in this position. You can build sustainable relationships at multiple levels, create internal and external alignment in a smart and distinctive way.

**About SITA**

SITA has been a leading technology partner for the international travel and transport sector since 1949. In its early years, the SITA company built one of the first large-scale communications networks for aviation and today continues to play a global role in making travel and logistics processes smarter, safer, and more efficient. SITA has since expanded this expertise into maritime services and managed services for logistics organizations

SITA supports organizations with contact center solutions, connectivity, digital collaboration, security, and managed services. Within this context, strategic international key account for whom SITA delivers services worldwide that directly contribute to customer contact, collaboration, and operational continuity.

Client context

The strategic international key account one of the world’s leading container shipping and logistics companies, with approximately 18.000 employees globally, 340 + offices in 120 + countries, and connections to more than 550 ports worldwide. The organization is known for its strong focus on quality, digitalization, customer centricity, and operational excellence.

For this role, insight into the international dynamics of a complex logistics organization is essential. You understand how technology, service delivery, and stakeholder management come together in an environment where continuity, reliability, and client satisfaction have a direct impact on the business.

The partnership between SITA and the strategic international key account is built on a strong foundation. Your assignment will be to further deepen this relationship, strengthen SITA’s position, and carefully and strategically develop new opportunities within the account.

**Portfolio and services at the key account**

· Contact centre and voice solutions

· Global connectivity solutions

· Managed services for communication and office environments

· Management of digital workplaces and office environments

· Security solutions

**What will you do?**

· You will have end-to-end responsibility for the international account management strategic key account within SITA.

· You will build and deepen sustainable relationships with stakeholders at operational, tactical, and strategic levels.

· You will safeguard the existing revenue base and drive maximum client retention in an environment where managed services are largely viewed as a commodity.

· You will identify commercial opportunities and translate them into distinctive, relevant, and viable propositions.

· You will clearly operate as a farmer rather than a hunter account retention, and strategic growth is the main focus.

· You will position SITA as a partner that adds value more intelligently, effectively, and innovatively than the market expects.

· You will work effectively with internal teams, senior stakeholders, and specialists to serve the client optimally.

· You will provide day-to-day direction to a highly skilled IT delivery team of 6 FTE at the client (virtual and extended account team).

**Terms of employment**

This position offers a fixed gross monthly salary between €9.000,- and €11.000,- gross monthly, complemented by an attractive variable compensation model. The bonus structure consists of a sales incentive based on revenue, with approximately 40% of the variable compensation linked to renewals. In addition, you will receive commission on closed deals. With strong performance, a total package of up to approximately €160,000 OTE is achievable.

**Procedure**

Following a successful introductory phone call, you will have 2 face-to-face meetings with a SoundPeople senior consultant. If both sides see sufficient reason to move forward, we will introduce you to SITA. You will then go through three interview rounds with the client:

The first interview round will take place with a Account Executive of SITA (Central Europe) and an HR professional. The second round will be with the SVP of Central Europe and the current Account Director. In the final stage, the ultimate selection and terms of employment will be aligned with the President of Europe and the COO.

**Interested?**

** **

This opportunity is designed for an accomplished enterprise account leader who understands that a mature strategic relationship still requires energy, precision and continuous development. If you can combine executive stakeholder management with commercial ownership and coordinated delivery, we would like to hear from you.

**Contact Sven Fremeijer **at Sound People BV, Executive Search

LinkedIn: https://www.linkedin.com/in/svenfremeijer/

Who are we looking for?

We are looking for a senior sales professional with extensive experience in complex enterprise environments and a strong understanding of international client dynamics. Ideally, you know the strategic international key account from a supplier or partner perspective and understand the organization, its decision-making processes, and the interests at play. You combine commercial sharpness with high-level know how to create momentum based on trust, substance, and personal leadership.

· Proven experience in MSP, IT, managed services and/or Telco environments

· Deep client knowledge and preferably previous experience with strategic key account

· Creative, innovative, and strategically strong in commercial positioning

· Excellent networker and a credible sparring partner at C-level

· Structured, results-driven, and operationally strong

· Able to move organizations forward through relationships and trust, rather than hierarchy or pressure

· Must: Excellent communication skills in an international environment.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
