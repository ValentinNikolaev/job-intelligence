# Junior Netzwerk Engineer* // in Köln // bis zu 50.000€ (*m/w/d)

Posted: 2026-08-13T07:00:44Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Unser Kunde ist ein spezialisierter IT-Dienstleister mit Fokus auf moderne Netzwerk- und Cybersecurity-Lösungen. Zur Verstärkung des Support-Teams wird ein Network & Security Support Engineer (m/w/d) gesucht, der den stabilen und sicheren Betrieb komplexer Kundenumgebungen unterstützt.

## Aufgaben

**Deine Mission**

- Bearbeitung und Lösung von Netzwerk- und Security-Incidents im 2nd-Level-Support

- Administration und Betrieb von Firewall-Systemen im Managed-Service-Umfeld

- Analyse und Behebung von Störungen in LAN-, WAN- und VPN-Netzwerken

- Umsetzung von Firewall-Changes und Sicherheitsoptimierungen

- Monitoring, Dokumentation und Unterstützung bei Security-Events

- Mitarbeit bei Kundenprojekten und der Einführung neuer Netzwerk- und Security-Lösungen

## Qualifikation

**Deine Superkräfte**

- Ausbildung im IT-Umfeld oder vergleichbare Qualifikation

- Erfahrung im Netzwerk- oder Security-Support

- Kenntnisse in TCP/IP, Routing & Switching, VLANs, VPN, DNS und DHCP

- Deutsch und Englisch in Wort und Schrift

***Nice-to-have***

- Zertifizierungen wie CCNA, Fortinet oder Sophos

- Erfahrung mit Firewalls (z. B. Fortinet, Sophos, Cisco, Palo Alto oder WatchGuard)

- Erfahrung mit Microsoft 365, Azure oder SIEM-Lösungen

- Grundkenntnisse in Linux- und Windows-Server-Umgebungen

## Benefits

**Das bietet dir das Hero Hub**

- Gehaltsrahmen bis 50.000 €

- Nach erfolgreicher Einarbeitung ein hybrides Arbeitsmodell

- Flexible Arbeitszeiten

- Herstellerzertifizierungen und Weiterbildungsmöglichkeiten

- Moderne Arbeitsmittel

- Betriebliche Altersvorsorge

- Entwicklungsperspektiven im Bereich Network & Cyber Security

**Bereit für deine nächste Mission?**

Dann freue ich mich auf deine Bewerbung oder einen vertraulichen Austausch.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
