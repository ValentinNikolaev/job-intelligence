# Digital Designer (m/w/d)

Posted: 2026-08-13T07:30:29Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

## Jobbeschreibung

Du weißt, wie man gutes Design auf digitalen Touchpoints erlebbar macht – von perfekten UI-Elementen im Shop bis hin zu performanten Ad-Creatives auf Social Media? Du denkst nicht in Silos, sondern verbindest kreative Ästhetik, Daten und moderne KI-Tools zu einem ganzheitlichen Markenerlebnis? Dann ist das deine nächste Challenge: Bei benuta erwartet dich ein dynamisches Umfeld mit echter Ownership! Als Digital Designer in unserem UX/UI-Team prägst du den visuellen Auftritt des europäischen Marktführers im Teppich-E-Commerce direkt mit – zukunftsorientiert, datengetrieben und auf State-of-the-Art-Niveau.

##

## Deine Aufgaben

- **Performance-Creatives:** Du entwickelst conversionstarke Ad-Creatives (statisch und animiert) für unsere Performance-Kampagnen auf Meta, YouTube, Google und Pinterest.

- **Newsletter-Design:** Du gestaltest ansprechende Newsletter-Vorlagen und -Inhalte, die unsere Kund*innen begeistern.

- **Datengetriebene Kollaboration:** Du arbeitest eng mit unserem Performance-Marketing-Team zusammen, leitest aus Kampagnenzielen und Testergebnissen kreative Ansätze ab und iterierst deine Creatives kontinuierlich auf Basis von Performance-Daten.

- **UI Design & Design-Systeme:** Du gestaltest UI-Elemente und Screens innerhalb unseres bestehenden Design-Systems und pflegst dessen Komponenten, damit unser Markenauftritt stets konsistent und markenkonform bleibt.

*Hinweis zur Stelle:* Wir besetzen diese Position ausschließlich in Festanstellung (eine freiberufliche oder projektbasierte Zusammenarbeit ist nicht vorgesehen). Als Office-First-Company arbeiten wir überwiegend vor Ort in unserem HQ in Bonn.

## Stellenanforderungen

Dein Profil

- **Ausbildung:** Du hast ein erfolgreich abgeschlossenes Studium, eine Ausbildung oder eine vergleichbare Qualifikation im Bereich Grafikdesign, Kommunikationsdesign, UI/UX-Design oder einem ähnlichen Feld.

- **Relevante Berufserfahrung:** Du bringst einschlägige Berufserfahrung als Digital Designer, UI Designer oder in einer vergleichbaren Rolle mit.

- **Figma & Tool-Skillset:** Du bist absolut sicher im Umgang mit Figma und beherrschst Design-Systeme, Komponenten sowie Auto-Layout. Erfahrung mit CMS-Systemen bringt dir zusätzliche Punkte.

- **Ads- & Motion-Experience:** Du hast Erfahrung in der Gestaltung von Performance-Werbemitteln für Social- und Paid-Kanäle (Kenntnisse der Meta Ads Library von Vorteil) und bringst idealerweise Erfahrung mit animierten Creatives oder Video-Content (z. B. via After Effects) mit.

- **KI als Werkzeug:** KI-Tools sind fester Bestandteil deines täglichen Workflows. Du nutzt sie clever, um Routinearbeiten zu beschleunigen und maximale Freiheit für deine kreative Arbeit zu gewinnen.

- **Soft Skills & Mindset:** Du bist ein kommunikationsstarker Teamplayer, arbeitest strukturiert sowie eigenverantwortlich und denkst lösungsorientiert.

- **Sprachkompetenz:** Du sprichst fließend Deutsch und hast gute Englischkenntnisse (weitere Sprachen sind angesichts unserer internationalen Ausrichtung ein Plus).

## Deine Benefits

- **Präsenz & Flexibilität:** Unser Fokus liegt auf der gemeinsamen Arbeit vor Ort an unserem Campus. Für die nötige Flexibilität in deiner Alltagsplanung - sei es für private Termine oder ungestörtes Arbeiten - bieten wir dir ein jährliches Kontingent von 26 Home-Office-Tagen.

- **Unser neuer Campus "benuta One":** Du arbeitest nicht in irgendeinem Büro. Ab Mitte 2027 ziehen wir in unseren brandneuen, hochmodernen Unternehmenscampus, der genau darauf ausgelegt ist, dass die Arbeit vor Ort Spaß macht - mit State-of-the-Art-Arbeitsplätzen, modernen Meetingräumen und viel Platz für echten Team-Spirit.

- **Deine Mobilität:** Egal wie du zu uns kommst, wir unterstützen dich. Du hast die Wahl zwischen einem vergünstigten Jobticket oder einer Tankkarte. Zudem bieten wir dir ein Firmenrad-Leasing (JobRad), E-Ladesäulen vor Ort und eine gute ÖPNV-Anbindung.

- **Rundum-Verpflegung:** Wir stärken dich im Alltag. Dein Frühstück geht komplett auf uns, und für die Mittagspause bieten wir dir eine bezuschusste Verpflegungsoption. Dazu gibt es jederzeit frisches Obst sowie kostenfreien Kaffee, Hafermilch und eine Auswahl an kalten Getränken.

- **Zeit für Erholung:** Du erhältst 28 Tage Urlaub und profitierst von unserem flexiblen Gleitzeitmodell. Weihnachten und Silvester sind bei uns grundsätzlich arbeitsfreie Tage, die nicht von deinem Urlaubskonto abgehen.

- **Deine Entwicklung & Kultur:** Ein strukturiertes Onboarding ab Tag eins, flache Hierarchien und viel Freiraum für deine eigenen Ideen unterstützen dich bei deinem nächsten Karriereschritt. Übrigens: Bei uns gilt *come as you are* – und auch dein Hund ist im Büro herzlich willkommen!

**Klingt nach deinem nächsten Match?** Dann freuen wir uns auf deine Bewerbung! Lade einfach deinen Lebenslauf, dein aussagekräftiges Portfolio und deine relevanten Zeugnisse über unser Online-Portal hoch.

Dein Ansprechpartner ist **Moritz Ziegert (Teamlead UX/UI)**.

**Bei uns zählt der Mensch und seine Motivation - unabhängig von Geschlecht, Herkunft, Religion oder sexueller Orientierung. Bewerbungen von Menschen mit einer Schwerbehinderung oder ihnen Gleichgestellten werden bei gleicher Eignung bevorzugt berücksichtigt.*

**Über benuta**

Seit 2008 revolutionieren wir von Bonn aus den europäischen Teppich- und Home-&-Living-E-Commerce. Mit über 100 Millionen Euro Umsatz, modernster AI-gestützter Produktinszenierung und Kunden in 17 Ländern verbinden wir die Sicherheit eines etablierten Marktführers mit dem Drive und den flachen Hierarchien eines Digital-Pioneers. Unser Ziel ist einfach: Jedes Zuhause noch schöner zu machen. Werde Teil unseres Teams und hilf uns dabei, noch mehr Menschen für unsere Produkte zu begeistern.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
