# Praktikum im Bereich Prozesstechnik

Posted: 2026-08-13T07:00:41Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Die KD Pharma Group ist ein mittelständisches, international agierendes Unternehmen mit Hauptsitz in Bexbach, Saarland. Es ist spezialisiert auf die Herstellung kundenspezifischer Produkte, die den vielseitigen Bedürfnissen des globalen Marktes entsprechen. Die KD Pharma Group ist eines der weltweit wenigen Unternehmen, das Omega-3-Konzentrate in einer Reinheit von bis zu 99,5 % anbietet. Dies gelingt durch die alleinige Fokussierung auf die Erforschung und Technologieentwicklung von Omega-3-Fettsäuren. Dadurch kann die KD Pharma Group maßgeschneiderte Lösungen bereitstellen, mit denen sich jeder Kunde im globalen Wettbewerb von seinen Konkurrenten abgrenzen kann.

Zur Verstärkung unseres Teams suchen wir ab sofort ein*e Praktikant*in für die Dauer von 3 Monaten um alle erforderlichen Dokumente für die Durchführung einer Prozessrisikoanalyse (u.a. P&IDs, Equipmentlisten, Softwaredetails, Prozessbeschreibung) zu Erstellen und zu Prüfen.

## Aufgaben

Als Praktikant*in unterstützt du unsere Ingenieursabteilung bei einer Vielzahl von spannenden und praxisnahen Aufgaben – ideal, um dein Wissen aus dem Studium direkt anzuwenden:

**Deine Aufgaben:**

- Erstellung und Korrektur technischer Unterlagen gemäß den K.D. Pharma-Standards

- Recherche und Zusammenstellung bestehender technischer Dokumentationen und Informationen

- Kommunikation und Abstimmung mit Anlagebedienenden, Technikern, Ingenieuren und Liferanten

- Einarbeitung in technische Datenblätter und Prozessbeschreibungen

- Erstellung und Bearbeitung von P&IDs mit AutoCAD

- Unterstützung bei der Vorbereitung und Teilanhme an Workshops zur Prozessrisikoanalyse (PRA)

## Qualifikation

- Du studierst aktuell im Bereich Ingenieurwesen, Verfahrenstechnik, Maschinenbau oder in einem vergleichbaren Studiengang

- Erfahrung mit technischer Dokumentation und AutoCAD von Vorteil

- Du arbeitest strukturiert, eigenständig und gewissenhaft

- Deine ausgezeichneten Planungs- und Organisationsfähkeiten zeichnen dich aus

- Du bringst Teamgeist, Kommunikationsfreude und Zuverlässigkeit mit

- Du bist aufgeschlossen, in einem interkulturellen und funktionsübergreifenden Umfeld zu arbeiten

- Du hast Lust, die Theorie aus deinem Studium mit wertvoller Praxis zu verknüpfen

- Du hast verhandlungssichere Englisch- und Deutschkenntnisse (in Wort und Schrift)

## Benefits

Eine abwechslungsreiche, vielseitige und anspruchsvolle Tätigkeit mit einem hohen Maß an Eigenverantwortung. Du wirst „on the job“ in einem engagierten und kompetenten Team eingearbeitet und erhältst einen umfassenden Einblick in die **Abläufe und Standard eines international tätigen Ingenieurteams.** Dabei lernst du auch den Umgang mit der AutoCAD-Software, um P&IDs erstellen und ändern zu können.

Wir freuen uns über deine Bewerbung!

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
