# Gründer:in (m/w/d) - Vorsorgeplattform

Posted: 2026-08-13T08:30:38Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**Ein Milliardenmarkt, der noch mit Papier arbeitet. Ein Netzwerk, das andere sich über Jahre erkämpfen. Eine Finanzierung, die steht. Und eine Plattform, die es noch nicht gibt. Du baust sie - als Gründer:in, nicht als Angestellte:r.**

**_**

**Worum es geht**

Jedes Jahr sterben in Deutschland rund eine Million Menschen. Fast alle hinterlassen ein Chaos: keine Patientenverfügung, keine Vollmacht, keine Ahnung wo die Versicherungspolice liegt, keine Idee was die verstorbene Person eigentlich gewollt hätte. Die Angehörigen sortieren das dann in der schlimmsten Woche ihres Lebens.

Wir bauen die Plattform, auf der Menschen das vorher regeln: digital, verständlich, in einem Nachmittag statt in fünf Behördengängen. Patientenverfügung, Vorsorgevollmacht, Bestattungswünsche, Notfallzugang für Angehörige. Und daran angeschlossen ist die Dienstleistung, die im Ernstfall tatsächlich übernimmt. Wir beginnen dort, wo der Bedarf am drängendsten ist: bei Menschen ab 70 und ihren Angehörigen, die Vorsorge für die Familie in die Hand nehmen - und öffnen die Plattform von dort aus Schritt für Schritt für alle.

Der Markt ist groß, unfassbar schlecht digitalisiert und emotional aufgeladen. Genau deshalb gewinnt hier, wer Vertrauen, Content, Reichweite und operative Abwicklung gleichzeitig kann.

_

**Warum das kein Blindflug ist**

Das hier ist keine Idee auf einer Serviette, aber auch kein fertiges Produkt, das nur noch verwaltet werden muss. Wir haben einen Prototypen live, der beweist, dass Menschen ihre Vorsorge digital regeln wollen. Die eigentliche Plattform wird jetzt von Grund auf neu gebaut. Von dir. Die bestehende Memovida-Plattform dient dabei als Blaupause - nicht als Altsystem, das du nur verwalten musst.

Was schon steht:

- **Ein bewiesenes Bedürfnis**. Der bestehende Prototyp hat echte Nutzer:innen, echte Dokumente und echte Nutzungsdaten. Du fängst nicht bei einer Vermutung an, sondern bei Erkenntnissen - und baust darauf das richtige Produkt.

- **Ein Bestattungsunternehmen als Gesellschafter**. Memovida betreut Bestattungen bundesweit und bringt die komplette operative Organisation, Preis- und Partnerstruktur und den Zugang zu Kund:innen mit.

- **Organische Reichweite als Gesellschafterbeitrag**. Einer unserer Gesellschafter gehört zu den stärksten SEO- und Plattform-Adressen im deutschen Markt und bringt sein Team mit ein. Reichweite ist bei uns kein Wunschzettel, sondern eingebracht.

- **Ein Vertriebskanal, den man nicht kaufen kann**. Einer unserer Gesellschafter ist ausgebildeter Hospizbegleiter und Unternehmensberater und bringt direkten Zugang zu einem bundesweiten Netzwerk aus der Hospiz- und Palliativarbeit mit - hunderte Menschen, die täglich mit genau unserer Zielgruppe sprechen.

- **Solide Ausstattung**. Die Finanzierung für die Startphase steht. Du musst nicht als erstes ein Pitchdeck bauen, um bezahlt zu werden. Du kannst am ersten Tag anfangen zu bauen.

Was fehlt, ist genau eine Sache: jemand, der jeden Tag aufsteht und das Ding baut.

## Aufgaben

Du bist operativ verantwortlich. Wir Gesellschafter sind Sparringspartner, Türöffner, Kapitalgeber und unterstützen, wo wir können.

_

**Die ersten 3 Monate**

- Du zerlegst den bestehenden Prototypen: Was funktioniert, was nicht, was war von Anfang an die falsche Idee.

- Du sprichst mit 50+ Nutzer:innen, Hospizbegleiter:innen und Angehörigen. Persönlich.

- Du baust die neue Plattform basierend auf bestehenden Konzepten und deinen eignen Ideen.

_

**Die ersten 12 Monate**

- **Die Plattform bauen**. Das ist deine Hauptaufgabe. Produkt, Flows, Texte, Landingpages, Automatisierungen. Größtenteils selbst, mit KI-Tools und punktueller Unterstützung durch Plattformspezialisten.

- **Kanäle zünden**. SEO und Content gemeinsam mit unserem Reichweiten-Gesellschafter, Partnerkanäle über unser Hospiznetzwerk, bezahlte Kanäle und Kooperationen eigenständig.

- **Monetarisierung schärfen.** Abo, Vermittlungserlöse, Versicherungspartner, Vorsorgeverträge - welche Kombination trägt, ist offen und deine Frage zu beantworten.

- **Team aufbauen**. Sobald Umsatz und Bedarf es tragen, holst du dir die ersten Leute dazu - zunächst punktuell, später fest. Wen, entscheidest du.

## Qualifikation

Ehrlich gesagt: dich, wenn du gerade in dem Fenster steckst, in dem man so etwas macht.

**Muss:**

- **Unternehmerischer Drive**. Du willst gründen, nicht „in einem Startup arbeiten". Der Unterschied ist dir sofort klar.

- **Kaufmännisches Verständnis**. Du kannst ein Geschäftsmodell rechnen, verstehst Deckungsbeitrag und Akquisekosten und weißt, wann eine Kennzahl nur hübsch aussieht.

- **Technisches Verständnis**. Du musst kein Senior Engineer sein, aber du musst in der Lage sein, mit modernen KI-Entwicklungstools (z. B. Claude Code) selbstständig eine echte Webplattform zu bauen: Features, Bugs, Deployments, Datenauswertung. Wer erst auf einen Entwickler warten muss, um eine Landingpage zu ändern, ist hier zu langsam.

- **Ein Beleg, dass du liefern kannst**. Eine eigene Firma, ein Nebenprojekt mit echten Nutzer:innen, eine Initiative an der Uni, ein Verein, ein Produkt, das du gebaut und verkauft hast. Muss nicht groß gewesen sein. Muss echt gewesen sein.

- **Bereitschaft, ins Risiko zu gehen**. Der wesentliche Teil deiner Vergütung ist die Beteiligung. Sie zahlt sich aus, wenn wir gewinnen.

- **Deutsch auf Muttersprachenniveau**. Wir arbeiten mit Angehörigen in Ausnahmesituationen und mit Behörden. Sprache ist hier kein Nice-to-have.

_

**Gerne, aber kein Muss:**

- Abschluss von einer starken Uni

- Erfahrung in einem Frühphasen-Startup, bei einem Company Builder oder in Beratung

- Erfahrung mit Content, SEO oder Performance-Marketing

- Erste Berührung mit regulierten Themen (Versicherung, Recht, Gesundheit)

_

**Was wir ausdrücklich nicht erwarten:**

20 Jahre Branchenerfahrung. Vorsorgethemen kannst du lernen, wir haben das Netzwerk dafür. Hunger und Umsetzungsgeschwindigkeit lernt man nicht nach.

_

**Das ist nichts für dich, wenn …**

- du eine ausgearbeitete Rollenbeschreibung und klare Prozesse brauchst, um loszulegen.

- dir „9-to-5" in den ersten Jahren wichtiger ist als das Ergebnis.

- du Tod, Trauer und Sterben nicht aushältst. Das Thema ist jeden Tag im Raum. Wir gehen respektvoll damit um, aber es geht nicht weg.

## Benefits

- **Ein Basisgehalt**, das dich trägt - du musst nicht von Ersparnissen leben.

- **Eine sehr attraktive Beteiligung am Unternehmen** für den Erfolgsfall. Du bist Gesellschafter:in, nicht Optionsinhaber:in. Die Beteiligung wächst dir über vier Jahre zu (Vesting, ein Jahr Cliff) - fair für beide Seiten.

- **Geschäftsführung** und echte operative Entscheidungsgewalt im Tagesgeschäft.

- **Die Chance, ein Produkt von Grund auf zu bauen** - Architektur, Design, Funktionsumfang, alles deine Entscheidung. Kein Altsystem, das dich bremst.

- **Ein Netzwerk, das man normalerweise erst nach Jahren hat**: ein etabliertes Bestattungsunternehmen, ein Top-SEO-Haus und direkten Zugang zur bundesweiten Hospiz- und Palliativarbeit - Gesellschafter, die ein eigenes Interesse an deinem Erfolg haben.

- **Finanzierung, die steht**, statt monatelangem Fundraising vor dem ersten Feature.

- **Ein Produkt mit Substanz**. Wenn das hier funktioniert, ist der Nutzen für die Menschen am anderen Ende sehr real.

**Wie wir vorgehen**

- Kurzbewerbung (siehe unten)

- Kennenlernen mit Manuel

- Gespräch mit allen Gesellschaftern

- Entscheidung

Der ganze Prozess dauert bei uns Wochen, nicht Monate.

_

**Bewerbung**

Schick uns deine Bewerbung mit:

- deinem Lebenslauf oder LinkedIn-Profil (kein Anschreiben nötig),

- einem Link zu etwas, das du gebaut hast - Produkt, Projekt, Repository, Firma, egal wie klein,

- einer Sprachnachricht von maximal 3 Minuten - Smartphone, ein Take, ungeschnitten. Beantworte darin die folgenden drei Fragen:

- Wer bist du in 30 Sekunden, und warum willst du ausgerechnet jetzt gründen?

- Was ist die Sache, auf die du am meisten stolz bist? Was war daran schwierig, und was hast du gemacht, als es nicht lief?

- Du übernimmst die Plattform morgen: Welche zwei, drei Ideen hast du sofort im Kopf, und womit fängst du an?

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
