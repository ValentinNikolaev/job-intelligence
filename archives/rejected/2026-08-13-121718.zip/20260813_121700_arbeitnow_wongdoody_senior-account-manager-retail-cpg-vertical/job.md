# (Senior) Account Manager - Retail & CPG Vertical

Posted: 2026-08-13T08:55:20Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

WongDoody creates human experiences! WongDoody schafft menschliche Erfahrungen in 22 Locations auf 4 Kontinenten. Wir glauben, dass die Zukunft gestaltbar ist. Indem wir menschliche Erfahrungen durch Kreativität und Technologie gestalten, arbeiten wir daran, eine Zukunft zu schaffen, an die wir glauben.

Für uns beginnt dies mit unserer eigenen Kultur. Wir streben danach, ein integratives Umfeld zu schaffen, in dem jeder Mensch sein ganzes Wesen in die Arbeit einbringen kann. Unsere Kund:innen sind Marken, an die wir glauben, von globalen Großunternehmen über lokale Held:innen bis hin zu Start-ups, die wir lieben. Mit jedem unserer Partner:innen begeben wir uns auf eine Reise der Co-Creation, bei der wir die Grenzen des Möglichen ausloten und den Raum erforschen, in dem Kreativität und Technologie aufeinander treffen.

Unser Team aus gut gelaunten, offenen, werteorientierten und kollaborativen Problemlöser:innen konzentriert sich bei allem, was wir tun auf ein Ziel: menschliche Erfahrungen. Menschliche Erfahrungen sind die Berührungspunkte, an denen Marken mit Kund:innen in Kontakt treten. Wir transformieren Unternehmen, indem wir mit Hilfe von Strategie, Kreativität, Daten und Technologie ansprechende, inspirierende Momente schaffen - unterstützt durch die globale technologische Stärke von Infosys.

**Retail & CPG Vertical **

Unser Team vereint tiefgehende Branchenexpertise in den Bereichen FMCG, Handel, Automobil, Maschinenbau und Technologie. Für Marken wie dm, Otto, Porsche, Bosch, TRUMPF und Mercedes-Benz entwickeln wir nutzerzentrierte Strategien, prägnante Markenauftritte, digitale Produkte sowie Influencer-Kampagnen, die Kreativität, Daten und Medien nahtlos miteinander verbinden..

**Unsere lokalen Benefits **

- Fexible Arbeitszeiten durch ein Arbeitszeitkonto mit 100 % Überstundenausgleich
- Arbeiten, von wo es dir passt – im Homeoffice, in einem unserer Büros (Stuttgart, Berlin, Düsseldorf) oder sogar befristet im EU-Ausland
- Kostenlose Snacks und Getränke in unseren Büros
- Ein innovatives Arbeitsumfeld mit moderner, technischer Ausstattung – MacBook, dienstliches iPhone sowie alle für deine Arbeit relevanten Tools
- Weiterbildungsangebote, um stets up-to-date zu bleiben
- 30 Tage Urlaub pro Jahr
- Urban Sports Club
- Corporate Benefits
- Ein inspirierendes Team, mit welchem die Zusammenarbeit für starke Marken Spaß macht

**Das erwartet Dich**

- Du schätzt es die zentrale Schnittstelle zwischen Kund:in und Team zu sein
- Operative Betreuung, strategische Beratung und Weiterentwicklung definierter Kund:innen
- Koordination von Projekten im Bereich Digital Campaigning, Social Media, New-Branding, E-Commerce, Website, CRM und Media
- Ressourcen und Budgets unter der Sicherstellung von Qualität, Timing und Controlling zuverlässig einsetzen
- Eigenständige Vorbereitung und Durchführung von Kund:innenpräsentationen und Workshops
- Selbstständiges und eigenverantwortliches Arbeiten als Teil eines interdisziplinären Projektteams (Account Management, Strategie, Kreation, Performance, Development und Kund:in)

**Das bringst Du mit**

- Du hast ein abgeschlossenes wirtschafts- oder kommunikationswissenschaftliches Studium oder eine vergleichbare Ausbildung mit mindestens 5 Jahren Berufserfahrung im Account Management
- Du hast bereits Agenturerfahrung, idealerweise mit Online-Schwerpunkt, als Account- oder Projektmanager oder in einer vergleichbaren Position
- Kund:innen- sowie Marktverständnis durch Erfahrungen in der Kund:innenbetreuung, in der Koordination von Online-Projekten als auch von Kampagnen
- Breite Berufs-/Projekterfahrung in verschiedenen Arten von Projekten in den Bereichen (digitale) Kampagnen, Social Media, Content Creator Marketing, etc.
- Aufgeschlossen für neue und innovative Projekte im Bereich neuer Technologien (AI, KI, ...)
- Du denkst strategisch und liebst es, deine Kunden zu beraten.
- Sehr gutes und effizientes Zeitmanagement bei sehr hohem Qualitätsanspruch
- Du hast eine eigenverantwortliche Arbeitsweise und eine positive und lösungsorientierte Grundhaltung, mit Hands-on-Mentalität
- Du verfügst über sehr gute Deutschkenntnisse und gute Englischkenntnisse in Wort und Schrift

Für uns zählt allein Deine Persönlichkeit und Deine beruflichen Fähigkeiten. Dein Geschlecht, Alter oder Aussehen, Deine Herkunft oder sexuelle Orientierung spielen für uns keine Rolle – wir sind offen für die Zusammenarbeit mit jeder Person.

Beachte bitte: Dies ist eine Stellenanzeige der WongDoody GmbH mit Sitz in Deutschland. Über unsere Website oder andere Quellen kannst Du zu Stellenanzeigen gelangen, die von einer unserer WongDoody-Schwesterfirmen veröffentlicht wurden, mit denen wir weltweit gemeinsam unter der Marke "WongDoody" auftreten. Für jedes Stellenangebot ist ausschließlich das Unternehmen verantwortlich, das die jeweilige Anzeige veröffentlicht hat. Ansprechpartner:innen, erforderliche Angaben und geltende Bedingungen können jeweils abweichen. [Hier](https://www.wongdoody.com/wongdoody-germany-privacy) kannst Du Dich darüber informieren, wie die WongDoody GmbH Deine im Bewerbungsprozess angegebenen personenbezogenen Daten verarbeitet). Wenn Du Fragen zum Bewerbungsprozess hast, wende Dich gerne direkt an unser People & Culture-Team unter -----

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
