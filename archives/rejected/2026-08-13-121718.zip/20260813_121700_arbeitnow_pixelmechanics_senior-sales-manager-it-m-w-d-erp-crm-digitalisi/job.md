# Senior Sales Manager IT (m/w/d) - ERP, CRM, Digitalisierung

Posted: 2026-08-13T08:30:13Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**Digitalisierung war gestern. Wir leben "AI First".**
Wir verstehen uns als Vorreiter im Bereich "AI First". Bei PixelMechanics arbeiten Marketing und Sales nicht gegeneinander, sondern bilden eine Einheit ("Smarketing"). Unser Marketing schafft qualifizierte Nachfrage – du entwickelst daraus tragfähige Kundenbeziehungen und erfolgreiche Abschlüsse.

Wir suchen einen erfahrenen **Senior Sales Manager IT**, der versteht, dass moderne ERP- und CRM-Systeme in Kombination mit KI, das Betriebssystem der Zukunft bilden.

**Was du bei uns konkret verantwortest:**

Du übernimmst qualifizierte Opportunities aus Marketing und Partnernetzwerk, entwickelst daraus belastbare Account-Strategien, steuerst komplexe Sales Cycles vom Erstgespräch bis zum Abschluss, arbeitest eng mit Consulting und Delivery an Angeboten und sorgst für transparente Forecasts im CRM.

**Dein Ziel:** profitable Projekte gewinnen, die für Neu- und Bestandskunden echten Prozessnutzen schaffen.

**Du hast**

-

**Fundierte Erfahrung im Lösungsvertrieb:** Du bringst nachweisbare Senior-Erfahrung im kompletten Sales Prozess und Verkauf von erklärungsbedürftigen IT-Produkten oder Dienstleistungen mit (Schwerpunkt ERP, CRM, SaaS im High-Ticket-Bereich).

-

**Methodische Kompetenz:** Du arbeitest strukturiert und bist vertraut mit gängigen Frameworks wie MEDDIC, SPIN, Sandler oder Challenger Sale und wendest diese sicher an.

-

**Ein "AI-Ready" Mindset:** Du bist offen für neue Technologien. Du nutzt KI bereits produktiv für Recherche, Account Planning, Angebotsvorbereitung und Kommunikation.

-

**Überzeugende Kommunikation:** Du kommunizierst und verhandelst sicher auf C-Level-Niveau, kannst komplexe Zusammenhänge verständlich darstellen und vertrittst deinen Standpunkt souverän und respektvoll.

-

**Reisebereitschaft:** Auch wenn wir hauptsächlich digital arbeiten, bist du bereit, für entscheidende Termine oder zur Pflege wichtiger persönlicher Beziehungen in geringem Maße zum Kunden zu reisen.

-

**Sprachliche Exzellenz:** Verhandlungssicheres Deutsch ist für diese Stelle unerlässlich. Englischkenntnisse sind von Vorteil.

**Deine Aufgaben**

-

**Strategische Beratung auf C-Level:** Du führst C-Level Entscheider durch komplexe Transformationsprojekte. Du verkaufst keine Einzellösung, sondern eine belastbare Grundlage für effizientere, integrierte und automatisierte Geschäftsprozesse.

-

**Management anspruchsvoller Sales Cycles:** Du steuerst Verkaufsprozesse souverän über mehrere Monate hinweg. Du verstehst, dass nachhaltige Geschäftsbeziehungen Zeit und Pflege benötigen, und nutzt diese Phase aktiv, um Vertrauen aufzubauen und die Bedürfnisse des Kunden tiefgreifend zu verstehen. Dabei bringst du den bei uns geschätzten „Human Touch“ ein und agierst stets serviceorientiert, um für den Kunden als echter Partner wahrgenommen zu werden.

-

**Effizienz durch AI:** Du setzt modernste AI-Tools gezielt ein, um deine Effizienz zu optimieren – von der Recherche bis zur Kommunikation. Da ca. 90 % deiner Termine online stattfinden, arbeitest du fokussiert und ressourcenschonend.

-

**Zusammenarbeit im Team:** Du greifst qualifizierte Opportunities auf, die durch unser Marketing vorbereitet wurden, und führst diese mit deiner fachlichen Expertise zum Abschluss. Zudem arbeitest du eng mit unseren Consultants und Entwicklerteams zusammen, um passgenaue Angebote zu erstellen. Wir gewinnen zusammen!

**Benefits**

-

Ein dynamisches und innovatives Arbeitsumfeld mit einem unbefristeten Arbeitsvertrag

-

Modern Work: Drei Tage pro Woche im Nürnberger Office, zwei Tage flexibel im Homeoffice

-

Du arbeitest an Projekten mit hohem Volumen und entsprechender Vergütung

-

Dedizierte Trainingszeiten während der Arbeitszeit

-

Permanenter Zugang zu den besten und neuesten AI-Tools (ChatGPT Team, Perplexity, KI-Sales-Tools etc.)

-

Nach Absprache temporäres Arbeiten aus dem Ausland möglich z. B. Workation (+/- 3 Stunden zu Deutschland)

-

Loyalität, Nachhaltigkeit und Fairness als Arbeitgeber

-

Familiäres und herzliches Miteinander

-

Corporate Benefits, Betriebliche Krankenzusatzversicherung (nach Probezeit)

-

Faire Arbeitszeiten damit du genügend Zeit für dein Privatleben hast

-

Endloser Zugang zu Kaffee und Wasser im Büro

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
