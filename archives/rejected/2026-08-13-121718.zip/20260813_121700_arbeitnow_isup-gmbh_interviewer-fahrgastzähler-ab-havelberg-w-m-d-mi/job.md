# Interviewer / Fahrgastzähler ab Havelberg (w/m/d) - Minijob

Posted: 2026-08-13T10:00:37Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Die ISUP GmbH ist ein in Dresden ansässiges und seit 35 Jahren umfassend im Verkehrssektor tätiges Ingenieurbüro. Im Bereich der empirischen Mobilitätsforschung führen wir deutschlandweit Verkehrserhebungen im Personennahverkehr durch. Diese bieten den Auftraggebern aktuelle Informationen über die tatsächliche Verkehrsnachfrage (zeitliche und räumliche Nutzung) und dienen u. a. als Aufteilungsschlüssel der Fahrgeldeinnahmen.

Zur Verstärkung unseres Teams suchen wir SIE.

## Aufgaben

Als Verkehrserheber(in) fahren Sie auf ausgewählten Buslinien im nördlichen ÖPNV-Landesnetz der NASA GmbH (Nahverkehrsservice Sachsen-Anhalt GmbH), zählen die Ein- und Aussteiger sowie die mitfahrenden Fahrgäste und befragen diese nach Fahrschein und Fahrtverlauf. Die hierbei ermittelten Daten werden im Anschluss per WLAN übertragen .

Die Erfassung der Daten erfolgt mit zur Verfügung gestellten Smartphones. Die Nutzung priv. Erfassungsgeräte ist nach Absprache möglich und wird mit einer Aufwandsentschädigung vergütet.

Die Verkehrserhebung "NASA 2026" wird u.a. auf folgenden Strecken durchgeführt:

- Linie 900 Havelberg - Stendal

Weitere Informationen / Linien finden Sie auch auf unserer Homepage.

## Qualifikation

Sie sind:

- aufgeschlossen, kommunikativ, pünktlich, zuverlässig und freundlich

- bereits über 18 Jahre

und verfügen über:

- die Möglichkeit auch Einsätze in Randzeiten zu übernehmen

- sehr gute deutsche Sprachkenntnisse (B2 und höher)

- ein gepflegtes Erscheinungsbild und höfliche Umgangsformen

- grundlegende Kenntnisse im Umgang mit Smartphone sowie MS Office (Excel-Tabellen)

- Zugang zum WLAN und eigene E-Mail-Adresse

- eigenen PKW (nicht Bedingung, aber von Vorteil)

Ihr Wohnort befindet sich

- möglichst in Havelberg oder der näheren Umgebung

## Benefits

Ihre Einsätze erfolgen flexibel nach Ihrer Verfügbarkeit (freie Einsatzwahl bezüglich Einsatzzeit und -ort aus einer Vergabeliste). Die Einsätze werden fahrplanabhängig in den Betriebszeiten der jeweiligen Verkehrsunternehmen stattfinden. Die Dauer eines Einsatzes beträgt zwischen ca. 3,0 und ca. 7,0 Stunden.

Pausen und Umstiegszeiten innerhalb eines Einsatzes werden voll bezahlt!

Im Vorfeld erhalten Sie von unseren Mitarbeitern eine kostenfreie Schulung/Einweisung im Untersuchungsgebiet, in welcher Ihnen die Arbeitsaufgaben, die Organisation sowie der Umgang mit der Erhebungs-App und den möglichen Fahrausweisen erklärt werden.

Abschlussbemerkungen:

- Vergütung: 15,00 Euro / Einsatzstunde

- monatliche Abrechnung / Überweisung

- Zeitraum: 31.08.2026 bis max. 06.12.2026

- geringfügige oder kurzfristige Beschäftigung (Minijob)

- für Selbstständige auch auf Honorarbasis möglich

Haben wir Ihr Interesse geweckt? Wir freuen uns auf Ihre Bewerbung - **gern auch direkt über das Onlineformular auf unserer Homepage!** Wählen Sie dazu bitte das Projekt "Sachsen-Anhalt Nord" aus.

Unsere Antwort erfolgt per E-Mail.

Sie haben keine erhalten? Dann schauen Sie doch einmal in Ihren SPAM- bzw. JUNK-Mail-Ordner.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
