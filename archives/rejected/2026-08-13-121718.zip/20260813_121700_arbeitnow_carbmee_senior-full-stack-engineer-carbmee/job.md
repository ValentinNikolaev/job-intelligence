# (Senior) Full-stack Engineer | Carbmee

Posted: 2026-08-13T08:09:07Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
