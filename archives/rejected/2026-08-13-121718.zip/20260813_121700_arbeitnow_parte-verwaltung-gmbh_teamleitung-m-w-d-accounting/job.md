# Teamleitung (m/w/d) Accounting

Posted: 2026-08-13T09:00:40Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

## Das bewegen Sie bei uns:

- Sie führen und entwickeln unser Buchhaltungsteam für Deutschland und unterstützen die schrittweise Überführung relevanter Buchhaltungsprozesse ins Haus.

- Bei der Ausgestaltung von Rollen, Prüfungsebenen und Freigabeworkflows wirken Sie aktiv mit und sorgen für einheitliche Standards über die Gesellschaften hinweg.

- Die HGB-konformen Monats-, Jahres- und Konzernabschlüsse der deutschen Gesellschaften koordinieren Sie und unterstützen das Konzernreporting nach Belgien über LucaNet.

- Neu erworbene Gesellschaften binden Sie nach unserem Finance-Playbook in die einheitliche Konten- und Reportingstruktur ein.

- Bei bilanziellen Grundsatzfragen – etwa zu Rückstellungen oder Share Deals – bringen Sie Ihre Expertise ein und stimmen sich eng mit Finance Director und Group CFO ab.

## Das bringen Sie mit:

- Sie sind Bilanzbuchhalter (IHK) oder vergleichbar qualifiziert; ein Studium im Bereich Rechnungswesen oder Finanzen ist ein Plus.

- Mindestens fünf Jahre Erfahrung in der deutschen Buchhaltung bringen Sie mit, idealerweise aus einem Multi-Entity-, Private-Equity- oder Buy-and-Build-Umfeld.

- Erste Führungserfahrung haben Sie bereits gesammelt und geben Ihr Wissen gerne an jüngere Kolleginnen und Kollegen weiter.

- Mit DATEV arbeiten Sie routiniert und im HGB bewegen Sie sich sicher, auch bei Rückstellungen und Intercompany-Sachverhalten. LucaNet-Erfahrung ist willkommen.

- Auf Deutsch und Englisch kommunizieren Sie sicher auf C1-Niveau.

## Das bieten wir Ihnen:

- **Unbefristete Festanstellung** mit sicheren Perspektiven.

- Geregelte Arbeitszeiten, flexible Gleitzeit und Option auf **mobiles Arbeiten**.

- **Flache Hierarchien**, abwechslungsreiche Aufgaben und ein starkes Teamgefühl.

- Gestaltungsspielraum sowie Weiterentwicklung durch **regelmäßige Weiterbildungen**.

- Moderner Arbeitsplatz, zeitgemäße Technik und **Dienstlaptop (auch privat nutzbar)**.

- **Zentrale Bürolage** mit guter ÖPNV-Anbindung.

## Ihre Ansprechpartnerin:

Theresa Jakob, HR Generalist

+49 151 58152451

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
