# SEO Lead (w/m/d)

Posted: 2026-08-13T10:00:31Z

## Rejection

- Category: tech_stack
- Reason: role does not mention Go/Golang or PHP

## Über die Rolle

Wir suchen einen SEO Lead (w/m/d), der/die die Verantwortung für unser Affiliate-Portfolio übernimmt und es weiter skaliert. Du arbeitest mit einigen der größten Publisher der Welt zusammen und hast direkten Einfluss auf den Umsatz.

Du treibst die SEO-Strategie für mehrere Affiliate-Websites in unterschiedlichsten Verticals voran, leitest laufende Go-Lives in neuen Märkten und führst ein kleines Team von SEO Content Managern. Du hast die Freiheit, die Richtung vorzugeben, Prioritäten zu setzen und schnell zu handeln, wenn sich etwas ändert – denn im SEO ändert sich immer etwas.

Bei WLX ist SEO keine Support-Funktion, sondern eine treibende Kraft. Wir haben die Ressourcen, den Rückhalt vom Management und das Hands-on-Know-how, um Dinge wirklich umzusetzen. Und anders als bei einer Agentur gehört alles, was wir aufbauen, uns selbst: eigene Projekte, die in enger Zusammenarbeit mit den größten Publishern der Welt umgesetzt werden. Das bedeutet echte Ownership, echten Impact und keine Kunden Briefings.

Wenn du darin aufgehst, neue Projekte zu launchen, das Tempo eines wachstumsstarken Umfelds liebst und ein wachsendes, mehrere Millionen schweres Portfolio über ein stetig expandierendes Spektrum an Verticals mitgestalten willst – dann ist das die passende Rolle für dich. Du berichtest an den Head of Organic und arbeitest eng mit Publishern, Vertical Managern und Content-Teams zusammen, um SEO-Potenziale in messbare Geschäftsergebnisse zu verwandeln.

## Das wirst Du tun

- **Das Umsatzwachstum bestehender Affiliate-Websites vorantreiben:** Langfristige SEO-Strategien entwickeln und umsetzen, hochwertige Seiten für Rankings und CTR optimieren und Backlink-Kampagnen über mehrere Affiliate-Websites hinweg verantworten.

- **Neue Affiliate-Websites end-to-end launchen:** Von Keyword-Clustering, Themen-Mapping und Content-Struktur bis zur Koordination mit Stakeholdern, um neue Websites von Grund auf live zu schalten.

- **On-Page- und Off-Page-Performance vorantreiben:** Content-Audits durchführen, die Nutzung von SERP-Features verbessern, Linkbuilding-Maßnahmen steuern und mit Agenturen und Publishern zusammenarbeiten, um die Domain Authority zu stärken.

- **Wachstumschancen identifizieren und erschließen:** Publisher recherchieren, neue Märkte einschätzen, Domain Authority und Traffic-Trends bewerten und Expansionsoptionen anhand von Business-Growth-Frameworks abwägen.

- **Ein Team von SEO Content Managern führen und entwickeln:** Klare Prioritäten setzen, Verantwortlichkeit einfordern, Weiterentwicklung coachen und bei Bedarf auch schwierige Gespräche führen.

## Das bringst Du mit

- Du bringst umfangreiche On-Page- und Off-Page-Erfahrung im SEO mit, mit nachweisbaren Erfolgen darin, organisches Wachstum zu skalieren.

- Du hast nachgewiesene Erfahrung in der Führung eines Teams mit Fokus auf Entwicklung, Motivation und High Performance

- Du sprichst Deutsch auf muttersprachlichem Niveau und verhandlungssicheres Englisch (C1+), du bewegst dich sicher mit Stakeholdern in beiden Sprachen.

- Idealerweise bist du in Berlin ansässig. Für die richtige Person ist die Position aber auch remote möglich.

- Du bist analytisch und strukturiert: du priorisierst das Wesentliche, kommunizierst klar und triffst Entscheidungen auch unter Druck.

- Du fühlst dich wohl in einem schnelllebigen, flachen Umfeld im Startup-Stil.

- Erfahrung im iGaming oder in anderen Affiliate-Marketing-Branchen sind von Vorteil.

## Über Uns

Bei We Love X entwickeln und betreiben wir leistungsstarke Vergleichsplattformen und Conversion-Funnels, die Millionen von Nutzer:innen mit den passenden Produkten und Services verbinden. Als Marktführer im SEA-basierten Affiliate-Marketing über mehrere Verticals hinweg verwandeln wir hochintentionierten Traffic in skalierbares Wachstum für unsere Partner. In den vergangenen Jahren haben wir zudem eines der am schnellsten wachsenden SEO-Geschäfte in unserem Markt aufgebaut – in Zusammenarbeit mit einigen der weltweit größten Publisher. Über unsere eigenen Plattformen hinaus inkubiert We Love X kontinuierlich neue, performance-getriebene Geschäftsmodelle: von der ersten Idee bis zur internationalen Skalierung.

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
