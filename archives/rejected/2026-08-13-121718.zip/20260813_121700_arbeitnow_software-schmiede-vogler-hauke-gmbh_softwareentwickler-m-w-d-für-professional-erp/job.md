# Softwareentwickler (m/w/d) für Professional ERP

Posted: 2026-08-13T10:00:41Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**Gestalte mit uns die ERP- und KI-Zukunft des Mittelstands**

Als Softwareentwickler (m/w/d) für Professional ERP entwickelst du digitale Lösungen, die mittelständische Unternehmen nachhaltig voranbringen – in unbefristeter Vollzeitanstellung und mit Freiraum für deine Ideen.

## Aufgaben

- Du gestaltest die digitale Zukunft des Mittelstands und entwickelst maßgeschneiderte Lösungen auf Basis unseres Professional ERP- und Professional MDE-Frameworks.

- Du übersetzt fachliche Anforderungen und definierte Aufgabenpakete im Kundenumfeld in durchdachte technische Lösungen.

- Du optimierst bestehende Anwendungen und Prozesse und bringst deine eigenen Ideen aktiv in die Weiterentwicklung unserer Systeme ein.

- Du gestaltest mit uns, wie moderne Technologien und KI künftig sinnvoll in ERP-Lösungen und Geschäftsprozesse integriert werden.

## Qualifikation

Du interessierst dich für die langfristige Optimierung von Geschäftsprozessen und nachhaltige, effiziente Lösungen? Nicht das Tool, sondern der Erfolg des Kunden steht bei dir im Fokus?

- **Studium oder Berufserfahrung**: Ein Studium in Informatik, oder eine vergleichbare Ausbildung sowie praktische Erfahrungen in der Softwareentwicklung sind von Vorteil.

- **Programmiersprachen** Idealerweise hast du Erfahrung mit gängigen Programmiersprachen wie Java, C# oder Python und bist in mindestens einer objektorientierten Programmiersprache zu Hause.

- **Technische Kompetenz**: Du hast bereits Erfahrung mit relationalen Datenbanken und SQL (MS SQL). Idealerweise ergänzt du deine Stärken mit Visual Studio Code oder bist bereit, dich darin einzuarbeiten.

- **Kaufmännisches Verständnis**: Du verstehst betriebliche Abläufe und kannst diese in digitale Lösungen übersetzen.

- **Lösungsorientiertes Denken**: Du gehst Herausforderungen mit Neugier und Fokus an, um betriebliche Abläufe effektiv umzusetzen.

- **Teamplayer-Mentalität**: Eigenverantwortung, Flexibilität und die Fähigkeit zur Zusammenarbeit auf Augenhöhe zählen zu deinen Stärken.

## Benefits

**Arbeiten, wie es zu dir passt**

- Mobile Office & Workation – arbeite dort, wo du am produktivsten bist

- Option auf eine 4-Tage-Woche

- Vertrauensarbeitszeit & flexible Arbeitszeiten

- Attraktives Gehalt & individuelle Entwicklungsmöglichkeiten

**Projekte, die Wirkung zeigen**

- Seit 1986: Stabile Software-Schmiede mit Vision

- Echte Digitalisierung statt Folienprojekte

- Direkter Austausch mit Entwicklung & Geschäftsleitung

**Kultur, die verbindet**

- Kommunikation auf Augenhöhe – im Team und mit Führung

- Raum für Ideen & Out-of-the-box-Denken

- Strukturierter Einstieg mit Mentoring und persönlichem Onboarding

- Langjährige Mitarbeiter- und Kundenbindung

**Und on top:**

- Moderne technische Ausstattung inkl. Laptop, Smartphone & Headset

- Urlaubs- & Weihnachtsgeld

- 50 € Sachbezug monatlich on top

- Zuschuss zur betrieblichen Altersvorsorge

- JobRad-Leasing mit Arbeitgeberzuschuss

- Fitness-Schmiede & betriebsärztliche Betreuung für deine Gesundheit

- Zuschuss zur Arbeitsplatzbrille

- Modernes Büro mit Open Work Space, Klimaanlage & Dachterrasse

**Dein Umfeld**

- Rund 65 Mitarbeitende aus verschiedenen Disziplinen am Standort Neckarsulm

- Moderne Software-Schmiede mit direktem Austausch zur Geschäftsleitung

- Seit 1986 erfolgreich am Markt – stabile ERP-Lösungen für rund 1.000 mittelständische Kunden

Klingt spannend? Dann freuen wir uns auf deine Bewerbung im #teamschmiede!

Kontakt: Isabel Reutter | +49 7132 9626-50

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
