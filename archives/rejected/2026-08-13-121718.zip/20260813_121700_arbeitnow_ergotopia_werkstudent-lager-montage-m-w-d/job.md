# Werkstudent Lager & Montage (m/w/d)

Posted: 2026-08-13T09:20:32Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Du packst gerne mit an, hast technisches Verständnis und suchst einen Werkstudentenjob, bei dem du nicht nur am Schreibtisch sitzt? Als **Werkstudent Lager & Montage** unterstützt du uns rund um Retouren, Versand und Lagerorganisation, baust unsere ergonomischen Produkte auf und sorgst dafür, dass sie geprüft, aufbereitet und wieder fit für ihren nächsten Einsatz sind. Dich erwartet ein abwechslungsreicher Job, bei dem du direkt siehst, was du am Ende des Tages geschafft hast.

-

**Lagerorganisation & Warenfluss:** Du unterstützt im Retourenlager bei der Erfassung von Warenein- und -ausgängen, hilfst beim Versand von Ersatzteilen und packst beim Be- und Entladen von Fahrzeugen mit an.

-

**Kommissionierung und Versandvorbereitung**: Du stellst unsere ergonomischen Produkte zusammen, verpackst sie transportsicher und bereitest sie für den Versand an unsere Kunden vor.

-

**Qualitätskontrolle:** Du baust unsere höhenverstellbaren Tische, ergonomischen Stühle etc. fachgerecht auf, prüfst sie auf ihre Funktion und Qualität und bewertest zurückgeführte Produkte hinsichtlich ihres Zustands und möglicher Weiterverwendung.

-

**Montagen beim Kunden:** Du begleitest gelegentlich regionale Auslieferungen und unterstützt unser Team bei Montagen direkt vor Ort beim Kunden.

-

**Verkauf und Beratung zu B-Ware: **Du unterstützt bei der Aufbereitung zurückgeführter Produkte, hilfst interessierten Kunden bei Fragen zur B-Ware – im Lager und gelegentlich im Showroom – und stellst sicher, dass unser Ausstellungsbereich stets ordentlich, aktuell und einladend ist.

-

Du bist aktuell in einem Studiengang eingeschrieben. Bei uns ist es weniger wichtig, welche spezifische Fachrichtung du verfolgst, solange du handwerkliches Geschick mitbringst und Lust hast, mitanzupacken.

-

Du bringst technisches Verständnis mit und kannst hierdurch kleinere Reparaturen eigenständig durchführen und technische Fragen zu unseren Produkten kompetent beantworten. Erfahrung im Möbelaufbau ist ein Plus, aber kein Muss.

-

Du hast Spaß an körperlicher Arbeit und bist in der Lage, auch schwerere Möbelteile sicher zu heben und zu bewegen.

-

Du hast einen Führerschein der Klasse B und bist für gelegentliche Montagetermine mobil einsetzbar.

-

Du arbeitest zuverlässig, sorgfältig und selbstständig, gleichzeitig bist du ein echter Teamplayer.

-

Du kommunizierst sicher auf Deutsch und trittst freundlich und professionell auf – auch direkt beim Kunden vor Ort.

#### **Benefits
**

-

**Ein Job mit Sinn**: Dein Beitrag auf dem Weg zu unserer Vision, die (Arbeits)-Welt “happy, healthy & productive” zu gestalten

-

**Wachstum**: Die Chance, deine Karriere in einem der wachstumsstärksten Office Furniture E-Commerce Start-Ups Deutschlands zu starten

-

**Impact: **Die Möglichkeit, unsere Abläufe im Lager- und Montageservice aktiv mitzugestalten

-

**Persönliche Entwicklung:** Eine starke Feedbackkultur sowie ein monatliches Personal-Development-Budget von 25,00 Euro inklusive optionalem Bookbeat und Blinkist Abo, um dich in deinem Wachstum zu unterstützen

-

**Wertschätzung**: Ein Team, welches wirklich ein Team ist. Company-Events, Afterwork Get Together sowie Teamevent-Budget auf Abteilungsebene - Spaß garantiert! Validiert durch Office Vibe und Kununu

-

**Wellbeing**: Büroausstattung mit ergonomischen Büromöbeln, Klimaanlage, Office Dog Policy sowie Snacks & Getränke

-

**Zusatzleistungen**: Edenred-Card mit monatlich 50,00 Euro steuerfreiem Sachbezug oder die Option auf einen EGYM Wellpass

-

**Vergünstigungen**: Mitarbeiterrabatt auf unser Portfolio - auch für Friends & Family sowie exklusive Rabatte durch einen Corporate Benefits Zugang

-

**Individuelle Flexibilität:** Flexible Arbeitszeiten, Hybridkultur (Office, Home Office), 20 Tage Urlaub und Workation Option, um die Welt zu entdecken

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
