# Azure Cloud Engineer

Posted: 2026-08-13T07:30:30Z

## Rejection

- Category: tech_stack
- Reason: role does not mention Go/Golang or PHP

📢 Hiring: Azure Cloud Engineer

📍 Location: Germany Remote

💼 Experience: 1-3 years

*German Language must*

Are you passionate about cloud technologies and modern infrastructure? We are seeking an experienced **Azure** **Cloud** **Engineer** with strong knowledge of **Azure** **Cloud** **Services,** **IaaS,** **PaaS,** **SaaS,** **Containers,** **and** **Kubernetes** to join our growing team.

## Tasks

Key Responsibilities

- Design, deploy, and manage scalable cloud solutions on Microsoft Azure.

- Implement and support Azure Infrastructure as a Service (IaaS) and Platform as a Service (PaaS) offerings.

- Manage containerized applications using Docker and Kubernetes.

- Deploy and maintain Azure Kubernetes Service (AKS) environments.

- Configure and manage Azure networking, security, monitoring, and governance.

- Automate infrastructure provisioning and application deployments using Infrastructure as Code (IaC).

- Collaborate with development, operations, and security teams to deliver cloud-native solutions.

- Troubleshoot and optimize cloud infrastructure, performance, and availability.

## Requirements

Required Skills

- Strong experience with **Microsoft** **Azure**

- Good understanding of **Cloud** **Computing** **concepts** **(IaaS,** **PaaS,** **SaaS)**

- Hands-on experience with **Azure** **Virtual** **Machines,** **Storage,** **Networking**

- Experience with **Containerization** **(Docker)**

- Experience in **Kubernetes** **/** **Azure** **Kubernetes** **Service** **(AKS)**

- Knowledge of Azure App Services, Functions, and API Management

- Familiarity with CI/CD tools such as Azure DevOps or GitHub Actions

- Understanding of cloud security, identity management, and governance

- Strong troubleshooting and problem-solving skills

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
