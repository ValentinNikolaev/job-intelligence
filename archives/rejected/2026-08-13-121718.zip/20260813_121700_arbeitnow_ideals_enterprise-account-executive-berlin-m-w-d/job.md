# Enterprise Account Executive - Berlin (m/w/d)

Posted: 2026-08-13T08:40:14Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

### Get to know us

Ideals is a global B2B SaaS product company recognized as[ the most highly rated and customer-centric brand](https://www.g2.com/categories/virtual-data-room?tab=highest_rated) in the secure business collaboration market. Trusted by over 2,000,000 users from 300,000 companies globally, we help people run high-stakes processes and make important decisions with less stress, higher quality, and shorter hours.

[Ideals Virtual Data Room (VDR)](https://www.idealsvdr.com/): Secure document sharing and collaboration for due diligence, fundraising, corporate reporting, licensing, clinical trials, and other complex transactions.

### The role

Ideals has been in the Virtual Data Room space since 2008 and has built a trusted reputation with clients across multiple industries in Europe, including [Orcan Energy](https://www.idealsvdr.com/clients/energy-firm-orcan-uses-ideals-for-its-fundraising-due-to-its-quality-customer-service-and-transparent-pricing/),[ E-Gruppe](https://www.idealsvdr.com/clients/case-study-e-gruppe/), Deloitte, and EY.

To support the next stage of Ideals VDR growth in Germany, we are looking for an **Enterprise Account Executive** based in **Berlin**. Joining our DACH Key Accounts team alongside your teammates in Munich and Frankfurt, you will own the full new business sales cycle and sell directly to a wide variety of enterprise corporations across diverse industries (such as energy, pharma, biotech, telecommunications, etc.).

As a quota-carrying strategic seller, your primary goal will be to grow sales and revenue through the acquisition of new strategic enterprise accounts and the expansion of existing ones. You will act as an impactful industry expert, generating demand, navigating complex 6 to 9-month sales cycles, and displacing incumbents by utilizing deep discovery and consultative selling frameworks.

Compensation package: 50% base salary; 50% performance-based variable.

### Why Ideals?

-

**Industry-leading sales culture: **Ideals ranks among the Top-5% of companies on [RepVue](https://www.repvue.com/companies/iDeals), as rated by sales professionals. You’ll be empowered with dedicated Sales Enablement, RevOps, DACH Marketing support, and a structured onboarding ramp.

-

**Stable growth: **You’ll join a profitable, bootstrapped SaaS company that is positioned to deliver 5x revenue expansion and reach unicorn status in the next 5 years. The deals you close will shape Ideals' footprint in Germany and feed into our global scaling ambition.

-

**Sales motion built on regional nuance:** You’ll be part of a European-headquartered org, with over 18 years of selling in the VDR business. You'll drive GTM in the region we understand deeply, backed by a product that already powers 10%+ of global M&A activity.

### What you will do

-

Proactively build and manage a pipeline focused on the acquisition of new strategic enterprise accounts (new logos)

-

Conduct solution-based sales engagements, including client meetings, executive presentations, and product demonstrations (face-to-face and virtual)

-

Maintain "White Space" analysis and execute strategic initiatives to upsell and cross-sell within the existing customer base

-

Develop and deliver comprehensive business cases that quantify the cost of inaction and address customer priorities, pain points, and ROI

-

Structure, negotiate, and close complex deals, guiding corporate clients step-by-step through enterprise procurement, security compliance, and legal processes

-

Orchestrate multi-threading strategies to navigate enterprise politics, establishing strong relationships with C-Suite executives and key stakeholders across various verticals

-

Keep an accurate track record of personal sales activities in the CRM, including methodical mid- and long-term forecasting

-

Provide relevant customer feedback to the product development team and collaborate with Customer Success, Marketing, and Inbound Sales to maximize revenue and customer satisfaction

### What you bring

-

4–7 years of demonstrable quota-carrying success in B2B sales

-

Proven track record of managing lengthy or complex enterprise sales cycles

-

Significant experience selling directly to C-level executives (CxOs) and multi-threading within large enterprise organizations

-

Clear understanding of, and practical experience with, consultative sales methodologies (e.g., MEDDIC/MEDPIC, SPIN, Challenger)

-

Exceptional business communication skills, enabling you to execute executive storytelling, challenge the status quo, and handle complex contracting negotiations

-

High learning agility, analytical thinking, and commercial curiosity to quickly grasp the nuances of various corporate industries

-

High AI fluency and advanced CRM tracking skills

-

Native-level proficiency in German with professional English level (C1+)

-

Based in Berlin or within a realistic commuting distance for regular in-person client meetings

### Nice to have

-

Fluency in an additional language

-

Background in SaaS, financial technology, or information security sectors

-

Familiarity with enterprise M&A use cases and corporate compliance workflows

### What we offer

We highly value our people, so we will empower you with all the resources and support to help you reach your full potential.

### For your best work

-

Remote-first flexibility to shape your ideal workday

-

Home workplace budget

-

Co-working expense coverage

-

Individual IT budget for extra equipment

-

Top-tier tech and AI-powered tools

### For your growth

-

Access to Ideals Academy with numerous courses

-

Investment in external learning and development activities

-

Guidance in Personal Development Plan creation

-

Professional literature and subscriptions coverage

-

Support of your passion as a speaker or writer

-

Internal talent mobility opportunities

### For your well-being

-

Tailored Wellness Package to support your physical and mental health

-

Urban Sports membership

-

Funding for sports competitions

-

30 business days of paid time off per year

-

Paid health-related time off

### Extra perks

-

Budget for team gatherings

-

Generous internal referral program

### Our culture

Commitment, Excellence, Collaboration, Trust and Care are core values to the Ideals team. For us, these are the principles that every Idealer lives and breathes. We are on the lookout for like-minded individuals who share our values. By doing so, we create a team where talents feel at ease and work to the best of their abilities.

[Discover more](https://ideals.jobs/our-culture/).

**Ideals is an equal opportunity employer**

Ideals is made up of people from a wide variety of backgrounds and lifestyles. We embrace diversity and invite applications from people from all walks of life. We don’t discriminate against employees or applicants based on gender identity or expression, sexual orientation, race, religion, age, national origin, or citizenship.

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
