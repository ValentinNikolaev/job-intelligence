# Baustoffprüfer (m/w/d)

Posted: 2026-08-13T08:30:40Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**Über uns:

**Rund 800 Mitarbeiterinnen und Mitarbeiter arbeiten in der SIERA Alliance an der Vision für eine bessere Zukunft in den Bereichen Umweltschutz und Klima, Wasser und Ökosysteme, Kreislaufwirtschaft, städtische Nachhaltigkeit und Infrastruktur sowie Impact-Technologie.

Bei der M&P Ingenieurgesellschaft Gruppe West bearbeiten derzeit ca. 100 Mitarbeitende an den Standorten Köln, Düsseldorf und Hagen Projekte aus den Bereichen Umwelttechnik und Wasserwirtschaft. Zur weiteren Verstärkung unserer Abteilung Baugrund suchen wir ab sofort Dich als Baustoffprüfer (m/w/d) an unserem Standort in Köln.

## Aufgaben

**Das sind Deine Aufgaben:**

- Durchführung sowie Auswertung geotechnischer Labor- und Feldversuche zur Führung bodenmechanischer Nachweise (z. B. Siebungen, statische und dynamische Lastplattendruckversuche)

- Gutachterliche Überwachung von Erdarbeiten u. a. im Verkehrswegebau im Rahmen der Eigen- und Fremdüberwachung gem. ZTV E-StB / ZTV SoB-StB

- Durchführung und Begleitung von Bohrarbeiten (Kleinrammbohrungen, Rammsondierungen, Aufschlussbohrungen) sowie Bau von Grundwassermessstellen

- Probenahmen aus den Umweltmedien Boden, Wasser und Luft sowie Materialproben für Rückbauuntersuchungen

- Mitarbeit an gutachterlichen Stellungnahmen und geotechnischen Berichten

## Qualifikation

**Das bringst Du mit:**

- Abgeschlossene Ausbildung zum Baustoffprüfer, Probennehmer oder gleichwertige Qualifikation

- Idealerweise Sachkunde LAGA PN 98; DGUV 101-004/TRGS 524

- Berufserfahrung im oben genannten Tätigkeitsfeld

- Souveränes Auftreten auf Baustellen und in der Kundenbetreuung

- Sicherer Umgang mit den gängigen MS-Office-Produkten

- Projekt- und zielorientierte Arbeitsweise

- Teamplayer mit guter Kommunikationsfähigkeit und Interesse an kreativen Aufgabenlösungen

- Gültige Fahrerlaubnis der Führerscheinklasse B

## Benefits

**Was wir Dir bieten:**

- Mitarbeit an vielseitigen und herausfordernden Projekten unterschiedlicher Größe mit aktivem Beitrag zum Umwelt- und Klimaschutz

- Flache Hierarchien in einer familiengeführten Unternehmensgruppe

- Flexible Arbeitszeiten und Möglichkeit zum mobilen Arbeiten (je nach Aufgabenbereich)

- Moderne Büroräume in attraktiver Lage mit guter Anbindung an ÖPNV und Autobahn

- Umfassende Einarbeitung, Fortbildungsangebote und Mentoringprogramm mit individuellen Entwicklungsmöglichkeiten

- Zusätzliche Vorteile, darunter Preisnachlässe über Corporate Benefit

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
