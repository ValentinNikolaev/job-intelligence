# Senior Cloud Infrastructure Engineer / OpenStack Engineer (m/w/d)

Posted: 2026-08-13T07:00:43Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Du möchtest nicht nur Systeme betreiben, sondern aktiv an einer modernen Cloud-Plattform mitwirken?

Für ein etabliertes und wachstumsstarkes Unternehmen suche ich einen erfahrenen Cloud Infrastructure Engineer, der seine Expertise in einer modernen Infrastruktur einbringen und die Weiterentwicklung einer OpenStack-basierten Umgebung aktiv mitgestalten möchte.

## Aufgaben

Deine Mission:

▪️ Betrieb, Weiterentwicklung und Optimierung einer OpenStack-Cloud-Plattform

▪️ Administration und Automatisierung moderner Linux-Infrastrukturen

▪️ Weiterentwicklung von Kubernetes- und Container-Plattformen

▪️ Automatisierung von Infrastruktur- und Deployment-Prozessen

▪️ Mitarbeit an Architektur- und Infrastrukturentscheidungen

▪️ Sicherstellung von Stabilität, Skalierbarkeit und Performance der Plattform

▪️ Enge Zusammenarbeit mit Development-, Plattform- und Infrastrukturteams

## Qualifikation

Das bringst du mit:

▪️ Erfahrung im Betrieb und der Weiterentwicklung von Cloud- oder Infrastrukturplattformen

▪️Kenntnisse in einem oder mehreren der folgenden Technologien:

- OpenStack

- Linux

- Kubernetes

- Ceph

- Ansible

- Terraform

## Benefits

Das bietet dir das Hero-Hub:

▪️ Moderne Cloud- und Infrastrukturthemen mit viel Gestaltungsspielraum

▪️ Umfangreiche Weiterbildungs- und Entwicklungsmöglichkeiten

▪️ Bis zu 4 Tage Homeoffice pro Woche

▪️ Gehalt bis 95.000 € p.a.

▪️ JobRad, ÖPNV-Ticket, eigene Kantine & kostenloses Laden von E-Fahrzeugen

▪️ Langfristige Perspektive in einem technisch starken Umfeld

📧 **Interesse?**

Dann melde dich gerne bei mir – ich freue mich auf den Austausch! 😊

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
