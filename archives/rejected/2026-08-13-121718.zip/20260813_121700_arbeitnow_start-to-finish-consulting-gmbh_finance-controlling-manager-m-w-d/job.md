# Finance & Controlling Manager (m/w/d)

Posted: 2026-08-13T10:00:41Z

## Rejection

- Category: tech_stack
- Reason: role does not mention Go/Golang or PHP

**Wir sind Start to Finish.**

Kein Startup kann wachsen ohne das richtige Team. Aus diesem Grund unterstützen wir aufstrebende Startups und Growth Companies wie Snocks, SellerX, Formary, Schema M und viele weitere dabei, ihre Schlüsselpositionen mit den richtigen Talenten zu besetzen.

Mit über 100 zufriedenen Kunden sind wir die #1 Recruiting Boutique für E-Commerce Startups im deutschsprachigen Raum.

**Unser Kunde sucht Dich!**

Das Unternehmen gibt schlechter Qualität einen Korb. Aus einem schwäbischen Familienbetrieb im Werkzeugbau ist eine wachsende E-Commerce-Marke für nachhaltige, hochwertige Produkte „Made in Germany" entstanden. Über 250.000 verkaufte Körbe später ist das Unternehmen auf klarem Wachstumskurs – mit neuen Produktlinien und neuen Vertriebskanälen. Damit die nächsten Schritte auf einer soliden Zahlenbasis gelingen, sucht das Unternehmen Verstärkung.

**Deine Rolle**

Du baust das Controlling von Grund auf – und machst aus Bauchgefühl und Excel-Tabellen echte, datenbasierte Steuerung. Du berichtest direkt an die Geschäftsführung, hast vollen Gestaltungsspielraum und wirst zur zentralen Stelle für alle kaufmännischen Fragen.

## Aufgaben

- **Controlling aufbauen:** KPI-Scorecard und Single Source of Truth etablieren, laufende Runrate, Budgetplanung und rollierender Forecast mit Szenarien

- **KPI-Steuerung:** Aufbau eines Dashboards mit den relevanten Kennzahlen (CAC, MER, Werbekostenquote, Deckungsbeitrag nach Werbung)

- **Liquidität & Cash:** rollierende 13-Wochen-Liquiditätsplanung und Planung der Vorfinanzierung unserer internationalen Produktion

- **Sortiment & Marge:** Schnelldreher und Ladenhüter identifizieren, Bundles kalkulieren, Deckungsbeitrag je Artikel und Variante ermitteln

- **Einkauf & Supply Chain:** ERP-Einkauf überwachen, neue Produkte kalkulieren (Landed Cost, Zoll, MOQ), Lieferantenkonditionen nachverhandeln, Make-or-Buy- und Investitionsrechnungen erstellen

- **Kosten & Partner:** Zahlungskonditionen, Dienstleister und Agenturen mit Zahlen hinterfragen

- **Sonderprojekte treiben:** internationale Produktion, neue Produktlinien und Investitionsentscheidungen kaufmännisch begleiten

## Qualifikation

- Kaufmännisches Studium oder Ausbildung (BWL, Finance, Controlling) oder vergleichbar

- Fundierte Controlling-/Finance-Erfahrung, idealerweise im E-Commerce oder Handel mit physischen Gütern

- Sehr stark in Zahlen und Analyse; sicher in Excel/Google Sheets und einem BI-Tool (Power BI oder Looker Studio)Erfahrung mit Forecast, Liquiditätsplanung, Deckungsbeitrags-/Margenrechnung und Bestandsdaten

- Die Fähigkeit, kaufmännische Projekte eigenständig zu treiben

- Verhandlungssicheres Deutsch, Englisch von Vorteil

- Hands-on-Mentalität, pragmatisch und mit dem Anspruch, Themen zu Ende zu bringen

## Benefits

- **100 % remote** – arbeite von überall, ohne Pendeln

- Ein wachsendes Unternehmen mit kurzen Wegen und schnellen Entscheidungen

- Viel Gestaltungsspielraum: Du baust Prozesse mit auf, statt sie nur zu verwalten

- Ein Team, das mitdenkt und anpackt

- Unbefristete Festanstellung in Vollzeit

**🚀 Bereit für den nächsten Step?**

Dann bewirb dich jetzt - Wir freuen uns auf dich! 💡

Die angegebene Gehaltsrange basiert auf aktuellen Marktdaten und gibt dir eine realistische Orientierung. Am Ende hängt es aber von zwei Dingen ab: deiner tatsächlichen Qualifikation – und vor allem von unserem Kunden, der die finale Entscheidung trifft. Wir sind eine Vermittlung, kein Arbeitgeber – das heißt, wir können das Angebot nicht selbst festlegen.

Was wir aber können: dich bestmöglich beraten, dein Profil stark positionieren und gemeinsam mit dir schauen, was drin ist.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
