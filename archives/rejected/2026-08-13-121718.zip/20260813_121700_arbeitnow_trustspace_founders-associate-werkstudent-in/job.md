# Founders Associate Werkstudent:in

Posted: 2026-08-13T10:30:32Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

TrustSpace ist ein schnell wachsendes Cybersecurity-Startup mit Hauptsitz in Berlin. Wir arbeiten mit spannenden Startups & großen Mittelständlern – und lösen alle Probleme rund um Cybersecurity.

Wir suchen eine:n motivierte:n Werkstudent:in als **Founders Associate mit Fokus Sales Ops**, der:die Lust hat, direkt mit unserem Founder-Team zusammenzuarbeiten und operative sowie strategische Themen im Sales-Bereich voranzutreiben.

## Aufgaben

- Unterstützung im Bereich Sales Operations und bei der Weiterentwicklung unserer Sales-Prozesse

- Recherche, Erstellung und Anreicherung von Leadlisten

- Pflege, Strukturierung und Optimierung unseres CRM-Systems

- Unterstützung der Founder bei verschiedenen operativen und strategischen Themen

## Qualifikation

- Du bist aktuell an einer Hochschule oder Universität eingeschrieben

- Du arbeitest sehr strukturiert, zuverlässig und eigenständig

- Du hast ein gutes analytisches Verständnis und arbeitest gerne mit Daten

- Du verfügst über sehr gute Deutschkenntnisse

## Benefits

- Direkter Impact & enge Zusammenarbeit mit den Foundern

- Viel Verantwortung und Einblicke in unterschiedliche Bereiche eines wachsenden Startups

- Steile Lernkurve & Option auf langfristige Zusammenarbeit

- Modernes Office in Berlin Mitte – onsite oder hybrid

- Junges, dynamisches Team & regelmäßige Teamevents

Wir freuen uns auf deine Bewerbung!

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
