# Werkstudent:in Marketing und PR (m/w/d)

Posted: 2026-08-13T09:31:28Z

## Rejection

- Category: tech_stack
- Reason: role does not mention Go/Golang or PHP

Drohnen schützen kritische Infrastrukturen, inspizieren gefährliche Einsatzorte, unterstützen Rettungskräfte und übernehmen Aufgaben, die für Menschen riskant, ineffizient oder schwer zugänglich sind.

Damit Drohnen ihr volles Potenzial entfalten können, müssen ihre Einsätze sicher, zuverlässig und skalierbar werden. Genau daran arbeiten wir bei ETANA SYSTEMS.

Wir entwickeln ein ganzheitliches Software-Ökosystem für industrielle Drohnenoperationen – von der Einsatzplanung über Training und Flottenmanagement bis zur Qualitätssicherung.

Unsere Vision ist eine Zukunft, in der Drohnen ein selbstverständlicher Bestandteil unserer Infrastruktur sind – sicher, zuverlässig, bezahlbar und überall dort verfügbar, wo sie gebraucht werden.

## Aufgaben

Als Werkstudent:in unterstützt du uns beim Aufbau und bei der Weiterentwicklung unseres Marketings und unserer Öffentlichkeitsarbeit.

Zu deinen möglichen Aufgaben gehören:

- Mitgestaltung unserer Marketingstrategie und Kommunikation

- Betreuung unserer Website und Social-Media-Kanäle

- Unterstützung bei Content-Marketing, SEO und digitalen Kampagnen

- Verfassen von Newslettern und Pressemitteilungen

- Erstellung von Medien und Marketingmaterialien

- Recherche relevanter Medien, Multiplikatoren, Veranstaltungen und Kooperationspartner

- Unterstützung bei Events

## Qualifikation

- Studium im Bereich Marketing oder vergleichbar

- Mindset over Skillset!

- Du arbeitest selbstständig und bist engagiert

- Du beherrschst Deutsch und Englisch sicher in Wort und Schrift

- Du kannst komplexe Themen verständlich, interessant und zielgruppengerecht vermitteln.

- Du kennst aktuelle Social-Media- und Content-Formate.

Wichtiger als ein perfekter Lebenslauf sind für uns deine Motivation, deine Lernbereitschaft und dein Interesse an unseren Themen.

## Benefits

- Direkte Zusammenarbeit mit dem Gründerteam und schnelle Entscheidungen

- Viel Gestaltungsspielraum für eigene Ideen – entscheidend ist, dass es funktioniert!

- Selbstständigkeit und Eigenverantwortung statt bloßer Zuarbeit

- Flexible Arbeitszeiten

- 100 % Remote-Arbeit

- Abwechslungsreiche Aufgaben an der Schnittstelle von Marketing, Software und Drohnentechnologie

- Arbeitsproben und Projektergebnisse, die du für dein persönliches Portfolio nutzen kannst

Wir suchen Unterstützung im Umfang von ca. 35 - 50 h pro Monat.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
