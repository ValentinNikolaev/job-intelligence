# Forward Deployed Robotics Engineer

Posted: 2026-08-13T08:40:22Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

## **About Black Forest Labs**

We’re the team behind Latent Diffusion, Stable Diffusion, and FLUX—foundational technologies that changed how the world creates images and video. We’re creating the generative models that power how people make images and video—tools used by millions of creators, developers, and businesses worldwide. Our FLUX models are among the most advanced in the world, and we’re just getting started.

Headquartered in Freiburg, Germany with a growing presence in San Francisco, we’re scaling fast while staying true to what makes us different: research excellence, open science, and building technology that expands human creativity.

## **Why This Role**

We're hiring a Forward Deployed, Robotics Engineer to put our models into the hands of our most important robotics and physical-AI customers. This is a high-ownership, build-in-public role: you'll embed with customers, ship real integrations on their robots, and feed what you learn straight back into our models and roadmap.

We care more about slope than years on a CV. If you've shipped robot-learning systems that real people use, in research, open source, or production; and you love being close to both the hardware and the customer, we want to hear from you, even if your background doesn't match every line below.

## **What You’ll Work On**

-

Partner with customers to design and ship integrations, finetunes, and interfaces on top of BFL's models, including our action / VLA models from first prototype to production.

-

Get models running *well* in the customer's environment: strong latency and output quality on real robots, across on-prem and BFL-hosted deployments, including real-time and on-device / edge constraints.

-

Find the highest-value use cases with customers and prototype solutions fast.

-

Identify and own opportunities to expand BFL's technologies into new domains

-

Prototype novel techniques from recent research papers in close collaboration with our research team

## **What We’re Looking For**

-

Proven track record as a robotics engineer, forward deployed engineer or technical founder

-

Experience working directly with customers, iterating on solutions and providing tailored support for serving generative AI models

-

Hands-on experience with action / VLA models and the surrounding open ecosystem (e.g. π0/π0.5, LeRobot), including imitation/reinforcement learning or policy learning

-

Ability to work on a broad class of engineering problems, from model hosting and backend engineering to building intuitive frontends and UI

-

Excellent communication skills and experience collaborating with non-technical stakeholders internally and externally, with the ability to explain complex technical concepts in simple terms to both technical and non-technical audiences

### **While not required, it’s an added plus if you also have:**

-

Prior knowledge about diffusion models and/or flow matching, and relevant fine tuning and distillation techniques

-

Experience with inference optimizations for transformer based machine learning models

-

Proven ability to architect solutions in complex enterprise environments

-

Contributed to open-source projects, in particular in the space of diffusion models, robotics, or simulation

-

Experience with cloud platforms and state of the art deployment solutions

## **How We Work Together**

We’re a distributed team with real offices that people actually use. Depending on your role, you’ll either join us in Freiburg or SF at least 2 days a week (or one full week every other week), or work remotely with a monthly in-person week to stay connected. We’ll cover reasonable travel costs to make this possible. We think in-person time matters, and we’ve structured things to make it accessible to all. We’ll discuss what this will look like for the role during our interview process.

**Everything we do is grounded in four values:**

-

**Obsessed.** We are a frontier research lab. The science has to be right, the understanding deep, the product beautiful.

-

**Low Ego.** The work speaks. The best idea wins, no matter who said it. Credit is shared. Nobody is above any task.

-

**Bold.** We take the ambitious bet. We ship, we do not wait for conditions to be perfect.

-

**Kind.** People over politics. We treat each other with genuine warmth. Agency without empathy creates chaos.

If this sounds like work you’d enjoy, we’d love to hear from you.

**Base Annual Salary:**

**EU** €120,000- €180,000 + Equity

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
