# Enterprise Account Executive - Dach

Posted: 2026-08-13T08:40:23Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**Shape the Future of Enterprise Success in the DACH Region with **[**monday.com**](http://monday.com)
Ready to make your mark in an extraordinary company?
Help us shape the region from our fast-growing Munich office, backed by a NASDAQ-listed company with $1B+ ARR.

As part of one of the fastest-growing software companies in the world, you’ll be embarking on an exciting journey with [monday.com](http://monday.com) to expand our presence in the DACH region.
As an Enterprise Account Executive, you’ll take ownership of winning enterprise level accounts, helping some of the region’s most influential organisations unlock their potential and achieve measurable success. This role offers you the chance to work at the intersection of strategic advisory, relationship-building, and business growth, driving meaningful impact across a new and existing client base.

**Responsibilities**

-

**Drive Growth:** Own and develop a book of named DACH enterprise accounts, balancing greenfield acquisition with expansion, cross-selling, and multi-product adoption.

-

**Master the Platform:** Deeply understand our AI Work Platform to run discovery calls that uncover true economic impact and turn them into qualified opportunities.

-

**Execute Account Strategy:** Design and execute comprehensive Account Plans for your top accounts to maximize adoption and organizational usage.

-

**Build Relationships:** Partner with key stakeholders and C-level decision-makers to build long-term, trust-based partnerships.

-

**Collaborate Cross-Functionally:** Work closely with SEs, SDRs, and CSMs to win and retain customers, while funneling market insights back to our product and field teams.

**Requirements**

-

**Languages:** Full professional fluency in both German and English.

-

**Experience:** 5+ years of experience in B2B SaaS sales or enterprise account management, managing large accounts (>€50K ACV).

-

**Methodology:** Strong command of structured sales frameworks (e.g., MEDDPICC, Command of the Message, or equivalent).

-

**Track Record:** Proven success navigating complex, multi-stakeholder enterprise sales cycles.

-

**Consultative Value:** Ability to deeply understand client needs, tailor solutions, and confidently pitch financial ROI and business cases to CFOs.

-

**Communication:** Exceptional presentation skills with the ability to build immediate credibility with senior executives.

-

**Mindset:** A curious, collaborative "builder" who constantly raises the bar and wants to win as a team.

**Why Join **[**Monday.com**](http://Monday.com)**?**

[monday.com](http://monday.com) is a Work OS that lets organisations manage all their work in one place. And like our platform, we are committed to building an organisation with one shared mission.

We believe that the most effective teams are built on skills and passion, which is why in our recruitment process, in addition to learning about your background and experience, we really want to understand who you are and what empowers you.

You'll join a fast-growing team with the energy of a startup and the experience of a global leader. As a founding member of the DACH region site, you'll have the chance to shape the future of the operations in this critical market. You will work in a company that fosters a culture of innovation, collaboration, and accountability, where every team member has the opportunity to make a direct impact.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
