# Senior Bauingenieur Geotechnik (m/w/d)

Posted: 2026-08-13T08:00:24Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**Über uns:

**Rund 800 Mitarbeiter arbeiten bei SIERA an der Vision für eine bessere Zukunft in den Bereichen Umweltschutz und Klima, Wasser und Ökosysteme, Kreislaufwirtschaft, städtische Nachhaltigkeit und Infrastruktur sowie Impact-Technologie. Zahlreiche Gesellschaften in Deutschland sorgen für die Nähe zu unseren Kunden.

Bei der M&P Ingenieurgesellschaft Gruppe West bearbeiten derzeit ca. 100 Mitarbeiter an den Standorten Köln, Düsseldorf und Hagen Projekte aus den Bereichen Umwelttechnik und Wasserwirtschaft. Kernkompetenzen sind Dienstleistungen in der Flächenentwicklung (Flächenrecycling, Baugrunduntersuchung und Rückbau), in der Entwicklung von Konzepten zur Altlastensanierung sowie zur Erkundung von Rüstungsaltlasten und der Kampfmittelräumung.

Arbeitsbeschreibung

Zur weiteren Verstärkung unserer Abteilung Baugrund suchen wir ab sofort Sie als Senior Bauingenieur Geotechnik (m/w/d) an unserem Standort in Köln.

## Aufgaben

**Das sind Deine Aufgaben:**

- Fokus auf Baugrund- und Gründungsberatung

- Verantwortung für die konstruktive und statische Planung geotechnischer Konstruktionen im Erd- und Spezialtiefbau (z. B. Fundamentierungen, Baugruben, Stützwände, Erdbauwerke) unter Einsatz von GGU- oder DC-Software

- Erstellung von Kostenschätzungen für Erdbau- und Spezialtiefbaumaßnahmen

- Betreuung und Überwachung von Tiefbaumaßnahmen vor Ort

- Verfassen von Berichten und Gutachten

- Eigenverantwortliche Termin- und Projektplanung

- Kundenbetreuung und Projektakquisition

## Qualifikation

**Das bringst Du mit:**

- Erfolgreich abgeschlossenes Studium im Bauingenieurwesen oder vergleichbare Ausbildung

- Mehrjährige fachbezogene Berufserfahrung (mindestens 5 Jahre)

- Sicheres schriftliches Ausdrucksvermögen, idealerweise belegt durch Erfahrung in der Erstellung von Berichten oder Gutachten

- Bereitschaft zur teamorientierten und interdisziplinären Zusammenarbeit mit verschiedenen Fachspezialist:innen

- Motivation zur kontinuierlichen Weiterbildung – intern wie extern – zur Erweiterung des Fach- und Branchenwissens

- Sicherer Umgang mit MS Office

- PKW-Führerschein (Klasse 3 bzw. B) und Reisebereitschaft für Tageseinsätze, vorwiegend in Westdeutschland

## Benefits

**Was wir Euch bieten:**

- Sinnstiftende Aufgaben: Du arbeitest an vielseitigen und herausfordernden Projekten unterschiedlicher Größe mit und trägst damit aktiv zum Umwelt- und Klimaschutz bei. Außerdem erwarten Dich flache Hierarchien in einer Unternehmensgruppe in Familienbesitz.

- Familienfreundlicher Arbeitgeber: Flexible Arbeitszeiten; mobiles Arbeiten ist je nach Aufgabe ebenfalls möglich.

- Tolles Büro: Attraktive Büroräume mit modernster Ausstattung in hervorragender Lage zu ÖPNV und Autobahnnetz. Notebook und Smartphone gehören zur Grundausstattung.

- Entwicklungschancen: Umfassende Einarbeitung, Fortbildungen sowie ein Mentoringprogramm. Sehr gute, individuelle Entwicklungsmöglichkeiten.

- Echte Benefits: Attraktive Vorteile wie Preisnachlässe bei Corporate Benefits und unser Mitarbeiter-werben-Mitarbeiter-Programm.

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
