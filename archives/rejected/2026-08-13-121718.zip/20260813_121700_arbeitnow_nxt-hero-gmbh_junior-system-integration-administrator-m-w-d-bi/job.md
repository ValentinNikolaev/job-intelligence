# Junior System- & Integration Administrator (m/w/d) // bis 45.000€

Posted: 2026-08-13T07:00:43Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Du möchtest nach deiner Ausbildung oder deinem Studium den nächsten Schritt gehen und suchst eine Position, in der du dich fachlich weiterentwickeln kannst? Dann könnte diese Stelle genau das Richtige für dich sein.

Für ein modernes Unternehmen im Raum Leipzig suchen wir einen **Junior System- & Integration Administrator (m/w/d)**, der Lust hat, sich in einer vielseitigen IT-Landschaft einzubringen und neue Technologien kennenzulernen.

## Aufgaben

**Deine Mission:**

- Administration und Weiterentwicklung der Windows- und Linux-Infrastruktur

- Unterstützung bei der Betreuung von **Active Directory**

- Mitarbeit bei der Integration und Automatisierung von IT-Prozessen

- Betreuung und Optimierung von Server- und Systemlandschaften

- Unterstützung im 2nd-Level-Support sowie enge Zusammenarbeit mit den Fachbereichen

- Mitarbeit in spannenden IT-Projekten und kontinuierliche Weiterentwicklung der Systemlandschaft

## Qualifikation

**Deine Superpower:**

- Abgeschlossene Ausbildung oder Studium im IT-Bereich

- Erste praktische Erfahrung mit **Active Directory**

- Grundkenntnisse in **Linux**, idealerweise auch im Umgang mit der **Shell** (nicht ausschließlich GUI)

- Interesse an Themen wie **Automatisierung**, Scripting oder Prozessoptimierung

## Benefits

**Das bietet Dir das Hero-Hub:**

- Jahresgehalt bis 45.000 €

- Flexible Arbeitszeiten, Hybrides Arbeitsmodell

- Individuelle Einarbeitung und Entwicklungsmöglichkeiten

- Moderne IT-Landschaft mit spannenden Projekten

- Kollegiales Team und flache Hierarchien

- Langfristige Perspektive in einem zukunftssicheren Unternehmen

📩 Interesse? Dann freue ich mich auf deine Nachricht oder deinen Lebenslauf.

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
