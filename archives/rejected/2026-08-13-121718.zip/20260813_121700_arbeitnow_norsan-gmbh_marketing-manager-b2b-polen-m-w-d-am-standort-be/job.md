# Marketing Manager B2B Polen (m/w/d) am Standort Berlin

Posted: 2026-08-13T06:30:59Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**Velkommen om bord – Willkommen an Bord!**

**Was erwartet Dich?** Ein Team mit norwegischen Wurzeln – hochmotiviert und internationalerHersteller der besten Omega-3 Produkte – eine Crew mit ganz viel Omega-3 Expertise – Das und vieles mehr sind wir, NORSAN.

**Unsere Mission?** Wir wollen über Omega-3-Fettsäuren und deren positive Wirkungen im Körper informieren und aufklären. Gleichzeitig möchten wir die besten Omega-3 Produkte zu einer optimalen Versorgung entwickeln und anbieten.

**Wie schaffen wir das?** Wir – die NORSAN-Crew – ein Segel-Team aus cleveren Köpfen, packt mit jeder Menge Einsatz, Kreativität und Spaß an, sind füreinander da und springen da ein, wo die Wellen am höchsten schlagen. Wir sind ein starkes Team, das das gemeinsame Ziel vor Augen hat und den Kurs sowie die Segel auch bei starkem Wind straff hält.

## Aufgaben

**Deine Aufgaben an Deck:**

- Du planst, koordinierst und verantwortest interessante Online- und Offline-Marketingprojekte sowie -kampagnen, die sich an das Medizin- und Therapieumfeld richten (Ärzte, Ernährungsberater, Therapeuten, Apotheken etc.).

- Du bist verantwortlich für die Planung und Umsetzung von Direktmarketing- und E-Mail-Marketing-Maßnahmen, erstellst Mailings, Newsletter, B2B-Customer-Journeys sowie Materialien für das Vertriebsteam.

- Du setzt deine kreativen Ideen eigenständig um – individuell oder in Zusammenarbeit mit dem Marketingteam und den Grafikern.

- Du koordinierst die Erstellung und Produktion von gedruckten Marketingmaterialien, einschließlich Displays, Flyern, Plakaten und anderen verkaufsfördernden Materialien.

- Du nimmst eine wichtige Schnittstellenfunktion zwischen dem Marketingteam, dem Apotheken-Vertriebsteam und dem Team wahr, das mit Experten zusammenarbeitet.

- Du steuerst Projekte in Zusammenarbeit mit Agenturen und externen Dienstleistern und sorgst für deren reibungslose und termingerechte Umsetzung.

- Du koordinierst die Veröffentlichung von Anzeigen und redaktionellen Artikeln in Fachzeitschriften und planst sowie realisierst Kampagnen zur Bewerbung von Webinaren für Fachkreise.Du betreust die Präsenz des Unternehmens auf Online-Verkaufsplattformen und Vergleichsportalen und hältst den Kontakt zu großen Online-Apotheken.

- Du betreust die Präsenz des Unternehmens auf Online-Verkaufsplattformen und Vergleichsportalen und hältst den Kontakt zu großen Online-Apotheken.

## Qualifikation

**Das erwarten wir von dir:**

- Du hast ein abgeschlossenes Studium im Bereich Marketing, Kommunikation, Management, Ernährungswissenschaften, Gesundheitswesen oder einer verwandten Fachrichtung. Alternativ verfügst du über eine abgeschlossene Berufsausbildung und entsprechende Berufserfahrung.

- Du bringst bereits 2–3 Jahre Erfahrung im Direktmarketing mit, Erfahrung in der Zusammenarbeit mit Online-Apotheken ist ebenfalls willkommen.

- Du verfügst über sehr gute Projektmanagement- und Organisationsfähigkeiten.

- Du zeichnest dich durch hohe Textkompetenz aus, hast ein Gespür für Ästhetik, Grafik und Layout und bist sicher im Umgang mit dem MS Office-Paket.

- Du arbeitest proaktiv, selbstständig und umsetzungsstark mit echter „Macher-Mentalität“ und bereicherst das Team durch offene Kommunikation, Feedbackfähigkeit sowie den Blick über den Tellerrand.

- Du interessierst dich für die Themen Gesundheit und Ernährung und gehst diese mit Begeisterung an.

## Benefits

***Vær en viktig del*** **– Sei ein wichtiger Teil des NORSAN-Teams**

Verantwortung, Vertrauen und jede Menge Gestaltungsmöglichkeiten. Unser Ziel - Wir spielen Dich stark für Deine persönliche und berufliche Weiterentwicklung.

***Helse er det viktigste*** **- Weil Gesundheit das Wichtigste ist**

Große und kleine Gesundheits-Benefits mit Sinn und Herz rund um Dein Wohlergehen, weil Du wichtig bist.

***Vi vokser sammen*** **– Wir wachsen gemeinsam**

Auch über die Ländergrenzen hinweg segelt NORSAN. Die enge Zusammenarbeit und der zielführende Austausch mit den internationalen Teams sind spannend auch für Deine tägliche Arbeit.

***Suksess feirer vi sammen*** **– Wir feiern Erfolge**

Das Erreichen eines Etappenzieles wird gefeiert. Für Deine privaten Träume und Wünsche nimmst Du außerdem an dem attraktiven NORSAN-Bonusprogramm teil.

***En NORSAN-familie*** **– Eine NORSAN-Familie**

Mit uns erlebst Du einmalige, große und kleine Teamevents mit gemeinsamen Erlebnissen und ganz viel Energie für unseren NORSAN-Teamspirit und ausreichend frischen Wind in den Segeln.

***Bli litt bedre, steg for steg*** **– Schritt für Schritt besser werden**

Neben unserer Mission zu mehr Gesundheit in der Bevölkerung beizutragen, gehen wir mit nachhaltigen und sozialen Projekten ein Schritt gemeinsam in Richtung einer besseren und gesünderen Welt.

Besuche uns auf unserer Website und lerne unsere großartigen Produkte, das NORSAN-Team und unsere Unternehmenskultur noch ein wenig besser kennen!

Arbeitszeit: Vollzeit

Arbeitsort: Berlin - direkt am Ostkreuz

Sende Deine Bewerbung gern mit Gehaltsvorstellung und frühestmöglichen Starttermin. Wir freuen uns auf Dich und Deinen frischen Wind im Team.

Marta Sokołowska vom NORSAN-Team

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
