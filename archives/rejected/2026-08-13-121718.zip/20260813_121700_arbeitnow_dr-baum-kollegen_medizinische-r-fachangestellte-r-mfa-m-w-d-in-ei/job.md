# Medizinische/r Fachangestellte/r (MFA) (m/w/d) in einer privaten Hautarztpraxis (Kassel)

Posted: 2026-08-13T09:31:29Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Zur Verstärkung unseres Teams suchen wir für unsere private Hautarztpraxis eine/n qualifizierte/n und engagierte/n Medizinische/n Fachangestellte/n (m/w/d) in Vollzeit.

In dieser Position unterstützt du mit hoher Präzision und Organisationsstärke die Abläufe in unserer Praxis und trägst maßgeblich zu einem strukturierten und effizienten Praxisalltag bei.

## Aufgaben

🔹 **Sprechstundenassistenz** – Du begleitest und unterstützt die Ärzt:innen während der Sprechstunde und assistierst bei ästhetischen Behandlungen.

🔹 **Praxisorganisation** – Du behältst den Überblick über die Abläufe, koordinierst die Übergänge zwischen Anmeldung, Arzt, OP und Laser und sorgst für einen reibungslosen Ablauf.

🔹 **Medizinische Tätigkeiten** – Du führst eigenständig Behandlungen wie Abstriche, Wundversorgung, Fäden ziehen und weitere Behandlungen durch.

🔹 **OP-Assistenz** - Du assistierst bei kleinen

ambulanten Eingriffen und führst eigenständig Behandlungen wie

Blutentnahmen und Fändenziehen durch

🔹 **Empfang & Terminorganisation**

– Du vertrittst die Anmeldung bei Engpässen, bist der erste Kontakt für

unsere Patienten an der Anmeldung, begrüßt die Patienten freundlich und

koordinierst Termine präzise, kommunizierst per E-Mail und Telefon und

arbeitest mit unserer neuen cloudbasierten Praxissoftware.

## Qualifikation

✔ Abgeschlossene Ausbildung als Medizinische Fachangestellte (MFA) oder vergleichbare Qualifikation

✔ Realschulabschluss oder Fachabitur

✔ Interesse an dermatologischen und ästhetischen Behandlungen sowie an der Arbeit mit modernen Technologien.

✔ Eine selbstständige, strukturierte Arbeitsweise.

✔ Zuverlässigkeit, Präzision und Verantwortungsbewusstsein.

## Benefits

✨ **Attraktive Sozialleistungen** – inklusive betrieblicher Altersvorsorge, Gesundheitsbonus & Jobticket.

✨ **Strukturierte Einarbeitung & Weiterentwicklung** – durch gezielte Schulungen und Weiterbildungen.

✨ **Modernes Arbeitsumfeld** – mit KI-gestützter Diagnostik, effizientem Praxismanagement und klaren Abläufen.

✨ **Eine unbefristete Vollzeitstelle** mit langfristiger Perspektive

✨ **Vielfältige Aufgaben**

Unsere Hautarztpraxis verbindet medizinische Expertise mit modernster Technologie. Wir setzen auf innovative und fortschrittliche Behandlungsmethoden und schaffen eine vertrauensvolle Atmosphäre für unsere Patienten.

Lust auf neue Herausforderungen in einer modernen Hautarztpraxis? Dann freuen wir uns auf deine Bewerbung!

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
