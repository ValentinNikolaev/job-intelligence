# Projektmanager Job | IT Projektmanager (m/w/d)

Posted: 2026-08-13T08:30:40Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**Gestalte Prozesse – nicht nur Projekte**

Du willst Projekte nicht nur koordinieren, sondern wirklich etwas bewegen?

Als IT-/ERP-Projektmanager:in übernimmst du Verantwortung: von der Analyse bis zum Go-live. Du arbeitest eng mit Entwicklung, Geschäftsleitung und Kunden und gestaltest aktiv die digitale Zukunft des Mittelstands.

## Aufgaben

**Deine Mission: Verantwortung, Wirkung, Digitalisierung**

- Du leitest ERP-Einführungsprojekte von A bis Z – vom Kick-off bis zum Go-live

- Du analysierst und optimierst Prozesse – z. B. in Logistik, Produktion oder Finance

- Du strukturierst Anforderungen, entwickelst Spezifikationen und stimmst dich eng mit Entwicklung und Kunden ab

- Du steuerst mehrere IT-/ERP-Projekte parallel – mit Überblick für Zeit, Budget und Qualität

- Du moderierst Workshops, gibst Schulungen und präsentierst Ergebnisse – überzeugend und zielgruppengerecht

- Du bringst dein Know-how aktiv in interne Digitalisierungsprojekte ein und gestaltest mit uns die Zukunft

## Qualifikation

**Womit du bei uns wirkst:**

- Du hast mehrere Jahre Erfahrung im IT-Projektmanagement oder IT-Consulting

- Du kennst betriebliche Prozesse z. B. in Produktion, Logistik oder Finance

- Du verstehst technische Zusammenhänge, etwa bei Schnittstellen, Datenflüssen oder APIs

- Du arbeitest strukturiert, verlässlich und mit einem klaren Blick für Zeit, Budget und Qualität

- Du moderierst sicher, kommunizierst klar und trittst überzeugend auf – intern wie extern

- Du bist gelegentlich in der DACH-Region unterwegs – planbar und in moderatem Umfang

## Benefits

**Was dich erwartet:**

**Arbeiten, wie es zu dir passt**

- Mobile Office & Workation – arbeite dort, wo du am produktivsten bist

- Option auf eine 4-Tage-Woche

- Vertrauensarbeitszeit & flexible Arbeitszeiten

**Projekte, die Wirkung zeigen**

- Seit 1986: Stabile Software-Schmiede mit Vision

- Echte Digitalisierung statt Folienprojekte

- Direkter Austausch mit Entwicklung & Geschäftsleitung

**Kultur, die verbindet**

- Kommunikation auf Augenhöhe – im Team und mit Führung

- Raum für Ideen & Out-of-the-box-Denken

- Strukturierter Einstieg mit Mentoring und persönlichem Onboarding

- Langjährige Mitarbeiter- und Kundenbindung

**Und on top: deine Benefits**

- Urlaubs- & Weihnachtsgeld

- Firmenwagen inkl. Tankkarte & Privatnutzung

- Laptop, Smartphone & Headset

- Modernes Büro mit Open Work Space, Klimaanlage & Dachterrasse

- Kaffeebar mit kostenfreien Snacks, Wasser, Tee & Milchgetränken

**#teamschmiede – dein nächster Schritt?**

Dann freuen wir uns auf deinen Lebenslauf oder dein LinkedIn-Profil – ganz unkompliziert.

**Kontakt:** Isabel Reutter · +49 7132 9626-50

**Dein neues Umfeld:**

Unsere Software-Schmiede zählt rund **65 Mitarbeitende** – Entwickler:innen, Projektmanager:innen, Consultants und Quereinsteiger:innen, die gemeinsam etwas bewegen wollen.

Unser Hauptsitz ist in Neckarsulm, wo dich ein topmodernes Büro mit Open Work Space, Dachterrasse und kurzen Wegen zur Geschäftsleitung erwartet.

**Seit 1986** wachsen wir stetig, nachhaltig und aus eigener Kraft. Unsere ERP-Lösungen sind bei **über 1.000 mittelständischen Kunden** im Einsatz – vom Familienbetrieb bis zum Industriekonzern.

Gerade in unsicheren Zeiten bieten wir dir, was wirklich zählt: **ein sicherer Arbeitsplatz mit Substanz – und einem Team, auf das du dich verlassen kannst.**

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
