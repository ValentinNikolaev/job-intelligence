# Senior Marketing Designer (m/f/d)

Posted: 2026-08-13T09:00:41Z

## Rejection

- Category: tech_stack
- Reason: role does not mention Go/Golang or PHP

## Your mission

Die Onepage GmbH ist ein AI-first-SaaS-Unternehmen, welches sich das Ziel gesetzt hat, den kinderleichten Aufbau von modernen, schnellen und conversionstarken Webseiten und Landingpages für jeden Unternehmer zu ermöglichen.

Mit Onepage AI 2.0 bauen wir die Brücke zwischen Vibe Coding und No-Code: Sections und Layouts entstehen per Prompt – und bleiben danach im visuellen Editor vollständig steuerbar. Kein Lock-in, kein "einmal generiert und nie mehr angefasst". Daran arbeiten wir – und suchen Leute, die dieses Problem genauso spannend finden wie wir.

**Deine Aufgaben**

- **Entwicklung von Creatives für Social Ads:** Gestaltung und Entwicklung ansprechender und wirkungsvoller Creatives für verschiedene Social-Media-Kanäle (Facebook, Instagram, LinkedIn usw.).

- **Zusammenarbeit mit unserem Marketing-Team:** Enge Zusammenarbeit mit unserem Marketing-Team, um die Konsistenz von Markenbotschaften und C.I. sicherzustellen und die Effektivität von Werbekampagnen zu steigern.

- **Konzeption und Umsetzung:** Entwicklung kreativer Konzepte und deren Umsetzung in visuell ansprechende Designs, die die Zielgruppe ansprechen und zur Erreichung der Marketingziele beitragen.

- **Optimierung unserer Anzeigen:** Kontinuierliche Analyse und Verbesserung der Performance von Social Ads durch Anpassung und Optimierung der Creatives auf Basis von Feedback und Performance-Daten.

- **Erstellung visueller Konzepte und Assets für Landingpages** sowie deren Umsetzung mithilfe unserer eigenen KI-gestützten Page-Builder-Software.

- **Erstellung von Reports, Infografiken und Präsentationsdesigns.**

- **Entwicklung von Creatives für Google Display Ads und Bild-Erweiterungen (Image Extensions).**

## Your profile

- **Erfahrung:** Du bringst mindestens 3-5 Jahre Erfahrung im Grafikdesign mit, idealerweise im Bereich Social-Media-Werbung und Marketing.

- **Design-Tools:** Du verfügst über fundierte Kenntnisse gängiger Design-Tools wie Figma und die Adobe Creative Suite (Photoshop, Illustrator, InDesign).

- **Ad-Erstellung:** Du hast Erfahrung in der Erstellung von statischen und animierten Ads (Meta, Instagram, LinkedIn).

- **KI-Kompetenz:** Du hast erste Erfahrungen im Umgang mit KI-Assistenten zur Entwicklung von Konzepten und visuellen Inhalten und bist generell offen dafür, die Möglichkeiten von KI zu erkunden.

- **Nutzerempathie:** Du hast die Fähigkeit, die Bedürfnisse unserer Nutzer zu verstehen und darauf basierend ansprechende und funktionale Designs zu entwickeln.

- **Ästhetik:** Du hast ein ausgeprägtes Gespür für Ästhetik und die Fähigkeit, schnell kreative und innovative Designlösungen zu entwickeln.

- **Kommunikation:** Du verfügst über exzellente Kommunikationsfähigkeiten und die Fähigkeit, effektiv in einem Remote-Team zu arbeiten.

- **Organisation:** Du gehst strukturiert an deine Arbeit heran und kannst mehrere Prioritäten effektiv managen.

## Why us?

- **Langfristige Perspektive:** Werde Teil eines modernen, innovativen Unternehmens mit Zukunft.

- **Remote-First:** Arbeite zu 100% remote und genieße maximale Flexibilität in deinem Arbeitsalltag.

- **Flache Hierarchien:** Profitiere von kurzen Entscheidungswegen und direkter Kommunikation.

- **Gesundheit:** Deine Gesundheit liegt uns am Herzen – wir unterstützen dich mit einer Zusatzkrankenversicherung sowie einem Zuschuss zu dem Gesundheitsprogramm von Wellhub.

- **Nachhaltige Benefits:** Erhalte attraktive Mitarbeiterrabatte in vielen Kategorien über FutureBens.

- **Mitgestaltung & Entwicklung:** Bringe deine Ideen aktiv ein, gestalte Prozesse mit und erweitere deine Fähigkeiten durch kontinuierliche Weiterbildung.

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
