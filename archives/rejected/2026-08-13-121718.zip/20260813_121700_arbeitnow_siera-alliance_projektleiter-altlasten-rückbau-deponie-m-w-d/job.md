# Projektleiter Altlasten/Rückbau/Deponie (m/w/d)

Posted: 2026-08-13T07:30:30Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**Über uns

**Rund 800 Mitarbeiter arbeiten bei SIERA an der Vision einer besseren Zukunft in den Bereichen Umweltschutz und Klima, Wasser und Ökosysteme, Kreislaufwirtschaft, städtische Nachhaltigkeit und Infrastruktur sowie Impact-Technologie.

Zur Verstärkung unseres Teams suchen wir ab sofort einen Projektleiter (m/w/d) für unsere Abteilung „Deponie – Altlasten – Rückbau“ an den Standorten Köln und Düsseldorf.

## Aufgaben

**Was du bei uns zu einer besseren Zukunft beitragen kannst:**

- Deponierecht & Genehmigung: Kenntnisse der Deponieverordnung (DepV) und zugehöriger Genehmigungsverfahren; Erfahrung in Planung und Ausführungsbegleitung von Deponieabdichtungssystemen

- Altlasten & Flächen: Bearbeitung, Planung und Durchführung von Altlasten- und Flächenrecyclingprojekten sowie Gebäudeschadstofferkundungen

- Rückbau & Sanierung: Planung von Rückbau-, Sanierungs- und Umbaumaßnahmen im Bestand

- Ausschreibung & Vergabe: Erstellung und Auswertung von Ausschreibungsunterlagen im GAEB-Format; Beratung bei Vergabe und Abrechnung von Bauleistungen

- Bauüberwachung: Fachgutachtliche Begleitung und örtliche Bauüberwachung auf unseren Baustellen

- Projektverantwortung: Eigenverantwortliche fachliche, terminliche und wirtschaftliche Abwicklung von Projekten

## Qualifikation

**Was du dafür mitbringen solltest:**

- Abgeschlossenes Studium als Geowissenschaftler (MSc, Dipl.-Geol., Dipl.-Geogr.) oder vergleichbare Qualifikation

- Mindestens 5 Jahre Berufserfahrung in den genannten Themenfeldern

- Souveränes Auftreten, Verhandlungsgeschick sowie Freude an Kundenbetreuung und Akquise

- Teamplayer mit guter Kommunikationsfähigkeit, zielorientierter Arbeitsweise und Freude an kreativen Lösungen

- Wünschenswert: Sachkunde nach DGUV 101-004 (BGR 128) / TRGS 524 und TRGS 519; Kenntnisse im Bereich Gebäudeschadstoffe

- Sicherer Umgang mit MS Office und einem Ausschreibungsprogramm

- PKW-Führerschein

## Benefits

**Was wir dir bieten:**

- Sinnstiftende Aufgaben: Vielseitige, herausfordernde Projekte mit aktivem Beitrag zu Umwelt- und Klimaschutz

- Familienfreundlichkeit: Flexible Arbeitszeiten und Option auf mobiles Arbeiten

- Modernes Arbeitsumfeld: Top-ausgestatteter Arbeitsplatz (Smartphone, Tablet, Laptop, Monitore) in verkehrsgünstiger Lage; engagiertes, junges und professionelles Team

- Teamspirit: Regelmäßige Team-Events und starkes Miteinander

- Weiterentwicklung: Beste Karrierechancen sowie attraktive Entwicklungs- und Weiterbildungsmöglichkeiten in einem stabilen Umfeld

- Echte Benefits: Leistungsgerechte Bezahlung, arbeitgeberfinanziertes Jobticket, betriebliche Altersvorsorge, Mitarbeiter-werben-Mitarbeiter-Programm, Corporate-Benefits-Rabatte, freie Getränke und frisches Obst

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
