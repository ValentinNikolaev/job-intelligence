# Projektleiter (m/w/d) vorsorgender Bodenschutz / Bodenkundliche Baubegleitung

Posted: 2026-08-13T08:30:39Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**Über uns:

**Rund 800 Mitarbeiter arbeiten bei SIERA an der Vision für eine bessere Zukunft in den Bereichen Umweltschutz und Klima, Wasser und Ökosysteme, Kreislaufwirtschaft, städtische Nachhaltigkeit und Infrastruktur sowie Impact-Technologie.

Über die Position

Bist du motiviert, in einem kompetenten Team Fragestellungen im Bereich Bodenschutz und bodenkundliche Baubegleitung erfolgreich zu bearbeiten? Dann bist du bei uns richtig. Wir untersuchen und bewerten das Umweltmedium Boden und tragen durch Planungs- und Kontrollmaßnahmen auf Baustellen aktiv zu seinem Schutz bei. Wir suchen dich für unsere Standorte Köln, Hagen und Düsseldorf.

## Aufgaben

**Deine Aufgaben:**

- Bodenkundliche Kartierungen zur Beurteilung und Dokumentation von Bodenverhältnissen

- Entwicklung von Konzepten zum Schutz des Bodens (z. B. bei Bauvorhaben oder landwirtschaftlicher Nutzung)

- Begleitung und Betreuung von (Groß-)Baustellen im Rahmen der bodenkundlichen Baubegleitung

- Kommunikation mit Auftraggebern, Landwirten/Eigentümern, Behörden und weiteren Fachplanern

- Dokumentation der Ergebnisse in Form von Gutachten und Präsentationen

- Eigenverantwortliche Leitung von Projekten in diesem Fachbereich

## Qualifikation

**Dein Profil:**

- Erfolgreich abgeschlossenes Studium oder vergleichbare Qualifikation in Bodenkunde, Agrarwissenschaften, Geographie, Geowissenschaften o. Ä.

- Mehrjährige Erfahrung in Bodenfunktionsbewertungen und der Erstellung von Bodenschutzkonzepten; Berufseinsteiger sind ebenfalls willkommen

- Erfahrung in bodenkundlicher Kartierung nach KA5

- Tiefbau-/Baustellenerfahrung wünschenswert

- Kenntnisse im Pflanzenanbau und in der Bodenrekultivierung von Vorteil

- Kenntnisse zur Bewertung von Böden unter bodenchemischen Aspekten (BBodSchG/BBodSchV, ErsatzbaustoffV, LAGA)

## Benefits

**Was wir dir bieten:**

- Sinnstiftende Aufgaben: Vielseitige und herausfordernde Projekte mit aktivem Beitrag zu Umwelt- und Klimaschutz; flache Hierarchien in einer Unternehmensgruppe in Familienbesitz

- Familienfreundlicher Arbeitgeber: Flexible Arbeitszeiten; mobiles Arbeiten je nach Aufgabe möglich

- Tolles Büro: Attraktive Büroräume mit modernster Ausstattung in hervorragender Lage zu ÖPNV und Autobahnnetz; Notebook und Smartphone gehören zur Grundausstattung

- Super Teamspirit: Regelmäßige Team-Events

- Entwicklungschancen: Umfassende Einarbeitung, Fortbildungen sowie ein Mentoringprogramm; sehr gute, individuelle Entwicklungsmöglichkeiten

- Echte Benefits: Attraktive Vorteile wie Preisnachlässe bei Corporate Benefits und unser Mitarbeiter-werben-Mitarbeiter-Programm

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
