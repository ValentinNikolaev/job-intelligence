# Civil Engineer (m/f/d)

Posted: 2026-08-13T08:00:28Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

As a **Civil Engineer (m/f/d),** you will lead the civil and structural design and delivery of Battery Energy Storage System (BESS) projects, ensuring that sites, foundations and balance-of-plant infrastructure are engineered safely, cost-effectively and to code. The role turns project sites into buildable, permit-ready designs and bridges the development, procurement and construction teams to support the company's growth in grid-scale energy storage.

## Your Contribution to the Energy Transition

-

Develop and review civil and structural designs for BESS sites, including grading, drainage, foundations, access roads and equipment pads, from concept through construction.

-

Design foundations and site layouts for battery containers, inverters and transformers, working closely with electrical engineering teams.

-

Manage geotechnical investigations and apply findings to foundation design, earthworks and overall site development.

-

Prepare technical specifications, scopes of work and tender documentation, and support the evaluation of EPC and civil contractor proposals.

-

Oversee civil works during construction and coordinate with consultants, authorities and stakeholders to ensure compliance with applicable standards, permits and health & safety requirements.

## Your Profile

- Bachelor’s or Master’s degree in Civil or Structural Engineering (or a related field) and 3+ years of experience in civil or structural design, ideally within energy, infrastructure or industrial projects.

- Proficiency in AutoCAD/Civil 3D, ArcGIS and other structural analysis and site design tools, with solid knowledge of foundation design, earthworks, drainage and relevant building codes.

- Experience with BESS, solar, wind or other renewable energy infrastructure projects is highly desirable.

- Fluent in English and German, with strong stakeholder management and cross-functional collaboration skills.

- Proactive, hands-on and adaptable mindset, with the willingness to work in a dynamic project environment and travel to project sites as required

## What We Offer at MIRAI Power

**Flexible Work Culture:** We focus on results rather than rigid rules, offering a high level of trust, autonomy, and flexibility.

**Real Impact & Ownership:** From day one, you will take on responsibility and have a direct influence on our projects, processes, and the future development of MIRAI Power.

**Collaborative Environment:** We believe in short decision-making paths, open communication, and working together as equals - this is part of our everyday culture.

**Professional Development:** Whether through technical training or business language courses, we actively support your personal and professional growth.

**Health & Mobility:** We support your well-being with **Wellpass** as well as a subsidy for the **Deutschlandticket** or an individual mobility solution.

**Additional Benefits:** Our benefits package also includes a company pension scheme, access to a pool vehicle for business travel, regular team events and team days, as well as our annual company offsite.

*Diversity*
*Diversity drives innovation. We welcome applications from people of all backgrounds, regardless of gender, nationality, ethnic origin, religion, age, disability, or identity. Applicants with severe disabilities will be given preferential consideration if equally qualified. Mutual respect, inclusion, and appreciation form the foundation of everything we do.*

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
