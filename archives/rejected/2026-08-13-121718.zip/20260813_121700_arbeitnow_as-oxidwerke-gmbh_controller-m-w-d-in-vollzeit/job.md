# Controller (m/w/d) - in Vollzeit

Posted: 2026-08-13T10:00:32Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**Gemeinsam Kreisläufe schließen – Aluminiumschmelze und Recycling vereint**

Am Standort Stockach betreiben wir mit der AS Oxidwerke GmbH ein Aluminiumschmelzwerk sowie eine Anlage zur Salzschlackenaufbereitung und bündeln damit umfassende Kompetenz entlang des Aluminiumkreislaufs. Wir produzieren hochwertige Aluminium-Walzbarren und führen Materialien aus der Aluminiumproduktion nachhaltig in den Wertstoffkreislauf zurück. Mit modernen Anlagen, kontinuierlicher Weiterentwicklung und einem engagierten Team leisten wir einen wichtigen Beitrag zur ressourcenschonenden und zukunftsfähigen Aluminiumindustrie.

## Aufgaben

- Bereitstellung von fundierten Entscheidungsgrundlagen und Aufzeigen von Einsparpotenzialen für das Management.

- Weiterentwicklung von Controlling-Instrumenten, ERP- und Berichtssystemen

- Mitgestaltung des Reporting, sowie Weiterentwicklung der Kosten- und Leistungsrechnung

- Weiterentwicklung der Controllingprozesse

- Vertretung und Unterstützung des Leiters Controlling/Finanzen

- Erstellung des Regelreportings, sowie betriebswirtschaftlicher Analysen

- Durchführung von Plan-Ist-Vergleichen und Ad-hoc-Auswertungen

- Führen von Statistiken

## Qualifikation

- Abgeschlossenes betriebswirtschaftliches Studium (BWL, Finance) oder vergleichbare kaufmännische Ausbildung

- Exzellente MS-Excel-Kenntnisse sowie Erfahrung mit SAP als ERP-System und Business-Intelligence-Tools

- Verhandlungssicheres Deutsch und Englisch

- Analytisches Denkvermögen, Zahlenaffinität, starke Kommunikationsfähigkeit und Durchsetzungskraft

- Mehrjährige Praxis im operativen oder finanziellen Controlling

- Eine pragmatische Hands-on-Mentalität, schnelle Auffassungsgabe und Freude daran, Dinge einfach zu machen, statt nur zu planen

## Benefits

- Unbefristete Tätigkeit in einem zukunftsorientierten Unternehmen

- Fundierte Einarbeitung und bedarfsorientierte Weiterbildungsmöglichkeiten

**Hast du Lust, dass wir gemeinsam anpacken für die Zukunft?**

Dann komm in unser Team.

Sende uns hierfür bitte Deine Bewerbungsunterlagen.

Kontakt

Silke Sailer

Head of HR

Tel: [+491](https://join.com/jobs/15830660/edit#)7612576030

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
