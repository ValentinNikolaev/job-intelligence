# Manager, Applied AI Architects

Posted: 2026-09-01T08:40:17Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

## **About the Team**

The Applied AI Architect team partners with organizations to turn OpenAI's most capable models into meaningful, real-world impact. We work with customers across industries to identify where AI can create value, design secure and scalable solutions, and help those solutions move from early exploration into sustained production adoption. The team brings together technical strategy, customer partnership, and practical deployment expertise, working closely with Sales, Product, Engineering, Research, and specialist delivery teams.

## **About the Role**

As the Manager of Applied AI Architects in Munich, you will lead a team of senior technical leaders responsible for the technical strategy, customer journey, and path to production value for OpenAI's largest and most complex customers across the DACH region. Your team will act as the “CTO of the book of business,” partnering with customer executives and technical teams from pre-sales discovery and solution evaluation through deployment, adoption, and measurable business impact.

You will set the operating model for how Applied AI Architects own technical account plans across ChatGPT Enterprise, the OpenAI API, Codex, and other agentic AI solutions. In close partnership with Sales leadership and Account Directors, you will help prioritize customer portfolios, allocate technical resources, and ensure business priorities translate into focused use cases, credible architectures, actionable adoption roadmaps, and durable customer value and growth.

You will remain accountable for the team's technical outcomes while developing its people and bringing in the right specialists across deployment, implementation, enablement, security, product, research, and partners. You will serve as an executive technical sponsor for critical engagements, a senior voice of the customer inside OpenAI, and a cross-functional leader who can move confidently between regional strategy, executive decision-making, architectural depth, and hands-on coaching.

This role is based in Munich. We use a hybrid work model of 3 days in the office per week and offer relocation assistance to new employees.

## **In this role, you will:**

-

Hire, coach, and develop a high-performing team of Applied AI Architects, creating an environment of technical excellence, sound judgment, continuous learning, accountability, and strong customer stewardship.

-

Define and continuously refine the strategy and operating model for Applied AI Architecture across Europe, aligning company priorities with the evolving needs of strategic customers and the regional go-to-market.

-

Partner with Sales leadership and Account Directors to prioritize accounts and opportunities, allocate technical resources effectively, and establish clear technical strategies for the region's most consequential engagements.

-

Ensure Applied AI Architects serve as the primary technical advisors for their portfolios, owning technical account plans, technical milestones, adoption priorities, account health, and expansion opportunities.

-

Lead complex, multi-threaded customer journeys that connect executive vision and business outcomes with use-case qualification, solution evaluation, enterprise governance, and a credible path to production.

-

Coach the team on Applied AI architectures spanning models, applications, data, integration, identity, security, privacy, governance, evaluation, reliability, and deployment.

-

Build trusted relationships with C-suite and board-level stakeholders, as well as senior AI, technology, data, security, and engineering leaders, serving as an executive technical sponsor when needed.

-

Mobilize Deployment Engineering, implementation, enablement, Product, Engineering, Research, Security, Legal, Privacy, partners, and other specialists to remove blockers and deliver a cohesive customer experience.

-

Establish a rigorous view of portfolio health, including technical wins, qualified use cases, production readiness, adoption, usage, risks, measurable customer impact, and the technical contribution to growth.

-

Translate patterns from the field into actionable feedback for Product, Engineering, Research, and go-to-market teams, while developing reusable architecture guidance and customer practices.

-

Foster a culture that balances ambitious customer outcomes with responsible AI deployment, clear ownership, thoughtful prioritization, and effective specialist handoffs.

## **You might thrive in this role if you:**

-

Possess deep technical acumen in modern AI systems, frontier models, agentic applications, platform technologies, software and cloud architecture, APIs, data integration, identity, security, privacy, evaluation, and enterprise deployment.

-

Bring 10+ years of experience in customer-facing technical roles such as solutions architecture, solutions engineering, technical account leadership, AI deployment, or technical consulting, including work with large and complex enterprises.

-

Have 4+ years of people-management experience hiring, coaching, and developing high-performing customer-facing technical teams.

-

Have guided enterprise organizations from technical discovery and evaluation through production adoption, healthy usage, and measurable business impact.

-

Demonstrate outstanding executive communication and presentation skills, with the ability to build credibility with CTOs, CIOs, CISOs, boards, business leaders, and hands-on engineers.

-

Can lead a complex portfolio, make thoughtful resource-allocation decisions, and balance regional strategy with hands-on support for critical customer engagements.

-

Exercise strong architectural judgment, including knowing when to go deep personally, when to coach the team, when to involve specialists, and how to define clear handoffs and ownership.

-

Build strong partnerships across Sales, Product, Engineering, Research, Deployment, Customer Engagement, Security, Legal, Privacy, and external partner ecosystems.

-

Are comfortable leading across European markets from London and adapting your approach to different industries, cultures, regulatory contexts, and customer operating models.

-

Embody a customer-centric philosophy focused on durable value, responsible production adoption, technical excellence, and long-term partnership.

-

Approach your work with humility, curiosity, a collaborative spirit, and a deep commitment to the safe and beneficial advancement of AI.

**About OpenAI**

OpenAI is an AI research and deployment company dedicated to ensuring that general-purpose artificial intelligence benefits all of humanity. We push the boundaries of the capabilities of AI systems and seek to safely deploy them to the world through our products. AI is an extremely powerful tool that must be created with safety and human needs at its core, and to achieve our mission, we must encompass and value the many different perspectives, voices, and experiences that form the full spectrum of humanity.

We are an equal opportunity employer, and we do not discriminate on the basis of race, religion, color, national origin, sex, sexual orientation, age, veteran status, disability, genetic information, or other applicable legally protected characteristic.

For additional information, please see [OpenAI’s Affirmative Action and Equal Employment Opportunity Policy Statement](https://cdn.openai.com/policies/eeo-policy-statement.pdf).

Background checks for applicants will be administered in accordance with applicable law, and qualified applicants with arrest or conviction records will be considered for employment consistent with those laws, including the San Francisco Fair Chance Ordinance, the Los Angeles County Fair Chance Ordinance for Employers, and the California Fair Chance Act, for US-based candidates. For unincorporated Los Angeles County workers: we reasonably believe that criminal history may have a direct, adverse and negative relationship with the following job duties, potentially resulting in the withdrawal of a conditional offer of employment: protect computer hardware entrusted to you from theft, loss or damage; return all computer hardware in your possession (including the data contained therein) upon termination of employment or end of assignment; and maintain the confidentiality of proprietary, confidential, and non-public information. In addition, job duties require access to secure and protected information technology systems and related data security obligations.

To notify OpenAI that you believe this job posting is non-compliant, please submit a report through [this form](https://form.asana.com/?d=57018692298241&k=5MqR40fZd7jlxVUh5J-UeA). No response will be provided to inquiries unrelated to job posting compliance.

We are committed to providing reasonable accommodations to applicants with disabilities, and requests can be made via this [link](https://form.asana.com/?k=bQ7w9h3iexRlicUdWRiwvg&d=57018692298241).

[OpenAI Global Applicant Privacy Policy](https://cdn.openai.com/policies/global-employee-and-contractor-privacy-policy.pdf)

At OpenAI, we believe artificial intelligence has the potential to help people solve immense global challenges, and we want the upside of AI to be widely shared. Join us in shaping the future of technology.

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
