# Senior MongoDB Administrator (m/w/d)

Posted: 2026-09-02T23:30:33Z

## Rejection

- Category: language_requirement
- Reason: hard German language requirement without English green light

IT42morrow steht für Innovation und Dynamik in der IT-Welt. Mit einer Palette von spannenden Projekten und einer Kultur, die Wachstum und Diversität fördert, sind wir auf der Suche nach einem neuen Star in unserem Entwickler-Team. Egal, ob Du ein erfahrener Profi oder ein begeisterter Neuling mit einer Leidenschaft für Technologie bist – wenn Du bereit bist, in die Welt der großen IT-Umgebungen einzutauchen, sollten wir uns unterhalten!

## Aufgaben

- Übernimm die Verantwortung für Design, Betrieb und Wartung großer, verteilter MongoDB-Cluster im geschäftskritischen Umfeld.

- Zeige deine Fähigkeiten bei der Architektur und Skalierung von Replica Sets und Sharded Clusters für maximale Hochverfügbarkeit und Ausfallsicherheit.

- Werde zum Problemlöser, wenn es um Cluster-Performance, Load-Balancing über Shards, Query-Optimierung und Indexstrategien geht.

- Du planst und führst Cluster-Erweiterungen, Rebalancing, Failover-Szenarien und rollierende Upgrades im laufenden Betrieb durch? Das ist dein Ding!

## Qualifikation

- **Cluster-Profi:** Du hast nachweisliche, mehrjährige Erfahrung im Aufbau und Betrieb ganzer MongoDB-Cluster in Produktivumgebungen – von der Konzeption von Replica Sets und Sharding-Strategien bis hin zum Betrieb von MongoDB Atlas oder Enterprise Advanced im großen Maßstab.

- **Skalierung & Hochverfügbarkeit:** Du verstehst die Mechanismen hinter Sharding, Replikation, Election-Prozessen und Read/Write-Concerns und weißt, wie man Cluster über mehrere Rechenzentren oder Regionen hinweg ausfallsicher auslegt.

- **Datenmodellierung:** Du weißt, wie man effiziente Schema-Designs, Aggregation Pipelines und Indexstrategien für performante Abfragen über verteilte Datenbestände gestaltet.

- **Automatisierung:** Mit Tools wie Ansible, Terraform oder Skriptsprachen (Python, Bash) automatisierst du Provisionierung, Konfiguration und den Betrieb ganzer Cluster.

- **Container-Plattformen:** Docker, Kubernetes oder OpenShift sind für dich unverzichtbare Werkzeuge, um Datenbank-Cluster konsistent und effizient zu betreiben.

- **Cloud-Themen:** Du hast bereits Erfahrung mit dem Betrieb verteilter Datenbanken in Cloud-Umgebungen auf Basis von MS Azure, Amazon Web Services oder der Google Cloud Platform.

- **Monitoring & Backup:** Du nutzt Tools wie MongoDB Ops Manager, Prometheus, Grafana oder den ELK Stack zur Cluster-Überwachung und setzt robuste Backup- und Recovery-Strategien für verteilte Umgebungen um.

- **Sicherheitsbewusst:** Für dich steht die Sicherheit der Daten immer an erster Stelle. Du bist vertraut mit Authentifizierung (LDAP, Kerberos), rollenbasierter Zugriffskontrolle (RBAC), Verschlüsselung und Auditing und sorgst dafür, dass Sicherheitslücken keine Chance haben

- .**Kommunikationsstark:** Du weißt, dass gutes Wissen geteilt werden muss. Im Team fühlst du dich wohl und kannst komplexe Sachverhalte klar und verständlich vermitteln.

- **Lernwillig:** Die IT-Welt verändert sich rasant, und du bist immer bereit, Neues zu lernen und dich weiterzuentwickeln.

- **Reiselustig:** Du bist offen für Einsätze bei unseren Kunden und siehst darin eine Chance, deinen Horizont zu erweitern.

- **Sprachtalent:** Du beherrschst Deutsch mindestens auf dem Niveau C1. Englischkenntnisse sind ein absoluter Pluspunkt.

## Benefits

- **Zukunftssicherheit:** Freu Dich auf einen unbefristeten Arbeitsplatz in einem zukunftsorientierten Unternehmen.

- **Entwicklungspotenzial:** Wir investieren in Deine Karriere mit individuellen Weiterbildungsmöglichkeiten.

- **Cutting-Edge Technologie:** Arbeite mit den neuesten Technologien und bleib immer am Puls der Zeit.

- **Projektvielfalt:** Bei uns gibt es eine breite Palette an Herausforderungen, die Deinen Arbeitsalltag spannend und abwechslungsreich gestalten.

- **Reisebereitschaft:** Für Dienstreisen bist Du bei uns in guten Händen – Organisation und Kostenübernahme sind selbstverständlich.

**Jetzt bist du am Zug!**

Ist das die Herausforderung, auf die du gewartet haben? Dann zögere nicht! Schicke uns deine Bewerbungsunterlagen, inklusive Gehaltsvorstellung und möglichem Startdatum. Lass uns gemeinsam die IT-Welt von morgen gestalten!

Wir sind schon gespannt auf dich!

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
