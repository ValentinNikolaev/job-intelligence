# Staff Engineer - Talentpool (m/f/d)

Posted: 2026-09-02T23:30:22Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**Entyre**, part of the Entyre Group, is one of the fastest-growing health tech scale-ups in Switzerland and the United States. With 500+ employees globally and offices in Zurich, Berlin, Boston, Chicago, Detroit, Arlington, and Columbus, we are scaling rapidly.

At **Entyre**, our mission is to reduce both under and over-provision of healthcare through the intelligent combination of human expertise and technology. Our dedicated care consultants work tirelessly on an international level, supported by our proprietary software solutions.

We believe that individuals in need of care, who are looked after by their relatives at home, have the right to live a self-determined and dignified life in their own homes. With our brands Pflegewegweiser and Entyre Care, we are committed to achieving this goal by focusing on two central pillars: providing professional support to caregiving relatives in all areas of home care with our extensive expertise and ensuring fair monetary compensation for their efforts. We are also driving the development of innovative solutions in collaboration with scientific partners.

In this vital, dynamic, and international environment, we are looking for a **Staff Engineer** (m/f/d) to join our team in Berlin.

**Role**

We’re looking for an experienced **Staff Engineer** to take ownership of the full software development lifecycle, from design and implementation to deployment. In this role, you’ll leverage your deep technical expertise to build high-quality, scalable software solutions while collaborating closely with our stakeholders in Germany, Switzerland and the US. You’ll play a crucial role in shaping our technical direction and driving continuous improvement across our systems and processes, leaving a lasting footprint on our growth trajectory.

**Key Responsibilities**

-

Lead end-to-end development of software solutions, including requirements gathering, architecture design, development, testing, and deployment

-

Own the full software development lifecycle (SDLC) from start to finish, ensuring high-quality, scalable solutions

-

Collaborate with cross-functional teams to understand business requirements and translate them into technical specifications

-

Design and implement backend and frontend systems, ensuring they meet business and functional requirements

-

Lead infrastructure setup and DevOps practices, ensuring efficient deployment pipelines and system reliability

-

Continuously stay current with emerging technologies and industry best practices to drive improvements

-

Collaborate with leadership to define technical strategy, contribute to hiring decisions, and support the growth of the engineering team

**Qualifications**

-

Minimum 8 years of relevant experience in software engineering, with a deep understanding of the full software development lifecycle

-

Proven experience in designing, building, and maintaining backend and frontend systems

-

Strong experience in DevOps practices and infrastructure setup

-

Prior experience with [Node.js](http://Node.js), [Vue.js/React.js](http://Vue.js/React.js), PostgreSQL, and Redis is a strong plus

-

Strong leadership skills, with the ability to take technical ownership of projects and inspire a team

-

Excellent communication skills, with the ability to work effectively with both technical and non-technical stakeholders

-

Experience in a technical lead role, mentoring other engineers and driving technical decisions

-

Strong problem-solving skills and a passion for continuous learning and improvement

-

Fluent English

**Preferred, but not critical:**

-

Experience in a startup or rapidly growing company environment

**How We Operate - Non-Negotiable:**

**1. "Insanely Great" for Families - Delivered Now:**
Forget just 'satisfaction'. We deliver support that makes caregivers feel loved and seen. Understand their pain, anticipate their needs, and solve them – fast.
The standard is *"Insanely Great,"* period. Anything less slows us down and fails our families.

**2. Speed is King - Ruthless Focus is the Key:**
Velocity comes from focus. Kill distractions. We concentrate all firepower on the #1 critical objective until it's done. Then we attack the next one.
Decide what not to do and cut it ruthlessly. Being a mile wide and an inch deep is failure. Move the needle now.

**3. Raise the Bar: Crush Mediocrity:**
Mediocrity is poison. It kills speed, morale, and companies. We hunt it down and eliminate it. Good enough is never good enough.
Demand A-Player performance from yourself and everyone around you. Own your shit. Deliver excellence, fast. No excuses, no passengers.

**4. The Speed Algorithm: Question. Delete. Simplify. Accelerate.**
This is how we build momentum: Question every requirement – who asked? why? Delete ruthlessly – parts, processes, bureaucracy. If you don't add 10% back later, you didn't cut enough. Simplify what's left. Then, accelerate cycle time like hell.
Challenge everything. "It can't be done" means "You haven't figured it out yet. Go do it." Break bottlenecks, find shortcuts, remove friction.

**5. Act Like Owners - Bold Bets, Fast Action:**
This is your company. Own the mission, own the results. Don't wait for permission – take initiative.
Make bold bets that can leapfrog progress for our families. Act decisively. Move fast. If you stumble, learn faster and go again. Bias for action is everything.

**The Bottom Line:**
We are building something vital, and we are doing it at lightning speed. This requires intensity, focus, and a relentless drive to execute. If reading this makes you want to jump up and build faster, welcome to Entyre. If not, get out of the way.

Ready to make an impact? We’re excited to receive your application and can’t wait to see what we can achieve together!

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
