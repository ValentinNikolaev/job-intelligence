# Embedded Software Engineer IoT & Connectivity (m/w/d)

Posted: 2026-09-02T17:09:24Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**Willkommen bei Wirelane**

Deutschland verzeichnet neue Rekordzulassungszahlen von Elektrofahrzeugen sowie eine rasant steigende Zahl von Lademöglichkeiten. Die Bundesregierung hat sich in diesem Kontext sehr ambitionierte Ziele gesetzt und möchte bis zum Jahr 2030 15 Millionen zugelassene elektrische Fahrzeuge und 1 Million installierte öffentliche Ladepunkte erreichen.
Als Full Service Provider für Ladeinfrastruktur bewegt sich Wirelane somit in einem sehr dynamischen und stark wachsenden Marktumfeld. Dabei müssen wir die stetig steigende Nachfrage nach und Anforderungen an innovativen Ladelösungen für Elektrofahrzeuge beherrschen.
Für unser schnell wachsendes Team suchen wir Dich als **Embedded Software Engineer IoT & Connectivity (m/w/d)** zur Verstärkung unseres Teams "**Build It"** an unserem **Firmenhauptsitz in München**.
In dieser Rolle sorgst Du dafür, dass unsere Ladeinfrastruktur zuverlässig vernetzt bleibt. Du arbeitest an der Schnittstelle von Embedded Software, IoT Connectivity und Payment-Systemen und trägst maßgeblich zur Stabilität und Weiterentwicklung unserer technischen Plattform bei.

**Deine Aufgaben**

- Du entwickelst und betreust unsere Embedded Software für Router, Connectivity-Lösungen und Payment Terminals.
- Du verantwortest Firmware Updates und Rollouts für unsere installierte Geräteflotte.
- Du stellst die zuverlässige Kommunikation zwischen Ladestation, Router und Bezahlsystem sicher.
- Du analysierst und behebst technische Störungen in den Bereichen Netzwerk, Mobilfunk und VPN.
- Du entwickelst Lösungen für Monitoring, Fernwartung und Automatisierung unserer Geräte.
- Du arbeitest eng mit Hardware-, Software- und Operations-Teams an der Weiterentwicklun unserer Ladeinfrastruktur zusammen.

**Wen wir suchen**

- Abgeschlossenes Studium der Informatik, Embedded Systems, Elektrotechnik oder einer vergleichbaren Fachrichtung
- Mehrjährige Erfahrung in der Embedded Softwareentwicklung
- Sehr gute Kenntnisse in Python sowie C oder C++
- Erfahrung mit Embedded-Systemen und hardwarenaher Softwareentwicklung
- Kenntnisse im Bereich IoT, Cloud-Technologien und vernetzter Geräte
- Erfahrung mit Firmware-Management und Geräteflotten von Vorteil
- Gute Kenntnisse von Netzwerkprotokollen wie TCP/IP, DNS, DHCP oder HTTPS
- Erfahrung mit VPN-Technologien wie WireGuard, OpenVPN oder IPsec
- Kenntnisse im Bereich LTE- und 5G-Kommunikation sind von Vorteil
- Sehr gute Deutschkenntnisse sowie gute Englischkenntnisse in Wort und Schrift

**Warum Wirelane? **

- Du übernimmst spannende Aufgaben in einem Technologieunternehmen mit einem innovativen und breiten Produktangebot.  
- Du profitierst von einem attraktiven Gesamtpaket aus Vergütung, Mitarbeiter-Benefits und Weiterbildungsmöglichkeiten.
- Du bist Teil einer rasant wachsenden Industrie, die zum ökologischen, gesellschaftlichen und wirtschaftlichen Wandel beiträgt.  
- Du arbeitest im motivierenden Arbeitsumfeld eines zielorientierten und schnell wachsendem Startups, das Du mitgestaltest.  
- Du übernimmst Verantwortung und arbeitest selbstständig in einem dynamischen Team.  
- Du arbeitest auf  Augenhöhe mit kurzen Kommunikationswegen, offenen Türen und mit engagierten Kolleg*innen mit viel Teamgeist und großer Umsetzungsstärke.

**Wer ist Wirelane? **

Unsere Kultur ist geprägt von starken Werten. Diese leiten uns in unserem Handeln und in unserer Zusammenarbeit:

**Candour** - We believe that open beats closed. 
**Collaboration** - We are better together.
**Competence **- We want to better our best.
**Courage** - We question the status quo.
**Circularity** - We care about what comes next.
 
Jede:r neue Mitarbeiter:in bietet uns die Möglichkeit, eine andere Perspektive einzubringen. Unser Ziel ist es, ein vielfältiges Team aufzubauen in der Alle, auch über das operative Geschäft hinaus, ihren Beitrag leisten und sich entwicklen können.

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
