# Project Manager, Gaming Localization Production

Posted: 2026-09-02T23:40:13Z

## Rejection

- Category: location_requirement
- Reason: requires United States location

## **About the Role**

We're looking for a Project Manager to own the day-to-day delivery of a large-scale localization program for a multinational gaming publisher. This customer ships localized content across dozens of titles, platforms and languages, and the program spans in-game text, marketing and UA content, cinematics and trailers, and supporting print and digital collateral.

You'll act as a key operational point of contact for the account, coordinating linguists, DTP and video specialists, and internal stakeholders to hit release-critical deadlines. This is a hands-on delivery role for someone who has managed localization programs for a game publisher before and is comfortable owning complex, multi-workstream schedules under tight deadlines.

## **Key Responsibilities**

-

Own end-to-end delivery of localization projects for the account, from initial quoting and scoping through scheduling, resourcing and budget tracking, to final delivery and invoicing, across multiple concurrent titles and languages.

-

Manage transcreation and marketing localization workstreams, ensuring tone, intent and cultural nuance are preserved for user acquisition, marketing and in-game copy.

-

Coordinate subtitling, voiceover (AI and human) and video localization for trailers, cinematics and other video assets, including timing, rendering, editing and final QC of localized video files.

-

Oversee desktop publishing (DTP) workflows for localized packaging, manuals and marketing collateral, working with DTP specialists to maintain layout fidelity across languages.

-

Run thorough linguistic and mechanical/functional QC on every project, tracking issues to resolution and feeding recurring themes back into style guides, glossaries and linguist onboarding.

-

Act as the day-to-day customer contact for delivery matters, managing a smooth workflow from quoting through local market review to completion, surfacing risks early and running status/retrospective calls.

-

Manage high-volume, high-stakes workstreams within the account, building strong customer relationships and driving overall customer satisfaction.

-

Build and maintain project schedules and resourcing plans across Workfront, Google sheets, and JIRA.

-

Manage content intake, review cycles and publishing workflows in coordination with the customer's content and web teams.

-

Use LILT-proprietary AI localization tools and build/maintain customer-specific translation memories and termbases to maintain consistency and leverage across projects.

-

Support vendor management, including onboarding and evaluating linguists and other specialist vendors for the account.

-

Support other project managers on the account, sharing best practice on production workflows and quality standards.

## **What You'll Bring**

-

Proven experience as a project manager in the localization industry, with direct experience delivering programs for a game publisher or games customer.

-

Hands-on experience managing transcreation, subtitling, DTP, video rendering/editing and linguistic/mechanical QC workflows concurrently across multiple languages.

-

Strong working knowledge of AEM, Workfront and Jira (or directly comparable content, work-management and issue-tracking tools).

-

Practical experience with AI localization tools and translation memory / terminology management.

-

Confident user of Google Workspace (Docs, Sheets, Slides) for reporting, tracking and customer-facing documentation.

-

Experience managing high-volume, high-stakes customer accounts, with excellent stakeholder management across internal teams, linguists and customer contacts.

-

Comfort with budget tracking and vendor/linguist management as part of day-to-day delivery.

-

Strong organizational skills and comfort managing multiple concurrent, deadline-driven workstreams.

-

Clear, confident written and verbal communication in English.

## **Nice to Have**

-

Experience with additional localization or workflow platforms beyond those listed above.

-

Familiarity with quality frameworks such as ISO 17100 or ISO 9001.

-

Experience working with global, multi-time-zone teams.

## **What We Offer**

-

The opportunity to work on high-profile, high-visibility programs for a global brand.

-

A remote-first, collaborative team culture spanning EMEA and beyond.

-

Exposure to cutting-edge AI-powered localization technology.

-

**AI is changing how the world communicates — and LILT is leading that transformation.**

LILT's mission is to make the world's information available to everyone, no matter the language they speak. Join our global community who thrive on innovation and excellence. Our collective knowledge, uniqueness, and skills deliver multilingual AI and human-verified services to Enterprises, Governments, and AI Developers around the world.

Earn money. Have fun. Advance human knowledge. Work on diverse projects from anywhere, any time you want. Get paid quickly and fairly, and build your professional network in a supportive community—all through a streamlined application process tailored to your expertise.

*Information collected and processed as part of your application process, including any job applications you choose to submit, is subject to LILT's Privacy Policy at *[*https://lilt.com/legal/privacy*](https://lilt.com/legal/privacy)*.*

*At LILT, we are committed to a fair, inclusive, and transparent hiring process. As part of our recruitment efforts, we may use artificial intelligence (AI) and automated tools to assist in the evaluation of applications, including résumé screening, assessment scoring, and interview analysis. These tools are designed to support human decision-making and help us identify qualified candidates efficiently and objectively. All final hiring decisions are made by people. If you have any concerns, require accommodations, or would like to opt-out of the use of AI in our hiring process, please let us know at ----- style="min-height:1.5em">

*LILT is an equal opportunity employer. We extend equal opportunity to all individuals without regard to an individual’s race, religion, color, national origin, ancestry, sex, sexual orientation, gender identity, age, physical or mental disability, medical condition, genetic characteristics, veteran or marital status, pregnancy, or any other classification protected by applicable local, state or federal laws. We are committed to the principles of fair employment and the elimination of all discriminatory practices.*

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
