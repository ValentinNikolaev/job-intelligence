# Sales Development Representative (SDR) - Virtual Data Rooms: Europe

Posted: 2026-09-02T23:20:10Z

## Rejection

- Category: tech_stack
- Reason: role does not mention Go/Golang or PHP

**Company Description:** Valutico is the world’s leading AI-powered valuation platform, powering hundreds of M&A advisors, private equity funds, and corporate finance teams worldwide. In 2025 we launched DoneDiligence, our AI-native Virtual Data Room, built from scratch for how M&A deals actually run today.

DoneDiligence pairs a secure, scalable VDR with AI built into every room. Buyer questions get answered directly from the documents. New uploads are indexed automatically. Missing or inconsistent items surface before they hit the Q&A queue. Teasers and CIMs are drafted from the source material in a fraction of the manual time.

We are building the next generation of deal execution infrastructure, where valuation, data rooms, and AI-powered analysis come together in one seamless workflow.

**The Opportunity:**

This is not a generalist SDR seat. We are hiring someone who already knows the Virtual Data Room world – who has prospected into deal teams, heard the objections, and understands what a data room actually has to do during a live process. You will be the first touch for DoneDiligence, generating the conversations our Account Executives close.

You will work the Europe M&A market – advisory boutiques and investment banks, private equity and venture capital funds, and corporate development teams across the region.

**Your Responsibilities:**

- You identify and develop new sales opportunities through outbound calls, emails, LinkedIn, and account-based outreach.
- You qualify prospects and book meetings for our Account Executives on Valutico’s Due Diligence Suite – the secure VDR, the AI-powered due diligence assistant, and the integrated valuation and analysis capabilities.
- You research target accounts and live deal activity to identify firms running M&A processes and the people who own the data room decision.
- You engage senior stakeholders across:

- M&A advisory and investment banking
- Private Equity & Venture Capital
- Corporate finance and corporate development teams
- Audit, tax advisory, and consulting firms

- You speak credibly about how data rooms are used in practice – Q&A management, indexing, permissioning, deal timelines – and where an AI-native room changes the work.
- You carefully maintain our CRM database with all relevant lead and prospect information.
- You track your own KPIs and actively contribute to achieving team goals.

**Requirements**

**What you need:**

- 1–2 years of experience prospecting into or selling Virtual Data Rooms, due diligence platforms, or M&A workflow software (Datasite, Ansarada, Intralinks, iDeals, Drooms, FirmRoom, SecureDocs, DealRoom, or similar). This is a must-have, not a nice-to-have.
- A working understanding of how an M&A process runs and where a data room sits within it.
- 1–3 years of overall experience in B2B sales or sales development, ideally in SaaS.
- Existing contacts in the M&A advisory, private equity, investment banking, or corporate development communities are a strong plus.
- Comfort opening conversations with senior stakeholders such as Partners, Directors, Investment Professionals, and Corporate Development teams.
- Fluency in English; additional regional languages are a strong plus.
- Excellent communication and interpersonal skills, with the credibility to hold a conversation in a high-trust, high-stakes environment.
- Strong organisational skills with great attention to detail, and the discipline to keep a CRM clean.
- A proactive mindset – able to work independently in a remote, international setting as well as collaboratively within a team.
- A positive attitude and a strong drive to meet and exceed sales targets.

**Benefits**

**What we offer:**

- A category-expanding product at the intersection of VDR, AI, and financial workflows.
- A strong, experienced sales team you can learn from – with ongoing support, honest feedback, and a real team spirit.
- Structured onboarding and a clear path toward an Account Executive seat for those who earn it.
- A modern, data-driven sales stack with automation-first tooling.
- Clear targets that we consistently hit – in an environment that recognises and rewards performance.
- An international, remote-first work environment with colleagues from around the globe.
- Fair and transparent compensation – a competitive base salary and an above-average, uncapped commission structure.

### **Why This Role Is Different:**

You are not just selling a Virtual Data Room.

You are selling a next-generation deal execution platform that combines:

- Secure data rooms
- AI native due diligence
- Integrated valuation and financial analysis tools

This is an opportunity to move beyond traditional VDR sales and help redefine how deals are executed globally.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
