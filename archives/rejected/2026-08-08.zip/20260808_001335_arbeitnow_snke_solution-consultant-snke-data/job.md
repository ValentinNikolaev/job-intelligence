# Solution Consultant – Snke Data

Posted: 2026-08-07T20:09:32Z

## Rejection

- Category: tech_stack
- Reason: role does not mention Go/Golang or PHP

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
