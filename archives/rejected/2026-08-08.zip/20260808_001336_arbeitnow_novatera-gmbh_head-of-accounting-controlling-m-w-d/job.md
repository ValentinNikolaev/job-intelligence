# Head of Accounting & Controlling (m/w/d)

Posted: 2026-08-07T17:00:32Z

## Rejection

- Category: tech_stack
- Reason: role does not mention Go/Golang or PHP

**Großraum Aalen | Vollzeit | Führungsverantwortung für vier Mitarbeitende**

Zahlen sind für Sie kein Rückspiegel, sondern ein Navigationssystem?

Für ein international tätiges Unternehmen mit rund 150 Mitarbeitenden im Großraum Aalen suchen wir eine erfahrene Führungspersönlichkeit als **Head of Accounting & Controlling (m/w/d)**.

In dieser Schlüsselposition führen Sie ein vierköpfiges Team und berichten direkt an die Geschäftsleitung. Sie stellen nicht nur verlässliche Zahlen und Prozesse sicher, sondern entwickeln die Bereiche Accounting und Controlling aktiv weiter.

Gesucht wird keine reine Zahlenverwaltung. Gesucht wird eine Persönlichkeit, die Zusammenhänge erkennt, Klarheit schafft und aus Zahlen fundierte Handlungsempfehlungen ableitet.

## Aufgaben

Ihre Aufgaben

- Sie übernehmen die fachliche und disziplinarische Führung sowie die Weiterentwicklung des vierköpfigen Teams.

- Sie tragen die Gesamtverantwortung für die Bereiche Accounting und Controlling.

- Sie stellen verlässliche Monats-, Quartals- und Jahresabschlüsse sicher.

- Sie entwickeln das Management-Reporting und die relevanten Kennzahlen kontinuierlich weiter.

- Sie steuern und optimieren die Budgetierungs-, Planungs- und Forecast-Prozesse.

- Sie führen Abweichungs-, Ergebnis- und Wirtschaftlichkeitsanalysen durch.

- Sie leiten konkrete Handlungsempfehlungen für die Geschäftsleitung ab.

- Sie treiben die Digitalisierung und Weiterentwicklung der Finanzprozesse voran.

- Sie sorgen für transparente, effiziente und belastbare Abläufe.

- Sie arbeiten eng mit internen Fachbereichen und relevanten externen Partnern zusammen.

- Sie wirken aktiv an strategischen und unternehmensweiten Projekten mit.

- Sie beraten und unterstützen die Geschäftsleitung kompetent bei kaufmännischen Fragestellungen.

## Qualifikation

Das bringen Sie mit

- Ein abgeschlossenes Studium mit Schwerpunkt Finanzen, Controlling oder Rechnungswesen beziehungsweise eine vergleichbare Qualifikation

- Mehrjährige Berufserfahrung in den Bereichen Accounting und Controlling

- Erfahrung in der Führung und Weiterentwicklung von Mitarbeitenden

- Fundierte Kenntnisse in Bilanzierung, Abschlusserstellung, Planung und Reporting

- Ausgeprägtes analytisches und unternehmerisches Denken

- Hohe Zahlenaffinität, verbunden mit einem klaren Blick für das Gesamtgeschäft

- Sicherer Umgang mit ERP-Systemen, MS Excel und digitalen Finanzprozessen

- Sehr gute Deutsch- und gute Englischkenntnisse

- Eine strukturierte, eigenverantwortliche und lösungsorientierte Arbeitsweise

- Kommunikationsstärke, Verbindlichkeit und ein souveränes Auftreten gegenüber der Geschäftsleitung

- Eine ausgeprägte Hands-on-Mentalität: Sie analysieren nicht nur, sondern setzen auch um.

## Benefits

Das erwartet Sie

- Eine verantwortungsvolle Schlüsselposition mit direkter Berichtslinie zur Geschäftsleitung

- Echter Gestaltungsspielraum bei der Weiterentwicklung von Accounting und Controlling

- Führungsverantwortung für ein eingespieltes, überschaubares Team

- Ein internationales Unternehmensumfeld mit kurzen Kommunikationswegen

- Hohe Sichtbarkeit und unmittelbarer Einfluss auf wichtige Unternehmensentscheidungen

- Eine Aufgabe, bei der Ihre fachliche Kompetenz ebenso zählt wie Ihre Persönlichkeit

- Ein vertraulicher und persönlich begleiteter Auswahlprozess durch Novatera

Ihre Wirkung

Sie halten nicht nur die Zahlen zusammen – Sie sorgen dafür, dass aus ihnen Orientierung, Transparenz und bessere Entscheidungen entstehen.

Interesse?

Dann freuen wir uns auf Ihren Lebenslauf oder zunächst ein kurzes persönliches Profil. Selbstverständlich behandeln wir Ihre Kontaktaufnahme absolut vertraulich.

**Ihr Kontakt:**

Novatera GmbH

Murát Pascal Dursun

CEO

**Better People. Better Growth.**

Wir begrüßen Bewerbungen unabhängig von Geschlecht, Alter, Herkunft, Religion, sexueller Identität oder körperlichen Voraussetzungen. Entscheidend sind Ihre Qualifikation, Ihre Persönlichkeit und Ihr Potenzial.

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
