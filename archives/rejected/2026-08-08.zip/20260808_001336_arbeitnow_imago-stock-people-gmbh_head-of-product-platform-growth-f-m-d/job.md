# Head of Product - Platform Growth (f/m/d)

Posted: 2026-08-07T16:00:25Z

## Rejection

- Category: tech_stack
- Reason: role does not mention Go/Golang or PHP

IMAGO is one of the leading agencies for visual content in Europe, with over 800 million photos and videos used daily by international clients across News Media, Broadcast, Sports, Brands, and Corporate sectors.

For almost 30 years, we’ve built a strong market position in Germany and continue evolving our platform to meet global digital demands. Our international team works closely together from our headquarters in the heart of Berlin.

This is a newly created, CEO-facing role with end-to-end ownership for developing our self-serve webshop into a major business line and, at the same time, establishing a strong product function across IMAGO as the overall Head of Product for our small product team.

## Your tasks

## 1) Build the webshop into a major business line:

- Continuously optimize user acquisition, engagement, and conversion

- Develop product and pricing concepts that increase transactions and reduce friction (in alignment with enterprise sales)

- Build a scalable organic growth engine: technical SEO/AI optimization, information architecture, internal linking, programmatic landing pages

- Drive international expansion: market prioritization, localization strategy, multi-market rollout

- Lead cross-functional execution across Marketing, Engineering, Data/BI and Sales

- Establish a strong product function across IMAGO:

- Own IMAGO’s product vision, strategy, and portfolio prioritization across self-serve growth and enterprise-facing initiatives

- Set up the product operating model (discovery, prioritization, roadmap, rituals, stakeholder alignment, measurement)

- Lead and develop our small product team (PM, Designer + Technical SEO Manager) and ensure high quality in discovery, UX, and decision-making

- Create transparency through KPIs and product performance reporting (e.g., conversion funnel, retention/repeat purchase, cycle time, engagement parameters)

- Act as a key sparring partner for the C-level on strategic bets, trade-offs, and investment decisions

## What we expect

- Senior product leader with experience owning growth for a self-serve digital product/platform (e-commerce, marketplace, large catalog)

- Proven ability to lead and develop a product team and run core product routines (discovery, prioritization, roadmap, measurement)

- Track record in SEO-led growth at scale (technical SEO, IA/internal linking, information architecture, scalable landing pages)

- Analytical and KPI-driven, experience improving conversion funnels (and ideally repeat purchase/retention)

- Strong prioritization and stakeholder management across Engineering, Marketing, Sales, Data/BI

- Business fluent in English and German

## Nice to have

- Very large catalog experience

- Media/licensing industry experience

## What we offer

- A modern workplace in the heart of Berlin

- Public transportation ticket

- Monthly budget to spend in an area of your liking, incl. Health (Urban Sports and others), Learning, Travelling, etc.

- Company pension scheme

- Platform for employee discounts from a wide range of providers

Looking forward to your application. 🙌🏼

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
