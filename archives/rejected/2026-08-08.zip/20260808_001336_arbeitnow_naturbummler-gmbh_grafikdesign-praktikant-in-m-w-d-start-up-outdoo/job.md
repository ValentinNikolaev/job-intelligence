# Grafikdesign Praktikant:in (m/w/d) | Start-Up | Outdoor

Posted: 2026-08-07T16:30:36Z

## Rejection

- Category: language_requirement
- Reason: hard German language requirement without English green light

Wir sind **Naturbummler** – ein junges, wachsendes Start-up aus Mannheim. Als D2C-Brand für **Dachzelte und Outdoor** leben wir die Mission "Adventure Anywhere". Dafür suchen wir Dich als **Praktikant:in im Bereich Design** – mit Lust, eine Marke aktiv mitzugestalten und richtig was zu lernen.

## Aufgaben

- Ein **junges und dynamisches Team**, das Ideen über Hierarchien stellt und mit dem du viele **spannende Projekte** entwickeln und umsetzen kannst!

- Die Chance, **Produkte zu gestalten die von tausenden Kunden genutzt werden:** Etiketten, Sticker, Packagings, Products – von Entwurf bis Druckdatei.

- Zusammenarbeit mit unserem **Marketing-Team**: Egal ob Social Media, Showrooms, Online-Shop oder verschieden Flyer für Events – **du bist mittendrin!**

- Du erlebst hautnah, wie **deine Design-Ideen zur Realität werden**

## Qualifikation

- Du befindest Dich aktuell im Studium und hast ab September 4**-6 Monate** Zeit für ein Praktikum bei uns

- Du studierst im **Bereich Design** und konntest durch Praktikas o.Ä. schon erste Erfahrungen sammeln

- Du liebst haptische Produkte und bist sicher im Umgang mit gängiger Design-Software (Photoshop bspw.)

- Pluspunkt: du hast Erfahrung im Bereich Videoediting & nutzt AI für deine Designs

- Du bist kommunikationsfreudig und bringst exzellente Deutschkenntnisse mit

- **Nice** **to** **have:** Du hast bereits Erfahrung im Bereich AI Design

## Benefits

- Dich erwartet eine lockere und **dynamische Start-Up Atmosphäre** in einem jungen Team

- Du erhältst von Tag 1 an **Eigenverantwortung** und kannst mit einer **steilen Lernkurve** rechnen

- **Team-Events** wie Rafting in Österreich oder Pizza & Wine Tastings im Office

- Im Office stehen für dich kostenlose Getränke und super Kaffee aus der Siebträgermaschine bereit

- **Hybrides Modell:** Wir freuen uns, wenn du ins Office kommst und respektieren es, wenn du auch gerne mal im Homeoffice oder von woanders aus arbeiten möchtest, wir legen Wert auf Flexibilität.

- Du bekommst **Mitarbeiterrabatt** auf alle Naturbummler Produkte oder kannst dir diese **kostenfrei ausliehen**

**Bereit für die Reise?** Dann schick uns deine Bewerbung, erzähl uns, warum du Lust auf ein Praktikum bei Naturbummler hast.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
