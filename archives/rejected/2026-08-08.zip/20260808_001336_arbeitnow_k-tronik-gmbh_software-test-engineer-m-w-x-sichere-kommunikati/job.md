# Software Test Engineer (m/w/x) - Sichere Kommunikation

Posted: 2026-08-07T16:30:37Z

## Rejection

- Category: tech_stack
- Reason: role does not mention Go/Golang or PHP

## Projektbeschreibung:

Technologie begeistert Sie? Uns auch! Zur Verstärkung unseres Expertenteams bei unserem Kunden aus der Funk- und Kommunikationsbranche suchen wir einen Software Test Engineer (m/w/x) - Sichere Kommunikation in Festanstellung bei K-tronik. Wir freuen uns darauf, Sie persönlich kennen zu lernen - und gemeinsam mit Leidenschaft und Teamgeist an spannenden Projekten und zukunftsweisenden Technologien zu arbeiten.

## Aufgaben:

- Du arbeitest in einem agilen und standortübergreifenden Software-Entwicklungsteam an der neusten Generation Software Defined Radios mit

- Dich erwartet die Erstellung und Durchführung von Test cases für den Code unserer Entwicklungsplattformen

- Um unseren Kundenanforderungen gerecht zu werden, testest du den Code gegen die Anforderungen und arbeitest an der Automatisierung von Tests und Test-Pipelines

- Neben der Konzeption und Erstellung von Test Cases ist auch die Dokumentation dieser ein wesentlicher Bestandteil

## Qualifikationen:

- Abgeschlossenes Studium der Informatik/ Elektrotechnik /Nachrichtentechnik /Physik oder vergleichbares

- Fortgeschrittene Kenntnisse in der Embedded Softwareentwicklung mit C/C++, sowie Python und (Embedded) Linux

- Kenntnisse in Testmanagement (Testmethoden, Test-/Integrationsstrategien, Testentwurfsmethoden)

- Kenntnisse in Konfigurationsverwaltungssystemen (z.B. Git)

- Erfahrungen im Bereich Betriebssysteme (insbesondere Netzwerktechnik) und Hardware Kenntnissen (HiL Systeme, Signalanalysen) wünschenswert

- Erfahrung im Safety/Security Umfeld und CMake Kenntnisse wünschenswert

- Sehr gute Deutsch- und Englischkenntnisse

## Benefits:

- Kollegiales und freundschaftliches Arbeitsklima

- Flexible Arbeitszeiten

- 30 Urlaubstage und flexible Urlaubsplanung

- Regelmäßige Team-Events

- Auszeichnung als Kununu TOP Company

- Corporate Benefits (Mitarbeiterangebote)

- Kostenlose Getränke

- Individuelle Weiterbildungsmöglichkeiten

- 360° Betreuung: Feedbackgespräche, Karriereplanung, Unterstützung bei Umzug, etc.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
