# Senior Full Stack Developer

Posted: 2026-08-25T11:55:24Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**About The Role**

At think-cell, we are continuously improving how professionals create business presentations by introducing smarter automation and assistance features into our product. In this role, you will help turn new ideas and early AI-driven concepts into reliable features used by more than 1.3 million users worldwide.

You will build production-ready systems that connect modern backend services with intuitive user interfaces. In this role, you will work closely with both C++ engineers developing the core product and AI engineers exploring new automation capabilities, helping bring new functionality from concept into everyday product usage.

This role is ideal for engineers who enjoy building clean, scalable systems, care deeply about code quality, and are motivated by shipping impactful features in a highly collaborative engineering environment.

**What you will do**

-

Build and maintain production-ready backend and full-stack features using TypeScript

-

Integrate AI-powered functionality into the think-cell product, such as text editing assistance and automated slide creation

-

Work closely with C++ engineers and AI engineers to translate ideas and prototypes into robust product features

-

Contribute to a strong engineering culture with rigorous code reviews and high standards for code quality

**You will be great for this position if you have**

-

A degree in computer science, mathematics, physics, or a similar technical field

-

Relevant experience as a backend or full-stack engineer

-

Strong experience with TypeScript and Node.js in production environments

- Curiosity about AI technologies and interest in integrating them into real-world products

- Experience with Python or C++ is a plus

**
What We Offer**

-

Brilliant Team: Work with international colleagues with strong academic and professional experience

-

Work–life balance: Flexible working hours and an environment that respects your time and focus.

-

Stable Environment: Join a market leader with a reliable product.

- Direct Exposure to C-level

-

Competitive salary & Relocation Support to Berlin

**Why is think-cell the right place for you?** 
At think-cell, we’re not just building innovative software – we’re empowering over 1.3 million business users across 35,000 companies, including the world’s top consulting firms, DAX 40 leaders, and the biggest US blue-chip enterprises. With offices in Berlin, Denver, Boston, London, Tokyo, and Dubai, we are a diverse, passionate team of over 220 people, united by a shared commitment to excellence and innovation. 

Our proprietary technology sets the standard in business document creation, and we're in a dynamic, growing market with enormous potential. As we continue to lead the way in our industry, we’re looking for talented individuals who can help us shape the future of business productivity. 

**Our Values ** 

At think-cell, our values are at the heart of everything we do. They guide how we work, collaborate, and create value for our customers. As part of our team, you will embody and help shape the following principles that define us: 

- Forward Thinking: We are adaptable innovators – we embrace change, value progress, and challenge the status quo to find the best solutions. 

- Ownership: We take pride in our work – we own our mistakes, learn from them, and go the extra mile to deliver exceptional results. 

- Customer First: We are committed to our customers – we understand, prioritize, and deliver lasting value through meaningful solutions. 

- Unified Team: We cultivate collaboration and value every voice – we prioritize integrity and respect, ensuring everyone feels heard, supported, and aligned in our shared mission. 

- Strive for Excellence: We are driven by excellence – we set ambitious goals, pursue quality relentlessly, and foster growth through exceptional talent. 

**Join Our Journey** 
We encourage you to apply even if you feel you don’t meet every single requirement. At think-cell, we celebrate diversity because we know it drives creativity and excellence. We welcome individuals from all backgrounds who are passionate about making a real impact. 

Joining us means more than just a job – it’s an opportunity to be part of an inclusive, innovative, and supportive team that values collaboration and growth. Together, we can push boundaries and achieve great things. 

Let’s shape the future of productivity together. We can’t wait to see what you’ll bring to our team. 

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
