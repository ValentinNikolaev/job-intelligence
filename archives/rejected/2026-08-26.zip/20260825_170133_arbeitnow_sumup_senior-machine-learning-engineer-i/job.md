# Senior Machine Learning Engineer I

Posted: 2026-08-25T11:55:22Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**About the team:**

Within the Global Operations organisation, our mission is to build the best customer experience in the fintech industry by delivering an effortless customer experience to all our merchants. We are seeking a skilled and passionate Senior AI / Machine Learning Engineer to join our talented AI team and lead the development of AI models and algorithms that will drive our customer support service to new heights.

As a Senior AI / Machine Learning Engineer at SumUp, you will be responsible for building and optimizing state-of-the-art AI models and algorithms. Your expertise with machine learning, deep learning, and LLMs will be crucial in driving the success of our AI-driven initiatives. You will work closely with cross-functional teams, including backend engineers, data scientists and product managers, to translate business requirements into innovative AI solutions. Your contributions will shape the future of our support products and help us stay at the forefront of technological advancements in the field of AI.

**What you’ll do**

- Architect, design, develop and deploy our AI solutions and systems in production environments, ensuring reliability, high performance and scalability.

- Collaborate and communicate closely with data scientists, product managers, developers and other business stakeholders to bring state-of-the-art AI solutions to Customer Support, enhancing customer experience and improving operational efficiency.

- Develop and maintain ML infrastructure and pipelines to support efficient data processing, model training and serving.

- Optimize and fine-tune machine learning models to improve accuracy, efficiency and scalability.

- Collect, preprocess and clean large text datasets to ensure high-quality input for model training and evaluation.

- Embrace software development principles, best practices and industry standards, including version control, CI/CD processes and unit testing frameworks as your day-to-day work.

- Collaborate with cross-functional teams to ensure seamless integration of machine learning solutions into software applications and platforms.

**You’ll be great for this position if you have:**

- Bachelor’s degree in Machine Learning, Computer Science or an engineering-related field.

- +8 years of proven experience working as a Machine Learning Engineer, focusing on building and deploying scalable machine learning or AI solutions and data-driven systems.

- Relevant experience building AI products, such as Chatbot Assistant, RAG system, etc.

- Excellent software development engineering skills to design computationally effective solutions and maintenance in large-scale production environments (data version control, model serving, continuous monitoring & alerting)

- Experience building and deploying ML models using cloud services (AWS, GCP, or Azure).

- Expert in Python and familiarity with MLOps tools (e.g., MLflow, Kubeflow, Airflow, Langfuse).

- Experience with machine learning workflow orchestration and algorithms optimisation, feature engineering pipelines, data ingestion and transformation.

- Good understanding of data pipelines, APIs, containers (Docker), and version control (Git).

- Excellent analytical and problem-solving skills, with strong attention to detail.

- You have working proficiency and communication skills in verbal and written English.

**Why you should join SumUp:**

🌍 Opportunity to work with SumUppers globally on large-scale fintech products used by millions of businesses worldwide, from our Berlin office. This involves an office-first setup.

🌈 Commitment to Diversity and Inclusion: Be part of a workplace that values and promotes diversity, fostering an inclusive environment where everyone's perspectives are respected and embraced

📚 A dedicated annual L&D budget of €2,000 for attending conferences and/or advancing your career through further education.

🚀 Enrolment onto our VSOP program: You will own a stake in SumUp’s future success

💶 A corporate pension scheme where we match up to 20% of your contributions

🔄 30 Days Sabbatical: Enjoy the unique opportunity to take a well-deserved break with our 30 days sabbatical benefit after completing 3 years of employment with SumUp.

🔗 Referral Bonus: Earn additional rewards by referring talented individuals to join the SumUp team.

🚵🏾‍♂️ Numerous other benefits such as Urban Sports Club subsidy, Kita placement assistance, relocation assistance, subsidised office lunches.

**About us:**

SumUp is a leading financial technology company, founded in 2012 with the goal of empowering small businesses around the globe. We’re the financial partner of choice for more than 4 million merchants in over 35 markets. We collectively build, plan and fine-tune the technology that drives SumUp and empowers small businesses around the world.

We believe in the everyday hero. Those who have the courage to follow their passion and who have the strength and determination to realise their dreams. Small business owners are at the heart of all we do, so we're creating powerful, easy-to-use financial solutions to help them run their business. With a founders mentality and a 'team-first attitude' our diverse teams across Europe, South America, and the United States work together to ensure that small business owners can be successful doing what they love.

*SumUp is an Equal Employment Opportunity employer that proudly pursues and hires a diverse workforce. SumUp does not make hiring or employment decisions on the basis of race, colour, religion or religious belief, ethnic or national origin, nationality, sex, gender, gender identity, sexual orientation, disability, age or any other basis protected by applicable laws or prohibited by Company policy. SumUp also strives for a healthy and safe workplace and strictly prohibits harassment of any kind.*

**Job Application Tip**

We recognise that candidates feel they need to meet 100% of the job criteria in order to apply for a job. Please note that this is only a guide. If you don’t tick every box, it’s ok too because it means you have room to learn and develop your career at SumUp.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
