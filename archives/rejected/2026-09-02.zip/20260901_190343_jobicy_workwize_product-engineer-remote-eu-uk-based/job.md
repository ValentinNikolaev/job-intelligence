# Product Engineer (Remote EU/UK Based)

Posted: 2026-08-28T18:23:51Z

## Rejection

- Category: tech_stack
- Reason: role does not mention Go/Golang or PHP

At Workwize, we’re helping IT teams to easily equip their remote and global teams with all necessary IT equipment. Our automated SaaS platform simplifies hardware deployment, management, and retrieval with fast, reliable deliveries in 100+ countries.

With 50.000 users and 120.000 devices under management, we’re solving hybrid work challenges like laptop deliveries, returns and equipment tracking, allowing IT teams to focus less on manual hassles and more on strategic initiatives.

Join our team to help shape the future of global collaboration. At Workwize, your work will make a real impact in building smarter, more connected workplaces worldwide.

LinkedIn has also recognized Workwize as one of the Top 10 Startups for 2025 in the Netherlands!

****

**Build real impact. Shape the future of work.**

We're hiring a **product engineer**, a new kind of engineer early in their career. Someone who cares more about what ships than about how many lines they wrote to ship it. You have used AI / AI agents as your default way of working to build and launch things at a pace that surprises people.

You don't need a long CV. You do need to be able to showcase you've actually built and shipped products and features, as well as have experience working alongside a team. If you get a kick out of taking a rough idea to a working version by the end of the week, putting it in front of real users, and then making it better, you'll feel at home here.

**About Workwize**

Workwize is the platform IT teams use to equip and manage remote and global workforces. We deliver, track, and retrieve hardware in over 100 countries, with 50,000 users and 120,000 devices under management today.

We're one of the fastest-growing scale-ups in the Netherlands, a LinkedIn Top 10 Startup (2025) and ranked #6 by Deloitte in the 50 fastest-growing Dutch tech companies. We work from a flat, open environment out of our Amsterdam HQ and across 40+ nationalities worldwide.

**What you'll do**

You'll own product ideas from the first sketch to something customers actually use. Day to day that looks like:

- Turning a problem into a working prototype fast, then hardening the ones that prove their worth into production features.

- Using agents and AI tooling to design, build, test, and ship, and knowing exactly where to trust the output and where to check it yourself.

- Making product calls, not just taking tickets. You'll decide what's worth building, what to cut, and what "good enough to ship" looks like.

- Setting up the evaluation and monitoring that tells you whether what you shipped is actually working once it's live, then iterating.

- Working directly with customers, support, and the rest of the product team to find the highest-leverage thing to build next.

**Who you are**

- You have around 1–2+ years of experience and a solid technical foundation. You understand how software systems fit together, how data flows, and why things break. You don't need to be the strongest raw coder in the room, but you can read, reason about, and debug what you and your agents produce.

- You've actually built and shipped things. Side projects, internships, a first job, hackathon wins, small tools people use. You can point to them and walk us through the choices you made.

- You've worked in a team. You know how to take feedback, review and get reviewed, and move something forward with other people.

- You have real product sense for someone early in their career. You can look at a half-formed request and see the job to be done, and you have taste about what makes something good to use.

- You use AI and agents as your default way of working, and you keep up as the tools change. You treat a model like a fast but unreliable teammate whose work you always check.

- You move fast and take ownership. You'd rather ship something small and learn than plan something big and wait. You're direct, curious, and happy to challenge how things are done. That fits how we work.

**Nice to have**

- A first role or internship at a SaaS or product company.

- Side projects or small products you built mostly on your own and got into people's hands.

- Any hands-on experience running evals, watching inference cost, or dealing with model failure modes like hallucination. If you don't have this yet, we'll teach you.

This is an early-career role. We care far more about what you've built and how you think than about years on paper.

**Workwize** **Offers**

- Flexible hybrid or remote work environment.

- Top-notch tools and equipment provided.

- Vibrant, entrepreneurial culture with opportunities for growth.

- Off-sites and multi-yearly team bonding events.

- Team lunches and surprise events to keep things fun.

- Pension scheme if in the Netherlands.

- Classpass corporate membership.

**Our Team**

Becoming part of Workwize means making an impact. We make sure that we will contribute to the change in the way of working. For us it is also important that we make an impact on our employees, that they feel challenged and ease. We consist of a rapid growing and ambitious team with all different backgrounds. Entrepreneurs, Operational specialists, Developers, Sales gurus you can find them all at Workwize and are always on the look-out for the next original ideas to reach more consumers and create the best value for our customers.

We are looking forward to meeting you and discover if there is a match with the Workwize team!
