# Backend Engineer F/H

Posted: 2026-08-25T12:41:39Z

## Rejection

- Category: stale
- Reason: published_at 2026-08-25T12:41:39Z is older than 7 days

En postulant à cette offre, vous aurez l'opportunité de rejoindre une entreprise innovante dans le secteur de la cybersécurité , proposant un produit collaboratif de gestion des identifiants et des accès open source utilisé par plus de 40 000 organisations dans plus de 50 pays . Ils sont à la recherche d'un Software Engineer H/F pour rejoindre l'équipe Backend . L'objectif sera de répondre aux demandes croissantes de leurs produits, de maintenir des standards de sécurité de premier ordre, et de…
