# Senior IT Project Manager (m/w/d)

Posted: 2026-09-06T23:05:29Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Gestalte IT-Projekte aktiv und übernimm Verantwortung dort, wo deine Entscheidungen Wirkung zeigen. An der Schnittstelle zwischen Business und IT treibst du Lösungen voran, die Prozesse verbessern und Unternehmen nachhaltig stärken. Bringe deine Beratungskompetenz, dein Projekt-Know-how und deine Eigeninitiative ein, um Kund*innen gezielt weiterzuentwickeln und Potenziale sichtbar zu machen.

**Was du bei uns machst**

- Du übernimmst die fachliche und organisatorische Leitung anspruchsvoller IT- und Digitalisierungsprojekte und bringst Kund*innen sicher auf ihrer Cloud Journey voran.

- Du berätst proaktiv in Business Consulting-Fragestellungen und Prozessoptimierungen an der Schnittstelle zwischen Business und IT, identifizierst Potenziale und entwickelst maßgeschneiderte Lösungsansätze.

- Digitalisierung, Collaboration und Cloud-Shift sind für dich nicht nur Schlagworte, sondern du denkst und handelst entlang moderner IT- und Geschäftsprozesse, um echten Mehrwert zu schaffen.

- Du planst, koordinierst und steuerst Projekte agil, klassisch oder hybrid – dabei kannst du je nach Bedarf auch in der Rolle eines (Technical) Product Owners beim Kunden agieren.

- Du bringst fundierte Kenntnisse aktueller IT-Trend-Themen mit, insbesondere zu Cloud-Hyperscalern wie AWS oder Microsoft Azure, und setzt diese gezielt zur Lösung operativer und strategischer Herausforderungen ein.

- Du kommunizierst klar und überzeugend auf allen Ebenen – intern im Team wie auch beim Kunden – und präsentierst Ergebnisse, Roadmaps und Empfehlungen professionell und zielführend.

**Wann du zu uns passt**

- Du hast fundierte Berufserfahrung in der IT-Projektsteuerung bzw. des Business Consultings und hast dementsprechend in mehreren Projekten erfolgreich mitgewirkt.

- In den Methoden des Projektmanagements kennst du dich bestens aus und kannst diese je nach Kundenszenario anwenden.

- Du hast Spaß an der Beratung, wechselnden Kund*innen und Einsatzorten sowie Lust, technologisch und methodisch stets mit der Zeit zu gehen und dich in ein engagiertes Team einzubringen.

- Du besitzt ein Consulting-Mindset, sprich du suchst dir eigenständig Aufgaben bei Kund*innen, stimmst dich aktiv ab, maximierst deine Auslastung und managst diese selbst.

- Die Unterstützung und Begleitung von Veränderungsprozessen bei Kund*innen sind selbstverständliche Bestandteile deines Handelns.

**Hey, wir sind Skaylink.**

**Begleite uns auf unserer Cloud Journey!**

Als Part of Vodafone bringen wir unsere Cloud-DNA und Innovationskraft ein. Gemeinsam treiben wir zentrale Cloud- und Transformationsprojekte voran. Von Cloud-Migrationen über Security-Lösungen bis hin zu Modern-Work-Projekten schaffen wir spürbaren Mehrwert für unsere Kund*innen. Dabei nutzen wir Synergien und bündeln unsere Stärken. So entstehen Lösungen mit nachhaltiger Wirkung und genau das macht uns zu einem der führenden Anbieter im Bereich Cloud-Technologien.

Unser Anspruch ist es, echte Ergebnisse zu schaffen, die messbar Wirkung zeigen und Projekte nachhaltig voranbringen. Wir beraten nicht nur, sondern setzen um. Denn Verantwortung zu übernehmen und Wirkung zu erzielen, gehört für uns zusammen.

Bei uns zählen deine Expertise, deine Leidenschaft und deine Motivation, etwas zu bewegen. Unterschiedliche Hintergründe, Perspektiven und Erfahrungen machen uns stark. Sie schaffen den Raum, in dem du dich einbringen und weiterentwickeln kannst.

Wenn du nicht nur mitlaufen, sondern wirklich etwas bewegen willst, bist du bei uns richtig.

**Was du von uns hast**

🎯 **Purpose** – Deine Expertise einsetzen (in Projekten bei re­nom­mierten Unternehmen wie BMW Group, Henkel oder KWS)

🌍 **Flexibilität** – Deine Balance finden (u. a. Workation, Urlaubsflexibilisierung)

📖 **Entwicklung** – Ankommen und Weiterkommen (u. a. Skaylink Campus, Entwicklungsgespräche, regelmäßige Befragungen der Mitarbeitenden)

🏖️ **Erholung** – Kraft tanken (u. a. 30 Tage Urlaub, 24. + 31.12 frei, Sabbatical)

🚲 **Mobilität** – Von A nach B kommen (u. a. BusinessBike, Zuschuss zum Deutschland-Ticket)

💻 **Ausstattung** – Die Qual der Wahl (Apple/Windows, Firmenhandy)

💪 **Unterstützung** – Fühl dich wohl (u. a. Employee Referral Program, Corporate Benefits, Arbeitsplatzbrille, jährlich 5 bezahlte Kind-krank-Tage)

🏆 **Events** – Zusammenkommen und Feiern (u. a. Sommer- und Weihnachtsfeier, Teamevents, Cross-Company Tech-Talks)

🧩 **Miteinander** – We are Skaylink!

**Du + Skaylink = Perfect Match? **

Dann bewirb dich – auch falls du nicht alle Anforderungen erfüllst! Wir benötigen nur deinen Lebenslauf und sind schon ganz gespannt darauf, von dir zu lesen.

Wir freuen uns auf die gemeinsame (Cloud) Journey mit dir!

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
