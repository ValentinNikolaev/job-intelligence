# Senior Fullstack Engineer (all genders)

Posted: 2026-09-07T02:09:20Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**Your Mission**

reev is building the **Energy Hub** for **EV charging** and **energy management** across Europe - the platform that companies, operators, and drivers use every day to run their charging and energy infrastructure.
We're looking for a Senior Fullstack Engineer to help build and evolve one of the core areas of the reev platform. You'll work across the stack, take ownership of meaningful product areas end-to-end, and help shape how we deliver value to operators and drivers across Europe.

**What You'll Do**
** **
Our stack is Kotlin on the backend, React for the reev hub, React Native for the driver apps, all running on AWS. You'll work across all of it, closely with your PM and designers.

- Design, build, and ship features across backend, web, and mobile that operators and drivers rely on daily.
- Own projects from discovery and technical design through rollout and continuous improvement.
- Make pragmatic technical decisions with customer and business impact in mind.
- Raise the bar on quality, reliability, performance, and security through code reviews, documentation, and knowledge sharing.

**What you bring along**

- 5+ years of professional software engineering experience, with a track record of shipping fullstack products.
- Solid experience across **frontend and backend**. **Kotlin**, **React**, **React Native**, and **AWS** are our stack; equivalent **JVM**, **TypeScript**, and cloud experience is welcome.
- A **product mindset**: you stay close to users, make thoughtful trade-offs, and use feedback to improve what you build.
- Care for engineering quality - testing, observability, maintainability, and the day-to-day experience of the people using your software.
- Comfort using **AI tools daily** to think, prototype, and unblock yourself.
- Clear communication in English. German is a plus, not a requirement.
- Bonus: experience in B2B SaaS, energy, or mobility.

**What you can expect from us**

**How we work**
Clear goals. Real ownership. No politics. We move fast, decide together, and hold each other accountable - because progress beats perfection. Monthly team events and regular cross-office collaboration between Munich and Zagreb keep us connected as one team.

**Where you'll work**
Our office at Stiglmaierplatz is where collaboration happens - in person, direct, eye to eye. For this role, we expect you on-site at least three days per week, because great things happen when you're in the same room.

**What You Get **

- **28 vacation days** - Plus additional days off between Christmas and New Year. Good work starts with proper rest.
- **Mental health**, taken seriously - Free access to the nilo platform with individual sessions from psychologists and business coaches. We want you balanced, not just productive.
- **AI tools - no limits** - Every person and every team at reev uses the AI tools they choose, without budget constraints. We believe in working with the best tools available, and we don't slow that down.
- **Move sustainably** - **JobRad**, subsidised **public transport**, or **EGYM Wellpass**. You choose what fits your life.
- **€1,000 learning budget** - Yours to use. Plus internal development opportunities. Because when you grow, we all grow.
- Your future, sorted - Digital, commission-free **company pension** (bAV) with **DYNO**. Transparent, with a personal dashboard. No fine print.
Benefits may vary slightly by location.

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
