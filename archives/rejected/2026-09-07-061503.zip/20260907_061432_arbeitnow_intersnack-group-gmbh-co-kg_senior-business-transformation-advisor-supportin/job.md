# Senior Business Transformation Advisor - Supporting Functions

Posted: 2026-09-07T02:30:15Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**Why This Role Matters**

As a **Business Transformation Advisor**, you will independently lead sub‑projects within the Transformation Management department. You bring expertise in project management, process optimisation, and functional specifications, with a strong focus on improving Finance and Controlling processes. Your work strengthens governance, transparency, and operational performance across supporting functions.

**Your Role at Intersnack**

-

Manage sub‑projects within broader transformation initiatives

-

Represent Business Transformation in discussions with Management Units, Group Functions, and external partners

-

Develop functional specifications, process improvements, and organisational designs

-

Optimise Finance and Controlling processes (budgeting, forecasting, reporting, cost allocation, internal controls)

-

Translate operational finance requirements into IT and end‑to‑end process solutions

-

Mentor junior colleagues and support their development

-

Act as a key link between Finance/Controlling and Business Transformation

**Education**

-

University degree in Business Administration, STEM, or related fields

-

Focus on Finance, Controlling, Accounting, or Analytics is a plus

**Experience**

-

Several years in business transformation, project management, or consulting

-

Strong Finance/Controlling background, ideally with operational exposure (e.g., month‑end closing, reporting, planning)

-

Experience with finance‑related IT systems (ERP, consolidation, BI)

**Skills**

-

Strong analytical and problem‑solving skills

-

Confident stakeholder engagement

-

Experience in process design and functional specifications

-

Solid understanding of financial processes, KPIs, and internal control frameworks

-

Proficiency with project management tools (e.g., JIRA, SharePoint)

-

Fluency in English; additional languages beneficial

-

Willingness to travel approx. 4 days/week

#### **What We Offer**

-

*A ****rewarding and dynamic role**** within one of Europe’s leading savory snacks producers.*

-

*A ****collaborative and inclusive environment**** that values teamwork, recognizes individuality, and encourages personal and professional growth.*

-

*A ****competitive salary and comprehensive benefits package****, along with opportunities to excel through your professionalism and performance.*

-

*A ****supportive and challenging work environment**** that empowers every team member to reach their full potential.*

-

*A**** caring workplace**** that that ****prioritizes wellbeing and work-life balance****, understanding these are essential for success.*

-

*A culture that ****celebrates diversity****, harnessing its power and potential to drive innovation.*

-

***Extraordinary team spirit****, empowering you to take ownership and encouraging continuous improvement.*

#### **About Intersnack**

*Intersnack is a leading European producer of savory snacks, dedicated to delivering exceptional quality and creating memorable snacking experiences. As a privately held company, we prioritize long-term growth and sustainability, driving innovation while maintaining a strong commitment to environmental and social responsibility.*

*With a robust financial performance—achieving a turnover exceeding €4.5 billion in 2024—we continue to expand our global footprint. Our operations span over 30 countries, supported by 12 regional management units, 45 production facilities, and a diverse workforce of approximately 15,000 employees worldwide.*

* *

#### **Your application**

Please ensure that all application documents are submitted **in English only**.

Kindly note that for **non-EU applicants**, a **valid work and residence permit** is required for this position.

**Are you excited about shaping the future with us? Then apply now - we look forward to getting to know you!**

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
