# Azure Cloud Architect (m/w/d)

Posted: 2026-09-06T23:05:29Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Du möchtest komplexe Azure-Lösungen mit PaaS, IaaS und Containerdiensten entwickeln? Als Cloud-Architect in unserem Team wirst du fortschrittliche Cloud-Lösungen auf Azure entwerfen und entwickeln. Wir setzen auf agile Arbeitsmethoden, DevOps und testgetriebene Entwicklung.

Als technische/r Expert*in verstehst du die Kundenanforderungen und setzt diese ins technische Design um. Dabei stellst du sicher, dass unsere Projekte sichere, skalierbare und zuverlässige Azure-Lösungen liefern.

**Was du bei uns machst**

- Du konzipierst und entwickelst fortschrittliche **Cloud-Lösungen** in **Azure**.

- Durch deine Erfahrung nimmst du maßgeblich Einfluss auf **Brownfield- und Greenfield-Projekte**.

- In unseren Projekten wendest du **DevOps-Prinzipien** und Infrastructure as Code sicher an.

- Regelmäßig berätst du unsere **Kunden** zu passenden Architekturen und Azure-Diensten.

- Du begleitest unsere Projekte von Anfang an: Angefangen in der **Pre-Sales **Phase bis hin zur erfolgreichen **Implementierung**.

**Wann du zu uns passt**

- Du hast mehrjährige Erfahrung im **Architekturdesign** und mit Azure PaaS-/Iaas-/Container-Diensten.

- Du bist in der Lage, **Geschäftsanforderungen** des Kunden in technische Architekturen zu übersetzen.

- Du hast bereits **Kund*innen** zu Azure-Dienste hinsichtlich Funktionalität, Sicherheit, Skalierung und Betriebszeit **beraten**.

- Mit **Azure DevOps**, automatisierten Pipelines und **Infrastructure as Code** bist du bestens vertraut und wirkst proaktiv im Entwicklungsprozess mit.

- Du bist in der Lage, technische Meetings zu leiten und unseren Kunden die Fortschritte verständlich zu präsentieren.

- Du sprichst fließend **Deutsch** und kannst dich auch auf **Englisch** sicher austauschen.

**Hey, wir sind Skaylink.**

**Begleite uns auf unserer Cloud Journey!**

Als Part of Vodafone bringen wir unsere Cloud-DNA und Innovationskraft ein. Gemeinsam treiben wir zentrale Cloud- und Transformationsprojekte voran. Von Cloud-Migrationen über Security-Lösungen bis hin zu Modern-Work-Projekten schaffen wir spürbaren Mehrwert für unsere Kund*innen. Dabei nutzen wir Synergien und bündeln unsere Stärken. So entstehen Lösungen mit nachhaltiger Wirkung und genau das macht uns zu einem der führenden Anbieter im Bereich Cloud-Technologien.

Unser Anspruch ist es, echte Ergebnisse zu schaffen, die messbar Wirkung zeigen und Projekte nachhaltig voranbringen. Wir beraten nicht nur, sondern setzen um. Denn Verantwortung zu übernehmen und Wirkung zu erzielen, gehört für uns zusammen.

Bei uns zählen deine Expertise, deine Leidenschaft und deine Motivation, etwas zu bewegen. Unterschiedliche Hintergründe, Perspektiven und Erfahrungen machen uns stark. Sie schaffen den Raum, in dem du dich einbringen und weiterentwickeln kannst.

Wenn du nicht nur mitlaufen, sondern wirklich etwas bewegen willst, bist du bei uns richtig.

**Was du von uns hast**

🎯 **Purpose** – Deine Expertise einsetzen (in Projekten bei re­nom­mierten Unternehmen wie BMW Group, Henkel oder KWS)

🌍 **Flexibilität** – Deine Balance finden (u. a. Workation, Urlaubsflexibilisierung)

📖 **Entwicklung** – Ankommen und Weiterkommen (u. a. Skaylink Campus, Entwicklungsgespräche, regelmäßige Befragungen der Mitarbeitenden)

🏖️ **Erholung** – Kraft tanken (u. a. 30 Tage Urlaub, 24. + 31.12 frei, Sabbatical)

🚲 **Mobilität** – Von A nach B kommen (u. a. BusinessBike, Zuschuss zum Deutschland-Ticket)

💻 **Ausstattung** – Die Qual der Wahl (Apple/Windows, Firmenhandy)

💪 **Unterstützung** – Fühl dich wohl (u. a. Employee Referral Program, Corporate Benefits, Arbeitsplatzbrille, jährlich 5 bezahlte Kind-krank-Tage)

🏆 **Events** – Zusammenkommen und Feiern (u. a. Sommer- und Weihnachtsfeier, Teamevents, Cross-Company Tech-Talks)

🧩 **Miteinander** – We are Skaylink!

**Du + Skaylink = Perfect Match? **

Dann bewirb dich – auch falls du nicht alle Anforderungen erfüllst! Wir benötigen nur deinen Lebenslauf und sind schon ganz gespannt darauf, von dir zu lesen.

Wir freuen uns auf die gemeinsame (Cloud) Journey mit dir!

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
