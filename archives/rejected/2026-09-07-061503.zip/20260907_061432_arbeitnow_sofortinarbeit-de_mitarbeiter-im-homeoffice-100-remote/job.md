# Mitarbeiter im Homeoffice - 100 % Remote

Posted: 2026-09-06T18:00:23Z

## Rejection

- Category: language_requirement
- Reason: hard German language requirement without English green light

Du bist kommunikativ, suchst eine echte Festeinstellung und möchtest vollflexibel von zu Hause aus arbeiten? Für unseren Auftraggeber suchen wir engagierte Mitarbeiter (m/w/d) in der telefonischen Terminvereinbarung für den Außendienst.

Bei diesem Stellenangebot handelt es sich um eine **direkte Festeinstellung** im Homeoffice. Die komplette technische Hardware (Laptop, Headset etc.) wird dir vom Arbeitgeber kostenfrei zur Verfügung gestellt. Du bringst die Motivation und eine angenehme Telefonstimme mit, um alles Weitere kümmern wir uns!

## Aufgaben

- **Terminvereinbarung:** Telefonische Kontaktaufnahme zu potenziellen Kunden zur Abstimmung von Beratungsterminen für den Außendienst (kein Verkauf)

- **Kalenderführung:** Effiziente Planung und Koordination der Außendienst-Routen in digitale Kalendersysteme

- **Stammdatenpflege:** Sorgfältige Erfassung und Aktualisierung aller Kundeninformationen im CRM-System

- **Schnittstellenarbeit:** Enger Austausch mit dem Außendienstteam zur optimalen Vorbereitung der Termine

## Qualifikation

- **Kommunikationsstärke:** Sehr gute Deutschkenntnisse in Wort und Schrift sowie Freude am Telefonieren

- **Zuverlässigkeit:** Selbstständige und strukturierte Arbeitsweise im Homeoffice

- **Homeoffice-Ausstattung:** Ein ruhiger Arbeitsplatz sowie ein stabiler Internetanschluss (DSL/Kabel) vor Ort

- **Quereinsteiger willkommen:** Erfahrung im Call Center oder Vertrieb ist von Vorteil, aber kein Muss, eine fundierte Einarbeitung ist gewährleistet!

## Benefits

- **Festeinstellung:** Langfristiger Arbeitsvertrag mit fester Vergütung

- **100 % Homeoffice:** Keine Fahrzeiten, keine Pendelkosten, arbeite dauerhaft aus deinen eigenen vier Wänden

- **Technik inklusive:** Vollständige Hardware-Ausstattung (PC/Laptop, Headset) wird dir direkt nach Hause geliefert

- **Strukturierte Einarbeitung:** Intensive, bezahlte Einarbeitungsphase

Nutze deine Chance auf eine sichere Festeinstellung im Homeoffice! Wir begleiten dich kostenfrei durch den gesamten Bewerbungsprozess bis zum Arbeitsvertrag.

Sende uns deine Bewerbung direkt per E-Mail oder melde dich telefonisch bei uns – wir freuen uns darauf, dich kennenzulernen!

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
