# Senior Consultant Endpoint Management (m/w/d)

Posted: 2026-09-06T23:05:29Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Bei uns gestaltest du den digitalen Arbeitsplatz von morgen – mit smartem Endpoint Management, automatisierten Prozessen und einem klaren Fokus auf Effizienz, Sicherheit und Nutzerfreundlichkeit.

Ob Windows, macOS, iOS oder Android – du bringst Struktur ins Gerätemanagement und machst moderne Arbeitsumgebungen wirklich modern.

**Was du bei uns machst **

- Du betreust und optimierst Microsoft Endpoint-Management-Lösungen (Intune, W365, AVD) im Modern Workplace-Umfeld
- Du analysierst die Anforderungen unserer Kund*innen und entwickelst individuelle, plattformübergreifende Lösungskonzepte
- Du führst Rollouts und Migrationen durch und unterstützt aktiv bei der Umsetzung
- Du automatisierst Prozesse im Client Management und entwickelst neue Skripte (PowerShell)
- Du modellierst Geschäftsprozesse zur Effizienzsteigerung und bist Sparringspartner*in für unsere Kund*innen
**Wann du zu uns passt **

- Du bringst Erfahrung im Bereich Windows-Clients, Serverbetriebssystemen und moderner Client Security mit
- Du kennst dich mit Intune, Windows 365, Azure Virtual Desktop , Entra ID und Co. bestens aus
- Du beherrschst PowerShell und hast Spaß an Automatisierung und Paketierung
- Du hast Kenntnisse in der Microsoft Defender Suite und Conditional Access
- Du arbeitest lösungsorientiert, tech-begeistert und auf Augenhöhe mit Kund:innen und Kolleg:innen
- Du nennst sehr gute Deutsch- und Englischkenntnisse in Wort und Schrift dein Eigen.

**Hey, wir sind Skaylink.**

**Begleite uns auf unserer Cloud Journey!**

Als Part of Vodafone bringen wir unsere Cloud-DNA und Innovationskraft ein. Gemeinsam treiben wir zentrale Cloud- und Transformationsprojekte voran. Von Cloud-Migrationen über Security-Lösungen bis hin zu Modern-Work-Projekten schaffen wir spürbaren Mehrwert für unsere Kund*innen. Dabei nutzen wir Synergien und bündeln unsere Stärken. So entstehen Lösungen mit nachhaltiger Wirkung und genau das macht uns zu einem der führenden Anbieter im Bereich Cloud-Technologien.

Unser Anspruch ist es, echte Ergebnisse zu schaffen, die messbar Wirkung zeigen und Projekte nachhaltig voranbringen. Wir beraten nicht nur, sondern setzen um. Denn Verantwortung zu übernehmen und Wirkung zu erzielen, gehört für uns zusammen.

Bei uns zählen deine Expertise, deine Leidenschaft und deine Motivation, etwas zu bewegen. Unterschiedliche Hintergründe, Perspektiven und Erfahrungen machen uns stark. Sie schaffen den Raum, in dem du dich einbringen und weiterentwickeln kannst.

Wenn du nicht nur mitlaufen, sondern wirklich etwas bewegen willst, bist du bei uns richtig.

**Was du von uns hast**

🎯 **Purpose** – Deine Expertise einsetzen (in Projekten bei re­nom­mierten Unternehmen wie BMW Group, Henkel oder KWS)

🌍 **Flexibilität** – Deine Balance finden (u. a. Workation, Urlaubsflexibilisierung)

📖 **Entwicklung** – Ankommen und Weiterkommen (u. a. Skaylink Campus, Entwicklungsgespräche, regelmäßige Befragungen der Mitarbeitenden)

🏖️ **Erholung** – Kraft tanken (u. a. 30 Tage Urlaub, 24. + 31.12 frei, Sabbatical)

🚲 **Mobilität** – Von A nach B kommen (u. a. BusinessBike, Zuschuss zum Deutschland-Ticket)

💻 **Ausstattung** – Die Qual der Wahl (Apple/Windows, Firmenhandy)

💪 **Unterstützung** – Fühl dich wohl (u. a. Employee Referral Program, Corporate Benefits, Arbeitsplatzbrille, jährlich 5 bezahlte Kind-krank-Tage)

🏆 **Events** – Zusammenkommen und Feiern (u. a. Sommer- und Weihnachtsfeier, Teamevents, Cross-Company Tech-Talks)

🧩 **Miteinander** – We are Skaylink!

**Du + Skaylink = Perfect Match? **

Dann bewirb dich – auch falls du nicht alle Anforderungen erfüllst! Wir benötigen nur deinen Lebenslauf und sind schon ganz gespannt darauf, von dir zu lesen.

Wir freuen uns auf die gemeinsame (Cloud) Journey mit dir!

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
