# VFX Artist (f/m/d) Regular / Senior

Posted: 2026-09-06T23:09:12Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**Your role:**

As a VFX Artist you create the visual effects that give our games impact, atmosphere, and life from combat and ability effects to environmental and ambient FX. You will work closely with Art Direction, 3D Artists, Animators, and Designers across multiple projects.

**The kind of stuff you`ll be doing:**

-

Build and maintain VFX directly in Unreal Engine 5 using Niagara.

-

Create and implement particle effects and VFX for combat, abilities, environments, and UI feedback.

-

Build and maintain VFX directly in Unreal Engine 5 using Niagara.

-

Implement destruction, fluid, and other physics-based simulations where needed.

-

Develop procedural VFX solutions to speed up iteration and improve consistency.

-

Create and tune post-process effects (bloom, distortion, screen-space effects, etc.) where relevant to a project's look.

-

Integrate VFX with gameplay logic using Blueprints (with Programming support for C++ where needed) to trigger, time, and expose parameters for effects at runtime.

-

Collaborate closely with Designers and Animators to time effects to gameplay, animations, and camera work.

-

Translate briefs and art direction into effects that fit the visual style and tone of each project.

-

Contribute to style guides and reference boards for effects across a project.

-

Take and act on feedback throughout iterative review cycles.

-

Help define and improve VFX workflows and pipelines.

-

Work on multiple game titles across different platforms simultaneously.

-

Implement destruction, fluid, and other physics-based simulations where needed.

-

Develop procedural VFX solutions to speed up iteration and improve consistency.

-

Create and tune post-process effects (bloom, distortion, screen-space effects, etc.) where relevant to a project's look.

-

Create supporting textures and materials/shaders for VFX use.

-

Integrate VFX with gameplay logic using Blueprints (with Programming support for C++ where needed) to trigger, time, and expose parameters for effects at runtime.

-

Collaborate closely with Designers and Animators to time effects to gameplay, animations, and camera work.

-

Translate briefs and art direction into effects that fit the visual style and tone of each project.

-

Contribute to style guides and reference boards for effects across a project.

-

Take and act on feedback throughout iterative review cycles.

-

Help define and improve VFX workflows and pipelines.

-

Work on multiple game titles across different platforms simultaneously.

**The ideal candidate also has:**

-

Experience with procedural/simulation tools such as Houdini or Embergen.

-

Background in traditional art fundamentals (color, motion, timing).

-

Interest in bridging the gap between Art and Technical Art.

-

Motivation to learn German.

**You have:**

-

A strong portfolio demonstrating particle and VFX work for real-time games.

-

Solid understanding of particle systems, timing, color, and motion as tools for visual storytelling.

-

Experience creating and implementing VFX directly in Unreal Engine 5 (Niagara).

-

Good knowledge of shaders and materials as they relate to VFX, including building effects using Unreal's Material Editor / Shader Graph.

-

Very good understanding of performance considerations and optimization for real-time VFX (e.g. draw calls, overdraw, texture and LOD budgets), including familiarity with in-engine profiling tools.

-

Experience with procedural VFX and simulation workflows, including destruction and fluid effects.

-

Proficiency with industry-standard 2D/3D tools such as Photoshop, Affinity Photo, or Blender for supporting textures and assets.

-

An eye for detail and consistency across a range of visual styles, from stylized to realistic.

-

Experience integrating VFX with gameplay via Blueprints, triggering, timing, and exposing parameters for designers to tune.

-

Understanding of vector math and core art fundamentals (lighting, composition, color theory) as they apply to real-time VFX.

-

Experience creating supporting 3D models for VFX-related assets (e.g. debris, projectiles, impact geometry).

**You are:**

-

Self-motivated, self-directed, reliable, and take initiative.

-

A collaborative team player who enjoys solving problems together.

-

Able to gather, analyze, and act on feedback from the team, with openness to critique.

-

Eager to learn and research new tools, styles, and techniques.

-

Confident with English communication, both verbally and in writing.

-

Happy to work with our team in Munich (Germany).

**What we offer:**

- A welcoming and vibrant office
- Flexible remote work options tailored to your needs
- A 38-hour work week that promotes a healthy work-life balance
- Monthly €50 credit card top-up*
- Public transport ticket covered by Aesir
- Lunch subsidy of €7.50 for each day you work, whether on site or remotely*
- Free drinks, coffee, tea, and a weekly fresh organic fruit basket
- Table tennis and foosball for creative breaks
- Fun company events :)

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
