# Forward Deployed Engineer

Posted: 2026-09-06T17:20:03Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

We are building the world's decision infrastructure: the strategic twin of every industrial organization. Our customers map reality, with its levers and constraints, into a model, and we run large-scale combinatorial optimization over the critical decisions in their value chain. We help Europe stay strong and the German Mittelstand make good decisions between market shifts, orders, machines and people.

Founded by Dana (CEO) and Erik (CTO) from RWTH research, backed by a €2.8M round led by Vorwerk Ventures, with customers live on our optimization models.

**Your mission**

Hi, I'm Erik, CTO of Circonomit. This ad is specific on purpose: you should be able to tell from it whether this is your job.

Most optimization software fails in the same place. Not in the solver, but in the gap between what a company actually does and what the model assumes. Somebody has to sit with the people who plan today, understand how they really decide, and turn that into something a machine can compute.

That is this role, and you do it hands on. You take the customer's planning problem apart, you build the model yourself, in code, on their data, and you stay with it until their management trusts the result enough to act on it. Then you bring back the part that should stop being project work and become product.

Most of this happens at your desk in Cologne, with days at the customer's site when the decisive conversations happen. You are the shortest path between our product and reality. What does not survive at a customer does not work.

We will not sugarcoat it: the data arrives messy, the first model is rarely the right one, and some weeks a customer deadline sets the priority.

**What you'll own**

- **The customer's decision problem.** Sit with the people who plan today, understand capacities, costs, lead times and the constraints nobody wrote down, and turn it into a model whose answer a plant manager acts on. Inventory, scheduling, supply shortages, order prioritization: the decisions that determine whether a plant stays competitive.
- **The customer's model, end to end.** You own it from the first conversation to the version that runs in production. Our math and OR team owns the engine and the solver core underneath; you own what is built on top of it for this customer.
- **The data it runs on.** ERP and Excel exports, inconsistent and incomplete. You get them into shape yourself and notice when numbers cannot be right before the customer does.
- **The result, all the way to trust.** Not a demo. A model that is used, questioned, corrected and used again.
- **The feedback loop into the product.** You see the same problem at the second and third customer before anyone else does. You make the call at the customer, and you argue the case for what belongs in the platform.
- **Your work, from the first line of code to a model the customer runs.** Nobody hands you a ticket and waits.

**How we work**

Small team, short lines of communication, no layers. You own your work end to end: you build it, you ship it to production yourself, you run it.

Feedback runs both ways and continuously, in weekly one-on-ones. We talk as equals, communicate proactively, and flag early when something isn't working out. Saying no is part of the job.

We review each other's work, and we like being together in the Cologne office, because the fastest conversations still happen in a room.

**Requirements**

- You have built quantitative models for real operations problems and taken them into production, not into a slide deck. Optimization, simulation, or a combination of both.
- **You have done this more than once, end to end, and at least one of those models still runs without you in the room.**
- **You still write the production code yourself, today.**
- Before you build anything, you can name the few assumptions and constraints that will decide the result, and you clear them with the customer first. Customers know their goal, they rarely know which constraint binds.
- You are comfortable in front of a plant manager or a controller, and you can leave that room knowing what the model has to do. You explain what the model does to people who will never read the code, and to people who will.
- You work with messy industrial data as a matter of course. Cleaning it is part of the problem, not beneath the job.
- Python at production quality.
- You have worked inside a team with shared standards, not only on your own projects.
- German and English, both at a level where you can run a customer meeting and write a specification. Team life runs in German; code and docs are English.
- NRW-based (Cologne office). Our customers sit across the DACH region and the decisive conversations happen on site, even though most of the work with them is online. Expect travel, not every week, but on a regular basis.

Nice to have: operations research background · optimization tooling such as Gurobi, OR-Tools or Pyomo · production planning, supply chain, inventory or logistics domain knowledge · experience in a consulting or forward deployed setting · early-stage startup experience.

This role is not for you if you want to hand over after the concept, if you would rather advise than be accountable for whether the thing works, if a plant floor is an obstacle rather than the interesting part, or if you are waiting for the next task to be handed to you.

**Benefits**

- **Impact.** You see your results in the real world, fast, and customers measure in euros what your work changed. They tell you, directly.
- **Ownership.** No layers between you and production, no approval chain that turns your decision into someone else's.
- **The people next to you.** The math and OR team on the engine, the CTO on the platform, and the founders on where this goes.
- **Shaping.** You make the call at the customer, and you argue the case for what becomes product. That argument is one of the most consequential in the company right now.
- **Feedback speed.** You will know where you stand. We say things out loud, we adjust, and we expect the same from you.
- **Compensation.** Competitive salary and relevant room in the equity package (VSOP) to match your contribution and your career development.
- **The basics.** Hardware of your choice · AI tooling budget · sports membership · Deutschland-Ticket.

**Process:** a 20-minute first call; a technical conversation with two of us; a hands-on challenge of about three hours on a real planning problem with messy data, followed by a 45-minute walkthrough where you explain your solution and the decisions behind it; then the team, online and then in person. Both sides decide. Two to three weeks end to end, and you hear back within days after each step. Before you decide, ask us to put you on a call with someone who will tell you the good, the bad and the ugly.

**To apply:** skip the cover letter. Tell us about a system you built for one specific customer, and what you would have had to change to make it work for the next one.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
