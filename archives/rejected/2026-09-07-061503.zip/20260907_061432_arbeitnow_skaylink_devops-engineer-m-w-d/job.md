# DevOps Engineer (m/w/d)

Posted: 2026-09-06T23:05:29Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Als **DevOps Engineer (m/w/d)** verantwortest du die Architektur, Automatisierung und kontinuierliche Verbesserung unserer AWS-Umgebungen und entwickelst skalierbare Lösungen, die echten Business Impact erzeugen.

**Was du bei uns machst **

- Du entwirfst und implementierst **skalierbare, sichere und hochverfügbare Plattformarchitekturen auf AWS** und anderen Cloud Providern und definierst Standards, Referenzarchitekturen und Best Practices.

- Du entwickelst und betreibst **Plattform-Services wie Networking, IAM, Compute, Storage, Container und Serverless.**

- Du treibst** Automatisierung** konsequent voran und entwickelst **Infrastructure-as-Code-Lösungen** (Terraform, CloudFormation, CDK) sowie **Self-Service-Frameworks.**

- Du gestaltest und optimierst **CI/CD-Pipelines, integrierst Security-, Compliance- und Quality-Checks** und implementierst moderne Deployment-Strategien (Blue/Green, Canary, Rolling).

- Du entwickelst zentrale Automatisierungs-Tools und Plattformkomponenten in **Python, erstellst APIs, CLI-Tools und wiederverwendbare Bibliotheken und nutzt AWS SDKs (boto3)** effizient.

- Du stellst die **Zuverlässigkeit, Skalierbarkeit und Performance der Plattform** sicher und implementierst Monitoring, Observability sowie automatisierte Incident- und Recovery-Prozesse.

**Wann du zu uns passt **

- Du bringst mehrjährige Erfahrung in der **Architektur, Entwicklung und Optimierung von AWS-Plattformen** mit.

- Du hast fundiertes Wissen in **Infrastructure as Code, Automatisierung und DevOps-Praktiken.**

- Du bist sicher im **Aufbau und Betrieb von Plattform-Services** sowie CI/CD-Pipelines und Deployment-Strategien.

- Du verfügst über **gute Programmierkenntnisse in Python** und Erfahrung mit AWS SDKs, APIs und Automatisierungsframeworks.

- Du verstehst **Monitoring, Observability und Cloud Operations** als integrale Bestandteile einer stabilen Plattform.

- Idealerweise hast du Erfahrung mit **Container-Technologien, Serverless-Architekturen** und relevanten AWS-Zertifizierungen (z. B. AWS Solutions Architect Professional).

- Sehr gute **Deutsch- und Englischkenntnisse** in Wort und Schrift.

**Hey, wir sind Skaylink.**

**Begleite uns auf unserer Cloud Journey!**

Als Part of Vodafone bringen wir unsere Cloud-DNA und Innovationskraft ein. Gemeinsam treiben wir zentrale Cloud- und Transformationsprojekte voran. Von Cloud-Migrationen über Security-Lösungen bis hin zu Modern-Work-Projekten schaffen wir spürbaren Mehrwert für unsere Kund*innen. Dabei nutzen wir Synergien und bündeln unsere Stärken. So entstehen Lösungen mit nachhaltiger Wirkung und genau das macht uns zu einem der führenden Anbieter im Bereich Cloud-Technologien.

Unser Anspruch ist es, echte Ergebnisse zu schaffen, die messbar Wirkung zeigen und Projekte nachhaltig voranbringen. Wir beraten nicht nur, sondern setzen um. Denn Verantwortung zu übernehmen und Wirkung zu erzielen, gehört für uns zusammen.

Bei uns zählen deine Expertise, deine Leidenschaft und deine Motivation, etwas zu bewegen. Unterschiedliche Hintergründe, Perspektiven und Erfahrungen machen uns stark. Sie schaffen den Raum, in dem du dich einbringen und weiterentwickeln kannst.

Wenn du nicht nur mitlaufen, sondern wirklich etwas bewegen willst, bist du bei uns richtig.

**Was du von uns hast**

🎯 **Purpose** – Deine Expertise einsetzen (in Projekten bei re­nom­mierten Unternehmen wie BMW Group, Henkel oder KWS)

🌍 **Flexibilität** – Deine Balance finden (u. a. Workation, Urlaubsflexibilisierung)

📖 **Entwicklung** – Ankommen und Weiterkommen (u. a. Skaylink Campus, Entwicklungsgespräche, regelmäßige Befragungen der Mitarbeitenden)

🏖️ **Erholung** – Kraft tanken (u. a. 30 Tage Urlaub, 24. + 31.12 frei, Sabbatical)

🚲 **Mobilität** – Von A nach B kommen (u. a. BusinessBike, Zuschuss zum Deutschland-Ticket)

💻 **Ausstattung** – Die Qual der Wahl (Apple/Windows, Firmenhandy)

💪 **Unterstützung** – Fühl dich wohl (u. a. Employee Referral Program, Corporate Benefits, Arbeitsplatzbrille, jährlich 5 bezahlte Kind-krank-Tage)

🏆 **Events** – Zusammenkommen und Feiern (u. a. Sommer- und Weihnachtsfeier, Teamevents, Cross-Company Tech-Talks)

🧩 **Miteinander** – We are Skaylink!

**Du + Skaylink = Perfect Match? **

Dann bewirb dich – auch falls du nicht alle Anforderungen erfüllst! Wir benötigen nur deinen Lebenslauf und sind schon ganz gespannt darauf, von dir zu lesen.

Wir freuen uns auf die gemeinsame (Cloud) Journey mit dir!

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
