# Senior Security Consultant (m/w/d)

Posted: 2026-09-06T23:05:29Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Bereit, die Zukunft der Sicherheit zu gestalten? Bei Skaylink konzipierst, berätst und implementierst du eigenständig Microsoft Security-Lösungen. Als vertrauensvolle*r Ansprechpartner*in begleitest du komplexe Kundenprojekte von Anfang bis Ende. Dabei definierst du fortlaufend Best Practices und Standards für unser Security-Team. Durch engen Austausch mit Microsoft und aktive Mitgestaltung unseres Security-Portfolios trägst du maßgeblich zur Weiterentwicklung bei. Unterstütze uns dabei, unser Wissen zu teilen und werde Teil eines dynamischen Teams!

**Was du bei uns machst**

- Du konzeptionierst, berätst und setzt Microsoft Security-Lösungen eigenständig um.

- Du begleitest komplexe Kundenprojekte als vertrauensvoller Ansprechpartner über alle Projektphasen hinweg.

- Du definierst fortlaufend Best Practices und Skaylink-Standards in unserem Security-Team.

- Du pflegst einen engen Austausch mit Microsoft zu technischen Themen, Workshop-Formaten und unserer Partnerschaft.

- Du gestaltest aktiv das Security-Portfolio bei Skaylink mit.

- Du gibst unseren juniorigen Kolleg*innen stetig dein Wissen weiter.

**Wann du zu uns passt**

- Du verfügst nachweislich über mehrjährige Berufserfahrung im IT-Security-Umfeld.

- Durch deine bisherige Laufbahn bist du im Besitz vertiefter Erfahrung in mindestens einer der Security-Säulen aus dem Microsoft Portfolio: Identity & Access Protection, Threat Protection, Information Protection, Endpoint Security oder Security Monitoring.

- Du besitzt grundlegende Kenntnisse in Microsoft-Infrastrukturen (z.B.: Windows Server, Active Directory, Entra ID & Hybrid Identity).

- Du brennst für IT-Security-Themen.

- Du nennst sehr gute Deutsch- und Englischkenntnisse in Wort und Schrift dein Eigen.

**Hey, wir sind Skaylink.**

**Begleite uns auf unserer Cloud Journey!**

Als Part of Vodafone bringen wir unsere Cloud-DNA und Innovationskraft ein. Gemeinsam treiben wir zentrale Cloud- und Transformationsprojekte voran. Von Cloud-Migrationen über Security-Lösungen bis hin zu Modern-Work-Projekten schaffen wir spürbaren Mehrwert für unsere Kund*innen. Dabei nutzen wir Synergien und bündeln unsere Stärken. So entstehen Lösungen mit nachhaltiger Wirkung und genau das macht uns zu einem der führenden Anbieter im Bereich Cloud-Technologien.

Unser Anspruch ist es, echte Ergebnisse zu schaffen, die messbar Wirkung zeigen und Projekte nachhaltig voranbringen. Wir beraten nicht nur, sondern setzen um. Denn Verantwortung zu übernehmen und Wirkung zu erzielen, gehört für uns zusammen.

Bei uns zählen deine Expertise, deine Leidenschaft und deine Motivation, etwas zu bewegen. Unterschiedliche Hintergründe, Perspektiven und Erfahrungen machen uns stark. Sie schaffen den Raum, in dem du dich einbringen und weiterentwickeln kannst.

Wenn du nicht nur mitlaufen, sondern wirklich etwas bewegen willst, bist du bei uns richtig.

**Was du von uns hast**

🎯 **Purpose** – Deine Expertise einsetzen (in Projekten bei re­nom­mierten Unternehmen wie BMW Group, Henkel oder KWS)

🌍 **Flexibilität** – Deine Balance finden (u. a. Workation, Urlaubsflexibilisierung)

📖 **Entwicklung** – Ankommen und Weiterkommen (u. a. Skaylink Campus, Entwicklungsgespräche, regelmäßige Befragungen der Mitarbeitenden)

🏖️ **Erholung** – Kraft tanken (u. a. 30 Tage Urlaub, 24. + 31.12 frei, Sabbatical)

🚲 **Mobilität** – Von A nach B kommen (u. a. BusinessBike, Zuschuss zum Deutschland-Ticket)

💻 **Ausstattung** – Die Qual der Wahl (Apple/Windows, Firmenhandy)

💪 **Unterstützung** – Fühl dich wohl (u. a. Employee Referral Program, Corporate Benefits, Arbeitsplatzbrille, jährlich 5 bezahlte Kind-krank-Tage)

🏆 **Events** – Zusammenkommen und Feiern (u. a. Sommer- und Weihnachtsfeier, Teamevents, Cross-Company Tech-Talks)

🧩 **Miteinander** – We are Skaylink!

**Du + Skaylink = Perfect Match? **

Dann bewirb dich – auch falls du nicht alle Anforderungen erfüllst! Wir benötigen nur deinen Lebenslauf und sind schon ganz gespannt darauf, von dir zu lesen.

Wir freuen uns auf die gemeinsame (Cloud) Journey mit dir!

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
