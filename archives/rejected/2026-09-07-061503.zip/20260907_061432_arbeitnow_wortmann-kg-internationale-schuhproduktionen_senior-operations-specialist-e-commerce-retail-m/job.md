# (Senior) Operations Specialist E-Commerce & Retail (m/w/d)

Posted: 2026-09-07T02:30:20Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Mode ist unsere Leidenschaft - und das bereits seit über 55 Jahren. Saison für Saison entwickeln wir als familiengeführte Unternehmensgruppe erfolgreiche Kollektionen, die inzwischen in über 70 Ländern und 15.000 Schuhgeschäften zu finden sind. Unsere Maxime lautet: Immer ein bisschen mehr tun als der Wettbewerb, Dinge ausprobieren, ausgetretene Pfade vermeiden und die Bodenhaftung nicht verlieren. Dass dieses Konzept aufgeht, spiegelt unsere Erfolgsgeschichte wider. Werden Sie Teil dieses Erfolgs und bewerben Sie sich beim europäischen Marktführer der Branche.

Für unsere Marke Tamaris suchen wir im Bereich Operations zum nächstmöglichen Zeitpunkt Sie als **(Senior) Operations Specialist E-Commerce & Retail (m/w/d).**

**Was Sie bei uns bewegen:**

-

Zentrale Schnittstelle zwischen E‑Commerce, Retail, Logistik, IT und externen Partnern, um kundenorientierte und effiziente End‑to‑End‑Prozesse sicherzustellen

-

Operative Betreuung und Koordination der Fulfillment‑, Lager‑ und Transportprozesse mit externen Dienstleistern für [tamaris.com](http://tamaris.com) in Europa

-

Eigenverantwortliche Initiierung, Planung und Umsetzung von (Teil‑)Projekten im E‑Commerce‑, Retail‑ und Omnichannel‑Umfeld – von der Anforderungserhebung über Konzept und Testing bis zum Roll‑out – einschließlich Identifikation von Optimierungspotenzialen, Einbringung eigener Ideen sowie Begleitung bis zur Bewertung der Ergebnisse

-

Identifikation von Potenzialen zur Prozessautomatisierung und Effizienzsteigerung – auch durch den Einsatz moderner Tools und KI‑basierter Auswertungen

-

Mitarbeit bei der Übersetzung der E‑Commerce‑ und Retail‑Wachstumsstrategie in konkrete Projekte, Roadmaps und Prozessverbesserungen

-

Operative Analyse und Mitgestaltung der internen und externen logistischen/operativen KPI‘s: Identifikation von Handlungsfeldern/Maßnahmen, enge Zusammenarbeit mit weiteren Fachbereichen (Sales, Merchandising, Customer Service & Experience), Unterstützung bei der Initiierung und Durchführung von Maßnahmen zur Steigerung der KPIs

-

Erstellung von Management‑Reports und Entscheidungsvorlagen

**Was uns ausmacht:**

-

Ein modernes Arbeitsumfeld mit Gestaltungsspielraum, flachen Hierarchien und einer familiären Unternehmenskultur

-

Alles, was Sie zum Arbeiten benötigen: Klimatisierte Büros, kostenlose Parkplätze sowie eine moderne Arbeitsplatzumgebung

-

Ein Arbeitstag, wie für Sie gemacht: Dank unserer flexiblen Arbeitszeitmodelle und der Möglichkeit des mobilen Arbeitens können Sie Ihr Berufsleben optimal an ihr Privatleben anpassen

-

Mit uns profitieren Sie von Sonderkonditionen und Angeboten bei verschiedensten Vertragspartnern über das Portal corporate Benefits.

-

Durch einen Mitarbeiterrabatt in unserem Fabrikverkauf sowie im Tamaris Onlineshop füllt sich der Schuhschrank wie von alleine

-

Niemand tritt gerne auf der Stelle: Durch Schulungen und Seminare fördern wir Ihre persönliche und fachliche Weiterbildung, denn Ihr Karriereweg ist keine Einbahnstraße

-

Fit und entspannt im Alltag: Durch verschiedene kostenlose Betriebssportgruppen, eine Kooperation mit lokalen Fitnessstudios sowie mit dem Anbieter [sportnavi.de](http://sportnavi.de)

-

Wir feiern Erfolg und Gemeinschaft: Arbeitgeberfinanzierte Team-Events und Firmenfeiern sind ein fester Bestandteil unserer Unternehmenskultur

**Was Sie ausmacht:**

-

Erfolgreich abgeschlossene kaufmännische Ausbildung oder abgeschlossenes betriebswirtschaftliches (Fach)Hochschulstudium

-

Berufserfahrung im E‑Commerce‑ oder Retail‑Umfeld, gerne im Bereich Fashion- oder Schuhhandel, idealerweise mit Logistik‑/Fulfillment‑Bezug

-

Erfahrung in der Mitarbeit an Projekten (Anforderungsaufnahme, Test, Roll‑out), gerne mit erster Teilprojekt‑Verantwortung

-

Kenntnisse in BI‑/Reporting‑Tools (z. B. Forecasts, Anomalie‑Erkennung, automatisierte Reports) und modernen Analyse‑/Automatisierungsansätzen von Vorteil

-

Eigenverantwortliche, strukturierte Arbeitsweise gepaart mit einer ausgeprägten Hands-On-Mentalität sowie Ziel- und Ergebnisorientiertheit

-

Analytisches Denkvermögen sowie Freude an der Gestaltung von Prozessen und deren Optimierung

-

Ausgeprägte Kommunikationsfähigkeit sowie verhandlungssichere Englischkenntnisse

-

Offenheit für Veränderungen, Spaß an kontinuierlicher Verbesserung und am Einsatz neuer Tools und Technologien

Sie sind ein verantwortungsbewusster und äußerst engagierter Teamplayer und schätzen die konstruktive Zusammenarbeit? Dann freuen wir uns auf Ihre aussagefähigen Bewerbungsunterlagen.

**IHR KONTAKT
Birthe Lömker**

HR Manager

Wortmann KG
Internationale Schuhproduktionen
Personalmanagement
Klingenbergstraße 1-3
32758 Detmold

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
