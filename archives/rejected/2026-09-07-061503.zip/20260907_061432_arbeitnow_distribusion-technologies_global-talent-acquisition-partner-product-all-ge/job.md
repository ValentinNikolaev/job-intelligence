# Global Talent Acquisition Partner, Product (all genders)

Posted: 2026-09-06T23:30:31Z

## Rejection

- Category: tech_stack
- Reason: role does not mention Go/Golang or PHP

**About us **

**Distribusion** is the world’s leading ground transportation marketplace and gives travellers seamless access to ground transportation online, from search to ticket purchase. We have built a cutting-edge B2B technology platform that connects bus, rail, and ferry operators in 70+ countries with the biggest online retailers, including Google Maps and [Booking.com](http://Booking.com).

We are shaping the future of travel and building the largest global network of transport providers and retailers. We are one of the fastest-growing startups in travel, backed by leading venture capital investors including TQ Ventures, Lightrock, Creandum, and Northzone,﻿ and are headquartered in Berlin, Germany. Following our recent $80m Series C funding, we are ready to push beyond.

**The opportunity**

We are seeking a** Talent Acquisition Partner**: an individual who is passionate about enabling a product-led organisation by engaging and hiring talented members across all different Business areas.

**What you will do:**

-

Own hiring end-to-end, from intake through offer, across Product, Tech, and Business, with **Product** as your primary area of depth.

-

Work as a peer to hiring managers and **Product leadership:** run intakes that sharpen unclear requirements, push back when a profile isn't hireable, calibrate on candidates, and hold the process to a standard when timelines get tight.

-

Develop sourcing strategies for talent that rarely applies passive outreach, Boolean, referrals, networking, and **competitive intelligence across travel tech, marketplaces, and B2B SaaS.**

-

**Maintain pipelines for critical and recurring roles,** so we're not starting from zero each time a req opens.

-

Coach hiring managers on interviewing and keep our assessment consistent as teams grow.

-

Use hiring data, funnel conversion, time-to-hire, and source effectiveness to change how we hire, not just to report on it.

-

Keep the ATS accurate and support employer branding in the communities we hire from.

**Who you are:**

-

5+ years in talent acquisition, in-house, with demonstrable full-cycle ownership: you've sourced, assessed, negotiated, and closed senior hires yourself.

-

Strong Product hiring track record. You can hold a credible conversation about discovery, roadmaps, and metrics, and judge whether a candidate's story about impact holds up.

-

Breadth across Tech and Business hiring alongside that depth.

-

Strong stakeholder management with senior hiring managers. You can redirect a stalled search, challenge a hiring manager, and deliver difficult market news without damaging the relationship.

-

A proven pipeline of both active and passive candidates, with rapport built throughout and offers closed at the end.

-

Data fluency: you can build a funnel view and use it to make an argument.

-

You have a curious mindset, always testing and adapting your search approach, driven by finding the right talent — and open to 360-degree feedback as a way to keep growing.

-

Comfortable in a fast-moving, global, diverse start-up environment, and open to feedback.

-

You have a curious mindset and an interest in research; open to 360-degree feedback and looking to grow.

-

Tools affinity, keeping our ATS updated, and data accurate.

-

You are fluent in English, both verbal and written.

**What you can expect:**

-

**Make a global impact.** Help shape how millions of people discover and book ground transportation worldwide.

-

**Own your work.** Take responsibility from day one and see the direct impact of your contributions.

-

**Build with the best tools.** We move fast, continuously evolve our tech stack, and invest in modern, efficient solutions.

-

**Work with industry leaders.** Our partners include [Booking.com](http://Booking.com), Google Maps, Amtrak, Deutsche Bahn, Renfe, and SNCF.

-

**Grow with exceptional people.** Join an international team that will challenge, support, and inspire you every day.

-

**Work your way.** Enjoy flexible and remote-friendly working options, relocation opportunities, and plenty of room to grow.

**Our hiring process for this role:**

Your Talent Partner (TP) and point of contact is **Nayab Fatima,** and the Hiring Manager (HM) is **Masha Marynova**.

For any queries, please reach out to your Talent Partner at (

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
