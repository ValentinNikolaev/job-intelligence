# Principal AI/ML Scientist & Engineer

Posted: 2026-08-19T11:05:26Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

We believe it takes great people to create a great product. That’s why our team lives our company values, and we hire based on them, too. Since 2010, Pipedrive has been on a mission to support sales and marketing teams with easy-to-use, powerful tools that make everyday work faster and easier. Today, our cloud-based software is trusted by over 100,000 companies and used in 179 countries. We have grown from a five-person team to a truly international company of over 850+ people, representing more than 50 nationalities, with ten offices distributed across Europe and the US. In 2020, Pipedrive received a majority investment from Vista Equity Partners, a global investment firm that invests exclusively in enterprise software, data and technology-enabled businesses, making Pipedrive the fifth unicorn from Estonia.

We are looking for a Principal AI/ML Scientist & Engineer to lead a growing team of Applied Scientists and AI/ML Engineers. This is a role for a pragmatic "Builder-Scientist" - a technical leader who possesses deep scientific rigor but is fundamentally driven by the iterative shipping of data products that customers fall in love with. You will lead the technical strategy for AI/ML-based solutions designed to extract value from both structured and unstructured data, bridging the gap between advanced research and production-grade systems. Your impact will be measured through technical leadership, leverage, and the real-world business outcomes you enable.

**Your new adventure: **

- Lead and mentor a team of Applied Scientists and AI/ML Engineers, fostering a culture of technical excellence and scientific rigor

- Lead the technical strategy for AI/ML-based solutions focused on extracting actionable value and insights from both structured CRM data and unstructured content

- Build the intelligence within our AI-native CRM, including the design of autonomous agentic workflows and real-time reasoning engines that execute business actions safely at scale

- Partner closely with the AI Platform team to drive the overarching strategy for large language model operations (LLMOps), ensuring infrastructure supports efficient experimentation and robust deployment

- Apply deep scientific intuition to the design of AI systems, ensuring that models and data-intensive solutions are optimized for customer centricity and real-world performance

- Act as a technical authority and multiplier across the AI/ML and data ecosystem, shaping the AI engineering roadmap and setting the bar for how we leverage the modern AI stack

- Lead as a high-impact individual contributor on our most critical systems, balancing a deep love for building with the ability to delegate effectively and grow the team’s technical capabilities

**Does this sound like you?**

- 8+ years of applied science or engineering experience with a broad, practical understanding of the full ML and AI lifecycle in high-scale production environments

- Proven ability to lead and scale a technical team, with experience mentoring senior talent and raising the technical bar of an organization

- Deep expertise in modern AI engineering concepts and tech stacks, with hands-on experience in agentic system orchestration (e.g., LangGraph), RAG architectures, and vector databases

- You are a deep scientist by training but a builder by choice; you prioritize shipping working, iterative solutions that solve real customer problems over chasing theoretical perfection

- Proven track record of delivering customer and business value through simple and complex AI/ML-based solutions at scale

- Broad exposure to ML, Deep Learning, and AI; you understand the practical trade-offs between different models and agentic frameworks

- Excellent product sense and business awareness, with the ability to translate technical and scientific choices into tangible improvements for our users

- Ability to lead through influence and technical authority, partnering with platform teams to influence strategy and raise the collective technical bar

- Solid understanding of cloud infrastructure (AWS/GCP), distributed systems, container orchestration, data engineering (batch pipeline, feature store, Kafka)

**Why Pipedrive?**

- **People-first culture** - Be part of a team that values authenticity, champions collaboration, and supports each other—no egos, just teamwork. Work alongside top talent from around the world in an inclusive space where different perspectives fuel our best ideas. Everyone is welcome

- **Unlock potential **– Push boundaries, take ownership, and experiment with the latest technologies as we enhance our AI First Vision. We empower bold ideas that drive real change

- **We’ve got you** – Your well-being matters. Enjoy flexible hours, wellness perks and SWAG. Think performance-based bonuses, 28 paid leave days, well-being days, compassionate leave, and even pawternal leave—because we take care of ourselves and our people

- **Grow with us** – Whether through mentorship, coaching, or internal mobility, we invest in helping you unlock your potential. Open, honest feedback and clear communication are at our core. We grow together through trust and accountability

- **Packed with purpose** – Help 100,000+ small and medium-sized businesses grow and succeed while doing meaningful, customer-driven work

**Diversity & Inclusion: **Pipedrive is an equal opportunity employer. We value diversity and are committed to creating an inclusive environment for all employees. We welcome applications regardless of race, color, religion, age, gender, sexual orientation, gender identity or expression, national origin, disability, veteran status, marital or family status, or any other characteristic protected by applicable law.

**Eligibility:** Please note that for this position, we are only able to consider candidates who already possess the legal right to work in Germany without the need for visa sponsorship or relocation assistance.

**Background Checks:** Where permitted by local law and necessitated by the scope of the role (e.g., access to sensitive data), Pipedrive may conduct a pre-employment background check. This will be handled in strict accordance with our [Candidates Privacy Notice](https://www.pipedrive.com/en/jobs/privacy-policy).

#LI-Hybrid

#LI-KA2

We’re on the lookout for a Principal AI/ML Scientist & Engineer to partner with our engineering and business teams, turning experimental AI and ML models into transparent, performant, production-ready solutions that create real business value.

If this is something for you, send us your resume (in English) or a link to your LinkedIn profile and please add why we should pay extra attention to your application.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
