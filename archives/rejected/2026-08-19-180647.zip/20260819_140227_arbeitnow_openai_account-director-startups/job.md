# Account Director, Startups

Posted: 2026-08-19T11:40:29Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**About the Team**

OpenAI’s mission is to build safe artificial general intelligence (AGI) which benefits all of humanity. This long-term undertaking brings the world’s best scientists, engineers, and business professionals into one lab together to accomplish this.

In pursuit of this mission, our Go To Market (GTM) team is responsible for helping customers learn how to leverage and deploy our highly capable AI products across their business. The team is made of Sales, Solutions, Support, Marketing, and Partnership professionals that work together to create valuable solutions that will help bring AI to as many users as possible.

**About the Role**

OpenAI is seeking a highly motivated and experienced Account Director to join our Startups Go To Market team. You will play a critical role in owning relationships with top startup customers and supporting them in building successfully on the OpenAI platform.

We believe that many of the most disruptive and category-defining AI applications will be created by startups. The Startup Go To Market team’s mission is to help startups harness the power of AI models to drive these advances. You will support startups building effectively with OpenAI’s APIs, and provide access to OpenAI teams and expertise to support their growth.

This role is a mixture of technical understanding, vision, partnership, and strategy. You’ll be responsible for serving as the primary relationship owner for a set of strategically important startup customers, as well as working across the OpenAI organization to help these startups accelerate their progress and be successful using our models. You’ll work cross-functionality with product, research, engineering, support, and solutions architecture to help customers get the most out of our models.

This role is based in Munich or Berlin. We use a hybrid work model of 3 days in the office per week and offer relocation assistance to new employees

**In this role, you will:**

-

Manage a portfolio of startups accounts, developing and executing strategies for a comprehensive account plan.

-

Partner with solutions and research engineering to build and execute complex customer programs and projects.

-

Own a consumption revenue target.

-

Manage consumption revenue forecasts.

-

Analyze key account metrics to create reports and provide insights to internal and external stakeholders.

-

Closely monitor the industry landscape (people, competitors, partners, etc.) to contribute to product roadmap and other corporate strategies.

-

Collaborate with solutions, marketing, communications, business operations, people operations, finance, product management, and engineering.

-

Serve as an advocate for improving the startup experience building with OpenAI, synthesizing product feedback from insights captured from our work with startups.

-

Closely monitor the industry landscape and startup landscape to contribute to product roadmap and other corporate strategies.

-

Support the recruitment and onboarding of other teammates.

-

Support the development of company culture.

**We're seeking someone with experience in:**

-

6+ years selling platform-as-a-service and/or software-as-a-service.

-

Designing and executing complex deal strategies.

-

Experience working in or around the startup ecosystem, preferably as either a founder of a startup, an employee of a startup, or someone who worked with startup customers.

-

Supporting the growth of fast-growing, high-performance companies.

-

Working directly with C-level executives.

-

Communicating technical concepts to customers and internal stakeholders.

-

Leading high-visibility customer events (CAB, conferences, product launches, etc.).

-

Gathering, distilling, and processing complex market (industry, competitor, customer, prospect) intelligence.

**You might thrive in this role if you: **

-

**Are customer-centric.** You are motivated to deeply understand your customer’s priorities and help them achieve their vision for using our models to improve their products and services. You build strong relationships with executives and professionals across functions and serve as a trusted advisor.

-

**Have a passion or deep curiosity in artificial intelligence.** You embrace the opportunity to help deploy our technology in a way that benefits humanity. You’re excited to educate our customers on AI and how to plan for the future.

-

**Are a builder.** You are excited to impact how our company operates and scales. Your passion is building strong systems and processes from the ground up and executing them with precision.

-

**Are excited by new challenges.** You don’t have the answers to every question up front, but the process of solving them invigorates you. Bespoke issues requiring multidimensional knowledge excite you. You’re willing to experiment with new solutions.

-

**Are a strategist.** You deeply understand go to market best practices and raise the bar for our organization. You think and plan forward on the order of years and bring internal and external stakeholders along with your strategy.

**About OpenAI**

OpenAI is an AI research and deployment company dedicated to ensuring that general-purpose artificial intelligence benefits all of humanity. We push the boundaries of the capabilities of AI systems and seek to safely deploy them to the world through our products. AI is an extremely powerful tool that must be created with safety and human needs at its core, and to achieve our mission, we must encompass and value the many different perspectives, voices, and experiences that form the full spectrum of humanity.

We are an equal opportunity employer, and we do not discriminate on the basis of race, religion, color, national origin, sex, sexual orientation, age, veteran status, disability, genetic information, or other applicable legally protected characteristic.

For additional information, please see [OpenAI’s Affirmative Action and Equal Employment Opportunity Policy Statement](https://cdn.openai.com/policies/eeo-policy-statement.pdf).

Background checks for applicants will be administered in accordance with applicable law, and qualified applicants with arrest or conviction records will be considered for employment consistent with those laws, including the San Francisco Fair Chance Ordinance, the Los Angeles County Fair Chance Ordinance for Employers, and the California Fair Chance Act, for US-based candidates. For unincorporated Los Angeles County workers: we reasonably believe that criminal history may have a direct, adverse and negative relationship with the following job duties, potentially resulting in the withdrawal of a conditional offer of employment: protect computer hardware entrusted to you from theft, loss or damage; return all computer hardware in your possession (including the data contained therein) upon termination of employment or end of assignment; and maintain the confidentiality of proprietary, confidential, and non-public information. In addition, job duties require access to secure and protected information technology systems and related data security obligations.

To notify OpenAI that you believe this job posting is non-compliant, please submit a report through [this form](https://form.asana.com/?d=57018692298241&k=5MqR40fZd7jlxVUh5J-UeA). No response will be provided to inquiries unrelated to job posting compliance.

We are committed to providing reasonable accommodations to applicants with disabilities, and requests can be made via this [link](https://form.asana.com/?k=bQ7w9h3iexRlicUdWRiwvg&d=57018692298241).

[OpenAI Global Applicant Privacy Policy](https://cdn.openai.com/policies/global-employee-and-contractor-privacy-policy.pdf)

At OpenAI, we believe artificial intelligence has the potential to help people solve immense global challenges, and we want the upside of AI to be widely shared. Join us in shaping the future of technology.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
