# Regional Sales Director (m/w/d) – Vertriebsleitung Region Süd

Posted: 2026-09-16T20:55:07Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Du willst kein Gebiet verwalten. Du willst ein Team bauen, das auch ohne dich verkauft. Als Regional Sales Director führst du acht Leute im Außendienst zwischen Ulm, Augsburg und München, mit KI-basierter Lead-Priorisierung, eigenem Forecast und Key-Account-Verhandlungen, die du selbst zum Abschluss bringst.

**Standort:** Großraum München – du arbeitest eigenständig in der Region Süd im Außendienst, mit rund 60 % Kundenterminen und 40 % Homeoffice, langfristig eher 50/50.

###

### Über uns

CarOnSale ist die KI-gestützte Plattform für den B2B-Gebrauchtwagenhandel in Europa. Über 40.000 Käufer aus mehr als 20 Ländern handeln auf unserer Plattform – und 85 % des Inventars ist exklusiv bei uns. Wir verbinden Software, Pricing-Intelligenz, Logistik und Finanzierung in einer Schicht – als Betriebssystem für eine ganze Branche.

***One Platform. One Profit Engine.***

###

### Deine Aufgaben

- Du baust das regionale Field-Sales-Team weiter auf und etablierst eine Leistungskultur, in der jede Person ihre Zahlen selbst verantwortet

- Du entwickelst eine hybride Vertriebsstrategie, die digitale Tools mit persönlicher Kundennähe verbindet

- Du implementierst klar strukturierte Vertriebsprozesse mit definierten Rollen

- Du setzt die regionalen Wachstumsziele um und führst strategische Key-Account-Verhandlungen bis zum Abschluss

- Du steuerst den Vertriebserfolg datengetrieben über KPIs, Forecasts und KI-basierte Lead-Priorisierung

- Du identifizierst Optimierungspotenziale entlang der Customer Journey und hebst Produktivität, Effizienz und Kundenzufriedenheit

- Du präsentierst deine Ergebnisse in KPI-Dashboards und Business Reviews auf Führungsebene

###

### Was du mitbringst

- Mindestens zwei Jahre Führungserfahrung mit einem Vertriebsteam von mehr als sechs Personen

- Erfahrung im Außendienst sowie im Hunting- und Farming-Modell

- Erfahrung im Vertrieb erklärungsbedürftiger, komplexer Produkte – du überzeugst mit Argumenten und gibst dieses Wissen an dein Team weiter

- Erfahrung im Teamaufbau und Performance-Coaching, mit operativer Nähe zum Tagesgeschäft

- KPIs, Forecasts und datengetriebene Steuerung sind für dich selbstverständlich, ebenso der Umgang mit Salesforce, Google Workspace, Looker oder Tableau

- Deutsch auf C2-Niveau, Englisch mindestens B2 für die Zusammenarbeit im Führungsteam

**Von Vorteil**

- Verständnis für skalierbare Vertriebsmodelle in digitalen Umfeldern, idealerweise Start-up, SaaS oder Plattform

- KI-gestützte Sales-Prozesse hast du nicht nur kennengelernt, sondern aktiv mitgestaltet

###

### Was dich bei uns erwartet

- Firmenwagen zur privaten Nutzung inklusive Tankkarte

- 28 Tage Urlaub

- 2× jährliches Karriere- & Entwicklungsgespräch

- Betriebliche Altersvorsorge mit 20 % Arbeitgeberzuschuss

- Dienstrad-Leasing zur privaten Nutzung

- FitX-Mitgliedschaft oder Urban Sports Club-Zuschuss

- Corporate Benefits: Mitarbeiterangebote und Vergünstigungen

- Virtual Stock Options – du beteiligst dich am Erfolg

- Moderne IT-Ausstattung für dein tägliches Arbeiten

- Strukturiertes Onboarding mit Buddy-Programm und Social Events

- Gelebte Vielfalt: aktives Frauennetzwerk

**Bewirb dich jetzt – dein Lebenslauf reicht.**

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
