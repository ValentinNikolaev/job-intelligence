# Channel Partner Manager - CEE

Posted: 2026-09-17T02:40:12Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**About **[**monday.com**](http://monday.com)

[monday.com](http://monday.com) is the AI work platform powering the most ambitious teams. 250,000+ customers across departments use us to bring people, workflows, and AI agents together on one flexible platform where AI doesn't just assist, it executes. We move fast, build things that matter, and foster an ownership-driven culture where you're empowered to shape how organisations work and outpace their competition.

**About the group / About the team**

[Monday.com](http://Monday.com) is growing and looking for a Channel Partner Manager to cover Central and Eastern Europe (CEE) based in Munich. This role includes managing all relationships and sales efforts with our channel partners, including direct client-facing responsibilities, mainly for strategic business.

The Channel Partner Manager is responsible for the constant growth of their partners' businesses and teams and for managing them together with their pipeline and forecasts.

**Office location:** Hybrid (3 days per week in our Munich office, Rindermarkt – steps from Marienplatz)

**About the role:**

-

Own the strategy, sales, and execution of growing your portfolio of partners in CEE

-

Lead strategic sales and strategic account management alongside your portfolio of partners inc. bringing in new business and growing existing business within your partner portfolio

-

Form close partnerships while striking a balance between company goals, speed, and economic potential

-

Evaluate the financial and non-financial benefits and risks of new and existing partnerships

-

Track, report, and optimise the performance of partnerships, including identifying issues as they arise, assessing possible solutions, and executing them

-

Own your partner’s portfolio targets and deliver the results month over month

-

Collaborate with different teams at [monday.com](http://monday.com) to build and maintain a pipeline of relationships with potential partners, taking responsibility for the relationship throughout all stages.

-

Willingness to travel as required or be based at the partner/customer office.

**Requirements**:

-

Minimum 6 years of experience in SaaS sales roles - must.

-

1+ years’ experience in managing Channel Partners/ Resellers - an advantage.

-

Strong sales background - with a track record - from the opportunity to close.

-

Account and quota planning skills.

-

Ability to take an entire project from A to Z.

-

Strong relationship builder, initiator, and outstanding verbal and written communication skills.

-

Exceptional organisational and multitasking skills.

-

Team player with a super proactive approach.

-

Fluency in Polish is strongly preferred

-

Strength and experience with public speaking - an advantage.

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
