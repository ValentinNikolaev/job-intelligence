# Coding Tutor/Lehrkraft (all genders)

Posted: 2026-09-17T02:40:09Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Du hast in der Softwareentwicklung mit Python gearbeitet – **Code geschrieben, Anwendungen automatisiert, vielleicht sogar objektorientiert entwickelt** – und willst dieses Wissen jetzt weitergeben, statt es nur für eigene Projekte zu nutzen? Als** Python-Tutor/Lehrkraft** begleitest Du unsere Teilnehmenden fachlich und didaktisch durch ihre Programmier-Weiterbildung: Du beantwortest ihre Fragen, hilfst ihnen über die Hürden bei Übungen und Projekten hinweg und sorgst dafür, dass sie am Ende nicht nur Python verstehen, sondern selbstständig damit arbeiten können.

Du bewertest** Lernfortschritte, führst Abschlussprüfungen durch und gibst strukturiertes, konstruktives Feedback**. Durch den engen Kontakt zu den Lernenden trägst Du außerdem aktiv zur Weiterentwicklung unserer Trainingsprogramme bei – in enger Zusammenarbeit mit dem Coaching Team Lead, dem Learning Team und weiteren Schnittstellen.

**Schwerpunkte Deiner Rolle**

-

Fachliche Beantwortung von Fragen der Lernenden (schriftlich und mündlich)

-

Vermittlung und Vertiefung von Trainingsinhalten in Live-Sessions, Webinaren, Classrooms und individueller Lernbegleitung

-

Begleitung bei Unsicherheiten im Lernprozess sowie in Übungen und Projekten

-

Durchführung und Bewertung von Abschlussprüfungen sowie Entscheidung über den Trainingserfolg

-

Erstellung, Aufbereitung und Weiterentwicklung von Lernmaterialien rund um objektorientierte Programmierung, Python, Jupyter Notebooks, Entwicklungsumgebungen (z. B. VS Code), Git, Bash/Scripting sowie GenAI-Tools; Kenntnisse in SQL sind ein Plus

-

Qualitätssicherung bestehender Trainings inkl. Feedback ans Learning-Team

-

Durchführung individueller Coaching-Sessions und Unterstützung neuer Teammitglieder

**Das bringst Du mit**

-

Abgeschlossenes Studium der Informatik oder eines fach verwandten Bereichs oder eine vergleichbare Qualifikation

-

Praxiskenntnisse in Softwareentwicklung (z. B. Webentwicklung, Datenverarbeitung, Automatisierung) sowie Kenntnisse in objektorientierter Programmierung

-

Sehr gute Programmierfähigkeiten in Python, Vertrautheit im Umgang mit Jupyter Notebooks und IDEs (z. B. VS Code) sowie gute Praxiskenntnisse in Bash/Scripting

-

Erfahrung mit Versionskontrolle (Git/GitHub) und gängigen Entwicklungsumgebungen

-

SQL-Kenntnisse sowie Erfahrung im Einsatz von GenAI-Tools sind von Vorteil

-

Didaktische Erfahrung in der Vermittlung technischer oder fachlicher Inhalte an nicht-technische Zielgruppen

-

Verständnis für didaktische Konzepte der Erwachsenenbildung und Online-Weiterbildung

-

Kenntnisse in Python, SQL, Power BI oder Excel sind ein Plus

-

Hohe Kunden- und Serviceorientierung, Empathie, klare Kommunikation und konstruktive Feedbackkultur

-

Hands-on-Mentalität, Teamgeist, Belastbarkeit und Flexibilität

-

Sehr gute Deutsch- und Englischkenntnisse (mind. C1)

**Das bieten wir Dir**

**Arbeitskultur**
Dich erwartet eine lösungsorientierte und datengetriebene Arbeitsweise, eine offene Feedbackkultur sowie ein starker Teamspirit. Zwei vom gesamten StackFuel-Team gewählte Trustees unterstützen Dich bei Fragen und Anliegen als neutrale, vertrauliche Anlaufstelle.

**Ownership**
Übernehme ab dem ersten Tag Verantwortung, bringe Deine eigenen Ideen aktiv ein, gestalte Prozesse nachhaltig und präge unsere Abläufe maßgeblich mit.
**
Workation**
Bis zu 10 Tage pro Jahr kannst Du von überall aus der EU, dem EWR und der Türkei arbeiten.
**
Raum für Austausch**
Regelmäßiger Austausch im Team, saisonale Feiern und eine immer gut gefüllte Küche sorgen für ein lebendiges Miteinander.

**Weiterentwicklung**
Absolviere unsere Online-Trainings, um Deine fachlichen Fähigkeiten auszubauen und Dich zur Expert:in für Daten und KI zu entwickeln.

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
