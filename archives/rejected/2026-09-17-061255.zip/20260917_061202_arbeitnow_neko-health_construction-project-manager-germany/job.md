# Construction Project Manager, Germany

Posted: 2026-09-17T02:40:10Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

### **Mission**

Neko is redefining what prevention means, from treating illness when it arrives, to sustaining health before it's ever at risk. Our mission: make data-driven, preventative care accessible to more people, before symptoms appear.

In a single, non-invasive visit under an hour, proprietary technology and direct clinical care combine to deliver personalised, actionable insights. It's a team that thinks in 10x, not 10%. Every role here plays a part in building a world where prevention is the norm, and where your work genuinely helps people live longer, healthier lives.

### **Role Purpose**

We are looking for an experienced Development/Construction Lead to manage clinic development projects across Germany. This role will oversee the full lifecycle of projects, from concept and planning through to operational delivery, ensuring projects are completed on time, within budget, and to the highest quality standards. The role requires strong knowledge of the German construction environment, particularly building permits and local project processes.

### **What You'll Delivery in the First 6-12 Months**

-

Lead clinic construction and development projects across Germany from concept through to operational handover.

-

Manage contractors, architects, and consultants while ensuring quality and timeline delivery.

-

Navigate German building permit processes and local regulatory requirements.

-

Monitor project budgets and capital expenditure, ensuring cost control on projects typically ranging from €5M–€15M.

-

Report project progress, risks, and issues to senior leadership and key stakeholders.

-

Coordinate site preparation and oversee construction activities across multiple clinic locations.

### **Minimum Qualifications **

-

10–15 years’ experience in construction, development, or project management.

-

Fluent German speaker with strong understanding of local construction and permit processes.

-

Background in commercial, retail, or real estate development environments (e.g., flexible office, commercial fit-outs, retail spaces).

-

Proven experience delivering projects from concept through to operational launch.

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
