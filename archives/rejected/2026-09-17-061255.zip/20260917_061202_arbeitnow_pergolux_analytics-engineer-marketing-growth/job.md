# Analytics Engineer - Marketing & Growth

Posted: 2026-09-17T02:40:08Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Senior Analytics Engineer Marketing & Growth : You will own and architect the systems and definitions that determine how every euro of marketing spend is measured, audited, and optimized. Your work will directly shape how we understand acquisition performance, allocate budgets, and scale efficiently across markets. You will join a lean, 4 person team working on mission-critical initiatives in a fast-growing, design-driven environment.

At **PERGOLUX**, we value integrity, innovation, ambition, and unity — and we build systems with the same care and precision as our products.

## **What You’ll Do**

-

Build and own the Single Source of Truth for Marketing and Storefront, defining CAC, Engagement, and core performance metrics with clarity, consistency, and auditability.

-

Implement Multi-Touch Attribution models and lay the groundwork for Marketing Mix Models that inform budget allocation and channel-level investment.

-

Expand Semantic model with relevant context and metrics that enables conversational analytics and shortens the time to insight

-

Design and build Data Health metrics that bring visibility to the quality, accuracy, freshness and completeness of our marketing and storefront data

-

Partner closely with marketing, storefront, and leadership stakeholders to drive faster, smarter decisions.

## **What You’ll Bring**

-

Minimum 5 years experience in analytics engineering roles

-

A strong, proactive ownership mindset with the confidence to challenge requests that introduce ambiguity, technical debt, or low business impact.

-

Expert proficiency in SQL, dbt, and data modeling, with experience building durable, modular systems that scale with the business. (Stack: Airbyte, Python, Snowflake, Looker)

-

Prior experience building Multi-touch Attribution Models or Marketing Mix Models (MMM)

-

Deep understanding of marketing analytics concepts, including ROAS, CPA, MER, attribution logic, CRM data structures, and channel mechanics.

-

Professional working proficiency in English, enabling clear communication in an international, cross-functional environment.

## **Benefits**

-

**Competitive Salary & Bonus Structure** – Your success is rewarded with strong compensation and performance-based bonuses.

-

**Real Ownership** – Take meaningful responsibility in your role and directly influence key business outcomes.

-

**International Team** – Collaborate with passionate colleagues across Europe, gaining exposure to diverse perspectives and ideas.

-

**Outdoor Lifestyle Discounts** – Enjoy exclusive discounts on **PERGOLUX** products.

-

**Fast-Track Career Opportunities** – As we scale quickly, you’ll have significant opportunities to grow into senior leadership roles.

-

**Team Culture** – Be part of regular team events, retreats, and a culture that celebrates wins—big and small.

-

**Bike Leasing Program** – Benefit from a sustainable and cost-effective bike leasing option to support commuting and an active lifestyle.

## **How to Apply**

If you’re excited to build high-impact data systems at the core of a fast-scaling global brand, we’d love to hear from you.

Apply via[ **PERGOLUX LinkedIn**](https://de.linkedin.com/company/pergolux) or through our[ **PERGOLUX Career Page**](https://pergoluxshop.com/pages/career?srsltid=AfmBOoovIyCkI0ANAyYXkPLHjJY3Dh5u7NQ3LHsQDbhh9KIjviUUJ1kV#ashby_embed_iframe)

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
