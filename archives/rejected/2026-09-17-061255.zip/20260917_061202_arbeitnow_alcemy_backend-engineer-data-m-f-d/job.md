# Backend Engineer - Data (m/f/d)

Posted: 2026-09-16T20:20:09Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**Berlin Mitte · Hybrid (up to 2 days/week remote) · €60,000–75,000 + VSOP equity**

###
Help us decarbonize cement and concrete - not tomorrow, today

alcemy is on a mission to keep 100 million tons of CO₂ out of the atmosphere every year by 2030. Making concrete accounts for around 8% of global CO₂ emissions, and our machine-learning software runs inside cement and concrete plants 24/7 to cut it - without sacrificing quality or driving up costs. We're already live in a third of Germany's cement plants and 30+ ready-mix concrete plants.

### The role

You'll own the systems that get plant data into alcemy.

That data comes from external partners, and it arrives messy. You'll build and own the APIs and services that take it in, make sense of it, and feed the machine-learning models behind our recommendations - designing those systems, deploying them, keeping them running, and diagnosing what went wrong when something upstream changes without warning.

It's a backend engineering role with a data problem at the centre of it, and it's refreshingly hands-on with customers: you'll dig into real-world data, explain what you find to non-technical people, and make getting data into alcemy dramatically easier.

What you need is solid production Python, the ability to run what you build, and comfort talking to the people on the other end of the pipe.

### What you'll do

- Own the data ingestion systems that bring messy plant data from external partners into something our ML can use
- Build and improve our ingestion APIs, moving us from strict, structured data requirements toward flexible, AI-powered ingestion — so customers onboard with far less friction
- Deploy, monitor and troubleshoot your systems in production, diagnosing and fixing issues when something upstream changes without warning
- Track down data anomalies and explain your findings to customers in plain language
- Build and maintain the APIs and PostgreSQL databases behind our products, and keep production running smoothly
- Work shoulder to shoulder with external partners, customers, sales and customer success - translating between the technical and the non-technical
- Collaborate with the product team on backend work

**Requirements**

***You'll thrive here if... above all, you care about climate change and want your work to count.
***

**Must-haves**

- You've deployed production-grade Python applications
- You know how to deploy, monitor and troubleshoot production systems in a cloud environment
- You communicate clearly in writing and in conversation, and you collaborate well across roles
- You're comfortable working directly with customers, sales and customer success - patient, plain-spoken, and at ease with non-technical enterprise teams
- You pick up unfamiliar codebases quickly, and you're keen to contribute early
- You're open to using AI tools to augment how you work

**Nice-to-haves**

- Exposure to machine learning or data pipeline projects
- Experience with FastAPI, Flask or Django
- PostgreSQL or similar SQL databases
- Experience designing or maintaining integrations with third-party or partner systems

Don't tick every box? We'd still love to hear from you.

###
How we work

You won't be working alone - you'll build collaboratively alongside senior and junior engineers, owning features end to end: build, test, review, deploy.

Small team, direct customer exposure, fast startup pace - so async communication, clear prioritisation, transparency, and direct feedback are the norm, and how we work is something we shape together, and keep improving.

We use Claude Code responsibly: AI to move fast, engineers always in charge and accountable, no AI-slop merge requests.

**We'll ask you to be flexible.** We don't have fixed teams or fixed projects here. As the business shifts, we'll ask you to move to where the work matters most and pick up new problems. If you enjoy variety and switching between problems, you'll do well here.

Hybrid by design (Berlin Mitte office, up to 2 days remote, plus offsites and boat trips), with real room to grow along technical-expert or management tracks - and the chance to lead a product area within a couple of years.

**Benefits**

- 25 days' vacation - plus an extra day for every 2 years here, and the days between Christmas and New Year off
- €1,500/year and 3 days/quarter for your own development
- The Mac of your choice
- An office in the heart of Berlin Mitte

**Our Tech Stack**

- **Backend & data:** Python throughout - FastAPI (auto-generated Swagger/OpenAPI), SQLAlchemy, pydantic, pytest, mypy; pandas, polars, numpy, sklearn; uv for dependencies
- **Infra:** PostgreSQL, AWS on Kubernetes managed with Terraform, ArgoWorkflows for scheduled jobs, GitLab for code
- **Frontend:** React & Next.js in TypeScript with TailwindCSS; Blueprint.js / Radix UI; TanStack Query or axios; Streamlit for internal tools

**Our Hiring Process is fully remote**

- Intro call with our Recruiter
- Meet our Hiring Manager
- A take-home task that mirrors the real work you'd be doing
- Technical interview (90 min) with two engineers, including 30 min of live coding
- Team-fit interview (45 min) with two future teammates

At alcemy, we're building a team as diverse as the industry we're transforming. We welcome applications from everyone and assess every candidate on merit alone - regardless of gender, age, ethnic or national origin, religion or worldview, disability, sexual orientation, or gender identity. We especially encourage people who are underrepresented in tech to apply. If you need any adjustments to take part fully in our hiring process, just let us know and we'll make them.

*
Note: We don't currently offer visa sponsorship, so you'll need a valid EU work visa.*

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
