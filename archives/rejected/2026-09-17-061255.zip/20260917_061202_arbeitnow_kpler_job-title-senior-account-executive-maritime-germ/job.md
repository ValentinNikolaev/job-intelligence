# Job Title Senior Account Executive - Maritime - Germany

Posted: 2026-09-17T02:04:23Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

At Kpler, we are dedicated to helping our clients navigate complex markets with ease. By simplifying global trade information and providing valuable insights, we empower organisations to make informed decisions in commodities, energy, and maritime sectors.

Since our founding in 2014, we have focused on delivering top-tier intelligence through user-friendly platforms. Our team of over 850 experts from 69 countries works tirelessly to transform intricate data into actionable strategies, ensuring our clients stay ahead in a dynamic market landscape. Join us to leverage cutting-edge innovation for impactful results and experience unparalleled support on your journey to success.

**About the Role**

As a Senior Account Executive focusing on the Maritime sector across Germany and Switzerland, you will be instrumental in expanding Kpler’s footprint in one of Europe’s most dynamic market regions. Working within our Mid-Market EMEA team, you will drive new account acquisition and uncover high-impact expansion opportunities by connecting commercial leaders with actionable data intelligence. In this role, your expertise will directly influence how maritime organizations make critical global trade decisions.

**Key Responsibilities**

-

Drive new account acquisition across Germany and Switzerland to consistently meet and exceed annual revenue targets.

-

Uncover and execute strategic upsell and cross-sell opportunities within existing accounts to maximize customer lifetime value.

-

Partner with cross-functional commercial teams to support territory forecasting, demand planning, and multi-year strategic goals.

-

Gather direct customer and market feedback to provide actionable product and competitive insights back to internal strategy teams.

-

Maintain rigorous CRM data hygiene in Salesforce to ensure transparent pipeline reporting and accurate revenue forecasting.

-

Represent Kpler externally with authority and professionalism, positioning our data solutions as essential for maritime industry leaders.

**Experience & Background**

**What you'll need (Must-haves):**

-

5+ years of commercial sales experience with a track record of driving new logo acquisition in a Senior AE role.

-

Proven background selling B2B SaaS, enterprise technology, or data intelligence solutions to corporate stakeholders.

-

Native or professional fluency in both German and English.

-

Strong negotiation skills combined with a proactive "hunter" mindset to independently develop and close high-value pipeline.

**Nice-to-haves:**

-

Direct commercial experience or domain knowledge within the maritime or global commodities trading sectors.

-

Hands-on proficiency with modern revenue enablement platforms (e.g., Salesforce, ZoomInfo, Outreach, LinkedIn Sales Navigator).

-

Bachelor’s degree in Business, Marketing, or a related field (or equivalent professional experience).

We are a dynamic company dedicated to nurturing connections and innovating solutions to tackle market challenges head-on. If you thrive on customer satisfaction and turning ideas into reality, then you’ve found your ideal destination. Are you ready to embark on this exciting journey with us?

**We make things happen**

We act decisively and with purpose, going the extra mile.

**We build together**

We foster relationships and develop creative solutions to address market challenges.

**We are here to help**

We are accessible and supportive to colleagues and clients with a friendly approach.

Our People Pledge

Don’t meet every single requirement? Research shows that women and people of color are less likely than others to apply if they feel like they don’t match 100% of the job requirements. Don’t let the confidence gap stand in your way, we’d love to hear from you! We understand that experience comes in many different forms and are dedicated to adding new perspectives to the team.

Kpler is committed to providing a fair, inclusive and diverse work-environment. We believe that different perspectives lead to better ideas, and better ideas allow us to better understand the needs and interests of our diverse, global community. We welcome people of different backgrounds, experiences, abilities and perspectives and are an equal opportunity employer.

By applying, I confirm that I have read and accept the [Staff Privacy Notice](https://www.kpler.com/privacy)

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
