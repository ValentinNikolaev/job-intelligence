# Senior Global Controller

Posted: 2026-09-17T02:40:08Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

As a **Senior Global Controller**, you will help build the financial foundation that supports **PERGOLUX**’s global expansion. You’ll work at the intersection of analysis, structure, and strategy — contributing directly to the financial clarity and operational excellence of a premium outdoor-living brand inspired by Scandinavian design. As we continue scaling across Europe, Australia, North America, and South America, your analytical mindset and precision will play a key role in strengthening our financial processes and insights.

### **What You’ll Do**

-

Support the preparation of monthly, quarterly, and annual financial reports.

-

Participate in budgeting and forecasting processes to support strategic planning.

-

Perform variance analysis, KPI reporting, and ad-hoc financial evaluations.

-

Maintain and enhance controlling processes, tools, and standardized reporting structures.

-

Assist with liquidity planning and cash-flow forecasting in a high-growth environment.

### **What You’ll Bring**

-

Degree in Business Administration, Finance, or Controlling — or relevant advanced training in accounting/controlling.

-

At least 3 years of professional experience in controlling or finance.

-

Strong proficiency in MS Excel; experience with BI tools is a plus.

-

Basic knowledge of HGB or IFRS is advantageous.

-

Strong analytical skills, attention to detail, and a structured, solution-oriented working style.

-

Experience working with Lucanet.

### **Benefits**

-

Competitive Salary – Your success is rewarded with strong compensation.

-

Real Ownership – Take meaningful responsibility in your role and directly influence key business outcomes.

-

International Team – Collaborate with passionate colleagues across Europe, gaining exposure to diverse perspectives and ideas.

-

Outdoor Lifestyle Discounts – Enjoy exclusive discounts on **PERGOLUX** products.

-

Fast-Track Career Opportunities – As we scale quickly, you’ll have significant opportunities to grow into senior leadership roles.

-

Team Culture – Be part of regular team events, retreats, and a culture that celebrates wins—big and small.

-

Bike Leasing Program – Benefit from a sustainable and cost-effective bike leasing option to support commuting and an active lifestyle.

-

Company Pension - Plan for a stable future.

### **How to Apply**

We look forward to receiving your application and resume!
Learn more about life at **PERGOLUX** on [**PERGOLUX LinkedIn**](https://de.linkedin.com/company/pergolux) or apply via our [**PERGOLUX Career Page**](https://pergolux.de/pages/career?srsltid=AfmBOoqMCh9jNL9qC5tGgLuWpo5TAmYtSUWWGHgoJ4Z0SwntMuQEk_qE).

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
