# Sales Manager – SaaS/B2B (f/m/d)

Posted: 2026-09-17T02:40:06Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**UNSER PURPOSE BEI PLANCRAFT**

**Gemeinsam das Rückgrat des europäischen Handwerks aufbauen – mit moderner Software und smarten AI-Lösungen.**
Wir entwickeln nicht einfach nur Software – wir haben die Mission, Handwerkerinnen und Handwerksbetrieben mehr Raum zu schaffen, indem wir sie mit einer praxisnahen SaaS-Lösung ausstatten, die so arbeitet wie sie: schnell, effizient und ohne unnötigen Admin-Aufwand. Unterstützt durch smarte AI-Funktionen genau dort, wo sie im Alltag wirklich helfen. Mit Tier 1 Investoren aus Europa und den USA wie Headline und Creandum sowie über 30.000 Handwerkerinnen als Kundenbasis skalieren wir europaweit, um aus einzelnen, verstreuten Betrieben vernetzte und erfolgreiche Communities zu machen.
Wir glauben an zero admin, nicht zero personality – und wir entwickeln jede Funktion mit den Menschen im Blick, die die Sicherheitsschuhe tragen, nicht die Anzüge. Wir haben Bock, die Zukunft zu gestalten, zusammen als Team, und sind bodenständig in unserer Mission, die Macherinnen von morgen zu unterstützen.

**DEINE MISSION BEI UNS**

Als **Sales Manager (f/m/d)** bist du ein zentraler Treiber des Umsatzwachstums bei **plancraft**. Du arbeitest mit qualifizierten, eingehenden Leads und begleitest sie vom ersten Gespräch bis zum Vertragsabschluss.

**Deine Verantwortlichkeiten**

-

Du bearbeitest **qualifizierte Leads** mit erkennbarem Bedarf.

-

Du führst **Produktdemos** durch, analysierst Kundenbedürfnisse und entwickelst passende Lösungen.

-

Du berätst potenzielle Kund:innen strukturiert und begleitest sie durch den gesamten **Verkaufsprozess**.

-

Du schließt Deals eigenständig ab – **vom Erstgespräch bis zum Vertragsabschluss**.

-

Du behältst deine **KPIs** im Blick und arbeitest **strukturiert mit unserem CRM**.

-

Du arbeitest eng mit **Marketing** und **Customer Success** zusammen, um die bestmögliche Kundenerfahrung zu schaffen.

Bei plancraft erwarten dich klare und transparente Karrierepfade – z. B. von Junior Sales Manager bis Senior Sales Manager – und du kannst dich bei uns mit klarer Perspektive und nachhaltig weiterentwickeln. Unsere Gehaltsstruktur ist transparent aufgebaut: Je nach Erfahrungslevel liegt dein On-Target-Earnings (OTE) zwischen **60.000 € und 87.500 €**, bestehend aus einem Fixgehalt zwischen **45.000 € und 62.500 €** sowie einer variablen Komponente zwischen **15.000 € und 25.000 €**.

**DEIN PROFIL**

**Must-haves**

-

Erste Erfahrung im **B2B- oder SaaS-Vertrieb**, idealerweise im Umgang mit **warmen Leads oder Closing**.

-

Erfahrung in der **Bedarfsanalyse** und im Führen strukturierter Verkaufsgespräche.

-

Erfahrung im Umgang mit **CRM-Systemen** (z. B. HubSpot, Pipedrive oder Salesforce).

-

Interesse daran, **AI zu nutzen**, um deinen Sales-Alltag smarter, skalierbarer und wirkungsvoller zu gestalten.

-

**Deutschkenntnisse auf C1/C2-Niveau**.

-

Offenheit, regelmäßig in unser Büro in **Hamburg** zu kommen (hybrid).

**Nice-to-Haves**

-

Erfahrung im **SaaS-Vertrieb**.

-

Erfahrung mit Kund:innen aus dem **Handwerks- oder Baugewerbe**.

**WARUM PLANCRAFT?**

-

**Team Spirit:** Mit Leidenschaft, Engagement und echtem Bock setzen wir alles daran, unsere Mission gemeinsam zu verwirklichen. Team Spirit feiern wir regelmäßig: mit 3 großen Team Events im Jahr, 2 monatlichen lockeren Formaten in unserem HQ und einer starken Recognition Culture, in der wir kleine wie große Erfolge sichtbar machen und gemeinsam zelebrieren.

-

**Ownership:** Bei uns übernimmst du Verantwortung ab Tag eins. In einem Umfeld mit flachen Hierarchien und hohem Vertrauen kannst du wirklich etwas bewegen.

-

**Weiterentwicklung:** Wir investieren gezielt in deine Entwicklung – durch eine starke Feedback Kultur, ein persönliches Learning Budget und Enablement Formate. Wir wollen dich bestmöglich unterstützen, damit du dein volles Potenzial entfalten kannst.

-

**AI Enablement:** Unsere internen Tools und Workflows sind von Grund auf KI-gestützt konzipiert. Wir unterstützen jedes Team und jede einzelne Person dabei, KI im Arbeitsalltag auf dem nächsten Level einzusetzen – inklusive einer eigenen ChatGPT+-Lizenz, selbstverständlich.

-

**Tech & Tooling:** Du bekommst moderne Hardware wie ein MacBook und hochwertige Over Ear Kopfhörer sowie alle Tools, die du für dein Daily Doing brauchst.

-

**Flexibilität:** Ob remote, hybrid oder im Office: Du arbeitest dort, wo du es am besten kannst. Unser Hamburger Büro am Rödingsmarkt (inkl. Dachterrasse) steht dir jederzeit offen.

-

**Erholung:** 30 Urlaubstage, der 24.12. frei, ein Zuschuss zum Urban Sports Club sowie interne Sport Meetups unterstützen dich beim Abschalten.

-

**Mobilität:** Du kannst dir ein JobRad holen oder ein bezuschusstes Deutschlandticket bzw. eine BahnCard nutzen.

-

**Internationales Umfeld:** Wir werden stetig internationaler mit Kolleginnen u. a. in Italien, Frankreich, den Niederlanden und Österreich – und kommunizieren intern auf Englisch.

We’re **#stoked** to shape the future,** #together** as a team, and **#humble** in our mission to support the builders of tomorrow. For a first impression of us, take a look at [**our Instagram**](https://www.instagram.com/plancraft.app/reels/) and [**LinkedIn page**](https://www.linkedin.com/company/plancraft-gmbh/?viewAsMember=true).

**Diversity makes us better.
**We welcome people of all backgrounds, identities, abilities, and experiences, and we believe that different perspectives lead to better ideas, stronger products, and a healthier workplace. If you’re excited about our mission but your experience doesn’t align perfectly with every requirement, we encourage you to apply anyway. You might be exactly who we’re looking for.

______

**On the application process
**We want your candidate experience with us to be smooth, transparent, and enjoyable. We aim to get back to you regarding your application within 5 business days. Our interview process typically takes about 4 weeks from start to finish, though this may vary by role. You can learn more about our process [**here**](https://plancraft.com/en-gb/jobs#hiring). If you need adjustments or flexibility at any stage, please don’t hesitate to let us know — we’ll do our best to make it work for you.

**Note on creating a test account:**
If you would like to create a test account as part of the challenge, please enter "Applicant" in the relevant field during registration and select "Other" under Trade. This ensures that our sales team does not mistakenly register you as a craft business and reach out to you unnecessarily.

Compensation: €45K – €62.5K • €15K – €25K Commission

- • Fixed Salary €45K – €62.5K • €15K – €25K Commission

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
