# Teamleiter Qualitätssicherung Kfz / Fahrzeugprüfung (m/w/d)

Posted: 2026-09-16T20:55:07Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Du hast Kfz-Fachwissen, weißt wie Qualitätsprozesse funktionieren – und willst ein Team führen, das beides zusammenbringt? Als Teamleiter Qualitätssicherung Kfz / Fahrzeugprüfung (m/w/d) bei CarOnSale stellst du sicher, dass unsere Fahrzeugberichte, Auktionen und Datenprozesse auf dem Niveau sind, das unsere Kunden und Partner erwarten.

**Standort:** Berlin Schöneberg – Du arbeitest vor Ort in unserem Büro, hybrid mit 3 Tagen Office und 2 Tagen Homeoffice.

###

### Über uns

CarOnSale ist die KI-gestützte Plattform für den B2B-Gebrauchtwagenhandel in Europa. Über 40.000 Käufer aus mehr als 20 Ländern handeln auf unserer Plattform – und 85 % des Inventars ist exklusiv bei uns. Wir verbinden Software, Pricing-Intelligenz, Logistik und Finanzierung in einer Schicht – als Betriebssystem für eine ganze Branche.

***One Platform. One Profit Engine.***

###

### Deine Aufgaben

- Du stellst sicher, dass Teamziele und KPIs erreicht werden – Genauigkeit, Effizienz und Timelines.

- Du überprüfst die Arbeitsergebnisse des Teams (Berichte, Datenpflege, Auktionsanpassungen) auf Qualität und Standardeinhaltung.

- Du leitest dein Team im Tagesgeschäft und führst fachlich bei komplexen oder kritischen Aufgaben und in arbeitsintensiven Phasen.

- Läuft im Tagesgeschäft ein Prozess nicht rund, übernimmst du Verantwortung, findest die Lösung und bringst den Prozess wieder auf Kurs. Wo nötig, entwickelst du neue Prozesse.

- Du bringst dich in Projekte ein und treibst die Weiterentwicklung unserer Prozesse im Rahmen unseres OKR-Frameworks voran.

- Du erstellst Arbeitspläne, priorisierst Aufgaben und sorgst für einen strukturierten Ablauf.

- Du kommunizierst regelmäßig mit dem Team und vermittelst Updates, Best Practices und Feedback.

###

### Was du mitbringst

- Erfahrung in der disziplinarischen Teamleitung – oder eine klare, belastbare Vorstellung davon, wie disziplinarische Führung funktioniert.

- Fähigkeit, Teammitglieder zu motivieren, zu fördern und klare Ziele zu setzen.

- Hohes Ownership: Du bist erster Ansprechpartner für dein Team, denkst aber auch teamübergreifend mit – wenn Prozesse brechen oder Fragen aufkommen, gehst du proaktiv ran und findest Lösungen.

- Hohe Eigenständigkeit und Verlässlichkeit bei der Steuerung von Prozessen.

- Erfahrung in der Qualitätssicherung, idealerweise im Bereich Fahrzeuge oder Auktionen.

- Sicheres Auftreten und Kommunikationsgeschick mit internen und externen Stakeholdern.

- Sicherer Umgang mit Office-Anwendungen und schnelle Einarbeitung in neue Systeme.

- Sehr gute Deutschkenntnisse in Wort und Schrift (mind. C1), Englischkenntnisse (mind. B1).

**Von Vorteil**

- Abgeschlossene Ausbildung oder Berufserfahrung im Kfz-Bereich – z. B. als Kfz-Mechaniker, Kfz-Mechatroniker oder im automobilen Handel. Genauso willkommen: ausgeprägtes privates Interesse an Fahrzeugen und die Bereitschaft, dich intensiv in Fahrzeugbewertung und Qualitätsprüfung einzuarbeiten.

###

### Was dich bei uns erwartet

- Hybrides Arbeiten: 3 Tage Office, 2 Tage Homeoffice – plus 10 Tage „Work from Anywhere" pro Jahr

- 28 Tage Urlaub

- 2× jährliches Karriere- & Entwicklungsgespräch

- Betriebliche Altersvorsorge mit 20 % Arbeitgeberzuschuss

- Bezahltes Deutschlandticket

- FitX-Mitgliedschaft oder Urban Sports Club-Zuschuss

- Virtual Stock Options – du beteiligst dich am Erfolg

- Moderne IT-Ausstattung für dein tägliches Arbeiten

- Strukturiertes Onboarding mit Buddy-Programm und Social Events

- Gelebte Vielfalt: aktives Frauennetzwerk, Meditations- & Gebetsraum

**Bewirb dich jetzt – dein Lebenslauf reicht.**

Du erfüllst nicht jede Anforderung zu 100 %? Kein Problem. Wenn du gerne führst, Prozesse im Griff hast und Bock auf Autos hast – meld dich.

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
