# Internship AI & Automation - Energy (m/f/d)

Posted: 2026-09-16T21:00:27Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

## 1KOMMA5°

Bei **1KOMMA5°** bauen wir Europas führende Energie-Software-Plattform **“Heartbeat”** und schaffen so ein **virtuelles Kraftwerk**, das Photovoltaik, Stromspeicher, Wärmepumpen und Ladesäulen der Kunden verknüpft und so die Rentabilität vernetzter Kundenanlagen deutlich erhöht. Wir bieten Kunden zudem einen "**One-Stop-Shop"** für den Kauf und die Installation individueller und intelligenter Energie-Systemlösungen, damit jeder Haushalt schnell und professionell klimaneutral wohnen, heizen und mobil sein kann. Gleichzeitig arbeiten wir in unserer Technologie-Sparte an der Weiterentwicklung und dem Ausbau der Heartbeat-Software, um Kunden **weltweit** mit dem Strommarkt zu vernetzen und so immer den **günstigsten und saubersten Stromtarif** anbieten zu können.

Erfahre über unser Product & Tech Team!

**Hast du Lust, die Energierevolution mit uns anzugehen? Dann bewirb dich jetzt und werde Teil unserer Mission!**

## Deine Position

Als Team Energy sind wir Teil des Product und Tech Teams von 1KOMMA5°. Wir arbeiten täglich daran, dass unsere digitalen Produkte tausenden Kund:innen weltweit zur Verfügung stehen. Wir wachsen stark und suchen deshalb weitere Verstärkung! Was zählt ist, dass du motiviert bist, die untenstehende Aufgaben anzugehen, Gas (bzw. Strom) zu geben und eine steile Lernkurve suchst.

- Du übernimmst eigenständig Automatisierungsprojekte - von der Analyse operativer Prozesse bis hin zur Umsetzung

- Dafür durchläufst du selbst unsere operativen Prozesse, damit du die Prozesse, die du automatisierst auf Einzelkunden-Ebene wirklich verstehst

- Dabei arbeitest du mit unserem Process- und Operations-Team zusammen, um Herausforderungen zu verstehen und darauf aufbauend Lösungen mit messbaren Impact zu bauen

- Dafür nutzt du Automatisierungsplattformen (z.B. n8n, Make, Zapier) sowie Coding-Agents um Systeme zu verbinden sowie App-Prototypen zu entwickeln

- Du setzt robuste und skalierbare Datenstrukturen auf und stellst sicher, dass Automatisierungen in unserer Wissensdatenbank dokumentiert sind

- Du evaluierst du eigenständig neue AI-Tools und Automatisierungsplattformen und bringst Vorschläge ein, wie wir Prozesse weiter verbessern und automatisieren können

## Dein Profil

- Du studierst Wirtschaftsinformatik, Informatik, Data Science oder ein vergleichbares Fach – oder bist tech-affin mit nachweisbarer Erfahrung

- Du hast praktische Erfahrung mit Automatisierungsplattformen (z. B. n8n, Make, Zapier)

- Du besitzt eine ausgeprägte hands-on Mentalität und bringst proaktiv Initiativen voran

- Du kannst uns für mindestens 5 Monate und gerne auch länger (Wunsch: 6 Monate) als Praktikant:in unterstützen

- Für diese Stelle ist es unerlässlich, dass du dich wohl damit fühlst fließend auf Deutsch zu kommunizieren (mind. C1 Niveau)

- Du suchst eine steile Lernkurve und bist offen für Feedback - jeder Mensch kann dazulernen, genau dafür wollen wir Raum geben

- Du hast bereits erste Erfahrung in der Energiewirtschaft? Super! Du bist noch Rookie in der Branche? Kein Problem – für uns zählt Motivation und Lernwille!

## Benefits

- Du hast die Möglichkeit in unseren **brandneuen** Büros in der **Hamburger Innenstadt,** **Berlin** &**München** zu arbeiten, mit flexiblen Home-Office Möglichkeiten

- Nutze dein **technisches Equipment** auch abseits der Arbeit in deiner **Freizeit**

- Du bist Teil eines **schnell wachsenden Unternehmens** mit viel **Entwicklungspotenzi** **al**, wo du **eigenständig** etwas aufbauen kannst und deinen Impact spürst

- Bewege dich in **flachen Hierarchien**, übernimm schon während deiner Einarbeitung **Verantwortung** und arbeite direkt mit Teilen des Managements zusammen

- Mit deiner Arbeit unterstützt du den Megatrend **“Energie- und Mobilitätswende”** und leistest einen **konkreten Beitrag** zum **nachhaltigen** Umbau unserer Energie-Infrastruktur

- Sei aktiv und nutze das Angebot von über 7.600 Sportpartnern mit dem **EGYM-Wellpass**

- Profitiere von **Benefits & Rabatten** durch Futurebens

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
