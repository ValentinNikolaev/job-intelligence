# Praktikant Inventory & Strategic Operations (m/w/d)

Posted: 2026-09-16T20:55:07Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

130.000 Fahrzeuge im Jahr. Sechs Länder. Hinter jeder Transaktion stecken Fahrzeugbewertungen, Kapazitätsplanung und Routenoptimierung, Prozesse, die bei CarOnSale gerade aktiv skaliert werden. Als Praktikant in Strategic Operations begleitest du diesen Aufbau von innen: echte Daten, echte Entscheidungsgrundlagen, KI-Tools im Einsatz. Kein Case.

**Standort:** Zentral in Berlin – Hybrid, 3 Tage Office, 2 Tage Homeoffice.

**Dauer:** 5 bis 6 Monate, Vollzeit. **Start:** nach Vereinbarung.

###

### Über uns

CarOnSale ist die KI-gestützte Plattform für den B2B-Gebrauchtwagenhandel in Europa. Über 40.000 Käufer aus mehr als 20 Ländern handeln auf unserer Plattform – und 85 % des Inventars ist exklusiv bei uns. Wir verbinden Software, Pricing-Intelligenz, Logistik und Finanzierung in einer Schicht – als Betriebssystem für eine ganze Branche.

***One Platform. One Profit Engine.***

###

### Deine Aufgaben

- **Prozessoptimierung:** Du unterstützt die Weiterentwicklung unserer Inspection- und Dispatching-Prozesse und hilfst, sie effizienter und skalierbarer zu machen.

- **Datenbasierte Analyse:** Du unterstützt bei der Analyse bestehender Abläufe, etwa Routeneffizienz, Termin-Auslastung und Qualitätsraten, und hilfst, Verbesserungsmaßnahmen abzuleiten.

- **KI und Automatisierung:** Du lernst unsere KI-Tools kennen und wirkst beim Aufbau von Automatisierungen und Agents mit, die echte operative Probleme lösen.

- **Reporting:** Du hilfst beim Erstellen von Präsentationen und Reportings, mit denen Performance-Kennzahlen und strategische Initiativen ans Management gehen.

- **Teamarbeit:** Du arbeitest eng mit Team-Leads, Disponenten und dem Ops-Management zusammen und begleitest laufende Projekte.

###

### Was du mitbringst

**Must-have**

- Studium in BWL, Wirtschaftswissenschaften, (Wirtschafts-)Ingenieurwesen, Logistik, Data oder einem verwandten Bereich, oder Abschluss bereits in der Tasche

- Analytisches und strukturiertes Denken kombiniert mit einer Hands-on-Mentalität

- Sicherer Umgang mit Zahlen und Daten; Excel und PowerPoint sind selbstverständlich

- KI-affine Arbeitsweise, du nutzt Tools wie Claude, ChatGPT oder Gemini aktiv im Alltag

- Deutsch C1 und Englisch C1, beide Sprachen gehören zum Arbeitsalltag

**Nice to have**

- Erste Erfahrung im Consulting, Business Development, Operations oder einem datengetriebenen Umfeld

- SQL oder erste Erfahrung mit BI-Tools

- Interesse an oder Erfahrung mit der Automobilbranche

###

### Was dich bei uns erwartet

- Strukturiertes Onboarding mit Buddy-Programm

- Regelmäßige Feedbackzyklen

- Frisches Obst und Getränke im Büro

- Laptop für mobiles Arbeiten

- Gelebte Vielfalt: aktives Frauennetzwerk, Meditations- & Gebetsraum

Wir besetzen aktuell mehrere Praktika im Operations-Umfeld. Wenn sich im Gespräch zeigt, dass ein anderer Bereich besser zu dir passt, sprechen wir darüber.

**Bewirb dich jetzt – dein Lebenslauf reicht.**

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
