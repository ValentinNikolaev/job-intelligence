# Kalkulator (m/w/d) - Tiefbau - mit moderner Software 75k-105k

Posted: 2026-09-16T20:20:05Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Keine Lust mehr darauf, LV-Massen mühsam von Hand zu ermitteln, unter ständigem Fristendruck zu kalkulieren und Nachträge zu schreiben, die keiner wertschätzt?

Wie wäre es stattdessen mit digitalen Aufmaßen, moderner Software und einem Team, das Deine Arbeit anerkennt?

Dann freuen wir uns auf Deine Bewerbung als Kalkulator (m/w/d)!

Folgende Benefits erwarten Dich:

- Digitale Aufmaße und moderne Kalkulationssoftware

- Überdurchschnittliches Gehalt (75k-105k) mit Erfolgsprämien für erfolgreiche Projekte

- Betriebliche Altersvorsorge oder vermögenswirksame Leistungen

- Firmenwagen zur privaten Nutzung oder Mobilitätsbudget

- 30 Urlaubstage und verlässliche Einsatzplanung

- Flexible Arbeitszeiten und Homeoffice für den Bürotag

- Realistische Fristen und faire Auslastung

- Überwiegend Bürotätigkeit mit Homeoffice-Anteil

Folgende Aufgaben erwarten Dich:

- Kalkulation von Tief-, Straßen- und Ingenieurbauprojekten

- Erstellung von Leistungsverzeichnissen und Mengenermittlungen

- Einholung und Auswertung von Nachunternehmer- und Lieferantenangeboten

- Erstellung von Angebots- und Auftragskalkulationen

- Mitwirkung bei Vergabeverhandlungen und Nachtragskalkulation

- Abstimmung mit Projektleitung und Einkauf

Das bringst Du mit:

- Studium Bauingenieurwesen oder Ausbildung als Bautechniker

- Erfahrung in der Kalkulation im Tief-/Ingenieurbau

- Sicherer Umgang mit Kalkulationssoftware (z. B. iTWO, RIB, Nevaris)

- Analytisches Denken, Sorgfalt und Kostenbewusstsein

- Sehr gute Deutschkenntnisse (mind. C1)

Interesse geweckt?

Dann freuen wir uns riesig, Dich nach Deiner Bewerbung kennenlernen zu -----

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
