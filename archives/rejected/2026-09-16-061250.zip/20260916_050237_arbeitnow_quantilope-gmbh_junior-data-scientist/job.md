# (Junior) Data Scientist

Posted: 2026-09-15T23:09:26Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**Introduction:**

At quantilope, we're transforming how the world's biggest brands understand their customers. As a (Junior) Data Scientist, you'll collaborate closely with Product Managers, Product Designers, and Software Engineers to build and evolve our AI-powered consumer insights platform. From developing agentic AI assistants and advanced analytics to creating innovative research tools usable by non-technical users — you'll be at the heart of scaling a sophisticated platform that puts automated, AI-powered insights into the hands of researchers and brands worldwide.

We are looking for a (Junior) Data Scientist who delivers production-grade results to high standards, who combines a passion for the latest AI technologies with the engineering discipline to ship them reliably, and who brings analytical and creative problem-solving to new challenges.

**What you will be doing:**

- You design and build agentic AI systems using frameworks like Pydantic AI, including tool registries, prompt engineering, grounding strategies, and orchestration of LLM-based workflows across multiple AI-powered products

- You closely collaborate with cross-functional teams to understand business requirements, translate them into technical specifications, and work with engineers to integrate AI and Data Science features into our platform

- You automate data analytics and insights visualizations that are applicable and interpretable by non-technical users, helping researchers and brand managers work with advanced methods without needing technical expertise

- You automate the application of advanced market research methods that are easy to use while being statistically and scientifically valid

- You build and ship machine learning models (supervised, unsupervised, LLM-based) end-to-end — from prototyping and training to production deployment in our platform

- You contribute to our AI observability and evaluation practices, working with tools like Langfuse and inspect-ai to monitor, trace, and continuously improve our AI systems in production

- You stay up-to-date with the latest advancements in AI, LLMs, and agentic architectures, incorporate them into your work, and proactively share insights and opportunities with colleagues

**Who you are:**

- You have a university degree in Computer Science, Artificial Intelligence, Statistics, Mathematics, Economics or a related relevant field

- You have at least one year of professional experience in Data Science and AI building production-grade products

- You have production-level experience building agentic AI systems or LLM-powered applications, including prompt engineering, tool-use patterns, retrieval-augmented generation (RAG), or similar approaches

- You have strong programming skills in Python and proficiency with relevant frameworks and libraries (e.g., FastAPI, Pydantic/Pydantic AI, Pytest, Pandas, NumPy, scikit-learn) as well as experience with LLM integration (Azure OpenAI, Anthropic, or similar providers)

- You have experience in the software industry including delivering high-quality, scalable services via APIs to production

- You write clean, well-tested, and maintainable code — you're comfortable working in a professional codebase with code reviews, automated testing (e.g., Pytest), and CI/CD practices

- You are an excellent and creative problem solver who is comfortable with ambiguity and change and who is curious to learn new tools, technologies, and domains

- You are fluent in English with excellent communication skills — including the ability to explain complex technical concepts to non-technical audiences and to work effectively in cross-functional teams

**Nice to have:**

- Familiarity with cloud-based infrastructure for software deployment (Kubernetes, Helm) and AI observability tooling (Langfuse, LLM tracing)

- Experience in or passion for the area of market research, marketing, or consumer insights

**Benefits of working at quantilope: **

- Flexible work environment: With flexible PTO, flexible working hours and remote/hybrid opportunities, we believe you can succeed from anywhere. Did we mention that everyone has the opportunity to work abroad for up to 6 weeks per year?

- Ongoing learning: With our dedicated learning budget for every employee and company-wide workshops with the best in the biz, we believe in providing our employees with all the tools they need to excel.

- Wellness is key: We offer Private Health Insurance & Pension plan options as well as the support of certified mental health first aiders. We also have Quantiwell days which are global mental health days twice a year where the whole company takes a day for themselves.

- Diverse & inclusive community: Our team spans the globe, driving diverse ways of working and thinking. With the help of an incredible Community Committee, we are committed to advancing education and awareness.

- Team bonding: Team offsites, summer and holiday parties? We’re all working hard and know how important it is to have fun along the way.

#DNI

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
