# Risk Strategist - Screening (Financial Crimes)

Posted: 2026-07-23T07:02:10Z

## Rejection

- Category: stale
- Reason: published_at 2026-07-23T07:02:10Z is older than 7 days

**Headquarters:** US-Chicago; US-Atlanta; US-Remote; Canada-Toronto; Canada-Remote

## Who we are

### About Stripe

Stripe is a financial infrastructure platform for businesses. Millions of companies—from the world's largest enterprises to the most ambitious startups—use Stripe to accept payments, grow their revenue, and accelerate new business opportunities. Our mission is to increase the GDP of the internet, and we have a staggering amount of work ahead. That means you have an unprecedented opportunity to put the global economy within everyone's reach while doing the most important work of your career.

### About the team

The Financial Crimes Risk Strategy team owns our first-line AML and sanctions programs globally. We own the end-to-end lifecycle of financial crime controls. We set the global standards that govern how risk is managed across our programs, design and drive the development of controls, infrastructure, and tooling with Engineering, Product, and Data Science, and maintain their effectiveness as our products and the regulatory landscape evolve. We build fast, with data, and with AI integrated into how financial crime risk is detected, managed, and monitored across everything Stripe builds.

## What you'll do

As a Risk Strategist on the Financial Crimes Risk Strategy team, you'll own our global screening programs — spanning sanctions, PEP, and negative news — setting the standards that govern how screening risk is managed, designing and driving the controls that operationalize those standards, and ensuring they remain effective as our products and the regulatory landscape evolve. Being effective in this role means going deep on both the domain and the data — we don't separate the two.

You'll partner closely with Product, Engineering, Data Science, Compliance, Legal, other Risk Strategy functions, and Operations to ensure screening considerations are embedded in every product and market decision. Beyond protecting against risk, you'll drive innovation in how Stripe approaches screening — staying ahead of regulatory change and pushing the boundaries of what effective, scalable financial crime risk management looks like at a global payments company.

### Responsibilities

- Lead our global sanctions and AML screening strategy — setting the standards that drive screening control design and infrastructure development, and translating requirements across OFAC, EU, UN, OFSI, and other applicable regimes, PEP screening, and negative news screening into actionable first-line programs and controls

- Own the design and ongoing improvement of financial crime controls — including sanctions screening, PEP screening, negative news screening, and digital asset-related safeguards — while continuously improving detection coverage and control performance as our products and the threat landscape evolve

- Embed screening risk requirements into product and infrastructure roadmaps — ensuring financial crime considerations drive product launches, market expansions, and platform decisions across Product, Engineering, Data Science, Compliance, Legal, and Operations

- Drive screening infrastructure and tooling forward by owning requirements, leading execution, and maintaining effectiveness metrics for screening systems and controls — building with observability by design and ensuring key performance indicators, key risk indicators, and monitoring thresholds are defined from inception

- Continuously assess and improve screening controls and systems — identifying gaps, recommending enhancements that strengthen detection effectiveness and anticipate regulatory or ecosystem changes, and leading delivery of those enhancements end-to-end

- Champion a technology-forward approach to financial crime risk management — leveraging AI tools, self-serve data analytics, and model governance best practices to improve how risk is detected, monitored, and managed at Stripe

- Stay informed on industry practices and regulatory developments and represent our sanctions and AML programs to regulators, bank and network partners, and external auditors

## Who you are

We're looking for someone who meets the minimum requirements to be considered for the role. If you meet these requirements, you are encouraged to apply. The preferred qualifications are a bonus, not a requirement.

### Minimum requirements

- 7+ years of professional experience in financial services, payments, or fintech, with at least 5 years in a related role (risk, compliance, or product enablement)

- Deep subject matter expertise in global sanctions compliance, including hands-on experience with OFAC, EU sanctions regimes, UN Security Council designations, OFSI, and other major global frameworks

- Demonstrated strong understanding of screening program design and control execution

- Strong AML screening expertise — proven ability to design, implement, and operationalize PEP screening and negative news screening programs in complex, multi-jurisdiction environments

- Proven ability to design, implement, and operationalize financial crime standards and controls in complex, global organizations

- Familiarity with model governance concepts — including model documentation, performance monitoring, and validation — and experience leading or contributing to model governance activities

### Preferred qualifications

- Experience leading transformative AML, Sanctions, or Transaction Monitoring initiatives, including global screening program design or transformations (e.g., vendor selection, watchlist management, false positive tuning)

- Proficiency with SQL and ability to independently mine and analyze data to develop risk insights and inform strategy

- Experience with crypto or digital asset products and their associated financial crime risk and regulatory considerations

- Advanced degree or professional certifications (e.g., CAMS, CGSS, CFCS)

**To apply:** [https://weworkremotely.com/remote-jobs/stripe-risk-strategist-screening-financial-crimes](https://weworkremotely.com/remote-jobs/stripe-risk-strategist-screening-financial-crimes)
