# Senior Account Executive

Posted: 2026-08-22T05:55:05Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

## **About Black Forest Labs**

We’re the team behind Latent Diffusion, Stable Diffusion, and FLUX—foundational technologies that changed how the world creates images and video. We’re creating the generative models that power how people make images and video—tools used by millions of creators, developers, and businesses worldwide. Our FLUX models are among the most advanced in the world, and we’re just getting started.

Headquartered in Freiburg, Germany with a growing presence in San Francisco, we’re scaling fast while staying true to what makes us different: research excellence, open science, and building technology that expands human creativity.

## **Why This Role**

Our models are already seeing strong inbound demand, and we’re expanding our commercial team to accelerate adoption across enterprise and strategic partners.

We’re looking for someone who can translate deep technical interest into durable, long-term partnerships especially across complex, non-standard engagements involving APIs, on-prem deployments, and custom licensing.

This role owns the end-to-end commercial journey, working closely with research, engineering, and leadership to help customers move confidently from evaluation to production.

## **What You’ll Work On**

- Own the full sales cycle from discovery through close and expansion across startups, scaleups, and enterprises

- Run complex, multi-stakeholder deals involving technical buyers, executives, and legal teams

- Design and execute sales motions across APIs, on-prem deployments, and custom licensing

- Build durable customer relationships that drive retention and long-term expansion

- Partner closely with solutions engineering, forward-deployed engineers, product, research, and legal on bespoke deals

- Translate customer needs and market signals into actionable feedback for product and research

- Help define early commercial processes, playbooks, and qualification frameworks as we scale

## **What We’re Looking For**

You’ve closed real, technically complex B2B deals and know how to operate without a playbook.

You bring strong judgment navigating long sales cycles, highly competitive environments with ambiguous requirements, and evolving products, and you’re comfortable working cross-functionally to get deals done the right way, not just quickly.

**You'll likely have:**

- Experience selling technical products to tech executives, ML teams, and enterprise stakeholders

- Ability to discuss model capabilities, inference requirements, and integration tradeoffs with technical buyers

- Proven success managing long, multi-stakeholder sales cycles and closing strategic landmark deals

- Strong negotiation skills across pricing, licensing, and custom commercial terms

- Track record building and scaling pipelines across different deal sizes and customer types

- Comfort shaping process and structure in fast-moving, early-stage environments

## **How We Work Together**

We’re a distributed team with real offices that people actually use. Depending on your role, you’ll either join us in Freiburg or SF at least 2 days a week (or one full week every other week), or work remotely with a monthly in-person week to stay connected. We’ll cover reasonable travel costs to make this possible. We think in-person time matters, and we’ve structured things to make it accessible to all. We’ll discuss what this will look like for the role during our interview process.

**Everything we do is grounded in four values:**

- **Obsessed.** We are a frontier research lab. The science has to be right, the understanding deep, the product beautiful.

- **Low Ego.** The work speaks. The best idea wins, no matter who said it. Credit is shared. Nobody is above any task.

- **Bold.** We take the ambitious bet. We ship, we do not wait for conditions to be perfect.

- **Kind.** People over politics. We treat each other with genuine warmth. Agency without empathy creates chaos.

If this sounds like work you’d enjoy, we’d love to hear from you.

**Base Annual Salary:**

**EU **€150,000 - €185,000 + variable + equity

**US **$180,000 - $210,000 USD + variable + equity

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
