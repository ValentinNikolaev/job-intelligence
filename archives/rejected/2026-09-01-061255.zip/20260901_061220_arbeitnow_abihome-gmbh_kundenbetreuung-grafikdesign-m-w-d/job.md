# Kundenbetreuung & Grafikdesign (m/w/d)

Posted: 2026-08-31T19:00:25Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Gradoo ist ein junges, wachsendes Unternehmen rund um Schulzeit, Abschluss und Schulmerch. Wir begleiten Schüler:innen und Schulen von der ersten Idee bis zum fertigen Produkt. Dabei verbinden wir kreative Ideen, digitale Lösungen und persönliche Betreuung und machen aus individuellen Vorstellungen echte Produkte.

## Aufgaben

- Du begleitest unsere Kund*innen im gesamten Prozess eigenständig. Vom Erstkontakt über die Angebotserstellung bis hin zum Vertragsabschluss

- Du berätst und schulst unsere Kund*innen zu Gestaltungsmöglichkeiten, Produkten und Abläufen

- Motiverstellung (vom ersten Kundenbriefing bis zur Reinzeichnung)

- Erstellung von Layouts zu verschiedenen Themen

- Erstellen von Ansichten, Grafiken, Katalogen und Zeitschriften

- Mitgestaltung von Merchandise- und Textildesigns

- Du bringst eigene Ideen ein und entwickelst unsere Prozesse, Vorlagen und Designs aktiv mit

## Qualifikation

- Du kommunizierst gerne und sicher im direkten Kundenkontakt, ob im Team, per Telefon oder WhatsApp

- Du bist engagiert, selbstständig und motiviert und hast Freude an eigenverantwortlichem Kundenmanagement

- Du beherrschst die Adobe Programme (Illustrator, InDesign, Photoshop und Acrobat) und hast Canva Erfahrung

- Du hast ein ausgeprägtes Gespür für Design und ein gutes Auge für Details

- Du bringst Interesse oder idealerweise Erfahrung im Bereich Merch/Textilien mit

- Du hast Lust, dich in neue und moderne KI-Tools einzuarbeiten

- Du verfügst über eine Berufsausbildung im Bereich Grafik bzw. Mediengestaltung

- Du hast eine Hands-on-Mentalität und möchtest aktiv mitentwickeln statt nur umzusetzen

- Du hast Lust auf einen Job, der spannende und abwechslungsreiche Aufgaben in einem sich immer weiterentwickelnden Umfeld bietet

## Benefits

- Die Chance und das Vertrauen, die Entwicklung des Unternehmens mit eigenen Ideen aktiv mitzugestalten

- kurze Entscheidungswege, flache Hierarchien und ein wertschätzendes Arbeitsklima

- Homeoffice-Möglichkeiten

- Weiterentwicklungsmöglichkeiten passend zu deinen Stärken

- Flexible Arbeitszeiten und eigenverantwortliches Arbeiten

Klingt gut? Dann schick uns deine Bewerbung.

Wir freuen uns auf Dich!

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
