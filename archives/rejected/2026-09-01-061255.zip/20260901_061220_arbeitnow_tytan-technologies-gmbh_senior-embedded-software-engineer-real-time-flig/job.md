# Senior Embedded Software Engineer – Real-Time Flight Software (m/f/d)

Posted: 2026-08-31T17:30:04Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

### TYTAN Technologies

At **TYTAN**, we aim to set a global standard in autonomous air defense with AI-driven, cost-efficient systems that counter unmanned aerial threats at scale. We protect people. We protect critical infrastructure. We protect Europe’s sovereignty.

We are looking for a Senior Embedded Software Engineer to own the real-time domain of our next-generation mission computer. Our platform is built around a modern heterogeneous multi-core Arm SoC with separate application and real-time processing domains. You will bring an open-source flight stack to life on the real-time core, take the platform from first boot to flight test, and set the standard for flight-critical firmware at TYTAN — working hand in hand with our in-house electronics and hardware team.

### **Your roadmap to make an impact**

-

Port and adapt an open-source flight stack to the real-time core of our next-generation mission computer, from bootloader to flight test.

-

Own real-time-domain bring-up: startup code, clocking and power states, peripheral drivers (UART, SPI, I2C, CAN), watchdogs and fault handling Design and implement the inter-processor communication between the real-time and Linux domains: transports, message contracts, time synchronization, degradation behavior.

-

Integrate flight-critical buses and sensor peripherals across the vehicle's avionics network.

-

Drive verification from day one: SIL/HIL test setups, automated on-target tests, flight-log analysis together with our GNC and flight-test engineers.

-

Define coding, review and testing standards for flight-critical firmware (static analysis, CI, traceability).

-

Work closely with our in-house hardware team: review schematics and pin multiplexing from the firmware perspective, support board bring-up and debugging in the lab.

-

Degree in Computer Science, Electrical Engineering, Embedded Systems or a comparable qualification.

-

5+ years of professional embedded C/C++ development.

-

Strong real-time operating system experience (e.g. NuttX, Zephyr, FreeRTOS), including board bring-up on new silicon.

-

Hands-on experience with heterogeneous multi-core SoCs and asymmetric multiprocessing (e.g. RPMsg / OpenAMP or comparable inter-core mechanisms).

-

Solid knowledge of embedded buses and protocols: CAN / CAN-FD, UART, SPI, I2C.

-

Experience with UAV flight stacks (e.g. PX4, ArduPilot) and related protocols (e.g. MAVLink, DroneCAN) is a strong plus.

-

Confident with JTAG/SWD debuggers, logic analyzers and oscilloscopes; able to read schematics and work at the hardware/software boundary.

-

A structured, safety-minded engineer who takes ownership from requirements to flight test - Fluent in English, German is beneficial.

### **Why TYTAN?**

-

**Build technology with real operational impact:** Develop autonomous defence systems designed to protect lives and strengthen Europe’s security

-

**Shape scalable defence capabilities:** Work on solutions built for mass deployment, cost efficiency, resilience, and reliable production at scale

-

**Contribute to networked air defence:** Help integrate our systems into multi-layered defence architectures alongside sensors, command systems, and effectors

-

**Develop for real-world operations:** Build capabilities together with end users and improve them continuously based on direct operational feedback

-

**Move fast and take ownership:** Work in a focused, high-performance team where decisions are made quickly and individual contributions have immediate impact

-

**Define a new generation of defence technology:** Join early and help shape the products, engineering standards, culture, and direction of a fast-growing deep-tech company

-

**Work with an international mission-driven team:** Collaborate with experienced specialists united by the goal of creating sovereign and effective security capabilities for Europe

###

### **Our Benefits**

-

**Virtual stock options:** Participate in our success through Virtual stock options (VSOPs) at the company's current valuation

-

**Monthly allowances: **€106/month in flexible benefits including lunch discounts and EGYM Wellpass or shopping credit

-

**Regular health care events:** Health check-ups, skin screenings, mental health workshops, and an annual vitamin infusion on us

-

**Referral bonus: **Earn a reward when someone you refer joins the team

-

**Regular team events: **On- and off-site activities to connect and celebrate together

-

**Corporate discounts:** Exclusive employee discounts across a wide range of partner brands

-

**Flexibility**: Flexible working hours and hybrid work model, plus a modern Munich office built for focus and collaboration

### About us

At TYTAN, it is more than just a job; it is about embracing autonomy, personal growth, and purpose. Make a lasting impact in the new era of defense! Join us to create a safer world for all.

WE are an equal-opportunity employer committed to fairness and inclusivity. We do not prioritize any specific religion, gender, nationality, or background. Due to security clearance requirements, affiliations with countries listed under § 13 para. 1 no. 17 SÜG may affect the application process. **Please note that we currently do not offer visa sponsorship, so we’re only able to consider candidates who already have a valid work permit. All qualified applicants are hereby encouraged to apply.**

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
