# Founders Associate (m/f/d) - start in September 2026

Posted: 2026-08-31T17:40:11Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**About the Role at RobCo**

RobCo is building the category of Autonomous Industrial Robotics and we're doing it fast. We believe that automating the ordinary frees humans to do the extraordinary, and we're building the end-to-end robotics infrastructure to make that possible - hardware, software, and AI in one stack that just works.

At RobCo, we automate the ordinary, so humans can do the extraordinary. To achieve this, we are looking for an ambitious Founders Associate (m/f/d) to help us establish RobCo as leading provider of automation solutions.

As our Founders Associate, you work side by side with Roman, our CEO and co-founder, and report directly to him. You take the topics highest on his agenda and see them through, working across whichever teams and sites they touch: a critical customer meeting, a board presentation, a new market we are entering, a partner initiative, a process that needs rebuilding as we scale. Expect several of them in parallel, and expect them to arrive before they have a team.

This role is a springboard, one of the best places in the company to learn a lot in a short time and grow into a strong operator. Within 18 to 24 months you will know RobCo deeply, commercially, operationally and technically, and that will open strong opportunities across the company as we grow.

The target** **start date for this role is September 2026.

**Your Responsibilities**

-

Execute the CEO's top projects and initiatives. Take the two or three most critical ones and deliver them end to end: understand what is really going on, turn his direction into a concrete plan, bring the right people together, and stay on it until it works.

-

Prepare and support critical investor, customer and leadership sessions and follow up on what was agreed.

-

Turn initiatives into progress on the ground. With the teams, at customer sites, and in our production environments.

-

Run several workstreams at once. Deciding where your attention goes each day is part of the job.

-

Step in when something slows down. Get involved early, find the actual bottleneck, and clear it with the owners.

-

Make what you solve stick. Clear workstreams, named owners, a working rhythm, honest progress tracking, early warning when something is at risk - plus the KPIs, dashboards and playbooks that keep the same topic from coming back in six months.

**We're looking for someone who has:**

-

2 to 5 years in a fast-paced environment - Investment banking, VC/PE, top-tier consulting, or an operating role in a well funded startup (Founders Associate, BizOps, Chief of Staff, GTM Ops).

-

A degree in Business Administration, Economics, Engineering, or comparable experience.

-

A clear bias for action: you prefer a good decision today over a perfect one next month, you commit once a direction is set, and you close the loop without being reminded.

-

Structure in ambiguity: you can take a loosely defined problem, break it down, and come back within days with a plan and the first step already done.

-

The ability to move people across teams without formal authority, through preparation, reliability, follow-through, and credibility with senior stakeholders.

-

A strong analytical toolkit and an AI-native way of working: advanced Excel and Sheets, confidence handling data yourself, and fluency with tools like Notion, Claude and Google Workspace.

-

Strong storylining, slide writing and communication skills to get your message across.

-

Willingness to work fully onsite at our Munich office and to travel regularly to customer sites and to our US locations in Austin and San Francisco. Being close to the team, to Roman and to our production environments matters in this role.

-

Very good English skills are required, German is a plus.

**Why join RobCo?**

-

Develop modular, software-defined robotics solutions with us that set new standards in automation.

-

Help us build robots equipped with state-of-the-art AI that perceive their environment, analyze data, and make intelligent decisions in real time.

-

As part of a very dynamic and fast-growing scale-up, you will take on responsibility from day one, drive your own projects, and see the direct impact of your work.

-

Flat hierarchies, open communication, and regular 360° feedback enable fast decisions and support your professional and personal development.

-

Wellpass membership (7,200+ studios across Germany), regular team events, and a team that takes both the work and the culture seriously.

-

Flexible working hours, a modern office, and - depending on the role - the option to work from home.

-

Regular team events - from relaxed beer & pizza nights on the rooftop terrace to shared experiences on ski trips or at Oktoberfest.

**About RobCo**

Founded in Munich in 2020, RobCo leads the transition toward fully Autonomous Industrial Robotics. Our mission is to deploy RobCo in every factory - solving the industrial labor shortage through end-to-end robotics that just works. Powered by Physical AI, our solutions combine a scalable modular hardware architecture with intelligent software that adapts to your use case, improves over time, and requires zero upfront investment through our Robotics-as-a-Service (RaaS) model.

We solve our customers' most pressing pain points - labor shortage, cost pressure, workplace safety, and national reshoring - across the full spectrum of Autonomous Industrial Robotics. With $160M raised from investors including Lightspeed, Lingotto Innovation, and Sequoia, 200+ people globally, and 2.5M+ operating hours in the field, we are deploying robots in factories across Europe and the United States - with our US operations headquartered in Austin, TX, and our RobCo Bay Area Demo Lab in San Francisco.

*Don’t meet every single requirement? If you’re excited about this role but your past experience doesn’t align perfectly with every qualification in the job description, we encourage you to apply anyway. You may be just the right candidate for this or other roles.*

*At RobCo, applicants are selected regardless of ethnic origin, religion, gender, age, disability, or sexual orientation. All decisions throughout the recruitment process are based solely on applicants’ qualifications, skills, knowledge, and experience, as well as relevant business requirements.*

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
