# QA Software Test Automation Engineers (Java)

Posted: 2026-08-31T20:04:06Z

## Rejection

- Category: role_mismatch
- Reason: title is an obvious mismatch for a backend profile

**The Role:**

Our team is expanding and we are hiring several high caliber QA Software Test Automation Engineers (Java) to join our fast-growing team. You will work with world class specialists in a friendly, supportive and open-minded environment on challenging goals that will help you to grow professionally and achieve new technical levels. This role will focus on improving and monitoring product quality via test automation framework development and test coverage extension for functional and performance suits.

**The main responsibilities of the position include:**

- Closely collaborate with the development team to help deliver high quality software

- Understand and translate business requirements to technical requirements

- Enhance software delivery and quality throughout the entire Software Development Life Cycle

- Perform automated functional and performance testing

- Design and develop the test automation framework, implement required libraries, and conduct auto-tests

- Maintain CI pipelines and integrate automated scripts into CI tools

- Manage any issues that may arise and drive resolutions throughout the testing process

- Actively participate in the Software Development Life Cycle and Software Testing Life Cycle

**Main requirements:**

- BSc/MSc in Computer Science

- Minimum 2 years’ experience in quality assurance and test automation (functional GUI and API)

- Practical experience in automation testing with Java (Selenium, REST Assured, or similar for mobile automation) is a must

- Experience in writing queries for SQL and NoSQL databases

- Experience in agile software development methodologies and testing procedures

- Strong interpersonal and organisational skills

- Committed to excellence, continuous improvement, and to achieving the best results

- Excellent written and verbal skills in English

**Benefit from:**

- Attractive remuneration package

- Intellectually stimulating work environment

- Continuous personal development and international training opportunities

**The Hiring Experience: What Awaits You**

- Let’s Connect – Intro Chat with Talent Acquisition

- Deep Dive – First Interview with Your Future Team

- Final Connection – Final Interview

**All applications will be treated with strict confidentiality!**

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
