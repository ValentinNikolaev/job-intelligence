# Graphic Designer (m/f/x)

Posted: 2026-08-31T18:00:24Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Angefangen hat alles vor sieben Jahren als ambitionierte Idee. Heute sind wir Marktführer für Abschlusszeitungen in Deutschland. Jedes Jahr nutzen mehr als zwei Drittel aller deutschen Abschlussjahrgänge die nuggit App, um ihre Abschlusszeitung und ihre Abschlusstextilien zu gestalten und sich damit eine Erinnerung an eine gemeinsame Zeit zu schaffen, die bleibt.

**Unsere Mission:** Durch digitale Innovation und persönlichen Kundenkontakt sind wir für SchülerInnen der verlässliche Partner bei ihrem allerersten großen Projekt. Dafür hinterfragen wir permanent den Status Quo und entwickeln neue, kreative Lösungen.

Wir sind ein kleines Team mit sehr großer Reichweite. Als **Graphic Designer (m/w/d)** verantwortest du unser operatives Design: Print, Textil und die Assets, die täglich rausgehen. Das heißt kurze Wege, direkte Sichtbarkeit deiner Arbeit und viel Verantwortung. Es heißt aber auch, dass du eigenständig arbeiten und priorisieren musst. Für spezifische Projekte arbeiten wir bei Bedarf mit externen ExpertInnen zusammen.

## Aufgaben

- **Print:** Du gestaltest Abschlusszeitungen für über zwei Drittel aller Schulen in Deutschland und setzt damit den Qualitätsmaßstab für den gesamten Markt.

- **Textil:** Wir bauen unser Textilgeschäft gerade neu auf. Du gestaltest Kollektionen, Prints und Motive und prägst, wie nuggit auf Hoodies und Shirts aussieht.

- **Vorlagen und Templates:** Du entwickelst die Design-Vorlagen weiter, mit denen zehntausende SchülerInnen in der nuggit App selbst gestalten. Sauber und produktionssicher.

- **Produkt:** Gemeinsam mit unserem Product-Team verbesserst du die Layout- und Gestaltungsmöglichkeiten innerhalb der App und bringst die Design-Perspektive genau dort ein, wo unsere NutzerInnen arbeiten.

- **Internationalisierung:** Wir bereiten den Schritt über Deutschland hinaus vor. Du denkst Layouts so, dass sie auch in anderen Märkten tragen.

**So arbeiten wir**

- **Figma ist unser Zuhause.** Wir arbeiten mit einem eigenen internen Setup, in das wir dich einarbeiten. Wenn du strukturiert arbeitest statt jede Datei neu zu erfinden, wirst du dich hier sofort wohlfühlen. Wie das bei uns konkret aussieht, zeigen wir dir im Prozess.

- **AI ersetzt dich nicht, sie hebelt deine Arbeit.** Wir nutzen AI aktiv im Design-Prozess: für Ideation, Varianten und die Automatisierung wiederkehrender Schritte. Du musst kein Prompt-Profi sein, aber du solltest Lust haben herauszufinden, was damit geht.

- **Eigeninitiative ist Pflicht, nicht Bonus.** Du bekommst Ziele und Kontext, den Weg gestaltest du selbst. Niemand verteilt dir Tickets und niemand treibt dich an.

- **Hybrid, ehrlich gemeint.** Unser neues Office liegt im Mindspace in der Uhlandstraße 32, direkt am Kudamm und bestens angebunden, mit allen Annehmlichkeiten eines Coworking Space. Alle weiteren Mindspace Standorte kannst du temporär mitnutzen. Homeoffice und mobiles Arbeiten sind selbstverständlich möglich, solange das Ergebnis stimmt.

## Qualifikation

- Du hast bereits Berufserfahrung als Graphic Designer gesammelt. Ob das zwei Jahre oder fünf sind, interessiert uns weniger als das, was du zeigen kannst.

- Du arbeitest sicher in Figma und hältst deine Dateien so, dass auch andere damit arbeiten können.

- Du hast ein solides Verständnis für Druckvorstufe und Print-Produktion. Textilerfahrung ist ein Plus, aber kein Muss.

- Du bist neugierig auf AI im Design-Workflow und probierst gerne aus, statt abzuwarten.

- Du organisierst dich selbst und priorisierst eigenständig. In einem Umfeld ohne feste Design-Hierarchie zu arbeiten, reizt dich, statt dich zu verunsichern.

- Du lieferst zuverlässig, auch wenn viel gleichzeitig läuft. Unsere Saison hat klare Peaks.

- Kreatives, kritisches und lösungsorientiertes Denken ist bei dir Standard.

- Du sprichst fließend Deutsch. Das ist bei uns Voraussetzung, weil unsere Zielgruppe und ein großer Teil unserer Designs deutschsprachig sind. Gutes Englisch ist ein Plus.

- Du hast eine proaktive Haltung und arbeitest gerne eng mit anderen Teams zusammen.

## Benefits

Unser Angebot

- Sieh, wie deine Designs jedes Jahr über 200.000 Mal gedruckt, verschickt und getragen werden

- Vielfältige Projekte von Print über Textil bis App-Layout

- Ein kleines Team, das Design ernst nimmt und immer offen für neue kreative Ideen ist

- Zusammenarbeit mit externen ExpertInnen, wenn ein Projekt es braucht

- Voller Zugriff auf moderne AI-Tools und die Zeit, dich darin richtig gut zu machen

- Kurze Wege und offene Ohren: Ideen landen bei uns direkt beim Entscheider, ohne Zwischenebenen

- Ein Gehalt von bis zu 45.000 EUR brutto im Jahr. Wir schneiden die Stelle nach der Person: Was du am Ende mitbringst, entscheidet über Zuschnitt und Einstufung.

Die perfekte Bewerberin oder den perfekten Bewerber gibt es nicht. Wir freuen uns auf deine Bewerbung, auch wenn du die Anforderungen (noch) nicht zu 100 % erfüllst, du aber die Motivation mitbringst, dir die nötigen Fähigkeiten anzueignen. Wir begrüßen BewerberInnen verschiedenster Hintergründe, ungeachtet ihrer Geschlechtsidentität, Religion, Ethnizität, nationaler Herkunft, sexuellen Orientierung, Migrationsgeschichte, Alter oder Einschränkungen.

Bitte bewirb dich ausschließlich über folgenden Link:

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
