# Tech Lead - E-Commerce (f/m/d)

Posted: 2026-08-31T17:30:03Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

kfzteile24 is Germany's leading digital company for car parts and automotive equipment. As a Berlin-based multichannel company, we own successful online shops like kfzteile24.de, autoteile24.de, and carpardoo in multiple European countries. We are Germany's best-known brand in the online aftermarket. With expert advice, a wide range of products and fast, reliable deliveries, we ensure individual mobility for our customers.

As a **Tech Lead – E-Commerce (f/m/d)**, you will own the technical direction of a cross-functional engineering team at the heart of our e-commerce platform. Your services power the customer journeys that millions of users depend on — from product discovery to checkout. You will define architecture, drive quality standards, and translate product ambitions into robust, scalable systems built on Java, Spring Boot, and Vue.js. Beyond the codebase, you will shape how your team engineers: establishing Spec Driven Development as a daily practice, setting guardrails for AI-assisted workflows, and developing engineers who think in systems — not just features. At kfzteile24, technical leadership means taking end-to-end ownership: of the code, the team, and the impact.

####
What we offer

-

Permanent employment contract and 30 days vacation

-

Possibility of home office 3 days a week

-

Internal and external training opportunities

-

Up to 50% employee discount in our branches and workshops

-

Various health and sport offers (e.g. Bike-Leasing, screen glasses / monitor glasses (VDU))

-

Additional benefits such as language courses via Babbel, company pension plan, corporate benefits

#### Your responsibility

-

**Own the Technical Direction:** Define the architecture and technical vision for your team's services within our e-commerce platform (Java, Spring Boot, Vue.js). Make decisions, reduce technical debt, and keep the codebase healthy and future-proof.

-

**Drive Agentic Engineering:** Pioneer Spec Driven Development in daily engineering workflows. Establish quality gates and review standards for AI-generated code.

-

**Build and Grow the Team:** Shape processes, rituals, and culture for your team. Mentor engineers through code reviews, pairing, and technical guidance. Coordinate with adjacent product teams across the e-commerce domain. Foster a quality mindset.

-

**Deliver Business Impact:** Collaborate closely with Product and UX to continuously improve customer journeys and conversion. Enable data-driven decisions through A/B testing and experimentation.

-

**Ship:** Take end-to-end responsibility for the team's delivery and operational stability.

#### Your skills

-

5+ years of professional software development, with a track record of delivering complex, high-performance web applications at scale

-

Hands-on technical leadership experience - guiding decisions, coordinating implementation and developing engineers

-

Strong coding skills across a modern e-commerce stack - Java on the backend, JavaScript (VueJS, Angular or React) on the frontend, paired with a fullstack mindset.

-

You have built or owned features in at least two core e-commerce domains - checkout, payments, routing, product listings, search, order management or similar - and understand what makes them hard at scale.

-

You build with AI. Tools like Claude Code or GitHub Copilot are part of your daily workflow, and you have opinions on what they do well, where they fail, and how to set up the right guardrails.

-

You think in systems - across services, domains, and team boundaries. You make architectural trade-offs with the long view in mind, communicate them clearly to engineers and stakeholders, and bring people along.

-

Proficiency in English required. German is a strong plus - internal communication is a mix of both

#### Bonus Skills

-

Experience with cloud services (AWS), monitoring (New Relic, OpenTelemetry), infrastructure-as-code (Terraform)

-

Event-driven architectures, distributed systems, and observability at scale

-

Experience with (technical) SEO / GEO

#### Apply now!

If you would like to be part of our motivated IT team, apply now for the position with us as **Tech Lead - E-Commerce (f/m/d)**, stating your salary expectations and your earliest starting date. If you have any questions, please contact **Irina Ring **at** +49 1520 315 4804.**

Please note that we only consider applications via our online portal. Applications by post or e-mail will not be considered and deleted.

For more information on data processing, see our [data protection declaration](https://kfzteile24.recruitee.com/datenschutzerklarung).

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
