# Embedded Software Engineer (m/f/d)

Posted: 2026-08-31T17:30:04Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

### TYTAN Technologies

At **TYTAN**, we aim to set a global standard in autonomous air defense with AI-driven, cost-efficient systems that counter unmanned aerial threats at scale. We protect people. We protect critical infrastructure. We protect Europe’s sovereignty.

We are looking for an Embedded Software Engineer to strengthen our firmware team across today's flying systems and our next-generation platform. You will work on what flies now, our custom flight-controller setup and the firmware of our microcontroller based subsystem boards and grow into our next-generation mission computer as it comes to life, working as part of our firmware team hand in hand with our in-house hardware team.

### Your Roadmap to Make an Impact

-

Develop and maintain firmware for our microcontroller based subsystem boards (sensor, interface, power and actuation electronics): peripheral drivers, bootloaders, bus protocols.

-

Extend and tune our custom flight-controller setup: device drivers, parameters and vehicle configuration, integration of new sensors and payloads.

-

Integrate sensors and peripherals across the vehicle: CAN-based avionics devices, SPI/I2C/UART sensors and telemetry plumbing.

-

Contribute to the next-generation mission computer across its real-time (RTOS) and Linux domains.

-

Build and maintain the test backbone: CI pipelines, hardware-in-the-loop setups, automated on-target tests, flight-log tooling.

-

Support board bring-up and debugging in the lab together with our in-house hardware team, and participate in integration and flight-test campaigns.

-

Write the documentation and test protocols that keep a growing firmware landscape maintainable.

-

Degree in Computer Science, Electrical Engineering, Embedded Systems or a comparable qualification.

-

1–3 years of professional experience in embedded C/C++ microcontrollers (strong graduates with relevant project work are welcome.

-

Working knowledge of an RTOS (e.g. FreeRTOS, Zephyr, NuttX) or bare-metal firmware; embedded Linux exposure and the motivation to grow into both domains.

-

Familiarity with common embedded buses (UART, SPI, I2C, CAN) and debugging tools (JTAG/SWD, logic analyzer, oscilloscope).

-

Hands-on experience with PX4 or ArduPilot (drivers, parameters, vehicle bring-up) is a strong plus.

-

Drones, RC aircraft or robotics as a student team, competition or serious hobby is a strong plus.

-

Solid Git workflow; experience with CI and Python-based tooling is a plus.

-

A hands-on, fast-learning team player who wants ownership early.

-

Fluent in English, German is beneficial.

### **Why TYTAN?**

-

**Build technology with real operational impact:** Develop autonomous defence systems designed to protect lives and strengthen Europe’s security

-

**Shape scalable defence capabilities:** Work on solutions built for mass deployment, cost efficiency, resilience, and reliable production at scale

-

**Contribute to networked air defence:** Help integrate our systems into multi-layered defence architectures alongside sensors, command systems, and effectors

-

**Develop for real-world operations:** Build capabilities together with end users and improve them continuously based on direct operational feedback

-

**Move fast and take ownership:** Work in a focused, high-performance team where decisions are made quickly and individual contributions have immediate impact

-

**Define a new generation of defence technology:** Join early and help shape the products, engineering standards, culture, and direction of a fast-growing deep-tech company

-

**Work with an international mission-driven team:** Collaborate with experienced specialists united by the goal of creating sovereign and effective security capabilities for Europe

###

### **Our Benefits**

-

**Virtual stock options:** Participate in our success through Virtual stock options (VSOPs) at the company's current valuation

-

**Monthly allowances: **€106/month in flexible benefits including lunch discounts and EGYM Wellpass or shopping credit

-

**Regular health care events:** Health check-ups, skin screenings, mental health workshops, and an annual vitamin infusion on us

-

**Referral bonus: **Earn a reward when someone you refer joins the team

-

**Regular team events: **On- and off-site activities to connect and celebrate together

-

**Corporate discounts:** Exclusive employee discounts across a wide range of partner brands

-

**Flexibility**: Flexible working hours and hybrid work model, plus a modern Munich office built for focus and collaboration

### About us

At TYTAN, it is more than just a job; it is about embracing autonomy, personal growth, and purpose. Make a lasting impact in the new era of defense! Join us to create a safer world for all.

WE are an equal-opportunity employer committed to fairness and inclusivity. We do not prioritize any specific religion, gender, nationality, or background. Due to security clearance requirements, affiliations with countries listed under § 13 para. 1 no. 17 SÜG may affect the application process.

**Please note that we currently do not offer visa sponsorship, so we’re only able to consider candidates who already have a valid work permit. All qualified applicants are hereby encouraged to apply.**

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
