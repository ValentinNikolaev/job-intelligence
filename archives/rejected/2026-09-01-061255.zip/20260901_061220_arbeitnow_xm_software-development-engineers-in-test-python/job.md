# Software Development Engineers in Test (Python)

Posted: 2026-08-31T20:04:06Z

## Rejection

- Category: tech_stack
- Reason: role does not mention Go/Golang or PHP

**The Role:**

Our team is expanding and we are hiring several high caliber SDET (Software Development Engineer in Test) - Python to join our fast-growing team. You will work with world class specialists in a friendly, supportive and open-minded environment on challenging goals that will help you to grow professionally and achieve new technical levels. This role will focus on improving and monitoring product quality via test automation framework development and test coverage extension for functional and performance suits. You will work with the most valuable part of the product - a Forex brokerage core. If you enjoy working with pure API, Python, cutting-edge technologies, Kafka and AWS, this role is for you.

**The main responsibilities of the position include:**

- Work in close cooperation with the development team to enhance software delivery and quality throughout the entire software development cycle

- Understand and translate high level business requirements to technical requirements

- Advise on efficient performance testing strategies for enhancing delivery and quality throughout the full software development cycle

- Develop formal test procedures and test plans from internal product design documentation as well as from external certification requirements

- Design, develop and modify functional and performance automation tests

- Design and implement test automation framework, required libraries and auto-tests

- Develop emulators for mobile testing

- Build CI/CD pipelines and integrate automation scripts into CI tools

- Manage any issues that may arise and drive resolutions throughout the testing process

- Share technical expertise with the rest of the QA team

- Actively participate in the Software Development Life Cycle and Software Testing Life Cycle

**Main requirements:**

- BSc/MSc in Computer Science, Software Engineering or similar

- Minimum 2 years of comprehensive experience in quality assurance

- Minimum 2 years of practical experience in Python development

- Strong hands-on experience in designing and developing automated tests using Python

- Strong technical background

- Experience in testing REST API

- Confident knowledge of Git

- Experience in agile software development methodologies and testing procedures

- Strong interpersonal skills

- Very good written and verbal skills in English

**The following will be considered an advantage:**

- Experience with testing framework development

- Experience with asynchronous and multithreading programming

- Experience in testing web sockets

- Experience with Docker

- Experience with Grafana

- Experience in performance testing

- Experience in the Finance/Forex domain

**Benefit from:**

- Attractive remuneration package plus performance related reward

- Intellectually stimulating work environment

- Continuous personal development and international training opportunities

**The Hiring Experience: What Awaits You**

- Let’s Connect – Intro Chat with Talent Acquisition

- Deep Dive – First Interview with Your Future Team

- Final Connection – Final Interview

**All applications will be treated with strict confidentiality!**

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
