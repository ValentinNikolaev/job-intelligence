# Senior Embedded Software Engineer – Embedded Linux Platform (m/f/d)

Posted: 2026-08-31T17:30:04Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

### TYTAN Technologies

At **TYTAN**, we aim to set a global standard in autonomous air defense with AI-driven, cost-efficient systems that counter unmanned aerial threats at scale. We protect people. We protect critical infrastructure. We protect Europe’s sovereignty.

We are looking for a Senior Embedded Software Engineer to own the Linux domain of our next-generation mission computer. Our platform is built around a modern heterogeneous multi-core Arm SoC with separate application and real-time processing domains. You will build the embedded Linux platform on the application cores and deliver the onboard capabilities that our autonomy depends on — GNC, vision pipeline, telemetry, payload integration — working hand in hand with several in-house hardware and software teams.

### Your Roadmap to Make an Impact

-

Own the embedded Linux platform on the application cores of our next-generation mission computer: Yocto-based BSP, kernel configuration, device trees, board-specific drivers.

-

Build the onboard capability set: camera and video pipeline, hardware-accelerated vision building blocks, telemetry, and clean integration interfaces for GNC and mission payloads.

-

Implement the Linux side of the inter-processor communication with the real-time domain, including health monitoring, time synchronization and watchdog strategies.

-

Make the platform fleet-ready: secure boot chain, signed image updates, system hardening, fast and deterministic boot.

-

Set up CI with automated on-target testing and hardware-in-the-loop rigs; support integration and flight-test campaigns.

-

Work closely with SoC vendor BSPs and our in-house hardware team during board bring-up and debugging.

-

Mentor engineers across the team on Linux platform topics and establish maintainable platform practices.

-

Degree in Computer Science, Electrical Engineering, Embedded Systems or a comparable qualification.

-

5+ years of professional embedded Linux experience: Yocto or Buildroot, kernel and device-tree work, driver development and debugging on Arm SoCs.

-

Strong C/C++ skills; Python for tooling and test automation.

-

Hands-on experience with heterogeneous multi-core SoCs and enough RTOS understanding to design clean contracts with a real-time domain.

-

Practical experience with camera/video pipelines (e.g. V4L2, GStreamer); ISP tuning and ML deployment on embedded accelerators (e.g. vendor NPU SDKs, TensorRT-class toolchains) are a strong plus.

-

Experience with secure boot, signed updates and embedded security hardening is a strong plus.

-

Experience with UAV flight stacks or companion-computer setups (e.g. PX4, ArduPilot, MAVLink) is a plus.

-

Comfortable in the lab: reading schematics, using scopes and analyzers during bring-up.

-

A pragmatic platform thinker who takes ownership and builds for the long run.

-

Fluent in English, German is beneficial.

### **Why TYTAN?**

-

**Build technology with real operational impact:** Develop autonomous defence systems designed to protect lives and strengthen Europe’s security

-

**Shape scalable defence capabilities:** Work on solutions built for mass deployment, cost efficiency, resilience, and reliable production at scale

-

**Contribute to networked air defence:** Help integrate our systems into multi-layered defence architectures alongside sensors, command systems, and effectors

-

**Develop for real-world operations:** Build capabilities together with end users and improve them continuously based on direct operational feedback

-

**Move fast and take ownership:** Work in a focused, high-performance team where decisions are made quickly and individual contributions have immediate impact

-

**Define a new generation of defence technology:** Join early and help shape the products, engineering standards, culture, and direction of a fast-growing deep-tech company

-

**Work with an international mission-driven team:** Collaborate with experienced specialists united by the goal of creating sovereign and effective security capabilities for Europe

###

### **Our Benefits**

-

**Virtual stock options:** Participate in our success through Virtual stock options (VSOPs) at the company's current valuation

-

**Monthly allowances: **€106/month in flexible benefits including lunch discounts and EGYM Wellpass or shopping credit

-

**Regular health care events:** Health check-ups, skin screenings, mental health workshops, and an annual vitamin infusion on us

-

**Referral bonus: **Earn a reward when someone you refer joins the team

-

**Regular team events: **On- and off-site activities to connect and celebrate together

-

**Corporate discounts:** Exclusive employee discounts across a wide range of partner brands

-

**Flexibility**: Flexible working hours and hybrid work model, plus a modern Munich office built for focus and collaboration

### About us

At TYTAN, it is more than just a job; it is about embracing autonomy, personal growth, and purpose. Make a lasting impact in the new era of defense! Join us to create a safer world for all.

WE are an equal-opportunity employer committed to fairness and inclusivity. We do not prioritize any specific religion, gender, nationality, or background. Due to security clearance requirements, affiliations with countries listed under § 13 para. 1 no. 17 SÜG may affect the application process.

**Please note that we currently do not offer visa sponsorship, so we’re only able to consider candidates who already have a valid work permit. All qualified applicants are hereby encouraged to apply.**

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
