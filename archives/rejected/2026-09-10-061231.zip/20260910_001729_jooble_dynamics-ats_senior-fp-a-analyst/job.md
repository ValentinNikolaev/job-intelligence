# Senior FP&A Analyst

Posted: 2026-09-09T00:00:00.0000000

## Rejection

- Category: tech_stack
- Reason: role does not mention Go/Golang or PHP

...**Senior **FP&A Analyst 

JOB-10047376

Anticipated Start Date 
September 14, 2026

Location 
Houston, TX 

Type of... ...Direct Hire 

Employer Info 
Our client specializes in the **engineering **and fabrication of rig systems, wellbore technologies, and...
