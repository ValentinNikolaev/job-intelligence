# Enterprise Account Executive, Puppet

Posted: 2026-08-06T23:25:15Z

## Rejection

- Category: language_requirement
- Reason: hard German language requirement without English green light

Perforce is a community of collaborative experts, problem solvers, and possibility seekers who believe work should be both challenging and fun. We are proud to inspire creativity, foster belonging, support collaboration, and encourage wellness. At Perforce, you’ll work with and learn from some of the best and brightest in business. Before you know it, you’ll be in the middle of a rewarding career at a company headed in one direction: upward.

 

With a global footprint spanning more than 80 countries and including over 75% of the Fortune 100, Perforce Software, Inc. is trusted by the world’s leading brands to deliver solutions for the toughest challenges. The best run DevOps teams in the world choose Perforce. 

**Position Summary:**

Perforce is searching for an Enterprise Account Executive to join the team. We are looking for an individual who is an experienced, high-energy sales professional with a proven track record of over-achieving quota. You will drive the revenue for new business, services, and renewals, through effective value selling and relationship development at the Director-level and above. You must be well-rounded in all aspects of enterprise account selling, including the ability to create a significant pipeline in a short amount of time, identify business drivers, and have a command of and deliver the Puppet value proposition. You will need to have experience selling software to large enterprise customers in the Germany & CEE markets, and be well-connected to in-region channel partners.

More than 40,000 organizations trust Puppet to innovate through IT infrastructure automation. Puppet helps customers strengthen their security posture, compliance standards, and business resiliency beyond the data center to the cloud.

**Responsibilities :**

- Actively manage current accounts and prospect to develop opportunities in medium and large Fortune 1000 accounts.

- Attainment of quota, quarterly and annually.

- Develop an active and vibrant pipeline, equal to 3x quota.

- Prepare accurate weekly forecasts and reports to sales leadership.

- Maintain current, accurate, and active Salesforce hygiene and have familiarity with MEDDPICC and Command of the Message.

- Ensure the successful rollout and adoption of Puppet Enterprise and related products through strong account management activities and coordination with pre-sales engineering and support resources.

- Develop account-based selling methodologies and closing plans.

- Prospect for new customers in conjunction with our channel partner and SI community.

- Build and strengthen the business relationship with current accounts and new prospects by leveraging the renewal revenue stream and converting to larger, strategic deals for long-term business opportunities.

- Travel as necessary to develop account relationships and close large opportunities.

**Requirements :**

- 4+ years of experience as an enterprise account executive selling into the German & CEE markets.

- Selling software to Fortune 500/1000 accounts with a strong technical acumen, as well as the ability to have a presence with upper management and executives in the accounts.

- Building and executing on a territory plan (Target Account Selling or other sales methodology to ensure you can develop a long-term selling strategy within these large accounts as well as create short-term tactical opportunities.)

- Driving demand for newer products and are skilled at selling professional services.

- Calling on platform, infrastructure, and application development teams at the Director to C-level.

- You have experience selling direct, leveraging the channel and alliance partners to deliver solutions with a proven track record of success.

- Native or professional German language skills are compulsory.

Additionally, this position is eligible for benefits including, but not limited to, medical, dental, vision, retirement benefits, life insurance, wellness programs, and other employee perks that may be offered by Perforce from time to time. The actual offer will depend on a number of factors including, but not limited to, a candidate’s education, skills, qualifications, depth of experience and other relevant business considerations. Perforce reserves the right to amend or modify employee perks and benefits at any time.

*All employees are expected to demonstrate AI fluency appropriate to their role and level, including responsible use of AI tools, sound judgment, and adherence to company AI governance and security policy standards.*

Come work with us! Our team members are valued for their contributions, introduced to new opportunities, and rewarded well. Perforce combines the experience and rewards of a start-up with the security of an established and privately held profitable company.

If you are passionate about the technology that impacts our day-to-day lives and want to work with talented and dedicated people across the globe, apply today!

[**www.perforce.com**](http://www.perforce.com/)

**Please click here for: **[**EOE & Belonging Statements | Perforce Software**](https://www.perforce.com/equal-opportunity-employer-statement)

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
