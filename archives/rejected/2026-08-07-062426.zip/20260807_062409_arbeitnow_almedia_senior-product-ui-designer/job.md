# Senior Product UI Designer

Posted: 2026-08-06T23:40:06Z

## Rejection

- Category: tech_stack
- Reason: role does not mention Go/Golang or PHP

This isn’t your regular job. Almedia is a place where those who want to push harder can accelerate their careers faster than anywhere else. We’re aiming to become Germany’s second bootstrapped unicorn. Almedia is already Europe’s #3 fastest-growing company in 2025 (FT1000).

We are building the future of marketing by rewarding our community of over 70 million users for engaging with our advertisers’ products. We are offering a new way to acquire users for the biggest companies in the world.

## **Senior Product UI Designer **

(€75K – €90K• Offers Equity • Offers Bonus)

At Almedia, you’ll:

-

**Own way more, way earlier** — you’ll be trusted with responsibility fast.

-

**Push harder, get further** — this isn’t a 9–5. We highly reward intensity.

-

**Join a rare environment** — you will work with ambitious high-speed, high-ownership people.

-

**Fully present** — we’re 5 days a week in the office to build the energising momentum we need.

We’re looking for a Senior Product Designer with exceptional visual and interaction design skills to join our team in Berlin. Reporting to the Head of Design, you’ll own end-to-end product experiences, shaping our design strategy and working closely with Product, Engineering, and Data Science. If you thrive in a fast-moving, iterative environment and are passionate about delivering high-quality, user-centric design, we’d love to hear from you.

## **Key Responsibilities 🎯**

-

**Lead UI Design Process:** Own the user interface design from concept to implementation, ensuring designs are visually compelling, intuitive, and aligned with user needs.

-

**Own the Design Process** – Lead design from discovery to implementation, ensuring a balance of speed, quality, and impact.

-

**Collaborate Cross-Functionally** – Work closely with Product, Engineering, and Data** **Science to align design with business goals and technical feasibility.

-

**Validate with Research** – Conduct user research, usability testing, and data analysis to inform and refine design decisions.

-

**Communicate & Lead** – Drive design critiques, stakeholder discussions, and alignment sessions, clearly articulating rationale behind decisions.

## **What You’ll Bring 💡**

-

**5+ years of experience** designing mobile-first products, with a strong portfolio showcasing impactful UI and UX work.

-

**Outstanding visual design skills**, with a keen eye for detail, hierarchy, and accessibility.

-

**Strong communication & collaboration**, effectively working across teams and presenting designs persuasively.

-

**Data-driven mindset**, using research and analytics to guide decisions and measure success.

-

**Bonus:** Experience with motion design and/or gamified elements.

## **What Makes You a Strong Fit 🌟**

-

**Strategic Thinking** – You contribute beyond design, helping shape product direction and ensuring alignment with business objectives.

-

**Fast & Effective** – You thrive in lean, iterative environments, balancing speed with quality.

-

**Technical Awareness** – You understand front-end development (HTML, CSS, JavaScript) and how it impacts design decisions.

-

**Proactive & Impact-Driven** – You take initiative, continuously pushing for better solutions, setting high standards, and driving improvements across the team.

## **Why Almedia? 🚀**

-

**Own Our Growth: **We offer all Berlin-based employees equity in Almedia to truly be a part of our success.

-

**Scale With Almedia: **Grow alongside a startup that has been profitable from day one.

-

**Central Berlin Office: **Work from a fully-stocked modern office built for collaboration, accessible from all around Berlin.

-

**Other Benefits: **Transport subsidy, breakfasts and lunches, language learning, Urban Sports Club, and more.

We believe in fostering talent, evaluating all skill levels during the hiring process, and providing a clear path for growth. Almedia is an equal opportunity employer. We embrace and celebrate diversity, and encourage individuals from all backgrounds to apply.

Compensation: €75K – €90K • Offers Equity

- • €75K – €90K • Offers Equity

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
