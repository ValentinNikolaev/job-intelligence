# Senior Indirect Tax Manager (m/f/d) - Munich based

Posted: 2026-08-06T23:09:47Z

## Rejection

- Category: tech_stack
- Reason: role does not mention Go/Golang or PHP

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
