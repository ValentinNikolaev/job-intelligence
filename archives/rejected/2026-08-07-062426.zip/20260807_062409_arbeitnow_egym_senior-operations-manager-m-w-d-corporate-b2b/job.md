# (Senior) Operations Manager (m/w/d) - Corporate B2B

Posted: 2026-08-06T23:09:47Z

## Rejection

- Category: tech_stack
- Reason: role does not mention Go/Golang or PHP

**Dein tägliches Workout**

Wir lieben, was wir tun und sind davon überzeugt, dass EGYM Wellpass der Gamechanger für Arbeitnehmende ist. Für den B2B-Bereich im Operations-Team in München suchen wir einen passionierten (Senior) Operations Manager - Corporate (m/w/d), der administrative Prozesse steuert und Kundenbeziehungen erfolgreich pflegt. In dieser zentralen Rolle hebst du die operativen Abläufe auf das nächste Level und agierst als strategischer Sparringspartner für die Führungsebene. Neben der Prozessoptimierung begleitest du deine Teammitglieder durch Mentoring und gestaltest die Teamkultur aktiv mit. Willst du Teil unseres hochmotivierten und preisgekrönten Teams sein, das mit Begeisterung an operativen Prozessen arbeitet? Dann bewirb dich jetzt! Give your career a workout!

- Operative Exzellenz & Koordination: Du stellst sicher, dass alle täglichen Abläufe in deinem Subteam termingerecht und in höchster Qualität durchgeführt werden. Dafür koordinierst du das Tagesgeschäft abteilungsübergreifend und priorisierst Aufgaben effizient
- Datenanalyse & Reporting: Du definierst relevante Kennzahlen (KPIs) und entwickelst Monitoringsysteme sowie Dashboards. Auf Basis deiner Analysen leitest du Maßnahmen zur Effizienzsteigerung ab und setzt diese erfolgreich um
- Prozessoptimierung: Du identifizierst Optimierungspotenziale, unterstützt bei der Standardisierung von Tools sowie Prozessen und wirkst an strategischen Projekten mit. Du bist Teil des internen Process Governance Committées, um globale Prozessänderungen voranzutreiben
- Kommunikation & Stakeholder-Management: Du bringst deine Fachexpertise im Austausch mit internen und externen Stakeholdern ein. Dabei stellst du eine zielgruppengerechte Informationsweitergabe sicher und arbeitest eng mit deiner Führungskraft zusammen
- Mitarbeiterentwicklung & Kultur: Du unterstützt deinen Team Lead bei Führungsaufgaben, begleitest das Onboarding neuer Teammitglieder und übernimmst Aufgaben im Mentoring. Du förderst aktiv eine wertschätzende Teamkultur und lebst unsere „Habits“ vor
- Entscheidungskompetenz: Du verantwortest die Ressourcenplanung innerhalb deines Bereichs und fungierst als erste Eskalationsstufe bei fachlichen Fragen

**Dein Fitness Level**

- Qualifikation: Du hast eine kaufmännische Ausbildung, (z. B. Büromanagement), ein abgeschlossenes Studium oder Vergleichbares
- Erfahrung: Mindestens drei Jahre Berufserfahrung im Bereich Operations, Prozessmanagement oder in einer vergleichbaren Schnittstellenfunktion
- Analytische Stärke: Du liebst Daten, beherrschst das Erstellen von Salesforce-Reports sowie die Analyse von Tableau-Dashboards und bist stark in der Ableitung strategischer Maßnahmen
- Projektmanagement-Skills: Du bringst Erfahrungen in der Projektarbeit mit und hast bei der Standardisierung von Prozessen mitgewirkt
- Leadership-Mentalität: Du hast Freude daran Wissen weiterzugeben, Teammitglieder zu fördern und Verantwortung zu übernehmen. Idealerweise bringst du erste Erfahrung in der fachlichen Führung mit
- Kommunikation: Du kannst komplexe Sachverhalte empfängergerecht aufbereiten. Dabei kommunizierst du sowohl schriftlich als auch mündlich auf Englisch (mindestens B2 Niveau) und bringst fließende Deutschkenntnisse mit
- Mindset: Du bist proaktiv, lösungsorientiert und hast eine hohe Eigenmotivation, den Verbesserungsprozess kontinuierlich voranzutreiben. Mit deiner kollegialen Art bereicherst du unser Team und sorgst für eine konstruktive Zusammenarbeit, die uns auch bei komplexen Herausforderungen schnell voranbringt

**Dein Trainingsziel für Deine ersten 6 Monate**

- Selbstständigkeit: Du steuerst die täglichen Abläufe sowie die Ressourcenplanung in deinem Subteam eigenständig und triffst fundierte Entscheidungen als erste fachliche Eskalationsstufe. Auf Basis von datenbasierten KPI-Reportings leitest du gezielte Maßnahmen zur Effizienzsteigerung ab und setzt diese in enger Abstimmung mit deiner Führungskraft erfolgreich um
- Tool- und Prozesswissen: Du beherrschst das Erstellen von Salesforce-Reports sowie die Analyse von Tableau-Dashboards zur Kennzahlenüberwachung und bringst dich aktiv im internen Process Governance Committée ein, um qualifizierte Vorschläge zur Standardisierung globaler Prozesse abzustimmen
- Netzwerk: Du hast dir eine vertrauensvolle Beziehung zum Führungsteam sowie den abteilungsübergreifenden Stakeholdern aufgebaut und bist im Team als fachliche Ansprechperson und Bindeglied zur Führungsebene etabliert

**Unser Trainingsequipment **

- Work-Life-Balance: Genieße 30 Urlaubstage pro Jahr und profitiere von viel Flexibilität durch unseres hybrides Arbeitsmodell (3 Home Office Tage pro Woche möglich)
- Fitness: Halte Dich fit und trainiere mit [EGYM Wellpass](https://egym-wellpass.com/mitarbeitende/) kostenlos in über tausende Sport- und Gesundheitseinrichtungen in ganz Deutschland oder nutze unser Inhouse Fitnessstudio mit allen EGYM Geräten
- Atmosphäre: Genieße die Start-Up Atmosphäre in einem hochmotivierten und sehr interdisziplinären Team
- Flex Budget: Nutze 60€ pro Monat flexibel für öffentliche Verkehrsmittel und Essenszuschuss
- Feedbackkultur: Entwickle Dich durch regelmäßiges Feedback weiter und werde Teil eines Teams, in dem Deine Ideen gehört werden
- Mentoring-Programm: Nutze unsere selbstorganisierte Mentoring-Plattform, um Wissen zu teilen und gemeinsam über Teams und Standorte hinweg zu wachsen
- bAV: Sichere Dich durch unsere attraktive betriebliche Altersvorsorge ab
- Bike Leasing: Tritt in die Pedale und halte Dich durch unser Bike Leasing Angebot fit
- Benefitportal: Nutze eine Vielzahl toller vergünstigter Angebote, von Mode (z.B. bis zu 30% Rabatt auf das Adidas Sortiment) über Freizeit (z.B. vergünstigte Konzert- oder Musicalkarten), in unserem Benefitportal

**Contact Information**

Bitte lade Deine vollständigen Unterlagen (CV, Startdatum und Gehaltswunsch) als PDF unter Angabe der ID #2028 hoch.

Kontaktperson: Jana Fakesch

Für weitere Informationen: [https://career.egym.com/](https://career.egym.com/)

#LI-JF

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
