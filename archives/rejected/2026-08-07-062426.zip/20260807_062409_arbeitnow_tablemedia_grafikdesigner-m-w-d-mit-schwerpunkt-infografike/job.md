# Grafikdesigner (m/w/d) mit Schwerpunkt Infografiken & Datenvisualisierung

Posted: 2026-08-06T23:09:47Z

## Rejection

- Category: language_requirement
- Reason: hard German language requirement without English green light

**Aufgaben  **

Gestaltung mit Haltung, Klarheit und digitalem Gespür:
Zur Verstärkung unseres Marketing-Teams suchen wir bei Table.Briefings eine kreative Persönlichkeit, die Marke, Design und Performance zusammenbringt, als Junior Art Director oder erfahrener Grafikdesigner (m/w/d)

Deine Aufgaben:

- Du gestaltest kanalübergreifende Marketingmaterialien entlang der gesamten Customer Journey
- Du setzt unsere Corporate Identity in Newslettern, Mailings, Social Media, Kampagnen und weiteren Assets konsistent um und entwickelst sie gestalterisch weiter
- Du arbeitest am visuellen Auftritt unserer Website und Nutzerbereiche mit
- Du konzipierst und produzierst performante Social Creatives für LinkedIn, Instagram, Facebook und weitere Kanäle
- Du bringst kreative Ideen für Kampagnen und Formate ins Team ein
- Du arbeitest eng mit Marketing, Redaktion, Tech, Events, Podcast und Geschäftsführung zusammen
- Du sorgst dafür, dass unser Markenauftritt über alle Touchpoints hinweg hochwertig und konsistent bleibt

**Qualifikation**

- Ausbildung oder Studium im Bereich Kommunikationsdesign, Grafikdesign, Mediendesign oder vergleichbar
- Erfahrung in der Gestaltung von Webseiten, Newslettern, Social Ads und digitalen Marketingmaterialien
- Sicheres Gespür für Typografie, Farbwelten, Bildsprache, Markenwirkung und visuelle Klarheit
- Gute Kenntnisse in UI/UX-Prinzipien
- Sehr gute Skills in der Adobe Creative Suite, insbesondere Photoshop; idealerweise auch Erfahrung mit Figma, Canva oder Emplifi
- Fähigkeit, Inhalte auch visuell präzise und verständlich auf den Punkt zu bringen
- Strukturierte, kreative und zuverlässige Arbeitsweise
- Sehr gute Deutschkenntnisse (Englischkenntnisse sind ein Plus)
- Ein Portfolio mit relevanten Arbeitsproben

Warum Table Media?

Weil du bei uns nicht einfach nur Assets produzierst. Du gestaltest die visuelle Kommunikation einer relevanten Medienmarke mit - in einem Umfeld, das journalistischen Anspruch, digitale Dynamik und inhaltliche Tiefe verbindet.

Klingt nach dir?
Dann freuen wir uns auf deine Bewerbung inklusive Portfolio.

**Benefits**

- 28 Tage Urlaub
- Flexible Remote-Office-Möglichkeiten
- Eine unbefristete Festanstellung mit einem herausfordernden und vielseitigen Aufgabengebiet
- Ungekürzte Ausgaben unserer Professional Briefings
- Moderne technische Ausstattung
- Ein Büro in Berlin-Mitte mit dem Flair des Berliner Kult-Cafés Einstein
- Wachstumskultur mit starken persönlichen und beruflichen Entwicklungsmöglichkeiten
- Eine offene und freundliche Atmosphäre mit Partnern und Kollegen aus der ganzen Welt

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
