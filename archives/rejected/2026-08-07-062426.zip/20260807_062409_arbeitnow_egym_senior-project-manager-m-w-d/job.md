# (Senior) Project Manager (m/w/d)

Posted: 2026-08-06T23:09:47Z

## Rejection

- Category: tech_stack
- Reason: role does not mention Go/Golang or PHP

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
