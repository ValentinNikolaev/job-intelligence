# Senior Associate (m/w/d) Zivilrecht, Gesellschaftsrecht | bis 200.000 € | Partnerschaft möglich

Posted: 2026-09-17T13:20:13Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Du hast bereits Erfahrungen im Zivil- und Gesellschaftsrecht gesammelt und möchtest dich nun in einer international tätigen Anwaltssozietät selbstständig machen? Du suchst nach netten Kollegen und einer Kanzlei, die Deine berufliche Entwicklung bis zur Partnerschaft fördert? Dann haben wir die perfekte Stelle für Dich!

Wir suchen für eine Kanzlei in **Berlin** eine/n **Senior Associate /** **Rechtsanwalt (m/w/d) mit Berufserfahrung** im Bereich **Zivilrecht und Gesellschaftsrecht**.

## **Die Kanzlei bietet Dir:**

-

eine **hochattraktive Vergütung bis 200.000 €**, je nach passender Berufserfahrung, Mandantenkreis oder Einstiegsposition

-

**persönlichen Freiraum** sowie viel Eigenverantwortung in der Mandatsbearbeitung

-

vielfältige **Entwicklungsmöglichkeiten** auf persönlicher, fachlicher und internationaler Ebene

-

eine langfristige Entwicklungsperspektive bis hin zu einer **Partnerschaft**

-

ein wertschätzendes **Miteinander** und einen starken Zusammenhalt in einer kollegialen Arbeitsatmosphäre

-

eine **aktive Mitgestaltung** und Weiterentwicklung des Praxisbereichs Zivil- und Gesellschaftsrecht

## **Dein Profil:**

-

Du hast Deine Staatsexamen überdurchschnittlich mit jeweils mind. acht Punkten abgeschlossen

-

Du konntest bereits **mind. 5 Jahre Berufserfahrung **im allgemeinen Zivilrecht sowie im Handels- und Gesellschaftsrecht sammeln

-

Du besitzt verhandlungssichere Englischkenntnisse

## **Deine Aufgaben:**

-

Du begleitest nationale und grenzüberschreitende Private-Equity-Transaktionen, einschließlich Buy-outs (LBOs/MBOs), Exits und Co-Investments

-

Du übernimmst eigenständig die Mandatsführung sowie den Ausbau langfristiger Mandantenbeziehungen als Senior Associate (m/w/d) oder Partner (m/w/d)

-

Die Führung und strategische Begleitung wirtschaftsrechtlicher Gerichts- und Schiedsverfahren fällt in deinen Aufgabensbereich

-

Du begleitest gesellschaftsrechtliche Transaktionen, Umstrukturierungen und Reorganisationen

###

### **Wie geht es weiter?**

Eine umfangreiche Bewerbung ist bei uns nicht erforderlich: Trage einfach Deine Kontaktdaten und Deinen Lebenslauf in das Formular ein.

In einem lockeren Kennenlern-Gespräch schilderst Du uns Deine Wünsche und Erwartungen. Wir erzählen dir mehr von dieser Karrierechance und prüfen dann gemeinsam, ob die Stelle für Dich passt.

### **Wer sind wir?**

Die Lawgentur ist der Recruiting-Partner für Recht- und Steuerprofis.

Als Karriereberater helfen wir Juristen, Steuerprofis, ReFas, NoFas und Business Professionals, die besten Jobs im Recht- und Steuerbereich zu finden.

Als Agentur unterstützen wir Kanzleien & Unternehmen, attraktive Arbeitsbedingungen zu bieten und eine hohe Mitarbeiterzufriedenheit zu erreichen.

Wir stehen für Recruiting mit Werten und bringen passende Talente zu den besten Arbeitgebern. Bist Du dabei?

Kontaktiere uns noch heute, um mehr über Deine neuen Karrieremöglichkeiten zu erfahren. Wir freuen uns darauf, Dich persönlich kennenzulernen!

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
