# Head of Operations & Service - Dosimetry

Posted: 2026-09-17T13:00:50Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**General Mission**

Reporting to the Business Unit President, the **Head of Operations & Service** is responsible for defining and executing the global operations strategy to support the growth, profitability and customer satisfaction objectives of the Dosimetry business. The role ensures the effective management of worldwide manufacturing, supply chain, order fulfillment and customer service activities, while building a resilient and scalable operational model. As a member of the Dosimetry leadership team, the position works closely with the Radiotherapy (RT) and Medical Imaging (MI) Business line, Finance, R&D, Quality and Regulatory Affairs, Business Unit President and People function to align operational priorities with business needs.

## Tasks

- Lead and continuously optimize worldwide manufacturing and supply chain operations across production sites in the United States, Germany and China, ensuring reliable product availability, operational efficiency and business continuity.

- Define the long-term manufacturing footprint and sourcing strategy, including make-versus-buy decisions, component manufacturing approaches, and production site allocation.

- Partner with Finance and MI – RT Business Lines to align demand forecasts, production planning and delivery commitments, ensuring accurate capacity planning and execution.

- Lead global customer service organizations across the United States, Germany, India and China, ensuring a seamless customer experience and responsive support across all regions.

- Oversee end-to-end order fulfillment processes from order intake to delivery, driving operational excellence, process standardization, and continuous improvement. Establish a performance-driven culture through the use of operational metrics, effective governance, and cross-functional collaboration.

- Build, develop and lead international teams, fostering accountability, collaboration and engagement.

- Ensure compliance with company policies, quality standards, regulatory requirements and health and safety guidelines.

- Support and promote IBA values while contributing to the achievement of the overall Dosimetry business strategy.

## Requirements

- Strategic mindset with the ability to translate business objectives into operational strategy

- Strong leadership and people management skills in an international and multicultural environment

- Expertise in manufacturing, supply chain, customer service and operations management

- Business acumen with strong understanding of forecasting, planning and financial drivers

- Customer-centric approach with a focus on service excellence

- Ability to drive operational excellence and continuous improvement

- Strong decision-making and problem-solving capabilities

- Influencing and stakeholder management skills across functions and geographies

- Ability to manage complexity, balance priorities and deliver results

- Accountability and ownership with a strong focus on execution and outcomes

- Fluent in English and German language

## Benefits

Diverse and challenging tasks / personal responsibility and teamwork / international and dynamic team / regular internal and external training - development and coaching / flexible working hours and home office / healthy breakfast and team events / a remuneration system that rewards your success/ 30 vacation days

Please apply directly online with salary expectation and start day.

Please note that we only accept online applications. Written application documents sent nevertheless will not be included in the application process and will not be returned.

Thank you for your understanding!

If you have any questions, please turn to Onyinye Nfiaji directly in LinkedIn.

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
