# Shop Manager TikTok Shop DACH (m/f/d)

Posted: 2026-09-17T12:30:28Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

## Your mission

**We’re looking for you!**

TikTok Shop is changing the way people shop online – and you can be part of it from the very beginning.

GENUINE is one of Germany’s leading TikTok Shop partners, and we’re looking for a **Shop Manager (m/f/d)** to join our team in Cologne. You’ll own the operational performance of some of our most important TikTok Shops – making sure prices are live, campaigns are registered, ads are running, stock is available, and every shop is set up to grow.

Your mission: **turn commercial strategy into flawless execution.** You’ll work closely with our Growth and Creator teams, manage everything happening inside Seller Center, and use performance and profitability data to identify the next growth opportunities.

Join one of Europe’s most sought-after TikTok Shop agencies and take ownership of the engine behind high-performing TikTok Shops.

- **Shop Ownership:** You take operational ownership of a selection of our core TikTok Shops – ensuring pricing, promotions, campaigns, listings, stock, and overall shop health are always on track.

- **Pricing & Promotions:** You implement pricing and promotional strategies in Seller Center and identify the best mechanics – from platform coupons and flash deals to product discounts, bundles, and campaign entries.

- **Campaign Management:** You register products and shops for TikTok campaigns, deals, and platform programs, ensuring deadlines and eligibility requirements are met.

- **Performance & Profitability:** You analyze performance at product, campaign, and account level – understanding what drives GMV, what actually generates margin, and where the next growth opportunity sits.

- **Ads & Boosting:** You set up and optimize TikTok Shop ad campaigns, manage budgets and bidding, and boost high-performing creator content and creator live streams.

- **Stock & Forecasting:** You monitor inventory and forecast demand based on promotions, campaigns, and creator activity – identifying potential out-of-stock risks before they impact performance.

- **Shop Health:** You monitor ratings, fulfillment, service indicators, and platform violations, taking action before issues affect shop performance.

- **Growth Opportunities:** You turn data into action – identifying underpriced SKUs, untapped campaign opportunities, categories with additional potential, and new TikTok Shop features worth adopting.

## Your profile

- Initial experience in **e-commerce, marketplace management, performance marketing, commercial operations, or account management** – ideally in a fast-paced environment.

- You’re highly analytical and comfortable working with **KPIs, profitability, pricing, and performance data** – but you also know how to turn insights into action.

- Strong commercial understanding: You understand how **pricing, discounts, advertising, stock, and promotions** interact and impact both GMV and profitability.

- You’re operationally strong and detail-oriented: deadlines, campaign registrations, pricing changes, and shop health metrics don’t slip through the cracks.

- You enjoy taking ownership and working cross-functionally with **Growth Managers, Creator Managers, and external partners**.

- Experience with **TikTok Shop, Seller Center, marketplaces, or social commerce** is a strong plus.

- Good English skills for internal communication; additional European languages are a plus.

## Why us?

## Why us?

- **Make an Impact:** Flat hierarchies and short decision-making processes – your ideas don’t get stuck in endless approval rounds. They get put into action.

- **Day-One Mentality:** We move fast. You’ll join an international, high-energy team where ideas don’t get stuck in meetings – they get executed.

- **Real Growth:** Build expertise in some of the most in-demand areas of digital marketing right now – creators, e-commerce, and live shopping.

- **Strong Team:** International, fast-paced, and open-minded – we work hard, and we make sure to have fun while doing it.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
