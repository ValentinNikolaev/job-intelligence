# Geschäftsleitungsassistenz mit Schwerpunkt im Personalbereich (m/w/d)

Posted: 2026-09-17T13:30:32Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Wir stellen ein!

**Sie

haben Freude an Personalthemen, behalten auch bei unterschiedlichen

Aufgaben den Überblick und arbeiten gerne nah an Mitarbeitenden und

Führungskräften?**

Zur Verstärkung unseres Teams suchen wir eine **Geschäftsleitungsassistenz mit Schwerpunkt im Personalbereich (m/w/d) in Teil- oder Vollzeit (30–40 Std./Woche).**

Sie

erwartet eine vielseitige Position mit Verantwortung, kurzen

Abstimmungswegen und einem abwechslungsreichen Arbeitsalltag. Dabei

verbinden Sie Ihre organisatorischen Fähigkeiten mit einem sicheren

Gespür für Menschen und unterstützen uns dort, wo Struktur,

Verlässlichkeit und eine gute Kommunikation gefragt sind.

## Aufgaben

Darum geht's: Aufgaben und Verantwortung

**Assistenz der Geschäftsbereichsleitung/Geschäftsführung**

- Laufende organisatorisch-technische Unterstützung

- Koordination und Organisation von Terminen und Kalendern

- Organisation und Abrechnung von Geschäftsreisen

- Vor- und Nachbereitung von Besprechungen und Sitzungen einschließlich Protokollführung

- Erstellung und Aufbereitung von Präsentationen, Berichten, Briefings und weiteren Unterlagen

- Unterstützung bei der internen und externen Korrespondenz

- Übernahme weiterer organisatorischer, administrativer und projektbezogener Aufgaben

**Schwerpunkt Personalwesen**

- Eigenständige

Betreuung und Administration des Personalwesens sowie zentrale

Ansprechperson für Mitarbeitende in personalrelevanten Fragestellungen

- Steuerung

und Begleitung des gesamten Recruiting-Prozesses von der Erstellung und

Veröffentlichung von Stellenausschreibungen über das Bewerbermanagement

bis zur Koordination des Auswahlprozesses

- Planung und Koordination des On- und Offboardings

- Vorbereitung

der monatlichen Lohn- und Gehaltsabrechnung sowie zentrale

Schnittstelle zur externen Lohnbuchhaltung, digitale

Personaladministration und Pflege des HR-Managementsystems

- Koordination von Maßnahmen zur Personalentwicklung, Weiterbildung und Mitarbeiterbindung

- Weiterentwicklung, Standardisierung und Optimierung bestehender HR-Prozesse

## Qualifikation

Das suchen wir: Erfahrungen und Skills

Abgeschlossene

kaufmännische Ausbildung, idealerweise mit Zusatzqualifikation im

Personalwesen, oder ein Studium mit Schwerpunkt Personal/BWL bzw. eine

vergleichbare Qualifikation

- Fundierte Berufserfahrung im Personalwesen und gute Kenntnisse in der operativen Personalarbeit

- Gute Kenntnisse im Arbeitsrecht und Sicherheit im Umgang mit personalrelevanten Fragestellungen

- Erfahrung in der vorbereitenden Lohn- und Gehaltsabrechnung sowie in der Zusammenarbeit mit externen Abrechnungsstellen

- Sicherer Umgang mit digitalen HR-Managementsystemen und eine hohe IT-Affinität

- Selbstständige, strukturierte und zuverlässige Arbeitsweise sowie ausgeprägtes Organisationsvermögen

- Kommunikationsstärke und ein professioneller, serviceorientierter Umgang mit Führungskräften und Mitarbeitenden

- Hohes Verantwortungsbewusstsein, absolute Diskretion und Loyalität

## Benefits

Das bieten wir

Flexible Arbeitszeiten und die Möglichkeit, regelmäßig mobil zu arbeiten.

- Eine Position in Teil- oder Vollzeit mit individuellem Arbeitszeitumfang.

- Viel Raum für eigenverantwortliches Arbeiten und die Möglichkeit, Prozesse aktiv mitzugestalten.

- Direkte Zusammenarbeit mit der Geschäftsleitung und enger Austausch mit unseren Führungskräften.

- Eine vielseitige Position an der Schnittstelle zwischen Personalwesen, Organisation und Geschäftsleitung.

- Möglichkeiten zur fachlichen und persönlichen Weiterbildung.

**Na, Lust bekommen?**

Dann

bewirb dich und werde Teil unseres Teams! Wir freuen uns auf deine

Bewerbung unter Angabe deines frühestmöglichen Eintrittstermins und

deiner Gehaltsvorstellung.

Sende uns deine Unterlagen an uns per Mail.

Übrigens:

Die GLC Glücksburg Consulting AG ist seit mehr als 30 Jahren

erfolgreich in der Tourismusbranche tätig. Vom Spreewald über die

Lutherstadt Wittenberg und den Harz bis hin zur Nord- und Ostseeküste

sind wir an vielfältigen Standorten aktiv – oft dort, wo andere Urlaub

machen.

Hinter

diesen Projekten stehen Menschen, Organisation und verlässliche

Strukturen. Und genau hier kommst du ins Spiel: Unterstütze uns im

Personalbereich und in der Geschäftsleitungsassistenz und gestalte

gemeinsam mit uns die weitere Entwicklung der GLC.

**Wir freuen uns darauf, dich kennenzulernen!**

Über uns

Die

GLC Glücksburg Consulting AG ist seit über 30 Jahren erfolgreicher

Projektmanager und -umsetzer für den Mittelstand und öffentliche

Auftraggeber. Ob Tourismus, IT oder Unternehmensfinanzierung - unsere

Projekte umfassen eine Vielzahl spannender Branchen und Fachbereiche und

bieten ausgesprochen gute Karriereperspektiven.

Über alle

Standorte und Fachbereiche leben wir dabei den Teamzusammenhalt und sind

der festen Überzeugung, dass wir als interdisziplinäres Team gemeinsam

mehr erreichen! Dabei haben wir stets das gemeinsame Ziel im Blick und

geben unseren Mitarbeitenden viel Raum, eigene Ideen einzubringen und

umzusetzen. Kundenorientiert und schnell zu handeln, ist unser

Erfolgsgeheimnis.

Du hast Lust, an Bord zu kommen? Unser fröhliches und energiegeladenes Team aus etwa 150 Köpfen freut sich schon auf Dich!

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
