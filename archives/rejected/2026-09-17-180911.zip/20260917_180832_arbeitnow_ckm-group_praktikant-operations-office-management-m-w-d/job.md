# Praktikant Operations & Office Management (m/w/d)

Posted: 2026-09-17T12:30:29Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

## Intro

Zur gehören eine Vielzahl von Unternehmen sowie eine Klinik, die alle dazu beitragen, unserer Vision von einer gesünderen Welt näher zu kommen.

Unser Ziel ist es, durch präventive Dienstleistungsmedizin, eHealth und Public Health eine führende und wegweisende Rolle im Gesundheitssystem von morgen einzunehmen. Dabei setzen wir auf smarte Logistik, Digitalisierung, Diagnostik und individuelle Prävention. Wir denken Gesundheitsversorgung und Diagnostik neu und hinterfragen dazu stets den Status Quo.

Ein neuer Pfeiler dieser Vision ist : Mit unserem telemedizinischen Service bieten wir einen einfachen und sicheren Zugang zu medizinischem Cannabis, um Symptome zu lindern und die Lebensqualität zu verbessern. Darüber hinaus unterstützen wir Patienten bereits heute mit modernen Lösungen zur medizinisch begleiteten Gewichtsreduktion. Perspektivisch planen wir, unser Angebot um weitere Präventions- und Gesundheitsleistungen zu erweitern, um noch mehr Menschen individuell auf ihrem Weg zu mehr Gesundheit und Lebensqualität zu begleiten.

Du hast Lust, im Tagesgeschäft eines wachsenden Unternehmens mit anzupacken, behältst auch bei vielen Themen gleichzeitig den Überblick und hast Spaß daran, sowohl im direkten Kundenkontakt als auch hinter den Kulissen für einen reibungslosen Ablauf zu sorgen? Dann unterstütze uns im Operations & Office Management im Rahmen eines **6-monatiges Praktikums**!

## Deine Mission bei uns

- **Support:** Du bearbeitest, verfolgst nach und löst Support-Tickets unserer Kund:innen und behältst dabei stets einen freundlichen, lösungsorientierten Ton.

- **Reklamationsmanagement:** Du entscheidest über Rückerstattungen und Reklamationen inkl. Kulanzentscheidungen und kommunizierst diese souverän per E-Mail und Telefon.

- **Dienstleistersteuerung:** Du steuerst externe Dienstleister, sichtest und vergleichst Angebote und behältst dabei Kosten und Qualität im Blick.

- **Büromaterial & Ausstattung:** Du kümmerst dich um Einkäufe für Büromaterial und -ausstattung und sorgst dafür, dass im Büro alles vorhanden ist, was das Team braucht.

- **Bürogestaltung:** Du gestaltest und „eventisierst" unser Büro und bringst eigene Ideen ein, um daraus einen Ort zu machen, an dem sich das Team wohlfühlt.

- **Operations-Projekte:** Du übernimmst projektbezogene Operations-Aufgaben und unterstützt so dabei, Unternehmen und Abteilung weiter voranzubringen.

## Was du mitbringen solltest

- **Sprachen:** Du kommunizierst stark und sicher, schriftlich wie mündlich – auf Deutsch (muttersprachlich) und Englisch (C1).

- **Organisationstalent:** Du bist organisiert, behältst auch bei mehreren Themen gleichzeitig den Überblick und hast ein hohes Pflichtbewusstsein.

- **Auffassungsgabe:** Du hast eine schnelle Auffassungsgabe und findest dich zügig in neue Themen und Tools ein.

- **Kundenorientierung:** Du bringst Kundenorientierung mit und behältst auch in herausfordernden Situationen einen kühlen Kopf.

- **Technisches Verständnis:** Du hast technisches Verständnis und Interesse an digitalen Tools und Prozessen.

- **Lernbereitschaft:** Du bist neugierig, lernbereit und packst gerne an – auch bei Themen außerhalb deines direkten Verantwortungsbereichs.

## Was wir dir bieten

- **Gestaltungsspielraum & Eigenverantwortung:** Bringe deine Ideen ein, übernimm Verantwortung und gestalte die Weiterentwicklung unserer Unternehmen aktiv mit.

- **Flexible Arbeitszeiten:** Wir arbeiten hybrid mit flexiblen Arbeitszeiten.

- **31 freie Tage:** 30 Urlaubstage plus jeweils halbe Arbeitstage an Heiligabend und Silvester.

- Weiterentwicklung: Wir fördern deine fachliche und persönliche Entwicklung durch individuelle Weiterbildungsmöglichkeiten.

- **Betriebliche Altersvorsorge mit DYNO**: Eine provisionsfreie bAV-Lösung, damit mehr von deiner Altersvorsorge dort ankommt, wo sie hingehört – bei dir.

- **Wellpass:** Zugang zu deutschlandweiten Sport-, Fitness- und Gesundheitsangeboten – von Fitnessstudios über Yoga und Schwimmen bis hin zu Massagen.

- **Probonio & Corporate Benefits:** Über unsere Mitarbeiterplattform erhältst du Zugang zu attraktiven Vergünstigungen, exklusiven Mitarbeiterangeboten und zahlreichen Rabatten.

- **Modernes Arbeitsumfeld:** Arbeiten im Herzen von Friedrichshain-Kreuzberg mit Blick auf die Spree und eigener Dachterrasse.

## Du hast Fragen? Wir sind für dich da.

***Teilnahmebedingungen:**

Die Empfehlung muss durch die Bewerberin oder den Bewerber im Online-Bewerbungsformular von GreenMedical über das Feld „Hat dich jemand empfohlen?“ angegeben werden. Andere Meldewege werden nicht berücksichtigt. Bei der Nennung mehrerer Personen entfällt der Prämienanspruch.

Die Prämie wird nur gewährt, wenn die empfohlene Person eingestellt wird und das Praktikum tatsächlich antritt. Die empfehlende Person muss sich nach Praktikumsbeginn selbstständig bei GreenMedical melden.

Die Prämie besteht aus einem Wunschgutschein im Wert von 100 Euro. Eine Barauszahlung oder ein Umtausch sind ausgeschlossen. Etwaige steuerliche Pflichten trägt die empfangende Person.

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
