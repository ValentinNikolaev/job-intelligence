# Manager, ADR - EMEA

Posted: 2026-09-17T08:40:09Z

## Rejection

- Category: tech_stack
- Reason: role does not mention Go/Golang or PHP

Camunda is **the enterprise platform for agentic orchestration**, enabling organizations to coordinate **AI agents, people, and systems **across complex, end-to-end business processes. With built-in governance, auditability, and human oversight, Camunda gives enterprises the control they need to move AI from pilots to production — safely and at scale. **Trusted by over 700 organizations worldwide**, including 9 of top 10 US banks, Camunda helps enterprises boost operational efficiency, accelerate time-to-value, and deliver better customer experiences.

**Fully remote and global,** we are in the middle of something bigger: **transforming into an AI-first organisation, built on our own platform**. We use Agentic AI to automate, orchestrate intelligent processes, and elevate human contribution across every team.

Named [GP Bullhound’s Top 100 Next Unicorn list,](https://www.gpbullhound.com/articles/top-100-next-unicorns-the-uk-france-and-germany-lead-with-the-most-promising-technology-companies-in-europe/) **2025 Great Place to Work certified.** ***Visionary***** **in [**2025 Gartner® Magic Quadrant™**](https://page.camunda.com/wp-2025-gartner-magic-quadrant-for-boat)** **for Business Orchestration and Automation Technologies. ranked **3rd in Flexa's 2026 **[**Most Flexible Companies**](https://flexa.careers/companies/camunda), We’re growing fast and looking for top talent to join our team. **If you want meaningful work, visible impact and put something genuinely rare on your CV, keep reading.**

**About the Role:**

Join Camunda as the Manager of Account Development and be at the forefront of our hyper-growth journey into new markets. In this dynamic role, you will take charge of pipeline generation for one of our EMEA ADR teams, closely collaborating with cross-functional teams across Sales, Marketing, Partner Management, and Customer Success. You will use your superpower in coaching to build and empower a high-performance team, fostering a culture of accountability and continuous development. This role not only demands strong leadership and management skills but also a passion for inspiring and uplifting your team to achieve their full potential.

**What you'll be doing:**

-

**Lead and develop a high-performing Account Development team**, focusing on attracting, onboarding, and coaching team members to excel in their roles and eventually promote into future GTM roles.

**Serve as a trusted partner** to Sales Leadership on all sales activities, strategies, and forecasting, leveraging data-led insights to drive results.

**Analyze pipeline management and team productivity metrics** to identify areas for improvement and implement actionable recommendations that lead to pipeline growth

**Champion a culture of continuous feedback and growth**, building a team environment that encourages innovation and celebrates achievements.

**What you bring:**

-

Ability and/or willingness to use [our product](https://accounts.cloud.camunda.io/signup?_ga=2.47330343.127558761.1654184528-504024057.1654184528).

-

Proven experience in leading high-performing global account development teams within a SaaS environment.

-

Strong analytical skills with experience in utilizing CRM for pipeline management and data analysis.

-

Exceptional people management skills and a demonstrated commitment to employee development and career growth.

-

A results-oriented mindset, with a track record of exceeding team pipeline generation and sales targets.

**Nice-to-haves:**

-

Familiarity with remote working principles and experience in driving success in highly transparent environments.

-

Experience and success in leading teams through change

-

Knowledge of modern sales strategies and methodologies to enhance team effectiveness.

-

A commitment to diversity, equity, and inclusion initiatives in the workplace.

***This role is an existing vacancy***

#LI-JS1 #LI-Remote #C1

**What We Have to Offer:**

**Compensation**

We offer competitive, fair, and transparent compensation. Salary ranges are location-based, with Standard and Major markets (global tech hubs) reflecting local competition.

**The Annual Total Target Cash **(base salary + 100% variable target, where applicable) shown below spans from the minimum in a Standard market to the maximum in a Major market. Final offers depend on **skills**, **experience**, and **location**, and we typically hire in the first half of the range to allow room for growth:

-

United States: $135,200.00 to $218,100.00

-

United Kingdom: £84,900.00 to £139,700.00

-

Singapore: S$168,000.00 to S$251,900.00

If you’re based elsewhere, you’ll be hired via [**Remote.com**](http://Remote.com) (our global employer partner), and your Talent Acquisition Partner will provide a personalized **Total Rewards Calculator** after your first interview.

**Equity: **We also offer equity (where applicable) through our [**Virtual Stock Option Plan (VSOP)**](https://docs.google.com/document/d/1hoyQAPTZ5nV7J47D9n3yqK5hhLj160Xf36iyqEXNOWE/edit?tab=t.0#heading=h.2qon7r4kdfe1).

**Benefits & Perks**

We invest in your wellbeing, growth, and ability to connect, along with perks that support you no matter where you’re based. Our benefits are globally designed and locally delivered where applicable.

-

**Remote & Flexible: **Work from anywhere with the setup that suits you, **home office budget, co-working space support, and flexible time off** to recharge when you need it.

-

**In Person Connection: **We invest in meaningful face time through our **Annual Kickoff **(Vienna in 2025, Madrid in 2026!), **team offsites, and Camundi Connection Budgets**, including contributing to meetups while travelling,, and local gatherings with fellow Camundi.

-

**Health & Wellbeing:** Access locally tailored healthcare, **Modern Health** for global mental wellbeing, and our **Live Well Lifestyle Spending Account (LSA),** a flexible, global benefit that puts you in control of your whole life, not just work, from: **staying active, to caring for family, exploring personal passions, meaningful experiences, and investing in your financial wellbeing.** The Live Well program launches in 2026 and scales to **€1,000 annually from 2027**.

-

**Financial Security:** Retirement and pension plans (often with company contributions), plus life and disability insurance where relevant.

-

**Professional Growth:** Up to $/€/£1,000 per year for self-driven learning: courses, certifications, books, you decide!

**AI in our hiring process**:*** **Camunda may use AI tools to aid the screening of applications and during the interview process. You can *[***learn more here***](https://camunda.com/ai-in-our-interviewing-process/)

*”Everyone is welcome at Camunda” *— *it’s a celebrated component of our culture. We strive to create an inclusive environment that empowers our people. At Camunda, we honour diverse cultures and backgrounds and are proud to be an equal opportunity employer. All qualified applicants will receive consideration without regard to gender, race, ethnicity, religion, belief, sexual orientation, age, disability or any other protected characteristics under applicable law. We are looking forward to your application!*

***Come join us and be part of Camunda’s incredible journey: Make an impact at a pivotal moment in our story!***

***Please be aware that scammers may impersonate Camunda by reaching out about job opportunities. Camunda will only contact candidates from an email address ending in @***[***camunda.com***](http://camunda.com)*** or *****@**[**talent.camunda.com**](http://camunda.com)***. We will never ask candidates for bank account details, checks, payment, or other sensitive financial information as part of our hiring process. If you receive a suspicious message, please do not respond, click any links, or share personal information.***

***Note for recruiting and placement agencies: Camunda does not accept unsolicited agency resumes. Please do not forward resumes to our careers site, employees, or any other Camunda contact unless we have specifically engaged your firm for that search. Camunda will not pay fees related to unsolicited resumes.***

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
