# Head of Growth (all genders) B2B SaaS für KMU

Posted: 2026-09-17T07:30:40Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Deutschland lebt von seinen kleinen und mittleren Unternehmen, und viel zu viel von deren Geld und Aufmerksamkeit geht in die Pflicht: Buchhaltung, Umsatzsteuervoranmeldung, Jahresabschluss. Unvermeidbare Arbeit, die niemand will und für die alle zu viel bezahlen.

mika nimmt sie ihnen ab. Weil nichts davon optional ist, verstehen wir das, was wir bauen, als Infrastruktur und nicht als Software, und der Zweck ist einfach: Es soll billiger werden, in Deutschland ein Unternehmen zu führen.

Von 100 auf über 700 Kund:innen in acht Monaten, und immer noch ein kleines Team. Deshalb sind diese Rollen bewusst breit: Du verantwortest einen ganzen Bereich und nicht einen Ausschnitt davon, es gibt mehr zu bauen als Menschen, die bauen, und der Bereich wächst so schnell, wie du wächst. Intern arbeiten wir auf Englisch, weil das Team international ist. Der Markt ist deutsch.

## Aufgaben

Du verantwortest die Neukunden-Pipeline und die gesamte Go-to-Market-Engine und berichtest direkt an den CEO. Wenn wir ins Gespräch kommen, konvertieren wir gut. Wir erzeugen nur nicht genug Gespräche. Das ist die Zahl, die dir gehört.

Diese Rolle ist gleichzeitig die seniorste und die operativste im Growth-Bereich. Du führst heute ein kleines Team und in einem Jahr ein echtes – und lieferst die ganze Zeit über selbst ab.

Parallel besetzen wir eine Vertriebsleitung. Growth verantwortet das Go-to-Market end to end; wie die Vertriebsleitung dazu steht, gestalten wir mit der Person, die zuerst an Bord ist.

**Was du machst**

- Du verantwortest Pipeline-Generierung als wichtigste Zahl des Unternehmens – end to end, nicht kanalweise

- Du skalierst Paid Acquisition um ein Vielfaches und hältst dabei den CAC-Payback unter drei Monaten – und entscheidest, wann wir das inhouse holen

- Du verantwortest Positionierung und Category Creation. mika ist die Finanz- und Steuerabteilung für Unternehmen, die zu klein für eine eigene sind – nie eine Buchhaltungssoftware

- Du machst aus Partnerschaften einen messbaren Kanal und entwickelst unsere Kundenbasis zu einer Community

- Du verantwortest neben der Demand- auch die Sales-Engine: Lane-Definition, Rep Economics, Win Rate, Cycle Time und ACV

- Du baust und führst das Team – du entscheidest, welche Rolle wann kommt, und stellst sie selbst ein

## Qualifikation

**Was du mitbringst**

- AI-native, nicht AI-curious. Claude oder Vergleichbares ist dein täglicher Sparringspartner, kein Tool, das du gelegentlich öffnest.

- Du hebst deinen eigenen Output damit und automatisierst die Teile deines Jobs, für die es keinen Menschen brauchen sollte. In dieser Rolle heißt das: die Analysen und Reportings, auf die du sonst warten müsstest – und denselben Anspruch an alle, die du einstellst.

- Du hast ein Unternehmen von rund 1 Mio. auf über 10 Mio. ARR gebracht – oder in einer früheren Rolle das erreicht, was wir uns für die nächsten 365 Tage vornehmen.

- Output vor Planung. Du wirst daran gemessen, was jede Woche live geht, nicht an Decks. Der Fehler, den wir nicht wiederholen: starke Analysen, aus denen nie ausgelieferte Arbeit wird.

- Du hast Paid in den sechsstelligen Monatsbereich skaliert und eine Content-Engine aufgebaut – und kannst Assets zeigen, die du selbst produziert oder direkt verantwortet hast

- Du skalierst von zwei auf zehn Leute, ohne die zehn zum Start zu brauchen

- First Principles und quantitativ. Du modellierst den Funnel, planst Quartale im Voraus und benennst die Metriken, an denen du gemessen werden willst, ohne dass man dich fragt.Selbststeuernd.

- Du siehst das Problem, bevor wir es ansprechen – und handelst.

- Geschmack. Du kannst beurteilen, ob ein Creative einem Premium-Anspruch genügt. Marke ist unser Distributions-Moat, und Qualität lässt sich nicht an Juniors delegieren.

- Belastbar in direkter Kommunikation. Du arbeitest mit drei meinungsstarken, operativen Foundern und gibst und nimmst klares Feedback ohne Drama.

**nice to have**

- Deutsche KMU-Zielgruppe, Fintech oder eine andere regulierte Kategorie

- Category Creation dort, wo es kein Suchvolumen gab

- Community-Aufbau

- Du hast schon ein kleines Growth-Team eingestellt und geführt

**kein Fit**

- Du brauchst ein großes Team oder gewachsene Strukturen, bevor du lieferst

- Du führst über Strategie-Decks, wartest auf Briefings oder steuerst vor allem Agenturen

- Du hast keinen eigenen Output vorzuweisen und keine Meinung zu unserem Funnel im ersten Gespräch

**Deutsch auf C1-Niveau oder höher ist Voraussetzung.** Unsere Zielgruppe, unsere Inhalte und unsere Sales-Gespräche sind deutsch – und du verantwortest die Sprache, die mika spricht. Englisch auf B2-Niveau oder höher, da Englisch unsere Teamsprache ist.

## Benefits

Grundgehalt 80.000 bis 130.000 EUR je nach Erfahrung, dazu ein variabler Anteil. Er hängt am Anfang stärker an dem, was du selbst abschließt, und verschiebt sich mit dem wachsenden Team in Richtung Teamleistung.

Drei Runden: ein erstes Kennenlernen, eine Arbeitssession mit einem kurzen Case und eine letzte Runde mit den Gründern. Für eine Rolle auf diesem Level kommt ein viertes Gespräch mit einem unserer Investoren oder Mentoren dazu. Ein Termin findet in Berlin persönlich statt, und du hörst in jeder Stufe innerhalb einer Woche von uns, auch wenn die Antwort nein ist.

**Warum mika?**

- **Kein Budgetdeckel.** Die Einmalaufträge, die Kund:innen mitbringen, decken die Akquise am ersten Tag. Solange der CAC hält, gibst du aus, was du brauchst.

- Die Rolle trägt die wichtigste Zahl des Unternehmens – mit den passenden Befugnissen

- Direkter Draht zu den Foundern und ein Platz bei jeder Entscheidung, die Growth berührt

- Eine Kategorie zum Aufbauen statt eines Marktanteils zum Verteidigen

- De facto C-Level. Für die richtige Person kann die Rolle den CMO-Titel tragen

- Berlin, keine festen Bürotage. Komm so oft, wie es braucht, um dein Team zu führen – das entscheidest du

Schick uns deinen Lebenslauf, die Zahlen, die du bewegt hast, und wie – plus eine Sache, die du an unserem Funnel ändern würdest, nachdem du zwanzig Minuten daraufgeschaut hast.

Bei mika schätzen wir Vielfalt und arbeiten an einem Umfeld, in dem alle im Team ihr Bestes geben können. Bau mit uns die Zukunft der Finanzen für kleine Unternehmen.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
