# EMC/EMI Engineer

Posted: 2026-09-17T08:40:08Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Here at The Exploration Company, we are building innovative aerospace technologies that advance the future of space transportation.

We are seeking an experienced and motivated EMC/EMI Engineer to join our team. The successful candidate will be responsible for developing design recommendations and establishing test policies related to Electromagnetic Compatibility (EMC) and Electromagnetic Interference (EMI) for our spacecraft applications. This role requires a thorough understanding of EMC/EMI principles, spacecraft systems, and industry standards to ensure the reliability and functionality of our spacecraft in harsh space environments.

**Key Responsibilities:**

-

**Design and Development:**

-

Provide expert guidance on EMC/EMI design practices to ensure spacecraft systems meet all relevant standards and requirements.

-

Collaborate with cross-functional teams to integrate EMC/EMI considerations into the design phase of spacecraft systems and subsystems.

-

Review and analyze design documents, schematics, and layout plans to identify potential EMC/EMI issues.

-

**Testing and Validation:**

-

Develop and implement comprehensive EMC/EMI test plans and procedures for spacecraft systems.

-

Conduct EMC/EMI testing, including pre-compliance and compliance testing.

-

Analyze test data, identify non-conformities, and recommend corrective actions to resolve EMC/EMI issues.

-

**Standards and technological watch:**

-

Ensure all designs and test procedures comply with relevant EMC/EMI standards

-

Stay updated with the latest developments in EMC/EMI standards and incorporate them into design and testing processes.

-

**Documentation and Reporting:**

-

Prepare detailed technical reports, test summaries, and design documentation related to EMC/EMI activities.

-

Maintain accurate records of all test results, design recommendations, and corrective actions.

-

**Collaboration and Support:**

-

Work closely with system engineers, hardware designers, and other stakeholders to address EMC/EMI challenges throughout the product development lifecycle.

-

Provide technical support and training to engineering teams on EMC/EMI best practices and mitigation techniques.

**Qualifications:**

-

Bachelor's or Master's degree in Electrical Engineering, Electronics Engineering, or a related field.

-

Minimum of 5 years of experience in EMC/EMI engineering, preferably in the aerospace or defense industry.

-

Strong knowledge of EMC/EMI principles, test methods, and mitigation techniques.

-

Experience with EMC/EMI standards, such as MIL-STD-461, CISPR, and DO-160.

-

Proficiency in using EMC/EMI testing equipment, including spectrum analyzers, network analyzers, and EMI receivers.

-

Excellent problem-solving skills and attention to detail.

-

Strong communication and interpersonal skills, with the ability to work effectively in a team environment.

-

Ability to manage multiple projects and priorities in a fast-paced environment.

**Preferred Qualifications:**

-

Experience with spacecraft systems and subsystems.

-

Knowledge of signal integrity and power integrity as they relate to EMC/EMI.

-

Experience with simulation tools for EMC/EMI analysis.

**Why you should join us!**

What makes us special here at The Exploration Company and why we think you will enjoy working here is:

-

We’re Agile - we make decisions fast whilst keeping our goals and systems in mind

-

We’re Open and Collaborative - we are transparent about risks and obstacles, so that we can cooperate to overcome them

-

We have a lot of Fun - we refuel our energy knowing we are democratising space. It’s a wonderful and rare opportunity, are YOU up for the challenge?

We'd love to hear from you if you wish to be a part of our journey. Please submit your CV now for immediate consideration and we will be in touch shortly.

*The Exploration Company is an equal opportunity employer and values diversity. We do not discriminate based on race, religion, colour, national origin, gender, sexual orientation, age, marital status or disability status. Relocation assistance is provided for those willing to relocate including visa sponsorship where applicable. *

*
All offers are contingent upon the successful completion of a background check, which will be subject to the country, role, and project you applied for. By submitting your application, you acknowledge and agree that any offer of employment may be conditional upon successful condition of this check. The Exploration Company partners with Zinc Work Limited located in the UK (Zinc), a third-party provider, to ensure this process as efficient and transparent as possible.

If applicable, you will receive an email from Zinc upon acceptance of your offer with a link to a secure portal where you can provide the required information to Zinc. *

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
