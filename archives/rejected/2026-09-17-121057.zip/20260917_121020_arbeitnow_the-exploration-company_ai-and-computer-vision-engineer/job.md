# AI and Computer Vision Engineer

Posted: 2026-09-17T08:40:08Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Here at The Exploration Company, we are building innovative aerospace technologies that advance the future of space transportation.

We want you as a hands-on AI and Computer Vision Engineer to build the perception capability behind autonomous close-proximity operations: models that estimate the relative position and orientation of non-cooperative spacecraft from camera images, trained largely on synthetic and lab data, and optimized to run on the compute we can actually fly.

This is a builder role. You write the training code, run the experiments, take the models onto embedded and neuromorphic hardware, and own the results.

## Key Responsibilities

In your capacity as AI and Computer Vision Engineer, your role will be continuously evolving, but day to day your duties will include:

-

Designing, training and evaluating deep-learning models for 6-DoF pose estimation of non-cooperative spacecraft

-

Owning the full training pipeline: dataset generation and management, augmentation, domain adaptation between synthetic, laboratory and orbital imagery, experiment tracking and reproducibility.

-

Optimizing models for flight-representative compute (knowledge distillation, pruning, quantization and quantization-aware training) and benchmarking latency, memory and power against onboard constraints.

-

Porting and evaluating models on embedded and neuromorphic hardware, and characterizing the accuracy versus energy trade-off.

-

Building explainability and uncertainty into the pipeline so failure modes such as high occlusion can be debugged and the technology is a credible candidate for certification.

-

Exploring privacy-preserving and distributed training approaches that let us improve models with partners without exchanging raw data.

-

Prototyping lightweight self-supervised refinement methods for later in-flight model adaptation on unlabeled imagery.

-

Defining requirements, test scenarios and validation criteria together with GNC/FPO, and supporting the selection and characterization of space-qualified camera sensors.

-

Running validation campaigns on hardware-in-the-loop testbeds and analyzing the results.

-

Managing our training compute footprint across cloud GPU and internal HPC efficiently.

## What we would love to see from you

In this role, ideally, you will have the following:

**Education**

-

Degree (MSc or PhD) in computer science, electrical engineering, robotics, aerospace, physics, or a comparable field with a strong machine learning focus.

**Experience**

-

3+ years building and shipping deep-learning computer vision systems such as object detection, keypoint detection, pose estimation, or 3D perception. PhD work in the field counts.

-

Demonstrable experience taking a model from research prototype to a constrained target: quantization, distillation, latency optimization, deployment on embedded or accelerator hardware.

-

Experience training on synthetic data and dealing with the sim-to-real gap.

-

Hands-on lab work: cameras, calibration, test setups, collecting and annotating your own data.

**Skills and Competencies**

-

Strong Python and PyTorch (or JAX/TensorFlow); clean, version-controlled, reproducible code.

-

Solid classical computer vision and 3D geometry: camera models, intrinsics and extrinsics, distortion, PnP, RANSAC, coordinate frames.

-

Comfortable with Linux, Git, containers, and running large training jobs on GPU clusters or in the cloud.

-

Genuinely hands-on and self-directed: you will carry your work largely on your own, with review support rather than daily direction.

-

Able to communicate results clearly in technical reports and reviews.

-

Working proficiency in English; German is a plus.

**Nice to have**

-

Familiarity with spacecraft rendezvous, docking, or vision-based navigation, and with benchmarks such as SPEED/SPEED+ and the ESA pose estimation challenges.

-

Spiking neural networks and neuromorphic hardware, or event-based cameras.

-

Federated learning, differential privacy, or secure aggregation.

-

Rendering and synthetic data generation (Blender, Unreal Engine, Isaac Sim, …).

-

Experience with space or safety-critical software assurance, or with publicly funded R&D projects.

**Why you should join us!**

What makes us special here at The Exploration Company and why we think you will enjoy working here is:

-

We’re Agile - we make decisions fast whilst keeping our goals and systems in mind

-

We’re Open and Collaborative - we are transparent about risks and obstacles, so that we can cooperate to overcome them

-

We have a lot of Fun - we refuel our energy knowing we are democratising space. It’s a wonderful and rare opportunity, are YOU up for the challenge?

We'd love to hear from you if you wish to be a part of our journey. Please submit your CV now for immediate consideration and we will be in touch shortly.

*The Exploration Company is an equal opportunity employer and values diversity. We do not discriminate based on race, religion, colour, national origin, gender, sexual orientation, age, marital status or disability status. Relocation assistance is provided for those willing to relocate including visa sponsorship where applicable. *

*
All offers are contingent upon the successful completion of a background check, which will be subject to the country, role, and project you applied for. By submitting your application, you acknowledge and agree that any offer of employment may be conditional upon successful condition of this check. The Exploration Company partners with Zinc Work Limited located in the UK (Zinc), a third-party provider, to ensure this process as efficient and transparent as possible.

If applicable, you will receive an email from Zinc upon acceptance of your offer with a link to a secure portal where you can provide the required information to Zinc. *

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
