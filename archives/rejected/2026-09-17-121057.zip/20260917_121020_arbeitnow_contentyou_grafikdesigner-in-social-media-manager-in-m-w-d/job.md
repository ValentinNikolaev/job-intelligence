# Grafikdesigner:in / Social-Media-Manager:in (m/w/d)

Posted: 2026-09-17T07:30:38Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Zur Verstärkung unseres Teams suchen wir zum nächstmöglichen Zeitpunkt eine kreative, organisierte Persönlichkeit, die Lust hat, mehrere Kunden eigenständig in Social Media, Design und Print zu begleiten.

contentyou ist eine Kreativ- und Content-Marketing-Agentur mit Sitz in Münster Wolbeck. Wir betreuen unsere Kunden ganzheitlich in den Bereichen Foto, Video, Social Media und Grafikdesign – von der Content-Idee bis zur fertigen Umsetzung. Hierbei kommen wir aus dem professionellen Foto & Video Bereich und haben vor knapp sechs Jahren die Abteilung Grafik/Design/Social Media zusätzlich aufgebaut. Aktuell sind wir ein sechsköpfiges Team und bilden seit 12 Jahren Fotografen aus.

## Aufgaben

**Kundenbetreuung (Social Media & Design)**

- Social-Media-Planungen erstellen und Content-Ideen entwickeln

- Beiträge, Reels und Storys posten

- Grafiken und Gestaltungen für Social Media und Print erstellen

- Direkte Kundenkommunikation, schriftlich und persönlich

- Tägliche Prüfung und Beantwortung von Nachrichten/Kommentaren bei Meta und LinkedIn

- Abstimmung und Organisation von Foto- und Filmterminen inkl. Konzept- und Ablaufplanung

- Gelegentliche Videobesprechungen mit Kunden zum Content-Austausch

**Print & Produktion**

- Print-Gestaltungen für verschiedene Formate

- Kommunikation mit Druckereien und Abstimmung von Printabnahmen

**Team & Zusammenarbeit**

- Regelmäßiger Austausch mit Kolleg:innen zu Bildbearbeitung und Videoschnitt

- Onboarding neuer Kolleg:innen

- Mitwirkung an Webseiten-Neugestaltungen

- Pflege des CI-Manuals von contentyou

**Weitere Aufgaben**

- Gelegentliche Entwicklung neuer Markenauftritte für Neukunden (Logo, CI, Konzept)

- Einfacher Videoschnitt und Grafikgestaltung mit DaVinci

- Quartalsweise Zusammenfassung der Arbeitsstunden bei Abo-Kunden

- Selbstständige Zeiteinteilung und Priorisierung mehrerer Kunden

## Qualifikation

- Mind. fünf Jahre einschlägige Berufserfahrung im Bereich Grafikdesign, Social Media oder Content-Erstellung

- Erfahrung in Grafikdesign und Social-Media-Content-Erstellung

- Sicherer Umgang mit gängigen Design-Tools, DaVinci-Kenntnisse von Vorteil

- Strukturierte, selbstständige Arbeitsweise und gutes Zeitmanagement

- Kommunikationsstärke im Umgang mit Kunden

- Teamfähigkeit und Freude an crossfunktionaler Zusammenarbeit

- Offenheit für neue Ideen und eigene Impulse

## Benefits

- Flexible Arbeitszeiten und Möglichkeit auf Homeoffice

- Modernes Arbeitsumfeld mit aktueller technischer Ausstattung

- Junges, kreatives Team mit flachen Hierarchien

- Raum für eigene Ideen und Gestaltungsfreiheit

- Weiterbildungsmöglichkeiten

- JobRad

- Bezuschussung der Fitnessstudio-Mitgliedschaft

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
