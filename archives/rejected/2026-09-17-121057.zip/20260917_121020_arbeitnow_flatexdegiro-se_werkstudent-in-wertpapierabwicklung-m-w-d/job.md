# Werkstudent/in Wertpapierabwicklung (m/w/d)

Posted: 2026-09-17T08:30:58Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

flatexDEGIRO SE betreibt die führende und am schnellsten wachsende Online-Brokerage-Plattform in Europa. Basierend auf moderner, hauseigener State-of-the-Art-Technologie wird den Kunden der Marken flatex und DEGIRO eine breite Palette unabhängiger Produkte mit Ausführung an Top TIER 1-Börsen angeboten. Der technologische Vorsprung, die hohe Effizienz und die starken Skaleneffekte ermöglichen es uns, unser Serviceangebot für Kunden kontinuierlich zu verbessern und führende Standards in Bezug auf Produkt-, Preis- und Plattformqualität zu setzen.

Mit mehr als 3,5 Millionen Kundenkonten und mehr als 75 Millionen abgewickelten Wertpapiertransaktionen im Jahr 2025 ist flatexDEGIRO der größte Retail-Online-Broker in Europa. In Zeiten von Bankenkonsolidierung, zunehmender Digitalisierung und dem immanenten Bedürfnis von Millionen von Europäern, ihre finanzielle Zukunft selbst in die Hand zu nehmen, ist flatexDEGIRO für weiteres profitables Wachstum bestens aufgestellt.

Möchtest du wissen, wie es ist, für flatexDEGIRO SE zu arbeiten?

Besuche uns auf Instagram @lifeatflatexdegiro und lerne die großartigen Menschen kennen, die uns zu dem machen, was wir sind! Siehst du dich schon als Teil dieses Teams? Dann freuen wir uns auf deine Bewerbung!

## Aufgaben

**Welche Aufgaben erwarten Dich bei uns?**

- Im Rahmen Deiner Tätigkeit erhältst Du spannende Einblicke in den Bereich Corporate Actions eines internationalen Finanzdienstleisters.

- Du unterstützt das Team Corporate Actions im operativen Tagesgeschäft.

- Du wirkst bei der Überwachung und Abstimmung interner Verrechnungs- und Bestandskonten für Wertpapier- und Cash-Positionen mit.

- Du identifizierst und analysierst Differenzen auf internen Konten und unterstützt bei deren Klärung.

- Du arbeitest mit internen Fachbereichen sowie externen Marktteilnehmern zusammen, um offene Sachverhalte zu bearbeiten.

- Du unterstützt bei der Bearbeitung und Nachverfolgung von Corporate-Action-Ereignissen und trägst zur Sicherstellung einer ordnungsgemäßen Abwicklung bei.

- Du übernimmst administrative und organisatorische Aufgaben innerhalb des Teams.

## Qualifikation

**Was wünschen wir uns von Dir?**

- Du bist eingeschriebene/r Student/in der Betriebswirtschaftslehre, Wirtschaftswissenschaften, Finance oder eines vergleichbaren Studiengangs.

- Du verfügst über sehr gute Deutsch- und Englischkenntnisse in Wort und Schrift.

- Du hast einen sicheren Umgang mit den gängigen MS-Office-Anwendungen, insbesondere Excel.

- Du bringst eine ausgeprägte analytische Denkweise sowie eine strukturierte Arbeitsweise mit.

- Du arbeitest sorgfältig, zuverlässig und eigenverantwortlich.

- Du besitzt ein hohes Maß an Integrität und Verantwortungsbewusstsein.

- Du verfügst über ausgeprägte Kommunikationsfähigkeiten und eine präzise schriftliche Ausdrucksweise.

- Du kannst Prioritäten setzen und mehrere Aufgaben effizient organisieren.

- Du arbeitest lösungsorientiert und behältst auch in einem dynamischen Umfeld den Überblick.

- Teamfähigkeit und eine hohe Motivation runden Dein Profil ab.

## Benefits

**Womit können wir dich begeistern?**

- Ein enthusiastisches Team, mit dem die Arbeit Spaß macht

- Persönliche und berufliche Weiterentwicklung mit Zugang zu relevanten Kursen

- Eine anspruchsvolle Tätigkeit in einem internationalen und schnell wachsenden Unternehmen

- Ein wettbewerbsfähiger Stundenlohn

- Viel Freiheit bei der Ausführung deiner Aufgaben und die Möglichkeit, deine eigene Karriere zu gestalten

- Die Möglichkeit, in einem neuen, enthusiastischen Team von Experten zu lernen und aktiv mitzuarbeiten.

Du findest dich in dieser Position wieder und bist gespannt auf deine neue Herausforderung? Dann bewirb dich ganz einfach und schnell über unser Online-Bewerbungsportal und unser Recruiting Team wird sich zeitnah bei dir melden!

Alle qualifizierten Bewerber werden ohne Rücksicht auf Ethnie, Hautfarbe, Religion, Alter, Geschlecht, nationale Herkunft, Behinderung, sexuelle Orientierung, Geschlechtsidentität/-ausdruck oder einen anderen gesetzlich geschützten Status bei der Einstellung berücksichtigt. flatexDEGIRO ist ein Arbeitgeber, der Chancengleichheit fördert.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
