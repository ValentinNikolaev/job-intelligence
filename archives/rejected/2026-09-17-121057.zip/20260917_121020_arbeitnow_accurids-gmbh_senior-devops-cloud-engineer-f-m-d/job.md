# Senior DevOps/ Cloud Engineer (f/m/d)

Posted: 2026-09-17T08:00:30Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

## Become a Part of ACCURIDS

Join us and help shape the future of pharmaceutical data!

At ACCURIDS, we’re building the data backbone behind life-science innovation — a system that identifies, links, and standardizes critical enterprise data in compliance with global standards such as ISO IDMP. We help global life-science companies launch products faster, more safely, and with better patient outcomes.

At ACCURIDS, you’ll join a collaborative, growth-driven environment where your work makes a real impact from day one.

## How you’ll make an impact:

- **You set up, maintain, and troubleshoot customer installations**, managing both high-standard SaaS environments and restrictive customer on-premise deployments.

- **You operate and scale our core AWS infrastructure**, managing multi-account environments, EKS, RDS, S3, networking, and IAM.

- **You support our development team with product operations**, maintaining and extending GitLab CI/CD pipelines, driving declarative GitOps workflows (ArgoCD/Kargo), and managing incident response.

- **You develop the Accurids SaaS platform stack**, focusing on enhancing platform automation, Infrastructure as Code (IaC), identity management, and advanced observability.

- **You drive our security operations**, building out our compliance posture through log reviews, vulnerability scanning, active monitoring, alerting, and supporting ISO 27001 requirements.

- **You ensure operational resilience and continuity**, working as a key senior pillar to transition our infrastructure from a single-point-of-failure risk to a robust, well-documented architecture.

## What helps you succeed:

- **Adaptability & Continuous Learning:** A strong engineering mindset with a proven ability to pick up new tools, architectures, and methodologies rapidly as our ecosystem evolves.

- **Cloud & Infrastructure Foundation:** 3–5+ years of experience in DevOps, Cloud Engineering, or Platform Engineering, with production exposure to a major cloud provider (we use AWS, but Azure or GCP experience is just as welcome).

- **Containerization Concepts:** Solid foundational knowledge of the Kubernetes ecosystem, Docker containerization, and configuring CI/CD pipelines (such as GitLab CI).

- **Modern Operations (Our Stack):** Familiarity with—or a strong desire to learn—Infrastructure as Code (Terraform) and declarative GitOps workflows (ArgoCD/Kargo).

- **Observability & Security Awareness:** Observability & Security: Familiarity with cloud security tooling and monitoring/observability (e.g., Prometheus, Grafana, Elasticsearch). Experience building a security posture is a strong plus.

- **Core Competencies:** Business fluency in English and an openness to integrating AI-assisted tools (like Cursor, Copilot, or ChatGPT) into your daily scripting and debugging workflows. *(It’s a nice-to-have bonus if you have prior experience with Elasticsearch, Keycloak, Spring Boot, PostgreSQL, or compliance frameworks like ISO 27001!)*

## Why you’ll love working here:

- **Impactful Career Growth:** Evolve into a Lead DevOps / Platform Lead role or deepen your specialization in Cloud Infrastructure, Kubernetes, Infrastructure as Code (IaC), and DevSecOps as we scale.

- **Epic Office & Hybrid Work:** Work from our brand-new office in the KölnTurm, featuring breathtaking views over the city (even higher than the view from the Cologne Cathedral!). Enjoy flexible hybrid options. (Note: On-site presence in Cologne/NRW is required; fully remote work is not offered).

- **Community & Industry Events:** Connect and grow your network through exclusive industry events hosted regularly right in our scenic office space.

- **Competitive Compensation:** Fixed salary package of €75,000 – €100,000 per year for a full-time, permanent position.

- Work-Life Balance & Perks: 30 days of paid vacation, a personal learning budget, hardware of your choice (Mac, Linux, Windows), and your choice between a subsidized Urban Sports Club membership or a €50/month City Plus Card.

- **Empowered Culture:** High trust, flat hierarchies, and an environment where your decisions directly shape the product.

## Not ticking every box?

We encourage you to apply anyway! We know great talent doesn’t always follow a checklist and we care more about your potential, curiosity, and motivation to learn.

At ACCURIDS, we’re committed to building a diverse and inclusive team. We especially encourage women and people from underrepresented backgrounds in tech, science, and data to apply.

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
