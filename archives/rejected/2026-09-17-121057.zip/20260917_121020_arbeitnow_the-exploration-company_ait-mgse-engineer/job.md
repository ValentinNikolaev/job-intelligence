# AIT MGSE Engineer

Posted: 2026-09-17T08:40:08Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Here at The Exploration Company, we are building innovative aerospace technologies that advance the future of space transportation.

We want you as a talented AIT MGSE Engineer to help us in our mission by designing and delivering the MGSEs needed for the preparation of our next capsule.

**Key Responsibilities**

In your capacity as MAIT MGSE Engineer, your role will be continuously evolving, but day to day duties will include:

-

Work closely with Engineering and AIT colleagues to understand and refine the requirements/timelines for the different MGSEs that we will need for various assembly or testing activities.

-

Conceptualise, design (CAD including manufacturing drawings), procure and commission the MGSEs.

-

Confirm with mechanical analysis/hand calculations/proof tests that the design is compatible with the external loads.

-

Discuss with suppliers the MGSE designs for ease of manufacturing and with the most adequate processes.

-

Follow up the manufacturing/procurement with the suppliers (with the support of our supply chain team) and answer any technical questions/concerns ensuring timely delivery of all items.

-

Provide necessary instructions and support the assembly / commissioning / implementation of these MGSEs.

**What we would love to see from you**

In the role of MAIT MGSE Engineer ideally, you will have the following:

-

Mechanical / Aerospace engineering degree or similar with focus on machine / structural design.

-

Minimum 2 years of experience in CAD design + drafting (using Siemens NX or similar) and FE analysis (using Hypermesh or similar).

-

Good understanding of machine design and different manufacturing processes (e.g. machining, welding, etc), design for manufacturing and GD&T.

-

Familiarity with standard margin calculation methodologies for various applications like beams, bolted joints, welds, etc.

-

Experience with design of test setups/jigs/fixtures and planning/execution of mechanical tests in-house would be a plus.

-

Good at documentation including design descriptions, assembly instructions, test reports, etc.

-

Creative with innovative ideas and technical problem solving/troubleshooting skills.

-

Basic hands-on experience with mechanical assembly and simple machining tools like drilling machine.

-

Previous experience in space AIT and MGSE design would be highly appreciated.

-

Good English communication skills (German would be a plus).

**Why you should join us!**

What makes us special here at The Exploration Company and why we think you will enjoy working here is:

-

We’re Agile - we make decisions fast whilst keeping our goals and systems in mind

-

We’re Open and Collaborative - we are transparent about risks and obstacles, so that we can cooperate to overcome them

-

We have a lot of Fun - we refuel our energy knowing we are democratising space. It’s a wonderful and rare opportunity, are YOU up for the challenge?

We'd love to hear from you if you wish to be a part of our journey. Please submit your CV now for immediate consideration and we will be in touch shortly.

*The Exploration Company is an equal opportunity employer and values diversity. We do not discriminate based on race, religion, colour, national origin, gender, sexual orientation, age, marital status or disability status. Relocation assistance is provided for those willing to relocate including visa sponsorship where applicable. *

*
All offers are contingent upon the successful completion of a background check, which will be subject to the country, role, and project you applied for. By submitting your application, you acknowledge and agree that any offer of employment may be conditional upon successful condition of this check. The Exploration Company partners with Zinc Work Limited located in the UK (Zinc), a third-party provider, to ensure this process as efficient and transparent as possible.

If applicable, you will receive an email from Zinc upon acceptance of your offer with a link to a secure portal where you can provide the required information to Zinc. *

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
