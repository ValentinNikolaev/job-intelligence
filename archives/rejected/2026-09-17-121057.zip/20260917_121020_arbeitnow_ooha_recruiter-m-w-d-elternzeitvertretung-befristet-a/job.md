# Recruiter (m/w/d) | Elternzeitvertretung | befristet auf 1 Jahr | Teilzeit | Hamburg

Posted: 2026-09-17T07:30:39Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Du suchst einen sinnvollen Job, der das Konsumentenverhalten nachhaltig verändert? Dann bist du bei uns richtig! Wir sind die ooha, ein Impact-Unternehmen aus Hamburg. Als Next-Gen-Agentur bringen wir Impact-Marken in die Supermarktregale und konsolidieren den LEH-Vertrieb von Brands wie Vita Coco, LEKKA, vly, HEJ oder Heimatgut.

Wir denken Agentur komplett neu – und das gilt auch dafür, wie wir Recruiting verstehen. Statt Bauchgefühl und Standard-Prozessen setzen wir auf eine offene, ehrliche und vertrauensbasierte Kultur, die schon beim ersten Kontakt mit Bewerber:innen spürbar sein soll. Bei uns bist du kein austauschbares Rädchen im Recruiting-Prozess, sondern das Gesicht von ooha für alle, die Teil unseres Teams werden wollen.

Unseren eigenen Impact leisten wir, indem wir 1 % unserer Umsätze gleichmäßig auf alle ooha-Köpfe verteilen und jede:r sich seinen Impact selbst aussuchen kann.

Für eine Elternzeitvertretung suchen wir ab dem 01.10.2026 befristet auf ein Jahr in Teilzeit (ca. 20 Wochenstunden) einen **Recruiting-Kopf (m/w/d)**, der Lust hat, die richtigen Menschen für ooha zu finden und dabei von Beginn an eigene Verantwortung im Bewerbungsprozess zu übernehmen.

Lust, Teil unseres Teams zu werden? Dann let's go ooha together!

## Aufgaben

- End-to-End-Betreuung des Recruiting-Prozesses – von der Stellenausschreibung bis zur Vertragsunterschrift

- Erstellung und Schaltung von Stellenanzeigen auf relevanten Plattformen

- Aktives Sourcing geeigneter Kandidat:innen über verschiedene Kanäle

- Sichtung eingehender Bewerbungen und Vorauswahl passender Profile

- Durchführung von Erstgesprächen und Koordination weiterer Interviewrunden mit den Fachbereichen

- Betreuung der Candidate Experience – von der ersten Rückmeldung bis zum Onboarding

- Pflege und Weiterentwicklung unserer Recruiting-Prozesse und -Tools

- Enge Zusammenarbeit mit Teamleads und der Geschäftsführung bei der Personalplanung

- Unterstützung beim Employer Branding, damit ooha auch am Arbeitsmarkt sichtbar bleibt

## Qualifikation

- Erste Erfahrung im Recruiting, HR oder in einer vergleichbaren Position

- Ein gutes Gespür für Menschen und die Fähigkeit, Potenzial über den Lebenslauf hinaus zu erkennen

- Strukturierte und selbstständige Arbeitsweise mit einem ausgeprägten Organisationstalent

- Kommunikationsstärke und Freude am Austausch mit Bewerber:innen und internen Teams

- Sicherer Umgang mit MS Office

- Gute Englischkenntnisse in Wort und Schrift

- Du willst Teil eines Teams sein – kein Einzelkämpfer, kein reiner Prozess-Abarbeiter

## Benefits

- **Verantwortung statt reine Zuarbeit** Du gestaltest den Recruiting-Prozess aktiv mit statt nur Termine zu koordinieren

- **Direkter Draht zu Bewerber:innen und Teamleads** Kein Elfenbeinturm – du bist die zentrale Schnittstelle im Bewerbungsprozess

- **30 Tage Urlaub** Damit Erholung nicht zu kurz kommt

- **50 € monatlicher Zuschuss** Wahlweise für eine Mitgliedschaft bei Urban Sports Club oder ein Gutscheinsystem

- **1 % Umsatz für deinen eigenen Impact** Gleichmäßig verteilt auf alle ooha-Köpfe – du entscheidest selbst, wofür du spendest

- **Einblick ins People & Culture-Setup einer wachsenden Agentur** Du gestaltest mit, wie ooha als Arbeitgeber wahrgenommen wird

- **Offene, ehrliche und vertrauensbasierte Kultur** Kein Ellenbogen-Mindset, kein Micromanagement

- **Starkes Team & Sinn in der Arbeit** Du findest die Menschen, die Marken vertreten, die wirklich etwas verändern wollen

- **Die am schnellsten wachsende Agentur aus Hamburg mit Haltung** Kurze Wege, schnelle Entscheidungen, echtes Mitgestalten

Wenn du es bis hierhin geschafft hast und an fast allen Punkten ein Häkchen gesetzt hast, dann freuen wir uns jetzt schon darauf, mehr von dir zu erfahren!

Schick uns gerne deinen CV inkl. 3 Sätze dazu, warum du perfekt zu ooha passt und warum du motiviert für die Stelle bist. Es wäre klasse, wenn du uns zusätzlich schon deine Gehaltsvorstellungen nennst.

Let's go ooha together.

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
