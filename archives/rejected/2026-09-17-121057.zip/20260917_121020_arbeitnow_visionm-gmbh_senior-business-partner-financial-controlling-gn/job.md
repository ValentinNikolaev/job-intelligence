# Senior Business Partner / Financial Controlling (gn) - DACH Region

Posted: 2026-09-17T08:00:28Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Sie sind seit einigen Jahren im Business- und Projektcontrolling tätig und

möchten Ihre Expertise nun bei einem innovativen Marktführer im Bereich

Robotik einbringen? Dann lassen Sie uns ins Gespräch kommen!

Unser Kunde steht für Innovation, Dynamik und technologischen Fortschritt. Am Standort in Hessen entwickelt und vertreibt das Unternehmen zukunftsweisende

Roboterlösungen, die Branchen weltweit revolutionieren.

In Ihrer neuen Rolle sind Sie nicht nur Zahlenverwalter, sondern strategischer

Mitgestalter. Als Sparringpartner treiben Sie die wirtschaftliche Performance

voran und sind maßgeblich an der Weiterentwicklung des Geschäftsbereiches beteiligt.

## Aufgaben

- Finanzieller Sparringspartner: Sie agieren als strategischer Business

Partner des Geschäftsbereichsleiters.

- Strategieentwicklung: Sie entwickeln die Geschäftsbereichsstrategie,

bewerten finanzielle Auswirkungen, erstellen fundierte Szenarien und

leiten daraus konkrete, realistische Handlungsempfehlungen ab.

- Ergebnisorientierte Umsetzung: Sie übersetzen strategische Ziele in

messbare Geschäftspläne und überwachen deren Erreichung.

- Unternehmensplanung: Sie treiben die Geschäftsplanung sowie die

Forecast- und Prognoseprozesse für Ihren Bereich proaktiv voran.

- Finanzielle Optimierung: Sie steuern die Kostenstruktur, steigern die Produktivität

und sichern die Kapitaleffizienz durch ein vorausschauendes Cashflow-Management.

- Transparente Berichterstattung: Sie gewährleisten ein verlässliches

Finanzreporting, etablieren interne Kontrollen (IKS), sichern Compliance

Vorgaben und minimieren Geschäftsrisiken

- Analyse und Bewertung: Sie analysieren und bewerten Finanzdaten, um

fundierte Geschäftsalternativen und maßgeschneiderte Lösungen

aufzuzeigen.

- Stakeholder-Management: Sie führen eine offene und zielgerichtete

Kommunikation auf allen Ebenen.

## Qualifikation

- Erfolgreich abgeschlossenes Studium im Bereich Rechnungswesen,

Finanzen, BWL oder vergleichbarer Fachrichtung

- Mindestens fünf Jahre Berufserfahrung im Projekt- und Unternehmenscontrolling

sowie nachweisbare Kenntnisse im Risikomanagement

- Fundiertes Know-How im Projektgeschäft und in der Percentage-of

completion - Methode (PoC)

- Nachgewiesene Erfolge in der strategischen Steuerung komplexer

Kostenstrukturen, der nachhaltigen Produktivitätssteigerung sowie der

Sicherstellung einer optimalen Kapitalausstattung

- Hohes Verantwortungsbewusstsein und Eigeninitiative, gepaart mit einer

konsequent selbstständigen und ergebnisorientierten Arbeitsweise

- Analytische und strukturierte Denk- und Kommunikationsweise,

Detailgenauigkeit und ein zielgerichtetes Vorgehen – auch bei hoher

Dynamik und im Multitasking

- Verhandlungssichere Deutsch- und Englischkenntnisse in Wort und

Schrift

## Benefits

- Mobiles Arbeiten und flexible Arbeitszeiten

- Zukunftssicheres Umfeld in einem krisensicheren, global agierenden Unternehmen mit flachen Hierarchien

- Attraktives Vergütungspaket

- Moderne Arbeitskultur

- Individuelle Entwicklungsangebote

Für weitere Fragen steht Ihnen Kerstin Mader unter der Rufnummer 06174-9619

310 gerne zur Verfügung.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
