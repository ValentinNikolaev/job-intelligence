# Customer Success Manager / Business Analyst B2B SaaS (w/m/d)

Posted: 2026-09-17T08:30:59Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Als **Customer Success Manager / Business Analyst B2B SaaS (m/w/d)** für unsere InfraCloud baust du gemeinsam mit unserem Customer-Success- und Entwicklungsteam die Kundenbetreuung bei HydroMapper weiter aus. Du bist zentrale Ansprechperson für unsere B2B-Kund:innen, begleitest sie bei der Nutzung unserer Plattform und sorgst dafür, dass Fragen, Feedback und Anforderungen strukturiert aufgenommen, gemeinsam mit den Anwender:innen spezifiziert und in User Stories für die Entwicklung übersetzt werden.

Verstärke unser Customer-Success-Team zum nächstmöglichen Zeitpunkt in **Vollzeit** oder **Teilzeit** mit mindestens 30 Stunden pro Woche an unserem Standort in **Hamburg**.

## Aufgaben

- Du betreust unsere InfraCloud-Kund:innen als zentrale Ansprechperson rund um die Nutzung der Plattform und begleitest sie lösungsorientiert bei ihren Anliegen.

- Du nimmst Kundenfeedback und Anforderungen strukturiert auf, spezifizierst neue Features gemeinsam mit den Anwender:innen und übersetzt diese in User Stories für unser Entwicklungsteam.

- Du planst und führst Kunden-Onboardings sowie Schulungen durch und erklärst technische Sachverhalte verständlich und zielgruppengerecht.

- Du unterstützt bei Anwenderfragen und Problemen, koordinierst die Klärung mit der Produktentwicklung und verfolgst offene Punkte zuverlässig nach.

- Du erstellst und entwickelst Schulungsunterlagen, Anleitungen, Wiki-Beiträge und Schulungsvideos kontinuierlich weiter, kommunizierst neue InfraCloud-Funktionen, beobachtest Unterstützungsbedarfe und wirkst am Aufbau standardisierter Customer-Success-Prozesse und KPIs mit.

## Qualifikation

- Mehrjährige praktische Erfahrung im Customer Success, SaaS-Umfeld, Account Management, Software-Support, Technical Account Management oder Implementierungsmanagement

- Erfahrung als Business Analyst:in, Anforderungsanalyst:in oder in einer vergleichbaren Rolle; Erfahrung in der Spezifikation von Anforderungen und Erstellung von User Stories ist von Vorteil

- Ausgeprägte Kommunikationsstärke, Freude am direkten Kundenkontakt und ein verbindliches, serviceorientiertes Auftreten

- Hohe Tech-Affinität sowie die Fähigkeit, dich schnell und eigenständig in eine Softwareplattform und neue Funktionen einzuarbeiten

- Strukturierte, eigenverantwortliche und zuverlässige Arbeitsweise mit ausgeprägter Lösungsorientierung sowie sehr gute Deutschkenntnisse und gute bis sehr gute Englischkenntnisse

Dein Bildungsweg ist für uns zweitrangig. Entscheidend sind deine Persönlichkeit, deine Fähigkeiten und relevante praktische Erfahrungen. Interesse an digitalen Lösungen für Bauwerke, Infrastruktur oder technische Anwendungen ist von Vorteil, aber keine Voraussetzung.

## Benefits

- **Umfassendes Onboarding:** Startklar ab Tag 1 - mit strukturierter Einführung und kontinuierlicher Betreuung durch eine:n Mentor:in.

- **Verantwortung & Projektvielfalt:** Du übernimmst Verantwortung für die Betreuung unserer InfraCloud-Kund:innen und wirkst am weiteren Aufbau von Prozessen mit.

- **Kultur & Zusammenarbeit:** Dynamische aber dennoch familiäre, wertschätzende Atmosphäre, ein hilfsbereites Team, kurze Wege, offene Türen - pragmatisch, lösungsorientiert und auf Augenhöhe.

- **Freiraum & Eigenverantwortung:** Viel Gestaltungsspielraum und Vertrauen in deine Expertise - mit Rückhalt, wenn du ihn brauchst.

- **Weiterentwicklung inklusive:** Learning-on-the-job sowie interne und externe Trainings und Fortbildungen, die dich weiterbringen.

- **Starke Tools:** Eine Vielzahl an Software- und Kommunikationsprogrammen für effiziente Kundenbetreuung, Anforderungsaufnahme, Dokumentation und Zusammenarbeit.

- **Flexibilität, die passt:** flexible Arbeitszeiten und Arbeitszeitkonto sowie hybrides Arbeiten - für bessere Vereinbarkeit von Arbeit und Privatleben.

- **Vorsorge & Mobilität:** Zuschuss zur betrieblichen Altersvorsorge sowie Zuschüsse zum Deutschlandticket oder fürs Parkhaus.

- **Fitness & Gesundheit:** Bezuschussung von Urban Sports Club oder Hansefit plus weitere Angebote im Rahmen des betrieblichen Gesundheitsmanagements.

- **Extras, die den Alltag schöner machen:** freie Getränke, zahlreiche gemeinsame Events, Mitarbeitervorteilsportal, Geburtstagsgutschein und viele weitere Sozialleistungen.

Klingt spannend?

Dann sende uns deinen Lebenslauf oder mehr über den Button „Bewerben“ oder per E-Mail. Wenn Du noch offene Fragen hast, wende Dich gerne an unsere Recruiterin Kerstin Pöpplau unter 0151 705 91 700! Nicht jeder Punkt passt? Bewirb dich trotzdem - den Rest entwickeln wir mit Dir gemeinsam.

**Wir freuen uns auf deine Bewerbung!**

HydroMapper GmbH

Veritaskai 6

21079 Hamburg

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
