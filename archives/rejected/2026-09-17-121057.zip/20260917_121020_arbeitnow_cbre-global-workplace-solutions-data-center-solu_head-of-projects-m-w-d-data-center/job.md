# Head of Projects (m/w/d) - Data Center

Posted: 2026-09-17T07:00:28Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**ABOUT CBRE DATA CENTER SOLUTIONS**

CBRE Data Center Solutions (DCS) is a part of the CBRE Group with over 155.000 employees worldwide and delivers fully integrated real estate, facilities and technology solutions for Data Center owners, occupiers and investors across the globe. As a dedicated business line within CBRE, DCS is dedicated to solving complex challenges within every stage of the real estate / facility lifecycle.

In Germany alone, our more than 1,200 employees are competent and passionate about serving as strategic partners. We offer our employees the best conditions for professional and personal development and to realize their full potential throughout their careers. Join us and bring your strengths to bear!

We provide our employees the best conditions to develop professionally and personally and to realise their full potential in the course of their career.

Join us now in **Frankfurt a. M**. and bring your unique talent and skills to our Team.

## Tasks

The Head of Projects leads and grows CBRE's Asset Upgrade and Replacement (AUR) service line across DACH and CEE, with full P&L accountability and direct responsibility for delivery, business development and team performance. Projects span Mechanical and Electrical upgrades and replacements in live 24/7 data centre environments, alongside Civil and fabric, fire alarm and suppression, and Security (access control and CCTV) works. The current regional revenue base is approximately $3 million annually, with aggressive year-on-year growth as the primary objective. The role operates as part of a wider project leadership community alongside the Whitespace, ICT and PjM service line leads, requiring close cross-functional collaboration to maximise regional impact. The role is based in Frankfurt, Germany, with regular travel across DACH and CEE required and occasional out-of-hours attendance for critical works windows.

**Key Responsibilities**

- Own and grow the regional P&L through pipeline development, client conversion and new business wins; selling services whenever possible to deliver aggressive year-on-year revenue growth.

- Lead the safe, on-time, on-margin delivery of capital asset upgrade and replacement projects across DACH and CEE, maintaining consistent governance, delivery standards and performance metrics.

- Build and convert a 12-to-24-month sales pipeline through an established network of data centre clients, investors and co-location operators; lead all bids, tenders and proposals.

- Apply industry-focused procurement strategies, including competitive tendering, supply chain selection and back-to-back subcontract structures, ensuring commercial compliance across FIDIC and other relevant contract frameworks.

- Recruit, coach, mentor and develop a high-performing team of Senior Project Managers, Project Managers and Project Support professionals; lead workforce planning and succession.

- Act as a credible senior representative for CBRE, presenting with equal confidence to prospective clients, industry forums and internal site operations teams.

- Partner with internal CBRE QHSE, Finance, Commercial, Sales, Procurement, Account, Technical and Operations leadership to align project delivery with regional business objectives, treating internal operational teams as valued client stakeholders.

- Ensuring project administration is ‘audit-ready’ as all times for the area of responsibility. This requires a thorough understanding of the delivery processes and IT tools, so that the project team members are clear on their objectives.

- Identifying continuous improvements for best business practices is essential.

## Requirements

- At least 7 years' experience delivering projects within the region. A minimum 3 years of People management across multi-countries is expected

- End-to-end P&L accountability; strong working knowledge of FIDIC and other recognised contract frameworks; able to identify and manage commercial risk across multi-jurisdiction projects

- Proven ability to develop and apply industry-focused procurement strategies, including supply chain selection, competitive tendering and back-to-back subcontracts

- Direct management of project professionals including recruitment, development, performance management and succession planning

- Track record of growing a projects revenue line; established network across DC clients, investors and co-lo operators in DACH/CEE

- Recognised PM qualification (PMI PMP, APM PMQ or equivalent); Engineering degree or diploma

- Business-level English and German (written and spoken)

## Benefits

- Future-proof job opportunity with a true development guarantee in one of the fastest-growing Data Centre markets worldwide

- TOP trainings with internationally recognized state-of-the-art certifications

- Attractive salaries based with a great bonus, annual salary assessment/increase, company car for private use and other good benefits

- 30 days of vacation per year for all employees

- International working environment with inspiring cross-border career opportunities

- Creative working culture with challenging responsibilities and a high level of autonomy

- DIVERSITY, OCCUPATIONAL SAFETY and WORK-LIFE BALANCE are practiced values!

***Do you need more good reasons? Please take a look at our recent won awards:***

- Top Company 2026 (for the fifth consecutive year among the top 5% of employers in Germany on Kununu)

- Best Place to Work (Glassdoor)

- Top 50 Employers for Gender Equality 2026 (The Times)

- World's Leading Facilities Management Provider for Data Centres 2026 (Data Centre Magazine)

- Best Workplace for Women 2026 (LATINA Style)

- Commitment to Diversity and Talent Development Award 2025 (Datacloud Global Awards)

- Outstanding Contribution to Skills and Training Award (DCS Awards)

- Best Data Centre Operator 2025 (Data Centre World Awards)

**Have We Sparked Your Interest?**

Please apply online by submitting your CV and relevant supporting documents/certificates (no cover letter required) and indicate your earliest possible start date and salary expectations.

To help protect the environment, we kindly ask that you apply exclusively through our applicant management system and refrain from submitting applications by post.

Hale Bati | Talent Acquisition Specialist

CBRE GWS IFM Industrie GmbH | Data Center Solutions

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
