# Full Stack Product Developer (m/w/d)

Posted: 2026-09-17T08:09:37Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**Aufgaben  **

**Du willst Technologie gestalten, die direkt etwas bewegt? **

Bei Table.Briefings entwickeln wir digitale Produkte für ein wachsendes Medienunternehmen. Unsere Software hilft dabei, Prozesse effizienter zu machen, neue Geschäftsmodelle zu ermöglichen und unseren Redaktionen den Rücken freizuhalten – damit sie sich auf das konzentrieren können, was sie am besten können: hochwertigen Journalismus!
Als dritter interner Entwickler bzw. dritte interne Entwicklerin übernimmst du eine zentrale Rolle in unserem Tech-Team. Du arbeitest an der gesamten Entwicklungskette: von der ersten Idee über Konzeption und Umsetzung bis zu Deployment, Betrieb und Weiterentwicklung.
Dabei geht es nicht nur darum, Features zu programmieren. Du hilfst uns, die richtigen Probleme zu erkennen, Anforderungen zu schärfen und Lösungen zu entwickeln, die für unser Business, unsere Nutzerinnen und Nutzer und unsere Redaktionen wirklich einen Unterschied machen.

**Deine Aufgaben **

- Du konzipierst, entwickelst und betreust unsere Webanwendungen, APIs und Apps.
- Du arbeitest an unseren Statamic-basierten Plattformen und entwickelst unser CMS weiter.
- Du entwickelst neue Funktionen mit unserem bestehenden Tech-Stack und verbesserst bestehende Lösungen kontinuierlich.
- Du beschäftigst dich mit dem Einsatz und der Optimierung von Large Language Models und Coding Agents– zur Automatisierung interner Prozesse und für neue Produktfeatures.
- Du entwickelst und integrierst RESTful APIs, zum Beispiel zur Anbindung von Systemen wie ActiveCampaign.
- Du wirkst bei der Konfiguration, Wartung und Absicherung unserer Linux-Server und Deployment-Prozesse mit.
- Du übersetzt Anforderungen aus unterschiedlichen Bereichen in klare technische Lösungen.
- Du bringst Struktur in komplexe oder noch nicht vollständig definierte Aufgaben und sorgst dafür, dass aus Ideen umsetzbare Produkte werden.
- Du arbeitest eng mit Stakeholdern, Produktverantwortlichen, Redaktion und Geschäftsführung zusammen.

**Unser Tech-Stack - Wir arbeiten unter anderem mit: **

- PHP und Laravel
- Statamic
- PostgreSQL
- Livewire
- HTML, CSS und JavaScript
- RESTful APIs
- Linux-Servern und modernen Deployment-Prozessen
- Large Language Models und Coding Agents
Du musst unseren Tech-Stack nicht bereits vollständig beherrschen – wichtiger sind uns dein technisches Verständnis, deine Kommunikationsstärke und deine Fähigkeit, komplexe Anforderungen schnell in gute Lösungen zu übersetzen. Du solltest aber Lust haben, mit unseren Technologien zu arbeiten und dich schnell in neue Systeme und Themen einzuarbeiten.
Wir suchen keine Person, die jedes Tool schon einmal eingesetzt hat, sondern jemanden, der gute technische Entscheidungen trifft, Zusammenhänge versteht und Verantwortung übernimmt.

**Qualifikation**

- Du hast fundierte Erfahrung in der Softwareentwicklung und beherrschst mindestens eine relevante Programmiersprache sicher.
- Du hast idealerweise Erfahrung mit Webanwendungen, APIs und Datenbanken.
- Du interessierst dich für unseren Tech-Stack und hast Lust, dich inLaravel,Statamic, PostgreSQL und Livewire einzuarbeiten oder darin weiterzuentwickeln.
- Du verstehst, wie man LLMs und CodingAgentssinnvoll und verantwortungsvoll in der Softwareentwicklung einsetzt – oder möchtest es lernen.
- Du kennst dich mit Linux-Servern,Deploymentund grundlegenden Fragen der IT-Sicherheit aus oder bist bereit, dich in diese Themen einzuarbeiten.
- Du kannst komplexe Probleme schnell erfassen, priorisieren und in konkrete nächste Schritte übersetzen.
- Du kommunizierst klar und gerne – auch mit Menschen, die nicht technisch arbeiten.
- Du kannst unterschiedliche Anforderungen und Perspektiven zusammenbringen und sicher mit Stakeholdern umgehen.
- Du arbeitest selbstständig, zuverlässig und lösungsorientiert.
- Du behältst auch dann den Überblick, wenn Anforderungen sich verändern, Informationen zunächst unvollständig sind oder mehrere Themen gleichzeitig auf dem Tisch liegen.
- Du hast Freude daran, in solchen Situationen Ruhe, Struktur und Verbindlichkeit zu schaffen.
- Sehr gute Deutschkenntnisse sind für die Kommunikation im Team und mit unseren Stakeholdern unerlässlich.

**Was uns wichtig ist**

Wir entwickeln nicht zum Selbstzweck. Unser Ziel ist Software, die unmittelbar Wirkung entfaltet: für unser Geschäft, für die Vervielfachung unserer Lizenzen und für unsere Redaktionen, die täglich anspruchsvolle Inhalte produzieren.
Dafür suchen wir eine Persönlichkeit, die Verantwortung übernimmt, Fragen stellt und sich aktiv einbringt. Du solltest dich in einem meinungsstarken, dynamischen Umfeld wohlfühlen, unterschiedliche Perspektiven aushalten und deine eigenen Ideen überzeugend vertreten können. Gleichzeitig ist uns wichtig, dass du pragmatisch bleibst und gemeinsam mit anderen zu guten Lösungen kommst.

**Benefits**

**Wir bieten dir: **

- Eine Schlüsselposition in einem innovativen und wachstumsstarken Medienunternehmen
- Die Möglichkeit,unseren Tech-Stackaktiv mitzugestalten und weiterzuentwickeln
- Viel Eigenverantwortung und kurze Entscheidungswege
- Einen vielseitigen Job mit direktem Einfluss auf unser Business und unsere Produkte
- Eine unbefristete Festanstellung in Teilzeit oder Vollzeit
- 28 Tage Urlaub
- Flexibilität bei Arbeitszeit und Arbeitsort > Drei Tage pro Woche in unserem Büro in Berlin-Mitte, zwei Tage im MobileOffice
- Persönliche und fachliche Entwicklungsmöglichkeiten in einer echten Wachstumskultur
- Eine offene, freundliche Atmosphäre mit Partnerinnen, Partnern und Kolleginnen und Kollegen aus der ganzen Welt

**Deine Bewerbung **

Wir freuen uns auf deinen Lebenslauf und ein kurzes, persönliches Motivationsschreiben mit maximal 1.000 Zeichen: Warum möchtest du als Full Stack Product Developer (m/w/d) bei Table.Briefings arbeiten?

Uns interessiert besonders, welche Probleme du gerne löst, wie du mit unterschiedlichen Anforderungen umgehst und was dich daran reizt, Technologie mit konkretem unternehmerischem und redaktionellem Nutzen zu entwickeln.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
