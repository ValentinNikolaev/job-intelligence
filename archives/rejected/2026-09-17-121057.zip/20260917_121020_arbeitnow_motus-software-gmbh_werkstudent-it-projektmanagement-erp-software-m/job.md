# Werkstudent - IT Projektmanagement ERP Software (m/w/d)

Posted: 2026-09-17T08:00:27Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Du hast Erfahrung mit ERP-Software? Du magst es, Skripte für Datenbanken zu verfassen und Daten von einer Datenbank zur anderen Datenbank zu migrieren? Du liebst es, beim Testen neuer Softwarefunktionen auch noch den kleinsten Fehler zu finden, damit die Funktion perfekt wird?

Dann unterstütze uns im Anwendungssupport für unsere weit verbreitete Warenwirtschaftslösung OC-Karat!

Wir haben seit eine große Pipeline an Kundenprojekten, die von einer Legacy Softeware auf eine neu entwickelte Software migriert werden. Dabei brauchen wir deine Unterstützung!

## Aufgaben

Zu Deinen Aufgaben gehören:

- Begleitung von Digitalisierungsprojekten bei Kunden

- ggf. Durchführung von Anwenderschulungen und Workshops

- Schreiben und Anpassen von Datenbankskripten

- Installation und Konfiguration unserer Softwareprodukte beim Kunden

- Bearbeitung und Lösung von Anwenderfragen

- Unterstützung bei der Weiterentwicklung der Software

- Softwaretesting

Deine mittelfristigen Weiterentwicklungsmöglichkeiten sind:

- Einstieg als Projektmanager mit hoher Eigenverantwortung

- Key Account Management

## Qualifikation

- Du befindest dich im Studium oder hast eine abgeschlossene Ausbildung zum Kaufmann/ Kauffrau für Digitalisierungsmanagement (Informatikkaufmann/frau) (w/m/d), Fachinformatiker (m/w/d), oder eine vergleichbare Qualifikation.

- Alternativ liegen Deine Interessen im IT-Bereich und Du hast Dir bereits wichtige Business IT-Themen beigebracht

- Erfahrung in der Stapler- oder Baumaschinenbranche ist wünschenswert

- Du denkst vernetzt und hast Spaß daran im Anwendungskontext Fehler zu erkennen und diese eigenverantwortlich mit dem Anwender zu lösen

- Du punktest mit der Fähigkeit, Dich auf Menschen und ihre unterschiedlichen IT-Kenntnisse einzustellen und technische Themen verständlich zu vermitteln

- Du bist in der Lage die Arbeitsweise der Anwender kritisch zu hinterfragen und auch alternative Lösungen aufzuzeigen

- Du hast bereits Erfahrung in der Anwendung, Installation, Konfiguration und Betreuung einer MSSQL-Datenbank basierten Software gesammelt

- Du hast bereits Erfahrung in der Stapler- oder Baumaschinenbranche

## Benefits

Der Grundstein für unsere Software wurde bereits vor 30 Jahren gelegt, wir selbst sind jedoch ein junges, flexibles Team und unterstützen Dich gerne in deiner Weiterentwicklung!

Wir sitzen in unserem modernen Büro in Regensburg und kommen mit dem Firmen eBike oder eCar zur Arbeit. Zweimal pro Woche bekommst du bei uns ein kostenloses Mittagessen. Diese Features bieten wir dir auch an.

Egal was Du heute machst, trau Dich und werde Teil unseres Teams.

Schick uns Deine Bewerbung zu. Wir möchten Dich als Person kennenlernen – ein klassisches Anschreiben muss gar nicht sein. Bis bald!

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
