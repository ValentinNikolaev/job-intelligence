# Technical Field Engineer - Montage & Inbetriebnahme (gn)

Posted: 2026-09-17T08:00:28Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Unser Kunde ist ein erfolgreiches, global agierendes und eigentümergeführtes Unternehmen der Kunststoff und Gummiindustrie mit rund 130 Mitarbeitenden und ein „Hidden Champion“ auf seinem Gebiet. Mit seiner 75-jährigen Historie zählt das Unternehmen heute zu den führenden Innovationstreibern der Branche. Kurze Entscheidungswege und flache Hierarchien zeichnen die Arbeitskultur aus.

## Aufgaben

- Montage, Inbetriebnahme und Weiterentwicklung von Sonderanlagen im Bereich Dosiertechnik mit Schwerpunkt Europa

- Blockweiser Einsatz am Produktionsstandort in Alzey zur Unterstützung von Anlagenprojekten und Montage

- Steuertechnische Optimierung der Performance beim Kunden

- Beratung und Unterstützung der Kunden

- Übernahme von kleinen bis mittleren Projekten im entsprechenden Bereich

- Unterstützung des Sales Teams bei spezifischen Kundenanforderungen

- Ausarbeiten von Steuerungsdiagrammen und Prüfen von Spezifikationen

- Erstellung von Lastenheften für Steuerungserweiterungen durch externe Partner

- Durchführen von Abnahmen bei Lieferanten und Koordination von internen Versuchen zur Optimierung von Sonderanlagen

## Qualifikation

- Abgeschlossene technische Ausbildung, bevorzugt im Bereich Elektrotechnik, Mechatronik, Mechanik oder Automatisierungstechnik

- Erste Berufserfahrung in Bau und Inbetriebnahme von kleinen und mittelgroßen Sondermaschinen

- Gute Kenntnisse gängiger Sicherheitstechnik im Maschinen- und Anlagenbau, Know How im Bereich Regelungstechnik ist von Vorteil

- Kundenorientiertes Auftreten und termingerechtes, selbstorganisiertes Arbeiten

- Ausgeprägte Lösungskompetenz und Hands-on-Mentalität

- Reisebereitschaft an den Standort in Alzey und für internationale Einsätze

- Fähigkeit, auf verschiedenen Ebenen erfolgreich zu kommunizieren

- Gute fachspezifische Englischkenntnisse

## Benefits

- Flache Hierarchien und ein kollegiales Miteinander in einer zukunftssicheren Branche

- Ein vielseitiger und verantwortungsvoller Arbeitsplatz

- Beste fachliche und berufliche Weiterentwicklungsmöglichkeiten

- Attraktives Vergütungspaket

Sie bringen noch nicht alle Anforderungen mit? Lassen Sie uns trotzdem ins Gespräch kommen?

Gerne steht Ihnen Kerstin Mader, 06174 9619 310, für weitere Informationen zur Verfügung.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
