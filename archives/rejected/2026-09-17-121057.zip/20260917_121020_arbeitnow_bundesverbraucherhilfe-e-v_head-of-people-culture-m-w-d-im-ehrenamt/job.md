# Head of People & Culture (m/w/d) im Ehrenamt

Posted: 2026-09-17T07:00:28Z

## Rejection

- Category: tech_stack
- Reason: role does not mention Go/Golang or PHP

Ehrenamtliche Mitwirkung lebt davon, dass Menschen sich willkommen fühlen, sich vernetzen können und Sinn in ihrer Aufgabe erleben. Genau dafür schaffen wir jetzt eine eigene Rolle.

Als Head of People & Culture sorgen Sie für eine gute interne Atmosphäre, bauen Formate für Vernetzung und Austausch auf und gestalten das Ehrenamtserlebnis bei der Bundesverbraucherhilfe aktiv mit. Die Rolle ist direkt am Präsidium angesiedelt und zunächst auf drei Monate befristet.

Nach dieser Aufbauphase entsteht daraus eine vollwertige People & Culture Experience: mit eigenen Merkmalen, Anerkennungsformaten und Benefits, weitgehend ohne Budget. Genau das ist die Herausforderung. Wer Lust hat, sich ihr zu stellen, ist bei uns richtig.

## Aufgaben

- Aufbau und Pflege einer Willkommens- und Wohlfühlatmosphäre für alle ehrenamtlich Tätigen

- Entwicklung von Formaten für Vernetzung und Austausch im Ehrenamt, etwa Themenrunden, feste Treffen oder informelle Formate

- Aufbau von Netzwerkperspektiven: Kontakte zwischen ehrenamtlich Tätigen und Fachbereichen herstellen und pflegen

- Gestaltung eines guten Ehrenamtserlebnisses von der Einarbeitung bis zur laufenden Begleitung

- Konzeption einer People & Culture Experience mit Merkmalen, Anerkennungsformaten und Benefits bei sehr geringem Budget

- Enge Abstimmung mit dem Präsidium zu Ausrichtung und Prioritäten

- Einholen von Feedback der ehrenamtlich Tätigen und Ableiten konkreter Verbesserungen

## Qualifikation

- Erfahrung im Community-, Kultur- oder Ehrenamtsmanagement, in Personalarbeit oder einer vergleichbaren Rolle

- Gespür für Menschen und Stimmungen, verbunden mit der Fähigkeit, daraus konkrete Formate zu entwickeln

- Kreativität im Umgang mit knappen Ressourcen: gute Ideen zählen mehr als Budget

- Organisationsgeschick und Verlässlichkeit bei der Umsetzung

- Klare, wertschätzende Kommunikation gegenüber sehr unterschiedlichen Menschen

- Ein formaler Abschluss ist keine Voraussetzung, Ihre Praxis zählt

## Benefits

- Volle Gestaltungsfreiheit beim Aufbau der People & Culture Experience der Bundesverbraucherhilfe

- Direkter Draht zum Präsidium und zu allen Fachbereichen

- Berufliche Vernetzung mit Fach- und Führungskräften aus Recht, Wirtschaft und Verwaltung

- Qualifizierte Tätigkeitsbescheinigung und auf Wunsch ein Referenzschreiben

- Zugang zu unseren Fortbildungen, Fachtagungen und Ausschusssitzungen

- Freie Zeiteinteilung, Zusammenarbeit überwiegend remote

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
