# Senior Full Stack Developer | Java / React (f/m/d)

Posted: 2026-09-17T08:00:30Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

## Become a Part of ACCURIDS

Join us and help shape the future of pharmaceutical data!

At ACCURIDS, we’re building the data backbone behind life-science innovation — a system that identifies, links, and standardizes critical enterprise data in compliance with global standards such as ISO IDMP. We help global life-science companies launch products faster, more safely, and with better patient outcomes.

At ACCURIDS, you’ll join a collaborative, growth-driven environment where your work makes a real impact from day one.

As a key member of our Product Development team, you will operate with a high degree of autonomy while collaborating closely with backend and frontend engineers, QA, DevOps, and product owners. In this role, you will directly align with cross-functional engineering stakeholders and indirectly impact our customers through the features and fixes you deliver, while having direct access to our CTO as a trusted mentor and technical sparring partner

## How you’ll make an impact:

- **Own features end-to-end:** Take full ownership of user-facing features across the stack, from refining business logic in modern Java/Spring Boot to building responsive React/TypeScript interfaces via GraphQL and REST APIs.

- **Amplify velocity with AI:** Lead by example in our AI-native engineering culture. You will use tools like Cursor, Claude, or Gemini to accelerate scaffolding, refactoring, and test writing, while acting as the ultimate authority on architectural integrity, security, and quality. As agents take on more of the routine coding, your leverage moves up a level - you direct them, shape the architecture, and own the quality of what ships.

- **Shape next-gen architecture:** Drive our evolution toward a multi-module Spring Modulith architecture, optimize complex PostgreSQL and Elasticsearch queries, and dive into domain-specific RDF semantic data structures.

- **Elevate quality & team standards:** Raise the bar on engineering hygiene by maintaining rigorous test coverage (JUnit, Testcontainers, Playwright), conducting sharp merge request reviews (including AI-generated code), and mentoring junior engineers.

## What helps you succeed:

- **Proven SaaS Experience:** 5+ years of shipping and owning full-stack features in production software. A degree in Computer Science, Fachinformatiker training, or strong hands-on experience as a career-changer are all welcome.

- **AI-Native Mindset:** AI tools (Cursor, Claude and Gemini) are an integral part of your daily workflow. You view AI as an output amplifier, combine high curiosity with deep technical judgment, and reject skepticism toward AI-assisted coding.

- **Location & Work Permit:** You are based in Germany within a reasonable commuting distance to our Cologne office (NRW) and hold a valid German work permit.

- **Full-Stack Core Stack:** Deep expertise in modern Java (17+), the Spring Boot ecosystem (Spring Security, Spring Data JPA), React 18, TypeScript, Redux, and GraphQL (Apollo Client).

- **Data & Testing Rigor:** Strong hands-on experience with SQL/PostgreSQL, Flyway migrations, full-stack testing (Unit, Integration, E2E), and GitLab CI/CD pipelines.

- **Languages:** Business fluent English is required; German skills are a strong plus.

- **Bonus Impact:** Prior experience with semantic web tools (RDF, SPARQL, Apache Jena), Material UI (MUI 5), Elasticsearch, or pharma/life-sciences domains (FHIR, IDMP) is a major plus.

## Why you’ll love working here:

- **Impactful Career Growth:** Evolve into a Technical Lead / Lead Engineer role or deepen your specialization in semantic data platforms, AI features, or platform architecture as we scale.

- **Epic Office & Hybrid Work:** Work from our brand-new office in the KölnTurm, featuring breathtaking views over the city (even higher than the view from the Cologne Cathedral!). Enjoy flexible hybrid options. (Note: On-site presence in Cologne/NRW is required; fully remote work is not offered).

- **Community & Industry Events:** Connect and grow your network through exclusive industry events hosted regularly right in our scenic office space.

- **Competitive Compensation:** Fixed salary package of €75,000 – €100,000 per year for a full-time, permanent position.

- Work-Life Balance & Perks: 30 days of paid vacation, a personal learning budget, hardware of your choice (Mac, Linux, Windows), and your choice between a subsidized Urban Sports Club membership or a €50/month City Plus Card.

- **Empowered Culture:** High trust, flat hierarchies, and an environment where your decisions directly shape the product.

## Not ticking every box?

Not ticking every box? We encourage you to apply anyway! We know great talent doesn’t always follow a checklist and we care more about your potential, curiosity, and motivation to learn.

At ACCURIDS, we’re committed to building a diverse and inclusive team. We especially encourage women and people from underrepresented backgrounds in tech, science, and data to apply.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
