# Financial Controller

Posted: 2026-09-17T08:30:58Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**YOUR FUTURE, ON DEMAND**

The ideal blend of stability and flexibility. A genuinely human employer that cares for people and the planet. True autonomy to shape what comes next, for us and you. This is the perfect platform to take your career where you want.

Back in 2005, we pioneered Europe’s first TV streaming service. Today, we’re the world’s first certified climate neutral TV streaming provider. Several million users across three countries. Over 230 colleagues of 47 nationalities. We’re the grown-up start-up, helping to shape a better future since day one. That hasn’t changed, even if the world has. We’re friendly, international, inclusive – and our people say we’re reliable and transparent, too. It’s why they trust us and believe in what we do.

**THE ROLE**

We are looking for a Controller to join the Zattoo Finance Team as a direct report to the CFO. You will support the team by providing accounting and controlling expertise for the Consumer business, while proactively and professionally executing the responsibilities and tasks you are assigned to. The position is based in Berlin, while the majority of the Finance team is based in Zurich.

**THE FINANCE TEAM**

The Zattoo Finance Team combines years of experience along with a high degree of responsibility and professionalism. We are eight people taking care of accounting, controlling, taxes, insurance and various processes centrally for our two companies in Switzerland and Germany.

## WHAT YOU’LL DO

- Responsible for Controlling and all Finance matters relating to our Consumer business, which mainly consists of our subscription business.

- Support with monthly close activities, prepare and provide timely and accurate reporting and analysis, business partnering, forecasting, budgeting, audit, etc.

- Lead and support projects, particularly in digitalisation and automation efforts

- Develop process and system enhancements to improve efficiency and accuracy

- Collaborate with colleagues from other departments e.g. Sales, Business Intelligence, Marketing, etc.

- Act as a primary user and expert of essential financial systems

## WHAT YOU’LL BRING

- Profound education in accounting and controlling plus a minimum of 5 years of controlling or FP&A experience

- Fluent in verbal and written English

- Experience supporting a distributed team

- Excellent communication and organizational skills

- Team player with superior interpersonal skills

- Analytical, systematic and strategic thinker

- Proactive and independent working style

- Track record for delivering high-quality work

- Experience with AI and BI tools and methodologies

- Modelling and scenario building, including predictive forecasting models

- Experience in building driver-based business models

- Experience in building state-of-the-art dashboards and reporting for specific target groups

- Strong mathematical skills

- **Bonus**: Previous work experience in an international environment, experience in business partnering

**WHY JOIN US?**

At Zattoo, you’re always on firm ground with real freedom to explore. You’ll have the support and opportunity you need to go far, while you’re helping us create a sustainable and entertainment-filled future for all.

## WHAT WE OFFER YOU

- **Reward**: strong market competitive salary

- **Recharge**: 30 days vacation plus public holidays

- **Regulate**: trust based flexible working hours and the option for remote work worldwide for up to 8 weeks per year

## Plus:

- **We’re sharing:** Free access to the best streaming experience on the market

- **We’re developing:** Your own development budget, German classes and Zattoo all-company hack days

- **We’re inclusive: ‘**Zattooies’ are a fun, engaged, and diverse team made up of 47 nationalities

- **We’re healthy:** Health checks, mental wellbeing support, team sports and more!

- **We’re responsible:** We are carbon neutral, an active employee Green team, discounted BVG tickets and free bike rentals

- **We’re sociable:** A calendar of events with fireside chats, lunches, in-house bar, BBQ’s, monthly socials, summer party and an annual off-site event

Zattoo enables our users to view indiscriminately and we reflect that in our team too. Regardless of race, gender, sexual orientation, religion, national origin, age, disability or any other characteristic protected by law we encourage everyone to apply and will give everyone equal consideration. We are an equal opportunities employer — join us and help build a diverse team dedicated to revolutionising the way you watch TV.

We are committed to ensuring fair, open, and equitable hiring practices and are happy to answer any questions you may have about us or the role throughout the whole process. In line with the EU Pay Transparency Directive, we share the applicable compensation range with you before your first interview.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
