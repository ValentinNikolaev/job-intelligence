# Entwicklungsingenieur:in (m/w/d) Stentgraft und Delivery-System

Posted: 2026-09-17T08:31:00Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Aortex entwickelt patientenindividuelle Stentgrafts für die endovaskuläre Behandlung von Aortenaneurysmen. Ein erheblicher Teil der betroffenen Patientinnen und Patienten ist mit den heute verfügbaren Standardprothesen anatomisch nicht behandelbar und bleibt deshalb von der schonenden, minimalinvasiven Therapie ausgeschlossen. Genau für diese Menschen entwickeln wir eine neue Prothesengeneration: eine ultradünne, präzisionsgewebte Polymermembran, kombiniert mit einem selbstexpandierenden Nitinol-Stent, gefertigt in einem patentierten Webverfahren und geometrisch aus der CT-Bildgebung des einzelnen Patienten abgeleitet.

Wir sind ein Startup in einer frühen Entwicklungsphase mit Sitz in Hamburg, gegründet von zwei Ingenieuren mit Erfahrung aus der industriellen Serienentwicklung. In Magdeburg entsteht gerade unser zweiter Standort, an dem wir unsere Entwicklungsarbeit bündeln. Unser deutsches Patent ist erteilt, die internationale Anmeldung läuft, erste Prototypen sind charakterisiert, und wir arbeiten eng mit universitätsmedizinischen Zentren und etablierten Auftragsfertigern zusammen.

Dafür suchen wir dich: Du bringst das Gesamtsystem aus Stentgraft, Stent, Katheter und Delivery-System technisch voran und baust die Prüfumgebung auf, mit der wir seine Sicherheit und Leistungsfähigkeit belegen. Du arbeitest an einem Produkt, das noch entsteht, und prägst damit, wie es am Ende aussieht.

## Aufgaben

- Du entwickelst das Gesamtsystem aus Stentgraft und seinen Subkomponenten Stent, Katheter und Delivery-System weiter, von der Konzeptidee über die Konstruktion bis zum funktionsfähigen Prototyp.

- Du legst die Einzelkomponenten aus, bewertest Werkstoff- und Fügekonzepte und überführst Entwurfsentscheidungen in belastbare Konstruktionen.

- Du konzipierst, konstruierst und baust die Prüfstände und Prüfaufbauten, die wir für Verifizierung und Validierung benötigen, und wählst die geeigneten Prüfmethoden dafür aus.

- Du führst Prüfungen durch, wertest sie aus und dokumentierst die Ergebnisse so, dass sie im Rahmen der Design Controls und der technischen Dokumentation verwendbar sind.

- Du stimmst dich eng mit unseren externen Entwicklungs- und Fertigungspartnern ab, übersetzt unsere Anforderungen in klare Vorgaben und begleitest die Umsetzung bis zum abgenommenen Ergebnis.

- Du arbeitest direkt mit den Gründern und mit unserer Regulatory-Affairs- und Qualitätsfunktion zusammen und bringst die technische Perspektive in die Produktentscheidungen ein.

## Qualifikation

Das solltest du mitbringen:

- Ein abgeschlossenes Studium in Maschinenbau, Medizintechnik, Werkstofftechnik oder eine vergleichbare Qualifikation.

- Berufserfahrung in der Entwicklung von Medizinprodukten, mit eigener Verantwortung für Bauteile oder Baugruppen.

- Sicherheit in der Konstruktion, im Umgang mit CAD und in der Auslegung mechanischer Systeme.

- Erfahrung im Aufbau von Prüfständen oder in der Planung und Durchführung mechanischer Prüfungen nach Norm.

- Sehr gute Deutsch- und Englischkenntnisse in Wort und Schrift, da wir mit internationalen Partnern und Zulieferern arbeiten.

- Bereitschaft zu gelegentlichen Reisen zu unserem Hamburger Standort und zu unseren Partnern.

Darüber hinaus freuen wir uns über:

- Erfahrung mit implantierbaren Produkten der Klasse III und besonders gern mit Stentgrafts, Kathetern oder Delivery-Systemen.

- Kenntnisse der einschlägigen Normen für endovaskuläre Prothesen, etwa ISO 25539-1 und ISO 7198.

- Erfahrung mit Nitinol oder anderen Formgedächtnislegierungen sowie mit textilen Werkstoffen.

- Vertrautheit mit Design Controls, Risikomanagement und der Verifikations- und Validierungslogik in der Medizintechnik.

- Erfahrung in der Zusammenarbeit mit externen Entwicklungspartnern und Auftragsfertigern.

## Benefits

Du bekommst bei uns viel Eigenverantwortung. Das Team in Magdeburg ist am Anfang klein, entsprechend groß ist dein Einfluss auf die technischen Entscheidungen, und du siehst deine Arbeit unmittelbar im Produkt wieder. Mit dem Wachstum des Standorts kann später auch Führungsverantwortung hinzukommen, wenn du das möchtest. Die Stelle ist unbefristet.

Bei den Rahmenbedingungen orientieren wir uns an markt- und branchenüblichen Standards und haben als Unternehmen in der Aufbauphase zugleich die Flexibilität, gemeinsam mit dir eine Lösung zu finden, die zu deiner Lebenssituation passt. Dein fester Arbeitsplatz ist Magdeburg. Wenn du dafür umziehst, unterstützen wir dich beim Wechsel. Die Stelle ist auf Vollzeit ausgelegt, über Teilzeitmodelle sprechen wir aber gern.

Vor allem aber arbeitest du an einem Produkt, das Menschen eine Behandlung ermöglichen kann, die ihnen heute verwehrt bleibt.

Schick uns deinen Lebenslauf. Ein klassisches Anschreiben und ein Foto brauchen wir nicht. Schreib uns stattdessen ein paar Sätze dazu, an welcher technischen Aufgabe du bisher am meisten gelernt hast und warum.

Wir freuen uns über Bewerbungen unabhängig von ethnischer Herkunft, Geschlecht, Religion oder Weltanschauung, Behinderung, Alter und sexueller Identität. Entscheidend ist für uns, was du kannst und was du bewegen willst.

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
