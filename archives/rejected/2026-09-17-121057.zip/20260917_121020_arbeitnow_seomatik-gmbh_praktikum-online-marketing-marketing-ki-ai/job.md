# Praktikum Online-Marketing / Marketing / KI / AI

Posted: 2026-09-17T07:30:39Z

## Rejection

- Category: tech_stack
- Reason: role does not mention Go/Golang or PHP

Die SEOMATIK GmbH ist eine der führenden Online-Marketing-Agenturen in Europa.

Als Full-Service-Agentur in der digitalen Vermarktung von Produkten und Websites liegen unsere Kernkompetenzen in den Bereichen Suchmaschinenoptimierung (SEO), Suchmaschinenwerbung (SEA) und Social Media Marketing (SMM).

Aktuell bieten wir folgende Position:

Praktikum Online-Marketing / Marketing / StartUp (KI / AI)

## Aufgaben

- Suchmaschinenoptimierung

- Suchmaschinenwerbung

- Social Media Marketing

- Content Marketing

- Webdesign Begleitung

- Grafik Design Begleitung

- etc.

## Qualifikation

- Kreativität,

- Aufgeschlossenheit,

- Teamfähigkeit,

- Motivation,

- und HUMOR (sehr wichtig!) :)

## Benefits

- spannende Projekte,

- grosses Lernpotential,

- familiäre Athmosphäre,

- offener Umgang,

- Nebentätigkeit nach Abschluss Praktikum,

- Zukunftschancen.

Wir freuen uns über Deine Bewerbung :)

LG Agnes Kmety

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
