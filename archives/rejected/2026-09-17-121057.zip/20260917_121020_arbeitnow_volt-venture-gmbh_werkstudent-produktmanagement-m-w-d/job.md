# Werkstudent Produktmanagement (m/w/d)

Posted: 2026-09-17T08:00:26Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Du bist auf der Suche nach einem abwechslungsreichen Job als Werkstudent:in und lebst für die Schnelligkeit im Web? Du bist umsetzungsorientiert, packst gerne an und hast Lust, die Produktdarstellung in unserem Shop weiterzuentwickeln und gemeinsam mit uns neue Rekorde zu knacken?

**Dann suchen wir Dich!**

Clevertronic ist der Rundum-Partner fürs Smartphone-Leben:

Wir kaufen gebrauchte Smartphones, Tablets und weitere Elektronik an, bereiten sie professionell auf und geben ihnen als geprüfte Refurbished-Produkte ein zweites Leben.

Mit rund 100 Kolleg:innen, mehr als 50 Mio. Euro Umsatz und profitablem Wachstum ohne Investoren gehören wir zu den größten Refurbishing-Unternehmen Deutschlands. Jetzt entwickeln wir Clevertronic zu einer Plattform rund ums Smartphone-Leben weiter - mit neuen Produkten, Geschäftsmodellen und Märkten.

## Aufgaben

Als Werkstudent:in im Produktmanagement arbeitest du mit unserem Sortiment an Smartphones, Tablets, Smartwatches und Macbooks. Du sorgst dafür, dass unsere Artikel überall richtig ankommen.

**Deine Aufgaben:**

- Du beobachtest den Wettbewerb und hältst unsere Preise marktgerecht

- Du legst neue Artikel an und pflegst Produktdaten

- Du optimierst die Darstellung im eigenen Webshop und auf Marktplätzen

- Du begleitest ein Gerät vom Ankauf bis zur vollständigen Vermarktung

- Du wertest Prüfungen, Ankäufe und Rücksendungen aus und leitest daraus Verbesserungen ab

## Qualifikation

- Eine zuverlässige und gewissenhafte Arbeitsweise

- Keine Angst vor Zahlen

- Teamfähigkeit und Lust darauf, etwas Neues zu lernen

- 15-20 Stunden Zeit in der Woche

- Du bist eingeschrieben, idealerweise in BWL, Wirtschaftsinformatik oder einem ähnlichen Fach, aber wir schauen mehr auf Interesse als auf den Studiengang

- Von Vorteil: Erfahrung mit Excel

## Benefits

- Echte Gestaltungsfreiheit und kurze Wege: deine Entscheidungen sehen wir direkt am Ergebnis.

- Einen klaren Entwicklungspfad: bei uns wächst du mit deinen Fähigkeiten, übernimmst zunehmend Verantwortung und kannst deinen fachlichen Impact kontinuierlich vergrößern.

- Ein Umfeld, das KI nicht ausbremst, sondern fördert: bei uns ist KI-gestütztes Arbeiten der Standard, nicht die Ausnahme.

Für einen guten Arbeitsalltag ist ebenfalls gesorgt:

flexible Arbeitszeiten, ein modernes Büro direkt am Friedenspark in Münster, subventioniertes Lunch, Snack-Kiosk, Kaffee und frisches Obst, Mitarbeiterrabatte auf unsere Produkte und Corporate Benefits.

Klingt nach dem richtigen nächsten Schritt für dich?

Dann schick uns deinen Lebenslauf - ein klassisches Anschreiben brauchst du nicht. Erzähl uns lieber kurz, warum du bei uns ins Produktmanagement einsteigen möchtest.

Wir freuen uns darauf, dich kennenzulernen!

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
