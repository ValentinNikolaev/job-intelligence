# Talent Acquisition Specialist / Recruiter (m/w/d)

Posted: 2026-09-17T08:31:00Z

## Rejection

- Category: tech_stack
- Reason: role does not mention Go/Golang or PHP

## Talent Acquisition Specialist / Recruiter (m/w/d)

**Recruiting im Gesundheitswesen | Remote | ab 30 Stunden pro Woche | Zum nächstmöglichen Zeitpunkt**

Für unsere medizinischen Versorgungszentren suchen wir jemanden, der den Bewerbermarkt kennt, passende Talente aufspürt und Menschen für einen Wechsel gewinnt. Jemanden, der versteht, warum eine Stelle unbesetzt bleibt und daraus die richtigen Maßnahmen ableitet.

Bei **Centric Health Deutschland** arbeiten wir mit unseren medizinischen Versorgungszentren an einer starken ambulanten Versorgung. Dafür brauchen unsere Teams die richtigen Menschen: von Medizinischen Fachangestellten über Physician Assistants bis hin zu Ärztinnen und Ärzten.

**Dein Auftrag: diese Menschen für uns gewinnen.** Du verantwortest das strategische und operative Recruiting – von der Entwicklung zielgerichteter Suchstrategien bis zur erfolgreichen Einstellung. Dabei arbeitest du eng mit unserer zentralen HR-Funktion und den Verantwortlichen vor Ort zusammen.

**Das liegt in deiner Hand**

- **Suchstrategien entwickeln:** Du klärst mit den Standorten, wen sie brauchen, hinterfragst Anforderungsprofile und übersetzt sie in eine realistische Suchstrategie.

- **Active Sourcing vorantreiben:** Du recherchierst gezielt geeignete Kandidatinnen und Kandidaten, entwickelst individuelle Ansprachen und gewinnst auch passive Talente für ein erstes Gespräch. Dafür nutzt du berufliche Netzwerke, Fachplattformen und Direktansprache und baust nachhaltige Kandidatenkontakte auf.

- **Recruiting-Kanäle gezielt einsetzen:** Du schreibst überzeugende Stellenanzeigen, wählst passende Plattformen und nutzt Social Recruiting dort, wo du unsere Zielgruppen tatsächlich erreichst.

- **Menschen für einen Wechsel gewinnen:** Du führst qualifizierte Erstgespräche, erkennst Motivation und Passung und vermittelst ein ehrliches Bild der Position und des jeweiligen Standorts.

- **Besetzungsprozesse verbindlich steuern:** Du hältst Kandidatinnen, Kandidaten und Fachbereiche im Austausch, holst Feedback ein und begleitest den Prozess bis zur Einstellung. Die fachliche Bewertung und finale Auswahl liegen bei den zuständigen Führungskräften.

- **Recruiting-Tool aufbauen und verwalten:** Gemeinsam mit HR gestaltest du den Aufbau und die Weiterentwicklung unseres Bewerbermanagementsystems. Du richtest Workflows, Bewerbungsphasen und Vorlagen ein und verantwortest die laufende Administration und Datenqualität.

- **KPIs tracken und Maßnahmen ableiten:** Du verfolgst relevante Recruiting-Kennzahlen wie Time-to-Hire, Kanalperformance sowie Rücklauf- und Konversionsquoten. Du machst Fortschritte und Engpässe sichtbar und nutzt die Ergebnisse, um Suchstrategien und Prozesse gezielt zu verbessern.

**Das bringst du mit**

- **Fundierte praktische Recruiting-Erfahrung:** Du hast Stellen eigenständig besetzt und kannst konkret erklären, mit welchen Maßnahmen du geeignete Menschen gewonnen hast. Erfahrung aus einem Unternehmen oder einer Personalberatung ist gleichermaßen willkommen.

- **Sicherheit im Active Sourcing:** Du beherrschst gezielte Recherche, passende Suchtechniken und individuelle Direktansprache. Du weißt, wie du Interesse weckst und aus einem ersten Kontakt einen qualifizierten Austausch entwickelst.

- **Gute Gesprächsführung:** Du hörst genau zu, stellst die richtigen Fragen und gewinnst Vertrauen. Du kannst Chancen überzeugend vermitteln und Erwartungen realistisch einordnen.

- **Eigenständige Prozesssteuerung:** Du priorisierst parallele Vakanzen, hältst Vereinbarungen nach und sprichst offen an, wenn Anforderungen, Rückmeldungen oder Rahmenbedingungen eine Besetzung erschweren.

- **Systemverständnis und analytischen Blick:** Du arbeitest sicher mit Bewerbermanagementsystemen und Recruiting-Kennzahlen. Idealerweise hast du bereits ein Recruiting-Tool mit aufgebaut oder bestehende Workflows weiterentwickelt.

- **Idealerweise Erfahrung im Gesundheitswesen:** Du kennst die Besonderheiten der Personalgewinnung für Praxen, MVZ oder andere medizinische Einrichtungen. Das ist ein Plus – entscheidend ist dein Recruiting-Handwerk.

**Was dich bei uns erwartet**

- **Ein klarer fachlicher Fokus:** Dein Schwerpunkt ist die Personalgewinnung für unsere Standorte – von der Suche bis zur Einstellung.

- **Verantwortung und Gestaltungsspielraum:** Du gestaltest Suchstrategien, Ansprache, Recruiting-Prozesse und die dazugehörige Tool-Struktur aktiv mit.

- **Direkte Zusammenarbeit:** Du arbeitest eng mit unserer zentralen HR-Funktion und den einstellenden Führungskräften. Prioritäten und anspruchsvolle Besetzungen stimmen wir gemeinsam ab.

- **Flexibles Arbeiten:** Du arbeitest vollständig remote mit einem Umfang ab 30 Wochenstunden. Optional steht dir unser Standort in Frankfurt zur Verfügung.

- **Eine Aufgabe mit sichtbarer Wirkung:** Mit jeder passenden Einstellung stärkst du unsere Praxisteams und damit die medizinische Versorgung vor Ort.

**Zeig uns, wie du Recruiting angehst.**

Wir freuen uns auf deinen Lebenslauf, deinen frühestmöglichen Starttermin, deinen gewünschten Stundenumfang und deine darauf bezogene Gehaltsvorstellung.

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
