# B2B Sales Manager (w/m/d)

Posted: 2026-09-17T08:40:04Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Unser Ziel ist eine Solaranlage auf jedem Dach, ein Speicher in jedem Haus und ein E-Auto in jeder Garage. Enpal macht das möglich mit einer integrierten Gesamtlösung für dezentrale Energie – von Solaranlage und Batteriespeicher über Wallbox, Smart Meter bis zur Wärmepumpe. Herzstück ist unsere KI-gestützte Plattform [Enpal.One](http://Enpal.One)+, die tausende Systeme intelligent vernetzt und Strombezug sowie -einspeisung effizient am Energiemarkt optimiert.

Bist Du bereit für Lösungen, die mehr als nur ein Versprechen sind und täglich echte Lebensqualität in tausende Haushalte bringen? Was du bei Enpal gestaltest, liefert morgen sauberen Strom und verändert nachhaltig, wie wir Energie nutzen.

### **Deine Aufgaben**

-

Du akquirierst, betreust und entwickelst eigenverantwortlich unsere Geschäftskunden aus dem Handwerk – sowohl operativ als auch strategisch.

-

Du identifizierst neue Geschäftspotenziale, berätst deine Kunden lösungsorientiert und baust langfristige Partnerschaften auf.

-

Du erstellst individuelle Angebote, führst Preis- und Vertragsverhandlungen und begleitest den gesamten Verkaufsprozess bis zum erfolgreichen Abschluss.

-

Du analysierst die Bedürfnisse deiner Kunden, erkennst Optimierungspotenziale und entwickelst passende Lösungen aus unserem Produkt- und Dienstleistungsportfolio.

-

Du arbeitest proaktiv mit unseren Geschäftskunden zusammen und nutzt dafür moderne CRM- und Shopsysteme.

-

Du arbeitest eng mit den Bereichen Einkauf, Operations und Customer Success zusammen, um die bestmögliche Kundenerfahrung sicherzustellen.

-

Du trägst aktiv zum Wachstum unseres Vertriebsteams und zum Aufbau des größten Energieunternehmens des 21. Jahrhunderts bei..

### **Dein Profil**

-

Du bist eine kommunikative, sympathische und überzeugende Persönlichkeit mit ausgeprägter Kundenorientierung.

-

Du hast idealerweise Erfahrung im B2B-Vertrieb oder Key Account Management.

-

Du führst Verhandlungen sicher und hast Freude daran, nachhaltige Kundenbeziehungen aufzubauen.

-

Du arbeitest strukturiert, eigenverantwortlich und lösungsorientiert.

-

Du besitzt eine hohe Eigenmotivation und hast den Ehrgeiz, deine Vertriebsziele zu erreichen und zu übertreffen.

-

Kenntnisse aus den Bereichen Photovoltaik, Wärmepumpen, Elektrotechnik oder Großhandel sind ein Plus, aber keine Voraussetzung.

Du bist interessiert, auch wenn du nicht alle Anforderungen erfüllst? Bewirb dich trotzdem! Wir freuen uns darauf, dein Potenzial zu entdecken - unabhängig davon, ob deine Erfahrung jede einzelne Voraussetzung erfüllt. ☀️

###
**Darauf kannst Du Dich freuen**

-

**Arbeite in Deutschlands erstem grünen Unicorn** - Gestalte aktiv die solare Energiewende mit.

-

**Die Sonne scheint auf der ganzen Welt** - Bei Enpal arbeitest du mit einem hochmotivierten, diversen Team aus über 65 Nationalitäten.

-

**Grown-up Business & Startup Spirit** - In unserem modernen Office in Berlin-Friedrichshain findest du von höhenverstellbaren Tischen, Tischtennisplatte bis gefüllten Getränkekühlschränken und Barista-Coffee alles was das Herz begehrt.

-

**Dein Kick-start bei Enpal** - Onboarding-Tag mit Welcome Bag, Buddy-Programm und einem Team, das dich wirklich abholt.

-

**Bleib auf dem Laufenden & gestalte mit** -** **Transparente All-Hands, kurze Entscheidungswege und eine offene Feedback-Kultur, denn ohne Fehler gibt es keinen Fortschritt.

-

**Energiewende geht nur gemeinsam** - Bei Enpal erwartet dich ein legendärer Teamspirit und unvergessliche Team- und Companyevents.

-

**Dein Extra-Boost** -** **29 Urlaubstage + je ein freier Tag an Heiligabend und Silvester, vergünstigte Mitgliedschaft bei Wellhub und Corporate Benefits. Alles, was dir hilft, Arbeit und Leben gut zu verbinden.

*Wir bei Enpal sind stolz auf die Vielfältigkeit unseres Teams. Weder bei der Einstellung noch während des Beschäftigungsverhältnisses werden Entscheidungen auf Basis von Hautfarbe, Religion oder religiösen Glaubens, ethnischer oder nationaler Herkunft, Nationalität, Geschlechteridentität, sexuelle Orientierung, Behinderung oder Alter getroffen. Enpal steht für einen sicheren Arbeitsplatz und geht gegen Diskriminierung und Belästigung jeglicher Art vor.*

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
