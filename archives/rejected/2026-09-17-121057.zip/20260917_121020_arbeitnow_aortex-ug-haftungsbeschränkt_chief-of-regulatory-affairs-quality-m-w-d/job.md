# Chief of Regulatory Affairs & Quality (m/w/d)

Posted: 2026-09-17T08:30:59Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Aortex entwickelt patientenindividuelle Stentgrafts für die endovaskuläre Behandlung von Aortenaneurysmen. Ein erheblicher Teil der betroffenen Patientinnen und Patienten ist mit den heute verfügbaren Standardprothesen anatomisch nicht behandelbar und bleibt deshalb von der schonenden, minimalinvasiven Therapie ausgeschlossen. Genau für diese Menschen entwickeln wir eine neue Prothesengeneration: eine ultradünne, präzisionsgewebte Polymermembran, kombiniert mit einem selbstexpandierenden Nitinol-Stent, gefertigt in einem patentierten Webverfahren und geometrisch aus der CT-Bildgebung des einzelnen Patienten abgeleitet.

Wir sind ein Startup in einer frühen Entwicklungsphase mit Sitz in Hamburg, gegründet von zwei Ingenieuren mit Erfahrung aus der industriellen Serienentwicklung und Strategieberatung. In Magdeburg entsteht mit dieser Position unser zweiter Standort, den du von Beginn an mit aufbaust. Unser deutsches Patent ist erteilt, die internationale Anmeldung läuft, erste Prototypen sind charakterisiert, und wir arbeiten eng mit universitätsmedizinischen Zentren und etablierten Auftragsfertigern zusammen. Vor uns liegt der Weg zur klinischen Erstanwendung und zur Zulassung eines Medizinprodukts der Klasse III, einschließlich der dafür notwendigen präklinischen Prüfungen und Tierstudien.

Dafür suchen wir dich: Du übernimmst die regulatorische Verantwortung für unser Produkt und baust unser Qualitätsmanagementsystem von Grund auf. Du gestaltest also nicht ein bestehendes System mit, sondern entscheidest, wie es aussieht.

## Aufgaben

- Du entwickelst die regulatorische Strategie für Aortex in Europa und den USA, legst Konformitätsbewertungsroute und Zeitplan für unser Produkt der Klasse III fest und steuerst die Auswahl und Zusammenarbeit mit der Benannten Stelle.

- Du baust unser Qualitätsmanagementsystem nach ISO 13485 auf und führst es zur Zertifizierung.

- Du verantwortest das Risikomanagement nach ISO 14971 sowie die Planung der biologischen Beurteilung nach ISO 10993.

- Du strukturierst die technische Dokumentation, legst die anzuwendenden Normen fest (unter anderem ISO 25539-1 und ISO 7198) und leitest daraus die Prüfpläne für Entwicklung und Verifizierung ab.

- Du planst die präklinische Prüfstrategie, von der Bench-Testung über die biologische Beurteilung bis zur GLP-konformen Tierstudie, und stellst sicher, dass die erzeugte Evidenz den Anforderungen der Behörden standhält.

- Du bereitest die klinische Bewertung und unsere geplante First-in-Human-Studie nach ISO 14155 regulatorisch vor und begleitest die Interaktion mit Behörden und Ethikkommissionen, einschließlich FDA Pre-Submissions und der Antragstellung für Breakthrough-Programme.

- Du qualifizierst unsere Vertragsfertiger aus regulatorischer Sicht, definierst die Anforderungen an Prozessvalidierung und Lieferantenmanagement und verankerst sie vertraglich.

- Du baust mittelfristig dein eigenes Team am neuen Standort Magdeburg auf und leitest dieses

## Qualifikation

- Abgeschlossenes Studium in Medizintechnik, Ingenieurwissenschaften, Naturwissenschaften oder eine vergleichbare Qualifikation.

- Mehrjährige Erfahrung in der Entwicklung von Medizinprodukten, idealerweise im kardiovaskulären Bereich und besonders gerne bei Aortenstentgrafts oder verwandten implantierbaren Produkten der Klasse III.

- Fundierte Kenntnisse der regulatorischen Anforderungen nach MDR und FDA, inklusive der jeweiligen Zulassungswege für Hochrisikoprodukte.

- Praktische Erfahrung im Aufbau, Betrieb oder in der Auditierung eines QMS nach ISO 13485 sowie im Risikomanagement nach ISO 14971.

- Lust darauf, Themen selbst zu bearbeiten, statt sie zu delegieren, und die Fähigkeit, in einem kleinen Team mit begrenzten Ressourcen Prioritäten zu setzen.

- Sehr gute Deutsch- und Englischkenntnisse in Wort und Schrift.

- Bereitschaft zu gelegentlichen Reisen zu unserem Hamburger Standort und zu Partnern.

## Benefits

Du bekommst bei uns echten Gestaltungsspielraum. Du arbeitest direkt mit den Gründern zusammen, entscheidest über den regulatorischen Kurs des Unternehmens und siehst deine Arbeit unmittelbar im Produkt wieder. Bei den Rahmenbedingungen orientieren wir uns an markt- und branchenüblichen Standards und haben als Unternehmen in der Aufbauphase zugleich die Flexibilität, gemeinsam mit dir eine Lösung zu finden, die zu deiner Lebenssituation passt. Dein fester Arbeitsplatz ist Magdeburg, wo wir unseren zweiten Standort aufbauen und wo du zu den ersten Personen im Team gehörst. Wenn du dafür umziehst, unterstützen wir dich beim Wechsel. Die Stelle ist auf Vollzeit ausgelegt, über Teilzeitmodelle sprechen wir aber gern.

Vor allem aber arbeitest du an einem Produkt, das Menschen eine Behandlung ermöglichen kann, die ihnen heute verwehrt bleibt.

Schick uns deinen Lebenslauf. Ein klassisches Anschreiben und ein Foto brauchen wir nicht. Schreib uns stattdessen drei Stichpunkte, welches regulatorische Projekt du bisher am spannendsten fandest und warum du Aortex interessant findest. Bitte nenne uns ebenfalls deine Gehaltsvorstellung.

Wir freuen uns über Bewerbungen unabhängig von ethnischer Herkunft, Geschlecht, Religion oder Weltanschauung, Behinderung, Alter und sexueller Identität. Entscheidend ist für uns, was du kannst und was du bewegen willst.

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
