# IT System Engineer / Systemadministrator Citrix (m/w/d)

Posted: 2026-09-17T07:00:27Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Für ein großes Klinikum in Dortmund wird ein **IT System Engineer** **/ Systemadministrator (m/w/d) mit Schwerpunkt Citrix** **& Infrastruktur** gesucht. Im Fokus stehen der Betrieb und die Weiterentwicklung einer komplexen, virtualisierten IT-Landschaft mit hohen Anforderungen an Verfügbarkeit und Sicherheit.

## Aufgaben

- Administration und Weiterentwicklung der **Citrix-Umgebung** (Virtual Apps & Desktops, PVS, ADC/NetScaler)

- Administration von **Windows- und Linux-Servern**

- Planung und Steuerung von IT-Infrastrukturprojekten

- 2nd- und 3rd-Level-Support sowie Fehleranalyse

- Einführung neuer Technologien und Optimierung der IT-Landschaft

- Erstellung technischer Dokumentationen und Betriebskonzepte

- Zusammenarbeit mit weiteren IT-Teams

## Qualifikation

- Ausbildung als **Fachinformatiker Systemintegration**, Studium der Informatik oder vergleichbare Qualifikation

- Fundierte Kenntnisse in **Citrix**, idealerweise mit Zertifizierung

- Erfahrung in IT-Projekten

- Analytische, strukturierte und lösungsorientierte Arbeitsweise

- Team- und Kommunikationsstärke

- Bereitschaft zur **Rufbereitschaft**

- Gute Deutsch- und Englischkenntnisse

## Benefits

- **Mobiles Arbeiten**

- Vergütung nach **TVöD**

- Arbeitgeberfinanzierte betriebliche Altersvorsorge

- Fahrradleasing und Altersvorsorge über Entgeltumwandlung

- Zuschuss zum ÖPNV-Ticket

- Individuelle Fort- und Weiterbildungsmöglichkeiten

- Betriebliche Gesundheitsangebote

- Mitarbeiterrabatte

- Kollegiales IT-Team und strukturierte Einarbeitung

- Hoher Gestaltungsspielraum in einer technisch anspruchsvollen Infrastruktur

**Interesse geweckt? Dann lass uns unverbindlich sprechen.**

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
