# Service Assistent (m/w/d) in Vollzeit

Posted: 2026-09-17T09:00:53Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Autohaus Wormser GmbH, ein renommierter Händler für Kraftfahrzeuge, bietet eine spannende Karrieremöglichkeit als Service Assistent (m/w/d) in Vollzeit. Mit Standorten in Erlangen-Tennenlohe, Forchheim und Coburg, sind wir stolz auf unsere Unternehmenswerte wie Zugehörigkeit, Gemeinschaft, Antrieb, Bildung, Fairness, gegenseitiger Respekt, Offenheit, Verantwortung und Teamarbeit. Unsere Mission ist es, Mobilität persönlich, regional und digital erlebbar zu machen. Bewerben Sie sich jetzt und werden Sie Teil unserer dynamischen und respektvollen Gemeinschaft.

## Aufgaben

- Abgleich der Werkstattkapazität und Pflege im Terminplanungssystem

- Sicherstellung der Kundenmobilität

- Prüfung der Teileverfügbarkeit bei der Terminvergabe

- Durchführung des Telefondienstes für den Service

- Kundenbetreuung

## Qualifikation

- Erfolgreich abgeschlossene (kaufmännische oder technische) Berufsausbildung (w/m/d)

- Gewissenhaftigkeit, Kundenorientierung sowie Team- und Kommunikationsfähigkeit

- Berufserfahrung in der Automobilbranche (von Vorteil)

## Benefits

- Unbefristetes Arbeitsverhältnis nach der Probezeit

- Prämien

- Urlaubs-und Weihnachtsgeld

- Vermögenswirksame Leistungen

- 30 Tage Urlaub

- Bikeleasing

- Weiterbildungen durch die BMW AG

- Kostenfreier Kaffee und Tee sowie Parkplätze auf dem Gelände

- Betriebsfeiern

Möchten Sie Teil eines renommierten Autohauses werden und Ihre Leidenschaft für Kundenservice ausleben? Bewerben Sie sich jetzt als Service Assistent (m/w/d) in Vollzeit!

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
