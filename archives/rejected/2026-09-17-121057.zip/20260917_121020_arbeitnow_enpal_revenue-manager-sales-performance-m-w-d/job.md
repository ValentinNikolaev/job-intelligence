# Revenue Manager Sales Performance (m/w/d)

Posted: 2026-09-17T08:40:04Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Unser Ziel ist eine Solaranlage auf jedem Dach, ein Speicher in jedem Haus und ein E-Auto in jeder Garage. Enpal macht das möglich mit einer integrierten Gesamtlösung für dezentrale Energie – von Solaranlage und Batteriespeicher über Wallbox, Smart Meter bis zur Wärmepumpe. Herzstück ist unsere KI-gestützte Plattform [Enpal.One](http://Enpal.One)+, die tausende Systeme intelligent vernetzt und Strombezug sowie -einspeisung effizient am Energiemarkt optimiert.

Bist Du bereit für Lösungen, die mehr als nur ein Versprechen sind und täglich echte Lebensqualität in tausende Haushalte bringen? Was du bei Enpal gestaltest, liefert morgen sauberen Strom und verändert nachhaltig, wie wir Energie nutzen.

Als **Revenue Manager** bist du der operative Performance-Partner eines Sales-Standorts. Du verbindest Daten, operative Steuerung und enge Zusammenarbeit mit den Führungskräften vor Ort. Das ist **keine reine Analystenrolle**. Du bist nah am operativen Geschäft, arbeitest direkt mit Führungskräften und sorgst dafür, dass aus Daten konkrete Maßnahmen und aus Maßnahmen bessere Ergebnisse werden.

**Kurz gesagt: Performance verstehen. Probleme lösen. Umsetzung treiben. Ergebnisse verbessern.**

**Deine Aufgaben**

-

Analyse von Sales-KPIs und Funnel-Performance

-

Identifikation von Performance-Lücken und konkreten Hebeln

-

Ableitung und Umsetzung operativer Maßnahmen

-

Sparring mit Standortleitung, Unit Leads und Teamleitern

-

Nachhalten von Initiativen bis zum messbaren Ergebnis

-

Weiterentwicklung von Dashboards, KPI-Reviews und Performance-Transparenz

**Was du mitbringst**

-

Mehrjährige Erfahrung in einem performance-orientierten Umfeld

-

Sehr starke analytische Fähigkeiten und gutes KPI-Verständnis

-

Sicherer Umgang mit Excel, idealerweise Power BI

-

Verständnis für Sales Funnels und Vertriebssteuerung

-

Souveränes Auftreten und starke Kommunikationsfähigkeit

-

Hohe Eigenverantwortung, Geschwindigkeit und Umsetzungsstärke

-

Lust, bestehende Prozesse zu challengen und Verantwortung zu übernehmen

Du bist interessiert, auch wenn du nicht alle Anforderungen erfüllst? Bewirb dich trotzdem! Wir freuen uns darauf, dein Potenzial zu entdecken - unabhängig davon, ob deine Erfahrung jede einzelne Voraussetzung erfüllt. ☀️

###
**Darauf kannst Du Dich freuen**

-

**Arbeite in Deutschlands erstem grünen Unicorn** - Gestalte aktiv die solare Energiewende mit.

-

**Die Sonne scheint auf der ganzen Welt** - Bei Enpal arbeitest du mit einem hochmotivierten, diversen Team aus über 65 Nationalitäten.

-

**Grown-up Business & Startup Spirit** - In unserem modernen Office in Berlin-Friedrichshain findest du von höhenverstellbaren Tischen, Tischtennisplatte bis gefüllten Getränkekühlschränken und Barista-Coffee alles was das Herz begehrt.

-

**Dein Kick-start bei Enpal** - Onboarding-Tag mit Welcome Bag, Buddy-Programm und einem Team, das dich wirklich abholt.

-

**Bleib auf dem Laufenden & gestalte mit** -** **Transparente All-Hands, kurze Entscheidungswege und eine offene Feedback-Kultur, denn ohne Fehler gibt es keinen Fortschritt.

-

**Energiewende geht nur gemeinsam** - Bei Enpal erwartet dich ein legendärer Teamspirit und unvergessliche Team- und Companyevents.

-

**Dein Extra-Boost** -** **29 Urlaubstage + je ein freier Tag an Heiligabend und Silvester, vergünstigte Mitgliedschaft bei Wellhub und Corporate Benefits. Alles, was dir hilft, Arbeit und Leben gut zu verbinden.

*Wir bei Enpal sind stolz auf die Vielfältigkeit unseres Teams. Weder bei der Einstellung noch während des Beschäftigungsverhältnisses werden Entscheidungen auf Basis von Hautfarbe, Religion oder religiösen Glaubens, ethnischer oder nationaler Herkunft, Nationalität, Geschlechteridentität, sexuelle Orientierung, Behinderung oder Alter getroffen. Enpal steht für einen sicheren Arbeitsplatz und geht gegen Diskriminierung und Belästigung jeglicher Art vor.*

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
