# Customer Success - EMEA

Posted: 2026-08-29T11:40:18Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

## About ElevenLabs

ElevenLabs is an AI research and product company transforming how we interact with technology.

We launched in January 2023 with the first human-like AI voice model. Today, we serve millions of users and thousands of businesses - from fast-growing startups to large enterprises like Deutsche Telekom and Meta. Our investors are some of the world's most prominent, including Andreessen Horowitz, ICONIQ Growth and Sequoia. We've raised $781M in funding and our last valuation was $11B - multiples of 11, always.

We have expanded from voice into three main platforms:

-

ElevenAgents enables businesses to deliver seamless and intelligent customer experiences, with the integrations, testing, monitoring, and reliability necessary to deploy voice and chat agents at scale.

-

ElevenCreative empowers creators and marketers to generate and edit speech, music, image, and video across 70+ languages.

-

ElevenAPI gives developers access to our leading AI audio foundational models.

Everything we do is the result of the creativity and commitment of our team - builders doing the best work of their lives. We are researchers, engineers, and operators. IOI medalists and ex-founders. If you want to work hard and create lasting positive impact, we want to hear from you.

## How we work

-

**High-velocity: **Rapid experimentation, lean autonomous teams, and minimal bureaucracy.

-

**Impact not job titles: **We don’t have job titles. Instead, it’s about the impact you have. No task is above or beneath you.

-

**AI first:** We use AI to move faster with higher-quality results. We do this across the whole company—from engineering to growth to operations.

-

**Excellence everywhere: **Everything we do should match the quality of our AI models.

-

**Global team: **We prioritize your talent, not your location.

## What we offer

-

**Innovative culture:** You’ll be part of a generational opportunity to define the trajectory of AI, surrounded by a team pushing the boundaries of what’s possible.

-

**Growth paths: **Joining ElevenLabs means joining a dynamic team with countless opportunities to drive impact - beyond your immediate role and responsibilities.

-

**Learning & development**: ElevenLabs proactively supports professional development through an annual discretionary stipend.

-

**Social travel**: We also provide an annual discretionary stipend to meet up with colleagues each year, however you choose.

-

**Annual company offsite: **Each year, we bring the entire team together in a new location - past offsites have included Croatia and Italy.

-

**Co-working**: If you’re not located near one of our main hubs, we offer a monthly co-working stipend.

This role is remote and can be executed across EMEA. If you prefer, you can work from our offices in Dublin, London or Warsaw.

## About ElevenLabs

ElevenLabs is a research and product company defining the frontier of Audio AI. Millions of individuals use ElevenLabs to read articles, voice over their videos, and reclaim voices lost from disability. And the leading developers and enterprises use ElevenLabs to create Conversational AI agents for support, sales, and education.

ElevenLabs launched in January 2023 with the first AI model to cross the threshold of human-like speech. In January 2025, we raised a $180 million Series C round, valuing ElevenLabs at $3.3 billion. The round was co-led by Andreessen Horowitz and ICONIQ Growth, with continued support from the leading names in tech, including Nat Friedman, Daniel Gross, Instagram co-founder Mike Krieger, Oculus VR co-founder Brendan Iribe, DeepMind and Inflection co-founder Mustafa Suleyman, and many others.

ElevenLabs is only 2 years old and scaling rapidly. We are just getting started. If you want to work hard and have an incredible impact, we would love to hear from you.

## How we work

-

**High-velocity: **Rapid experimentation, lean autonomous teams, and minimal bureaucracy.

-

**Impact not job titles: **We don’t have job titles. Instead, it’s about the impact you have. No task is above or beneath you.

-

**AI first:** We use AI to move faster with higher-quality results. We do this across the whole company—from engineering to growth to operations.

-

**Excellence everywhere: **Everything we do should match the quality of our AI models.

-

**Global team: **We prioritize your talent, not your location.

## What we offer

-

**Learning & development**: Annual discretionary stipend towards professional development.

-

**Social travel**: Annual discretionary stipend to meet up with colleagues each year, however you choose.

-

**Annual company offsite: **We bring the entire company together at a new location every year.

-

**Co-working**: If you’re not located near one of our main hubs, we offer a monthly co-working stipend.

-

**Innovative culture:** You’ll be part of a generational opportunity to define the trajectory of AI, surrounded by a team pushing the boundaries of what’s possible.

## About the role

-

Be part of an early CS team with endless opportunities for impact . You’ll partner with the CS team to help develop a scalable CS playbook and framework that supports our customers in EMEA.

-

Build, maintain and own strong relationships with a book of 40-50 enterprise clients.

-

Play a key role in onboarding new clients and driving long term adoption of multiple products.

-

Monitor customer usage and adoption of our products to identify areas for improvement or revenue expansion.

-

Own expansion and renewal of accounts within your book of business - this is a commercial role.

-

Own your customer success KPIs (NRR/GRR) and contribute to CS OKR goals.

## **Requirements**

-

5-7 years of previous experience in Customer Success in a fast paced, SaaS organisation.

-

Experience demonstrating and unlocking value for customers with technical, mission critical products (such as conversational AI).

-

Commercial experience - you will own renewals and expansion for your book of business, driving towards best in class NRR results.

-

Demonstrates a strong builder mindset with a relentless focus on customer excellence and scalable product solutions.

-

Exceptional communicator with the ability to establish, nurture, and maintain relationships across all levels of customer organizations, including complex stakeholder environments.

-

Strong analytical thinker and creative problem-solving skills to address diverse customer challenges and drive optimal outcomes.

-

Must be fluent in English - additional languages are a plus.

#LI-Remote

We are an equal opportunity employer and do not discriminate on the basis of race, religion, national origin, gender, sexual orientation, age, veteran status, disability or other legally protected statuses.

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
