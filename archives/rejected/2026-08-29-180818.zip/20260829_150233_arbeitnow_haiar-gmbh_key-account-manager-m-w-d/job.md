# Key Account Manager*in (m/w/d)

Posted: 2026-08-29T15:17:20Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Als **Key Account Manager*in** verantwortest die Bestandskunden von CARvinci® in Autohäusern und Autohausgruppen — von der Vertragsverlängerung bis zum Ausbau des Accounts. Du bist die zentrale Ansprechperson für unsere Kunden – von der Einführung über die laufende Betreuung bis zur strategischen Weiterentwicklung. Du verstehst die Prozesse unserer Kunden im Detail, übersetzt sie in konkrete Lösungen und sorgst dafür, dass unser Produkt echten Mehrwert stiftet. Gleichzeitig bringst du die Erkenntnisse aus dem Kundenkontakt zurück ins Unternehmen und gestaltest unsere internen Abläufe aktiv mit.

## Aufgaben

- Du führst feste Jour Fixes und Review-Termine mit deinen Key Accounts durch.

- Du baust belastbare Beziehungen auf allen Ebenen auf — vom Fachanwender bis zur Geschäftsführung des Autohauses.

- Du erkennst ungenutzte CARvinci-Funktionen bei deinen Kunden und entwickelst Strategien, um diese Funktionen in den Einsatz zu bringen.

- Du arbeitest eng mit Vertrieb, Produkt und Support zusammen und bringst Kundenfeedback strukturiert zurück ins Unternehmen.

## Qualifikation

- Erfahrung im Account Management oder Customer Success — idealerweise im B2B- oder SaaS-Umfeld.

- Verhandlungssicherheit auf Entscheiderebene und Erfahrung im Umgang mit unterschiedlichen Stakeholdern.

- Ausgeprägtes Prozessverständnis und die Fähigkeit, komplexe Sachverhalte klar zu vermitteln.

- Strukturierte, eigenverantwortliche Arbeitsweise mit hoher Service- und Abschlussorientierung.

- Abgeschlossenes Studium oder eine vergleichbare Qualifikation sowie verhandlungssichere Deutschkenntnisse.

## Benefits

- Faire Vergütung — marktgerecht und regelmäßig überprüft.

- Büro in Münster — vor Ort und hybrid.

- 30 Tage Urlaub — plus frei am Geburtstag.

- Freie Ausstattung — Mac, Windows oder Linux, Software deiner Wahl.

- Mittagessen im Office.

- EGYM Wellpass.

Klingt nach dir?

Dann freuen wir uns auf deine Bewerbung – ein Lebenslauf genügt, ein Anschreiben ist kein Muss.

Der Bewerbungsprozess:

- Online-Bewerbung — Formular ausfüllen, Anschreiben optional.

- Kurzes Telefonat — zehn Minuten, um beide Seiten abzuklopfen.

- Kennenlerngespräch per Video — rund 30 Minuten mit Team und Rolle.

- Praxisaufgabe — ein kurzes Demo-Gespräch anhand eines echten Kundenfalls, ca. 45 Minuten Vorbereitung.

- Finales Gespräch — vor Ort in Münster oder per Video.

- Willkommen im Team — Angebot plus strukturiertes Onboarding ab Tag eins.

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
