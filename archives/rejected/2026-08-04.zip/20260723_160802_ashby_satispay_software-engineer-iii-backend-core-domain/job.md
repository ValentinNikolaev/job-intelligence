# Software Engineer III, Backend - Core Domain

Posted: 2026-04-09T15:46:06.335+00:00

## Rejection

- Category: stale
- Reason: published_at 2026-04-09T15:46:06.335+00:00 is older than 7 days

About us

Satispay began by rethinking the simple act of a payment to remove the friction from our daily routines. But we didn't stop there. Today, we are building a complete financial platform designed to empower people and concretely improve their lives. By giving our 6 million users a clear, open path to pay, save, and invest, we are evolving into the definitive destination for every financial need.



What you'll be doing

As a Software Engineer, Backend in the Core Team, you’ll play an important role in building and maintaining the backbone of our payment platform. You will be a key contributor to the technical quality and delivery of robust systems that support multiple services and product teams across the company. Here's what your day-to-day will look like:

 - Contribute to core platform domains: Help build, maintain, and scale our most sensitive systems—such as the Transaction Ledger, Identity & Access Management (IAM), or Payment Orchestration.

 - Develop risk & financial engines: Implement and optimise services dedicated to bank integrations, credit risk, and real-time fraud detection to protect our "source of truth."

 - Collaborate on technical solutions: Participate in technical analysis for new projects, engage in technical discussions, and contribute to high-quality documentation (Smart Papers).

 - Drive engineering quality: Ensure technical excellence by writing clean code, implementing rigorous testing strategies, and executing safe rollouts while resolving technical blockers.

 - Work in an AI-powered environment: Leverage AI tools daily to write and optimise code, speed up root cause analysis, and generate documentation to raise engineering efficiency.

 - Grow and collaborate: Work with senior engineers to elevate your architectural skills while supporting junior team members in adopting best practices for secure and reliable development.



Who we're looking for

We need a problem-solver who loves teamwork and gets things done. If you're curious and ready for real ownership, you'll fit in! Does this sound like you?

 - Experience: You have at least 3 years of experience as a Backend Engineer, with a proven track record of building and maintaining scalable microservices.

 - Technical Foundations: Deep expertise in Java and Spring Boot, with a solid understanding of distributed systems and external dependencies like banking APIs.

 - Cloud Awareness: Good exposure to cloud environments (AWS is a plus) and relational databases (PostgreSQL).

 - Reliability Mindset: You care deeply about system health, data integrity, and clean business logic, with comfort in debugging complex service issues.

 - Communication: You are able to communicate technical concepts clearly and collaborate effectively with both technical and non-technical peers.

 - Language proficiency: You are passionate about FinTech and fluent in English.



CareAbout: how we support your impact

We move fast, and evolution never stops. It's a fun ride, but it can be challenging. To make sure our people truly thrive, we're committed to making their lives easier, both in the office and out in the world. That's why we created CareAbout:

 - ❤️ Health (Private insurance for you and your family, psychological support with Serenis, mental health workshops)

 - 💰 Financial resources (Stock Option Plan, Meal vouchers, Relocation support if you're moving countries)

 - ⚙️ Growth and development (Professional development programs, Internal mobility, Language courses with Preply)

 - 🌱 Flexibility (Unlimited PTO, Hybrid working policy*, Flexible working hours)

 - 👨‍👩‍👧 Family (Enhanced parental leave, Additional leave for child sickness)

*We embrace three days per week in-office (Tuesday and Thursday + 1 of your choice), with the option to request extra remote time.



Salary: €45,000 - €53,000 gross per annum
This range is set using objective, gender-neutral criteria for the role's core requirements. However, we do not believe in putting a ceiling on talent. The final compensation package is tailored according to your unique experience and expertise. If your skills go beyond the standard profile, apply anyway so we can discuss a package that reflects your true value.



Equal opportunity employer

At Satispay, we're proud to be an equal opportunity employer. We celebrate diversity and inclusion, welcoming individuals of all backgrounds. This opportunity is open to everyone, regardless - for instance - of race, colour, religion, sex, gender identity, sexual orientation, and national origin. Join us in a workplace where everyone belongs!



Learn more about us

Our values and pillars aren't just fancy words on a page - they really shape everything we do. Explore them here. https://www.satispay.com









#LI-VR1
#LI-Hybrid







By submitting this application, I acknowledge that I have read and understood the content of the Privacy Policy https://www.satispay.com/en-it/legal-hub/privacy-policy/candidates/
