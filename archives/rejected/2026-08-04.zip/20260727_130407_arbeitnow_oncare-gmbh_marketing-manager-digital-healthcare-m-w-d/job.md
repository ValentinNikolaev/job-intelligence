# Marketing Manager - Digital Healthcare (m/w/d)

Posted: 2026-07-27T11:00:35Z

## Rejection

- Category: language_requirement
- Reason: hard German language requirement without English green light

Bei myoncare schaffen wir eines der innovativsten Gesundheits-Ökosysteme weltweit. Unsere Plattform verbindet Patienten, Kliniken, Ärzte und Partner in einem einzigen digitalen System und ermöglicht etwas, das es bisher nicht gab: **kontinuierliche, personalisierte Gesundheitsbegleitung – sicher, skalierbar und global.**

Doch echte Innovation braucht Sichtbarkeit. Deshalb suchen wir jemanden, der nicht nur Marketing denkt, sondern Marketing baut. Jemanden, der Technologien versteht, Performance liebt, kreativ arbeitet und strategisch plant.

**Jemanden, der unsere Vision in starke Botschaften, messbares Wachstum und skalierbare Kampagnen verwandelt.**

Wenn du Lust hast, Marketing nicht „abzuarbeiten“, sondern **aktiv zu gestalten**, Daten zu nutzen, um smarter zu skalieren, und Kampagnen aufzusetzen, die im Gesundheitsmarkt wirklich etwas bewegen – dann bist du bei uns richtig.

Erlebe und gestalte die digitale Revolution des Gesundheitswesens hautnah als unser(e) neue(r) **Marketing Manager (w/m/d).**

## Aufgaben

**Produktmarketing (Strategisch)**

- Entwickle und schärfe die Positionierung und das Messaging, um unsere Zielgruppen nachhaltig zu überzeugen.

- Erarbeite fundierte Marktanalysen und entwickle aussagekräftige Kunden-Personas.

- Führe Wettbewerbsanalysen durch, um die Marktlandschaft zu verstehen und unser Produkt zu differenzieren.

**Content Marketing (Hands-On)**

- Du erstellst zielgruppenspezifischen Content für Website, Social Media, Newsletter, Presse und weitere relevante Kanäle.

- Du betreust unsere Social-Media-Kanäle, steigerst Reichweite und Interaktion und reagierst auf Trends in Echtzeit.

- Entwickle performante Inhalte zur Unterstützung von Lead-Generierungskampagnen (z. B. Landingpages, E-Mail-Strecken).

- Entwickle Thought-Leadership-Inhalte, um ONCARE als vertrauenswürdige Stimme im Markt zu etablieren.

- Optimiere Inhalte für SEO, um organischen Traffic zu steigern und Suchrankings zu verbessern.

**Abteilungsübergreifende Zusammenarbeit**

- Kooperiere mit dem Produktteam, um über den Produkt-Roadmap informiert zu bleiben und Funktionen in Kundennutzen zu übersetzen.

- Unterstütze das Vertriebsteam, indem du sicherstellst, dass es mit den richtigen Materialien und Insights ausgestattet ist, um Abschlüsse zu erzielen.

## Qualifikation

**Erfahrung**

- Erfolgreich abgeschlossenes Studium im Bereich Marketing, Kommunikation, Medien oder eine vergleichbare Qualifikation.

- 3–5 Jahre Erfahrung im Bereich Produktmarketing, Content-Marketing oder einer Hybridrolle - idealerweise im B2B-Umfeld.

- Nachweisbare Erfolge bei der Entwicklung überzeugender Messages und der Erstellung wirkungsvoller Inhalte.

- Fundierte Kenntnisse in den Bereichen Social Media, Content Marketing und SEO sowie in gängigen CMS- und Analyse-Tools (z. B. WordPress, Google Analytics).

- Erfahrung im Gesundheitswesen ist von Vorteil.

**Fähigkeiten**

- **Starkes Ownership**: Du ergreifst Initiative, setzt eigene Prioritäten und führst Projekte erfolgreich zum Abschluss.

- **Handlungsorientierung**: Du bist ergebnisorientiert, gedeihst in einem dynamischen Umfeld und triffst entschlossene Maßnahmen, um Wirkung zu erzielen.

- **Eigenverantwortliches Arbeiten im Team**: Du agierst selbstständig, ohne den Teamgedanken aus den Augen zu verlieren.

- **Kreativität** und ein gutes Gespür für Design und aktuelle Trends.

- Sicherer Umgang mit MS Office-Anwendungen.

- Fließende Deutsch- und Englischkenntnisse in Wort und Schrift (C1-Niveau oder höher).

## Benefits

- Wettbewerbsfähiges Gehalt mit leistungsorientierten Entwicklungsmöglichkeiten

- Zentrales Büro mit vielfältigen Lunch-Optionen in unmittelbarer Umgebung

- Zusammenarbeit in einem internationalen Team - profitiere vom Austausch mit Kolleg:innen aus aller Welt

- Kaffee- und Tee-Flat

- Wechselnde Mitarbeiterrabatte

- Hochwertige Networking-Möglichkeiten mit unseren Schwesterunternehmen sqanit (digitale Plattformlösungen) und CONVIEN (Meeting- & Travel-Optimierung) zur Unterstützung deiner beruflichen Weiterentwicklung

- Direkter Kontakt zu Entscheidungsträgern und flache Hierarchien

Trage zur Digitalisierung des Gesundheitswesens bei und mache mit uns den visionären Schritt in die Zukunft!

Werde Teil der ONCARE Family und bewirb Dich noch heute mit Deinen vollständigen Bewerbungsunterlagen unter Angabe Deines frühestmöglichen Eintrittstermins und Deiner Gehaltsvorstellung.

Wir freuen uns auf Dich!

Bitte beachte die Datenschutzbestimmungen auf unserer Homepage!

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
