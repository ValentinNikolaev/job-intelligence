# Backend PHP Developer

Posted: 2026-06-29T12:11:45Z

## Rejection

- Category: stale
- Reason: published_at 2026-06-29T12:11:45Z is older than 7 days

## Description

**CapsLock** builds exceptional IT marketing solutions for large partners from North America. We create a unique marketing platform to deliver high-quality service in different industries.

**Role overview**

CapsLock is looking to hire an outstanding **Backend PHP Developer** with solid technical skills to support all current projects and create new ones.

You'll be involved in a spectrum of development practices, from cultivating high-level design to the specifics of software implementation. We have a great IT team with a strong development background to improve your skills and share your knowledge.

**Responsibilities**

- Researching, designing, implementing, and managing software programs.
- Testing and evaluating new programs.
- Identifying areas for modification in existing programs and subsequently developing these modifications.
- Producing clean, efficient code based on specifications.
- Integrating software components and third-party programs.
- Determining operational practicality.
- Developing quality assurance procedures.
- Deploying software tools, processes, and metrics.
- Maintaining and upgrading existing systems.
- Verifying and deploying programs and systems.
- Recommending and executing improvements.
- Creating technical documentation for reference and reporting.
- Working closely with other developers, designers, business and systems analysts to achieve the best result.

## Requirements

**Skills & Background:**

- 3+ years of professional development experience in PHP.
- Solid knowledge of OOP, design patterns, and layered architecture.
- Proficiency in writing PHP code (7.4+).
- Expertise in Symfony PHP framework.
- Strong experience in SQL with MySQL/PostgreSQL.
- Experience with designing software architecture.
- Comfortable working with Git in Git-based workflows.
- Conversational English level.
- Strong communication skills, mainly written (as a remote company, we heavily emphasize written communication across all departments).

**Nice to Have:**

- A proactive approach to problem-solving.
- A positive attitude and entrepreneurial spirit.
- Frontend development experience.
- Experience in TDD, DDD.
- Familiarity with Docker, *nix systems, and shell scripting.

**Why do we deserve your attention?**

Not only do we offer fair and competitive pay, but we also provide perks and benefits that support your well-being and growth. Here are some of them:

**Remote Work**

We are a truly remote-first company. You choose where you feel the most productive and comfortable to make an impact.

**Paid Time Off**

Work-life balance matters to us, and we support it with paid time off for rest, personal time, or simply doing what makes you happy.

**Ongoing Learning**

We believe in curiosity and growth. That’s why we support continuous learning with workshops, online courses, conferences, and certifications.

**Home Office**

We help you set up your perfect workspace by covering equipment and furniture expenses, so you can do your best work from home.

**Physical Well-Being**

From gym memberships and yoga classes to home workout equipment or even a bicycle, we give you the flexibility to stay active your way.

**Unlimited Sick Days**

Your health matters. Take the time you need to rest and recover - we’ll be here when you’re ready to return.

**Medical Coverage**

We support you and your family with reimbursement for medical insurance and health-related expenses, including dental care and psychological support.

**Co-Working Space**

If you sometimes crave a change of scenery or more social interaction, we’ll cover the full cost of a co-working space.

**Fun Stuff**

From gaming nights and fitness challenges to annual retreats at world-class resorts, we make sure there’s never a shortage of fun and connection.
