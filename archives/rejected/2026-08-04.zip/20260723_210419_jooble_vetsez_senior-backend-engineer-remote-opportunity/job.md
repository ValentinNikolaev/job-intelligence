# Senior Backend Engineer (Remote Opportunity)

Posted: 2026-08-01T00:00:00.0000000

## Rejection

- Category: tech_stack
- Reason: role does not mention Go/Golang or PHP

...We are currently looking for a **Senior Backend Engineer ** for a 100% **remote **position on a large federal government healthcare technology project. This role will support the design, development, and modernization of enterprise backend services, APIs, and integration solutions...
