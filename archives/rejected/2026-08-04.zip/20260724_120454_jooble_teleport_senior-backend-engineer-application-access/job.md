# Senior Backend Engineer - Application Access

Posted: 2026-07-25T00:00:00.0000000

## Rejection

- Category: stale
- Reason: published_at 2026-07-25T00:00:00.0000000 is older than 7 days

Role Description
We are looking for product-oriented **backend engineers **to join our Application Access (MCP) engineering team here at Teleport. You will be responsible for designing and implementing backend services and APIs that enable access controls auditing tools, audit...
