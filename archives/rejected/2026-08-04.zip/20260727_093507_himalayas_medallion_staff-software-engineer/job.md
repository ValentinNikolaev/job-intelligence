# Staff Software Engineer

Posted: 2026-06-23T10:46:30Z

## Rejection

- Category: stale
- Reason: published_at 2026-06-23T10:46:30Z is older than 7 days

### **About [Medallion](https://himalayas.app/companies/medallion):**

At [Medallion](https://himalayas.app/companies/medallion), we believe healthcare teams should focus on what truly matters - delivering exceptional patient care. That’s why we’ve built a leading provider operations platform to eliminate the administrative bottlenecks that slow healthcare organizations down. By automating licensing, credentialing, payer enrollment, and compliance monitoring, [Medallion](https://himalayas.app/companies/medallion) empowers healthcare operations teams to streamline their workflows, improve provider satisfaction, and accelerate revenue generation, all while ensuring superior patient outcomes.

As one of the fastest-growing healthcare technology companies - ranked #3 on Inc. Magazine’s 2024 Fastest-Growing Private Companies in the Pacific Region, #5 on LinkedIn's 2024 Top US Startups, a Glassdoor Best Place to Work in 2024 & 2025, and featured on The Today Show - [Medallion](https://himalayas.app/companies/medallion) is revolutionizing provider network management. Our CEO, Derek Lo, has been named one of the Top 50 Healthcare Technology CEOs of 2024 by The Healthcare Technology Report. Backed by $130M in funding from world-class investors like Sequoia Capital, Google Ventures, Optum Ventures, Salesforce Ventures, Acrew Capital, Washington Harbour, and NFDG, we’re on a mission to transform healthcare at scale.

### About the role

As a Staff Software Engineer, you will work closely with senior members of the team on a variety of high-impact projects, shipping production code during your very first week, getting steady exposure to a broad set of technologies, and rapidly taking on more responsibility. Expect to work with full autonomy, affect the company roadmap, and ship features that make a meaningful impact on the healthcare system. All on a supportive and experienced team of engineers, PMs, and designers.

This role reports to one of our Engineering Managers and base compensation for this role may land between $210,000-$260,0000. In addition to base salary, [Medallion](https://himalayas.app/companies/medallion) offers equity, and benefits as part of the total compensation package. Many factors are considered when determining pay including: market data, geographic location, skills, qualifications, experience, and level.

### What you'll do

- Work on meaningful projects with business impact from your very first day.
- Scope and lead large projects, addressing ambiguity, creating plans, and ensuring technical excellence
- Help develop the team roadmap, balancing key technical and product tradeoffs
- Teach and mentor members of the engineering team, constantly modeling how great software should be developed
- Work within our tech stack, which includes Python and Django on the backend, and React, JavaScript, and TypeScript on the frontend
- Write a lot of code :)

### Requirements:

- Have 8+ years of experience as a software engineer
- Experience mentoring and leading teams, ideally in a startup environment
- Have worked in multiple functional areas – frontend, backend, platform, services, data, or cloud infrastructure.
- Have a strong technical foundation
- Strong ability to work cross functional to help define, build and deliver on product and tech objectives
- Care deeply about both technical success and product success
- Excellent communication skills

*We prioritize candidate safety. Please be aware that official communication will only come from @medallion.co email addresses.*

Originally posted on [Himalayas](https://himalayas.app)
