# Lead Python Software Engineer, Commercial Systems

Posted: 2026-06-21T20:26:28Z

## Rejection

- Category: stale
- Reason: published_at 2026-06-21T20:26:28Z is older than 7 days

[Canonical](https://himalayas.app/companies/canonical) is a leading provider of open-source software and operating systems for global enterprise and technology markets. Our platform, Ubuntu, is very widely used in breakthrough enterprise initiatives such as public cloud, data science, AI, engineering innovation and IoT. Our customers include the world's leading public cloud and silicon providers, and industry leaders in many sectors. The company is a pioneer of global distributed collaboration, with 1200+ colleagues in more than 80 countries and very few office-based roles. Teams meet two to four times yearly in person, in interesting locations around the world, to align on strategy and execution.

The company is founder led, profitable and growing.

We are hiring a **Python Software Engineer** who strives for the highest engineering quality, seeks improvements, continuously develops their skills, and applies them at work. This is an exciting opportunity to work with many popular software systems, integrations technologies, and exciting open source solutions.

The Commercial Systems unit is conceived as six engineering teams that closely collaborate with other engineering and business teams at [Canonical](https://himalayas.app/companies/canonical). Services designed, developed, and operated by the Commercial Systems unit are at the heart of [Canonical](https://himalayas.app/companies/canonical) business and Python plays an integral role in it. We are looking for Python Software Engineers for the Integrations team.

The **Integrations** team is responsible for the automation of SAAS user management and onboarding of new data sources to the data mesh. The team designs, develops, and operates a Python based solution to automate SAAS seat management and track spend across the application portfolio. Furthermore the team integrates internal and external data sources into the data mesh using open-source ETL solutions, enabling more data driven decisions in the organization.

**Location**: This role will be based remotely in the EMEA region.

### **The role entails**

- Develop engineering solutions leveraging Python

- Collaborate with colleagues on technical designs and code reviews

- Deploy and operate services developed by the team

- Depending on your seniority, coach, mentor, and offer career development feedback

- Develop and evangelize great engineering and organizational practices

### **What we are looking for in you**

- Exceptional academic track record from both high school and university

- Undergraduate degree in a technical subject or a compelling narrative about your alternative chosen path

- Track record of going above-and-beyond expectations to achieve outstanding results

- Experience with software development in Python

- Professional written and spoken English with excellent presentation skills

- Result-oriented, with a personal drive to meet commitments

- Ability to travel internationally twice a year, for company events up to two weeks long

### **Nice-to-have skills**

- Performance engineering and security experience

- Experience with Airbyte, Ranger, Temporal, or Trino

### **What we offer colleagues**

We consider geographical location, experience, and performance in shaping compensation worldwide. We revisit compensation annually (and more often for graduates and associates) to ensure we recognize outstanding performance. In addition to base pay, we offer a performance-driven annual bonus or commission. We provide all team members with additional benefits, which reflect our values and ideals. We balance our programs to meet local needs and ensure fairness globally.

- Distributed work environment with twice-yearly team sprints in person

- Personal learning and development budget of USD 2,000 per year

- Annual compensation review

- Recognition rewards

- Annual holiday leave

- Maternity and paternity leave

- Employee Assistance Program

- Opportunity to travel to new locations to meet colleagues

- Priority Pass, and travel upgrades for long haul company events

### **About [Canonical](https://himalayas.app/companies/canonical)**

[Canonical](https://himalayas.app/companies/canonical) is a pioneering tech firm at the forefront of the global move to open source. As the company that publishes Ubuntu, one of the most important open source projects and the platform for AI, IoT and the cloud, we are changing the world of software. We recruit on a global basis and set a very high standard for people joining the company. We expect excellence - in order to succeed, we need to be the best at what we do. Most colleagues at [Canonical](https://himalayas.app/companies/canonical) have worked from home since its inception in 2004.​ Working here is a step into the future, and will challenge you to think differently, work smarter, learn new skills, and raise your game.

###
[Canonical](https://himalayas.app/companies/canonical) is an equal opportunity employer

We are proud to foster a workplace free from discrimination. Diversity of experience, perspectives, and background create a better work environment and better products. Whatever your identity, we will give your application fair consideration.

Originally posted on [Himalayas](https://himalayas.app)
