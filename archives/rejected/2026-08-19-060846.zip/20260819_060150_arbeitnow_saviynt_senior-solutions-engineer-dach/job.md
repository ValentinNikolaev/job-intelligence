# Senior Solutions Engineer - DACH

Posted: 2026-08-19T02:04:52Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Saviynt's AI-powered identity platform manages and governs human and non-human access to all of an organization's applications, data, and business processes. Customers trust Saviynt to safeguard their digital assets, drive operational efficiency, and reduce compliance costs. Built for the AI age, Saviynt is today helping organizations safely accelerate their deployment and usage of AI. Saviynt is recognized as the leader in identity security, with solutions that protect and empower the world’s leading brands, Fortune 500 companies and government institutions. For more information, please visit [www.saviynt.com](http://www.saviynt.com/).

The Senior Solutions Engineer is a member of the Saviynt Sales organization,responsible for collaborating with the Sales Directors and Regional VPs to sell anintegrated suite of Access Governance and Cloud Security solutions to new and existingaccounts. This individual will have a broad understanding of vendor solutions, industrybest practices, and technology integration, demonstrating expertise and delivery offunctional and technical solutions to sophisticated customer engagements.

This individual will also provide expert knowledge to existing and prospective customers through conducting detailed technical discovery, responses to Request for Proposals(RFPs), and delivery of Proof of Concepts (POCs). Besides, this individual will be a contributor to Product Marketing collaborating in the development of white papers, solutions briefs, webinars, and blogs. The Senior Solutions Engineer will work proactively, and independently with various facets of the business ultimately driving opportunities to closure and possibility impacting revenue.

The Senior Solutions Engineer will be expected to mentor/coach Solutions Engineers on strategy, influencing the customer, managing scope, and execution of technical presentations. This person must be located in Munich/ Frankfurt/ Stuttgart / Germany and will work remotely + travel.

**WHAT YOU WILL BE DOING**

- Develop and deliver technical presentations to demonstrate enterprise solutions, ease-of-configuration, simplicity of architecture, and intelligence of workflows providing the opportunity for customer interaction and demonstrating excellent presentation skills.

- Effectively communicate solution value to the business and technical audiences that is clear and satisfies prospective customer requirements and/or inquiries.

- Provide needs assessment, consultation, technical solutions, and customer support with a team of Saviynt professionals.

- Collaborate with both the sales and global bid team members to respond to satisfy prospective customer inquiries resulting from an RFx.

- Assist members of the global bid team and collaborate with members of the product management team in the curation of RFx responses.

- Effectively communicate with sales directors and sales management, working proactively and independently to prioritize and manage top regional opportunities, driving them to closure.

- Regularly provide solution feedback and competitive intel from the field to Saviynt product management, solutions strategy, and marketing teams.

- Ramp and coach Solutions Engineers on solution demonstration, RFP responses and presentations, technical overviews, POC scope management, and execution.

- Up to 60% international travel across the DACH region

**WHAT YOU BRING**

- Fluent in English and German. Other European languages are a plus (written/spoken)

- Domain expertise - Privilege Access Management, Identity Governance and Administration, Application GRC, and/or, Cloud Security

- Minimum of five (5) years previous Solutions Engineering with demonstrable success in Cloud Security, Privileged Access Management, Application GRC, and/or Identity Governance and Administration solutions

- Bachelor's degree in information systems or related area, or demonstration of equivalent knowledge such as technical certifications from ISACA, (ISC)², AWS Cloud Practitioner, Microsoft Azure Fundamentals, Google Cloud Security Engineer, etc.

- Ability to travel up to 60% across the DACH region

- Superior communication, relationship and customer service skills that result in the ability to rapidly assess needs and sell solutions to sophisticated customers.

- Ownership and management of technical team relationships within existing and prospective opportunities

- Self-sufficient with a high degree of autonomy and a passion for working within a dynamic startup-like environment

- Exemplary technical skills enabling configuration and rapid problem solving in the field including:

- Experience in Identity Governance and Administration domain with firm grasp of its concepts such as Identity Life Cycle Management, Entitlements Management, Access Request, Workflow, Policy and Role Management, Access Certification, Audit, Reporting/Analytics, and Deployment Scenarios

- Database query experience in a relational database environment (MySQL and Elastic Search)

- Experience with REST API, PowerShell, and GraphAPI

- Knowledge of authentication and authorization protocols and standards including SAML, OAuth/2, SCIM, OpenID, WS-Trust, SPNEGO, [x.509](http://x.509), SPML, Kerberos, REST, JSON, and others that facilitate Single Sign On (SSO), ID federation, etc.

- Understanding of data governance concepts and compliance regulations such as GDPR & CCPA

- Experience with regulatory compliance and security frameworks such as SOX, NERC-CIP, HIPAA, Cobit, Center for Internet Security (CIS), Cloud Security Alliance, NIST, PCI, etc.

- Experience with AzureAD, Okta, JumpCloud, OneLogin, PingDirectory, Active Directory, eDirectory, Oracle Internet Directory, Radiant Logic, and other Cloud/LDAP/Virtual directories

- Basic understanding of networking technologies such as HTTP, TCP/IP, firewalls, and encryption

- Exemplary communication and relationship skills (verbal, written and presentations)

- Strong business and technical document creation skills (e.g. scope definition, proposals, architecture and network diagrams, etc.)

**If required for this role, you will:**

- Complete security & privacy literacy and awareness training during onboarding and annually thereafter

- Review (initially and annually thereafter), understand, and adhere to Information Security/Privacy Policies and Procedures such as (but not limited to):

> Data Classification, Retention & Handling Policy

> Incident Response Policy/Procedures

> Business Continuity/Disaster Recovery Policy/Procedures

> Mobile Device Policy

> Account Management Policy

> Access Control Policy

> Personnel Security Policy

> Privacy Policy

Saviynt is an amazing place to work. We are a high-growth, Platform as a Service company focused on Identity Authority to power and protect the world at work. You will experience tremendous growth and learning opportunities through challenging yet rewarding work which directly impacts our customers, all within a welcoming and positive work environment. If you're resilient and enjoy working in a dynamic environment you belong with us!

***Saviynt is an equal opportunity employer and we welcome everyone to our team. All qualified applicants will receive consideration for employment without regard to race, color, religion, sex, sexual orientation, gender identity, national origin, disability, or veteran status.***

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
