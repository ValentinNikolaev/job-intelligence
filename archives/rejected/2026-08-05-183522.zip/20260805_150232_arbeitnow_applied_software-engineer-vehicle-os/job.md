# Software Engineer - Vehicle OS

Posted: 2026-08-05T11:40:32Z

## Rejection

- Category: tech_stack
- Reason: role does not mention Go/Golang or PHP

## About Applied Intuition

Applied Intuition, Inc. is powering the future of physical AI. Founded in 2017 and now valued at $15 billion, the Silicon Valley company is creating the digital infrastructure needed to bring intelligence to every moving machine on the planet. Applied Intuition services the automotive, defense, trucking, construction, mining and agriculture industries in three core areas: tools and infrastructure, operating systems, and autonomy. Eighteen of the top 20 global automakers, as well as the United States military and its allies, trust the company’s solutions to deliver physical intelligence. Applied Intuition is headquartered in Sunnyvale, California, with offices in Washington, D.C.; San Diego; Ft. Walton Beach, Florida; Ann Arbor, Michigan; London; Stuttgart; Munich; Stockholm; Bangalore; Seoul; and Tokyo. Learn more at [applied.co](http://applied.co).

*We are an in-office company, and our expectation is that employees primarily work from their Applied Intuition office 5 days a week. However, we also recognize the importance of flexibility and trust our employees to manage their schedules responsibly. This may include occasional remote work, starting the day with morning meetings from home before heading to the office, or leaving earlier when needed to accommodate family commitments.*

**About the role**
We are looking for a software engineer with a passion for improving developer experience and deployment processes. In this role, you will work across engineering teams to identify key sources of friction, improve workflows, develop new tools, and generally uplevel the velocity and reliability of the entire software, and automotive development and deployment lifecycle.

## **At Applied Intuition, you will:**

-

Design, build, and improve the tools, libraries, and frameworks for our engineering team

-

Build and test scalable tools for deploying to various automotive and cloud platforms

-

Optimize our compile/build times using tools like Bazel, CMake, Docker

-

Improve software deployment and data collection frameworks

-

Identify and solve bottlenecks within our software stack

## **We're looking for someone who has:**

-

2+ years of relevant experience, also open to high-performing new grads with <2.0 GPA (on German scale)

-

Self-starter with a "can-do" attitude, high energy, and the independence to drive projects forward

-

Experience using Python, Go, or Java

-

Experience with CI, build, and deployment technologies like Bazel, Buildkite, Docker, Kubernetes, and Jenkins, and comfortability with scripting for automation

-

Experience with Linux and/or ARM systems

-

Experience working with configuration management tools like Ansible and Terraform

## **Nice to have:**

-

Experience using C and C++

-

Experience working in automotive or related industries

-

Experience with deploying software on either public clouds (e.g., AWS) or on-premise clusters

## **Benefits and perks:**

-

30 days of paid vacation per year

-

Daily meal benefits: €19 lunch budget and €19 dinner budget, free breakfast, snacks, and drinks in the office

-

€965 annual learning & development and €580 annual fitness budget

-

Subsidized Wellpass membership, giving you access to thousands of gyms, studios, and wellness facilities across Germany

-

€25 monthly contribution to your Deutschlandticket for regional public transport across Germany

-

Generous parental leave: on top of statutory parental leave

*Don’t meet every single requirement? If you’re excited about this role but your past experience doesn’t align perfectly with every qualification in the job description, we encourage you to apply anyway. You may be just the right candidate for this or other roles.*

*Applied Intuition is an equal opportunity employer and federal contractor or subcontractor. Consequently, the parties agree that, as applicable, they will abide by the requirements of 41 CFR 60-1.4(a), 41 CFR 60-300.5(a) and 41 CFR 60-741.5(a) and that these laws are incorporated herein by reference. These regulations prohibit discrimination against qualified individuals based on their status as protected veterans or individuals with disabilities, and prohibit discrimination against all individuals based on their race, color, religion, sex, sexual orientation, gender identity or national origin. These regulations require that covered prime contractors and subcontractors take affirmative action to employ and advance in employment individuals without regard to race, color, religion, sex, sexual orientation, gender identity, national origin, protected veteran status or disability. The parties also agree that, as applicable, they will abide by the requirements of Executive Order 13496 (29 CFR Part 471, Appendix A to Subpart A), relating to the notice of employee rights under federal labor laws.*

Compensation: €70K – €120K • Offers Equity

- • €70K – €120K • Offers Equity

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
