# Teamleiter IT (m/w/d)

Posted: 2026-08-05T14:09:39Z

## Rejection

- Category: tech_stack
- Reason: role does not mention Go/Golang or PHP

**Dein zukünftiger Job**

Als **Teamleiter IT (m/w/d)** bist Du die Brücke zwischen Management-Ebene und den Teams, die Hand-On im Geschehen unterwegs sind. Du bringst einiges an Erfahrung als Senior System Engineer mit und scheust Dich nicht vor Führungsverantwortung oder bringst sogar schon Erfahrung mit. Du administrierst, migrierst und härtest unsere Systeme – und baust parallel ein schlagkräftiges Team für unsere interne IT auf. Du übernimmst die fachliche und disziplinarische Leitung für IT-Helpdesk (1st-Level) und IT-Infrastruktur & Operations (Server, Netzwerk, Cloud) und arbeitest dabei eng mit unserem CIO zusammen.

**Wofür wir Dich brauchen**

- Fachliche und disziplinarische Führung eines kompakten, aktuell im Aufbau befindlichen Teams von 6–8 Personen (Helpdesk und Infrastruktur) – als Führungskraft, die auch selbst mit anpacken kann
- Administration unserer heterogenen Serverlandschaft: Linux (ca. 70–80 %) und Windows, rund 100 VMs sowie einzelne Bare-Metal-Server
- Fachliche Steuerung und ggf. operative Mitarbeit an der laufenden Migration von VMware ESXi zu Proxmox VE, inklusive Ablösung veralteter Altsysteme und Applikationen
- Betreuung und Weiterentwicklung unserer Netzwerkinfrastruktur (Firewalls, Switching, VPN) inklusive der Anbindung unserer zwei Rechenzentren und weiterer Standorte
- Mitarbeit an unserer hybriden Exchange-/M365-Umgebung (on-premises, Entra ID) sowie Auflösung bestehender Altlasten (z.B. Split-Brain-DNS, File-Server)
- Verantwortung für verschiedene IT-Projekte, z.B. die laufende Einführung von Intune für unsere gemischte Endgerätelandschaft (macOS/Windows)
- Ressourcen- und Kapazitätsplanung im Team sowie Steuerung externer IT-Dienstleister, die uns ergänzen
- Einführung und Optimierung von IT-Richtlinien, Arbeitsabläufen und Prozessen sowie Umsetzung von IT-Security-Standards nach ISO 27001 und KRITIS-Anforderungen
- Zusammenarbeit mit unserem Dev-Team, der Netz-IT und den Fachabteilungen

**Was Du mitbringst**

- Abgeschlossenes Studium in Informatik, Informationstechnologie oder einem verwandten Fachbereich – alternativ gleichwertige Kenntnisse und praktische Erfahrung
- Mehrjährige Erfahrung als System Engineer/Administrator, idealerweise mit erster Erfahrung in der fachlichen oder disziplinarischen Führung eines kleinen Teams
- Du hast auch in den letzten Jahren noch aktiv selbst administriert – Du kommst nicht aus einer reinen People-Management-Rolle, sondern willst weiterhin technisch nah dran sein
- Praktische Erfahrung mit Virtualisierung (VMware und/oder Proxmox), fundierte Linux-Administration sowie Grundkenntnisse in Windows-Server-Umgebungen
- Erfahrung mit Active Directory/Entra ID- bzw. Exchange-Hybridszenarien sowie mit gängiger Netzwerktechnik (Firewalls, VPN, Routing)
- Vertrautheit mit gesetzlichen Anforderungen und Best Practices, idealerweise im KRITIS-Umfeld
- Kommunikationsstärke, Entscheidungsfreude und Teamorientierung, verbunden mit Lust darauf, ein Team im Aufbau aktiv zu prägen
- Fließende Deutsch- und gute Englischkenntnisse in Wort und Schrift

**Deine Vorteile bei uns**

- Unbefristeter Arbeitsvertrag mit 30 Tagen Urlaub sowie ein zusätzlicher freier Tag an Deinem Geburtstag
- Flexible Arbeitszeiten dank Gleitzeit und der Möglichkeit zum tageweisen mobilen Arbeiten
- Deutschlandticket nach der Probezeit, zu 100% finanziert
- Hochwertige technische Ausstattung
- Vermögenswirksame Leistungen, betriebliche Altersversorgung
- Kostenloses IPTV sowie ein vergünstigter Mitarbeiteranschluss (verfügbar, sofern ein Anschluss der DNS:NET vor Ort besteht)
- Arbeit in einer zukunftsweisenden Branche
- Flache Hierarchien, kurze Informationswege und ein angenehmes Arbeitsklima
- Familiäres und offenes Miteinander in einer Duz-Kultur
- Moderne Büros in verkehrsgünstiger Lage mit Blick auf den Checkpoint Charlie
- Kostenfreie Getränke und guten Kaffee…
- …und vieles mehr.

**Jetzt bewerben und gemeinsam mit uns die digitale Zukunft mit Lichtgeschwindigkeit gestalten!**

Dann freuen wir uns, Dich persönlich kennenzulernen! Schicke uns einfach Deine vollständigen Bewerbungsunterlagen, inklusive Deiner Gehaltsvorstellung und des frühestmöglichen Eintrittstermins über unser Bewerbungsformular.

Wenn du noch Fragen hast, melde Dich gerne bei Deiner Kontaktperson:

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
