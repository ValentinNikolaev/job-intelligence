# Werkstudent IT (m/w/d)

Posted: 2026-08-05T14:09:39Z

## Rejection

- Category: tech_stack
- Reason: role does not mention Go/Golang or PHP

**Dein zukünftiger Job**

Du bist Teil unseres IT-Supports und damit erste Anlaufstelle für unsere Kolleg:innen bei allem, was mit Hardware, Software und Anwendungen zu tun hat. Du hilfst bei den Themen, die den Arbeitsalltag der anderen ausbremsen – schnell, freundlich und lösungsorientiert.
Genauso wichtig wie das Tagesgeschäft: Wir wollen Wissen, das aktuell nur in Köpfen steckt, sauber aufnehmen und dokumentieren – Abläufe, wiederkehrende Probleme, Lösungswege. Du bringst ein gutes Gespür dafür mit, wie man aus "das machen wir immer so" eine nachvollziehbare Beschreibung macht.

**Wofür wir Dich brauchen**

- Du nimmst IT-Störungen telefonisch oder schriftlich entgegen, analysierst sie und findest Lösungen – oder leitest sauber vorqualifiziert weiter, wenn's tiefer geht
- Du dokumentierst jeden Fall strukturiert in unserem Ticketsystem
- Du kümmerst dich um Pflege und Wartung unserer Arbeitsplatzsysteme (macOS & Windows) und bist zur Stelle, wenn's mal klemmt
- Du installierst, konfigurierst und aktualisierst Software
- Du unterstützt neue Kolleg:innen beim Onboarding, damit sie technisch von Tag eins an startklar sind
- Du hilfst mit, unsere interne Wissensdatenbank und Checklisten für wiederkehrende Themen auf- und auszubauen
- Du unterstützt uns beim Wechsel auf ein neues Ticketsystem (Jira) – dabei geht's nicht nur ums Umziehen, sondern auch darum, Abläufe sauber neu zu beschreiben
- Du hältst Prozesse und Abläufe so fest, dass auch neue Kolleg:innen sie ohne Nachfragen verstehen

**Was Du mitbringst**

- Du studierst Informatik, Wirtschaftsinformatik oder einen vergleichbaren technischen Studiengang – wichtig ist echtes Interesse an IT.
- Grundkenntnisse in macOS und Windows. Linux-Kenntnisse von Vorteil.
- Du arbeitest strukturiert, zuverlässig und behältst auch bei mehreren offenen Themen den Überblick.
- Du kommunizierst klar und hast Spaß daran, anderen Dinge verständlich zu erklären – schriftlich genauso wie mündlich.
- Du bist bereit, regelmäßig und verlässlich vor Ort in Berlin zu sein – Präsenz ist für diese Stelle kein Nice-to-have, sondern Teil des Jobs.
- Du kommunizierst sicher auf Deutsch und hast grundlegende Englischkenntnisse für technische Dokumentation und Tools.
- Erste Berührung mit Ticketsystemen oder IT-Support
- Kenntnisse in Microsoft 365
- Interesse an SAP-Administration oder angebundenen Systemen wie xSuite – falls dich das reizt, findet sich bei uns Raum dafür

**Deine Vorteile bei uns**

- Jahresurlaubsanspruch von 30 Tagen bei einer Vollzeitwoche, entsprechend 18 Tagen bei einer 3-Tage-Woche (20 Stunden), sowie ein zusätzlicher freier Tag an Deinem Geburtstag
- Flexible Arbeitszeiten dank Gleitzeit
- Hochwertige technische Ausstattung
- Arbeit in einer zukunftsweisenden Branche
- Flache Hierarchien, kurze Informationswege und ein angenehmes Arbeitsklima
- Familiäres und offenes Miteinander in einer Duz-Kultur
- Moderne Büros in verkehrsgünstiger Lage mit Blick auf den Checkpoint Charlie
- kostenfreie Getränke und guten Kaffee...
- …und vieles mehr

**Jetzt bewerben und gemeinsam mit uns die digitale Zukunft mit Lichtgeschwindigkeit gestalten!**

Möchtest Du Teil unseres erfolgreichen Teams werden und mit uns gemeinsam weiterwachsen?

Dann freuen wir uns darauf, Dich persönlich kennenzulernen. Bitte schicke uns Deine vollständigen Bewerbungsunterlagen mit der Angabe Deiner Gehaltsvorstellung und Deines frühestmöglichen Eintrittstermins.
**
**Kontaktperson: Tom Piper

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
