# Teamleiter Sales Dortmund

Posted: 2026-08-07T20:40:20Z

## Rejection

- Category: tech_stack
- Reason: role does not mention Go/Golang or PHP

## **Über Salonkee **

Wir bei Salonkee glauben, dass Friseure und Beauty- Expert:innen ihre Zeit mit Handwerk und Kreativität verbringen sollten - nicht mit Zettelwirtschaft. Als eines der am schnellsten wachsenden SaaS-Unternehmen Europas bieten wir Salons eine Komplettlösung: von der smarten Online-Buchung bis hin zu automatisierten Zahlungen.

Wir suchen keine Verwalter, sondern Gestalter. In Dortmund schlagen wir das nächste Kapitel auf und suchen jemanden, der unser lokales Team nicht nur führt, sondern gemeinsam mit uns wächst.

## **Deine Rolle: Mitmacher, Stratege & Mentor**

Du bist das Gesicht von Salonkee in Dortmund. Deine Aufgabe ist es, ein schlagkräftiges Team aufzubauen und gleichzeitig sicherzustellen, dass wir nah am Kunden bleiben.

-

**Teamaufbau & Coaching:** Du baust das Team auf ca. fünf Talente aus. Du führst keine Excel-Tabellen, sondern Menschen - durch 1:1s, gemeinsames Training und echtes Feedback.

-

**Präsenz im Markt:** Du bist kein Büromensch. Du begleitest dein Team zu Terminen vor Ort, unterstützt bei der Kaltakquise und zeigst in Live-Demos, wie Salonkee den Alltag der Salonbesitzer erleichtert.

-

**Struktur schaffen:** Du organisierst die Woche so, dass dein Team Erfolg haben kann. Du behältst die CRM-Pflege und die Kennzahlen im Blick, um frühzeitig zu sehen, wo wir nachjustieren können.

-

**Vorbildfunktion:** Gerade am Anfang bist du selbst aktiv im Verkauf tätig. Nicht, um Rekorde zu brechen, sondern um den Markt in Dortmund im Detail zu verstehen.

## **Das bringst du mit**

-

**Erfahrung im Außendienst:** Du hast 2–4 Jahre Erfahrung im Vertrieb (idealerweise B2B) gesammelt und weißt, wie man Türen öffnet.

-

**Lust auf Führung:** Du musst noch kein „Director“ gewesen sein, aber du hast das Talent, andere zu motivieren und Verantwortung für gemeinsame Ziele zu übernehmen.

-

**Strukturierte Arbeitsweise:** Du planst deine Region eigenständig und weißt, wie man Prioritäten setzt.

-

**Kommunikation:** Du sprichst fließend Deutsch und kannst dich sicher auf Englisch mit unserem internationalen Team austauschen.

-

**Mobilität:** Für die Termine bei unseren Partnern vor Ort ist ein Führerschein notwendig.

## **Warum Salonkee?**

-

**Sicherheit & Erfolg:** Ein attraktives Gehaltspaket aus Fixum & Provision, das deine Leistung wirklich belohnt.

-

**Dein Firmenwagen:** Auch zur privaten Nutzung - damit du immer flexibel bleibst.

-

**Freiraum:** Wir vertrauen dir. Deine Arbeitszeit gestaltest du so, wie es für dich und dein Team am besten passt.

-

**Echte Benefits:** 50 € monatliches Guthaben (steuerfrei) via Probonio für deine persönlichen Bedürfnisse sowie regelmäßige Teamevents, die diesen Namen auch verdienen.

**Klingt nach deinem nächsten Schritt?** Wir machen es kurz: Schick uns deinen Lebenslauf. Wir freuen uns darauf, dich kennenzulernen und gemeinsam Dortmund zu erobern!

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
