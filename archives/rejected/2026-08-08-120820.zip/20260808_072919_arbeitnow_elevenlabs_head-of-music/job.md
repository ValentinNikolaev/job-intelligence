# Head of Music

Posted: 2026-08-07T20:40:19Z

## Rejection

- Category: tech_stack
- Reason: role does not mention Go/Golang or PHP

## About ElevenLabs

ElevenLabs is an AI research and product company transforming how we interact with technology.

We launched in January 2023 with the first human-like AI voice model. Today, we serve millions of users and thousands of businesses - from fast-growing startups to large enterprises like Deutsche Telekom and Meta. Our investors are some of the world's most prominent, including Andreessen Horowitz, ICONIQ Growth and Sequoia. We've raised $781M in funding and our last valuation was $11B - multiples of 11, always.

We have expanded from voice into three main platforms:

-

ElevenAgents enables businesses to deliver seamless and intelligent customer experiences, with the integrations, testing, monitoring, and reliability necessary to deploy voice and chat agents at scale.

-

ElevenCreative empowers creators and marketers to generate and edit speech, music, image, and video across 70+ languages.

-

ElevenAPI gives developers access to our leading AI audio foundational models.

Everything we do is the result of the creativity and commitment of our team - builders doing the best work of their lives. We are researchers, engineers, and operators. IOI medalists and ex-founders. If you want to work hard and create lasting positive impact, we want to hear from you.

## How we work

-

**High-velocity: **Rapid experimentation, lean autonomous teams, and minimal bureaucracy.

-

**Impact not job titles: **We don’t have job titles. Instead, it’s about the impact you have. No task is above or beneath you.

-

**AI first:** We use AI to move faster with higher-quality results. We do this across the whole company—from engineering to growth to operations.

-

**Excellence everywhere: **Everything we do should match the quality of our AI models.

-

**Global team: **We prioritize your talent, not your location.

## What we offer

-

**Innovative culture:** You’ll be part of a generational opportunity to define the trajectory of AI, surrounded by a team pushing the boundaries of what’s possible.

-

**Growth paths: **Joining ElevenLabs means joining a dynamic team with countless opportunities to drive impact - beyond your immediate role and responsibilities.

-

**Learning & development**: ElevenLabs proactively supports professional development through an annual discretionary stipend.

-

**Social travel**: We also provide an annual discretionary stipend to meet up with colleagues each year, however you choose.

-

**Annual company offsite: **Each year, we bring the entire team together in a new location - past offsites have included Croatia and Italy.

-

**Co-working**: If you’re not located near one of our main hubs, we offer a monthly co-working stipend.

## About the role

The ElevenLabs Music team is entering its next phase of growth. After gaining significant traction across enterprise, creator, and artist products, we're expanding our leadership team to accelerate product development, licensing, partnerships, and go-to-market across our music business.

We are hiring a Head of Music to lead our enterprise and consumer music business end to end. We have the best AI music and audio researchers and world-class music models - built in partnership with artists, labels, and publishers. We’re doubling down on music and seeking an experienced industry leader to guide us into the future. We intend to be the defining AI music company. Our Head of Music will ensure we get there.

The Head of Music will build on our momentum and help shape the future of our rapidly growing music business, driving a unified strategy for our B2B, artist-focused, and creator/consumer offerings. They will oversee music product, licensing, marketing, and partnerships. They will also work hand-in-hand with our GTM and FDE teams on the sale and implementation of our music tools. In addition, they will represent ElevenLabs at industry and tech events globally. This is a singular role for an exceptional individual with deep experience, ties, and respect across the music industry.

## Requirements

-

Can craft and execute a cohesive strategy across B2B, artist, and consumer music tools, including product, licensing, marketing, partnerships, and sales. Should personally spike in at least one of these disciplines.

-

Proven track record of driving the development of music technology, including excellent product sense.

-

Deep knowledge of licensing across the recorded music and publishing industries.

-

Experience with marketing music technology products.

-

Leadership and management experience.

-

Comfort with public speaking.

## Location

This role is remote and can be executed globally, but San Francisco, New York, and London are preferred.

We are an equal opportunity employer and do not discriminate on the basis of race, religion, national origin, gender, sexual orientation, age, veteran status, disability or other legally protected statuses.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
