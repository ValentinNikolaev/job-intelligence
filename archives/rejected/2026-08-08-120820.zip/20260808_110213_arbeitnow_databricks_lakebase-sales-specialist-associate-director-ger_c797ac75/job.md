# Lakebase Sales Specialist, Associate Director (Germany)

Posted: 2026-08-08T08:55:34Z

## Rejection

- Category: tech_stack
- Reason: role does not mention Go/Golang or PHP

SLSQ327R173

Databricks is seeking a **Lakebase Sales Specialist** to help customers modernize their operational data foundation with **Databricks Lakebase**, our **fully-managed Postgres** offering for **intelligent applications**. This high-impact role sits within the Lakebase Go-To-Market team and partners closely with regional Account Executives to drive adoption of Lakebase with platform, application, and data teams.

Lakebase gives customers a unified, governed foundation for **operational workloads** and **AI-native applications**, helping them move away from a fragmented estate of point databases toward a modern, scalable, serverless Postgres service. If you want to be at the forefront of operational databases for AI and intelligent applications at one of the fastest-growing data and AI companies in the world, this is your opportunity.

## **The impact you will have**

- **Drive new Lakebase revenue** by identifying, qualifying, and closing Lakebase opportunities within a defined territory, in partnership with regional Account Executives and the broader account team.

- **Lead with outcomes** for key Lakebase personas — including **platform teams and developers**, **data teams**, and **central IT** — articulating how Lakebase helps them ship features faster, simplify operational data architectures, and improve governance and cost efficiency.

- **Sell the value of fully-managed Postgres for intelligent applications**, positioning Lakebase as the optimal choice for operational workloads that power real-time, AI-driven experiences.

- **Run complex, multi-threaded sales cycles** from discovery and value hypothesis through commercial negotiation and close, navigating executive, technical, and line-of-business stakeholders.

- **Orchestrate proof-of-value and POCs** that validate Lakebase’s benefits for OLTP-style workloads, reverse ETL, and AI/ML-driven applications, in partnership with solution architects and specialists.

- **Compete and win** against legacy and cloud-native operational databases by leveraging our compete assets, benchmarks, and customer references.

- **Align to measurable business outcomes** such as performance, developer productivity, time-to-market for new features, cost reduction, and simplification of the operational data landscape.

- **Partner cross-functionally** with Product Management, Marketing, Customer Success, and Partner teams to shape territory plans, launch plays, and co-selling motions with key ISVs and GSIs.

- **Enable the field** by sharing Lakebase best practices, success stories, and sales motions with broader sales teams, helping scale Lakebase proficiency across the organization.

## **What success looks like in this role**

This role requires the ability to operate across **two key motions** simultaneously:

- **Establish top strategic focus accounts** by engaging application development teams to create net-new intelligent applications leveraging Lakebase.

- **Drive longer-term Postgres standardization and migration** within Databricks' most strategic accounts.

Candidates should demonstrate how they can **act as a force multiplier** across multiple dimensions of the business.

Success in this role requires strength in four areas:

- **Business ownership** – Operate at a business-unit level by tracking revenue, pipeline, and key observations, and by identifying areas needing additional focus or support.

- **Strategic account engagement** – Partner with account teams to engage priority accounts across the global DB700, driving strategic opportunities from initial engagement through successful outcomes.

- **Field enablement** – Build and execute enablement plans that empower AEs and SAs to confidently carry the Lakebase conversation even when the specialist is not present.

- **Market voice and thought leadership** – Develop an internal and external presence by contributing to global AMAs and internal forums, and by representing Databricks at key first- and third-party events.

The interview process is designed to evaluate candidates across all four of these dimensions.

## **What we look for**

- **7+ years of enterprise SaaS sales experience**, consistently exceeding quota in complex, multi-stakeholder deals.

- Proven success selling **data platforms, operational databases (e.g., Postgres, MySQL, cloud-native DBaaS), or adjacent data/AI infrastructure** to technical buyers and business leaders.

- Strong understanding of **modern data and application architectures**, including cloud-native services, microservices, event-driven systems, and how operational data underpins AI and analytics strategies.

- Ability to sell to both **technical stakeholders** (developers, architects, data engineers) and **business stakeholders** (product leaders, operations, line-of-business owners).

- Demonstrated experience leading **specialist or overlay motions**, working jointly with core Account Executives to create and progress opportunities.

- Executive presence with the ability to **whiteboard architectures**, lead C-level conversations, and build trust with senior decision makers.

- Strong **value selling** skills: adept at discovering pain, building a business case, and tying technical capabilities to clear, quantified outcomes.

- Excellent **communication, storytelling, and negotiation** skills, with comfort presenting to both large and small audiences.

- Bachelor’s degree or equivalent practical experience.

## **Preferred qualifications**

- Experience selling **Postgres, operational databases, OLTP workloads, or transactional cloud database services**, ideally within large or strategic accounts.

- Familiarity with **data platforms, lakehouse architectures, and cloud ecosystems** (AWS, Azure, GCP), including how operational databases fit within broader data and AI strategies.

- Understanding of **reverse ETL, real-time decisioning, and operational analytics** use cases, and how they drive value for customer-facing and internal applications.

- Exposure to **AI-native and agent-driven applications** that depend on low-latency, highly scalable operational data services.

- Prior experience in a **high-growth, category-creating environment**, helping shape new plays, messaging, and customer narratives.

- Experience collaborating with **partners and ISVs** to drive joint pipeline and co-sell motions.

*This description is intended to outline the core responsibilities and qualifications for the Lakebase Account Executive role. Actual responsibilities may evolve as the Lakebase product and go-to-market motions continue to grow and mature.*

**About Databricks**

Databricks is the Data and AI company. More than 20,000 organizations worldwide — including adidas, AT&T, Bayer, Block, Mastercard, Rivian, Unilever, and 70% of the Fortune 500 — rely on the Databricks Data + AI Platform to build and scale data and AI apps, analytics and agents. Headquartered in San Francisco with 30+ offices around the globe, Databricks offers a unified platform that includes Genie, Lakebase, Agent Bricks, Lakeflow, Lakehouse, and Unity Catalog. To learn more, follow Databricks on [LinkedIn](https://www.linkedin.com/company/databricks), [X](https://x.com/databricks), [YouTube](https://www.youtube.com/@Databricks), and [Instagram](https://www.instagram.com/databricksinc/?hl=en).

**Benefits

**At Databricks, we strive to provide comprehensive benefits and perks that meet the needs of all of our employees. For specific details on the benefits offered in your region click [here](https://docs.google.com/document/d/154un3e8Xav4BceOSlcYFZRGEuQI54xMxVydRwQn54eQ/edit?usp=sharing).

**Our Commitment to Diversity and Inclusion**

At Databricks, we are committed to fostering a diverse and inclusive culture where everyone can excel. We take great care to ensure that our hiring practices are inclusive and meet equal employment opportunity standards. Individuals looking for employment at Databricks are considered without regard to age, color, disability, ethnicity, family or marital status, gender identity or expression, language, national origin, physical and mental ability, political affiliation, race, religion, sexual orientation, socio-economic status, veteran status, and other protected characteristics.

**Compliance**

**If access to export-controlled technology or source code is required for performance of job duties, it is within Employer's discretion whether to apply for a U.S. government license for such positions, and Employer may decline to proceed with an applicant on this basis alone.**

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
