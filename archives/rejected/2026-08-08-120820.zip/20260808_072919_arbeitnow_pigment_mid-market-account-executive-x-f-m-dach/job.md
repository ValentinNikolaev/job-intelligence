# Mid-Market Account Executive (x/f/m) - DACH

Posted: 2026-08-08T05:05:19Z

## Rejection

- Category: tech_stack
- Reason: role does not mention Go/Golang or PHP

**Join Pigment: The AI Platform Redefining Business Planning**

Pigment is the AI-powered business planning and performance management platform built for agility and scale. We connect people, data, and processes in one intuitive, feature-rich solution, empowering every team—from Finance to HR—to build, adapt, and align strategic plans in real time.

Founded in 2019, Pigment is one of the fastest-growing SaaS companies globally. Industry leaders like Unilever, Snowflake, Siemens, and DPD use Pigment daily to make more informed decisions and confidently navigate any scenario.

With a team of 600+ across Paris, London, New York, Toronto, San Francisco and Austin, we've raised nearly $400M from top-tier investors and were named a Visionary in the 2024 Gartner® Magic Quadrant™ for Financial Planning Software.

At Pigment, we take smart risks, celebrate bold ideas, and challenge the status quo—all while working as one team. If you're driven by innovation and ready to make an impact at scale, we’d love to hear from you.

**What you'll do**

- Lead the full sales-cycle, from initial interest to deal close and coordinate collaboration cross-functionally with customer success, technical teams, etc.

- Create detailed business plans designed to attain predetermined goals and quotas

- Build relationships with executives at all levels and in all industries, in order to close deals (mid-sized corporate organisations)

- Consult with prospects and existing customers regarding business objectives and requirements, and build long-lasting partnerships (corporate organisations)

- Model a wide range of use cases in which Pigment can drive business transformation across different industries

- Provide professional after-sales support with our CSM team to maximise customer loyalty

- Negotiate agreements and keep records of sales and data in Salesforce

- Think critically about sales insights and data and experiment with new growth tactics

**Who you are**

- You have first hand experience as a B2B Account Executive or similar sales role in SaaS B2B or finance product

- You have the ability to open and develop a mid-market market across our DACH market.

- You thrive partnering with business leaders and executives, developing long-term relationships, closing deals, and aligning key stakeholders at each stage of the sales lifecycle

- You have an affinity for tech and product issues and / or a relevant experience in finance or business planning

- You are passionate about our overall mission at Pigment and how it can bring value to our clients

- You have a deep track record of creating significant revenue impact and deep relationships for your organisation

- You are a resourceful, creative problem-solver when faced with the business needs of your clients, and understanding how Pigment plugs into the bigger picture for them

**What we offer**

- Competitive package

- Trust and flexible working hours

- Along with one company offsite every year, we have brand new offices at the heart of major cities including New York, San Francisco, Toronto, Paris, and London

- High-end equipment (based on stock/availability) to do your work in the best conditions

- Hybrid working environment

**How we work**

- Thrive Together: We can only win as a team. We are all founders and do the right thing for our peers, Pigment customers, partners, and the planet

- Never Settle: We aim to become the best at what we do by delivering with rigor and ambition every day. Delivering means building a passionate Pigment community

- Go for it: We are biased towards action. Every action leads to learning and these learnings get us one step closer to our mission

- Be real, be humble: We are generous with our feedback, open to change our views and we approach it with empathy knowing everyone is trying to do the best for Pigment

*We conduct background checks as part of our hiring process, in accordance with applicable laws and regulations in the countries where we operate. This may include verification of employment history, education, and, where legally permitted, criminal records. Any checks will be conducted lawfully prior to formal employment contracts being signed, with candidate consent, and information will be treated confidentially.*

*Pigment is an equal opportunity employer. We believe diversity is a strength and fosters innovation. We are committed to enabling everyone to feel included and valued at the workplace. All qualified applicants will receive consideration for employment without regard to age, color, family, gender identity, marital status, national origin, physical or mental disability, sex (including pregnancy), sexual orientation, social origin, or any other characteristic protected by applicable laws. We may process your personal data in accordance with our **[HR Data Protection Notice](https://get.pigment.com/hubfs/Legal/Applicant%20data%20protection%20notice%20-%20may%202026.pdf)**.*

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
