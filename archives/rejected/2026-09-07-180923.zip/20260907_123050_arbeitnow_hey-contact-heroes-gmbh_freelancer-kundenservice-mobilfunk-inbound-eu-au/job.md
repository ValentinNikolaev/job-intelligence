# Freelancer - Kundenservice Mobilfunk Inbound - EU, außerhalb Deutschland - 100% Remote

Posted: 2026-09-07T10:30:45Z

## Rejection

- Category: language_requirement
- Reason: hard German language requirement without English green light

## Kennst du schon die hey contact heroes?

**Noch nicht? Dann wird’s Zeit!**

Die hey contact heroes stehen für echte Innovationen im Kundenservice! Wir haben uns auf die Bereitstellung erstklassiger Kundenservice-Lösungen spezialisiert hat. Mit über 500 Agent/innen sind wir in mittlerweile 17 Ländern rund um die Uhr und rund um den Globus im Einsatz.

**100 % Remote - innerhalb der EU (ausgenommen: Deutschland)**

Die hey contact heroes starten für eine große und bekannte Mobilfunk-Marke ein neues, größeres Projekt im Bereich Prepaid-Kundenservice. Es handelt sich um einen Inbound-Service.

Dafür suchen wir zuverlässige, motivierte Freelancer innerhalb der EU, mit Wohnsitz außerhalb Deutschlands, die uns langfristig im Inbound-Customer-Service unterstützen.

Wenn du außerhalb von Deutschland lebst und arbeitest und als selbständiger Freelancer remote arbeiten möchtest, bist du bei uns genau richtig.

## Deine Mission:

- Bearbeitung von Inbound-Anrufen rund um Prepaid-Produkte, Tarife, SIM-Karten, Aufladungen und technische Basisanfragen

- Professionelles Projektumfeld mit festen Ansprechpartnern

- Flexible Einsatzzeiten im Rahmen des Projekts, Du bestimmst wann Du arbeitest

- Vergütung pro Stunde oder pro Produktivminute (abhängig vom Projektmodell)

- 100 % Remote - Arbeite von deinem Standort innerhalb der EU (außer Deutschland)

## Dein Profil:

**1. Rechtliche & formale Voraussetzungen:**

- Selbstständigkeit/Freelancer-Status im jeweiligen Wohnsitzland

- Wohnsitz außerhalb von Deutschland, aber innerhalb der EU

- Fähigkeit, ordnungsgemäße Rechnungen gemäß den gesetzlichen Vorgaben des eigenen Landes an internationale Auftraggeber (uns) auszustellen

- Erfüllung der steuerlichen Pflichten im eigenen Land

**2. Fachliche & persönliche Anforderungen:**

- Deutschkenntnisse auf C1/C2-Niveau

- Erfahrung im telefonischen Kundenservice von Vorteil

- Selbstständige Arbeitsweise & Organisation

- Langfristiges Interesse an der Projektmitarbeit

**3. Technische Voraussetzungen:**

- Stabile Internetverbindung (mindestens 50 Mbit/s)

- Headset, zwei Monitore, Webcam und einen leistungsfähigen PC

- Ruhiger, ungestörter Arbeitsplatz im Home-Office (kein Einblick/Zugang für Dritte)

- Sicherer Umgang mit webbasierten Tools

## Unser Angebot:

- Langfristiges Großprojekt mit stabiler Auslastung

- Attraktive und faire Konditionen, je nach Projektmodell

- Persönlicher Support durch ein erfahrenes Team

- Hohe Flexibilität, Du planst deine Einsätze eigenständig

**Klingt gut? Dann freuen wir uns auf deine Bewerbung!**

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
