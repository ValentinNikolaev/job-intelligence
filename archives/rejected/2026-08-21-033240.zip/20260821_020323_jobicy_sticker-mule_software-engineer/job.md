# Software engineer

Posted: 2026-08-16T14:51:52Z

## Rejection

- Category: tech_stack
- Reason: role does not mention Go/Golang or PHP

Sticker Mule is building the Internet's most lucrative commerce platform by combining software, manufacturing, and AI into one fully integrated stack. No print company, or pure software company for that matter, can match what we're doing. We're privately owned, profitable, and doing 9-figures in annual revenue with no meddlesome investors.





### **How we work**



- 

Small, autonomous teams that own products end-to-end.




- 

Prioritize what matters right now and pivot instantly when needed.




- 

Ship across web and mobile from the same codebase. We use Go, TypeScript, React, Expo, GraphQL, Postgres, and run on GCP.




- 

Use AI aggressively to push the limit of what we can do.




- 

Move fast, build for the masses, and deprioritize edge cases.




- 

Fully remote from 40+ countries and collaborate using Asana and Slack.






### **Requirements**



- 

You are an exceptional full-stack software engineer.




- 

You use AI aggressively and write well in English.








### **What you will work on**

You'll help build and scale **Sticker Mule Pro** - a suite of software tools for creators and businesses:





- 

Stores (Shopify alternative)




- 

AI tools (internal and customer-facing)




- 

Notify (Mailchimp alternative)




- 

Reply (Zendesk alternative)




- 

Hire Me (Contra alternative)




- 

Mobile apps






### **Compensation**



- 

Salary: $150,000–$250,000 USD




- 

$20,000 signing bonus




- 

4 weeks vacation + country-specific holidays




- 

Fully remote
