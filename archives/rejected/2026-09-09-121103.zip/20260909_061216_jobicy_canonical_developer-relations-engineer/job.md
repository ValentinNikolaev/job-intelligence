# Developer Relations Engineer

Posted: 2026-09-02T04:55:25Z

## Rejection

- Category: stale
- Reason: published_at 2026-09-02T04:55:25Z is older than 7 days

As the publisher of Ubuntu we serve millions of developers, building for the cloud, IoT and data science. We aim to make open source easier and more reliable for innovators and enterprises.

We have created a new Developer Relations team to engage directly with open source communities and developer-centric organisations. We hope both to communicate our vision and products for better open source development experiences, and also to have a better feedback loop from those audiences to shape our offerings and priorities.

A Developer Relations Engineer is a technical expert, strategist and communicator with deep empathy for developers. This discipline combines practical engineering skills with firm diplomacy across organisational boundaries, in both directions. Like our audience, a Developer Relations Engineer is never satisfied with the status quo, and is driven by an insatiable curiosity to find better ways to get things done. They are problem-solvers and inventors, who understand people's needs and love the way that tools can be adapted to meet them. They stay current with tech trends and provide insights and guidance while fostering innovation.

To improve your chances of success in this application, read our advice on [how to get a job at Canonical](https://canonical.com/blog/how-to-get-a-job-at-canonical).

**Location**: *we are building our initial DevRel team in Europe, Middle East, African and American time zones*

## What your day will look like

In a typical day, a developer relations engineer might:

- take part in team product meetings, at levels from strategy to day-by-day development progress, contributing insight and expertise

- maintain conversations with developer community members wherever they may be found - IRC, social media, product forums, meet-ups and more

- work with colleagues in other teams in the company, as part of efforts to help establish commonality and consistent approaches

- help solve specific technical problems that users or colleagues have identified

- contribute to technical documentation to ensure that developer users' needs are met there

- work on technical articles, presentations or workshops

- identify new opportunities and directions for improvement in the developer experience we provide

- present at conferences, meetups or technical events

## What we are looking for in you

A strong candidate

- is a programmer or developer with a demonstrable passion for and engagement in open-source software

- has worked with real-world challenges developing and deploying software using Linux

- has practical hands-on experience of Linux software packaging (including Snaps, debs, charms, rocks, PIP, containers)

- understands current software packing issues and trends in the Linux ecosystem

- has been a contributor to open-source communities, software and documentation

- is an engaging, vivacious speaker and presenter

- can work effectively, tactfully, empathetically and confidently in contexts where different parties have different perspectives, needs and understanding

- builds trust, relationships and confidence

- is willing to travel globally twice a year for company events, as well as to upstream and partner events

## Additional skills that you might also bring

- previous experience in a developer advocacy or community role

- in-depth familiarity with Ubuntu and the Canonical ecosystem of products

## What we offer you

We consider geographical location, experience, and performance in shaping compensation worldwide. We revisit compensation annually (and more often for graduates and associates) to ensure we recognise outstanding performance. In addition to base pay, we offer a performance-driven annual bonus. We provide all team members with additional benefits, which reflect our values and ideals. We balance our programs to meet local needs and ensure fairness globally.

- Distributed work environment with twice-yearly team sprints in person - we’ve been working remotely since 2004!

- Personal learning and development budget of USD 2,000 per year

- Annual compensation review

- Recognition rewards

- Annual holiday leave

- Maternity and paternity leave

- Employee Assistance Programme

- Opportunity to travel to new locations to meet colleagues from your team and others

- Priority Pass for travel and travel upgrades for long haul company events

## About Canonical

Canonical is a pioneering tech firm that is at the forefront of the global move to open source. As the company that publishes Ubuntu, one of the most important open source projects and the platform for AI, IoT and the cloud, we are changing the world on a daily basis. We recruit on a global basis and set a very high standard for people joining the company. We expect excellence - in order to succeed, we need to be the best at what we do.

Canonical has been a remote-first company since its inception in 2004.​ Work at Canonical is a step into the future, and will challenge you to think differently, work smarter, learn new skills, and raise your game. Canonical provides a unique window into the world of 21st-century digital business.

## Canonical is an equal opportunity employer

We are proud to foster a workplace free from discrimination. Diversity of experience, perspectives, and background create a better work environment and better products.[ Whatever your identity, we will give your application fair consideration.](https://canonical.com/careers/diversity/identity)

#LI-remote
