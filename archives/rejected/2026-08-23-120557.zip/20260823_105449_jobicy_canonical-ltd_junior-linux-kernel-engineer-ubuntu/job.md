# Junior Linux Kernel Engineer - Ubuntu

Posted: 2026-08-22T16:40:08Z

## Rejection

- Category: tech_stack
- Reason: role does not mention Go/Golang or PHP

Canonical is a leading provider of open source software and operating systems to the global enterprise and technology markets. Our platform, Ubuntu, is very widely used in breakthrough enterprise initiatives such as public cloud, data science, AI, engineering innovation, and IoT. Our customers include the world's leading public cloud and silicon providers, and industry leaders in many sectors. The company is a pioneer of global distributed collaboration, with 1200+ colleagues in 75+ countries and very few office-based roles. Teams meet two to four times yearly in person, in interesting locations around the world, to align on strategy and execution.

The company is founder-led, profitable, and growing.

Every year we select new junior professionals into the Canonical Kernel Team, to work on the Linux kernel for Ubuntu. If you’ve enjoyed operating systems in your coursework or current role, you are confident in your ability to write high quality C and possibly Rust, and are ready to take the plunge and see how it all works, then this would be a great place to pursue your next career stage. We are a global team working to ship the world's most widely used Linux kernel, across the very latest silicon and cloud, where you can apply and grow your software engineering skills.

The Canonical Kernel Team builds and maintains all supported Ubuntu Linux kernels for a variety of platforms and architectures from small embedded devices to standard desktop/server systems to large-scale cloud environments. In your first year you will tackle serious initiatives, which include but are not limited to:

- Optimized solutions for key Silicon and Cloud partner platforms

- Developer platforms such as Raspberry Pi and RISC-V

- Enabling Ubuntu on a wide range of embedded systems

- Security hardening and exploit mitigation

- Third-party driver integration and distribution, such as graphics

- Expanded driver support for bleeding-edge PC platforms

We select candidates that are recent university graduates or early career professionals who are enthusiastic to develop kernel-level software in multiple areas including security updates, patching, and testing. The successful candidate will have a background in software engineering, be motivated to work in a distributed team and willing and able to travel globally twice a year for company engineering events.

These are full-time positions available to prospective or recently graduated students.

**Location:** We have home-based Kernel Teams in every timezone.

## **The role entails**

- Collaborate regularly and proactively with a globally distributed team

- Learn from senior mentors to demystify the inner workings of the Linux kernel and how it is distributed

- Work closely with external silicon, cloud, or hardware manufacturer delivery teams on bleeding-edge platforms

- Diagnose and resolve issues in the kernel reported by customers, the community, and discovered by your own rigorous testing

- Take personal responsibility for the delivery of various flavors of the Ubuntu Linux kernel

- Improve tooling and automation for delivery and test of Ubuntu Linux kernels

- Submit, review, and apply kernel patches, working with both internal and external upstream maintainers

## **What we are looking for in you**

- Well-organized and motivated self-starter able to thrive in a remote work environment

- Professional manner with colleagues, business partners, and the open-source community

- Ability to communicate effectively in English, both written and verbal

- Programming experience in C and/or Rust

- Familiarity with version control practices, ideally with git

- Understanding of operating system kernel fundamentals

- Ability to travel twice a year for company events of up to two weeks length

## **Nice-to-have skills**

- Interest and experience in Rust

- Python and Bash scripting ability

- Prior experience with Ubuntu/Debian/Snap packaging

- Demonstrated experience with kernel patching and debugging

- Strong grasp of device drivers, BSP’s, and other low level system engineering

## **What we offer colleagues**

We consider geographical location, experience, and performance in shaping compensation worldwide. We revisit compensation annually (and more often for graduates and associates) to ensure we recognize outstanding performance. In addition to base pay, we offer a performance-driven annual bonus or commission. We provide all team members with additional benefits which reflect our values and ideals. We balance our programs to meet local needs and ensure fairness globally.

- Distributed work environment with twice-yearly team sprints in person

- Personal learning and development budget of USD 2,000 per year

- Annual compensation review

- Recognition rewards

- Annual holiday leave

- Maternity and paternity leave

- Team Member Assistance Program & Wellness Platform

- Opportunity to travel to new locations to meet colleagues

- Priority Pass and travel upgrades for long-haul company events

## **About Canonical**

Canonical is a pioneering tech firm at the forefront of the global move to open source. As the company that publishes Ubuntu, one of the most important open-source projects and the platform for AI, IoT, and the cloud, we are changing the world of software. We recruit on a global basis and set a very high standard for people joining the company. We expect excellence; in order to succeed, we need to be the best at what we do. Most colleagues at Canonical have worked from home since our inception in 2004.​ Working here is a step into the future and will challenge you to think differently, work smarter, learn new skills, and raise your game.

## **Canonical is an equal opportunity employer**

We are proud to foster a workplace free from discrimination. Diversity of experience, perspectives, and background create a better work environment and better products. [Whatever your identity, we will give your application fair consideration.](https://canonical.com/careers/diversity/identity)

#LI-remote
