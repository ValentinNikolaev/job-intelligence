# AI Strategy Consultant

Posted: 2026-07-24T07:01:12Z

## Rejection

- Category: stale
- Reason: published_at 2026-07-24T07:01:12Z is older than 7 days

**Headquarters:** Remote (North America)

## About Hightouch

Hightouch is an Agentic Marketing Platform powered by the industry-leading Composable CDP. With complete brand context, customer data, and performance history in one place, every marketer finally has the power to build and ship end-to-end campaigns themselves. Teams move faster, stay on brand, and get AI marketing that actually works.

Founded in 2019 and headquartered in San Francisco, Hightouch enables marketing teams to analyze performance, brainstorm ideas, and generate creative at a speed and quality that wasn't previously possible.

Named a Leader in the 2026 Gartner® Magic Quadrant™ for Customer Data Platforms, Hightouch is trusted by leading enterprises like Domino's, Spotify, Aritzia, Cars.com, Ramp, and PetSmart.

At Hightouch, our mission is to help our customers leverage data and AI to grow their businesses. The team is ambitious, impact-driven, efficient — and we believe humility, kindness, and compassion are essential to our success. If you're energized by velocity, obsessed with raising the bar, and want to build alongside people who care deeply about each other and our customers, we'd love to meet you.

## **About The Role**

At its core, the AI Strategy Consultant role centers around driving marketing strategy and transformation in enterprise organizations.

Today, most marketing communications are planned weeks in advance on a calendar based on dates and internal priorities. Each email, push, campaign takes 3-5 people and dozens of steps to create. Our customers come to us looking to transform the way they do marketing: using AI agents to rapidly learn about consumer preferences and deliver highly effective marketing and product experiences to each customer 1:1.

As an AI Strategy Consultant, you are the** **trusted technical–strategic partner for our AI Decisioning customers. You own the bridge between what the product can do and what the customer’s business needs — from discovery through go‑live and expansion.

You’ll work with as a part of a driven and creative team of ML + product engineers, product designers, and other Strategy Consultants to deploy new use cases with the largest customer-facing brands in the world. Your mission is to uncover the most impactful use cases for our customers, understand the insights that are derived from the decision engine, and recommend to our customers new campaigns or adjustments to achieve greater outcomes.

You’ll immerse yourself in our customer’s marketing organization. You’ll partner with customer teams and explore the data, and plunge into the product landscape to help us scale. The problems you’ll work on require a curious and analytical approach, sharp product intuition, and the ability to use insight to improve decisions.

**No two days are the same, but you can expect to:**

- Own all phases of AI Decisioning use case delivery working alongside Hightouch engineers, customer executives, marketers, and IT stakeholders

- Run design sessions with customers to decide on and document use case requirements and improvements

- Champion delivery & project management excellence through development of process playbooks and best practices

- Proactively identify, escalate, and mitigate potential project risks

- Build relationships with key stakeholders at Hightouch customers

- Participate in driving the AI Decisioning product strategy

## What We're Looking For

- Ability to travel 10 - 25% required

- Experience working with Martech tools/CEMs/CDPs/etc.

- Strong discovery and interpersonal skills

- Intellectual curiosity, high ambition, and humility

- Clear communicator: you are able to express yourself clearly and persuasively, both in writing and speech

- Experience managing and executing technical projects with a customer-first attitude and a strong sense of empathy

## Bonus If You Have

- Experience with programming, scripting or statistical packages (e.g. Python, R, Matlab, SQL)

We are looking for talented, intellectually curious, and motivated individuals who are interested in tackling the problems above. We focus on impact and potential for growth more than years of experience. The salary range for this position is $170,000-$200,000 (80/20 split variable) USD per year.

**E-Verify Statement**

*Hightouch participates in E-Verify. After you join the team, we'll verify your eligibility to work in the U.S. by submitting information from your Form I-9 to the Social Security Administration and, if needed, the Department of Homeland Security. This process happens post-hire only — we never use E-Verify to pre-screen applicants.*

*
*[*E-Verify Notice**
*](https://www.rhoworld.com/wp-content/uploads/E-Verify_Participation_Poster-1.pdf)[*E-Verify Notice (Spanish)**
*](https://www.rhoworld.com/wp-content/uploads/E-Verify_Participation_Poster_ES-1.pdf)[*Right to Work Notice**
*](https://www.rhoworld.com/wp-content/uploads/ier_poster_final.pdf)[*Right to Work Notice (Spanish)*](https://www.rhoworld.com/wp-content/uploads/spanish_ier_poster_final.pdf)

**To apply:** [https://weworkremotely.com/remote-jobs/hightouch-ai-strategy-consultant](https://weworkremotely.com/remote-jobs/hightouch-ai-strategy-consultant)
