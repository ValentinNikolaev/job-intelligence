# Backend-Entwickler Laravel (m/w/d) 4-Tage-Woche

Posted: 2026-09-09T10:40:51Z

## Rejection

- Category: stale
- Reason: published_at 2026-09-09T10:40:51Z is older than 7 days

Intro Du möchtest an einer Legal-Tech-Anwendung arbeiten, die für E-Commerce-Unternehmen wie eine digitale Rechtsabteilung funktioniert? Du entwickelst gern robuste Backend-Lösungen, denkst in sauberer Geschäftslogik, klaren Schnittstellen, wartbaren Systemen und möchtest technische Lösungen mit echtem Produktbezug gestalten? Dann bist du als Backend-Entwickler (m/w/d) beim Händlerbund genau richtig! Bei uns entwickelst du an einer Plattform, die rechtliche Prozesse digital abbildet und automat…
