# SAP ABAP Entwickler – Fokus Output Management & Formulare - Vollzeit (m/w/d)

Posted: 2026-09-05T05:30:01Z

## Rejection

- Category: tech_stack
- Reason: role does not mention Go/Golang or PHP

ÜBER** UNS:**

Wir sind die 24 Log GmbH, ein innovatives und wachsendes Unternehmen im Bereich der SAP Logistik. Unsere Mission ist es, die komplexen Herausforderungen der modernen Logistik mit intelligenten, zielstrebigen und benutzerfreundlichen Lösungen zu meistern. Von der Konzeption über die Realisierung und Implementierung bis hin zum flächendeckenden, internationalen Rollout und Betrieb begleiten wir Ihre Projekte gewissenhaft und zielorientiert.

Mit unseren SAP-basierten IT-Logistiklösungen und Systemintegrationen sichern wir den reibungslosen Ablauf Ihrer logistischen Prozesse und tragen dazu bei, dass Ihre Projekte erfolgreich und termingerecht abgeschlossen werden.

WIR** BIETEN:**

-

**Sicherer Arbeitsplatz:** Jede Person, die wir einstellen, soll langfristig mit uns wachsen. Das Ziel jeder Einstellung ist eine unbefristete Übernahme.

-

**Firmenwagen:** Für die Ausübung deiner Tätigkeiten stellen wir dir einen Firmenwagen zur Verfügung, damit du flexibel und komfortabel unterwegs bist - auch privat. Du hast **freie Fahrzeugauswahl**!

-

**BIKELEASING:** Du leistest dir dein Wunschfahrrad günstig über unser "Jobrad"-Programm. Umweltfreundlich und fit unterwegs – wir unterstützen dich dabei!

-

**Vielfältige Mitarbeitervorteile:** Profitiere von vermögenswirksamen Leistungen (VWL) und betrieblicher Altersvorsorge (BAV). Wir bieten dir zudem flexible Arbeitszeiten und freie Zeitgestaltung.

-

**Tolle Arbeitsatmosphäre:** Unsere Arbeit lebt von einem positiven und kundenorientierten Umfeld. Nur wer selbst positiv eingestellt ist, kann auch andere begeistern.

-

**Gute Vergütung & Karrierechancen:** Unsere Mitarbeitenden erhalten ein marktgerechtes Gehalt und können von zahlreichen weiteren Leistungen profitieren. Du hast zudem die Möglichkeit, über unser partizipatives Modell fortlaufend von den Erfolgen in der Umsetzung persönlich zu profitieren.

-

**Individuelle Entfaltungsmöglichkeiten:** Spannende Projekte mit viel Potenzial für die eigene Entwicklung und ein persönliches Weiterbildungsbudget, das individuell eingesetzt werden darf.

DEINE** AUFGABENBEREICHE:**

-

**Entwicklung & Design:** Konzeption und Implementierung von komplexen Formularen mittels **Adobe Forms**, **SmartForms** und klassischen **SAPscript**-Beständen.

-

**Programmierung:** Erstellung und Optimierung von ABAP- und ABAP-OO-Programmen zur Datenbeschaffung für den Formulardruck.

-

**Modernisierung:** Migration bestehender Formularlandschaften (z.B. von SmartForms zu Adobe Forms) und Anbindung an Cloud-Lösungen.

-

**Schnittstellenmanagement:** Integration von Formularen in Geschäftsprozesse (SD, MM, FI/CO) sowie Anbindung von externen Output-Management-Systemen.

-

**Beratung:** Unterstützung der Fachabteilungen bei der Definition von Layouts und technischen Anforderungen.

-

**Troubleshooting:** Analyse und Behebung von Fehlern im Druckumfeld sowie Performance-Optimierung.

DEIN** PROFIL:**

-

**Ausbildung:** Studium der (Wirtschafts-)Informatik oder eine vergleichbare Qualifikation mit mehrjähriger Berufserfahrung in der SAP-Entwicklung.

-

**Sprachkenntnisse:** Fundiertes Wissen in **ABAP** und **ABAP Objects**.

-

**Fokus Formulare:** Expertenkenntnisse in **Adobe Interactive Forms (Adobe Document Services), SmartForms und SAPScript** sind zwingend erforderlich.

-

**Web-Technologien:** Grundkenntnisse in JavaScript (für Adobe Forms Logik) sowie idealerweise erste Berührungspunkte mit SAPUI5/Fiori.

-

**Prozesswissen:** Gutes Verständnis der gängigen SAP-Module (insb. SD, MM, PP) und deren Drucksteuerung (Nachrichtenfindung).

-

**Arbeitsweise:** Analytisches Denkvermögen, Qualitätsbewusstsein und Freude an der Dokumentation.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
