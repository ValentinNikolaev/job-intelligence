# Analyst Early Stage Team

Posted: 2026-09-05T02:40:13Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

## Analyst Early Stage Investment Team (m/f/d) - Berlin, Munich, London

HV Capital is one of Europe's largest generalist VCs. We invest from pre-seed through growth, across SaaS, fintech, deep tech, and beyond. This is a seat inside the investment team, working directly with partners on sourcing, diligence, and portfolio support.

## What you'll actually work on

**Finding the next companies before anyone else does.** Building market maps in sectors we're excited about, sourcing directly instead of waiting for inbound, running comps, and going deep enough on a space that you know it better than the partner sitting next to you.

**Running real diligence.** Talking to founders, customers, and competitors. Building the model, not just filling in someone else's template. Stress-testing a business case instead of taking the deck at face value. Writing memos that make a case a partner would actually defend in an investment committee.

**Forming your own view, and holding it.** We're still making bets on people as much as products, and that means judgment: reading a founder, reading a room, deciding whether you'd trust this person with your own money. That's a muscle, not a checklist.

**Sitting in the room, eventually.** Partner meetings and deal reviews once you've earned it; not to run them, but to watch how a real investment decision actually gets made, and to have a sharp, well-formed view ready when someone asks for yours.

**Portfolio support.** The odd KPI request, board-prep question, or research ask from a founder who needs a sharp answer fast, not a polished deck in two weeks.

## What good looks like here

We evaluate analysts on judgment and reasoning (can you form an independent view and defend it under pushback), commercial acumen (do you actually understand what makes a business work), deal execution (can you run a process end to end from sourcing, modeling, diligence to closing support), and how you show up in the room. Ownership and curiosity matter as much as any of that. Chasing a thread nobody assigned you, following through without being asked twice.

The craft still matters. A clean model, a memo that holds up, a process run properly. That's the baseline, not optional. What increasingly separates a good analyst from a great one on top of that is judgment: forming a view nobody handed you, and holding it under pushback.

## What we're looking for

At least 2 -3 years of real work experience. Beyond that, we don't have one template. We've hired from strategy consulting, banking, asset management, the sciences, and straight out of operating roles at startups. What matters more than your last job title: can you form a view and defend it, can you read a room, do you have an actual edge instead of a template CV?

Compensation: €90K

- Analyst • €90K

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
