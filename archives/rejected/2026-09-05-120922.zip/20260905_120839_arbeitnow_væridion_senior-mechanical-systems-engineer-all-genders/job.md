# Senior Mechanical Systems Engineer (all genders)

Posted: 2026-09-04T23:40:09Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**Your Mission:**

We are looking for a Senior Mechanical Systems Engineer (all genders) to help us design and develop the mechanical systems on board our fully battery-electric aircraft (CS-23). You will contribute to the definition and development of key aircraft mechanical systems, including the Environmental Control System, landing gear, ice protection, interiors and other mechanical systems. Your work will span the full system development lifecycle, from system-level requirements, architecture and functional analysis through preliminary and detailed design, supplier involvement, testing and certification. You will work closely with overall aircraft design, structures, flight physics, propulsion and other engineering teams to ensure optimal system integration and will play a key role in the detailed definition of the overall aircraft.

**Your Day-to-Day:**

-

Define and derive system-level requirements for mechanical aircraft systems based on CONOPS, aircraft-level requirements and applicable regulations.

-

Perform system-level functional analysis, including functional decomposition and identification of system interfaces.

-

Contribute to the definition and development of mechanical systems to achieve the required level of maturity at each aircraft design phase.

-

Define and manage functional and physical interfaces between mechanical systems and other aircraft disciplines.

-

Collaborate with partners and suppliers as a technical interface for mechanical systems.

-

Support Functional Hazard Assessments (FHA) and system safety activities in accordance with ARP4754A, ARP4761A and applicable certification requirements.

-

Support system integration, verification, testing and certification activities.

**Your Profile:**

-

Engineering degree in Aerospace Engineering, Mechanical Engineering or equivalent.

-

8+ years of aerospace experience, with a focus on aircraft mechanical systems.

-

Experience with systems engineering, including requirements definition, functional analysis and system integration.

-

Knowledge and experience in mechanical aircraft systems, preferably cabin Environmental Control System and/or landing gear.

-

Experience across the aircraft development lifecycle, including EASA/FAA Part 23 or 25 certification.

-

Experience working in an EASA Part 21J organization, or international equivalent.

-

Excellent verbal and written communication skills in English; another European language is a plus.

-

Proactive, solution-oriented and comfortable taking ownership in a fast-paced environment.

-

Passionate about aviation and the electrification of flight.

-

Experience with electric or hybrid-electric aircraft and strong understanding of aircraft systems.

-

Experience working in an aerospace startup or new aircraft development programme.

-

Previous CVE or equivalent technical authority responsibility for one or more mechanical systems on a CS-23 aircraft programme.

*We recognize that women and other under-represented groups are often overlooked in our industry. If you’re excited about this role but don’t meet every listed qualification, we still encourage you to apply. Talent and potential can’t always be captured in a checklist.*

**Why us?**

-

Be part of an ambitious team determined to shape the future of aviation.

-

We are an in-office company, but we value flexibility and trust employees to manage their schedules responsibly. This may include occasional remote work or adjusting hours to accommodate personal commitments.

-

Subsidized EGYM Wellpass membership: your (mental) health is important for us.

-

Enjoy a subsidized lunch with a 5€ company contribution per meal on office days.

-

Become a part of our success with virtual stock options.

-

Choose the option that suits your needs: either a free charging station for your electric car or a public transport job ticket as part of the Deutschlandticket.

-

Lease a high-quality bicycle or e-bike through our JobRad program and benefit from tax advantages. Whether for your daily commute or personal use, enjoy more mobility and sustainability.

-

Pension scheme to support your long-term financial security.

-

Work in one of our offices in Munich or Delft. Enjoy the modern Balan Campus in Munich or work inside the aerospace ecosystem at TU Delft.

-

Boost your professional as well as personal growth executing your own ideas and independent projects.

-

Join our internal social events and retreats (e.g. cooking, game nights, sports).

VÆRIDION was founded in 2021 to transform regional air travel with the Microliner, a 100% electric commercial aircraft. By delivering the most energy-efficient aircraft, we are building the future where clean, safe, and affordable electric aviation seamlessly connects people and businesses. We’re bringing together the brightest minds in aerospace, automotive engineering, and business to disrupt the aviation industry.

Compensation: €80K – €100K

- • Salary €80K – €100K

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
