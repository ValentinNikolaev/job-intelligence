# Senior Fullstack Engineer (m/f/d)

Posted: 2026-09-05T02:09:05Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**Become part of the Verivox Team**

We oﬀer a fulltime position (40h/week) in one of our locations in either **Heidelberg, Berlin, Leipzig or Munich**. The oﬀer includes the option of working several days per week in the **mobile ****oﬃce.**

**Your mission**

- Through your expertise, you provide excellent user experience to our insurance comparison platform using Angular and modern full-stack technologies
- You are part of a cross-functional team in close cooperation with UX Designer, Backend engineers, QA engineers and Product Owner in an established Agile environment
- Make sure what you develop is always in line with the product vision and implement designs from Figma while contributing to backend services too
- Strive to see the big picture and collaborate with the team to connect the dots across frontend and backend APIs
- Suggest improvements, ideas, and solutions for performance optimization, code quality enhancement and AI-powered features
- Share your ideas and expertise in product and technical discussions

**Your essential experience and education**

- You love full-stack development with a strong Angular focus and strive for excellent user experience combined with high code quality
- You have 6+ years of professional experience, with Angular as your primary frontend technology. You have extensive hands-on experience with TypeScript, RxJS, plus professional backend experience with Node.js/NestJS
- TypeScript, HTML5, SCSS and modern testing frameworks (Jest, Karma) are your daily companions
- You have solid knowledge of API design, Docker, Kubernetes, PostgreSQL, Redis, and cloud infrastructure
- You take end-to-end responsibility of your code and its delivery to the customer through CI/CD pipelines
- You are fluent in English, German is a plus

**What's in it for you? **

- Around 500 employees from over 35 nations as a collegial community
- Open, diverse corporate culture with flat hierarchies, as well as a modern and appreciative working environment
- Personal flexibility through flexible working hours, generous remote work policies, and the option to work from other EU countries from time to time
- Selected training courses through the Verivox Academy, as well as language courses to support your personal and professional development
- Individual area of responsibility with space for the development of one's own ideas and concepts
- Uncomplicated cooperation: we are on first-name terms & don't insist on dress codes
- Exclusive employee benefits such as job bike, a subsidy for the Deutschlandticket, lunch, and employee discounts
- Comprehensive wellness programs including EGYM Wellpass, a subsidized company pension plan, BUK Family Service, and much more
- Centrally located offices in Heidelberg, Berlin, Munich, and Leipzig with optimal transportation connections

**Are you up to meet these exciting challenges?**

We look forward to getting to know you! Show us how you can help drive us forward. Please submit your application, including your salary expectations and notice period or earliest possible start date, via the “Apply now” button.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
