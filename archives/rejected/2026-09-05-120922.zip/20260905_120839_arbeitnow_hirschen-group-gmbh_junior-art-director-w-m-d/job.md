# (Junior) Art Director (w/m/d)

Posted: 2026-09-05T05:09:43Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**Wer wir sind. **

Eine der führenden Kommunikationsagenturen im deutschen Raum mit mehr als 300 Mitarbeiter*innen. Wir bieten the full monty: Konzeption, Kreation, Redaktion, Organisation, Kampagnen, Social-Media und technologische Plattformen. Wir begleiten Kund*innen aus Wirtschaft, Politik, Gesellschaft und Medien. Und wir entwickeln alles, was diese für eine wirksame Kommunikation brauchen: Social Media-Kampagnen, Magazine, Fernsehspots und Websites. Von der strategischen Kernidee bis zur technischen Umsetzung. Am liebsten für die komplexen Themen unserer Zeit.

**Was zu tun ist.**

Nachdenken, neu denken, zu Ende denken, mitdenken, groß denken. Ganzheitliche Gestaltungskonzepte mitentwickeln. Ob ein Social Asset funktioniert oder ein Bild zur Headline passt, erkennst du auf den ersten Blick. Guten Ideen gibst du ein schärferes Profil und optischen Feinschliff.

Beim Tagesgeschäft verlierst du nie den Überblick. Auch wenn’s mal kompliziert wird.
Du magst Gegensätze. Vertrackte Themen, klare Umsetzung. Komplexe Botschaften. Und die großen und kleinen Herausforderungen des Alltags.

**Was du mitbringst.**

Du hast mindestens anderthalb Jahre eine Agentur von innen gesehen und dich draußen nach Typos, Trends und Artworks umgeschaut. Du kannst aus einer Idee ein starkes visuelles Konzept entwickeln und dieses eigenständig umsetzen. Du bewegst etwas. Auch mal im Video. Du arbeitest selbstständig und hast ein sicheres Gespür nicht nur für Design, sondern auch Neugier für die Struktur dahinter. After Effects ist dir nicht neu. Photoshop, Illustrator und InDesign kannst du sowieso. Und KI weißt du sinnvoll einzusetzen.

**Wen wir suchen.**

Eine*n (Junior) Art Director (w/m/d). Zum schnellstmöglichen Zeitpunkt. Für Berlin.

**Was wir bieten.**

Einen Arbeitsplatz im schönen Berlin Kreuzberg. Oder da, wo du gerade bist. Als Teil eines liebevollen Teams. Komplexe Inhalte. Klare Kommunikation. Relevante Botschaften. Ein Umfeld aus Lehren und Lernen. Mit jeder Menge Verantwortung. Gut zu wissen - wir reden viel miteinander. Immer auf Augenhöhe. Ist uns eben wichtig.

Außerdem. Anspruchsvolle und herausfordernde Projekte für großartige Kund*innen aus verschiedenen Branchen. Zum Reinbeißen und Lernen. Natürlich auch Freiräume für Weiterbildungen, Seminare und mehr.

**Was, wenn's passt?**

Dann sollten wir uns kennenlernen.

Wir freuen uns über jede Bewerbung von qualifizierten Menschen. Jeder geschlechtlichen und sexuellen Identität. Jeglicher Religionszugehörigkeit. Jeden Alters. Von Bewerbenden mit Migrationshintergrund, People of Colour und/oder Menschen mit Behinderungen. Wiedereinsteiger*innen. Eltern. Quereinsteiger*innen. Alle sind bei uns gleichermaßen willkommen.

Schick uns gerne deine Bewerbungsunterlagen und lass uns wissen wer du bist. Wenn du möchtest, kannst du deine Unterlagen auch anonymisiert als Blind-Bewerbung einreichen – wir stellen einen fairen und transparenten Auswahlprozess sicher. Wir freuen uns auf dich.

Und noch ein Hinweis: Wir nehmen Informationssicherheit ernst – und freuen uns, wenn du diesen Anspruch mit uns teilst.

**Deine Ansprechpartnerin.**

Anette Lezak

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
