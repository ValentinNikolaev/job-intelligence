# Cloud Security Engineer

Posted: 2026-09-05T02:40:08Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

[YGO.ai](http://YGO.ai) is a VC-funded AI tourism platform. We are hiring a Cloud Security Engineer to own the security of our cloud platform, the APIs our enterprise clients run on and the company itself.

🛡️ **About this role.** The role carries two things at once. You own security engineering directly and hands-on. You build the security function around it as we grow. At YGO a pod lead is a squad leader and a spokesperson, close to the work and close to the client, rather than a full-time manager. You will not stop being an engineer.

The work is broad. You might review source code in the morning, investigate an endpoint alert after lunch and help design a new authentication flow the next day. You identify the highest-risk problems, decide what happens first and execute.

We serve major travel enterprises and we have enterprise commitments going live from the start of 2027. Security is a condition of that business, not a layer added afterwards.

### 🧑‍💻 What you'll own

-

**Application security.** Hands-on code and architecture review across our APIs, backend services and internal tooling. Targeted penetration testing to validate issues yourself. Working with engineers on root causes and practical fixes rather than handing over reports. Vulnerability management and the external penetration tests we commission

-

**Detection and response.** Knowing we are under attack while it is happening and what happens next. Alerting, intrusion detection, incident process and the on-call path

-

**Cloud and platform hardening.** Access control, network boundaries, secrets management, containers and the deployment pipeline. Security through the SDLC: CI/CD, repositories and dependencies

-

**The security of our APIs.** Authentication and authorization, tenant isolation, token scoping and lifecycle, abuse prevention, enterprise SSO and the audit trail our clients and our own accountability depend on

-

**The security of our AI systems.** Prompt injection, tool and agent permissions, our MCP server, retrieval and data ingestion. The data-residency rules we are held to contractually

-

**Identity and company security.** SSO, MFA and privileged access for employees, onboarding and offboarding, access reviews, MDM, endpoint security and SaaS access. The practical IT security a company our size needs done, not discussed

-

**Secure design across the pods.** Threat modelling and design review that enables engineers rather than gatekeeping them and raises the standard of what they ship

-

**The security function itself.** Set the priorities and the roadmap from actual risk, not security theatre. Decide what we build, buy, automate or leave for later. Grow the team and hire into it, represent security to enterprise clients and carry our SOC 2 programme on Drata. Compliance is part of the job and it is not the centre of it

### 🚢 What you'll secure

-

An AI search and recommendation engine for major travel enterprises: enterprise integration, SSO, client security reviews, GDS integrations

-

A content enrichment API sold as SaaS: high scale, public facing, data and AI heavy

-

The platform underneath: a client console with organisations, projects and API tokens, supplier and business-client integrations, data ingestion, an MCP server, and several LLM providers behind a single internal library

### 📚 Our stack

-

**Backend:** Go monorepo (no framework, 3+ services)

-

**Data:** PostgreSQL, Redis, Redis Asynq queue

-

**Hosting:** PaaS-managed containers, Cloudflare in front

-

**Observability:** Jaeger tracing, BetterStack for logging, alerting and on-call

-

**Compliance:** Drata, SOC 2 in progress

-

**AI tooling:** Claude Code, used across the whole team

### ✅ You must have

-

**5+ years of hands-on security work spanning more than one discipline.** Not five years of engineering with some security in it. This role sets the standard for the company, so it needs someone who has seen enough to have judgement rather than opinions

-

**Application security depth.** You know how modern web applications and APIs are attacked. You can validate an issue yourself through code review or a targeted penetration test and work with the engineer on the fix

-

**A strong grasp of authentication and authorization.** OAuth and OIDC, sessions, token handling, access control and the failure modes behind most API breaches

-

**Cloud security fundamentals, properly.** Identity, network, workload and pipeline security on a modern cloud platform, applied to production systems you were responsible for

-

**Defensive experience alongside the offensive.** You have investigated real incidents. You have built or improved the detection and alerting that catches them

-

**Threat modelling and secure architecture** for cloud, container and API systems

-

**An engineering background.** You are comfortable in a codebase, you can review what our engineers and our AI tools produce and you can build what you need yourself. Our backend is Go. Prior Go experience is a plus and not a requirement

-

**Comfort in resource-constrained environments.** Startups, small security teams or consultancies taught you to prioritize on risk, business impact and available resources and to execute yourself

-

**The appetite to build a team.** You want to grow this function and eventually lead it. Prior leadership experience is a plus and not a requirement. We would rather have depth and develop the leadership than the reverse

-

**Working proficiency with Claude Code.** Share specific examples

-

Judgement about pace. You secure a company that ships daily without becoming the reason it stops. Guardrails over gates

-

Experience of SOC 2, ISO 27001 or demanding enterprise security reviews

-

Excellent spoken and written English. You will talk to auditors, client security teams and our own engineers, often in the same week

-

⚠️ European or African time zones (±3 hours from CET)

-

Available full-time (40 hours per week)

### 🌟 Nice to have

-

**AI and LLM security:** prompt injection, agent and tool permissions, model security, retrieval pipelines. Very few security roles let you both use AI as your main tool and secure it as your subject. This one does

-

**Early security hire experience.** You have been the first or one of the first security hires at a startup or scale-up

-

Experience leading or mentoring security engineers

-

Go

-

Security tooling or automation you built yourself

-

MDM, endpoint protection and identity provider administration (Google Workspace or similar)

-

Compliance automation tooling (Drata, Vanta, Secureframe or similar)

-

Security certifications. Valued as a signal, never required

-

GDPR depth. Travel or GDS exposure

-

German

### ❤️ You are a great fit if you

-

See security as an engineering discipline. You ship fixes and guardrails, not slide decks

-

Can explain a vulnerability to an engineer and its business risk to a client's security lead in the same afternoon

-

Have done offensive work as a penetration tester or consultant and wanted broader ownership than producing reports

-

Want to build something and own it, rather than advise on someone else's

-

Are comfortable challenging unnecessary security bureaucracy and genuinely risky engineering decisions alike

-

Get frustrated when a security fix takes weeks instead of days

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
