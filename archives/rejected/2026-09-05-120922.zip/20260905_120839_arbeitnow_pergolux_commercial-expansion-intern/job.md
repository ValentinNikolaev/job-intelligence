# Commercial Expansion Intern

Posted: 2026-09-05T02:40:11Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

## About PERGOLUX

PERGOLUX is building a category-defining outdoor-living brand—online and now in physical retail. We move fast, test ideas in the real world and give ambitious people room to shape what comes next.

## The Opportunity

PERGOLUX is at the starting line of a major new phase of commercial expansion: building a Germany-wide showroom network and the model that can scale beyond it.

This is a chance to join while the playbook is still blank. Working close to leadership, you will help answer where we expand, how we evaluate opportunities, which economics matter and what systems will make the model repeatable.

This is not a pure strategy role. You will call people, chase answers, test live opportunities and build working tools. But your real output is the blueprint—not simply executing a rollout manual, but helping write it.

## What You’ll Build

### Find the expansion logic

-

Map priority markets, customer demand, retail formats and competitive dynamics.

-

Speak with brokers, landlords, operators and internal teams to test assumptions and close information gaps.

-

Use live location opportunities to learn which criteria truly predict a great showroom.

### Build the commercial model

-

Create business cases and scenarios around rent, investment, revenue potential and payback.

-

Define practical scorecards, decision gates and evidence standards for location choices.

-

Turn incomplete data into clear recommendations and commercial trade-offs.

### Design the expansion operating system

-

Shape the pipeline, workflows, handovers and information structure behind future expansion.

-

Build lightweight dashboards, automations, templates and AI-enabled tools that remove repetitive work.

-

Identify what should be standardised across markets—and what should stay flexible.

### Write the playbook from the first showrooms

-

Compare early assumptions with actual results and customer feedback.

-

Capture what worked, what failed and what should change before the next wave.

-

Turn those lessons into a scalable roadmap and clear guidance for future execution teams.

## Your Business Impact

-

Give PERGOLUX a clear answer to where, when and under what conditions physical retail should scale.

-

Make location decisions faster, more consistent and grounded in economics rather than intuition.

-

Create a repeatable expansion playbook that lowers risk and management effort for every new showroom.

## What You’ll Bring

-

You are enrolled in or recently graduated from university; your field matters less than how you think and execute.

-

You are a sharp, curious generalist who enjoys moving between research, conversations, numbers and building.

-

You get energy from messy problems, create structure quickly and do not wait for a perfect brief.

-

You are willing to get your hands dirty—whether that means making calls, cleaning data or testing a rough solution.

-

You can turn imperfect information into a clear point of view and communicate it confidently in German and English.

-

You are happy to travel across Germany when real-world learning beats another desk-based analysis.

## Nice to Have

-

Exposure to commercial real estate, retail, consulting, startups, operations or business development—helpful, not required.

-

Experience building a business case, process, dashboard, automation or internal tool from scratch.

-

A strong instinct for what is commercially useful, not just analytically interesting.

## AI-Native Is a Plus

Bonus points if you use AI tools to turn repetitive work into lightweight solutions—not just to draft messages.

-

Hands-on experience with Claude Code, Codex, Cursor, Replit or similar AI coding tools.

-

Vibe-coding or rapid-prototyping experience: automations, scrapers, dashboards, small internal tools or data workflows.

-

You do not need a computer-science degree; curiosity, judgment and the ability to ship something useful matter more.

## What We Offer

-

A rare chance to help design a new growth engine at an early stage.

-

Direct exposure to leadership and the full logic behind major commercial expansion.

-

Work that shapes real investment decisions and remains useful long after the internship.

-

An ambitious international team, modern equipment, employee events, product discounts and standard local benefits.

## How to Apply

Send us your CV and a short note on one project where you turned an unclear problem into a concrete result. If you have built or automated something with AI tools, show us—that counts.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
