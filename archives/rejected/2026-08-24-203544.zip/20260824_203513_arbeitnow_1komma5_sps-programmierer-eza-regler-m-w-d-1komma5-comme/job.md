# SPS Programmierer EZA-Regler (m/w/d) - 1KOMMA5° Commercial & Industrial Solutions

Posted: 2026-08-24T12:00:42Z

## Rejection

- Category: language_requirement
- Reason: hard German language requirement without English green light

## 1KOMMA5°

Bei 1KOMMA5° Commercial Solutions unterstützen wir ALLE Gewerbe- und Industrieunternehmen in Deutschland auf ihrem Weg zur CO₂-Neutralität – mit sicheren, effizienten und innovativen New Energy-Anlagen. Damit tragen wir aktiv zu einer klimaneutralen Wirtschaft bei.

Zur Verstärkung unseres Teams suchen wir eine:n SPS-Programmierer EZA-Regler (m/w/d) – Commercial Solutions, die ihre Expertise in Photovoltaik, Energiespeicher, Ladeinfrastruktur, Energiemanagement und Netzwerktechnik einbringen möchten. Bei uns erwarten dich spannende Projekte, ein dynamisches Team und die Chance, die Zukunft von New Energy-Anlagen aktiv mitzugestalten.

## Deine Position

- Entwicklung, Programmierung (ST nach IEC 61131) und Parametrierung zertifizierter EZA-Regler / Parkregler für gewerbliche und industrielle PV- und Speicher-Großanlagen

- Implementierung komplexer Regelkonzepte (Wirk- und Blindleistungsmanagement, Q(U)-Regelung, Spannungsstatik) am Netzverknüpfungspunkt nach VDE-AR-N 4110 und 4120

- Anbindung der Regler an Netzbetreiber-Schnittstellen mittels Fernwirktechnik (IEC 60870-5-101/104, Modbus TCP/RTU) sowie technische Abbildung von Redispatch-2.0-Prozessen

- Technische Umsetzung und Begleitung des Zertifizierungsprozesses (Anlagenzertifikat & Konformitätserklärung) nach FGW-Richtlinien (z. B. TR8) in Abstimmung mit Zertifizierungsstellen

- Durchführung von Funktionstests und Unterstützung bei Fern- sowie Vor-Ort-Inbetriebnahmen (mit planbarem Reiseanteil von ca. 10–20 %) inklusive Erstellung der Systemdokumentation

## Dein Profil

-

Abgeschlossenes Studium oder Technikerausbildung in Elektrotechnik, Automatisierungstechnik, Energietechnik, Informatik oder eine vergleichbare Qualifikation

-

Fundierte Erfahrung in der SPS-Programmierung (ST nach IEC 61131-3) und speziell in der Anwendung und Programmierung von EZA-Reglern / Parkreglern

-

Sichere Kenntnisse in industriellen Kommunikationsprotokollen (Fernwirktechnik IEC 60870-5-104, Modbus) sowie praktische Einblicke in Redispatch 2.0

-

Grundlegendes Wissen über die Mittel- und Hochspannungsrichtlinien (VDE-AR-N 4110 / 4120, grundlegend 4105) sowie Erfahrung mit den FGW-Richtlinien (TR3, TR4, TR8)

-

Analytische Denkweise, ausgeprägte Troubleshooting-Kompetenz in der Fehleranalyse und eine strukturierte Arbeitsweise

-

Kommunikationsstärke für den souveränen Austausch an den Schnittstellen zu Netzbetreibern, Zertifizierungsstellen und internen Teams

-

Führerschein der Klasse B, Reisebereitschaft nach Bedarf für gezielte Vor-Ort-Inbetriebnahmen sowie verhandlungssichere Deutsch- (C1/C2-Niveau) und sehr gute Englischkenntnisse

## Benefits

- Arbeiten, wo's modern ist: Du arbeitest 100% Remote aus dem HomeOffice– ausgestattet mit hochwertigem HomeOffice Equipment wie Laptop, Curved Monitor, Tablet und Firmenhandy

- Sicherheit, auf die Du bauen kannst: Ein unbefristeter Arbeitsvertrag ist für uns selbstverständlich. Du startest mit 28 Urlaubstagen, die jährlich um einen weiteren Tag ansteigen – bis auf 30 Tage

- Starker Teamgeist: Wir sind ein junges, hoch motiviertes Team, in dem das Miteinander wirklich zählt. Erfolge feiern wir gemeinsam auf coolen Teamevents, Sommerfesten, Weihnachtsfeiern oder bei Offsites

- TOP-Arbeitgeber: Wir von 1KOMMA5° mit ca. 3000 Mitarbeiter sind einer der verlässlichsten Arbeitgeber Deutschlands im Umfeld der Erneuerbaren Energien

- Arbeit mit echtem Sinn (Purpose): Du bist Teil der Lösung! Mit Deinem handwerklichen Können unterstützt Du die Energie- und Mobilitätswende und baust unsere Infrastruktur aktiv für eine nachhaltige Zukunft um

- Starke Zusatz-Benefits: Du hast die Wahl! Nutze Vorteile wie das EGYM Wellpass bei über 7.600 Sportpartnern.

- Exklusive Rabatte: Profitiere von tollen Mitarbeiterangeboten und Vergünstigungen über die Plattform FutureBens

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
