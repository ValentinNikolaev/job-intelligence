# Senior Cloud Architect

Posted: 2026-08-05T17:09:19Z

## Rejection

- Category: tech_stack
- Reason: role does not mention Go/Golang or PHP

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
