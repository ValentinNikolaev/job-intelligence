# Software Engineer in Network Infrastructure

Posted: 2026-08-03T10:25:58Z

## Rejection

- Category: tech_stack
- Reason: Python + R is not a target stack

**About Nebius:**

Nebius is leading a new era in cloud infrastructure for the global AI economy. We are building a full-stack AI cloud platform that supports developers and enterprises from data and model training through to production deployment, without the cost and complexity of building large in-house AI/ML infrastructure.

Built by engineers, for engineers. From large-scale GPU orchestration to inference optimization, we own the hard problems across compute, storage, networking and applied AI.

Listed on Nasdaq (NBIS) and headquartered in Amsterdam, we have a global footprint with R&D hubs across Europe, the UK, North America and Israel. Our team of 1,500+ includes hundreds of engineers with deep expertise across hardware, software and AI R&D.

## The Role

We’re looking for a** Software Engineer** to build software that makes network operations safe, scalable, and boring — even as we launch new data centers and expand fast. This is not a “write scripts for configs” role: you’ll build the tooling and services that sit between the network core (switches/ports/VLANs, traffic processors) and the cloud platform on top, using open source where it fits and building the missing pieces where it doesn’t.

### Your responsibilities will include:

- Build and maintain services and tooling that automate the network lifecycle: day-0 provisioning, day-N changes, drift detection, and operational verification

- Make network changes safe and transparent: CI/CD workflows, diff/review tooling, staged rollouts/rollbacks, audit trails, and guardrails

- Develop observability systems that scale across many sites: telemetry pipelines, signal quality, and tooling that shortens incident investigations

- Close “last mile” gaps between the network and the platform: integrate source-of-truth data, expose APIs, and build reliable automation around it

- Collaborate closely with network engineers and SREs to turn real operational pain into product-quality tooling

### We expect you to have:

- 5+ years of professional software engineering experience (or equivalent practical background)

- Strong coding skills and ownership mindset: you can ship and operate reliable services

- Proficiency in **Go** or readiness to switch; **Python** is also welcome (other languages can be useful for OSS debugging/fixes)

- **You don’t have to be Network expert** but we expect you to have interest in infrastructure and/or network

### It will be an added bonus if you have:

- Background in networking (ex-network engineer, CCNP/education, DC networking exposure) or strong interest and proven ability to learn fast

- Experience building automation/infra tooling: CI/CD, IaC, testing/staging environments, or “network-as-code” style workflows

- Low-level networking / datapath experience: eBPF/XDP, DPDK, kernel networking, traffic processing systems

- Experience designing high-load services and observability platforms (metrics/logs/traces, alerting, regression detection)

- Contributions to open source or experience extending/debugging OSS components in production environments

### **We expect Engineers to:**

- Manage large-scale projects involving multiple stakeholders

- Break down complex tasks and guide both their own work and that of more junior colleagues

- Be experts in specific technologies and write high-quality code that can serve as a reference

- Assess task priority and focus on high-impact work, avoiding low-value efforts

- Have strong architectural thinking and contribute to system design

- Be involved in hiring and actively contribute to interviews

- Be willing to share knowledge and mentor others

**Benefits & Perks:**

- Competitive compensation

- Career growth and learning opportunities

- Flexibility and ownership

- Collaborative and innovative culture

- Opportunity to work on impactful AI projects

- International environment and talented teams

**What's it like to work at Nebius:**

Fast moving - Bold thinking - Constant growth - Meaningful impact - Trust and real ownership - Opportunity to shape the future of AI

**Equal Opportunity Statement:**

Nebius is an equal opportunity employer. We are committed to fostering an inclusive and diverse workplace and to providing equal employment opportunities in all aspects of employment. We do not discriminate on the basis of race, color, religion, sex (including pregnancy), national origin, ancestry, age, disability, genetic information, marital status, veteran status, sexual orientation, gender identity or expression, or any other characteristic protected by applicable law.

Applicants must be authorized to work in the country in which they apply and will be required to provide proof of employment eligibility as a condition of hire.

If you need accommodations during the application process, please let us know.
