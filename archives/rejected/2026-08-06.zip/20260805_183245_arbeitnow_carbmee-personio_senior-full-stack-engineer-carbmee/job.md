# (Senior) Full-stack Engineer | Carbmee

Posted: 2026-08-05T14:09:12Z

## Rejection

- Category: tech_stack
- Reason: role does not mention Go/Golang or PHP

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
