# Senior Backend Engineer

Posted: 2026-08-04T00:00:00.0000000

## Rejection

- Category: tech_stack
- Reason: Spring Boot is not a target stack

Role Description
We are seeking an experienced **Backend Engineer **to build and enhance a Java & Spring Boot based enterprise application that... ...work culture: make the most of the flexibility that comes with **remote **work.

~Growth mindset: reap the benefits of a range of...
