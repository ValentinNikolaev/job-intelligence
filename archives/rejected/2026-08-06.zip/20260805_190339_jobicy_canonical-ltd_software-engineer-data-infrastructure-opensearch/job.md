# Software Engineer - Data Infrastructure - OpenSearch/ElasticSearch

Posted: 2026-08-01T03:04:24Z

## Rejection

- Category: tech_stack
- Reason: role does not mention Go/Golang or PHP

Canonical is building a comprehensive automation suite to provide multi-cloud and on-premise data solutions for the enterprise. The data platform team is a collaborative team that develops a full range of data stores and data technologies, spanning from big data, through NoSQL, cache-layer capabilities, and analytics; all the way to structured SQL engines.

The OpenSearch team is, among other things, focused on creating the best enterprise automation solution for search and analytics suites like OpenSearch and Elasticsearch.

We have a number of openings we are looking to hire across a range of levels. We will help you identify a suitable position depending on your experience and interests. Engineers who thrive at Canonical are mindful of open-source community dynamics and equally aware of the needs of large, innovative organisations.

Location: This role can be filled in European, Middle East and African time zones.

## What your day will look like

The OpenSearch team is responsible for the automation of OpenSearch operations. This includes ensuring fault-tolerant replication, TLS, installation, and much more; but also provides domain-specific expertise on the actual data system to other teams within Canonical. This role is focused on the creation and automation of features of data platforms, not analysing the data in them.

- Collaborate proactively with an internationally distributed team

- Write high-quality, idiomatic Python code to create new features

- Debug issues and interact with upstream communities publicly

- Work with helpful and talented engineers including experts in a diverse set of fields

- Work from home with global travel for 2 to 4 weeks per year for internal and external events

## What we are looking for in you

- Proven hands-on experience in software development using Python

- Proven hands-on experience in distributed systems development

- Bachelor’s or equivalent in Computer Science, STEM, or a similar degree

- Willingness to travel up to 4 times a year for internal events

## Additional skills that you might also bring

You might also bring a subset of experience from the following, which will determine the exact role and level we consider you for:

- Experience operating and managing search and analytics engines like Elasticsearch, Logstash, KIbana, and OpenSearch

- Experience with Linux systems administration, package management, and operations

- Experience with the public cloud or a private cloud solution like OpenStack

- Experience with operating Kubernetes clusters and a belief that it can be used for serious persistent data services

## What we offer you

Your base pay will depend on various factors including your geographical location, level of experience, knowledge and skills. In addition to the benefits above, certain roles are also eligible for additional benefits and rewards including annual bonuses and sales incentives based on revenue or utilisation. Our compensation philosophy is to ensure equity right across our global workforce.

In addition to a competitive base pay, we provide all team members with additional benefits, which reflect our values and ideals. Please note that additional benefits may apply depending on the work location and, for more information on these, please ask your Talent Partner.

- Fully remote working environment - we’ve been working remotely since 2004!

- Personal learning and development budget of 2,000USD per annum

- Annual compensation review

- Recognition rewards

- Annual holiday leave

- Parental Leave

- Employee Assistance Programme

- Opportunity to travel to new locations to meet colleagues at ‘sprints’

- Priority Pass for travel and travel upgrades for long haul company events

## About Canonical

Canonical is a pioneering tech firm that is at the forefront of the global move to open source. As the company that publishes Ubuntu, one of the most important open source projects and the platform for AI, IoT and the cloud, we are changing the world on a daily basis. We recruit on a global basis and set a very high standard for people joining the company. We expect excellence - in order to succeed, we need to be the best at what we do.

Canonical has been a remote-first company since its inception in 2004.​ Work at Canonical is a step into the future, and will challenge you to think differently, work smarter, learn new skills, and raise your game. Canonical provides a unique window into the world of 21st-century digital business.

Canonical is an equal-opportunity employer

We are proud to foster a workplace free from discrimination. Diversity of experience, perspectives, and background create a better work environment and better products. [Whatever your identity, we will give your application fair consideration.](https://canonical.com/careers/diversity/identity)

#LI-remote
