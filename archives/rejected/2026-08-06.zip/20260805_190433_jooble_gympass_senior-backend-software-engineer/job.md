# Senior Backend Software Engineer

Posted: 2026-07-31T10:54:40.6772012+00:00

## Rejection

- Category: tech_stack
- Reason: role does not mention Go/Golang or PHP

...We are hiring a **Senior Backend **Software **Engineer ** in our CARE - AI Engine team in Brazil ! This is a **Remote **– Brazil position, meaning you can work from anywhere within the country. Please note that this role is only open to candidates in Brazil. We build AI-powered...
