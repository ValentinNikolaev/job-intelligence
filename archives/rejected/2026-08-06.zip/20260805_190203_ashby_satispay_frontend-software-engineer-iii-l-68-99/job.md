# Frontend Software Engineer III - L.68/99

Posted: 2026-07-17T14:27:50.288+00:00

## Rejection

- Category: stale
- Reason: published_at 2026-07-17T14:27:50.288+00:00 is older than 7 days

Frontend Software Engineer III (L.68/99)

📢 Championing Diversity: People with disabilities encouraged to apply (L.68/99) 🚀

We Welcome Everyone!

This role is part of our commitment to fostering an inclusive workplace: this is why Satispay mainly dedicates this job opportunity to candidates eligible under specific employment protection laws, including those with disabilities or other protected status, in line with Italian law (L.68/99). We encourage candidates from all backgrounds to apply.

Still willing to apply for the role? This specific application form is dedicated mainly to candidates with disabilities. However, we value diversity and talent in all its forms, and everyone is welcome to apply for a job at Satispay! If you’re interested in the role, but you’re not a candidate with disabilities, visit the following link and apply here https://jobs.ashbyhq.com/satispay/8bed4693-6d80-421c-8d64-5fd6bfc02096.



About us

Satispay began by rethinking the simple act of a payment to remove the friction from our daily routines. But we didn’t stop there. Today, we are building a complete financial platform designed to empower people and concretely improve their lives.

By giving our 6 million users a clear, open path to pay, save, and invest, we are evolving into the definitive destination for every financial need.



What you’ll be doing

As a Frontend Software Engineer, you’ll play a key role in contributing to the development of a next-generation, highly scalable, and performant core frontend platform. Here’s what your day-to-day will look like:

 - Collaborate on feature development – Working closely with the team to implement new features, participating in code reviews, and contributing to knowledge-sharing sessions.

 - Enforce coding standards – Ensuring adherence to design patterns and best practices for frontend development.

 - Contribute to the technical vision – Supporting the foundations for a scalable, maintainable, and high-performance UI platform.

 - Evaluate and select technologies – Researching and choosing modern frontend technologies, frameworks, and tools.

 - Design scalable systems – Creating systems that support scalability and modularity to handle evolving business requirements.

Our frontend stack is built around TypeScript and React, with state management handled via TanStack Query, Zustand, and Jotai. We use Tailwind CSS and headless libraries like Radix UI or Base UI to power a modular, accessible design system shared across teams. Validation and functional programming are supported through Zod, fp-ts, and effect.

We also use GraphQL, Next.js and TanStack Start in selected projects, utilizing PostgreSQL for data persistence alongside AWS services like Lambda, S3, SNS, and SQS for serverless and asynchronous architectures. Our testing strategy includes Vitest, React Testing Library, and Playwright for E2E testing.

Everything runs on AWS, with CI/CD pipelines managed via CodeBuild, CodePipeline, and GitHub Actions. Monitoring and observability are handled with Sentry and Kibana.

Expect challenges, collaboration, and the freedom to bring your ideas to life. Things change quickly here, so be ready to adapt, take initiative, and shape your role as we grow.



Who we’re looking for

We need a problem-solver who loves teamwork and gets things done. If you're curious and ready for real ownership, you'll fit in! Does this sound like you?

 - Relevant experience – 3-5 years in front-end development, with a track record of delivering high-quality web applications.

 - Expertise in JavaScript frameworks – Proficient in JavaScript, TypeScript, React, and state management libraries like Tanstack Query

 - Experience with design systems – Skilled in using component libraries (e.g., Storybook, Headless UI, Tailwind CSS) and collaborating on UI/UX discussions

 - Strong understanding of build systems and APIs – Experienced with modern front-end build systems (Vite, Rollup, Nx/Turborepo) and deep knowledge of RESTful APIs, GraphQL, and WebSockets

 - Strong ownership of features – Experience maintaining Node.js applications in production, including using observability/logging tools (e.g., Grafana, Cloudwatch, Logstash) and maintaining unit, integration, and E2E tests.

 - Performance Optimization – Implementing techniques like lazy loading, code splitting, and caching to ensure optimal application performance.

Don't worry if you don't tick every box. We believe in the power of different viewpoints and strengths. Your unique perspective is important as we build something special. If you're passionate and can make a difference, we truly encourage you to apply.



CareAbout: how we support your impact

We move fast, and evolution never stops. It’s a fun ride, but it can be challenging. To make sure our people truly thrive, we’re committed to making their lives easier, both in the office and out in the world. That’s why we created CareAbout:

 - ❤️ Health (Private insurance for you and your family, psychological support with Serenis, mental health workshops)

 - 💰 Financial resources (Stock Option Plan, Meal vouchers, Relocation support if you’re moving countries)

 - ⚙️ Growth and development (Professional development programs, Internal mobility, Language courses with Preply)

 - 🌱 Flexibility (Unlimited PTO, Hybrid working policy*, Flexible working hours)

 - 👨‍👩‍👧 Family (Enhanced parental leave, Additional leave for child sickness)

*We embrace three days per week in-office (Tuesday and Thursday + 1 of your choice), with the option to request extra remote time.



Salary: €45,000 - €53,000 gross per annum

This range is set using objective, gender-neutral criteria for the role's core requirements. However, we do not believe in putting a ceiling on talent. The final compensation package is tailored according to your unique experience and expertise. If your skills go beyond the standard profile, apply anyway so we can discuss a package that reflects your true value.



Equal opportunity employer
At Satispay, we're proud to be an equal opportunity employer. We celebrate diversity and inclusion, welcoming individuals of all backgrounds. This opportunity is open to everyone, regardless - for instance - of race, colour, religion, sex, gender identity, sexual orientation, and national origin. 
Join us in a workplace where everyone belongs!



Learn more about us
Our values and pillars aren’t just fancy words on a page - they really shape everything we do. 
Explore them here https://www.satispay.com/en-it/company/values/.



#LI-VR1

#LI-Hybrid









By submitting this application, I acknowledge that I have read and understood the content of the Privacy Policy https://www.satispay.com/en-it/legal-hub/privacy-policy/candidates/
