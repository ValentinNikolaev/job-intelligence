# Software Engineer III, Backend (L.68/99)

Posted: 2026-07-10T09:17:20.677+00:00

## Rejection

- Category: stale
- Reason: published_at 2026-07-10T09:17:20.677+00:00 is older than 7 days

📢 Championing Diversity: People with disabilities encouraged to apply (L.68/99) 🚀



We Welcome Everyone!

This role is part of our commitment to fostering an inclusive workplace: this is why Satispay mainly dedicates this job opportunity to candidates eligible under specific employment protection laws, including those with disabilities or other protected status, in line with Italian law (L.68/99). We encourage candidates from all backgrounds to apply.

Still willing to apply for the role? This specific application form is dedicated mainly to candidates with disabilities. However, we value diversity and talent in all its forms, and everyone is welcome to apply for a job at Satispay! If you’re interested in the role, but you’re not a candidate with disabilities, visit the following link and apply here https://www.satispay.com/en-it/work-at-satispay/open-positions/f97f126b-a3db-41ce-bf91-63f8f4400cda/



About us

Satispay began by rethinking the simple act of a payment to remove the friction from our daily routines. But we didn't stop there. Today, we are building a complete financial platform designed to empower people and concretely improve their lives. By giving our 6+ million users a clear, open path to pay, save, and invest, we are evolving into the definitive destination for every financial need.



What you'll be doing

As a Software Engineer III, Backend Developer, you’ll play a key role in shaping the future of digital payments by designing and building scalable, high-quality systems. You’ll be delivering features, gaining deep system context, and growing your technical expertise. Here’s what your day-to-day will look like:

 - Own the Story Lifecycle: Complete the entire story lifecycle from intake to production release. You’ll be responsible for standing up product stories and ensuring all requirements are met.

 - Contribute to Technical Excellence: Conduct technical analysis for standard scope stories and implement robust, scalable back-end solutions

 - Grow Technical Leadership: Begin to provide guidance and mentorship for peers and juniors, especially in technical implementation, while ensuring service/component-level technical vision is aligned with the roadmap.

 - Ensure Quality and Stability: Accurately estimate effort and resolve blockers promptly. You will participate in resolving incident resolution including root cause analysis and prevention, ensuring technical transparency across your scope.

 - Document and Communicate: Create comprehensive technical documentation for the features you build and collaborate with stakeholders



Who we’re looking for

We need a problem solver who is eager to learn, owns their work, and is ready to collaborate and to take real ownership. Does it sound like you?

 - Experience & Technical Foundations: You have at least 3 years of industry experience working with Java and a foundational understanding of cloud platforms (AWS is a plus).

 - Teamwork and Communication: You are able to communicate clearly and professionally, contributing to team-level knowledge sharing and building trust with peers.

 - User Focus: Possesses an inherent desire to understand and address user needs, ensuring the back-end system supports a great user experience.

 - Passion and Language Skills: You are passionate about FinTech or startup environments and fluent in English.

 -  conduct technical analysis for large-scope projects affecting multiple systems.

 - Structured Communication: You are able to communicate in a structured and convincing manner, adapting your style to build trust positively and professionally with various stakeholders, including coordinating implementation with other teams.

 - Passion and Language Skills: You are passionate about FinTech or startup environments and fluent in English.



CareAbout: how we support your impact

We move fast, and evolution never stops. It’s a fun ride, but it can be challenging. To make sure our people truly thrive, we’re committed to making their lives easier, both in the office and out in the world. That’s why we created CareAbout:

 - ❤️ Health (Private insurance for you and your family, psychological support with Serenis, mental health workshops)

 - 💰 Financial resources (Stock Option Plan, Meal vouchers, Relocation support if you’re moving countries)

 - ⚙️ Growth and development (Professional development programs, Internal mobility, Language courses with Preply)

 - 🌱 Flexibility (Unlimited PTO, Hybrid working policy*, Flexible working hours)

 - 👨‍👩‍👧 Family (Enhanced parental leave, Additional leave for child sickness)



*We embrace three days per week in-office (Tuesday and Thursday + 1 of your choice), with the option to request extra remote time.



Salary: €45,000 - €53,000 gross per annum

This range is set using objective, gender-neutral criteria for the role's core requirements. However, we do not believe in putting a ceiling on talent. The final compensation package is tailored according to your unique experience and expertise. If your skills go beyond the standard profile, apply anyway so we can discuss a package that reflects your true value.



Equal opportunity employer
At Satispay, we're proud to be an equal opportunity employer. We celebrate diversity and inclusion, welcoming individuals of all backgrounds. This opportunity is open to everyone, regardless - for instance - of race, colour, religion, sex, gender identity, sexual orientation, and national origin. Join us in a workplace where everyone belongs!



Learn more about us
Our values and pillars aren’t just fancy words on a page - they really shape everything we do. Explore them here https://www.satispay.com/en-it/company/values/.




#LI-HYBRID
#LI-VR1







By submitting this application, I acknowledge that I have read and understood the content of the Privacy Policy https://www.satispay.com/en-it/legal-hub/privacy-policy/candidates/
