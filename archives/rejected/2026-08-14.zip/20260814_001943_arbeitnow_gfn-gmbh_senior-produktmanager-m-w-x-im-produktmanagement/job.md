# Senior Produktmanager (m/w/x) im Produktmanagement für unsere Umschulungen FISI/FIAE Remote

Posted: 2026-08-13T21:00:28Z

## Rejection

- Category: language_requirement
- Reason: hard German language requirement without English green light

Die GFN GmbH begleitet als Bildungsanbieter mit IT-Spezialisierung deutschlandweit Menschen bei ihrer Weiterbildung und beruflichen Neuorientierung. Die GFN GmbH sucht dich für die Schwestergesellschaft EduTech GmbH, die Produktentwicklung der GFN.

Du hast Lust auf eine spannende Herausforderung im Bildungsbereich? Du möchtest Teil eines dynamischen Teams sein und den digitalen Wandel aktiv mitgestalten? Dann bist du bei uns genau richtig!

**Für unsere AI & Learning Design Abteilung suchen wir dich als Senior Produktmanager (m/w/x) FISI/FIAE.**

**Dein Einsatzort ist remote innerhalb von Deutschland, wir unterstützen flexible Arbeitszeitmodelle.**

## Aufgaben

- **Geförderte Bildung:** Du bringst Kenntnisse des geförderten Bildungsmarktes (SGB II, SGB III, Bildungsgutschein, AZAV) mit und hast Spaß daran Umschulungen zu gestalten, die Lernende in die Zukunft führen.

- **Produktportfolio entwickeln:** Du leistest einen Beitrag, das Umschulungsportfolio modern aufzustellen. Optimalerweise hast du ein gutes Verständnis didaktischer Konzepte, sowie moderner Lernformate.

- **Produktentwicklung steuern:** Du hast Interesse an IT-Themen, insbesondere im Umfeld der Fachinformatiker-Umschulungen und angrenzender Bildungsprodukte.

- **Zertifizierungsvorgaben erfüllen:** Du hast Verantwortung für Zertifizierungen, einschließlich der Festlegung und Weiterentwicklung von Konzepten, Lehrplänen und Materialien.

- **Schnittstellen pflegen und managen:** Du arbeitest mit vielen Schnittstellen, um die Produkte digital und offline zu gestalten und hast langjährige Erfahrung in der Entwicklung, Weiterentwicklung und Steuerung von Bildungsprodukten. Außerdem hast du schon in Projektstrukturen gearbeitet.

- **Produktschulungen abhalten:** Du bereitest Schulungen vor und erklärst Vertrieblern die Hintergründe zum Produkt und die Produkteigenschaften.

- **Weitere Kenntnisse:** Du hast einen sichereren Umgang mit MS Office; Kenntnisse in SharePoint, sowie Atlassian-Tools wie Jira und Confluence, Moodle sowie internen Verwaltungs- und Managementsystemen wie TC-Manager. KI-Kenntnisse sind von Vorteil.

- **Lernkultur fördern:** Du bist Teil eines Teams, das die Lernkultur unserer Bildungsmaßnahmen für unsere Kunden aktiv mitgestaltet und weiterentwickelt.

## Qualifikation

**Beruflicher Hintergrund:** Du hast ein Studium im Bildungsmanagement, Pädagogik, IT - Softwareentwicklung oder einschlägige Berufserfahrung im geförderten Bildungsbereich spezifisch in Umschulungen.

**Fachkenntnisse:** Du hast Erfahrung im Produktmanagement und interessierst dich für Softwareentwicklung und Systemadministration und angrenzende Bereiche.

**Methodik:** Du hast ein ausgeprägtes Interesse an Organisation, Schnittstellentätigkeit und Konzeptarbeit.

**Persönliche Fähigkeiten:**

- Du arbeitest eigenverantwortlich, strukturiert und lösungsorientiert. Außerdem zeichnet dich Kommunikationsstärke und sicheres Auftreten gegenüber unterschiedlichen Stakeholdern aus.

- Du hast Organisationsgeschick sowie Priorisierungsfähigkeit. Eine ausgeprägteanalytische und konzeptionelle Denkweise ist hilfreich.

- Dich zeichnet Durchsetzungsvermögen bei gleichzeitig hoher Team- und Kooperationsorientierung aus. Du west eine hohe Kunden- und Teilnehmerorientierung aus.

- Daneben bringst du Innovationsfreude und Offenheit für Veränderungen mit, zeigst Eigeninitiative, Verantwortungsbewusstsein und hast eine Hands-on-Mentalität.

- Resilienz und Belastbarkeit in einem dynamischen Umfeld sind von Vorteil.

- Ein gutes Set an Konfliktstrategien ist hilfreich sowie die Fähigkeit, unterschiedliche Interessen konstruktiv zusammenzuführen. Diplomatisches Geschick und Moderationskompetenz bei herausfordernden Abstimmungsprozessen sind von Vorteil.

**Sprachkenntnisse:** Du verfügst über sehr gute Deutschkenntnisse, die es dir ermöglichen, effektiv zu kommunizieren.

## Benefits

- Mobiles Arbeiten innerhalb Deutschlands

- Flexibles Arbeitszeitmodell

- 6 Wochen Urlaub im Jahr

- Mitarbeiterrabatte: attraktive Preisnachlässe bei unterschiedlichen Anbietern

- Interne & externe Weiterbildungsmöglichkeiten, festes jährliches Weiterbildungsbudget

- Jobrad

- Wellpass

- Zuschuss zum Deutschland-Ticket

- Bildschirmarbeitsplatzbrille

- Gruppenunfallversicherung

Bei uns erwartet dich ein vorurteilsfreies, wertschätzendes Miteinander. Wir leben Vielfalt – sowohl mit unseren Teilnehmer:innen als auch im GFN-Team.

Interessiert? Dann bewirb dich jetzt über unser Bewerbungsformular – inklusive

Gehaltswunsch und frühestmöglichem Startdatum. Falls du noch Fragen hast, sprich uns gerne an.

**Wir freuen uns auf dich!**

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
