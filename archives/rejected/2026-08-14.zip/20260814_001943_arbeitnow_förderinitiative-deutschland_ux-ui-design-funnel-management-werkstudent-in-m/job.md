# UX/UI Design & Funnel Management | Werkstudent*in (m/w/d)

Posted: 2026-08-13T21:30:27Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Die **Förderinitiative Deutschland** ist eine spezialisierte Unternehmensberatung mit Sitz in München. Wir unterstützen innovative Unternehmen dabei, staatliche Fördermöglichkeiten – insbesondere die Forschungszulage – erfolgreich zu nutzen.

Unser Anspruch ist es, einen traditionell komplexen Beratungsprozess so **digital, einfach und nutzerfreundlich wie möglich** zu gestalten.

Unser Büro befindet sich in der **Infanteriestraße 11 in München** – direkt neben der **Hochschule Fresenius** und der **AMD Akademie Mode & Design**.

Damit arbeitest du in einem modernen, studentischen Umfeld mit kurzen Wegen zur Hochschule und einer zentralen Lage in München.

Dafür entwickeln wir unsere Website, Landingpages, Funnels und digitalen Prozesse kontinuierlich weiter. Als Werkstudent*in im Bereich **UX/UI Design & Funnel Management** arbeitest du direkt an unserer digitalen Customer Journey und kannst deine eigenen Ideen von der Konzeption bis zur tatsächlichen Umsetzung begleiten.

## Aufgaben

-

Konzeption und Überarbeitung unserer Website, Landingpages und digitalen Funnels

-

Entwicklung neuer Seitenstrukturen, Nutzerführungen und Customer Journeys

-

Erstellung von Wireframes, Mockups und UI-Designs in Figma

-

Optimierung bestehender Seiten hinsichtlich UX, Conversion und Nutzerführung

-

Weiterentwicklung unseres visuellen Auftritts und unserer Designsysteme

-

Umsetzung und Anpassung von Seiten mit WordPress und Elementor

-

Entwicklung neuer Landingpages und Prototypen mit AI- und No-Code-Tools

-

Optimierung von Formularen, Kontaktstrecken und Conversion-Punkten

-

Analyse bestehender Funnels und Identifikation von UX- und Conversion-Potenzialen

-

Entwicklung und Umsetzung von A/B-Test-Ideen

-

Koordination von Website- und Funnel-Projekten mit internen und externen Entwicklern

-

Eigenständiges Projektmanagement für digitale Projekte

-

Einsatz moderner AI-Tools zur schnelleren Konzeption, Gestaltung und Umsetzung

## Qualifikation

-

Du bist aktuell an einer Hochschule oder Universität eingeschrieben.

-

Du hast ein gutes Auge für Design, Typografie, Struktur und Benutzerfreundlichkeit.

-

Du interessierst dich für UX/UI Design, Websites, Landingpages und digitale Funnels.

-

Du denkst nicht nur visuell, sondern möchtest verstehen, warum Nutzer klicken, abspringen oder konvertieren.

-

Idealerweise hast du bereits erste Erfahrungen mit Figma, WordPress oder Elementor gesammelt.

-

Tools wie Lovable, Perspective Funnels, Codex, Canva oder vergleichbare AI-Tools findest du spannend.

-

Du arbeitest strukturiert, selbstständig und lösungsorientiert.

-

Du kannst eigene Projekte koordinieren und behältst auch bei mehreren Aufgaben den Überblick.

-

Du sprichst fließend Deutsch und gutes Englisch.

-

Du hast Lust, Verantwortung zu übernehmen und deine eigenen Ideen tatsächlich umzusetzen.

Vorkenntnisse aus eigenen Projekten, Uni-Projekten, Websites oder Figma-Designs sind willkommen – wichtiger als ein perfekter Lebenslauf sind für uns Lernbereitschaft, Eigeninitiative und ein gutes Gespür für digitale Produkte.

## Benefits

-

**Verantwortung ab dem ersten Tag** – deine Designs und Funnel-Ideen werden tatsächlich umgesetzt**Direkter Impact** auf Websites und Funnels, die täglich von potenziellen Kunden genutzt werden

-

Enge Zusammenarbeit mit der **Geschäftsführung und dem Marketing-Team**

Kurze Entscheidungswege und flache Hierarchien

-

Junges, ambitioniertes Team im Herzen von München-Schwabing

-

Viel Freiheit für eigene Ideen, neue Technologien und moderne Tools

-

Intensive Weiterentwicklung in **UX/UI Design, Conversion Rate Optimization, Funnel Building und Projektmanagement**

-

Arbeit mit modernen **AI- und No-Code-Tools**

-

Überdurchschnittliche Vergütung

-

Modernes Büro in **München-Schwabing (dirk**

-

Snacks und Getränke im Büro

-

**Wellpass-Mitgliedschaft** für deine Work-Life-Balance

-

Perspektive auf eine langfristige Zusammenarbeit als **Werkstudent*in oder Vollzeitkraft**

Bei uns gestaltest du nicht einfach einzelne Grafiken. Du beschäftigst dich mit der Frage, wie aus einem Website-Besucher ein Interessent und aus einem Interessenten ein Kunde wird.

Von der ersten Headline über die Seitenstruktur bis zum Formular entwickelst du digitale Nutzererlebnisse, testest neue Ideen und siehst unmittelbar, welchen Einfluss deine Arbeit auf unser Wachstum hat.

Klingt nach dir? Dann möchten wir dich kennenlernen. Schick uns einfach deinen Lebenslauf, dein LinkedIn-Profil oder – falls vorhanden – ein kleines Portfolio. Auch eigene Websites, Figma-Projekte, Uni-Projekte oder persönliche Projekte sind für uns interessant.

**Wir freuen uns auf deine Bewerbung!**

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
