# Vertriebsleitung / Senior Closer - B2B Fördermittelberatung (m/w/d)

Posted: 2026-08-13T21:30:26Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Wir sind eine spezialisierte Beratung für **Fördermittel** und **Government Funding** mit Sitz in **München-Schwabing**. Wir helfen **innovativen, technologiegetriebenen mittelständischen Unternehmen**, das volle Potenzial staatlicher Förderprogramme – insbesondere der **Forschungszulage (FZulG)** – auszuschöpfen. Sie erwartet ein **zukunftssicheres Segment**, ein **überdurchschnittlich attraktives Provisionsmodell** und echter **Gestaltungsspielraum** als Führungskraft.

## Aufgaben

Als **Vertriebsleitung** (Sales Manager / Head of Sales) verantworten Sie den **Auf- und Ausbau unseres B2B-Vertriebs**. Ihre zentrale Aufgabe ist es, **Neukunden erfolgreich abzuschließen** und das **Vertriebsteam** fachlich wie strategisch zu **führen**.

- **Abschluss von qualifizierten Neukunden** aus dem innovativen Mittelstand – die **Termine werden durch unser Marketing bereitgestellt** (kein Coldcalling)

- **Fachliche und strategische Führung** sowie Weiterentwicklung des **Vertriebsteams**

- Entwicklung und Umsetzung von **Vertriebsstrategien** für die **Fördermittelberatung**

- Steuerung des gesamten **Sales-Cycles** bei beratungsintensiven **B2B-Deals im hohen sechsstelligen Bereich**

- Aufbau und Pflege **langfristiger Kundenbeziehungen** auf **Geschäftsführungs- und Entscheiderebene**

- **Coaching, Schulung und Performance-Steuerung** der Teammitglieder

- **Monitoring der Zielerreichung** sowie kontinuierliche Optimierung der Vertriebsprozesse

## Qualifikation

- Nachweisliche **Abschlusserfolge im beratungsintensiven B2B-Vertrieb**, idealerweise mit hochpreisigen oder erklärungsbedürftigen Produkten/Dienstleistungen

- Erfahrung in der **Leitung, Motivation und Entwicklung von Vertriebsteams**

- **Souveränes Auftreten** sowie ausgezeichnete **Kommunikationsstärke** auf Entscheiderebene

- Ausgeprägtes Gespür für Kundenbedürfnisse und eine **service- sowie abschlussorientierte Arbeitsweise**

- Erfahrung im **Account Management** und in der Pflege langfristiger Kundenbeziehungen

- **Analytisches Denken**, strukturiertes Vorgehen und Sicherheit im Umgang mit **CRM-Systemen**

- Relevanter Ausbildungs- oder Studienhintergrund bzw. vergleichbare Berufserfahrung

- Kenntnisse in der **Fördermittelberatung** oder **Forschungszulage (FZulG)** von Vorteil

## Benefits

- **Überdurchschnittlich attraktives, leistungsabhängiges Provisionsmodell**

- **Firmenfahrzeug** sowie weitere attraktive **Incentives**

- **Warme, vom Marketing bereitgestellte Termine** – kein Coldcalling

- Verantwortungsvolle **Führungsposition** mit großem **Gestaltungsspielraum**

- **Zukunftssicheres Beratungssegment** mit hohem Marktpotenzial

- Moderner Arbeitsplatz im Herzen von **München-Schwabing**

Sie wollen **große Deals abschließen** und ein **Team in einem wachsenden Markt führen** – ohne Kaltakquise, mit vorqualifizierten Terminen? Dann freuen wir uns auf Ihre Bewerbung, idealerweise mit Angabe Ihres frühestmöglichen Eintrittstermins und Ihrer Gehaltsvorstellung.

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
