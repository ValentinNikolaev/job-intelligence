# IT Operations Administrator (f/m/d)

Posted: 2026-08-13T20:40:20Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

## **About Focused Energy**

Focused Energy is a pioneering international deep-tech company with locations in Germany and the US, dedicated to commercializing laser-driven nuclear fusion. Our mission is to deliver clean, safe, and virtually limitless energy to the world. As we rapidly scale, we seek talented individuals who thrive on bringing clarity and structure to fast-growing environments.

Join us as a IT Operations Administrator to help shape the future of clean energy. In this role, you will own the systems, processes, and enablement that keep our IT environment secure, scalable, and consistent. You will ensure platforms are configured correctly, access is managed accurately, operational processes are followed, and employees are trained and confident in using the tools they need to succeed.

## **About the Role**

As Focused Energy grows across multiple sites, the IT Operations Administrator will own the systems and processes that support reliable day-to-day IT delivery globally. You’ll administer SaaS platforms, manage user access and licences, maintain clear IT processes, and enable employees to use their tools confidently. This is a systems and process ownership role not a traditional helpdesk position and works closely with the IT Operations Manager, IT Support Specialist, and People Operations.

## What You’ll Do

-

Own SaaS platform administration across all Focused Energy sites, including user accounts, licences, access rights, and approved access changes.

-

Execute IT processes consistently, identify process gaps, and keep documentation accurate and current.

-

Design and deliver user training that helps employees use core IT tools confidently and reduces tool-related support needs.

-

Coordinate onboarding and offboarding IT activities with People Operations, ensuring new starters have the required access on day one and leavers are fully deprovisioned on time.

-

Build and maintain an accessible library of IT process documentation, user guides, and self-service resources.

-

Conduct regular licence audits, identify unused licences, and flag cost or access anomalies to the IT Operations Manager.

-

Partner with the IT Operations Manager and IT Support Specialist on access reviews, cross-site coordination, and IT improvement initiatives.

-

Apply IT processes and standards consistently across locations while responding effectively to the needs of a technically diverse, globally distributed workforce.

## Who You Are

-

You work independently within established processes and proactively identify routine work that needs to be done.

-

You are highly organised and reliable, with strong attention to detail in account provisioning, access changes, licence management, and audit activities.

-

You communicate clearly with both technical and non-technical colleagues and keep stakeholders informed without over-escalating.

-

You take ownership of tasks from start to finish, flag blockers early, and learn from errors by documenting and preventing recurrence.

-

You can adapt your communication and training style to support employees across different locations, teams, and levels of technical confidence.

-

You are comfortable making day-to-day decisions within approved frameworks and know when an issue requires escalation.

-

You collaborate effectively with IT, People Operations, SaaS vendors, and employees across the organisation.

## Desirable Skills & Knowledge

-

Experience administering SaaS platforms, including user accounts, licences, permissions, and access controls.

-

Practical knowledge of identity and access management, SSO tooling, access reviews, and account provisioning and revocation.

-

Familiarity with productivity and collaboration tools such as Google Workspace or Microsoft 365, Slack, Jira, Confluence, and Box.

-

Experience with ticketing systems, MDM platforms, or comparable IT administration tools.

-

Strong IT process documentation skills, with the ability to create clear guides for non-technical users.

-

Experience designing or delivering user training and enablement programmes.

-

Understanding of ITIL-aligned service management principles, GDPR requirements relevant to IT operations, and core IT security standards.

-

Business fluent in both English and German (written and verbal).

Focused Energy is an equal opportunity employer committed to creating an inclusive environment. Qualified applicants will receive consideration for employment without regard to race, color, religion, sex, sexual orientation, gender perception or identity, national origin, age, marital status, protected veteran status, or disability status.

Pursuant to the San Francisco Fair Chance Ordinance, Focused Energy will consider for employment qualified applicants with arrest and conviction records.

Compensation offered will be determined by factors such as location, level, job-related knowledge, skills, and experience. Certain roles may be eligible for incentive compensation, equity, benefits.

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
