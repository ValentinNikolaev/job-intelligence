# Operations & Automation Engineer – Renewable Energy

Posted: 2026-08-13T20:40:07Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

# **Operations & Automation Engineer – Renewable Supply**

Festanstellung, Vollzeit · Berlin (HQ)

**Unsere Mission für dich**

Gestalte mit uns die nachhaltige Energieversorgung von morgen – und baue als Operations & Automation Engineer skalierbare Prozesse und Automatisierungslösungen auf, die trawa beim Wachstum unterstützen. trawa baut Europas führende B2B-Plattform für saubere Energie. Wir kombinieren Energiebelieferung, fortschrittliche Energiemanagement-Software und intelligente Optimierung von Verbrauch und Flexibilitäten, damit Unternehmen in einem volatilen Energiemarkt erfolgreich bleiben und ihre Dekarbonisierung beschleunigen.

Als Operations & Automation Engineer startest du im Customer Support – nicht weil Support deine Endstation ist, sondern weil direkter Kundenkontakt der beste Weg ist, zu verstehen, wo Automatisierung den größten Unterschied macht. Du entwickelst unseren KI-gestützten Ticket-Copilot weiter, baust die dafür nötige Tooling-Landschaft auf und erweiterst deinen Wirkungskreis Schritt für Schritt auf den gesamten Ops-Bereich. Dein Ziel: manuelle und wiederkehrende Aufgaben zu reduzieren und trawa dadurch effizienter, schneller und skalierbarer zu machen.

**Als Operations & Automation Engineer übernimmst du folgende Aufgaben:**

-

**Weiterentwicklung des Customer Support-Agenten:** Du bist Owner unseres KI-gestützten Ticket-Copilots – von der Anforderungsdefinition über die technische Weiterentwicklung bis zur Integration in unsere Tooling-Landschaft (Velaris, Airtable, HubSpot). Du treibst die Automatisierung von Ticket-Assignment, Lösungsvorschlägen und Kundenkommunikation aktiv voran.

-

**Customer Support als Lernvehikel:** Du bearbeitest selbst eingehende Kundenanfragen – per Telefon und E-Mail – um ein tiefes Verständnis für wiederkehrende Probleme, Edge Cases und Prozesslücken zu entwickeln. Dieses Wissen fließt direkt in die Weiterentwicklung des Agenten und der Knowledge Base ein.

-

**Ownership der Tooling-Landschaft:** Du evaluierst, implementierst und entwickelst die Tools weiter, die unser Ops-Team braucht – von dedizierten Ticketing-Systemen bis hin zu Automatisierungsplattformen. Du erkennst, wo aktuelle Tools an ihre Grenzen stoßen, und treibst die Einführung von Alternativen voran.

-

**Automatisierung im gesamten Ops-Bereich:** Customer Support ist der Anfang. Gemeinsam mit angrenzenden Teams – Finance, Onboarding, Customer Success – identifizierst du weitere Automatisierungspotenziale, entwickelst Lösungen und baust so Schritt für Schritt eine zentrale Automatisierungskapabilität bei trawa auf.

-

**Stakeholder Management & kontinuierliche Iteration:** Du arbeitest eng mit internen Teams zusammen, holst Feedback ein, priorisierst Anforderungen und sorgst dafür, dass Automatisierungslösungen nicht nur gebaut, sondern auch genutzt und stetig verbessert werden.

**Das Team**

Du wirst Teil unseres Business Operations Teams – mit Funktionen wie Onboarding, Customer Support und Customer Success darunter. Gemeinsam arbeiten wir daran, Prozesse im gesamten Ops-Bereich effizienter zu machen und Automatisierung dort einzusetzen, wo sie den größten Unterschied macht. Du gestaltest diesen Weg aktiv mit – als Querschnittsfunktion, die nah an den Problemen ist und pragmatische Lösungen entwickelt.

**Nach wem wir suchen:**

-

**Frisch von der Uni oder mit erster relevanter Erfahrung** – wichtiger als Berufserfahrung ist ein ausgeprägtes technisches Verständnis und der Antrieb, Dinge selbst in die Hand zu nehmen

-

**Technologieaffinität auf einem anderen Level:** Du hast bereits mit Automatisierungstools, APIs, KI-Agenten oder ähnlichem gearbeitet – oder brennst darauf, es zu tun

-

**Ausgeprägte Eigenverantwortung und Gründlichkeit:** Du verlierst keine Aufgabe aus den Augen, priorisierst souverän und lieferst zuverlässig

-

**Starkes Prozessverständnis:** Du erkennst schnell, wo manuelle Arbeit durch Automatisierung ersetzt werden kann, und weißt, wie du das strukturiert umsetzt

-

**Exzellente kommunikative Fähigkeiten und hands-on Mentalität:** Du gehst professionell und lösungsorientiert auf Kund:innen sowie interne Teams ein und packst Probleme selbst an

-

**Einfallsreichtum und Eigeninitiative:** Wenn du eine Lösung nicht kennst, findest du sie – durch Research, Experimentieren oder den direkten Austausch mit Kolleg:innen

-

**Interesse am komplexen Energiemarkt** und Bereitschaft, dich in die Welt der erneuerbaren Energien einzuarbeiten

-

Deutsch auf Muttersprachlerniveau sowie fließendes Englisch

**Deine ersten 90 Tage:**

-

**Monat 1:** Du tauchst in trawas Ops-Welt ein – Produkte, Prozesse, Tools und Kundenkontakt. Du bearbeitest erste eigene Kundenanfragen, um ein echtes Verständnis für wiederkehrende Probleme und Prozesslücken zu entwickeln. Gleichzeitig machst du dich mit dem bestehenden Customer Support-Agenten vertraut und verstehst, wo er heute an seine Grenzen stößt.

-

**Monat 2:** Du übernimmst die Ownership des Customer Support-Agenten und bringst erste konkrete Verbesserungen ein – in der Knowledge Base, im Automatisierungsgrad und in der Tool-Integration. Du evaluierst, ob die aktuelle Tooling-Landschaft die Zielversion des Agenten unterstützen kann, und entwickelst einen klaren Fahrplan für die nächsten Schritte.

-

**Monat 3 und danach:** Du verantwortest die Weiterentwicklung des Agenten end-to-end und hast erste Automatisierungen live gebracht, die dem Team messbar Zeit sparen. Du blickst über den Customer Support hinaus, identifizierst die nächsten Automatisierungspotenziale im Ops-Bereich und beginnst, trawa's Automatisierungskapabilität systematisch aufzubauen.

**Warum wir?**

-

**Dein Impact:** Du treibst bei trawa aktiv voran, wie wir Prozesse automatisieren und den gesamten Ops-Bereich effizienter machen – eine zentrale Voraussetzung dafür, dass trawa skalieren kann. Dein Beitrag ist direkt spür- und messbar.

-

**Office First Kultur:** Unser schönes Office in Berlin Mitte ist das Herz unserer Zusammenarbeit. Wir leben eine Kultur, in der wir als Team vor Ort wirken, voneinander lernen und Geschwindigkeit aufnehmen – das ist uns sehr wichtig. Mit flexiblen Arbeitszeiten im Rahmen unserer Office-First-Kultur und 30 Urlaubstagen unterstützen wir dich – ob für Familie, persönliche Projekte oder Erholung.

-

**Attraktive Benefits:** Neben einem wettbewerbsfähigen Gehalt erhältst du Essensgutscheine, steuerfreie Extras und eine Urban Sports-Mitgliedschaft.

-

**Persönliche Entwicklung:** Arbeite mit modernen Tools und lerne von Branchenexpert:innen. Wir bieten dir Weiterbildungstage, ein jährliches L&D-Budget und Coaching-Sessions über Sparrks.

-

**Vielfalt & Inklusion:** Bei uns sind alle willkommen – wir engagieren uns für einen integrativen Arbeitsplatz, der Vielfalt wertschätzt durch Angebote wie Mitarbeiter:innen- und Diversity-Netzwerke. Daher ermutigen wir Menschen unterschiedlichen Geschlechts, Alters, sexueller Orientierung, ethnischer Zugehörigkeit und körperlicher oder neurodiverser Vielfalt zur Bewerbung.

**Bereit zu gestalten?**

Wenn du operativ stark bist, technisch denkst und gerne Verantwortung übernimmst, dann bewirb dich jetzt! Auch wenn du nicht alle Anforderungen zu 100 % erfüllst: Wir sind offen für Persönlichkeiten mit Potenzial und Leidenschaft.

**Über uns**

Willkommen im trawa-Universum! Wir haben es uns zur Aufgabe gemacht, das grüne Versorgungsunternehmen der Zukunft von Grund auf aufzubauen. Wie machen wir das? Wir schaffen einen direkten Zugang zu erneuerbarer Energie für B2B-Industrieunternehmen. Wir entwickeln Software und Technologie, um die Volatilität des Energiemarktes zu bewältigen. Wir professionalisieren die Energiebeschaffung auf der Käuferseite.

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
