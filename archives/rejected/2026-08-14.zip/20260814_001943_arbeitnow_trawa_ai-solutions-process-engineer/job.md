# AI Solutions & Process Engineer

Posted: 2026-08-13T20:40:07Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

# AI Solutions & Process Engineer

Festanstellung, Vollzeit · Berlin (HQ)

## Deine Mission

Die Energiekosten in Europa sind doppelt so hoch wie in den USA und China. Gleichzeitig wird sich die Stromnachfrage bis 2050 voraussichtlich verdoppeln. Marktpreisvolatilität und zunehmende Komplexität werden uns erhalten bleiben. Damit steht das Rückgrat der europäischen Industrie unter Druck – und Unternehmen müssen jetzt handeln.

trawa entwickelt die Lösung: die erste integrierte B2B-Energieplattform, die Energiebeschaffung, Energiemanagement und die Steuerung von Flexibilitäten in einem Produkt vereint. **Supply, Manage, Flex – kombiniert.** Diese Integration ermöglicht Einsparungen von bis zu 30 % bei den wiederkehrenden Stromkosten und unterstützt Unternehmen gleichzeitig dabei, auf erneuerbare Energien umzusteigen.

Wir sind Europas am schnellsten wachsende B2B-Energieplattform. Aktuell sind wir in Deutschland und Österreich aktiv und planen, unsere Aktivitäten 2027 auf einen dritten Markt auszuweiten. Unser Ziel ist die europaweite Skalierung. Wir bewegen uns schnell – das Marktfenster ist offen, und wir wollen es nutzen.

## Über trawa

trawa ist ein Scale-up mit Sitz in Berlin und rund 100 Mitarbeitenden, davon etwa 30 in Product & Tech. Bis heute haben wir mehr als 35 Millionen Euro eingesammelt, darunter eine Series-A-Finanzierungsrunde über 24 Millionen Euro im Mai 2025. Zu unseren Investoren zählen Balderton, Headline, Speedinvest, AENU, Magnetic und Tiny VC. Alle drei Gründer sind weiterhin aktiv dabei und zu 100 % committed, das Energieversorgungsunternehmen der Zukunft aufzubauen.

Wir suchen eine:n **AI Solutions & Process Engineer**, um gemeinsam die nächste Wachstumsstufe zu erreichen. Du berichtest direkt an unseren General Manager Energy Solutions und arbeitest eng mit unseren Tech- & Commercial-Teams zusammen. Du gestaltest das Produkt mit, das die europäische Industrie wieder wettbewerbsfähiger macht – und setzt deine Ideen mit hohem Tempo um.

Die Position ist in Berlin angesiedelt. trawa ist ein **Office-First-Unternehmen**: In der Regel arbeitest du an fünf Tagen pro Woche aus unserem Büro.

## Wen wir suchen

-

**Digital Experience:** Du entwickelst sowohl customer-facing als auch interne Tools entlang der User Journey, die uns im europäischem Energiemarkt einen strukturellen Wettbewerbsvorteil verschaffen. Dabei eliminierst du Friction, erhöhst Conversion Rates und schaffst so die Grundlage für skalierbares Wachstum.

-

**Scalability:** Du verantwortest die übergreifende Prozessarchitektur inkl. Datenmodell des Revenue-Prozesses, identifizierst gemeinsam mit den betroffenen Teams kontinuierlich Optimierungspotenzial und steigerst durch Automatisierung nachhaltig die Effizienz unserer Prozesse.

-

**Growth Engine:** Du vereinst unsere interne Prozessarchitektur mit der digitalen Experience und schaffst so eine Growth Engine, die nachhaltiges, planbares und skalierbares Wachstum für trawa schafft.

-

**User Journey:** Du hast die Journey unserer Kunden und die dahinterliegenden Prozesse ganzheitlich im Blick – vom Erstkontakt mit einem Lead bis zum erfolgreichen Start einer Kundenbeziehung - gleichermaßen aus Kundenperspektive wie auch aus interner Sicht rund um operative Skalierbarkeit.

-

**AI Craftsmanship:** Du nutzt state-of-the art AI Lösungen in deiner täglichen Arbeit und baust so AI-native Lösungen, die trawa als Vorreiter im Energiemarkt rund um den Einsatz von AI positionieren.

## Deine Ziele in den ersten 90 Tagen

-

Du hast das notwendige Verständnis zu unseren Produkten, zum Energiemarkt, zur Journey unserer Kunden sowie zu relevanten internen Prozessen aufgebaut.

-

Du hast dich als fester Ansprechpartner rund um unsere Growth Engine etabliert - und bist im stetigen Austausch mit allen wichtigen internen Stakeholdern dazu.

-

Du hast eine Strategie für die Weiterentwicklung des Bereichs bei trawa entwickelt, klare Prioritäten gesetzt und eine Roadmap mit klaren Verantwortlichkeiten und Meilensteinen aufgesetzt, die unser weiteres Wachstum in Deutschland und die Expansion unterstützt.

-

Du hast dabei insbesondere erste Optimierungsprojekte zur Steigerung der Conversion Rates sowie zur internen Prozessoptimierung angestoßen - und erste Ergebnisse sind in Sicht.

## Was dir zum Erfolg verhilft

-

Du kannst technische Lösungen nicht nur mit Low-Code oder Vibe-Coding Ansätzen umsetzen, sondern bist auch in der Lage, robusten Code zu entwickeln.

-

Du verbindest technisches Denken mit Nutzerverständnis. Mithilfe qualitativer und quantitativer Research-Methoden identifizierst du Pain Points, validierst Hypothesen und leitest daraus Lösungen mit echtem Mehrwert für die User ab.

-

Du gehst Aufgaben mit Eigeninitiative und klarer Zielorientierung an.

-

Du denkst analytisch und strukturiert: Komplexe Prozesse zerlegst du gerne in einzelne Schritte, erkennst Optimierungspotenziale und triffst Entscheidungen auf Basis von Zahlen und Metriken.

-

Du berücksichtigst bei deiner Entscheidungsfindung auch strategische Ziele und kannst dich sowohl in die Perspektive von Kunden als auch von unserem Vertrieb hineinversetzen.

-

Du bist am Puls der Zeit rund um AI: Du verfolgst aktuelle AI-Trends, testest neue Tools und entwickelst deine Expertise stetig weiter.

-

Du überzeugst durch starke Kommunikationsfähigkeiten und eine kooperative Arbeitsweise. Der Austausch mit internen Stakeholdern fällt dir ebenso leicht wie die professionelle Kommunikation mit Kund:innen und externen Ansprechpartner.

-

Erfahrung in der Energiewirtschaft ist ein Plus, aber kein Muss.

## Warum trawa?

**Wirkung:** Europäische KMU geben jährlich zwischen 150.000 und 10 Millionen Euro für Strom aus – viele davon zahlen zu viel und sind an veraltete Beschaffungsmodelle gebunden. Mit unserem Produkt veränderst du unmittelbar, wie Tausende Unternehmen Energie einkaufen, managen und nutzen. Die Wirkung ist messbar, der Markt ist riesig und der Zeitpunkt ist jetzt.

**Verantwortung:** Bei uns übernimmst du Verantwortung für deine Themen und treibst Ergebnisse voran – unabhängig von deinem Hintergrund oder deiner bisherigen Berufserfahrung.

**Lernen und Entwicklung:** Wir stellen dir ein jährliches Weiterbildungsbudget und feste Zeit für deine persönliche und fachliche Entwicklung zur Verfügung. Dich erwarten Mentoring, vielfältige Lernmöglichkeiten und echte Perspektiven für deinen nächsten Karriereschritt.

**Vielfalt und Inklusion:** Wir sind ein Arbeitgeber, der Chancengleichheit lebt, und unser Team spiegelt das wider. Menschen aus mehr als 15 Nationen bringen unterschiedliche Sprachen, Erfahrungen und Perspektiven zusammen. Bei trawa ist Familienfreundlichkeit auf allen Ebenen selbstverständlich – in unserem Team und in der Führung arbeiten Eltern. Wir setzen uns für ein inklusives Umfeld ein, in dem alle ihr Bestes geben können.

**Vergütung und Benefits:** Wir bieten ein wettbewerbsfähiges Vergütungspaket mit Gehalt und Stock Options, 30 Urlaubstagen sowie zahlreichen Benefits. Dazu gehören Zuschüsse für Internet und Mittagessen, eine Mitgliedschaft im Sport Club, feste Lerntage mit jährlichem Weiterbildungsbudget, ein wöchentliches Team-Mittagessen und regelmäßige Teamevents.

Bei trawa bauen wir einen vielfältigen, inklusiven und authentischen Arbeitsplatz auf. Wenn dich die Position begeistert, dein bisheriger Weg aber nicht in allen Punkten dem Anforderungsprofil entspricht, freuen wir uns trotzdem über deine Bewerbung. Vielleicht bist du genau die richtige Person für diese oder eine andere Position bei uns.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
