# Head of Customer - DACH

Posted: 2026-08-13T17:40:10Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**About Us**

Hawk is the leading provider of AI-supported anti-money laundering and fraud detection technology. Banks and payment providers globally are using Hawk’s powerful combination of traditional rules and explainable AI to improve the effectiveness of their AML compliance and fraud prevention by identifying more crime while maximizing efficiency by reducing false positives. With our solution, we are playing a vital role in the global fight against Money Laundering, Fraud, or the financing of terrorism. We offer a culture of mutual trust, support and passion – while providing individuals with opportunities to grow professionally and make a difference in the world.

## Your Mission

As Head of Customer for DACH at Hawk, you own everything that happens with our customers in your territory: the outcomes (GRR, NRR), the operating model that makes delivery repeatable, and the people who run it. You lead a regional team of Customer Value Partners, Data Scientists, and Implementation Consultants, and you sit between the Chief Customer Officer and the front line. This isn't a role where the playbook already exists and you just execute it, but it's also not a role where you build your own version in isolation. Much of the operational discipline, the services products, systems, and tools that make execution scalable, is still being built globally, and you're a core contributor to that single, globally deployable model, not the architect of a regional one. You carry the region's commercial outcomes, you carry escalations personally when they matter, and you help build the machine that gets deployed everywhere, starting here.

## Key Responsibilities

-

Own the regional commercial outcome: drive GRR and NRR across your portfolio of Customer Value Partner-managed accounts, and report on it with the same rigor you'd expect from your own team.

-

Contribute to Hawk's customer operating model, the delivery methodology, systems, and tools that make outcomes repeatable at scale, and roll it out in your region rather than building a parallel version of your own. You've seen what good looks like elsewhere and bring that judgment to a global effort, including coaching your Customer Value Partners as the model takes shape.

-

Lead and grow a cross-functional regional team, Customer Value Partners, Data Scientists, and Implementation Consultants, hiring, onboarding, and developing people as the region scales.

-

Be the last line of defense on escalations. When an account is genuinely at risk, you're the one on the governance call working the problem, not reading about it after the fact.

-

Partner with Sales as a credibility engine for the region: get pulled into pre-sale conversations, help scope engagements, and make sure what gets sold is something your team can actually deliver.

-

Run regular business reviews with Sales and company leadership covering forecasting, account health, and where the region's growth is actually coming from.

-

Work with your peer Heads of Customer and the functions that own the global model to keep your region aligned: feed regional learnings back in, adopt changes as they roll out, and flag where local market realities genuinely require an exception rather than a workaround.

-

Own people development across the region: performance reviews, career planning, and skills coverage across the CVP, Data Science, and Implementation Consultant roles, so the region is never one departure away from a delivery gap.

-

Represent the region in leadership conversations, giving the CCO and the rest of the leadership team an honest, evidence-based read on regional health, risk, and opportunity.

## Your Profile

-

10+ years leading and managing professional services or delivery organizations within B2B enterprise software. This means you've actually run a PS team, owned utilization, staffing, and delivery quality across a book of engagements, not just managed customer success or account relationships.

-

A genuine builder who plays well with a global standard. You've contributed to or helped roll out a services operating model across multiple markets before, delivery methodology, tooling, staffing model, and you understand the difference between adapting a global model locally and quietly building your own. You can point to what you contributed and why it worked.

-

A track record of owning a commercial number, GRR, NRR, revenue, or bookings, and hitting it, not just influencing it from the side.

-

Real experience managing a team through escalations. You've been the person on the call when an account was genuinely at risk, not just the person who heard about it afterward.

-

Comfortable with SaaS and services financial metrics (GRR, NRR, utilization) and can read a regional forecast without someone translating it for you.

-

Strong hiring instincts. You've built or scaled a team before, and you know the difference between a candidate who interviews well and one who'll actually do

-

the job.

-

Genuine comfort operating at C-suite level, with customers and with internal stakeholders alike.

-

Strong grasp of SaaS and enterprise software delivery models; experience in AML, fraud prevention, or another regulated financial services domain is a real advantage, not a nice-to-have footnote.

-

Fluent in German, in addition to fluent English.

## Bonus

-

Experience leading a team spanning multiple functions (delivery, data science, technical implementation) rather than a single-discipline team.

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
