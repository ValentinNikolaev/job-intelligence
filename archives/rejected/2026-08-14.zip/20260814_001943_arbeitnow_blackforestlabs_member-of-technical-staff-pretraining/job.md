# Member of Technical Staff - Pretraining

Posted: 2026-08-13T17:55:33Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

## **About Black Forest Labs**

We're the team behind Latent Diffusion, Stable Diffusion, and FLUX — foundational technologies that changed how the world creates images and video. Our models power the tools used by millions of creators, developers, and businesses worldwide, and FLUX is among the most advanced generative systems in the world.

Headquartered in Freiburg, Germany with a growing presence in San Francisco, we're scaling fast while staying true to what makes us different: research excellence, open science, and building technology that expands human creativity.

## **Why This Role**

We're building the foundation models that power the next wave of visual intelligence — and pretraining is where that work begins. This role sits at the center of our research effort. You'll shape training objectives, architectures, data strategies, and systems behind our joint image, video, and audio foundation models, with a direct line from your research to products used by millions.

This is a Staff / Senior IC role. We're looking for someone who has already led pretraining at the frontier and wants to do it again.

## **What You'll Work On**

- Lead large-scale pretraining experiments for our multimodal (image, video, audio) foundation models (architecture, objective functions, scaling strategies)

- Develop and evaluate novel ideas across architecture, optimizers, and training algorithms.

- Contribute across the full stack: low-level GPU and systems optimizations, research code, and high-level model design

- Lead focused research projects independently and drive larger cross-team initiatives

## **What We're Looking For**

- You've led or co-owned pretraining for a foundation model (image, video, LLM, or multimodal) that shipped to production or a major release

- Own architectural calls that move the model: attention patterns, modulation schemes, loss formulations, tokenization strategies

- Deep experience with large-scale distributed training: FSDP/TP/PP, multi-node runs at 500+ GPUs, debugging loss spikes, NaNs, throughput regressions, and silent correctness issues at scale

- Strong intuition for architecture and objective design — you've made calls on attention patterns, modulation schemes, or loss formulations that moved a real model

- Track record of shipping: top-venue publications (NeurIPS, ICML, ICLR, CVPR, ICCV, ECCV) paired with production impact, or unambiguous production wins at a frontier lab

- Deep Python and PyTorch proficiency; comfortable reading and modifying low-level training code

- Familiarity with visual generative models is a must

## **How We Work Together**

We’re a distributed team with real offices that people actually use. Depending on your role, you’ll either join us in Freiburg or SF at least 2 days a week (or one full week every other week), or work remotely with a monthly in-person week to stay connected. We’ll cover reasonable travel costs to make this possible. We think in-person time matters, and we’ve structured things to make it accessible to all. We’ll discuss what this will look like for the role during our interview process.

**Everything we do is grounded in four values:**

- **Obsessed.** We are a frontier research lab. The science has to be right, the understanding deep, the product beautiful.

- **Low Ego.** The work speaks. The best idea wins, no matter who said it. Credit is shared. Nobody is above any task.

- **Bold.** We take the ambitious bet. We ship, we do not wait for conditions to be perfect.

- **Kind.** People over politics. We treat each other with genuine warmth. Agency without empathy creates chaos.

If this sounds like work you’d enjoy, we’d love to hear from you.

**Base Annual Salary:**

**EU** €130,000-€340,000 + Equity

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
