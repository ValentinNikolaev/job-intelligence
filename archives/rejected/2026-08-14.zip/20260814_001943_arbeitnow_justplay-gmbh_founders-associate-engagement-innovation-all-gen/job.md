# Founders Associate - Engagement Innovation (all genders)

Posted: 2026-08-13T20:40:18Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

JustPlay is looking for an experienced and business-oriented **Founders Associate - Engagement Innovation** to help us make JustPlay app ecosystem dramatically more fun, exciting and engaging.

You'll work directly with our founders across every product team, constantly looking for ideas that make users want to click, play, win, explore and come back.

We're not looking for someone to manage roadmaps or introduce more product processes. We're looking for someone with exceptional consumer instincts, extremely high agency and an obsession with the mechanics behind the world's most engaging B2C products.

You should be the kind of person who opens an app like TikTok, Temu, MONOPOLY GO!, Duolingo or Whatnot and immediately starts dissecting why it works and how those ideas could be applied somewhere completely different.

Some of your ideas may become major features. Others might be a different CTA, a more exciting reward reveal, a new event, better framing of a prize, or an experiment we can ship next week.

We care much more about the impact of an idea than its complexity.

## **Job Responsibilities**

-

Work directly with the founders as a thinking partner on what makes JustPlay exciting to play

-

Embed across product teams to find opportunities — not to run them

-

Maintain a constant flow of ideas, from single-line copy changes to entirely new mechanics

-

Tear down the world's most engaging consumer apps and translate what works there into what could work here

-

Turn ideas into things people can act on: a sharp one-pager, a mock, a test plan — whatever gets it moving fastest

-

Push ideas through to launch by making yourself useful to the teams shipping them

-

Measure what happens, tell the truth about it, and scale or kill accordingly

-

Build our collective instinct for engagement, so the whole company gets better at this over time

## **Job Requirements**

-

Exceptional consumer instincts: you can tell why something is fun or addictive, not just that it is

-

Extremely high agency: you find the problem, propose the answer, and chase it until it's live, without being assigned it

-

A genuine obsession with engagement mechanics in top B2C products such as games, social, commerce, or education

-

Evidence that your ideas have shipped and moved a number, however small the idea was

-

Fluency with data: you can read an experiment result honestly, including when it kills your favourite idea

-

You write and speak clearly enough to sell an idea to a founder and an engineer in the same afternoon

-

Comfortable being the newest voice in a room of people who know the product better than you and disagreeing anyway

-

You communicate fluently in English, both written and spoken

**Nice to Have**

-

Casual, hyper-casual, or rewarded mobile gaming experience

-

Background in LiveOps: events, seasons, progression, economies, or meta design

-

Hands-on experimentation experience: you've designed and read A/B tests

-

Enough technical or design literacy to mock something up yourself rather than describe it

-

Familiarity with loyalty and rewards mechanics, or the mobile advertising landscape

## **Job benefits**

-

**Work-Life Balance and Flexibility**: Flexible working hours and options for digital nomads, occasional office visitors, or regular office-goers

-

**Mental Health Support**: Free personal coaching through our partner[ nilo.health](http://nilo.health) to support our team members to live fulfilled lives at home and at work

-

**Training & Development**: A competitive personal development budget of up to 2000€/year for training, conferences, workshops, etc.

-

**Germany-Based Benefits**: 25 vacation days, free[ Wellhub](https://wellhub.com/de-de/) gold subscription, free monthly Deutschland-Ticket, and a monthly €50 tax-free internet contribution

-

**State-of-the-Art Equipment**: Doesn’t matter if you are a MacBook or Windows user; we will provide you with the technical gear you need to succeed

-

**A Relocation Package**: Includes visa support for those who need it

-

**Berlin Office Perks**: Ergonomic setup, free daily lunch, and a dog-friendly environment.

-

**Engaging and Diverse Work Environment:** Join a diverse team, with over 30 nationalities working from over 25 different locations

** Benefits may vary depending on location and contract type. Do not hesitate to ask us about more details on our benefits offer.*

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
