# Communication and Engagement Working Student

Posted: 2026-08-13T17:09:28Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
