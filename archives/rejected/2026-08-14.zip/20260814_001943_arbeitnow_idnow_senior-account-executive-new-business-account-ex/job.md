# Senior Account Executive - New Business & Account Expansion (f/m/d) - DACH (Berlin oder München)

Posted: 2026-08-13T17:55:33Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

IDnow is a** leader in digital identity and fraud prevention in Europe** with a mission to transform trust into the most powerful asset in the digital world, empowering enterprises with **AI-driven, SaaS-based identity solutions that deliver scalable security, adaptive compliance, and real-time fraud prevention**.** **Through its broad portfolio of digital identity and fraud prevention solutions, IDnow establishes, maintains and enriches trust throughout the customer journey, ensuring businesses can confidently and securely operate while leveraging digital identity to drive growth, security and scalability.

The company has **offices in Germany, United Kingdom, Romania and France**, and is backed by renowned institutional investors, including Corsair Capital and Seventure Partners. Its **portfolio of international clients spans a wide range of end markets** including financial services, telecommunications, travel & mobility, gaming, and other industries.

**This position is based in Berlin or Munich, Germany.**

**Wer wir sind und warum du uns kennen solltest**

IDnow ist mehr als ein Technologieanbieter. Wir sind ein Unternehmen, das **digitale Identität neu denkt** und Vertrauen zu einer echten Währung macht. Unsere Lösungen unterstützen täglich Unternehmen verschiedenster Branchen von Finanzdienstleistern und Telekommunikation über Mobilität und E-Commerce, bis hin zu vielen weiteren Industrien dabei, sichere, nahtlose und benutzerfreundliche digitale Erfahrungen zu ermöglichen.

Unsere Mission: **Wir gestalten eine Zukunft, in der Vertrauen im digitalen Raum genauso selbstverständlich ist wie in der realen Welt.****
**Dafür suchen wir Menschen wie dich: strategisch denkend, neugierig, ambitioniert und mit echter Leidenschaft für Business Impact.

**Du erkennst Chancen/Potenziale/Möglichkeiten, die anderen noch verborgen sind **

In dieser Rolle bist du nicht einfach Verkäufer:in - du bist **Architekt:in für Wachstum**.

Du bringst unsere Lösungen zu führenden Unternehmen, die täglich Millionen Kund:innen bedienen.
Du verbindest Technologie, Business Value und Branchen-Know-how zu einer Story, die Entscheider:innen überzeugt.
Und du verwandelst komplexe Prozesse in klare, skalierbare Deals.

**Was du bewegst**

- Du entwickelst und implementierst eigenständig Go-to-Market-Strategien für neue Geschäftsfelder und Zielbranchen.

- Du baust und pflegst einen hochwertigen Sales-Funnel — von Lead- Qualifizierung bis zum Deal Closing - und übertriffst regelmäßig Umsatz- und Wachstumsziele.

- Du identifizierst Cross- & Upselling-Potenziale bei Bestandskunden und entwickelst diese systematisch weiter.

- Du baust vertrauensvolle Beziehungen zu Entscheidungsträger:innen auf, auch auf C-Level und positionierst IDnow als Trusted Advisor.

- Du verantwortest den kompletten Sales-Cycle: Leadgenerierung, Verhandlung, Vertragsabschluss und Übergabe an Implementation/Onboarding.

- Du beobachtest Markt und Konkurrenz, leitest daraus Chancen ab und bringst neue Impulse für unser Business Development ein.

- Du arbeitest funktionsübergreifend mit Marketing, Produktmangamenet, Customer Success und Legal zusammen, um kundenzentrierte Lösungen zu schaffen.

**Dein Profil**

- Du verfügst über 5–7 Jahre Erfahrung im B2B-Vertrieb, **insbesondere** in der Neukundenakquise und Account Expansion - idealerweise im SaaS- oder Tech-Umfeld

- Du hast umfassende Erfahrung mit komplexen Verkaufszyklen sowie mit Enterprise-Deals und Vertragsverhandlungen.

- Du bist mit Sales-Methodologien wie MEDDPIC bestens vertraut und setzt sie sicher in der Praxis ein.

- Du verstehst den Markt für Identitätsverifikation oder ähnliche Compliance/Trust-Themen, Branchenwissen (z. B. FinTech, Telekom, E-Commerce) ist ein Plus.

- Du arbeitest selbstständig, strukturiert und ergebnisorientiert; der Umgang mit CRM-Systemen ist für dich Alltag (z. B. Salesforce)

- Du sprichst fließend Deutsch und Englisch; weitere europäische Sprachen sind willkommen.

- Du überzeugst mit ausgeprägten kommunikativen Fähigkeiten, insbesondere Präsentationen & Verhandlungen auf Entscheider:innen-Ebene.

- Du bist kundenorientiert, zuverlässig, analytisch und hast Spaß daran, mit Stakeholdern auf allen Ebenen zusammenzuarbeiten.

**Was dich erwartet**

- Flexible Arbeitszeiten und Remote-Option mit Ausstattung nach Bedarf.

- Nutzung unserer Mental-Health-Plattform mit 1:1 Sessions.

- Zugang zu Weiterbildungsressourcen (z. B. über Udemy - unbegrenzter Zugriff auf Kurse und Zertifizierungen).

- Regelmäßige Team-Events, Summer-Parties & Onsite-Zusammenkünfte.

- Sonderurlaub bei besonderen Anlässen bzw. für Familienbedürfnisse.

- Work-cation-Möglichkeiten für mehr Work-Life-Flexibilität.

- Eine inklusive Unternehmenskultur - wir stehen für Gleichberechtigung und Vielfalt und leben eine faire, diskriminierungsfreie Einstellungspolitik.

**Bereit, die Zukunft der digitalen Identität mitzugestalten?**

Dann freuen wir uns auf deine Bewerbung!
Lade deinen Lebenslauf einfach über unser Portal hoch.
Ein paar kurze Infos zu Startdatum & Gehaltsvorstellung helfen uns, noch schneller auf dich einzugehen.

**Let’s build trust - together.**

*IDnow applies the principles of non-discrimination and equality: We strive to establish, maintain, and promote an open and inclusive recruitment process and working environment by respecting the principles of equal opportunities. Including but not limited to: race or ethnic origin, religion or convictions, gender identity or expression, citizenship, marital status, disability, age, or sexual orientation.*

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
