# Senior Architect mit KI im GKV-Umfeld (m/w/d)

Posted: 2026-08-13T17:30:14Z

## Rejection

- Category: language_requirement
- Reason: hard German language requirement without English green light

Als IT-Dienstleister treiben wir die Digitalisierung des öffentlichen Sektors voran und schaffen echten Mehrwert für Millionen Menschen in Deutschland. Wir können vieles richtig gut, aber eben noch nicht alles. Darum suchen wir immer wieder neue Kolleg:innen, die mit ihren Ideen, ihrem Können und Engagement etwas bewegen wollen. Fühlst du dich angesprochen? Dann gestalte Deine Welt zum Besseren und werde Teil unseres Customer Clusters Healthcare.

### DEINE MISSION

Als **Senior Architekt mit KI im GKV-Umfeld (m/w/d)** gestaltest du nicht nur die technische Architektur und Entwicklung innovativer Lösungen, sondern bringst deine Erfahrung im GKV-Umfeld gezielt ein und entwickelst sichere, zukunftsfähige Lösungen an der Schnittstelle von KI, IT und Healthcare.

Deine Aufgaben

-

Entwicklung und technische Konzeption von Lösungen im GKV-Umfeld

-

Übernahme architektonischer Verantwortung sowie Begleitung der technischen Umsetzung

-

Entwicklung unter besonderer Berücksichtigung von IT-Sicherheit und Datenschutz

-

Analyse komplexer fachlicher und technischer Anforderungen und Überführung in nachhaltige Lösungen

-

Zusammenarbeit mit verschiedenen Stakeholdern und technischen Teams

-

Einsatz moderner Technologien und ggf. KI-basierter Lösungen im Healthcare-Umfeld

### DAS IST UNS WICHTIG

-

Mindestens 5 Jahre praktische Erfahrung in der Softwareentwicklung bzw. IT-Architektur

-

Fundierte Erfahrung im GKV-Umfeld und ein gutes Verständnis der Prozesse und Anforderungen im Gesundheitswesen

-

Erfahrung in der Rolle als Architekt, Senior Developer oder Lead Developer

-

Strukturierte, analytische Arbeitsweise sowie ein hoher Anspruch an Qualität und Sicherheit

-

Sehr gute Deutschkenntnisse in Wort und Schrift

-

Nice to have:

-

Praxis in der Entwicklung sicherer und zuverlässiger Softwarelösungen unter Berücksichtigung von IT-Sicherheitsanforderungen

-

Erfahrung mit KI-Lösungen im GKV-Umfeld, idealerweise im Umgang mit sensiblen Patientendaten

### DEIN NEUER ARBEITSPLATZ

-

Was bei uns zählt? Klar definierte Rollen, echtes Miteinander und ein gemeinsames Ziel. Wir nennen das Responsiveness – transparent, wertschätzend und zielorientiert.

-

Hier bist du am Wandel direkt beteiligt, wenn du möchtest. – Nimm Teil an Projekten, die uns als Unternehmen weiterentwickeln.

-

Flexible Arbeitszeiten und Remote Work? – Sind selbstverständlich.

-

Individuelles Hardware-Budget? – Stell dir deinen Arbeitsplatz so zusammen, wie du dich am wohlsten fühlst.

-

Mental Health? – Dein mentales Wohlbefinden ist uns wichtig. Mit OpenUp unterstützen wir dich und bieten dir jederzeit kostenlosen Zugang zu professioneller psychologischer Unterstützung.

-

Individuelles Weiterbildungsbudget? – Egal ob die nächste Zertifizierung oder ein lang ersehnter Sprachkurs – du entscheidest, worin und wann du dich weiterbildest.

-

Mitarbeiter:innen-PC-Programm? – Lease dir dein nächstes Device zur rein privaten Nutzung einfach über virtual7.

-

JobRad oder Firmenwagen? – Wir helfen dir dabei, so mobil zu sein, wie du es brauchst.

Erzähl mir, wer du bist und wann du anfangen kannst. Gerne auch über

**Julia Tismer**

Principal Recruiting Specialist

+49 151 52330481

[](https://virtual7.de/story/marcus-hammer/)

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
