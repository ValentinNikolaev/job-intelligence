# SMB Sales Account Executive (m/f/d)

Posted: 2026-08-13T20:45:24Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**Your wellbeing, our mission. Join a company shaping a healthier world.**

**GET TO KNOW US**

At Wellhub we're revolutionizing workplace wellness. Our platform connects employees worldwide to the best partners for fitness, mindfulness, therapy, nutrition, and sleep—all in one simple subscription. Headquartered in NYC with team members in Europe, North America and South America, we're on a mission to make every company a wellness company.

We believe work should be fulfilling, inspiring, and balanced. Here, you'll find a team that values wellbeing, collaboration, and different perspectives, where passion and creativity push boundaries to create real impact. Your contributions will help shape a healthier, more balanced world for you and millions of people globally.

**Join us in redefining the future of wellbeing!**

**THE OPPORTUNITY**

We are looking for an **SMB Account Executive** to join our **Client Sales** team in **Munich**!

As an SMB Account Executive, you will play a key role in driving Wellhub's growth by acquiring new SMB customers (up to 500 employees). You will primarily manage inbound opportunities while proactively developing outbound business when needed. Through a consultative sales approach, you'll partner with HR leaders and business decision-makers to understand their goals and demonstrate how Wellhub can help organizations build healthier, happier, and more engaged workforces. This is an exciting opportunity for someone who enjoys building relationships, thrives in a fast-paced environment, and is motivated by delivering business impact while creating an exceptional customer experience.

**YOUR IMPACT**

- **Full-Cycle Sales Execution:** Own the full sales cycle from qualification/validation, product demonstrations to proposal, negotiation, and closing. Sell quickly and at high volume to penetrate the SMB market.

- **Pipeline & Activity Management:** Maintain a high volume of outreach (video meetings, phone calls, email, social selling) to systematically connect with potential corporate clients. Manage a healthy pipeline, keep CRM data accurate, and ensure reliable sales forecasting.

- **AI-Powered Efficiency:** Leverage AI tools and digital assistants as strategic partners in your daily workflow to streamline prospecting, optimize deal management, reduce administrative friction, and elevate the quality of your sales engagement.

- **Target Achievement:** Consistently achieve or crush your quarterly sales quotas through disciplined execution.

- **Stakeholder Engagement:** Build trusted relationships with HR leaders, business owners, and key stakeholders to align solutions with their organizational goals.

- **Cross-Functional Collaboration:** Partner closely with Sales Development, Marketing, Customer Success, Legal, and other teams to deliver a seamless customer journey while sharing best practices to lift team performance.

- **Continuous Improvement:** Utilize sales metrics, market trends, competitive intelligence, and feedback to continually refine your strategy and improve performance.

- **Mission Champion:** Live the Wellhub mission by promoting wellbeing, inspiring others, and helping companies create healthier, happier workplaces.

**WHO YOU ARE**

- **Professional Experience:** 3+ years of experience in full-cycle B2B sales, ideally within SaaS, HR Tech, high-velocity sales, or a high-growth technology environment. Experience selling to SMB companies (up to 500 employees) or in the wellbeing industry is preferred.

- **Tech & AI Curiosity:** Curious about technology and eager to explore and adopt AI tools to sharpen your sales approach, increase day-to-day productivity, and work smarter. You see AI as a strategic asset to help you work efficiently and focus on high-impact customer interactions.

- **Sales Capabilities:** Strong consultative selling, negotiation, active listening, and relationship-building skills. Proficient in pipeline management, data-driven forecasting, and using Salesforce (or similar CRM platforms).

- **Communication & Reach:** Excellent verbal, written, and presentation skills with the ability to engage decision-makers effectively through virtual meetings and digital channels. Native German speaker with professional working proficiency in English.

- **Mindset & Approach:** Ambitious, adaptable, coachable, and comfortable navigating ambiguity in a fast-paced environment. Combines an entrepreneurial, competitive drive to succeed with a strong team-first mindset.

- **Mission Alignment:** Passionate about health and wellbeing, with a genuine desire to help organizations create healthier, more balanced work environments.

We recognize that everyone brings different experiences and perspectives to the table. Even if you don't meet every qualification listed above, we encourage you to apply. We believe diverse backgrounds make our teams stronger, and we'd love to hear from you.

**WHAT WE OFFER YOU**

With thoughtful benefits, emotional wellbeing resources, and a culture that empowers you to take ownership of your role and your wellbeing, we create an environment where you can thrive in all dimensions of your life. Our benefits include:

**WELLHUB:** Free Gold membership with access to onsite gyms and studios, digital fitness programs, and online wellness resources for meditation, nutrition, mental wellbeing support, and more! Add up to three family members to your plan, ensuring access to wellness for those who matter most to you.

**FLEXIBLE WORK:** As a Flexible First company, we offer hybrid and remote options to give you the freedom to work in a way that suits you. The model for this specific role can be discussed with your recruiter and hiring manager. We offer all employees a one-time reimbursement to set up their home office equipment and a monthly work allowance to help cover the costs of working from home. Our offices are in Germany, Italy, Netherlands, Portugal, Romania, Spain, and the UK. You can work from any office or remotely based in any of these countries.

**FLEXIBLE SCHEDULE: ** Flexibility for us isn't just about where we work—it also means being able to shape how and when we get things done. Together with their leaders, employees define schedules that align with their time zones, team needs, and personal routines.

**PAID TIME OFF:** We know how important it is to take time away from work to recharge. Employees receive 30 days paid holiday per year in addition to annual holidays (including an extra holiday on your birthday!).

**PARENTAL LEAVE:** Welcoming a new child is one of the most special moments in your life. Take the time to be present and enjoy your growing family. We offer 100% paid parental leave to all new parents. Parents giving birth are eligible for an extended leave and a ramp-back period to return part-time while they get settled.

**CAREER GROWTH:** Access world-class platforms, participate in interactive sessions, build your personalized development roadmap, and explore internal opportunities. We focus on continuous learning and feedback to support your journey toward personal and professional success.

**CULTURE:** You'll join a team of passionate people who come together to break boundaries, support each other, and create a meaningful impact in workplace wellness. We win together, building trust through open communication and a culture where every perspective matters. [Learn more about our shared culture and values here. ](https://wellhub.com/en-us/careers/our-values/)

**Want to see what it's really like to work here? Follow us on **[**Instagram**](https://www.instagram.com/lifeatwellhub/)** @lifeatwellhub and watch our team video on **[**YouTube**](https://www.youtube.com/watch?v=ZgIPiszTVm4)**!**

**Diversity, Equity, and Belonging at Wellhub**

We aim to create a collaborative, supportive, and inclusive space where everyone knows they belong. At Wellhub, we welcome and celebrate your authentic self.

Wellhub is committed to creating a diverse work environment and is proud to be an equal opportunity employer. All qualified applicants will receive consideration for employment without regard to race, religion, color, sex, gender identity or expression, sexual orientation, age, non-disqualifying physical or mental disability, national origin, veteran status, or any other basis covered by appropriate law.

Our commitment to inclusion also extends to how we recognize and reward our people. We're proud to be Syndio Fair Pay Certified, reflecting our ongoing dedication to equitable and fair pay practices across our global team. [Read more about it here.](https://www.linkedin.com/posts/wellhub_fairpay-syndio-activity-7407826561531363328-wbN_?utm_source=share&utm_medium=member_desktop&rcm=ACoAAAzHQWABKsRqcpvxy4QpDCJNe_szRdC4hgY)

Questions on how we treat your personal data? See our [Job Applicant Privacy Notice.](https://wellhub.com/en-us/careers/job-applicant-privacy-notice/)

** #LI-HYBRID**

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
