# Working Student Employment Law

Posted: 2026-08-13T17:55:33Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Celonis is the global leader in Process Intelligence and the pioneer of Process Mining technology. As one of the world’s fastest-growing enterprise SaaS companies, we are changemakers pushing the boundaries of what’s possible. We invest heavily in advanced AI capabilities—specifically our Process Intelligence Graph—to turn data insights into immediate business action. We believe there is a massive opportunity to unlock global productivity and sustainability by placing intelligence at the core of every business process. Join our mission to make processes work for people, companies, and the planet.

**The Team:**

Celonis is looking for an exceptional candidate to join our Global Employment Law & Compliance team.

With operations spanning more than 20 countries across Europe, North America, and Asia, our Legal team plays a critical role in supporting the company’s global expansion. This is a unique opportunity to join an organization redefining how AI and data transform the business world. Based in Munich, this part-time position (up to 20 hours/week) will collaborate closely with the wider international Legal team.

**The Role:****
****
**As a Working Student, you will be actively involved in driving our departmental and corporate goals forward. Applying your legal knowledge to the world of artificial intelligence, you will coordinate compliance and advisory queries, identify cross-border best practices, and assist in drafting processes, policies, and legal documents.

A defining focus of this role is our integration of advanced technology. You will play a key role in supervising and refining AI-generated legal content, ensuring its absolute accuracy, and exploring how these tools can be leveraged to generate reliable legal insights.

This position offers an exceptional opportunity to join our dynamic legal team, allowing you to develop into a strategic thinker while actively shaping the future of legal work.

#### **
The work you'll do:**

Legal Research & Documentation

- Conduct global legal research on employment laws and regulations under the guidance of senior team members.

- Summarize case law, regulatory updates, and guidance materials for internal distribution.

- Assist in drafting, reviewing, and updating internal policies, procedures, and legal documentation.

- Organize, help draft and manage critical documentation for ongoing internal investigations.

Policy & Compliance Assistance

- Help maintain and update legal databases and tracking tools.

- Support the team in ensuring that documents and policies are aligned with local legal requirements.

General Legal Support

- Help design and format training materials, workshops and presentations.

- Assist in distributing compliance reminders, newsletters, or updates to relevant teams.

AI & Technology Innovation

- Review AI-generated legal content for accuracy, flagging inconsistencies or potential issues.

- Leverage AI tools to support basic legal queries and assist with early-stage research for larger projects.

- Provide input on how AI-generated insights can be improved based on context and team feedback.

Team Coordination & Collaboration

- Maintain shared folders, legal templates, and knowledge libraries to ensure centralized, up-to-date access across the team.

- Collaborate with the People & Culture team to support cross-functional tasks such as onboarding materials or process guides.

#### **The qualifications you need:**

Education, Languages & Location

- Currently pursuing a degree in Law (Staatsexamen / Wirtschaftsrecht / LL.B. / LL.M.) or a related field.

- Business Fluent English (spoken and written); native-level proficiency or equivalent. Knowledge of Spanish or German is a strong plus.

- Based in Munich to work on-site from Celonis’ Headquarters.

Technical Skills

- Proficiency in Google Workspace (Google Sheets, Google Drive, Google Mail, Google Slides).

- Experience using AI and familiarity with AI tools is highly valued.

Legal & Compliance Knowledge

- Basic understanding of employment law, HR-related legal issues, and compliance frameworks.

- Strong interest in emerging legal topics, especially those involving AI and data privacy.

Soft Skills & Work Style

- Strong communication skills, both verbal and written.

- Highly organized, detail-oriented, and able to thrive in a fast-paced environment.

- Demonstrated project management abilities and the capacity to manage multiple tasks simultaneously.

- An analytical mindset with a structured approach to problem-solving and a quick learning ability.

- Capable of working independently as well as collaboratively within a global team.

** **

**What Celonis can offer you:**

- Pioneer Innovation: Work with the global leader in Process Mining and the Process Intelligence Graph to shape the future of AI-driven business operations.

- Ownership from Day 1: Every full-time "Celonaut" is an owner, receiving Restricted Stock Units (RSUs) and merit-based refresh grants.

- Unrivaled Family Support: Benefit from our inclusive parental leave policy—24 weeks of fully paid leave for primary carers and 12 weeks for supporting carers, available from your first day of employment.

- Work-Life Integration: Enjoy Unlimited PTO (in applicable regions) and generous PTO globally, as well as a flexible hybrid work model that balances remote focus with vibrant office collaboration.

- Continuous Growth: Elevate your skills through our 70-20-10 learning framework, mentorship programs, and access to a dedicated learning platform.

- Holistic Well-being: Prioritize your health with subsidized Wellhub memberships, mental health counseling, and dedicated "Wellness Weeks" that prioritize work/life balance.

- Drive Sustainability: Participate in annual Impact Days, where you receive paid time off to volunteer for community and environmental causes with your local office, or virtually.

- Global Inclusion & Belonging: Find community through our Inclusion Think Tank and participate in our annual Inclusion Days, ensuring every voice is heard and valued.

- Value-Driven Impact: Join a mission-led organization where our core values—Live for Customer Value, The Best Team Wins, We Own It, and Earth Is Our Future—drive every decision.

**About Us:**

Celonis makes processes work — for people, companies, and the planet. Powered by process mining and AI, the Celonis Process Intelligence Platform integrates process data and business context to create a living digital twin of business operations. We enable thousands of companies worldwide to understand how their business actually runs and, together with their partners, build intelligent solutions that transform and continuously improve the way they operate — unlocking billions in value. Celonis is headquartered in Munich, Germany, and New York City, USA, with more than 20 offices worldwide.

Get familiar with the Celonis Process Intelligence Platform by watching this [video](https://academy.celonis.com/learn/video/discover-the-ems).

**Celonis Inclusion Statement:**

At Celonis, we believe our people make us who we are and that “The Best Team Wins”. We know that the best teams are made up of people who bring different perspectives to the table. And when everyone feels included, able to speak up and knows their voice is heard - that's when creativity and innovation happen.**
**

**Your Privacy:**

Any information you submit to Celonis as part of your application will be processed in accordance with Celonis’ [Accessibility and Candidate Notices](https://www.celonis.com/careers/candidate-notices)

By submitting this application, you confirm that you agree to the storing and processing of your personal data by Celonis as described in our [Privacy Notice for the Application and Hiring Process](https://www.celonis.com/careers/privacy-notice/).

Please be aware of common job offer scams, impersonators and frauds. Learn more [here](https://www.celonis.com/careers/fraud-alert/).

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
