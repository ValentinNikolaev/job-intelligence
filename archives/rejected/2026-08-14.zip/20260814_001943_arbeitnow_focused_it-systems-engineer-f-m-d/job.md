# IT Systems Engineer (f/m/d)

Posted: 2026-08-13T20:40:20Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

## **About Focused Energy**

Focused Energy is a pioneering international deep-tech company with locations in Germany and the US, dedicated to commercializing laser-driven nuclear fusion. Our mission is to deliver clean, safe, and virtually limitless energy to the world. As we rapidly scale, we seek talented individuals who thrive on bringing clarity and structure to fast-growing environments.

## About the Role

Focused Energy’s German operations are growing, and the IT systems supporting that growth need an engineer who can own their operation with confidence. As an IT Systems Engineer, you’ll ensure that Focused Energy’s Darmstadt IT environment runs reliably, securely, and efficiently across device management, endpoint security, cloud services, access management, and automation.

This is a systems ownership role, with end-user support as a secondary responsibility. You’ll work onsite in Darmstadt, collaborate with colleagues across Berlin and Austin, and help build a more stable, automated, and scalable IT environment for the scientists and engineers developing fusion technology.

## What You’ll Do

-

Own the operation and maintenance of IT systems and infrastructure in Darmstadt, including MDM, endpoint security, cloud services, device lifecycle, and access management.

-

Lead automation and scripting initiatives that reduce repetitive manual work, improve consistency, and increase operational efficiency.

-

Manage onboarding and offboarding IT execution, including account provisioning, device readiness, access management, and access revocation.

-

Maintain and improve Focused Energy’s security baseline by supporting MFA enforcement, endpoint hardening, patch management, access reviews, and security event response.

-

Build and maintain accurate system documentation, configuration records, support processes, and operational runbooks.

-

Identify recurring incidents and improvement opportunities, investigate root causes, and implement lasting technical solutions.

-

Contribute to IT improvement projects such as MDM consolidation, cloud service migration, DLP implementation, EDR rollout, and unified device management.

-

Provide efficient end-user support to Darmstadt employees while coordinating shared infrastructure with the wider IT team and escalating architectural changes, security incidents, and vendor decisions appropriately.

## Who You Are

-

You take ownership of systems issues and improvement opportunities without waiting to be assigned tasks.

-

You are technically confident, hands-on, and comfortable operating interconnected systems in a fast-growing environment.

-

You think in systems, considering how components interact before making configuration or production changes.

-

You are proactive about identifying risks, recurring issues, automation opportunities, and operational improvements.

-

You communicate system status, incidents, risks, and project progress clearly in English; German language skills are a plus.

-

You follow through to resolution, document what was changed and why, and work to prevent issues from recurring.

-

You can balance systems engineering responsibilities with secondary end-user support demands.

-

You collaborate effectively with employees, People Operations, IT colleagues across sites, vendors, and service providers.

## Desirable Skills & Knowledge

-

Experience in IT systems engineering, including endpoint management, cloud services, identity and access management, and network fundamentals.

-

Strong experience with MDM platforms and device lifecycle management across Windows and macOS environments.

-

Practical knowledge of endpoint security, EDR and DLP tooling, endpoint hardening, patch management, and MFA enforcement.

-

Familiarity with Microsoft 365, including Exchange, Teams, SharePoint, and Intune or an equivalent MDM platform.

-

Experience with Box, Atlassian tools such as Jira and Confluence, access management platforms, and cloud infrastructure services.

-

Scripting and automation skills using PowerShell, Python, or an equivalent language.

-

Knowledge of ITIL-aligned incident and change management, root-cause analysis, and documentation-first operational practices.

-

Understanding of GDPR requirements applicable to German IT operations and disciplined access review and security procedures.

Focused Energy is an equal opportunity employer committed to creating an inclusive environment. Qualified applicants will receive consideration for employment without regard to race, color, religion, sex, sexual orientation, gender perception or identity, national origin, age, marital status, protected veteran status, or disability status.

Pursuant to the San Francisco Fair Chance Ordinance, Focused Energy will consider for employment qualified applicants with arrest and conviction records.

Compensation offered will be determined by factors such as location, level, job-related knowledge, skills, and experience. Certain roles may be eligible for incentive compensation, equity, benefits.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
