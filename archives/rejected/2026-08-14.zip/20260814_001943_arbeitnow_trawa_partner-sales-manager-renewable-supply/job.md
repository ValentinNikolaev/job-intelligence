# Partner Sales Manager - Renewable Supply

Posted: 2026-08-13T20:40:07Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

# Partner Sales Manager - Renewable Supply

Festanstellung, Vollzeit · Berlin (HQ)

#

Deine Mission

Du bist kommunikationsstark, arbeitest gerne nah am Menschen und hast Freude daran, langfristige Vertriebspartnerschaften aufzubauen und zu echten Wachstumstreibern zu entwickeln? Dann bist du bei uns genau richtig.

Als **Partner Sales Associate / Manager** entwickelst, betreust und skalierst du das trawa-Vertriebspartnernetzwerk – von der ersten Akquise bis zur messbaren Performance. Gemeinsam mit unserem Vertriebsteam baust du starke Kooperationen auf, bist zentrale Ansprechperson für unsere externen Vertriebspartner und verantwortest den Deal-Flow mit.

Bring dein Vertriebstalent ein, arbeite eng mit unseren Partnern zusammen und hilf uns dabei, unsere Vision einer modernen und nachhaltigen Energieversorgung Wirklichkeit werden zu lassen.

## Über trawa

Willkommen im **trawa-Universum**! Wir haben es uns zur Aufgabe gemacht, das grüne Energieversorgungsunternehmen der Zukunft von Grund auf aufzubauen.

Wie machen wir das? Wir schaffen direkten Zugang zu erneuerbarer Energie für B2B-Industrieunternehmen. Wir entwickeln Software und Technologie, um die Volatilität des Energiemarkts zu bewältigen, und professionalisieren die Energiebeschaffung auf der Käuferseite.

## Das Team

Du wirst Teil unseres sechsköpfigen Partnerschaftsteams und arbeitest eng und interdisziplinär mit den Teams aus Sales, Marketing, Operations und Business Analytics zusammen.

## Deine Aufgaben

-

**Vertriebspartnernetzwerk aufbauen und skalieren:** Du entwickelst, betreust und skalierst unser Netzwerk entlang der gesamten Partner-Journey. Dabei pflegst du engen Kontakt zu Energieberater:innen, externen Vertriebspartnern und Unternehmen aus relevanten Branchen.

-

**Neue Partner gewinnen:** Du identifizierst, qualifizierst und aktivierst neue Partner, um das Wachstum im Geschäftskundensegment gezielt auszubauen.

-

**Deal-Pipelines steuern:** Du verantwortest das Pipeline- und Performance-Tracking und unterstützt gemeinsam mit unserem Sales-Team den gesamten Vertriebsprozess.

-

**Partnerschaften entwickeln:** Du baust langfristige Beziehungen zu Vertriebspartnern, Verbänden und Handelskammern auf und stärkst damit trawas Positionierung in unseren aktiven Märkten.

-

**Partner onboarden und befähigen:** Du verantwortest Onboarding-, Enablement- und Aktivierungsinitiativen sowie Partner-Incentives, um die Zusammenarbeit messbar zu steigern.

-

**Performance analysieren und optimieren:** Du führst regelmäßige Partner-Reviews durch, analysierst bestehende Kooperationen und leitest konkrete Verbesserungsmaßnahmen ab – von Angebotsprozessen bis hin zu Vergütungsstrukturen.

-

**Crossfunktional zusammenarbeiten:** Du arbeitest eng mit Sales, Marketing und Revenue Operations zusammen, um Synergien zu nutzen, Strukturen zu schaffen und die Partnerperformance kontinuierlich zu steigern.

## Wen wir suchen

-

Du bringst drei bis fünf Jahre Berufserfahrung im Aufbau von Vertriebsnetzwerken, in Vertriebspartnerschaften oder im Account Management mit und kannst einen nachweisbaren direkten Beitrag zum Umsatz vorweisen.

-

Du kommunizierst mit unterschiedlichsten Charakteren und Persönlichkeiten auf Augenhöhe und baust belastbare Beziehungen auf.

-

Du bist hochmotiviert und hast den Antrieb, Partnerschaften aktiv weiterzuentwickeln und Deal-Pipelines zu steuern.

-

Du trittst in einem dynamischen, wachstumsorientierten Umfeld sicher auf und findest dich schnell in neuen Strukturen zurecht.

-

Du hast ein Studium in BWL, VWL, Wirtschaftsingenieurwesen oder einem vergleichbaren Fach abgeschlossen – oder überzeugst durch ein entsprechend relevantes berufliches Profil.

-

Du sprichst verhandlungssicher Deutsch und verfügst über Englischkenntnisse auf mindestens B2-Niveau.

-

Du interessierst dich für Energie-, SaaS- oder ClimateTech-Themen. Kenntnisse im Energiemarkt sind ein Plus, aber keine Voraussetzung.

## Deine ersten 90 Tage bei trawa

### Monat 1: Einarbeitung und Orientierung

-

Du lernst trawas Produkte, den Energiemarkt und unsere Partnerlandschaft von Grund auf kennen.

-

Du führst Gespräche mit relevanten internen Stakeholdern und entwickelst ein klares Verständnis dafür, wie Deals bei trawa entstehen, gesteuert und abgeschlossen werden.

-

Du übernimmst von Anfang an erste Verantwortung in der direkten Partnerbetreuung.

### Monat 2: Beziehungsaufbau und aktive Entwicklung

-

Du etablierst dich als verlässliche Ansprechperson für bestehende Partner und treibst gleichzeitig den Aufbau neuer Partnerbeziehungen voran.

-

Deine Partner-Pipeline wächst um qualifizierte Partner, die strategisch zu trawa passen.

-

Du begleitest laufende Deals eng, vertrittst trawas Interessen klar und identifizierst Schwachstellen im gemeinsamen Deal-Management.

-

Du entwickelst konkrete Lösungsvorschläge zur Verbesserung der Zusammenarbeit.

### Monat 3: Eigenverantwortung und messbarer Impact

-

Du steuerst deine Partner-Pipeline und die zugehörigen Deals vollständig eigenverantwortlich.

-

Erste Deals sind abgeschlossen oder stehen unmittelbar vor dem Abschluss.

-

Du lieferst eine fundierte Einschätzung dazu, welche Partner gut performen und wo weiteres Investment sinnvoll ist.

-

Du bist die strategische Schnittstelle zwischen unserem Partnernetzwerk und trawa.

## Warum trawa?

Gestalte mit uns die Zukunft der Energiewirtschaft und treibe eigenverantwortlich Projekte voran, die echten Einfluss auf unsere Produkte, unsere Kund:innen und die Umwelt haben.

-

**Dein Impact:** Du übernimmst Verantwortung in unserem dynamischen Team und gestaltest aktiv innovative Produkte und Partnerschaften, die die Energiewende vorantreiben und zur Dekarbonisierung der Industrie beitragen. Dein Beitrag hat direkten Einfluss, und du kannst stolz auf deine Ergebnisse sein.

-

**Flexibles Arbeiten:** In unserem schönen Büro fördern wir eine lebendige Unternehmenskultur, in der wir gerne gemeinsam arbeiten. Homeoffice ist ebenfalls möglich. Mit flexiblen Arbeitszeiten und 30 Urlaubstagen unterstützen wir deine Work-Life-Balance.

-

**Attraktive Benefits:** Neben einem wettbewerbsfähigen Gehalt erhältst du Essensgutscheine, steuerfreie Extras und eine Urban-Sports-Mitgliedschaft.

-

**Persönliche Entwicklung:** Du arbeitest mit modernen Technologien und lernst von erfahrenen Expert:innen aus der Branche. Zusätzlich bieten wir Weiterbildungstage, ein jährliches L&D-Budget und Coaching-Sessions über Sparrks.

-

**Vielfalt und Inklusion:** Bei uns sind alle willkommen. Wir setzen uns für einen inklusiven Arbeitsplatz ein, der Vielfalt wertschätzt, und ermutigen Menschen unabhängig von Geschlecht, Alter, sexueller Orientierung, ethnischer Herkunft sowie körperlicher oder neurodiverser Vielfalt zur Bewerbung.

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
