# Sr.Enterprise Account Executive - Munich

Posted: 2026-08-13T20:55:12Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**About Neo4j:**

Neo4j is the graph intelligence platform that transforms data into knowledge to power the next generation of intelligent applications and AI systems. It includes enterprise-ready knowledge graphs for accurate, explainable, and governed AI; the most comprehensive, trusted, and easy-to-deploy graph capabilities across any environment and data source; and an unmatched ecosystem trusted by 84 of the Fortune 100 and supported by the world’s largest graph community. Intelligence that works. Results that matter.

Built to work everywhere and integrate with everything across every cloud for dynamic, personalized, and autonomous AI systems. We deliver quicker results, contextual knowledge, and solutions that impact customers and employees across the business.

**Our Vision: **

At Neo4j, we have always strived to help the world make sense of data.

As business, society and knowledge become increasingly connected, our technology promotes innovation by helping organizations to find and understand data relationships. We created, drive and lead the graph database category, and we’re disrupting how organizations leverage their data to innovate and stay competitive.

**
****About the Role:****
****
**** We are seeking a driven, high-energy individual who is passionate about new business acquisition and enterprise sales. As a Senior Enterprise Account Executive, you will be responsible for executing a strategic sales plan in your assigned territory, with a focus on revenue growth and new customer acquisition. This role offers the opportunity to work closely with cross-functional teams, including solution engineering (pre-sales), marketing, and professional services, to ensure customer satisfaction and long-term success.**

- Develop and execute a territory plan based on target agencies and applicable use cases, resulting in a pipeline of opportunities in the target market, that will help you achieve quarterly and annual sales metrics.

- Develop expert knowledge of Neo4j solutions and applicability in the target market.

- Develop and present to customers a strong understanding of the benefits and advantages of graph technology versus alternative database approaches.

- Execute sales cycles that employ Strategic Selling strategies and tactics.

- Build and present proposals for Neo4j solutions that involve Neo4j products and Services.

- Work with the Solution resources to scope and deliver on well-qualified POC’s

- “Land & Expand” - Grow the business in accounts that you have landed

- Provide guidance, direction, and support to your assigned SDR in their efforts to support your pipeline development.

- Provide guidance and direction to your Field Marketing resources so they can target programs to your target accounts.

- Provide guidance and direction to the Channel Director so they can target partners and programs for your target accounts.

- Maintain Neo4j[ Salesforce.com](http://salesforce.com) CRM system with accurate information about your pipeline, in accordance with Neo4j forecasting guidelines.

Ideally, you should have:

- Coursework in database, SQL, computer programming, Computer Information Systems, Computer Science, Electrical Engineering, or similar, is desirable.

- Experience selling information management tools to customers in the enterprise market.

- 7-10 years of consistent success meeting or exceeding sales objectives selling technical solutions and software products into the enterprise market.

- Demonstrable experience executing enterprise complex sales strategies and tactics.

- Experience with the commercial open-source business model, selling subscriptions for on-premise deployments and/or hybrid on-prem/cloud deployments.

- Previous experience and thrive in a smaller, high-growth software company, where you have leveraged dedicated SDR resources, Field Marketing resources, and Pre-Sales Engineering helping build the business.

- Strong conviction and approach to how and where graph solutions fit into the enterprise marketplace.

- Be a hard-working, responsible, self-starter, with the ability to work remotely in a home-office environment, as well as travel to client sites to run meetings.

- Excellent references, ideally from previous Sales managers and/or customers.

- Demonstrate attention to detail, ensuring accurate entry and management of lead data in our[ SalesForce.com](http://salesforce.com) CRM system.

- Be proficient with standard corporate productivity tools (e.g., Google Docs, MS Office,[ Salesforce.com](http://salesforce.com), web conferencing).

- Be a team player with the highest level of integrity and humour.

**Languages: Fluency in both German and English is required.**

**Why Join Neo4j?**

Neo4j is, without question, the most popular graph intelligence platform in the world. We have customers in every industry globally, and our products are a proven product/market fit. Joining our team is an opportunity to shape the future of data and analytics. Below are just a few exciting facts about Neo4j.

- Neo4j is one of the fastest-scaling technology companies in this industry. It [recently surpassed $200M](https://neo4j.com/press-releases/neo4j-revenue-milestone-2024/) in annual recurring revenue (ARR), doubling its ARR [over the past three years.](https://neo4j.com/press-releases/2021-company-momentum/)

- Raised the biggest funding round in database history ($325M Series F). Backed by world-class investors like Eurazeo, GV (formerly Google Ventures), and Inovia Capital, Neo4j has raised over $600M in funding and is currently valued at over $2Bn. This puts Neo4j among the most well-funded database companies in history.

- 84% of the Fortune 100 and 58% of the Fortune 500 use Neo4j. Examples include [Boston Scientific](https://neo4j.com/case-studies/boston-scientific/), [BT Group](https://neo4j.com/case-studies/bt/), [Caterpillar](https://neo4j.com/case-studies/caterpillar/), [Cisco](https://neo4j.com/case-studies/cisco/), [Comcast](https://neo4j.com/case-studies/comcast/), [Department for Education UK](https://neo4j.com/case-studies/department-for-education-uk/), [eBay](https://neo4j.com/case-studies/ebay/), [NBC News](https://neo4j.com/case-studies/nbc-news/), [Novo Nordisk](https://neo4j.com/case-studies/novo-nordisk/), [Worldline](https://neo4j.com/case-studies/worldline/), and [others](https://neo4j.com/case-studies/).

- Co-founder and CEO Emil Eifrem has built an amazing culture that prides itself on relationships, inclusiveness, innovation, and customer success.

- Countless [industry awards](https://neo4j.com/awards/). Massive enterprises and individual developers/data scientists love Neo4j. A strong sense of community and ecosystem is built around the platform.

- A recent Forrester Total Economic Impact™ Study cited Neo4j as delivering 417% ROI to customers.

[Research](https://www.bizjournals.com/bizwomen/news/profiles-strategies/2022/07/getting-the-job-how-gender-equity.html?page=all) shows that members of underrepresented communities are less likely to apply for jobs when they don’t meet all the qualifications. **If this is part of the reason you hesitate to apply, we’d encourage you to reconsider and give us the opportunity to review your application. **At Neo4j, we are committed to building awareness and helping to improve these issues.

One of our central objectives is to provide an inclusive, diverse, and equitable workplace for everyone to develop their potential and have a positive, career-defining experience. We look forward to receiving your application.

**Neo4j Values:**

Neo4j is a Silicon Valley company with a Swedish soul. We foster collaboration and each of us is empowered to contribute and put our innovative stamp on projects. We hire candidates who reflect the following Neo4j core values:

(we)-[:VALUE]->(relationships)
(we)-[:FOCUS_ON]->(userSuccess)
(we)-[:THRIVE_IN]->(:Culture {type: [‘Open’, ‘Inclusive’]})
(we)-[:ASSUME]->(:Intent {direction:’Positive’})
(we)-[:WELCOME]->(:Discussions {nature: ‘IntellectuallyHonest’})
(we)-[:DELIVER_ON]->(ourCommitments)

Neo4j is committed to protecting and respecting your privacy. Please read the[ privacy notice regarding Neo4j's recruitment process](https://neo4j.com/privacy-policy/recruitment-process/?ref=hr-) to understand how we will handle the personal data that you provide.

More information at[ ](http://www.neo4j.com/)[www.neo4j.com](https://www.neo4j.com).

©2026 Neo4j, Inc., Neo Technology®, Neo4j®, Cypher®, Neo4j Bloom™, Neo4j Graph Data Science Library™, Neo4j® Aura™, and Neo4j® AuraDB™ are registered trademarks or a trademark of Neo4j, Inc. All other marks are owned by their respective companies.

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
