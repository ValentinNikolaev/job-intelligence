# Partner Sales Manager - Battery Solutions

Posted: 2026-08-13T20:40:07Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

# Partner Sales Manager - Battery Solutions

Festanstellung, Vollzeit · Berlin (HQ)

#

## Deine Mission

Als **Partner Sales Manager** wirst du zur treibenden Kraft hinter unserem indirekten Vertrieb. Du baust ein starkes Netzwerk aus Installationsbetrieben, Hardwareherstellern, Projektentwickler:innen und Energieberatungen auf und entwickelst daraus nachhaltige Vertriebspartnerschaften.

Du arbeitest an der Schnittstelle zwischen unseren externen Partnern sowie den Teams aus Sales und Business Analytics. Dabei begleitest du unsere Partner bei allen Fragen rund um trawa und unsere Lösungen für ihre Kund:innen.

Gemeinsam entwickelst du nicht nur langfristige Partnerschaften und eine wachsende Endkundenpipeline, sondern gestaltest aktiv mit, wie Unternehmen durch intelligente Batteriesteuerung Stromkosten senken, ihren Verbrauch flexibilisieren und die Energiewende vorantreiben.

Durch den Ausbau erneuerbarer Energien wird die Stromerzeugung immer dynamischer. Werde Teil des trawa-Teams und hilf dabei, den europäischen Mittelstand zeitgemäß aufzustellen.

## Das Team

Du wirst Teil unseres sechsköpfigen Partnerschaftsteams und arbeitest eng und interdisziplinär mit den Teams aus Sales, Marketing, Operations und Business Analytics zusammen.

## Deine Aufgaben

-

**Vertriebspartnerschaften aufbauen und entwickeln:** Du entwickelst und steuerst starke Partnerschaften rund um unsere intelligente Batteriesteuerung, um neue Geschäftskund:innen zu gewinnen. Dabei vermittelst du den konkreten Nutzen – von der Verbrauchsflexibilisierung und Kosteneinsparungen bis hin zu zusätzlichen Erlösmöglichkeiten.

-

**Partnerbeziehungen pflegen:** Du baust vertrauensvolle und langfristige Beziehungen zu Installationsbetrieben, Hardwareherstellern, Projektentwickler:innen und Energieberatungen auf. Als wichtiges Bindeglied verbindest du unsere externen Partner mit den Teams aus Sales und Business Analytics.

-

**Pipeline generieren:** Du gehst aktiv auf potenzielle Partner und Endkund:innen zu und nutzt dein Netzwerk, um eine wachsende Pipeline qualifizierter Interessent:innen für trawas intelligente Batteriesteuerung aufzubauen.

-

**Batteriespeicherpotenziale analysieren:** Du analysierst das Batteriespeicherpotenzial an Kundenstandorten unserer Partner und berätst sie als erste Anlaufstelle zu den Möglichkeiten und dem gemeinsamen Vorgehen.

-

**Partnerschaften optimieren:** Du entwickelst bestehende Partnerschaften kontinuierlich weiter und bringst innovative Ideen ein – von Angebotsprozessen bis hin zu Vergütungsmodellen.

-

**Ergebnisse messbar machen:** Du arbeitest eigenständig und kreativ mit deinen Partnern und misst deine Aktivitäten anhand von KPIs, die auf trawas ambitionierte Wachstumsziele einzahlen.

-

**Markt- und Branchenwissen einbringen:** Du beobachtest Branchentrends, regulatorische Entwicklungen und das Wettbewerbsumfeld im Batteriespeicherbereich. So triffst du fundierte strategische Entscheidungen und vertiefst den Austausch mit deinen Partnern.

## Wen wir suchen

-

Du bringst mindestens zwei Jahre Berufserfahrung in einer vergleichbaren Position mit, idealerweise mit Schwerpunkt auf Partnerschaften, Kundenbetreuung oder Vertrieb. Erfahrung im Energie- oder Batteriespeicherbereich ist ein Plus, aber kein Muss.

-

Du hast ein Bachelorstudium oder eine relevante Ausbildung abgeschlossen.

-

Du begeisterst dich für zwischenmenschliche Dynamiken und die Entwicklung erfolgreicher Partnerschaften. Dabei kannst du einen nachweisbaren Track Record vorweisen.

-

Du gehst gerne auf Menschen zu und fühlst dich wohl dabei, neue Geschäftskontakte zu knüpfen und weiterzuentwickeln.

-

Du kommunizierst klar und überzeugend und kannst zwischen Partnern, Sales, Marketing und Tech vermitteln.

-

Du sprichst fließend Deutsch und verfügst über gute Englischkenntnisse auf mindestens B2-Niveau.

-

Erfahrung im komplexen oder technischen Vertrieb beziehungsweise ein gutes Verständnis des Energiemarkts und relevanter Technologien – zum Beispiel EMS, Batteriespeicher oder Energiemärkte – ist ein Plus.

-

Du hast Freude daran, komplexe Produkte in einfacher Sprache verständlich und greifbar zu machen.

-

Du wohnst in Berlin oder bist bereit, nach Berlin zu ziehen.

## Deine Ziele in den ersten 90 Tagen

### Nach sechs Wochen: Onboarding

-

Du hast trawas Geschäftsmodell und unsere Produkte verstanden.

-

Du hast die wichtigsten internen und externen Stakeholder kennengelernt.

-

Du kennst die relevanten Partner-, Analyse- und Vertriebsprozesse.

-

Du hast erste Partnerpotenziale identifiziert und einen priorisierten Plan für die Aktivierung und Akquise erstellt.

### Bis zum Ende des dritten Monats: Ramp-up

-

Du betreust deine Partner eigenständig und führst regelmäßige Gespräche.

-

Du hast mehrere vielversprechende neue Partner angesprochen und erfolgreich onboarded.

-

Du dokumentierst und priorisierst deine Aktivitäten anhand der vereinbarten KPIs und generierst erste qualifizierte Pipeline über deine Partner.

-

Du hast erste Vertriebsinitiativen entwickelt und umgesetzt sowie konkrete Prozessverbesserungen angestoßen.

## Warum trawa?

Gestalte mit uns die Zukunft der Energiewirtschaft und treibe eigenverantwortlich Projekte voran, die echten Einfluss auf unsere Produkte, unsere Partner, unsere Kund:innen und die Umwelt haben.

-

**Dein Impact:** Du baust die Partnerschaften und Strukturen auf, mit denen wir die Industrie dekarbonisieren. Jeder aktivierte Partner und jede vermarktete Batterie trägt dazu bei, die Energiewende zu beschleunigen.

-

**Flexibles Arbeiten:** Dich erwartet ein schönes Büro in Berlin mit einer lebendigen Unternehmenskultur, flexiblen Arbeitszeiten und 30 Urlaubstagen.

-

**Attraktive Benefits:** Neben einem wettbewerbsfähigen Gehalt erhältst du Essensgutscheine, steuerfreie Extras, eine Urban-Sports-Mitgliedschaft und Zugang zu [nilo.health](http://nilo.health).

-

**Persönliche Entwicklung:** Du arbeitest mit modernen Technologien und lernst von erfahrenen Expert:innen. Zusätzlich bieten wir Weiterbildungstage, ein jährliches L&D-Budget von 1.000 Euro und Coaching-Sessions über Sparrks.

-

**Vielfalt und Inklusion:** Bei uns sind alle willkommen. Wir setzen uns für einen inklusiven Arbeitsplatz ein, der Vielfalt wertschätzt, und ermutigen Menschen unabhängig von Geschlecht, Alter, sexueller Orientierung, ethnischer Herkunft sowie körperlicher oder neurodiverser Vielfalt zur Bewerbung.

## Unser Bewerbungsprozess

Innerhalb von zwei Wochen erhältst du eine Rückmeldung von uns. Der Bewerbungsprozess umfasst Gespräche, eine praktische Challenge und Interviews mit unserem Team.

Wir ermutigen dich, dich auch dann zu bewerben, wenn du nicht alle Qualifikationen erfüllst. Lass dich davon nicht zurückhalten – wir freuen uns darauf, von dir zu hören!

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
