# Experimental Scientist (f/m/d)

Posted: 2026-08-13T20:40:20Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**About Focused Energy**

Focused Energy is a pioneering international deep-tech company with locations in Germany and the US, dedicated to commercializing laser-driven nuclear fusion. Our mission is to deliver clean, safe, and virtually limitless energy to the world. As we rapidly scale, we seek talented individuals who thrive on bringing clarity and structure to fast-growing environments.

As a **Experimental** **Scientist**, you’ll build experimental capability in Darmstadt and help execute compression experiments at ELI Beamlines and other external facilities. Focused Energy’s Target Physics Risk Mitigation project requires experimental validation of foam compression and hydrodynamic instability behaviour in wetted foam targets this is an important input to the company’s path to ignition.

You’ll bridge experiment and simulation by operating shock and compression diagnostics, analysing experimental data, and running radiation hydrodynamic simulations that can be compared directly with experimental results. Working alongside the foam compression team, you’ll help deliver the project’s Q1 2027 milestones.

## What You’ll Do

-

Own the execution of laser compression experiments at ELI Beamlines and other external facilities, including shot planning, diagnostic setup, and data collection.

-

Lead the operation of VISAR, SOP, and X-ray radiography diagnostics, building reliable procedures and deep diagnostic expertise within the foam compression team.

-

Drive radiation hydrodynamic simulations of foam compression and hydrodynamic instabilities using a multi-dimensional code such as FLASH or an equivalent.

-

Analyse experimental data comprehensively and document results in a form that supports physics interpretation and project reporting.

-

Compare simulation results with experimental data, clearly identifying areas of agreement, discrepancy, and uncertainty.

-

Build productive working relationships with ELI Beamlines and other facility partners to support beamtime access and campaign execution.

-

Improve the team’s understanding of foam compression and hydrodynamic instability physics by connecting experimental observations with simulation predictions.

-

Partner with Franzi Treffert, the Target Design team, and the simulation team on experimental planning, physics interpretation, and model validation.

## Who You Are

-

You take ownership of your experimental and simulation workstream and manage day-to-day priorities without waiting for direction.

-

You are comfortable working independently in technically demanding, multidisciplinary environments.

-

You communicate experimental results, simulation findings, risks, and data-quality issues clearly in writing and team meetings.

-

You plan carefully and follow through across the full experiment cycle, from beamtime preparation through data analysis and reporting.

-

You use sound judgement when configuring diagnostics, selecting analysis approaches, and setting simulation parameters.

-

You recognise when a decision involves project priorities, experimental scope, or resource conflicts and escalate it appropriately.

-

You collaborate effectively with internal science teams and external laser-facility partners.

-

You are keen to build expertise, share reliable procedures, and support more junior contributors as the team grows.

## Desirable Skills & Knowledge

-

Experience with laser compression experiments in high-energy-density physics, inertial confinement fusion, or a closely related field.

-

Knowledge of hydrodynamic instabilities, including Rayleigh–Taylor and Richtmyer–Meshkov instabilities.

-

Practical experience operating shock and compression diagnostics such as VISAR, SOP, and X-ray radiography.

-

Experience with radiation hydrodynamic modelling using FLASH or an equivalent multi-dimensional simulation code.

-

Strong data analysis skills using Python or a comparable scientific computing language.

-

Experience with HPC simulation workflows and computational experiment pipelines.

-

Familiarity with experimental design and shot planning for laser facilities.

-

Knowledge of Monte Carlo uncertainty analysis, Bayesian optimisation, reproducible scientific analysis, and systematic result documentation.

Focused Energy is an equal opportunity employer committed to creating an inclusive environment. Qualified applicants will receive consideration for employment without regard to race, color, religion, sex, sexual orientation, gender perception or identity, national origin, age, marital status, protected veteran status, or disability status.

Pursuant to the San Francisco Fair Chance Ordinance, Focused Energy will consider for employment qualified applicants with arrest and conviction records.

Compensation offered will be determined by factors such as location, level, job-related knowledge, skills, and experience. Certain roles may be eligible for incentive compensation, equity, benefits.

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
