# Senior Software Engineer: Agentic Engineering & Open Source (m/w/d)

Posted: 2026-08-13T19:00:32Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

B310 ist eine Software-Engineering-Beratung mit Fokus auf Open Source Software und Agentic Engineering. Wir suchen Verstärkung durch einen erfahrenen Senior Software Engineer (m/w/d) zum nächstmöglichen Zeitpunkt.

## Aufgaben

Du arbeitest mit uns an modernen Software- und Agentic-Engineering-Themen und beschäftigst dich damit, wie AI die Softwareentwicklung und bestehende Engineering-Prozesse verändert. Dabei testest und bewertest du aktuelle AI-Tools und neue Technologien, vergleichst unterschiedliche Setups für den produktiven Einsatz und entwickelst AI-gestützte Engineering-Workflows weiter. Darüber hinaus wirkst du an internen Tools, Open-Source-Projekten und der Optimierung unserer Tool-Landschaft mit. Je nach Interesse und Erfahrung kannst du außerdem bei der Vorbereitung und Durchführung technischer Workshops unterstützen.

## Qualifikation

Dein Profil

- Abgeschlossenes Studium, idealerweise im Bereich Informatik, Wirtschaftsinformatik oder vergleichbar

- **Mehr als 10 Jahre Berufserfahrung** im Software Engineering bzw. in der professionellen Softwareentwicklung

- Sehr gute Kenntnisse moderner Softwareentwicklung und Softwarearchitektur

- Fundierte Kenntnisse in mindestens einer modernen Programmiersprache

- Erfahrung mit **TypeScript oder Elixir** ist besonders willkommen – andere Programmiersprachen sind ebenfalls interessant

- Interesse/ Erfahrung an **AI, Agentic Engineering und Open Source**

- Offenheit für neue Technologien, Methoden und die Veränderungen, die AI für die Softwareentwicklung mit sich bringt

- Bereitschaft, über klassische Programmierung hinauszudenken und **neue Engineering-Ansätze** auszuprobieren

- Selbstständige, strukturierte und lösungsorientierte Arbeitsweise

- Idealerweise Interesse oder Erfahrung in der Durchführung technischer Workshops

- Sicherer Umgang mit macOS

- Du wohnst in Schleswig Holstein (oder planst schon aktiv den Umzug)

- keine Rüstungsprojekte

- **Deutsch auf muttersprachlichem Niveau und Englisch verhandlungssicher**

## Benefits

- Arbeit an aktuellen Themen rund um **AI und Agentic Engineering**

- Einsatz moderner AI- und Coding-Tools und Modelle wie **Claude Code, Codex, usw.**

- Mitarbeit an und Entwicklung von **Open-Source-Projekten**

- Hoher fachlicher Gestaltungsspielraum

- Zusammenarbeit mit einem erfahrenen Team aus dem Open-Source- und Software-Engineering-Umfeld

- Möglichkeit, neue Technologien und Arbeitsweisen aktiv mitzugestalten

- Firmenlaptop (Mac)

- Flexible Arbeitszeiten

- Home Office (bis zu 3 Tage die Woche)

B310 ist eine Software-Engineering-Beratung mit Fokus auf **Open Source Software und Agentic Engineering**. Unser Team verfügt über langjährige Erfahrung in der Entwicklung und Weiterentwicklung etablierter Open-Source-Lösungen, im Bildungsbereich sowie im Betrieb moderner Software-Systeme.

Wir wollen AI nicht einfach nur als zusätzliches Tool einsetzen, sondern gemeinsam herausfinden und gestalten, **wie sich professionelles Software Engineering durch AI nachhaltig verändert.**

Interesse?

Du hast mehr als zehn Jahre Erfahrung im Software Engineering, bist offen für die Veränderungen durch AI und hast Lust, neue Technologien und Engineering-Ansätze aktiv mitzugestalten?

Dann freuen wir uns darauf, dich kennenzulernen.

Schick uns eine kurze Nachricht mit deinem Lebenslauf und ein paar Sätzen dazu, warum die Position für dich interessant ist.

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
