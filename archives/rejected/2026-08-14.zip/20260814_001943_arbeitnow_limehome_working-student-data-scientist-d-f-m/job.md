# Working Student Data Scientist (d/f/m)

Posted: 2026-08-13T17:30:18Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**Help Shape the Future of Revenue Optimization as our Working Student Data Science (m/f/d)**

At Limehome, data is at the core of every decision we make. As a Working Student Data Science, you'll have the opportunity to work on real-world machine learning and statistical problems that directly impact our pricing strategy, revenue, and guest experience. You'll collaborate with experienced Data Scientists, Analysts, Engineers, and Revenue Managers while developing practical skills in data science, experimentation, and commercial decision-making.

This is an excellent opportunity to gain hands-on experience applying advanced analytics to one of the most exciting challenges in hospitality technology.

**How you’ll be hosting with heart:**

-

Support the development and continuous improvement of our pricing algorithms through data analysis and experimentation.

-

Prepare, clean, validate, and explore large datasets to uncover meaningful patterns and commercial opportunities.

-

Assist in developing, evaluating, and comparing statistical and machine learning models.

-

Support the design and analysis of experiments to measure the impact of pricing and product initiatives.

-

Build visualizations and reports that communicate insights clearly to technical and non-technical stakeholders.

-

Help automate recurring analyses and improve existing data science workflows.

-

Collaborate closely with Data Scientists, Data Engineers, Business Intelligence, Product, and Revenue Management on cross-functional projects.

-

Stay curious and continuously expand your knowledge of statistics, machine learning, AI, and modern analytical tools.

**What you need to shoot for the stars:**

-

Currently pursuing a Bachelor's or Master's degree in Data Science, Statistics, Mathematics, Computer Science, Physics or another quantitative field.

-

First hands-on experience with Python through university, internships, personal projects, or open-source contributions and basic knowledge of SQL and working with structured data.

-

Familiarity with common Python libraries such as Pandas, NumPy, Matplotlib, or Scikit-Learn.

-

Strong analytical thinking and a structured approach to problem-solving, backed by a solid understanding of probability, statistics, and basic machine learning concepts.

-

Curiosity about applying data science to real business challenges.

-

Excellent communication skills in English and the ability to explain analytical findings clearly.

**We're designed to stay because: (Intern/WS)**

-

**Onboarding and Feedback:** We make sure that you’ll have a smooth start through our well thought-out onboarding process. Develop yourself through constant feedback and peer reviews.

-

**Oneteam:** A transparent company culture with team stand-ups, regular all-hands, suite company events (Summer, Wiesn).

-

**Everything for our limehomies:** Up to 24 paid vacation days in a year, discounts at Urban Sports Club, support with mental health (Nilo.health), staycations in one of our suite Limehomes, and many more benefits.

-

**Competitive Salary:** live comfortably in Munich as a working student with our salary of €15/17 per hour, as a voluntary/mandatory intern with our salary of €2550/1800 per month.

-

**Free Drinks and Snacks**: We always provide fresh fruit, healthy snacks and chocolate, as well as juices and coffee.

**Who we are:**

Limehome is a leading tech-enabled operator in the hospitality industry offering functional, design accommodations across Europe. Using proprietary technology, Limehome delivers comfortable and convenient stays with a seamless digital guest experience for business and leisure travellers. Our vision is to be the first choice in travel for everyone, everywhere. By now, our portfolio consists of more than 10,000 apartments and hotel rooms under contract across 150 cities in 13 European countries.

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
