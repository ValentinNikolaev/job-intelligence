# Working Student Deposit Operations (m/f/d)

Posted: 2026-08-13T17:55:04Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Raisin is the world’s leading platform for savings and investment products. Founded in 2012, the **FinTech** connects consumers with banks in the EU, the UK and the US. This gives consumers **better interest rates** and banks a **diversified form of refinancing**. Our vision is to offer savings and investments without barriers and thus open up the global 160 trillion euro market.

Raisin currently employs more than 800 people from over 75 countries worldwide. Today, the platform holds over 80 billion euros in assets from **more than one million investors** which have accrued over 5 billion euros in returns.

**Team**

The Operations team is responsible for integrating banks into the world of digital deposits and improving their business on a daily basis by introducing them to new products or features.

In addition, we also build and strengthen relationships with our existing partners. Our tasks also include continuously ensuring smooth operations with deposit taking banks, investment products and distribution partners.

Our tasks are varied and range from meetings with existing deposit taking banks to daily operational and incident management tasks.

**Your Responsibilities**

- Support and manage standard operational ticket requests from deposit taking partner banks and internal stakeholders.

- Assist in conducting ledger-to-bank reconciliation by analysing data and creating reports for internal stakeholders as well partner banks.

- Create and maintain audit-proof Standard Operating Procedures, onboarding guides, and flowcharts as internal processes evolve.

- Proactively map out current manual workflows to identify bottlenecks and assist the team in proposing automation ideas.

- Handle daily written correspondence with partner banks and track compliance with our Service Level Agreements (SLAs).

**Your Profile**

- Currently enrolled in a Bachelor’s or Master’s program in Business Administration, Data Science, Economics, Law, Marketing, or a related field.

- Prior internship or practical experience in startups, consulting, or operations is a plus. However, early-career candidates and motivated fast-learners are strongly encouraged to apply.

- Proficient in Microsoft Excel for data organization and analysis.

- Comfortable balancing independent problem-solving with close team collaboration.

- Advanced proficiency (C1 level or higher) in both English and German. Additional European languages are a valuable plus.

**Join our mission, join our team – and grow with us!**

At Raisin, we care about each other and it is one of our top priorities to foster an open and caring environment in which everyone feels welcome and comfortable. Our culture is strongly driven by our ambitious team, which connects more than 75 different nationalities.

As part of our team, you will benefit from:

- Employee Development Budget of €400 and one full training day per year.

- Flexible working hours, home office and 20 vacation days per year.

- Do you miss being in the office? The Deutschland Ticket gets you there, which we subsidize with €25 per month.

- Enjoy more than 50+ different sports with Urban Sports Club: We subsidize your membership with more than €20 per month.

- Hungry all the time? Snacks, daily fresh fruit as well as drinks provided at the office.

[*Raisin Applicant Privacy Policy*](https://www.raisin.com/corporate/raisin-applicant-privacy-policy/)

We value diversity and the unique experiences each individual brings. If you’re excited about this role but don’t meet every requirement, we still encourage you to apply.

We are an equal opportunity employer and are committed to creating an inclusive environment for everyone, regardless of race, colour, ancestry, religion, sex, national origin, sexual orientation, age, citizenship, marital status, disability, or gender identity.

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
