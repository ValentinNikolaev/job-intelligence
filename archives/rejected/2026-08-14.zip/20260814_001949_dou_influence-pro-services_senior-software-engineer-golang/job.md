# Senior Software Engineer Golang

Posted: 2026-08-06

## Rejection

- Category: stale
- Reason: published_at 2026-08-06 is older than 7 days

**InfluenceProServices** builds services, tools, and infrastructure that drive marketing business growth and help teams scale efficiently. Every day, we tackle complex technical and operational challenges, enabling our customers to push boundaries and achieve greater success.
We are now looking for an experienced engineer with deep expertise in programming and software development. We expect the candidate to be proficient in designing and developing backend services and systems, with a focus on aligning them with long-term business vision and needs. You will help develop new directions, implement modern solutions, and strengthen the team’s expertise.

**Responsibilities**

- Design and build new backend services and systems using Go
- Develop and maintain internal services and tools to support product growth
- Lead projects and initiatives, from technical design to production deployment
- Collaborate closely with engineers, product managers, and infrastructure teams
- Oversee the full product delivery cycle: architecture, development, testing, and deployment
- Maintain technical documentation in Jira and Confluence
- Drive improvements in development processes and engineering culture

**Experience and skills**

- Strong experience in backend programming and software development, with hands-on project work in Go
- Proven ability to build resilient and scalable applications, applying SOLID principles and modern architectural practices
- Hands-on experience with cloud services (AWS, GCP, or Azure)
- Experience of integration and management of MySQL, PostgreSQL databases
- Proficiency with Docker and containerization
- Experience building and maintaining CI/CD pipelines and automating deployments
- Strong Linux knowledge, confident in the command line, with cloud infrastructure experience
- Ability to write clear, high-quality technical documentation
- Experience working with Jira and Confluence
- Strong teamwork and self-management skills

**Nice to have:**

- Hands-on experience deploying applications to Kubernetes using Helm and GitOps
- Familiarity with infrastructure-as-code tools (Terraform, Ansible, etc.)
- Knowledge of security best practices and DDoS protection
- Interest in learning and applying new languages and technologies

**What We Offer:**

- Paid vacation and sick leave
- The opportunity to work in a dynamic, multicultural team of professionals driven by a shared passion for product innovation and real impact
- A flat structure with no micromanagement and full ownership of your work
- A remote-first culture with flexible working hours
