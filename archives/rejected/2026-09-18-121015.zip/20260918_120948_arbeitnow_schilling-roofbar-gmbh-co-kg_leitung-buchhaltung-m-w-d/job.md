# Leitung Buchhaltung (m/w/d)

Posted: 2026-09-18T11:00:49Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Du bist jemand, der Buchhaltung nicht nur verwaltet, sondern wirklich versteht? Du arbeitest gerne eigenständig, bringst Struktur in Prozesse und möchtest Verantwortung übernehmen?

Wir suchen eine **Buchhaltungsleitung (m/w/d)**, die unsere Buchhaltung fachlich und operativ unterstützt. Dabei geht es nicht um reine vorbereitende Tätigkeiten – du buchst und kontierst selbstständig, behältst den Überblick über Zahlen und Prozesse und bist eine wichtige Schnittstelle im Unternehmen.

Wir suchen eine kommunikative Persönlichkeit, die fachliche Tiefe in der Buchhaltung mit einer offenen und verbindlichen Art verbindet. Du arbeitest gerne mit Menschen zusammen, übernimmst Verantwortung und bringst dich aktiv ein.

**Arbeitszeit:** Montag bis Freitag, 11:00 Uhr bis 20:00 Uhr

**Arbeitsmodell:** Vor Ort – Homeoffice ist für diese Position nicht vorgesehen.

## Aufgaben

- Eigenständige Bearbeitung der laufenden Finanzbuchhaltung

- Selbstständige Kontierung und Verbuchung von Geschäftsvorfällen

- Verantwortung für die Debitoren- und KreditorenbuchhaltungÜberwachung und Bearbeitung offener Posten

- Durchführung und Kontrolle von Buchhaltungsprozessen mit DATEVSicherstellung einer korrekten und strukturierten Buchführung

- Unterstützung bei administrativen Aufgaben und organisatorischen Themen

- Mitwirkung bei der Optimierung von Abläufen innerhalb der Buchhaltung

- Ansprechpartner für interne Rückfragen rund um buchhalterische Themen

## Qualifikation

- Mehrjährige Berufserfahrung in der praktischen Buchhaltung

- Nachweisbare Erfahrung mit eigenständigen Buchungen und Kontierungen

- Sehr gute Kenntnisse in DATEV (Voraussetzung)Sicherer Umgang mit dem Kontenrahmen SKR03

- Grundverständnis für Debitoren, Kreditoren und offene Posten

- Strukturierte, sorgfältige und zuverlässige Arbeitsweise

- Hohes Maß an Eigenständigkeit und Verantwortungsbewusstsein

- Kommunikationsstärke und Freude am Austausch mit anderen Teams

- Bereitschaft, neben buchhalterischen Themen auch administrative Aufgaben zu übernehmen

Wenn du nicht nur Zahlen verwalten möchtest, sondern eine Buchhaltung aktiv mitgestalten willst, freuen wir uns darauf, dich kennenzulernen.

Wir suchen keine Person für reine Zuarbeit – wir suchen jemanden, der Buchhaltung versteht, Verantwortung übernimmt und mit seiner Erfahrung einen echten Unterschied macht.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
