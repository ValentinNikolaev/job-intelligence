# Senior Forward Deployed Platform Engineer (m/w/d)

Posted: 2026-09-18T08:30:39Z

## Rejection

- Category: tech_stack
- Reason: role does not mention Go/Golang or PHP

As one of the leading German HealthTech companies, we are reshaping discharge management – technology-driven, patient-centered, and free from bureaucracy. In addition to our market-leading SaaS platform, we develop AI solutions that radically simplify processes in hospitals and for aftercare providers, relieve healthcare professionals, and refocus attention on patients. Today, we already connect two-thirds of all German hospitals with over 650 rehabilitation clinics and 25,000 nursing and homecare providers. With currently around 100 employees, we continue to grow – and we are looking for people with character who want to help us improve the healthcare system and solve administrative complexity across care journeys in Europe.

Our AI portfolio spans model development through to production inference at scale, in a highly regulated healthcare context. This role exists to make sure that infrastructure runs reliably, scales predictably, and gets AI engineers' work safely into production.

## What to expect

This is what you can expect from us as a Senior Forward Deployed Platform Engineer:

-

Purposeful work – your work keeps our AI portfolio reliable and performant for hospitals and aftercare providers who depend on it daily.

-

Company culture – we believe in flat hierarchies that promote high performance and strong team dynamics. We foster an environment characterized by mutual respect, loyalty, and recognition. Together, we strive for our goals – and expect the same from you.

-

Flexibility – want to pick up your child from daycare? Like to exercise during lunch? We'll support you. We are a remote-friendly company offering flexible working hours. Workations are also possible by arrangement.

-

Edenred card – which you can use according to your needs.

-

Extra vacation day – so you can celebrate your birthday with your loved ones, you'll have the day off.

This is how you will make an impact as a Senior Forward Deployed Platform Engineer:

-

Our AI portfolio needs to run reliably and perform well. Thus it has to be properly monitored.

-

Capacity needs planning, support scaling initiatives, and ensure our systems remain stable as the company grows.

-

SageMaker models need to be continuously delivered, following AWS' best practices.

-

AI engineers need assistance with productionalizing AI workloads end-to-end, from code to container build, and rollouts using optimal deployment strategies.

## How we build

We run a modern cloud-native stack to build, ship, and operate AI workloads reliably in a regulated healthcare environment.

-

Cloud: AWS (The European Sovereign Cloud partition)

-

Runtime: Kubernetes and Postgres

-

Inference: Bedrock, SageMaker, ClearML

-

Observability: Datadog, LangFuse, OTEL

-

CI/CD: GitHub Enterprise Cloud with Actions

-

Plus various auxiliary tools for security, compliance and operations: DockerHub, Google as IdP, SonarCloud, VPNs, QuickSight, CDN, Snowflake, ETLs, etc.

## Requirements

Here's how we picture you as our Senior Forward Deployed Platform Engineer:

These are the knowledge and skills you need:

-

Experience with AWS (CloudFormation, IAM, ECR, SageMaker, Bedrock, S3, SQS, DynamoDB, RDS, KMS).

-

Experience with Kubernetes (EKS) in production (kustomize, HPA and KEDA based autoscaling).

-

Experience deploying SageMaker models, setting up custom inference containers (HuggingFace and/or OSS model) and endpoints (provisioning, autoscaling, and blue/green rollouts).

-

Familiarity with observability & LLMOps best practices and solutions (Datadog, Langfuse, LLM/GenAI tracing, OTel, CloudWatch).

-

Proficiency in Python, specifically with FastAPI and async task management.

-

Knowing how to set up ML/LLM GPU inference on EKS (GPU-backed instances, Nvidia driver/plugin).

-

Ability to own technical decisions and collaborate directly with other teams.

-

Troubleshooting, RCA, and resolving problems. When things get stressful, you stay cool headed and work through issues step by step, asking for support from SMEs when needed.

-

Preference for writing over talking, resulting in clear, concise, yet complete documentation and asynchronous communications.

-

This is a cross-functional role bridging the gap between applications and the platform. Ability to both explain complex concepts clearly to non-domain experts, and extract information through well-formed questions during verbal communication, is a must.

Bonus points:

-

Healthcare or regulated-domain experience (e.g. ISO 27001, C5).

-

Self-hosting/home lab.

-

Nvidia Triton/vLLM or similar.

-

MLflow, Kubeflow, ClearML, DVC, Vertex AI.

-

Slack and GitHub automations (bots, workflows, apps, etc.).

This will help you decide if you want to join us – our values are:

-

Strong opinions, weakly held. We adapt, negotiate trade-offs, and reconsider decisions when necessary. We don't stick to one implementation – we re-evaluate and adjust as needed (including throwing away the old one).

-

Pragmatic choice of tools and avoidance of one-size-fits-all thinking.

-

Bringing professionalism and empathy to how you work with others.

-

Strong belief in solid technical fundamentals and preference for understanding and first principles over memorization.

-

Language proficiency (at least English, but the more, the better).

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
