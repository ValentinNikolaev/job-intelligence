# Controlling & Finanzbuchhaltung (m/w/d)

Posted: 2026-09-18T11:00:49Z

## Rejection

- Category: tech_stack
- Reason: role does not mention Go/Golang or PHP

## Über acáo GmbH

Die acáo GmbH entwickelt als Innovationsschmiede für FMCG bio-vegane und nachhaltige Lebensmittel- und Getränkeprodukte. Unser Sortiment, darunter acáo Original, acáo Mate, BIO ISO, Limissimo und possibilitea Eistee ist deutschlandweit in führenden Drogerieketten präsent. Zusätzlich vertreiben wir im E-Commerce unter der Marke Wildbär nachhaltige, plastikfreie Alltagsgegenstände.

Um unsere Finanzprozesse effizient zu steuern und unser Wachstum zu unterstützen, suchen wir Verstärkung im Bereich Controlling und Finanzbuchhaltung.

## Ihre Aufgaben

Als Teil unseres Teams übernehmen Sie zentrale Funktionen in der Finanzverwaltung und -analyse. Sie sind verantwortlich für die kontinuierliche Überwachung und Steuerung unserer finanziellen Performance.

-

Sie verantworten die laufende Finanzbuchhaltung, die unser Steuerberater outgesourced für uns übernimmt, und stellen die korrekte Abwicklung aller Buchungsvorgänge sicher.

-

Sie führen Soll-Ist-Vergleiche durch und analysieren Abweichungen, um Optimierungspotenziale aufzuzeigen.

-

Sie unterstützen bei der Budgetplanung und -kontrolle.

-

Sie wirken bei der Erstellung von Reportings und Analysen für die Geschäftsleitung mit.

-

Sie sind Ansprechpartner/in für externe Prüfer und Steuerberater.

## Was Sie mitbringen sollten

Wir suchen eine Persönlichkeit mit fundiertem Wissen in Finanzbuchhaltung und Controlling, die unsere Leidenschaft für schlanke Prozesse und hohe Automatisierung teilt.

-

Eine abgeschlossene kaufmännische Ausbildung oder ein Studium mit Schwerpunkt Finanzen/Controlling.

-

Mehrjährige Berufserfahrung in der Finanzbuchhaltung und im Controlling, idealerweise in einem FMCG-Umfeld (aber kein Muss).

-

Sicherer Umgang mit DATEV-Auswertungen und MS Excel.

-

Fundierte Kenntnisse im HGB.

-

Eine strukturierte, eigenverantwortliche Arbeitsweise und ein ausgeprägtes Zahlenverständnis.

-

Teamfähigkeit und Kommunikationsstärke.

## Unsere Benefits

Wir möchten, dass Sie sich bei uns wohlfühlen und Ihre Arbeit optimal gestalten können.

-

Ihre Arbeitszeiten können Sie flexibel gestalten, und die Möglichkeit zum Homeoffice wird durch eine entsprechende Ausstattung unterstützt.

-

Wir bieten einen barrierefreien Zugang zu unseren Räumlichkeiten.

-

Für berufliche Zwecke stellen wir Ihnen ein Firmenhandy und einen Firmenlaptop zur Verfügung.

-

Bei uns gibt es eine lockere Kleiderordnung, die zu einer entspannten Arbeitsatmosphäre beiträgt.

-

Regelmäßige Teamevents und Firmenfeiern fördern den Zusammenhalt.

-

Sie erhalten 28 Urlaubstage pro Jahr und einen unbefristeten Arbeitsvertrag nach einer 6-monatigen Probezeit bei einer 39-Stunden-Woche.

-

Kostenlose Getränke stehen Ihnen zur Verfügung.

## Was Sie nach Ihrer Bewerbung erwartet

Nachdem Sie Ihre Bewerbung eingereicht haben, prüfen wir sorgfältig, ob Ihre Qualifikationen und Erfahrungen zu dieser Rolle passen. Wir melden uns zeitnah bei Ihnen mit einem Update zum weiteren Prozess. Auch wenn Sie nicht alle Anforderungen zu 100% erfüllen, ermutigen wir Sie, sich zu bewerben, wenn Sie sich von der Aufgabe angesprochen fühlen.

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
