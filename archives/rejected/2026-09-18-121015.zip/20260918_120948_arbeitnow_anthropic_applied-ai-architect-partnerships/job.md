# Applied AI Architect, Partnerships

Posted: 2026-09-18T08:55:17Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

## **About Anthropic**

Anthropic’s mission is to create reliable, interpretable, and steerable AI systems. We want AI to be safe and beneficial for our users and for society as a whole. Our team is a quickly growing group of committed researchers, engineers, policy experts, and business leaders working together to build beneficial AI systems.

## **About Anthropic**

Anthropic’s mission is to create reliable, interpretable, and steerable AI systems. We want AI to be safe and beneficial for our users and for society as a whole. Our team is a quickly growing group of committed researchers, engineers, policy experts, and business leaders working together to build beneficial AI systems.

## **About the role**

As an Applied AI Architect on the Partnerships team at Anthropic, you will be a Pre-Sales architect focused on cultivating technical relationships with our Global and Regional System Integrators (GSIs/RSIs), and our cloud partners (AWS and GCP). You will strengthen our relationships with key partners to accelerate indirect revenue, enable their AI practices, and execute on long-term GTM strategy.

## **Responsibilities:**

-

**Strategic Technical Partnership**: Be a technical thought partner to the Anthropic GTM partnerships team, providing technical expertise to better understand the partner landscape, driving key strategic programs, and identifying opportunities to deepen partner technical capabilities. Embed with GSI and cloud partner technical teams to enable their AI practices, support troubleshooting, evangelize Anthropic in their developer communities, and serve as an escalation point for complex technical issues.

-

**Joint Solution Development:** Collaborate with partners to identify high value industry-specific GenAI applications, develop joint solutions and codify reference architectures / best practices to accelerate time to deployment

-

**Customer Deal Support: ** Intervene directly to unblock strategic customer deals where partners are the primary delivery vehicle, providing deep technical expertise and solution architecture guidance.

-

**Partner Ecosystem & Events: **Represent Anthropic at partner events such as GSI customer workshops, AWS summits, and industry conferences. Lead or support partner-specific developer events, hackathons, and technical enablement sessions, especially for technically native communities.Product Feedback: Validate and gather feedback on Anthropic's products and offerings, especially as they relate to partner use cases and deployment patterns, and deliver this feedback to relevant Anthropic teams to inform product roadmap and partner strategy.

## **You may be a good fit if you have:**

-

5+ years of experience in technical customer-facing/partner-facing roles such as Solutions Architect, Sales Engineer, Partner Sales Engineer, Technical Account Manager

-

Track record of successfully partnering with GSIs and/or cloud providers to solve complex technical challenges, from initial solution design through customer delivery

-

Exceptional ability to build relationships with and communicate technical concepts to diverse stakeholders to include C-suite executives, engineering & IT teams, and more

-

Strong presentation & technical communication skills with the ability to translate requirements between technical and business stakeholders

-

Experience designing scalable cloud architectures and integrating with enterprise systems

-

Familiarity with common LLM frameworks and tools or a background in machine learning or data science

-

Excitement for engaging in cross-organizational collaboration, working through trade-offs, and balancing competing priorities

-

A love of teaching, mentoring, and helping others succeed

-

Passion for thinking creatively about how to use technology in a way that is safe and beneficial, and ultimately furthers the goal of advancing safe AI systems

## **Logistics**

**Minimum education: **Bachelor’s degree or an equivalent combination of education, training, and/or experience

**Required field of study: **A field relevant to the role as demonstrated through coursework, training, or professional experience

**Minimum years of experience: **Years of experience required will correlate with the internal job level requirements for the position

**Location-based hybrid policy:** Currently, we expect all staff to be in one of our offices at least 25% of the time. However, some roles may require more time in our offices.

**Visa sponsorship:** We do sponsor visas! However, we aren't able to successfully sponsor visas for every role and every candidate. But if we make you an offer, we will make every reasonable effort to get you a visa, and we retain an immigration lawyer to help with this.

**We encourage you to apply even if you do not believe you meet every single qualification.** Not all strong candidates will meet every single qualification as listed. Research shows that people who identify as being from underrepresented groups are more prone to experiencing imposter syndrome and doubting the strength of their candidacy, so we urge you not to exclude yourself prematurely and to submit an application if you're interested in this work. We think AI systems like the ones we're building have enormous social and ethical implications. We think this makes representation even more important, and we strive to include a range of diverse perspectives on our team.

**Your safety matters to us.** To protect yourself from potential scams, remember that Anthropic recruiters only contact you ----- addresses. In some cases, we may partner with vetted recruiting agencies who will identify themselves as working on behalf of Anthropic. Be cautious of emails from other domains. Legitimate Anthropic recruiters will never ask for money, fees, or banking information before your first day. If you're ever unsure about a communication, don't click any links—visit [anthropic.com/careers](http://anthropic.com/careers) directly for confirmed position openings.

## **How we're different**

We believe that the highest-impact AI research will be big science. At Anthropic we work as a single cohesive team on just a few large-scale research efforts. And we value impact — advancing our long-term goals of steerable, trustworthy AI — rather than work on smaller and more specific puzzles. We view AI research as an empirical science, which has as much in common with physics and biology as with traditional efforts in computer science. We're an extremely collaborative group, and we host frequent research discussions to ensure that we are pursuing the highest-impact work at any given time. As such, we greatly value communication skills.

The easiest way to understand our research directions is to read our recent research. This research continues many of the directions our team worked on prior to Anthropic, including: GPT-3, Circuit-Based Interpretability, Multimodal Neurons, Scaling Laws, AI & Compute, Concrete Problems in AI Safety, and Learning from Human Preferences.

## **Come work with us!**

Anthropic is a public benefit corporation headquartered in San Francisco. We offer competitive compensation and benefits, optional equity donation matching, generous vacation and parental leave, flexible working hours, and a lovely office space in which to collaborate with colleagues. **Guidance on Candidates' AI Usage:** Learn about [our policy](https://www.anthropic.com/candidate-ai-guidance) for using AI in our application process.

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
