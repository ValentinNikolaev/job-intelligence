# Werkstudent Content (m|w|d) - ca. 15 Wochenstunden

Posted: 2026-09-18T11:00:48Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

## Deine Rolle bei uns

Als Werkstudent:in im Bereich Content hilfst du uns, unsere Expertise in Marketing, Automation und KI sichtbar zu machen. Du bereitest komplexe Themen verständlich und ansprechend auf – von Blogartikeln über LinkedIn-Posts bis hin zu Whitepapers und Case Studies – und füllst unsere Marke mit Leben. So trägst du dazu bei, dass unser Wissen bei den richtigen Menschen ankommt und Wirkung entfaltet.

**Was Dich bei uns erwartet**

- Echte Verantwortung und die Möglichkeit, eigene Ideen umzusetzen

- Einblicke in die Arbeit an der Schnittstelle von Marketing, Technologie und KI

- Arbeiten mit modernen Tools und KI in der Praxis, nicht nur in der Theorie

- Flache Hierarchien, kurze Entscheidungswege und ein starkes Team

- Flexible Arbeitszeiten, die sich gut mit deinem Studium vereinbaren lassen

- Persönliche und fachliche Weiterentwicklung und Raum, dazuzulernen

- Faire Vergütung und die Option auf eine längerfristige Zusammenarbeit

## Aufgaben

- Recherche, Konzeption und Erstellung von Content für unsere Kanäle (Blog, LinkedIn, Newsletter, Website)

- Aufbereitung komplexer Themen aus Marketing, Automation und KI in verständliche, ansprechende Inhalte

- Unterstützung bei der Content-Planung und Pflege unseres Redaktionskalenders

- Einsatz von KI-Tools für eine effiziente Content-Produktion (z. B. Ideenfindung, Entwürfe, Optimierung)

- Mitarbeit an Case Studies, Whitepapers und Präsentationen

- Unterstützung bei SEO-Optimierung und der Erfolgsmessung unserer Inhalte

## Qualifikation

- Eingeschriebene:r Student:in, idealerweise in Kommunikation, Marketing, Medien, Journalismus oder einem verwandten Studiengang

- Ausgeprägtes sprachliches Gespür und Freude am Schreiben (sehr gutes Deutsch in Wort und Schrift)

- Erste Erfahrung im Erstellen von Content (z. B. durch Praktika, Nebentätigkeiten oder eigene Projekte) von Vorteil

- Echtes Interesse an Marketing, Digitalisierung und KI

- Offenheit für den Einsatz von KI-Tools im Content-Alltag

- Selbstständige, strukturierte Arbeitsweise und ein Auge für Qualität

- Verfügbarkeit von 10 - 15 Stunden pro Woche (nach Absprache)

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
