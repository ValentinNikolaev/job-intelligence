# Technical Product Research Intern in Agentic Payments / Stablecoins / Web3

Posted: 2026-09-18T09:30:53Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**About us**

We are a regulated fintech from Hamburg building the compliant payment layer between AI agents and data providers. Our infrastructure enables agents to discover, pay, and consume data autonomously — using e-money tokens, the x402 protocol, and real-time euro settlement. Backed by the City of Hamburg, MiCAR-compliant, PSD2-regulated.

**The role**

We're looking for a proactive developer-researcher in Berlin who sits at the intersection of code and market intelligence. You won't just research, you'll build prototypes, test integrations, and shape how we position ourselves in a fast-moving market. This role is ideal for someone who likes digging into new protocols, testing APIs hands-on, and turning findings into actionable recommendations.

## Tasks

- Map the agentic payments landscape: who are the players, what protocols exist (x402, MCP, Skyfire, etc.), where are the gaps

- Identify and evaluate potential data provider partners (weather, finance, geo, pricing APIs) for our pilot program

- Research and categorize data providers across verticals — build a product matrix comparing pricing models, API quality, MCP readiness, and agent compatibility

- Build small proof-of-concepts and test integrations with MCP servers and data provider endpoints

- Analyze competitor products, pricing models, and regulatory positioning

- Research how LLM platforms (Anthropic, OpenAI, etc.) are integrating external data sources and payment layers

- Synthesize findings into clear internal memos and pitch materials — no 50-page reports, short and actionable

- Proactively flag opportunities, risks, and potential partners without waiting to be asked

## Requirements

- Currently studying computer science, fintech, business informatics, or similar — or recently graduated

- Can write code: comfortable with APIs, HTTP requests, basic scripting (Python, TypeScript, or similar)

- Genuinely curious about AI agents, crypto payments, and fintech regulation — not just checking a box

- Proactive by default: you see something interesting, you dig in and share it before anyone asks

- Strong English communication skills, written and verbal

- Based in Berlin or willing to be

- Bonus: experience with blockchain/stablecoins, MCP, or fintech regulation

## Benefits

- Direct access to the founding team — your work shapes product and strategy decisions

- Real ownership: your research and prototypes go into production, not a drawer

- A front-row seat to the intersection of AI, payments, and European regulation

- Flexible hours (Werkstudent: 15-20h/week, Praktikum: full-time for 3-6 months)

- Office in Berlin, remote flexibility

**Send a short email with your CV and a few sentences on why this excites you. No cover letter template, just tell us what you'd research first if you started tomorrow.**

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
