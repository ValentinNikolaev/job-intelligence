# Senior Design Engineer, Design Operations: AI-Powered Design Platform

Posted: 2026-09-18T08:55:22Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Celonis is the trusted platform to industrialize Enterprise AI. At our core is the Celonis Context Model — which combines process data, business knowledge, and intelligence into a living digital twin of the enterprise that AI can actually understand, turning AI's operational blind spots into operational clarity. World's leading companies trust Celonis and its global ecosystem of partners to make their AI agents, people, systems, and processes work together, achieving transformational outcomes. We believe there's a massive opportunity to unlock global productivity and sustainability by giving AI the context to understand how every business process really works. Join our mission to make processes work for people, companies, and the planet.

**Why this role matters**

Great design at enterprise scale isn't just about craft, it's about the tooling, automation, and guardrails that let a design org move fast and stay consistent. At Celonis, that machine now runs on AI: designers use AI coding agents and generation tools every day, and our design system is being made agent-ready so those tools produce on-brand, accessible work by default.

This role sits at the intersection of design, engineering, and product. You'll design and build the platform that makes all of this work, the internal tooling, automation, and agent-pipeline infrastructure behind our design practice, bringing real UX judgment to tools the design org actually uses, and governing how AI is used safely and measurably. It's a senior, hands-on role for someone who designs and builds tools, not just processes.

**About the team**

You'll join the team that owns Celonis's design system and the operations behind how design gets done. We turn a talented group of designers into a high-performing, consistent practice — and increasingly, we integrate AI tooling into every step of the workflow without sacrificing quality, security, or brand integrity.

**What you'll do**

- Design and build internal tools and automations with strong UX, so the design org's own tooling is genuinely usable, not just functional, using TypeScript/JavaScript, Python, APIs, and the Figma plugin/REST APIs.

- Engineer the agent pipeline: stand up and maintain the MCP servers, context pipelines, and integrations that connect the design system to AI coding agents (Cursor, Claude Code, v0, Copilot).

- Automate governance-as-code: build CI checks, release automation, and policy enforcement so standards are guardrails in the pipeline rather than docs nobody reads.

- Own and govern the AI tool stack: evaluate, integrate, license, and roll out tools, and partner with security and legal on data/IP review and human-in-the-loop checkpoints.

- Instrument and report on impact: build telemetry and dashboards for design-system and AI-tool adoption, cycle time, and quality that leadership actually uses.

- Collaborate with designers, PMs, and engineers to derive and evolve the design system and the workflows around it.

- Build prompt and template infrastructure, reusable prompts, specs, and starter kits, so AI-assisted quality is consistent across the org.

- Set tooling and operations standards, lead platform initiatives, and mentor designers and engineers across the practice.

**What you'll bring**

- Around 5–8 years across design engineering, front-end, design-systems tooling, or platform/internal-tools engineering, with genuine design/UX sensibility, not engineering-only.

- Good UX instincts: you can design a usable tool and translate ambiguous needs into thoughtful solutions, with a foundation in HTML/CSS and front-end craft.

- Strong engineering skills, comfortable building real tools and automations (TypeScript/JavaScript and/or Python), working with APIs, CI/CD, and integrations.

- Solid working knowledge of Figma at an organizational level and its plugin/REST APIs.

- A track record of measurably improving how a design or product team works through tooling and automation.

- Hands-on fluency with AI tooling and a thoughtful, responsible point of view on governing it at work.

- A strong product mindset and bias toward ownership, plus the communication and leadership of a senior IC.

**Bonus points**

- Experience building or operating MCP (Model Context Protocol) servers or similar AI integration infrastructure.

- Experience standing up AI tool governance (access, licensing, security/IP review, usage policy) at org scale.

- Familiarity with design tokens and Code Connect, including Angular/TypeScript and CSS custom properties, enough to keep the agent-ready pipeline healthy.

- Experience building dashboards / telemetry for tooling adoption and impact.

- Background supporting design in complex B2B / enterprise or data-heavy environments.

**How we work**

This is a senior role: you'll own major areas of our tooling and platform with full autonomy, design and build with a high bar, set the standards others rely on, lead initiatives, and mentor. We value people who bring AI into the workflow thoughtfully: faster and safer, never at the cost of quality or trust.

197289803

**What Celonis can offer you:**

- Pioneer Innovation: Work with the global leader in Process Mining and the Process Intelligence Graph to shape the future of AI-driven business operations.

- Ownership from Day 1: Every full-time "Celonaut" is an owner, receiving Restricted Stock Units (RSUs) and merit-based refresh grants.

- Unrivaled Family Support: Benefit from our inclusive parental leave policy—24 weeks of fully paid leave for primary carers and 12 weeks for supporting carers, available from your first day of employment.

- Work-Life Integration: Enjoy Unlimited PTO (in applicable regions) and generous PTO globally, as well as a flexible hybrid work model that balances remote focus with vibrant office collaboration.

- Continuous Growth: Elevate your skills through our 70-20-10 learning framework, mentorship programs, and access to a dedicated learning platform.

- Holistic Well-being: Prioritize your health with subsidized Wellhub memberships, mental health counseling, and dedicated "Wellness Weeks" that prioritize work/life balance.

- Drive Sustainability: Participate in annual Impact Days, where you receive paid time off to volunteer for community and environmental causes with your local office, or virtually.

- Global Inclusion & Belonging: Find community through our Inclusion Think Tank and participate in our annual Inclusion Days, ensuring every voice is heard and valued.

- Value-Driven Impact: Join a mission-led organization where our core values—Live for Customer Value, The Best Team Wins, We Own It, and Earth Is Our Future—drive every decision.

**About Us:**

Celonis is the trusted platform to industrialize Enterprise AI, empowering organizations to analyze, design, and operate AI-driven processes. The Celonis Platform is powered by the Celonis Context Model, which combines process data, business knowledge, and intelligence to create a living digital twin of the enterprise that AI can understand — turning AI’s operational blind spots into operational clarity. Industry-leading companies around the world trust Celonis and its global ecosystem of partners to make their AI agents, people, systems, and processes work together, achieving transformational outcomes. Celonis is headquartered in Munich, Germany, and New York City, USA, with more than 20 offices worldwide.

Get familiar with the Celonis Process Intelligence Platform by watching this [video](https://www.youtube.com/watch?v=YR5oRJGhJYg&list=PLuVor-ZUD4pnM6G33C5D0tjXUvlTPYBRe).

**Celonis Inclusion Statement:**

At Celonis, we believe our people make us who we are and that “The Best Team Wins”. We know that the best teams are made up of people who bring different perspectives to the table. And when everyone feels included, able to speak up and knows their voice is heard - that's when creativity and innovation happen.**
**

**Your Privacy:**

Any information you submit to Celonis as part of your application will be processed in accordance with Celonis’ [Accessibility and Candidate Notices](https://www.celonis.com/careers/candidate-notices)

By submitting this application, you confirm that you agree to the storing and processing of your personal data by Celonis as described in our [Privacy Notice for the Application and Hiring Process](https://www.celonis.com/careers/privacy-notice/).

Please be aware of common job offer scams, impersonators and frauds. Learn more [here](https://www.celonis.com/careers/fraud-alert/).

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
