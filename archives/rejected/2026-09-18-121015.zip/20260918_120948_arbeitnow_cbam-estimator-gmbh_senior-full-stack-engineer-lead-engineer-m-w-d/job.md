# Senior Full Stack Engineer / Lead Engineer (m/w/d)

Posted: 2026-09-18T09:30:53Z

## Rejection

- Category: tech_stack
- Reason: role does not mention Go/Golang or PHP

Wir sind CBAM Estimator – ein junges SaaS-Unternehmen mit Sitz in Stuttgart. Unsere Mission ist es, Unternehmen dabei zu unterstützen, die Anforderungen des EU Carbon Border Adjustment Mechanism (CBAM) korrekt, effizient und skalierbar umzusetzen.

Dafür entwickeln wir moderne Web-Plattformen, mit denen unsere Kunden die Auswirkungen, Pflichten und Kosten des CBAM fundiert analysieren und realistisch einschätzen können. Zu unseren Kunden zählen internationale Industrie- und Handelsunternehmen, die auf verlässliche Daten, saubere Prozesse und Planungssicherheit angewiesen sind.

Wir sind ein junges, internationales Team mit unterschiedlichen Hintergründen – von IT über Emissionsberechnung und Mathematik bis hin zu Business. Uns verbindet der Anspruch, komplexe Regulierung pragmatisch und nachvollziehbar lösbar zu machen. Wir arbeiten datengetrieben, direkt und ohne große Konzernbürokratie. Verantwortung zu übernehmen, Dinge zu hinterfragen und schnell umzusetzen gehört für uns ganz selbstverständlich zum Alltag.

## Aufgaben

- Du übernimmst Verantwortung für komplette Features: von der Konzeption über Implementierung bis hin zum Deployment und Betrieb.

- Du arbeitest mit modernen Web-Technologien (Next.js, TypeScript, TailwindCSS) und entwickelst dabei skalierbare, wartbare Anwendungen.

- Du konzeptionierst saubere Architekturen, modulare Systeme und APIs mit Fokus auf Performance, Sicherheit und Stabilität.

- Du gestaltest und pflegst CI/CD-Pipelines und DevOps-Workflows (z. B. mit GitHub Actions), sorgst für automatisierte Tests, Review-Prozesse und stabile Deployment-Strategien.

- Du bringst Best Practices für Security, Performance und Skalierbarkeit mit und setzt diese konsequent um, um produktionsreife Systeme zu liefern.

- Du übernimmst Aufgaben in der Projektleitung: strukturierst Anforderungen, priorisierst Tasks, koordinierst Abstimmungen und behältst Timelines im Blick.

## Qualifikation

- Mehrjährige praktische Erfahrung als Software Engineer in produktiven Web-Anwendungen.

- Sehr solides Fundament in TypeScript und modernen JavaScript-Ökosystemen.

- Erfahrung im Entwurf und in der Weiterentwicklung größerer Codebases mit klaren Struktur- und Qualitätsansprüchen.

- Routine im Arbeiten mit verteilten Systemen, mehreren Environments und stabilen Release-Prozessen.

- Erfahrung im Abwägen von Qualität, Geschwindigkeit und Komplexität bei realen Produktanforderungen.

- Erfahrung in der fachlichen Anleitung von Entwickler:innen, inkl. Mentoring, Feedback und konstruktiven Code Reviews.

- Klare, strukturierte Kommunikation – auch bei komplexen technischen Themen und gegenüber Nicht-Tech-Stakeholdern.

- Eigenverantwortliche, verlässliche Arbeitsweise und ein ausgeprägtes Qualitätsbewusstsein.

## Benefits

- Home Office / Remote-First

- Well Pass

- Attraktive, marktgerechte Vergütung

- Flexible Arbeitszeiten

Wenn du Lust hast, Verantwortung zu übernehmen und ein komplexes Produkt nachhaltig mitzugestalten, freuen wir uns, von dir zu hören!

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
