# Senior Content & Editorial Manager (m/w/d)

Posted: 2026-09-18T11:00:48Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

## Wir stellen uns vor!

Als kompetenter Dienstleister rund ums Edelmetall begleitet die Dr. Bernhard Burger AG Goldschmiede, Silberschmiede, Juweliere und Industriebetriebe in allen Bereichen ihres Handwerks. Unser Marketingteam macht diese Arbeit sichtbar — mit Kampagnen, Inhalten und Formaten entlang des gesamten Edelmetallkreislaufs.

Jetzt bauen wir unseren Content-Bereich aus: Wissensformate, Videoreihen, Interviews aus der Werkstatt und ein verlässliches Grundrauschen über alle Kanäle — mit echtem Mehrwert für unsere Branche. Dafür suchen wir Sie: jemanden mit einem geschulten Auge für guten Content, der die Qualität unserer Inhalte in Wort, Bild und Video verantwortet. Die großen Ziele und Prioritäten gibt die Marketingleitung vor — die Contentstrategie entwickeln Sie mit, bringen die richtigen Themen auf die richtigen Kanäle und sorgen dafür, dass alles, was rausgeht, unserem Anspruch genügt.

Wir haben die Themen, die Kanäle und den Zugang zu echtem Handwerk — was fehlt, ist jemand, der beim Content den Hut aufhat. Sie können hier gestalten, und deshalb sollen Sie gestalten können: Redaktionsplan, Qualitätsmaßstab und Freigaberoutine entstehen mit Ihnen. Wir erwarten Handwerk, eigene Ideen und echte Lust darauf, einen Bereich zu prägen, statt ihn zu verwalten. Wenn Sie das reizt, freuen wir uns darauf, Sie kennenzulernen.

## Welche Aufgabenfelder erwarten Sie?

**» Qualitätsverantwortung für unseren gesamten Content:** Sie stehen dafür ein, dass alles, was rausgeht — Wort, Bild, Video — unserem Anspruch genügt. Nach einer kurzen Kalibrierungsphase mit der Marketingleitung geben Sie reguläre Inhalte eigenständig frei. Den Qualitäts- und Tonalitätsmaßstab dahinter schreiben Sie auf, damit auch Externe überprüfbar daran arbeiten.

**» Aufbau und Führung von Redaktionsplan und Themenspeicher** mit mindestens sechs Wochen Vorlauf über Blog, Social Media, Newsletter, Website und unseren Wissensbereich: Themenplanung und die Weiterentwicklung unserer Contentstrategie entstehen gemeinsam mit der Marketingleitung — welches Format auf welchen Kanal gehört und wie Inhalte weiterverwertet werden, entscheiden und verteilen Sie.

**» Eigene Umsetzung nach Ihren Stärken — Texten im Fokus:** Blogbeiträge, Website-Texte, Whitepaper (etwa quartalsweise), Newsletter und Social-Texte schreiben und redigieren Sie selbst, dazu redaktionelle Konzepte, Drehbücher und Briefings. Liegt Ihre Stärke auch in Design, Foto oder Video, setzen Sie dort ebenfalls selbst um — und alles davon können Sie jederzeit an andere im Team oder unsere Freelancer geben. Sie entscheiden je Aufgabe, ob Sie produzieren oder produzieren lassen.

**» Planung und Umsetzung von Videodrehs und Shootings:** Themenentwicklung, Drehbücher, Organisation von Protagonisten und Video-Freelancern, Begleitung vor Ort und Abnahme der Post-Production — gedreht wird im Mietstudio und direkt bei unseren Kunden in ihren Werkstätten und Betrieben. Drehtage fallen derzeit etwa einmal im Monat an, meist ein bis drei Tage am Stück, Tendenz steigend.

**» Steuerung der Gewerke und Freelancer:** Was Sie nicht selbst umsetzen, briefen Sie präzise, koordinieren die Spezialisten und nehmen Ergebnisse fachlich fundiert und CD-konform ab — die Qualität trägt in jedem Fall Ihre Handschrift.

**» Entwicklung eigener Content-Formate und -Serien;** Interviews mit Kunden und Fachleuten führen Sie selbst.

**» Inhaltliches SEO:** Sie schreiben und optimieren Inhalte SEO-bewusst und arbeiten mit Keyword-Vorgaben — Recherche und Briefings bauen Sie sich mit der Zeit selbst auf. Technisches SEO und Tracking liegen nicht bei Ihnen.

**» Redaktionsverantwortung für alle Kanäle,** über die wir Content distribuieren — von Blog, Newsletter und Website bis Social Media: Wochenplan und Freigaben liegen bei Ihnen. Die laufende Ausspielung verantworten Sie zu Beginn selbst.

**» Content-Performance:** Die monatliche Datenauswertung bekommen Sie aufbereitet — daraus leiten Sie gemeinsam mit der Marketingleitung Anpassungen an Themen, Formaten und Kanälen ab. Die Auswertung selbst gehört nicht zu Ihrer Rolle.

**» Entwicklungsperspektive Presse:** In einer zweiten Stufe — frühestens nach erfolgreicher Einarbeitung — übernehmen Sie die operative Pressearbeit mit Themenplanung, Entwürfen, Presseverteiler und Koordination.

**» Zuarbeit zu Messen und Branchenterminen:** Ankündigungen, Materialien und Nachberichte kommen von Ihnen — die Organisation der Termine selbst bleibt bei der Marketingleitung.

**Was nicht in Ihrer Rolle liegt:** die übergeordneten Marketingziele, Marke und CI (Marketingleitung) · technisches SEO, Tracking und Reporting · Newsletter-Infrastruktur und CRM-Strecken · der Programmbetrieb unserer Weiterbildungsformate · Websiteentwicklung.

## Was zeichnet Sie aus?

» Ein geschultes Auge für guten Content über Text, Bild, Design und Video: Sie beurteilen Arbeiten fachlich, briefen präzise, erkennen, wann etwas noch nicht gut genug ist, und können Ihre Entscheidungen begründen.

» Sehr gutes, eigenes Texten als Kern Ihres Handwerks (bitte mit Arbeitsproben): Sie machen aus Rohmaterial veröffentlichungsfähige Texte. Kommt gestalterisches Können dazu — ein Gespür für Bild, Layout und Video —, ist das für uns die stärkste Kombination. Art Director oder Kameraprofi müssen Sie deshalb nicht sein.

» Mehrjährige Berufserfahrung in der Steuerung mehrerer Formate und Gewerke, idealerweise aus einer Agentur im Projekt- oder Account-Management — dazu exzellentes Deutsch.

» Sicherheit mit erklärungsbedürftigen Themen: Sie arbeiten sich selbstständig in technische Inhalte ein und bereiten sie für unterschiedliche Zielgruppen auf. SEO-Grundverständnis setzen wir voraus, eigenständige Keyword-Recherche können Sie bei uns vertiefen.

» Producing- und Produktionsverständnis: Drehs und Shootings konzipieren, planen, begleiten und fachlich abnehmen — dafür bringen Sie gelegentliche Reisebereitschaft mit.

» Inhalte in WordPress strukturiert einstellen und pflegen (Webentwicklung brauchen Sie nicht) und strukturiertes Arbeiten in Projektmanagement-Tools (z. B. Asana).

» Kommunikationsstärke, Freude an Interviews und Gesprächen mit Kunden — und die Haltung, Entscheidungen zu begründen, statt sie nur zu treffen.

» Nice-to-have: vertiefte eigene Umsetzungspraxis in Design, Foto oder Video, Schnitt-Grundlagen, Erfahrung mit mehrsprachigen Inhalten (DE/EN/NL) oder Affinität zu Handwerk und Schmuck.

## Worauf Sie sich freuen können:

**» Gestaltungsspielraum:** Sie bauen Ihren Bereich aktiv mit auf — flache Hierarchien, kurze Entscheidungswege, familiäre Atmosphäre.

**» Modernes Arbeitsumfeld:** helles, modernes Marketingbüro, in das wir gerade erst umgezogen sind — für Produktionen nutzen wir ein Mietstudio und drehen vor Ort bei unseren Kunden.

**» Flexibles Arbeiten:** Laptop für Remote-Arbeit (mind. 3 Tage vor Ort, 2 remote), Gleitzeit, 30 Tage Urlaub.

**» Ausstattung:** höhenverstellbare Arbeitsplätze, moderner Hardware-Standard und umfangreiches Equipment für die Contentproduktion.

**» Entwicklung:** vielfältige Weiterbildungs- und Entwicklungsmöglichkeiten in einem wachsenden Familienunternehmen.

**» Teamkultur:** fester monatlicher Austausch im Marketingteam, gemeinsame Remote-Tage im Coworking Space — auch mal in einer anderen Stadt —, dazu Mitarbeiterevents und Grillen.

**» Kleinigkeiten, die den Tag besser machen:** kostenloser Kaffee, Obstkorb und Getränke.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
