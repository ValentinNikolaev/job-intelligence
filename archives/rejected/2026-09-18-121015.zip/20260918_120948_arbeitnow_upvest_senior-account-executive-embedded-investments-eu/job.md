# (Senior) Account Executive, Embedded Investments - Europe (f/m/d)

Posted: 2026-09-18T08:40:12Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

At Upvest, we are on a **mission to make investing as easy as spending money**. Upvest empowers businesses to offer a wide range of investment products and the best experience in the field of capital market investment and retirement planning. Upvest’s Investment API is easy to integrate so that fintechs and financial institutions can save resources and fully focus on their core business.

We are proud to partner with Europe’s leading Fintechs and financial institutions such as DKB, Revolut, N26 and Raisin. Founded in 2017 by Martin Kassing, Upvest now brings together over 270 talented professionals from more than 70 nationalities. Upvest is backed by **€280M in total funding** from world-class investors, including **BlackRock, Tencent, Sapphire Ventures, and Bessemer Venture Partners, Earlybird, Notion Capital, and Motive**. Our latest **€105M funding round in March 2026** - led by Sapphire and Tencent - serves as a massive catalyst for our growth, allowing us to offer premier investment experience.

#
**About the role:**

**The Growth team at Upvest is driving our go-to-market activities**, spanning across Marketing, Sales and Customer Success. Our mission is to become the Investment-as-a-service category leader for Europe's leading brokers, banks, wealth managers, and non-financial platforms. We're honoured to work with some of Europe's leading brands in a fast moving and expanding market already and are just getting started.

As Upvest enters the next stage of growth, we are seeking a highly motivated and outcome-driven **Account Executive **to join us and build out our **Embedded Investments segment**. All our team efforts are centred around the client and give you the opportunity to work with high autonomy coupled with inspirational leadership. Working in the Growth team combines impactful work with a relaxed and fun atmosphere. We have established strong practices around feedback, team health and social events.

**Embedded finance is a €100bn+ opportunity** in the EU and UK by 2030 and is rapidly expanding beyond payments and lending. Investments are the next frontier: payment apps, online retailers, social networks, telecoms, spend management, and a new generation of AI platforms just to name a few all reach millions of users who expect financial services to be simple and frictionless. For them, embedded investing is a new revenue stream and a powerful way to strengthen engagement and loyalty. In Europe, this market is largely untapped.

In this role, you will **work directly with our Director of Growth **[**Alexander Reichhardt**](https://www.linkedin.com/in/alexander-reichhardt-87b6a9b0/)** **to open that market for Upvest. You will sell to companies who have not launched an investment products before, which means translating what our Investment API does into their language: product, growth, and user engagement. This is an opportunity to build a segment from the ground up, own sizeable client relationships from first contact to signature, and accelerate Upvest's path to 100m+ end users.

# **What you’ll do:**

-

Own the cross-functional sales cycle until contract closing to meet or exceed sales targets

-

Build our embedded pipeline across Europe by identifying and opening platforms outside traditional financial services, from consumer apps, retailers and telecoms to B2B software and AI platforms

-

Build the business by consultatively understanding our clients' needs and developing compelling sales materials that communicate the Upvest value proposition effectively to product, growth and commercial stakeholders

-

Shape our embedded proposition together with Product, Solutions Engineering and Partnerships by bringing back what plug-and-play needs to mean for clients without in-house investment expertise

-

Build and maintain strong client and industry relationships through regular client calls and networking events

-

Enable a seamless client onboarding experience via effective communication with our implementations team

# **What you bring:**

-

**Experience:** You have 2–4+ years of experience in sales, partnerships, or business development, ideally in a B2B environment, with experience working with API-based products and exposure to financial services. Alternatively, you have 2–4+ years of experience at a specialised financial services consultancy, working on IT infrastructure-related projects, ideally within the investment services sector

-

**Closing track record:** You have successfully taken complex commercial or partnership deals from initial discussions through to signature and launch, ideally with a track record of consistent quota attainment. You are seeking an individual contributor role and are genuinely motivated by selling and closing deals rather than managing a sales team

-

**Industry Exposure:** You have previous experience in financial services, with a strong interest in software- and infrastructure-as-a-service products (e.g., BaaS and embedded payments), and a genuine curiosity about investments and securities trading

-

**Client-centric sales:** You have demonstrated expertise with B2B sales methodologies, such as solution/consultative selling as well as practical application of industry best practices, always starting with the clients needs'

-

**Modern, AI-enabled selling:** You work data- and KPI-driven, apply clear qualification frameworks to allocate your time, and use AI actively to increase your coverage and throughput

-

**Stakeholder management Skills:** You have demonstrated strong leadership skills, are able to communicate well with different stakeholder groups, from product and growth teams to legal, risk and compliance, and are not afraid to challenge assumptions internally or externally.

-

**Negotiation Skills:** Strong relationship-building and negotiation skills, with the ability to create trust, effectively handle objections and present compelling pitches.

-

**Project Management:** Hands-on, proactive ownership of complex projects, including ensuring consistent and reliable communication with multiple client and internal stakeholders and diligent internal documentation.

# **It’s great if you also have:**

-

Experience selling to banks or wealth managers

-

Industry Knowledge - thorough understanding of the investment industry, its current trends and competitive landscape

-

Professional Network: Strong professional network in the investment industry

-

Location Preference: Preference for candidates located in Berlin / remote Germany and fluent in German (C2 or native)

# **How we Upvest in you:**

-

**Best-in-class AI tools: **Every Upvenger has €20,000 per year to spend on the best AI tools available — so you're always working with the most powerful models and tooling on the market

-

**Impact-driven work:** We’re building the infrastructure that will power the future of investing in Europe. It’s complex, ambitious, and meaningful. You’ll work with modern technologies and create something entirely new. No legacy systems, no limits

-

**Wellbeing:** Recharge with 30 days of annual leave and maintain a healthy lifestyle with sports benefits. Access confidential professional coaching and enjoy the flexibility to work remotely abroad for up to 183 days a year. Recharge with UpRest, a one-month fully paid sabbatical after every 4 years of working at Upvest

-

**Development:** Growth is in our DNA. Each Upvenger has access to a personal development budget and the freedom to decide how to use it

-

**Flexible work environment:** Work from any of our hubs in Berlin, London or Tallinn hybrid or remotely across Europe, depending on the role. We give you the choice and budget to work where you’re most comfortable and productive, either at home or in the office. You choose

-

**Compensation and equity:** We believe that all Upvengers contribute to our success and deserve a competitive, above-market salary and a participation in our employee equity program

-

**Team celebrations:** Participate in company-wide events, such as UpFest, dinners, offsites and our Holiday party, to connect with colleagues and celebrate our achievements

-

**Inclusion**: We’re committed to a culture where everyone belongs and thrives. Our Employee Resources Groups foster inclusion and connection, like Upfem for our female Upvengers, or UpVergent supporting neurodivergent Upvengers and allies

# **Our Values:**

-

**Make it easy for others.** We simplify the complex and act with the best intentions

-

**Own the outcome.** We are proactive, fast and confident to get the job done, valuing progress over perfection

-

**Rise to the challenge.** We aim high and push the boundaries. We stay curious, learn and celebrate our wins together

-

**Tell the story.** We start with the Why to align on purpose. We are transparent and share knowledge to empower and inspire others

Upvest is an equal opportunity employer. We celebrate diversity and are committed to creating an inclusive environment for all employees.

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
