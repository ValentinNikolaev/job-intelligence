# Praktikum Social Media, Content & Community (m/w/d)

Posted: 2026-09-18T10:00:27Z

## Rejection

- Category: tech_stack
- Reason: role does not mention Go/Golang or PHP

**100 % remote · Teilzeit möglich · Start nach Absprache**

**Your wardrobe has more in it.**

Das Lieblingsteil, das du immer gleich kombinierst. Die Jacke, die du fast vergessen hast. Das Outfit, das längst in deinem Schrank steckt.

Ich bin Christopher, Gründer von **Try It**. Ich entwickle eine App, mit der Menschen ihre eigene Garderobe neu entdecken, Kleidung kombinieren und Outfits für ihren Alltag planen können. Die Idee dahinter: mehr Freude an dem, was schon da ist. Mit dem eigenen Stil und der Freiheit, selbst zu entscheiden.

Ich baue Try It aktuell selbst auf. Jetzt suche ich jemanden, der Lust hat, diese Idee mit mir nach draußen zu tragen – mit Persönlichkeit, eigenen Gedanken und einem Gespür für Mode, Menschen und digitale Kultur.

Lass uns Try It gemeinsam ein Gesicht geben

Vielleicht hast du schon eine Szene im Kopf. Eine Frage, die du Menschen stellen würdest. Ein Video, das du selbst gerne sehen würdest. Oder eine Idee, wie du mit mir vor der Kamera zeigen könntest, was in einem ganz normalen Kleiderschrank steckt.

Genau solche Impulse wünsche ich mir.

Ich möchte mit dir Inhalte entwickeln, ausprobieren und Menschen kennenlernen, die sich für die Idee hinter Try It begeistern. Du kannst deine Perspektive einbringen und mitprägen, wie die Marke sichtbar wird.

Wenn du sagst: „Christopher, das müssen wir mal zeigen“ oder „Lass uns das anders erzählen“, möchte ich das hören. Ich bin bereit, selbst vor der Kamera zu stehen, dazuzulernen und mit dir etwas aufzubauen.

## Aufgaben

**Was du mitgestalten kannst**

Deine Schwerpunkte lege ich gemeinsam mit dir fest – passend zu deinen Stärken, deinen Lernzielen und deiner verfügbaren Zeit.

- **Inhalte mit Persönlichkeit:** Du entwickelst Ideen für Reels, TikToks und Storys rund um echte Kleidung, persönliche Lieblingsstücke und den Alltag vor dem Kleiderschrank. Von der ersten Idee bis zur Umsetzung kannst du mitgestalten.

- **Präsenz vor der Kamera:** Wenn du Freude daran hast, wirst du selbst in unseren Inhalten sichtbar. Du kannst Formate gestalten, mich als Gründer einbeziehen und deinen eigenen Stil entwickeln.

- **Eine Community aufbauen:** Du greifst Fragen auf, stößt Gespräche an und entwickelst kleine Formate, bei denen Menschen gerne mitmachen und ihre Erfahrungen teilen.

- **Creator kennenlernen:** Du entdeckst Menschen, die zu Try It passen, unterstützt die persönliche Kontaktaufnahme und entwickelst mit mir Ideen für gemeinsame Inhalte.

- **Die Marke weiterentwickeln:** Du bringst ein, was dir auffällt – welche Themen Menschen beschäftigen, welche Inhalte etwas auslösen und wo die App oder ihre Kommunikation noch Fragen offenlässt.

Dabei interessieren mich die Menschen hinter den Reaktionen: Was erkennen sie aus ihrem Alltag wieder? Worüber möchten sie sprechen? Was bringt sie dazu, selbst etwas auszuprobieren?

## Qualifikation

**Was du mitbringst**

**Du** interessierst dich für Mode und persönlichen Stil. Du hast ein Gefühl dafür, wie Menschen auf Social Media miteinander sprechen und weshalb sie sich bestimmten Communities verbunden fühlen.

**Erste praktische Erfahrungen** solltest du mitbringen. Vielleicht hast du eigene Inhalte umgesetzt, einen Account mitgestaltet, ein kreatives Projekt begleitet oder eine kleine Community aufgebaut. Mich interessiert, was **dein Beitrag** war und was du dabei gelernt hast.

Außerdem wünsche ich mir:

- **Eigene Ideen und Lust auf Umsetzung.** Du siehst Möglichkeiten und gehst den nächsten Schritt, um etwas daraus zu machen.

- **Sprachgefühl.** Du kannst dich auf Deutsch klar, sicher und persönlich ausdrücken. Du hörst zu und findest einen respektvollen Umgang mit unterschiedlichen Menschen.

- **Gespür für Menschen und digitale Kultur.** Du verstehst Humor, Stimmungen und die Eigenheiten verschiedener Fashion- und Lifestyle-Communities.

- **Urteilsvermögen.** Du kannst einschätzen und begründen, warum ein Inhalt oder eine Zusammenarbeit zu Try It passt.

- **Selbstständigkeit und Verlässlichkeit.** Du gehst vereinbarte Aufgaben eigenständig an, hältst Absprachen ein und meldest dich, wenn du Unterstützung brauchst.

- **Offenheit.** Du möchtest ausprobieren, Feedback geben und annehmen und deine Fähigkeiten weiterentwickeln.

Freude daran, vor der Kamera zu stehen, ist sehr willkommen. Erfahrungen mit Creatorn, Videoschnitt oder Gestaltungstools sind ein Plus.

**Du musst zum Start nicht alles können.** Eine große eigene Reichweite oder ein perfekter Lebenslauf sind keine Voraussetzung. Ich möchte sehen, dass du bereits etwas ausprobiert hast und Lust hast, darauf aufzubauen.

## Benefits

**Rahmen und Perspektive**

Ob du dich beruflich neu orientieren möchtest, studierst oder neben einer anderen Tätigkeit praktische Erfahrungen sammeln willst: Ich freue mich darauf, dich kennenzulernen. Ein Pflichtpraktikum ist ebenfalls möglich.

- **Arbeitsort:** 100 % remote.

- **Beginn:** nach Absprache.

- **Umfang:** Teilzeit möglich; die wöchentlichen Stunden vereinbare ich mit dir.

- **Dauer:** nach gemeinsamer Absprache und gegebenenfalls den Vorgaben deiner Ausbildung oder Hochschule.

- **Vergütung:** unbezahlt, sofern die rechtlichen Voraussetzungen für deine konkrete Praktikumsform erfüllt sind. Das wird vor Beginn geklärt.

Ich finanziere Try It derzeit selbst und verdiene damit noch nichts. Eine Vergütung kann ich aktuell nicht anbieten. Das möchte ich von Anfang an offen sagen.

Lust, mitzugestalten?

Dann bewirb dich direkt über JOIN.

Schick mir deinen Lebenslauf oder einen kurzen Überblick über deinen bisherigen Weg und erzähl mir:

- Was spricht dich an Try It an?

- Was hast du bereits gestaltet, umgesetzt oder mit aufgebaut? Was war dabei dein Beitrag?

- Welcher Account oder welche Community begeistert dich – und warum?

Vorhandene Videos, Projektlinks oder andere Arbeitsproben schaue ich mir gerne an. Ein neues Konzept oder Bewerbungsvideo musst du dafür nicht erstellen.

Nenne bitte auch deinen möglichen Starttermin, deinen gewünschten Zeitraum und wie viele Stunden pro Woche du verlässlich einbringen kannst.

Ich freue mich darauf, dich und deine Sicht auf Mode, Menschen und Content kennenzulernen.

**Christopher**

Gründer von **Try It**

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
