# Founders Associate - Growth Intern (m/w/d)

Posted: 2026-09-18T10:30:38Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

## About reltix

Ich bin Jan, Mitgründer von reltix und verantwortlich für alles, was mit Wachstum zu tun hat. Wir gehen einen Weg, den im Property Management so niemand geht: Immobilien sind die größte Asset-Klasse der Welt. Und die am schlechtesten betriebene. Allein in Deutschland: Millionen von Wohnungen, betreut von tausenden, oft kleinen und analog arbeitenden Verwaltungen. Und das ausgerechnet jetzt, wo die großen Aufgaben Wohnraummangel, Sanierungswelle und Energiewende auf die Branche zukommen.

Software allein hat diese Branche zwanzig Jahre lang kaum verändert. Sie wird es auch nicht. Service ist das Produkt. Deshalb bauen wir mit reltix nicht die nächste Software für alte Strukturen. Wir bauen die Verwaltung von Grund auf neu und betreiben sie selbst. KI-nativ mit Daten, Prozessen, Software und Service in einem. So entsteht ein System, das mit jeder Einheit dazulernt; und ein Service, der jeden Tag besser wird. Deutschlands deutscheste Branche bekommt ein Betriebssystem.

Ja, das ist ein Praktikum. Aber keins, in dem du nur Slides schön machst oder Listen pflegst. Du arbeitest an den gleichen Themen wie ich. Du bekommst echte Probleme. Ich suche jemanden, den ich nach seinem internship unbedingt behalten will.

## Deine Aufgaben

-

Venture Development: Neue Revenue Streams durchrechnen, Business Cases bauen, erste Tests aufsetzen

-

Geographische Expansion: Marktanalysen für neue Städte, Setup vorbereiten, mit raus in die Execution

-

Strategic Partnerships: Potenzielle Partner identifizieren, ansprechen, Calls vorbereiten und mitführen

-

Leadgen: Eigene Kanäle und Konzepte testen, messen, verwerfen oder skalieren

-

Automatisierung & KI: Prozesse finden, die uns bremsen, und sie mit KI-Workflows selbst lösen

## Dein Profil

-

80/20-Mindset: Schnell statt perfekt, brutal priorisiert

-

Grit & Curiosity: Rückschläge spornen dich an, neue Themen lernst du in Rekordzeit

-

Erste Erfahrung in High-Octane-Umgebungen (Startup, Consulting, VC, IB) oder eigene Projekte, die zeigen, dass du Dinge zu Ende bringst

-

Du bist im Studium, dazwischen oder gerade fertig; 3+ Monate Vollzeit

-

Sehr gutes Deutsch, sicheres Englisch

## Warum wir?

-

Verantwortung ab Tag 1: Du kannst den Vertrieb und unsere Prozesse mit aufbauen und shapen

-

Perspektive: Gute Entwicklungschancen mit klaren Zielen

-

Team & Kultur: Du arbeitest in einem ambitionierten Team, das mit viel Spaß an der Sache die Industrie revolutioniert und das auch gerne auf einem der zahlreichen Teamevents feiert

-

Wellness-Budget: Monatliches Gesundheitsbudget für mentale und körperliche Balance

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
