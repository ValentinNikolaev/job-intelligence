# (Junior) CRM Manager (m/w/d)

Posted: 2026-09-18T10:30:38Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

## DEINE MISSION

**Lust, Ernährung neu zu denken?** Bei yfood machen wir seit 2017 gutes Essen alltagstauglich – ausgewogen, praktisch und richtig lecker. Mit unseren Produkten haben wir eine eigene Kategorie geformt: Smart Food. In ganz Europa unterwegs, rasant wachsend und immer auf der Suche nach neuen Ideen. Wenn du Teil eines dynamischen Teams sein möchtest, das die Lebensmittelbranche revolutioniert, dann bist du bei yfood genau richtig.

## Deine Aufgaben als CRM Manager

Zur Verstärkung unseres CRM-Teams suchen wir befristet (erstmal auf 2 Jahre) eine (Junior) CRM Manager, die unsere Kundenkommunikation über alle Märkte hinweg operativ mitgestaltet. Der Fokus liegt auf der Umsetzung unserer CRM-Kampagnen sowie der kontinuierlichen Weiterentwicklung unserer Retention- und Loyalty-Maßnahmen.

- Konzeption, Erstellung und Aussteuerung von CRM-Kampagnen mit Schwerpunkt E-Mail-Marketing in unserem CRM-Tool Emarsys

- Entwicklung von zielgruppengerechtem und überzeugendem Copy für Newsletter, E-Mail-Flows und Kampagnen rund um Food & Nutrition

- Analyse und Reporting der Kampagnenperformance anhand relevanter KPIs wie Öffnungs-, Klick- und Conversion-Raten sowie Ableitung konkreter Optimierungsmaßnahmen

- Durchführung und Auswertung von A/B-Tests zur kontinuierlichen Weiterentwicklung von Copy, Betreffzeilen und Customer Journeys

- Einsatz von AI-Tools zur Optimierung und effizienteren Gestaltung bestehender Prozesse

- Enge Zusammenarbeit mit Grafik, Content und dem Webshop-Team

- Erstellung SEO-optimierter Texte, beispielsweise für Landingpages, unter Berücksichtigung relevanter Keywords

## DAS MACHT DICH AUS

## Deine Qualifikationen als CRM Manager

- Ca. 1–3 Jahre Berufserfahrung sowie erste Kenntnisse im Online-Marketing, insbesondere im E-Mail-Marketing

- Grundkenntnisse im Bereich SEO

- Ausgeprägte Copywriting-Skills und ein gutes Gespür für zielgruppengerechte Kommunikation, idealerweise mit Erfahrung im Bereich Food & Nutrition oder vergleichbaren Konsumgüter- bzw. Lifestyle-Themen

- Erste Erfahrung mit einem CRM-Tool wie Emarsys, Klaviyo, Salesforce Marketing Cloud oder Braze – Emarsys-Erfahrung ist von Vorteil, aber kein Muss

- Gutes analytisches Verständnis und sicherer Umgang mit relevanten Kampagnen-KPIs

- Hands-on-Mentalität sowie eine selbstständige, strukturierte und sorgfältige Arbeitsweise – auch bei mehreren parallelen Projekten

- Kreativität und ein gutes Gespür für Marke und Tonalität

- Offene, kommunikative Art und Freude an der Zusammenarbeit im Team

- Eigeninitiative und Lust darauf, Themen selbstständig voranzutreiben

- Fließende Deutsch (C2) und Englisch (C1) Kenntnisse

## WAS UNS ANTREIBT

Wir sind ein bisschen anders – und genau das macht uns aus

- **Leidenschaft** – Wir brennen für das, was wir tun. Voller Energie, voller Optimismus, immer hungrig nach Neuem.

- **Verantwortung** – Heißt für uns: Füreinander einstehen, Verantwortung übernehmen und alles geben, wenn’s drauf ankommt.

- **Professionalität** – Wir nehmen unsere Arbeit ernst – uns selbst aber nicht zu sehr. Wir sind offen, direkt und immer auf Augenhöhe. Kein Bullshit, kein Ego. Nur Team.

- **Innovation** – Wir denken lieber „Warum eigentlich nicht?“ statt „Das war schon immer so.“ Wir lieben neue Ideen, unkonventionelle Wege – und bleiben nie stehen.

## (WH)yfood?

## Was wir dir bieten: Unsere Benefits

- **Wir fördern Chancengleichheit und schätzen Vielfalt.** Wir verpflichten uns, ein integratives Umfeld für alle Mitarbeitende zu schaffen.

- **yfood wächst international:** Obwohl Deutschland unsers „Home Base“ ist, haben wir mit unseren internationalen Märkten ein dynamisches und buntes Umfeld geschaffen, in dem viele spannende Themen auf Dich warten.

- **Agilität ist uns wichtig.** Daher arbeiten wir in einem hybriden Arbeitsmodell und bieten dir die Möglichkeit mit Workation aus dem EU-Ausland zu arbeiten.

- **Urlaub ist wichtig.** Daher erhältst du bei uns 30 Tage bezahlten Urlaub im Jahr.

- **yfood hält dich fit**. Mit einer subventionierten Mitgliedschaft bei EGYM-Wellpass kannst du dir für nur 29€ im Monat Gutes tun. Dazu bieten wir im Rahmen unseres Gesundheitsmanagements & Healthy@yfood Workshops und Aktionen (z.B. Yoga, Breathwork, Soccer, Pickleball) an.

- **Gemeinsam Gutes tun.** Mit unserem yforgood Day erhältst du einen bezahlten Tag pro Jahr, um gemeinsam mit deinem Team eine soziale, gemeinnützige oder ökologische Initiative zu unterstützen.

- **Weg vom Fleck**. Wir steuern 30€ zu deinem ÖPNV-Ticket bei und bieten dir über JobRad die Möglichkeit, vergünstigt ein Fahrrad zu leasen.

- **Trainiere deine Geschmacksnerven**. Bei uns ist jeder der Lust hat Teil unseres Sensory-Teams. Probiere also neue Produkte, Sorten oder Geschmäcker vor allen anderen. Ansonsten gibt es so viel yfood wie du tragen kannst, natürlich auch für dich gratis.

- **Als Start-Up hat man oft mit Klischees zu kämpfen**. Manche sind aber auch wahr. Daher gibt es bei uns natürlich auch einen Obstkorb, deinen gratis Koffein-Kick oder das stille Wässerchen.

- **Come as you are.** Ob im Anzug oder Einhorn-Onesie. Einen Dresscode kennen wir nicht.

## KONTAKT

Katharina Bauer

Senior Talent Acquisition Manager

**Chancengleichheit für alle**

yfood steht für die Chancengleichheit aller ein. Wir begrüßen und feiern Vielfalt und setzen uns dafür ein, ein inklusives Arbeitsumfeld für alle Mitarbeiter:innen zu schaffen. Wir stehen allen Personengruppen offen, unabhängig von Alter, Hautfarbe, Herkunft, Ethnizität, Religion, Geschlecht, sexueller Orientierung, Geschlechtsidentität und/oder -ausdruck, Familienstand oder anderen gesetzlich geschützten Merkmalen.

Wir begrüßen Bewerbungen von Menschen mit Schwerbehinderung ausdrücklich.

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
