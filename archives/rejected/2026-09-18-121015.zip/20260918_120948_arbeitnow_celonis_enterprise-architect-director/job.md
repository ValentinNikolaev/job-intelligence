# Enterprise Architect Director

Posted: 2026-09-18T08:55:22Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Celonis is the trusted platform to industrialize Enterprise AI. At our core is the Celonis Context Model — which combines process data, business knowledge, and intelligence into a living digital twin of the enterprise that AI can actually understand, turning AI's operational blind spots into operational clarity. World's leading companies trust Celonis and its global ecosystem of partners to make their AI agents, people, systems, and processes work together, achieving transformational outcomes. We believe there's a massive opportunity to unlock global productivity and sustainability by giving AI the context to understand how every business process really works. Join our mission to make processes work for people, companies, and the planet.

#### **The Role**

To push further our vision of Enterprise AI, we are looking for a senior leader to grow and lead our team of Enterprise Architects.

This high-impact leadership role demands a unique blend of deep technical expertise, people management experience, and executive presence. You will act as an executive sponsor, confidently presenting to customer C-level executives and helping your team translate strategic goals into actionable technical plans.

Your primary goal is to lead and empower a team that supports our growing sales organization in achieving revenue goals. You will ensure your team successfully unlocks technical blockers by fostering close partnerships with leadership across Sales, Value Engineering, Product Management, Data Ops, and Information Security teams.

#### Measures of Success

Your success will be measured by your team's impact, including new customer acquisition rates, retention, up-selling, and your overarching contribution to the overall sales team and business success.

#### The work you’ll do:

- Team Leadership: Hire, mentor, and manage a team of Enterprise Architects who define the overall architecture, data, and cloud strategy for our largest client accounts.

- Executive Engagement: Act as an executive sponsor in pre-Sales and post-Sales phases, presenting strategic visions to C-level executives and engaging with customer Architecture and security teams.

- Drive Strategic Innovation: Guide your team to design architectures that drive enterprise modernization, leverage capability mapping, and explore innovative solutions using emergent technologies like Agentic AI.

- Cross-Functional Alignment: Serve as the leadership bridge between our product & engineering teams within Celonis and client teams to ensure the delivery of premier technical services.

- Ecosystem & Readiness: Oversee the assessment of the IT landscape maturity of our customer installed base and ensure your team effectively coaches Celonis account teams and ecosystem partners on architecture, integration, performance, and scalability.

- Thought Leadership: Direct the development of re-usable assets for projects, as well as customer-facing position papers and thought leadership presentations on architecture and innovation with Celonis.

#### The qualifications you need:

- Experience: 20+ years of relevant experience, including a proven track record of managing Enterprise Architects or technical teams at a top consulting firm or software vendor.

- Strategic Vision: Proven ability to think strategically, guiding your team to connect technical solutions to business value and customer objectives.

- Communication: Excellent written and verbal communication skills, with a proven track record of navigating complex negotiations and presenting to C-level executives.

- Enterprise Architecture Expertise: Demonstrated experience and deep understanding of Capability Mapping, Enterprise Modernization, and Agentic AI.

- Technical Foundation: Strong background in Data Architecture, system integrations, data operations, automation capabilities, and data-related languages (SQL, Python, etc.). You must be able to comfortably switch from discussing high-level architecture strategy to understanding hands-on demo environments.

- Ecosystem Knowledge: Strong understanding of cloud-native architectures, SaaS solutions (Salesforce, SAP, Dynamics CRM, ServiceNow), cybersecurity posture fundamentals, API ecosystems, and legacy on-premise enterprise architectures.

- Education: MSc degree in Computer Science or an equivalent in an Information Technology-related field.

- Languages: Fluency in English is required; an additional language such as Spanish, French, German, or Italian is a strong advantage.

#### Preferred:

- Celonis Certifications and extensive leadership experience managing projects with OCPM and Case Centric Data Pipelines.

- Industry standard certifications such as AWS/Azure/GCP, ESB / ETL (Mulesoft, Oracle, SAP, Talend, Informatica), or TOGAF/Zachmann.

- Experience spanning at least two domains (e.g., Finance, Manufacturing, Supply Chain, HR) and at least two industries (e.g., Consumer Goods, Banking, Pharma, Aerospace).

197289803

**What Celonis can offer you:**

- Pioneer Innovation: Work with the global leader in Process Mining and the Process Intelligence Graph to shape the future of AI-driven business operations.

- Ownership from Day 1: Every full-time "Celonaut" is an owner, receiving Restricted Stock Units (RSUs) and merit-based refresh grants.

- Unrivaled Family Support: Benefit from our inclusive parental leave policy—24 weeks of fully paid leave for primary carers and 12 weeks for supporting carers, available from your first day of employment.

- Work-Life Integration: Enjoy Unlimited PTO (in applicable regions) and generous PTO globally, as well as a flexible hybrid work model that balances remote focus with vibrant office collaboration.

- Continuous Growth: Elevate your skills through our 70-20-10 learning framework, mentorship programs, and access to a dedicated learning platform.

- Holistic Well-being: Prioritize your health with subsidized Wellhub memberships, mental health counseling, and dedicated "Wellness Weeks" that prioritize work/life balance.

- Drive Sustainability: Participate in annual Impact Days, where you receive paid time off to volunteer for community and environmental causes with your local office, or virtually.

- Global Inclusion & Belonging: Find community through our Inclusion Think Tank and participate in our annual Inclusion Days, ensuring every voice is heard and valued.

- Value-Driven Impact: Join a mission-led organization where our core values—Live for Customer Value, The Best Team Wins, We Own It, and Earth Is Our Future—drive every decision.

**About Us:**

Celonis is the trusted platform to industrialize Enterprise AI, empowering organizations to analyze, design, and operate AI-driven processes. The Celonis Platform is powered by the Celonis Context Model, which combines process data, business knowledge, and intelligence to create a living digital twin of the enterprise that AI can understand — turning AI’s operational blind spots into operational clarity. Industry-leading companies around the world trust Celonis and its global ecosystem of partners to make their AI agents, people, systems, and processes work together, achieving transformational outcomes. Celonis is headquartered in Munich, Germany, and New York City, USA, with more than 20 offices worldwide.

Get familiar with the Celonis Process Intelligence Platform by watching this [video](https://www.youtube.com/watch?v=YR5oRJGhJYg&list=PLuVor-ZUD4pnM6G33C5D0tjXUvlTPYBRe).

**Celonis Inclusion Statement:**

At Celonis, we believe our people make us who we are and that “The Best Team Wins”. We know that the best teams are made up of people who bring different perspectives to the table. And when everyone feels included, able to speak up and knows their voice is heard - that's when creativity and innovation happen.**
**

**Your Privacy:**

Any information you submit to Celonis as part of your application will be processed in accordance with Celonis’ [Accessibility and Candidate Notices](https://www.celonis.com/careers/candidate-notices)

By submitting this application, you confirm that you agree to the storing and processing of your personal data by Celonis as described in our [Privacy Notice for the Application and Hiring Process](https://www.celonis.com/careers/privacy-notice/).

Please be aware of common job offer scams, impersonators and frauds. Learn more [here](https://www.celonis.com/careers/fraud-alert/).

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
