# HR Manager - Personalentwicklung & Nachwuchsförderung (m/w/d)

Posted: 2026-09-18T09:30:51Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

*Bremen | Voll- oder Teilzeit (min. 30 Std./Wo.) | 55.000 € - 62.000 € / Jahr (Vollzeitäquivalent)*

**Menschen entwickeln. Verantwortung übernehmen. HR gemeinsam weiterbringen.**

MERENTIS steht für intelligente Prozessautomatisierung, moderne IT-Lösungen und zuverlässige Services. Mit unseren Teams aus Beratung, Technologie und Support unterstützen wir Unternehmen dabei, effizienter zu arbeiten und Veränderungen erfolgreich umzusetzen.

Unsere Teams sollen wachsen fachlich und persönlich. Dafür suchen wir Verstärkung im HR-Team: jemanden, der Menschen gerne begleitet, Entwicklung möglich macht und gemeinsam mit Führungskräften und Kolleg:innen gute Lösungen entwickelt und umsetzt.

Dabei verbindest du Personalentwicklung mit operativer HR-Arbeit nah an den Menschen, mit Gestaltungsspielraum und dem Anspruch, gute Ideen in die Praxis zu bringen.

## Aufgaben

Du gestaltest die Personalentwicklung für das gesamte Unternehmen und betreust zusätzlich unsere Auszubildenden und Studierenden.

- Du entwickelst unsere Skill- und Kompetenzmodelle weiter und führst Mitarbeiter- und Entwicklungsgespräche.

- Du leitest daraus konkrete Entwicklungsmaßnahmen und Lernmöglichkeiten ab und bringst sie in die Umsetzung.

- Du baust unsere PE-Instrumente und -Prozesse weiter aus und nutzt dabei digitale Tools und KI, wo sie einen echten Mehrwert bieten.

- Du begleitest Führungskräfte bei Entwicklungs- und Personalthemen und bist dabei zugewandt, klar und lösungsorientiert.

- Du betreust unsere Auszubildenden und Studierenden entlang des gesamten Employee Lifecycles vom Recruiting und der Einstellung bis zum Austritt. Dazu gehören u. a. Auswahlprozess/Vorstellungsgespräche, Vertragsmanagement, Fragen zu Entgelt und Zeitkonten sowie die laufende Betreuung.

- Du übernimmst eigene HR- und PE-Projekte und hältst die Fäden zusammen.

- Im kleinen HR-Team unterstützt du auch über deinen eigenen Aufgabenbereich hinaus, wenn es darauf ankommt.

## Qualifikation

- Mehrjährige Berufserfahrung in der Personalentwicklung und/oder operativen Personalarbeit idealerweise 3 - 5 Jahre.

- Erfahrung im Mittelstand ist ein Plus. Wichtiger ist uns dein Verständnis für pragmatische Lösungen und kurze Entscheidungswege.

- Freude daran, Menschen zu erreichen und auch schwierige Themen offen und respektvoll anzusprechen.

- Eine gute Mischung aus Konzeptstärke und Umsetzungswillen.

- Ausgeprägte Kommunikations- und Beratungskompetenz. Du kannst unterschiedliche Perspektiven zusammenbringen und auch bei schwierigen Themen klar und wertschätzend bleiben.

- Interesse an IT, Digitalisierung und KI.

- Eigeninitiative und Durchhaltevermögen. Du bleibst auch an Themen dran, wenn Veränderungen Zeit brauchen.

- Eine pragmatische Haltung: Du wartest nicht auf die perfekte Lösung, sondern findest eine gute und setzt sie um.

## Benefits

- Eine tolle Unternehmenskultur

- Mobile Hardware

- Bis zu 60% mobiles Arbeiten

- Firmenfitness

- SpenditCard

- Bikeleasing

- Betriebliche Altersvorsorge

- Regelmäßige Firmenevents und -veranstaltungen

Ein kleines HR-Team, kurze Entscheidungswege und eine Rolle, in der Personalentwicklung und echte Personalarbeit zusammengehören.

Du arbeitest eng mit deiner Führungskraft und der Geschäftsführung zusammen. Deine Ideen sind willkommen entscheidend ist, dass daraus gemeinsam abgestimmte Lösungen und konkrete Ergebnisse werden.

Wenn du PE kannst, HR verstehst und gerne Dinge ins Rollen bringst, sollten wir uns kennenlernen.

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
