# Werkstudent Marketing Projektmanagement (m|w|d) - ca. 10 Wochenstunden

Posted: 2026-09-18T11:00:48Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

## Deine Rolle bei uns

Als Werkstudent:in im Marketing-Projektmanagement sorgst du dafür, dass unsere Projekte reibungslos laufen. Du behältst den Überblick über Aufgaben, Zeitpläne und Deadlines, koordinierst zwischen Teams und unterstützt uns dabei, unsere Projekte strukturiert und effizient ans Ziel zu bringen. So schaffst du die organisatorische Grundlage, auf der gute Marketing-Arbeit erst entstehen kann.

**Was dich bei uns erwartet**

- Echte Verantwortung und die Möglichkeit, eigene Ideen umzusetzen

- Einblicke in die Arbeit an der Schnittstelle von Marketing, Technologie und KI

- Arbeiten mit modernen Tools und KI in der Praxis, nicht nur in der Theorie

- Flache Hierarchien, kurze Entscheidungswege und ein starkes Team

- Flexible Arbeitszeiten, die sich gut mit deinem Studium vereinbaren lassen

- Persönliche und fachliche Weiterentwicklung und Raum, dazuzulernen

## Aufgaben

- Unterstützung bei der Planung, Koordination und Steuerung von Marketingprojekten

- Pflege von Projektplänen und Aufgabenübersichten (z. B. in Tools wie Plane)

- Koordination und Nachverfolgung von Aufgaben und Deadlines im Team

- Unterstützung des Marketing-Teams im Tagesgeschäft und bei operativen Aufgaben

- Mithilfe bei der Optimierung und Automatisierung von Projekt- und Marketingprozessen

## Qualifikation

- Eingeschriebene:r Student:in, idealerweise in BWL, Marketing, Wirtschaft, Kommunikation, Projektmanagement oder einem verwandten Studiengang

- Organisationstalent mit strukturierter, selbstständiger und zuverlässiger Arbeitsweise

- Ein gutes Gespür für Prioritäten und Deadlines, auch wenn mehrere Themen gleichzeitig laufen

- Kommunikationsstärke und Freude an der Zusammenarbeit im Team

- Sicherer Umgang mit gängigen Office- und Kollaborationstools; Erfahrung mit Projektmanagement-Tools von Vorteil

- Interesse an Marketing, Digitalisierung und KI

- Sehr gutes Deutsch in Wort und Schrift

- Verfügbarkeit von rund 10 Stunden pro Woche (nach Absprache)

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
