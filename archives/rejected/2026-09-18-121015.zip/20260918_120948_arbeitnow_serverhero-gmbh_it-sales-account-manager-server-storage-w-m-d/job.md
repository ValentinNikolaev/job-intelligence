# IT Sales / Account Manager Server & Storage (w/m/d)

Posted: 2026-09-18T09:00:46Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Wir sind Serverhero - die Experten für Server und Storage und der am schnellsten wachsende Hardware-Lieferant im Bereich Datacenter. UND WER BIST DU?

## Aufgaben

WAS DU BEI UNS MACHST?

Ein Hero sein!

- ...für deine Kunden: Du begleitest deine Kunden durch den gesamten Salesprozess: von der Beratung, über die Angebotserstellung, der Auftragsbearbeitung und -dokumentation bis zur Auslieferung und baust dir so deine eigenen langfristig erfolgreichen Kundenbeziehungen auf.

- ...für deinen eigenen Erfolg: Du betreust, berätst und entwickelst unsere Neu- und Bestandskunden fachlich herausstechend kompetent und ganz individuell zu unserem Produktportfolio im Bereich Server & Storage.

- ...für unser Management: Du bringst Ideen ein, hinterfragst kritisch und verbesserst, was es zu verbessern gibt.

- ...für dich selbst: Entwickle dich fachlich und persönlich weiter, mit deinem Einsatz hast du deinen Erfolg in der Hand – wir supporten und fördern wir dich auf deinem

## Qualifikation

WAS DU MITBRINGEN SOLLTEST:

- Zeig uns nicht nur was du kannst, sondern auch wer du bist – die Chemie muss stimmen.

- Du bringst mehrjährige Berufserfahrung im IT-Umfeld eines IT-Systemhauses oder der Distribution und gute Kenntnisse in den Bereichen Datacenter / Server / Storage (HPE, Fujitsu, IBM o.ä.) mit.

- Du verfügst über ein abgeschlossenes Studium im (betriebs-) wirtschaftlichen/technischem Bereich oder eine abgeschlossene kaufmännische Ausbildung.

- Deine mitreißende Sales-Mentalität, Kommunikationsstärke gepaart mit Lösungsorientierung und Verhandlungssicherheit sind in deiner DNA verankert - vor allem im telefonischen Kontakt macht dir so schnell keiner etwas vor.

- Dein Teamgeist und deine strukturierte, zuverlässige und kollegiale Arbeitsweise zeichnen dich ebenso aus, wie deine Eloquenz in deutscher, wünschenswert auch englischer Sprache.

## Benefits

WAS WIR DIR BIETEN:

- 31 Tage Urlaub zur verdienten Erholung.

- Freitags kannst du auch ab 14 Uhr schon ins Wochenende starten.

- Fachliche und persönliche Weiterentwicklung sind wichtige Pfeiler unserer Unternehmenskultur; wir bieten dir ein breites Angebot bezüglich deiner individuellen Karriereplanung.

- Nicht nur fit im Kopf – auch sonst unterstützen wir einen gesunden Lifestyle durch ergonomische Arbeitsplätze, eine Urban Sportsclub-Mitgliedschaft oder gemeinsam organisierten sportlichen Aktivitäten.

- mobile Mittagskantine - wir bezuschussen dein Mittagessen!

- Jobticket oder JobBike? Kein Problem!

- Wir denken gemeinsam an deine Zukunft und unterstützen deine Altersvorsorge.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
