# Founders Associate

Posted: 2026-09-18T09:30:50Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

We are looking for a Founder's Associate to work directly alongside our Founder on whatever moves the company forward most. You sit at the intersection of strategy and operations, and get a front row seat to how an industrial company is built.

## Aufgaben

- **Right hand to the Founder:** define and execute the company's highest-priority strategic and operational initiatives.

- **Be the link between the Founder and the team.** You make sure decisions get through and that nothing stays stuck in between.

- **Define and build automations for manual work** across procurement, admin tasks, and many more, alongside our AI and Automation Engineer.

- **Support with investor relations**

## Qualifikation

- **Bachelor’s or Master's degree from a top university** in business, engineering or at the intersection of business and technology, with top grades.

- **Get things done** mentality: prioritising progress and results over process.

- **Humble, low ego**, not afraid to get your hands dirty.

- **First experience in a high paced environment**: consulting, a startup or something comparable.

- **Technical literacy**: you are a fast learner and comfortable diving into technical topics.

- **Strong communicator** who is comfortable in customer meetings as on the shop floor.

## Benefits

- **Ownership through ESOP**.

- **Scaling from 0 to 1**: you shape how this company works, from the processes to the team around you.

- An interdisciplinary **team of top performers** that will both support and challenge your growth.

- **Lunch allowance**, a **subsidized sports membership** and modern tech.

- A **new office in** **Garching**, right on top of our own production floor.

Vetaion is building a fully automated production facility for control cabinets in Munich. We use digital twins and robotics to automate the manufacturing process, orchestrated by VetaionOS, our own operating system for the factory.

Our mission is to strengthen Germany as a leading industrial hub. Join our team and our mission, let's reinvent the future of production together!

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
