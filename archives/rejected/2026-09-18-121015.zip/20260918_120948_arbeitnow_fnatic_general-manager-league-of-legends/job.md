# General Manager, League of Legends

Posted: 2026-09-18T08:40:05Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Fnatic League of Legends holds one of the richest histories and legacies in the game, from its inception to the present day. As General Manager, you will lead one of the premier teams in Fnatic’s portfolio, with a critical role in continually raising the bar and adding to that legacy of success.

In 2027 we go into a rebuild, and we are looking for an exciting new General Manager to lead that effort. You will shape the squad, the staff and the environment around them, and set the direction for the years that follow.

You'll report to the Chief Gaming Officer.

**What you’ll do:**

-

Own the sporting performance and delivery of results of Fnatic League of Legends, shaping a team capable of sustained success

-

Lead recruitment and selection of League of Legends athletes, coaches and performance staff, and execute changes as necessary, including benching and transfers

-

With the coaching staff, establish a high performance culture through defining key values and expectations that the team should represent and follow

-

Manage team performance and behaviours, ensuring standards are upheld through appropriate recognition and disciplinary actions

-

Create an elite-tier performance environment with the practice approach, facilities, scheduling and team operations required to win at the highest level

-

Establish a platform and team culture that makes Fnatic a home players and staff aspire to be at and want to stay at, through player care and player experience worthy of their ambition

-

Establish a clear team structure and processes, and continually optimise them in collaboration with senior Esports management

-

Manage the League of Legends team budget, allocating resources effectively to deliver competitive success whilst supporting revenue generating activities

-

Oversee player contracts and obligations, monitoring the delivery of player obligations towards Fnatic, Riot Games and our partners

-

Champion a data and science led approach across recruitment, performance and decision-making, building on Fnatic's analytics capability and the tools that support it

-

Nurture relationships with title stakeholders on League of Legends specific topics, including Riot Games, tournament organisers, teams and player representatives, protecting the team’s interests throughout

-

Be a proactive ambassador for Fnatic across media, community and partner activities, including but not limited to interviews, content, community, and fan meetings

-

Ensure Fnatic brand, content and partnership strategies can be activated through player insights and access, and that the wider business is integrated with, and understood by, our League of Legends division

-

Lead on ad-hoc sporting projects as defined by CGO

**We’re looking for:**

-

Leadership experience within professional gaming or sports, with genuine accountability for results

-

Passion for esports and a strong understanding of the League of Legends scene

-

Competitive instinct and knowledge of what it takes to win

-

People management experience, including coaches and world-class athletes

-

Ability to inspire and educate the current and next generation of professional gamers, with a readiness to walk the extra mile for players when needed

-

Strong interpersonal and communication skills, with the confidence to represent Fnatic publicly and build trusted relationships with players, staff and fans

-

Commercial literacy, comfortable holding a budget and producing business cases

-

Proven ability to work with talent and people from diverse cultures and backgrounds

-

Excellent written and verbal English, other languages desirable

-

Based in Berlin, or willing to relocate

##
**Diversity, Equity & Inclusion: #AlwaysFnatic**

At Fnatic, we believe that a diverse mix of voices leads to better discussions, decisions, and outcomes for everyone. We strive to recruit and nurture an inclusive workforce who feel empowered every day to forge the future as part of the Black and Orange squad.

We know that applying for jobs can be daunting - but be assured that at Fnatic:

-

Who you are, and how you identify has no impact on our selection process

-

We understand no candidate will tick 100% of what our job descriptions are seeking, so if you’re missing a point here or there, we still want to hear from you

-

We're happy to consider reasonable adjustments where needed to fully participate in Fnatic’s recruitment experience - just let us know.

# About us

Fnatic is a global esports performance brand headquartered in London, laser-focused on seeking out, levelling up and amplifying gamers and creators. Our history is unparalleled. Founded in 2004, we are the most successful esports brand of the last decade, winning more than 200 championships across 30 different games.

Today, driven by our ability to advance esports performance, Fnatic is the channel through which the most forward-thinking brands communicate with young people. We deliver industry-leading content, experiences and activations globally with bases in Berlin, Belgrade, Tokyo among others. Our pros and creators generate hundreds of millions of watch hours, showcasing our global partners to an audience of millions of fans across our social platforms.

Forging the future is in our DNA. We pioneered the intersection of street culture and esports with merch collaborations, and continue to lead the industry with the quality of our pro wear and fan apparel. After launching in 2016, our award-winning esports equipment (comprising mice, keyboards, headsets and pads) has sold to hundreds of thousands of gaming enthusiasts who want to play better.

Gaming is the place where music, fashion, sport and technology come together, and Fnatic is leading the charge.

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
