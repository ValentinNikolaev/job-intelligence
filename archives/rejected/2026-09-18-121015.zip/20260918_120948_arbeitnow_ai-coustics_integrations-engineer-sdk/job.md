# Integrations Engineer (SDK)

Posted: 2026-09-18T10:00:28Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Voice is becoming the primary interface for technology. For the first time in history, we can use natural language to control and interact with our devices, services, and applications, and we're only at the beginning of the adoption of Voice and Physical AI across industries. Current voice interactions, however, still lack a fundamental human skill: nuanced understanding of audio scenes and environments. Navigating complex auditory scenes, distinguishing between multiple voices, or focusing on a main speaker are all part of the challenge of "teaching machines to hear like human beings."

At ai-coustics, we're building the audio intelligence layer and developer tooling to enable more robust and intelligent voice agents and Physical AI applications. Today, Voice AI companies like Perplexity, PolyAI, LiveKit, AssemblyAI or Telli use our SDK to prepare their agents for real-world acoustic challenges. Our models power thousands of agents worldwide and process millions of hours each month.

We are backed by leading early-stage investors including Connect Ventures, Partech, Inovia Capital, as well as angel investors from HuggingFace, DeepMind and Amazon with deep expertise in AI and developer infrastructure. These partners share our vision and are helping us build a world-class team operating with high levels of responsibility and velocity. We look for people who take ownership, think systemically, and want to solve challenging real-world problems in close collaboration with our customers.

### **Role overview**

We're looking for an Integrations Engineer to make our SDK easy to adopt on the platforms voice agent developers actually build on. Our core SDK is native and ships with wrappers for Python, Node.js, C, C++, Rust and WebAssembly, plus plugins for LiveKit Agents and Pipecat. You will own the plugins and the public surface of the language wrappers, keep them released in lockstep with the core SDK and work with upstream open-source maintainers so our integrations stay first-class.

You sit in the SDK team and work closely with developer relations and with customers who integrate us.

### **Tasks**

- Own our LiveKit Agents and Pipecat plugins in Python and TypeScript, from design to release

- Maintain the public API, examples and packaging of our Python, Node.js and WebAssembly wrappers together with the SDK team

- Land contributions in upstream projects and build relationships with their maintainers

- Own the integration documentation: quickstarts, compatibility matrix, migration guides

- Triage integration issues from customers and partners, reproduce them and fix them or route them to the right team

- Bring new models and features into every integration as the core SDK ships them

- Track how developers integrate us and use that to decide what to improve next

### **Requirements**

- 3+ years of professional experience in both Python and TypeScript

- You have published and maintained a package on PyPI or npm with external users, including versioning, release notes and breaking-change management

- You have contributed to an upstream open-source project and got changes merged

- You understand real-time audio basics: sample rates, frame sizes, buffering, latency budgets

- You write documentation developers actually read, and you enjoy helping other engineers integrate your work

- You are comfortable in a codebase with a native core and can read Rust and C bindings even if you don't write them daily

- You use AI coding tools daily and know where they help and where they don't

- Bonus: experience with LiveKit, Pipecat or another voice agent framework, WebRTC, PyO3 or napi-rs bindings, gRPC or protobuf

### **You may not be a great fit if…**

- You want to work on DSP or model development in the native core

- You prefer building one product over maintaining several integrations

- You don't want to talk to customers and partner engineers

- You see open-source contribution as a side activity rather than part of the job

- Remote-first is a hard requirement for you

### **Compensation**

Base salary of **€75,000 – €95,000 per year** (Berlin, mid to senior level), plus stock options.

### **Benefits**

- Work on real-time audio infrastructure used by voice AI companies worldwide, at a rapidly growing startup backed by top investors.

- Competitive package with stock options, so you take part in the company's success.

- Small team, direct access to the founders and full ownership of your area.

- Berlin office with a hybrid setup, and the trust to ship fast.

- World-class team of engineers and researchers with ample room for professional growth.

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
