# Senior Product Manager - Data Lakehouse (f/m/d)

Posted: 2026-09-18T08:30:33Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Trusted Shops creates digital trust between people, businesses, and AI agents, with one clear goal: becoming the #1 Community of Trust. Every day, we help businesses build trust online and empower consumers to make confident decisions in an increasingly digital world.

As our products, reporting capabilities, and AI-driven use cases continue to grow, the company increasingly needs prepared, standardized data products – the data basis for self-service reporting, APIs (Metrics-as-a-Service), and AI-driven access via MCP or Chat interfaces. You and your team will own the whole journey from raw data to documented, trustworthy data products that people and machines can actually use.

To strengthen our Data Services department, we are looking for a

**Senior Product Manager - Data Lakehouse (m/f/d)**

*(Hybrid in Cologne or remote in Berlin / Full-time / Permanent contract)*

### **Responsibilities**

-

You own the product portfolio and roadmap for the domain, driving the shift from reactive requests ("build the metric asked for") to proactive, reusable metric standards.

-

You run data products end-to-end. You know your consumers, treat them as customers, and track whether they actually trust and use what you ship.

-

Together with your team, you define the semantic layer: metric and dimension definitions, metadata, and documentation that make a data product clear to people working in BI tools and reliable for AI agents.

-

You provide metrics-as-a-service. Your team exposes metrics through an API that product engineering teams integrate directly into their own products.

-

You are the point of contact for internal consumers and product teams: you set expectations, explain trade-offs, and say no when needed. You align shared standards and dimensions with the Finance Data Domain team and work with the Data Platform team as your service provider.

-

Several years of product management experience, including ownership of data or analytics products such as data products, semantic layers, data platforms, or data-intensive APIs.

-

Strong data-as-a-product mindset with a focus on consumers, quality, governance, semantic consistency, and measurable adoption.

-

Proven ability to define and standardize metrics and data concepts that can be used consistently across teams and use cases.

-

Demonstrated experience leading in complex environments, setting direction under ambiguity, and making autonomous decisions.

-

Strong stakeholder management and communication skills with the ability to align diverse groups without formal authority.

-

Solid understanding of modern data ecosystems and tooling, ideally including lakehouse architectures, dbt, semantic layers, reporting platforms, and AI-enabled data access patterns.

### **What we offer yo**

-

Hybrid work: Flexible remote work combined with time in our Cologne office

-

Workation: Temporarily work from within the EU, Iceland, Liechtenstein, or Norway

-

Permanent contract with Europe’s trusted brand

-

One “Self Education Day” per month

-

27 vacation days + 3.5 additional days off (Christmas, New Year’s Eve, Carnival)

-

Buddy program & structured onboarding

-

Individual training and development opportunities

-

Regular team, unit, and company events

-

Health Pass (free online and offline sports, fitness, and health courses)

*BUILD A COMMUNITY OF TRUST WITH US - #cometotr****us****t*

Not sure if you are what we are looking for? Apply!
At Trusted Shops, we are interested in you as a person. Whether you fit in with us is independent of gender, nationality, ethnic and social origin, religion/belief, disability, age, sexual orientation and identity. Trusted Shops is clearly committed to diversity and against discrimination.

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
