# Customer Success Manager (m/w/d)

Posted: 2026-09-18T08:40:04Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Wir bei SoSafe haben das Ziel, der führende Anbieter für Human Risk Management Lösungen in Europa zu werden. Unsere preisgekrönte Awareness-Plattform unterstützt Unternehmen dabei, nachhaltige Verhaltensänderungen durch effektive, interaktive Trainings rund um Cyber-Sicherheit und Datenschutz zu erzielen. Prognosen zufolge wird Cyberkriminalität die Welt bis 2025 jährlich 10,5 Billionen Dollar kosten – werde Teil der Lösung und gestalte die Zukunft der Cybersicherheit aktiv mit!

**So trägst du dazu bei:**

Mit deiner kunden- und produktorientierten Denkweise betreust du deine Kunden und sorgst für deren Erfolg mit der SoSafe-Produktsuite. Du bist verantwortlich für den Aufbau von Beziehungen und kommunizierst deinen Kunden den Mehrwert des Einsatzes der SoSafe Produkte, um die Kundenbindung zu steigern und auszubauen.

Zu deinen Aufgaben in unserem Customer Success Team gehören:

-

Aufbau langfristiger Kundenbeziehungen durch lösungsorientierte Beratung

-

Beratung von Kunden in Bezug auf Maßnahmen zur Sensibilisierung für Cybersicherheit

-

Proaktive Unterstützung der Kunden bei der Erreichung ihrer Ziele

-

Konzeption und Durchführung von Business-Reviews

-

Verwaltung von Kampagnen zur Förderung des Sicherheitsbewusstseins bei den Kunden von SoSafe und Aufzeigen des ROI

-

Einbringen von Feedback in unser Produktentwicklungsteam als Stimme des Kunden

-

Nutzung der Kundenbeziehung, um aus Kunden Fans zu machen

**Was dich auszeichnet:**

-

Du bist kundenorientiert und möchtest deine Kunden unterstützen, ihre Ziele zu erreichen

-

2+ Jahre praktische Erfahrung als Customer Success Manager oder in einer anderen kundenorientierten und beratenden Funktion (Vertrieb, Beratung, etc.)

-

Exzellente Deutsch- und Englischkenntnisse in Wort und Schrift (weitere Sprachkenntnisse sind erwünscht)

-

Du sicher in der Identifikation und Verhandlung kommerzieller Details mit Kunden (Vertragsverlängerungen und Upsells)

-

Du bist in der Lage, mehrere interne und externe Stakeholder bei einer Vielzahl von Kunden und Projekten zu managen

-

Du hast Erfahrung in einer SaaS-Umgebung und bist bereit, dich weiter in die sich entwickelnde Technologie einzuarbeiten

-

Du bist ein Teamplayer und möchtest Teil eines dynamischen Teams sein, das stetig voneinander lernt

-

Du hast Verständnis dafür, wie technische Initiativen in geschäftlichen Nutzen umgesetzt werden

**Was wir bieten*:**

-

Work-Life-Balance: Flexible Arbeitszeiten, 33 Tage Urlaub

-

Well-being und finanzielle Unterstützung: Zugang zur Open-Up App, Mitarbeiterrabatte

-

Verbindung & Gemeinschaft: Virtuelle Events, gemeinsame Teamaktivitäten und Möglichkeiten für lokale Treffen

-

Und vieles mehr: Technische Ausstattung, Empfehlungsprämien, hundefreundliches Büro

**Die oben genannten Vergünstigungen gelten für Vollzeitmitarbeiter und können je nach Standort leicht variieren. Dies ist nur eine Auswahl – mehr erfährst Du im Verlauf des Bewerbungsprozesses.*

**Über uns**

Wir bei SoSafe haben es uns zur Aufgabe gemacht, die digitale Welt sicherer zu gestalten, indem wir den menschlichen Faktor in der Cybersicherheit in den Mittelpunkt stellen.

Als eines der am schnellsten wachsenden Security-Awareness-Scale-ups weltweit nutzen wir verhaltenswissenschaftliche Erkenntnisse und datengesteuertes Lernen, um Menschen effektiv gegen Cyber-Bedrohungen zu stärken. Unser Human Risk Management-Ansatz unterstützt Unternehmen dabei, ihre Mitarbeiter*innen zum wirkungsvollsten Schutzschild gegen Sicherheitsrisiken zu entwickeln.

Mit der Unterstützung führender VCs wie Highland Europe und Global Founders Capital expandieren wir weltweit in rasantem Tempo. Wir suchen Teamplayer, die sinnvolle Veränderungen im Bereich Cybersicherheit vorantreiben, Verantwortung übernehmen und gemeinsam mit uns wachsen wollen.

Wenn du in einem lebendigen, zielorientierten Umfeld aufblühst, das Innovation, Vielfalt und Zusammenarbeit großschreibt – dann bist du bei uns genau richtig!

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
