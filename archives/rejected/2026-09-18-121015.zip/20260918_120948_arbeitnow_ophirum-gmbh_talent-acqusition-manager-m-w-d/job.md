# Talent Acqusition Manager (m/w/d)

Posted: 2026-09-18T10:00:28Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Wir, die OPHIRUM GmbH, sind ein auf Edelmetalle spezialisiertes Handelshaus mit Hauptsitz in Frankfurt am Main. Gegründet in 2010 sind wir aktuell im Verbund mit der GOLDFUXX GmbH bundesweit an über 70 Standorten vertreten und in Deutschland der größte Filialist im Edelmetallhandel.

Unser Kerngeschäft beinhaltet den An- und Verkauf von Gold und Silber in Form von Barren und Münzen und dies direkt vor Ort zur Mitnahme oder auch über unseren Online-Shop. Daneben bieten wir die Möglichkeit der Einlagerung, innovative Sparplan-Modelle sowie den Ankauf von Altgold.

## Aufgaben

Sie haben Freude daran, Menschen zusammenzubringen, Prozesse aktiv zu steuern und Recruiting nicht nur administrativ, sondern auch strategisch zu begleiten? Dann freuen wir uns darauf, Sie kennenzulernen.

- Eigenverantwortliche Steuerung des gesamten Recruiting-Prozesses (End-to-End Recruiting) für kaufmännische Positionen innerhalb unseres Unternehmens

- Erstellung, Veröffentlichung und Optimierung von Stellenausschreibungen auf verschiedenen Recruiting-Kanälen

- Sichtung und Vorauswahl eingehender Bewerbungen

- Durchführung telefonischer und virtueller Erstgespräche mit Kandidat:innen

- Koordination und Abstimmung von Interviewterminen mit Fach- und Führungskräften

- Steuerung externer Dienstleister, Jobportale und Recruiting-Partner

- Unterstützung beim Ausbau und der Weiterentwicklung unserer Recruiting-Prozesse

- Mitwirkung bei der Planung, Erstellung und Steuerung von Social-Recruiting-Kampagnen

- Active Steuerung laufender Ausschreibungen hinsichtlich Reichweite, Qualität und Besetzungsfortschritt

- Enge Zusammenarbeit mit den Fachbereichen und der Personalabteilung

## Qualifikation

- Abgeschlossene kaufmännische Ausbildung oder vergleichbare Qualifikation

- Mindestens 2–3 Jahre Berufserfahrung im Recruiting, idealerweise im kaufmännischen Umfeld

- Erfahrung in der Steuerung und Koordination externer Dienstleister und Recruiting-Partner

- Erste Erfahrungen im Bereich Social Recruiting und Kampagnensteuerung sind wünschenswert

- Sicheres Auftreten sowie ausgeprägte Kommunikationsfähigkeit

- Strukturierte, zuverlässige und eigenverantwortliche Arbeitsweise

- Hohes Organisationsvermögen und gutes Zeitmanagement

- Diskretion, Verbindlichkeit und professioneller Umgang mit sensiblen Daten

- Sehr gute Deutschkenntnisse (Muttersprachniveau) in Wort und Schrift

- Sicherer Umgang mit MS Office

## Benefits

- Eine langfristige und abwechslungsreiche Aufgabe in einem zukunftssicheren Arbeitsumfeld

- Kurze Entscheidungswege sowie eine flache und unbürokratische Hierarchie

- Eine angemessene Vergütung inkl. 28 Urlaubstagen (bei einer 5-Tage-Woche)

- Eine attraktive betriebliche Altersvorsorge

Haben wir Ihr Interesse geweckt? Dann freuen wir uns darauf, Sie kennenzulernen!

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
