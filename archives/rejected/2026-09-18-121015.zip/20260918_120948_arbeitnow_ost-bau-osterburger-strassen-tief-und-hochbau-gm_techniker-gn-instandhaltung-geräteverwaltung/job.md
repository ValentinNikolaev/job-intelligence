# Techniker (gn) Instandhaltung & Geräteverwaltung

Posted: 2026-09-18T11:00:49Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**Was wir dir bieten:**

- Attraktive Vergütung und alle Vorteile des Bauhauptgewerbes

- Persönliche und fachliche Weiterbildungsmöglichkeiten

- Moderne Arbeitsplätze und Technik

- 30 Tage Urlaub, Urlaubs- & 13. Monatsentgelt laut Tarif, KITA-Zuschuss

- Sicherer Arbeitsplatz in einem etablierten Unternehmen

- Betriebliche Altersvorsorge und Gesundheitsförderung

**Deine Aufgaben in unserem Team:**

- Verwaltung und Disposition von Baumaschinen und Kleingeräten

- Prüfung zurückgegebener Maschinen auf Sauberkeit, Funktion, Vollständigkeit

- Regelmäßige Durchführung von Inventuren (Bestandsaufnahme Bauhof/Baustellen)

- Durchführung von Pflege-, Instandsetzungs- und Reparaturarbeiten

- Organisation der turnusmäßigen Wartungstermine und Durchsichten

- Durchführung von Schweißarbeiten im Zusammenhang mit Aufarbeitungsmaßnahmen

- Enge Zusammenarbeit mit dem Platzmeister und den Baustellen

- Regelmäßige Aktualisierung der Gerätelisten

- Ermitteln und Aufstellen von Investitionsbedarf

- Beschaffung erforderlicher Materialien und Komponenten für Baumaschinen und Kleingeräten

- Lager- und Transportdisposition (Einholung von Ausnahmegenehmigungen nach StVO)

- Koordinieren und Überwachen des Werkstattbetrieb und des Fahrpersonals

**Was du mitbringen solltest:**

- Abgeschlossene Ausbildung zum Schlosser/Metallbauer, Kraftfahrzeugmechatroniker, Land- und Baumaschinenmechatroniker oder vergleichbar

- Fundierte Kenntnisse im Umgang mit mechanischen, hydraulischen und elektrischen Bauteilen, Wartung und Instandhaltung

- Handwerkliches Geschick und technisches Verständnis

- Erfolgreich absolvierte Schweißerprüfung mit gültiger Schweißerprüfbescheinigung wünschenswert

- Organisationstalent und strukturierte Arbeitsweise

- Tageweise Reisebereitschaft zu Baustellen ggf. Montagetätigkeit in Sperrpausen

- Führerschein Klasse B erforderlich, Klasse CE wünschenswert

- Anwendungssichere PC- und MS-Office-Kenntnisse

#wirkönnendasprio1

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
