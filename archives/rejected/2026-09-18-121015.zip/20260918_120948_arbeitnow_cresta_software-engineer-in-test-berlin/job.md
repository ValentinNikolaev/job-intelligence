# Software Engineer in Test (Berlin)

Posted: 2026-09-18T08:55:09Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Cresta unlocks the true potential of the customer experience, turning every conversation into a competitive advantage. Cresta’s unified AI platform combines conversational AI agents, real-time human agent augmentation, and comprehensive conversation intelligence to drive revenue and efficiency gains across every channel. The world’s leading companies, including United Airlines, Cox Communications, and Marriott, use Cresta to power world-class customer experiences every day.

Born from the Stanford AI Lab, Cresta has raised more than $270 million from the world’s leading investors, including a16z, Greylock, and Sequoia. Cresta’s leadership includes some of the leading minds in AI today. Our CEO, [Ping Wu](https://www.linkedin.com/in/pingwu/), founded and led Google's Contact Center AI and Vertex AI platforms before joining Cresta to build the future of AI-driven customer experiences.

Over the next few years, AI is going to redefine how people all over the world interact with businesses every day. Come build that future at Cresta.

**About the Role:**

We are seeking a diligent and detail-oriented Software Engineer in Test to join our engineering team in Berlin, Germany. This role will be crucial in ensuring the robustness, scalability, and high quality of our software solutions and will be highly focused on building, expanding, and maintaining our automated testing ecosystem. While strong manual testing instincts are important, this role is designed for someone who will spend the majority of their time writing code, advancing automation, and developing internal tools. The ideal candidate is someone who can independently identify what and how to test, take ownership of impactful projects, and help elevate quality across the organization.

**Responsibilities**

- Design, develop, and execute comprehensive test plans and test cases for new and existing features.

- Identify ambiguities or gaps in product specifications and propose improvements to ensure testability.

- Automate key scenarios using our Playwright-based test framework (TypeScript), with a focus on reliability and maintainability.

- Perform manual exploratory testing, particularly for complex, high-impact features or areas with low automation ROI.

- Analyze and communicate test results, triaging issues with clear, actionable insights.

- Maintain and evolve testing standards, procedures, and documentation.

- Set up and manage testing environments to mirror production usage patterns.

- Investigate customer-reported issues, including log analysis (e.g., from Datadog/Grafana), reproduction steps, and severity assessment.

- Collaborate with developers and product managers to drive quality from feature design through release.

- Contribute to release decisions with risk assessments and test coverage summaries.

- Partner with cross-functional teams to elevate quality across the SDLC.

- Identify and advocate for opportunities to expand test coverage across the organization.

**Qualifications**

- BS/MS in Computer Science, Engineering, or equivalent technical experience.

- 5+ years of experience in software QA within SaaS, preferably in customer engagement or contact center platforms.

- Strong track record in creating and executing both manual and automated test strategies.

- Proficiency in automation frameworks (e.g., Playwright, Cypress) and modern development workflows.

- Deep understanding of QA methodologies, processes, and CI/CD practices.

- Attention to detail with a bias toward risk-based testing.

- Strong problem-solving and debugging skills, including backend and frontend issue investigation.

- Ability to think like an end-user and test accordingly, especially when product requirements are minimal or evolving.

- Excellent communication skills and the confidence to constructively advocate for quality.

- Experience mentoring peers or contributing to testing infrastructure is a plus.

**Compensation:**

Compensation for this position includes a base salary, equity, and a variety of benefits. Actual salaries will be based on candidate-specific factors, including experience, skills, and location, as well as applicable local minimum pay requirements. We are actively hiring for this role in Berlin. For further details, please consult your recruiter.

***Our use of AI in recruiting:**** We may use AI tools in our recruiting process, which require human review and oversight. If you have questions about our use of AI or wish to opt out, please contact ***
***Recording & AI transcription:**** We do not authorize candidates to record or use AI transcription of any interview by phone, notetaker app, AI glasses, or other device. Candidates may request an exception or accommodation for review during the interview process as needed.
*
***Recruiting impersonation scams:**** We have noticed a rise in recruiting impersonations across the industry, where scammers attempt to access candidates' personal and financial information through fake interviews and offers. All Cresta recruiting email communications will always come from the ----- domain. Any outreach claiming to be from Cresta via other sources should be ignored.*

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
