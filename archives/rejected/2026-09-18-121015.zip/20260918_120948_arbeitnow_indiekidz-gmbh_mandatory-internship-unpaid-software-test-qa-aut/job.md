# Mandatory Internship(Unpaid), Software Test(QA) Automation Engineer

Posted: 2026-09-18T09:30:53Z

## Rejection

- Category: role_mismatch
- Reason: title is an obvious mismatch for a backend profile

Occibo Studio(occibo[dot]com) is an AI powered SaaS app for children’s book creation. We are looking for a student intern to build and maintain UI test automation so we can ship fast with confidence.

**Location and mode**

Full **remote or once a month onsite** in Berlin. Preference for candidates who has test automation experience.

**Internship type**

**Unpaid**, mandatory internship as part of your degree.

## Tasks

**What you will do**

- Build end to end UI automation for the Occibo web app

- Write test plans, test cases, and regression suites for functional flows

- Convert product requirements into automated checks, including edge cases

- Set up test data strategies and stable selectors with the UI team

- Add API level checks where needed to reduce flaky UI tests

- Run tests in CI, track failures, triage bugs, and keep tests reliable

- Add basic performance and reliability checks for key user flows

- Use AI tools to speed up test creation, analysis, and maintenance

**Tools you might use**

Playwright, Cypress, Selenium, WebdriverIO, TestCafe

Jest, Vitest, Mocha

GitHub Actions or similar CI

## Requirements

- Currently enrolled in CS, Software Engineering, or related field

- Experience with at least one test automation framework, Playwright or Cypress preferred

- Comfortable with JavaScript or TypeScript, and Git

- Understands SaaS quality basics, CI, and reliable test design

- Interest in AI and experience using AI tools for engineering work

- Fluent English - speaking and writing

## Benefits

- Real product problems, not toy projects

- Mentorship and direct collaboration with the founder and team

- A portfolio of experiments, reports, and shipped prototypes you can reference

Nice to have

- Prior SaaS UI automation work, real project or internship

- Experience with API testing, Postman or REST clients

- Based in Berlin and can join onsite once a week

**How to apply**

Send a message with your CV, short note/cover letter(preferred), your best project link, the test framework you know, and your availability and start date.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
