# Werkstudent (m/w/d) Content Creation & Design

Posted: 2026-09-18T11:00:49Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Das Trikot ist das Aushängeschild eines Vereins. Ein Trikot ist Liebe, Emotion, Verantwortung & Tradition. Meist haben aber nur Profiteams die Möglichkeit, ihre Trikots individuell zu gestalten.

Hier setzen wir an: Wir haben eine Plattform entwickelt, auf der Sportler*innen mit Hilfe eines 3D-Konfigurators ihr hochwertiges & individuelles Trikot gestalten können.

## Aufgaben

- Ads & Creatives: Du gestaltest Static Ads und Video Ads für unsere Paid-Media-Kampagnen und entwickelst passende Creatives für unterschiedliche Plattformen und Zielgruppen.

- Content-Produktion: Du unterstützt bei der Planung und Umsetzung unserer Foto- und Videoproduktionen und bringst dabei deine kreativen Ideen ein.

- Inhouse-Produktionen: Kleinere Foto- und Videoproduktionen setzt du mit Unterstützung des Teams auch eigenständig um – von der Idee bis zum fertigen Content.

- Videoschnitt: Du bearbeitest und schneidest Video-Content für unsere Social-Media-Kanäle und Paid-Media-Kampagnen und bereitest ihn passend für die jeweiligen Formate auf.

## Qualifikation

- Du befindest dich in einem laufenden Studium im Bereich Medien, Kommunikation, Design oder vergleichbar

- Du hast erste Erfahrung in der Erstellung von Foto- & Videomaterial für Social Media

- Du arbeitest sicher mit Canva und Photoshop; Kenntnisse in Adobe Premiere Pro sind von Vorteil

- Du hast ein gutes visuelles Gespür, bist kreativ und interessierst dich für Sport und Social Media

- Du arbeitest strukturiert, eigenständig und bringst gute Deutsch- und Englischkenntnisse mit

## Benefits

Wir wissen, dass wir nur mit einem starken Team erfolgreich sein können!

Deshalb erwartet dich ein motiviertes und ambitioniertes Team bestehend aus A-Playern, die den Unternehmenserfolg vorantreiben. Aber auch sonst soll es dir an nichts fehlen:

- Hochwertige Apple-Ausstattung für ein produktives Arbeiten

- Modernes Office im Herzen von Ehrenfeld mit gemütlichem Pausenraum und Küche

- Flexible Arbeitszeiten, Home Office und Workation-Möglichkeiten

- Regelmäßige Teamevents und ein Buddyprogramm für dein Onboarding

- Mitarbeiterrabatte und Corporate Benefits

Bewerbe dich in nur 5 Minuten über den Bewerberfragebogen auf unserer Homepage oder schick uns deinen Lebenslauf und dein Portfolio inkl. Einstiegsdatum per E-Mail.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
