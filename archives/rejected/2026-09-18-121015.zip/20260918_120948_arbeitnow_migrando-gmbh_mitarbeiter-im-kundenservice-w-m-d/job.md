# Mitarbeiter im Kundenservice (w/m/d)

Posted: 2026-09-18T09:30:50Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

## Einleitung

**Wir sind auf der Suche nach neuen Kollegen!** Migrando ist ein Legal-Tech-Unternehmen aus Cottbus. Wir haben es uns zur Aufgabe gemacht, den komplizierten und langwierigen Prozess der Einbürgerung effizienter und kundenfreundlicher zu gestalten. Mit unserer Expertise im Ausländerrecht, unserer juristischen Kompetenz und einem starken Team von zahlreichen Mitarbeitern begleiten wir tausende Mandanten erfolgreich auf dem Weg zur deutschen Staatsbürgerschaft. Am besten verschaffst du dir gleich einen Einblick unter migrando(.)de/karriere, unserer Karriere-Page. Denn wir können hier schreiben was wir wollen, im Endeffekt bleibt es eine langweilige Einleitung.

**Uns ist egal, welche Zertifikate du hast oder wo du studiert hast.** Was uns interessiert: Was kannst du wirklich? Wer jahrelang in der Praxis gearbeitet und Hands-on-Erfahrungen gesammelt hat, bringt mehr mit als jeder Kursabschluss. Wenn du neugierig bist, Verantwortung nicht scheust und Lust hast, dich kontinuierlich weiterzuentwickeln, wollen wir dich kennenlernen.

## Wir bieten Dir

- **Klarer Fokus & keine Kaltakquise**

Du rufst niemanden unaufgefordert an. Du betreust ausschließlich warme Leads von Menschen, die sich bei uns gemeldet haben und unsere Hilfe wirklich wollen.

- **Moderne Vertriebsstruktur statt Excel-Chaos**

Wir arbeiten digital und mit System (z. B. HubSpot). Keine Zettelwirtschaft, sondern smarte Prozesse, die dir die Arbeit erleichtern.

- **Kein Callcenter-Feeling**

Bei uns gibt’s keine Fließbandgespräche, keine strengen Skripte und keine anonymen Großraumbüros. Du arbeitest an einem individuellen Arbeitsplatz in einem modernen Altbau-Büro.

- **High-End Hardware nach Wahl**

Egal ob MacBook Pro oder Windows-Tower. Du bekommst die Maschine, auf der du am besten performst.

- **Große Reichweite**

Über die Jahre konnten wir mit unserer Plattform bereits viele Menschen erreichen. Diese große Menge an Traffic ermöglicht es uns, viele heiße Leads zu haben, die deinen Arbeitsalltag zum Erfolgserlebnis machen. (15.000 Website-Klicks pro Tag, ca. 750 Leads pro Tag)

- **Wettbewerbsfähiges Gehalt & Sicherheit**

Wir schätzen deine Leistung mit einer fairen, guten Bezahlung und geben dir langfristige Perspektiven in einem unbefristeten Arbeitsverhältnis.

- **Feel-Good-Managerin im Haus**

Massage gefällig? Unsere festangestellte Feel-Good-Managerin sorgt für kleine Auszeiten und Entspannungsangebote zwischendurch.

- **Arbeiten im Herzen von Cottbus**

Zentrale Lage, großartige VBB-Anbindung und Mitarbeiterparkplätze direkt ums Eck. Kurze Wege für einen entspannten Alltag.

- **Legendäre Team-Events & Wertschätzung**

Wir sind überzeugt: Vertrieb funktioniert nur gemeinsam. Ellenbogenmentalität gibt es bei uns nicht – dafür aber coole Events und echte Wertschätzung im Alltag.

- **Kleine Teams statt Großraumbüro**

Du arbeitest in überschaubaren Teams, in denen man sich kennt und schnell ins Gespräch kommt.

- **Ergonomischer Arbeitsplatz mit moderner Ausstattung**

Rückenfreundlicher Stuhl, höhenverstellbarer Tisch, zwei große Monitore, ein hochwertiges Headset, ein leistungsstarker Laptop und eine ruhige Umgebung.

- **Homeoffice-Möglichkeit**

Grundsätzlich arbeiten wir im Büro, weil Zusammenarbeit und Austausch vor Ort für uns wichtig sind. Gleichzeitig ist Home Office jederzeit möglich. Auch spontan und ohne lange Abstimmung.

- **Vertrauensarbeitszeit ohne Kernzeiten**

Bei uns gibt es keine vorgeschriebenen Zeitfenster, in denen du anwesend sein musst.

- **Flexible Teilzeitmodelle**

Ob 4-Tage-Woche, 30 Stunden oder ein individuelles Modell. Dein Job soll zu deinem Leben passen, nicht andersherum.

- **Spontan Urlaub nehmen**

Manchmal braucht man einfach eine Auszeit. Wir planen unsere Teams so, dass auch spontane freie Tage möglich sind, ganz ohne Stress oder schlechtes Gewissen.

- **Familienfreundliche Kultur**

Kranke Kinder, Elternabend oder kurzfristiger Arzttermin – wir wissen, dass solche Situationen zum Alltag gehören. Familie und Gesundheit haben bei uns Vorrang.

- **Kurze Wege**

Bei uns musst du dich nicht durch die Hierarchien hangeln oder lange Mails schreiben, um gehört zu werden. Du kannst jederzeit direkt mit Kolleg:innen, Teamleads oder der Geschäftsführung sprechen. Entscheidungen fallen schnell, Austausch ist direkt und niemand sitzt „im Elfenbeinturm“.

- **Mitgestalten statt nur abarbeiten**

Wir suchen Kolleg:innen, die mitdenken. Wenn du eine Idee hast, wie ein Prozess besser laufen kann, ein Tool sinnvoll wäre oder ein Workflow smarter funktionieren könnte, dann wirst du gehört.

- **Sinnstiftende Arbeit**

Deine Tätigkeit hat direkten Einfluss auf das Leben von Menschen. Du unterstützt sie dabei, in Deutschland anzukommen, Sicherheit zu finden und ein neues Kapitel aufzuschlagen. Das ist keine trockene Büroarbeit – es ist Arbeit mit echter Bedeutung und spürbarer Wirkung.

- **Fitnessraum im Haus**

Unser eigener Fitnessraum steht dir direkt im Haus zur Verfügung – kostenlos, gut ausgestattet und jederzeit zugänglich.

## Mögliche Aufgabenbereiche

- **Erste Anlaufstelle über alle Kanäle**

Ob Telefon, Ticketsystem oder Social Media: Du bist die Stimme von Migrando und hilfst schnell und freundlich weiter, egal wo die Anfrage reinkommt.

- **Fragen rund um die Einbürgerung beantworten**

Du gibst Auskunft zu unseren Leistungen und erklärst, wie der Weg zur Staatsbürgerschaft bei uns abläuft.

- **Statusauskünfte zum Verfahren**

Du schaust im System nach, wo ein Vorgang gerade steht, und erklärst den nächsten Schritt so, dass ihn auch jemand ohne Fachwissen versteht.

- **Erklären in einfacher Sprache**

Viele unserer Mandant:innen lernen gerade erst Deutsch. Du findest Worte, die ankommen, und wiederholst auch gern ein zweites Mal.

- **Aktives, einfühlsames Zuhören**

Du hörst nicht nur, was gefragt wird, sondern erkennst auch, was dahintersteckt, und gehst genau darauf ein.

- **Termine vereinbaren und verwalten**

Du stimmst Rückrufe und Gesprächstermine ab und behältst im Blick, wer wann eine Rückmeldung erwartet.

- **Nachforderung fehlender Unterlagen**

Du erinnerst freundlich an offene Dokumente und erklärst, warum sie gebraucht werden.

- **Saubere Dokumentation in unseren Systemen**

Du hältst fest, was besprochen wurde, inklusive Rückmeldungen, Beschwerden und Lösungen. So haben alle Kolleg:innen den gleichen Stand.

- **Schnittstelle zur Sachbearbeitung und zum Anwaltsteam**

Wenn eine Frage tiefer geht, leitest du sauber weiter, gibst den Kontext mit und sorgst dafür, dass niemand zweimal dasselbe erzählen muss.

- **Umgang mit Beschwerden und Unmut**

Wenn jemand ungeduldig oder enttäuscht ist, bleibst du ruhig, nimmst das ernst und findest gemeinsam eine Lösung.

- **Muster erkennen und Verbesserungen anstoßen**

Wenn dieselbe Frage ständig kommt, sagst du Bescheid. Daraus bauen wir bessere Infos, damit das Problem gar nicht erst entsteht.

## Dein Profil

- **Erfahrung im Kundenservice oder Lust darauf**

Du hast schon im Service gearbeitet? Perfekt. Du bist Quereinsteiger:in mit Leidenschaft für guten Kontakt zu Menschen? Genauso gern.

- **Freude am Kontakt mit Menschen**

Du telefonierst gern, hörst aktiv zu und hast keine Scheu davor, den ganzen Tag im Gespräch zu sein.

- **Geduld und ein langer Atem**

Manche Fragen kommen zum dritten Mal. Für dich ist das kein Problem, sondern normal.

- **Empathie und interkulturelle Offenheit**

Du arbeitest mit Menschen aus ganz unterschiedlichen Ländern und Lebenslagen und begegnest allen auf Augenhöhe.

- **Klare, einfache Kommunikation**

Du kannst komplizierte Sachverhalte so erklären, dass sie auch ohne Vorwissen verständlich sind, am Telefon wie schriftlich.

- **Gute Deutschkenntnisse in Wort und Schrift**

Deutsch ist dein tägliches Arbeitswerkzeug. Alle weiteren Sprachen sind ein echtes Plus.

- **Kundenorientierung und Teamgeist**

Du bringst beides zusammen: Du willst den Menschen am Telefon wirklich helfen und arbeitest gleichzeitig gut mit deinen Kolleg:innen zusammen.

- **Zuverlässigkeit und Struktur**

Du behältst den Überblick, auch wenn viele Anfragen gleichzeitig reinkommen, und vergisst keine Rückmeldung.

- **Ruhe in stressigen Momenten**

Wenn es hektisch wird oder jemand verärgert ist, bleibst du sachlich und freundlich.

- **Sicherer Umgang mit dem PC**

E-Mail, Telefonanlage und Ticketsystem sind für dich kein Neuland. Erfahrung mit CRM-Systemen wie HubSpot ist ein Plus, aber kein Muss. Wir zeigen dir alles.

- **Sorgfalt bei der Dokumentation**

Du hältst fest, was besprochen wurde, weil davon die Arbeit deiner Kolleg:innen abhängt.

- **Diskretion**

Du gehst mit sensiblen Daten verantwortungsvoll um. Schweigepflicht ist für dich selbstverständlich.

- **Lernbereitschaft**

Rechtliche Vorkenntnisse brauchst du nicht. Interesse daran, dich einzuarbeiten, aber schon.

- **Keine formellen Voraussetzungen**

Du brauchst kein Studium und keine zehn Jahre Berufserfahrung. Auch wenn nur die Hälfte hier auf dich zutrifft: Bewirb dich.
**Wie geht’s weiter?**

Einfach online bewerben, Lebenslauf hochladen und vielleicht trinken wir schon bald zusammen einen Kaffee im Büro. Mach dir keinen Stress mit Zeugnissen – zeig uns einfach, was du kannst.

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
