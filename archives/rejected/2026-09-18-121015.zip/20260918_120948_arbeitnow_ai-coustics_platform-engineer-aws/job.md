# Platform Engineer (AWS)

Posted: 2026-09-18T10:00:28Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Voice is becoming the primary interface for technology. For the first time in history, we can use natural language to control and interact with our devices, services, and applications, and we're only at the beginning of the adoption of Voice and Physical AI across industries. Current voice interactions, however, still lack a fundamental human skill: nuanced understanding of audio scenes and environments. Navigating complex auditory scenes, distinguishing between multiple voices, or focusing on a main speaker are all part of the challenge of "teaching machines to hear like human beings."

At ai-coustics, we're building the audio intelligence layer and developer tooling to enable more robust and intelligent voice agents and Physical AI applications. Today, Voice AI companies like Perplexity, PolyAI, LiveKit, AssemblyAI or Telli use our SDK to prepare their agents for real-world acoustic challenges. Our models power thousands of agents worldwide and process millions of hours each month.

We are backed by leading early-stage investors including Connect Ventures, Partech, Inovia Capital, as well as angel investors from HuggingFace, DeepMind and Amazon with deep expertise in AI and developer infrastructure. These partners share our vision and are helping us build a world-class team operating with high levels of responsibility and velocity. We look for people who take ownership, think systemically, and want to solve challenging real-world problems in close collaboration with our customers.

### **Role overview**

We're looking for a Platform Engineer to own our cloud infrastructure on AWS. Our SDK runs on customers' devices and servers, and every session talks to our platform: EKS clusters, Aurora Postgres, ElastiCache, CloudFront, Temporal, all managed with Terraform and GitOps. You will be the single accountable owner of this platform: its reliability, security, cost and the deployment pipelines the engineering teams rely on.

Security controls, access management and evidence are part of the job. You report to the CTO and work daily with the backend lead and our IT operations engineer.

### **

Tasks**

- Own the AWS infrastructure end to end: Terraform, multi-account setup, networking, IAM, EKS, databases, CDN

- Run the Kubernetes stack: service mesh, certificates, secrets management, autoscaling, upgrades

- Own observability for the platform: metrics, logs, alerting and the dashboards teams operate from

- Build and maintain the CI/CD pipelines and deploy roles for our backend and frontend services

- Implement and maintain the technical controls for SOC 2 and keep the evidence current

- Plan capacity for continued fast growth and own platform cost

- Be on-call for the infrastructure, write runbooks and run incident reviews

### **

Requirements**

- 5+ years running production infrastructure on AWS with Terraform

- Deep EKS experience: node pools, autoscaling, networking and IP planning, upgrades, workload placement

- Certified Kubernetes Administrator (CKA) or AWS Certified CloudOps Engineer – Associate (formerly SysOps Administrator), or both

- You design IAM and access with least privilege and can explain your decisions to an auditor

- You have been the single accountable infrastructure owner at a company, not one engineer in a large SRE team

- Strong Linux, networking and debugging skills across the stack

- You automate everything repeatable and treat infrastructure changes like code: reviewed, tested, reversible

- You use AI coding tools daily and know where they help and where they don't

- Bonus: SOC 2 or ISO 27001 controls and evidence work, Istio, Temporal, GitHub Actions with OIDC, cost optimization, CloudFront and WAF

### **

You may not be a great fit if…**

- You have only operated infrastructure someone else designed

- You prefer application development over infrastructure

- You want to hand security and compliance to a separate team

- On-call is a dealbreaker for you

- Remote-first is a hard requirement for you

### **

Compensation**

Base salary of **€80,000 – €100,000 per year** (Berlin, senior level), plus stock options. Where you land in the range depends on your experience and the depth of your AWS and EKS ownership.

### **

Benefits**

- Work on real-time audio infrastructure used by voice AI companies worldwide, at a rapidly growing startup backed by top investors.

- Competitive package with stock options, so you take part in the company's success.

- Small team, direct access to the founders and full ownership of your area.

- Berlin office with a hybrid setup, and the trust to ship fast.

- World-class team of engineers and researchers with ample room for professional growth.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
