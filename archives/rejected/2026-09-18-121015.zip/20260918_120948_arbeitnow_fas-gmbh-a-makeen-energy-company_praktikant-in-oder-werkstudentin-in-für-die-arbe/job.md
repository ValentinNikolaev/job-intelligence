# Praktikant*in oder Werkstudentin*in für die Arbeitsvorbereitung - Bachelor- oder Masterarbeit möglich

Posted: 2026-09-18T10:00:27Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Du möchtest praktische Erfahrungen sammeln, Verantwortung übernehmen und einen direkten Einblick in unsere betrieblichen Abläufe bekommen?

Dann bist du bei uns genau richtig!

## Aufgaben

- Erfassung und Verbuchung von Arbeitskarten

- Prüfung der Arbeitskarten auf Vollständigkeit und Plausibilität

- Pflege und Aktualisierung von Daten in unseren Systemen

- Unterstützung bei der Aufbereitung und Kontrolle von Arbeitsdaten

- Nachverfolgung und Zuordnung von Arbeitsvorgängen

- Allgemeinen Aufgaben und Projekten innerhalb der Arbeitsvorbereitung

## Qualifikation

- Interesse an technischen und organisatorischen Abläufen

- Eine sorgfältige und zuverlässige Arbeitsweise

- Spaß am Umgang mit Daten und Zahlen

- Teamgeist und Kommunikationsfähigkeit

- Eigeninitiative und die Bereitschaft, Neues zu lernen

## Benefits

Dich erwartet eine spannende und abwechslungsreiche Tätigkeit in einem familiären Arbeitsumfeld, das von Humor und Engagement geprägt ist.

MAKEEN Energy ist ein wertebasiertes Unternehmen, und daher ist es wichtig, dass Du eine Übereinstimmung zwischen Deinen eigenen und den Werten des Unternehmens erkennen kannst. Mehr dazu erfährst du hier.

Wir setzen auf eine kooperative Zusammenarbeit mit flachen Hierarchien und starkem Teamgeist.

- Eine verantwortungsvolle Position in einem wachsenden internationalen Umfeld mit flachen Hierarchien

- Eine spannende Aufgabe mit viel Eigenverantwortung

- 30 Tage Urlaub

- Intensive Einarbeitung durch ein freundliches, kollegiales Team

- Urlaubs- und Weihnachtsgeld

Wir freuen uns auf Dich!

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
