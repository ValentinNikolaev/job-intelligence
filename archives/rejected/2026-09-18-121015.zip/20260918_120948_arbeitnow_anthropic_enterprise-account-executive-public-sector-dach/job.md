# Enterprise Account Executive, Public Sector, DACH

Posted: 2026-09-18T08:55:17Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

## **About Anthropic**

Anthropic’s mission is to create reliable, interpretable, and steerable AI systems. We want AI to be safe and beneficial for our users and for society as a whole. Our team is a quickly growing group of committed researchers, engineers, policy experts, and business leaders working together to build beneficial AI systems.

## **About the role**

As an Enterprise Account Executive at Anthropic, you'll join the foundational team at the forefront of introducing our cutting-edge AI productivity SaaS solution to large enterprise organizations across DACH. You'll drive the adoption of safe, frontier AI by securing strategic deals with major corporations, technology companies, and research institutions. You'll leverage your consultative sales expertise in the enterprise sector to propel revenue growth while becoming a trusted partner to enterprise stakeholders, helping them embed and deploy AI while uncovering its full range of capabilities across business operations, research, and administration. In collaboration with GTM, Product, and Marketing teams, you'll continuously refine our value proposition, sales methodology, and market positioning to resonate with enterprise decision-makers in the German market.

## **Responsibilities:**

- Win new business and drive revenue for Anthropic within the enterprise sector across DACH. Navigate complex enterprise organizations to reach key decision-makers, educate them about our services, and help them succeed with Anthropic. You'll own the full sales cycle, from first outbound to close

- Design and execute innovative sales strategies tailored to enterprise procurement cycles and budgeting processes to meet and exceed revenue quotas. Analyze enterprise market landscapes, trends, and dynamics to translate high-level plans into targeted sales activities and campaigns

- Spearhead market expansion by identifying new use cases within enterprise departments, innovation centers, and operational offices. Collaborate cross-functionally to differentiate our offerings for enterprise applications

- Navigate complex enterprise stakeholder ecosystems including executives, administrators, IT departments, and procurement offices to build consensus across DACH business culture and practices

- Inform product roadmaps and features by gathering feedback from enterprise users and conveying market needs from the German enterprise landscape. Provide insights that strengthen our value proposition for enterprise customers

- Continuously refine the enterprise sales methodology by incorporating learnings into playbooks, templates, and best practices. Identify process improvements that optimize sales productivity and consistency

## **You may be a good fit if you have:**

- **Native German speaker** with excellent written and verbal communication skills in German and English

- 7+ years of B2B sales experience in enterprise technology, preferably in SaaS or emerging technologies

- Specialised sales industries experience: Public Sector

- A track record of managing complex sales cycles within large enterprise organizations and securing strategic deals by understanding both technical requirements and business use cases

- Demonstrated ability to navigate enterprise bureaucracies and procurement processes, building consensus among diverse stakeholders including executives, administrators, and IT departments

- Extensive experience negotiating complex agreements within enterprise procurement frameworks and policies

- Proven experience exceeding revenue targets in the enterprise sector by effectively managing an evolving pipeline and sales process

- Excellent communication skills and the ability to present confidently to various enterprise audiences, from technical teams and business analysts to senior executives

- Deep understanding of enterprise buying cycles, decision-making processes, and key pain points, particularly within the German market

- A strategic, analytical approach to assessing the enterprise market combined with creative, tactical execution to capture opportunities

- A passion for and/or experience with advanced AI systems and their applications in enterprise environments. You feel strongly about ensuring frontier AI systems are developed safely and ethically for business use

## **What We Offer:**

- Competitive base salary and commission structure

- Equity participation in Anthropic's growth

- Comprehensive benefits package

- Opportunity to shape the AI industry in DACH and EMEA

- Professional development and career growth opportunities

**Location:** Munich, Germany (hybrid working available)

## **Logistics**

**Minimum education: **Bachelor’s degree or an equivalent combination of education, training, and/or experience

**Required field of study: **A field relevant to the role as demonstrated through coursework, training, or professional experience

**Minimum years of experience: **Years of experience required will correlate with the internal job level requirements for the position

**Location-based hybrid policy:** Currently, we expect all staff to be in one of our offices at least 25% of the time. However, some roles may require more time in our offices.

**Visa sponsorship:** We do sponsor visas! However, we aren't able to successfully sponsor visas for every role and every candidate. But if we make you an offer, we will make every reasonable effort to get you a visa, and we retain an immigration lawyer to help with this.

**We encourage you to apply even if you do not believe you meet every single qualification.** Not all strong candidates will meet every single qualification as listed. Research shows that people who identify as being from underrepresented groups are more prone to experiencing imposter syndrome and doubting the strength of their candidacy, so we urge you not to exclude yourself prematurely and to submit an application if you're interested in this work. We think AI systems like the ones we're building have enormous social and ethical implications. We think this makes representation even more important, and we strive to include a range of diverse perspectives on our team.

**Your safety matters to us.** To protect yourself from potential scams, remember that Anthropic recruiters only contact you ----- addresses. In some cases, we may partner with vetted recruiting agencies who will identify themselves as working on behalf of Anthropic. Be cautious of emails from other domains. Legitimate Anthropic recruiters will never ask for money, fees, or banking information before your first day. If you're ever unsure about a communication, don't click any links—visit [anthropic.com/careers](http://anthropic.com/careers) directly for confirmed position openings.

## **How we're different**

We believe that the highest-impact AI research will be big science. At Anthropic we work as a single cohesive team on just a few large-scale research efforts. And we value impact — advancing our long-term goals of steerable, trustworthy AI — rather than work on smaller and more specific puzzles. We view AI research as an empirical science, which has as much in common with physics and biology as with traditional efforts in computer science. We're an extremely collaborative group, and we host frequent research discussions to ensure that we are pursuing the highest-impact work at any given time. As such, we greatly value communication skills.

The easiest way to understand our research directions is to read our recent research. This research continues many of the directions our team worked on prior to Anthropic, including: GPT-3, Circuit-Based Interpretability, Multimodal Neurons, Scaling Laws, AI & Compute, Concrete Problems in AI Safety, and Learning from Human Preferences.

## **Come work with us!**

Anthropic is a public benefit corporation headquartered in San Francisco. We offer competitive compensation and benefits, optional equity donation matching, generous vacation and parental leave, flexible working hours, and a lovely office space in which to collaborate with colleagues. **Guidance on Candidates' AI Usage:** Learn about [our policy](https://www.anthropic.com/candidate-ai-guidance) for using AI in our application process.

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
