# Revenue Operations Manager - Sales Excellence

Posted: 2026-09-18T08:40:04Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

### **About SoSafe**

SoSafe is a leading human risk management platform designed to transform the "human factor" from a security vulnerability into a proactive layer of defense. We focus on driving measurable behavior change and quantifiable risk reduction for our global customers.

### **Your Role: Drive Sales Performance & Velocity**

As **Revenue Operations Manager** for Sales Excellence, you will be the strategic partner to our Sales leadership and the operational engine behind our Account Executives. Across the SaaS industry, sales cycles have recently increased by 3-4 weeks on average. Furthermore, industry-wide SQL to Closed-Won conversion rates have dropped. Your core mission is to counteract these market headwinds by optimizing our sales mechanics, critical processes, and pipeline management.

You will ensure that our AEs spend less time on administrative friction and more time executing a frictionless, high-converting sales process tailored to our mid-market European buyers.

### **What you will own (key responsibilities)**

-

**Operationalize the 2026 ICP: **Drive strict alignment with our new Ideal Customer Profile, focusing our AE efforts on corporate to mid-enterprise EU organizations with 500 to 5,000 employees. Equip the sales team to prioritize accounts in regulated industries (e.g., Manufacturing, Finance, Healthcare) that are driven by compliance mandates like NIS2 and DORA.

-

**Optimize our Buyer Journey: **Tailor our Salesforce deal stages and qualification methodology to engage the right stakeholders at the right time. Specifically, build workflows that help AEs navigate the Head of IT, who acts as the primary decision-maker in our core mid-market deals.

-

**Pipeline & Forecasting: **Manage our Clari forecasting architecture to move the sales organization from "available data" to "actionable insights." Track and optimize foundational sales metrics such as Pipeline Velocity, Average Time in Stage, and Stage Conversion. Ensure pipeline health by maintaining a target Pipeline Coverage ratio of 3-4x.

-

**Deal Desk & Approval Processes: **Own and refine the Deal Desk and commercial approval processes within Salesforce. Create a streamlined pricing and discounting framework that protects our margins while accelerating deal velocity.

-

**Tech Stack Optimization: **Maximize the ROI of our GTM tech stack, acting as the business owner for tools like Salesloft or Clari. Implement AI-driven intelligence and automation to improve rep productivity.

-

**Cross-Functional Alignment:** Act as the strategic bridge between CS, Sales and Marketing leadership as well as our Product Organisation to build a friction-free customer journey. Align sales processes with our target mid-market enterprise ICP (501–5,000 employee companies in highly regulated sectors).

### **What You Bring (requirements)**

-

**Experience: **5+ years of professional experience in Revenue Operations, Sales Operations, or Sales Strategy ideally within a high-growth B2B SaaS environment.

-

**Sales Process Mastery: **You possess a deep understanding of B2B sales methodologies (MEDDIC etc.) and know how to hardwire these frameworks directly into CRM validation rules and sales stages.

-

**Analytical & Financial mindset: **You are highly fluent in modern SaaS and sales performance metrics. You deeply understand the mechanics of Win Rates, Sales Cycle Length, CAC Payback, Net Magic Number, and the Rule of 40.

-

**Tech Stack Expertise: **Advanced administration and architectural experience with Salesforce (SFDC) and a leading forecasting platform (Clari preferred). Familiarity with Salesloft or similar sales engagement platforms is highly advantageous.

-

**Strategic Execution: **You are not a reactive ticket-taker. You proactively analyze Pipeline Flow and Forecast vs. Actuals dashboards to identify bottlenecks and present data-backed recommendations to the CRO and Director of RevOps.

### **Why Join the SoSafe RevOps Team?**

-

**A Seat at the Table:** Our RevOps organization manages the entire GTM stack and architecture. You will have direct exposure to executive leaders (CRO, COO, and Director of RevOps) and have a large, visible impact on our profitability journey.

-

**Cutting-Edge Stack:** We don’t tolerate legacy tech debt. You will work with a modern infrastructure, including Salesforce, HubSpot, Salesloft, Clari CoPilot, and cutting-edge tools like Clay or Claude.

-

**Team Culture:** Join a highly collaborative group of operations professionals and GTM engineers who balance top-tier technical performance with wit, humility, and zero ego. And join our fun team events!

**What we offer***

-

Work/Life balance: Flexible hours, 33 vacation days

-

Wellbeing and financial support: Access to Open Up, corporate discounts

-

Connection & community: Virtual events, collaborative team activities, and opportunities for local meet-ups

-

And the list goes on: Tech equipment, referral bonuses, dog-friendly HQ

**Perks and benefits listed above are for full-time employees and may vary slightly by office location. These are just a sample — you'll learn more during the interview process.*

**About Us**

At SoSafe, we’re on a mission to make the digital world safer by addressing the human factor in cybersecurity. As one of the fastest-growing security awareness scale-ups worldwide, we leverage behavioural science and data-driven learning to empower people against cyber threats. Our Human Risk Management approach helps organisations turn their employees into their strongest line of defence.

Backed by leading VCs like Highland Europe and Global Founders Capital, we’re rapidly expanding across the globe. We’re looking for team players who want to drive meaningful change in cybersecurity, take ownership of their work, and grow with us.

If you thrive in a vibrant, purpose-driven environment that values innovation, diversity, and collaboration, then this is the place for you!

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
