# Business Unit Leiter Banking (w/m/d)

Posted: 2026-09-18T09:00:51Z

## Rejection

- Category: tech_stack
- Reason: role does not mention Go/Golang or PHP

**Über cognitivo**

Die cognitivo AG ist eine spezialisierte Unternehmensberatung für Software und Analytics mit Hauptsitz in Karlsruhe. Seit 2013 begleiten wir Banken, Versicherungen und Zahlungsdienstleister entlang ihrer gesamten Wertschöpfungskette – von der Strategie bis zur Abnahme. Unser Leitsatz: „Big enough to deliver and small enough to care.“

**Gestalte die Zukunft unserer Business Unit Banking**

Als Leiter Business Unit Banking übernimmst du die unternehmerische Gesamtverantwortung für die Weiterentwicklung unserer Business Unit und gestaltest damit maßgeblich ihre Zukunft. Du verbindest strategisches Denken, Führungsstärke und vertriebliche Verantwortung mit einem tiefen Verständnis für die Anforderungen des Banking- und Payment-Marktes. Gemeinsam mit einem engagierten Team entwickelst du unsere Kundenbeziehungen weiter, erschließt neue Geschäftsfelder und sorgst dafür, dass aus Marktchancen nachhaltiges Wachstum entsteht. Dabei arbeitest du eng mit unseren Kunden auf Management-Ebene zusammen und behältst die wirtschaftliche Entwicklung der Business Unit stets im Blick.

## Aufgaben

**Was dich bei uns erwartet**

- Du steuerst und entwickelst die Business Unit Banking mit einem Team von 5 bis 10 Mitarbeitenden und trägst

- Verantwortung für Umsatz, Profitabilität, Wachstum und die strategische Zielerreichung. Gemeinsam mit dem

- Team entwickelst du eine nachhaltige Wachstumsstrategie, stärkst unsere Marktposition und identifizierst neue

- Projekte, Geschäftsfelder, Trends und Marktchancen. Daraus entwickelst du gemeinsam mit unseren internen

- Teams passende Vertriebs- und Leistungsangebote.

**Kunden & Vertrieb**

- Betreuung von Key Accounts und Entwicklung von Cross- und Upselling-Potenzialen

- Ausbau langfristiger Partnerschaften auf Management-Ebene

- Steuerung des gesamten Vertriebsprozesses – von der Identifikation neuer Opportunities über die

- Angebotserstellung bis zum Vertragsabschluss

- Sichtbare Marktpräsenz durch Netzwerkpflege, Kundenveranstaltungen, Fachbeiträge, Partnerschaften und

- strategische Kontakte

**Operative Verantwortung & Führung**

- Sicherstellung einer effizienten und kundenorientierten Leistungserbringung

- Aktive Mitarbeit in IT-Projekten von der Konzeption bis zur erfolgreichen Implementierung

- Führung, Motivation und Entwicklung unserer IT-Projektmanager und Consultants

- Förderung von Eigenverantwortung und Expertenkompetenzen sowie gezielte Gewinnung neuer Talent

## Qualifikation

**Das bringst du mit**

- Du verbindest Führungserfahrung mit ausgeprägtem unternehmerischem Denken, trittst souverän und überzeugend auf und übernimmst gerne die Gesamtverantwortung für die Entwicklung einer Business Unit

- Erfolgreich abgeschlossenes Studium in BWL, Informatik, Wirtschaftsinformatik, Wirtschaftsmathematik oder eine vergleichbare Qualifikation

- Mindestens fünf Jahre Erfahrung in der disziplinarischen Führung von Teams

- Erfahrung im B2B-Vertrieb und Freude daran, Kundenbeziehungen aufzubauen und nachhaltig weiterzuentwickeln

- Ein breites Netzwerk in der Payment- und Bankenbranche ist von Vorteil

- Sichere Kommunikation auf Deutsch und Englisch

- Bereitschaft, dort zu arbeiten, wo du gebraucht wirst – direkt beim Kunden, in einer unserer Niederlassungen oder zeitweise remote

## Benefits

**Das bieten wir dir**

- Dich erwartet eine verantwortungsvolle und unternehmerisch geprägte Position mit flachen Hierarchien

- und kurzen Entscheidungswegen. Wir bieten dir attraktive Benefits wie Edenredkarte, Jobrad und

- betriebliche Altersvorsorge sowie ein umfangreiches Weiterbildungsangebot.

- Dazu kommen ein unbefristeter Arbeitsvertrag mit attraktiver Vergütung und 30+2 Urlaubstagen pro Jahr, steigend mit der Betriebszugehörigkeit.

**Warum cognitivo?**

Wir verbinden fachliches Verständnis, Technologie und Beratung und begleiten unsere Kunden bei der Entwicklung und Umsetzung innovativer IT-Lösungen im Banking- und Payment-Umfeld. In deiner Rolle gestaltest du nicht nur Kundenbeziehungen und Projekte, sondern entwickelst eine gesamte Business Unit unternehmerisch weiter – und kannst deine Führungsstärke sowie deine strategischen und vertrieblichen Kompetenzen gezielt einsetzen und weiterentwickeln.

**Bereit für den nächsten Schritt?**

Du möchtest Verantwortung übernehmen, Kundenbeziehungen nachhaltig ausbauen, neue Geschäftsmöglichkeiten entwickeln und gemeinsam mit einem engagierten Team innovative IT-Lösungen für den Banking-Markt vorantreiben? Dann freuen wir uns auf deine aussagekräftige Bewerbung!

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
