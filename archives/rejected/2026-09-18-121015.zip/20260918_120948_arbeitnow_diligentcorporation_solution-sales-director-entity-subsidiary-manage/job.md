# Solution Sales Director - Entity & Subsidiary Management

Posted: 2026-09-18T08:55:06Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**Position Overview:**

The Solutions Sales Director will play an instrumental role in driving revenue growth for Diligent’s solutions across existing and new accounts. This role is focused on candidates with strong expertise in **entity management space**, either as a practitioner (e.g., company secretary) or someone who has directly used entity management tools in a commercial or operational setting. The Solutions Sales Director is responsible for managing larger, complex accounts with longer sales cycles and driving adoption of the Diligent One Platform.

This individual contributor position manages the full sales cycle, from initial prospect/customer meetings through to deal completion, while orchestrating internal expertise to deliver on and grow accounts. Providing coaching, guidance, and support to Sales stakeholders is a key element to enable team members to learn best practices. Success in this role is measured by expanding product usage in existing customers, migrating customers to the Diligent One Platform, and selling to new accounts.

**Key Responsibilities:**

- Demonstrate and maintain expert-level knowledge of Diligent’s entity and subsidiary management solutions.

- Prospect and manage new and existing business within the designated territory, focusing on larger, complex accounts with longer sales cycles.

- Apply a consultative ‘solutions selling’ approach, using deep domain expertise to understand customer needs and position the Diligent One Platform effectively.

- Leverage industry-focused insights to create long-term competitive advantages for customers.

- Expand strategic customer relationships and drive growth across multiple areas of the organisation.

- Gather feedback from customers on needs, products, and features; collaborate with product management and marketing to drive improvements.

- Develop strategic account plans that generate new business and upsell opportunities, coordinating cross-functional teams to execute plans.

- Manage the end-to-end sales cycle using Diligent-approved methodologies.

- Utilize sales tools to identify leads, schedule meetings, and increase win rates.

- Maintain accurate CRM records, forecasts, and regular reporting on pipeline and bookings.

- Understand competitor landscape, customer strategy, and industry trends.

- Partner with Sales stakeholders to discover and qualify new opportunities, building a structured pipeline.

**Required Experience/Skills:**

- Experience in the** entity management**** space**, either as a practitioner (Corporate Secretary or similar) or selling entity/subsidiary management solutions.

- Proven success in account management or new business, achieving revenue targets in the technology, SaaS, or GRC sectors.

- Ability to build and maintain relationships with diverse stakeholders at all levels.

- Continuous learning mindset with a desire to expand knowledge of products, industry trends, and customer challenges.

- Excellent communication, presentation, and influencing skills.

- High curiosity and empathy to understand customer context, issues, and pain points through effective questioning and listening.

- Self-motivated, results-driven, and able to operate effectively in a fast-paced, dynamic environment.

#LI-HB1

#LI-Hybrid

**About Us**

Diligent is the AI leader in governance, risk and compliance (GRC) SaaS solutions, helping more than 1 million users and 700,000 board members to clarify risk and elevate governance. The Diligent One Platform gives practitioners, the C-Suite and the board a consolidated view of their entire GRC practice so they can more effectively manage risk, build greater resilience and make better decisions, faster.

At Diligent, we're building the future with people who think boldly and move fast. Whether you're designing systems that leverage large language models or part of a team reimaging workflows with AI, you'll help us unlock entirely new ways of working and thinking. Curiosity is in our DNA, we look for individuals willing to ask the big questions and experiment fearlessly - those who embrace change not as a challenge, but as an opportunity. The future belongs to those who keep learning, and we are building it together. At Diligent, you’re not just building the future - you’re an agent of positive change, joining a global community on a mission to make an impact.

Learn more at diligent.com or follow us on [LinkedIn](https://www.linkedin.com/company/diligent-board-member-services/mycompany/verification/) and [Facebook](https://www.facebook.com/DiligentCorporation/)

**What Diligent Offers You**

- **Creativity is ingrained in our culture.** We are innovative collaborators by nature. We thrive in exploring how things can be differently both in our internal processes and to help our clients

- **We care about our people. **Diligent offers a flexible work environment, global days of service, comprehensive health benefits, meeting free days, generous time off policy and wellness programs to name a few

- **We have teams all over the world**. We may be headquartered in New York City, but we have office hubs in Washington D.C., Vancouver, London, Galway, Budapest, Munich, Bengaluru, Singapore, and Sydney.

- **Diversity is important to us.** Growing, maintaining and promoting a diverse team is a top priority for us. We foster and encourage diversity through our Employee Resource Groups and provide access to resources and education to support the education of our team, facilitate dialogue, and foster understanding.

Diligent created the modern governance movement. Our world-changing idea is to empower leaders with the technology, insights and connections they need to drive greater impact and accountability – to lead with purpose. Our employees are passionate, smart, and creative people who not only want to help build the software company of the future, but who want to make the world a more sustainable, equitable and better place.

Headquartered in New York, Diligent has offices in Washington D.C., London, Galway, Budapest, Vancouver, Bengaluru, Munich, Singapore and Sydney.  To foster strong collaboration and connection, this role will follow a hybrid work model. If you are within a commuting distance to one of our Diligent office locations, you will be expected to **work onsite at least 50% of the time.** We believe that in-person engagement helps drive innovation, teamwork, and a strong sense of community.

Diligent is proud to be an equal opportunity employer. We do not discriminate based on race, color, religious creed, sex, national origin, ancestry, citizenship status, pregnancy, childbirth, physical disability, mental disability, age, military status, protected veteran status, marital status, registered domestic partner or civil union status, gender (including sex stereotyping and gender identity or expression), medical condition (including, but not limited to, cancer related or HIV/AIDS related), genetic information, or sexual orientation in accordance with applicable federal, state and local laws. We also consider qualified applicants regardless of criminal histories, consistent with legal requirements. See also Diligent's [EEO Policy](https://www.diligent.com/company/eeo-policy) and [US EEOC](https://www.diligent.com/-/media/project/diligent/master/eeo-is-the-law-poster-eeocselfprintposter-and-ofccp-supplement-from-20170719.pdf?rev=96fafda8-f51d-44b6-a380-9af42898f526&hash=614AE342F4AB51A091EA3E15F84F7E49)[’](https://www.diligent.com/-/media/project/diligent/master/eeo-is-the-law-poster-eeocselfprintposter-and-ofccp-supplement-from-20170719.pdf?rev=96fafda8-f51d-44b6-a380-9af42898f526&hash=614AE342F4AB51A091EA3E15F84F7E49)[s Know Your Rights](https://www.diligent.com/-/media/project/diligent/master/eeo-is-the-law-poster-eeocselfprintposter-and-ofccp-supplement-from-20170719.pdf?rev=96fafda8-f51d-44b6-a380-9af42898f526&hash=614AE342F4AB51A091EA3E15F84F7E49). We are a drug free workplace.

We are committed to providing reasonable accommodations for qualified individuals with disabilities and disabled veterans in our job application procedures. If you need assistance or an accommodation due to a disability, you may contact us at -----

To support a fair and consistent hiring process, we use AI and digital automated tools to assist our recruitment team in organizing candidate data, surfacing relevant applications, coordinating interview scheduling and summarizing interview notes. All final screening, evaluation, and hiring decisions are made by humans on our team. To learn more about how we collect, protect, and process your information, please review our [Candidate Privacy Policy](https://www.diligent.com/legal/candidate-privacy).

At Diligent, we recognize the value of a diverse global workforce. Visa sponsorship may be available for select positions based on business needs and specific role requirements. Sponsorship decisions are evaluated on a case-by-case basis, and eligibility should not be assumed for all opportunities.

**Recruitment agencies:** Diligent does not accept unsolicited agency resumes. Please do not forward resumes to our jobs alias, Diligent employees or any other organization location. Diligent is not responsible for any fees related to unsolicited resumes

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
