# Werkstudent Google Ads / SEA (m/w/d)

Posted: 2026-09-18T09:00:46Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Wir sind eine stark wachsende Google Ads Agentur mit Sitz in München. Unser dynamisches Team aus Digital Natives betreut die spannendsten E-Commerce Brands und macht sie zu den Marktführern im DACH-Markt.

Um unser ambitioniertes Wachstumsziel im Bereich SEA zu erreichen, suchen wir dich als Unterstützung für unser Account-Management-Team. Deine Mission: Du lernst das Google-Ads-Handwerk von Grund auf, unterstützt bei der Betreuung unserer Agenturkunden und legst den Grundstein für eine mögliche Karriere im Performance-Marketing.

## Aufgaben

Du unterstützt unsere Account Manager bei der Betreuung unserer Agenturkunden, die sich mit ihrem Geschäftsmodell stark auf den eigenen Online-Shop konzentrieren.

- Du übernimmst eigenständig operative Aufgaben in den Google-Ads-Konten: Kampagnenpflege, Keyword-Recherche, Anzeigenoptimierung.

- Du bereitest Performance-Reportings vor und hilfst bei der Analyse und Interpretation der Kampagnendaten.

- Du bekommst Einblicke in die gesamte Google-Welt - Google Ads, Google Analytics, Tag Manager, Merchant Center.

- Du nimmst an internen Strategiegesprächen teil und bringst eigene Ideen ein.

**Deine Chance:** Nach deinem Studienabschluss besteht die Möglichkeit, als Vollzeit Google Ads Account Manager bei uns einzusteigen.

## Qualifikation

- Du studierst aktuell BWL, Marketing, (Wirtschafts-)Informatik oder einen vergleichbaren Studiengang.

- Du interessierst dich für Online-Marketing und idealerweise erste Berührungspunkte mit Google Ads oder E-Commerce.

- Du arbeitest strukturiert, analytisch und lösungsorientiert.

- Du hast Lust, dich intensiv einzuarbeiten und Verantwortung zu übernehmen.

- Du sprichst gerne mit Menschen und kannst dir vorstellen, später auch direkten Kundenkontakt zu übernehmen.

- Du beherrschst Deutsch fließend, Englisch in Wort und Schrift ist ein Plus.

- Du schließt dein Studium in voraussichtlich einem Jahr ab und hast Interesse danach Vollzeit bei uns einzusteigen

## Benefits

- Ein faires Werkstudentengehalt, das mit Erfahrung wachsen kann.

- Agenturgründer, die eine klare Vision für die Agentur haben und das Wachstum aller Mitarbeitenden proaktiv fördern.

- Eine nachhaltige, überdurchschnittlich hohe Lernkurve – du bist kein kleines Zahnrad im System.

- Arbeiten auf Augenhöhe im Team und kurze Entscheidungswege.

- Ein Team aus Digital Natives, in dessen positiver Arbeitsatmosphäre du dich wohlfühlen wirst.

- Regelmäßige Team Events und Workations.

- Benefits wie neuestes Apple Equipment, Wellpass und das Bezahlen von Kursen & Co. sind für uns selbstverständlich – bei allem anderen: Lass uns darüber reden!

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
