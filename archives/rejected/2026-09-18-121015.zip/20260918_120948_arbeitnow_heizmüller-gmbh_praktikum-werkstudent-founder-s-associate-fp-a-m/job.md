# Praktikum / Werkstudent Founder's Associate FP&A (m/w/d) - Berlin - Deutsch C2 erforderlich

Posted: 2026-09-18T10:30:37Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

DU BEKOMMST DIE ZAHLEN DIESER FIRMA KOMPLETT IN DIE HAND.

Jede Wärmepumpe, die wir einbauen, sind 35.000 bis 40.000 Euro. Du baust die erste echte Finanzsteuerung dahinter und stellst sie einmal im Monat den drei Gründern vor. Im CEO Office, neben anderen Founder's Associates, die genauso hungrig sind wie du.

Heizmüller baut Wärmepumpen in Berliner Altbauten. 24 Anlagen im Monat. Im ersten Jahr von null auf 1,2 Mio. Euro Monatsumsatz. Bootstrapped. Kein Investorengeld, das Fehler zudeckt. Büro in Alt-Moabit.

Bevor du weiterliest: Das hier ist ein Praktikum oder eine Werkstudentenstelle, vor Ort in Berlin, und es geht nur auf Deutsch. C2 oder Muttersprache. Belege, Buchungen und Gespräche sind deutsch, daran führt kein Weg vorbei.

Klartext zum Titel: Du baust das selbst, von der ersten Buchung an. Niemand legt dir einen fertigen Datensatz hin. Wir können das auch, wir haben nur keine Zeit dafür.

## Aufgaben

- Festlegen, was als Kosten einer Baustelle zählt und was Overhead ist. Diese Regeln gibt es heute nicht, deine Entscheidung steht danach in jeder Zahl

- Jede Woche: Buchungen aus sevDesk und Lexware holen und den Baustellen zuordnen

- Nachfragen, wenn eine Position nicht passt. Beim Projektleiter, bei Daniel, bei wem auch immer sie herkommt

- Jeden Monat: Deckungsbeitrag je Baustelle, dazu die Kosten, die nicht auf der Baustelle entstehen: Nacharbeiten, Serviceeinsätze, Office

- Zu jeder Position vier Fragen: Warum fällt das an? Wieso können wir es nicht einsparen? Welche Alternativen gibt es? Was empfiehlst du?

- Das Ganze Daniel, Metin und Linus vorstellen. Sie fragen nach, „das ist halt so“ reicht nicht

- Ein bis zwei Mal im Monat ein, zwei Zahlen fürs All Hands. High Level, der Rest bleibt in der Runde

- Woran wir messen: nach einem Jahr wissen wir für jede Baustelle, was sie gebracht hat, das Reporting läuft in festem Takt, und mindestens ein Hebel ist gehoben, der die Marge messbar bewegt hat

## Qualifikation

- Deutsch auf C2-Niveau oder Muttersprache. Das ist eine harte Voraussetzung, keine Formalie: Belege, Buchungen und alle Gespräche sind deutsch

- Du suchst ein Praktikum oder eine Werkstudentenstelle, vor Ort in Berlin

- Rund ein Jahr Erfahrung in Finance. Praktikum oder Werkstudentenstelle zählt. Controlling, FP&A, Accounting, Transaction Services oder Billing

- Du studierst an einer renommierten Universität, Schwerpunkt Wirtschaft oder etwas Ähnliches

- Deckungsbeitragsrechnung, GuV, Kostenarten. Das sitzt. Grundlagen bringen wir dir hier nicht bei

- Du weißt, was eine Buchung ist, und findest dich in sevDesk und Lexware zurecht, ohne dass dir jemand erklärt, was ein Kontenrahmen ist

- Google Sheets sicher. Formeln, Verknüpfungen, Pivots. Excel benutzen wir nicht

- Du baust ein Modell so, dass ein anderer es versteht. Annahmen an einer Stelle, keine Hardcodes im Formelwerk

- Buchhaltung musst du nicht selbst machen. Lesen musst du sie

## Benefits

Bis zu 20 Euro die Stunde

Teil der Class of 2026: gemeinsames Onboarding, Demo Day am Ende, Leute neben dir, die genauso hungrig sind

Option auf Übernahme als Full-Time Founder's Associate

Büro in Alt-Moabit, Essen, keine Titel, kurze Wege zu den Gründern

Du kannst zu der Baustelle fahren, aus der eine Zahl kommt, und dir ansehen, warum sie so hoch ist

Was du vorher wissen musst: Du baust das selbst, von der ersten Buchung an. Niemand legt dir einen fertigen Datensatz hin. Wir können das auch, wir haben nur keine Zeit dafür. Die Arbeit nehmen wir dir nicht ab, aber wir gehen mit dir durch, was du gebaut hast.

Uns interessiert nicht, wie dein Modell aussieht oder womit du es baust. Nur, dass es funktioniert. If it works, do it. Du berichtest mindestens monatlich an drei Gründer, die nachfragen. Wo du arbeitest, ist uns egal, solange die Zahlen stehen und du im Monatstermin da bist.

So läuft die Bewerbung: 1. Telefonat mit Linus, 20 Minuten. 2. Eine Arbeitsprobe: ein echter Monat aus unseren Zahlen, anonymisiert. Du lieferst Deckungsbeitrag je Baustelle und eine Empfehlung, eine Seite. 3. Videogespräch über deine Arbeitsprobe, wir haben sie vorher ohne dich gelesen. 4. Ein Termin bei uns im Büro, zwei Interviewer. 5. Eine Referenz, dann das Angebot.

Kein Anschreiben. Lebenslauf reicht.

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
