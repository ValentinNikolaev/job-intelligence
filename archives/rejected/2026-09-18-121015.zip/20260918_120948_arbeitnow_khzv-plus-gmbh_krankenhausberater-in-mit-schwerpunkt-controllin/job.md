# Krankenhausberater/in mit Schwerpunkt Controlling (m/w/d) in Voll- oder Teilzeit

Posted: 2026-09-18T09:30:50Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Die KHZV PLUS GmbH ist ein wachsendes Beratungsunternehmen und engagierter Partner für Krankenhäuser. Unser Leistungsspektrum reicht von Controlling und Budget- und Entgeltverhandlungen bis hin zur praxisnahen Unterstützung im Krankenhausalltag.

Als Beratungstochter des Krankenhauszweckverbandes Rheinland e. V. verbinden wir fachliche Expertise mit individuellen Lösungen und langjähriger Erfahrung im Gesundheitswesen. 2021 gegründet, vereint die KHZV PLUS die Agilität eines jungen Beratungsunternehmens mit der Erfahrung und Stabilität eines seit über 30 Jahren im Gesundheitswesen etablierten Trägers.

Unser Anspruch ist es, Krankenhäuser nachhaltig zu entlasten und sie bei den Herausforderungen eines zunehmend komplexen Gesundheitswesens kompetent zu begleiten.

## Aufgaben

**Wie können Sie uns dabei unterstützen?**

Als Krankenhausberater/in mit Schwerpunkt Controlling (m/w/d) an unserem Standort in Köln entwickeln Sie gemeinsam mit unseren Kunden praxisnahe Lösungen zu Budget- und betriebswirtschaftlichen Fragestellungen, unterstützen die Weiterentwicklung ihrer Steuerungs- und Controllingprozesse und geben dabei wichtige Impulse für die Weiterentwicklung von KHZV PLUS.

Im Einzelnen unterstützen Sie uns bei:

**Krankenhausberatung und Projektarbeit**

- Analyse von Leistungs-, Erlös- und Kostendaten

- Beratung und Unterstützung unserer Kunden bei betriebswirtschaftlichen und Controlling-Fragestellungen

- Mitwirkung bei der Weiterentwicklung der Kostenstellen- und Kostenträgerrechnung

- Unterstützung bei der Erstellung von Monats- und Jahresabschlüssen

- Vorbereitung und Begleitung von Budget- und Entgeltverhandlungen

**Mitwirkung an der Weiterentwicklung des Beratungsbereichs**

- Mitwirkung bei der Weiterentwicklung unseres Beratungsangebots und der Entwicklung neuer Beratungsfelder

- Unterstützung bei der Repräsentation von KHZV PLUS bei Kunden, Fachgesprächen und Veranstaltungen

## Qualifikation

**Was sollten Sie dafür mitbringen?**

- Abgeschlossenes Studium der Betriebswirtschaftslehre, Gesundheitsökonomie oder eine vergleichbare Qualifikation

- Mehrjährige Erfahrung im Krankenhauscontrolling oder Krankenhausberatung sowie erste Kenntnisse in Budget- und Entgeltverhandlungen

- Kommunikationsstärke, sicheres Auftreten und ausgeprägte Organisationsfähigkeit

- Unternehmerisches Denken, Eigeninitiative und eine strukturierte, lösungsorientierte Arbeitsweise sowie Offenheit für neue Themen und Herausforderungen.

## Benefits

**Was Sie bei uns erwartet:**

- Ein professionelles und kollegiales Team sowie ein wertschätzendes Arbeitsumfeld

- Flexible Arbeitsmodelle mit Gleitzeit und mobiler Arbeit

- Kostenloses Parken, S-Bahn-Anschluss in fünf Gehminuten und Jobticket

- Eine attraktive Vergütung und Benefits wie: Betriebliche Altersvorsorge, Arbeitgeber-Budget für Zusatzversicherungen, Bike Leasing und weitere

**Konnten wir Ihr Interesse wecken?**

Wir freuen uns über Ihre Bewerbung mit Lebenslauf und Anschreiben. Ihre Unterlagen behandeln wir selbstverständlich vertraulich. Wir freuen uns darauf, Sie bald persönlich kennenzulernen!

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
