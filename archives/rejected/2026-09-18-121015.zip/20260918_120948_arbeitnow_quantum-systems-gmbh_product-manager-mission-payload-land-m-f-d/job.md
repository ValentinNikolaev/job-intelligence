# Product Manager Mission Payload Land (m/f/d)

Posted: 2026-09-18T08:30:44Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Join Quantum-Systems and drive mission-critical payload capabilities to make a real impact. As Product Manager Mission Payload Land, you own the strategy, roadmap, and delivery for payload capabilities across our Land Domain Vehicle Portfolio.

You operate at the intersection of customer value, technical feasibility, and commercial viability; working in tight collaboration with payload providers and internal engineering teams. You balance tactical mission requirements against platform constraints, make build-or-buy trade-offs consciously, and define high-value ConOps and payload configurations that the organization can execute against.

#### **What is your Day to Day Mission:**

-

End-to-End Product Management: Own the vision, roadmap, and lifecycle management for mission payload integration across the UGV portfolio from discovery and concept validation to operational deployment

-

Market Screening & Ecosystem Management: Screen the market to identify, evaluate, and stand up partnerships with payload vendors across the domains ISR, Electronic Warfare, Communications, Combat Engineering, Logistics, and more

-

Continuous Discovery & Experimentation: Drive prototyping and experimental integration of partner payloads including mechanical, E/E, and software integration interfaces and assess performance and usability

-

Build-or-Buy & Productization: Prioritize payload capabilities based on mission utility and drive formal build-or-buy decisions for high-value use cases

-

Engineering & Vendor Collaboration: Serve as the functional bridge between external payload suppliers, customer stakeholders, and internal engineering teams

-

Iterative Delivery: Consolidate customer, user, and field operational insights to set product priorities and continuously convert requirements into shipped capabilities

#### **
**

#### **What you bring to the team:**

-

Multiple years of hands-on experience in technical product/project management or systems engineering, ideally at a Tier-1 Defence Electronics, C4ISR, or Sensor Subsystem OEM

-

Strong commercial instincts paired with a solid technical foundation, enabling you to liaise seamlessly between engineering teams and external customer stakeholders

-

A proactive, solution-oriented approach with a proven ability to deliver results in a fast-paced, high-ambiguity environment

-

Fluency in English to effectively engage with our global team and international customers; German is a plus

#### **Why Quantum-Systems:**

-

We believe in the power of combined efforts: straightforward tech expertise paired with a customer-centric focus.

-

We are industry pioneers who are ambitious, bold, and visionary.

-

We push limits, think outside-the-box and strive for technological excellence to shape the future of aerial data.

-

We promise to be your runway for individual and professional growth.

**
**

#### **Our benefits:**

-

**Company pension scheme: **We support you so that you can already make provisions for later.

-

**Flexible working hours: **With trust-based working hours, you are not only responsible for your working hours, but also for your work-life balance.

-

**Mobile Work:** If things get a little busy in the office, you have the option to work remotely one flexible day per week to create the right balance.

-

**Stay active:** With EGYM Wellpass, you get access to thousands of fitness and sports facilities — and of course, we subsidize the membership.

-

**Bike-Leasing: **We support you in staying environmentally mobile and healthy.

-

**Corporate Benefits: **Your opportunity for attractive offers and discounts from well-known suppliers and brands, e.g. Adidas, Apple, Expedia.

-

**Employee events: **We not only want to grow together, but also celebrate our successes together.

-

**Lunch-Card: **Be powerful with delicious energy, daily lunch budget is sponsored.

-

**Company Shuttle:** Enjoy our convenient shuttle service that picks you up from Laim in Munich and brings you to our location, with return trips at the end of the workday.

#### **About us:**

Quantum Systems specialises in the development, design, and production of small Unmanned Aerial Systems (sUAS). The company’s range of electric vertical take-off and landing (eVTOL) sUAS are built to maximize range and versatility and to provide operators with a seamless user experience. By integrating cutting-edge software capabilities, like edge computing and real-time AI-powered data processing, Quantum Systems is building next-generation UAS for clients in defence, security, public sectors.

#### **Our commitment:**

We are an open-minded company that not only values diversity, but actively promotes it. Regardless of gender, age, ethnic origin, religion, sexual orientation or disability, we firmly believe that the diversity of our employees is an essential part of our success.

At our company, every voice is heard and every perspective is valued. We believe that our differences enrich us and help us to find creative solutions and generate innovative ideas. We pride ourselves on creating an inclusive work environment where all employees can reach their full potential.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
