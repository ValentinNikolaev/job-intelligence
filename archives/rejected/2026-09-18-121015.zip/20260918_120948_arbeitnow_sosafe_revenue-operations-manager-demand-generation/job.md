# Revenue Operations Manager - Demand Generation

Posted: 2026-09-18T08:40:04Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

### **About SoSafe**

SoSafe is a leading human risk management platform designed to transform the "human factor" from a security vulnerability into a proactive layer of defense. We focus on driving measurable behavior change and quantifiable risk reduction for our global customers.

### **Your Role: Architect of Our Demand Engine**

As **Revenue Operations Manager **for Demand Generation, you will own the end-to-end operational architecture connecting Marketing, our SDR organization, and Account Executives into a single, cohesive pipeline creation engine. Rather than viewing demand in isolated channel silos, you will design the infrastructure, data routing, and AI-native automations that fuel both Inbound and Outbound motions.

You will ensure that every inbound handoff is seamless and that outbound prospecting is hyper-targeted toward our highest-converting opportunities; directly counteracting broader SaaS industry trends where late-stage conversion rates have tightened..

### **What you will own (key responsibilities)**

-

**Own the Holistic Lead & Pipeline Lifecycle: **Design, optimize, and oversee the full demand funnel from initial buyer signal to Closed-Won deal. Bridge the gap between HubSpot Marketing automation, Salesloft cadences, and Salesforce CRM to eliminate lead leakage and friction.

-

**Operationalize Our 2026 ICP & Intent Signals:** Hardwire our target ICP criteria, EU mid-market organizations with 500–5,000 employees in regulated industries (Manufacturing, Healthcare, Finance, Public Sector), into our lead scoring and routing logic. Use Clay and Zapier to enrich accounts based on Microsoft 365 tech stack indicators and regulatory pressure signals (e.g., NIS2, DORA compliance deadlines).

-

**Supercharge SDR & AE Outbounding: **Build automated prospecting workflows that allow SDRs and AEs to discover, enrich, and add target ICP contacts into Salesloft cadences with one click.

-

**Channel Efficiency & Attribution: **Track and optimize lead-to-opportunity conversion metrics across all GTM motions. Capitalize on data showing that AE-sourced pipeline yields significantly higher win rates than traditional cold marketing leads, using insights to reallocate GTM focus dynamically.

-

**Introduce AI-Native Lead Generation: **Partner with our dedicated GTM Engineer to implement cutting-edge AI use cases across the top of the funnel. Drive automated lead enrichment, intent-based account prioritization, and automated meeting scheduling to maximize representative output per hour.

-

**Pipeline Health & Target Setting: **Partner with Marketing Leadership, Sales Leadership, and the Revenue Operations team to set MQL/SQL targets, track funnel velocity, and maintain a robust unweighted pipeline coverage ratio of 3-4x across all territories.

### **What You Bring (requirements)**

-

**Experience:** 5+ years of professional experience in Revenue Operations, Marketing Operations, or Sales Operations within a high-growth B2B SaaS environment.

-

**Holistic GTM Perspective: **You view demand generation as a single team sport. You understand how marketing campaigns, SDR outbound cadences, AE self-prospecting, and channel partner motions interact to create a pipeline.

-

**Tech Stack Mastery: **Advanced experience administering and integrating HubSpot (Marketing Suite), Salesforce (SFDC), and Salesloft. Experience with data orchestrators like Clay, Zapier, and forecasting platforms like Clari is highly preferred.

-

**Data-Driven by heart: **Fluency across core SaaS funnel metrics, including MQL-to-SQL Conversion, Cost per Opportunity, Win Rates by Channel, CAC Payback, and Pipeline Velocity.

-

**Process Engineering Mindset:** You excel at translating complex go-to-market strategies into automated, fail-safe system logic with clear SLA governance between Marketing, SDRs, and AEs.

### **Why Join the SoSafe RevOps Team?**

-

**A Seat at the Table:** Our RevOps organization manages the entire GTM stack and architecture. You will have direct exposure to executive leaders (CRO, COO, and Director of RevOps) and have a large, visible impact on our profitability journey.

-

**Cutting-Edge Stack:** We don’t tolerate legacy tech debt. You will work with a modern infrastructure, including Salesforce, HubSpot, Salesloft, Clari CoPilot, and cutting-edge tools like Clay or Claude.

-

**Team Culture:** Join a highly collaborative group of operations professionals and GTM engineers who balance top-tier technical performance with wit, humility, and zero ego. And join our fun team events!

**What we offer***

-

Work/Life balance: Flexible hours, 33 vacation days

-

Wellbeing and financial support: Access to Open Up, corporate discounts

-

Connection & community: Virtual events, collaborative team activities, and opportunities for local meet-ups

-

And the list goes on: Tech equipment, referral bonuses, dog-friendly HQ

**Perks and benefits listed above are for full-time employees and may vary slightly by office location. These are just a sample — you'll learn more during the interview process.*

**About Us**

At SoSafe, we’re on a mission to make the digital world safer by addressing the human factor in cybersecurity. As one of the fastest-growing security awareness scale-ups worldwide, we leverage behavioural science and data-driven learning to empower people against cyber threats. Our Human Risk Management approach helps organisations turn their employees into their strongest line of defence.

Backed by leading VCs like Highland Europe and Global Founders Capital, we’re rapidly expanding across the globe. We’re looking for team players who want to drive meaningful change in cybersecurity, take ownership of their work, and grow with us.

If you thrive in a vibrant, purpose-driven environment that values innovation, diversity, and collaboration, then this is the place for you!

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
