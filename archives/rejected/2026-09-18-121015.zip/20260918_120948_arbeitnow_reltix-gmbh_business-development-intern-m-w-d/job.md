# Business Development Intern (m/w/d)

Posted: 2026-09-18T10:30:37Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

## Deine Aufgaben

Als Business Development Intern bist du Analyst, Operator und Möglichmacher:in in einer Person. Du arbeitest eng mit dem Gründungs- und Operations-Team an strategischen und operativen Themen – von der Prozessautomatisierung bis zur Skalierung unserer Hausverwaltung.

-

**Kunden-Onboarding:** Du verantwortest den strukturierten Onboarding-Prozess neuer Kunden in unser Produkt und unsere Prozesse – von der Datenerfassung über die Koordination mit Eigentümern bis zur Übergabe ans Property Management.

-

**Automatisierung:** Du identifizierst manuelle und repetitive Abläufe, implementierst No-Code- und Low-Code-Lösungen (z. B. n8n Workflows, Lovable Tools, Claude Code) und steigerst so messbar die Effizienz im operativen Tagesgeschäft.

-

**Prozessoptimierung:** Du analysierst bestehende Operations-Prozesse, erkennst Ineffizienzen und Engpässe und entwickelst gemeinsam mit dem Team schlankere, standardisierte Abläufe.

-

**Partner-Koordination:** Du bist erste:r Ansprechpartner:in für externe Partner und Dienstleister im operativen Kontext, prüfst Angebote, koordinierst Prozesse und sorgst für klare Kommunikation.

-

**Strukturen schaffen:** Du hilfst beim Aufbau skalierbarer Operations-Strukturen – von der Dokumentation interner Abläufe über standardisierte Checklisten bis zur Vorbereitung des operativen Wachstums in ganz Deutschland.

## Dein Profil

-

**Unternehmerisches Denken:** Du willst gestalten, Verantwortung übernehmen und Dinge nicht nur analysieren, sondern auch umsetzen.

-

**Starke Struktur & Klarheit:** Du erkennst Muster, denkst in Systemen und kannst Komplexität gut runterbrechen und priorisieren.

-

**Hands-on & Low-ego Mentalität:** Du arbeitest eigenständig, zuverlässig und pragmatisch.

-

**Kommunikationsstärke:** Du trittst professionell auf – ob im Team, gegenüber Partnern oder Eigentümern.

-

**Tech-Affinität:** Du nutzt AI-Tools oder No-Code-Lösungen bereits produktiv oder hast Lust, dich tief einzuarbeiten.

-

**Sprache:** Du kommunizierst fließend auf Deutsch und verhandlungssicher auf Englisch (in Wort und Schrift).

-

**Bonus:** Interesse an Immobilien, PropTech oder der Digitalisierung regulierter Märkte.

## Warum wir?

-

Du arbeitest an der Schnittstelle zwischen Business Development, Operations und Produkt und siehst täglich, was deine Arbeit bewirkt.

-

Direkte Zusammenarbeit mit dem Gründungsteam: Entscheidungen, Diskussionen, Umsetzung.

-

Verantwortung ab Tag 1: Du führst eigene Projekte, setzt Ideen um und bekommst schnell Ownership.

-

Team & Kultur: junges, ambitioniertes Team, offene Kommunikation und regelmäßige Teamevents.

-

Wellness-Budget: Monatliches Budget für mentale und körperliche Balance.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
