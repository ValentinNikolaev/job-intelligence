# Founders Associate Intern (Q1 2027)

Posted: 2026-09-18T08:30:41Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Wir die beiden **Gründer, Jan und Ben**, haben unsere Leidenschaft für die Immobilie schon früh entdeckt und gemeinsam angefangen, selbst Bestand umzubauen und zu erweitern. Dabei sind uns Ineffizienzen aufgefallen, die wir nun gezielt adressieren: Auf der Baustelle gehen viel Zeit, Geld und Nerven verloren, weil Prozesse, Software und Gewerke nicht optimal zusammenspielen. **Die Lösung dafür bauen wir jetzt, als vertikal integrierten Operator, der Assets mit Software und Infrastruktur verbindet.**

Mit Lestate Real erwerben und transformieren wir Bestandsimmobilien. **Mit Realaize bauen wir das Betriebssystem, um gezielt und repetitiv Transformationspotenzial zu finden, zu analysieren und zu bewerten**. **Mit Werkr bauen wir eine Franchise-basierte Infrastruktur** auf, um unsere und externe Projekte effizient umzusetzen.

Wir stehen ganz am Anfang. Deshalb suchen wir Talente, die mitgestalten statt verwalten wollen und Lust haben, etwas wirklich Bedeutsames von Grund auf mitzubauen.

## Aufgaben

Als Founders Associate arbeitest du direkt mit den Gründern und bist an praktisch jedem Teil des Aufbaus eines Unternehmens beteiligt, dort, wo es gerade am meisten zählt.

- Unterstützung bei Deal-Screening, Markt- und Wettbewerbsanalysen

- Mitarbeit an Investorenunterlagen wie Pitch Decks, Teaser und Datenraum

- Recherche und Aufbereitung für Finanzmodell und Business-Planung

- Organisatorische und strategische Unterstützung rund um Gründung, Verträge und Aufbau der Gruppenstruktur

- Eigenständige Übernahme klar abgegrenzter Projekte, sobald du dich eingearbeitet hast

## Qualifikation

- Du studierst BWL, VWL, Finance oder etwas Vergleichbares an einer führenden Universität oder Hochschule (z. B. WHU, HHL, EBS, Mannheim, FS, St. Gallen oder vergleichbar)

- Du denkst schnell, arbeitest strukturiert und brauchst keine ständige Anleitung

- Du bist sattelfest in Excel und PowerPoint und wie wir AI maximal effizient darin nutzen. Erste Berührung mit Immobilien, VC oder Finanzmodellierung ist von Vorteil, aber kein Muss

- Praxiserfahrung durch Praktika, Werkstudententätigkeiten oder eigene Projekte zählt für uns mehr als reine Semesterzahl

- Verhandlungssicheres Deutsch und Englisch

- Du willst Verantwortung, und zwar jetzt

**Ein Plus, aber kein Muss:**

- Erfahrung in der Immobilienbranche

- Ein Auge für spannende Immobilien, den Markt, aktuellen Finanzkennzahlen und Neuigkeiten

## Benefits

- Direkter Zugang zu den Gründern und zu jeder wichtigen Entscheidung, ohne Zwischenebenen

- Perspektive auf eine Festanstellung

- Viel Freiraum und Verantwortung ab dem ersten Tag

- Für und zählen Ergebnisse, nicht unbedingt deine Anwesenheit, erwarten aber dennoch gelegentliche Anwesenheit im Büro

- Echter Einblick in den Aufbau eines Unternehmens von null: Gründung, Fundraising, Produktentwicklung und operatives Geschäft

- Offene Feedbackkultur und kurze Entscheidungswege

**Start: Q1 2027** | **Dauer: 3–6 Monate**, flexibel nach Absprache | Standort: Düsseldorf (hybrid) | Freiwilliges Praktikum oder Pflichtpraktikum möglich

Wir bauen die Firma gerade komplett auf. Das bedeutet hohes Commitment auf unserer Seite, und das erwarten wir auch von dir.

Schick uns deinen Lebenslauf und etwas, das zeigt, wie du denkst.

Wir freuen uns über Bewerbungen unabhängig von Geschlecht, Alter, Herkunft, Religion, Behinderung oder sexueller Identität.

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
