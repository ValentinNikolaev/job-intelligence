# (Senior) Manager SAP FI/CO (m/w/d) – S/4HANA Finance

Posted: 2026-09-18T08:30:26Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**Wir sind die Berater der Weltmarktführer: Hochmotivierte Expertinnen und Experten, die als erfolgreiches Team digitale End-to-End-Geschäftsprozesslösungen vorantreiben. Gemeinsam stärken wir die Zukunft der beeindruckendsten Unternehmen der Welt aus Maschinen- und Anlagenbau, Automotive, Life Science, Pharma und Chemie, mit denen wir viel gemeinsam haben.**

Unser ausgezeichneter Ruf bei Hidden Champions öffnet Dir die Türen für anspruchsvolle Projekte mit einzigartigen Gestaltungsmöglichkeiten. Werde Teil einer der besten und verlässlichsten Beratungen und nutze vielfältige Entwicklungschancen. Als engagiertes Teammitglied kannst Du bei uns schnell Verantwortung übernehmen und über Dich hinauswachsen. Du triffst auf ein starkes Team, das zusammenhält und wirklich etwas bewegen will.

Für unsere nationalen und internationalen Rollout-, Transformations- und Implementierungsprojekte im SAP S/4HANA Umfeld suchen wir aktuell nach **Principal Consultants (m/w/d) sowie Managern (m/w/d)** mit Schwerpunkt Finance.

### **Was Dich erwartet**

-

Planung, Steuerung, Durchführung und Kontrolle von internationalen SAP ERP & S/4HANA Implementierungs-, Transformations- und Rollout- Projekten mit Fokus FI/CO

-

Fachlicher Ansprechpartner bei der Definition von End-to-End Prozessen

-

Implementierung neuer Lösungen und Strategien zur Optimierung der (globalen) SAP Systeme unserer Kunden

-

Analyse, Gestaltung und Implementierung von Geschäftsprozessen

-

Erkennen und proaktives Handling von Problemen, inkl. Erarbeitung von Lösungsvorschlägen unter Berücksichtigung wirtschaftlicher und kapazitätsrelevanter Gesichtspunkte

-

Unterstützung im Presales und beim Auf- und Ausbau unserer Kundenbeziehungen

-

Mitwirkung bei der Unternehmensentwicklung sowie der Weiterentwicklung unserer Projektmanagement-Methodik

-

Je nach Rollen und Funktion: Führung und fachliche Weiterentwicklung von Teammitgliedern

### **Was wir uns wünschen**

-

Erfolgreich abgeschlossenes Hochschulstudium (z.B. im Bereich BWL, Wirtschaftsinformatik, Wirtschaftsingenieurwesen) oder vergleichbare Qualifikation

-

Mindestens 8 Jahre Erfahrung in der Konzeption, Durchführung, Kontrolle und Leitung von SAP ERP Projekten (Schwerpunkt Finance), sowie erste Kenntnisse in SAP S/4HANA

-

Erfahrung in der Harmonisierung von Geschäftsprozessen in Industrieunternehmen bzw. in der Fertigungsindustrie

-

Mehrjährige Erfahrung im Design globaler Rechnungswesen Standards & Prozesse, Neuen Hauptbuch und/oder des Universal Journals, Paralleler Rechnungslegung nach IFRS/HGB, Segmentberichterstattung, Neue Anlagenbuchhaltung, Credit Management & Cash Management, Datenmigration im Umfeld von SAP

-

Ausgeprägte methodische Kenntnisse im Projektmanagement

-

Sehr gute Deutsch- und Englischkenntnisse, weitere Fremdsprachen von Vorteil

-

Analytische und konzeptionelle Denkweise, ausgeprägte Kommunikationsfähigkeit auf allen Managementebenen in multikulturellen Umgebungen

-

Reisebereitschaft, auch für gelegentliche Auslandseinsätze

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
