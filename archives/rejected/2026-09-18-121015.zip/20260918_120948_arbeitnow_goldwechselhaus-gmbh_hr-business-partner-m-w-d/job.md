# HR Business Partner (m/w/d)

Posted: 2026-09-18T09:00:46Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**HR Business Partner (m/w/d)**

Arbeitszeit: 32–40 Stunden/Woche

Standort: Nordrhein-Westfalen / Großraum Köln-Düsseldorf (mit 1–2 Homeoffice-Tagen)

Als HR Business Partner (m/w/d) sind Sie der zentrale HR-Experterte für das Goldwechselhaus, die deutsche Tochtergesellschaft unseres niederländischen Mutterkonzerns. Sie unterstützen den Operations Manager und die Regionalleiter bei allen HR-Fragestellungen. Dabei verbinden Sie strategische Beratung mit einem Hands-on-Ansatz und nehmen eine Schlüsselrolle bei der Weiterentwicklung der HR-Organisation innerhalb des Goldwechselhauses ein.

## Aufgaben

**Was sind Ihre Aufgaben als HR Business Partner?**

Als HR Business Partner (m/w/d) agieren Sie als strategischer Sparringspartner für den Operations Manager Deutschland, die Regionalleiter sowie den zentralen HR-Manager in den Niederlanden. Basierend auf unserer HR-Vision beraten Sie zu vielfältigen HR-Themen – von komplexen Einzelfällen und dem deutschen Arbeitsrecht bis hin zu Organisations- und Veränderungsprozessen. Sie bewegen sich sicher zwischen Belegschaft, Führungskräften und Unternehmensleitung und verstehen es, komplexe Herausforderungen in praxisnahe, passgenaue Lösungen zu übersetzen.

Das Goldwechselhaus befindet sich in einer Phase der gezielten HR-Professionalisierung. Das bedeutet: Sie beraten nicht nur, sondern gestalten Prozesse, Richtlinien und ein tragfähiges HR-Fundament für die Zukunft aktiv mit. Sie erhalten großen Handlungsspielraum, um eigene Initiativen einzubringen und nachhaltige Verbesserungen umzusetzen.

Sie erkennen proaktiv Handlungsbedarfe, begeistern Menschen und wissen genau, wann beratende Unterstützung, wann konsequentes Durchgreifen und wann die Übergabe der Verantwortung an die jeweilige Führungskraft geboten ist. Sie sind im operativen Geschäft präsent, besuchen regelmäßig unsere Standorte und befähigen Führungskräfte, ihre Teams eigenverantwortlich und erfolgreich zu führen. So stärken Sie die Führungskultur und verankern HR als nachhaltigen Werttreiber für das Business.

## Qualifikation

**Das bringen Sie mit**

Als HR Business Partner begeistern Sie sich für Veränderungsprozesse und überzeugen durch eine lösungsorientierte Hands-on-Mentalität, mit der Sie Führungskräfte sowie Kolleginnen und Kollegen mitreißen. Sie agieren gerne nah am Geschäft und verstehen HR als strategischen Business Partner.

- Erfolgreich abgeschlossenes betriebswirtschaftliches Studium (Fachhochschule/Bachelor), idealerweise mit Schwerpunkt Personalmanagement / HR, oder eine vergleichbare Qualifikation (z. B. Wirtschaftsrecht oder Geprüfte/r Personalfachkaufmann/-frau).

- Mehrjährige, fundierte HR-Berufserfahrung (Richtwert ca. 5 Jahre), bevorzugt in einer internationalen oder deutsch-niederländischen, mittelständischen Matrixorganisation.

- Fundierte Kenntnisse moderner HR-Prozesse sowie praxiserprobte Erfahrung in der Organisationsentwicklung, im Change-Management und in strategischen HR-Handlungsfeldern.

- Fähigkeit zur Übersetzung von Konzernrichtlinien in rechtlich belastbare, praxistaugliche lokale HR-Lösungen sowie fundierte Beratungskompetenz im deutschen Arbeits- und Steuerrecht. Sie steuern das Vertragsmanagement gemäß BGB und stellen die rechtskonforme Führung der Personalakten sicher.

- Sicheres Agieren in Umfeldern mit kurzen Entscheidungswegen sowie die Flexibilität, nahtlos zwischen strategischer Beratung und operativer Umsetzung zu wechseln.

- Exzellente, praxiserprobte Kenntnisse im deutschen Arbeitsrecht (u. a. NachwG, BUrlG, KSchG, BGB, BetrVG).

- Fundierte Kenntnisse des deutschen Sozialversicherungsrechts (Kranken-, Renten-, Arbeitslosen-, Pflege- und Unfallversicherung) sowie in SGB, ArbSchG, DSGVO, AGG und HinSchG.

- Verhandlungssichere Deutschkenntnisse (in Wort und Schrift auf rechtssicherem Niveau) sowie sehr gute Englischkenntnisse (C2-Niveau). Niederländischkenntnisse sind für die Konzernkommunikation von Vorteil.

- Erfahrung im Umgang mit HR-Management-Systemen (AFAS), ausgeprägtes Zahlenverständnis für HR-Analytics/Reporting sowie ausgeprägte Organisationssensitivität.

Sie zeichnen sich durch ausgeprägte Lösungsorientierung und Entscheidungsstärke aus; gepaart mit hoher Kommunikations- und Überzeugungskraft, einem feinen Gespür für organisatorische Zusammenhänge sowie analytischem Urteilsvermögen agieren Sie als geschätzte HR-Autorität auf Augenhöhe.

## Benefits

**Das bieten wir Ihnen**

- Ein Attraktives Bruttojahresgehalt zwischen 65.000 € und 75.000 € (auf Vollzeitbasis / 40 Stunden), abhängig von Ihrer Qualifikation und Berufserfahrung – inklusive jährlicher Gehaltsanpassung (Inflationsausgleich), leistungsbezogener Gehaltsperspektive und einer Bonusregelung auf Basis transparenter SMART-Ziele.

- Einen Dienstwagen, auch zur uneingeschränkten privaten Nutzung.

- 28 Urlaubstage pro Kalenderjahr.

- Übernahme bzw. Erstattung der Reise- und Übernachtungskosten für Dienstreisen zwischen Deutschland und den Niederlanden.

- Moderne Arbeitsmittel (Laptop, Smartphone – auch zur privaten Nutzung) sowie eine flexible Homeoffice-Regelung (1 bis 2 Tage pro Woche).

- Attraktiver Personalrabatt auf unser gesamtes Produktsortiment.

**Ihre Position im Unternehmen**

In Ihrer Rolle als HR Business Partner agieren Sie in einer grenzüberschreitenden Matrixorganisation. Sie sind die zentrale HR-Ansprechperson für den deutschen Markt, berichten hierarchisch an den HR-Manager und arbeiten eng mit dem zentralen HR-Team am Hauptsitz in den Niederlanden zusammen. Dadurch profitieren Sie von der Fachexpertise und den Ressourcen der Gruppe und genießen gleichzeitig maximale Gestaltungsfreiheit bei der lokalen Umsetzung in Deutschland.

Sie arbeiten eng mit dem Operations Manager sowie den Regionalleitern zusammen und bilden die Schnittstelle zu externen Partnern (z. B. Sozialversicherungsträgern, Steuerberatern). Durch diese enge Verzahnung von lokalem Management, Konzernzentrale und Ihrer HR-Expertise stellen wir eine optimale Betreuung der Organisation sicher.

**Wer wir sind**

Wir sind das Goudwisselkantoor / Goldwechselhaus. Was als familiengeführtes Unternehmen begann, hat sich in über 40 Jahren zu einem etablierten Handelsunternehmen für Gold, Silber, Uhren und Schmuck entwickelt – mit heute mehr als 500 Mitarbeiterinnen und Mitarbeitern in den Niederlanden, Deutschland und Belgien. Trotz unseres stetigen Wachstums haben wir uns die Werte eines Familienunternehmens bewahrt: persönliches Engagement, gegenseitiges Vertrauen und langfristige Orientierung. Wir pflegen kurze Entscheidungswege, kennen einander und übernehmen gemeinsam Verantwortung. Dies spiegelt sich in der hohen Loyalität unseres Teams und der schnellen Integration neuer Kolleginnen und Kollegen wider.

**Lernen wir uns kennen**

Haben wir Ihr Interesse geweckt? Dann freuen wir uns auf Ihre Bewerbung. Sie haben vorab Fragen zur Position? Wenden Sie sich gerne an Ronald Niemeijer. Wir freuen uns auf Ihre Kontaktaufnahme. Ein fachliches Assessment kann Bestandteil des Auswahlverfahrens sein.

**Sicherheit & Datenschutz**

Aufgrund unserer Geschäftstätigkeit im Bereich wertvoller Wirtschaftsgüter sind eine Überprüfung des beruflichen Profils (ausschließlich über berufsbezogene Netzwerke gemäß DSGVO/BDSG) sowie die Einholung eines behördlichen Führungszeugnisses Bestandteil des Bewerbungsprozesses. Detaillierte Informationen hierzu erhalten Sie im Laufe des Verfahrens.

Ausführliche Hinweise zum Schutz Ihrer personenbezogenen Daten finden Sie in unserer Datenschutzerklärung. Lesen Sie hier unser Privacy Statement.

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
