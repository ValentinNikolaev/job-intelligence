# (Senior) DevOps Engineer - Infrastructure & Security (m/f/d)

Posted: 2026-09-18T09:00:46Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Du willst Infrastruktur nicht nur betreiben, sondern verantworten? Bei uns gehört dir der komplette Stack – vom Proxmox-Cluster im eigenen Rechenzentrum über Firewalls und VPNs bis zu AWS und den Deployment-Pipelines.

Testsieger ist eines der größten Vergleichsportale Deutschlands: 4,2 Millionen Produkte, Testberichte, Kundenbewertungen und ein integrierter Preisvergleich, der Millionen Nutzer zum richtigen Kauf führt. Ein 20-köpfiges Team mit direkten Wegen und ohne Konzern-Overhead.

Du übernimmst die Rolle des technischen Owners für unsere Infrastruktur – mit einem Team an deiner Seite, und einem Engineering-Team, das auf dich zählt.

## Aufgaben

- Du verantwortest den Betrieb unserer Linux-Serverlandschaft: On-Premise-Cluster (Proxmox, ZFS) und AWS

- Du betreibst und härtest Netzwerk und Security: Firewalls, VPN, Zugriffskontrolle, Zertifikate, Hardening – inklusive der Netzanbindung an unseren größten Partner

- Du automatisierst mit Ansible und hältst Infrastruktur versioniert, reproduzierbar und dokumentiert

- Du betreust unsere Container-Plattform (Docker, Nomad, Traefik) und die CI/CD-Pipelines (GitHub Actions), damit die Teams sicher und schnell shippen

- Du administrierst MySQL in Produktion: Backups, Performance, Recovery

- Du baust Monitoring, Logging und Alerting aus (Grafana, New Relic) und führst Incidents zur Ursache

- Du bist Sparringspartner für Engineering, Data und Product – und erklärst, warum Dinge so gebaut sind, wie sie gebaut sind

## Qualifikation

- Mehrjährige Erfahrung im Betrieb von Linux-Serverumgebungen (Debian/Ubuntu) – du weißt, wie man Systeme auch ohne Assistenz von A nach B bringt

- Fundierte Netzwerkkenntnisse: TCP/IP, Routing, DNS, Load Balancing, Firewall- und VPN-Administration

- Nachweisbare Praxis in Infrastructure Security: Hardening, Access Control, Security Best Practices

- Ansible in Produktion, Container-Orchestrierung (Nomad, Kubernetes oder vergleichbar), CI/CD-Pipelines

- Erfahrung mit AWS oder einer vergleichbaren Public Cloud

- MySQL-Administration in Produktion

- Bash und Python – für Tooling, nicht nur für Einzeiler

- Monitoring, Logging und Troubleshooting sind für dich Handwerk, nicht Kür

- Plus: Terraform, RabbitMQ, Redis, Zero-Trust-Konzepte

- Gutes Englisch in Wort und Schrift – unser Engineering-Team arbeitet international

## Benefits

- Volle technische Verantwortung für einen echten Hybrid-Stack (On-Premise + Cloud) – Entscheidungen triffst du, nicht ein Architekturboard

- Attraktives Gehalt, Rufbereitschaft wird vergütet und ist verteilt

- Ownership-Kultur mit kurzen Wegen: Du sprichst direkt mit der Geschäftsführung

- Moderner Stack: Proxmox, AWS, Ansible, Nomad, Docker, MySQL, Python, GitHub Actions, Next.js-Ökosystem

- Hybrides Arbeiten mit Basis in Osnabrück

Wenn du Infrastruktur als dein Produkt verstehst und Lust hast, sie mit klarer Verantwortung weiterzuentwickeln – melde dich. Wir freuen uns auf dich.

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
