# Strategy & Operations, Germany

Posted: 2026-09-18T08:40:05Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**About the Team**

OpenAI’s mission is to build safe artificial general intelligence that benefits all of humanity. Our EMEA organization translates OpenAI’s global mission and strategy into meaningful local impact, working across Growth, Product, Marketing, Partnerships, Finance, Research, Operations and Compliance.

**About the Role**

As Strategy and Operations lead, you will develop country strategies, identify the most important market opportunities and barriers, align cross-functional teams around a focused set of priorities, and personally drive initiatives through to measurable outcomes.

This is an individual-contributor role. The primary focus is Consumer, with opportunities to create adjacent impact across B2B. You will go deep in a small number of priority markets while building approaches that can scale across EMEA.

This is not a strategy-only role. The successful candidate will combine rigorous analysis and market judgment with urgency, hands-on execution and the ability to influence without formal authority.

This role is based in Munich or Berlin. We use a hybrid work model of 3 days in the office per week and offer relocation assistance to new employees.

**In this role, you will:**

-

**Build country strategies:** Develop plans, priorities and forecasts for key European markets and translate company strategy into practical local action.

-

**Drive growth and conversion:** Use data, customer insight and experimentation to improve acquisition, engagement, retention, conversion and monetization.

-

**Lead market expansion and localization:** Identify opportunities, build scalable launch frameworks and determine where products and go-to-market should adapt.

-

**Turn strategy into execution:** Personally move initiatives from diagnosis and prioritization through delivery, measurement and iteration.

-

**Lead cross-functional teams:** Align Product, Growth, Marketing, Brand, Partnerships, Finance, Research, Operations and Compliance around shared outcomes.

-

**Represent regional insight:** Ensure European market and customer perspectives shape global roadmaps and decisions.

-

**Measure and scale impact:** Define success metrics and determine when a successful local approach should be replicated.

**You might thrive in this role if you:**

-

Have 10 years + of experience in growth, strategy, business operations or quantitative analytics with meaningful responsibility for outcomes.

-

Have developed country, regional or multi-market strategies and translated them into focused execution plans.

-

Bring exceptional analytical and problem-solving skills, including forecasting, financial modeling and growth metrics.

-

Can show examples of personally taking initiatives from insight through launch and measurement.

-

Understand European markets while maintaining a regional and scalable perspective.

-

Communicate clearly with senior stakeholders and influence teams without formal authority.

-

Operate with high ownership and urgency in ambiguous, resource-constrained environments.

-

Have a deep interest in AI and alignment with OpenAI’s mission.

**About OpenAI**

OpenAI is an AI research and deployment company dedicated to ensuring that general-purpose artificial intelligence benefits all of humanity. We push the boundaries of the capabilities of AI systems and seek to safely deploy them to the world through our products. AI is an extremely powerful tool that must be created with safety and human needs at its core, and to achieve our mission, we must encompass and value the many different perspectives, voices, and experiences that form the full spectrum of humanity.

We are an equal opportunity employer, and we do not discriminate on the basis of race, religion, color, national origin, sex, sexual orientation, age, veteran status, disability, genetic information, or other applicable legally protected characteristic.

For additional information, please see [OpenAI’s Affirmative Action and Equal Employment Opportunity Policy Statement](https://cdn.openai.com/policies/eeo-policy-statement.pdf).

Background checks for applicants will be administered in accordance with applicable law, and qualified applicants with arrest or conviction records will be considered for employment consistent with those laws, including the San Francisco Fair Chance Ordinance, the Los Angeles County Fair Chance Ordinance for Employers, and the California Fair Chance Act, for US-based candidates. For unincorporated Los Angeles County workers: we reasonably believe that criminal history may have a direct, adverse and negative relationship with the following job duties, potentially resulting in the withdrawal of a conditional offer of employment: protect computer hardware entrusted to you from theft, loss or damage; return all computer hardware in your possession (including the data contained therein) upon termination of employment or end of assignment; and maintain the confidentiality of proprietary, confidential, and non-public information. In addition, job duties require access to secure and protected information technology systems and related data security obligations.

To notify OpenAI that you believe this job posting is non-compliant, please submit a report through [this form](https://form.asana.com/?d=57018692298241&k=5MqR40fZd7jlxVUh5J-UeA). No response will be provided to inquiries unrelated to job posting compliance.

We are committed to providing reasonable accommodations to applicants with disabilities, and requests can be made via this [link](https://form.asana.com/?k=bQ7w9h3iexRlicUdWRiwvg&d=57018692298241).

[OpenAI Global Applicant Privacy Policy](https://cdn.openai.com/policies/global-employee-and-contractor-privacy-policy.pdf)

At OpenAI, we believe artificial intelligence has the potential to help people solve immense global challenges, and we want the upside of AI to be widely shared. Join us in shaping the future of technology.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
