# Lohn- und Gehaltsbuchhalter (m/w/d)

Posted: 2026-09-18T09:30:51Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Die Flohr Holding bündelt zentrale kaufmännische Funktionen für mehrere Unternehmen unserer Unternehmensgruppe.

Zur Gruppe gehören unter anderem die **Lokspace GmbH**, die **Locontact GmbH**, die **Eisenbahn-Güterlogistik GmbH** sowie zwei weitere Einzelunternehmen.Für unseren Standort in Siegburg suchen wir einen erfahrenen **Lohn- und Gehaltsbuchhalter (m/w/d)**, der die Personalabrechnung unserer Unternehmen zuverlässig und eigenständig betreut

## Aufgaben

- Eigenständige Durchführung der monatlichen Lohn- und Gehaltsabrechnung für mehrere Unternehmen

- Betreuung unterschiedlicher Mitarbeitergruppen innerhalb unserer Unternehmensgruppe

- Pflege und Kontrolle sämtlicher abrechnungsrelevanter Stammdaten

- Bearbeitung von Ein- und Austritten

- Prüfung von Arbeitszeiten, Fehlzeiten, Urlaub und sonstigen abrechnungsrelevanten Daten

- Erstellung von Meldungen und Bescheinigungen

- Kommunikation mit Krankenkassen, Finanzämtern und Sozialversicherungsträgern

- Betreuung der Mitarbeiter bei Fragen zur Abrechnung

- Vorbereitung und Begleitung von Lohnsteuer- und Sozialversicherungsprüfungen

- Abstimmung mit Finanzbuchhaltung, Personalverantwortlichen und Geschäftsführung

- Gesellschaftsübergreifende Abstimmung von Personal- und Lohnkosten

- Pflege und Weiterentwicklung der digitalen Abrechnungsprozesse

**Wir arbeiten mit DATEV**

Unsere Lohn- und Gehaltsabrechnung erfolgt mit **DATEV Lohn und Gehalt**.

Daher setzen wir praktische Erfahrung mit **DATEV Lohn und Gehalt** für diese Position voraus.

## Qualifikation

- Abgeschlossene kaufmännische, steuerfachliche oder vergleichbare Ausbildung

- **Mehrjährige praktische Berufserfahrung in der Lohn- und Gehaltsabrechnung**

- Gute bis sehr gute Kenntnisse in **DATEV Lohn und Gehalt**

- Sehr gute Kenntnisse im Lohnsteuer- und Sozialversicherungsrecht

- Erfahrung mit Melde- und Bescheinigungswesen

- Sicherer Umgang mit digitalen Arbeitsprozessen

- Selbstständige, strukturierte und zuverlässige Arbeitsweise

- Hohes Verantwortungsbewusstsein und Diskretion

- Erfahrung in der Betreuung mehrerer Gesellschaften ist von Vorteil

## Benefits

- **45.000 bis 52.000 € brutto/Jahr**, abhängig von Erfahrung und Qualifikation

- Unbefristete Festanstellung bei der Flohr Holding

- Betriebliche Altersversorgung

- Zuschuss zum Fitnessstudio bzw. Firmenfitness

- Moderner Arbeitsplatz in Siegburg

- Kurze Entscheidungswege

- Direkte Zusammenarbeit mit der Geschäftsführung

- Hoher eigener Verantwortungsbereich

- Möglichkeit, Prozesse aktiv mitzugestalten und weiterzuentwickeln

Wir suchen keine reine Abrechnungskraft.

Du solltest deine Abrechnungen verstehen, Auffälligkeiten erkennen, eigenständig Lösungen finden und Verantwortung für eine zuverlässige Lohn- und Gehaltsabrechnung innerhalb unserer Unternehmensgruppe übernehmen.

**Wir freuen uns darauf, dich kennenzulernen.**

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
