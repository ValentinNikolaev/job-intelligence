# Full Stack Developer

Posted: 2026-09-18T09:30:51Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

We are looking for a **Full Stack Developer** to push the software that runs our factory floor. You will work with our engineering team on the production software that runs the factory and guides the assembly of every cabinet.

Development cycles are more direct than anywhere in the industry: you will see your software used in production by your colleagues the same day you ship it.

## Tasks

- **Advance our web-based production software** which runs our company processes.

- Make **frontend and backend scale** as we add production lines an functionality.

- **Extend the data model** behind cabinets, parts and orders.

- Work directly with our engineers and with the people on the floor who use what you build.

- Implement physical improvements to our **end-to-end production process** in our operating system.

## Requirements

- **Master's degree in computer science** or similar fields with strong grades.

- **3+ years of experience** as a full stack developer.

- Comfortable across **frontend, backend and databases**.

- **Get things done** mentality: prioritising progress and results over process.

- **Humble, low ego**, not afraid to get your hands dirty.

- Experience with **production or manufacturing software** is a strong plus.

- You **ship early** and iterate with your users constantly.

- **Fluent in English**, German is a plus.

- Tech stack: TypeScript, React, Tailwind CSS, SQL / PostgreSQL, Supabase, Git

## Benefits

- **Ownership through ESOP**.

- **Scaling from 0 to 1**: you shape how this company works, from the processes to the team around you.

- An interdisciplinary **team of top performers** that will both support and challenge your growth.

- **Lunch allowance**, a **subsidized sports membership** and modern tech.

- A **new office in** **Garching**, right on top of our own production floor.

Vetaion is building a fully automated production facility for control cabinets in Munich. We use digital twins and robotics to automate the manufacturing process, orchestrated by VetaionOS, our own operating system for the factory.

Our mission is to strengthen Germany as a leading industrial hub. Join our team and our mission, let's reinvent the future of production together!

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
