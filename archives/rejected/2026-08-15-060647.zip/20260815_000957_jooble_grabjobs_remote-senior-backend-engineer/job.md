# Remote Senior Backend Engineer

Posted: 2026-08-13T09:05:09.6270000

## Rejection

- Category: tech_stack
- Reason: role does not mention Go/Golang or PHP

...Partners, Softbank, and heavy hitters like the former COO of Venmo and the President of Impossible Foods.
We are looking for a **backend engineer **that is comfortable taking a high degree of ownership for their program vision and execution of ideas. Beyond a strong...
