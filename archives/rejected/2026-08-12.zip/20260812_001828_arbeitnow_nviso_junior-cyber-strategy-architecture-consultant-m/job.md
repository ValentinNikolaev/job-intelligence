# Junior Cyber Strategy & Architecture Consultant (m/w/d) - Focus GRC

Posted: 2026-08-11T14:30:26Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

It all starts with the mission: NVISO is here to protect European society from potentially devastating cyber attacks! This means we offer cyber security services to private and governmental organizations to help them better prepare for, prevent, detect and respond to cyber security incidents.

All of this is built on four fundamental values that define who we are: We are Proud, We Break Barriers, We Care and No BS!

## Tasks

As a **Junior Cyber Strategy & Architecture Consultant (m/w/d) with a focus on GRC located in Germany**, you will work together with Senior or Principal Consultants to support our larger to smaller customers with the overall reinforcement of their security posture. Typical engagements include (but are not limited to):

- Assisting client’s IT or security teams with the implementation of strategic security programs and projects. You solve together with other NVISO experts customers challenges or work in full integration with the client organization.

- Supporting the refinement of security governance, policies, processes and guidelines in all areas of the cyber security field.

- Assisting the implementation our client’s ISMS (Information Security Management Systems) by also implementing NVISO solutions based on controls frameworks.

- Supporting the refinement our client’s Security Strategy by developing Enterprise and IT governance structures through policies, standards, processes and operational structures.

- Assisting in the definition of action plans in alignment with internal and external stakeholders.

- Assisting in reaching or maintaining compliance to information security legal, contractual, or internal requirements; this includes implementing semi-automated solutions (GRCasaCode and Continuous Compliance supported by scripted and automated solutions).

- Assist the preparation of reporting to the senior management of the client.

## Requirements

Requirements

- Bachelor or a Master’s degree, your education is not required to be in IT or technology, however you should have strong affinity with technology.

- Basic knowledge in the area of Cyber Security.

- Basic knowledge on automation and coding is beneficial but not needed.

- First experiences in mapping NIST, ISO27001, NIS2 and/or DORA requirements to practical implementations are beneficial.

- Used to operating with a great deal of autonomy, but also appreciate the value of team work.

- Basic project management skills.

- Excellent written and verbal German and English communication skills, with the ability to effectively communicate complex concepts.

- **You hold citizenship in one of the 32 NATO member states.**

## Benefits

What do we offer

At NVISO, we care. We are committed to offering you a highly competitive remuneration package including financial and non-financial components:

- A training budget of 10.000 EUR and 10 days training man days every 2 years;

- An annual gross base salary between 57,000 EUR and 62,000 EUR, depending on your experience;

- Working and learning from the best people in the European cyber security industry. We have multiple SANS Instructors working at NVISO, our staff has presented at popular hacking conferences (BlackHat, BruCON, OWASP, etc.) and all of our technical staff can acquire deep technical security certifications (GSE, GXPN, GREM, GCFA, OSCP, etc.);

- An entrepreneurial and agile company, where you will be stimulated and supported in driving new initiatives (either through internal innovation or by improving our service offering), without losing sight of having fun!;

- Regular team-building and fun events throughout the year;

- Our commitment to coach, counsel, and help you grow; each employee receives a personal coach within the team, whose role is to ensure your well-being and helps you grow in your career!;

- Flexible working hours, homeworking and the possibility to work from abroad;

- Business Bike Leasing;

- BahnCard 50 1st class + public transfer ticket;

- 30 holidays;

- Cool offices in the center of Frankfurt, and Munich with BBQ, kicker table, table tennis, Playstation, etc..

**Disclaimer on the Use of AI Tools in the Application Process**

Please be aware that the creation and submission of application documents (e.g. CV, cover letter, case studies, etc.) using AI-powered tools is only permitted to a **limited extent**.

*Our expectations:*

Application documents must authentically reflect your own qualifications, personality, and motivation.

The use of AI for supportive purposes (e.g. spell-checking, improving wording) is acceptable.

**Fully generated application documents created by AI without personal adaptation or review are not** **permitted.**

Under no circumstances may **NVISO information, data, or documents** be uploaded to or processed by external AI tools.

We reserve the right to exclude applications from the selection and interview process that are clearly created primarily or exclusively by AI and show no recognizable personal input.

The purpose of this policy is to ensure a fair and transparent recruitment process and to obtain an authentic impression of our applicants.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
