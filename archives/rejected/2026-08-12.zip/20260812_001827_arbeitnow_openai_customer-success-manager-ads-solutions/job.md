# Customer Success Manager - Ads Solutions

Posted: 2026-08-11T17:40:11Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**About the Team**

OpenAI’s mission is to ensure the responsible and widespread adoption of artificial intelligence. In support of that mission, the Ads Solutions team partners closely with advertisers to deeply understand their businesses and needs, helping inform the development of products and solutions that drive meaningful revenue growth and long-term success on the platform—while maintaining strong standards for user trust and platform integrity.

**About the Role**

We’re looking for a Customer Success Manager to support advertisers in onboarding, launching, and growing on OpenAI’s advertising platform. You will manage a portfolio of partners and serve as a trusted advisor, helping them achieve their business objectives while ensuring a strong and responsible experience on our platform.

This role sits at the intersection of relationship management, strategy, and execution. You’ll work closely with Sales to drive long-term partner growth and with internal teams to continuously improve the advertiser experience.

This role is based in our Munich office. We use a hybrid work model of** **3 days in the office per week and offer relocation assistance to new employees.

**In this role, you will:**

-

Own relationships with a portfolio of advertising partners, serving as their primary point of contact.

-

Guide advertisers through onboarding and campaign launches to ensure strong adoption of OpenAI’s ads products.

-

Analyze campaign performance and provide clear, actionable recommendations to improve outcomes.

-

Identify opportunities to expand partnerships through increased product adoption and incremental investment.

-

Partner cross-functionally with Sales, Product, Analytics, Policy, and Operations to resolve issues and enhance platform value.

-

Surface advertiser feedback and insights to inform product improvements and long-term strategy.

-

Help build scalable processes and best practices that support the growth of OpenAI’s advertising ecosystem.

**You might thrive in this role if you:**

-

Have 5-10+ years of experience in digital advertising, account management, customer success, consulting or a related client-facing role.

-

Have experience managing advertiser or agency relationships in a platform, publisher, or adtech environment.

-

Are comfortable interpreting performance data and translating insights into strategic recommendations.

-

Have experience with data querying (e.g. SQL, advanced excel/GSheet)

-

Communicate clearly and build trust with both technical and non-technical stakeholders.

-

Operate with ownership and accountability in fast-moving, evolving environments.

-

Demonstrate sound judgment and a commitment to user trust and responsible platform growth.

**About OpenAI**

OpenAI is an AI research and deployment company dedicated to ensuring that general-purpose artificial intelligence benefits all of humanity. We push the boundaries of the capabilities of AI systems and seek to safely deploy them to the world through our products. AI is an extremely powerful tool that must be created with safety and human needs at its core, and to achieve our mission, we must encompass and value the many different perspectives, voices, and experiences that form the full spectrum of humanity.

We are an equal opportunity employer, and we do not discriminate on the basis of race, religion, color, national origin, sex, sexual orientation, age, veteran status, disability, genetic information, or other applicable legally protected characteristic.

For additional information, please see [OpenAI’s Affirmative Action and Equal Employment Opportunity Policy Statement](https://cdn.openai.com/policies/eeo-policy-statement.pdf).

Background checks for applicants will be administered in accordance with applicable law, and qualified applicants with arrest or conviction records will be considered for employment consistent with those laws, including the San Francisco Fair Chance Ordinance, the Los Angeles County Fair Chance Ordinance for Employers, and the California Fair Chance Act, for US-based candidates. For unincorporated Los Angeles County workers: we reasonably believe that criminal history may have a direct, adverse and negative relationship with the following job duties, potentially resulting in the withdrawal of a conditional offer of employment: protect computer hardware entrusted to you from theft, loss or damage; return all computer hardware in your possession (including the data contained therein) upon termination of employment or end of assignment; and maintain the confidentiality of proprietary, confidential, and non-public information. In addition, job duties require access to secure and protected information technology systems and related data security obligations.

To notify OpenAI that you believe this job posting is non-compliant, please submit a report through [this form](https://form.asana.com/?d=57018692298241&k=5MqR40fZd7jlxVUh5J-UeA). No response will be provided to inquiries unrelated to job posting compliance.

We are committed to providing reasonable accommodations to applicants with disabilities, and requests can be made via this [link](https://form.asana.com/?k=bQ7w9h3iexRlicUdWRiwvg&d=57018692298241).

[OpenAI Global Applicant Privacy Policy](https://cdn.openai.com/policies/global-employee-and-contractor-privacy-policy.pdf)

At OpenAI, we believe artificial intelligence has the potential to help people solve immense global challenges, and we want the upside of AI to be widely shared. Join us in shaping the future of technology.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
