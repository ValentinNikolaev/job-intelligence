# Praktikum im Bereich Creative Marketing

Posted: 2026-08-11T14:00:39Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Du liebst es, Ideen in starke visuelle Konzepte zu übersetzen? Du willst mit deinem Gestaltungstalent das Branding eines jungen Hightech-Unternehmens mitprägen? Du möchtest in einem hoch-innovativen und wachsenden Start-up arbeiten und deine Erfahrung ins Team einbringen?

Dann werde Teil unseres Teams in Augsburg ab Oktober 2026!

## Aufgaben

In unserem Team übernimmst du die gestalterische Umsetzung unserer Marketing- und Kommunikationsmaterialien – von Produktbroschüren über Newsletter bis zu LinkedIn-Beiträgen, Pitchdecks und Produktflyern.

Die Inhalte liefern die jeweiligen Fachabteilungen – deine Stärke liegt im **Design**: Layout, Typografie, Bildsprache und die konsequente Umsetzung unserer Corporate Identity.

Zusätzlich übernimmst du die **Videoproduktion** für Social Media, Website und Events – von der Aufnahme über den Schnitt bis zur fertigen Bearbeitung. Mit deinen kreativen Ideen gestaltest du aktiv unser Branding mit und arbeitest dabei eng mit einem interdisziplinären Team zusammen.

## Qualifikation

- Studium im Bereich Kommunikationsdesign oder vergleichbar

- Sicherer Umgang mit Gestaltungstools – Affinity-Apps oder Adobe Creative Cloud

- Erfahrung in der Videoproduktion: Aufnahme, Schnitt und Bearbeitung

- Gutes Gefühl für Typografie, Layout und visuelle Identität

- Eigenverantwortliche und organisierte Arbeitsweise

- Begeisterung für technische Innovationen und Affinität zur Start-up-Mentalität

- Sehr gute Deutsch- und Englischkenntnisse in Wort und Schrift

## Benefits

- Spannende Aufgaben mit viel Eigenverantwortung

- Internationales Umfeld mit Kunden aus verschiedenen Branchen

- Flexible Arbeitszeiten und Remote-Möglichkeit (Einarbeitungsphase erfolgt in Präsenz)

- Regelmäßige Team-Events

- Kostenlose Früchte, Snacks, Getränke und guter Kaffee

- Flache Hierarchien und kurze Entscheidungswege

Haben wir dein Interesse geweckt? Wir freuen uns, dich kennenzulernen!

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
