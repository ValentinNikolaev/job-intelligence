# Legal Director - 11810

Posted: 2026-08-11T14:04:54Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Coupa makes margins multiply through its community-generated AI and industry-leading total spend management platform for businesses large and small. Coupa AI is informed by trillions of dollars of direct and indirect spend data across a global network of 10M+ buyers and suppliers. We empower you with the ability to predict, prescribe, and automate smarter, more profitable business decisions to improve operating margins.

**Why join Coupa?**

🔹 Pioneering Technology: At Coupa, we're at the forefront of innovation, leveraging the latest technology to empower our customers with greater efficiency and visibility in their spend.

🔹 Collaborative Culture: We value collaboration and teamwork, and our culture is driven by transparency, openness, and a shared commitment to excellence.

🔹 Global Impact: Join a company where your work has a global, measurable impact on our clients, the business, and each other.

Learn more on [Life at Coupa](https://insde.co/uzoy) blog and hear from our employees about their experiences working at Coupa.

**The Impact of a Legal Director at Coupa:**

We are looking for an enthusiastic and sharp Legal Director/Senior Legal Counsel (DACH/EMEA) to join our EMEA commercial legal team and the broader global Coupa Legal team. You will be the go-to lawyer for the DACH Region with also exposure to multiple other jurisdictions across EMEA, reporting directly to the Head of Legal EMEA. This is a fully remote role, with the possibility of visiting our office depending on your location.

**What You'll Do: **

- Provide legal support for Coupa’s Go-To-Market sales organization across EMEA to help close deals and keep the business moving.

- Negotiate and draft various commercial documents, such as SaaS master subscription agreements, DPAs, AI terms, professional services agreements, partner agreements, and regulatory addenda (including DORA).

- Take over any service desk tickets assigned to the EMEA Legal team on any legal subject matter to keep the queue moving and the business unblocked.

- Advise on regulatory and customer compliance requirements across the EU/EEA.

- Get to know Coupa’s products, SaaS offerings, security, and data protection policies inside and out to build a strong foundation for supporting every line of business.

- Partner closely with the sales operations, finance, product, privacy, security and Deal Desk teams, as well as other stakeholder teams, to ensure that agreements are consistent with internal corporate policies and processes.

- Resolve customer success issues and any commercial dispute by working directly with a customer representatives and internal teams.

- Collaborate with legal and cross-functional stakeholders to help standardize documentation across, develop guidelines, and improve the team’s efficiency and effectiveness every quarter.

- Develop training materials and deliver *ad-hoc* sales enablement sessions on topics such as new regulations and the contracting process.

- Assist with other projects as assigned.

**What You Will Bring to Coupa: **

- Qualified German lawyer. A Master of Laws Degree or being a member in good standing of a recognized international bar is a plus.

- Fluent written and verbal German and English language skills is required, and other language(s) is highly desirable.

- 10+ years of relevant experience with at least 4 years in-house in the tech sector, ideally with exposure to the US software industry. You should be comfortable working directly with strategic and regulated customers, internal clients and executives.

- Ability to handle complex contractual issues quickly and work with autonomy.

- Excellent written and verbal communication skills.

- Highly responsive and service-oriented attitude.

- Ability to organize, prioritize and manage deadlines in a fast-paced, evolving and demanding work environment.

- Ability to develop and maintain strong working relationships within the Coupa Legal Department, across other supporting departments and with demanding internal clients.

- Talent for thinking “outside the box” in confronting new issues and pursuing novel approaches to old problems.

- A commitment to excellence and to ensuring the success of Coupa’s customers.

At Coupa, we are 100% committed to creating and nurturing an environment that supports your physical, mental, and community well-being . We offer a comprehensive suite of benefits designed to help you and your family thrive:

**Global Well-Being Perks (For All Employees Globally)**

- **Global Wellness Days:** Enjoy two designated, company-wide paid wellness days off each year (typically the first Friday in March and the last Friday in September) so the entire global team can unplug, step away, and recharge together .

- **Birthday Time-Off:** Celebrate your day! Coupa provides a paid day off on your birthday or another day of your choice within your birthday month .

- **Volunteer Time Off (VTO):** Giving back is in our DNA. We offer 40 hours of paid VTO annually to support the community initiatives and volunteer programs you are passionate about .

- **Employee Assistance Program (EAP):** Access free, confidential, 24/7/365 counseling and resources for emotional support, work-life solutions, financial advice, legal guidance, and support for new parents .

- **Business Travel Protection:** Travel with peace of mind. Zurich Travel Assist provides medical, safety, pre-trip planning, and emergency support during any business travel .

- **Referral Bonus Program:** Share the Coupa experience! Receive generous monetary referral bonuses when you successfully refer talented friends or acquaintances who are hired into open roles .

*Please note: In addition to these global well-being perks, Coupa offers highly competitive, location-specific benefits packages (which include comprehensive medical/dental insurance, retirement/pension plans, and life or accident protection) tailored to your primary work location. Your recruiter will walk you through the specific regional benefits package for this role during the interview process.*

Coupa complies with relevant laws and regulations regarding equal opportunity and offers a welcoming and inclusive work environment. Decisions related to hiring, compensation, training, or evaluating performance are made fairly, and we provide equal employment opportunities to all qualified candidates and employees.

Please be advised that inquiries or resumes from recruiters will not be accepted.

By submitting your application, you acknowledge that you have read [Coupa’s Privacy Policy](https://www.coupa.com/privacy-policy) and understand that Coupa receives/collects your application, including your personal data, for the purposes of managing Coupa's ongoing recruitment and placement activities, including for employment purposes in the event of a successful application and for notification of future job opportunities if you did not succeed the first time. You will find more details about how your application is processed, the purposes of processing, and how long we retain your application in our Privacy Policy.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
