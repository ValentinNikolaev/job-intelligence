# Regional Client Partner, Ads Solutions

Posted: 2026-08-11T17:40:11Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**About the Team**

OpenAI’s mission is to ensure the responsible and widespread adoption of artificial intelligence. In support of that mission, the Ads Solutions team partners closely with advertisers to deeply understand their businesses and needs, helping inform the development of products and solutions that drive meaningful revenue growth and long-term success on the platform—while maintaining strong standards for user trust and platform integrity.

**About the Role**

This role is focused on driving new and expanded advertising revenue and ensuring successful business results for advertisers. You will own the full sales cycle — from prospecting to deal closure, developing long-term commercial partnerships to help advertisers achieve their business objectives while ensuring a strong and responsible experience on our platform.

You’ll work closely with Customer Success Managers and key cross-functional partners to ensure advertisers achieve successful outcomes after the sale, while maintaining primary ownership of revenue growth and commercial strategy.

This role is based in our Munich office. We use a hybrid work model of** **3 days in the office per week and offer relocation assistance to new employees.

**In this role, you will:**

-

Prospect, qualify, and close new advertising opportunities, leading the full sales cycle from initial engagement through contract execution.

-

Own and achieve a defined revenue target within an assigned territory or vertical.

-

Develop and execute structured account plans to drive advertiser ROI and long-term revenue growth.

-

Build and maintain relationships with senior-level advertising decision-makers, delivering strategic guidance and actively gathering their feedback.

-

Structure and negotiate complex commercial agreements.

-

Quantify opportunities through clear, data-driven business cases aligned to advertiser objectives.

-

Lead cross-functional collaboration across Product, Engineering, Marketing, Policy, and Operations to support complex deals.

-

Partner with Customer Success Managers to ensure seamless post-sale transitions and coordinated expansion strategies.

-

Maintain rigorous pipeline management and accurate revenue forecasting.

**You might thrive in this role if you:**

-

Have 10+ years of experience in performance marketing, digital marketing, or client-facing strategy and consulting roles.

-

Have 3+ years of experience as proven advisor influencing executives and clients.

-

Have experience owning revenue targets and closing complex deals.

-

Can build structured business cases and influencing senior stakeholders (internally and externally).

-

Have strong verbal and written communication skills.

-

Can operate in ambiguous, fast-changing environments.

-

Understand the client’s business and priorities to define success metrics and align on partnership goals.

-

Translate analytical insights into compelling commercial narratives.

**About OpenAI**

OpenAI is an AI research and deployment company dedicated to ensuring that general-purpose artificial intelligence benefits all of humanity. We push the boundaries of the capabilities of AI systems and seek to safely deploy them to the world through our products. AI is an extremely powerful tool that must be created with safety and human needs at its core, and to achieve our mission, we must encompass and value the many different perspectives, voices, and experiences that form the full spectrum of humanity.

We are an equal opportunity employer, and we do not discriminate on the basis of race, religion, color, national origin, sex, sexual orientation, age, veteran status, disability, genetic information, or other applicable legally protected characteristic.

For additional information, please see [OpenAI’s Affirmative Action and Equal Employment Opportunity Policy Statement](https://cdn.openai.com/policies/eeo-policy-statement.pdf).

Background checks for applicants will be administered in accordance with applicable law, and qualified applicants with arrest or conviction records will be considered for employment consistent with those laws, including the San Francisco Fair Chance Ordinance, the Los Angeles County Fair Chance Ordinance for Employers, and the California Fair Chance Act, for US-based candidates. For unincorporated Los Angeles County workers: we reasonably believe that criminal history may have a direct, adverse and negative relationship with the following job duties, potentially resulting in the withdrawal of a conditional offer of employment: protect computer hardware entrusted to you from theft, loss or damage; return all computer hardware in your possession (including the data contained therein) upon termination of employment or end of assignment; and maintain the confidentiality of proprietary, confidential, and non-public information. In addition, job duties require access to secure and protected information technology systems and related data security obligations.

To notify OpenAI that you believe this job posting is non-compliant, please submit a report through [this form](https://form.asana.com/?d=57018692298241&k=5MqR40fZd7jlxVUh5J-UeA). No response will be provided to inquiries unrelated to job posting compliance.

We are committed to providing reasonable accommodations to applicants with disabilities, and requests can be made via this [link](https://form.asana.com/?k=bQ7w9h3iexRlicUdWRiwvg&d=57018692298241).

[OpenAI Global Applicant Privacy Policy](https://cdn.openai.com/policies/global-employee-and-contractor-privacy-policy.pdf)

At OpenAI, we believe artificial intelligence has the potential to help people solve immense global challenges, and we want the upside of AI to be widely shared. Join us in shaping the future of technology.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
