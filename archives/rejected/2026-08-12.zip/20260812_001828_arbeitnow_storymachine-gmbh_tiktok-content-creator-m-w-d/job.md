# TikTok Content Creator (m/w/d)

Posted: 2026-08-11T14:30:26Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

## Allgemeine Infos

Standort: Berlin

Arbeitszeit: Vollzeit

Start: ab sofort

StoryMachine ist eine 2017 gegründete Agentur mit dem Schwerpunkt auf strategischem Storytelling für Brands, Persönlichkeiten und politische Institutionen.

Die Basis unseres integrativen Storytellings ist journalistisch und komplett datengetrieben. Wir betrachten Social Channels nicht isoliert, sondern heben ihre Stärken und Besonderheiten hervor und bringen sie zum Vorteil unserer Kund*innen ein.

Unser Büro befindet sich in einem alten Varieté-Theater mitten im Herzen von Berlin. Dort triffst du auf einzigartige Charakterköpfe als Kolleg*innen und erhältst bei regelmäßigen Weiterbildungsimpulsen in unseren internen Academies frische Perspektiven aus der Politik-, Wirtschafts- und Medienwelt.

## Über die Stelle

Wir suchen dich – einen kreativen Kopf mit Leidenschaft für virale Inhalte und einem Gespür für Trends! Als **TikTok Content Creator** bei StoryMachine agierst du mit Leidenschaft, frischen Ideen und vertrittst uns als Expert*in im Bereich **TikTok nach außen wie nach innen** **.**

Du entwickelst TikTok als Kompetenzfeld bei uns weiter, konzipierst Formate und Best Practices und wirst zur zentralen Ansprechperson für alles rund um TikTok, sowohl intern als auch in der Beratung unserer Kund*innen.

Diese Rolle bietet dir **viel Eigenverantwortung, Gestaltungsspielraum** und die Möglichkeit, TikTok bei StoryMachine maßgeblich zu prägen.

## Deine Aufgaben

➡️ TikTok-Strategie – Du entwickelst nachhaltige TikTok-Strategien für unsere Kunden und setzt sie eigenständig um.

➡️ Content-Expertise – Du identifizierst Trends, Formate und Chancen auf TikTok und leitest daraus kreative wie strategische Empfehlungen ab.

➡️ Beratung von Kund*innen – Du berätst Unternehmen auf Expertenniveau zu Kanalaufbau, Content-Strategien und Best Practices.

➡️ Produktion & Umsetzung – Du planst, drehst und editierst TikTok-Content eigenständig

➡️ Format- & Konzeptentwicklung – Du entwickelst skalierbare Video- und Storytelling-Formate, die auf TikTok performen.

➡️ Analyse & Optimierung – Du beobachtest KPIs, leitest Learnings ab und optimierst Strategien datenbasiert.

➡️ Teamübergreifende Zusammenarbeit – Du arbeitest eng mit Redaktion, Design, Consulting und Data zusammen.

## Das bringst du mit

✅ TikTok-Expertise - Du kennst die Plattform in ihrer Tiefe: Trends, Mechaniken, Community-Dynamiken, Formate.

✅ Eigenständigkeit – Du baust Themen gerne selbst auf, triffst Entscheidungen und treibst Projekte proaktiv voran.

✅ Strategisches Denken – Du kannst kreative Ideen in klare Strategien überführen – für interne Projekte wie für Kund*innen.

✅ Beratungskompetenz – Du kannst komplexe Plattformlogiken verständlich vermitteln und souverän vor Unternehmen auftreten.

✅ Content-Verständnis – Du weißt, wie guter Video- und Storytelling-Content entsteht, was wirkt und warum.

## Warum StoryMachine

⭐ Netzwerk & Miteinander – Ob beim wöchentlichen Teamlunch, bei regelmäßigen Events oder über interne Netzwerke: Bei uns findest du Anschluss und echte Verbindungen.

⭐ Wissen & Entwicklung – In unserer internen Academy erwarten dich relevante Weiterbildungen, die dich fachlich und persönlich stärken.

⭐ Persönliche Entwicklung – Du bekommst von Anfang an Verantwortung und Aufgaben, die dich herausfordern und fördern.

⭐ Feedback-Kultur – Wir leben konstruktiven Austausch auf Augenhöhe.

⭐ Teamgeist – Ein herzliches, diverses Team mit wöchentlichen Lunches & gemeinsamen Events.

⭐ Work-Life-Balance – Mit nilo.health erhältst du Zugang zu mentaler Unterstützung – in jeder Lebensphase.

✉️ Let’s talk!

Schick uns einfach deinen Lebenslauf an:

Wir freuen uns auf dich!

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
