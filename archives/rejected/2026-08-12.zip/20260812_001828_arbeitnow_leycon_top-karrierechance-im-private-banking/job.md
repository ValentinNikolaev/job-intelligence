# Top-Karrierechance im Private Banking

Posted: 2026-08-11T15:00:27Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**Schwäbisch Hall | Private Banking**

Sie beraten anspruchsvolle Kunden nicht einfach – Sie entwickeln langfristige Beziehungen und denken Vermögen ganzheitlich?

Für eine erfolgreiche Sparkasse mit etabliertem Private-Banking-Bereich suchen wir eine **starke Beraterpersönlichkeit (m/w/d)**, die Verantwortung übernimmt, unternehmerisch denkt und vermögende Kunden auf Augenhöhe begleitet.

**Wenn Sie mehr bewegen möchten als klassische Anlageberatung, sollten wir sprechen.**

## Aufgaben

Ihre Aufgabe

**Vermögen ist mehr als eine Zahl. Sie verstehen die Ziele Ihrer Kunden, erkennen Potenziale und entwickeln daraus langfristige Lösungen.**

- Vermögende Privatkunden **ganzheitlich und auf Augenhöhe** begleiten

- Bestehende Beziehungen **intensivieren und neue Kunden gewinnen**

- Vermögensstrategien mit Spezialisten **individuell gestalten**

- Ein starkes **regionales Netzwerk** aufbauen und pflegen

- Das Haus bei **exklusiven Kunden- und Netzwerkveranstaltungen** repräsentieren

## Qualifikation

Ihr Profil

- **Fundierte bankfachliche Qualifikation**, z. B. Bankbetriebswirt oder vergleichbare Weiterbildung und idealerweise eine erfolgreich abgeschlossene Weiterbildung zum Financial Consultant

- **Erfahrung in der Beratung vermögender Privatkunden** oder im Private Banking

- **Ausgeprägte Vertriebsstärke** und Freude daran, Kundenbeziehungen aktiv weiterzuentwickeln

- **Souveränes Auftreten, hohe Beratungskompetenz** und Gespür für anspruchsvolle Kundensituationen

- **Eigeninitiative, unternehmerisches Denken** und der Anspruch, Kunden langfristig auf Augenhöhe zu begleiten

## Benefits

**Das Angebot**

- Etabliertes Kundenportfolio mit weiterem Entwicklungspotenzial

- Hoher Grad an Eigenverantwortung und unternehmerischem Handlungsspielraum

- Professionelles Umfeld mit kurzen Entscheidungswegen

- Attraktive Vergütung nach TVöD-S

- 32 Urlaubstage sowie zusätzliche freie Tage am 24. und 31. Dezember

- Betriebliche Altersversorgung und umfangreiche Weiterbildungsangebote

- Weitere attraktive Zusatzleistungen

Interesse?

**Klingt nach dem nächsten Schritt für Sie? Dann freue ich mich auf ein vertrauliches Gespräch.**

**Diskret. Persönlich. Verbindlich.**

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
