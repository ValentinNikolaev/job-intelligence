# Senior AV Delivery Specialist

Posted: 2026-08-11T14:30:14Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Role: **Senior AV Delivery Specialist**

Contract Type: **Full-time, 12-months contract**

Location: **Frankfurt, Germany**

Salary: **To €80,000 (dependent on experience), plus company benefits**

Hours: **Monday – Friday –** **(9.00 am - 5.30 pm) **

Kinly is a unified global leader in collaboration, systems integration, and managed services. We focus on transforming workspaces, simplifying complexity, and empowering people.

With comprehensive capabilities, decades of experience, and expanded delivery teams, we empower global businesses to thrive in the hybrid world, and we are committed to driving a new era of inspiration and opportunity for our people, clients, and partners; one seamless experience at a time.

With 27 offices in 11 countries, 1,600 colleagues, 900 specialist accreditations, 40-years' professional experience and 2,500 customers, we are delivering scalable, secure, and sustainable solutions around the world.

Exciting new opportunity has arisen, on-site at a major global organisation, working as the Senior AV Delivery Specialist, to be responsible for overseeing building projects from inception through to delivery and completion. It requires working closely with design teams and external vendors to manage project design development and ensure quality in execution and delivery.

**Key responsibilities:**

-

Managing project schedules, identifying risks and clearly communicating goals to project stakeholders

-

Coordinating and collaborating with team across the globe to ensure delivery of projects, including schedule, budget, technical and installation oversight

-

Conducting value engineering sessions with contractors to ensure project budget and quality goals are met

-

Working with architects, construction managers, vendors, and logistics team to specify and deliver our global AV design

-

Monitoring and overseeing overall project of the build out process from beginning to end, while coordinating and maintain our global standard in place

-

Coordinating with various teams to schedule techs, programmers & engineers for deployment as well as maintaining the provided time line

-

Issues

-

Troubleshooting technical challenges, problem solving, and physical site related issues

-

Regularly inspecting installation work performed by vendors & contractors before and after room deployments

** **

**Skills and experience:**

-

Fluency in both German and English

-

Proven hands-on experience in AV Collaboration, Room Integration & Project Management

-

Advanced understanding of AV system functionality and installation processes and techniques

-

Proficiency with Microsoft Office, Microsoft project, Adobe Acrobat, and AutoCAD viewing

-

Experience with AV Switching, Touch Panels, Advanced AV Troubleshooting & Maintenance

-

Creative problem-solving, logical deployment skills, agile under pressure, and impeccable organisational abilities

-

Ability to read and comprehend project technical documents including, but not limited to engineering and architectural drawings, schedules, test reports, or commissioning documents

-

Solid understanding of audio/video protocols as well as Crestron coding and DSP site files

-

Self-motivated and able to multitask and work in a fast-paced environment

-

Excellent communications skills, computer skills, customer service skills, follow-up skills and organisational skills

-

Excellent problem solving and troubleshooting skills with the ability to think creatively

-

Must cover different shifts, patterns and travel

**If you are selected for interview, and need any reasonable adjustments made for your interview, please let the Talent Acquisition team know, at the point of scheduling.**

**If you do require details of the vacancy or the application process in an alternative format, please email **

** **

**Equal Opportunities:**

Kinly is committed to providing equal opportunities in employment, all qualified applicants will receive consideration for employment without regard to sex, age, gender identity, pregnancy, colour, race, national origin, sexual orientation, disability, religion or any other ‘protected characteristics. We welcome your application.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
