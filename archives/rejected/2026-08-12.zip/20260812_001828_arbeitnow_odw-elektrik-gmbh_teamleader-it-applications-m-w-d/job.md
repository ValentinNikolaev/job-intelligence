# Teamleader IT Applications (m/w/d)

Posted: 2026-08-11T14:30:28Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Sie möchten nicht nur IT-Anwendungen verwalten, sondern die digitale Transformation eines internationalen Unternehmens aktiv mitgestalten? Dann übernehmen Sie als Teamleader IT Applications eine Schlüsselrolle in unserer globalen IT-Organisation.

In dieser Position führen Sie unser Team IT Applications und verantworten die Weiterentwicklung unserer Applikationslandschaft – von Microsoft 365 und Azure über PLM/PDM-Lösungen bis hin zu innovativen KI- und Automatisierungstechnologien wie Microsoft Copilot und der Power Platform.

## Aufgaben

- Fachliche und disziplinarische Führung des Teams IT-Applications inkl. Weiterentwicklung und Förderung der Mitarbeiter

- Sicherstellung des reibungslosen Betriebs und der Weiterentwicklung der globalen IT-Applikationen und -Systeme:Microsoft 365, Azure/Entra ID und Modern-Work-UmfeldPLM/PDM (CIM-Database), CAD und angrenzende FachapplikationenCollaboration, Intranet/SharePoint, DMS, Telefonie

- Verantwortung für die übergreifende Anwendungs-/Applikationsarchitektur inkl. Definition und Weiterentwicklung von Standards, Roadmaps und Integrationskonzepten

- Verantwortung für die ODW KI-/Automatisierungsthemen (Microsoft Copilot, Copilot Studio, Power Platform) inkl. Governance, Rollout und Enablement

- Steuerung von Informationssicherheit & Compliance im Verantwortungsbereich (ISO 27001, TISAX, NIS2) in enger Abstimmung mit dem ISMS

- Koordination und Leitung globaler IT-Projekte in enger Abstimmung mit Fachbereichen und externen Partnern

- Steuerung und Priorisierung globaler Anforderungen sowie Bewertung und Entscheidung von Make-or-Buy (Eigenentwicklung vs. Standardsoftware/Zukauf) inkl. Wirtschaftlichkeits- und Compliance-Betrachtung

- Schnittstelle zwischen IT und Fachbereichen inkl. Anforderungs- und Prozessmanagement in Abstimmung mit allen IT-Teams

- Steuerung an internen Kommunikations- und Enablement-Kampagnen (z. B. Adoption neuer Tools)

- Verantwortlich für 1st- und 2nd-Level-Support im Fachbereich sowie Anwender-/Systembetreuung

- Überwachen, Steuern und Optimieren der Applikationen; kontinuierliche Verbesserung von IT-Services, -Systemen, -Tools und -Prozessen

## Qualifikation

**Fachliche Voraussetzungen**

- Erfolgreich abgeschlossenes Studium im Bereich Informatik oder gleichwertige Aus-/Weiterbildung im IT-Bereich

- Erfahrung in der Führung (kleiner) Teams

- Gute Kenntnisse in: Microsoft 365 / Azure / Entra ID, Cloud-Applikationen, PLM/PDM, CAD, sowie erste Erfahrungen in KI/Automatisierungstechniken wie Copilot, Power Platform, oder vergleichbar

- Erfahrung im Aufbau und Betrieb von IT-Systemen sowie im Leiten globaler IT-Projekte

- Kenntnisse in ISMS/ISO 27001, TISAX, NIS2 von Vorteil

- Zertifizierungen (z. B. ITIL) wünschenswert

- Gute Englischkenntnisse in Wort und Schrift

**Persönliche Voraussetzungen**

- Hohe Teamfähigkeit

- Ausgeprägte konzeptionelle und analytische Fähigkeiten

- Belastbarkeit, Fähigkeit unter Druck zu arbeiten

- Gute Kommunikations- und Moderationsfähigkeit

- Unternehmerisches Denken

## Benefits

- Verantwortungsvolle Führungsaufgabe mit großem Gestaltungsspielraum

- Internationale Zusammenarbeit in einem globalen Unternehmensumfeld

- Modernes Technologieumfeld mit Fokus auf Cloud, Digitalisierung und KI

- Kurze Entscheidungswege und hohe Eigenverantwortung

- Gleitzeit und Hybrides Arbeiten

- Individuelle Weiterbildungs- und Entwicklungsmöglichkeiten

- Attraktives Vergütungspaket sowie umfangreiche Sozialleistungen

- Einen gut erreichbaren Arbeitsplatz – Direkt an der A66 Ausfahrt 47 Steinau und fußläufig zum Bahnhof

- Betriebliche Gesundheitsförderung und Sportangebote (Fitnessstudio)

- Bike-Leasing

Bereit, die digitale Transformation mitzugestalten?

Dann freuen wir uns auf Ihre Bewerbung und darauf, gemeinsam die Zukunft der IT-Applikationslandschaft bei ODW-ELEKTRIK weiterzuentwickeln.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
