# Senior Product Manager- Hardware

Posted: 2026-08-28T20:45:26Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

## Team description

The Hardware Tribe designs and builds the point-of-sale devices and accessories that let millions of small businesses take payments every day, spanning industrial design, embedded systems, mobile apps and backend services. This role sits at the centre of that work, partnering closely with hardware, software, industrial design, marketing, finance and executive teams to shape new POS features and bring them to market. It's an opportunity to own the strategy, roadmap and customer experience for a physical product that merchants rely on every single day.

## What you'll do

-

Lead a team of engineers and designers to deliver the best possible POS experience for merchants

-

Turn merchant feedback into clear technical requirements and product decisions

-

Partner with hardware, engineering, industrial design and product design teams to shape new features

-

Define the strategy, roadmap and specifications for POS systems based on market needs and technical trends

-

Manage the product lifecycle from early concept through to mass production

-

Make the final call on long-term product strategy and rollout

## You'll be great for this role if…

-

Experience in product management with a focus on consumer applications or consumer electronic devices.

-

Track record of building and scaling B2B or B2C products.

-

Experience leading cross-functional teams to deliver products and projects.

-

Strong communication and interpersonal skills, comfortable working with executive management and external partners.

-

Ability to take ownership and deliver results in a fast-paced, dynamic environment.

## Why you should join SumUp

🌎 Opportunity to work with SumUppers globally on large-scale fintech products used by millions of businesses worldwide, from our Berlin office. This involves an office-first setup

🌈 Commitment to Diversity and Inclusion: be part of a workplace that values and promotes diversity, fostering an inclusive environment where everyone's perspectives are respected and embraced

🚀 Enrolment onto our Virtual Stock Option programme: you will own a stake in SumUp's future success

📚 A dedicated annual L&D budget of €2000 for your individual development, which can be used to attend conferences and/or advance your career through further education

💶 A corporate pension scheme where we match up to 20% of your contributions

🏖 Generous time off: enjoy 28 days of paid leave plus public holidays and special leave days

🎁 Numerous other benefits such as Urban Sports Club subsidy, Kita placement assistance, subsidised office lunches

🌴 Break4me: 1-month sabbatical after 3 years of service

🔗 Referral Bonus: earn additional rewards by referring talented individuals to join the SumUp team

## About SumUp

Be empowered to do more that matters.

At SumUp, we're on a mission to empower small businesses across the globe by providing simple and affordable tools that allow them to thrive. Today, over 4 million businesses in 38 markets rely on SumUp as their financial partner to manage payments, finance and customer relationships.

Our commitment to small businesses is reflected in [our diverse team](https://youtu.be/9DG64C3moeQ?si=YpcWuBNBTOQPzeLI) of over 3,000 SumUppers from over 90 nationalities, united by global collaboration and an innovative mindset. [Our core values](https://www.sumup.com/careers/culture/) lay the foundation for who we are and what we stand for, shaping our work culture and driving our success. We foster inclusivity and a continuous learning culture, providing a safe space for personal and professional growth. Our differences make us unique and strong as we strive to create an environment where everyone belongs and feels supported, no matter how they identify.

SumUp is proud to be an Equal Employment Opportunity employer, actively seeking and embracing diversity in our workforce. We don't make hiring or employment decisions based on race, colour, religion or religious belief, ethnic or national origin, nationality, sex, gender, gender identity, sexual orientation, disability, age or any other basis protected by applicable laws or prohibited by company policy. Our commitment extends beyond recruitment to creating a safe and respectful workplace where harassment of any form is strictly prohibited. Discover more about our culture and opportunities on our [careers website](https://www.sumup.com/careers/), and follow our journey on [LinkedIn](https://www.linkedin.com/company/sumup/), [Instagram](https://www.instagram.com/insidesumup/), and [TikTok](https://www.tiktok.com/@insidesumup).

**Job Application Tip**

We recognise that candidates feel they need to meet 100% of the job criteria in order to apply for a job. Please note that this is only a guide. If you don't tick every box, it's ok too because it means you have room to learn and develop your career at SumUp.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
