# Software-Entwickler (Backend) (m/w/d) - alemo kommunikations GmbH

Posted: 2026-09-07T15:01:32Z

## Rejection

- Category: tech_stack
- Reason: role does not mention Go/Golang or PHP

Spannende, abwechslungsreiche und wirklich anspruchsvolle Projekte Eigenverantwortung und Selbständigkeit in Deiner Arbeit ab dem ersten Tag Freie Wahl von Hardware und OS sowie ein sehr ergonomischer Arbeitsplatz Leistungsorientierte Vergütung Interessante Möglichkeiten, Erfahrungen mit modernen Technologien, Entwicklungswerkzeugen und -prozessen (Kanban / Jira, Bitbucket, GIT, CI/CD, Docker, ) zu sammeln bzw. auszubauen Flexible Arbeitszeiten und Home-Office-Möglichkeiten Richtig viel Spaß, T…
