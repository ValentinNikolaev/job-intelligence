# Senior Fullstack Engineer - Localization

Posted: 2026-09-11T20:45:28Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

The Localization team builds and owns the systems that make sure every merchant, in every one of our 38 markets, can understand and use our products in their own language. It's one of the most critical enablers of SumUp's global growth, sitting at the heart of how fast and how well we can go to market anywhere in the world.

As our Senior Full Stack Engineer, you'll bring dedicated engineering ownership by working closely with the team to scope, build and ship the systems, integrations and tooling accelerate the ongoing evolution of our localization platform towards greater automation, scalability and end-to-end integration. If you want autonomy, meaningful scope, and the chance to shape a growing function, this is the role.

**What you'll do:**

- Design, build and optimise localization solutions across product, CMS, CRM, marketing and design systems, so content moves faster without compromising quality

- Improve the localization management platform to give the team greater visibility and control while reducing manual steps

- Embed automated language and quality checks into several steps of the localization workflows, catching issues before they reach production

- Improve the experience for developers, designers, marketers and content teams by ensuring localization solutions support their processes and ways of working

- Partner with Web and Mobile, Website, Comms Platform and other technical teams to enable localization capabilities across the technology stack

- Explore how AI and language technology can strengthen and future-proof the localization stack, while ensuring solutions meet evolving compliance requirements.

**You'll be great for this role if:**

- Strong background in backend engineering, ideally with Go (alternatively knowledge with Python, Rust or C++)

- Experience building and maintaining RESTful APIs in a microservices or distributed systems environment

- Working knowledge of databases such as PostgreSQL and event streaming tools such as Kafka

- Comfort translating priorities from non technical stakeholders into scoped, shippable engineering work

- Ability to operate independently across a fragmented, distributed system landscape, working within architecture owned by other teams

- Exposure to frontend frameworks such as Reactjs and languages like Typescript

- Experience working with translation management systems (TMS), or with the localization of web or mobile applications and other content platforms.

**Why you should join SumUp**

🌎 Opportunity to work with SumUppers globally on large-scale fintech products used by millions of businesses worldwide, from our Berlin office. This involves an office-first setup

🌈 Commitment to Diversity and Inclusion: be part of a workplace that values and promotes diversity, fostering an inclusive environment where everyone's perspectives are respected and embraced

🚀 Enrolment onto our Virtual Stock Option programme: you will own a stake in SumUp's future success

📚 A dedicated annual L&D budget of €2000 for your individual development, which can be used to attend conferences and/or advance your career through further education

💶 A corporate pension scheme where we match up to 20% of your contributions

🏖 Generous time off: enjoy 28 days of paid leave plus public holidays and special leave days

🎁 Numerous other benefits such as Urban Sports Club subsidy, Kita placement assistance, subsidised office lunches

🌴 Break4me: 1-month sabbatical after 3 years of service🔗 Referral Bonus: earn additional rewards by referring talented individuals to join the SumUp team

**About SumUp**

Be empowered to do more that matters.

At SumUp, we're on a mission to empower small businesses across the globe by providing simple and affordable tools that allow them to thrive. Today, over 4 million businesses in 38 markets rely on SumUp as their financial partner to manage payments, finance and customer relationships.

Our commitment to small businesses is reflected in [our diverse team](https://youtu.be/9DG64C3moeQ?si=YpcWuBNBTOQPzeLI) of over 3,000 SumUppers from over 90 nationalities, united by global collaboration and an innovative mindset. [Our core values](https://www.sumup.com/careers/culture/) lay the foundation for who we are and what we stand for, shaping our work culture and driving our success. We foster inclusivity and a continuous learning culture, providing a safe space for personal and professional growth. Our differences make us unique and strong as we strive to create an environment where everyone belongs and feels supported, no matter how they identify.

SumUp is proud to be an Equal Employment Opportunity employer, actively seeking and embracing diversity in our workforce. We don't make hiring or employment decisions based on race, colour, religion or religious belief, ethnic or national origin, nationality, sex, gender, gender identity, sexual orientation, disability, age or any other basis protected by applicable laws or prohibited by company policy. Our commitment extends beyond recruitment to creating a safe and respectful workplace where harassment of any form is strictly prohibited. Discover more about our culture and opportunities on our [careers website](https://www.sumup.com/careers/), and follow our journey on [LinkedIn](https://www.linkedin.com/company/sumup/), [Instagram](https://www.instagram.com/insidesumup/), and [TikTok](https://www.tiktok.com/@insidesumup).

[Berlin office](https://www.youtube.com/watch?v=9DG64C3moeQ)

**Job Application Tip**

We recognise that candidates feel they need to meet 100% of the job criteria in order to apply for a job. Please note that this is only a guide. If you don't tick every box, it's ok too because it means you have room to learn and develop your career at SumUp.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
