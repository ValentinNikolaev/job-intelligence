# AI Automation Specialist - Marketing & GTM (d/f/m)

Posted: 2026-09-21T05:40:07Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

## Our story:

Every year millions of people are either filing their taxes in fear or giving up on their tax refund altogether. We're working on fixing that. Our intuitive app enables anyone, regardless of education or background, to file their taxes with newfound confidence.

Spread across Germany, Spain and the UK, the team at Taxfix Group with its brands Taxfix and Steuerbot, is a compassionate group of solution-finders. We speak our minds openly, and with over 400 professionals, including tax experts, developers, and IT security experts, we're rich in ideas and voices. The group has facilitated more than 3.5 billion euros in tax refunds for its customers since its founding in 2016.

## About the role

Across marketing - steering, paid channel operations, creative production, experimentation, reporting - skilled people still spend days on work that follows a pattern. That was just the cost of doing business until coding agents arrived and dropped the speed limit for building internal software from months to days. The tools to erase that repetitive work now exist, and most of the gain hasn’t been claimed yet.

You claim it. This is a founding-engineer role for the automation layer of our marketing operating system. Taxfix’s marketing team is rebuilding around an agentic-first way of working, where AI is the default mode for all work - and you build the systems that make it real: agent harnesses, data and context pipelines, integrations, and internal tooling.

You embed with our teams, find the workflows that eat the most time or cap the most output, and remove them. You choose what to build, you build it, you ship it, and you run it.

## What you'll do

-

**Design and build our agentic operating model.** Taxfix is rebuilding around an AI-first, agentic-first way of working, and you drive or contribute to what that operating system becomes. Understand the problem space and the solution space, map how the work should run when agents carry the load, then design the system and build it.

-

**Find the bottlenecks, then remove them.** Embed with the Creative Studio, User Acquisition, CRM, SEO/AEO, and analytics teams. Map how work actually flows, find where hours disappear or quality caps out, and turn multi-day processes into effective automated systems.

-

**Build advanced agentic systems, including agent harnesses.** Go past single-shot scripts and one-step automations. Design and build the agent harnesses that let agents run complex, multi-step workflows toward a goal: the orchestration, the tool interfaces, the guardrails, the memory, and the evaluation loops that keep them reliable. Example targets: automate creative production workflows or build a multi-agent system to automate channel operations end-to-end.

-

**Own your architecture.** Build software where we don't buy it. Wire up a lean no-code stack where that wins. You decide based on ROI for the use case, then handle your own deployment, DevOps, and maintenance.

-

**Systematize and scale what works.** Recognize patterns across teams. When you automate a workflow for one, abstract and modularize it so the rest of the org can run and benefit from it. Document the tools and the playbooks so the wins compound over time.

-

**Turn individuals into builders.** As you ship, you pull marketers up with you: hand off tools they can run and extend, show them how you built it, and contribute to our move toward an AI-first organization. You lead this shift by building and coaching others.

## Who you are

**The 33/33/33 hybrid.** You work at the intersection of marketing, engineering, and analytics: about a third marketing sense, a third software engineering or advanced marketing automation, a third analytics and data. Few people carry all three. You are one of them, or you are close and hungry to close the gap.

We hire from two directions and weight them equally:

-

A (former) software engineer who wants to work on marketing and growth problems, or

-

A marketing-automation or MarTech builder with real full-stack engineering range.

Either way, you build. You have shipped systems, not only configured them.

-

**High agency & low ego.** You are a self-starter. You get close to teams, understand the opportunity, and implement it end to end. You set your own success metrics around the efficiency and output you unlock.

-

**Comfortable in the ambiguity.** You build the infrastructure, choose the tools, deploy the software, and maintain it, with no map or backlog handed to you. You read this as the appeal, not as a risk.

-

**High conscientiousness and relentless curiosity.** You finish what you start and hold the bar high on the work that ships. And you are genuinely obsessed with where AI is going: you are the first to dig into a new capability, figure out how it works, and ask what it means for our work. That curiosity extends across the full Growth area, where marketing, product, engineering, data, and design meet.

## What you'll bring

-

A track record of building internal tools, automation pipelines, or backend integrations that changed how real work got done. Software engineering, MarTech, or marketing automation backgrounds all qualify.

-

Hands-on experience with modern AI-assisted build tools (Claude Code, agent frameworks, model APIs) used to ship working software fast.

-

Fluency with REST APIs, webhooks, data pipelines, and connecting disparate software platforms (e.g. creative suites, ad network APIs, CRM systems)

-

Solid grounding in analytics and data management, knowing how data flows through internal systems to power automated marketing operations.

## Why Taxfix?

-

A chance to do meaningful, people-centric work with an international team of passionate professionals.

-

Holistic well-being with free mental health coaching sessions.

-

A monthly allowance to spend on an extensive range of services that you can use and roll over as flexibly as you like.

-

Employee stock options for all employees—because everyone deserves to benefit from the success they help to create.

-

30 annual vacation days and flexible working hours.

-

A generous learning budget to support your personal and professional development and guidance from our internal L&D experts.

-

Work from abroad for up to six weeks every year. Just align with your team, and then enjoy your trip.

-

Plenty of opportunities to socialise as a team. In addition to internal meetups, our international team hosts regular get-togethers—virtually and in person when possible.

-

Free tax declaration filing, of course, through the Taxfix app—and internal support for all personal tax-related questions.

-

Have a four-legged friend in your life? We’re happy to have dogs join us in the office.

Excited? So are we. Learn more about [Team Taxfix](https://medium.com/taxfix) on our blog and get a glimpse of our culture.

*At Taxfix, we believe that incredible things happen when you have a wealth of perspectives and experiences. We're proudly committed to equal employment and development opportunities no matter your gender, race, religion, age, sexual orientation, colour, disability, or place of origin. To help mitigate any potential unconscious biases, we ask that you refrain from including your picture, age, or marital status on your CV. Let your experiences speak for themselves.*

Not sure if you meet all the requirements for this role? Please apply anyway. You might bring something special to the team that we hadn't considered previously.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
