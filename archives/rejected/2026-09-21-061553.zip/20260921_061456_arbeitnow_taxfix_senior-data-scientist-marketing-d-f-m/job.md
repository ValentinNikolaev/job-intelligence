# Senior Data Scientist, Marketing (d/f/m)

Posted: 2026-09-21T05:40:07Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

## **Our story:**

Every year millions of people are either filing their taxes in fear or giving up on their tax refund altogether. We're working on fixing that. Our intuitive app enables anyone, regardless of education or background, to file their taxes with newfound confidence.

Spread across Germany, Spain and the UK, the team at Taxfix Group with its brands Taxfix, Steuerbot and TaxScouts, is a compassionate group of solution-finders. We speak our minds openly, and with over 400 professionals, including tax experts, developers, and IT security experts, we're rich in ideas and voices. The group has facilitated more than 3.5 billion euros in tax refunds for its customers since its founding in 2016.

## **Why this role, why now?**

Our data infrastructure and marketing foundations are already in place. We run a large marketing budget across competitive digital channels and our stakeholders are data-driven - they run experiments and dig into data themselves. What's missing is the rigorous scientific layer that connects attribution, MMM and incrementality testing into one coherent, automated measurement framework. You will own that build.

## **Your challenge:**

Join our Marketing Analytics team as a Senior Data Scientist, where your mission is to build the measurement and modeling capability that decides how we grow. You will own how Taxfix measures marketing causally and turn that into production models that directly shape CLV, CAC, and revenue. Your output is durable measurement infrastructure and models that the Growth Marketing, CRM, and MarTech teams rely on every day to scale efficiently in competitive markets.

## **Your responsibilities and decisions:**

-

Design and run experiments as a discipline. Geo tests and incrementality studies are your primary instrument for establishing what actually drives growth. You’ll focus on a full cycle from choosing the design to reading the result and turning it into a spend decision.

-

Advance our steering mechanisms (regression, Bayesian inference, causal inference) turning open-ended budget questions into clear decision framework that increases CLV and reduces CAC.

-

Own and advance our marketing measurement stack (attribution, MMM, incrementality testing, brand tracking) and set the standard the marketing organisation uses to make budget, channel-mix, and retention decisions.

-

Build production-grade models (CLV, demand forecasting) that feed live decisions such as budget allocation and channel mix - not one-off analyses.

-

Communicate results persuasively to technical and non-technical stakeholders and drive adoption of recommendations across Marketing.

-

Bring AI-native analytics workflows (agentic data exploration, LLM-assisted causal analysis) into the team's everyday practice.

## **Your profile:**

**Must have**

-

**5+ years** in data science or analytics, ideally with exposure to marketing or growth contexts.

-

Strong statistical and causal inference foundation: regression, Bayesian methods and especially **incrementality testing.** You can design a test from scratch: pick the unit of randomisation, reason about power and minimum detectable effect, and defend the runtime with more than intuition.

-

Deep understanding of **marketing attribution** - not just channel mechanics. You understand what a multi-touch model can and cannot tell you and how to triangulate attribution against incrementality reads.

-

Advanced **SQL and Python**; comfortable working with sparse, high-dimensional advertising data.

-

**Hands-on experience with AI-driven workflows**: prototyping with LLMs (e.g. Claude Code, Gemini CLI), automating pipelines (e.g. LangChain, n8n), or AI-powered IDEs (e.g. Cursor).

-

**Proactive and outcome-driven** - someone who picks up a project and drives it fully, from data pipeline to business recommendation.

**Nice to have**

-

Experience with **Marketing Mix Modelling** (MMM). Formal MMM experience is a bonus, but what actually matters is that you understand the regression underneath it.

-

**Machine learning** experience (classification, clustering, forecasting, CLV prediction) - strong plus, not a blocker.

-

**Dbt** for **data modelling**

-

Familiarity with **BI tools such as Looker**.

**Soft skills we're looking for **

-

**Ownership and proactivity** - someone who suggests new projects and expands scope, not just executes assigned work.

-

Ability to ideate and **learn quickly** in unfamiliar domains (we don't need a marketer; we need a scientist who can quickly grasp marketing measurement logic).

-

Strong **stakeholder management and communication skills** - able to bridge technical results and business decisions for both analyst and executive audiences.

**The team:**

-

You will join a small, high-impact team: one senior data scientist, one mid-level data scientist, one analytics engineer, and the hiring manager. Small team, large mandate.

## **Why Taxfix?**

-

A chance to do meaningful, people-centric work with an international team of passionate professionals.

-

Holistic well-being with free mental health coaching sessions.

-

A monthly allowance to spend on an extensive range of services that you can use and roll over as flexibly as you like.

-

Employee stock options for all employees—because everyone deserves to benefit from the success they help to create.

-

30 annual vacation days and flexible working hours.

-

Work from abroad for up to six weeks every year. Just align with your team, and then enjoy your trip.

-

Plenty of opportunities to socialise as a team. In addition to internal tech meetups, our international team hosts regular get-togethers—virtually and in person when possible.

-

Free tax declaration filing, of course, through the Taxfix app—and internal support for all personal tax-related questions.

-

Have a four-legged friend in your life? We’re happy to have dogs join us in the office.

Excited? So are we. Learn more about [Team Taxfix](https://medium.com/taxfix) on our blog and get a glimpse of our culture.

*At Taxfix, we believe that incredible things happen when you have a wealth of perspectives and experiences. We're proudly committed to equal employment and development opportunities no matter your gender, race, religion, age, sexual orientation, colour, disability, or place of origin. To help mitigate any potential unconscious biases, we ask that you refrain from including your picture, age, or marital status on your CV. Let your experiences speak for themselves.*

Not sure if you meet all the requirements for this role? Please apply anyway. You might bring something special to the team that we hadn't considered previously.

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
