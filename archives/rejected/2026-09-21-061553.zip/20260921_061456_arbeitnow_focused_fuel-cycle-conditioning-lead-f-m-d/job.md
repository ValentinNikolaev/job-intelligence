# Fuel Cycle Conditioning Lead (f/m/d)

Posted: 2026-09-21T05:40:08Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

## **About Focused Energy**

Focused Energy is an international deep-tech company based in Germany and the US, working to commercialize laser-driven nuclear fusion. Our mission is to provide clean, safe, and virtually unlimited energy to the world. We are rapidly scaling and looking for talented individuals who thrive in building clarity and structure within fast-growing environments.

**Role Overview:**

The Fuel Cycle Conditioning Lead is responsible for the design and development of fuel cycle conditioning systems, including chamber conditioning and tritium processing systems. Reporting to the Fuel Cycle Group Leader, this role leads the development of key fuel cycle components and ensures their integration within the wider reactor and plant design. As a critical member of the Fuel Cycle team, the position supports the conceptual and technical development of one of the plant's core systems, working closely with Fuel Recycling and Fuel Storage teams to deliver a safe, efficient, and integrated fuel cycle solution.

**Key Responsibilities:**

-

End-to-end accountability for the Fuel Cycle Conditioning design.

-

Provide technical leadership for Fuel Cycle Conditioning activities.

-

Define and govern the overall Fuel Cycle Conditioning architecture, including system configuration, key design parameters, and fundamental safety principles.

-

Resolve complex, cross-disciplinary technical issues that cannot be addressed at the component or discipline level.

-

Author key engineering deliverables, including system design descriptions, design basis documents, interface control documents, and safety analysis inputs.

-

Lead and coordinate a multidisciplinary engineering team.

-

Report design progress, risks, and issues to the Fuel Cycle Group Leader.

-

Manage design change control processes to maintain schedule and cost performance while preserving design integrity.

** Required Skills & Experience**

-

M.Sc. in Nuclear Engineering or Chemical Engineering.

-

Experience in fluid engineering.

-

Advanced experience with process engineering simulation tools.

-

Minimum of 5 years of experience.

-

Minimum 2 years of experience leading multidisciplinary technical teams.

-

Deep knowledge of process engineering for plant systems, safety analysis principles, and design basis development.

-

Knowledge of nuclear reactor physics.

-

Advanced Fusion & fission reactor knowledge is an advantage.

-

Mastery of process engineering tools.

-

Understanding of processes, mechanical analyses, and I&C.

-

Requirements management. RAMI., Licensing, Documentation and control., Project scheduling.

Focused Energy is an equal opportunity employer committed to creating an inclusive environment. Qualified applicants will receive consideration for employment without regard to race, color, religion, sex, sexual orientation, gender perception or identity, national origin, age, marital status, protected veteran status, or disability status.

Pursuant to the San Francisco Fair Chance Ordinance, Focused Energy will consider for employment qualified applicants with arrest and conviction records.

Compensation offered will be determined by factors such as location, level, job-related knowledge, skills, and experience. Certain roles may be eligible for incentive compensation, equity, benefits.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
