# Customer Value Partner (German Speaking)

Posted: 2026-09-21T05:40:03Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**About Us**

Hawk is the leading provider of AI-supported anti-money laundering and fraud detection technology. Banks and payment providers globally are using Hawk’s powerful combination of traditional rules and explainable AI to improve the effectiveness of their AML compliance and fraud prevention by identifying more crime while maximizing efficiency by reducing false positives. With our solution, we are playing a vital role in the global fight against Money Laundering, Fraud, or the financing of terrorism. We offer a culture of mutual trust, support and passion – while providing individuals with opportunities to grow professionally and make a difference in the world.

## Your Mission

As a Customer Value Partner at Hawk, you own the customer relationship from first scoping through implementation and into ongoing growth: one name, one accountable owner, no handoffs between a CSM, an Engagement Manager, and a PM along the way. You run delivery according to Hawk's best practices and methodology, and you're judged on whether the customer hits the outcomes we promised. At the core of the role is understanding what value actually means for each customer, in their own numbers, against their own objectives, and then building it, not reporting on it after the fact. You're not a project manager who bends to every customer's internal governance model. You're the person who proves the value Hawk delivers, then converts that proof into retained and expanded revenue.

## Key Responsibilities

-

Own the full customer lifecycle for your portfolio, from initial scoping and implementation through to ongoing value realization, adoption, and new use cases. There's no relay handoff here; you carry the account start to finish.

-

Manage delivery according to Hawk's best practices and methodology: build the plan, track progress against it, and report clearly. Lightweight project management, owned by us.

-

Understand what value truly means for each customer, in their own numbers, and then build it. Design and drive joint success plans that align Hawk's delivery to each client's real business objectives and regulatory context, not a generic template.

-

Own commercial outcomes: drive GRR and NRR for your accounts, and where contract terms carry revenue contingency, own that recognition outcome too.

-

You're not negotiating deal terms, but you're building and proving the confidence that gets deals signed and renewed.

-

Monitor usage and performance relentlessly, and turn what you find into optimization work: false positives down, analyst hours back, faster investigations. These are numbers customers see in their own systems, not numbers we tell them about.

-

Bring AI and agentic AI tools and techniques into how you manage your customers: faster QBR prep, sharper account insight, more consistent reporting, so your time goes to judgement and relationships, not manual admin.

-

Work the sales cycle as a credibility engine, not a seller. You get pulled into pre-sale conversations to build confidence that Hawk can actually deliver what's being promised, backed by your own track record of having done it, and you're the SME customers turn to for end-to-end value creation and enablement with Hawk's technology.

-

Build and defend executive relationships across the account, from governance calls to QBRs, so that Hawk's value is something the customer's leadership sees and states in their own words, not something we have to convince them of every quarter.

## Your Profile

-

5+ years in customer-facing roles spanning some combination of customer success, engagement management, or delivery/project management within B2B enterprise software. This role consolidates all three, so breadth across them matters more than a title match.

-

A real track record managing accounts at $500K+ ARR, including cross-sell or expansion work you can point to and explain, not just accounts you kept alive.

-

Comfortable owning a delivery plan end to end, scoping, tracking, and reporting, using Hawk's best practices and methodology, without needing a separate PM in the room to keep things on track.

-

Strong grasp of SaaS and enterprise software delivery models; experience in AML, fraud prevention, or another regulated financial services domain is a real advantage, not a nice-to-have footnote.

-

Hands-on comfort with AI and agentic AI tools and techniques, and you actually use them, to work faster, sharpen your analysis, and raise the quality of what you deliver to customers, not just aware that they exist.

-

Genuine comfort operating at C-suite level. You can run a governance call with a customer's leadership team and hold your own, translating delivery status into a conversation executives actually want to have.

-

A bias toward ownership over process. You understand what value actually means for a customer, not just what the contract says, and you close the gap yourself rather than waiting for someone else to.

-

Experience in, or real appetite for, a start-up or scale-up environment where the account model is still being built as you go, not a fully mature playbook you're just executing.

-

Fluent German communication skills

## Bonus

-

Another language relevant to Hawk's EMEA customer base, in addition to fluent English.

-

Prior experience where you personally carried both the commercial number (GRR/NRR) and the delivery outcome for the same account, rather than one or the other

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
