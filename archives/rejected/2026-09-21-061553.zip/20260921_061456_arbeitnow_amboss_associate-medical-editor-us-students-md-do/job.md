# Associate Medical Editor - US Students (MD/DO)

Posted: 2026-09-21T05:40:11Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Hello there, we are AMBOSS, and we are looking for a committed physician to support our medical editorial team. You’ll apply your medical knowledge and experience to help produce the reliable resource you wish you’d had as a medical student. Join our team of ambitious and talented medical professionals and help improve medical education for millions of students worldwide.

## You will:

-

Work closely with other motivated medical professionals to help plan, develop, write, and review medical content for students, with a strong focus on the US market.

-

Bring fresh ideas to how we improve and evolve our existing content

-

Integrate user feedback and incorporate new evidence-based guidelines to keep our content current and relevant to the target users.

-

Become an expert in using our content management system, which seamlessly integrates text, images, and videos to create our AMBOSS QBank.

-

Use low-code automation and retrieval-augmented generation tools, with human oversight, to support high-quality, accurate editorial work.

-

Build intermediate-to-advanced agentic AI skills and apply them hands-on to shape new products for the US student market

## You bring:

-

An MD or DO degree, preferably with USMLE or COMLEX experience.

-

Excellent written and verbal communication skills in English, so you can articulate an idea clearly and make a case for it.

-

High agency, creativity, and problem-solving skills.

-

Genuine curiosity about AI tools and a willingness to experiment, even without deep technical background

-

Familiarity with the AMBOSS platform (preferably a current or previous AMBOSS user).

-

Proficiency in finding, selecting, and interpreting clinical literature and medical society guidelines.

-

Didactic mindset.

-

Knowledge of (or curiosity about) emerging tools and resources in US medical education.

-

Full-time or near-full-time availability (at least 30 hours/week).

-

**Located in Germany or willing to relocate to Germany. (we provide relocation support)**

-

Experience with the creation of educational content (a plus).

-

Experience using LLM tools or building AI-supported workflows (a plus).

-

Digital literacy or technological proficiency, e.g., basic CS skills (a plus).

## You enjoy:

-

Working in a team of smart and very communicative editors.

-

Systems-level thinking that centers the user experience.

-

Explaining complex medical topics to others in a clear and didactic manner.

-

Giving and receiving authentic feedback.

-

Learning new skills and diving into different ways of working.

## **Benefits:**

**🌴 Rest & Time Off** (30 paid vacation days, AMBOSS holiday, personal purpose day and more)

**🥙Food & Office Comfort (**Daily healthy breakfast & lunch by in-house chef in Berlin HQ, AMBOSS daycare, work remotely from other office spaces in Cologne, Sardinia, Cape Town)

**🏃 Health, Fitness & Mobility** (Urban Sports Club -M plan- , Fitbit Versa 3, Deutschland Ticket…)

Check out the full list of benefits below:

[https://go.amboss.com/the-amboss-prescription-de](https://go.amboss.com/the-amboss-prescription-de)

We believe that diversity is a powerful driver of innovation and progress. That’s why we are committed to fostering an inclusive, respectful, and supportive environment where everyone—regardless of gender, age, ethnic or cultural background, religion, disability, sexual orientation, gender identity—is valued and given equal opportunity to thrive. We warmly welcome people of all backgrounds to help us fulfil our mission: empowering all medical professionals to provide the best possible care 🩺

Even if you don’t meet every single point in the job description, we still encourage you to apply. We’d love to hear from you!

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
