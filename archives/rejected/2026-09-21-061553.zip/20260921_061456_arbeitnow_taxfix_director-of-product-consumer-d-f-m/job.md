# Director of Product, Consumer (d/f/m)

Posted: 2026-09-21T05:40:07Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

# **Our story:**

Every year millions of people are either filing their taxes in fear or giving up on their tax refund altogether. We're working on fixing that. Our intuitive app enables anyone, regardless of education or background, to file their taxes with newfound confidence.

Spread across Germany, Spain and the UK, the team at Taxfix Group with its brands Taxfix, Steuerbot and TaxScouts, is a compassionate group of solution-finders. We speak our minds openly, and with over 400 professionals, including tax experts, developers, and IT security experts, we're rich in ideas and voices. The group has facilitated more than 3.5 billion euros in tax refunds for its customers since its founding in 2016.

# **Your opportunity:**

AI is fundamentally changing how people optimize their taxes. The playbook that built our self-filing business over the last decade won't be the one that grows it over the next five. This role exists to write the new one.

Taxfix's self-filing product is what put us on the map nearly 10 years ago, and it remains the core of our business today spanning both the Taxfix and Steuerbot brands in Germany. But the market is shifting fast: consumer expectations, competitive dynamics, and the products themselves are all being reshaped by AI.

As Director of Product for Self-Filing, you will own our core self-filing product lines. You set the product vision, lead the strategy, and drive the quality of execution across a set of high-autonomy Builder teams. You work as a duo with the Commercial leader of your business area. The Commercial leader owns the *what*, *why*, and *how much.* The Director of Product owns the *how* — the product vision, the roadmap, the craft, and the delivery.

You'll report directly to the Chief Product Officer, with full senior sponsorship to move fast and make the big calls.

# **Your responsibilities and decisions:**

-

**Own the product vision and roadmap.** You set the product direction for self-filing in Germany and make it clear to the builders working with you, to your commercial partner, and to leadership. You make trade-offs visible and hold the line when priorities need protecting.

-

**Shape the two-brand strategy.** Taxfix and Steuerbot are two trusted brands serving the same market. You'll play a central role in how they evolve: where they converge and where they stay distinct.

-

**Build the AI-native product.** You've been applying AI as a design lens, not following the trend. You have a clear POV on where AI removes genuine cognitive load in the filing journey and where it's noise. You push the team to build experiences that weren't possible 18 months ago and to reimagine filing itself: from a once-a-year event into a year round optimization experience.

-

**Grow beyond filing into wealth creation.** This area is evolving from a once-a-year filing product into a broader, year-round financial relationship. You'll help shape and build the relationship to adjacent financial services that deepen value for users and give them a reason to stay with us between filing seasons.

-

**Be the definitive authority on the user.** You've done more user interviews than most of the team combined. You describe your users as people, not segments, and you use that to kill bad ideas early and back good ones hard. Your instincts come from direct contact, not distance.

-

**Lead your Builder teams.** Small, high-autonomy teams who own the full loop from idea to production. You set the bar for craft, give them a vision sharp enough to act on, and create the conditions where ambitious work and fast execution coexist. You raise the floor and push the ceiling.

-

**Prioritise ruthlessly in a competitive market.** This is a fiercely contested space with strong, sometimes free, alternatives. You decide what *not* to do as clearly as what to do, and you grow the product through focus, not by trying to do everything.

-

**Push the team on experimentation.** You treat experimentation as an engine of product decisions, not a nice-to-have. A/B tests, bandits, and how fast the team can run, read, and act on experiments are first-class metrics you own and push relentlessly.

-

**Be the commercial partner, not the commercial owner.** Your duo partner owns the P&L. Your job is to translate their ambition into a product that can deliver it and to push back clearly when the product path and the commercial ask don't align. You hold the quality bar even when the pressure is to ship faster or cut corners.

-

**Own delivery transparency.** What's in flight, what's at risk, what's shipping and when. If something will be late or descoped, you say so early to your teams, your partner, and upward. No surprises.

# **Your profile:**

-

You've **led product at a high-growth B2C** consumer tech company and delivered results under real commercial pressure. You've owned a multi-team product area, not a single feature stream.

-

You've grown a major product line in a fiercely competitive market and you know how to decide what *not* to do.

-

You optimise for the company's outcome, not your org's size. You've made calls that were right for the user and the business even when they didn't maximise your own product area.

-

You've built something real users love and you can describe exactly why it worked, what metric moved, and what you'd do differently.

-

You've shipped AI products that changed user behaviour. In production, used at scale.

-

You've led people and raised the bar. People who've worked with you got better, and you can name how.

-

You believe experimentation is key to products that win. You're fluent in testing methods (A/B, bandits), you treat experimentation velocity as a metric that matters, and you make calls from evidence rather than opinion.

-

You've built a product vision from scratch and got an organization to follow it because the argument was clear, not because of authority.

-

You've made hard trade-offs visible and held the line when everything felt urgent.

-

You are genuinely AI-native. You use AI in your own practice daily with workflows, coding assistants, real product problems as a way of working.

-

You're fluent in **English and German**, given the primary market and the teams you'll lead.

# **Why Taxfix?**

-

A chance to do meaningful, people-centric work with an international team of passionate professionals.

-

Holistic well-being with free mental health coaching sessions.

-

A monthly allowance to spend on an extensive range of services that you can use and roll over as flexibly as you like.

-

Employee stock options for all employees—because everyone deserves to benefit from the success they help to create.

-

30 annual vacation days and flexible working hours.

-

Work from abroad for up to six weeks every year. Just align with your team, and then enjoy your trip.

-

Plenty of opportunities to socialise as a team. In addition to internal tech meetups, our international team hosts regular get-togethers—virtually and in person when possible.

-

Free tax declaration filing, of course, through the Taxfix app—and internal support for all personal tax-related questions.

-

Have a four-legged friend in your life? We’re happy to have dogs join us in the office.

Excited? So are we. Learn more about [Team Taxfix](https://medium.com/taxfix) on our blog and get a glimpse of our culture.

*At Taxfix, we believe that incredible things happen when you have a wealth of perspectives and experiences. We're proudly committed to equal employment and development opportunities no matter your gender, race, religion, age, sexual orientation, colour, disability, or place of origin. To help mitigate any potential unconscious biases, we ask that you refrain from including your picture, age, or marital status on your CV. Let your experiences speak for themselves.*

Not sure if you meet all the requirements for this role? Please apply anyway. You might bring something special to the team that we hadn't considered previously.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
