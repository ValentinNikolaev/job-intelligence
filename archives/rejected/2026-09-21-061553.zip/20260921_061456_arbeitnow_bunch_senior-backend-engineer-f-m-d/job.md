# (Senior) Backend Engineer (f/m/d)

Posted: 2026-09-21T05:40:06Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

[bunch](https://www.bunch.capital/) is building the backbone of private markets. We are enabling next-gen fund operations with one integrated system that combines secure data infrastructure, AI-powered workflows and expert fund services. If you value ownership, growth through real responsibility, and working with a thoughtful, ambitious team, this role might be for you.

# Your Role

You will be at the core of building the technology that powers bunch. We aim to build something meaningful with high impact, not just write code. We offer you freedom and ownership to build the right solutions and influence the product roadmap.

-

Design and implement robust, scalable, and secure backend services that solve real customer problems

-

Collaborate with your Product Managers, by actively participating in problem discovery and solution creation by leveraging your technical expertise

-

Work closely with other cross-functional teams to ensure a smooth delivery of new features and improvements

-

Maximize your team’s output by enhancing functionality and proactively addressing technical debt as well as actively contributing to improving collaboration and communication

# **About You**

-

To excel as a member of the Product Development team, you should combine a passion for technology with an entrepreneurial mindset and strong problem-solving skills

-

You are a team player with excellent communication skills and a strong work ethic

-

Proficient in backend development with TypeScript or any strongly typed language, SQL databases Nest.js or similar web/dependency management frameworks (e.g., Spring Boot)

-

Strong understanding of system design principles, scalability, and performance tuning

-

5+ years of professional experience building backend systems in fast-paced environments

-

Experience with fintech, highly regulated industries, or document processing is a plus

-

**Note: This position is open to mid-level and senior candidates; we’ll tailor responsibilities and compensation to the right level of experience depending on the outcome of the interview process.**

# **Our tech stack**

We strive to keep our technology stack as simple and efficient as possible.

-

**Frontend & Backend:** TypeScript on both the frontend (Svelte, but moving towards React) and the backend (Node.js with Nest.js)

-

**Database:** MySQL

-

**Infrastructure:** Kubernetes (K8S) on top of AWS

-

**Source Control & CI/CD:** GitHub

-

**Third-Party Applications:**

-

FusionAuth for authentication

-

Retool for low-code internal frontend solutions

-

Twilio and SendGrid for sending SMS and emails

-

Tally for creating custom forms

# **Workplace & Benefits**

-

Customizable benefits package (wellbeing, sport, mobility, food, and more)

-

28 days of vacation, plus 2 company days and local public holidays

-

Remote-flexible hybrid (3 days/week in office)

-

Up to 4 remote calendar weeks a year

-

A great tech and work setup

-

Work with a diverse team of 120+ bunchies from 40+ countries, with leaders who are best-in-class in their domains

# **What your interview journey will look like**

-

**First interview** **with the People team (20 min): **get acquainted with the bunch and to understand if what we’re offering is what you’re searching for

-

**Hiring Manager Interview (60 min):** this conversation with an Engineering Manager will cover product-focused culture and values, including collaboration, ownership, self-awareness, and quality standards.

-

**Technical Interview (60 min)**: this interview in the form of a technical conversation with two engineers will focus on collaborative problem-solving, starting with open-ended questions and progressing to more specific challenges or short algorithm tasks.

-

**Final Round: Meet our CTO (45 min)** to learn about ways of working, vision for bunch, and team culture.

-

**Meet-and-Greet (Optional - 30 min) **to meet a few members of your future cross-functional team.

**About bunch**

bunch is building the operating infrastructure for the next generation of private markets. We combine AI-powered automation with deep regulatory expertise to replace fragmented spreadsheets and manual processes with one integrated platform across the fund lifecycle, purpose-built for private markets heading toward $32 trillion in Assets Under Management.

We've 4x our ARR in 2025, crossed 150 fund managers and 12,000 LPs on the platform, and just closed our $35M Series B in May 2026. We're looking for ambitious people who want real ownership of hard problems, and who care about building infrastructure that actually matters to the people using it.

____

At bunch, we're committed to an inclusive environment where diversity is valued and celebrated. We provide equal opportunities to all qualified applicants.

We process personal data in line with applicable laws (including GDPR). See our[ Privacy Policy](https://www.bunch.capital/privacy-policy) for details on your rights and how to reach us.

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
