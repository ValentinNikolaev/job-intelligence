# Head of Finance

Posted: 2026-09-21T05:40:06Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

[bunch](https://www.bunch.capital/) is building the backbone of private markets. We are enabling next-gen fund operations with one integrated system that combines secure data infrastructure, AI-powered workflows and expert fund services. If you value ownership, growth through real responsibility, and working with a thoughtful, ambitious team, this role might be for you.

We are looking for a Head of Finance to be the most senior finance hire at bunch as we rebuild our finance function from the ground up. bunch has just closed its Series B, is actively acquisitive, runs multiple entities across geographies and is building toward Series C and ultimately an exit. This role owns capital, forecasting, budgeting, investor reporting, M&A finance, and EPR implementation and architects a function that scales from scrappy to exit-grade.

You will own the Finance function at a high-growth, VC-backed fintech at an inflection point, reporting to the General Counsel, working directly with the founders and management team.

**Your role**

-

Own the full budgeting cycle end-to-end — top-down and bottom-up — working with the founders, department heads, and all teams. You'll run monthly variance reviews, drive quarterly budget control processes, challenge and sign off on procurement and vendor requests, and translate business strategy into financial plans with clear KPIs and milestones.

-

Build and maintain a robust cash forecasting model, providing regular management updates on burn rate and runway.

-

Prepare monthly and quarterly updates for board meetings, present financial performance to investors, and field questions on KPIs and progress.

-

Set up the analytical foundations expected of a Series C/D company. You'll own unit economics, cohort analyses, and profitability modelling; centralise Finance as the single source of truth for financial and operational KPIs; drive data quality improvements across Sales, Analytics, and other teams; and support commercial strategy with pricing analysis. You'll also hire to build out this function over time.

-

Lead all financial aspects of equity rounds — modelling, due diligence management, and investor responses. Your first major milestone: get bunch Series C ready.

-

Manage financial due diligence on acquisitions, build M&A models, support target selection, and own Finance's role in post-merger integration. You'll also develop relationships with banks to secure acquisition financing when needed.

-

Own bunch's banking relationships and build a strong network of German and European banking partners. Manage liquidity optimisation strategies and establish treasury policies for the group. Keep other financial risks such as currency risk in mind and develop mitigation strategies as appropriate (e.g. hedging)

-

Scope and lead the implementation of an ERP system across the bunch group.

-

Own existing non-dilutive funding disbursements and lead future applications — including grants and other funding options across our markets.

-

Lead audits from the Finance side, coordinating with external tax advisors and accountants. Act as primary liaison for all external bookkeeping, accounting, and tax advisory relationships — including cost reviews and optimisation.

-

Set the standard for excellence in the team, drive process optimisation and automation, and ensure Finance is a high-performing function that's a genuine driver of bunch's growth.

**About you**

-

6+ years of progressive experience in an in-house finance role (ideally SaaS or VC-backed environment), PE, reputable management or financial consultancy, and/or investment banking, with at least 3+ years in a leadership role

-

Proven experience in VC-backed financing rounds post-Series B

-

Track record of building robust financial models from scratch and comfort working with multi-entity and multi-currency structures

-

Familiarity with accounting, billing, and spend management tools (e.g. DATEV, Stripe, Moss, Spendesk) as well as ERPs (NetSuite, etc.)

-

Proven ownership of forecasting and budgeting cycles, not just supporting them

-

Hands-on now, strategic later as the role grows into a VP level; wants to “do” and build from scratch, not just managing others

-

Combines excellent technical expertise with the versatility, commercial flexibility and presence to be the strategic finance partner for management and represent bunch to investors and external partners — equally comfortable in the boardroom and in the spreadsheet

-

Excellent communication skills, i.e. able to translate complex financial data into clear narratives for non-finance stakeholders

-

High levels of proactivity and solutions-orientedness

-

Fund industry or fintech experience is a plus, not a requirement

-

Comfort with operating with ambiguity and building processes where none or few exist

-

Fluent in English, B2/C1+ German strongly preferred

**Workplace & Benefits**

-

Benefit from working with a diverse mix of talents, unrivalled energy, and team spirit within a culture of drive and ownership

-

Take part in a network of people passionate about investment and work closely with the most interesting players in private markets

-

Flexible hours and a hybrid office setup (3 days/week in office)

-

4 remote calendar weeks/year

-

28 days of vacation, 2 company days, plus local public holidays

-

A competitive compensation package

-

A great tech and work setup with everything you need

**Hiring process**

-

**People Team Interview (30 min)** – Meet us & ensure mutual fit

-

**Deep Dive Interview (45 min)** – Collaboration, ownership, and culture

-

**Case Study (90-120 min) **– Technical skillset evaluation

-

**2-3 Stakeholder Interviews (30 min each)** – Meet the Founders and your most important stakeholders

**About bunch**

bunch is building the operating infrastructure for the next generation of private markets. We combine AI-powered automation with deep regulatory expertise to replace fragmented spreadsheets and manual processes with one integrated platform across the fund lifecycle, purpose-built for private markets heading toward $32 trillion in Assets Under Management.

We've 4x our ARR in 2025, crossed 150 fund managers and 12,000 LPs on the platform, and just closed our $35M Series B in May 2026. We're looking for ambitious people who want real ownership of hard problems, and who care about building infrastructure that actually matters to the people using it.

____

At bunch, we're committed to an inclusive environment where diversity is valued and celebrated. We provide equal opportunities to all qualified applicants.

We process personal data in line with applicable laws (including GDPR). See our[ Privacy Policy](https://www.bunch.capital/privacy-policy) for details on your rights and how to reach us.

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
