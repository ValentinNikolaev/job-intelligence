# Senior Product Designer

Posted: 2026-09-21T05:40:02Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**At Moss, we give finance professionals the power to automate their day-to-day and make forward-thinking decisions.**

**Our culture is what makes that possible: we play to win, we obsess over quality, and we win as One Moss, and it works. Moss closed a €35 million Series C in August 2026, crossing a €1 billion valuation, and became one of Europe's fintech unicorns. Join us for what's next.**

As a Senior Product Designer at Moss, you'll play a key role in defining how finance teams automate their work with the help of agents. This is an exciting time to join and help shape both what and how we solve for our customers' needs with AI.

You'll join an experienced team of 8 product designers based across Berlin, London, Amsterdam, and Warsaw. Curiosity, empathy, and craft are at the core of how we design product at Moss. The team is AI-forward and values growth and learning as much as shipping the best possible experiences for our customers. Moss values design as a strategic lever for growth and customer satisfaction, on par with product and engineering at every stage.

We’re looking for multiple product designers to join us and shape the future of finance and accounting work, as well as the new ways we design that future.

**What you’ll do**

-

Design Moss’ next generation of accounting products where agents and finance professionals work together, ensuring accuracy and trust throughout.

-

Build deep understanding of your problem space alongside peers from product management, engineering, and finance experts. Identify and solve for opportunities that drive Moss' growth across our target markets (Germany, UK, Netherlands).

-

Build with AI to make customer-ready demos the default design artifact, moving fluidly between code and canvas throughout the process.

-

Continuously test assumptions with customers, grounding an iterative design process in understanding of finance professionals' needs.

-

Inspire your team to go the extra mile, taking solutions from useful to delightful.

-

Raise the quality bar for yourself and the design team through jams and crits. Share learnings and contribute to our evolving design context, including our component and skill libraries.

**About you**

-

Experience designing complex products end-to-end, in close collaboration with product and engineering leads.

-

A portfolio that demonstrates product thinking and customer centricity as much as visually strong work.

-

Evaluative research practice spanning planning through synthesis.

-

Demonstrated use of AI in your workflow, and passion for experimenting with the latest tools and workflows.

-

Clear communication. The ability to confidently present and articulate your ideas, and bring cross-functional peers along with strong rationale.

-

Team player. A collaborative, empowering way of working.

In addition, here are the skills and attributes we are looking for:

-

**Expert Crafter:** You are the expert in maintaining design quality, ensuring every solution is both intuitive and simple, pushing for excellence in both visual design and user experience while leveraging the design system as much as possible.

-

**Velocity Driver:** You move quickly and strategically. You make smart, informed decisions to prioritize the most impactful work and move work forward by delivering high-quality designs that balance speed and thoughtfulness.

-

**Customer Champion:** You deeply understand the mindset and motivations of our users, designing with empathy and anticipating needs before they arise. You translate these insights into intuitive, user-centered solutions.

-

**Visionary Strategist:** You craft design strategies that balance long-term vision with short-term impact. Your designs not only solve today’s challenges but set the foundation for future scalability and growth.

-

**Growth-Driven Innovator:** You actively seek and give constructive feedback, always evolving your skill set and mindset. You embrace challenges, leave ego at the door, and focus on continuous improvement for yourself and the team.

**About Moss**

Moss is the Finance AI platform for Europe's mid-sized businesses, giving companies real-time visibility and full control over their spend. By automating card issuing, invoice management and expenses, Moss simplifies financial workflows and frees finance and accounting teams from manual, administrative work.

Founded in Berlin and used by more than 10,000 businesses including Flink, Schufa, n8n and Auto1, Moss has raised €220+ million to date and operates in Germany, the Netherlands, the UK and further EU markets. In August 2026, [Moss closed a €35 million Series C ](https://www.getmoss.com/magazine/moss-series-c?origin-page=en-us%2Fcareers)led by Portage, crossing a €1 billion valuation and becoming one of Europe's newest fintech unicorns. Moss is backed by investors including Valar Ventures, Tiger Global, Global Founders Capital, Cherry Ventures, A-Star.

We're a team of 300+ people from 50+ nationalities across 5 offices in Europe and we hire, reward, and grow people based on [Moss DNA](https://www.linkedin.com/company/moss-finance/life/c2ac8184-5388-4962-ad07-e0bcbfe080f0/?viewAsMember=true): playing to win, obsessing over quality, winning as One Moss. If that's how you want to work, we want to hear from you. - here's **what else to expect:**

-

Top-of-market compensation package, including equity.

-

Our vibrant offices are at the heart of our culture, where in-person time fuels collaboration and connection over weekly breakfasts and Friday demos.

-

Additional benefits include: 20 days “work from abroad”, 600EUR/GBP Learning & Development Budget, and other local benefits.

*Unless stated otherwise, benefits apply to full-time positions (interns and working students receive a tailored package).*

***By applying for the above position, you will confirm that you have reviewed and agreed to our ***[***Data Privacy Policy***](https://www.getmoss.com/privacy-policy)***.***

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
