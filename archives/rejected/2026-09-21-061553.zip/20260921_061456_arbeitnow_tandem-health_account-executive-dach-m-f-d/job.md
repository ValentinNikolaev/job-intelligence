# Account Executive - DACH (m/f/d)

Posted: 2026-09-21T02:40:11Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

# Build something monumental for Healthcare!

At Tandem Health we’re reimagining healthcare by putting clinicians first. Our platform - designed by clinicians, for clinicians - is built on deep insight into real-world pain points, with intuitive medical notes and workflows that truly support patient care.

We’re a fast-scaling health-tech company backed by top investors and expanding globally. We move fast, stay curious, and believe building something that matters starts with an extraordinary team. If you're passionate about impact and innovation, we'd love to meet you!

Every day, physicians across Germany, Austria and Switzerland lose hours to documentation instead of patients. Tandem gives that time back - and clinicians actually use it. That’s rare in health tech, and it changes the way you sell: you’re not convincing people they have a problem, you’re showing them a better way to work.

We’re building the DACH market from the ground up - a real product with real pull, backed to win, and a sales team being built right now. If you want ownership over a market rather than a slice of a machine someone else already built, this is the room to be in.

## About Tandem

Tandem builds AI that gives time back to physicians, therapists and nurses. Our team of clinicians, psychologists and AI engineers builds close to the reality of care - pairing modern technology with medical expertise to cut administrative load and free up time for patients.

-

**200+ people**, founded August 2023

-

**$60M** raised, backed by leading European VCs (Northzone, Kinnevik) and angels from companies like OpenAI

-

Product already live and in daily clinical use across Europe in +5000 healthcare organisations

## About the role

At Tandem Health, we’re building a clinician copilot that gives time back to care teams so clinicians can focus on patients. As an Account Executive m/f/d, you’ll turn thoughtful research and crisp outreach into momentum by opening the right doors, surfacing real problems, and setting up conversations that change how care is delivered. You’ll help define our outbound voice and playbooks with a bias for speed to impact, craft that delights, and radical transparency. You’ll work closely with clinicians and product so every meeting speaks to real workflows and outcomes. As our European footprint expands, this role can grow into leadership as we scale the commercial team.

## What you’ll do

-

Own the **full cycle**: qualify, demo, negotiate, close

-

Run a high throughput of meetings while keeping every conversation consultative, not transactional

-

Present the product to clinicians and decision-makers and translate their documentation pain into a clear reason to act

-

Manage relationships through to a live, happy customer, working closely with your SDR and MedOps

-

Stay engaged in your customer relationships long term, update and upsell them on new developments and features

-

Feed what you hear in the market back to product

-

Represent Tandem at events across the region

## What you bring

-

**3+** of full-cycle B2B sales, selling digital medical products (ideally SaaS) to clinicians in outpatient settings and/or MVZ (chains) - e.g. practice-management/EHR systems, DiGAs, scheduling software, AI imaging, telemedicine

-

A track record of hitting and beating quota - and you can prove it with concrete numbers

-

The consultative, lead-from-the-front selling style described in “How we sell”

-

**Native-level German** and **C1/C2 English**

## Bonus points

-

Previous experience in field sales, door-to-door prospecting, or territory-based commercial roles.

-

Experience selling to healthcare professionals (clinics, private practices, care providers) or working in regulated environments.

-

Experience in digital products, SaaS, or technology that improves professional workflows.

## How we sell (our culture)

We hire salespeople who lead, not ones who wait for a script:

-

You bring a **point of view** - you help a clinician see their documentation burden in a new light, instead of listing features.

-

You **tailor** the message to whoever is across the table: practice owner, chief physician, or administration.

-

You **lead the conversation** and put the hard topics - including price - on the table early, rather than hoping they don’t come up.

-

You are **relentless about results** and back what you say with numbers.

## What we offer

-

Competitive salary, reviewed as you grow, plus stock options

-

30 days of holiday

-

Paid parental leave

-

€1,000 annual health & wellbeing budget, plus mental-health support whenever you need it

-

A real learning budget and internal growth paths - build your career without leaving Tandem

-

Fully AI native company - let our agents do the grunt work

-

Two company off-sites a year, plus a team budget for the things that bring you closer

-

State of the art office in the heart of Munich, your choice of IT equipment

## Location & way of working

DACH-based · Hybrid · Regular working weeks with the wider team in Munich, fully Munich based preferred

## Compensation

Competitive base + uncapped OTE

## Applying

We building a team that reflects the world we want to change, and we welcome applicants of every background. *(m/f/d)*

We adopt a continuous selection process, so please make sure to apply with your CV in English.

# Culture at Tandem

At Tandem, we move fast, think big, and take ownership. We're a high-performing, diverse team with a shared drive to change the future of healthcare - and we’re just getting started.

Our culture is built on action, ambition, and learning. You'll be trusted to take the lead, challenge yourself, and make an impact from day one. We believe real growth happens when you're stretched, supported, and surrounded by smart, passionate teammates who want to win together.

Even though we’re spread across countries, we come together often in Sweden for team meetings, social events, and offsites - blending global reach with real human connection.

We hire for talent, potential, and attitude - valuing different backgrounds and fresh perspectives. Great ideas come from everywhere, and we’re building a team that reflects the world we want to change.

*Tandem handles sensitive patient data and will conduct a background check before hiring any candidate.*

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
