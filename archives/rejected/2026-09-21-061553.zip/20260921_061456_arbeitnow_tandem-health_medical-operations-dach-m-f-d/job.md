# Medical Operations - DACH (m/f/d)

Posted: 2026-09-21T02:40:11Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

# Build something monumental for Healthcare!

At Tandem Health we’re reimagining healthcare by putting clinicians first. Our platform - designed by clinicians, for clinicians - is built on deep insight into real-world pain points, with intuitive medical notes and workflows that truly support patient care.

We’re a fast-scaling health-tech company backed by top investors and expanding globally. We move fast, stay curious, and believe building something that matters starts with an extraordinary team. If you're passionate about impact and innovation, we'd love to meet you!

## About the Role

At Tandem, we're helping clinicians reclaim their time and focus on what matters most: patient care. As part of the Medical Operations team, you'll use your clinical experience and your drive for innovation to power the adoption and evolution of Tandem's clinician co-pilot in healthcare settings across the DACH region.

This is a high-impact, multifaceted role ideal for someone with a clinical background, commercial acumen, and a passion for technology. You’ll act as a bridge between users and internal teams - supporting clinicians, optimizing onboarding, and shaping product development. Whether demoing Tandem to prospects, managing clinical incidents, or refining AI prompts, you’ll play a key role in building the future of healthcare.

## What You Will Do

-

Guide clinicians through onboarding, training, and day-to-day support via tools like Intercom.

-

Ensure clinicians are getting the most out of Tandem, solving problems and gathering feedback for continuous improvement.

-

Build templates and prompts, and contribute to ongoing refinement of Tandem’s AI assistant.

-

Run live product demos for prospective clients and support commercial efforts.

-

Log and manage clinical safety incidents and optimise internal operations to scale safely.

-

Work closely with product, engineering, and commercial teams to ensure smooth rollout and workflow integration.

-

Represent Tandem at conferences, events, and workshops, sharing our vision with clinicians and stakeholders.

##
What You Bring

-

Clinical experience in a healthcare setting (e.g. general practice, hospital ) post studies

-

Some experience in consulting, corporate, or startup environments.

-

A passion for technology, AI, and its potential to transform healthcare.

-

Excellent communication and collaboration skills - comfortable working with clinicians, engineers, and commercial teams.

-

Native in German and fluent in English, with excellent communication skills.

-

Strong organisational skills and a process-driven mindset.

-

A strong sense of ownership and initiative coupled with a proactive and curious approach

-

Willingness to work flexibly, travel as needed, and step up during critical moments.

## Bonus Points

-

Familiarity with prompting and large language models (LLMs).

-

Experience working in a healthtech or SaaS company.

-

Exposure to regulatory standards in DACH or EU (e.g. clinical safety, digital health compliance).

-

Experience running implementation projects or customer-facing rollouts.

##
Location

We believe the best ideas happen when we’re together. This is a full-time role based in our Munich office where you will work primarily in order to collaborate, connect, and build our culture. Travel is expected locally to meet customers, and regular trips to Stockholm to meet the full team are also a requirement.

## How to Apply

We adopt a continuous selection process, so please make sure to apply with your CV in English.

Our interview process consists of 4 stages:

-

Screening interview with Talent Acquisition

-

Follow up task/case interview with some of our Medical Operations team members

-

Interview with our Country Manager in DACH

-

Working Day - Join us in the Munich office for a day to experience our culture firsthand, collaborate with our team, and see how you work in action.

*By submitting your application, you consent to the processing of your personal data for recruitment purposes in accordance with our privacy policy.*

# Culture at Tandem

At Tandem, we move fast, think big, and take ownership. We're a high-performing, diverse team with a shared drive to change the future of healthcare - and we’re just getting started.

Our culture is built on action, ambition, and learning. You'll be trusted to take the lead, challenge yourself, and make an impact from day one. We believe real growth happens when you're stretched, supported, and surrounded by smart, passionate teammates who want to win together.

Even though we’re spread across countries, we come together often in Sweden for team meetings, social events, and offsites - blending global reach with real human connection.

We hire for talent, potential, and attitude - valuing different backgrounds and fresh perspectives. Great ideas come from everywhere, and we’re building a team that reflects the world we want to change.

*Tandem handles sensitive patient data and will conduct a background check before hiring any candidate.*

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
