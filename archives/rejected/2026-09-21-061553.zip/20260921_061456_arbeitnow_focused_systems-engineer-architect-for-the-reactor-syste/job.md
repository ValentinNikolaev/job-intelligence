# Systems Engineer / Architect for the Reactor System (f/m/d)

Posted: 2026-09-21T05:40:08Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**About Focused Energy**

Focused Energy is building the future of clean energy through laser-driven inertial fusion. Backed by our $240M Series A - the largest fully secured Series A in the global fusion industry we are scaling rapidly across multiple geographies.

Based in Germany and the US, we have brought together the top scientific and engineering minds using proven technologies to unlock fusion power at commercial scale. Focused Energy is working to realize game-changing scientific innovation that promises to deliver a clean, sustainable and abundant source of power globally.

**Your Role**

As Systems Engineer / Architect for the Reactor System, you will lead the architecture, integrated design, analysis, and development of the fusion island across the full engineering lifecycle — from concept and preliminary design through detailed design, commissioning support, and operations readiness. Working at the interface of multiple engineering disciplines, you will ensure that plant systems are safe, reliable, fully integrated, and compliant with regulatory requirements. You will oversee reactor and fusion island activities with a focus on technical interdependencies, alignment with key design and construction objectives, and delivery against major project milestones. A core responsibility of the role is to ensure that the final plant design is coherent, safe, and licensable.

**What You'll Do**

-

Lead, support and drive the systems engineering process including the fusion island and the fuel cycle.

-

Develop, enforce and maintain system architecture, design descriptions, design basis documents, requirements, and interface control documents.

-

Baseline definition and maintenance.

-

Identify and promote system-level trade studies and design option analyses to optimize performance, safety, and cost.

-

Ensure proper integration of all disciplines into a coherent plant design.

-

Apply safety principles including defense-in-depth, single failure criterion, and diversity and redundancy requirements.

-

Participate in design review meetings, safety review committees, and independent verification and validation (IV&V) activities.

**Who You Are**

-

Degree in engineering. M.Sc. or Ph.D. in engineering would be nice to have.

-

Minimum of 5 years of experience in systems engineering.

-

Experience with requirements engineering.

-

Demonstrated ability to break down complex systems into manageable pieces.

-

Capability to perform content-based multifaceted trade-offs/balancing within the triple constraint framework.

-

Instinctive ability to challenge constructively.

-

Nuclear plant systems design.

-

Systems engineering methodologies.

-

Multidisciplinary integration.

-

Model-Based Systems Engineering.

-

Familiarity with CAD/plant design tools.

## **Nice-to-haves**

-

Experience in the nuclear industry or a comparable high-integrity safety environment.

-

Demonstrated knowledge of nuclear plant systems design and safety analysis principles.

-

Familiarity with Model-Based Systems Engineering (MBSE) and tools such as SysML or Cameo Systems Modeler.

-

Experience with Jira and Confluence, RAMI analysis, Quality Assurance, Licensing processes.

**What We Offer**

-

Innovative Technology & Mission: Be part of a cutting-edge company working on groundbreaking research in clean energy and scientific discovery.

-

Career Development: We invest in our people. This is an opportunity to join an early, growing company at the forefront of new technology, where you’ll have the opportunity to develop and grow your career.

-

Collaborative Culture: Work with great people in a dynamic, international environment with top-tier scientists, engineers and professionals passionate about solving global challenges.

-

Ownership: Take ownership from day 1 and drive impact by making decisions, solving challenges and shaping the future of our company.

-

Your Success is our Success: We offer a competitive salary and company ownership in the form of stock options, giving you a direct stake in our success and ownership in what we build together.

-

Vacation Days: We support your work-life-balance by granting you 30 days of vacation per year.

-

Snacks and Drinks: Our office fridges are never empty. Enjoy our healthy snacks and drinks. Our Darmstadt office even offers a canteen with delicious lunch options daily.

-

Retirement Plan: If you decide for a private pension plan, we will finance 20% on top of your monthly contributions, plus loyalty incentives.

-

Equipment: We offer state-of-the-art Windows or Apple Laptops. In addition, you will receive a keyboard, mouse and headset so you are fully equipped from day 1.

-

Events: We organize regular events to foster team bonding, encourage collaboration, and build a strong, supportive company culture. Connect with colleagues across departments, share ideas, and have fun together, both in and outside of the workplace.

-

Mobility with NAVIT: We partner with NAVIT to support your flexible commuting needs—whether it’s a public transportation ticket, taxi rides or car-sharing you choose what fits your lifestyle.

Focused Energy is an equal opportunity employer committed to creating an inclusive environment. Qualified applicants will receive consideration for employment without regard to race, color, religion, sex, sexual orientation, gender perception or identity, national origin, age, marital status, protected veteran status, or disability status.

Pursuant to the San Francisco Fair Chance Ordinance, Focused Energy will consider for employment qualified applicants with arrest and conviction records.

Compensation offered will be determined by factors such as location, level, job-related knowledge, skills, and experience. Certain roles may be eligible for incentive compensation, equity, benefits.

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
