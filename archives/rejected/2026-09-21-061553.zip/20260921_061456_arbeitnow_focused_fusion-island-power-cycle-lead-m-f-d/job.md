# Fusion Island Power Cycle Lead (m/f/d)

Posted: 2026-09-21T05:40:08Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

## **About Focused Energy**

Focused Energy is an international deep-tech company based in Germany and the US, working to commercialize laser-driven nuclear fusion. Our mission is to provide clean, safe, and virtually unlimited energy to the world. We are rapidly scaling and looking for talented individuals who thrive in building clarity and structure within fast-growing environments.

**Role Overview:**
As the **Fusion Island Power Cycle Lead – Reactor**, you will lead the design and development of the Fusion Island power cycle, including the cooling system, thermodynamic cycle, and primary heat exchanger. You will oversee the system from concept through detailed design, licensing, construction, and commissioning, while ensuring safe, efficient, and integrated solutions across the reactor plant. This is a key technical leadership role requiring deep engineering expertise and the ability to lead multidisciplinary teams and complex design decisions.

**Key Responsibilities:**

-

End-to-end accountability for the fuel cycle power cycle design.

-

Technical Leadership.

-

Define and govern the overall power cycle design architecture, including configuration, major design parameters, and fundamental safety approach.

-

Resolve complex, cross-cutting technical issues that cannot be resolved at the engineer or discipline level.

-

Write key engineering deliverables including system design descriptions, design basis documents, interface control documents, and safety analysis inputs.

-

Lead a multidisciplinary team.

-

Report design status, risks, and issues clearly and regularly to the Fusion Island Group Leader.

-

Manage design change control processes to maintain schedule and cost discipline while preserving design integrity.

**Required Skills & Experience**

-

M. Sc. in nuclear engineering or in aerospace engineering.

-

Experience in thermal-hydraulics.

-

Advanced Experience specifically in CFD.

-

Minimum of 5 years of experience.

-

Minimum 2 years of experience leading multidisciplinary technical teams.

-

Deep knowledge of fluid dynamics, safety analyses principles, and design basis development.

-

Knowledge of nuclear reactor physics.

-

Advanced Fusion Reactor knowledge is an advantage.

-

Fusion is an advantage.

-

Mastery of CFD.

-

Understanding thermodynamic cycles, thermal-hydraulics, mechanical analyses and I&C.

-

Manage requirements.

-

RAMI, licensing, documentation and control, project scheduling.

Focused Energy is an equal opportunity employer committed to creating an inclusive environment. Qualified applicants will receive consideration for employment without regard to race, color, religion, sex, sexual orientation, gender perception or identity, national origin, age, marital status, protected veteran status, or disability status.

Pursuant to the San Francisco Fair Chance Ordinance, Focused Energy will consider for employment qualified applicants with arrest and conviction records.

Compensation offered will be determined by factors such as location, level, job-related knowledge, skills, and experience. Certain roles may be eligible for incentive compensation, equity, benefits.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
