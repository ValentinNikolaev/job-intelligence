# Product Owner - Agentic

Posted: 2026-09-21T05:40:03Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**About Us**

Hawk is the leading provider of AI-supported anti-money laundering and fraud detection technology. Banks and payment providers globally are using Hawk’s powerful combination of traditional rules and explainable AI to improve the effectiveness of their AML compliance and fraud prevention by identifying more crime while maximizing efficiency by reducing false positives. With our solution, we are playing a vital role in the global fight against Money Laundering, Fraud, or the financing of terrorism. We offer a culture of mutual trust, support and passion – while providing individuals with opportunities to grow professionally and make a difference in the world.

## **Your Mission**

As Senior Product Owner for our Agentic Team, your mission is to own the end-to-end roadmap for Hawk's suite of agentic products — spanning investigation, customer due diligence, regulatory reporting, and the core platform capabilities that support them. This is the hub for agentic development at Hawk today, and the role carries genuine responsibility for setting the standard for how (semi-)autonomous AI is built and governed in a regulated, high-stakes environment — where a wrong answer can mean a missed financial crime or a false accusation. Product strategy and vision are shaped in close alignment with leadership and stakeholders across adjacent product teams. The role requires the ability to articulate not only what these products do, but why they are built the way they are — and the commercial rationale for why customers should invest in them.

## **Key Responsibilities**

-

Own the agentic roadmap end-to-end — from backlog prioritization and change/feature request triage through in-year roadmap execution — and be the final point of accountability for what actually ships.

-

Shape product vision and multi-year strategy for the agentic line in close alignment with leadership and key stakeholders across the business. As the senior member of this team, this role carries more forward-looking, strategic weight than a typical PO — helping set direction, not just executing against it.

-

Treat commercial ownership as core to the job, not adjacent to it: pricing, packaging, and CARR/revenue framing sit as close to this role as backlog grooming does.

-

Be the face of the agentic product externally where it matters — representing the roadmap in customer advisory boards, competitive reviews, analyst conversations, and key/enterprise deal support.

-

Act as the connective hub between the agentic team and adjacent screening, fraud, and KYC product teams, ensuring agentic capabilities integrate cleanly instead of bolting on.

-

Keep the product legible to everyone who needs it: own documentation, product briefings, and the product newsletter, the artifacts that let engineering, sales, and customers understand what's being built and why.

-

Run tight, agile delivery day-to-day with development and data science, keeping planning honest and timely without turning process into ceremony.

## **Your Profile**

-

3–5 years as a Product Owner or Product Manager, and 3–5 years in the financial industry — ideally with direct exposure to Anti-Financial Crime (AML, fraud, sanctions screening, KYC/CDD). We're open on the exact mix; what matters is that both sides are real, not adjacent.

-

Demonstrable, hands-on experience building agentic products in a regulated environment, including familiarity with explainability, safety, accuracy monitoring, and bias considerations.

-

Strong product operations instincts in a fast-moving environment: you run tight, agile processes without turning them into ceremony, adapt quickly when the ground shifts, and keep planning solid instead of firefighting.

-

A sharp, decisive prioritizer with a genuine quality bar: you slice, scope, and rescope work under pressure, defend that scope when it's challenged, and know the difference between shipping fast and shipping sloppy — you don't trade one for the other without a reason.

-

Commercial literacy as a working skill, not an afterthought. You think about pricing and packaging with the same seriousness you bring to feature scoping, because building the right thing and selling the right thing are two different jobs — and both are yours.

-

A progressive, clear-thinking communicator. You have a real point of view on where agentic AI in financial crime is heading, you can defend it, and you can also explain the "how" and "what" when the room needs it — not just the vision.

-

Genuinely curious about the agentic AI landscape as it evolves. You bring that outside perspective back into the product, translating what's newly possible into concrete roadmap ideas rather than chasing hype for its own sake.

-

Genuinely customer-focused and stakeholder-minded: you engage directly with customers and treat their input — including complaints — as valuable signal rather than noise, and you give the same weight to input from engineering and other internal stakeholders.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
