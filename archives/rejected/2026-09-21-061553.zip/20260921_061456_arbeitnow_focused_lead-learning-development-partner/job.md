# Lead Learning & Development Partner

Posted: 2026-09-21T05:40:08Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

# **About Focused Energy**

Focused Energy is an international deep-tech company based in Germany and the US, working to commercialize laser-driven nuclear fusion. Our mission is to provide clean, safe, and virtually unlimited energy to the world. We are rapidly scaling and looking for talented individuals who thrive in building clarity and structure within fast-growing environments.

# About The Role

As our Lead Learning & Development Partner, you'll be the first dedicated L&D hire at Focused Energy and will have the opportunity to build the function from the ground up. This is a build from zero, sequenced for impact rather than a catalogue of offerings. You'll own manager development, a shared picture of the skills the organization has and needs, the learning infrastructure that makes learning findable and current, successor readiness for the roles that matter most, and the knowledge management work that keeps technical and scientific expertise from leaving with the person who holds it.

You'll work closely with People Business Partners, functional leads, People Operations, and the Strategic People Projects Partner, and you'll partner with subject matter experts across the organization as co-authors of the learning that translates deep technical and scientific knowledge into something usable by the people who need it.

This is a highly hands on role. We're looking for someone who brings a strong point of view, can operate independently, and is excited to determine what great learning looks like at Focused Energy, and then make it happen.

# **WHAT YOU'LL DO**

-

Build and own the L&D function at Focused Energy, from diagnosing organizational needs through designing, delivering, and continuously improving learning programs.

-

Design and run manager development: frameworks, content, cohorts, and ongoing support for people managers at every level.

-

Own the skill map: the critical skills per function and level, where Focused Energy stands today and where the gaps are, kept current together with functional leads.

-

Design skill development: learning paths that close those gaps, spanning technical and scientific depth as well as leadership, built with subject matter experts as co-authors rather than external content alone.

-

Own succession planning for critical roles: successor pipelines, readiness reviewed together with People Business Partners and the VP People, and the development plans that follow from that review.

-

Build the learning infrastructure, including platform selection, setup, and content that stays findable and current.

-

Own the capability track of onboarding, so new joiners understand how Focused Energy works within their first 30 days, in partnership with People Operations, which keeps the administrative side of onboarding.

-

Own knowledge management: capturing technical and scientific expertise so it doesn't leave the organization when the person who holds it does.

-

Use feedback, data, and observation to evaluate learning effectiveness, and be willing to stop investing in programs that aren't creating meaningful impact.

-

Partner with People Business Partners on the parts of succession and skills work that draw on the performance picture they hold, and with the Enablement & Analytics team so skill and succession data live in the People reporting layer.

-

Partner with the Strategic People Projects Partner on leadership program builds that run as joint projects.

-

Bring recommendations and a clear point of view on L&D priorities, sequencing, program design, and infrastructure rather than waiting for direction.

# **WHAT YOU BRING**

-

Several years of experience in Learning & Development, organizational development, leadership development, instructional design, or a closely related field.

-

Strong knowledge of adult learning principles and instructional design, with the ability to translate those principles into practical, engaging learning experiences.

-

Experience designing and delivering manager and/or leadership development programs.

-

Experience building skill frameworks or competency models, and using skills data to inform development and workforce planning conversations.

-

Experience with succession planning, including building successor pipelines for critical roles and the development plans that support readiness.

-

Experience building or improving learning infrastructure, ideally including selecting, implementing, or managing a Learning Management System or equivalent platform.

-

Experience with knowledge management, documentation, and practices that capture and transfer critical expertise.

-

Strong communication skills and the ability to translate complex or technical information into accessible learning formats without losing accuracy.

-

A highly independent, hands on approach. You're comfortable building something from scratch, making decisions with imperfect information, and taking ownership for outcomes.

-

Strong stakeholder management and collaboration skills, with the ability to build trust with executives, managers, technical experts, and employees across different functions.

-

A data informed and iterative mindset: you use feedback and evidence to understand what is working, improve it, and change course when it isn't.

-

Experience working in a deep tech, scientific, engineering, or otherwise highly technical environment is a strong advantage.

# **Why work with Us?**

-

Innovative Technology & Mission: Be part of a cutting-edge company working on groundbreaking research in clean energy and scientific discovery.

-

Career Development: We invest in our people. This is an opportunity to join an early, growing company at the forefront of new technology, where you’ll have the opportunity to develop and grow your career.

-

Collaborative Culture: Work with great people in a dynamic, international environment with top-tier scientists, engineers, and professionals passionate about solving global challenges.

-

Ownership: Take ownership from day 1 and drive impact by making decisions, solving challenges, and shaping the future of our company.

-

Your Success is our Success: We offer a competitive salary and company ownership in the form of stock options, giving you a direct stake in our success and ownership in what we build together.

-

Vacation Days: We support your work-life balance by granting you 30 days of vacation per year.

-

Flexibility: Work should fit around your life, not the other way around. We offer the ability to work from our office, but some flexibility to work from home as well.

-

Snacks and Drinks: Our office fridges are never empty. Enjoy our healthy snacks and drinks. Our Darmstadt office even offers a canteen with delicious lunch options daily.

-

Retirement Plan: If you decide on a private pension plan, we will finance 20% on top of your monthly contributions, plus loyalty incentives.

-

Events: We organize regular events to foster team bonding, encourage collaboration, and build a strong, supportive company culture. Connect with colleagues across departments, share ideas, and have fun together, both in and outside of the workplace.

Focused Energy is an equal opportunity employer committed to creating an inclusive environment. Qualified applicants will receive consideration for employment without regard to race, color, religion, sex, sexual orientation, gender perception or identity, national origin, age, marital status, protected veteran status, or disability status.

Pursuant to the San Francisco Fair Chance Ordinance, Focused Energy will consider for employment qualified applicants with arrest and conviction records.

Compensation offered will be determined by factors such as location, level, job-related knowledge, skills, and experience. Certain roles may be eligible for incentive compensation, equity, benefits.

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
