# Account Executive - ElevenCreative - Germany

Posted: 2026-09-21T05:40:07Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

## About ElevenLabs

ElevenLabs is an AI research and product company transforming how we interact with technology.

We launched in January 2023 with the first human-like AI voice model. Today, we serve millions of users and thousands of businesses - from fast-growing startups to large enterprises like Deutsche Telekom and Meta. Our investors are some of the world's most prominent, including Andreessen Horowitz, ICONIQ Growth and Sequoia. We've raised $781M in funding and our last valuation was $11B - multiples of 11, always.

We have expanded from voice into three main platforms:

-

ElevenAgents enables businesses to deliver seamless and intelligent customer experiences, with the integrations, testing, monitoring, and reliability necessary to deploy voice and chat agents at scale.

-

ElevenCreative empowers creators and marketers to generate and edit speech, music, image, and video across 70+ languages.

-

ElevenAPI gives developers access to our leading AI audio foundational models.

Everything we do is the result of the creativity and commitment of our team - builders doing the best work of their lives. We are researchers, engineers, and operators. IOI medalists and ex-founders. If you want to work hard and create lasting positive impact, we want to hear from you.

## How we work

-

**High-velocity: **Rapid experimentation, lean autonomous teams, and minimal bureaucracy.

-

**Impact not job titles: **We don’t have job titles. Instead, it’s about the impact you have. No task is above or beneath you.

-

**AI first:** We use AI to move faster with higher-quality results. We do this across the whole company—from engineering to growth to operations.

-

**Excellence everywhere: **Everything we do should match the quality of our AI models.

-

**Global team: **We prioritize your talent, not your location.

## What we offer

-

**Innovative culture:** You’ll be part of a generational opportunity to define the trajectory of AI, surrounded by a team pushing the boundaries of what’s possible.

-

**Growth paths: **Joining ElevenLabs means joining a dynamic team with countless opportunities to drive impact - beyond your immediate role and responsibilities.

-

**Learning & development**: ElevenLabs proactively supports professional development through an annual discretionary stipend.

-

**Social travel**: We also provide an annual discretionary stipend to meet up with colleagues each year, however you choose.

-

**Annual company offsite: **Each year, we bring the entire team together in a new location - past offsites have included Croatia and Italy.

-

**Co-working**: If you’re not located near one of our main hubs, we offer a monthly co-working stipend.

## **About the role**

You will own the ElevenCreative enterprise sales motion across the DACH region, building pipeline and closing deals with enterprise creative and marketing teams. DACH has one of the strongest existing enterprise footprints for ElevenLabs, with meaningful ARR, proven deal velocity, and growing creative demand - this is a market where we are accelerating, not experimenting.

ElevenCreative is our AI creative platform - the place where enterprise creative and marketing teams generate and edit speech, image, video, and music using the best AI models available. You will sell the full ElevenCreative suite alongside adjacent capabilities like dubbing, Flows, and Studio to enterprise buyers who are looking to modernize how they produce content at scale.

This is a green-field role. You will define the playbook, build the pipeline, and close the deals - working cross-functionally with product, marketing, solutions, and customer success.

## **In this role you will**

-

Build and manage a growing portfolio of enterprise accounts to drive ElevenCreative revenue in your territory, identifying new business opportunities where AI creative tools can transform how teams produce content

-

Lead consultative, multi-stakeholder sales cycles, building compelling business cases that translate AI creative capabilities into measurable business value for senior executives and economic buyers

-

Develop and execute territory and account strategies from scratch, including target account identification, outbound sequencing, event strategy, and pipeline building

-

Develop a deep understanding of the AI creative landscape - customer use cases, competitive dynamics, and emerging trends - particularly as they apply to media, automotive, consumer goods, publishing, or advertising

-

Partner with product, marketing, solutions engineering, and customer success to ensure smooth onboarding, deployment, and expansion of accounts

-

Serve as a trusted advisor to enterprise creative and marketing leaders, educating them on how AI is changing content production and where ElevenCreative fits in their stack

-

Represent ElevenCreative at industry events, conferences, and client meetings in your territory

## **Who you are**

We are looking for someone who combines enterprise sales instincts with genuine curiosity about how creative and marketing teams produce content at scale. You will thrive in this role if you:

-

Have 5+ years of quota-carrying sales experience selling technology, SaaS, or AI products to enterprise buyers, ideally with exposure to the creative tools, digital media, or content production space

-

Have deep familiarity with the AI creative tools or digital media landscape - you understand how enterprise creative and marketing teams evaluate, adopt, and deploy new tooling, and you know the industry well enough to build credibility with buyers quickly

-

Have proven success navigating complex, multi-stakeholder enterprise sales cycles across business, IT, legal, and procurement

-

Can translate technically complex AI capabilities - voice synthesis, image and video generation, dubbing, music creation - into clear business value for non-technical decision makers

-

Are comfortable building pipeline from scratch in a new market or territory, including outbound, events, and account-based strategies

-

Have strong executive presence and the ability to build relationships at the VP and C-suite level

-

Native or full professional proficiency in German; strong English for internal collaboration

-

Thrive in high-growth, fast-moving environments where the scope expands faster than anyone can fully prepare for, and treat that as a feature rather than a problem

## **Bonus**

-

Experience selling creative, design, media production, or content platform tools to enterprise buyers

-

Familiarity with AI or generative AI products and how enterprise buyers evaluate them

-

Experience with localization, dubbing, or audio and video production workflows and the buyers who own them

-

Deep knowledge of the media, automotive, consumer goods, publishing, or advertising verticals and the enterprise buying dynamics within them

**Location**

This role is remote across Germany but Munich is preferred.

#LI-remote

We are an equal opportunity employer and do not discriminate on the basis of race, religion, national origin, gender, sexual orientation, age, veteran status, disability or other legally protected statuses.

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
