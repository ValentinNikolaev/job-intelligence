# Senior Scientist, LPI Modeling & Beam Smoothing (f/m/d)

Posted: 2026-09-21T05:40:08Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Focused Energy is building the future of clean energy through laser-driven inertial fusion. Backed by our $240M Series A — the largest fully secured Series A in the global fusion industry — we are scaling rapidly across multiple geographies.

Based in Germany and the US, we have brought together the top scientific and engineering minds using proven technologies to unlock fusion power at commercial scale. Focused Energy is working to realize game-changing scientific innovation that promises to deliver a clean, sustainable and abundant source of power globally.

## **Your Role**

Focused Energy is looking for a Senior Scientist to bring deep theoretical and simulation expertise in laser-plasma interaction (LPI) modeling, beam smoothing, and laser-target coupling to our Science team. This is a role that spans both the laser system and target physics sides of the house, translating laser system capabilities into target physics requirements, and target physics needs into laser beam requirements, an end-to-end view that is critical to refining our roadmap forward.

You will act as a scientific anchor for the beam smoothing project and a trusted theoretical resource across several teams: supporting implementation work, providing simulation and theory support for LPI research, and contributing to the design and interpretation of experiments. Your work will directly shape beam requirements (picket, drive, beam port design) and the physics roadmap that underpins our path to fusion energy at commercial scale.

## **What You'll Do**

-

Provide theoretical and simulation support on the beam smoothing project.

-

Coordinate laser beam requirements, including picket and drive beam design and beam port design.

-

Support the roadmap, partnering with the diagnostics team and leading physics efforts.

-

Provide theoretical support for implementation in the DUED code.

-

Provide theoretical support for LPI science across LPI experiments and simulations.

-

Partner closely with the beam smoothing team, the laser and science teams working on beam requirements, the target design team, and the target physics team on LPI risk mitigation and imprint/hydrodynamic instabilities.

## **Who You Are**

### **Must-haves**

-

PhD in plasma physics or an equivalent field.

-

10+ years of post-doc or staff scientist experience.

-

Strong theoretical and simulation knowledge of beam smoothing techniques.

-

Strong theoretical knowledge of LPI (CBET, SBS, SRS, and/or TPD) and experience with PIC/fluid simulations.

-

Knowledge of High-Performance Computing (HPC).

-

Excellent programming skills for HPC (OpenMP/MPI) in C++ and/or Python or an equivalent language.

-

Strong mathematical background, including linear algebra, dynamical systems, partial differential equations, stochastic differential equations, and numerical modeling.

-

Strong background in laser fusion science.

-

Excellent communication skills and a strong collaborator across technical teams.

-

High capability in prioritization, problem-solving, and adaptability.

### **Nice-to-haves**

-

Experience designing or interpreting LPI or rad-hydro experiments.

-

Knowledge of imprint requirements.

-

Knowledge of rad-hydro physics and simulations.

-

Knowledge of laser science and optics.

-

Experience leading a team.

## **What We Offer**

-

Innovative Technology & Mission: Be part of a cutting-edge company working on groundbreaking research in clean energy and scientific discovery.

-

Career Development: We invest in our people. This is an opportunity to join an early, growing company at the forefront of new technology, where you'll have the opportunity to develop and grow your career.

-

Collaborative Culture: Work with great people in a dynamic, international environment with top-tier scientists, engineers and professionals passionate about solving global challenges.

-

Ownership: Take ownership from day 1 and drive impact by making decisions, solving challenges and shaping the future of our company.

-

Your Success is our Success: We offer a competitive salary and company ownership in the form of stock options, giving you a direct stake in our success and ownership in what we build together.

-

Vacation Days: We support your work-life-balance by granting you 30 days of vacation per year.

-

Snacks and Drinks: Our office fridges are never empty. Enjoy our healthy snacks and drinks. Our Darmstadt office even offers a canteen with delicious lunch options daily.

-

Retirement Plan: If you decide for a private pension plan, we will finance 20% on top of your monthly contributions, plus loyalty incentives.

-

Equipment: We offer state-of-the-art Windows or Apple Laptops. In addition, you will receive a keyboard, mouse and headset so you are fully equipped from day 1.

-

Events: We organize regular events to foster team bonding, encourage collaboration, and build a strong, supportive company culture. Connect with colleagues across departments, share ideas, and have fun together, both in and outside of the workplace.

-

Mobility with NAVIT: We partner with NAVIT to support your flexible commuting needs — whether it's a public transportation ticket, taxi rides or car-sharing you choose what fits your lifestyle.

-

Fitness with Wellhub: We care about your health. Get access to a wide range of gyms, fitness studios and wellness services across Europe through our partnership with Wellhub.

Focused Energy is an equal opportunity employer committed to creating an inclusive environment. Qualified applicants will receive consideration for employment without regard to race, color, religion, sex, sexual orientation, gender perception or identity, national origin, age, marital status, protected veteran status, or disability status.

Pursuant to the San Francisco Fair Chance Ordinance, Focused Energy will consider for employment qualified applicants with arrest and conviction records.

Compensation offered will be determined by factors such as location, level, job-related knowledge, skills, and experience. Certain roles may be eligible for incentive compensation, equity, benefits.

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
