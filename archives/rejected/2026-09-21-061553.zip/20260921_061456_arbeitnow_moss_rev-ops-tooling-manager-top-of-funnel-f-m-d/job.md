# Rev Ops Tooling Manager - Top of Funnel (f/m/d)

Posted: 2026-09-21T05:40:02Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**At Moss, we give finance professionals the power to automate their day-to-day and make forward-thinking decisions.**

**Our culture is what makes that possible: we play to win, we obsess over quality, and we win as One Moss, and it works. Moss closed a €35 million Series C in August 2026, crossing a €1 billion valuation, and became one of Europe's fintech unicorns. Join us for what's next.**

This role owns Moss's top of funnel tooling stack: HubSpot, the Salesforce lead and campaign layer, Salesloft and Attention. Much of this stack was built without deep Salesforce expertise, so you will start by diagnosing where lead routing and attribution genuinely break down, then rebuild it into something best in class, including AI driven routing and dynamic nurture.

You will set the roadmap for this domain within Commercial Systems, working closely with Growth, BDR and SDR teams whose pipeline quality depends on the decisions you make, and partnering closely with the Head of GTM Automation. You will report to the Director of Commercial Systems, with weekly check ins against cycle goals rather than close oversight, and no direct reports of your own.

**Your responsibilities**

-

Own and administer the marketing automation stack, currently HubSpot, to support campaign management and email marketing as the backbone of Moss's top of funnel motion

-

Design and maintain the tooling that supports the handoff between multi-channel lead flows across marketing, product and sales into Salesforce, including tools such as Sweep, Calendly and n8n, to ensure the critical lead infrastructure supports the SLAs that BDR and SDR teams work to

-

Administer Salesforce's Lead, Contact and campaign influence layer, diagnosing and fixing gaps in the current routing setup

-

Partner with Growth, BDR, SDR and Partnerships to translate their requirements into system changes, working closely with the Head of GTM Automation's team

-

Run sales productivity tooling such as Attention, including onboarding and offboarding commercial users

-

Monitor system performance, resolve bugs and ship fixes in partnership with engineering

-

Act as the internal and vendor facing subject matter expert for top of funnel tooling, experimenting to keep the stack best in class

**About you**

-

4+ years' experience administering a marketing automation platform (HubSpot or equivalent) and Salesforce, including lead routing and lifecycle management, in a B2B SaaS context

-

Salesforce Certified Administrator

-

Experience with AI productivity tooling such as n8n and Attention

-

Fluent English (native or C2)

-

Experience with lead routing or lifecycle management tooling such as LeanData, RingLead or Chili Piper is a plus

-

Experience working with APIs and engineering teams is a plus

**In addition, here are the skills and attributes we are looking for:**

-

Takes time to understand the problem with business stakeholders before proposing a solution

-

Delivers change consistently, with a track record of measurable impact rather than one-off wins

-

Comfortable diagnosing messy, undocumented systems and defining the target state yourself, rather than working from a pre-defined spec

-

Willing to experiment and test new approaches to keep the stack ahead of what's standard

-

Designs and builds AI-powered workflows or tools in production, with clear evidence of real-world usage and impact

**About Moss**

Moss is the Finance AI platform for Europe's mid-sized businesses, giving companies real-time visibility and full control over their spend. By automating card issuing, invoice management and expenses, Moss simplifies financial workflows and frees finance and accounting teams from manual, administrative work.

Founded in Berlin and used by more than 10,000 businesses including Flink, Schufa, n8n and Auto1, Moss has raised €220+ million to date and operates in Germany, the Netherlands, the UK and further EU markets. In August 2026, [Moss closed a €35 million Series C ](https://www.getmoss.com/magazine/moss-series-c?origin-page=en-us%2Fcareers)led by Portage, crossing a €1 billion valuation and becoming one of Europe's newest fintech unicorns. Moss is backed by investors including Valar Ventures, Tiger Global, Global Founders Capital, Cherry Ventures, A-Star.

We're a team of 300+ people from 50+ nationalities across 5 offices in Europe and we hire, reward, and grow people based on [Moss DNA](https://www.linkedin.com/company/moss-finance/life/c2ac8184-5388-4962-ad07-e0bcbfe080f0/?viewAsMember=true): playing to win, obsessing over quality, winning as One Moss. If that's how you want to work, we want to hear from you. - here's **what else to expect:**

-

Top-of-market compensation package, including equity.

-

Our vibrant offices are at the heart of our culture, where in-person time fuels collaboration and connection over weekly breakfasts and Friday demos.

-

Additional benefits include: 20 days “work from abroad”, 600EUR/GBP Learning & Development Budget, and other local benefits.

*Unless stated otherwise, benefits apply to full-time positions (interns and working students receive a tailored package).*

***By applying for the above position, you will confirm that you have reviewed and agreed to our ***[***Data Privacy Policy***](https://www.getmoss.com/privacy-policy)***.***

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
