# Sales Development Representative - DACH (m/f/d)

Posted: 2026-09-21T02:40:11Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

# Build something monumental for Healthcare!

At Tandem Health we’re reimagining healthcare by putting clinicians first. Our platform - designed by clinicians, for clinicians - is built on deep insight into real-world pain points, with intuitive medical notes and workflows that truly support patient care.

We’re a fast-scaling health-tech company backed by top investors and expanding globally. We move fast, stay curious, and believe building something that matters starts with an extraordinary team. If you're passionate about impact and innovation, we'd love to meet you!

Every day, physicians across Germany, Austria and Switzerland lose hours to documentation instead of patients. Tandem gives that time back - and clinicians actually use it. That’s rare in health tech, and it changes the way you sell: you’re not convincing people they have a problem, you’re showing them a better way to work.

We’re building the DACH market from the ground up - a real product with real pull, backed to win, and a sales team being built right now. If you want ownership over a market rather than a slice of a machine someone else already built, this is the room to be in.

## About Tandem

Tandem builds AI that gives time back to physicians, therapists and nurses. Our team of clinicians, psychologists and AI engineers builds close to the reality of care - pairing modern technology with medical expertise to cut administrative load and free up time for patients.

-

**200+ people**, founded August 2023

-

**$60M** raised, backed by leading European VCs (Northzone, Kinnevik) and angels from companies like OpenAI

-

Product already live and in daily clinical use across Europe in +5000 healthcare organisations

## About the role

As a Sales Development Representative (SDR), you will be responsible for creating new business opportunities by identifying, engaging, and qualifying potential customers across the DACH region. You are the first point of contact between Tandem and prospective healthcare providers and play a critical role in building our commercial pipeline.

You will work closely with Account Executives, Marketing, and Leadership to generate qualified meetings, uncover customer challenges, and help accelerate Tandem’s growth across Germany, Austria, and Switzerland.

This role is ideal for ambitious individuals looking to build a career in SaaS and healthcare technology sales, with a clear pathway into Account Executive, Business Development, or Sales Leadership roles as the company scales.

You are the front of Tandem’s DACH growth engine. Most of our German-speaking pipeline has only ever been touched by email - you’re here to pick up the phone and change that, turning a large, barely-worked pool of clinicians into qualified conversations for our AEs.

## What you’ll do

-

Run high-volume outreach - **phone-first** - across self-serve, inbound and outbound leads

-

Qualify hard against clear criteria: right decision-maker in the room, real documentation pain, readiness to buy - only qualified meetings go into an AE’s calendar

-

Book qualified first meetings for Account Executives and hand them over cleanly

-

Keep the pipeline honest in our CRM (Attio) - accurate notes, clean data, tight follow-up

-

Represent Tandem to clinicians with credibility and energy

## What you bring

-

**1–2 years** in a sales / SDR role, selling digital medical products (ideally SaaS) to clinicians in outpatient settings - e.g. practice-management/EHR systems, DiGAs, scheduling software, AI imaging, telemedicine

-

Strong on the phone: you lead the call and you can take rejection without losing momentum

-

**Drive** - self-motivated and results-driven (this one is non-negotiable)

-

Coachable: you take feedback and improve fast

-

Genuine curiosity about the product and the clinical world it lives in

-

**Native-level German** (customer-facing) and **C1/C2 English** (internal)

## Bonus points

-

Experience in outbound sales, lead generation, cold calling, or appointment setting.

-

Experience working with healthcare providers, medical practices, clinics, or healthcare software.

-

Familiarity with CRM platforms such as HubSpot or Salesforce.

-

Previous experience in SaaS, digital health, medtech, or startup environments.

-

Experience working in a high-growth company with ambitious commercial targets.

## How we sell (our culture)

We hire salespeople who lead, not ones who wait for a script:

-

You bring a **point of view** - you help a clinician see their documentation burden in a new light, instead of listing features.

-

You **tailor** the message to whoever is across the table: practice owner, chief physician, or administration.

-

You **lead the conversation** and put the hard topics - including price - on the table early, rather than hoping they don’t come up.

-

You are **relentless about results** and back what you say with numbers.

## What we offer

-

Competitive salary, reviewed as you grow, plus stock options

-

30 days of holiday

-

Paid parental leave

-

€1,000 annual health & wellbeing budget, plus mental-health support whenever you need it

-

A real learning budget and internal growth paths - build your career without leaving Tandem

-

Fully AI native company - let our agents do the grunt work

-

Two company off-sites a year, plus a team budget for the things that bring you closer

-

State of the art office in the heart of Munich, your choice of IT equipment

## Location & way of working

DACH-based · Hybrid · Regular working weeks with the wider team in Munich, fully Munich based preferred

## Compensation

Competitive base + uncapped OTE

## Applying

We’re building a team that reflects the world we want to change, and we welcome applicants of every background. *(m/f/d)*

We adopt a continuous selection process, so please make sure to apply with your CV in English.

# Culture at Tandem

At Tandem, we move fast, think big, and take ownership. We're a high-performing, diverse team with a shared drive to change the future of healthcare - and we’re just getting started.

Our culture is built on action, ambition, and learning. You'll be trusted to take the lead, challenge yourself, and make an impact from day one. We believe real growth happens when you're stretched, supported, and surrounded by smart, passionate teammates who want to win together.

Even though we’re spread across countries, we come together often in Sweden for team meetings, social events, and offsites - blending global reach with real human connection.

We hire for talent, potential, and attitude - valuing different backgrounds and fresh perspectives. Great ideas come from everywhere, and we’re building a team that reflects the world we want to change.

*Tandem handles sensitive patient data and will conduct a background check before hiring any candidate.*

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
