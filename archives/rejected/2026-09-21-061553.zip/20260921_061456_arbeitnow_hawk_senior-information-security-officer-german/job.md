# (Senior) Information Security Officer (German)

Posted: 2026-09-21T05:40:03Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**About Us**

Hawk is the leading provider of AI-supported anti-money laundering and fraud detection technology. Banks and payment providers globally are using Hawk’s powerful combination of traditional rules and explainable AI to improve the effectiveness of their AML compliance and fraud prevention by identifying more crime while maximizing efficiency by reducing false positives. With our solution, we are playing a vital role in the global fight against Money Laundering, Fraud, or the financing of terrorism. We offer a culture of mutual trust, support and passion – while providing individuals with opportunities to grow professionally and make a difference in the world.

**Your Mission:**

We are seeking a highly skilled and technically strong **(Senior) Information Security Officer** to join Hawk’s Information Security function. This role is critical to maintaining trust with our customers, supporting pre-sales and sales engagements, and ensuring Hawk remains compliant with security standards such as ISO 27001.

You will act as a key technical and communication bridge between customers, auditors, internal teams, and our security tooling landscape. From managing security enquiries and RFPs to strengthening our ISMS and improving endpoint and access security, you will play a vital role in safeguarding Hawk’s platform, data, and operations.

This is an ideal opportunity for someone who combines **excellent communication skills** and **strong security fundamentals**, with the ability to operate confidently with both technical and non-technical stakeholders. **Fluent German** is essential for this role due to regular engagement with German-speaking customers.

**Key Responsibilities:**

**Customer & Pre-Sales Security Support**

-

Respond to security questionnaires, RFPs, and due-diligence requests in collaboration with Sales and Pre-Sales.

-

Participate in customer calls to explain Hawk’s security posture and answer technical, compliance, and infrastructure-related questions.

-

Represent Hawk’s security capabilities clearly and confidently to regulated financial institutions.

**ISMS & Compliance (ISO 27001)**

-

Support the ongoing operation and improvement of Hawk’s ISMS, ensuring alignment with ISO 27001 controls and underlying processes.

-

Assist in internal audits, evidence gathering, and risk assessments.

-

Help maintain certification readiness by driving documentation, process adherence, and corrective actions.

**Platform & 3rd-Party Security Oversight**

-

Monitor the security posture of Hawk’s corporate tools, infrastructure, and integrations.

-

Support vendor assessments and due diligence for security-related tools.

-

Collaborate with Engineering, IT, and InfoSec to strengthen platform and enterprise security baselines.

**Cross-Functional Collaboration & Stakeholder Communication**

-

Work closely with Information Security, IT, Engineering, Sales, Customer Success, and Procurement teams.

-

Translate complex technical and security concepts into clear explanations for both technical and non-technical audiences.

-

Contribute to internal security awareness, documentation, and operational processes.

**Your Profile:**

**Technical Experience & Skills:**

-

5+ years of hands-on experience in Information Security, IT Security, or a related GRC role within a B2B tech or SaaS environment

-

Proven experience operating and improving an ISMS aligned to ISO 27001, including policy development, risk assessments, internal audits, and certification maintenance

-

Working knowledge of additional regulatory and compliance frameworks — SOC 2, DORA, and NIS 2

-

Solid understanding of IT security fundamentals: authentication, endpoint security, encryption, network basics

-

Good technical competence across multiple operating systems (macOS, Windows, Linux)

-

Experience coordinating with external auditors, certification bodies, and regulators

-

Relevant certifications highly desirable (e.g., ISO 27001 Lead Implementer/Auditor, CISSP, CISM, CRISC, CompTIA Security+)

**Communication & Stakeholder Management:**

-

Fluent German and English — mandatory due to regular engagement with German-speaking customers, auditors, and regulators

-

Ability to articulate complex security and compliance topics clearly to diverse audiences (engineers, customers, auditors, leadership)

-

Strong documentation skills with attention to accuracy, consistency, and audit-readiness

**Bonus:**

-

Experience with identity and access management tools (e.g., JumpCloud, Okta), MDM solutions, and enterprise security platforms

-

Exposure to 3rd-party risk management, vendor security assessments, or SaaS security tooling

-

Experience supporting security questionnaires, RFPs, or due-diligence calls with regulated financial customers

-

Familiarity with data protection requirements (GDPR) in a security context

-

A proactive, structured, and collaborative approach with the ability to balance multiple priorities in a fast-paced environment

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
