# Support Analyst (German Speaking)

Posted: 2026-09-21T05:40:03Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**About Us**

Hawk is the leading provider of AI-supported anti-money laundering and fraud detection technology. Banks and payment providers globally are using Hawk’s powerful combination of traditional rules and explainable AI to improve the effectiveness of their AML compliance and fraud prevention by identifying more crime while maximizing efficiency by reducing false positives. With our solution, we are playing a vital role in the global fight against Money Laundering, Fraud, or the financing of terrorism. We offer a culture of mutual trust, support and passion – while providing individuals with opportunities to grow professionally and make a difference in the world.

**Your Mission**
As Support Analyst, you will serve as the frontline technical and functional expert for customers using the Hawk platform, ensuring a seamless user experience. You will provide expert guidance on rule configuration, user management, workflows, and integration troubleshooting via our ticketing system while collaborating with internal teams to resolve complex issues. We are seeking a proactive problem solver, who can communicate effectively with technical and non-technical stakeholders fluently in German and English and ensure high customer satisfaction.

**Your Responsibilities **

-

Provide timely, high-quality support for customers via our ticketing system, assisting with rule configuration, user management, workflow optimization, and integrations.

-

Troubleshoot rule behaviour and configuration issues and investigate why alerts trigger (or don’t) and identifying root causes across data, configuration, and platform behaviour.

-

Diagnose, prioritize, and resolve system errors, collaborating with engineers and product teams to identify root causes and implement fixes.

-

Notify customers of incidents, document root cause analyses in collaboration with engineers, and ensure clear communication throughout the resolution process.

-

Work closely with internal teams to resolve complex issues, escalate critical cases, and relay customer feedback for product improvements.

-

Participate professionally in international video conference calls, providing clear, concise explanations of technical issues and solutions to a diverse customer base.

-

Develop comprehensive documentation for both technical and non-technical users, ensuring clarity in troubleshooting steps, platform functionality, and best practices.

-

Apply your understanding of Fraud Prevention, Compliance, and/or Payments Processing to guide customers effectively in a highly regulated and complex environment.

**Your Profile**

-

3+ years of experience in technical support, application support, or a customer-facing technical role.

-

Bachelor’s degree in Computer Science, Information Technology, Business, or a related field (or equivalent experience).

-

Strong analytical and troubleshooting skills, with the ability to diagnose issues in SaaS applications.

-

Experience working with ticketing systems (e.g., Zendesk, Jira, ServiceNow) and monitoring tools.

-

Ability to explain complex technical concepts to both technical and non-technical users.

-

Familiarity with financial crime prevention, fraud detection, compliance, or payments processing is highly desirable.

-

Strong verbal and written communication skills, particularly in a customer-facing role.

-

Highly organized, able to prioritize tasks effectively in a fast-paced environment.

-

Comfortable participating in international calls across multiple time zones.

-

German and English fluency

**Preferred Qualifications**

-

Experience in AML, Fraud Prevention, or Compliance platforms

-

Familiarity with cloud-based platforms, APIs, and integrations

-

Previous experience in a SaaS, FinTech, or RegTech company

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
