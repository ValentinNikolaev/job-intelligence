# Senior Engineering Project Manager (m/w/d)

Posted: 2026-09-21T05:09:23Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**The Role: What to expect **

Idealworks builds industrial automation as a coordinated system — mobile robots, orchestration software, simulation, and increasingly humanoids and physical AI, working together in real production environments rather than as isolated pilots. Since our founding within BMW Group and our integration into Agile Robots SE, we've grown from a Munich-based robotics team into a global player.

As physical AI and humanoid robotics move from research into industrial deployment, our project landscape is expanding: today's programs span classic mobile robot fleets, next-generation humanoid platforms, and the simulation environments used to develop and validate both. We're looking for a Senior Engineering Project Manager to lead this kind of work end to end - technically credible enough to sit with R&D and hardware/software engineering, and organized enough to keep shareholders, partners, and customers aligned as programs move from concept to production.

**Role Responsibilities: What you will do**

**Project & Program Delivery**

- Manage complex engineering projects across the full lifecycle — from scoping and planning through execution, integration, testing, and handover — spanning both software and hardware workstreams.
- Define and manage project plans, milestones, budgets, and resourcing; monitor schedule, cost, quality, and contractual compliance throughout.
- Identify technical, schedule, and commercial risks early, and drive mitigation and contingency planning across multi-disciplinary teams.
- Plan and coordinate integration and validation phases (e.g., factory and site acceptance testing) across hardware, software, and systems components.

**Cross-Functional & Technical Coordination**

- Act as the connective layer between product management, partner management, solution engineering, software development, hardware development, R&D, innovation management, and operations — ensuring each function's inputs and dependencies are captured and sequenced correctly.
- Work closely with engineering leads on cutting-edge developments in mobile robots, humanoid platforms, simulation tooling, and physical AI to translate technical realities into realistic, defensible project plans.
- Support innovation and R&D initiatives as they mature into deployable projects, helping bridge the gap between exploratory work and production-grade delivery.

**Stakeholder & Partner Management****
**

- Serve as a primary point of contact for a diverse stakeholder landscape, including shareholders, technology and integration partners, and customers, tailoring communication to each audience.
- Prepare and lead steering committee meetings, status reviews, and escalation discussions; ensure decisions are documented and followed through.
- Manage claims, change requests, and contract or scope amendments in coordination with commercial and legal stakeholders.
- Build long-term, trust-based relationships with partners and customers that extend beyond a single project milestone.

**Operational Excellence**

- Track and report on project and portfolio KPIs (schedule adherence, cost/margin, quality, and stakeholder satisfaction) to leadership and shareholders.
- Contribute to continuous improvement of project management methodology, tooling, and best practices across the organization.
- Support resource planning and prioritization across a portfolio of concurrent engineering projects.

**Role Requirements: What you need to succeed**

- At least 5 years of experience in a similar role, or in a technical role such as engineering, software development, product management, program management, project management, or partner management, within the robotics industry or a domain of comparable technical complexity (e.g., autonomous systems, industrial automation, advanced hardware/software integration).
- Demonstrated ability to manage complex, cross-functional engineering projects that combine hardware and software development.
- Strong technical fluency to engage credibly with R&D, software, and hardware engineers on cutting-edge topics in mobile robotics, humanoids, simulation, or physical AI, without needing to be the domain expert yourself.
- A track record of managing external stakeholders e.g. customers, partners, or investors including steering committees, escalations, and commercial discussions.
- Solid grounding in project management fundamentals: planning, budgeting, risk management, and reporting.
- Excellent communication skills, with the ability to translate between technical and business/executive audiences.
- A degree in engineering, computer science, software development, mechatronics, robotics, or a related technical field is a plus.
- Fluency in English required; German is a plus.
- Willingness to travel internationally as project needs require.

**Why idealworks**

- At idealworks, you will find an international working environment and become part of an experienced, open team where mutual trust counts. You will feel at home from the very first second!
- Experience a first-hand start-up feeling and flat hierarchies with varied and responsible tasks that you work on independently.
- Look forward to hybrid working model with 30 vacation days per year and various opportunities to balance your free time, family and job.
- For your commitment to helping us achieve our mission, you will not only be rewarded with appreciation, but also with above-average pay including a bonus scheme and an annual personal development budget.
- We offer exciting corporate benefits, an attractive company pension scheme and regular team events.
- Our modern office is easily accessible by public transport, bike and car and offers numerous catering options for relaxed lunch breaks with your team.
- Driven by our unique corporate culture, the five values "passion for results", "wellbeing", "personal growth", "trust" and "being and acting as one team" determine our daily actions and cooperation.

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
