# Senior Radiation Safety Engineer (f/m/d)

Posted: 2026-09-21T05:40:08Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**About Focused Energy**

At Focused Energy, we are pioneering SourceLight—a breakthrough initiative in compact, laser-driven radiation sources (LDRS) with cutting-edge, high-power laser technology. Our dual-mode LDRS platform enables real-time, non-destructive inspection of a wide range of materials, including complex and shielded items, by combining MeV X-rays and fast neutrons in a single, modular system. This technology addresses critical challenges across nuclear waste analysis, contraband detection, infrastructure inspection, and medical isotope production. With its unique combination of high resolution, material specificity, and deployment flexibility, LDRS creates opportunities beyond the limits of conventional systems. Our cross-disciplinary team brings together experts in laser and plasma physics, engineering, and AI. We are building our first demonstrator facility in Biblis, Germany, and moving rapidly toward market readiness and commercial deployment. Join us at the ground floor of this deep-tech venture and help shape the future of radiation source technology.

**Role Scope & Context**

As a Senior Radiation Safety Engineer, you will ensure that safety is systematically integrated into the design, construction,** **commissioning, and operation of LDRS facilities and systems. The role supports the identification,** **assessment, and mitigation of hazards across complex, high‑energy and high‑risk technologies, enabling** **safe and compliant operations while supporting rapid technical development. Its deliverables will shape** **the installation requirements and procedures for future LDRS products at customer sites.

**Core Responsibilities**

-

Build the radiation safety framework for SourceLight / LDRS, including governance, responsibilities, procedures, documentation, review processes, and escalation paths.

-

Design, specify, and validate radiation shielding for LDRS facilities.

-

Define, implement, and maintain radiation monitoring and dosimetry systems.

-

Own the integration of radiation protection systems with controls and building infrastructure.

-

Own radiation safety documentation and licensing submissions.

-

Conduct or supervise radiation measurements during commissioning and operation.

-

Act as (or support) Radiation Safety Officer, including audits and investigations.

-

Lead radiation safety input into design reviews, commissioning reviews, operational readiness reviews, change processes, and customer deployment concepts.

-

Acts as the functional owner for radiation safety topics within SourceLight / LDRS.

-

Acts as a trusted safety authority across engineering and operations.

-

Communicates radiation risks clearly to technical and non‑technical stakeholders.

-

Demonstrates proactive, solution‑oriented, and collaborative working style.

-

Connects technical depth with operational realism

**Requirements**

-

Strong expertise in radiation protection, shielding, and dosimetry, preferably with pulsed neutrons. Medical or industrial radiation facilities, accelerator-like systems, high-energy physics facilities, X-ray systems, neutron or gamma radiation environments, or comparable regulated technical environments are possible examples of background.

-

Experience with shielding, dose, and activation analyses using Monte Carlo methods (e.g. MCNP, FLUKA, GEANT4, PHITS)

-

Experience with shielding design, dose estimation, radiation monitoring, access control, controlled areas, safety interlocks, commissioning, and operating procedures.

-

Understanding of radiation protection principles, regulatory requirements, documentation standards, and authority-facing communication.

-

Understanding of control systems and safety interlocks.

-

Solid grounding in ALARA principles and radiation measurement techniques.

-

Ability to communicate with regulation authorities in German.

**Personal Skills**

-

Strong analytical capability.

-

Structured working style.

-

Clear written and verbal communication.

**What We Offer**

-

Be part of an innovative, mission-driven team at the forefront of deep-tech

-

Opportunity to shape systems and processes from the ground up

-

Collaborate with world-class researchers, engineers, and scientists

-

Competitive compensation, flexible work arrangements, and career advancement opportunities

-

Play a vital role in launching pioneering technology with real-world impact

Focused Energy is an equal opportunity employer committed to creating an inclusive environment. Qualified applicants will receive consideration for employment without regard to race, color, religion, sex, sexual orientation, gender perception or identity, national origin, age, marital status, protected veteran status, or disability status.

Pursuant to the San Francisco Fair Chance Ordinance, Focused Energy will consider for employment qualified applicants with arrest and conviction records.

Compensation offered will be determined by factors such as location, level, job-related knowledge, skills, and experience. Certain roles may be eligible for incentive compensation, equity, benefits.

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
