# Senior FP&A Analyst – Revenue Analytics & Modeling (d/f/m)

Posted: 2026-09-21T05:40:07Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

## Our story:

Every year millions of people are either filing their taxes in fear or giving up on their tax refund altogether. We're working on fixing that. Our intuitive app enables anyone, regardless of education or background, to file their taxes with newfound confidence.

Spread across Germany, Spain and the UK, the team at Taxfix Group with its brands Taxfix and Steuerbot, is a compassionate group of solution-finders. We speak our minds openly, and with over 400 professionals, including tax experts, developers, and IT security experts, we're rich in ideas and voices. The group has facilitated more than 3.5 billion euros in tax refunds for its customers since its founding in 2016.

## The opportunity:

Taxfix is continuously evolving its business model for scalability in the context of a subscription-driven revenue base. This shapes how we plan, forecast, and measure the business, and it makes revenue planning one of the most interesting places to work in FP&A right now.

As Senior Financial Analyst in the FP&A team, you will take care of the company topline model and help shape a scalable revenue planning landscape. You will report to the Senior Director of FP&A and work closely with Product, Marketing, Monetization, Data, and Accounting, with regular exposure to the Senior Leadership team.

## Your responsibilities:

-

Own the company topline revenue model: design, maintain, and continuously improve it, with clear accountability for forecast accuracy.

-

Lead the redesign of the revenue modeling landscape toward a scalable, and auditable structure with a single source of truth.

-

Build subscription economics into planning: recurring revenue, subscriber growth, retention and churn cohorts.

-

Own scenario and what-if modeling for budgeting, pre-budgeting, and long-range planning, translating business questions into quantified options.

-

Drive alignment of key KPI definitions across Finance, Data, and Accounting, contributing to a single company-wide KPI glossary.

-

Deliver revenue insights and analysis for Board materials and investor reporting.

-

Partner with Product, Marketing, and Monetization on pricing decisions, growth cases, and ROI assessments.

-

Set modeling standards within FP&A and provide technical mentorship to junior analysts.

-

Drive automation of recurring planning and reporting workflows, leveraging planning tools (Pigment) and AI-enabled solutions.

## Your profile:

-

5+ years of experience in FP&A, strategic finance, or a highly analytical role, ideally in a high-growth or subscription-based business; consulting or investment banking backgrounds welcome if combined with hands-on modeling ownership.

-

Proven track of owning mindset of company-level revenue or topline model, not just contributing to one.

-

Deep familiarity with subscription metrics: recurring revenue, cohorts, LTV, churn, retention, and customer acquisition economics, beyond high-level financial KPIs.

-

Demonstrated experience simplifying or rebuilding complex legacy models into scalable structures.

-

Hypothesis-driven mindset: you form a view, test it against data, and defend it with senior stakeholders

-

Excellent communication skills; able to translate stakeholders input into scalable model structures with model output designed for management and Board audiences.

-

Expert in Excel and Google Sheets; experience with planning tools (Pigment a strong plus) and cloud-based finance systems.

-

SQL is a strong plus; Python, R, or BI tools are welcome.

-

Confident with financial statements and accounting principles, able to link revenue drivers to P&L outcomes.

-

Experience mentoring or coaching junior team members is a plus.

## Why Taxfix?

-

A chance to do meaningful, people-centric work with an international team of passionate professionals.

-

Holistic well-being with free mental health coaching sessions.

-

A monthly allowance to spend on an extensive range of services that you can use and roll over as flexibly as you like.

-

Employee stock options for all employees—because everyone deserves to benefit from the success they help to create.

-

30 annual vacation days and flexible working hours.

-

A generous learning budget to support your personal and professional development and guidance from our internal L&D experts.

-

Work from abroad for up to six weeks every year. Just align with your team, and then enjoy your trip.

-

Plenty of opportunities to socialise as a team. In addition to internal meetups, our international team hosts regular get-togethers—virtually and in person when possible.

-

Free tax declaration filing, of course, through the Taxfix app—and internal support for all personal tax-related questions.

-

Have a four-legged friend in your life? We’re happy to have dogs join us in the office.

Excited? So are we. Learn more about [Team Taxfix](https://medium.com/taxfix) on our blog and get a glimpse of our culture.

*At Taxfix, we believe that incredible things happen when you have a wealth of perspectives and experiences. We're proudly committed to equal employment and development opportunities no matter your gender, race, religion, age, sexual orientation, colour, disability, or place of origin. To help mitigate any potential unconscious biases, we ask that you refrain from including your picture, age, or marital status on your CV. Let your experiences speak for themselves.*

Not sure if you meet all the requirements for this role? Please apply anyway. You might bring something special to the team that we hadn't considered previously.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
