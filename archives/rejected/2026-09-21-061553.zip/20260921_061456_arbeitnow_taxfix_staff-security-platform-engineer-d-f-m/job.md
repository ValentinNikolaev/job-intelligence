# Staff Security & Platform Engineer (d/f/m)

Posted: 2026-09-21T05:40:07Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

## Our story:

Every year millions of people are either filing their taxes in fear or giving up on their tax refund altogether. We're working on fixing that. Our intuitive app enables anyone, regardless of education or background, to file their taxes with newfound confidence.

Spread across Germany, Spain and the UK, the team at Taxfix Group with its brands Taxfix and Steuerbot, is a compassionate group of solution-finders. We speak our minds openly, and with over 400 professionals, including tax experts, developers, and IT security experts, we're rich in ideas and voices. The group has facilitated more than 3.5 billion euros in tax refunds for its customers since its founding in 2016.

## **The opportunity**

As our Staff Security & Platform Engineer within the Corporate IT team, you'll sit at the intersection of IT, network security, and internal platform infrastructure. Reporting to our Director of IT, Security & Infrastructure and working closely with our Systems Engineer, Platform Engineering, SRE,Engineering leads, and Legal and Compliance, you'll be an integral part of the team that enables Taxfix's growing agent ecosystem to be secure, compliant, and accessible to all employees. As agentic infrastructure becomes central to how we operate, the attack surface evolves in ways traditional tooling simply wasn't built for — and IT together with you are the team which stays ahead of it. This isn't a gatekeeping role. It's a builder role: you'll design the frameworks, harden the platforms, and create the conditions that enables people at Taxfix to build responsibly.

##
**Your responsibilities**

-

Develop tools, capabilities, and agentic skills that ensure compliance with EU AI Act in GDPR, as well as security standards, enabling people across the organization to ship, integrate and deploy high quality automations and internal tools.

-

Co-design and govern the permissioning framework that defines what agents are allowed to know and access, ensuring no agent retains broader permissions than its job requires.

-

Own MDM, endpoint security, and identity and access management across internal systems, and lead incident response for security events involving agents or internal infrastructure.

-

Work alongside the Systems Engineer to build, harden, and evolve the agentic platform layer — including secure sandboxes, credential vaults, and CI/CD pipelines with embedded security checks — and define internal platform standards that make the secure path the default path.

-

Design and run adversarial testing exercises against agent deployments — covering prompt injection, privilege escalation, and data exfiltration via reasoning chains — and maintain a growing library of AI-specific attack patterns and test cases focusing on internal business operation use cases.

-

Brief leadership on emerging AI threat vectors and translate them into practical, actionable mitigations — keeping the whole team informed as the landscape evolves.

-

You'll work in close partnership with our Legal, Risk and Compliance team to ensure that everything we build meets the highest standards of regulatory integrity — translating compliance requirements into practical, engineering-led solutions.

## **Your profile**

-

You have a solid background in security engineering, with hands-on experience in penetration testing, threat modelling, or red teaming — and a genuine curiosity for finding what's broken before others do.

-

You're familiar with AI and machine learning-specific attack surfaces, including prompt injection, data poisoning, model inversion, and indirect injection via documents or APIs.

-

You have practical experience designing and enforcing least-privilege architectures and know your way around identity and access management in real-world environments.

-

You understand GDPR and DSGVO not just in theory but in practice — you've built or audited data classification and retention frameworks and know what compliance actually looks like on the ground.

-

You're comfortable at the platform layer: CI/CD pipelines, secrets management, sandbox environments, and scripting and automation to build test suites and security tooling.

-

You bring network security fundamentals that allow you to have credible conversations with third-party providers, assess their work, and know when to ask the right questions.

-

You communicate clearly and document rigorously — every attack vector found, every access decision made, every framework designed is written up and kept current.

-

You're a collaborative partner to engineers and builders, not a blocker — your goal is safer agents, not fewer agents.

## Why Taxfix?

-

A chance to do meaningful, people-centric work with an international team of passionate professionals.

-

Holistic well-being with free mental health coaching sessions.

-

A monthly allowance to spend on an extensive range of services that you can use and roll over as flexibly as you like.

-

Employee stock options for all employees—because everyone deserves to benefit from the success they help to create.

-

30 annual vacation days and flexible working hours.

-

A generous learning budget to support your personal and professional development and guidance from our internal L&D experts.

-

Work from abroad for up to six weeks every year. Just align with your team, and then enjoy your trip.

-

Plenty of opportunities to socialise as a team. In addition to internal meetups, our international team hosts regular get-togethers—virtually and in person when possible.

-

Free tax declaration filing, of course, through the Taxfix app—and internal support for all personal tax-related questions.

-

Have a four-legged friend in your life? We’re happy to have dogs join us in the office.

Excited? So are we. Learn more about [Team Taxfix](https://medium.com/taxfix) on our blog and get a glimpse of our culture.

*At Taxfix, we believe that incredible things happen when you have a wealth of perspectives and experiences. We're proudly committed to equal employment and development opportunities no matter your gender, race, religion, age, sexual orientation, colour, disability, or place of origin. To help mitigate any potential unconscious biases, we ask that you refrain from including your picture, age, or marital status on your CV. Let your experiences speak for themselves.*

Not sure if you meet all the requirements for this role? Please apply anyway. You might bring something special to the team that we hadn't considered previously.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
