# Senior Commercial Leader / Entrepreneur in Residence (d/f/m)

Posted: 2026-09-21T05:40:07Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

## Our story:

Every year millions of people are either filing their taxes in fear or giving up on their tax refund altogether. We're working on fixing that. Our intuitive app enables anyone, regardless of education or background, to file their taxes with newfound confidence.

Spread across Germany, Spain and the UK, the team at Taxfix Group with its brands Taxfix and Steuerbot, is a compassionate group of solution-finders. We speak our minds openly, and with over 400 professionals, including tax experts, developers, and IT security experts, we're rich in ideas and voices. The group has facilitated more than 3.5 billion euros in tax refunds for its customers since its founding in 2016.

## **The opportunity:**

Taxfix is building a portfolio of AI-native, SaaS-oriented businesses across different stages of maturity — from established profit pools to scaling businesses and earlier-stage growth bets.

We are looking for senior commercial leaders who can take ownership of one of these business areas and build it into a focused, repeatable, and durable growth engine.

This role is for high-agency commercial builders who combine strong revenue ownership, sharp customer understanding, and disciplined execution with the ability to operate in ambiguity, experiment quickly, and make clear strategic choices.

You will report to the COO or a designated business line leader and work closely with a senior product counterpart in a joint business-building setup. You will own the commercial side of the business while shaping shared priorities across product, monetization, and growth.

You will partner closely with Product, Marketing/Growth, Sales, Partnerships, Operations/Service Delivery, Finance, Legal, Data/Analytics, and People. The initial focus is Germany, with potential to support expansion into additional markets.

The exact scope will depend on your experience spike and where we see the strongest fit.

## **Your responsibilities:**

**Own commercial strategy and outcomes.** Define growth ambition, profitability targets, commercial priorities, and the execution roadmap for a major business area.

**Make key commercial choices.** Shape ICP, segmentation, positioning, value proposition, pricing, packaging, channels, and customer lifecycle.

**Build repeatable growth loops.** Improve acquisition, activation, conversion, retention, expansion, and win-back through disciplined experimentation.

**Lead revenue generation.** Build or scale the right commercial motion — product-led, sales-assisted, partner-led, account-based, lifecycle-driven, or hybrid.

**Partner closely with Product.** Work with a senior product counterpart on roadmap implications, monetization priorities, and business-critical product choices.

**Establish performance discipline.** Define KPIs, forecasting, dashboards, review rituals, and accountability mechanisms.

**Build strong teams.** Hire, coach, and raise the bar for commercial talent while creating clear ownership and leadership capacity.

**Manage complexity.** Anticipate regulatory, operational, data, partner, and compliance risks and create practical guardrails.

## **What success looks like:**

Success depends on the maturity and economics of the business you lead.

In more mature businesses, success may mean sharper focus, stronger pricing and commercial discipline, better profitability, healthier cash generation, and durable growth.

In scaling or earlier-stage businesses, success may mean clearer ICP and positioning, stronger conversion and retention, validated propositions and channels, healthier unit economics, and repeatable growth loops.

Across all cases, success means stronger commercial judgment, faster learning, better execution, and tight alignment between product direction, monetization, and business outcomes.

## **Your profile:**

-

10+ years of experience in commercial, sales, GTM, strategy, or general management roles; experience in SaaS, subscriptions, platforms, marketplaces, fintech, or B2B services is strongly preferred.

-

Proven ability to build or scale a commercial engine, including sales motion, segmentation, pricing, packaging, channels, lifecycle, and operating cadence.

-

Strong sales background with hands-on ownership of revenue outcomes, pipeline quality, conversion, forecasting, and commercial performance.

-

Strong P&L and unit economics orientation, including CAC, payback, retention, expansion, margin trade-offs, service cost, and cash implications.

-

Strong product-commercial judgment and ability to work closely with Product without relying on hierarchy.

-

High ownership, structured execution, and comfort operating in ambiguity.

-

Data-driven and experiment-minded, using evidence, customer signals, and fast learning loops to improve performance.

-

Talent multiplier with experience hiring, coaching, delegating, and developing strong leaders.

-

Fluent in English; German is a strong plus.

## **Particularly relevant experience spikes**

**We are hiring across several priority business lines and do not expect every candidate to cover all of them. We are especially interested in profiles with one or more of the following spikes:**

**Consumer SaaS / self-service**
Experience scaling consumer SaaS, subscription, or product-led growth businesses with high-volume digital funnels, including conversion, lifecycle, retention, pricing, experimentation, and efficient acquisition.

**Consumer SaaS / expert-assisted services**
Experience scaling SaaS subscription businesses where software and service delivery are deeply connected, including expert support, operations, quality control, capacity planning, and service economics.

**SaaS for self-employed professionals**
Experience building and scaling Business SaaS solutions for self-employed professionals, SMEs, accountants, or similar B2B ecosystems, including sales-led or partner-led GTM, onboarding, retention, expansion, and platform monetization.

## Why Taxfix?

-

A chance to do meaningful, people-centric work with an international team of passionate professionals.

-

Holistic well-being with free mental health coaching sessions.

-

A monthly allowance to spend on an extensive range of services that you can use and roll over as flexibly as you like.

-

Employee stock options for all employees—because everyone deserves to benefit from the success they help to create.

-

30 annual vacation days and flexible working hours.

-

A generous learning budget to support your personal and professional development and guidance from our internal L&D experts.

-

Work from abroad for up to six weeks every year. Just align with your team, and then enjoy your trip.

-

Plenty of opportunities to socialise as a team. In addition to internal meetups, our international team hosts regular get-togethers—virtually and in person when possible.

-

Free tax declaration filing, of course, through the Taxfix app—and internal support for all personal tax-related questions.

-

Have a four-legged friend in your life? We’re happy to have dogs join us in the office.

Excited? So are we. Learn more about [Team Taxfix](https://medium.com/taxfix) on our blog and get a glimpse of our culture.

*At Taxfix, we believe that incredible things happen when you have a wealth of perspectives and experiences. We're proudly committed to equal employment and development opportunities no matter your gender, race, religion, age, sexual orientation, colour, disability, or place of origin. To help mitigate any potential unconscious biases, we ask that you refrain from including your picture, age, or marital status on your CV. Let your experiences speak for themselves.*

Not sure if you meet all the requirements for this role? Please apply anyway. You might bring something special to the team that we hadn't considered previously.

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
