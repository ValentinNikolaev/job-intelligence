# KYC Intern (f/m/d)

Posted: 2026-09-21T05:40:02Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**At Moss, we give finance professionals the power to automate their day-to-day and make forward-thinking decisions.**

**Our culture is what makes that possible: we play to win, we obsess over quality, and we win as One Moss, and it works. Moss closed a €35 million Series C in August 2026, crossing a €1 billion valuation, and became one of Europe's fintech unicorns. Join us for what's next.**

Our KYC Operations team is looking for an** KYC Intern** **(f/m/d)** **in Berlin. **

This internship will provide hands-on experience in Moss’s efforts to combat crime and fraud while offering a top-notch onboarding experience for our customers.

You will support the team and learn about **Know-Your-Customer (KYC)**, regulatory requirements, anti-money laundry principles and safety measures across all our markets. In this role, you'll have the chance to learn from a team of seasoned professionals who have extensive experience from renowned payments companies, banks, and consultancies.

We’re looking for someone to **start as soon as possible, for at least 6 months full-time. **During the initial four weeks, the role will be based on-site five days per week. Following this period, the position will transition to a hybrid working model, with three days in the office and two days working from home.

**Your responsibilities**

Here's a bit more on what you can expect to be doing day-to-day:

-

**Customer onboarding support **- you’ll assist the team in the onboarding process and later perform it yourself, under guidance.

-

**Customer due diligence **- you’ll collect and verify customer information to ensure compliance with the anti-money laundering (AML) regulation.

-

**Documentation preparation and review **- you’ll review and verify various documents, contact information, identification records, financial statements to ensure accuracy and compliance.

-

**Collaboration **- you’ll communicate effectively with internal teams and customers to convey and resolve issues. You’ll also continuously review, optimize and improve our internal processes to ensure a smooth experience.

**About you**

For this internship, we are looking for someone with the following interests and abilities:

-

Interest or initial experience in a customer-facing role, with a keen interest in regulated Banking or FinTech fields preferred.

-

You are fluent in both German (B2) and English (B2); Dutch, French, or Spanish are a plus.

In addition, here are the **skills and attributes** we are looking for:

-

**Clear & collaborative communicator** - You are able to communicate complex topics to a range of audiences in a clear, concise, and expert manner.

-

**Attention to detail **- You are precise and diligent in your data analysis and documentation.

-

**Ability to prioritize** - You are able to manage stakeholder requests and prioritize ever-changing challenges to effectively meet deadlines.

-

**Investigative approach to work** - You conduct research and apply critical thinking in order to assess and manage risks and evaluate customer profiles.

**About Moss**

Moss is the Finance AI platform for Europe's mid-sized businesses, giving companies real-time visibility and full control over their spend. By automating card issuing, invoice management and expenses, Moss simplifies financial workflows and frees finance and accounting teams from manual, administrative work.

Founded in Berlin and used by more than 10,000 businesses including Flink, Schufa, n8n and Auto1, Moss has raised €220+ million to date and operates in Germany, the Netherlands, the UK and further EU markets. In August 2026, [Moss closed a €35 million Series C ](https://www.getmoss.com/magazine/moss-series-c?origin-page=en-us%2Fcareers)led by Portage, crossing a €1 billion valuation and becoming one of Europe's newest fintech unicorns. Moss is backed by investors including Valar Ventures, Tiger Global, Global Founders Capital, Cherry Ventures, A-Star.

We're a team of 300+ people from 50+ nationalities across 5 offices in Europe and we hire, reward, and grow people based on [Moss DNA](https://www.linkedin.com/company/moss-finance/life/c2ac8184-5388-4962-ad07-e0bcbfe080f0/?viewAsMember=true): playing to win, obsessing over quality, winning as One Moss. If that's how you want to work, we want to hear from you. - here's **what else to expect:**

-

Top-of-market compensation package, including equity.

-

Our vibrant offices are at the heart of our culture, where in-person time fuels collaboration and connection over weekly breakfasts and Friday demos.

-

Additional benefits include: 20 days “work from abroad”, 600EUR/GBP Learning & Development Budget, and other local benefits.

*Unless stated otherwise, benefits apply to full-time positions (interns and working students receive a tailored package).*

***By applying for the above position, you will confirm that you have reviewed and agreed to our ***[***Data Privacy Policy***](https://www.getmoss.com/privacy-policy)***.***

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
