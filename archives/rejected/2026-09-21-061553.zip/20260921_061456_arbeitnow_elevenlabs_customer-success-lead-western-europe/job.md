# Customer Success Lead - Western Europe

Posted: 2026-09-21T05:40:07Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

## About ElevenLabs

ElevenLabs is an AI research and product company transforming how we interact with technology.

We launched in January 2023 with the first human-like AI voice model. Today, we serve millions of users and thousands of businesses - from fast-growing startups to large enterprises like Deutsche Telekom and Meta. Our investors are some of the world's most prominent, including Andreessen Horowitz, ICONIQ Growth and Sequoia. We've raised $781M in funding and our last valuation was $11B - multiples of 11, always.

We have expanded from voice into three main platforms:

-

ElevenAgents enables businesses to deliver seamless and intelligent customer experiences, with the integrations, testing, monitoring, and reliability necessary to deploy voice and chat agents at scale.

-

ElevenCreative empowers creators and marketers to generate and edit speech, music, image, and video across 70+ languages.

-

ElevenAPI gives developers access to our leading AI audio foundational models.

Everything we do is the result of the creativity and commitment of our team - builders doing the best work of their lives. We are researchers, engineers, and operators. IOI medalists and ex-founders. If you want to work hard and create lasting positive impact, we want to hear from you.

## How we work

-

**High-velocity: **Rapid experimentation, lean autonomous teams, and minimal bureaucracy.

-

**Impact not job titles: **We don’t have job titles. Instead, it’s about the impact you have. No task is above or beneath you.

-

**AI first:** We use AI to move faster with higher-quality results. We do this across the whole company—from engineering to growth to operations.

-

**Excellence everywhere: **Everything we do should match the quality of our AI models.

-

**Global team: **We prioritize your talent, not your location.

## What we offer

-

**Innovative culture:** You’ll be part of a generational opportunity to define the trajectory of AI, surrounded by a team pushing the boundaries of what’s possible.

-

**Growth paths: **Joining ElevenLabs means joining a dynamic team with countless opportunities to drive impact - beyond your immediate role and responsibilities.

-

**Learning & development**: ElevenLabs proactively supports professional development through an annual discretionary stipend.

-

**Social travel**: We also provide an annual discretionary stipend to meet up with colleagues each year, however you choose.

-

**Annual company offsite: **Each year, we bring the entire team together in a new location - past offsites have included Croatia and Italy.

-

**Co-working**: If you’re not located near one of our main hubs, we offer a monthly co-working stipend.

**About the Role**

As the Customer Success Lead you'll lead a team of experienced Customer Success team members across the Western Europe region. You'll balance people leadership, strategic direction, and hands-on customer impact - driving excellence in post-sales outcomes and ensuring your team consistently delivers measurable value to customers and the business.

**You will:**

-

Lead, coach, and develop a high-performing CS team, owning team and regional NRR performance, customer retention, and expansion goals.

-

Act as a player-coach: directly manage priority accounts, join key customer conversations, and model best-in-class success practices.

-

Lead by example in complex post-sales and renewal cycles, unblocking issues, driving adoption, and identifying expansion opportunities.

-

Set strategic direction for the team, aligning customer success initiatives with company goals and market trends.

-

Monitor and optimize delivery quality across all accounts, ensuring consistency, excellence, and predictability in customer outcomes, implementing scalable processes that improve accuracy, visibility, and operational efficiency.

-

Design and implement repeatable playbooks for renewals, upsells, and adoption; automate workflows and tools to scale team impact.

-

Own the ongoing development and optimization of best practices for Commercial and Scale playbooks, ensuring consistent execution, measurable impact, and continuous refinement as the business evolves.

-

Build and maintain executive-level relationships across priority accounts, serving as a strategic advisor and customer advocate in internal and external forums.

-

Represent the voice of the customer in leadership discussions, influencing roadmap, operations, and revenue strategies.

-

Partner with Europe GTM & cross functional leadership to align organizational objectives, drive cross-functional initiatives, and ensure cohesive execution across customer success, sales, and operations teams.

**Requirements**

• 10+ years of experience in Customer Success or post-sales roles within SaaS, ideally some of this within Western Europe accounts.

• Demonstrated technical acumen with the ability to upskill and enable the team — fostering confidence in navigating product capabilities, integrations, and data insights to strengthen customer outcomes.

• 5+ years of direct people leadership experience — managing CSMs, driving team quota, and developing talent through coaching and enablement. Passion for developing people and building a high-performance, feedback-driven culture grounded in accountability, learning, and customer impact.

• Strong player-coach mindset: comfortable managing key accounts directly while leading others to excel in their own portfolios.

• Demonstrated success in exceeding renewal, expansion, and NRR goals through effective customer engagement and strategic account management.

• Expertise in CS methodologies and best practices (e.g. success planning, adoption frameworks, ROI storytelling, executive alignment).

• Strong analytical and operational skills: adept at using data to identify performance trends, optimise workflows, and forecast outcomes.

• Strong builder mindset - you thrive in building from scratch, redefining processes and playbooks, and operating with an AI-first mindset

• Bonus: Hands-on with tools (Salesforce, Gong, Sigma, Pylon) and capable of improving data quality, visibility, and usage insights across the team.

• **Proficiency in German or French is required.**

This role is remote-first, so it can be executed from anywhere within Europe. If you prefer, you can work from our offices in London, Dublin or Paris.

We are an equal opportunity employer and do not discriminate on the basis of race, religion, national origin, gender, sexual orientation, age, veteran status, disability or other legally protected statuses.

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
