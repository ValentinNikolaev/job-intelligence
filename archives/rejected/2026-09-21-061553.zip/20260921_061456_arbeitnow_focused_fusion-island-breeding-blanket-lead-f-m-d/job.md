# Fusion Island Breeding Blanket Lead (f/m/d)

Posted: 2026-09-21T05:40:08Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**About Focused Energy**

Focused Energy is building the future of clean energy through laser-driven inertial fusion. Backed by our $240M Series A - the largest fully secured Series A in the global fusion industry we are scaling rapidly across multiple geographies.

Based in Germany and the US, we have brought together the top scientific and engineering minds using proven technologies to unlock fusion power at commercial scale. Focused Energy is working to realize game-changing scientific innovation that promises to deliver a clean, sustainable and abundant source of power globally.

**Your Role**

As a Fusion Island Breeding Blanket Lead, you would be responsible for leading the design and development of the Breeding Blanket within the Fusion Island. The position oversees all key aspects of the system, including the cooling concept, tritium breeding and extraction, and structural and mechanical integrity, from early-stage concept development through detailed design, licensing, and handover to construction and commissioning. The role requires deep technical expertise as well as the ability to provide cross-functional coordination and technical leadership across the relevant engineering interfaces

**What You'll Do**

-

End-to-end accountability for the fusion island breeding blanket design.

-

Technical leadership.

-

Define and govern the overall power cycle design architecture, including configuration, major design parameters, and fundamental safety approach.

-

Resolve complex, cross-cutting technical issues that cannot be resolved at the engineer or discipline level.

-

Write key engineering deliverables including system design descriptions, design basis documents, interface control documents, and safety analysis inputs.

-

Lead a multidisciplinary team.

-

Report design status, risks, and issues clearly and regularly to the Fusion Island Group Leader.

-

Manage design change control processes to maintain schedule and cost discipline while preserving design integrity.

**Who You Are**

-

M. Sc. in nuclear engineering or chemical engineering. Ph. D. in nuclear engineering or Ph. D. in chemical engineering is an advantage.

-

Experience in thermal-hydraulics, tritium transport and mechanical design.

-

Minimum of 5 years of experience.

-

Minimum 2 years of experience leading multidisciplinary technical teams.

-

Deep knowledge of safety analyses principles, and design basis development.

-

Knowledge of nuclear reactor physics.

-

Advanced Fusion Reactor knowledge is an advantage.

-

IFE is an advantage.

-

Mastery of CFD or Thermomechanical FEA tools.

-

Understanding tritium fuel cycle, and I&C.

-

Manage requirements, RAMI, licensing, documentation and control, project scheduling.

**Nice-To Haves**

-

Mastery in thermal hydraulics applied to the nuclear industry.

-

Mastery in tritium transport applied to the nuclear industry, especially in fusion.

-

Experience in advanced nuclear reactor systems.

-

Programming skills.

**What We Offer**

-

Innovative Technology & Mission: Be part of a cutting-edge company working on groundbreaking research in clean energy and scientific discovery.

-

Career Development: We invest in our people. This is an opportunity to join an early, growing company at the forefront of new technology, where you’ll have the opportunity to develop and grow your career.

-

Collaborative Culture: Work with great people in a dynamic, international environment with top-tier scientists, engineers and professionals passionate about solving global challenges.

-

Ownership: Take ownership from day 1 and drive impact by making decisions, solving challenges and shaping the future of our company.

-

Your Success is our Success: We offer a competitive salary and company ownership in the form of stock options, giving you a direct stake in our success and ownership in what we build together.

-

Vacation Days: We support your work-life-balance by granting you 30 days of vacation per year.

-

Snacks and Drinks: Our office fridges are never empty. Enjoy our healthy snacks and drinks. Our Darmstadt office even offers a canteen with delicious lunch options daily.

-

Retirement Plan: If you decide for a private pension plan, we will finance 20% on top of your monthly contributions, plus loyalty incentives.

-

Equipment: We offer state-of-the-art Windows or Apple Laptops. In addition, you will receive a keyboard, mouse and headset so you are fully equipped from day 1.

-

Events: We organize regular events to foster team bonding, encourage collaboration, and build a strong, supportive company culture. Connect with colleagues across departments, share ideas, and have fun together, both in and outside of the workplace.

-

Mobility with NAVIT: We partner with NAVIT to support your flexible commuting needs—whether it’s a public transportation ticket, taxi rides or car-sharing you choose what fits your lifestyle.

Focused Energy is an equal opportunity employer committed to creating an inclusive environment. Qualified applicants will receive consideration for employment without regard to race, color, religion, sex, sexual orientation, gender perception or identity, national origin, age, marital status, protected veteran status, or disability status.

Pursuant to the San Francisco Fair Chance Ordinance, Focused Energy will consider for employment qualified applicants with arrest and conviction records.

Compensation offered will be determined by factors such as location, level, job-related knowledge, skills, and experience. Certain roles may be eligible for incentive compensation, equity, benefits.

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
