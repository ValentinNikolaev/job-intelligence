# Solution Architect (German Speaking)

Posted: 2026-09-21T05:40:03Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**About Us**

Hawk is the leading provider of AI-supported anti-money laundering and fraud detection technology. Banks and payment providers globally are using Hawk’s powerful combination of traditional rules and explainable AI to improve the effectiveness of their AML compliance and fraud prevention by identifying more crime while maximizing efficiency by reducing false positives. With our solution, we are playing a vital role in the global fight against Money Laundering, Fraud, or the financing of terrorism. We offer a culture of mutual trust, support and passion – while providing individuals with opportunities to grow professionally and make a difference in the world.

**Your Mission:**

As a Solution Architect at Hawk, you will be the technical architect and strategic partner for our Tier-1 banking and enterprise fintech clients. You will bridge the gap between complex financial crime challenges and our cutting-edge AI platform, designing end-to-end solutions that directly impact the global fight against money laundering and fraud.

**Responsibilities:**

**Technical Leadership & Design**

-

Lead the end-to-end technical solution design for enterprise clients, translating complex business requirements into robust High-Level (HLD) and Low-Level Design (LLD) documentation.

-

Facilitate interactive technical workshops and whiteboarding sessions with senior stakeholders to define system architecture and integration workflows.

-

Own the creation and maintenance of engagement artifacts, including technical configuration drafts and design documents for internal and client approvals.

-

Collaborate closely with Engineering and Product teams to advocate for client-requested features and ensure technical feasibility.

**Client Engagement & Delivery**

-

Act as the primary technical point of contact for Hawk’s top-tier customers, ensuring a seamless onboarding experience and high levels of customer trust.

-

Coordinate with client-side technical stakeholders to oversee the implementation of AI-driven transaction monitoring and screening solutions.

-

Manage project timelines and billable utilization proactively, maintaining a consulting mindset toward time reporting and resource management.

-

Probe client business logic to ensure solutions don't just meet technical specs, but solve core operational challenges like false positive reduction and regulatory compliance.

**
Your Profile:**

**Experience & Communication**

-

Extensive professional experience in technical implementation, solution architecture, or technical consulting, specifically within the enterprise software space.

-

Native-level or professional fluency in German (C1/C2) and English is essential for managing our DACH enterprise portfolio.

-

Proven ability to present complex technical concepts to both technical and non-technical audiences with confidence and clarity.

-

Demonstrated experience leading customer-facing workshops and driving technical decision-making processes.

**Technical Skills**

-

Strong background in technical design and the ability to architect end-to-end software solutions for large-scale organizations.

-

Analytical mindset with the business acumen to connect technical configurations to broader financial crime prevention goals (FRAML).

-

Experience managing the full lifecycle of technical documentation, from initial discovery to final sign-off.

-

Ability to coordinate cross-functionally with internal engineering teams to resolve complex implementation roadblocks.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
