# Technical Product Manager (d/f/m) - People Intelligence Apps

Posted: 2026-09-21T05:40:07Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

## Our story:

Every year millions of people are either filing their taxes in fear or giving up on their tax refund altogether. We're working on fixing that. Our intuitive app enables anyone, regardless of education or background, to file their taxes with newfound confidence.

Spread across Germany, Spain and the UK, the team at Taxfix Group with its brands Taxfix and Steuerbot, is a compassionate group of solution-finders. We speak our minds openly, and with over 400 professionals, including tax experts, developers, and IT security experts, we're rich in ideas and voices. The group has facilitated more than 3.5 billion euros in tax refunds for its customers since its founding in 2016.

## The opportunity: ** **

As our People Intelligence/Apps Technical Product Manager within the People Strategy & Insights team, you'll be a critical part of developing our agentic enablement platform and responsible for building and shipping the People applications that power how we hire, develop, and grow our team — from workforce planning tools to AI-augmented performance and org design solutions.
Reporting to our Director of People Strategy & Insights and collaborating closely with People Partners, Leaders, FP&A, IT, and AI and Platform Engineering, you'll translate complex People domain challenges into elegant, scalable products that make a real difference in how we operate. At Taxfix, we're building an AI-native company — and this role sits right at the heart of that mission.

## **Your responsibilities**

-

Develop a deep understanding of the employee as “Builder” concept, and map the requirements different parts of the organisation have to unlock the capability of Engineers and non-Engineers to ship agentic workflows.

-

Design and implement AI-augmented tools and human-AI collaboration patterns, experimenting with emerging techniques to push the boundaries of what's possible in People operations.

-

Build, iterate, and continuously improve People applications using no-code and low-code platforms such as Claude Code, Notion, n8n, Google Cloud Apps, and other AI tools — owning the full product lifecycle from concept through delivery and optimisation.

-

Lead the continued adaption of Product mindset and ways of working across the People function, including the development and on going refinement of the People Products Roadmap.

-

Translate stakeholder needs into a prioritised People applications roadmap, balancing day-to-day operational demands with longer-term strategic initiatives and a clear build-vs-buy framework.

-

Build and maintain integrations across the People tech stack — including HiBob, Ashby, Peakon, and Postgres — ensuring seamless data flows, strong data integrity, and reliable automation via n8n.

-

Lead change management for new applications and features, creating documentation, training materials, and enablement sessions, then gathering feedback to iterate rapidly.

-

Partner with PSI leadership, People Partners, Workforce Planners, and FP&A, while collaborating with IT and Engineering to ensure all solutions meet IT security and privacy standards.

## **Your profile**

-

You bring 5+ years of experience in technical product management or a closely related role, with a proven track record of building and shipping internal tools end-to-end.

-

You have hands-on experience building with AI tools such as Claude, GPT, or Google AI Studio, and you think naturally about how to design effective human-AI collaboration patterns.

-

You are a curious PM that is not afraid to challenge the status quo in a pragmatic and constructive way.

-

You are thinking in systems, understanding the economical aspect of internal processes and products and how those can create value.

-

You are technically fluent, comfortable working with APIs, webhooks, SQL, and cross-system data flows, and you know when to bring in Engineering versus when to build it yourself.

-

You have a product mindset: you manage roadmaps, prioritise ruthlessly, and deliver incremental value in fast-paced environments, all while keeping the end user's experience front and centre.

-

You are highly proficient with no-code and low-code platforms, Notion, n8n, AppSheet, Google Cloud Apps, or similar, and you're comfortable designing data models that support complex business logic and reporting.

-

Experience in People or HR tech, workforce planning, or org design is a strong plus, as is a background in high-growth startup or scale-up environments where ambiguity is the norm, not the exception.

## Why Taxfix?

-

A chance to do meaningful, people-centric work with an international team of passionate professionals.

-

Holistic well-being with free mental health coaching sessions.

-

A monthly allowance to spend on an extensive range of services that you can use and roll over as flexibly as you like.

-

Employee stock options for all employees—because everyone deserves to benefit from the success they help to create.

-

30 annual vacation days and flexible working hours.

-

A generous learning budget to support your personal and professional development and guidance from our internal L&D experts.

-

Work from abroad for up to six weeks every year. Just align with your team, and then enjoy your trip.

-

Plenty of opportunities to socialise as a team. In addition to internal meetups, our international team hosts regular get-togethers—virtually and in person when possible.

-

Free tax declaration filing, of course, through the Taxfix app—and internal support for all personal tax-related questions.

-

Have a four-legged friend in your life? We’re happy to have dogs join us in the office.

Excited? So are we. Learn more about [Team Taxfix](https://medium.com/taxfix) on our blog and get a glimpse of our culture.

*At Taxfix, we believe that incredible things happen when you have a wealth of perspectives and experiences. We're proudly committed to equal employment and development opportunities no matter your gender, race, religion, age, sexual orientation, colour, disability, or place of origin. To help mitigate any potential unconscious biases, we ask that you refrain from including your picture, age, or marital status on your CV. Let your experiences speak for themselves.*

Not sure if you meet all the requirements for this role? Please apply anyway. You might bring something special to the team that we hadn't considered previously.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
