# Partnerships Associate Manager - GER

Posted: 2026-09-21T05:40:02Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**At Moss, we give finance professionals the power to automate their day-to-day and make forward-thinking decisions.**

**Our culture is what makes that possible: we play to win, we obsess over quality, and we win as One Moss, and it works. Moss closed a €35 million Series C in August 2026, crossing a €1 billion valuation, and became one of Europe's fintech unicorns. Join us for what's next.**

We are now looking for a Partnerships Associate to support our growth journey in Germany. This is a junior-level role designed for early-career professionals with a strong interest in finance, accounting, or Fintech. You’ll help identify and connect with potential partners, build a strong pipeline, and support the foundation for lasting cosmmercial relationships. Over time, you’ll have the opportunity to develop into a full-cycle Partner Manager role, taking end-to-end ownership of strategic partnerships.

**Your responsibilities**

Here's a bit more on what you can expect to be doing day-to-day:

-

**Partner Identification & Assessment: **Research and identify prospective partners aligned with Moss’ strategic priorities and ideal customer profiles. Support the initial assessment of partners through qualitative and quantitative analysis (e.g., partner fit, customer base, integration potential).

-

**Outreach & Pipeline Building:** Own the top of the funnel for our partnerships pipeline. Proactively reach out to prospective partners via email, LinkedIn, events, and other channels. Engage partners with a clear value proposition and qualify initial interest.

-

**Relationship Building & Support: **Assist in building and maintaining strong working relationships with partners. Participate in partner calls and meetings, prepare follow-ups, and support ongoing communication. Help deliver value to partners by understanding their needs and coordinating with internal teams.

-

**Process & Reporting: **Track outreach and pipeline activity in CRM tools (e.g., Salesforce). Share regular updates on partner funnel status and help improve outreach playbooks and processes. Collaborate with Partnerships, Sales, and Marketing to ensure partner prospects are well aligned with Moss’ commercial strategy.

**About you**

We think you’ll need the following **experience and qualifications** to succeed in this role:

-

First experience (1-2 years of full-time work) in business development, partnerships, finance, accounting, or Fintech

-

Academic background in business, finance, economics, or similar fields

-

Fluent in German (C2) & English (C1)

In addition, here are the **skills and attributes** we are looking for:

-

**Curious & Analytical:** You’re structured in your research and bring insights into conversations.

-

**Relationship— Oriented: **You enjoy speaking to people, understand how to build rapport, and communicate with clarity.

-

**Self-Starter:** You take initiative, manage your own pipeline, and are eager to learn from every interaction.

-

**Team Player:** You collaborate closely with teammates and internal stakeholders to deliver joint results.

-

**Growth-Driven:** You’re looking to grow into a Partner Manager role over time and want to learn how to build high-impact commercial partnerships.

**About Moss**

Moss is the Finance AI platform for Europe's mid-sized businesses, giving companies real-time visibility and full control over their spend. By automating card issuing, invoice management and expenses, Moss simplifies financial workflows and frees finance and accounting teams from manual, administrative work.

Founded in Berlin and used by more than 10,000 businesses including Flink, Schufa, n8n and Auto1, Moss has raised €220+ million to date and operates in Germany, the Netherlands, the UK and further EU markets. In August 2026, [Moss closed a €35 million Series C ](https://www.getmoss.com/magazine/moss-series-c?origin-page=en-us%2Fcareers)led by Portage, crossing a €1 billion valuation and becoming one of Europe's newest fintech unicorns. Moss is backed by investors including Valar Ventures, Tiger Global, Global Founders Capital, Cherry Ventures, A-Star.

We're a team of 300+ people from 50+ nationalities across 5 offices in Europe and we hire, reward, and grow people based on [Moss DNA](https://www.linkedin.com/company/moss-finance/life/c2ac8184-5388-4962-ad07-e0bcbfe080f0/?viewAsMember=true): playing to win, obsessing over quality, winning as One Moss. If that's how you want to work, we want to hear from you. - here's **what else to expect:**

-

Top-of-market compensation package, including equity.

-

Our vibrant offices are at the heart of our culture, where in-person time fuels collaboration and connection over weekly breakfasts and Friday demos.

-

Additional benefits include: 20 days “work from abroad”, 600EUR/GBP Learning & Development Budget, and other local benefits.

*Unless stated otherwise, benefits apply to full-time positions (interns and working students receive a tailored package).*

***By applying for the above position, you will confirm that you have reviewed and agreed to our ***[***Data Privacy Policy***](https://www.getmoss.com/privacy-policy)***.***

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
