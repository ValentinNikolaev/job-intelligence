# Program Manager - Reactor (f/m/d)

Posted: 2026-09-21T05:40:08Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**About Focused Energy**

Focused Energy is building the future of clean energy through laser-driven inertial fusion. Backed by our $240M Series A - the largest fully secured Series A in the global fusion industry we are scaling rapidly across multiple geographies.

Based in Germany and the US, we have brought together the top scientific and engineering minds using proven technologies to unlock fusion power at commercial scale. Focused Energy is working to realize game-changing scientific innovation that promises to deliver a clean, sustainable and abundant source of power globally.

**Your Role**

As a Program Manager - Reactor you will be responsible for managing the reactor department projects and coordinate with other departments and aligning with company wide PM efforts.

**What You'll Do**

-

Plan and track projects, translating strategic goals into clear tasks, schedules, and milestones with particular emphasis on long-horizon, high-consequence programs such as the fusion island wall design, procurement and commissioning.

-

Track budget and personnel capacity to ensure efficient resource allocation across multi-year reactor programs.

-

Maintain project plans, schedules, and workflows in Jira, Jira Big Picture and Confluence.

-

Track progress and follow up with engineers and stakeholders from reactor, engineering, targets, lasers and science.

-

Planning and coordination of appointments, meetings, sessions, and events such as conferences, safety reviews, and internal progress review days, including follow-up on decisions and action items.

-

Own risk and change management as a core responsibility; maintain risk registers, drive mitigation planning, and ensure change control processes are followed rigorously in a safety-critical environment.

-

Serve as the central point of contact for interfacing with program management, finance, and all other SST departments; liaise with suppliers, research partners, external regulatory bodies and government partners where applicable.

-

Coordinate with company-wide PM efforts to ensure compliance with company-wide standards.

-

Support public funding resource coordination with our finance and programs team.

-

Ensure adherence to radiation safety, high-voltage system protocols, and any applicable nuclear regulatory or licensing requirements; coordinate with safety officers and compliance leads as needed

**Who You Are**

-

Master's degree or higher in nuclear engineering, physics, or a related field; a PhD preferred.

-

Deep experience in R&D and engineering-heavy project management and coordination, ideally within experimental physics or nuclear energy research environments.

-

Strong communication, administrative, and personal time-management skills.

-

Excellent written and verbal communication skills in both English and German.

-

Possess a broad, cross-functional skill set and identify less as a subject matter expert and more as a systems integrator.

-

Ability to present complex scientific content clearly, precisely, and in a manner tailored to the target audience—including non-technical stakeholders and regulatory bodies.

-

Familiarity with Jira, Jira Big Picture, and Confluence (or similar tools).

-

Demonstrated ability to manage high-stakes, safety-critical programs with rigorous risk and change management practices.

-

Tracking cost, schedule, and scope performance (Earned Value Management – EVM).

-

Work Breakdown Structure (WBS) creation and control.

-

Agile/hybrid methodologies where relevant (e.g., for R&D phases).

-

Familiarity with nuclear safety case development and safety justification processes.

-

Understanding of Plant lifecycle: concept → FEED → detailed design → procurement → construction → commissioning.

## **Nice-to-haves**

-

Successes built around breakthroughs.

-

Specialization in fusion-relevant disciplines is a strong advantage.

-

Direct experience working in or managing programs within controlled environments, including radiation-controlled areas.

-

Familiarity with Jira, Jira Big Picture, and Confluence (or similar tools).

-

Familiarity with nuclear regulatory frameworks or licensing processes (or a radiation protection regulator).

-

IPMA or PMI certification and familiarity with agile and hybrid project management methods.

-

Experience interfacing with government funding bodies or public research programs.

**What We Offer**

-

Innovative Technology & Mission: Be part of a cutting-edge company working on groundbreaking research in clean energy and scientific discovery.

-

Career Development: We invest in our people. This is an opportunity to join an early, growing company at the forefront of new technology, where you’ll have the opportunity to develop and grow your career.

-

Collaborative Culture: Work with great people in a dynamic, international environment with top-tier scientists, engineers and professionals passionate about solving global challenges.

-

Ownership: Take ownership from day 1 and drive impact by making decisions, solving challenges and shaping the future of our company.

-

Your Success is our Success: We offer a competitive salary and company ownership in the form of stock options, giving you a direct stake in our success and ownership in what we build together.

-

Vacation Days: We support your work-life-balance by granting you 30 days of vacation per year.

-

Snacks and Drinks: Our office fridges are never empty. Enjoy our healthy snacks and drinks. Our Darmstadt office even offers a canteen with delicious lunch options daily.

-

Retirement Plan: If you decide for a private pension plan, we will finance 20% on top of your monthly contributions, plus loyalty incentives.

-

Equipment: We offer state-of-the-art Windows or Apple Laptops. In addition, you will receive a keyboard, mouse and headset so you are fully equipped from day 1.

-

Events: We organize regular events to foster team bonding, encourage collaboration, and build a strong, supportive company culture. Connect with colleagues across departments, share ideas, and have fun together, both in and outside of the workplace.

-

Mobility with NAVIT: We partner with NAVIT to support your flexible commuting needs—whether it’s a public transportation ticket, taxi rides or car-sharing you choose what fits your lifestyle.

Focused Energy is an equal opportunity employer committed to creating an inclusive environment. Qualified applicants will receive consideration for employment without regard to race, color, religion, sex, sexual orientation, gender perception or identity, national origin, age, marital status, protected veteran status, or disability status.

Pursuant to the San Francisco Fair Chance Ordinance, Focused Energy will consider for employment qualified applicants with arrest and conviction records.

Compensation offered will be determined by factors such as location, level, job-related knowledge, skills, and experience. Certain roles may be eligible for incentive compensation, equity, benefits.

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
