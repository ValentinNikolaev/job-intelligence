# BDR

Posted: 2026-09-21T05:40:03Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**About Us**

Hawk is the leading provider of AI-supported anti-money laundering and fraud detection technology. Banks and payment providers globally are using Hawk’s powerful combination of traditional rules and explainable AI to improve the effectiveness of their AML compliance and fraud prevention by identifying more crime while maximizing efficiency by reducing false positives. With our solution, we are playing a vital role in the global fight against Money Laundering, Fraud, or the financing of terrorism. We offer a culture of mutual trust, support and passion – while providing individuals with opportunities to grow professionally and make a difference in the world.

**Your Mission**

Are you a dynamic and driven Business Development Representative looking to grow your career in enterprise SaaS sales and marketing? Hawk is looking for a BDR in Munich or London to join our Marketing team, where you will be responsible for helping to generate revenue by building relationships and arranging meetings with our target accounts. You will be adept at identifying prospect goals and pain-points and then combining email, social media and other channels to share content, insights and solutions that deliver real value and relevance.

**Your Responsibilities**

-

Build value-led relationships with prospective mid-market and enterprise accounts via email and other channels

-

Research target accounts and contacts to understand their goals and pain-points, and identify opportunities for relevant engagement

-

Meet MQL and pipeline generation targets by setting up meetings between prospective customers and Hawk Sales representatives

-

Create and execute pre-event campaigns to drive awareness of Hawk event participation and schedule meetings

-

Attend industry events and conferences, as required

-

Execute timely and personalized post-event follow-up, converting event conversations and leads into qualified meetings

-

Leverage marketing campaigns and other content for optimized outreach and to generate demand for Hawk products and services

-

Write professional and appropriate email and other communication materials, knowing when and how to tailor emails to maximize engagement

-

Manage a variety of sales tools, combining intelligence from multiple sources to prioritize outreach based on intent and other factors

-

Build phenomenally productive relationships with your colleagues in Sales and Marketing

-

Be meticulous in maintaining records of contact and hold others to account on doing the same

**Your Profile – You Will Bring**

-

2+ years’ experience in a business development role at a B2B technology organization

-

A love for engaging with people and finding ways to connect challenges with solutions

-

A passion for the art/science of cold email writing

-

Exceptional written and verbal communication skills in English; German would be an advantage

-

A drive for delivering results and working to targets

-

Positivity and resourcefulness

-

Resilience and tenacity

-

The ability to manage your time and prioritize tasks with a sense of urgency and focus

-

An interest in technology and AI

-

Familiarity with CRM systems

-

The ability to work as part of a cross-functional team, being based in Marketing and working with Sales on a daily basis

-

A hybrid working approach, spending two days per week in the London or Munich office

-

Knowledge of the financial services sector would be a significant advantage

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
