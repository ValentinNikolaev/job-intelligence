# Fusion Island Group Leader (f/m/d)

Posted: 2026-09-21T05:40:08Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

## **About Focused Energy**

Focused Energy is an international deep-tech company based in Germany and the US, working to commercialize laser-driven nuclear fusion. Our mission is to provide clean, safe, and virtually unlimited energy to the world. We are rapidly scaling and looking for talented individuals who thrive in building clarity and structure within fast-growing environments.

## **Your Role**

The Fusion Island Group Lead is responsible for overseeing the integrated design of the complete plant system, with a focus on the fusion island, from early concept development through detailed design, licensing, and handover to construction and commissioning. The position provides both technical and organizational leadership, with overall accountability for engineering activities within the group and authority for key design and delivery decisions.

##
**What You'll Do**

-

End-to-end accountability for the fusion island design.

-

Technical Leadership & Design Authority.

-

Define and govern the overall systems design architecture, including plant configuration, major design parameters, and fundamental safety approach.

-

Lead critical design reviews, independent assessments, and design verification activities.

-

Resolve complex, cross-cutting technical issues that cannot be resolved at the engineer or discipline level.

-

Approve key engineering deliverables including system design descriptions, design basis documents, interface control documents, and safety analysis inputs.

-

Lead, manage, and develop a multidisciplinary team.

-

Define roles, responsibilities, and performance expectations for all team members.

-

Report design status, risks, and issues clearly and regularly to the VP of reactor and fuel cycle.

-

Manage design change control processes to maintain schedule and cost discipline while preserving design integrity.

## **Who You Are**

-

Degree in engineering. M.Sc. or Ph.D. in nuclear engineering would be nice to have.

-

Minimum of 10 years of experience.

-

Minimum 5 years of experience leading multidisciplinary technical teams.

-

Deep knowledge of nuclear plant systems, safety analysis principles, and design basis development.

-

Deep knowledge of nuclear reactor physics, fusion is an advantage.

-

Mastery of nuclear plant systems.

-

Understanding of thermal-hydraulics, neutronics, mechanical analyses, I&C, and activation.

-

Experience in Manage requirements, Configuration management, Nuclear safety., RAMI, Licensing, Documentation and control, Project scheduling.

## **Nice to Have**

-

Experience with fusion-specific systems.

-

Strong command of codes and standards.

-

Experience managing large engineering programs, including scope, schedule, budget, and risk.

-

Experience with advanced reactor designs.

## **What We Offer**

-

Innovative Technology & Mission: Be part of a cutting-edge company working on groundbreaking research in clean energy and scientific discovery.

-

Career Development: We invest in our people. This is an opportunity to join an early, growing company at the forefront of new technology, where you’ll have the opportunity to develop and grow your career.

-

Collaborative Culture: Work with great people in a dynamic, international environment with top-tier scientists, engineers and professionals passionate about solving global challenges.

-

Ownership: Take ownership from day 1 and drive impact by making decisions, solving challenges and shaping the future of our company.

-

Your Success is our Success: We offer a competitive salary and company ownership in the form of stock options, giving you a direct stake in our success and ownership in what we build together.

-

Vacation Days: We support your work-life-balance by granting you 30 days of vacation per year.

-

Snacks and Drinks: Our office fridges are never empty. Enjoy our healthy snacks and drinks. Our Darmstadt office even offers a canteen with delicious lunch options daily.

-

Retirement Plan: If you decide for a private pension plan, we will finance 20% on top of your monthly contributions, plus loyalty incentives.

-

Equipment: We offer state-of-the-art Windows or Apple Laptops. In addition, you will receive a keyboard, mouse and headset so you are fully equipped from day 1.

-

Events: We organize regular events to foster team bonding, encourage collaboration, and build a strong, supportive company culture. Connect with colleagues across departments, share ideas, and have fun together, both in and outside of the workplace.

-

Mobility with NAVIT: We partner with NAVIT to support your flexible commuting needs—whether it’s a public transportation ticket, taxi rides or car-sharing you choose what fits your lifestyle.

-

Fitness with Wellhub: We care about your health. Get access to a wide range of gyms, fitness studios and wellness services across Europe through our partnership with Wellhub.

Focused Energy is an equal opportunity employer committed to creating an inclusive environment. Qualified applicants will receive consideration for employment without regard to race, color, religion, sex, sexual orientation, gender perception or identity, national origin, age, marital status, protected veteran status, or disability status.

Pursuant to the San Francisco Fair Chance Ordinance, Focused Energy will consider for employment qualified applicants with arrest and conviction records.

Compensation offered will be determined by factors such as location, level, job-related knowledge, skills, and experience. Certain roles may be eligible for incentive compensation, equity, benefits.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
