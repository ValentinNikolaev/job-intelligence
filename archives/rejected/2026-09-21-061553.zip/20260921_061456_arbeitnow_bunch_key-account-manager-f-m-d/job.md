# Key Account Manager (f/m/d)

Posted: 2026-09-21T05:40:06Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

[bunch](https://www.bunch.capital/) is building the backbone of private markets. We are enabling next-gen fund operations with one integrated system that combines secure data infrastructure, AI-powered workflows and expert fund services. If you value ownership, growth through real responsibility, and working with a thoughtful, ambitious team, this role might be for you.

To expand our core team, we are seeking a passionate and driven **Key Account Manager** who wants to play a pivotal role in scaling our business and transforming private markets. You will work closely with the Customer Success Team and will report directly to our Head of Customer Success.

## **Your role**

Customer experience is central to our mission. As we scale into new markets and expand our product capabilities, we need a dedicated partner for our fund managers and investors—someone who elevates every interaction and turns exceptional service into measurable growth.

In this role, you will shape how our customers experience bunch, strengthen long-term relationships, and directly influence retention, expansion, and market reputation.

## **Top responsibilities**

-

Serve as the strategic point of contact for fund managers, ensuring a seamless, high-quality experience across all touchpoints.

-

Lead the end-to-end post-sales lifecycle—from onboarding through growth and upsell—collaborating with multiple departments including Operations, Product, Sales, Legal, and Finance.

-

Build deep, trust-based relationships with customers and translate their needs into clear insights that drive product and operational improvements.

-

Own and optimise key customer metrics, including NPS, retention, NRR,, and escalation management.

-

Collaborate closely with the Head of Customer Success to refine and scale our Customer Success strategy as the company grows.

## **About you**

-

3+ years of professional experience, including 1–3 years in enterprise Account Management or Customer Success.

-

Ability to manage complex, high-value customer relationships and confidently engage with senior stakeholders.

-

Strong analytical and communication skills, with the ability to simplify complex topics and tailor your approach to diverse audiences.

-

Proven track record of operating effectively in fast-moving, high-growth environments and adapting quickly to changing priorities.

-

Proficiency in English and German

## **Workplace & Benefits**

-

Competitive salary

-

Customizable benefits package (wellbeing, sport, mobility, food, and more)

-

28 days of vacation, plus 2 company days and local public holidays

-

Remote-flexible hybrid (3 days/week in office)

-

Up to 4 remote calendar weeks a year

-

A great tech and work setup

-

Work with a diverse team of 120+ bunchies from 40+ countries, with leaders who are best-in-class in their domains

## **Hiring process**

-

**People Team Interview (30 min):** Introduction to bunch, expectations, values, and your career aspirations.

-

**Deep-Dive Interview with Chey, Head of Customer Success (30 min):** Explore the role, your experience, and how your journey aligns with our mission.

-

**Practical Interview with the Customer Success Team (45 min):** Demonstrate your approach to Account Management and communication.

-

**Final two part stakeholder interview:** first with our operations team and second with one of our Co-founders to ask questions and get to know our leadership.

**About bunch**

bunch is building the operating infrastructure for the next generation of private markets. We combine AI-powered automation with deep regulatory expertise to replace fragmented spreadsheets and manual processes with one integrated platform across the fund lifecycle, purpose-built for private markets heading toward $32 trillion in Assets Under Management.

We've 4x our ARR in 2025, crossed 150 fund managers and 12,000 LPs on the platform, and just closed our $35M Series B in May 2026. We're looking for ambitious people who want real ownership of hard problems, and who care about building infrastructure that actually matters to the people using it.

____

At bunch, we're committed to an inclusive environment where diversity is valued and celebrated. We provide equal opportunities to all qualified applicants.

We process personal data in line with applicable laws (including GDPR). See our[ Privacy Policy](https://www.bunch.capital/privacy-policy) for details on your rights and how to reach us.

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
