# Solution Engineer - Germany

Posted: 2026-09-21T05:40:10Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

## 🌀 The Company

Filigran, founded in October 2022, stands out in the cybertech ecosystem for its commitment to revolutionizing cyber threat management with a proactive approach. Its mission is to develop innovative open-source solutions designed to anticipate cyber threats, identify security gaps, and strengthen organizational security posture.

Filigran solutions are now trusted by over 6,000 public and private organizations worldwide.

## 🎯 The Role

We're looking for a **Senior Solution Engineer** to join our **Go-to-Market team** and help us guide our most strategic prospects and customers in adopting and integrating Filigran’s open source platforms — OpenCTI, OpenAEV & XTM One. You’ll play a key role at the intersection of technical expertise and client enablement by running demos, delivering workshops, building prototypes, and translating customer needs into integrated technical solutions.

Your work will directly support our Sales, Customer Success, and Product teams by enabling strong adoption, trust, and long-term success with Filigran’s ecosystem.

## 💼 Your Responsibilities

-

Deliver technical and functional guidance to key prospects and customers

-

Build and run product demonstrations and workshops tailored to use cases

-

Design technical solutions aligned to customer architecture and business goals

-

Lead successful Proof-of-Value (PoV) deployments and maintain healthy environments

-

Support smooth handovers from Sales to Customer Success

-

Represent Filigran as a technical advisor in client discussions, from dev teams to C-level

-

Contribute to technical documentation, training, and integration projects

-

Maintain strong relationships with the OpenCTI community and users

-

Work closely with Product, Engineering, and Marketing to feed back insights and influence the roadmap

## 🤝 Who You’ll Work With

-

Reports to the VP of Solution Engineering

-

Works cross-functionally with Sales, Customer Success, Product Management, and Engineering

-

Collaborates closely with DACH Sales and Channel on go-to-market strategies

-

Engages with community members and technical users of our open source platforms

## 🧬 Profile We’re Looking For

-

5+ years in a Solution Engineering, Technical Account Management, Consulting, or Presales role

-

Strong understanding of cybersecurity and Continuous Threat Exposure Management (CTEM)à sdfh topics

-

Ability to explain technical concepts to both engineering and non-technical stakeholders

-

Experience leading workshops, technical trainings, or product demos

-

Comfortable operating in a remote-first, fast-paced, and collaborative environment

-

Fluent in German and English

-

Bonus: Prior experience in CTEM, breach and attack simulation/pentesting, CTI, SOC or public sector cybersecurity

## 🌱** Why Join Filigran? More than just a job.**

We’re a fast-growing, global, and fully remote company building open-source cybersecurity solutions, increasingly powered by AI, to help defense teams anticipate threats and act faster.

⭐ **What we believe**

We believe we do work that matters, uniting defenders into a global community to make security more open, resilient & collaborative.

💻 **How we work**

We do work that matters by combining strong engineering standards with emerging technologies, including AI, to move faster and smarter.

🧭 **What guides us**

We make our work matter by building a culture grounded in our CORE values of Cohesion, Openness, Responsibility, and Equity. The principles that guide how we make decisions, treat people, and grow together, especially when no one’s watching.

## **💰 Compensation & Benefits**

-

**Competitive pay + equity** - everyone shares in our success

-

**Remote-first, flexible, and balanced** - work that fits your life

-

**Your setup, your choice** - pick the gear that works for you

-

**Twice-a-year gatherings** - we meet in person for regional and global offsites to connect, collaborate, and strengthen our culture beyond the screen

## **🌍 Equal Employment Opportunity**

**We enable cybersecurity through inclusion - from code to culture.**

At Filigran, we are proud to be an equal opportunity employer. We believe diversity of our people make our products and our team stronger. We welcome talent of every background, identity, and lived experience, regardless of race, color, religion, gender, gender identity or expression, sexual orientation, national origin, age, disability, or veteran status.

What matters here is what you bring, not what you look like, where you’re from, or how you identify.

## **🚀 Ready to Join Us?**

Apply now and help us build the future of the cybersecurity ecosystem, together.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
