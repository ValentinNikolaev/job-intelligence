# Senior Mechanical Engineer (f/m/d)

Posted: 2026-09-21T05:40:08Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

## **About Focused Energy**

Focused Energy is an international deep-tech company based in Germany and the US, working to commercialize laser-driven nuclear fusion. Our mission is to provide clean, safe, and virtually unlimited energy to the world. We are rapidly scaling and looking for talented individuals who thrive in building clarity and structure within fast-growing environments.

**Role Overview:**
The Senior Mechanical Engineer plays a technical leadership role in the design, development, and integration of complex mechanical systems that enable Focused Energy’s experimental programs and facility projects.

This role is responsible for translating demanding scientific and engineering requirements into practical, manufacturable, and reliable mechanical solutions. In addition to leading key mechanical design efforts, the Senior Mechanical Engineer provides guidance to other engineers and helps ensure designs are robust, build-ready, and fully prepared for integration and operation.

**Key Responsibilities:**

-

Lead the mechanical design of complex systems and assemblies, including laser integration structures, vacuum chambers, diagnostics mounts, target systems, and facility-related mechanical equipment.

-

Take technical ownership of mechanical work packages, driving them from concept through detailed design, build, integration, testing, and commissioning.

-

Define and manage mechanical requirements and interfaces with laser, diagnostics,

-

Targetry, controls, electrical, safety, systems engineering, facilities, suppliers, and technicians.

-

Review and guide engineering analysis, including structural loading, thermal behavior, vibration, stability, tolerances, alignment, and manufacturability.

-

Lead mechanical design reviews and technical decision-making, ensuring risks, design maturity, documentation, and integration readiness are clear before key project milestones.

-

Mentor and guide other mechanical engineers, helping them solve complex design problems, improve documentation quality, and deliver robust mechanical designs

**Required Skills & Experience**

-

Degree in Mechanical Engineering or closely related discipline.

-

8+ years’ experience in mechanical design, development and integration of complex systems.

-

Strong 3D CAD capability, ideally Autodesk Inventor.

-

Proven ability to take technical ownership of mechanical subsystems or work packages.

-

Ability to work across multidisciplinary interfaces including electrical, controls, systems, safety, facilities and suppliers.

-

Ability to guide and support other mechanical engineers through complex technical challenges.

Focused Energy is an equal opportunity employer committed to creating an inclusive environment. Qualified applicants will receive consideration for employment without regard to race, color, religion, sex, sexual orientation, gender perception or identity, national origin, age, marital status, protected veteran status, or disability status.

Pursuant to the San Francisco Fair Chance Ordinance, Focused Energy will consider for employment qualified applicants with arrest and conviction records.

Compensation offered will be determined by factors such as location, level, job-related knowledge, skills, and experience. Certain roles may be eligible for incentive compensation, equity, benefits.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
