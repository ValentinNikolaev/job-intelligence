# Talent Acquisition Speciliast (mf/d)

Posted: 2026-09-21T05:09:40Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**About us:**

**Talent Acquisition Specialist (m/f/d) | ****Elternzeitvertretung / Parental Leave Cover**
Fixed-term, around12 months | ideally part-time (60–80%), with the option to extend to full-time | Berlin (hybrid) | Recruiting for SRLabs and Allurity group companies
based candidates.

Please apply only if you are based in Berlin and has right to work. No visa sponsor available, No remote options available.

**About us**
SRLabs is home to some of the sharpest minds in cybersecurity. We secure critical infrastructures in finance, energy, and telecommunications — not through compliance checklists, but through hands-on hacking resilience. Our work lives at the intersection of deep technical research and impactful consulting for organisations that care about staying ahead of real threats.
We're a team of 60 people based in Berlin, with colleagues from all over the world. We're part of Allurity, a European cybersecurity group of 12+ sister companies, which gives us scale without sacrificing our startup energy.

We're looking for a Talent Acquisition Specialist to cover a parental leave for around 12 months. In this role, you won't just recruit for SRLabs — you'll also support hiring across several of our Allurity sister companies, working closely with our cross-company People Hub. It's a great opportunity to get hands-on, end-to-end recruiting experience across a range of technical and business roles, in an organisation that takes hiring seriously without drowning it in process.

**Your responsibilities**

**Full-Cycle Recruiting**

- Own end-to-end recruiting for open roles at SRLabs and selected Allurity sister companies — from intake call to signed offer.
- Write and post compelling, accurate job ads that speak to the kind of people we want to attract.
- Screen applications and conduct first-round interviews, giving candidates a fair, fast, and human process.
- Coordinate interview loops with hiring managers and technical interviewers, and keep candidates informed at every step.
**Sourcing**

- Proactively source candidates for harder-to-fill and technical roles via LinkedIn Recruiter, Boolean search, and other channels.
- Build and maintain talent pipelines for recurring role types across the group.
- Help identify and test new sourcing channels, particularly for niche cybersecurity talent.
**Cross-Company Collaboration**

- Partner with hiring managers and People colleagues across Allurity sister companies to understand their hiring needs and local market context.
- Contribute to shared recruiting standards, templates, and best practices via the People Hub.
- Support group-wide initiatives such as the graduate/internship pilot and employer-branding activities where relevant.
**Candidate & Hiring Manager Experience**

- Be the main point of contact for candidates throughout the process — approachable, responsive, and clear.
- Coach hiring managers on structured interviewing and help them make confident, fair decisions.
- Gather feedback to continuously improve the candidate and hiring manager experience.
**Systems & Process**

- Keep our ATS/Personio data accurate and up to date — job postings, pipelines, candidate statuses, and reporting.
- Maintain recruiting-related documentation and help keep our hiring process easy to follow for everyone involved.
- Track basic recruiting metrics (time-to-fill, pipeline health, source effectiveness) and flag bottlenecks early.

**What do you bring?**

- Proven technical recruiting experience (agency or in-house) — this is a must. You've hired engineers, security specialists, or comparable technical profiles, and you can hold a credible conversation with them. This isn't a role for a first-time recruiter, but you don't need to be senior either.
- A bit of hands-on sourcing know-how — comfortable using LinkedIn Recruiter or similar tools, and not afraid of a Boolean search string.
- Good communication skills in both German and English — you can run a candidate conversation and write a clear job ad in either.
- A structured, organised way of working — you keep pipelines tidy and don't let candidates fall through the cracks.
- Genuine affinity for tech and cybersecurity talent — you don't need to code yourself, but you understand technical roles well enough to assess and engage the people in them.
- Comfortable working across multiple companies and stakeholders at once, with a good sense for adapting your approach to different teams and cultures.
- Ownership mentality — you follow through, flag issues early, and don't wait to be told what's next.
- Based in Berlin, with an existing right to work in Germany.

**What awaits you with us?**

- A front-row seat in the world of cybersecurity — one of the most interesting and relevant fields there is right now.
- Real end-to-end ownership of recruiting across multiple companies, not just req-filling.
- A close-knit, international team that takes the work seriously but doesn't take itself too seriously.
- 30 days of paid vacation (pro-rated for the contract term).
- Learning budget for courses or conferences relevant to your role.
- BVG public transport pass and gym membership discounts.
- German language lessons (if you need them).
- Flexible home office.
- Exposure to group-wide People initiatives and colleagues across 12+ Allurity sister companies.

This is a fixed-term position (Elternzeitvertretung) for approximately 12 months, covering a parental leave. It starts as a part-time role at 60–80%, with the option to move to full-time during the contract term depending on hiring volume. There's a real possibility of a handover period with the current role holder to ensure continuity.

**Apply now**

SRLabs is committed to building an inclusive and diverse environment. We are an equal opportunity employer and do not discriminate on any basis — we welcome applications from all qualified individuals.

Sound like you? We'd love to hear from you.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
