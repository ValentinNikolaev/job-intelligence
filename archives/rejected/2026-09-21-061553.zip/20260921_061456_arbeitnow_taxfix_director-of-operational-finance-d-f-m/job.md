# Director of Operational Finance (d/f/m)

Posted: 2026-09-21T05:40:07Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

## Our story:

Every year millions of people are either filing their taxes in fear or giving up on their tax refund altogether. We're working on fixing that. Our intuitive app enables anyone, regardless of education or background, to file their taxes with newfound confidence.

Spread across Germany, Spain and the UK, the team at Taxfix Group with its brands Taxfix and Steuerbot, is a compassionate group of solution-finders. We speak our minds openly, and with over 400 professionals, including tax experts, developers, and IT security experts, we're rich in ideas and voices. The group has facilitated more than 3.5 billion euros in tax refunds for its customers since its founding in 2016.

## **Role:**

As the Director of Operational Finance, you will be pivotal in advancing Taxfix's financial infrastructure to support our expansive growth and innovation initiatives. Based in the Berlin office, you will collaborate closely with senior leadership and cross-functional teams. Your strategic oversight will further drive the optimization of our financial operations, enhance compliance with international standards, and foster relationships with key stakeholders, ultimately supporting Taxfix's mission and growth trajectory. You will also drive AI adoption and automation across Finance, and further build and lead our team of highly qualified and motivated experts. You will lead a team of 10+ highly motivated experts.

## **Responsibilities:**

-

Further elevate and strategically oversee the end-to-end operational finance function, ensuring excellence in delivery and alignment with the group’s strategic objectives.

-

Spearhead and manage high-impact finance projects across multiple countries, ensuring excellence in delivery and alignment with strategic goals.

-

Cultivate and lead a high-performing finance team, fostering a culture of excellence, innovation, and accountability.

-

Champion cross-functional initiatives, driving collaboration and innovation across the organisation and regarding new product launches.

-

Act as a key advisor and contact for senior management and external partners on advanced financial and administrative matters.

-

Ensure the preparation of comprehensive monthly and audited annual financial statements, maintaining rigorous compliance with legal and regulatory requirements.

-

Drive further AI adoption and automation in Finance: agent/AI-based workflows, and tooling-led productivity gains.

-

Strategically manage financial risks, including FX and interest costs, to safeguard the company's financial health.

-

Oversee implementation of IFRS reporting, ensuring transparency and reliability in financial reporting.

## **Your Profile:**

-

Extensive experience in finance and strategic project management, with ideally 10 years in leadership roles.

-

Demonstrated success in managing large-scale, multinational finance teams and projects with a strategic impact.

-

Deep knowledge of HGB, ideally IFRS, combined with experience in internal control systems and global financial regulations.

-

Exceptional leadership capabilities, with a proven track record of managing and inspiring diverse, geographically dispersed teams.

-

Strong analytical and strategic thinking skills, with the ability to navigate and influence complex financial environments.

-

Demonstrated experience in building and maintaining relationships with key external stakeholders, including auditors, banks and consultants and senior leadership.

-

Exceptional project management skills, with a history of delivering complex projects within scope, time, and budget constraints.

-

Expertise in negotiating and managing vendor and service provider relationships.

-

Agility to thrive in a dynamic, fast-paced environment, with a deep understanding of business drivers and industry trends.

-

Fluency in both German and English.

## Why Taxfix?

-

A chance to do meaningful, people-centric work with an international team of passionate professionals.

-

Holistic well-being with free mental health coaching sessions.

-

A monthly allowance to spend on an extensive range of services that you can use and roll over as flexibly as you like.

-

Employee stock options for all employees—because everyone deserves to benefit from the success they help to create.

-

30 annual vacation days and flexible working hours.

-

A generous learning budget to support your personal and professional development and guidance from our internal L&D experts.

-

Work from abroad for up to six weeks every year. Just align with your team, and then enjoy your trip.

-

Plenty of opportunities to socialise as a team. In addition to internal meetups, our international team hosts regular get-togethers—virtually and in person when possible.

-

Free tax declaration filing, of course, through the Taxfix app—and internal support for all personal tax-related questions.

-

Have a four-legged friend in your life? We’re happy to have dogs join us in the office.

Excited? So are we. Learn more about [Team Taxfix](https://medium.com/taxfix) on our blog and get a glimpse of our culture.

*At Taxfix, we believe that incredible things happen when you have a wealth of perspectives and experiences. We're proudly committed to equal employment and development opportunities no matter your gender, race, religion, age, sexual orientation, colour, disability, or place of origin. To help mitigate any potential unconscious biases, we ask that you refrain from including your picture, age, or marital status on your CV. Let your experiences speak for themselves.*

Not sure if you meet all the requirements for this role? Please apply anyway. You might bring something special to the team that we hadn't considered previously.

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
