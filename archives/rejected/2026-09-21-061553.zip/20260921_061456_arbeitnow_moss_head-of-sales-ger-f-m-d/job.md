# Head of Sales - GER (f/m/d)

Posted: 2026-09-21T05:40:02Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**At Moss, we give finance professionals the power to automate their day-to-day and make forward-thinking decisions.**

**Our culture is what makes that possible: we play to win, we obsess over quality, and we win as One Moss, and it works. Moss closed a €35 million Series C in August 2026, crossing a €1 billion valuation, and became one of Europe's fintech unicorns. Join us for what's next.**

This role reports to the VP Sales and carries end-to-end accountability for the Germany revenue number. Germany is Moss's most established commercial market: 10-12 Account Executives, a strong GTM model with qualified leads, and a product with genuine traction in the SMB segment.

The person joining will be the most visible leadership presence in the market, and will be measured on how quickly they earn the team's respect through commercial credibility, coaching quality, and being genuinely in the weeds on deals.

**Your responsibilities**

-

Own the Germany revenue number across all Account Executives: conversion rates, deal discipline, average order value, and pipeline health, with a clear mandate to drive a step change in team accountability and urgency.

-

Coach the team directly on live deals: join customer calls, run structured deal reviews, and give specific, actionable feedback that changes how AEs qualify, multi-thread, and close.

-

Diagnose pipeline and performance data to identify where deals stall, where next steps are missing, and where team habits need to change, then translate those findings into concrete processes and targeted interventions.

-

Build and iterate core sales infrastructure: qualification frameworks, mutual action plans, and the weekly coaching cadences the team runs on.

-

Partner with marketing, product, and revenue operations to adapt the go-to-market as Moss's product and customer segmentation evolve, including more complex deal structures and outbound motions ahead.

-

Lead the career and performance conversations the team needs: clear expectations, honest feedback, and visible accountability when the bar is not being met.

**About you**

-

4+ years of full-funnel B2B SaaS sales experience in SMB or mid-market (50-500 employees), with clear evidence of quota attainment in a high-volume, high-velocity environment

-

2+ years leading a direct team of Account Executives with full quota responsibility

-

Demonstrable experience impacting conversion rates, pipeline health, and driving excellent team culture

-

Fluent in German (C2) and English (C1)

In addition, here are the skills and attributes we are looking for:

-

Establishes credibility with a team through deal involvement and coaching quality, not seniority; closes the product knowledge gap fast by leaning in, not waiting to be trained

-

Reads pipeline data with urgency: spots a pattern, forms a hypothesis, tests a fix, and tracks what changes

-

Direct and specific when coaching AEs: concrete feedback on specific deals, not high-level frameworks

-

Brings intrinsic drive and models the accountability and urgency expected of the team

-

Already uses AI tools to improve personal productivity and incorporates them independently into new workflows

**About Moss**

Moss is the Finance AI platform for Europe's mid-sized businesses, giving companies real-time visibility and full control over their spend. By automating card issuing, invoice management and expenses, Moss simplifies financial workflows and frees finance and accounting teams from manual, administrative work.

Founded in Berlin and used by more than 10,000 businesses including Flink, Schufa, n8n and Auto1, Moss has raised €220+ million to date and operates in Germany, the Netherlands, the UK and further EU markets. In August 2026, [Moss closed a €35 million Series C ](https://www.getmoss.com/magazine/moss-series-c?origin-page=en-us%2Fcareers)led by Portage, crossing a €1 billion valuation and becoming one of Europe's newest fintech unicorns. Moss is backed by investors including Valar Ventures, Tiger Global, Global Founders Capital, Cherry Ventures, A-Star.

We're a team of 300+ people from 50+ nationalities across 5 offices in Europe and we hire, reward, and grow people based on [Moss DNA](https://www.linkedin.com/company/moss-finance/life/c2ac8184-5388-4962-ad07-e0bcbfe080f0/?viewAsMember=true): playing to win, obsessing over quality, winning as One Moss. If that's how you want to work, we want to hear from you. - here's **what else to expect:**

-

Top-of-market compensation package, including equity.

-

Our vibrant offices are at the heart of our culture, where in-person time fuels collaboration and connection over weekly breakfasts and Friday demos.

-

Additional benefits include: 20 days “work from abroad”, 600EUR/GBP Learning & Development Budget, and other local benefits.

*Unless stated otherwise, benefits apply to full-time positions (interns and working students receive a tailored package).*

***By applying for the above position, you will confirm that you have reviewed and agreed to our ***[***Data Privacy Policy***](https://www.getmoss.com/privacy-policy)***.***

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
