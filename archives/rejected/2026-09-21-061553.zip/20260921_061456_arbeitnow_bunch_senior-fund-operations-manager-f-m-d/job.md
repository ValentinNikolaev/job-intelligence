# (Senior) Fund Operations Manager (f/m/d)

Posted: 2026-09-21T05:40:06Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

[bunch](https://www.bunch.capital/) is building the backbone of private markets. We are enabling next-gen fund operations with one integrated system that combines secure data infrastructure, AI-powered workflows and expert fund services. If you value ownership, growth through real responsibility, and working with a thoughtful, ambitious team, this role might be for you.

As we scale following our Series B, we are looking for a Senior Fund Operations Manager to play a key role in delivering exceptional fund operations and service quality to our customers. This is not a traditional fund administration role focused on repetitive processing.

We are looking for operators who deeply understand private markets operations, enjoy solving complexity, and want to help shape how modern fund administration should work.

You will work at the intersection of fund operations, client service, and product development - partnering closely with fund managers, investors, product teams, and internal operations functions to deliver a seamless experience across the full fund lifecycle.

We are particularly looking for strong expertise in fund administration, transfer agency operations, fund onboarding, and complex post-close operational processes.

# **Your role**

-

Act as a strategic operational partner to fund managers, supporting them across the day-to-day operations of their funds and delivering an exceptional customer experience.

-

Own and coordinate complex post-close operational processes, including capital calls, distributions, investor reporting cycles, and ongoing fund lifecycle events.

-

Lead operational execution for fund migrations and new fund launches, including the review, reconciliation, and migration of historical data from previous administrators.

-

Own capital call and distribution calculations end-to-end using our automated operational workflows, including the interpretation of LPA clauses, management fee calculations, equalisation mechanics, liquidity buffer assessments, and investor allocation logic.

-

Partner directly with fund managers to explain methodologies, align on assumptions and outputs, incorporate feedback where appropriate, and guide clients towards operationally and legally sound approaches based on fund documentation.

-

Partner with Fund Accounting to support recurring reporting cycles and ensure operational and financial data is complete, accurate, and audit-ready.

-

Support treasury-related workflows, including payment coordination, invoice handling, and operational cash movement processes.

-

Act as a key point of contact for fund managers and investors, helping resolve operational queries with a high level of responsiveness and ownership.

-

Collaborate closely with Product and Engineering teams to shape and improve our internal platform and operational tooling based on real customer workflows and operational pain points.

-

Help drive the evolution of our “full back-office” operating model by identifying opportunities for automation, AI adoption, and scalable operational design.

-

Support, review, and mentor more junior team members, helping establish high standards for quality, operational rigour, and client service.

-

Improve processes, workflows, and documentation across the organisation to increase scalability, transparency, and operational excellence.

# **About you**

-

You bring 3+ years of experience in fund administration, fund operations, transfer agency, or related private markets operations environments.

-

You have strong hands-on experience managing operational fund workflows across the full lifecycle, particularly capital activity, reporting processes, and complex operational coordination.

-

You understand private markets fund structures and are comfortable reviewing LPAs, investment agreements, and related fund documentation to identify operationally relevant terms and requirements.

-

You are highly detail-oriented and able to manage complex operational processes with accuracy and ownership under tight timelines.

-

You are comfortable working cross-functionally with other Fund Accounting, Product, and client-facing teams.

-

You bring a strong service mindset and understand how operational quality directly impacts customer trust and long-term relationships.

-

You enjoy improving systems and processes and are excited by the opportunity to help modernise fund administration through technology and AI.

-

You are proactive, structured, and comfortable operating in a fast-moving, high-growth environment.

-

You enjoy mentoring others and raising the operational quality bar across a team.

-

You are fluent in English; German is a plus.

# **Workplace & Benefits**

-

Competitive salary

-

Customizable benefits package (wellbeing, sport, mobility, food, and more)

-

28 days of vacation, plus 2 company days and local public holidays

-

Remote-flexible hybrid (3 days/week in office)

-

Up to 4 remote calendar weeks a year

-

Work with a diverse team of 120+ bunchies from 40+ countries, with leaders who are best-in-class in their domains

# Hiring Process

-

People Team Interview (30 min) – Meet us & check initial fit

-

Hiring Manager Interview (45 min) – Collaboration, ownership, and culture

-

Case interview (45 min) + VP of Operations screen (30 min) – Collaborative problem-solving and communication skills

-

Final Round (60 min) – Meet our Founders and senior stakeholders

-

Reference calls to confirm your relationship building abilities

**About bunch**

bunch is building the operating infrastructure for the next generation of private markets. We combine AI-powered automation with deep regulatory expertise to replace fragmented spreadsheets and manual processes with one integrated platform across the fund lifecycle, purpose-built for private markets heading toward $32 trillion in Assets Under Management.

We've 4x our ARR in 2025, crossed 150 fund managers and 12,000 LPs on the platform, and just closed our $35M Series B in May 2026. We're looking for ambitious people who want real ownership of hard problems, and who care about building infrastructure that actually matters to the people using it.

____

At bunch, we're committed to an inclusive environment where diversity is valued and celebrated. We provide equal opportunities to all qualified applicants.

We process personal data in line with applicable laws (including GDPR). See our[ Privacy Policy](https://www.bunch.capital/privacy-policy) for details on your rights and how to reach us.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
