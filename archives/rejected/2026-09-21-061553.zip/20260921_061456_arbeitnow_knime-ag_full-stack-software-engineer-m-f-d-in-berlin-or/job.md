# Full-Stack Software Engineer (m/f/d) in Berlin or Konstanz

Posted: 2026-09-21T05:09:37Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**Mission**

Join KNIME in developing a state-of-the-art end-to-end AI and data science platform that helps thousands of professionals around the world to answer their data questions via one of the most reliable and transparent computation frameworks – KNIME workflows.

**Role Overview**

As a Full-Stack Software Engineer in the user-facing Sleek UX team, you will provide meaningful contributions to enhance the day-to-day experience of the people who build with KNIME. Together with a team of outstanding engineers, you will be involved in designing and implementing cross-stack features within KNIME’s family of products, written in Java and Vue. You will be working closely together with our product managers and designers to make the user experience frictionless, enjoyable, and consistent.

**Responsibilities**

-

Build and maintain end-to-end features that provide value to the many people building their data workflows with KNIME.

-

Design and implement robust backend business logic to ensure reliable application performance.

-

Partner with stakeholders to translate product requirements into intuitive user experiences.

-

Leverage AI-assisted coding tools to accelerate development workflows while maintaining strict engineering standards.

-

Uphold code quality through automated testing, peer reviews, and continuous delivery pipelines.

-

Track usage of AI agents within daily development routines to ensure they are deployed for suitable tasks with proper oversight.

**Requirements**

-

Degree in Computer Science or related field.

-

Minimum 5 years of experience in professional software development.

-

High competence in frontend development (Vue, React, or similar).

-

High competence in backend development (Java and modern Java frameworks).

-

Experience in contributing to the architecture of existing software systems.

-

Experience with AI-assisted software engineering (experience with AI agents is a plus).

-

Ability to work effectively in unfamiliar codebases.

-

Solid understanding of full stack development.

-

Practical experience with Golang is a plus.

-

Fluent in English (both verbal and in writing).

**Leveling**

You will be a Full-Stack Software Engineer in the Sleek UX team, reporting to the team lead, with ample opportunity for career and personal growth with KNIME’s comprehensive levelling framework.

**What Success Looks Like**

-

Contribute ideas and technical insight to team discussions and code reviews.

-

Surface and mitigate technical debt, security issues, and architectural risks.

-

Grow knowledge and experience measurably by navigating technical challenges and enhancing user value.

-

Add to a healthy, collaborative environment where trust enables a genuine sense of enjoyment and pride in building great software together

**What we offer**

-

Ownership across the stack: Own features end to end across Java, TypeScript influencing architecture and direction.

-

An exceptional team to work with: highly capable, independent engineers who are a pleasure to work with.

-

Visible impact: Help shape an intuitive experience that thousands of data professionals around the world rely on every day.

-

Deep collaboration in a low-ego, global culture: Work closely with fellow engineers, architects, QA, and UX in an open environment spanning more than 30 nationalities that values transparency, low-ego collaboration.

-

Continuous learning: Hands-on challenges, peer exchange, soft-skill training and learning cafés, and exposure to cutting-edge AI and data-analytics work.

-

Flexibility, health and wellbeing: Hybrid working, flexible hours, subsidised sports or yoga courses, physiotherapy, and flu shots at select locations.

-

Great places to work: Beautiful offices, including one in the heart of Berlin Kreuzberg, along with the everyday things that make office days good: shared breakfasts and lunches, a stocked fruit basket, and celebrations.

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
