# Senior Product Manager (m/f/d)

Posted: 2026-09-21T05:40:02Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**At Moss, we give finance professionals the power to automate their day-to-day and make forward-thinking decisions.**

**Our culture is what makes that possible: we play to win, we obsess over quality, and we win as One Moss, and it works. Moss closed a €35 million Series C in August 2026, crossing a €1 billion valuation, and became one of Europe's fintech unicorns. Join us for what's next.**

Our Product team is seeking a Senior Product Manager to own a product area end-to-end — from problem definition through delivery. You'll shape the roadmap yourself, grounded in direct customer conversations, and partner with a strong cross-functional team of engineers and designers to turn that vision into shipped, measurable impact. You are joining at an exciting time as we are defining how our experience in an AI-first finance world will look like.

**Your responsibilities**

Here's a bit more on what you can expect to be doing day-to-day:

-

Own and manage the product roadmap for your product area end-to-end, from discovery through delivery

-

Define and track OKRs with your squad and report progress

-

Partner closely with Engineering and Design on technical scoping, discovery, and delivery

-

Ground prioritisation in direct conversations with customers and customer-facing teams - build the case for what matters rather than inheriting a backlog

-

Identify and proactively flag dependencies with adjacent product teams before they become delivery risks

-

Represent the customer in cross-functional decisions and trade-off discussions

-

Develop a 12-18 months vision with focus on an AI-first UX

**About you**

We think you’ll need the following **experience and qualifications** to succeed in this role:

-

4+ years of product management experience, including at least 2 years owning a customer-facing product area end-to-end and 2 years in a B2B environment

-

You have demonstrated success in conceptualising, developing, launching, and scaling products within a fast-paced environment

-

Proven experience navigating ambiguous, evidence-light problem spaces and defining solutions from scratch, rather than executing a pre-scoped backlog

-

Experience partnering directly with engineering on technical trade-offs and dependency management

-

Fluent in English (our working language); German is a plus

In addition, here are the **skills and attributes** we are looking for:

-

**Ownership-driven** - you take a problem from ambiguity to a shipped, measurable outcome without waiting to be told what's next. You fundamentally care about the customer.

-

**Evidence-led** - you test whether the data you're using actually answers the question, not just whether it points in the right direction.

-

**Proactive communicator** - you surface risks and dependencies early, rather than after they've caused a problem.

-

**Strategic** - you hold a multi-quarter view of your domain, not just the next ticket.

-

**Collaborative** - you weigh what's best for the wider product organization, not only your own roadmap.

**About Moss**

Moss is the Finance AI platform for Europe's mid-sized businesses, giving companies real-time visibility and full control over their spend. By automating card issuing, invoice management and expenses, Moss simplifies financial workflows and frees finance and accounting teams from manual, administrative work.

Founded in Berlin and used by more than 10,000 businesses including Flink, Schufa, n8n and Auto1, Moss has raised €220+ million to date and operates in Germany, the Netherlands, the UK and further EU markets. In August 2026, [Moss closed a €35 million Series C ](https://www.getmoss.com/magazine/moss-series-c?origin-page=en-us%2Fcareers)led by Portage, crossing a €1 billion valuation and becoming one of Europe's newest fintech unicorns. Moss is backed by investors including Valar Ventures, Tiger Global, Global Founders Capital, Cherry Ventures, A-Star.

We're a team of 300+ people from 50+ nationalities across 5 offices in Europe and we hire, reward, and grow people based on [Moss DNA](https://www.linkedin.com/company/moss-finance/life/c2ac8184-5388-4962-ad07-e0bcbfe080f0/?viewAsMember=true): playing to win, obsessing over quality, winning as One Moss. If that's how you want to work, we want to hear from you. - here's **what else to expect:**

-

Top-of-market compensation package, including equity.

-

Our vibrant offices are at the heart of our culture, where in-person time fuels collaboration and connection over weekly breakfasts and Friday demos.

-

Additional benefits include: 20 days “work from abroad”, 600EUR/GBP Learning & Development Budget, and other local benefits.

*Unless stated otherwise, benefits apply to full-time positions (interns and working students receive a tailored package).*

***By applying for the above position, you will confirm that you have reviewed and agreed to our ***[***Data Privacy Policy***](https://www.getmoss.com/privacy-policy)***.***

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
