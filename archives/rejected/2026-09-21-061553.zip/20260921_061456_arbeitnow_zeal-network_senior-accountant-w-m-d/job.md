# (Senior) Accountant (w/m/d)

Posted: 2026-09-21T02:40:14Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

ZEAL Network SE ist eine international tätige Unternehmensgruppe und Deutschlands führender Anbieter von Online-Lotterien mit den Marken LOTTO24 und Tipp24. Gemeinsam mit Partnern wie ONCE sowie innovativen Angeboten wie Freiheit+, Traumhausverlosung, Traumautoverlosung und ZEAL Ventures gestalten wir die Zukunft digitaler Lotterien und investieren in neue Geschäftsmodelle. Unser vielfältiges Team aus über 350 Mitarbeitenden verbindet Innovationsgeist, Zusammenarbeit und das gemeinsame Ziel, Menschen dabei zu unterstützen, ihre Träume zu verwirklichen.

# **Deine Aufgaben:**

-

Du übernimmst Verantwortung für zentrale Themen der Hauptbuchhaltung, insbesondere Rückstellungen, personalbezogene Buchungen sowie Kontenabstimmungen.

-

Du bist aktiv an der Erstellung von Monats- und Jahresabschlüssen nach IFRS und deren Überleitung nach HGB für die dir zugeordneten Konzerngesellschaften beteiligt und arbeitest dabei eng mit Controlling, Group Reporting und weiteren Finance-Teams (z. B. Nebenbücher, Tax, Treasury und Investor Relatons), sowie anderen Stakeholdern zusammen.

-

Du treibst die kontinuierliche Verbesserung und Automatisierung von Prozessen voran, denkst innovativ und stellst die Einhaltung von Bilanzierungsrichtlinien sowie internen Kontrollsystemen (ICS) sicher.

-

Du pflegst und optimierst relevante Prozessdokumentationen.

-

Du unterstützt aktiv bereichsübergreifende Projekte, insbesondere rund um unsere Online-Plattform sowie bei der Einführung neuer Produkte oder Features.

-

Du trägst durch eine präzise und termingerechte Buchhaltung wesentlich zur Qualität unserer Finanzberichterstattung bei und übernimmst Verantwortung für buchhalterische Themen innerhalb des Hauptbuch-Teams.

# **Was du mitbringst:**

-

Du hast mindestens 5 Jahre Berufserfahrung in der Finanzbuchhaltung bzw. Hauptbuchhaltung.

-

Du verfügst über sehr gute Kenntnisse in MS Excel, sowie gängigen Buchhaltungssystemen (MS Dynamics Business Central oder MS Dynamics NAV sind ein Plus).

-

Du arbeitest selbstständig, strukturiert und zuverlässig und zeichnest dich durch eine proaktive Kommunikation aus.

-

Idealerweise hast du Erfahrung mit Cash Management Software (E-Banking Treasurysysteme).

-

Eine Weiterbildung als Bilanzbuchhalter*in oder eine vergleichbare Qualifikation ist von Vorteil.

-

Erfahrungen mit FloQast oder vergleichbaren Reporting- bzw. Abschlussmanagement-Tools sind ein Plus.

-

Du verfügst über sehr gute Deutsch- und Englischkenntnisse in Wort und Schrift.

# **Was wir anbieten:**

-

Eine moderne, dynamische Unternehmenskultur, basierend auf dem Erfolg eines innovativen E-Commerce-Unternehmens.

-

Ein talentiertes Team aus ambitionierten, gleichgesinnten Kolleg*innen, in dem dein Wissen und deine Ideen wirklich etwas bewegen.

-

Kontinuierliche persönliche Weiterentwicklung, unterstützt durch ein jährliches Weiterbildungsbudget von 1.500 €, das du in deine berufliche Entwicklung investieren kannst.

-

Vertrauen und Eigenverantwortung – kein Mikromanagement, sondern echtes Vertrauen in deine Fähigkeiten, hervorragende Ergebnisse zu liefern.

-

Flexible Arbeitsmöglichkeiten mit einem hybriden Arbeitsmodell, das auf Resultate fokussiert ist.

-

Unbegrenzte Urlaubstage zusätzlich zu deinem regulären Urlaubsanspruch von 30 Tagen pro Jahr.

-

Möglichkeit zu Workations im Ausland über unser WorkFlex-Tool.

-

Monatlicher Mobilitätszuschuss von 30 €, den du für das Verkehrsmittel deiner Wahl nutzen kannst (z. B. das Deutschlandticket), sowie Zugang zu einem Fahrrad-Leasing-Programm.

-

Betriebliche Altersvorsorge in Zusammenarbeit mit Degura zur Absicherung deiner finanziellen Zukunft.

-

Geförderte EGYM WELLPASS-Mitgliedschaft – du zahlst nur 25 € pro Monat und erhältst Zugang zu zahlreichen Fitnessstudios und Sportangeboten in ganz Deutschland.

-

Monatliche Firmenevents sowie regelmäßige Teamaktivitäten und informelle Treffen – besonders beliebt: unsere kostenlose Lunches von Montag bis Donnerstag im Büro!

**Klingt interessant? Wir freuen uns auf deine Bewerbung!**

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
