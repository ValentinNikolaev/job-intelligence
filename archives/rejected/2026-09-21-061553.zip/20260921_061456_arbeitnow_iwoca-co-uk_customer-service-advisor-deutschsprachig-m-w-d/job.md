# Customer Service Advisor - Deutschsprachig (m/w/d)

Posted: 2026-09-21T02:40:12Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

## **Customer Service Advisor - deutschsprachig (m/w/d)**

### **Das Unternehmen**

Gerade für kleine Unternehmen muss es oft schnell gehen. Chancen warten nicht und Liquiditätsengpässe können über Nacht entstehen. Um voranzukommen und zu wachsen, brauchen KMU Finanzierung, die genauso flexibel und reaktionsschnell ist wie sie selbst.

Genau deshalb haben wir iwoca gegründet. Unsere smarte Technologie, moderne Datenanalyse und unser erstklassiger Kundenservice sorgen dafür, dass Unternehmer*innen schnell, sicher und kontrolliert handeln können - genau in den Momenten, in denen es darauf ankommt.

Wir haben bereits mehr als 150.000 Unternehmen mit über 4,5 Milliarden Euro unterstützt. Unser Team setzt alles daran, noch mehr Mittelständler*innen zum Erfolg zu verhelfen - durch besseren Zugang zu Finanzierung und zusätzliche Services, die den Geschäftsalltag einfacher machen. Unsere Mission? Eine Million Unternehmen in ihren entscheidenden Momenten zu unterstützen und so einen nachhaltigen Beitrag zu leisten- sowohl für die Unternehmen selbst, als auch für ihr wirtschaftliches Ökosystem und die deutsche Gesamtwirtschaft.

**Die Stelle**

Als Customer Service Advisor*in bist du die erste Anlaufstelle für potentielle Neukund*innen und langjährige Bestandskund*innen und somit iwocas “Aushängeschild”. Du kümmerst dich um eingehende Anrufe, E-Mails und Webchats und unterstützt Unternehmer*innen sowohl bei allgemeinen Fragen als auch bei der Antragstellung und Folgefinanzierungen. Dabei legst du höchsten Wert auf Kundenservice und ermöglichst unseren Kund*innen durch deine Kommunikation die optimale Nutzung unserer Produkte.

Ein grundlegender Baustein für unseren Erfolg ist es, Kund*innen und Partner*innen von unserer Mission zu überzeugen und zu begeistern - das reicht bei unseren Kund*innen vom Frisörsalon bis zur Zahnarztpraxis und bei unseren Partner*innen von der Finanzberatung bis zu Mitarbeitenden der Bankfiliale.

Wenn Sie mehr über diese Position erfahren möchten, finden Sie hier [den passenden Artikel](https://www.iwoca.de/kredit/ein-tag-von-einer-kundenbetreuerin-bei-iwoca).

Zusammen arbeiten, gemeinsam wachsen: Bei uns erwartet dich ein Umfeld, in dem deine Ideen wirklich etwas bewegen. Dass unsere Kultur nicht nur auf dem Papier gut klingt, zeigt auch unser [Kununu-Score von über 4,4](https://www.kununu.com/de/iwoca-deutschland) – ein Team, auf das man sich jeden Tag freuen kann!

**Die Anforderungen**

Grundlegend:

-

Zeigt Neugier im Umgang mit KI-Tools und Interesse daran, diese weiter zu erlernen. Du nutzt KI bereits sicher in der Praxis, um Probleme zu lösen, effizienter zu arbeiten und die Qualität deiner Arbeit zu verbessern. Dabei zeigst du ein gutes Gespür dafür, wann der Einsatz sinnvoll ist, und kannst deine Entscheidungen nachvollziehbar begründen.

-

Du bist für die allgemeine Kundenzufriedenheit verantwortlich und stellst sicher, dass Kundenanfragen per Telefon, E-Mail oder Webchat bestmöglich und zügig bearbeitet werden.

-

Du beantwortest Fragen zu unseren Produkten, dem Antragsprozess und iwoca allgemein und unterstützt so Neu- und Bestandskund*innen.

-

Du hilfst Unternehmen, ihren Antrag auszufüllen und die notwendigen Dokumente bereitzustellen, die wir für eine Kreditentscheidung benötigen.

-

Du arbeitest mit verschiedenen Teams innerhalb von iwoca zusammen, um das beste Ergebnis für unsere Kund*innen zu erzielen.

-

Du nimmst aktiv an der Weiterentwicklung von iwoca teil, indem du Rückmeldungen von Kund*innen oder Angebote von Wettbewerbern teilst und regelmäßig Feedback zu unseren Prozessen gibst

**Das wichtigste zu dir: **

-

Du hast Spaß an der Kommunikation mit Kund*innen und lebst “Customer Centricity". Für dich ist es die größte Motivation, Erfolge mit unseren Kund*innen zu erzielen.

-

Du hast eine abgeschlossene kaufmännische Ausbildung / betriebswirtschaftliches Studium und kannst mit relevanter Berufserfahrung im Kundenservice punkten (Erfahrungen im Bankenumfeld oder einem Fintech sind ein Plus).

-

Du bist hochmotiviert, organisiert, ein/e echte/r Teamplayer*in und hast eine ‘Hands-on-Mentalität’.

-

Du hast exzellente Kommunikationsfähigkeiten und ausgezeichnete Deutschkenntnisse(C1/C2). Außerdem bringst du Englischkenntnisse mit, sodass Meetings in unserem internationalen Team kein Problem für dich sind.

-

Eine selbstständige, teamorientierte und zuverlässige Arbeitsweise ist für dich selbstverständlich.

### **Das Gehalt**

Wir rechnen mit einem Gehalt zwischen 36.000 € und 44.000 € für diese Stelle. Uns ist es jedoch wichtig, dich fair zu bezahlen, also gib in deiner Bewerbung unbedingt deine Gehaltsvorstellungen an. Wir vergleichen Gehälter regelmäßig mit den marktüblichen Sätzen und führen zusätzlich vierteljährliche Performance- und Gehaltsreviews durch.

### **Die Kultur**

Bei iwoca gewinnt die beste Idee. Unsere Kultur basiert auf eigenständigem Denken, dem Hinterfragen von Annahmen und faktenbasierten Entscheidungen. Wir legen großen Wert auf Lernen und Weiterentwicklung und geben dir die Freiheit, dich in die Richtung zu entwickeln, in der du am wirkungsvollsten bist.

Wir sind ein Technologieunternehmen und glauben an das Potenzial von KI, uns schneller und besser arbeiten zu lassen. Wir schaffen die Voraussetzungen dafür, dass alle im Team jederzeit Zugriff auf die besten Modelle haben – und dass diese Modelle mit unseren Daten arbeiten können. Gleichzeitig unterstützen wir dich dabei, den Umgang mit neuen Tools zu lernen und dich mit ihnen weiterzuentwickeln.

### **Die Büros**

Wir geben uns viel Mühe, iwoca zu einem großartigen Arbeitsplatz zu machen:

-

Büros in Berlin, Frankfurt, London und Leeds mit reichlich Snacks und Getränken

-

Veranstaltungen und Clubs: Von Laufgruppen und Padel bis hin zu monatlichen Ping-Pong- und Billard-Turnieren

### **Die Benefits**

-

Ein smartes, motiviertes und internationales Team (wir vertreten über 35 verschiedene Nationalitäten) mit einem unbändigen Growth-Mindset

-

26 Urlaubstage pro Jahr, plus ein freier Tag an deinem Geburtstag, die Möglichkeit, bis zu fünf Urlaubstage zu kaufen oder zu verkaufen, sowie unbegrenzter (unbezahlter) Urlaub

-

Ein 1-monatiges, voll bezahltes Sabbatical nach 4 Jahren bei iwoca

-

Direkter Zugang zur Unterstützung von zertifizierten Psycholog*innen mit unserem Partner OpenUp für Teammitglieder, die emotionale oder mentale Unterstützung brauchen

-

Zuschuss zur Fitnessstudio-Mitgliedschaft: 25 € für Fit711 oder den Urban Sports Club

-

30 € Zuschuss zum Deutschlandticket

-

Betriebliche Altersvorsorge über Canada Life

-

Top-Standorte: In Frankfurt direkt in der Innenstadt, in Berlin mitten im Prenzlauer Berg

-

Ein bezahlter Tag für Freiwilligenarbeit, an dem du eine gemeinnützige Organisation deiner Wahl unterstützen kannst

-

Voll ausgestattete Kühlschränke in unseren Büros mit allem, was das Herz begehrt: von gesunden Snacks bis hin zu Nervennahrung für den ganzen Tag

-

“Summer Houses” im Süden Europas und “Winter Houses” in den Alpen – bisher ging’s unter anderem nach Frankreich, Italien, Spanien und sogar noch weiter weg

-

Corporate Benefits Rabatte

Und damit das Lernen nie aufhört, bieten wir:

-

Ein persönliches Budget zum Lernen und Weiterbilden für alle

-

Ein Budget für Deutsch/Englisch-Unterricht

-

Vorträge mit internen und externen Referent*innen für das ganze Unternehmen

-

Zugang zu Lernplattformen wie Treehouse

Nützliche Links:

-

Mehr Details und zusätzliche Benefits findest du unter [iwoca Benefits & Richtlinien](https://coda.io/@iwocade/iwoca-benefits-policies-de)

-

Hier findest du unser [iwoca Willkommenspaket für Interviews](https://coda.io/@iwocade/iwoca-interview-welcome-pack-de)

Compensation: €36K – €44K • Offers Bonus

- • €36K – €44K • Offers Bonus

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
