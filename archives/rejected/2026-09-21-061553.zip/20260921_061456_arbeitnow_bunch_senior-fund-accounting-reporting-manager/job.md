# (Senior) Fund Accounting & Reporting Manager

Posted: 2026-09-21T05:40:06Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

[bunch](https://www.bunch.capital/) is building the backbone of private markets. We are enabling next-gen fund operations with one integrated system that combines secure data infrastructure, AI-powered workflows and expert fund services. If you value ownership, growth through real responsibility, and working with a thoughtful, ambitious team, this role might be for you.

We are building the next generation of fund services: technology-driven, automated and seamlessly integrated with product & engineering. In close partnership with Moore TK, a leading advisor in tax and accounting for private capital clients, we combine deep domain expertise with cutting-edge technology.

For our VC & PE clients, we deliver high-quality investor reporting and financials – fast, standardized, and audit-proof. We rely on modern tools, clean data models and automation instead of Excel overload.We develop an integrated end-to-end operating model (accounting, reporting, tax) – standardized, quality-assured and knowledge-driven – thereby creating a foundation for scalable, future-proof fund services.

**Your role**
You will take responsibility for fund accounting and investor reporting for selected VC/PE funds - delivered on time, accurately, and in full compliance with Invest Europe standards. You are more than just a numbers expert: you ensure transparency and trust among fund managers, LPs, and investment teams, making the success of our funds visible.

With your eye for efficiency, you will actively drive the automation and digitization of our processes and work with us to shape the next stage of development for our services. Quality, responsibility and progress are not buzzwords to you, they’re what truly motivate you.

**What You’ll Do**

-

Preparation of accurate investor reports including performance metrics (IRR, TVPI, DPI, RVP, etc.), NAV and carried interest calculations. Ensuring compliance with the Invest Europe guidelines and handling ad-hoc enquiries.

-

Responsibility for annual financial statements including notes, close coordination with auditors, monitoring of quality and timelines as well as risk-oriented reviews.

-

Conduct reviews of accounting data, reconciliations and valuation checks, while continuously improving our quality assurance process.

-

Collaboration with product and engineering teams to further standardise and automate our processes.

-

Support portfolio valuations, waterfall calculations and reviews of capital calls, distributions and management fee calculations.

-

Proactive, reliable communication with GPs, LPs and internal teams (operations, tech).

-

Work closely with the tax team on tax-related matters and ensure consistency between accounting, tax ledger and investor reporting.

**About you**

-

Degree in accounting, finance or controlling (or equivalent)

-

5 years of relevant experience in fund accounting/administration (alternative investments). Experience in integrated setups involving operations, accounting/reporting and tax is a plus.

-

Solid knowledge of Local GAAP and IFRS, experience with further standards (e.g., Luxembourg, US) and audit experience are advantageous.

-

Practical experience with Invest Europe Guidelines and strong command of reporting processes.

-

High IT affinity, experienced in fund-reporting software, advanced Excel / Google Sheets skills; interest in using project management software is a plus.

-

Analytical, detail-oriented, dynamic, deadline-driven and eager to learn continuously.

-

Proficiency in English; German a strong advantage.

**Workplace & Benefits**

-

Take part in a network of people passionate about investment and work closely with the most interesting players in the private market.

-

Benefit from working with a diverse mix of talents, unrivalled energy, and team spirit within a culture of drive and ownership

-

Flexible hours and a hybrid office setup (3 days/week in office)

-

4 remote calendar weeks/year

-

30 days of vacation, 2 company days, plus local public holidays

-

A competitive compensation package

-

A great tech and work setup with everything you need

**About bunch**

bunch is building the operating infrastructure for the next generation of private markets. We combine AI-powered automation with deep regulatory expertise to replace fragmented spreadsheets and manual processes with one integrated platform across the fund lifecycle, purpose-built for private markets heading toward $32 trillion in Assets Under Management.

We've 4x our ARR in 2025, crossed 150 fund managers and 12,000 LPs on the platform, and just closed our $35M Series B in May 2026. We're looking for ambitious people who want real ownership of hard problems, and who care about building infrastructure that actually matters to the people using it.

____

At bunch, we're committed to an inclusive environment where diversity is valued and celebrated. We provide equal opportunities to all qualified applicants.

We process personal data in line with applicable laws (including GDPR). See our[ Privacy Policy](https://www.bunch.capital/privacy-policy) for details on your rights and how to reach us.

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
