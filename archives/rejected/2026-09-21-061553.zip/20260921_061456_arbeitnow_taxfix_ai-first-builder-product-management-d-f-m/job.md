# AI First Builder (Product Management) (d/f/m)

Posted: 2026-09-21T05:40:07Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

# **Our story:**

Every year millions of people are either filing their taxes in fear or giving up on their tax refund altogether. We're working on fixing that. Our intuitive app enables anyone, regardless of education or background, to file their taxes with newfound confidence.

Spread across Germany, Spain and the UK, the team at Taxfix Group with its brands Taxfix, Steuerbot and TaxScouts, is a compassionate group of solution-finders. We speak our minds openly, and with over 400 professionals, including tax experts, developers, and IT security experts, we're rich in ideas and voices. The group has facilitated more than 3.5 billion euros in tax refunds for its customers since its founding in 2016.

# **Your opportunity:**

AI is shifting how the best products get built. The handoffs between product, design, and engineering are slowing us down. The companies moving fastest are doing it with people who own the full loop, from the user problem to the shipped feature, without losing the thread.

At Taxfix, we’re rebuilding our R&D organization around this idea. We call these people **builders**.

A Builder has a primary craft, one they’re genuinely excellent at, but they don’t stop there. They stretch across product, design, and engineering as the situation demands, using AI to cover the gaps. They’re accountable to outcomes, not job descriptions.

Taxfix has put €5 billion back into our customers’ pockets and we aren’t stopping there. We operate in Germany, Spain, and the UK, and we’re in the middle of a genuine AI transformation in how we build and how we’re organized.

Assume there’s no designer to give you a Figma file. No engineer to hand the spec to. The magic is knowing what to build, why, and in what order, then making it happen. If building the thing sounds more natural to you than describing it, this role is for you.

# **Your responsibilities and decisions:**

-

Take a user problem from rough idea to shipped product. Write the brief, design the flow, prototype it, and get it in front of users, with as few handoffs as possible. **Own the full loop.**

-

Compress research, synthesis, and spec-writing from weeks into hours. You reach for AI tools not because you’ve been asked to, but because they’re faster. You know when to trust the output, when to edit it, and when to reject it. **Use AI as a force multiplier.**

-

You structure fuzzy problems, identify what should and shouldn’t be built, and move forward when there are dozens of possible directions. The magic is in the trade-offs, not the feature list. **Turn ambiguous ideas into things users can trust.**

-

No layers, no waiting. You’ll work closely with two or three other people who share the same model. **Work in small, focused teams.**

-

You know the metric your team is trying to move. You measure your week by what changed in user behaviour, not by how many tickets moved to Done. **Be accountable to outcomes, not roadmaps.**

-

You give feedback directly, to anyone, regardless of level. You raise blockers early and in the open. Push back when something’s wrong. **Team player who raises the bar.**

-

The PM who builds the prototype instead of describing it. Who writes the SQL query instead of waiting for an analyst. Who reads the API spec before assuming something is impossible. Who writes code to get it into the hands of users faster. That instinct is what we’re hiring for. **Stretch beyond product.**

# **Your profile:**

## Your craft

-

You have a genuine product craft and a track record to prove it. You’ve shipped things that real people use, and you can point to the metric that moved when you did.

-

You have a builder track record: you’ve made things with AI, not just written specs about them. Shipped products, agent workflows, or tools real users have touched. Any of these count.

-

You’re AI-native by default. You use tools like Claude, Cursor, Lovable, or similar regularly. You follow the AI product space closely and you know the difference between a demo and something production-ready.

-

You’ve built personal AI workflows that make you meaningfully faster. You know when to trust AI output, when to edit it, and when to reject it.

-

You’ve gone from user problem to testable prototype without waiting for a brief to be written for you. The output was good enough that a team shipped from it.

-

Low PM baggage: you’re not attached to how product management "should" be done. You care about outcomes, not territory.

## Your range

-

Across all three disciplines, you can hold your own: in Product you can identify opportunities, assess impact, and prioritize ruthlessly. In Design, you have taste: you know when something looks right but feels wrong. In Engineering, you’ve used AI coding tools to build something real, and you’re not dependent on an engineer to tell you why it’s broken.

## How you work

-

Data fluency: you know the metric you were trying to move, and you can say whether you moved it, with healthy skepticism about what metrics do and don’t tell you.

-

You believe in experimentation and ship with velocity to learn quickly. You know your way around AB tests and are excited to try new data science models to learn faster.

-

You’ve worked on products where getting it wrong has real consequences for real people, and that raised your bar, not lowered it.

-

You’ve found a way through blockers rather than waiting to be unblocked. When something was genuinely impossible, you documented why and moved on.

-

Fluency in English is required.

# This role is not for you if…

-

You’re not genuinely excited about being able to stretch across design and engineering functions.

-

You’ve never built an AI prototype and/or shipped code (vibe coded side project counts)

-

You pride yourself in what you delivered rather than the outcome you achieved.

-

You need certainty, a full brief, or someone else’s research to get started.

-

You don’t believe in fast learning and getting things into customers hands early and use

# **Why Taxfix?**

-

A chance to do meaningful, people-centric work with an international team of passionate professionals.

-

Holistic well-being with free mental health coaching sessions.

-

A monthly allowance to spend on an extensive range of services that you can use and roll over as flexibly as you like.

-

Employee stock options for all employees—because everyone deserves to benefit from the success they help to create.

-

30 annual vacation days and flexible working hours.

-

Work from abroad for up to six weeks every year. Just align with your team, and then enjoy your trip.

-

Plenty of opportunities to socialise as a team. In addition to internal tech meetups, our international team hosts regular get-togethers—virtually and in person when possible.

-

Free tax declaration filing, of course, through the Taxfix app—and internal support for all personal tax-related questions.

-

Have a four-legged friend in your life? We’re happy to have dogs join us in the office.

Excited? So are we. Learn more about [Team Taxfix](https://medium.com/taxfix) on our blog and get a glimpse of our culture.

*At Taxfix, we believe that incredible things happen when you have a wealth of perspectives and experiences. We're proudly committed to equal employment and development opportunities no matter your gender, race, religion, age, sexual orientation, colour, disability, or place of origin. To help mitigate any potential unconscious biases, we ask that you refrain from including your picture, age, or marital status on your CV. Let your experiences speak for themselves.*

Not sure if you meet all the requirements for this role? Please apply anyway. You might bring something special to the team that we hadn't considered previously.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
