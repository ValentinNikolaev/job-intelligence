# Director Venture Scaling - iF Momentum (all genders)

Posted: 2026-09-21T05:09:41Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**Your mission**

Breakthrough technologies can create entirely new industries and companies of global relevance – but only if scientific excellence is matched by exceptional execution, capital and commercial ambition. As Director Venture Scaling iF Momentum, your mission is to help build the next generation of DeepTech champions: companies with the potential to become category leaders, scale internationally and transform their industries. You will work side by side with exceptional founders, opening access to industry, capital and talent while developing iF Momentum into a leading European platform for scaling ambitious DeepTech ventures.

- Take ownership of iF Momentum and its portfolio of highly ambitious DeepTech ventures, helping founders build companies with the potential to become global category leaders while ensuring outstanding program quality, team performance, budget discipline and measurable impact.
- Identify venture-scale opportunities and challenge founders on the fundamental choices that determine scale: market ambition, positioning, value propositions, business models and commercial strategies and the path towards building a globally competitive company.
- Turn technological advantage into commercial momentum by helping ventures move from first market validation towards repeatable customer demand, scalable go-to-market models and international growth.
- Drive commercial and industry scale-up by helping startups develop customer use cases, industrial pilots, venture-client collaborations, licensing models and strategic partnerships – and turn early validation into repeatable commercial traction.
- Build the financing pathway required for scale – from the next institutional funding round to the capital required for industrialisation and international growth – by challenging financial models, cap tables, equity stories, funding strategies, investor materials and data rooms.
- Establish clear milestones and priorities for each venture, continuously challenge whether they are on the fastest credible path towards commercial scale, and deploy program resources where they can create the greatest enterprise value and impact.
- Lead and develop a multidisciplinary venture-building team and coordinate closely with colleagues across the wider Impossible Founders platform.
- Build and activate a high-calibre network of founders, investors, corporates, and experts that can materially accelerate the growth of iF Momentum ventures.
- Secure new sponsorships, strategic partnerships and commercial opportunities, and develop scalable business models and future revenue streams for iF Momentum.

**Your profile**

**What matters most to us**

- You know what separates a promising technology from a venture-scale company and have the judgement to identify opportunities with the potential to build significant, globally competitive businesses.
- You bring substantial professional experience from venture capital, entrepreneurship, venture building, transaction or strategy advisory, venture building, or a fast-growing technology company – ideally with direct exposure to building, financing or scaling ambitious technology ventures.
- You fully understand the specific challenges of DeepTech commercialisation and can bridge the worlds of science, technology, industry and capital.
- You have worked closely with ambitious founders through critical stages of company building – ideally including commercial scale-up, institutional fundraising, international expansion or the creation of a new market category.
- You are confident working with business plans, financial models, cap tables, market and competitive analyses, due diligence materials and investor narratives.
- You have successfully supported startups turn commercial strategy into traction – developing customers, industry partnerships, pilots and go-to-market models that can ultimately scale beyond individual projects.
- You combine strategic judgement with a hands-on mindset and are comfortable challenging founders on ambition, priorities, milestones and difficult decisions.
- You can already bring in an established network of investors, industry partners, and senior operators and know how to activate it when it can materially accelerate a venture.
- You have experience leading teams, projects or portfolios and know how to create clear responsibilities, high quality standards and an effective delivery culture.
- You communicate clearly and credibly with founders, executives, investors, scientists and external partners in an international environment.
- You are fluent in English; German language skills are highly desirable.
**Additionally, it would be a plus if you bring**

- Practical exposure to patents, intellectual property strategies, licensing processes or technology transfer.
- Experience with industrial pilots, venture-client models, joint development agreements or other forms of startup–industry collaboration, or experience scaling your own startup.
- Exposure to public grants, non-dilutive funding or blended financing strategies.

**Why us?**

At Impossible Founders, the people behind the impossible are the most important catalyst. That's why we do everything we can to create a collaborative working environment:

- **Responsibility & autonomy:** You take on real responsibility from day one and have the freedom to actively shape your role and the company. Output counts, and you are given the freedom you need to do your job in the best possible way.
- **Flexible & family-friendly working**: We offer a high degree of flexibility through our hybrid work setup. Mondays are our shared office day, while on other days you can choose whether to work remotely or from the office — depending on what works best for your role, team, and personal circumstances.
- **Meaningful mission & impact:** You will work on projects that address real challenges in AI, climate tech, and beyond. You will achieve impact and visibility by working closely with founders, researchers, and leading partners.
- **Collaborative culture & diversity:** We cultivate a collaborative culture - practical, ego-free, and driven by shared responsibility. Our team is characterized by diversity and openness. The company language is English so that everyone feels welcome.
**Attractive working conditions:**

- 30 days of vacation
- Deutschlandticket
- International team and English as company language
- Central office in a prime location
- Choice of your own hardware

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
