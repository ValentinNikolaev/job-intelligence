# Project Manager - Customer Operations AI & Automation (f/m/d)

Posted: 2026-09-21T02:40:14Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

ZEAL Network SE ist eine dynamische, international tätige Unternehmensgruppe, die seit über 20 Jahren spannende und innovative Lotterieerlebnisse schafft. Als Deutschlands größter Anbieter von Online-Lotterien mit unseren Marken LOTTO24 und Tipp24 und als zuverlässiger Partner von ONCE, der zweitgrößten nationalen Lotterie Spaniens, gestalten wir die Zukunft der Lotteriebranche. Unsere Leidenschaft für Innovation zeigen wir unter anderem mit unseren neuesten Marken Freiheit+ und Traumhausverlosung, die frische und aufregende Träume Wirklichkeit werden lassen. Darüber hinaus investieren wir über ZEAL Ventures in inspirierende E-Commerce-Start-ups wie Omaze und DAYMADE und fördern damit neue Ideen und Chancen.

Unser Team aus über 350 Expert*innen mit unterschiedlichsten Hintergründen ist durch eine visionäre Denkweise, eine Leidenschaft für Zusammenarbeit und das gemeinsame Ziel vereint, Träume zu inspirieren. Bei ZEAL ermutigen wir unsere Mitarbeitenden, groß zu denken und gemeinsam an einem gemeinsamen Zweck zu arbeiten: Menschen zu helfen, ihre Träume zu erkennen und zu verwirklichen.

# **Über die Rolle**

Wir suchen eine:n **Customer Operations AI & Automation Manager (f/m/d)**, der bzw. die die **AI-Agenda innerhalb von Customer Operations** verantwortet. Du bist die treibende Kraft, wenn es darum geht, KI-gestützte Features und Projekte zu identifizieren, umzusetzen und zu monitoren, die Effizienz, Qualität und Customer Experience im gesamten Customer-Operations-Bereich verbessern.

Die Rolle ist **hands-on und stark cross-funktional** und richtet sich an jemanden, der gerne mehrere Projekte gleichzeitig steuert, mit unterschiedlichen Stakeholdern zusammenarbeitet und Spaß daran hat, komplexe oder ineffiziente Prozesse aufzuräumen und smartere Arbeitsweisen zu entwickeln.

Das **Operational Excellence Team** ist zentral innerhalb von Customer Operations angesiedelt und arbeitet eng mit unseren beiden operativen Teams **Customer Support** sowie **Payments, Fraud & Verification** zusammen, um unsere Arbeitsweise kontinuierlich zu verbessern. Unser Ziel ist es, unsere Prozesse schneller, smarter und skalierbarer zu machen.

# Deine Aufgaben:

**AI Implementation & Lifecycle Management**

-

Du steuerst den gesamten Lifecycle von AI-Features innerhalb von Customer Operations – von der ersten Idee und dem Business Case über die Implementierung bis hin zum laufenden Monitoring und der Optimierung

-

Gerade in der Anfangsphase arbeitest du selbst aktiv an der Umsetzung mit und entwickelst gemeinsam mit Customer Support sowie Payments, Fraud & Verification konkrete Use Cases für AI Chat- und AI Email Agents

-

Du verantwortest das Monitoring und Performance Tracking bereits implementierter AI-Features und stellst sicher, dass sie die erwarteten Effizienz- und Qualitätsverbesserungen erzielen

-

Du erkennst Probleme frühzeitig und sorgst dafür, dass diese schnell gelöst werden

-

Du bist die zentrale Ansprechperson für alle AI-bezogenen Themen innerhalb des Bereichs

**Projekt- & Stakeholdermanagement**

-

Du steuerst mehrere Projekte parallel für unterschiedliche Stakeholder und behältst Timelines, Prioritäten und Erwartungen im Blick

-

Du arbeitest eng mit den Customer-Operations-Teams zusammen, verstehst ihre Pain Points und übersetzt diese in konkrete AI- und Automatisierungsmöglichkeiten

-

Du koordinierst die Zusammenarbeit mit verschiedenen cross-funktionalen Stakeholdern und bringst Projekte gemeinsam mit ihnen erfolgreich in die Umsetzung

**Operational Excellence**

-

Du identifizierst proaktiv Ineffizienzen und Möglichkeiten zur Prozessverbesserung – nicht nur dort, wo AI zum Einsatz kommen kann, sondern auch bei allgemeinen Prozessen, die sich vereinfachen oder optimieren lassen

-

Du bringst eine „Think outside the box“-Mentalität mit, hinterfragst bestehende Arbeitsweisen und entwickelst neue, smartere Lösungen

# Was du mitbringst:

-

Sehr gute Deutschkenntnisse in Wort und Schrift sind ein Must-have

-

Nachgewiesene Erfahrung im Bereich Operational Excellence (OPEX) in Customer Support und Fraud Operations

-

Gutes Verständnis dafür, wie AI und Automatisierung im operativen Umfeld eingesetzt werden können, z. B. Chatbots, intelligentes Routing sowie der Aufbau von Prozessen und Workflows

-

Erfahrung darin, mehrere Projekte für unterschiedliche Stakeholder gleichzeitig zu steuern, verbunden mit sehr guten Priorisierungs- und Organisationsfähigkeiten

-

Erfahrung mit dem Lifecycle bereits implementierter Features und Tools – einschließlich Monitoring, Performance Tracking und kontinuierlicher Optimierung

-

Sehr gute Stakeholdermanagement-Skills und Sicherheit in der Zusammenarbeit sowohl mit operativen Teams als auch mit Senior Leadership

-

Ausgeprägte analytische Fähigkeiten und Problemlösungskompetenz sowie Kreativität, um auch nicht offensichtliche Lösungen zu finden

-

Sehr gute Kommunikationsfähigkeiten sowie eine proaktive und transparente Art der Kommunikation

# **Was wir anbieten:**

-

Eine moderne, dynamische Unternehmenskultur, basierend auf dem Erfolg eines innovativen E-Commerce-Unternehmens.

-

Ein talentiertes Team aus ambitionierten, gleichgesinnten Kolleg*innen, in dem dein Wissen und deine Ideen wirklich etwas bewegen.

-

Kontinuierliche persönliche Weiterentwicklung, unterstützt durch ein jährliches Weiterbildungsbudget von 1.500 €, das du in deine berufliche Entwicklung investieren kannst.

-

Vertrauen und Eigenverantwortung – kein Mikromanagement, sondern echtes Vertrauen in deine Fähigkeiten, hervorragende Ergebnisse zu liefern.

-

Flexible Arbeitsmöglichkeiten mit einem hybriden Arbeitsmodell, das auf Resultate fokussiert ist.

-

Unbegrenzte Urlaubstage zusätzlich zu deinem regulären Urlaubsanspruch von 30 Tagen pro Jahr.

-

Möglichkeit zu Workations im Ausland über unser WorkFlex-Tool.

-

Monatlicher Mobilitätszuschuss von 30 €, den du für das Verkehrsmittel deiner Wahl nutzen kannst (z. B. das Deutschlandticket), sowie Zugang zu einem Fahrrad-Leasing-Programm.

-

Betriebliche Altersvorsorge in Zusammenarbeit mit Degura zur Absicherung deiner finanziellen Zukunft.

-

Geförderte EGYM WELLPASS-Mitgliedschaft – du zahlst nur 25 € pro Monat und erhältst Zugang zu zahlreichen Fitnessstudios und Sportangeboten in ganz Deutschland.

-

Monatliche Firmenevents sowie regelmäßige Teamaktivitäten und informelle Treffen – besonders beliebt: unsere kostenlose Lunches von Montag bis Donnerstag im Büro!

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
