# Customer Support Specialist - German / English (f/m/d)

Posted: 2026-09-21T05:40:02Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**At Moss, we give finance professionals the power to automate their day-to-day and make forward-thinking decisions.**

**Our culture is what makes that possible: we play to win, we obsess over quality, and we win as One Moss, and it works. Moss closed a €35 million Series C in August 2026, crossing a €1 billion valuation, and became one of Europe's fintech unicorns. Join us for what's next.**

Our Customer Support team is seeking a** Customer Support Specialist (f/m/d)**.

As a **Customer Support Specialist for our German customers**, you’ll be not only working with our customers, but also gaining valuable insights about the product functionality and impact.

This role isn’t just about resolving queries – in some of the cases you would need to use an **investigative approach**, diving into more complex cases such as potential fraud investigations or payment issues. You will be working with multiple stakeholders across the company, ensuring customer issues are resolved, while continuously learning and growing in a dynamic, fast-paced environment.

**Your responsibilities
**Here's a bit more on what you can expect to be doing day-to-day:

-

You handle customer support queries via calls, chat, and emails, acting as the first point of contact

-

You gain insights about our customers’ needs through your interactions and channel these back to our product team to improve our customer experience

-

You continuously innovate and optimize internal processes with the team to elevate the customer experience* *

-

You not only support our customers, but also the team on topics such as shift management or technical leadership

-

You are working in projects to improve the support experience

**About you
**We think you’ll need the following experience and qualifications to succeed in the role:

-

Previous experience in a customer facing roles

-

Fluent **German (C1) and English (C1) **

In addition, here are the skills and attributes we are looking for:

-

**Methodical thinker -** You have a data-driven, structured and solution-oriented way of working, you work through priorities calmly and systematically.

-

**Proactive problem-solver -** You take ownership in finding solutions to complex problems, and you go one step further in looking for solutions that stop the problem from happening again.

-

**Clear Communicator - **You are able to communicate complex topics to a range of audiences in a clear, concise, and expert manner in written and oral form. You remain composed in difficult situations.

-

**Customer oriented - **You empathize with your customer’s challenges and pain points to better understand their needs and find a swift solution.

-

**Quick learner - **You are quick to understand new technologies, processes, products, and enjoy keeping up to date and learning. You are keen to understand internal and the customers' financial processes.

**About Moss**

Moss is the Finance AI platform for Europe's mid-sized businesses, giving companies real-time visibility and full control over their spend. By automating card issuing, invoice management and expenses, Moss simplifies financial workflows and frees finance and accounting teams from manual, administrative work.

Founded in Berlin and used by more than 10,000 businesses including Flink, Schufa, n8n and Auto1, Moss has raised €220+ million to date and operates in Germany, the Netherlands, the UK and further EU markets. In August 2026, [Moss closed a €35 million Series C ](https://www.getmoss.com/magazine/moss-series-c?origin-page=en-us%2Fcareers)led by Portage, crossing a €1 billion valuation and becoming one of Europe's newest fintech unicorns. Moss is backed by investors including Valar Ventures, Tiger Global, Global Founders Capital, Cherry Ventures, A-Star.

We're a team of 300+ people from 50+ nationalities across 5 offices in Europe and we hire, reward, and grow people based on [Moss DNA](https://www.linkedin.com/company/moss-finance/life/c2ac8184-5388-4962-ad07-e0bcbfe080f0/?viewAsMember=true): playing to win, obsessing over quality, winning as One Moss. If that's how you want to work, we want to hear from you. - here's **what else to expect:**

-

Top-of-market compensation package, including equity.

-

Our vibrant offices are at the heart of our culture, where in-person time fuels collaboration and connection over weekly breakfasts and Friday demos.

-

Additional benefits include: 20 days “work from abroad”, 600EUR/GBP Learning & Development Budget, and other local benefits.

*Unless stated otherwise, benefits apply to full-time positions (interns and working students receive a tailored package).*

***By applying for the above position, you will confirm that you have reviewed and agreed to our ***[***Data Privacy Policy***](https://www.getmoss.com/privacy-policy)***.***

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
