# (Senior / Staff) Product Manager - Growth (f/m/d)

Posted: 2026-09-21T05:40:06Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

[bunch](https://www.bunch.capital/) is building the backbone of private markets. We are enabling next-gen fund operations with one integrated system that combines secure data infrastructure, AI-powered workflows and expert fund services. If you value ownership, growth through real responsibility, and working with a thoughtful, ambitious team, this role might be for you.

## **Your Role**

As a Senior or Staff-level Product Manager for Growth at bunch, you will lead a small Growth squad focused on discovering, validating, and shipping products that open the upmarket segment — larger VC funds and private equity managers whose scale and complexity put them beyond today’s product, but who become our most valuable customers the moment we can serve them.

This is greenfield work. You’ll start from real conversations with target accounts, not an inherited roadmap.

You will:

-

Own the Growth squad end to end: discovery, roadmap, build, and commercial outcomes

-

Work closely with Commercial to identify target accounts worth winning, then get in front of them through discovery calls, demos, and POC scoping

-

Identify recurring problems across upmarket accounts and decide what to build to deliver the highest ROI

-

Prototype fast — with the team and with AI tooling — so an idea becomes something a prospect can touch in weeks or months, not quarters

-

Run experiments knowing most will fail: kill the losers quickly and cheaply, and double down on what converts

-

Convert working prototypes into paid POCs, and paid POCs into signed contracts and product lines

-

Lead a small team of engineers as an active, hands-on product manager

**About you**

-

7+ years in product, with a track record of taking ambiguous, zero-to-one problems to shipped, revenue-generating products

-

Experience operating at senior or staff level, with the ability to run a squad without someone setting direction for you

-

Strong fintech experience and comfort with financial services complexity, regulation, and sophisticated buyers

-

Commercial mindset: you think in business cases and ROI, can hold your own in front of a fund CFO or COO, and understand how discovery turns into POCs and signed contracts

-

Fluent with AI tools such as Claude, Lovable, or similar, especially for research, analysis, and prototyping

-

Experimental by temperament: energised by high-risk, high-reward work and able to design experiments so failures are fast and cheap

-

Comfortable with ambiguity and small teams; you would rather own one hard problem with two people than manage twenty on a roadmap someone else set

-

Exposure to private markets — VC, PE, fund administration, or working inside a GP or fund — is a plus

-

Experience in a growth, new-ventures, or incubation function is a plus

**Success Indicators**

-

A visible pipeline of experiments run, killed, or scaled, with clear reasoning for each

-

Paid MVPs landed with accounts previously out of reach

-

MVPs with a clear path to signed contracts in the upmarket segment

**Workplace & Benefits**

-

Customizable benefits package (wellbeing, sport, mobility, food, and more)

-

28 days of vacation, plus 2 company days and local public holidays

-

Remote-flexible hybrid (3 days/week in office)

-

Up to 4 remote calendar weeks a year

-

A great tech and work setup

-

Work with a diverse team of 120+ bunchies from 40+ countries, with leaders who are best-in-class in their domains

**Hiring process**

-

People Team Interview (30 min) – Meet us & check initial fit

-

Hiring Manager Interview (60 min) – Collaboration, ownership, and product/commercial fit

-

Product Case Interview (60 min) – Problem discovery, experimentation, and prioritisation

-

Cross-functional Interview (60 min) – Commercial collaboration, stakeholder management, and impact

-

Final Round (60 min) – Meet senior leaders from Product and Commercial

Optional Meet & Greet (30 min) – Meet your future teammates

Questions? Reach out to

### **Curious to learn more?**

Get a feel for who we are, how we work, and what we’re building:

-

[About bunch](https://www.bunch.capital/about) – Our mission, product, and journey so far

-

[Case Studies](https://www.bunch.capital/case-studies) – About those who already build on bunch

-

[Gathering insights](https://www.bunch.capital/blog) – Our latest bunch of blog posts

-

[Glossary](https://www.bunch.capital/private-markets-glossary) – Explore commonly used private market terms

**About bunch**

bunch is building the operating infrastructure for the next generation of private markets. We combine AI-powered automation with deep regulatory expertise to replace fragmented spreadsheets and manual processes with one integrated platform across the fund lifecycle, purpose-built for private markets heading toward $32 trillion in Assets Under Management.

We've 4x our ARR in 2025, crossed 150 fund managers and 12,000 LPs on the platform, and just closed our $35M Series B in May 2026. We're looking for ambitious people who want real ownership of hard problems, and who care about building infrastructure that actually matters to the people using it.

____

At bunch, we're committed to an inclusive environment where diversity is valued and celebrated. We provide equal opportunities to all qualified applicants.

We process personal data in line with applicable laws (including GDPR). See our[ Privacy Policy](https://www.bunch.capital/privacy-policy) for details on your rights and how to reach us.

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
