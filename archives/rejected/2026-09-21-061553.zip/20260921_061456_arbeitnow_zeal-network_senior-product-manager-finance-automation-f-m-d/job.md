# Senior Product Manager - Finance Automation (f/m/d)

Posted: 2026-09-21T02:40:14Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

ZEAL Network SE is a dynamic, international group of companies that has been creating exciting and innovative lottery experiences for over 20 years. As Germany’s largest provider of online lotteries through our brands LOTTO24 and Tipp24, and a trusted partner of Spain’s ONCE, the second-largest national lottery, we’re shaping the future of the lottery industry. We are passionate about driving innovation, as demonstrated by our newest brands, Freiheit+ and Traumhausverlosung, which bring fresh and exciting dreams to life. Additionally, through ZEAL Ventures, we invest in inspiring e-commerce start-ups like Omaze and DAYMADE, fueling fresh ideas and opportunities.

Our team of 350+ professionals from diverse backgrounds is united by a visionary mindset, a passion for collaboration, and a commitment to inspire dreams. At ZEAL, we empower our people to think ambitiously and work together toward a shared purpose: helping people imagine and achieve their aspirations.

# The role:

As our** Senior** **Product Manager – Finance Automation Platform (f/m/d)**, you will own a brand-new Core Platform domain focused on Finance. Acting as the primary product partner for our Finance Automation team, you will translate financial and accounting requirements into scalable platform capabilities that automate reconciliation, improve data integrity, and enable reliable financial operations.

This is a true domain ownership role. You will define the product vision, roadmap, and priorities for the Finance Platform domain while working closely with Engineering and Finance to build reliable, scalable solutions. You will also help shape the future scope of the platform, including how far ownership should extend into finance systems and accounting processes.

# Your tasks:

-

Own the product strategy and roadmap for the Finance Platform domain, aligning platform investments with Finance and business priorities.

-

Act as the primary product partner between Finance and Core Platform Engineering, building trusted relationships and translating financial requirements into scalable platform capabilities.

-

Drive the automation of reconciliation, accounting workflows, and financial data processing, reducing manual effort and increasing operational reliability.

-

Translate accounting policies, financial controls, and compliance requirements into platform services, data models, and automation.

-

Ensure the reliability, integrity, and auditability of finance-critical data across platform services and infrastructure changes.

-

Partner with Finance to continuously improve reconciliation accuracy, financial reporting, and audit readiness.

-

Collaborate closely with Payments and other product teams to ensure finance-relevant data is generated consistently and reliably across the platform.

-

Establish scalable ways of working, including transparent prioritisation, request management, and stakeholder communication.

-

Define, monitor, and continuously improve KPIs such as reconciliation accuracy, automation coverage, finance data reliability, manual effort reduction, and audit outcomes.

-

Help shape the long-term ownership model for finance-related platform capabilities together with Finance leadership.

# What you offer us:

-

Proven experience owning a product or platform domain end-to-end, including product strategy, roadmap definition, prioritisation, and stakeholder management.

-

Strong understanding of finance operations, accounting processes, reconciliation, financial controls, or financial reporting.

-

Ability to translate complex business and financial requirements into scalable technical solutions and platform capabilities.

-

Experience working closely with engineering teams on data-intensive or platform products.

-

Excellent stakeholder management skills with the ability to build trusted relationships across Finance, Engineering, and other business functions.

-

Strong analytical mindset with experience using KPIs and data to guide product decisions and measure impact.

-

Comfortable operating in an evolving environment where you help shape product scope, ownership, and long-term strategy.

-

Experience with ERP or accounting systems (e.g. Microsoft Business Central), audit processes, or regulated industries is a strong plus.

# **What we offer you:**

-

A modern, dynamic culture grounded in the success of a leading-edge e-commerce company.

-

A talented team of ambitious, like-minded colleagues where your knowledge and ideas truly make an impact.

-

Ongoing personal growth, supported by an annual development budget of €2,500 to invest in your professional development.

-

Trust and autonomy, no micromanagement, just confidence in your ability to deliver and excel.

-

Flexible work options with a hybrid setup focused on results.

-

Unlimited vacation days in addition to your yearly 30-day vacation allowance.

-

Opportunity for workations abroad using our WorkFlex tool.

-

Monthly mobility allowance of €30 to use on the mobility option of your choice (e.g., the Deutschlandticket), plus access to a company bike leasing program.

-

Company pension scheme, provided in partnership with Degura, to support your future financial security.

-

Subsidized EGYM WELLPASS membership, with a contribution of only €25 per month, giving you access to a wide range of gyms and sports options across Germany.

-

Monthly company events, team activities, and informal gatherings, including our popular company-wide lunches provided four days a week.

Not ticking every box or think you’ve got that unique set of skills we haven’t realized we need? Get in touch anyway, we’re always looking to add great people!

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
