# Director of Customer Support

Posted: 2026-09-16T23:55:15Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**What Makes Cloudbeds Unique**
At Cloudbeds, we're not just building software, we’re transforming hospitality. Our intelligently designed platform powers properties across 150 countries, processing billions in bookings annually. From independent properties to hotel groups, we help hoteliers transform operations and uplevel their commercial strategy through a unified platform that integrates with hundreds of partners. And we do it with a completely remote team. Imagine working alongside global innovators to build AI-powered solutions that solve hoteliers' biggest challenges. Since our founding in 2012, we've become the World's Best Hotel PMS Solutions Provider and landed on Deloitte's Technology Fast 500 again in 2024, but we're just getting started.

**How You'll Make an Impact:**

As Director of Customer Support, you will lead our global support organization and own the experience hoteliers have when they need us most. This is a builder's role at a pivotal moment. We are transforming reactive support into proactive partnership, combining AI at scale with the empathy of true hospitality. You will be accountable for the health of the queue, the quality of every answer, and the wellbeing of the people who deliver it — raising first contact resolution and driving down resolution times while keeping the customer experience human.

**Our Customer Support Team:**

Forget the stuffy corporate office. We are a completely remote global team of innovators and hospitality experts. The support organization spans roughly 66 coaches and advanced support specialists across LATAM, EMEA, and APAC, organized into teams led by experienced leads and senior leads. We are our clients' secret weapon and trusted advisor, and we are rebuilding how support works from the ground up.

**What You Bring to the Team:****
**

- Lead a global, multi-time-zone customer support organization with full accountability for first contact resolution, response and resolution times, CSAT, and retention

- Bring a track record of moving the metrics that matter and rebuilding team health and morale after periods of high pressure

- Apply deep hospitality or hospitality-technology experience to every escalation and process decision — you understand property operations, distribution, and what downtime costs a hotelier in real time

- Deploy AI-assisted support with strong instincts for where it helps the hotelier and where it gets in the way — accuracy over scale

- Translate technical and operational concepts into clear, practical guidance for non-technical customers and internal teams

- Lead other leaders with empathy and accountability across multiple regions, languages, and cultures

**What Sets You Up for Success:****
**

- 8+ years in customer support or service, including at least 4 years leading teams with experience leading other leaders

- Direct experience leading customer support for a SaaS or software product — not solely hotel, resort, or travel/reservations operations — you know what it means to own a queue, a ticket, and a CSAT score in a software environment

- Direct, hands-on hotel or resort operations experience in a guest-facing role (front desk, guest services, GM, or similar) — you understand property operations and distribution, and what downtime costs a hotelier because you've lived it on the floor, not just adjacent to it

- Bachelor's degree or equivalent experience in hospitality, business, or technology

- Experience scaling a high-volume support function through significant change or transformation

- Excellent crisis management and escalation handling with confident cross-functional alignment across Product, Onboarding, and Account Management

- A bias toward fixing root causes — you challenge process that creates unnecessary work and prove a fix by hand before automating it

- Experience leading distributed teams across multiple regions, languages, and cultures

**Bonus Skills to Stand Out :**

- Senior leadership experience managing managers across multiple regions

- Advanced degree in Hospitality or Business

- Experience standing up a customer recovery or save motion for at-risk accounts

#LI-AM1
#LI-REMOTE

**What to Expect - Your Journey with Us**
Behind Cloudbeds' revolutionary technology is a team of redefining what's possible in hospitality. We're 650+ employees across 40+ countries, bringing together elite engineers, AI architects, world-class designers, and hospitality veterans to solve challenges others haven't dared to tackle. Our diverse team speaks 30+ languages, but we all share one language: a passion for innovation and travel. From pioneering breakthroughs in machine learning to revolutionizing how hotels operate, we're not just watching the future of hospitality unfold – we're coding it, designing it, writing it, and shipping it. If you're ready to work alongside some of the brightest minds in tech who are obsessed with using AI to transform a trillion-dollar industry, this is your chance to be part of something extraordinary.

Learn more online at [cloudbeds.com](https://www.cloudbeds.com/)

**Company [Awards](https://www.cloudbeds.com/press/?press_type=company-news&news_category=awards):**

- Best All-In-One Hotel Management System | HotelTechAwards (2025)

- Overall 10 Best Places to Work | HotelTechAwards (2025)

- Most Loved Workplace® Certified (2024)

- Top 10 People’s Choice (2024)

- Deloitte Technology Fast 500 (2024)

**Discover our Benefits:**

- Remote First, Remote Always

- PTO in accordance with local labor requirements

- Monthly Wellness Fridays - enjoy an extra-long weekend every month

- Fully Paid Parental Leave

- Home office stipend based on country of residency

- Professional development courses in Cloudbeds University

- Access to professional development, including manager training, upskilling and knowledge transfer

**Everyone is Welcome - A Culture of Inclusion **

Cloudbeds is proud to be an Equal Opportunity Employer that celebrates the diversity in our global team! We do not discriminate based upon race, religion, color, national origin, gender (including pregnancy, childbirth, or related medical conditions), sexual orientation, gender identity, gender expression, age, status as a protected veteran, status as an individual with a disability, or other applicable legally protected characteristics.

Cloudbeds is committed to the full inclusion of all qualified individuals. As part of this commitment, Cloudbeds will ensure that persons with disabilities are provided reasonable accommodations in the hiring process. We encourage deaf, hard-of-hearing, deaf-blind, and deaf-disabled individuals to apply. If reasonable accommodation is needed to participate in the job application or interview process or to perform essential job functions, please contact our HR team by phone at (858) 201-7832 or via email at

To all Staffing and Recruiting Agencies: Our Careers Site is only for individuals seeking a job at Cloudbeds. Staffing, recruiting agencies, and individuals being represented by an agency are not authorized to use this site or to submit applications, and any such submissions will be considered unsolicited. Cloudbeds does not accept unsolicited resumes or applications from agencies. Please do not forward resumes to our jobs alias, Cloudbeds employees, or any other company location. Cloudbeds is not responsible for any fees related to unsolicited resumes/applications.

#LI-REMOTE

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
