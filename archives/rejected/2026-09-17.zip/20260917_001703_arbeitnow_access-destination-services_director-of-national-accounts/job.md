# Director of National Accounts

Posted: 2026-09-16T23:40:11Z

## Rejection

- Category: tech_stack
- Reason: role does not mention Go/Golang or PHP

**Access Your Potential.**
Join us to create and deliver experiences that inspire people, spark connection, and bring imagination to life—while having a lot of fun doing it.

We are seeking a Director of National Accounts!

## **About the Job**

The Director of National Accounts plays a key leadership role in driving strategic growth across Access’ high-value national clients and prospects. This person will develop and execute account strategies designed to expand revenue, strengthen client loyalty, and deepen long-term partnerships.

This role is highly focused on proactive business development, cross-market collaboration, and ensuring national account strategies are executed consistently across local teams. The Director will serve as both a strategic partner and relationship leader, representing Access at the highest levels of client engagement.

## **What You'll Be Doing**

-

Manage a national account pipeline exceeding $12.5M annually, driving progress against revenue, new business, and account growth goals.

-

Develop and execute strategic account plans that strengthen year-over-year relationships and expand client share-of-wallet.

-

Build and maintain relationships with key client stakeholders, gathering insights and ensuring proposals and deliverables align with their priorities.

-

Represent Access in the field, supporting local teams and maintaining strong client engagement across markets.

-

Prepare strategic presentations, manage RFP responses, and ensure timely, thoughtful follow-up with clients and prospects.

-

Partner closely with National Sales, local offices, and cross-functional teams to deliver a seamless and consistent client experience.

-

Influence teams across markets to execute national strategies effectively, even without direct reporting authority.

-

Use market intelligence and industry trends to identify opportunities and shape strategic account plans.

## **About Access**

Access is a destination management company that designs shared experiences for some of the world’s most recognizable brands. From intimate incentive trips to large-scale meetings, trainings, and sales-driven events, we bring people together through thoughtful design, smart sourcing, and seamless execution. Our work blends imagination with intention. We dream big, then we build it right.

## **About You**

We know that there’s no one in the world like you. And we know that you have a lot to offer the next company you work with. Below is a list of “nice-to-haves”, but don’t let those deter you from applying. Access believes that an inclusive team and culture is important. We seek applicants from all backgrounds to ensure we get the best, most creative talent on our team.

Nice-to-haves:

-

7+ years of successful sales and account management experience within the DMC, hospitality, or a related industry.

-

Experience leading large, multi-market national or enterprise accounts.

-

Demonstrated ability to generate **$3.5M+ in self-generated business annually**.

-

Experience navigating complex account relationships, multiple decision makers, and enterprise-level buying processes.

-

Strong financial and business acumen, including pipeline management, forecasting, profitability, and budgeting considerations.

-

Advanced negotiation experience involving MSAs, large-scale program contracts, and complex service agreements.

-

Executive presence and confidence working with senior-level stakeholders across Procurement, Marketing, Sales Leadership, and the C-Suite.

-

Strong cross-functional leadership skills with the ability to influence without direct authority.

-

Experience mentoring sellers or contributing to team development and best-practice sharing.

-

Bachelor’s degree in Business, Hospitality Management, Marketing, or a related field preferred.

## **What Success Looks Like**

-

National Accounts deliver consistent revenue growth while meeting or exceeding defined revenue, new business, and gross profit goals.

-

Strategic account plans lead to deeper client engagement, stronger relationships, and increased share-of-wallet.

-

Clients view Access as a trusted strategic partner, resulting in repeat business, multi-year partnerships, and strong feedback.

-

National Sales, local offices, and cross-functional partners work together seamlessly to deliver consistent service across destinations.

-

Competitive opportunities are supported through strong client engagement, strategic presentations, and timely RFP responses.

-

You represent Access with professionalism and credibility, strengthening our reputation and presence in the marketplace.

## **Why Access?**

**CULTURE & EXTRAS**

-

Certified as a Great Place to Work – 3 years in a row and counting!

-

55+ years in the industry!

-

Women-owned and women-led

-

Fun, creative, and supportive culture

-

Focus on recognition and employee value – including annual and quarterly awards

-

Paid day off to serve your local community

-

Annual all-company retreat to connect, learn, and have fun together

-

Annual qualifier-based incentive trip for top performers (certain departments eligible)

-

Regional team outings

-

Monthly companywide meetings to connect, learn, and celebrate wins

**COMPENSATION**

-

Highly competitive total compensation, including strong base salary and quarterly bonuses

-

Very strong performance-based quarterly commission plans

-

401k with company match (eligible after 1 year – up to 4% of salary matched, vested immediately)

-

Monthly cell phone stipend

**WORK LIFE BALANCE**

-

Flexible schedule opportunities

-

Generous PTO

-

Sick days

-

9 full holidays

-

5 half days off prior to holidays to unplug early

-

2 floating holidays off to be used on holidays of your choice

-

½ day Fridays in July & August (based on achievement of goals)

**HEALTH, WELLNESS, AND FAMILY**

-

Extensive menu of health plans to choose from

-

Paid parental leave

-

Pet insurance program

-

Employee Assistance Plan (EAP)

**PROFESSIONAL DEVELOPMENT**

-

Mentorship program

-

“Masterclasses” in industry/department-specific topics

-

State-of-the-art technology platforms and tools – including training

-

Annual and monthly meeting content that focuses on professional development

*What are you waiting for? Scroll back to the top and apply!*

Access is committed to building a diverse and inclusive team. We are a proud Equal Opportunity Employer and prohibit discrimination based on race, color, religion, sex (including gender identity, sexual orientation, and pregnancy), national origin, age, disability, or genetic information. We will ensure that individuals with disabilities are provided reasonable accommodation to participate in the application or interview process. If you need assistance or an accommodation due to a disability, you may contact us at Access is committed to building a diverse and inclusive team. We are a proud Equal Opportunity Employer and prohibit discrimination based on race, color, religion, sex (including gender identity, sexual orientation, and pregnancy), national origin, age, disability, or genetic information. We will ensure that individuals with disabilities are provided reasonable accommodation to participate in the application or interview process. If you need assistance or an accommodation due to a disability, you may contact us at -----

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
