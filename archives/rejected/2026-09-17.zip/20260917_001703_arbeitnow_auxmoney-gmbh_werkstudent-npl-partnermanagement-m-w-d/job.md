# Werkstudent NPL & Partnermanagement (m/w/d)

Posted: 2026-09-16T23:09:57Z

## Rejection

- Category: language_requirement
- Reason: hard German language requirement without English green light

**Dein neues Team:**

Du willst verstehen, wie Forderungsverkauf, Partnersteuerung und saubere Prozesskontrollen in der Praxis zusammenspielen? Im Bereich NPL & Partnermanagement verantworten wir die operativen Abläufe rund um den Forderungsverkauf und die Zusammenarbeit mit unseren Partnern. Dabei sorgen wir dafür, dass unsere NPL- und Partnerprozesse zuverlässig, datenbasiert und revisionssicher dokumentiert laufen. Als Werkstudent (m/w/d) unterstützt Du uns im Tagesgeschäft und arbeitest eng mit internen Schnittstellen sowie externen Partnern zusammen.

**Das erwartet Dich:**

- **Monitoring & IKS:** Du unterstützt beim Monitoring laufender NPL- und Partnerprozesse sowie bei monatlichen IKS-Kontrollen und dokumentierst Nachweise nachvollziehbar in unseren internen Systemen.
- **Zahlungsverbuchung & Reporting:** Du spielst Zahlungen in unsere interne Inkasso-Software ein, führst Kontrollen und Abgleiche durch und erstellst Zahlungsberichte.
- **Datenchecks & Abgleiche:** Du führst vordefinierte SQL-Checks aus, passt diese bei Bedarf minimal an und erstellst Grundgesamtheiten inklusive CSV-Exporten sowie Duplikats-, Schnittmengen- und Plausibilitätsprüfungen.
- **Forderungsverkauf & Rückabwicklung:** Du unterstützt bei der Vorbereitung und operativen Abwicklung von Forderungsverkäufen an Debt Collection Agencies (DCAs), bearbeitest definierte Sonderfälle, begleitest Prozess- und Dateitransfers und dokumentierst Vorgänge sauber im Ticket-System.
- **Partnerabstimmung & Nachverfolgung:** Du stimmst Dich mit unserer Partnerbank SWK, den DCAs sowie intern mit IT ab, klärst Rückfragen und hältst offene Punkte konsequent nach.
- **DCA-Statistiken & Präsentation:** Du bereitest DCA-Statistiken auf und unterstützt bei deren Vorstellung.
- **Maximale Flexibilität:** Du arbeitest hybrid mit einem festen Präsenztag pro Woche in Düsseldorf und ansonsten im Homeoffice innerhalb Deutschlands.

**Das bringst Du mit:**

- **Studium:** Du bist aktuell in einem Studium der BWL, Wirtschaftswissenschaften, (Wirtschafts-)Informatik oder in einem vergleichbaren Studiengang eingeschrieben.
- **Erste Praxiserfahrung:** Du hast erste Erfahrung im Umgang mit Daten, Reports oder operativen Abläufen gesammelt, zum Beispiel durch Praktika, eine Werkstudierendentätigkeit oder eine Ausbildung, und idealerweise bringst Du erste SQL-Kenntnisse mit.
- **Struktur & Sorgfalt:** Du arbeitest zuverlässig, sorgfältig und strukturiert und übernimmst Aufgaben eigenständig.
- **Datenaffinität:** Du hast Freude an Zahlen, Tabellen und Listen und ein gutes Verständnis für Abgleiche und Plausibilitätsprüfungen.
- **Tool-Sicherheit:** Du verfügst über sehr gute MS-Office-Kenntnisse, insbesondere in Excel, und findest Dich schnell in neuen Systemen zurecht.
- **Kommunikation:** Du bereitest Themen klar und übersichtlich auf und kommunizierst gerne mit unterschiedlichen Ansprechpartnerinnen und Ansprechpartner.
- **Sprachen:** Du verfügst über sehr gute Deutschkenntnisse und gute Englischkenntnisse in Wort und Schrift.

**Das bringen wir mit: **

- **Flexible Arbeitszeiten**: Gestalte Deinen Arbeitstag so, dass er optimal zu Deinem Studium passt – wir unterstützen Deine individuellen Bedürfnisse!
- **Möglichkeit zur Arbeit im Homeoffice**: Arbeite dort, wo Du Dich am wohlsten fühlst. Ob im Büro oder von zu Hause – Du entscheidest!
- **Flache Hierarchien**: Bei uns wird Teamarbeit großgeschrieben! Du hast direkten Kontakt zu Entscheidungsträgern und kannst Deine Ideen einbringen.
- **Vielfältige Gestaltungs- und Entwicklungsmöglichkeiten**: Du hast die Chance, Deine eigenen Projekte zu leiten und Deine Fähigkeiten in einem dynamischen Umfeld weiterzuentwickeln.
- **Zahlreiche bereichsübergreifende Events**: Knüpfe wertvolle Kontakte und erlebe unser Team bei spannenden Veranstaltungen und Teamevents.
- **Vergünstigte Mitgliedschaft bei Fitness First oder Urban Sports Club**: Bleib fit und gesund – wir fördern Dein Wohlbefinden mit attraktiven Fitnessangeboten!
- **Täglich frisches Obst, endlos Kaffee, Tee und Wasser**: Genieße eine gesunde Snack- und Getränkebar, die Dir hilft, energisch durch den Tag zu kommen.
- **Rabatte über Corporate Benefits**: Profitiere von exklusiven Angeboten und Rabatten auf zahlreiche Produkte und Dienstleistungen – ein zusätzliches Plus für Deinen Geldbeutel!
**Schließe Dich unserem Team an und bewirb Dich noch heute! Vergiss nicht, uns Dein voraussichtliches Ende des Studiums, Deinen gewünschten Stundenlohn sowie Dein nächstmögliches Startdatum mitzuteilen. Wir freuen uns darauf, Deine Bewerbung zu erhalten!**

Für uns als Arbeitgeber sind Chancengleichheit und Diversität besonders wichtig. Daher freuen wir uns auf Bewerbungen von Müttern, Vätern, Menschen mit Behinderungen und Menschen aus der LGBTQIA+ Community. Bitte teile uns gerne mit, wenn wir z.B. ein geschlechtsneutrales Pronomen verwenden sollen, Du einen barrierefreien Zugang zu unserem Büro benötigst oder wir mehr Zeit für den Bewerbungsprozess einplanen sollen.

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
