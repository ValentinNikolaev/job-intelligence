# Senior Backend Engineer (m/w/d)

Posted: 2026-09-16T20:55:07Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

You don't want another role where someone else owns the architecture and you own the tickets. Here you pick the technology, design the architecture, and set the standards the backend runs on. 40,000 buyers, 20+ countries, 130,000 vehicles sold a year through one auction backend, and you decide how it scales.

**Location:** Central Berlin — hybrid, 3 days in the office and 2 days from home.

###

### About us

CarOnSale is the AI-powered platform for B2B used car trading in Europe. Over 40,000 buyers from more than 20 countries trade on our platform — and 85% of inventory is exclusive to us. We connect software, pricing intelligence, logistics and financing in one layer — as the operating system for an entire industry.

***One Platform. One Profit Engine.***

###

### Your responsibilities

- You own backend development end to end: technology selection, architecture design, and implementation of the features that carry platform performance and scale

- You build AI-first. Coding agents, LLMs and AI-assisted development are part of the daily workflow here, not a pilot project

- You set the standards: code quality benchmarks, development practices and CI/CD pipelines, agreed cross-functionally and enforced in review

- You mentor the engineers around you, share what you know, and raise the bar on backend practice

- You challenge how we work. When our approach is wrong, you say so and you bring the better one

###

### What you bring

- 8+ years in software engineering, 5+ of them focused on backend

- Deep TypeScript proficiency, with strong Node.js, NestJS and PostgreSQL experience

- A proven mentorship track record: you have coached engineers and raised the standard around you

- Solid command of Git, Docker and CI/CD pipelines

- Comfortable in Scrum or Kanban, working with JIRA and Confluence

- English at C1 level, written and spoken, for daily work with an international team

- AI-native working style: you use AI tools in your own development workflow and have real judgement about where they accelerate you and where they don't

- Based in Berlin or ready to relocate

**Nice to have**

- WebSockets or other real-time systems

- Search frameworks such as Elasticsearch or Lucene

- Automotive or B2B trading background

- Conversational German

###

### What to expect from us

- Hybrid working: 3 days in office, 2 days remote – plus 25 "Work from Anywhere" days per year

- 28 days annual leave

- 2× annual career & development conversations

- Company pension with 20% employer contribution

- Fully paid Deutschlandticket (public transport)

- FitX membership or Urban Sports Club subsidy

- Virtual stock options — share in the upside

- Modern IT setup for your day-to-day work

- Structured onboarding with buddy programme and social events

- Lived diversity: active women's network, meditation & prayer room

**Apply now — your CV is enough.**

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
