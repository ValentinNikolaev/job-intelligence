# CRM & Subscription Manager*in (m/w/d)

Posted: 2026-09-06T18:30:24Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Wir sind Fabio und Luis, die Gründer von Hunderunde. Wir haben Hunderunde gestartet, weil wir überzeugt sind: Hunde verdienen natürliche Ernährung, die wirklich hilft. Unsere pflanzenbasierten Toppings unterstützen Verdauung, Haut & Fell und das allgemeine Wohlbefinden von Hunden, tierärztlich mitentwickelt und mit echtem Anspruch an Wirksamkeit. Für uns ist das keine reine Business-Idee: Ein Teil dessen, was wir verdienen, geht an ein Straßenhund-Rettungsprojekt in Rumänien, Tierschutz gehört für uns genauso zur Marke wie das Produkt selbst.

## Aufgaben

Deine Aufgabe: Diese Reise so zu gestalten, dass mehr Menschen bleiben, statt nach der ersten Bestellung wieder zu verschwinden.

- **Klaviyo als dein Zuhause:** Du baust, testest und optimierst unsere E-Mail-Flows (Post-Purchase, Win-Back, Wirkungsfenster-Check-ins bei Woche 2 & 6, Kündigungs-Flows) und Kampagnen. Segmentierung ist für dich kein Buzzword, sondern Alltag.

- **WhatsApp-Marketing:** Du entwickelst unseren WhatsApp-Kanal als zweiten Lifecycle-Kanal weiter – von Onboarding-Sequenzen bis zu Sparplan-Reminder und Winback.

- **Sparplan-Steuerung:** Du bist verantwortlich dafür, dass unser Abo wächst und weniger Menschen kündigen. Du kennst die technischen Grenzen von ReCharge (z. B. bei Rabatt-Mechaniken für Bestandskunden) und findest trotzdem smarte Lösungen – Pause-Angebote statt Kündigung, Win-Back-Flows für reversible Absprünge, Intervall-Anpassungen.

- **Datengetriebenes Arbeiten:** Du liest unsere Kundendaten (Shopify, ReCharge, Klaviyo, Umfragen) und leitest daraus konkrete Maßnahmen ab – nicht nur Reports, sondern Taten.

- **A/B-Testing & Optimierung:** Betreffzeilen, Sendezeitpunkte, Flow-Logik – du testest kontinuierlich und triffst Entscheidungen auf Basis von Daten, nicht Bauchgefühl.

- **Zusammenarbeit:** Du arbeitest eng mit uns Gründern, unserem Content-/Copy-Bereich und unserer Kundenservice-Kollegin zusammen, um Kommunikation konsistent gegenüber unseren Kunden zu halten.

## Qualifikation

Das bringst du mit:

- 2–3+ Jahre Erfahrung als CRM Manager, Retention Manager oder E-Mail Marketing Manager – idealerweise bei einer D2C-Marke

- Praxiserfahrung mit Klaviyo (oder vergleichbarem) auf fortgeschrittenem Niveau: Flows, Segmentierung, Deliverability

- Erfahrung mit Subscription-/Abo-Modellen im E-Commerce (Kein Muss, aber klares Plus)

- Erfahrung mit WhatsApp-Marketing oder die Bereitschaft, dich da schnell reinzufuchsen

- Zahlenaffinität: Du liest Kohorten, Churn-Raten und Flow-Performance und ziehst daraus die richtigen Schlüsse

- Sehr gutes Deutsch (Wort und Schrift) – unsere Kommunikation ist warm, persönlich, auf Augenhöhe mit unseren Kundinnen

**Nice-to-haves:**

- Erfahrung im Pet-, Food-Supplement- oder Wellness-Bereich

- Shopify-Kenntnisse

- Erste Erfahrung mit Compliance-Anforderungen bei gesundheitsbezogenen Claims (wir arbeiten mit tierärztlich begleiteten Studien und einem strikten Wording-Regelwerk)

- Gespür für Copy – du musst keine Texter:in sein, aber ein gutes Gefühl für Ton und Sprache hilft enorm

## Benefits

Was wir bieten

- Verantwortung für einen der wichtigsten Hebel im Unternehmen – kein Zuarbeiten, sondern echte Ownership über CRM & Subcription Model

- Direkter Draht zu den Gründern, kurze Entscheidungswege, kein Konzern-Prozess

- Ein Produkt, hinter dem du stehen kannst: pflanzenbasierte Toppings, tierärztlich mitentwickelt, mit echtem Tierschutz-Engagement

- Ein Team, das schnell wächst und in dem deine Arbeit direkt sichtbare Wirkung hat

Klingt nach dir?

Schick uns deinen Lebenslauf und ein paar Zeilen, warum du zu uns passt.

Wir freuen uns auf dich.

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
