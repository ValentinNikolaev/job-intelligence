# Senior Software Engineer (Capacity and Quota Management)

Posted: 2026-08-16T23:55:13Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**About Nebius:**

Nebius is leading a new era in cloud infrastructure for the global AI economy. We are building a full-stack AI cloud platform that supports developers and enterprises from data and model training through to production deployment, without the cost and complexity of building large in-house AI/ML infrastructure.

Built by engineers, for engineers. From large-scale GPU orchestration to inference optimization, we own the hard problems across compute, storage, networking and applied AI.

Listed on Nasdaq (NBIS) and headquartered in Amsterdam, we have a global footprint with R&D hubs across Europe, the UK, North America and Israel. Our team of 1,500+ includes hundreds of engineers with deep expertise across hardware, software and AI R&D.

#### The role:

We are looking for a Senior Software Engineer to join the team building the Capacity and Quota Management control plane — the system that decides who gets compute, when, and how much.

Idle GPUs are waste. Overallocated ones are a contract you can't keep. Our platform consists of two core components: a capacity reservation engine managing guaranteed GPU reservations and their lifecycle, including rebalancing and auto-reclamation logic; and a Quotas Control Plane that manages quotas across all Nebius services, handles customer quota requests, and runs the algorithms that distribute resources. Both are exposed through APIs that give external customers, internal users, and downstream services visibility and control over their limits.
This is a high-ownership role. You will define how Capacity and Quota Management matures, from the technical foundations to the tradeoffs that outlast any single feature.

#### We expect you to have:

-

5+ years of professional software engineering experience

-

Strong knowledge of Python or willingness to quickly become productive with our technology stack

-

Experience building distributed backend systems and microservice architectures

-

Understanding of distributed transactions, consistency models, and reliable asynchronous workflows

-

Strong communication and ownership mindset

**Benefits & Perks:**

- Competitive compensation

- Career growth and learning opportunities

- Flexibility and ownership

- Collaborative and innovative culture

- Opportunity to work on impactful AI projects

- International environment and talented teams

**What's it like to work at Nebius:**

Fast moving - Bold thinking - Constant growth - Meaningful impact - Trust and real ownership - Opportunity to shape the future of AI

**Equal Opportunity Statement:**

Nebius is an equal opportunity employer. We are committed to fostering an inclusive and diverse workplace and to providing equal employment opportunities in all aspects of employment. We do not discriminate on the basis of race, color, religion, sex (including pregnancy), national origin, ancestry, age, disability, genetic information, marital status, veteran status, sexual orientation, gender identity or expression, or any other characteristic protected by applicable law.

Applicants must be authorized to work in the country in which they apply and will be required to provide proof of employment eligibility as a condition of hire.

If you need accommodations during the application process, please let us know.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
