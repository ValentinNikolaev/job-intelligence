# (Senior) Event & Operations Manager (m/w/d)

Posted: 2026-08-17T02:09:05Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**TechQuartier**

Seit zehn Jahren ist das **TechQuartier** der Ort in Frankfurt, an dem durch Events, Programme und Accelerator-Initiativen die richtigen Menschen zusammenkommen. Als zentraler Innovationstreiber am Finanzplatz Frankfurt vernetzt das TechQuartier Gründer:innen von FinTech- und GreenTech-Start-ups mit etablierten Unternehmen aus zukunftsweisenden Bereichen wie KI, Quantencomputing, Finanzwesen, GreenTech und Mittelstand.

Seit 2017 ist das TechQuartier Teil der Digital Hub Initiative (de:hub) des Bundes und wurde 2024 offiziell als FinTech Hub Frankfurt anerkannt. TechQuartier ist zudem Veranstalter und Gastgeber des IMPACT FESTIVAL in Frankfurt – Deutschlands größte B2B-Veranstaltung für digitale & nachhaltige Transformation.

Das TechQuartier treibt das Start-up-Ökosystem in der Region Frankfurt Rhein-Main kontinuierlich voran und stärkt seine Rolle als zentraler Innovationsknotenpunkt in Europa.

Wenn Du Lust hast, in einem dynamischen Umfeld Verantwortung zu übernehmen, eigene Ideen einzubringen und gemeinsam mit uns Innovation voranzutreiben, bist Du bei uns genau richtig.

**Werde ****ab November in Vollzeit ****Teil unseres Teams. Wir freuen uns auf Deine Bewerbung!**

**Warum diese Rolle echten Impact hat**

Unser Coworking-Space ist ein lebendiger Ort, an dem Menschen kreativ arbeiten, sich vernetzen und durch vielfältige Events zusammenkommen. Um dieses Umfeld zu ermöglichen, braucht es eine starke organisatorische Basis.

Als** (****Senior) Event & Operations Manager:in** übernimmst Du genau diese Verantwortung. Du sorgst dafür, dass der Space im Alltag reibungslos läuft und unsere Veranstaltungen im Coworking-Space von der Planung bis zur Umsetzung professionell organisiert sind. Dein Beitrag macht den Unterschied zwischen einem Ort, der einfach funktioniert, und einem Ort, der Membern, Gäst:innen und Eventeilnehmenden positiv in Erinnerung bleibt.

**Was Du bei uns bewegst**

- Du planst, betreust und bereitest externe und interne Veranstaltungen in unserem Coworking-Space vor und nach.
- Du gestaltest ein positives Event-Erlebnis, indem Du Bedürfnisse erkennst und proaktiv passende Lösungen findest.
- Du steuerst den täglichen Betrieb des Coworking-Spaces und stellst sicher, dass Abläufe und Standards zuverlässig funktionieren.
- Durch Deine Ideen und strategische Herangehensweise entwickelst Du den Coworking-Space und das Event Management kontinuierlich weiter.
- Du koordinierst Aufgaben im Team und schaffst ein motivierendes und inklusives Umfeld.

**Was Du mitbringst**

- Du bringst relevante Berufserfahrung und/oder einen passenden Abschluss mit, der Dich fachlich gut auf die Rolle vorbereitet. Für diese Position ist eine fundierte Expertise in den Bereichen Event Management und Office Management wichtig.
- Du bringst eine hohe Lernbereitschaft, Hands-on-Mentalität und Lösungsorientierung mit.
- Du überzeugst durch eine zuverlässige, strukturierte und eigenständige Arbeitsweise und behältst auch bei komplexen Aufgaben den Überblick.
- Du bist ein Kommunikationstalent und Dir fällt es leicht, mit Stakeholdern in Kontakt zu treten und Dich auf Deutsch und Englisch sicher zu vernetzen.
- Du hast Freude daran, Berufseinsteiger:innen und Praktikant:innen zu begleiten und zu unterstützen.

**Keine Notwendigkeit, aber sicher hilfreich**

- Du hast Erfahrungen in einem Start-up- oder Coworking-Umfeld gesammelt und kennst die Dynamik agiler Arbeitskulturen.
- Du interessierst Dich für neue Ideen, Trends und Innovationen.

**Was Dich bei uns erwartet**

**Team-Spirit:** Wir sind ein offenes, engagiertes und internationales Team, das Innovation und Entrepreneurship lebt. Um neue und kreative Lösungsansätze zu fördern, schätzen wir verschiedene Meinungen und Blickwinkel.
**Innovations-Hub: **Du arbeitest in einem modernen und inspirierenden Umfeld mitten im Frankfurter Start-up-Ökosystem. Im Austausch mit Start-ups lernst Du regelmäßig neue Trends und Technologien kennen, baust wertvolle Kontakte auf und bist Teil zahlreicher Events im TechQuartier.
**Eigenverantwortung: **Bei uns arbeitest Du von Tag eins eigenverantwortlich an Deinen Projekten, triffst Entscheidungen und gestaltest die Zukunft des TechQuartiers aktiv mit.
**Karriere & Entwicklung: **Wir pflegen eine offene Lern- und Feedbackkultur. Klare Karrierelevel, Skillprofile und viel Raum für eigene Ideen unterstützen Dich dabei, Deine Stärken gezielt auszubauen und Dich persönlich weiterzuentwickeln.
**Flexibilität:** Mit eigenem Laptop und Deutschlandticket bist Du bestens ausgestattet. Durch die Option flexibel gestaltbarer Arbeitszeiten innerhalb unserer Kernarbeitszeit arbeitest Du so, wie Du am produktivsten bist.
**Extras:** 30 Urlaubstage plus freie Tage an Heiligabend und Silvester sowie an Deinem Geburtstag, betriebliche Altersversorgung, Shopping- und Fitnessrabatte, regelmäßige Team-Events und kostenfreie Getränke.

**Wir suchen Potenzial, nicht perfekte Lebensläufe**

Die Stellenanzeige klingt spannend für Dich, aber Du erfüllst nicht jedes aufgelistete Kriterium? Bitte bedenke, dass es sich bei den Anforderungen um eine erste Orientierung handelt. Wir suchen Menschen mit Drive, Lernbereitschaft und Lust auf Verantwortung. Lass uns sprechen und gemeinsam herausfinden, ob wir zusammenpassen.

**Unser Bewerbungsprozess**

- Absenden Deiner Bewerbung über unser Karriereportal
- Virtuelles Erstgespräch über Microsoft-Teams mit HR
- Zweites Gespräch vor Ort im TechQuartier mit Deinem Teamlead
- Finale Entscheidung & Angebot
Je nach Rolle oder Situation kann der Ablauf leicht variieren – wir halten Dich dabei jederzeit transparent auf dem Laufenden.

Du hast noch offene Fragen? Kontaktiere **Tina** (Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
