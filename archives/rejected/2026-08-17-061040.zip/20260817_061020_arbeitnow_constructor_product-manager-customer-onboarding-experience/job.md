# Product Manager: Customer Onboarding Experience

Posted: 2026-08-16T17:40:14Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

### **About You**

You are a technically fluent, customer-obsessed PM who gets energized by removing friction from developer workflows. You have a strong instinct for what makes integrations feel fast and safe, and you know how to balance developer needs with long-term product maintainability. You bring systems thinking to SDK and tracking decisions, hold a high bar for integration correctness and reliability, and are energized by the challenge of reducing time-to-value for the teams and customers who depend on you.

###
**About Us**

Constructor is the next-generation platform for search and discovery in ecommerce, built to explicitly optimize for metrics like revenue, conversion rate, and profit. Our search engine is entirely invented in-house utilizing transformers and generative LLMs, and we use its core and personalization capabilities to power everything from search itself to recommendations to shopping agents. Engineering is by far our largest department, and we've built our proprietary engine to be the best on the market, having never lost an A/B test to a competitive technology. We're passionate about maintaining this and work on the bleeding edge of AI to do so.

Out of necessity, our engine is built for extreme scale and powers over 1 billion queries every day across 150 languages and roughly 100 countries. It is used by some of the biggest ecommerce companies in the world like Sephora, Under Armour, and Petco.

We're a passionate team who love solving problems and want to make our customers' and coworkers' lives better. We value empathy, openness, curiosity, continuous improvement, and are excited by metrics that matter. We believe that empowering everyone in a company to do what they do best can lead to great things.

Constructor is a U.S. based company that has been in the market since 2019. It was founded by Eli Finkelshteyn and Dan McCormick who still lead the company today.

### **About the Position**

As the PM for Customer Developer Experience + Customer Data Integrations, you will own the end-to-end integration journey for Constructor's customers and SIs — from first setup through long-term adoption. Your north star is time-to-value: making it fast, correct, and reliable for any team to integrate with Constructor and start getting results.

You will span two tightly connected surfaces:

-

CDX — SDKs, UI libraries, integration patterns, docs, and the extensibility model that lets customers build on Constructor without accumulating hidden complexity.

-

CDI — tracking/instrumentation, data attributes, event validation tooling, and the reliability + correctness of the data flows that power Constructor's AI.

Day-to-day, you will:

-

Define and drive a roadmap that measurably reduces integration time, defects, and escalations.

-

Improve integration correctness for key tracking flows (search → PDP → conversion, sponsored click tracking, etc.) by reducing common failure modes and adding robust validation and diagnostics.

-

Build and evolve validation and debugging tooling that empowers customers, Solutions Engineers, and Customer Success to self-serve faster.

-

Define clear support and capability boundaries to reduce high-visibility escalations and improve customer predictability.

-

Partner with Engineering, Solutions/CS, and other Product teams to sequence work, de-risk launches, and ensure new capabilities ship integration-ready.

Define and report a CDX+CDI KPI stack (time-to-first-value, adoption, defect rate, escalation volume, doc findability) and drive continuous improvement.

##
**Requirements**

-

3+ years of product management experience shipping developer-facing or integration-heavy products — such as SDKs, APIs, web tracking/instrumentation, data pipelines, or developer tooling.

-

Demonstrated ability to reduce time-to-value or integration complexity in a B2B SaaS environment — with concrete, measurable outcomes.

-

Technical fluency sufficient to reason credibly about event flows, browser/web constraints, attribution, versioning, breaking changes, and rollout risk — without needing to be an engineer.

-

Track record of strong cross-functional collaboration: aligning Engineering, Customer Success, Solutions, and other Product teams on priorities and support boundaries.

-

Comfort defining metrics and making decisions with imperfect data; experience building and reporting product health dashboards.

-

Strong written communication — clear specs, integration guides, capability docs, and stakeholder updates.

## **Benefits**

🏝️ Unlimited vacation time - we strongly encourage all of our employees take at least 3 weeks per year

💰 A competitive compensation package including stock options

🌎 Fully remote team - choose where you live

🛋️ Work from home stipend! We want you to have the resources you need to set up your home office

💻 Apple laptops provided for new employees

🧑‍🎓 Training and development budget for every employee, refreshed each year

👪 Maternity & Paternity leave for qualified employees

🧠 Work with smart people who will help you grow and make a meaningful impact

🏥 Company sponsored US health coverage (100% paid for employee)

### **Diversity, Equity, and Inclusion at Constructor**

At we are committed to cultivating a work environment that is diverse, equitable, and inclusive. As an equal opportunity employer, we welcome individuals of all backgrounds and provide equal opportunities to all applicants regardless of their education, diversity of opinion, race, color, religion, gender, gender expression, sexual orientation, national origin, genetics, disability, age, veteran status or affiliation in any other protected group.

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
