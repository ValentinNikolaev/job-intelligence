# (Senior) Associate Inhouse Consulting & Value Creation

Posted: 2026-08-16T23:30:05Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**Du möchtest Integrationen nicht nur begleiten, sondern aktiv mehrere Unternehmen gleichzeitig weiterentwickeln und operativ verbessern? Dann suchen wir genau dich, zum nächstmöglichen Zeitpunkt als:**

**(Senior) Associate Inhouse Consulting & Value Creation (w/m/d)

**Als (Senior) Associate Inhouse Consulting & Value Creation (w/m/d) bist du zentral in der Umsetzung unserer Integrationen und Skalierungsinitiativen eingebunden. Du arbeitest eng mit dem Group Head of Integration & Scaling sowie dem COO zusammen und übernimmst Verantwortung für die operative Umsetzung über mehrere Gesellschaften hinweg. Dafür brauchen wir deine Unterstützung!

Die **[Arsipa Gruppe](http://www.arsipa.de/)** ist eine schnell wachsende, Unternehmensgruppe im Bereich Health, Safety & Environment, unterstützt von Warburg Pincus. Mit über 1.000 Mitarbeitenden, 20+ Tochtergesellschaften und 48 Standorten in Deutschland und Österreich bauen wir im Rahmen einer klaren Buy-&-Build-Strategie eine skalierbare Plattform mit nachhaltiger Wertschöpfung. Unser Ziel: eine der führenden Anbieterinnen im deutschsprachigen Markt - unterstützt durch zentrale Funktionen wie Finance, HR, Marketing und IT am Standort Berlin.

**Deine Aufgaben:**

-

**Steuerung & Performance**

-

Unterstützung und teilweise eigenständige Steuerung von Post-Merger-Integrationen (Day 1, 30, 60, 100)

-

Aufbau und Tracking relevanter KPIs (z.B. Time-to-Integration, Synergien, Performance)

-

Analyse der Performance einzelner Gesellschaften und Ableitung konkreter Maßnahmen

-

Sicherstellung, dass definierte Initiativen operativ umgesetzt werden

-

**Aufbau & Skalierung**

-

Umsetzung gruppenweiter Standards (SOPs, Governance, Strukturen) in den einzelnen Einheiten

-

Mitarbeit am Aufbau eines skalierbaren Operating Models

-

Integration neuer Gesellschaften in bestehende Strukturen

-

Identifikation und Umsetzung von Best Practises über mehrere Gesellschaften hinweg

-

Enge Zusammenarbeit mit Geschäftsleitungen der Tochtergesellschaften zur Weiterentwicklung ihrer Einheiten

-

**Enge Zusammenarbeit mit:**

-

lokalen Stakeholder

-

Geschäftsleitungen der Tochtergesellschaften

**Deine Startvoraussetzungen:**

-

Mehrjährige Erfahrung in Strategy & Beratung, Private Equity, Start-up/Scale-up oder vergleichbarem Umfeld mit operativem Fokus

-

Erste Erfahrung in Integration, Transformation oder Multi-Company-Setups

-

Fähigkeit, Themen eigenständig voranzutreiben und umzusetzen

-

Hohe Umsetzungsstärke, analytisches Denken und pragmatische Arbeitsweise

**Unsere Benefits:**

-

**Attraktives Arbeitsumfeld:** 30 Tage Jahresurlaub, Heiligabend und Silvester jeweils einen halben Tag frei, ein hybrides Setup mit einem Homeoffice-Tag pro Woche sowie ein zentral gelegenes Office im Rocket Tower inklusive Gym, unmittelbar an der U-Bahn-Station „Kochstraße“.

-

**Direkte Nähe zum COO und zum Integration & Scaling Team:** Enge Zusammenarbeit mit unserem COO, dem Group Head of Integration & Scaling sowie den Geschäftsführungen unserer Tochtergesellschaften - mit direktem Einfluss auf die Weiterentwicklung unserer Gruppenstruktur.

-

**Gestaltungsspielraum in einer Buy-&-Build-Plattform:** Aktive Mitgestaltung von Integrationen, Skalierungsinitiativen, Operating Models und gruppenweiten Standards in einer krisensicheren, rasant wachsenden Unternehmensgruppe - unterstützt durch einen der weltweit führenden Investoren, Warburg Pincus.

-

**Einblicke in Post-Merger-Integration und operative Skalierung:** Von Day-1-, 30-, 60- und 100-Tage-Integrationen über KPI-Tracking, Performance-Analysen und Governance-Strukturen bis hin zur Umsetzung konkreter Verbesserungsmaßnahmen wirkst Du an zentralen Initiativen unserer Buy-&-Build-Strategie mit.

**Unser Bewerbungsprozess:**

Wir freuen uns über deine Bewerbung über unser Stellenportal. Nach der Prüfung deines CVs wartet ein dreistufiger Bewerbungsprozess auf dich. Dieser startet mit einem kurzen Telefonat mit Allen, Sr. Talent Acquisition Partner, gefolgt von einem Video Call mit dem Fachbereich. Anschließend besteht die Möglichkeit, das Team sowie die verschiedenen Aufgaben und Verantwortungsbereiche der Stelle vor Ort besser kennenzulernen. Werde Teil unserer spannenden Reise!

**Wir freuen uns auf Dich!**

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
