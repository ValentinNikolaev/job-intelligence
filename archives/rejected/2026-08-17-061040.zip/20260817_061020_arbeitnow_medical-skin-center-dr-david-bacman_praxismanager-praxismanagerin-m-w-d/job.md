# Praxismanager / Praxismanagerin (m/w/d)

Posted: 2026-08-16T16:30:24Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**Über uns**

Das Medical Skin Center von Dr. David Bacman ist eine Praxis für Dermatologie und ästhetische Medizin in Köln-Lindenthal. Zum Haus gehören ein integriertes MEDISPA und ein eigener Onlineshop für medizinische Skincare. Unser Anspruch ist in allen Bereichen derselbe: medizinische Hautgesundheit und Ästhetik auf höchstem Niveau — getragen von einem Team, das mit Sorgfalt, Präzision und echter Freude an Qualität arbeitet.

Für die Leitung der Organisation suchen wir eine Persönlichkeit, die Verantwortung übernimmt und Verlässlichkeit schafft. Als Praxismanager:in verantworten Sie das operative Management unseres gesamten Hauses — Praxis, MEDISPA und Onlineshop — und unterstützen Dr. Bacman in der strategischen und operativen Führung. Sie arbeiten entlang klarer Strukturen, etablierter Standards und definierter Abläufe.

**Ihre Aufgaben**

• **Operatives Management:** Steuerung des täglichen Betriebs von Praxis, MEDISPA und Onlineshop, Umsetzung von Prozessoptimierungen und Qualitätsstandards, Verantwortung für das gesamte Patientenerlebnis vor Ort — vom ersten Kontakt bis zur Nachbetreuung

• **Personalmanagement & HR:** eigenständige Organisation des Recruiting-Prozesses, On- und Offboarding, Pflege des HR-Systems Factorial, erste Ansprechperson für das Team im Tagesgeschäft

• **Buchhaltung & Controlling:** vorbereitende Buchhaltung über DATEV Online, enge Abstimmung mit dem Steuerbüro, Kontrolle von Eingangsrechnungen, Zahlungsläufen und Budgetvorgaben, Mitwirkung an Planung, Analysen und Reports

• **Lager- & Produktmanagement:** Überwachung der Bestände von medizinischem Verbrauchsmaterial bis zu Verkaufsartikeln, Planung der jährlichen Inventur, Koordination von Lieferanten, Fulfillment- und Kooperationspartnern

• **IT, Systeme & Qualitätssicherung:** reibungsloser Betrieb von Kassensystemen, CRM, Onlineshop sowie HR- und KI-gestützten Tools, Koordination der IT-Dienstleister, Organisation der Wartung medizinischer Geräte, Weiterentwicklung des Qualitätsmanagements

• **Marketing, Kommunikation & Kundenbindung:** Planung und Koordination der Maßnahmen gemeinsam mit Dr. Bacman, Schnittstelle zu externen Dienstleistern für Social Media, Digital Marketing, Grafik und PR, Stärkung von Patientenbindung, Loyalität und Wiederkehrrate

• **Strategische & wirtschaftliche Planung:** Mitwirkung an Jahresplanung und Kennzahlen, Analyse und Optimierung betriebswirtschaftlicher Prozesse, strategische Weiterentwicklung von Praxis und Marke gemeinsam mit Dr. Bacman

**Ihr Profil**

• abgeschlossene Ausbildung oder Studium — etwa im Praxis- oder Gesundheitsmanagement, in Betriebswirtschaft oder eine vergleichbare Qualifikation

• mehrjährige Erfahrung im Praxis-, Standort- oder Betriebsmanagement, idealerweise im Gesundheitswesen, in der ästhetischen Medizin oder im gehobenen Dienstleistungsumfeld

• Führungserfahrung und die Fähigkeit, ein Team wertschätzend und verbindlich zu koordinieren

• betriebswirtschaftliches Verständnis und ein sicherer Umgang mit Zahlen, Budgets und Kennzahlen

• hohe Affinität zu digitalen Systemen — von HR-Software über CRM bis zu KI-gestützten Tools

• Organisationstalent, eine vorausschauende und verlässliche Arbeitsweise sowie Serviceorientierung auf höchstem Niveau

• die Bereitschaft, innerhalb etablierter Strukturen und Standards zu führen — Verbesserungen bringen Sie strukturiert ein

• wertschätzende, klare Kommunikation und absolute Diskretion im Umgang mit sensiblen Informationen

**Wir bieten**

• eine unbefristete Anstellung in einer etablierten, wachsenden Praxis

• die zentrale operative Führungsrolle unseres Hauses — eingebettet in klare Strukturen und etablierte Standards, mit kurzen Entscheidungswegen

• direkte Zusammenarbeit mit Dr. Bacman

• ein besonderes Arbeitsumfeld: Dermatologie, ästhetische Medizin, MEDISPA und Onlineshop unter einem Dach

• eine strukturierte Einarbeitung entlang unserer dokumentierten Standards und Prozesse sowie regelmäßige Fort- und Weiterbildung

• eine attraktive, der Verantwortung angemessene Vergütung

• geregelte, planbare Arbeitszeiten

• Mitarbeitervorteile auf Behandlungen und Produkte unseres Hauses

**Rahmenbedingungen**

• Umfang: Vollzeit

• Arbeitsmodell: Präsenztätigkeit — vollständig vor Ort in unserer Praxis

• Beginn: zum nächstmöglichen Zeitpunkt

• Vertrag: unbefristete Anstellung

• Vergütung: 4.200 – 5.400 € brutto pro Monat, je nach Qualifikation und Erfahrung

• Standort: Medical Skin Center, Dürener Str. 245 a, 50931 Köln

**Ihre Bewerbung**

Senden Sie uns Ihren Lebenslauf und einige Zeilen zu Ihrer Person und Ihrer Motivation — ein förmliches Anschreiben ist willkommen. Ihre Bewerbung behandeln wir selbstverständlich streng vertraulich.

Bewerbungen an: Mehr über unsere Praxis: [www.dr-bacman.de](http://www.dr-bacman.de)

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
