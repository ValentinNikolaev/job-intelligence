# Working Student (f/m/d) - IT Infrastructure

Posted: 2026-08-17T02:30:17Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

At Instagrid, you are part of the clean-tech revolution by bringing pure energy into your region, helping professional workers transitioning away from combustion generators and making it possible for them to experience a safe, efficient, clean and silent energy solution.

#### **Your mission**

As a working student in our IT team, you support the day-to-day operation of our IT infrastructure and actively contribute to projects. You are the first point of contact for our colleagues when it comes to technical questions, and you make sure that workplaces and devices run reliably. Along the way, you'll get to know a modern, fully cloud-based Microsoft 365 environment from the ground up.

#### **Your Impact**

-

**1st Level Support / Helpdesk:** You are the first contact for IT requests and incidents – you log tickets, resolve issues independently or escalate them in a well-prepared way, and document your solutions.

-

**On-Site Service:** You provide hands-on deskside support directly at our Ludwigsburg site – setting up and handing over hardware, troubleshooting at the workplace, and assisting colleagues in person with their devices and peripherals.

-

**IT Onboarding:** You prepare workplaces and end-user devices (Windows & Mac) for new colleagues, set up user accounts in Microsoft 365 / Entra ID, and support them through their first IT day.

-

**Client Management & Maintenance:** You manage and maintain our endpoints via Intune, take care of software deployment, updates, and configurations, and keep an eye on the device inventory.

-

**Project Work:** You support IT infrastructure and automation projects, e.g. rollouts, the introduction of new tools, or the improvement of existing processes.

-

**Documentation:** You maintain guides and our internal knowledge base so that knowledge stays accessible to everyone.

-

You are an enrolled student, ideally in (business) informatics or a comparable field of study – though all tech-enthusiastic study programs are welcome.

-

You have an interest in or initial experience with Microsoft 365 (e.g. Exchange Online, Teams, SharePoint, Entra ID, Intune).

-

You bring basic knowledge of operating and administering Windows and macOS devices.

-

You work in a service- and solution-oriented way, enjoy communicating with people, and take a structured approach.

-

You are confident in both German and English (spoken and written).

-

You work independently and reliably, and you are curious to learn new things.

### Your benefits

-

Flexible working hours

-

Generous vacation entitlement plus additional special leave days (pro rata basis)

-

The opportunity to work in a company at the forefront of innovation

### This is Instagrid

Pure instant power. Anywhere. We have created the world’s most advanced portable power supplies, bringing freedom to the way our customers work. With you we want to shape a world where advanced technology meets environmental responsibility and create lasting impact. Driven by our curiosity and the desire to leave tomorrow's world cleaner than we found it yesterday. Join us in transitioning away from combustion generators to a cleaner alternative for fast, measurable, and real outcomes. What we’ve achieved so far is just the beginning.

At Instagrid, we are deeply committed to equal employment opportunities as we believe in the power of diverse teams. We do not just accept diversity but actively search for the best talent regardless of gender, ethnical origin, age, religion, sexual orientation or place of origin. Working as a team, we treat each other with respect and value each other’s opinions to achieve our common goals.

We are looking forward to receiving your application!

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
