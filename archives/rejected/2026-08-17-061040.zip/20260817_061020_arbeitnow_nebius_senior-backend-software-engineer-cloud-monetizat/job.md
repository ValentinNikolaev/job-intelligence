# Senior Backend Software Engineer (Cloud Monetization Platform)

Posted: 2026-08-16T23:55:13Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**About Nebius:**

Nebius is leading a new era in cloud infrastructure for the global AI economy. We are building a full-stack AI cloud platform that supports developers and enterprises from data and model training through to production deployment, without the cost and complexity of building large in-house AI/ML infrastructure.

Built by engineers, for engineers. From large-scale GPU orchestration to inference optimization, we own the hard problems across compute, storage, networking and applied AI.

Listed on Nasdaq (NBIS) and headquartered in Amsterdam, we have a global footprint with R&D hubs across Europe, the UK, North America and Israel. Our team of 1,500+ includes hundreds of engineers with deep expertise across hardware, software and AI R&D.

#### The role:

We are looking for a **Senior Backend Software Engineer** to join our **Cloud Monetization Platform** team in Amsterdam or remotely.

Our platform powers the commercial foundation of Nebius Cloud. Every GPU hour, storage operation, network transfer, reservation, enterprise contract, or customer payment flows through the systems we build before becoming revenue.

Unlike traditional billing systems, our platform combines several challenging engineering domains. You'll design clean abstractions for a rapidly evolving business model, build reliable distributed workflows where correctness and consistency are as important as performance, and help shape a modern platform from the ground up.

#### We expect you to have:

-

5+ years of professional software engineering experience

-

Strong knowledge of Python or willingness to quickly become productive with our technology stack

-

Experience building distributed backend systems and microservice architectures

-

Understanding of distributed transactions, consistency models, and reliable asynchronous workflows

-

Experience designing scalable backend services

-

Strong communication and ownership mindset

It would be an added bonus if you had experience building Billing, payments or pricing systems

#### Technology stack:

-

Python, gRPC, Temporal, YDB, Kafka-like messaging, Kubernetes, 25+ microservices.

**Benefits & Perks:**

- Competitive compensation

- Career growth and learning opportunities

- Flexibility and ownership

- Collaborative and innovative culture

- Opportunity to work on impactful AI projects

- International environment and talented teams

**What's it like to work at Nebius:**

Fast moving - Bold thinking - Constant growth - Meaningful impact - Trust and real ownership - Opportunity to shape the future of AI

**Equal Opportunity Statement:**

Nebius is an equal opportunity employer. We are committed to fostering an inclusive and diverse workplace and to providing equal employment opportunities in all aspects of employment. We do not discriminate on the basis of race, color, religion, sex (including pregnancy), national origin, ancestry, age, disability, genetic information, marital status, veteran status, sexual orientation, gender identity or expression, or any other characteristic protected by applicable law.

Applicants must be authorized to work in the country in which they apply and will be required to provide proof of employment eligibility as a condition of hire.

If you need accommodations during the application process, please let us know.

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
