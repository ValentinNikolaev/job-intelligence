# Werkstudent Projektmanagement (all genders)

Posted: 2026-08-16T17:09:40Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**WAS DU VON UNS ERWARTEN KANNST**

apoprojekt ist Partner für jeden Transformationsbedarf im Bestand und eines der dynamischsten Unternehmen der Bau- und Immobilienbranche. Seit unserer Gründung 2007 sind wir von einem Zwei-Mann-Unternehmen zu einer Größe von mehr als 600 Mitarbeitenden gewachsen. Wir wollen den Markt verändern: Mit unserem Design & Build-Ansatz und weniger Schnittstellen zwischen Planung und Ausführung. Mit mehr Miteinander und voller Verantwortung für unsere Projekte. Um die besten Teams der Branche zusammenzustellen, suchen wir die kompetentesten und talentiertesten Mitarbeitenden. Und dafür brauchen wir genau Dich! Was uns besonders auszeichnet, ist unsere gelebte Werte- und Unternehmenskultur. Bei uns erwarten Dich nicht nur Aufgaben mit einer steilen Lernkurve – sondern auch ein spürbarer Teamspirit. Bist Du dabei?

**DEINE HERAUSFORDERUNG**

- Du unterstützt unser Team im Mieterausbau bei der erfolgreichen Umsetzung von Bauprojekten.
- Du unterstützt bei der Erstellung von Leistungsverzeichnissen, Terminplänen und Kostenverfolgungen.
- Du überwachst und dokumentierst die Terminsituation der laufenden Projekte.
- Du unterstützt bei der Bauüberwachung und Koordination der ausführenden Gewerke.

**DEIN PROFIL, UM GEMEINSAM ETWAS ZU BEWEGEN**

- Du befindest Dich in einem laufenden Studium, vorzugsweise in einem fortgeschrittenen Semester eines technischen oder kreativen Studiengang (Bauingenieurwesen, Architektur o.Ä.).
- Du verfügst idealerweise über erste Erfahrungen in der Bearbeitung von Bauprojekten und im Umgang mit einer Bauprojektmanagement-Software wie iTWO.
- Du bist sicher im Umgang mit MS Office.
- Du verfügst über organisatorisches Geschick und Kommunikationsstärke und bist offen für abwechslungsreiche Aufgaben sowie Spaß an Teamarbeit.

**KONTAKT**

Fabian Carlsen
Recruiting Manager

apoprojekt GmbH
Holstenwall 5
20355 Hamburg
Mobil +49 151 53824356
Zentrale +49 40 8797898-0

[www.apoprojekt.de](https://www.apoprojekt.de/)

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
