# Product Manager (d/f/m)

Posted: 2026-08-24T09:30:35Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**Hypofriend is a next-generation online mortgage advisor using proprietary technology to find customers the best mortgage possible and give holistic financial advice.**

Unlike other mortgage advisors or brokers, we use financial insights to guide our customers. By joining us, you will be able to tap into these insights and be part of our path to transform the industry. We provide customers with tools that help them navigate the entire home buying process, from making buying decisions and give advice on the next steps to build wealth in Germany.

**As Product Manager** you own a slice of that machine end-to-end: the internal platform our advisors and operations team run on, and the AI and automation that make the mortgage process faster and less manual. You will work closely with engineering, design, advisors, and the founders.

## Tasks

- Own your product area end-to-end — from problem discovery and prioritisation to spec, launch, and measurement.

- Build for our advisors and ops team. Improve the CRM, advisory and application workflows, document handling, and lender submission so advisors spend their time advising, not administrating.

- Ship AI and automation into the mortgage journey — document extraction and verification, AI-assisted advisory prep, decision support, and agentic workflows — with clear guardrails for accuracy and compliance.

- Connect the dots across the funnel. Understand how the customer-facing product, advisor tooling, and lender/partner integrations affect each other, and make trade-offs across them.

- Learn the business deeply enough to find the levers. Understand our advice and sales principles, how the market works, and how advisors, banks and agents actually move a case forward. Use that to spot where the business loses value — drop-offs, rework, waiting time — and where a product change unblocks it. A roadmap here is a set of bets on levers, not a wish list of features.

- Define success with numbers. Set metrics per initiative (conversion, time-to-offer, advisor capacity per case, automation rate, error rate), instrument them, and report honestly on outcomes.

- Write clear specs and keep delivery moving. Groom the backlog, run rituals, unblock engineers, and make the call when scope has to be cut.

- Work within a regulated domain. Partner with compliance and our lending partners so what we ship holds up under German mortgage regulation.

## Requirements

- 2–4 years in product management, ideally on a product with real operational complexity (fintech, marketplace, internal tooling, or workflow automation).

- Comfort with numbers and data — you can write your own SQL queries or analyses rather than waiting for someone else.

- A practical grasp of what today's AI models can and cannot be trusted with, and how to design around that.

- A solid UX foundation — you understand how interface and interaction design shape behaviour, and you can design flows that guide advisors and the CSM team towards the right action instead of just exposing more fields and buttons.

- Strong written communication and the ability to make complex financial mechanics feel simple.

- Structured, self-directed, and comfortable in a small team where you own the outcome, not just the ticket.

- Fluent English. German is a strong plus (our lenders, contracts, and regulation are German).

- Interest in mortgages, real estate, or personal finance — the domain rewards people who go deep.

Nice to have

- Experience with process automation, document AI, or LLM-based product features in production.

- Background in lending, insurance, or another regulated financial product.

- Some technical fluency — you can read an API contract and discuss architecture trade-offs with engineers.

## Benefits

**What can Hypofriend offer you?**

👪 Motivated, interdisciplinary team with years of experience building successful digital products

🏠 Work up to 100% from home, with occasional meetings in our Berlin headquarters

📈 Stock options in a growing company

💼 Excellent career opportunities as our company scales

💥 Help to shape the innovative practices and products which are redefining the German mortgage industry

💻 Latest Macbook

🏃🏼‍♂️ Urban Sports Membership

📍 3-story office at Rosenthaler Platz

- **A lean team and a flat structure.** High independence and end-to-end ownership: you take a problem from discovery to launch to measurement yourself, without layers of approval in between.

- **Your users sit next to you.** Our advisors and CSM team are the people your product serves, so feedback comes in hours rather than after a research cycle — and you see the effect of what you shipped almost immediately.

- **Big scope, real impact.** Three brands and one shared financial picture — a wide surface for a team this size, and decisions that visibly move the business.

- **Fast pace.** We ship, learn and correct quickly instead of planning quarters in advance.

- **Profitable, bootstrapped and proven.** Eight years on the market, 500,000 customers, and we fund ourselves — so the roadmap follows customer value and business sense, not the next funding round. You also get real scale of data to work with.

- **Genuinely hard problems.** Optimisation across lender rules, tax logic, risk and long-term financial outcomes, plus AI and automation applied to a regulated, high-stakes process.

How we work — and who thrives here

**This will be a good fit if you:**

- Take initiative by default. When something is unclear or broken, you go and find out, rather than waiting for a decision to arrive.

- Solve problems from first principles. You dig into messy, ambiguous situations, form your own view of the root cause, and propose a way forward.

- Learn fast and enjoy it. Mortgages, German regulation, lender logic, our internal systems — a lot to absorb, and you will be expected to get up to speed largely on your own.

- Handle context switching. On any given day you may move between an AI experiment, an advisor workflow bug, a lender requirement and a data question — and hold several threads open at once without dropping them.

**It probably will not be a good fit if you:**

- Prefer one clearly scoped project at a time with minimal interruption.

- Want a defined process, an existing playbook, and clear direction on what to work on next.

- See the PM role mainly as writing tickets and coordinating rather than digging into the domain and the numbers yourself.

- Are uncomfortable making decisions with incomplete information, or need consensus before moving.

First 6 months — what success looks like

- Month 1–2: You know the mortgage process end-to-end, have shadowed advisors on real cases, and can articulate the core pillars of our workflow.

- Month 3–4: You own a defined area, have a prioritised roadmap for it, and have shipped at least one improvement with a measurable effect on advisor efficiency or conversion.

- Month 5–6: You are the go-to person for your domain, running discovery independently, and one AI/automation initiative is live and demonstrably reducing manual work per case.

We are looking forward to your application!

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
