# AI/ML Engineer (m/f/d) Autonomous Systems

Posted: 2026-08-24T09:00:30Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

We are **MOTOR Ai**. Our mission is to make Level 4 autonomous driving a reality in Germany and beyond. By combining state-of-the-art AI with the expertise of our multidisciplinary team, we are poised to introduce the first solution of its kind in Germany that is eligible for certification on European roads. Since 2017, we have been steadfastly pursuing a single goal: to shape a future that is already in motion.

## Tasks

- Model Development & Training - Design, train, and fine-tune machine learning models to meet performance, accuracy, and robustness requirements for autonomous driving use cases

- Model Deployment & Integration - Integrate trained models into production systems, ensuring reliable, efficient, and safe operation within the overall software stack

- Experimentation & Evaluation - Run structured experiments and evaluations to validate model performance, using established metrics and benchmarks

- Performance Optimization - Optimize models for latency, memory, and compute constraints relevant to real-time autonomous systems

- Cross-Functional Collaboration - Partner with data, perception, and simulation teams to ensure models are built on the right data and validated against real-world scenarios

## Requirements

- A completed degree in computer science, machine learning, data science, or a comparable field - or equivalent vocational training/apprenticeship in a relevant technical discipline. Hands-on experience counts at least as much as the formal qualification

- 3+ years of relevant hands-on experience in applied AI/ML engineering

- Strong knowledge of deep learning and reinforcement learning; familiarity with Active Inference approaches is a plus. Experience in the automotive industry and a track record of turning research papers into working product features are both an advantage

- Strong Python skills with solid ML fundamentals, and hands-on experience with deep learning frameworks (PyTorch and/or TensorFlow)

- Experience with reinforcement learning tooling (e.g. Stable-Baselines3, RLlib) and experiment-tracking tools (e.g. MLflow, Weights & Biases)

- Experience deploying and optimizing models for production/real-time systems (e.g. ONNX, TensorRT, C++ integration)

- Solid engineering practices: Git, CI/CD pipelines, and containerization (Docker, ideally Kubernetes)

- Comfortable working with cloud/GPU compute environments (AWS, GCP, or Azure) and data tooling (NumPy, Pandas, SQL); experience with simulation environments such as CARLA and ROS/ROS2 familiarity are both a plus

- An open-minded, curious mindset - you enjoy trying new approaches and ideas

- A valid driving license

- English C1 is required; German is a plus

## Benefits

- Focus on people: Our strength lies in our diversity. We respect each other for who we are

- Genuine team spirit: working in teams that drive change forward – no matter how complex and extensive the projects are

- Your professional development is important to us – that's why we cover the costs of further education and training

- Flexible working hours – with room for the realities of life (parenthood, caregiving responsibilities, voluntary work, etc.)

- Whether it's fashion, beauty, travel or culture – you'll receive numerous discounts through our partner Corporate Benefits

- Social relevance: We work on solutions that have game-changing qualities

- Subsidy for public transport tickets

- Excellent transport links: attractive location in Wedding with very good public transport connections

Excited about our vision and ideas? Do you see real value in autonomous driving for everyone? Then apply to MOTOR Ai and become an active part of a safe, explainable future of mobility.

At our new premises, we place great importance on getting to know one another and working together to drive our vision forward. Our international team is growing and working together on this exciting mission. Face-to-face collaboration is the key to success, which is why we have decided not to become a fully remote company.

*We ask recruitment consultancies and agencies not to submit candidate profiles without our prior express request. Any candidate profiles submitted without a prior written placement agreement signed by both parties shall be deemed to have been submitted unsolicited. No entitlement to placement fees or other charges shall arise from their use or from the subsequent recruitment of the candidate.*

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
