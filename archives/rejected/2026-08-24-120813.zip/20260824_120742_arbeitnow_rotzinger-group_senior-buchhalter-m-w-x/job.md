# Senior Buchhalter (m/w/x)

Posted: 2026-08-24T05:30:17Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Zur Verstärkung unseres Finanzbereichs suchen wir Dich als erfahrenen **Senior Buchhalter (m/w/d)**, der nicht nur fachlich sicher im Rechnungswesen ist, sondern auch mit einer ausgeprägten **Hands-on-Mentalität** aktiv im Tagesgeschäft mitarbeitet. Du übernimmst von Anfang an Verantwortung in der operativen Buchhaltung und bringst Dein Know-how in die Weiterentwicklung von Prozessen und Abläufen ein. Perspektivisch ist vorgesehen, dass Du im nächsten Schritt die **fachliche Verantwortung für unser dreiköpfiges Team im Rechnungswesen** übernimmst und damit eine wichtige Schlüsselrolle in unserem Finanzbereich einnimmst.

-

Eigenverantwortliche Betreuung der laufenden Finanzbuchhaltung nach HGB, insbesondere in den Bereichen Debitoren-, Kreditoren-, Anlagen- und Hauptbuchhaltung

-

Mitarbeit bei der termingerechten Erstellung von Monats-, Quartals- und Jahresabschlüssen nach HGB

-

Durchführung von Kontenabstimmungen sowie Klärung und Buchung von Sachverhalten im Hauptbuch

-

Unterstützung bei der Erstellung von Auswertungen, Reports und betriebswirtschaftlichen Analysen für die Geschäftsführung und Fachbereiche

-

Mitwirkung bei der Liquiditätsplanung sowie Unterstützung im Zahlungsverkehr und Mahnwesen

-

Sicherstellung einer ordnungsgemäßen Buchführung unter Einhaltung gesetzlicher, steuerlicher und interner Vorgaben

-

Ansprechpartner für buchhalterische Fragestellungen innerhalb des Unternehmens sowie für Steuerberater, Wirtschaftsprüfer und externe Dienstleister

-

Mitwirkung bei steuerlich relevanten Themen, insbesondere im Bereich Umsatzsteuer, in Abstimmung mit externen Beratern

-

Unterstützung bei der Weiterentwicklung und Optimierung von buchhalterischen Prozessen, Richtlinien und internen Kontrollen

-

Mitarbeit an Projekten im Finanzbereich, z. B. bei der Digitalisierung, ERP-Weiterentwicklung oder der Optimierung von Reporting-Strukturen

-

Je nach Teamstruktur fachliche Unterstützung und Anleitung von Kolleginnen und Kollegen im Rechnungswesen

**Fachliche Anforderungen: **

-

Erfolgreich abgeschlossene kaufmännische Ausbildung mit Weiterbildung zum Bilanzbuchhalter (IHK) oder abgeschlossenes betriebswirtschaftliches Studium mit Schwerpunkt Rechnungswesen/Finanzen oder vergleichbare Qualifikation

-

Mehrjährige Berufserfahrung in der Finanzbuchhaltung, idealerweise in einem mittelständischen Unternehmen

-

Sehr gute Kenntnisse im HGB sowie fundierte Erfahrung in der Erstellung von Monats-, Quartals- und Jahresabschlüssen

-

Gute Kenntnisse in den Bereichen Debitoren-, Kreditoren-, Anlagen- und Hauptbuchhaltung

-

Sicherer Umgang mit ERP-Systemen, idealerweise SAP R/3, sowie sehr gute MS-Excel-Kenntnisse; Erfahrung mit BI-Tools von Vorteil

-

Gute Kenntnisse in umsatzsteuerlichen Fragestellungen; weitere steuerliche Kenntnisse von Vorteil

-

Strukturierte, sorgfältige und eigenverantwortliche Arbeitsweise sowie ein hohes Maß an Zuverlässigkeit

-

Hands-on-Mentalität und Freude an der operativen Mitarbeit im Tagesgeschäft

-

Analytisches Denkvermögen sowie Affinität zu Zahlen, Prozessen und Systemen

-

Gute Deutschkenntnisse in Wort und Schrift; Englischkenntnisse von Vorteil

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
