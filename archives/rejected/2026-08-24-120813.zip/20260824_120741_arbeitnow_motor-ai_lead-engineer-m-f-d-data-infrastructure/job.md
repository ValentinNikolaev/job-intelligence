# Lead Engineer (m/f/d) Data Infrastructure

Posted: 2026-08-24T09:00:29Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Most technologies promise the future. We're already building it. At **MOTOR Ai**, we've spent years doing what others said couldn't be done in Germany: developing Europe's first certifiable Level 4 autonomous driving system - one that doesn't just detect the world around it, but understands it. Rooted in cognitive neuroscience and driven by a team that bridges disciplines, we're not waiting for autonomous mobility to arrive. We're the reason it will.

## Tasks

- Data Infrastructure Strategy & Architecture - Define the strategy and architecture for data platforms, storage, and pipelines, ensuring scalability, reliability, and cost-efficiency as our data volume and usage grow

- Team Leadership - Build, lead, and develop the data infrastructure team, ensuring the right skills and capacity to support engineering, ML, and simulation data needs

- Platform Reliability & Scalability - Ensure data platforms and pipelines are robust, monitored, and able to scale with our growing data and compute requirements

- Cross-Functional Enablement - Partner with data engineering, AI, perception, and simulation teams to ensure infrastructure meets their evolving data access and processing needs

- Data Security & Governance - Establish standards for data security, access control, and versioning, ensuring our data infrastructure is compliant, auditable, and trustworthy

## Requirements

- A completed degree in computer science, data engineering, information systems, or a comparable field - or equivalent vocational training/apprenticeship in a relevant technical discipline. Hands-on experience counts at least as much as the formal qualification

- 10+ years of hands-on experience in data infrastructure or data platform engineering, including experience building infrastructure from the ground up

- A proven track record designing and operating data platforms for very large data volumes, together with a solid understanding of infrastructure budgeting and cost optimization

- Experience leading and developing a team, including prior organizational or people-management responsibility

- A technical skill set comparable to a senior data engineer - solid, hands-on experience with cloud data infrastructure, storage systems, and data pipelines

- Strong communication skills, with the ability to align stakeholders across technical and non-technical teams

- English C1 is required; German is a plus

## Benefits

- Genuine team spirit: working in teams that drive change forward - no matter how complex and extensive the projects are

- Flexible working hours - with room for the realities of life (parenthood, caregiving responsibilities, voluntary work, etc.)

- Whether it's fashion, beauty, travel or culture - you'll receive numerous discounts through our partner Corporate Benefits

- Social relevance: We work on solutions that have game-changing qualities

- Subsidy for public transport tickets

- Your professional development is important to us - that's why we cover the costs of further education and training

- Excellent transport links: attractive location in Wedding with very good public transport connections

- Focus on people: Our strength lies in our diversity. We respect each other for who we are

The road ahead is being built right now. If you want a hand in shaping it - we'd like to hear from you.

At our new premises, we place great importance on getting to know one another and working together to drive our vision forward. Our international team is growing and working together on this exciting mission. Face-to-face collaboration is the key to success, which is why we have decided not to become a fully remote company.

*We ask recruitment consultancies and agencies not to submit candidate profiles without our prior express request. Any candidate profiles submitted without a prior written placement agreement signed by both parties shall be deemed to have been submitted unsolicited. No entitlement to placement fees or other charges shall arise from their use or from the subsequent recruitment of the candidate.*

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
