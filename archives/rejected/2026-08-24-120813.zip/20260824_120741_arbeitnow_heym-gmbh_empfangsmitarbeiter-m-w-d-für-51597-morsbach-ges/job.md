# Empfangsmitarbeiter (m/w/d) für 51597 Morsbach gesucht!

Posted: 2026-08-24T08:00:34Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Seit der Unternehmensgründung im Jahre 1978 in Limburg ist das

Unternehmen HEYM stetig gewachsen. Heute zählt die HEYM GmbH im Bereich

Sicherheitsdienste, Sicherheitssysteme sowie Gebäudereinigung zu den

bedeutendsten Branchen-Dienstleistern in Deutschland.

Wir, das

Team der Heym GmbH, betreuen unsere Kunden umfassend mit unseren

technischen und personellen Dienstleistungen. Die Zufriedenheit des

Kunden ist unser Ziel. Zur Verstärkung unseres Teams suchen wir ab

sofort:

Empfangsmitarbeiter (m/w/d) in Teilzeit in 51597 Morsbach.

Die Arbeitszeiten liegen wechselweise von 07.00 Uhr bis 13.00 Uhr sowie von 13.00 Uhr bis 19.00 Uhr.

## Aufgaben

- Empfang, Anmeldung und Weiterleitung von Kunden und Besuchern

- Annahme und Weiterleitung von Telefonaten

- Bearbeitung eingehender Mails

- Weitere administrative Aufgaben

## Qualifikation

- Verantwortungsbewusstsein

- Zuverlässigkeit

- Teamfähigkeit

- Sicheres und freundliches Auftreten

- Gute Deutschkenntnisse in Wort und Schrift

- EDV Kenntnisse

## Benefits

- Aussicht auf ein unbefristetes Arbeitsverhältnis

- hochwertige und abwechslungsreiche Tätigkeiten

- pünktliche und faire Bezahlung

- Attraktive Mitrabeiterangebote (Benefits)

- feste Integration in bereits bestehende langjährige Teams

- fundierte Einarbeitung und ständige Betreuung

- sichere und krisenfeste Arbeitsplätze

- flache Hierarchien und kurze Entscheidungswege

- partnerschaftliche Arbeitsatmosphäre

- ein dynamisches und motiviertes Team

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
