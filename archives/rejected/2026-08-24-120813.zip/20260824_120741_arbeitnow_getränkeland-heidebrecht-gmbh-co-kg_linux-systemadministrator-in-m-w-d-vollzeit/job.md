# Linux - Systemadministrator:in (m/w/d) - Vollzeit

Posted: 2026-08-24T09:30:31Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Wir sind Getränkeland - DIE GETRÄNKEKÖNNER, als mittelständische und familiengeführte Unternehmensgruppe sind wir mit knapp 100 Filialen und rund 600 Mitarbeitenden in vier Bundesländern aktiv. Unsere Geschäftsfelder umfassen neben dem stationären Einzelhandel auch den Großhandel, E-Commerce mit Getränken sowie die Softwareentwicklung.

## Aufgaben

- Installation und Anwendungsadministration von Linux-Systemen

- Fehleranalyse sowie Herbeiführung von Erstlösungen durch Remote Support

- Qualifizierte Störungsannahme per Telefon

- Mitwirkung an Rufbereitschaften

- Monitoring und Performanceanalyse

- Übernahme regelmäßiger Wartungsarbeiten (Erweiterungen, Updates)

- Sicherstellung der IT-Sicherheit und Mitwirkung an Datenschutz- und EDV-Compliance-Themen

- Unterstützung bei Installation und Administration von Windows-Systemen

- Installation und Administration von Datenbanken (MySQL / IBM DB2)

## Qualifikation

- Abgeschlossene Ausbildung im IT-Bereich (z. B. Fachinformatiker Systemintegration) oder vergleichbare Qualifikation bzw. Quereinstieg ist mit entsprechenden Fachkenntnissen möglich

- Sicherer Umgang mit LINUX

- Grundkenntnisse SQL, Shell Scripting

- Hohe Serviceorientierung und Kommunikationsfähigkeit

- Zuverlässigkeit, Belastbarkeit und Organisationstalent

- Kommunikationsstärke, Teamfähigkeit und sicheres Auftreten

- Freude an eigenverantwortlichem Arbeiten

## Benefits

**Was wir dir bieten**

- Eine strukturierte Einarbeitung sowie vielseitige Aufgabenfelder mit Gestaltungsspielraum

- Individuelle Weiterbildungs- und Entwicklungsmöglichkeiten

- Flexible Arbeitszeiten und eine gute Vereinbarkeit von Beruf und Privatleben

- Einen sicheren Arbeitsplatz in einem stabilen Unternehmensumfeld

- Einen ergonomischen Arbeitsplatz und moderne Technik

- Saftige 20% Mitarbeiterrabatt in allen Getränkeland-Filialen / Onlineshops

- Betriebliche Krankenzusatzversicherung

- Betriebliche Altersvorsorge

- Edenred-Karte – monatliches Nettoguthaben bei vollständiger Anwesenheit

Haben wir dein Interesse geweckt? Dann schick uns deine Bewerbung und lass uns gemeinsam bei einem kühlen (oder heißen) Getränk deiner Wahl herausfinden, ob wir zueinander passen!

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
