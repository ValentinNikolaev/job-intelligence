# Product Owner - Healthtech (m/w/d)

Posted: 2026-08-24T09:00:28Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

In Deutschland geben Patienten jährlich 30 Milliarden EUR beim Zahnarzt aus. Trotz dieser Marktgröße arbeiten viele Praxen noch immer mit veralteter Offline-Software aus den 80er Jahren. Roger ist hier, um das zu ändern.

Unsere Mission: Zahnarztpraxen mit unserem virtuellen KI-Assistenten Roger zu revolutionieren. Unsere Software transformiert Behandlungsplanung und Patientenkommunikation, steigert Effizienz und Umsatz und vereinfacht den Praxisalltag für Zahnärzt:innen und ihre Teams.

In dieser Rolle verantwortest du das Product Backlog und die operative Umsetzung der Roadmap bei Roger. Du arbeitest eng mit dem Entwicklungsteam, dem Gründer/CEO und unseren Nutzer:innen zusammen und übersetzt Produktstrategie in konkrete, priorisierte Anforderungen – damit das Team die richtigen Dinge zur richtigen Zeit liefert.

## Aufgaben

- **Product Backlog verantworten:** Du pflegst, priorisierst und verfeinerst das Backlog und sorgst dafür, dass es jederzeit die wichtigsten Wertbeiträge abbildet.

- **Roadmap in Umsetzung bringen:** Du übersetzt die gemeinsam mit Gründer/CEO entwickelte Produktstrategie in klare User Stories, Akzeptanzkriterien und Sprint-Ziele.

- **Time-to-Market sicherstellen:** In enger Abstimmung mit Engineering sorgst du für eine effiziente Umsetzung und schnelle, verlässliche Auslieferung neuer Features.

- **Features zur Optimierung des Praxisalltags konzipieren:** Du entwickelst neue Features, die den Arbeitsalltag in Arztpraxen spürbar erleichtern – von der Idee bis zum Release.

- **Praxisverwaltungssysteme (PMS) verstehen und analysieren:** Du analysierst bestehende Praxisverwaltungssysteme und leitest daraus Anforderungen ab (inkl. Reverse Engineering von Datenstrukturen und Workflows).

- **Datenabgleich und Nutzerfeedback einholen:** Über den Abgleich von Datenstrukturen mittels SQL und direktes Nutzerfeedback gestaltest du praxisnahe, bedarfsgerechte Lösungen. Ein Verständnis der medizinischen Realität hilft dir, passgenaue Features zu entwickeln.

- **Als Kommunikationsschnittstelle zwischen Business und Technik agieren:** Du bist das Bindeglied zwischen Nutzer:innen, Stakeholdern und Engineering und kommunizierst Prioritäten klar in beide Richtungen.

## Qualifikation

- Erfahrung als Product Owner, Product Manager oder in einer vergleichbaren Rolle in einem Healthtech Startup / Scale-up - idealerweise in der Zahnmedizin.

- Sicherer Umgang mit agilen Methoden (Scrum/Kanban) und Backlog-Management.

- Du nutzt KI-Tools selbstverständlich in deiner täglichen Arbeit und suchst aktiv nach Wegen, Produkt und Prozesse damit besser und schneller zu machen.

- Du verstehst, wie sich KI sinnvoll in Produkte einbauen lässt und wo sie echten Nutzen stiftet statt nur draufzusitzen.

- Du verfolgst neue KI-Entwicklungen aktiv und bringst Ideen ein, wie wir sie bei Roger einsetzen können (AI-pilled / AI-First-Mentalität).

- Gutes technisches Verständnis, um Produktanforderungen präzise an das Engineering-Team weiterzugeben.

- Wachstumsdrang / Growth Mindset: Tiefe Verpflichtung zu persönlichem und beruflichem Wachstum, offen für Feedback und neue Lernmöglichkeiten.

- Persönliche Fähigkeiten: analytisches und strukturiertes Arbeiten, Eigeninitiative, selbstständige Problemlösung, Lernbereitschaft und Freude an der Arbeit im Team.

- Abgeschlossenes Studium, idealerweise im medizinischen, wirtschaftlichen oder IT-Bereich.

- Sehr gute Deutsch- und Englischkenntnisse.

**Nice to have**

- SQL-Kenntnisse

- BigQuery

- Erste Führungserfahrung

## Benefits

- Lebendige Kultur: Tauche ein in eine Kultur mit tatsächlich flachen Hirarchien, die Innovation, Teamarbeit und Spaß bei der Arbeit feiert.

- Karrierechance

Bewirb Dich jetzt bei Roger und teile uns Dein frühestmögliches Startdatum mit. Wir können es kaum erwarten, Dich kennen zu lernen und Dein Potenzial zu entfesseln!

Falls du nicht alle geforderten Erfahrungen mitbringst – kein Problem! Wenn du motiviert bist und Lust hast, dich im Bereich Product Management weiterzuentwickeln, freuen wir uns trotzdem auf deine Bewerbung.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
