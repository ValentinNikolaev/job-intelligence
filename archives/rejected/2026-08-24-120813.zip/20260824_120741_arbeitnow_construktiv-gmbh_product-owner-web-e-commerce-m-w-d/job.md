# Product Owner Web & E-Commerce (m/w/d)

Posted: 2026-08-24T08:10:30Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**Join the Team!**

Du bist ein Organisationstalent und überzeugst mit hervorragender Kommunikationsstärke und analytischen Fähigkeiten? Du hast als Digital Native ein gutes Gespür für Marketing, E-Commerce und aktuelle Trends? Perfekt! Dann werde Teil unseres engagierten Teams und arbeite gemeinsam mit uns an herausfordernden Problemstellungen in spannenden Kundenprojekten. Wir suchen zum nächstmöglichen Zeitpunkt in Vollzeit zur Verstärkung unseres Teams in Bremen.

**Deine Aufgaben**

-

Du bist für das Consulting und Projektmanagement in Website- und E-Commerce Projekten zuständig

-

Du entwickelst digitale Strategien, die deinen Kunden helfen, ihre Online-Präsenz und Umsätze nachhaltig zu optimieren.

-

Du verantwortest die Konzeption, Umsetzung und Optimierung von Websites, Online-Shops und E-Mail-Kampagnen

-

Du berätst deine Kunden proaktiv, scheust keine Calls und Meetings und hebst neue Umsatzpotenziale in deinen Projekten

-

Du koordinierst und verteilst Aufgaben für unsere Kreation und Webentwicklung

-

Du übernimmst die Vorbereitung und Ausarbeitung von Präsentationen

**So überzeugst du uns**

- Du hast mind. zwei Jahre Erfahrung in der Begleitung von Online-Projekten, idealerweise agenturseitig
- Du weißt wie Websites und Online-Shops aufgebaut sind und bringst Verständnis in HTML, CSS & Co. sowie erste Erfahrungen in gängigen Systemen wie WordPress, Shopify, Klaviyo, Brevo oder Mailchimp mit
- Du fühlst dich online zuhause und hast keine Berührungsängste mit AI Tools
- Du schätzt Eigenverantwortung, bist gut organisiert und kannst dich auf schnell wechselnde Prioritäten einstellen
- Du verfügst über ein ausgeprägtes Kommunikationstalent und lässt dich auch in schwierigen Situationen nicht aus der Ruhe bringen
- Idealerweise kannst du ein abgeschlossenes Studium im Bereich Wirtschaftsinformatik, Digitale Medien oder BWL oder eine themenverwandte Ausbildung vorweisen

**Was wir dir bieten**

- Bei uns erwarten dich spannende, vielfältige Projekte mit coolen Kunden aus den unterschiedlichsten Branchen – da kommt keine Langeweile auf
- Deine Gesundheit liegt uns am Herzen, daher bezuschussen wir gerne deine Mitgliedschaft bei EGYM Wellpass, die dir Zugang zu vielen Sportangeboten ermöglicht
- Für deine persönliche Work-Life-Balance sind deine Arbeitszeiten flexibel, du kannst auf Wunsch zwei Tage pro Woche mobil von zu Hause aus arbeiten und wir ermöglichen dir in Abstimmung gerne bis zu zwei Mal im Jahr eine selbstgeplante Workation
- Wir sorgen für steile Lernkurven und investieren in deine Entwicklung – neben internen Workshops kannst du regelmäßig an spannenden Webinaren, Konferenzen und Messen teilnehmen
- Als Goodie on top gibt es attraktive Mitarbeiterrabatte (Corporate Benefits), regelmäßige Teamevents und einen Sonderurlaubstag für deinen Geburtstag
- Last but not least: Dich erwarten die weltbesten Kolleg:innen, die dich mit großer Hilfsbereitschaft und einem immer offenen Ohr herzlich in Empfang nehmen

**Eckdaten**

- Vollzeit, Bremen
- Zunächst befristet auf zwei Jahre, mit guter Aussicht auf eine langfristige Anstellung.

**Werde Teil des Teams!**

Sende uns deine aussagekräftige Bewerbung unter Angabe deines frühestmöglichen Eintrittstermins und deiner Gehaltsvorstellung bitte an
**Über uns**

construktiv ist eine dynamische Digitalagentur mit rund 100 Mitarbeitenden an den Standorten Bremen und Berlin. Zu unseren Kunden zählen namhafte Unternehmen wie McCain, REWE, Deutsche Glasfaser, Arolsen Archives, OBI, Paramount+, Gutfried, Tartex, Messe Bremen und viele mehr. Seit fast 30 Jahren entwickeln und optimieren wir erstklassige Websites und Onlineshops für unsere Kunden – innovativ und pragmatisch. Von der Konzeption, über Design, technische Entwicklung und Content-Erstellung bis hin zum Editorial Design.

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
