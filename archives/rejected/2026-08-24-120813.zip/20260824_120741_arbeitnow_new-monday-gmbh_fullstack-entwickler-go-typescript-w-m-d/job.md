# Fullstack-Entwickler Go + TypeScript (w/m/d)

Posted: 2026-08-24T09:00:28Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**Stuttgart** (hybrid: 3 Tage vor Ort, 2 Tage remote) · **Freelance** · Softwareentwicklung

Fullstack-Entwickler Go + TypeScript (w/m/d), Freelance, Vollzeit (5 Tage pro Woche), ab sofort. Laufzeit: 60 Projekttage (ca. 3 Monate). Einsatzort: Stuttgart, davon 3 Tage pro Woche vor Ort und 2 Tage remote.

Für ein Kundenprojekt suchen wir eine:n erfahrene:n Fullstack-Entwickler:in (w/m/d) auf Freelance-Basis, die:der eine B2B-SaaS-Plattform im Security-Umfeld mitentwickelt, vom Go-Backend über das Frontend bis zum Betrieb.

New Monday ist eine Digitalagentur aus Berlin, die zu 100% remote arbeitet. Zu unseren Kunden zählen namhafte Konzerne wie Atruvia, DAK, SAP, Lufthansa uvm. genau wie moderne Start-Ups wie NUMA Stays.

Als Agentur zeichnen wir uns vor allem durch flache Hierarchien, unser agiles Mindset und einen New Work Approach aus. Bitte beachte: Anders als bei unseren internen Positionen erfordert dieses Projekt eine **Präsenz von 3 Tagen pro Woche beim Kunden in Stuttgart.**

## Aufgaben

- Konzeption und Entwicklung einer B2B-SaaS-/MSSP-Plattform für die Durchführung und Verwaltung von Pentests.

- Implementierung von Backend- und Frontend-Komponenten (Go, React/Vue.js/Angular).

- Erstellung und Weiterentwicklung von Architekturkonzepten für skalierbare Multi-Tenant-Lösungen.

- Implementierung von IAM- und KMS-Funktionalitäten.

- Unterstützung beim Betrieb und der Weiterentwicklung der Plattform (DevOps).

- Entwicklung und Integration KI-gestützter Funktionen und Prozesse.

- Durchführung von Code-Reviews, insbesondere für KI-generierten Code.

- Erstellung technischer Dokumentationen sowie Test- und Automatisierungskonzepte.

## Qualifikation

- Mehrjährige Erfahrung in der Entwicklung von SaaS-Anwendungen.

- Fundierte Erfahrung in der Fullstack-Entwicklung mit Go und React, Vue.js oder Angular (TypeScript).

- Erfahrung mit Multi-Tenant-Architekturen sowie IAM- und KMS-Lösungen.

- Nachweisbare Erfahrung in Softwarearchitektur und technischen Konzepten.

- Erfahrung mit KI-/agentengestützter Softwareentwicklung und Code-Review-Prozessen.

- Kenntnisse im DevOps-Umfeld sowie im Betrieb cloudbasierter Anwendungen.

- Erfahrung mit Testautomatisierung und Test-Driven Development (TDD).

- Verfügbarkeit ab sofort sowie Bereitschaft zu 3 Tagen pro Woche vor Ort in Stuttgart.

## Benefits

- Tolle Leute, super Atmosphäre, dynamisches Team, agile Arbeitsweise

- Sweet Spot zwischen Corporate-Alltag und kreativem Agenturleben: Bei uns musst du nicht zwischen hunderten Projekten gleichzeitig jonglieren, sondern bist für ein einzelnes Projekt eingeteilt.

- Klar umrissenes Projekt mit definierter Laufzeit und planbarer Auslastung (5 Tage pro Woche)

- An den Remote-Tagen flexibles Arbeiten von dort, wo du möchtest

- Eigenständiges, flexibles Arbeiten ohne Micromanagement

**Erstes Kennenlernen** Du lernst unsere Arbeitsweise und Philosophie kennen. Du hast die Gelegenheit, dich vorzustellen. Wir beantworten alle deine Fragen in entspannter Atmosphäre.

**Fachliches Gespräch** Ausführlicheres Kennenlernen mit Fokus auf deine Projekterfahrung, den Tech-Stack und das konkrete Projekt. Gelegenheit zu gegenseitigen Fragen.

**Follow-Up** Abstimmung der Details: Startdatum, Konditionen und der Ablauf beim Kunden. Danach kann es direkt losgehen.

Also los geht's! Wir freuen uns auf deine Bewerbung.

Um es einfach zu halten, verzichten wir gerne auf ein Anschreiben. Schick uns einfach deinen Lebenslauf bzw. dein Profil mit Projektreferenzen, auch wenn du das Gefühl hast, nicht 100 % der Anforderungen zu erfüllen.

New Monday fördert aktiv die Gleichstellung aller Beschäftigten. Wir begrüßen daher alle Bewerber:innen, unabhängig von Geschlecht, ethnischer, kultureller und sozialer Herkunft, Alter, Religion, Weltanschauung, Behinderung sowie sexueller Identität der Person. Menschen mit Schwerbehinderung werden bei gleicher Eignung unter Berücksichtigung aller Umstände des Einzelfalls bevorzugt.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
