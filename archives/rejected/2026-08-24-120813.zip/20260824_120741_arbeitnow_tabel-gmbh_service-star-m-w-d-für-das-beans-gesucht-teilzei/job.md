# Service-Star (m/w/d) für das "Beans" gesucht! (Teilzeit/Werkstudent/Minijob)

Posted: 2026-08-24T05:30:28Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**Du bist der geborene Gastgeber und hast Spaß daran, Menschen glücklich zu machen?**

Wir im "Beans" sind ein fröhliches Team, das unseren Gästen nicht nur leckeres Essen, sondern auch ein unvergessliches Erlebnis bieten möchte. Und dafür brauchen wir DICH als charmante und zuverlässige Unterstützung!

**Bist du...**

-

... ein Service-Talent, das mit einem Lächeln auf den Lippen jeden Gast begeistert?

-

... jemand, der Tische eindecken kann, als gäbe es dafür eine Goldmedaille?

-

... zuverlässig wie ein Schweizer Uhrwerk und immer pünktlich am Start?

-

... fit im Umgang mit Gästen und hast immer einen freundlichen Spruch parat?

**Was wir von dir erwarten (alles machbar, versprochen!):**

-

Du sorgst dafür, dass sich unsere Gäste rundum wohlfühlen: Tische liebevoll eindecken, Bestellungen aufnehmen, Getränke und Speisen servieren – und das alles mit einem Lächeln!

-

Du behältst auch in stressigen Situationen den Überblick und bleibst cool.

-

Du bist ein Teamplayer und unterstützt deine Kollegen, wo du nur kannst.

-

Du bist sorgfältig und achtest auf Ordnung und Sauberkeit im Restaurant.

**Was wir dir bieten (mehr als nur ein Job):**

-

**Ein Team, das dich feiert:** Wir sind offen, ehrlich und haben immer Spaß bei der Arbeit.

-

**Flexible Arbeitszeiten:** Teilzeit, Werkstudent oder Minijob – wir passen uns deinem Leben an!

-

**Faire Bezahlung:** Über Tariflohn und attraktive Zuschläge.

-

**Trinkgeld:** Das Sahnehäubchen auf deinem Verdienst.

-

**Die Chance, zu glänzen:** Bei uns kannst du deine Service-Skills unter Beweis stellen und dich weiterentwickeln.

-

**Ein cooles Arbeitsumfeld**: Mit Herzblut

**Faktencheck:**

-

**Was:** Servicekraft (m/w/d)

-

**Wann:** Ab sofort oder nach Vereinbarung

-

**Wie:** Teilzeit, Werkstudentenjob oder Minijob

-

**Wo:** Restaurant "Beans"

-

**Bezahlung:** Über Tarif + Zuschläge + Trinkgeld

-

**Sprachen:** Deutsch (fließend), Englisch (optional, aber gerne gesehen)

**Klingt nach deinem neuen Lieblingsjob?**

Schick uns deine Bewerbung (ein kurzer Lebenslauf reicht uns) an.

Wir freuen uns auf dich!

**P.S.:** Wenn du uns erzählst, wie du einen Gast zum Lachen gebracht hast, hast du schon fast gewonnen! 😊

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
