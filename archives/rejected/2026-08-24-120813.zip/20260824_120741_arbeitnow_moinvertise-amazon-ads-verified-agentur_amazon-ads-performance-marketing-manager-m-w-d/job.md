# Amazon Ads Performance Marketing Manager (m/w/d)

Posted: 2026-08-24T08:30:34Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**Was dich bei moinvertise erwartet**

Bei uns bekommst du die Möglichkeit, Verantwortung zu übernehmen und deine eigenen Ideen einzubringen.

Unser Büro befindet sich in der historischen Walzenmühle in direkter Nähe zum Flensburger Hafen. Gleichzeitig ist es bei uns auch möglich, remote zu arbeiten.

Darüber hinaus erwarten dich bei uns:

- Flache Hierarchien und kurze Entscheidungswege

- Flexible Arbeitszeiten

- Möglichkeiten zur fachlichen und persönlichen Weiterbildung

- Ein dynamisches, engagiertes Team

- Viel Raum, eigene Ideen einzubringen und Dinge mitzugestalten

## Aufgaben

Du kennst Amazon Ads nicht nur aus dem Kampagnenmanager, sondern verstehst, wie aus Daten, Struktur und einer klaren Strategie nachhaltige Performance entsteht?

Dann könnte die Rolle bei **moinvertise** gut zu dir passen.

Wir suchen Verstärkung im Bereich Amazon Advertising. Dabei geht es nicht darum, Kampagnen einfach nur laufen zu lassen. Du übernimmst Verantwortung für deine Accounts, analysierst Entwicklungen, hinterfragst Ergebnisse und entwickelst Maßnahmen, mit denen sich die Performance unserer Kund:innen gezielt weiterentwickeln lässt.

Du arbeitest eigenständig, bringst deine Ideen ein und tauscht dich eng mit dem Team und unseren Kund:innen aus.

**Deine Aufgaben**

- Entwicklung, Steuerung und kontinuierliche Optimierung von Amazon Ads Strategien

- Verantwortung für **Sponsored Products, Sponsored Brands und Sponsored Display**

- Strukturierung und Weiterentwicklung von Kampagnen und Accounts

- Analyse relevanter Performance-Daten und Ableitung konkreter Handlungsempfehlungen

- Identifikation von Wachstumspotenzialen und Entwicklung passender Maßnahmen

- Regelmäßige Auswertung und Einordnung der Kampagnenperformance

- Strategischer Austausch mit Kund:innen zu Performance, Entwicklungen und nächsten Schritten

- Planung und Durchführung von Tests zur Weiterentwicklung bestehender Kampagnenstrategien

- Beobachtung neuer Möglichkeiten und Entwicklungen innerhalb von Amazon Advertising

- Mitgestaltung und Weiterentwicklung unserer internen Prozesse und Arbeitsweisen

## Qualifikation

**Das bringst du mit**

Fundierte praktische Erfahrung im **Amazon Ads Management**

- Sicherer Umgang mit Sponsored Products, Sponsored Brands und Sponsored Display

- Ein gutes Verständnis für Performance Marketing und die Zusammenhänge innerhalb des Amazon-Marktplatzes

- Freude an Zahlen, Analysen und datenbasierten Entscheidungen

- Die Fähigkeit, Performance nicht nur auszuwerten, sondern daraus konkrete nächste Schritte abzuleiten

- Eine strukturierte, zuverlässige und eigenständige Arbeitsweise

- Einen hohen Qualitätsanspruch an deine eigene Arbeit

- Freude daran, Verantwortung für Accounts und Ergebnisse zu übernehmen

- Eine klare und professionelle Kommunikation im Austausch mit Kund:innen und im Team

- Gute Deutsch- und Englischkenntnisse

**Nice to have**

- Erfahrung mit größeren oder komplexeren Amazon Ads Account-Strukturen

- Erfahrung mit Automatisierungen, Regeln oder Tools im Amazon-Advertising-Umfeld

- Kenntnisse rund um Amazon Retail bzw. Seller Central oder Vendor Central

- Erfahrung mit Reporting- und Analyse-Tools

- Interesse an AI und daran, neue Technologien sinnvoll in bestehende Prozesse zu integrieren

- Berührungspunkte mit Themen wie Profitabilität, Conversion-Optimierung oder strategischer Sortimentssteuerung

Wir möchten Amazon Advertising nicht nach einem starren Schema betreiben. Stattdessen schauen wir uns genau an, was für den jeweiligen Account sinnvoll ist, welche Maßnahmen funktionieren und wo sich Dinge verbessern lassen.

Dabei sind uns ein offener Austausch, eigenständiges Arbeiten und ein gemeinsamer hoher Qualitätsanspruch wichtig.

Du sollst bei uns nicht einfach Kampagnen verwalten, sondern aktiv dazu beitragen, Strategien, Prozesse und unsere Arbeit im Amazon Advertising weiterzuentwickeln.

**Klingt interessant?**

Dann freuen wir uns darauf, mehr über dich zu erfahren.

Schick uns einfach deinen Lebenslauf und ein paar Worte zu dir und deiner bisherigen Erfahrung im Amazon Advertising.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
