# Enterprise Account Executive, Advertising Technology Solutions

Posted: 2026-08-24T06:45:30Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**About Mirakl:**

Founded in 2012, Mirakl has been at the forefront of marketplace innovation, empowering every business to compete in the platform economy.

Today, Mirakl's operating system combines an enterprise marketplace solution (Mirakl Platform) that enables retailers and B2B organizations to launch, scale, and operate marketplaces and dropship, AI-powered multichannel selling (Mirakl Connect), retail media (Mirakl Ads) and an agentic commerce infrastructure (Mirakl Nexus).

With dual headquarters in Boston and Paris, Mirakl helps a global ecosystem of 450+ marketplaces (B2C and B2B) and a network of over 100k third-party marketplace sellers. Brands like Macy's, Decathlon, Carrefour, Asos, and Airbus Helicopters use Mirakl to grow their businesses in new and remarkable ways.

For more information, visit [www.mirakl.com](http://www.mirakl.com).

**Mirakl in Numbers:**

- 🗓️ Founded in 2012 | Member of French Tech Next40

- 👥 750+ employees in 9 offices worldwide: Paris, Barcelona, Bordeaux, Boston, London, Munich, New York, Sydney, Tokyo

**Our Values:**

Working at Mirakl means accelerating your career alongside ambitious, passionate, and supportive colleagues. We're proud of the diversity of backgrounds, perspectives, and experiences that make our teams unique.

Our 5 values guide how we collaborate:

- 💡** Work Hard Together:** Teamwork and collaboration are the foundation of our success

- 🏆 **Get Things Done: ** We prioritize action and efficiency for impactful results

- 🚀 **Go Above & Beyond:** We tackle challenges proactively and always aim for excellence

- 🎓 **Succeed Through Expertise:** Knowledge sharing and continuous learning are core to our culture

- 🤝 **Satisfy & Empower Clients:** We're committed to our clients' success

### Enterprise Account Executive - Mirakl Ads

### The Team You'll Join

You'll be part of our EMEA Ads team led by **[Octavie Gosselin](https://www.linkedin.com/in/octavie-gosselin-1a997144/)**, VP Ads. The team consists of 7 professionals covering the EMEA region. Together, you'll be empowering businesses to monetise their ecommerce web traffic across both marketplace and first-party offerings while delivering more value to advertisers, marketplace sellers, and publishers.

### Your Impact

-

Develop and execute a go-to-market sales strategy for Mirakl Ads across EMEA territory, owning quota attainment through a structured, repeatable approach to new customer acquisition within retailer and marketplace operator.

-

Manage the full end-to-end sales cycle (typically 5 to 9 months) across all stages: prospecting and outbound engagement, discovery and business case development, technical validation with the solution engineering team, commercial negotiation with procurement and legal, and contract closure.

-

Build deep expertise in [**Mirakl Ads** ](https://www.mirakl.com/products/mirakl-ads?utm_term=mirakl%20ads&utm_campaign=274107632&utm_source=google&utm_medium=cpc&utm_content=719883937107&hsa_acc=4800297465&hsa_cam=274107632&hsa_grp=169159272159&hsa_ad=719883937107&hsa_src=g&hsa_tgt=kwd-2373216321008&hsa_kw=mirakl%20ads&hsa_mt=p&hsa_net=adwords&hsa_ver=3&gad_source=1&gad_campaignid=274107632&gbraid=0AAAAADwgkiicXehIxx5T0n3aLFCouS-KS&gclid=CjwKCAjwu53SBhAhEiwAJzSLNsQT7imCS1iLvgHEaaScfS0myEPkfy7sEuK2G1086o59HLr1_85niRoCxMgQAvD_BwE)and act as a trusted advisor on retail media monetisation strategies, sponsored product mechanics, and advertiser ROI, positioning Mirakl's differentiators against competing retail media solutions.

-

Navigate complex retailer organisations to build and maintain senior-level relationships with the key decision-makers driving retail media initiatives, including: Chief Digital Officers, VP/Heads of eCommerce, Heads of Retail Media or Monetisation, CMOs, as well as engaging technical and legal stakeholders throughout the process

-

Own and grow a healthy, multi-stage pipeline, partnering closely with Solutions Engineering, Product, Customer Success, and Legal teams to accelerate deal progression and ensure a smooth transition to onboarding post-signature

**Experience**

- 5+ years of quota-carrying experience in SaaS or Ad-tech/Retail Media sales, with a consistent track record

- Proven ability to manage and prioritise a pipeline, accelerating sales cycles to deliver against quarterly and annual revenue goals

- Skilled in solution selling and ROI-based selling, with experience engaging technical and business stakeholders across multiple levels (from practitioners to C-suite)

- Negotiation skills with a track record of closing mid-to-large enterprise deals

- Experience using CRM tools (e.g. Salesforce) to manage forecasting, pipeline hygiene, and reporting

**Nice to Have**

- Familiarity with the programmatic advertising ecosystem: DSPs, ad servers, APIs, and data-driven media buying

- Experience in marketplace platforms or eCommerce environments

- Comfortable leveraging AI-powered sales tools (e.g. Gong, Dust) to improve prospecting, call preparation, and deal reviews

**Languages**

- English & German: C2 level (required)

###

### **We keep it transparent and timely. Here's what to expect:**

- **Introductory call : **A conversation to learn about your background and motivations, and to answer your questions about Mirakl, the team, and the role.

- **Business interview** Meet the hiring manager to discuss your experience, problem‑solving approach and impact.

- **Values Interviews : **Meet with team members from different functions to explore your alignment with our core values and ways of working.

- **Final decision & offer : **We consolidate feedback quickly and aim to share decisions without delay. If successful, we'll walk you through the offer details, benefits, and next steps.

### **Benefits at Mirakl :**

- **Public Transport Pass:** 50% reimbursement on your monthly public transport subscription.

- **Health Insurance:** Flexible coverage tailored to individual or family needs, with Mirakl contributing to your plan.

- **Meal Allowance:** Mirakl provide a monthly meal allowance.

- **Hybrid Setup:** 4 days in-office & 1 day remote.

- **Pension & Life Insurance:** Mirakl contributes monthly to your pension and covers 100% of life insurance premiums.

- **ClassPass forfait:** Enjoy access to 40,000+ gyms and wellness studios worldwide with a no-commitment ClassPass membership.

- **Paid Time Off:** paid vacation days per calendar year.

*We welcome collaborators with their diverse perspectives and experiences to power us forward. These often far exceed conventional job requirements and help us create a culture of continuous learning. If you're ready to join a global leader powering digital transformation for 450+ of the world's most innovative retailers and B2B organizations.*

*As part of our recruitment process, Mirakl processes your personal data to review and manage your application and, where appropriate, to consider your profile for future opportunities. You can exercise your data protection rights at any time, and as further detailed in our policies. For more information about how we process your personal data and your rights, please consult our Recruitment Privacy Notice, [here](https://www.mirakl.com/recruitment-privacy-notice) in English and [here](https://www.mirakl.com/fr-FR/recruitment-privacy-notice) in French. *

*We may use Artificial Intelligence (AI) solutions to help streamline our hiring process, including screening applications, analyzing resumes, and assessing responses. While AI helps us work efficiently, all final hiring decisions are made by humans. For more information, visit our *[*AI Guidelines for Candidates and Interviews*](https://info.mirakl.com/ai-guidelines-for-candidates-and-interviews)*.*

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
