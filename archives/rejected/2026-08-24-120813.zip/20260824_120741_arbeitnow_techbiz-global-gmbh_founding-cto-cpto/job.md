# Founding CTO/CPTO

Posted: 2026-08-24T05:30:26Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**Berlin • Cybersecurity & AI Startup • Recently Secured Significant Funding**

We are building a next-generation **Identity + AI Enforcement** platform in Berlin.

Following newly secured funding, we are looking for a **technical co-founder** who will architect and build the core product from day one.

We are looking for a visionary **Founding CTO/CPTO** for a hybrid role based in Berlin. If you are passionate about deep tech, thrive in fast-paced environments, and have experience building transactional platforms, this is your opportunity to make a lasting impact.

#### Responsibilities

-

Lead customer discovery and validation to refine the value proposition to our three main target groups: Deep Tech founders, investors, and corporate partners.

-

Co-build the product vision to establish the leading deep technology database of Europe as well as the most effective match-making platform.

-

Establish the technological foundation of a transactional platform, including the data infrastructure.

-

Develop and execute the company’s technology strategy and roadmap.

-

Recruit and lead an in-house, top-tier engineering team.

-

Manage the company’s data, including storage, analysis, data privacy, and security.

#### **Requirements and Skills**

-

**10+ years experience** in backend engineering and system architecture.

-

Proven ability to design and ship complex distributed systems.

-

Strong understanding of **OAuth/OIDC, API keys, tokens, scopes, identity flows**.

-

Knowledge of **RBAC/ABAC** or fine-grained access models.

-

Exposure to **Zero Trust principles**, access control models, or identity governance.

-

Experience with **AI/LLM systems, agent logic, or willingness to learn fast**.

-

Understanding of **SaaS integration security**, OAuth app marketplaces.

-

Hands-on coding mentality; can build MVP and early architecture yourself.

-

Experience integrating with multiple SaaS systems and APIs.

-

Strong security mindset and understanding of modern attack surfaces.

-

Ability to move fast, take ownership, and operate independently.

-

Experience managing **small engineering teams** in early-stage environments.

-

Hands-on experience with infrastructure-as-code (Terraform) and cloud deployments.

-

Low ego, high commitment, and a **true founder mentality**.

#### Nice to Have

-

Experience with **AI/LLM systems**, multi-agent orchestration, or agent frameworks.

-

Experience with **policy engines** (custom enforcement logic).

-

Experience building **event-driven architectures** or streaming systems (Kafka, Pub/Sub).

-

Familiarity with **token analysis**, secret scanning, or credential hygiene.

-

Experience with **cloud IAM** (AWS/GCP/Azure roles, service principals).

-

Experience with **risk scoring**, anomaly detection, or behavior-based systems.

-

Exposure to **agent sandboxing**, isolated execution, or container micro-VMs.

-

Previous experience in **cybersecurity**, identity startups.

-

Understanding of **graph databases**, unified identity graphs, or permission maps.

-

Prior startup or co-founder experience.

#### Benefits

-

**Elevate Europe's Tech Sovereignty**: Help shape the culture and strategy of one of Europe’s leading Deep Tech platforms for this decade and beyond, empowering Europe’s independence from non-European technologies while supporting founders tackling major global challenges.

-

**Unparalleled Network Access**: Gain direct access to Tier 1 European Deep Tech startups, scaleups, and top investors, connecting with the forefront of Europe’s Deep Tech ecosystem.

-

**Founder Culture**: Operate with autonomy, driving initiatives as a force multiplier for Tier 1 Deep Tech founders, while refining your skills alongside Europe's leading (Deep) Tech experts.

-

**Compensation**: Receive an equity package in a validated, high-growth business with seed-stage traction and a profitable business model, incl. a compensation tied to business results.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
