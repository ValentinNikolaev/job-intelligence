# Administrator IT-Infrastruktur (m/w/d)

Posted: 2026-08-24T07:00:48Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Die interface projects GmbH ist ein Dresdner Softwareunternehmen mit den Schwerpunkten Enterprise Search, Machine Learning und generative KI. Unser Produkt **INTERGATOR** ist eine semantische Enterprise Search, die sowohl in der Industrie als auch bei Behörden und Forschungseinrichtungen eingesetzt wird.

Für unsere interne IT suchen wir Verstärkung mit einem klaren Schwerpunkt auf **Microsoft, Microsoft 365, Endgeräten und Anwendersupport**.

## Aufgaben

- Du übernimmst Verantwortung für den **zuverlässigen Betrieb und die kontinuierliche Weiterentwicklung unserer internen IT**.

- Du sorgst dafür, dass unsere Kolleginnen und Kollegen **sicher und zuverlässig arbeiten können** – vom Benutzerkonto über PC und Notebook bis zu Microsoft 365, Teams, Telefonie und den benötigten Zugängen und Berechtigungen.

- Du verantwortest gemeinsam mit dem Infrastruktur-Team den Betrieb unserer heterogenen IT-Landschaft und behältst dabei insbesondere die **Microsoft- und Windows-Infrastruktur** im Blick: Windows Server und Clients, Active Directory, Entra ID, Microsoft 365, Exchange, Intune, Teams, SharePoint, Dynamics und angrenzende Dienste.

- Im Admin-Team ergänzt ihr euch fachlich: Dein Schwerpunkt liegt auf unserer internen Unternehmens-IT mit besonderem Fokus auf zentrale Microsoft-Dienste, Benutzer und Endgeräte. Deine Kollegen bringen ihre Schwerpunkte in Linux, Virtualisierung und Kubernetes ein.

- Du begleitest unsere Endgeräte über ihren gesamten Lifecycle – von Auswahl und Beschaffung über Einrichtung, Softwareverteilung und Updates bis zur Ablösung.

- Du analysierst Störungen und Probleme, koordinierst deren Lösung und arbeitest dabei eng mit deinen Admin-Kollegen, unserem DevOps-Team und weiteren technischen Ansprechpartnern zusammen. Dabei gilt für uns: Du musst nicht jedes Problem allein lösen, aber du sorgst dafür, dass es gelöst wird.

- Du gestaltest unsere IT-Infrastruktur aktiv mit, erkennst Verbesserungspotenziale und entwickelst bestehende Lösungen, Prozesse und Standards eigenständig weiter.

- Du automatisierst wiederkehrende administrative Aufgaben und sorgst dafür, dass unsere IT mit dem Unternehmen mitwachsen kann.

- Du behältst Themen wie **Berechtigungen, Security, Updates, Backup, Monitoring, Lizenzen und Lebenszyklen unserer Systeme** im Blick und bringst notwendige Maßnahmen selbstständig auf den Weg.

- Du sorgst für eine nachvollziehbare und aktuelle Dokumentation der Systeme, Konfigurationen und wesentlichen Betriebsprozesse.

## Qualifikation

- Du hast eine abgeschlossene Ausbildung im Bereich Fachinformatik/Systemintegration, ein entsprechendes Studium oder eine vergleichbare Qualifikation.

- Du verfügst über mehrere Jahre Berufserfahrung in der Administration und Betreuung professioneller IT-Infrastrukturen.

- Du bringst fundierte praktische Erfahrung in der Microsoft-Welt mit, insbesondere in mehreren der Bereiche Windows Server, Active Directory, Microsoft 365, Entra ID, Exchange, Intune, Teams oder SharePoint.

- Du kennst die Administration von Windows-Clients und hast Erfahrung mit Endpoint Management, Softwareverteilung, Patchmanagement oder vergleichbaren Aufgaben.

- Du hast ein solides Verständnis für Netzwerke, Firewalls, VPN, Virtualisierung, Backup und die grundlegenden Zusammenhänge moderner IT-Infrastrukturen.

- Du hast bereits mit PowerShell oder anderen Werkzeugen administrative Abläufe automatisiert.

- Du verfügst über sehr gute Deutsch- und gute Englischkenntnisse.

(Deutsch Muttersprachler*in oder mindestens Level C)

**Was uns darüber hinaus wichtig ist**

- Du verstehst Administration nicht nur als das Abarbeiten einzelner Aufgaben, sondern fühlst dich **für das Funktionieren und die Weiterentwicklung deines Bereichs verantwortlich.**

- Du kannst selbstständig Prioritäten setzen und zwischen einer schnellen pragmatischen Lösung und einer nachhaltigen Verbesserung unterscheiden.

- Du arbeitest gerne breit und behältst auch dann den Überblick, wenn ein Problem mehrere Systeme oder Verantwortungsbereiche berührt.

- Du arbeitest gerne mit Spezialisten zusammen, respektierst deren Expertise und stimmst dich eng und konstruktiv mit ihnen ab.

- Du hast Freude am direkten Kontakt mit Kolleginnen und Kollegen und kannst technische Zusammenhänge verständlich vermitteln.

- Du bist offen und kommunikativ und arbeitest gerne im Team.

- Du möchtest dich kontinuierlich weiterentwickeln und begeisterst dich für neue Technologien und neues Wissen.

## Benefits

- Hohe Eigenverantwortung in einem strategisch wichtigen Technologiebereich

- Zusammenarbeit in einem erfahrenen, kollegialen Team

- Flache Hierarchien und kurze Entscheidungswege

- Flexible Arbeitszeiten ohne Kernarbeitszeiten

- Möglichkeit auf bis zu 2 Tage Home-Office pro Woche

- Sehr gute Vereinbarkeit von Beruf und Familie

- Freiraum, eigene Ideen einzubringen und Verantwortung zu übernehmen

- Regelmäßige Teamevents & Outdoor-Aktivitäten

- Getränkeflat (Kaffee, Wasser und Tee)

- Gute Erreichbarkeit – unsere Büroräume sind bestens an die DVB (Bus & Bahn) angebunden

- Jobrad

- Weiterbildungsangebote

Bitte sende uns deine **vollständigen Bewerbungsunterlagen per E-Mail**. Dazu gehören:

-

Anschreiben
*

Lebenslauf

-

relevante Zeugnisse

-

Angabe zum frühestmöglichen Eintrittstermin

-

Gehaltsvorstellung

**Wichtig:** Wir können ausschließlich vollständige Bewerbungen inklusive Anschreiben berücksichtigen. Verweise oder Links zu LinkedIn- bzw. XING-Profilen ersetzen die vollständigen Bewerbungsunterlagen nicht.

Werde Teil unseres Teams Administrator IT-Infrastruktur (m/w/d) und präge die Zukunft der Enterprise Search mit innovativer Technologie in einem dynamischen, wachsenden Unternehmen im Herzen Dresdens!

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
