# (Junior) Business Development Manager (M&A) - Standort: Hannover oder München

Posted: 2026-08-24T09:00:29Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Wir sind eine spezialisierte M&A-Boutique mit Fokus auf Buy- und Sell-Side-Mandate von deutschen und ausländischen Investoren im Mittelstand. Unsere Mandanten auf der Buy-Side sind überwiegend Private-Equity-Investoren, die im deutschsprachigen Mittelstand Buy-and-Build-Strategien umsetzen mit Schwerpunkt auf dem Business-Services-Sektor.

## Aufgaben

- Identifikation und Qualifikation potenzieller Targets im deutschen Mittelstand entlang der Investmentkriterien unserer Mandate (Recherche via Northdata, Pitchbook, Mandantenbriefings, eigene Markt-Mappings)

- Direktansprache von Geschäftsführern und Inhabern über alle relevanten Kanäle: Telefon, E-Mail, LinkedIn und persönliche Meetings vor Ort

- Aufbau und Pflege von Beziehung mit Geschäftsinhabern, für die ein Verkauf erst in 1-2 Jahren relevant wird

- Anbahnung und Koordination von Erstgesprächen zwischen Targets und Mandanten bis hin zum LOI

- Pflege der Pipeline und Aktivitätenreporting in HubSpot

- Enge Abstimmung mit dem für das Buy-Side-Mandat verantwortlichen MD

## Qualifikation

- 1–2 Jahre Berufserfahrung in einem relevanten Umfeld — z.B. M&A, Corporate Finance, PE, Unternehmensberatung, B2B-Vertrieb mit Mittelstandsfokus oder vergleichbar

- Souveränes, professionelles Auftreten, d.h. du kannst auf Augenhöhe mit erfahrenen Mittelständlern und Inhabern sprechen

- Hohe Eigenmotivation und Resilienz: Cold Outreach im Mittelstand bedeutet viele Neins für jedes Ja

- Strukturierte, systematische Arbeitsweise

- Deutsch auf muttersprachlichem Niveau, verhandlungssicheres Englisch

- Präsenz in München oder Hannover (Office-based, kein Remote)

- Verständnis grundlegender M&A-Prozessmechanik (Teaser, NDA, IM, LOI, DD)

Idealerweise bringst du mit:

- Netzwerk im deutschen Mittelstand

- Erfahrung mit langen Sales-Zyklen / komplexen Deals

- HubSpot-Kenntnisse

## Benefits

Freu dich auf ein dynamisches, engagiertes und offenes Team mit rund 12 Kolleginnen und auf regelmäßige Team-Dinner, Team-Offsites sowie Sommer- und Weihnachtsfeiern.

Wir freuen uns auf deine Bewerbung!

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
