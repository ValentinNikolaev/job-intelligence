# Werkstudent (m/w/d) Digitale Warenwirtschaft & ERP (Odoo)

Posted: 2026-08-24T08:30:34Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

*Du bringst Struktur in unsere Rohstoffe, digitalisierst den Warenfluss und baust unser Lager komplett neu auf – vom ersten Scan bis zum letzten Sack.*

Bei LAKEFIELDS stellen wir in unserer eigenen Manufaktur am Bodensee getreidefreies Premium-Futter für Hunde und Katzen her – aus frischem Fleisch zertifizierter Betriebe sowie regionalem Obst und Gemüse. Damit wir weiter wachsen können, bauen wir unsere Rohstoff-, Bestands- und Lagerprozesse gerade komplett neu in unserem ERP-System Odoo auf. Dafür suchen wir dich: eine engagierte Werkstudentin oder einen engagierten Werkstudenten, die/der dieses Projekt von Grund auf mitgestaltet.

## Aufgaben

**01** **ERP-Fundament: Rohstoffe & Stammdaten**

Rohstoffe im ERP anlegen und laufend pflegen

Sinnvolle Nummernkreise sowie Kategorien für Rohstoffe entwickeln und einführen

**02** **Barcode-Power & Hardware-Setup**

Barcodes für Rohstoffe und Produkte erzeugen

Barcode-Drucker und Handscanner auswählen, installieren und in Betrieb nehmen

**03** **Wareneingang** **im Griff**

Eingehende Produkte und Rohstoffe erfassen, per Scanner einlesen und im ERP sauber einbuchen

Bestellungen digitalisieren und Lieferungen mit den Bestellungen abgleichen, damit wir sichere und saubere Bestände erhalten

**04** **Warenfluss** **& Lagerdesign**

Lagerplätze vergeben und im ERP anlegen

Ein chaotisches oder ein anderes gut funktionierendes Lagersystem konzipieren und einführen

**05** **Saubere** **Bestände – abteilungsübergreifend**

Enge Abstimmung mit Herstellung, Etikettierung, Konfektionierung und Einlagerung, damit täglich produzierte Mengen korrekt und zeitnah verbucht werden

Fehlmengen erfassen und dokumentieren

Sicherstellen, dass das ERP jederzeit einen sauberen, verlässlichen Bestand ausweist

## Qualifikation

Eingeschriebene/r Student/in, idealerweise mit Bezug zu Wirtschaft, Logistik/Supply Chain, Wirtschaftsinformatik oder einem technischen Studiengang – auch andere Fachrichtungen mit Interesse am Thema sind willkommen

Erste Erfahrung mit ERP-Systemen (Odoo-Kenntnisse von Vorteil) oder hohe Bereitschaft, dich zügig einzuarbeiten

Strukturierte, sorgfältige Arbeitsweise und Freude an Ordnung und Systematik

Technisches Verständnis für Hardware wie Drucker und Scanner sowie keine Berührungsängste mit neuer Software

Kommunikationsstärke im Austausch mit mehreren Abteilungen (Produktion, Etikettierung, Konfektionierung, Lager)

Eigeninitiative und Hands-on-Mentalität – du willst ein Projekt von Grund auf mitgestalten, statt nur zu verwalten

## Benefits

Ein eigenständiges, sichtbares Digitalisierungsprojekt mit viel Gestaltungsspielraum und direkter Verantwortung

Eine Vergütung oberhalb des Branchendurchschnitts sowie einen Bonus bei erfolgreichem Projektabschluss

Flexible Arbeitszeiten im Rahmen deines Studiums – in der Vorlesungszeit bis zu 20 Std./Woche, in den Semesterferien nach Absprache auch mehr

Start ab dem 01.11.2026

Einblicke in Produktion, Qualität und Logistik eines wachsenden Premium-Herstellers für Tiernahrung

Kurze Entscheidungswege und direkten Kontakt zur Geschäftsführung

**Klingt nach dir?**

Dann freuen wir uns auf deine Bewerbung mit Lebenslauf und ein paar Zeilen dazu, warum du zu diesem Projekt passt.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
