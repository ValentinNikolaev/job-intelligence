# Senior Project Manager

Posted: 2026-08-24T05:30:23Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

#### **Why This Role Matters**

** **

As a Senior Project Manager, you will lead strategic rollout projects within the Business Transformation programme portfolio, driving high-impact initiatives and acting as a senior project leader. You will contribute to the strategic roadmap, ensuring alignment with Business Transformation’s and Intersnack’s long-term goals, and oversee multiple complex projects to deliver within scope, budget, and timeline.

You will enforce project management standards and compliance, provide thought leadership on methodologies and solutions, and drive the development of advanced project management tools. You will mentor and develop team members, collaborate with central and local teams to ensure seamless integration, monitor progress, proactively manage risks, and resolve implementation challenges. You will also ensure alignment with local and parallel projects to prevent conflicts and coordinate responsibilities across delivery teams.

#### **Your Role at Intersnack**

**Project & Leadership**

-

Lead multiple high-complexity projects or programmes with high strategic relevance, substantial budgets, and exceptional complexity.

-

Act as a trusted senior partner to Management Units, Group Functions, and Business Transformation leadership, providing thought leadership and strategic guidance.

-

Serve as a visible representative of Business Transformation’s expertise, maintaining long-term relationships with C-level stakeholders and key business partners.

**Methodology & Governance**

-

Drive the development and refinement of advanced methodologies, tools, and governance frameworks, ensuring continuous improvement, scalability, and innovation.

-

Assume responsibility for project initiation, cross-demand generation, and expansion of project scope to deliver maximum business value.

**Value Creation & Growth**

-

Identify and pursue opportunities for cross-demand generation, expanding the scope and impact of initiatives.

-

Contribute to the evolution of Business Transformation practices to enhance efficiency and strategic impact across the organization.

#### **Education:**

University degree in Business Administration, Science, Technology, Engineering, Computer Science, Mathematics, or a related field

#### **Experience**:

Comprehensive experience in leading large-scale transformation projects

#### **Skills**:

-

Exceptional leadership, strategic thinking, and stakeholder engagement skills

-

Ability to mentor and develop team members

-

Strong communication and collaboration skills

-

Proven ability to facilitate discussions between IT and business teams, ensuring alignment and results

-

Strong problem-solving and decision-making skills

-

Proficiency in advanced project management tools and methodologies (e.g., PRINCE2, PMI)

-

Experience with Infor-based IT solutions and multi-tenant cloud environments

-

Experience in implementing complex, integrated IT landscapes supported by processes in a multi-national context

-

Fluency in English; additional languages are a plus

#### **Additional requirements:**

-

Willingness to travel approximately 4 days per week across Intersnack locations.

#### **What We Offer**

-

*A ****rewarding and dynamic role**** within one of Europe’s leading savory snacks producers.*

-

*A ****collaborative and inclusive environment**** that values teamwork, recognises individuality, and encourages personal and professional growth.*

-

*A ****competitive salary and comprehensive benefits package****, along with opportunities to excel through your professionalism and performance.*

-

*A ****supportive and challenging work environment**** that empowers every team member to reach their full potential.*

-

*A**** caring workplace**** that that ****prioritises wellbeing and work-life balance****, understanding these are essential for success.*

-

*A culture that ****celebrates diversity****, harnessing its power and potential to drive innovation.*

-

***Extraordinary team spirit****, empowering you to take ownership and encouraging continuous improvement.*

#### **About Intersnack**

* *

*Intersnack is a leading European producer of savory snacks, dedicated to delivering exceptional quality and creating memorable snacking experiences. As a privately held company, we prioritise long-term growth and sustainability, driving innovation while maintaining a strong commitment to environmental and social responsibility.*

*With a robust financial performance—achieving a turnover exceeding €4.5 billion in 2024—we continue to expand our global footprint. Our operations span over 30 countries, supported by 12 regional management units, 45 production facilities, and a diverse workforce of approximately 15,000 employees worldwide.*

* *

#### **Your application**

Please ensure that all application documents are submitted **in English only**.

Kindly note that for **non-EU applicants**, a **valid work and residence permit** is required for this position.

**Are you excited about shaping the future with us? Then apply now - we look forward to getting to know you!**

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
