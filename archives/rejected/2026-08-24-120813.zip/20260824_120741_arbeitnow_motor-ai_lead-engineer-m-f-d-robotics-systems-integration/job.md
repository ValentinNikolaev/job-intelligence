# Lead Engineer (m/f/d) Robotics & Systems Integration (C++)

Posted: 2026-08-24T09:00:29Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

We are committed to making autonomous driving a reality in Germany. Leveraging our proprietary AI, we are on track to deliver Europe’s first certifiable Level 4 autonomous driving system. Since 2017, our multidisciplinary team has worked in seamless synergy to push the boundaries of what’s possible. The future of mobility is inevitable - and we are here to define it.

## Tasks

- Define the strategy and architecture for integrating perception, planning, and control software into a cohesive, reliable robotics system, and decide how the system is built, tested, and compiled

- Build, lead, and develop our Software Integration and Robotics team, ensuring the right skills and capacity to deliver stable system-level releases. Own psychological safety, 1:1s, growth, performance management, and leave planning for your direct reports

- Own the integration backlog, release deadlines, and cross-team dependencies (Perception, Motion Planning, Simulation), ensuring committed system-level releases are delivered reliably and meet performance and safety requirements

- Set quality standards - code review, CI/CD, coding guidelines - across the C++ integration and robotics codebase, and own code-quality gatekeeping

- Partner closely with the perception, motion planning, and simulation teams, acting as an internal technical evangelist to ensure architectural decisions support company-wide technical goals

## Requirements

- A completed degree in computer science, robotics, electrical engineering, mechatronics, or a comparable field - or equivalent vocational training/apprenticeship in a relevant technical discipline. Hands-on experience counts at least as much as the formal qualification

- 10+ years of overall experience in software engineering for robotics, embedded, or autonomous systems, including at least 5 years in a leadership role

- Proven experience leading an engineering team that includes mid-level engineers, with a hands-on hardware integration background and the ability to coach and upskill your team on embedded real-time software

- Excellent modern C++ skills (C++17–C++23), experience with embedded systems and RTOS, and strong robotics domain knowledge

- Experience with CI/CD and setting technical direction, including build and toolchain decisions; ROS2 experience is a strong plus, and prior software architecture experience is a plus

- Comfortable acting as an internal technical evangelist/consultant across teams, owning code-quality gatekeeping (PR reviews, CI) and authoring coding guidelines

- Strong people-leadership skills - psychological safety, coaching/1:1s, performance feedback - with a leadership orientation valued at least as highly as deep technical execution

- Excellent communication skills, able to translate technical decisions for non-technical stakeholders and align cross-functional teams

- English C1 is required; German is a plus

## Benefits

- Genuine team spirit: working in teams that drive change forward – no matter how complex and extensive the projects are

- Flexible working hours – with room for the realities of life (parenthood, caregiving responsibilities, voluntary work, etc.)

- Whether it's fashion, beauty, travel or culture – you'll receive numerous discounts through our partner Corporate Benefits

- Social relevance: We work on solutions that have game-changing qualities

- Subsidy for public transport tickets

- Your professional development is important to us – that's why we cover the costs of further education and training

- Excellent transport links: attractive location in Wedding with very good public transport connections

- Focus on people: Our strength lies in our diversity. We respect each other for who we are

The road ahead is being built right now. If you want a hand in shaping it - we'd like to hear from you.

At our new premises, we place great importance on getting to know one another and working together to drive our vision forward. Our international team is growing and working together on this exciting mission. Face-to-face collaboration is the key to success, which is why we have decided not to become a fully remote company.

*We ask recruitment consultancies and agencies not to submit candidate profiles without our prior express request. Any candidate profiles submitted without a prior written placement agreement signed by both parties shall be deemed to have been submitted unsolicited. No entitlement to placement fees or other charges shall arise from their use or from the subsequent recruitment of the candidate.*

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
