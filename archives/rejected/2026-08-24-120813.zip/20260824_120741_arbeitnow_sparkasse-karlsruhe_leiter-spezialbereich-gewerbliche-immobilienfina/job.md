# Leiter Spezialbereich gewerbliche Immobilienfinanzierung (m/w/d)

Posted: 2026-08-24T09:30:30Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**Mit einer Bilanzsumme von über 12 Mrd. €, ca. 1.300 Mitarbeitenden und einer über 213-jährigen Unternehmensgeschichte sind wir eines der größten und das älteste selbstständige Finanzdienstleistungsinstitut unserer Region. Gemessen an der Bilanzsumme ist die Sparkasse Karlsruhe die fünftgrößte Sparkasse in Baden-Württemberg und gehört zu den 25 größten Sparkassen in Deutschland. Wir überzeugen unsere Kunden vor Ort und digital mit individueller Beratung und bestem Service. Unser Erfolgsrezept? Der Mensch! Die Nähe zu unseren Kunden und unseren Mitarbeitenden ist unser wichtigstes Ziel.**

Sie führen ein Team mit 11 Mitarbeitenden und sind als Spezialbereich in der Gesamtabteilung Firmenkundenberatung angesiedelt. Ihr Team betreut die **Bauträger, Projektgesellschaften und professionellen Immobilieninvestoren.**

Kommen Sie zur Sparkasse Karlsruhe – werden Sie Teil unseres Teams.

## Aufgaben

- Führung der Mitarbeiter

- Aktive, ganzheitliche Betreuung zugeordneter Kunden im Rahmen eines professionellen Kundenbeziehungsmanagements

- Betriebswirtschaftliche Analyse der eingereichten Unterlagen

- Früherkennung von Kreditrisiken, ggf. Intensivbetreuung

- Betreuung der gewerblichen Aktivbedarfe der Kunden und Erstellung von Kreditbeschlüssen

## Qualifikation

- Bankbetriebswirt/-in, Bachelor oder vergleichbare Qualifikation

- idealerweise Führungserfahrung

- Mehrjährige erfolgreiche Tätigkeit im gewerblichen Kreditgeschäft

- Erfahrungen im Bereich Rund um die Immobilie

## Benefits

- eine krisensichere Anstellung bei einem starken regionalen Arbeitgeber

- Als tarifgebundene Arbeitgeberin wenden wir die einschlägigen tariflichen Regelungen des TVöD-AT sowie des TVöD-BT-S an.

Die Vergütung erfolgt nach Entgeltgruppe 13. Die Jahresbruttovergütung orientiert sich an der Erfahrung und Qualifikation und liegt in einer Spanne von ca. 73.400 € bis ca. 97.600 € mit 13,83 Monatsgehältern inkl. Höchstbetrag der vermögenswirksamen Leistungen

- Möglichkeit einer leistungsorientierten Vertriebsprämie

- 39-Stunden Woche bei Vollzeit

- Flexible Arbeitszeitgestaltung (ohne Wochenendarbeit und Spätdienste)

- 32 Urlaubstage (ab 2027: 33 Tage) + bezahlte Freistellung am 24.12. und 31.12.

- Möglichkeit zum mobilen Arbeiten

- Betriebliche Altersvorsorge

- Betriebliche Krankenversicherung

- Unterstützung Ihrer beruflichen Aus- und Weiterbildung

- Fahrradleasing

- 50% Zuschuss zum Jobticket

- weitere Vergünstigungen bei Finanzprodukten sowie exklusive Mitarbeiterangebote zu Top-Konditionen über "corporate benefits" – Mitarbeiterrabatte bei über 1.500 Shops

- weitere Benefits finden Sie auf unserer Homepage.

**Interessiert?**Wir freuen uns auf Ihre Bewerbung unter Angabe Ihrer Gehaltsvorstellung (bezogen auf Vollzeit) und Ihres möglichen Eintrittstermins. Bewerben Sie sich bis zum **30.09.2026.**

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
