# AI Content & Design Creator (m/w/d)

Posted: 2026-08-24T10:30:32Z

## Rejection

- Category: tech_stack
- Reason: role does not mention Go/Golang or PHP

**Wer wir sind:**

Seit über 25 Jahren steht ZEINpharma für Mikronährstoffe in Premiumqualität. Heute umfasst das Produktportfolio über 170 Produkte – von Vitaminen, Mineralstoffen und Enzymen bis hin zu patentierten Spezialwirkstoffen. Als Familienunternehmen legen wir Wert auf erlesene Inhaltsstoffe, höchste Reinheit und die Formulierung unserer Produkte auf Basis neuester wissenschaftlicher Erkenntnisse. Entwicklung und Herstellung erfolgen aus einer Hand an unserem Unternehmensstandort im hessischen Nauheim – für Kunden in Deutschland und weltweit.

Was uns auszeichnet: Der Anspruch, Dinge neu und anders zu denken – kurze Entscheidungswege und Raum für persönliche Gestaltung. ‚Jeder Tag ist Deiner' ist hierbei kein einfaches Versprechen. Wir suchen kreative, kluge und erfahrene Persönlichkeiten, die mit uns das tägliche ‚Plus' an Gesundheit weitergeben – an Menschen, die das Besondere suchen und für die ein gesundes und erfülltes Leben besonders wichtig ist.

## Aufgaben

**Deine Rolle:**

Unser Marketing-Team wächst weiter – Was jetzt fehlt, ist die Person, die Content und Design mit KI-Tools auf ein neues Produktions-Level hebt: schneller, skalierbarer und mit einem Qualitätsanspruch, der sich nicht anlesen lässt, sondern aus echter Tool-Erfahrung kommt. Du arbeitest eng mit dem Senior Art Director zusammen und übersetzt Kampagnen- und Contentkonzepte in Bild, Bewegtbild und automatisierte Content-Pipelines.

Zu deinen Aufgaben gehören:

- Konzeption und Produktion von Grafiken, Social-Media-Content, Ad Creatives und Produktvisuals mit KI-Tools (Midjourney, Adobe Firefly, DALL·E, Photoshop Generative Fill)

- Enge Zusammenarbeit mit Senior Art Director und Content Marketing Manager – Umsetzung von Kampagnen- und Contentkonzepten in Bild- und Videosprache

- Aufbau und Pflege KI-gestützter Content-Workflows und Automatisierungen (Template-Systeme, Batch-Produktion, Content-Pipelines)

- Video- und Bewegtbild-Content mit KI-Tools (Runway, Sora, CapCut AI o. Ä.) für Social Media und Ads

- Evaluierung und Einführung neuer KI-Tools für Design, Content und Automatisierung

- Sicherstellung von Markenkonsistenz und Qualität bei allen KI-generierten Assets

## Qualifikation

**Dein Profil:**

- Ausbildung/Studium im Bereich Grafikdesign, Mediengestaltung, Kommunikationsdesign oder vergleichbar – Quereinstieg mit starkem Portfolio ist willkommen

- Praktische, hands-on Erfahrung mit KI-Tools für Bild- und Videogenerierung (Midjourney, Adobe Firefly, DALL·E, Runway o. Ä.)

- Sicherer Umgang mit Adobe Creative Cloud (Photoshop, Illustrator, Premiere)

- Verständnis für Prompting und Workflow-Automatisierung (z. B. n8n, Zapier, Make) von Vorteil

- Gespür für Marken- und Bildsprache sowie hohe Qualitätsansprüche an das eigene Ergebnis

- Proaktive, experimentierfreudige Arbeitsweise – du testest neue Tools, bevor andere überhaupt davon gehört haben

## Benefits

**Was dich bei uns erwartet:**

- Die Chance, KI-gestützte Content-Produktion bei ZEINpharma von Grund auf zu prägen – kein Verwalten von Bestehendem, sondern echtes Aufbauen

- Modernes, neues Büro in Rüsselsheim, kurze Entscheidungswege und direkter Draht zur Geschäftsführung

- Budget für Tools, Lizenzen und Weiterbildung im KI-Bereich

- 50 % Mitarbeiterrabatt auf alle ZEINpharma-Produkte sowie Zugang zu Corporate Benefits

- Hochmoderne, höhenverstellbare Büroausstattung, Mitarbeiterparkplätze und kostenlose Getränke

**Du möchtest Teil unseres Teams werden?**

Wolltest du schon immer zeigen, was KI-gestütztes Design wirklich leisten kann – statt nur darüber zu reden? Und legst du Wert auf ein innovatives Umfeld mit flachen Hierarchien und viel Raum für persönliche Entwicklung?

Dann bist du bei uns genau richtig.

Bei uns zählen Leidenschaft für Gesundheit, für das Besondere, unternehmerisches Denken und die Lust, Dinge wirklich voranzubringen. Wir freuen uns auf dich!

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
