# Product Owner Data & AI (m/w/d) – fluege.de

Posted: 2026-08-24T07:30:33Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

## Einleitung

TC Flights Germany ist bekannt für eines der erfolgreichsten Flugportale in Deutschland – . Wir sind Teil der Tongcheng Travel, einem international agierenden Unternehmen im Online-Reisevertrieb. Unsere Vision ist es, Deutschlands erste Wahl für den Vergleich und die Buchung von Flugreisen zu sein.

Wir bieten unseren Kund:innen ein benutzerfreundliches und individuelles Buchungserlebnis. Das erreichen wir gemeinsam mit all unseren Mitarbeitenden, die in einem flexiblen und modernen Arbeitsumfeld ihre individuellen Stärken und Ideen proaktiv einbringen. Wir legen großen Wert auf eine positive und motivierende Atmosphäre, in der alle gerne zur Arbeit kommen. Wir ergreifen Initiative, übernehmen Verantwortung, respektieren einander, treiben Veränderungen voran, sind wissbegierig und erarbeiten Lösungen als Team.

Du möchtest die Zukunft datengetriebener Produkte bei [fluege.de](http://fluege.de) aktiv mitgestalten? Du bewegst dich sicher zwischen Business, Technologie und Daten und möchtest AI-Lösungen nicht nur entwickeln, sondern auch deren strategische Ausrichtung vorantreiben?

Als **Product Owner Data & AI (m/w/d)** verbindest du Produktverantwortung mit Expertise in Machine Learning, Data Science und Generative AI. Gemeinsam mit unseren Fachbereichen identifizierst und priorisierst du wertschöpfende Anwendungsfälle und entwickelst innovative Lösungen mit messbarem Business Impact. Dabei begleitest du den gesamten Lebenszyklus moderner Data- und AI-Produkte und agierst als zentrale Schnittstelle zwischen Business, Analytics und Technologie.

**Klingt das interessant für dich?** Dann werde Teil unseres Teams und gestalte die Zukunft datengetriebener Produkte bei [fluege.de](http://fluege.de) mit. Die Position ist im Rahmen einer Elternzeitvertretung für voraussichtlich 15 Monate befristet.

## Deine Aufgaben

- Du verantwortest die Roadmap unserer Data-, Analytics- und AI-Produkte und priorisierst Initiativen nach Business Value und strategischer Relevanz

- Du identifizierst gemeinsam mit Fachbereichen datengetriebene Potenziale und übersetzt Geschäftsanforderungen in konkrete AI- und Machine-Learning-Lösungen

- Du analysierst komplexe Datensätze, entwickelst Prognosemodelle und leitest daraus umsetzbare Handlungsempfehlungen ab

- Du konzipierst, entwickelst und evaluierst Machine-Learning-Modelle sowie moderne AI-Lösungen auf Basis von LLMs, RAG und agentischen Workflows

- Du begleitest den gesamten Produktlebenszyklus von der Problemdefinition über Entwicklung und Validierung bis zum produktiven Einsatz

- Du verantwortest den Betrieb, das Monitoring und die kontinuierliche Optimierung produktiver AI-Systeme in modernen Cloud-Umgebungen

- Du arbeitest eng mit Product, Engineering, Analytics und weiteren Stakeholdern zusammen und kommunizierst Fortschritte, Risiken und Ergebnisse transparent

## Dein Profil

- Mehrjährige Berufserfahrung im Bereich Machine Learning, Data Science, AI Engineering oder Advanced Analytics

- Erfahrung als Product Owner, Product Manager oder in einer vergleichbaren Rolle mit Verantwortung für Produkte, Projekte oder komplexe Initiativen

- Sehr gute Kenntnisse in Python, SQL sowie modernen Data-Science- und Machine-Learning-Frameworks

- Fundierte Erfahrung mit Generative AI, Large Language Models (LLMs), Prompt Engineering und Retrieval-Augmented Generation (RAG)

- Erfahrung mit Cloud-Plattformen, idealerweise AWS, sowie dem produktiven Betrieb von AI- und ML-Lösungen

- Kenntnisse in MLOps, CI/CD, Monitoring und der kontinuierlichen Weiterentwicklung produktiver Systeme

- Analytische Stärke, ausgeprägte Kommunikationsfähigkeit und die Fähigkeit, technische und fachliche Anforderungen miteinander zu verbinden

- Sehr gute Deutsch- und Englischkenntnisse in Wort und Schrift

## Das bieten wir dir

- **Onboarding:** professionelle Einarbeitung, Buddy-Programm, Willkommenswoche

- **Agiles Arbeitsumfeld:** aktive Beteiligung an der Gestaltung unserer Produkte und Strategie

- **Work-Life-Balance:** 30 Tage bezahlter Urlaub, mobiles Arbeiten in Deutschland und weltweit mit Workflex, Sabbatical, HomeOffice Option

- **Weiterentwicklung:** Individuelle Entwicklungspläne, Coaching, Online-/Offline-Schulungen & Workshops, kontinuierliches Feedback

- **Unternehmerische Verantwortung:** zertifizierter Klimapartner seit 2023

- **Essen & Trinken:** Essenszuschuss, kostenlose Getränke und Speisen

- **Wertschätzung:** bis zu 34 Urlaubstage je nach Betriebszugehörigkeit, Jubiläumsbonus, Mitarbeiterempfehlungsbonus

- **Events:** regelmäßige Team-, Firmen- und Büroveranstaltungen

- **Wohlbefinden:** monatlicher Zuschuss zur EGYM-Wellpass-Mitgliedschaft, Betriebliches Gesundheitsmanagement, Betriebsarzt, sportliche Aktivitäten und Veranstaltungen, Ermäßigung für Fitnessstudios, betriebliche Altersvorsorge

- **Diversity:** bewusster Fokus auf internationale Teams und Zusammenarbeit

- **Mobilität:** Zuschuss zum Deutschland-Ticket, JobRad

## Deine Reise zu uns

Bei uns ist jede Person willkommen – egal, wer du bist oder woher du kommst. Wir freuen uns über jede Bewerbung. Bei ist Platz für Vielfalt!

Deinen Pre-Check-In gestalten wir so einfach wie möglich. Sende uns einfach deinen CV unter Angabe deines frühestmöglichen Eintrittstermins und deiner Gehaltsvorstellung. Wir freuen uns auf deine Unterlagen.

**Ready for Boarding?**

Hast du noch offene Fragen, dann schreibe uns gerne eine E-Mail an .

Für tiefere Einblicke in unser Arbeitsleben folge uns gerne auf und/oder

TC Flights Germany GmbH

People & Culture

Hainstraße 17-19

04109 Leipzig

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
