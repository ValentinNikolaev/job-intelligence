# Creative Strategist (m/w/d) - Hybrid (Remote+Office)

Posted: 2026-08-24T10:00:46Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Wir bei Inkster schreiben Eigenverantwortlichkeit, Motivation und Spaß groß! Als 10 köpfiges Team aus Digital Natives und unserem einzigartigen 2-Wochen Tattoo auf Fruchtbasis sind wir im Juni 2021 gestartet und in wenigen Monaten zum Europamarktführer aufgestiegen und verkaufen in sechs internationale Märkte. Wenn du dich für E-Commcerce, Marketing und Online-Shops interessierst, bist du bei uns richtig.

**Zur Verstärkung suchen wir ab 01.10.26 eine/n Creative Strategist.**

Du findest E-Commerce und die Abläufe dahinter interessant? Du hast Lust in einem spannenden Start-up mit hohem Erfolgspotenzial zu arbeiten?

Als Creative Strategist (m/w/d) überwachst und optimierst Du bei Inkster den gesamten Prozess von der Konzeptionierung/Strategie über die Produktion bis zum Monitoring von Creatives eigenständig. Als fünfte Vollzeitkraft und Mitgliedes unseres 10-köpfigen Teams, hast direkten Einfluss auf den Erfolg und erhältst exklusive Einblicke in die Wachstumsstrategie einer jungen Love-Brand sowie die Gestaltungsmacht Inkster mit zu bauen. Wir freuen uns auf dich!

## Aufgaben

- Du entwickelst innovative und überzeugende Kampagnen, die unsere Kunden auf uns aufmerksam machen.

- Du erstellst die Briefings für unser Content Creator:innen Team.

- Du analysierst regelmäßig unsere eigenen Anzeigen sowie die besten Anzeigen auf dem Markt. Du zerlegst gemeinsam mit dem Team historische Kampagnen und aktuelle Trends in ihre Einzelteile und stellst Thesen auf, warum diese so gut performen und was wir konkret daraus lernen und als Inspiration mitnehmen können

- Du überlegst dir neue Ideen für unsere Testing-Kampagnen, sammelst strukturierte Learnings und verbesserst so kontinuierlich die Performance unserer bestehenden und zukünftigen Kampagnen

- Du organisierst und bedienst den Content-Bedarf des Teams und der unterschiedlichen Kanäle

- Du leitest das Projektmanagement unserer externen Content Agentur

## Qualifikation

- Du hast ein abgeschlossenes Studium im Bereich Medien, Marketing, Kommunikation o.ä. oder Du überzeugst uns, dass Du das nicht brauchst

- Unterschiedlichen Anforderungen der Plattformen Instagram, TikTok & Co. sind Dir bekannt und du verbringst auch gerne deine Freizeit auf diesen Plattformen

- Dich zeichnen deine Eigeninitiative & Selbstständigkeit aus

- Du kannst dir selbstsicher Kampagnen-Konzepte ausdenken

- Du hast ein Gespür für die aktuellen Trends und ein starkes Interesse für Social Media

- Du kennst den Unterschied zwischen UGC und Video Ads, als auch organic und paid Social Media Content

- Du bist kommunikativ, teamfähig und hast eine sehr ausgeprägte kreative Ader und ein Gespür für die nächsten Social-Media Trends

- Du hast sehr gute Sprachkenntnisse in Deutsch und Englisch

## Benefits

- Die Möglichkeit ein Teil unserer Familie zu werden, mit uns gemeinsam zu wachsen und als Schlüsselfigur Verantwortung zu übernehmen

- Flexibles Arbeiten mit flachen Hierarchien und einem hochmotivierten Team

- Du wirst gefordert und gefördert. Du lernst von uns und wir von dir.

- EGYM Wellpass Fitnessmitgliedschaft, mit der du alle relevanten Yoga, Wellness und Fitnessangebote nutzen kannst

- Regelmäßige Team-Events auf Kosten der Firma

- Abwechslungsreiche Aufgaben

- Deine Bedürfnisse im Mittelpunkt: Hybrid Modell mit Remote Work + attraktivem Office Standort im Herzen von Hamburg

- Wir freuen uns auf deine Bewerbung! 🚀

Wir mögen es unkompliziert und effektiv. Schick uns einfach deinen **Lebenslauf** und ein **kurzes Schreiben**, warum gerade du die richtige Person für den Job bist und falls du Erfahrung in der Kampagnen-Erstellung hast, kannst du diese gerne kurz und knapp an deine Bewerbung anhängen.

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
