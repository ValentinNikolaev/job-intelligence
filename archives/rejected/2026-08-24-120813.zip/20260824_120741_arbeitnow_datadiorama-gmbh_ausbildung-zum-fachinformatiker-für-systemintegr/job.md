# Ausbildung zum Fachinformatiker für Systemintegration

Posted: 2026-08-24T07:01:08Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**Werde Teil des Datadiorama-Teams in Potsdam!**

## Aufgaben

Du interessierst dich für IT-Systeme, Netzwerke und wie komplexe Infrastrukturen im Hintergrund funktionieren? Du möchtest Theorie nicht nur lernen, sondern bei realen Kundenprojekten in der Praxis anwenden? Dann suchen wir Dich!

Die Datadiorama GmbH ist ein modernes IT-Systemhaus in Potsdam. Wir unterstützen unsere Kunden bei der Digitalisierung durch innovative IT-Services, Netzwerktechnik und Softwarelösungen. Wir wachsen weiter und suchen für unseren Standort in Potsdam Verstärkung für unser Team.Deine Aufgaben in der Ausbildung

Während deiner dreijährigen Ausbildung zum Fachinformatiker für Systemintegration wirst du zum Experten für unsere IT-Infrastruktur. Dein Fokus liegt auf dem Planen, Installieren und Betreiben vernetzter IT-Systeme.

- **IT-Infrastruktur:** Du lernst, wie man Serverlandschaften plant, konfiguriert und administriert.

- **Netzwerktechnik:** Du richtest Netzwerke ein, überwachst die Kommunikation und sorgst für eine reibungslose Anbindung – ob LAN, WAN oder VPN.

- **Support & Troubleshooting:** Du bist erste Anlaufstelle bei technischen Problemen, analysierst Störungen und findest effiziente Lösungen.

- **IT-Sicherheit & Datenschutz:** Du lernst, wie man Systeme vor Bedrohungen schützt und betriebliche Sicherheitsvorgaben umsetzt.

- **Kundenbetreuung:** Du berätst unsere Kunden bei der Auswahl von IT-Lösungen und hilfst bei der Implementierung neuer Technologien.

## Qualifikation

- **Technisches Interesse:** Du begeisterst dich für Hardware, Betriebssysteme und Netzwerke.

- **Analytisches Denken:** Du hast Spaß daran, Fehler zu suchen, logisch zu denken und technische Probleme zu lösen.[1](https://drive.google.com/open?id=1GGXwFmX3VYL5rKpiIzF7XbTy2SEXBXuy)

- **Lernbereitschaft:** Du bist motiviert, dich schnell in neue IT-Themen und Technologien einzuarbeiten.

- **Teamgeist & Kommunikation:** Du arbeitest gerne im Team und hast Freude daran, mit Kunden zu kommunizieren.[1](https://drive.google.com/open?id=1GGXwFmX3VYL5rKpiIzF7XbTy2SEXBXuy)

- **Zuverlässigkeit:** Du arbeitest strukturiert und behältst auch in stressigen Situationen den Überblick.

## Benefits

- **Praxis pur:** Bei uns bist du kein "Kaffeekocher", sondern fester Bestandteil des Teams. Du lernst "on the job" an realen Kundenprojekten.

- **Erfahrenes Team:** Wir unterstützen dich bei deiner fachlichen Entwicklung und stehen dir mit Know-how zur Seite.

- **Perspektive:** Nach erfolgreichem Abschluss streben wir eine langfristige Übernahme unserer Auszubildenden an.

- **Modernes Umfeld:** Ein offenes, dynamisches Arbeitsklima in Potsdam und Berlin

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
