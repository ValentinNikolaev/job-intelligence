# Head of Quality (m/w/d) - unbefristete Direkteinstellung beim Kunden

Posted: 2026-08-24T06:30:51Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Für ein international erfolgreiches Unternehmen suchen wir eine erfahrene Führungspersönlichkeit zur Leitung des Bereichs Qualitätssicherung und Qualitätsmanagement mit Führungsverantwortung. Standort: Süddeutschland.

## Aufgaben

- Fachliche und organisatorische Leitung des Bereichs Qualitätssicherung und Qualitätskontrolle

- Koordination sämtlicher Aktivitäten zur Sicherstellung der Produkt- und Prozessqualität

- Führung, Motivation und Weiterentwicklung des QS-Teams

- Überwachung und kontinuierliche Verbesserung von Qualitätsstandards und Prüfprozessen

- Analyse von Qualitätskennzahlen sowie Ableitung geeigneter Maßnahmen zur Optimierung

- Durchführung und Begleitung interner und externer Audits

- Zusammenarbeit mit Lieferanten im Rahmen von Qualitätsmeldungen und Lieferantenbewertungen

- Durchführung von Lieferantenaudits sowie Unterstützung bei qualitätsrelevanten Themen

- Erstellung und Pflege von Prüfplänen, Prüfprozessen und Qualitätsdokumentationen

- Enge Zusammenarbeit mit angrenzenden Bereichen wie Produktion, Entwicklung und Einkauf

## Qualifikation

- Abgeschlossenes technisches Studium oder eine technische Ausbildung mit entsprechender Weiterbildung (z. B. Meister oder Techniker)

- Mehrjährige Berufserfahrung im Qualitätsmanagement eines produzierenden Unternehmens

- Erfahrung in der Führung eines Teams im Qualitätsumfeld

- Kenntnisse gängiger Qualitätsmanagementsysteme und Normen gemäß DIN EN ISO 13485

- Erfahrung im Umgang mit Lieferanten sowie in der Durchführung von Audits

- Gute Englischkenntnisse in Wort und Schrift

- Strukturierte, sorgfältige und lösungsorientierte Arbeitsweise

- Teamfähigkeit sowie ausgeprägte Kommunikationsstärke

## Benefits

- Verantwortungsvolle Führungsposition mit Gestaltungsspielraum

- Modernes Arbeitsumfeld und kurze Entscheidungswege

- Attraktives Vergütungspaket mit zusätzlichen Leistungen

- Langfristige Perspektive in einem international ausgerichteten Unternehmen

- Angenehmes Arbeitsklima in einem engagierten Team

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
