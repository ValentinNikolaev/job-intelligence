# Influencer & Social Media Marketing Manager (m/w/d)

Posted: 2026-08-24T10:30:32Z

## Rejection

- Category: tech_stack
- Reason: role does not mention Go/Golang or PHP

**Wer wir sind:**

Seit über 25 Jahren steht ZEINpharma für Mikronährstoffe in Premiumqualität. Heute umfasst das Produktportfolio über 170 Produkte – von Vitaminen, Mineralstoffen und Enzymen bis hin zu patentierten Spezialwirkstoffen. Als Familienunternehmen legen wir Wert auf erlesene Inhaltsstoffe, höchste Reinheit und die Formulierung unserer Produkte auf Basis neuester wissenschaftlicher Erkenntnisse. Entwicklung und Herstellung erfolgen aus einer Hand an unserem Unternehmensstandort im hessischen Nauheim – für Kunden in Deutschland und weltweit.

Was uns auszeichnet: Der Anspruch, Dinge neu und anders zu denken – kurze Entscheidungswege und Raum für persönliche Gestaltung. ‚Jeder Tag ist Deiner' ist hierbei kein einfaches Versprechen. Wir suchen kreative, kluge und erfahrene Persönlichkeiten, die mit uns das tägliche ‚Plus' an Gesundheit weitergeben – an Menschen, die das Besondere suchen und für die ein gesundes und erfülltes Leben besonders wichtig ist.

## Aufgaben

**Deine Rolle:**

Du baust unser Influencer-Programm und unsere Social-Media-Präsenz systematisch auf – von der ersten Creator-Ansprache bis zur laufenden Kampagnensteuerung. Gemeinsam mit Content Marketing, Art Direction und unserem AI Content Creator sorgst du dafür, dass ZEINpharma auf Instagram, TikTok & Co. sichtbar, authentisch und wirksam auftritt.

Zu deinen Aufgaben gehören:

- Aufbau und Steuerung des Influencer-Programms: Auswahl, Ansprache, Vertragsverhandlung, Kampagnensteuerung

- Redaktionsplanung und operative Umsetzung für unsere Social-Media-Kanäle

- Community Management sowie Steuerung von Reichweite und Engagement

- Erfolgsmessung und Reporting von Influencer- und Social-Kampagnen

- Enge Zusammenarbeit mit Content Marketing, Art Direction und AI Content & Design Creator

## Qualifikation

**Dein Profil:**

- Mehrjährige Erfahrung im Influencer Marketing und/oder Social Media Management – idealerweise Consumer Health, Beauty oder FMCG

- Bestehendes Netzwerk zu Creators und Agenturen von Vorteil

- Kennzahlenorientiert: Du steuerst über Reichweite, Engagement und ROI, nicht nur nach Bauchgefühl

- Kreativität gepaart mit organisatorischem Talent und Verhandlungsgeschick

## Benefits

**Was dich bei uns erwartet:**

- Die Möglichkeit, Influencer Marketing bei ZEINpharma von Grund auf aufzubauen

- Enge Zusammenarbeit mit einem wachsenden, kreativen Marketing-Team

- Kurze Entscheidungswege, flache Hierarchien und viel Gestaltungsspielraum

- 50 % Mitarbeiterrabatt auf alle ZEINpharma-Produkte sowie Zugang zu Corporate Benefits

**Du möchtest Teil unseres Teams werden?**

Wolltest du schon immer zeigen, was KI-gestütztes Design wirklich leisten kann – statt nur darüber zu reden? Und legst du Wert auf ein innovatives Umfeld mit flachen Hierarchien und viel Raum für persönliche Entwicklung?

Dann bist du bei uns genau richtig.

Bei uns zählen Leidenschaft für Gesundheit, für das Besondere, unternehmerisches Denken und die Lust, Dinge wirklich voranzubringen. Wir freuen uns auf dich!

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
