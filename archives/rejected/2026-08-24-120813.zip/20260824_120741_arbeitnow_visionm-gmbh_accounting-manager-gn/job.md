# Accounting Manager (gn)

Posted: 2026-08-24T10:30:32Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Die Mission unseres Kunden ist es, Menschen, Umwelt und Produktionsprozesse vor den schädlichen Auswirkungen industrieller Prozesse zu schützen. Damit leistet das Unternehmen einen wichtigen Beitrag zu einer effizienten Produktion, zum Umweltschutz sowie zu mehr Sicherheit am Arbeitsplatz.

Das Unternehmen mit Hauptsitz in Schweden ist ein führender internationaler Anbieter in den Bereichen Luftfiltration, Verfahrenstechnik sowie Mess-, Steuer- und Regelungstechnik. Insgesamt beschäftigt die Unternehmensgruppe weltweit rund 2.400 Mitarbeitende.

## Aufgaben

- Verantwortung für alle Accounting-Prozesse für vier deutsche Gesellschaften

- Führung und Entwicklung des sechs-köpfigen Teams

- Sicherstellung der korrekten und termingerechten Erstellung der Abschlüsse sowie des Management-Reportings gemäß HGB und IFRS

- Koordination und Steuerung der Compliance-Prozesse einschl. Umsatzsteuer, Körperschaftssteuer, Quellensteuer

- Zentraler Ansprechpartner im Finance-Umfeld für lokale rechtliche und regulatorische Fragestellungen

- Sicherstellung der Einhaltung interner Kontrollsysteme und Unternehmensrichtlinien

- Enge Zusammenarbeit mit Wirtschaftsprüfern, Steuerberatern und Behörden bei Jahresabschlussprüfungen und Betriebsprüfungen

- Leitung und Unterstützung von Optimierungs- und Auto-matisierungsprozessen im Accounting

- Überwachung konzerninterner Transaktionen und Treasury

- Zusammenarbeit mit regionalen und globalen Finanzteams und Mitwirkung an Transformations- und Migrationsprojekten

## Qualifikation

- Erfolgreich abgeschlossenes Studium mit Schwerpunkt Finanzen, Rechnungswesen, Wirtschaftswissenschaften oder vergleichbarer Fachrichtung und mindestens 5 Jahre einschlägige Berufserfahrung oder vergleichbare Ausbildung mit entsprechender Berufserfahrung, idealerweise in einem internationalen Umfeld mit Verantwortung für deutsche Gesellschaften

- Fundierte Kenntnisse der Rechnungslegung nach HGB und IFRS sowie des deutschen Steuerrechts, einschließlich Erstellung gesetzlicher Abschlüsse und Begleitung von Abschlussprüfungen

- Umfassendes Verständnis der End-to-end-Prozesse im Rechnungswesen (Hauptbuch, Kreditoren-/Debitorenbuchhaltung, Anlagenbuchhaltung und Reporting)

- erste Führungserfahrung oder erkennbares Führungspotenzial, ausgeprägte Kommunikationsfähigkeit und Eigeninitiative

- Sehr gute Deutsch- und Englischkenntnisse

## Benefits

- Arbeitgeberzuschuss zur Betrieblichen Altersvorsorge

- Bezuschusstes Mittagessen

- weitere Corporate Benefits

Für Rückfragen steht Ihnen Frau Kerstin Mader, 06174 9619 310, gerne zur Verfügung.

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
