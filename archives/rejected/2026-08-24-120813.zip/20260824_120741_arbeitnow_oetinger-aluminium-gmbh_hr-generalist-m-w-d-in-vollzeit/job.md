# HR-Generalist (m/w/d) - in Vollzeit

Posted: 2026-08-24T06:30:50Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Die OETINGER Aluminium GmbH produziert mit ihren 400 Mitarbeitern an zwei Standorten im Süden Deutschlands und einem Standort in Tschechien ca. 220.000 Tonnen Aluminiumlegierungen aus Recyclingmaterial. OETINGER ist damit einer der bedeutendsten Hersteller von Aluminiumgusslegierungen in Europa.

## Aufgaben

- Operative Durchführung, kontinuierliche Optimierung und Digitalisierung der HR-Prozesse

- Unterstützung und Mitgestaltung von Personalentwicklungsmaßnahmen

- Mitarbeit bei arbeitsrechtlichen Fragestellungen sowie der Umsetzung gesetzlicher und tariflicher Anforderungen

- Analyse von HR-Kennzahlen sowie Ableitung geeigneter Maßnahmen

- Aktive Mitgestaltung der HR-Strategie, Umsetzung personalstrategischer Themen und Einbringen in die Entwicklung von Standards, Rollen und HR-Instrumenten

- Eigenverantwortliche Durchführung von Recruiting-Prozessen

## Qualifikation

- Erfolgreich abgeschlossenes Studium mit Schwerpunkt Personal, Betriebswirtschaft oder vergleichbare Qualifikation

- Mehrjährige Berufserfahrung im Personalwesen als HR Generalist, HR Business Partner oder in einer vergleichbaren Position

- Gute Kenntnisse im Arbeitsrecht und in modernen HR-Prozessen

- Erfahrung in der Zusammenarbeit mit Führungskräften unterschiedlicher Hierarchieebenen

- Hohe Eigeninitiative, Verantwortungsbewusstsein und unternehmerisches Denken

- Stärke in Kommunikation, Konfliktlösung und lösungsorientiertem Arbeiten

- Sicherer Umgang mit HR-Systemen sowie MS Office

- Sehr gute Englischkenntnisse in Wort und Schrift

- Kenntnisse in P&I LOGA von Vorteil

## Benefits

- Unbefristete Tätigkeit in einem tarifgebundenen Unternehmen

- Fundierte Einarbeitung und bedarfsorientierte Weiterbildungsmöglichkeiten

- Sichere berufliche Perspektive in einer zukunftsweisenden Branche mit nachhaltigen Ansätzen

- JobRad, Wellpass und kostenlose Getränke

Du möchtest Personalprozesse nicht nur verwalten sondern aktiv mitgestalten?

Sende uns Deine Bewerbung oder rufe uns einfach unter 07309 83-202 an.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
