# Senior Consultant – Healthcare (m/w/d)

Posted: 2026-08-24T05:30:15Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Bereit für deine Karriere als **Senior Consultant** **– Healthcare**? Du willst im Healthcare Bereich wirklich etwas bewegen?
Werde Teil einer aufstrebenden Boutique-Beratung, die **neue Maßstäbe im Gesundheitswesen** setzt.
**Die Kunden**: Leistungserbringer **im gesamten DACH-Raum** – von privaten Klinikträgern über universitäre Einrichtungen bis hin zu HealthTech Startups.
**Die Mission: **nachhaltige Strategien & realisierbare Lösungen für eine zukunftsfähige Versorgung – ganzheitlich, menschlich, wirkungsorientiert.

### **Deine Benefits**

-

Großräumiges, **modernes Office in München** mit super Öffi-Anbindung

-

**Hybrides Arbeiten**: 1–2 Tage Homeoffice pro Woche

-

Onboarding Buddy ab Tag 1

-

**Regelmäßige Teamevents** – ob Weihnachtsfeier, After-Work-Drinks, Selbstverteidigungskurse zum Weltfrauentag oder Workation in der Toskana

-

Klarer Karrierepfad, regelmäßige Feedbackschleifen & individuelle **Entwicklungschancen**

-

**Weiterbildungsbudget **für deine persönliche und fachliche Entwicklung.

-

Gemütliche Küche mit kostenlosen Getränken

-

50 € monatlich extra – für dein Urban Sports-Abo, Jobrad oder den nächsten Einkauf. Du entscheidest!

-

Ein Jahresbruttogehalt ab 72.000€ Brutto je nach Erfahrung und Qualifikation wird dir eine deutliche Überzahlung ermöglicht – zusätzlich erhältst du einen Bonus on top!

-

Last but not least: Offenheit für deine Wünsche!

### **Deine Aufgaben**

Als Senior Consultant unterstützt du bei der **Steuerung komplexer Beratungsprojekte** und begleitest Kunden bei strategischen und operativen Transformationsvorhaben.

-

Mitarbeit bei der Koordination und (Teil-)Leitung anspruchsvoller Projekte in den Bereichen **Sanierung, Restrukturierung, Optimierung und Medizinstrategie **

-

Eigenverantwortliche Steuerung von **Arbeitspaketen, Projektmodulen und interdisziplinären Teams **

-

**Konzeption und Moderation interaktiver Workshops** sowie Durchführung von Interviews, Präsentationen und Kundenterminen auf Managementebene

-

**Entwicklung innovativer Strategien, Business Cases** sowie Wirtschaftlichkeits- und Leistungsanalysen

-

**Fachliches Coaching und Unterstützung von Projektteammitgliedern** im laufenden Projektgeschäft

-

**Aufbau und Weiterentwicklung nachhaltiger Kundenbeziehungen** als zentrale Ansprechperson

-

**Aktive Mitwirkung bei Angebots-, Akquise- und Pitch-Prozessen **zur Erweiterung des Leistungsportfolios

-

Übernahme eigener Themen und Initiativen zur Weiterentwicklung des Unternehmens

-

**Min. 3 Jahre Erfahrung** im Consulting ODER Klinikumfeld (z.B. Controlling, Unternehmensentwicklung, Projektmanagement o.ä.)

-

**Absolviertes Masterstudium**, idealerweise in Gesundheitsökonomie, Wirtschaftswissenschaften, Public Health oder einem vergleichbaren Studiengang – mit Bachelorabschluss ca. 5-6 Jahre Erfahrung

-

**Affinität für Healthcare-Themen **– von Klinik bis Med-Tech

-

Starke analytische Fähigkeiten

-

**Verhandlungssichere Deutsch **& Englisch Kenntnisse

-

**Reisebereitschaft **von ca. 2 Tagen wöchentlich im DACH-Raum

-

**Nice-to-have:**

-

Erste Personalverantwortung und / oder Projektverantwortung

-

Erfahrung in der Zusammenarbeit mit C-Level/Geschäftsführung/Medizinischen Führungskräften

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
