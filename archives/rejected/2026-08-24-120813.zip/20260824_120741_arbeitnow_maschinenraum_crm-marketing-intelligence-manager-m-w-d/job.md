# CRM & Marketing Intelligence Manager (m/w/d)

Posted: 2026-08-24T09:30:30Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

## Jobbeschreibung

Für den Maschinenraum suchen wir zum nächstmöglichen Zeitpunkt einen

## CRM & Marketing Intelligence Manager (m/w/d) mit einer starken Analysefähigkeit für Daten und der Entwicklung sowie Umsetzung von konkreten Maßnahmen zur Steigerung von Engagement und Loyalität unserer Mitgliedsunternehmen.

**Über den Maschinenraum**

Der Maschinenraum ist das geteilte Innovationsökosystem deutscher Mittelstands- und Familienunternehmen, um gemeinsam Zukunftsthemen besser zu verstehen und mutiger zu gestalten. Gemeinsam mit rund 80 Mitgliedsunternehmen – darunter Fiege, Sennheiser, Vorwerk und Viessmann – bietet der Maschinenraum Formate und Strukturen, um Transformation systematisch anzugehen: durch den Austausch von Erfahrungen, den Aufbau von Kompetenzen und die Entwicklung konkreter Lösungen. Das Team aus rund 40 Mitarbeitenden betreut die Mitgliedsunternehmen, entwickelt Trainings- und Beratungsformate und betreibt einen Co-Innovation-Space im Herzen Berlins.

Als CRM & Marketing Intelligence Manager (m/w/d) bist du die datengetriebene Kraft hinter unserer Mitgliederkommunikation. Du analysierst, wie sich unsere Mitglieder verhalten – welche Formate sie nutzen, wo sie aktiv sind und wo sie abspringen – und übersetzt diese Erkenntnisse in gezielte Maßnahmen, die Engagement und Bindung stärken. Du konzipierst zusätzlich Strategien zur Identifizierung und Ansprache von neuen Zielgruppen und Kontaktpersonen im Netzwerk.

## Was du bewirkst

- **CRM-Management & Datenstruktur**

Du verantwortest die Pflege und Weiterentwicklung unserer CRM-Struktur in Salesforce und stellst sicher, dass Daten vollständig, aktuell und auswertbar sind. Du baust ein KPI-Framework auf, das dem Team eine datenbasierte Steuerung ermöglicht und erstellst regelmäßige Reportings, aus denen du Optimierungsmaßnahmen ableitest.

- **Zielgruppen- & Verhaltensanalyse**

Du analysierst das Verhalten unserer Mitglieder systematisch – auf Basis von CRM- und Analytics-Daten – und entwickelst ein tiefes Verständnis dafür, was verschiedene Zielgruppen antreibt und was sie zurückhält. Du bist verantwortlich für die Segmentierung unserer bestehenden Mitgliederbasis und erstellst Strategien für und mit unseren Teams, wie sie diese zielführend identifizieren und ansprechen.

- **Growth & Retention Maßnahmen**

Auf Basis deiner Analysen entwickelst und steuerst du gezielte Handlungen sowie automatisierte Marketingmaßnahmen zur Steigerung von Awareness, Engagement und Loyalität. Du arbeitest dabei eng mit den anderen Teams des Maschinenraum zusammen und unterstützt sie mit Handlungsempfehlungen für die Weiterentwicklung sowie Vermarktung von Angeboten.

## Das bist du

- Du denkst in Daten, aber handelst in Maßnahmen. Du weißt, dass Zahlen allein nichts verändern – und verstehst es, Insights in überzeugende Empfehlungen und konkrete Umsetzung zu übersetzen.

- Du bringst 3–5 Jahre Berufserfahrung im CRM, Growth Marketing oder einer vergleichbaren datengetriebenen Rolle mit – idealerweise in einem B2B-Umfeld, einem E-Commerce oder einer mitgliederbasierten Organisation.

- Du hast nachweisliche Erfahrung in der Zielgruppensegmentierung und Verhaltensanalyse sowie in der Ableitung konkreter Kommunikations- und Marketingmaßnahmen.

- Du arbeitest sicher mit Salesforce (Sales/Marketing Cloud) – alternativ bringst du tiefes Know-how in vergleichbaren B2B-CRMs (z. B. HubSpot) mit und hast keine Scheu vor Salesforce

- Du bringst Erfahrung mit relevanten KI-Tools in den Bereichen Analyse und Marketing Automation mit.

- Du denkst strukturiert, arbeitest präzise und kannst komplexe Datenzusammenhänge klar und verständlich kommunizieren.

- Du bist eigeninitiativ und verlierst dich nicht in der Analyse – du willst Dinge bewegen.

- Deutsch auf muttersprachlichem Niveau ist Voraussetzung; gute Englischkenntnisse sind ein Plus.

**Was uns besonders macht**

Der Zusammenhalt in unserem Team macht uns besonders – und jede:r Einzelne trägt dazu bei, unsere Vision zum Leben zu erwecken. Folgende Benefits bieten wir dir:

- Die Möglichkeit, datenbasiertes Marketing in einer der spannendsten Netzwerkorganisationen im deutschsprachigen Mittelstand von Grund auf aufzubauen.

- Enge Zusammenarbeit mit Geschäftsführung, Member Success und Kommunikationsteam.

- 30 Urlaubstage sowie freie Tage an Brückentagen.

- Flexible Arbeitszeiten und die Möglichkeit, im Home Office zu arbeiten.

- Einen modernen Arbeitsplatz im Herzen Berlins mit sehr guter Verkehrsanbindung.

- Regelmäßige Teamevents (z.B. unser Sommerfest und jährliches Offsite) sowie Weiterbildungsangebote & Corporate Benefits.

- Eine Aufgabe, die Sinn macht – in einem Team, das füreinander da ist.

## Stellenanforderungen

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
