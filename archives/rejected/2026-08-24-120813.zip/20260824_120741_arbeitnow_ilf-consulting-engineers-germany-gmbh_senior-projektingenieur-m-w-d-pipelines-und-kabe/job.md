# Senior Projektingenieur (m/w/d) Pipelines und Kabeltrassen

Posted: 2026-08-24T08:30:25Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**Ein Team, in dem man sich wohlfühlt:**

Wir sind ein mittelständisches Familienunternehmen mit mehr als 500 Mitarbeitenden an 7 Standorten in Deutschland. Als Ingenieurs- und Beratungsdienstleister sind wir weltweit in Projekten tätig, welche die Energiewende vorantreiben, den Schutz der Umwelt fördern und zur Verbesserung unser aller Lebensqualität beitragen. Die Position ist in unserem Bereich Trassierung & Genehmigung angesiedelt, die aktuell etwa 20 Mitarbeitende umfasst.

**Aufgaben, die motivieren:**

-

**Führungsstark! **Sie verstärken die Führung des rasch wachsenden Bereichs Trassenplanung und Genehmigungen. Dabei dabei sind Sie für die disziplinarische und fachliche Führung sowie die Weiterentwicklung Ihrer Mitarbeitenden zuständig.

-

**Expertenwissen gefragt!** In leitender Funktion erstellen Sie Konzepte, Machbarkeitsstudien und Trassenplanungen unter Berücksichtigung technischer, wirtschaftlicher und ökologischer Aspekte.

-

**Fachkundig und vielseitig** kümmern Sie sich um geografische und fachtechnische Fragestellungen im Rahmen der Grob- & Entwurfstrassenplanung. Zudem erarbeiten Sie Baukonzepte und planen die Baustellenlogistik.

-

**Souverän und kommunikationsstark** treten Sie im Rahmen von Fachgesprächen mit Behörden sowie Trägern öffentlicher Belange und anderen Stakeholdern auf. Selbstständig kümmern Sie sich um das Behördenengineering und das Stakeholdermanagement.

**Qualifikationen, die überzeugen:**

-

Erfolgreich abgeschlossenes Studium in Bereich Bauingenieurwesen, Geoinformation oder Geografie, idealerweise mit dem Schwerpunkt Infrastrukturplanung und Tiefbau.

-

Mindestens 5 Jahre Erfahrung in der Planung und Genehmigungsplanung von erdverlegten Leitungen (Pipelines und/oder Kabel).

-

Leidenschaft für die Energiewende und die Motivation, aktiv zu einer nachhaltigen Zukunft beizutragen.

-

Hervorragende Deutschkenntnisse in Wort und Schrift sowie gute Englischkenntnisse.

-

Kenntnisse im Genehmigungsrecht sind von Vorteil.

-

Kommunikationsstarke*r, flexible*r Teamplayer*in mit der Bereitschaft zu gelegentlichen Geschäftsreisen (Führerschein Klasse B erforderlich).

Worüber wir uns freuen: Wenn Sie für Ihren Job brennen, egal welcher ethnischen Herkunft, Religion oder Weltanschauung Sie angehören. Auch Geschlecht, Behinderung, Alter oder sexuelle Identität spielen für uns keine Rolle. Hauptsache, Sie passen zu uns!

91% unserer Mitarbeitenden stimmen der Aussage zu, dass ILF in Deutschland ein "Great Place to work" ist:

-

**Sympathische Unternehmenskultur** und gelebte V**I**e**LF**alt: Viele lokale aber auch überregionale **Live-Events** prägen unser Miteinander und der Großteil der Mitarbeitenden ist per "Du". Besonders stolz macht uns die **Internationalität** unseres Teams mit mehr 30 unterschiedlichen Nationen.

-

**Moderne Arbeitsumgebung: **An allen Standorten sind unsere Arbeitsplätze technisch hochwertig und mit** höhenverstellbaren Schreibtischen** ausgestattet. Auch wenn es uns von anderen Unternehmen vielleicht nicht unterscheidet: Wir bieten freie **Getränke,** den obligatorischen Obstkorb und weitere **Snacks** für Zwischendurch inklusive Eis im Sommer.

-

**Entwicklung und Netzwerken**: Wir planen für alle Mitarbeitenden jährliche **Weiterbildungsbudgets** ein, die für externe Angebote (z.B. Udemy) und unsere interne ILF-Academy genutzt werden können. Außerdem wird in regelmäßigen **Feedbackgesprächen** auf Wunsch die Möglichkeit neuer oder erweiterter Verantwortungsbereiche besprochen. Unsere Nachwuchskräfte treffen sich regelmäßig im **Club der Jungingenieur:innen**.

-

**Über das Gehalt hinaus: **Wir beteiligen unsere Mitarbeitenden an** Unternehmensgewinnen, **honorieren Mitarbeiterempfehlungen sowie Fachartikel und -vorträge mit großzügigen** Prämien **und würdigen herausragende Projekte mit unseren** Excellence Awards. **Zusätzlich kann sich jeder Mitarbeitende wahlweise für eine** Pluxee Guthabenkarte, **eine **Zusatzkrankenversicherung **oder den **EGYM-Wellpass **entscheiden.

-

**Gesund und nachhaltig: **Wir erstatten die monatlichen Kosten für das **Deutschlandticket **und bieten die Option auf** Bike-Leasing. **Außerdem bezuschussen wir die Mitgliedschaft in einem** Fitnessstudio **und** Arbeitsplatzbrillen.** Bei Fragen aus allen Lebensbereichen bekommen Sie mit unserem externen** Employee Assistance Program **unkomplizierte und schnelle Unterstützung.

-

**Work-Life-Balance:** Für individuelle Bedürfnisse in allen Lebenslagen finden wir passende Lösungen in Bezug auf** Arbeitszeit** (flexible Arbeitszeitgestaltung inkl. Gleitzeitkonto und verschiedene Teilzeitvarianten) und **Arbeitsort** (z.B. mobiles Arbeiten, Standortwechsel, Auslandseinsätze). Zusätzlich zu 30 **Urlaubstagen** und Sonderurlaubstagen bei besonderen Anlässen wie z.B. Hochzeit oder Umzug sind Heiligabend und Silvester jedes Jahr frei.

**Überzeugt? **Dann werden Sie Teil von Engineering Excellence und senden uns Ihre Bewerbung über den untenstehenden Button!

**Weitere Fragen? **Noch mehr über uns und unseren Bewerbungsprozess erfahren Sie [hier](https://www.ilf.com/de-de/willkommen-bei-ilf-deutschland/).

**Ihr Ansprechpartner: **Frau Lina Thiele (040 - 524754614 / -----

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
