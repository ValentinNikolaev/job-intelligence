# UX / UI Designer

Posted: 2026-08-24T05:30:26Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Wir bauen ein großartiges Unternehmen auf, das finanzielle Inklusion, Schufa-Dienste und Open Banking für Millionen von Kunden in Deutschland zusammenbringt. Die App und die Web-Strategie als Kanäle sind sehr wichtig. Deshalb suchen wir einen großartigen UI-UX Designer, der unser Team verstärkt.

**Deine Aufgaben**

● Du konzeptionierst und gestaltest native/responsive Websites für Mobile oder Desktop/Laptop.

● Du übernimmst die Führung bei der Visualisierung von Features, Produkten und Services für unsere Kunden und bringst die besten UI und UX Ergebnisse in enger Zusammenarbeit mit den Bereichen Produkt, Content, Kommunikation und dem Management.

● Du erstellst Mockups, Wireframes und interaktive Prototypen

● Du gestaltest verschiedene digitale Werbeformate wie Display Ads, Newsletter, Teaser

● Du bist verantwortlich für die zielgruppengerechte Gestaltung von User Interactions und für A/B-Tests

● Du kommunizierst im interdisziplinären großen Marketing Team, Produktteam und Frontend-Entwicklern.

**Dein Profil**

● Du hast 5 Jahre Erfahrung als Screendesigne/UI Designer,

● Du hast bereits in einem regulierten Geschäftsumfeld gearbeitet. Du verfügst über eine AIS-Lizenz für PSD2 (optional)

● Du hast auch bereits eine leitende Rolle in einigen Projekten übernommen, um die Freigabe von Funktionen und Produkten für den Markt zu koordinieren.

● Du hast wichtige Produkte in der Branche für B2C-Unternehmen auf dem deutschen Markt entwickelt.

● Deutsche Muttersprache oder C2-Zertifizierung. Schriftliche Deutschkenntnisse sind obligatorisch, zusammen mit Englisch auf einem kommunikativen Niveau im Arbeitsbereich.

● Du kennst die Dos & Don'ts des conversion-strong mobile & web design.

● Du bist versiert im Umgang mit Invision und den neuesten Webtools und verfügst über solide Kenntnisse in allen Tools wie Photoshop, Sketch, etc.

● Du bist detailorientiert, kommunikationsstark und besitzt einen ausgeprägten Teamgeist. Benefits Als Teil -Teams gibt es folgende

**Benefits:**

● Die Möglichkeit, vom ersten Tag an Verantwortung zu übernehmen

● Die Chance, sich in einem dynamischen und flexiblen Startup-Umfeld zu entfalten.

● Zugang zu umfangreichen Coaching- und Trainingsprogrammen durch unser persönliches Entwicklungsbudget

● 25 Urlaubstage

● Private Krankenversicherung

● 1:1 Sprachunterricht in Deutsch und Englisch.

Das Unternehmen hat sich dem Grundsatz verschrieben, dass kein Mitarbeiter oder Stellenbewerber aufgrund von Alter, Behinderung, Geschlechtsumwandlung, Ethnie, Religion oder Weltanschauung, Geschlecht, sexueller Orientierung, Ehe oder Lebenspartnerschaft, Schwangerschaft und Mutterschaft benachteiligt werden darf.

Wenn du bereit bist, in der Welt der FinTech einen bedeutenden Beitrag zu leisten und dich auf eine spannende Karrierereise zu begeben. Unsere aktuellen Tech Stacks sind: Java, Spring, PostgreSQL, AWS, DocumentDB, Ansible, Jenkins, Kubernetes, Docker, Jira, React.js, React Native, etc.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
