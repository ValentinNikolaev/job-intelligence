# Maschinenbautechniker (m/w/d) - Rohrleitungsberechnung

Posted: 2026-08-24T09:00:29Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Für die EH Engineering GmbH in **Marl** suchen wir schnellstmöglich einen

**Maschinenbautechniker (m/w/d) – Rohrleitungsberechnung**

**Über uns**

Die Ebert HERA Esser Group ist ein gewachsener Firmenverbund und international erfolgreich in der Instandhaltung technischer Großanlagen im Bereich Raffinerie, Petrochemie und Chemie tätig.

Die EH Engineering GmbH ist aus diesem Firmenverbund gewachsen und betreut eben diese Kunden mit Engineeringleistungen. Primär im Brownfield werden unsere Betriebsnahen Projekte in direkter Zusammenarbeit mit unseren Bauherren bewältigt.

## Aufgaben

- **Berechnung von Rohrleitungssystemen**

- Planung im **Rohrleitungs- und Anlagenbau**

- Durchführung von **Vor-Ort-Begehungen**

- Entwicklung technischer **Lösungskonzepte**

- Technische Beratung unserer Kunden

- Enge Zusammenarbeit mit den Bereichen **Konstruktion, Fertigung und Montage**

## Qualifikation

**Erfolgreich abgeschlossene Ausbildung** zum **staatlich geprüften Maschinenbautechniker (m/w/d)** oder eine vergleichbare Qualifikation

- Sicheres technisches Verständnis komplexer Zusammenhänge

- Gute Kenntnisse in **MS Office**

- Ausgeprägtes **räumliches Vorstellungsvermögen**

- Fundierte **technische, mathematische und physikalische Kenntnisse**

- **Selbstständige, strukturierte und qualitätsbewusste Arbeitsweise**

- **Flexibilität** und Verantwortungsbewusstsein

- Hohe **Team- und Kommunikationsfähigkeit**

- **Eigeninitiative**, Kreativität und Engagement

Wünschenswerte Kompetenzen welche Ihr Profil abrunden

- **Innovationsgeist** und Interesse an neuen technischen Lösungen

- **Englischkenntnisse** in Wort und Schrift

## Benefits

- **Attraktive und leistungsgerechte Vergütung**

- Bis zu **30 Tage Urlaub**

- **Urlaubs- und Weihnachtsgeld**

- **Unbefristete Festanstellung**

- Vielfältige **Weiterbildungsmöglichkeiten**

- Vergünstigungen über unser **Corporate Benefits Programm**

- **JobRad-Leasingangebot** für Fahrräder & E-Bikes

- **Abwechslungsreiche und interessante Tätigkeiten**

- Angenehme, **teamgeprägte Arbeitsatmosphäre** mit offener Kommunikation

- **Modern ausgestatteter Arbeitsplatz**

- **Intensive Einarbeitung „on the Job“**

- **Flache Hierarchien und schnelle Entscheidungen**

Wir haben Ihr Interesse geweckt? Dann freuen wir uns auf Ihre Bewerbung!

Ansprechpartner: **Herr Alexander Fürst**

Geforderte Anlagen: Anschreiben, Lebenslauf, Zeugnisse

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
