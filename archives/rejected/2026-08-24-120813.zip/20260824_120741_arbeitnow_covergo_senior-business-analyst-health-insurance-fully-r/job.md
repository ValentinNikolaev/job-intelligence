# Senior Business Analyst - Health Insurance (Fully Remote)

Posted: 2026-08-24T08:40:32Z

## Rejection

- Category: tech_stack
- Reason: role does not mention Go/Golang or PHP

### **Top 3 Reasons To Join Us**

- Competitive Salary
- 100% Remote
- Working on the latest tech for the Insurtech Market Leader

### **About Us**

At CoverGo, our mission is to empower all insurance companies to make insurance 100% digital and accessible to everyone.

- We are a leading global no-code insurance platform for health, life, and P&C
- We’re the winner of the Insurtech of the Year in all of Asia and other awards globally
- We work with insurance enterprise clients such as AXA, Bupa, MSIG, Dai-ichi, Bank of China Group Insurance, and many more
- We're an international, diverse team of over 120 people with 30 nationalities and team members working remotely from all over the world
- We are fully funded and backed by reputable VC funds and strategic institutional investors
- We have a global presence in Asia, EMEA and the Americas
- We’ve grown our annualized revenue by over 30x since January 2021
- We’re constantly working towards making CoverGo a workplace that you love coming to. We deeply believe that bringing together a diversity of thoughts, expressions, and perspectives is key to building the best culture for equally diverse communities all over the world

### **What You Will Do:**

- Work with clients and technical resources to identify their business problems and develop the right approach and analytical solution
- Plan and design simple to semi-complex business processes and system modifications
- Make recommendations to improve and support business activities
- Gather business requirements through a variety of techniques such as work sessions and interviews then analyze and document client complex business requirements and processes; communicate these requirements to appropriate parties
- Create complex test case scenarios to be used in testing; monitor/oversee the testing of business applications to verify that all client requirements are incorporated into the system design
- Develop business requirements documents/user stories to support the required modifications
- May plan, allocate and monitor work of other business analysts
- Understand simple to complex systems and related data to surface actionable insights, demonstrate sound judgment and decision-making skills
- Assist in providing time estimates for project related tasks
- Aid in updating process and procedural documentation
- Develop basic understanding of technical development cycle of mobile application or web portals
- Support QA, UAT and Release phases of the project via defect analysis, change maintenance, etc.
- Any other task that may be assigned

### **What We Need:**

- Minimum 5 years of experience as Business Analyst
- A degree in Business, IT or any relevant field
- Previous experience working in the health insurance industry is required
- Insurtech experience is preferred
- Health Insurance-related domain certification from INS/LOMA or III is an added advantage
- Knowledge of business analysis concepts of defining requirements, translating to technical solutions, and Agile approach to prioritizing work to epics, sprints
- Business analysis skills including facilitation, process documentation, requirements gathering and user acceptance testing
- Good organizational/time management skills to prioritize work and meet deadlines within defined timeframes
- Experience in an Agile and/or Scrum environment is a must
- Basic knowledge in generating process documentation, and document system functionality, data integration, and workflow
- Excellent written and verbal communication skills in English
- Technical writing skills is a plus

### **Why You'll Love Working Here**

- Fully Remote
- Flexible Leave
- International Environment
- Competitive renumeration package
- Performance Bonus
- Company activities and events
- Learning and development plan
- Remote work allowance

**CoverGo Company **[**Video**](https://www.youtube.com/watch?v=YI0ezLxvFvA)

By submitting your application, you confirm that you have read, understood, and accepted the content of CoverGo’s [Privacy Notice](https://apply.workable.com/covergo/gdpr_policy?lng=en) and you consent to the processing of your data as part of this application.

[](https://www.youtube.com/watch?v=YI0ezLxvFvA)

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
