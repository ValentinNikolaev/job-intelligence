# RA-Spezialisten (m/w/d)

Posted: 2026-08-24T06:30:52Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Für ein international erfolgreiches Unternehmen suche ich einen RA-Spezialisten (m/w/d).

## Aufgaben

- Verantwortung für nationale und internationale Produktzulassungen

- Sicherstellung der regulatorischen Compliance nach MDR und relevanten Normen

- Betreuung von Produktänderungen sowie Post-Market-Surveillance-Aktivitäten

- Unterstützung von Entwicklungsprojekten aus regulatorischer Sicht

- Zusammenarbeit mit Behörden, Benannten Stellen und internen Fachbereichen

## Qualifikation

- Erfahrung im Bereich Regulatory Affairs

- Gute Kenntnisse der MDR (EU) 2017/745 sowie relevanter Normen (u. a. ISO 13485, ISO 14791, IEC 60601-1, IEC 62304 und ISO 10993)

- Strukturierte und eigenverantwortliche Arbeitsweise

- Sehr gute Deutsch- und Englischkenntnisse

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
