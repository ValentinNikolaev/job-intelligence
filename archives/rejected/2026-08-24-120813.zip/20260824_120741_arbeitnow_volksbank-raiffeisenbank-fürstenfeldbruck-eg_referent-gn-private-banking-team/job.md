# Referent *(gn) Private Banking Team

Posted: 2026-08-24T08:30:34Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Wir sind eine erfolgreiche, innovative Genossenschaftsbank im Landkreis Fürstenfeldbruck mit einer Bilanzsumme von ca. 2,1 Mrd. €, 13 Geschäftsstellen und 260 engagierten Mitarbeiterinnen und Mitarbeitern.

## Aufgaben

- Unterstützung der Private Banking Spezialisten in Vor- und Nachbereitung von Kundenterminen

- Aktive Unterstützung in der Kundenbetreuung durch eigenständige Vorbereitung von Vermögensstrukturanalysen und Präsentationen

- Koordination von Kundenterminen /-anfragen sowie Aktivitäten in den Marktbereichen

- Eigenständige Bearbeitung von Konto- und Depoteröffnungen, Transaktionen- sie fungieren dabei als Schnittstelle zu internen Fachabteilungen und Verbundpartnern (DZ Bank, Union Investment, DZ Privatbank)

- Eigenständige Erledigung von Service- und Standartaufträgen bei allen Themen unserer Kunden rund um Wertpapier- & Depotgeschäft

- Sicherstellung eines Reibungslosen Backoffice-Ablaufs und Einhaltung regulatorischer Anforderungen

- Kommunikative Schnittstelle zwischen Kunden & Beratern sowie Verbundpartnern auch unter vertrieblichen Fokus

- Unterstützung und Verwaltung des VR Bank FFB Stiftungsmanagements (u.a. Kontrollfunktion, Vertragskontrolle, Zuwendungsbescheinigungen)

## Qualifikation

- Abgeschlossene kaufmännische Ausbildung – idealerweise im Bankenumfeld

- Erfahrung im Wertpapiergeschäft und Beratung von vermögenden Kunden (Privat-/Unternehmenskunden) oder im Assistenzbereich ist von Vorteil

- Ausgeprägte Service- und Kundenorientierung

- Verhandlungs- und kommunikationsstarke Vertriebspersönlichkeit

- Selbstständiges Arbeiten mit Einsatzfreude und Teamfähigkeit ist für Sie selbstverständlich

- Routinierter Umgang mit tätigkeitsspezifischer EDV-Anwendung

- Organisationstalent mit hohem Qualitätsanspruch, eine selbständige Arbeitsweise sowie Termintreue

- Bedarfsweise Mobilität im Geschäftsgebiet ist vom Standort Fürstenfeldbruck aus unabdingbar

## Benefits

**1.** **Arbeitsplätze vor Ort:** kurze Fahrtwege spart viel Freizeit und ist auch ökologisch sinnvoll

**2.** **Flache Hierarchien:** Bei uns stehen alle Türen offen. So gibt es überall kurze Wege bis hin zum Vorstand. Entscheidungen können jederzeit schnell und unbürokratisch getroffen

werden.

**3.** **Sichere Arbeitsplätze:** Andere Banken bauen ständig Arbeitsplätze ab ….. wir wachsen weiter!

4. **Bezahlung:

**a) 13 Tarifgehälter + Provisionsbeteiligung für ausgewählte Produkte, zusätzliche Erfolgsbeteiligung

b) Gehaltsumwandlung/Nettolohnoptimierung möglich, z.B. für Jobfahrrad, PC- und

Handyleasing, Essenszuschüsse, Erholungszuschuss uvm.

c) Vorteilhafte Mitarbeiter-Konditionen

- für Bankprodukte und für die Angebote unserer Verbundpartner

- im regionalen und überregionalen Einzelhandel

-> viele Vorteilskonditionen können zusätzlich auch von Ihren Familienmitgliedern in Anspruch genommen werden

d) Betriebliche Krankenzusatz …. Familie mitversichert zum Vorzugstarif

e) Spezialtarif/Zuschuss für Fitnessclub, Schwimmbad, Yoga, Pilates, Bouldern,

Massage uvm. (-> auch für Familienangehörige möglich)

f) Betriebliche Altersvorsorge

g) Rabatte für Autokauf

**5. Arbeitszeiten**

a) Gleitzeit

b) Öffnungszeiten, die auch Raum für private Erledigungen lassen, z.B. Mittwoch

Nachmittag frei, Freitag nur bis 15 Uhr

Schließen Sie sich unserem engagierten Team als Referent *(gn) im Private Banking an und gestalten Sie die Zukunft einer vertrauenswürdigen Bank mit regionalem Fokus in Fürstenfeldbruck. Werden Sie Teil unseres Erfolgs!

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
