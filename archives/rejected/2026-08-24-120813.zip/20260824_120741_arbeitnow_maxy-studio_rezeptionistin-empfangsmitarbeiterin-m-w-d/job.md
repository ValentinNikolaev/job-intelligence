# Rezeptionistin / Empfangsmitarbeiterin (m/w/d)

Posted: 2026-08-24T09:30:35Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Du bist ein Organisationstalent, hast Freude am Umgang mit Menschen und möchtest in einem modernen, ästhetischen Praxisumfeld arbeiten?

Dann werde Teil unseres jungen, dynamischen Praxisteams im Maxi Studio in Neubrandenburg, in dem kurze Wege, ein modernes Miteinander und ein hoher Anspruch an Service und Ästhetik zum Alltag gehören.

Wir suchen eine freundliche und zuverlässige Rezeptionistin bzw. Empfangsmitarbeiterin, die unsere Patientinnen und Patienten vom ersten Kontakt an professionell betreut und gleichzeitig dafür sorgt, dass im Praxisalltag alles reibungslos organisiert ist.

## Aufgaben

- Herzlicher Empfang und Betreuung unserer Patientinnen und Patienten

- Terminvergabe und Koordination der Behandlungsabläufe

- Telefonische und schriftliche Kommunikation mit Patientinnen und Patienten

- Organisation des Empfangs- und Wartebereichs

- Bearbeitung allgemeiner organisatorischer und administrativer Aufgaben

- Unterstützung bei Abrechnung, Dokumentation und Praxisorganisation

- Enge Abstimmung mit unserem ärztlichen und medizinischen Team

- Sicherstellung eines professionellen und hochwertigen Patientenerlebnisses

## Qualifikation

- Idealerweise Erfahrung am Empfang, in einer Praxis, Klinik, Hotellerie oder im gehobenen Kundenservice

- Freundliches, gepflegtes und professionelles Auftreten

- Ausgeprägte Serviceorientierung und Freude am Kontakt mit Menschen

- Organisationstalent und ein gutes Gespür für Prioritäten

- Zuverlässige, strukturierte und selbstständige ArbeitsweiseSicherer Umgang mit digitalen Anwendungen und modernen Kommunikationsmitteln

- Diskretion und Verantwortungsbewusstsein im Umgang mit sensiblen PatientendatenInteresse an den Bereichen Ästhetik, Beauty und Longevity

## Benefits

- Ein modernes und hochwertiges Arbeitsumfeld im Maxi Studio in Neubrandenburg

- Ein junges, dynamisches Team mit kurzen Entscheidungswegen

- Moderne Praxisstrukturen statt starrer Hierarchien

- Eine abwechslungsreiche Position mit viel Patientenkontakt

- Viel Raum für eigenverantwortliches Arbeiten

- Eine umfassende Einarbeitung in unsere Abläufe und SystemeFlexible Arbeitszeiten nach Absprache

- Die Möglichkeit, einen wachsenden Praxisbereich aktiv mitzugestalten

Werde Teil unseres Teams!

Bei uns bist du nicht einfach nur die Person am Empfang – du bist ein wichtiger Teil des gesamten Patientenerlebnisses und häufig der erste persönliche Kontakt zu unserer Praxis.

Wenn du Organisation, Service und Ästhetik miteinander verbinden möchtest und Lust auf ein modernes Praxisumfeld hast, freuen wir uns darauf, dich kennenzulernen.

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
