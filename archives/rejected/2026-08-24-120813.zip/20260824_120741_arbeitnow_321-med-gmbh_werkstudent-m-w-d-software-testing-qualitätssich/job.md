# Werkstudent (m/w/d) Software Testing / Qualitätssicherung München

Posted: 2026-08-24T09:00:26Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Über 321 MED

321 Med unterstützt medizinische Einrichtungen dabei, effizienter, wirtschaftlicher und zukunftsfähiger zu arbeiten. Wir stehen für klare Kommunikation, starke Partnerschaften und Lösungen, die im Praxisalltag wirklich funktionieren.

## Aufgaben

- **Durchführung manueller Tests unserer Webanwendungen und digitalen Produkte**

- **Erstellung, Pflege und Dokumentation von Testfällen, Testplänen und Testergebnissen**

- **Identifikation, Analyse und Nachverfolgung von Softwarefehlern in enger Zusammenarbeit mit dem Entwicklungsteam**

- **Unterstützung bei der Qualitätssicherung von Frontend- und Backend-Funktionalitäten**

- **Durchführung von Regressions-, Funktions- und Usability-Tests vor neuen Releases**

- **Überprüfung von Anforderungen und Spezifikationen hinsichtlich Testbarkeit und Qualität**

- **Dokumentation von Auffälligkeiten sowie Mitarbeit bei der kontinuierlichen Verbesserung unserer Testprozesse**

## Qualifikation

- **Laufendes Studium im Bereich Informatik, Wirtschaftsinformatik, Software Engineering oder einer vergleichbaren Fachrichtung**

- **Interesse an Softwarequalität, Testing und der Analyse technischer Systeme**

- **Erste Kenntnisse im Umgang mit Webanwendungen sowie grundlegendes Verständnis von HTML, CSS und JavaScript sind von Vorteil**

- **Idealerweise erste Erfahrungen mit Testmanagement- oder Ticket-Systemen (z. B. Jira)**

- **Strukturierte, sorgfältige und ergebnisorientierte Arbeitsweise**

- **Analytisches Denkvermögen und ausgeprägte Problemlösungsfähigkeiten**

- **Hohes Qualitätsbewusstsein und ein Auge für Details**

- **Gute Kommunikationsfähigkeit sowie Freude an der Zusammenarbeit im Team**

- **Selbstständige und verantwortungsbewusste Arbeitsweise**

## Benefits

- **Flexible Arbeitszeiten, die sich mit deinem Studium vereinbaren lassen**

- **Praktische Erfahrungen in der professionellen Softwareentwicklung und Qualitätssicherung**

- **Enge Zusammenarbeit mit erfahrenen Entwicklern, Designern und Produktmanagern**

- **Moderne Arbeitsumgebung und aktuelle Technologien**

- **Möglichkeit, eigene Ideen einzubringen und Prozesse aktiv mitzugestalten**

- **Perspektive auf eine langfristige Zusammenarbeit und mögliche Übernahme nach dem Studium**

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
