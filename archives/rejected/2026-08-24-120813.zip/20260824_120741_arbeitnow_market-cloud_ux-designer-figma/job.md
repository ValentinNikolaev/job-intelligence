# UX Designer (Figma)

Posted: 2026-08-24T08:30:35Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**

Role: UX Designer**

**📍 Location:Europe / Remote

🕒 Employment Type:Contract**

## Tasks

Key Responsibilities

- Design user-centric web and mobile experiences using **Figma**.

- Create wireframes, user flows, mockups, and interactive prototypes.

- Conduct user research and translate insights into design solutions.

- Collaborate closely with Product Managers, Developers, and stakeholders.

- Maintain and evolve design systems, components, and style guides.

- Ensure consistency, usability, accessibility, and responsiveness across products.

- Participate in usability testing and incorporate feedback into designs.

- Present design concepts and rationale to stakeholders.

## Requirements

Required Qualifications

- 3+ years of experience in UX/UI Design.

- Strong proficiency in **Figma**, including components, auto-layout, prototyping, and design systems.

- Solid understanding of UX principles, information architecture, and interaction design.

- Experience designing responsive web and mobile applications.

- Strong portfolio showcasing end-to-end design projects.

- Excellent communication and collaboration skills.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
