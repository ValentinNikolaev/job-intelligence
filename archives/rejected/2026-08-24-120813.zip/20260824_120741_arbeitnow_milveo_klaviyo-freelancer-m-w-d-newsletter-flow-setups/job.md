# Klaviyo Freelancer (m/w/d) - Newsletter & Flow-Setups für E-Commerce Brands

Posted: 2026-08-24T09:30:33Z

## Rejection

- Category: tech_stack
- Reason: role does not mention Go/Golang or PHP

**Beschäftigungsart:** Freelance / Selbstständig

**Standort:** 100 % Remote

Wir sind die Milveo Capital GmbH – eine E-Commerce Marketing Agentur. Wir betreuen D2C- und E-Commerce-Brands in den Bereichen Shopify, Google Ads, Meta Ads, Klaviyo und SEO.

Für unsere Shopify E-commerce Kunden suchen wir einen erfahrenen **Klaviyo Freelancer (m/w/d)**, der eigenständig zwei Arten von Aufträgen umsetzt:

- **Newsletter-Kampagnen** – Konzeption, Design, Copy und Versand für laufende Brands

- **Klaviyo-Setups** – Neuaufsetzen von Accounts inkl. Welcome Flow, Warenkorbabbrecher & Co.

## Aufgaben

**Newsletter-Kampagnen**

- Planung und Umsetzung von Kampagnen in Klaviyo für mehrere E-Commerce Brands

- Aufbau im Klaviyo-Editor: Layout, Bildintegration, mobile Optimierung

- Texten von Betreffzeilen, Preheadern und Newsletter-Copy auf muttersprachlichem Deutsch

- Segmentierung und Empfängerauswahl (inkl. Engagement-Segmenten und List-Hygiene)

- A/B-Tests, Terminierung, Versand und Qualitätskontrolle vor dem Livegang

**Klaviyo-Setups**

- Aufsetzen neuer Klaviyo-Accounts inkl. Shopify-Integration

- Aufbau der Kern-Flows: Welcome Flow, Warenkorbabbrecher, Browse Abandonment, Post-Purchase, Winback / Reaktivierung

- Erstellung und Einbindung von Sign-up-Formularen und Pop-ups (Double-Opt-in-konform)

- Technisches Setup: Domain-Authentifizierung (DKIM/SPF), Sending-Domain, Deliverability-Grundlagen

- Grundlegende Segment- und Listenstruktur anlegen

- Kurzes Reporting bzw. Übergabedokumentation der wichtigsten KPIs und Einstellungen

## Qualifikation

- Mehrjährige, nachweisbare Erfahrung mit Klaviyo – kein Einstiegsprofil

Erfahrung sowohl mit Kampagnen-Versand als auch mit dem Aufbau kompletter Flow-Setups

- Deutsch auf muttersprachlichem Niveau (Copy geht direkt live)

- Sicheres Gespür für E-Commerce-Copy, Angebotskommunikation und Kampagnen-Timing

- Sauberes Auge für Design und markenkonforme UmsetzungKenntnis der rechtlichen Rahmenbedingungen im E-Mail-Marketing (DSGVO, Double-Opt-in, Impressum, Abmeldelink)

- Selbstständige, verlässliche Arbeitsweise und Einhaltung von VersandterminenGültige Gewerbeanmeldung bzw. selbstständige TätigkeitVon Vorteil: Erfahrung mit Shopify sowie mit Deliverability-Themen

## Benefits

- Langfristige Zusammenarbeit mit planbarem, wachsendem Auftragsvolumen

- Abwechslung: laufende Kampagnen und Setup-Projekte für unterschiedliche Brands

- 100 % remote und flexible Zeiteinteilung

- Abgegrenzter Scope: Du setzt um, wir kümmern uns um Kundenkommunikation und StrategieDirekte Ansprechpartner, kurze Wege, schnelle Entscheidungen

Die Kunden, wo wir gerade Unterstützung brauchen sind zu klein für eine vollwertige Klaviyo Betreuung. Daher suchen wir jemanden, der Newsletterpakete anbietet.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
