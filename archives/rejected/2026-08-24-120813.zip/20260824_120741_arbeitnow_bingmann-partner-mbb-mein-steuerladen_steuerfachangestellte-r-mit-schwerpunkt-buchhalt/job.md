# Steuerfachangestellte/r mit Schwerpunkt Buchhaltung

Posted: 2026-08-24T09:00:27Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**Buchhaltung ist bei uns kein Durchgangsposten.**

In vielen Kanzleien ist Buchhaltung das, was man macht, bis man etwas anderes darf. Bei uns ist sie ein eigenes Handwerk. Und wer es beherrscht, muss sich hier für nichts rechtfertigen.

Der Grund ist einfach: Eine saubere laufende Buchhaltung entscheidet darüber, wie gut ein Jahresabschluss wird, wie belastbar eine BWA ist und ob ein Mandant im Dezember noch reagieren kann.. oder erst hinterher erfährt, was er hätte tun können.

Erkennst du dich hier wieder?

- Du siehst in Zahlen schnell, wenn etwas nicht stimmt. Oft bevor jemand fragt.

- Du würdest deine Mandanten gern selbst anrufen, statt Notizen weiterzureichen.

- Digitale Belegprozesse reizen dich mehr, als sie dich nerven.

- Du magst den Monatsrhythmus. Das Chaos drumherum eher nicht.

- Du willst in deinem Fach richtig gut werden. Nicht möglichst schnell etwas anderes machen.

Wenn du auch nur einmal genickt hast: Lass uns reden.

## Aufgaben

Buchhaltung ist bei uns kein Zuarbeiten. Du führst deine Mandanten selbst.

- Laufende Finanzbuchhaltung für deinen eigenen Mandantenstamm, quer durch die Branchen

- Digitale Belegprozesse mit DATEV Unternehmen online. Einrichten, betreuen und besser machen

- Umsatzsteuer-Voranmeldungen und die laufende Kommunikation mit dem Finanzamt

- Auswertungen, die Mandanten wirklich lesen: BWA, offene Posten, Liquidität

- Erste Ansprechperson für deine Mandanten in allen Fragen rund um die Buchhaltung

- Wenn du magst: Mitarbeit bei Jahresabschlüssen, Lohnbuchhaltung oder in der Wirtschaftsprüfung

Der letzte Punkt ist ein Angebot, keine Bedingung. Wer bei der Buchhaltung bleiben will, bleibt bei der Buchhaltung — und wird darin richtig gut.

## Qualifikation

Kein Anforderungs-Wettrennen. Wichtiger als die perfekte Vita ist, dass die Richtung stimmt:

- Eine Ausbildung als Steuerfachangestellte/r, Finanzbuchhalter/in, Bilanzbuchhalter/in oder Praxis, die für sich spricht

- Sicherheit in der laufenden Buchhaltung und bei der Umsatzsteuer

- DATEV im Alltag, nicht nur vom Hörensagen

- Lust darauf, mit Mandanten direkt zu sprechen, statt nur zu buchen

- Und eine Sache, die uns wichtig ist: Du sagst früh Bescheid, wenn etwas hakt. Nicht erst, wenn die Frist drückt

Du machst Mandantenbuchhaltung seit Jahren? Super. Du hast deine Ausbildung gerade fertig? Auch super. Was wir voraussetzen, ist Kanzleierfahrung. Nicht viel davon aber welche. Mandantenbuchhaltung tickt anders als die Buchhaltung eines einzelnen Unternehmens, und das lernt man nur in der Kanzlei.

## Benefits

**Vergütung: Leistung, die sich zeigt 💶**

- Überdurchschnittliche Vergütung. Dazu Fahrtkostenzuschuss und Benzingutscheine. Bei uns selbstverständlich und nicht Verhandlungssache.

- Wir schauen uns Gehälter einmal im Jahr von uns aus an. Du musst nicht danach fragen.

**Arbeitsplatz & Ausstattung 🪴**

- Lichtdurchflutete, weitläufige Räume mit Blick in die grüne Außenanlage. Kein Großraumbüro.

- Entspannte Parkplatzsituation durch eigenes Betriebsgelände, keine Parkplatzsuche nötig

- Höhenverstellbarer Schreibtisch, mind. 2 Monitore und Klimaanlage in jedem Raum

- Neueste IT: ASP, DMS, DUO, Mandanten-Cloud, elektronische Signatur

- Wöchentliches Team-Lunch auf Kanzlei-Kosten: gemeinsam bestellt bei wechselnden Lieferanten

- Unbegrenzt freie Getränke, Kaffee aus der Siebträgermaschine, Wasser, Cola, Bionade, Tee und Naschereien

**Weiterbildung & Zukunft: wir denken langfristig mit dir 🚀**

- Wir investieren in dich: Weiterbildung auf Kanzleikosten und in der Arbeitszeit bis zum Steuerfachwirt oder Bilanzbuchhalter, wenn du das willst.

- Im ersten Gespräch sagst du uns, wo du in drei Jahren stehen willst. Danach planen wir rückwärts, statt dir einen Katalog hinzulegen.

- Kurze Wege: Stefanie und Florian entscheiden zu zweit. Eine gute Idee braucht hier zehn Minuten, kein Konzeptpapier.

- Wir duzen uns alle, vom Azubi bis zum Wirtschaftsprüfer

- Einen Dresscode gibt es nicht. Wer zum Mandanten fährt, weiß selbst, was passt.

Du sitzt vor deinem Handy oder Laptop und denkst: „Klingt nach mir"? Dann mach den ersten Schritt so einfach wie möglich.

**Nur Lebenslauf nötig.** Schreib uns in zwei, drei Sätzen, wer du bist, wo du gerade stehst und worauf du Lust hast. Den Rest klären wir im Gespräch.

Wir melden uns innerhalb von einem Tag. Immer auch wenn es nicht passt.

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
