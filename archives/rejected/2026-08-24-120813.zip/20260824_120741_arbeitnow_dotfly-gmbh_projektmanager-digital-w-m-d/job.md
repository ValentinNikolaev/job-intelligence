# Projektmanager digital (w/m/d)

Posted: 2026-08-24T10:00:45Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Du bist Dreh- und Angelpunkt erfolgreicher digitaler Projekte und hast Budgets, Timings und Ressourcen jederzeit im Blick. Du berätst deine Kund:innen auf Augenhöhe, nimmst Anforderungen mühelos auf, strukturierst sie und schaffst so die Basis für eine erfolgreiche Zusammenarbeit. Nach innen koordinierst du Prioritäten und Deadlines und ermöglichst deinem Team, selbstorganisiert und zielsicher zu arbeiten. Dank deines technischen Verständnisses behältst du auch bei komplexen Projekten den Überblick und sorgst freundlich-bestimmt für hohe Qualität im geplanten Zeit- und Budgetrahmen.

## Aufgaben

Das wirst du tun  

Du steuerst komplexe digitale Projekte und bringst sie unter Berücksichtigung von Budget, Zeit und Qualität zum Erfolg.

Du koordinierst Ressourcen und Timings, behältst Risiken im Blick und steuerst frühzeitig gegen, wenn Projekte aus dem vereinbarten Rahmen laufen.

Du bist zentrale Ansprechpartner:in für deine Kund:innen, moderierst Meetings und sorgst für eine klare und verbindliche Kommunikation.

Du nimmst Anforderungen auf, strukturierst und priorisierst sie und sorgst gemeinsam mit dem Team für ein umsetzbares und gepflegtes Backlog.

Du behältst die Wirtschaftlichkeit deiner Projekte im Blick und kümmerst dich um Projektcontrolling, Abrechnung und Change Requests.

## Qualifikation

Das bringst du mit  

Du bringst fundierte Erfahrung im Management von Digitalprojekten und ein sehr gutes technisches Verständnis mit, insbesondere in TYPO3 und/oder Shopware.

Du kennst Jira nicht nur oberflächlich, sondern arbeitest sicher mit Backlogs, Tickets, Epics, Sprints und agilen Workflows.

Du denkst unternehmerisch, zielorientiert und analytisch und behältst auch bei mehreren parallelen Themen den Überblick.

Du kommunizierst gerne und richtig gut: empathisch, verbindlich und flexibel genug für unterschiedlichste Kund:innen und ein buntes, interdisziplinäres Team

Du arbeitest zuverlässig, strukturiert und eigenständig, packst gerne mit an und fühlst dich in einem agilen Arbeitsumfeld wohl.

Du bist KI-affin, nutzt KI selbstverständlich im Arbeitsalltag und hast Lust, damit deine Arbeit und unsere Prozesse kontinuierlich weiterzuentwickeln.

Sehr gute Deutschkenntnisse (mindestens C1) runden dein Profil ab.

## Benefits

Das erwartet dich  

Hybrides Arbeiten: Dein Arbeitsalltag verbindet vor allem Präsenz im Büro mit Homeoffice, orientiert daran, was deine Projekte und die Zusammenarbeit gerade brauchen.

Workation: Wenn es passt, kannst du deinen Arbeitsplatz auch für eine Zeit ins Ausland verlegen.

28 Tage Urlaub plus zwei zusätzliche freie Brauchtumstage.

Swapfiets, Deutschlandticket oder Urban Sports Club: Du entscheidest, welcher Benefit am besten zu dir passt.

Weiterbildungsbudget für deine fachliche und persönliche Entwicklung.

MacBook oder Dell: Du entscheidest, womit du am liebsten arbeitest.

Flache Hierarchien und selbstorganisiertes Arbeiten mit viel Raum, Verantwortung zu übernehmen.

Anspruchsvolle Projekte und großartige Kund:innen, die gemeinsam mit uns an einer nachhaltigen und gemeinwohlorientierten Welt arbeiten.

Und das Beste: rund 30 Kolleg:innen mit unterschiedlichen Skills und Persönlichkeiten, die sich auf deine Ideen freuen!

Bewerben geht ganz einfach

Klingt nach dir? Dann melde dich bei uns! Wir freuen uns darauf, dich kennenzulernen und zu erfahren, wie du deine Erfahrungen und Ideen bei dotfly einbringen und uns mitgestalten möchtest.

Und mach dir keinen Stress wegen der Formalien. Schick uns einfach deinen Lebenslauf, ein paar spannende Details zu dir, deinen frühesten Eintrittstermin und deine Gehaltsvorstellung an uns. Ansprechpartnerin ist Natalie Hohmann.

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
