# Consultant IT-Compliance & Informationssicherheit (w/m/d)

Posted: 2026-08-24T09:30:34Z

## Rejection

- Category: language_requirement
- Reason: hard German language requirement without English green light

[Einsatzort / Remote] · IT-Compliance / Informationssicherheit

Consultant IT-Compliance & Informationssicherheit (w/m/d), Start: September 2026. Projektsprache: Deutsch.

Für ein Kundenprojekt suchen wir eine:n erfahrene:n Consultant (w/m/d), die:der bei einer der großen gesetzlichen Krankenkassen Deutschlands die Compliance-Grundlagen für eine neue Entwicklungs- und Betriebsplattform erarbeitet, von den Prozessen und Verfahrensanweisungen bis zu den technischen Plattformanforderungen.

New Monday ist eine Digitalagentur aus Berlin, die zu 100% remote arbeitet. Zu unseren Kunden zählen namhafte Konzerne wie Atruvia, DAK, SAP, Lufthansa uvm. genau wie moderne Start-Ups wie NUMA Stays.

**Zum Projekt:** Das Kernsystem des Kunden bildet sämtliche sozialversicherungsrechtlich relevanten Kernprozesse ab und ist seit über 20 Jahren im Einsatz. Es wird grundlegend erneuert: Der bestehende Monolith wird in eine kleinteiligere, fachlich geschnittene Anwendungslandschaft auf Basis von Self Contained Systems (SCS) überführt. Dafür entsteht eine Entwicklungs- und Betriebsplattform, die voraussichtlich ab 2027 von rund 150 Entwickler:innen genutzt wird. Viele Compliance-Fragen, die bisher zentral gelöst wurden, müssen künftig dezentral in den einzelnen Teams beantwortet werden. Deine Aufgabe: ein tragfähiges, praxistaugliches und mit den Stakeholdern abgestimmtes Set an Prozessen, Verfahrensanweisungen und technischen Plattformanforderungen, mit dem die Entwicklungsteams effizient und zugleich compliancekonform arbeiten können.

## Aufgaben

- Einarbeitung und Analyse: Strukturierter Überblick über die bestehenden Richtlinien und Policies des Kunden, die für Entwicklung, Betrieb und Weiterentwicklung der neuen Plattform relevant sind.

- Konzeption des Vorgehens: Entwurf eines transparenten, nachvollziehbaren Vorgehensmodells zur systematischen Ableitung der benötigten Artefakte (Prozesse, Verfahrensanweisungen, technische Anforderungen) aus den bestehenden Richtlinien und Policies.

- Erarbeitung von Prozessen und Verfahrensanweisungen zur operativen Umsetzung der Complianceanforderungen durch die zukünftigen Anwendungsentwicklungsteams und Betriebsorganisationen.

- Erarbeitung eines sicheren Entwicklungsprozesses, der den Vorgaben von KRITIS, ISO 27001 sowie internen Richtlinien genügt.

- Identifikation, Spezifikation und Dokumentation der technischen Anforderungen an die Plattform (z. B. Logging, Monitoring, Rechte- und Rollenkonzepte, Schnittstellen, Automatisierung).

- Iterative Abstimmung und Qualitätssicherung: Vorstellung der Arbeitsergebnisse bei den Ownern der Richtlinien und Policies sowie der Projektleitung, Aufnahme und Bewertung von Feedback.

- Überarbeitung, Verfeinerung und Konsolidierung der Entwürfe auf Basis des Feedbacks und der Praxiserfahrungen aus Pilotierungen bzw. ersten Umsetzungen.

- Fachliche Begleitung der Einführung in den beteiligten Teams (Entwicklung, Betrieb, ggf. weitere Einheiten) und Unterstützung bei der Integration in deren Arbeitsweisen (z. B. agile Entwicklung, DevOps-Ansätze).

## Qualifikation

- Abgeschlossenes Studium der (Wirtschafts-)Informatik, Information Security, Wirtschaftswissenschaften mit IT-Schwerpunkt oder eine vergleichbare Qualifikation (z. B. langjährige einschlägige Berufserfahrung in vergleichbarer Rolle).

- Mindestens 5 Jahre Berufserfahrung in der IT, davon mindestens 3 Jahre in einem oder mehreren der folgenden Bereiche: IT Service Management (z. B. ITIL), Datenschutz im IT-Kontext, Informationssicherheit.

- Nachweisbare Erfahrung in der Konzeption und Dokumentation von IT-Prozessen, Ablauf- und Verfahrensanweisungen oder technischen Plattformanforderungen in komplexen IT-Umgebungen. Bitte beschreibe in deiner Bewerbung mindestens zwei Projekte, in denen du entsprechende Aufgaben verantwortet hast.

- Kenntnisse der Anforderungen aus KRITIS und ISO 27001.

- Sehr gute Deutschkenntnisse in Wort und Schrift (mindestens Niveau C1).

## Benefits

- Tolle Leute, super Atmosphäre, dynamisches Team, agile Arbeitsweise

- Sweet Spot zwischen Corporate-Alltag und kreativem Agenturleben: Bei uns musst du nicht zwischen hunderten Projekten gleichzeitig jonglieren, sondern bist für ein einzelnes Projekt eingeteilt.

- Klar umrissenes Projekt mit definierter Laufzeit und planbarer Auslastung

- Eine Rolle mit sichtbarem Ergebnis: Die von dir erarbeiteten Prozesse und Anforderungen werden ab 2027 die Arbeitsgrundlage für rund 150 Entwickler:innen

- Eigenständiges, flexibles Arbeiten ohne Micromanagement

**Erstes Kennenlernen** Du lernst unsere Arbeitsweise und Philosophie kennen. Du hast die Gelegenheit, dich vorzustellen. Wir beantworten alle deine Fragen in entspannter Atmosphäre.

**Fachliches Gespräch** Ausführlicheres Kennenlernen mit Fokus auf deine Erfahrung mit IT-Compliance, Informationssicherheit und Prozesskonzeption sowie das konkrete Vorhaben. Gelegenheit zu gegenseitigen Fragen.

**Follow-Up** Abstimmung der Details: Startdatum, Konditionen und der Ablauf beim Kunden. Danach kann es direkt losgehen.

Also los geht's! Wir freuen uns auf deine Bewerbung.

Um es einfach zu halten, verzichten wir gerne auf ein Anschreiben. Schick uns einfach deinen Lebenslauf bzw. dein Profil inklusive der zwei Referenzprojekte, auch wenn du das Gefühl hast, nicht 100 % der Anforderungen zu erfüllen.

New Monday fördert aktiv die Gleichstellung aller Beschäftigten. Wir begrüßen daher alle Bewerber:innen, unabhängig von Geschlecht, ethnischer, kultureller und sozialer Herkunft, Alter, Religion, Weltanschauung, Behinderung sowie sexueller Identität der Person. Menschen mit Schwerbehinderung werden bei gleicher Eignung unter Berücksichtigung aller Umstände des Einzelfalls bevorzugt.

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
