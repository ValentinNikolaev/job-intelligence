# AI/ML Engineer

Posted: 2026-08-24T09:26:14Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**This position is listed on behalf of a partner company, who manages all applications and next steps. Our partner is looking for an AI/ML Engineer based in Germany.**

This is an opportunity to develop AI and machine learning solutions that support the personalization of digital therapies and improve patient outcomes.
You’ll work with longitudinal real-world health data to build models that can predict risks and enable more adaptive approaches to care.
The role spans the full ML lifecycle, from data pipelines and model development through validation, deployment, and production integration.
You’ll collaborate closely with engineering and multidisciplinary teams to translate advanced models into reliable digital health products.
A strong focus on explainability, reproducibility, privacy, and regulatory requirements makes this a technically rigorous environment.
You’ll also have the opportunity to explore generative AI applications for patient education and digital coaching.
This is a high-impact role for an experienced ML professional who wants to apply AI to meaningful healthcare challenges.

**Accountabilities:**

- Design, develop, train, and evaluate supervised and unsupervised machine learning models using longitudinal and real-world health data.

- Build scalable and reliable data pipelines supporting model training, testing, validation, and deployment.

- Develop machine learning solutions capable of identifying health risks, supporting personalized interventions, and enabling adaptive care pathways.

- Work closely with software and engineering teams to integrate ML models into production Software as a Medical Device (SaMD) and digital therapeutic solutions.

- Establish robust processes for model reproducibility, monitoring, evaluation, and performance optimization.

- Ensure models and ML workflows meet relevant requirements around explainability, reliability, privacy, and regulatory compliance.

- Apply appropriate techniques for real-world signal processing, data preparation, feature engineering, and model validation.

- Contribute to the evaluation and responsible adoption of generative AI technologies for healthcare education, coaching, and related applications.

- Collaborate with cross-functional experts to translate clinical and behavioral health challenges into effective technical solutions.

- Contribute to the continuous improvement of machine learning infrastructure, development practices, and MLOps processes.

## Requirements:

- 4+ years of professional experience in AI/ML engineering, machine learning, data science, or a closely related field, ideally involving digital health or healthcare datasets.

- Strong proficiency in Python and hands-on experience with data wrangling, machine learning development, and real-world signal processing.

- Practical experience with leading ML frameworks and libraries such as TensorFlow, PyTorch, and scikit-learn.

- Experience designing and implementing MLOps pipelines for reliable model development, testing, deployment, and maintenance.

- Understanding of machine learning applied to longitudinal, real-world, or time-series health data.

- Familiarity with clinical validation, model evaluation, bias mitigation, and privacy-preserving machine learning practices.

- Understanding of the challenges associated with deploying AI/ML solutions in regulated healthcare or Software as a Medical Device environments.

- Strong analytical and problem-solving abilities, with a rigorous and evidence-driven approach to technical decisions.

- Ability to work collaboratively with engineering, data science, healthcare, and other multidisciplinary stakeholders.

- Strong communication skills and the ability to explain complex technical concepts clearly to both technical and non-technical audiences.

- Interest in generative AI and its responsible application to healthcare education, coaching, and patient support is a plus.

- Experience working effectively in a remote or distributed environment is preferred.

## Benefits:

- Fully remote working environment, with Europe-based candidates preferred.

- Full-time, permanent position within a technology-focused healthcare environment.

- Opportunity to contribute to the development of next-generation digital health and digital therapeutic solutions.

- Work with real-world health data and advanced AI/ML technologies focused on improving patient outcomes.

- Exposure to a certified Software as a Medical Device environment with strong emphasis on evidence, quality, and regulatory standards.

- Collaboration with multidisciplinary teams and leading partners across Pharma, MedTech, and academic research.

- Opportunity to work at the intersection of artificial intelligence, behavioral science, digital therapeutics, and healthcare.

- Meaningful opportunity to contribute to scalable solutions addressing chronic care management.

- Remote-first culture supported by collaborative teams focused on measurable patient impact.

**How Jobgether works:**

We use an **AI-powered matching process** to ensure your application is reviewed quickly, objectively, and fairly against the role's core requirements. Our system identifies the top-fitting candidates, and this shortlist is then shared directly with the hiring company. The final decision and next steps (interviews, assessments) are managed by their internal team.

We appreciate your interest and wish you the best!

[ Why Apply Through Jobgether?](https://jobgether.com/how-jobgether-works)

**Data Privacy Notice:** By submitting your application, you acknowledge that Jobgether will process your personal data to evaluate your candidacy and share relevant information with the hiring employer. This processing is based on legitimate interest and pre-contractual measures under applicable data protection laws (including GDPR). You may exercise your rights (access, rectification, erasure, objection) at any time.

#LI-CL1

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
