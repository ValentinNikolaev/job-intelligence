# AI Product Manager

Posted: 2026-08-12T14:40:23Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**The AI orchestration of your wildest imagination.**

n8n is the open workflow orchestration platform built for the new era of AI. We give technical teams the freedom of code with the speed of no-code, so they can automate faster, smarter, and without limits. Backed by a fiercely inventive community and 500+ builder-approved integrations, we’re changing the way people bring systems together and scale ideas for impact.

Since our founding in 2019, we’ve grown into a diverse team of over 260 - working across Europe and the US, connected by a shared builder spirit and with our centre of gravity in Berlin. Along the way, we’ve:

-

Cultivated a community of more than 650,000 active developers and builders

-

Earned 190K+ GitHub stars, making us one of the world’s Top 40 most popular projects

-

Backed by top investors, from Sequoia’s first German seed to our SAP's recent strategic investment - bringing us to a $5.2bn valuation

That’s the company we’ve built. Now we’d love to see what *you *can build. If you’re applying, try n8n out - whether you’re technical or not - and share a screenshot of your first workflow with us. The easiest place to start is here: [app.n8n.cloud/register](http://app.n8n.cloud/register).

We’re in a defining moment of an incredible journey. Come and build with us.

At n8n, we think the future of software lives in the wonderfully weird space between deterministic workflows, AI agents, and human judgment. Not everything should be automated. Not everything should be agentic. The magic is knowing what belongs where.

We’re hiring multiple AI Product Managers across levels to help shape that layer. You might be a **Senior Product Manager **who has shipped AI products to real users, or an **early-career builder with unusually strong product and AI instincts **with a track record of making things. Either way, we care about whether you can turn ambitious, occasionally chaotic AI ideas into product experiences that users can trust, understand, and build with.

You’ll own one focused AI workstream. Depending on your level, you may lead it independently or work alongside a senior PM who acts as your primary mentor. In both cases, you’ll be close to users, close to the technology, and close to the future of AI products.

We move quickly, care deeply about craft, and are still early enough that strong product judgment can meaningfully shape the direction of the platform. You’ll be front and center of n8n’s rocketship, collaborating closely with Engineering, Design, Data, Product Marketing, DevRel, Community, Support, and Customer Success.

This is not an ML platform or research role. We’re looking for people who have built with AI deeply: whether through production products, serious prototypes, public projects, agent workflows, evals, or tools real users have touched.

## Where you might focus

### AI Trust*

*Make AI on n8n trustworthy.*

This workstream focuses on evals, observability, traces, guardrails, reliability, latency, cost, debugging, and human-in-the-loop patterns. The layer that turns “AI works in demos” into “AI works in production.”

**Mission:** raise the bar on AI quality across the platform and make AI behavior inspectable.

### AI Building / Super Agent*

*Make n8n itself an AI-first product.*

This workstream focuses on Super Agent, custom memory, Skills, computer and browser use, files, chat-first building, and proactive suggestions. It's the product-as-AI angle where AI builds with the user, not just for the user.

**Mission:** shift a meaningful share of n8n usage to AI-native surfaces.

**🚀 If this sounds like the kind of ambiguity you like turning into product, hit apply.**

**A quick note, because this is AI and the plot moves fast: the workstreams below reflect where we’re headed today. By the time you join, some details may have evolved. Think of them as a useful snapshot of the problems we care about, not a legally binding prophecy.*

# Requirements

*We’re open to different experience levels, but the bar on AI depth, product taste, and builder energy is high.*

## Must-haves

-

🤖 **AI-native by default:** you use tools like Claude Code, Cursor, Lovable, n8n, or similar regularly, and you follow the AI product space closely.

-

🧱 **Product Management track record:** You have successfully shipped real AI products, serious prototypes, public projects, agent workflows, eval suites, or tools used by real people.

-

🧪 **Eval practice:** You’ve built or meaningfully shaped evals, not just talked about them.

-

🛠️ **Harness literacy:** You understand tool loops, planners, scaffolding, context management, and the practical constraints of agentic systems.

-

🎯 **Strong product instincts:** You think clearly about trade-offs, user value, product quality, and what should or should not be built.

-

🎨 **UX taste:** You know what good looks like and what beautiful UX feels like. You can explain why one product feels great and another feels off.

-

🧭 **Comfort with ambiguity:** You bring order to chaos, structure fuzzy problems, and make progress when there are dozens of possible directions.

### For more senior candidates, we’ll also look for

-

🚀 **Shipped AI in production:** Real LLM or agent features, real users, real failures you learned from.

-

🎯 **0-to-1 product ownership:** You’ve owned ambiguous product areas from problem discovery through launch and iteration.

-

📊 **Data fluency:** SQL, funnels, product metrics, and healthy skepticism of what metrics do and do not tell you.

-

🤝 **Influence without authority:** You can align engineering, design, data, and go-to-market teams around complex product decisions.

###
For earlier-career candidates, we’ll especially value

-

⚡ **High slope:** you learn fast, ship fast, and raise the quality bar quickly.

-

🪶 **Low PM baggage:** you’re not overly attached to how PM “should” be done.

-

🔬 **Deep AI tinkering:** you’ve built or seriously experimented with non-trivial AI projects, even if they were solo or side projects.

-

👀 **Visible building:** public demos, writing, talks, open-source work, or other proof that you learn by making.

## Nice-to-haves

-

🔌 Workflow automation, orchestration, or developer tooling background.

-

🌐 Open-source and community experience.

-

🌱 Founding or early-stage background.

-

💻 Coding background.

-

📈 Growth experimentation experience.

-

✍️ Public writing, talks, or visible building.

*n8n is an equal opportunity employer and does not discriminate on the basis of race, religion, colour, national origin, gender, sexual orientation, gender identity, age, marital status, veteran status, or disability status.*

*We can sponsor visas to Germany; for any other country, you need to have existing right to work.*

***Our company language is English.***

*You care about diversity and inclusion? We do too! Check out our *[*Diversity, Inclusion and Belonging initiatives at n8n*](https://www.notion.so/Diversity-inclusion-and-belonging-n8n-c1bec2fff536422d868b1a438d990e35?pvs=21)* (*[*https://www.notion.so/n8n/Diversity-inclusion-and-belonging-n8n-c1bec2fff536422d868b1a438d990e35*](https://www.notion.so/n8n/Diversity-inclusion-and-belonging-n8n-c1bec2fff536422d868b1a438d990e35)*).*

##

***Location disclaimer:** If you see multiple job postings for the same role, it is most likely because we're hiring remotely for this role and posting in different locations to make sure every potential candidate can see the role. Please apply to the location you're the most likely to work from in the future. *

## **Benefits **

-

**Competitive compensation** 💸 – We offer fair and attractive pay.

-

**Ownership** 💪 – Our core value is to “empower others,” and we mean it—you’ll get a slice of n8n with equity.

-

**Work/life balance** 🏖️ – We work hard but ensure you have time to recharge:

-

**Europe:** 30 days of vacation, plus public holidays wherever you are.

-

**US:** 20 vacation days, 8 sick days, plus public holidays wherever you are.

-

**Health & wellness** 🩺 –

-

**Europe:** We provide benefits according to local country norms.*

-

**US**: Multiple low-premium, low-deductible medical plans with coverage for individuals and families—plus a no-cost premium HDHP option with a pre-seeded HSA—along with dental and vision coverage.

-

**Future planning** 💰 –

-

**Europe:** We provide pension contributions according to local country norms.*

-

**US:** 401(k) retirement plan with a 4% employer match.

-

**Financial security** 🛡️ –

-

**Europe:** We provide benefits according to local country norms.*

-

**US: **Company-paid short-term and long-term disability insurance, plus life insurance to support you and your loved ones.

-

**Career growth** 📈 – We hire rising stars who grow with us! You’ll get €1K (or equivalent) per year to spend on courses, books, events, or coaching to level up your skills.

-

**A passionate team** 🤩 – We love our product, and we prove it with regular hackathons where we see who can build the coolest thing with it!

-

**Remote-first** 🌏 – Our team works remotely across Europe, with regular off-sites for team bonding. Some roles, like sales in the US, are hybrid—please check the job description.

-

**Giving back** 🤝 – We're big fans of open source, and you'll get $100 per month to support projects you care about.

-

**AI enablement 🤖 –** We believe in working smarter—everyone gets an unlimited AI budget to explore and use the best tools to boost productivity and creativity.

-

**Transparency** 🙏 – We all know what everyone’s working on, how the company is doing—the whole shebang.

** Country-specific details are provided in your contract.*

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
