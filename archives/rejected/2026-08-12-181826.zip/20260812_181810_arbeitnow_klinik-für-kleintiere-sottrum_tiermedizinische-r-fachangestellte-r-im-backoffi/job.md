# Tiermedizinische:r Fachangestellte:r im Backoffice (m/w/d) mit Schwerpunkt Verwaltung und Administration

Posted: 2026-08-12T14:00:38Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Als inhabergeführtes Familienunternehmen, legen wir viel Wert auf individuelle Kunden- bzw. Patientenbetreuung. Medizinisches Fachwissen verbinden wir mit Einfühlungsvermögen, Teamgeist und echter Einsatzbereitschaft. Dank modernster Klinikausstattung gewährleisten wir umfangreiche Diagnostik- und Therapiemöglichkeiten für Kleintiere aller Art. Neben grundsätzlichen Leistungen wie Impfungen und allgemeinen Gesundheitschecks zählen zu unseren Spezialgebieten unter anderem: Chirurgie, Augen- und Zahnheilkunde, Dermatologie, Gynäkologie, Physiotherapie, innere Medizin und Kardiologie.

## Aufgaben

**Tiermedizinische:r Fachangestellte:r im Backoffice (m/w/d) mit Schwerpunkt Verwaltung und Administration – Gestalte die Abläufe hinter den Kulissen**

Wir bieten Dir eine unbefristete Anstellung in Voll- oder Teilzeit in

einer modernen und gleichzeitig familiären Kleintierklinik. Du profitierst von einem engagierten, herzlichen und erfahrenen Team sowie

einem Arbeitsbereich mit viel Abwechslung und einer langfristigen

Perspektive.

**Das sind Deine Aufgaben:**

✓ Vorbereitung und Bearbeitung buchhalterischer Vorgänge und Rechnungsprozesse

✓ Unterstützung bei der Rechnungsprüfung und Belegverwaltung

✓ Erstellung und Pflege von Dokumenten, Formularen und Belegen

✓ Bearbeitung von Versicherungs- und Abrechnungsunterlagen

✓ Mitwirkung bei der Bestandsverwaltung von Medikamenten sowie bei Einkaufs- und Warenwirtschaftsprozessen

✓ Koordination und Bearbeitung des allgemeinen Schriftverkehrs sowie der E-Mail-Kommunikation

✓ Unterstützung der Klinikleitung bei organisatorischen und administrativen Aufgaben

✓ Ansprechpartner für externe Dienstleister sowie interne Fachbereiche sowie die dazugehörige Terminorganisation

✓ Pflege von Stammdaten in unserer Praxissoftware

✓ Organisation und Optimierung interner Abläufe

✓ Bestellung von Praxis-, Büro- und Verbrauchsmaterialien

## Qualifikation

**Das bringst Du mit:**

✓ Eine abgeschlossene Ausbildung als Tiermedizinische:r Fachangestellte:r

✓ Idealerweise Zusatzqualifikation im kaufmännischen Bereich, in Buchhaltung,

✓ Praxismanagement oder Gesundheitswesen

✓ Erfahrung im Backoffice, in der Praxisorganisation oder administrativen Tätigkeiten

✓ Sehr gute EDV-Kenntnisse sowie Erfahrung im Arbeiten mit Praxissoftware

✓ Organisationstalent mit einer strukturierten und vorausschauenden Arbeitsweise

✓ Kommunikationsstärke, Freundlichkeit und Zuverlässigkeit

✓ Freude daran, Prozesse aktiv mitzugestalten sowie Verantwortung zu übernehmen

✓ Begeisterung für moderne Tiermedizin und die Arbeit in einem engagierten Team

## Benefits

**Das erwartet Dich bei uns:**

✓ Strukturierte Einarbeitung mit einem erfahrenen Team das zur Seite steht

✓ Betriebliche Altersvorsorge

✓ Vorausschauende Planung der Arbeitszeiten

✓ Flexible Arbeitszeiten

✓ Digitale Zeiterfassung

✓ Fachliche Weiterbildungsmöglichkeiten

✓ Ein hohes Maß an Verantwortung

✓ Hohes fachliches Niveau

✓ Benefits, wie z.B. Physiotherapie am Arbeitsplatz

✓ Monatsgehalt

✓ Arbeitsbekleidung

✓ Hansefit-Mitgliedschaft

✓ Bürohunde sind willkommen

✓ Nicht zu vergessen – einen immer gefüllten Süßigkeitenschrank

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
