# Account Executive-Manufacturing Vertical

Posted: 2026-08-12T14:04:38Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Over 50,000 customers globally trust our end-to-end, cloud-driven networking solutions and rely on our top-rated services and support to accelerate their digital transformation efforts and deliver progress like never before and with double digit growth year over year, no provider is better positioned to deliver better outcomes on scale, than Extreme.

Come become part of something big with us! We are a global leader, with hubs in Europe, North America, South America, Asia Pacific, and the Middle East.

The Sales Account Executive is responsible for driving new business, building and maintaining customer loyalty, ensuring high retention rates, promoting our Customer centric culture/forward thinking strategies and initiatives. The successful Sales Account Executive will leverage our three tiered sales model, prospecting for new business and partnering with the internal/external Sales teams providing our Customers with an experience exceeding expectations. The team is made up of credible top performers who foster and entrepreneurial spirit and delivering predictable and consistent revenue growth.

**Position Responsibilities**

- Represent our comprehensive solution of end to end Wired / Wireless Data Networking; Network Management and Security solutions, growing revenue and profit margins within the assigned territory achieving properly aligned quotas

- Utilize your Solutions Sales expertise to prospect and capture new business while growing the existing install base

- Provide in-depth business planning and reporting (monthly forecast, weekly commit, pipeline development, etc.)

- Develop strong, mutually beneficial relationships with cross functional teams within the territory and across the company

**Requirements**

- Proven hunter with a history of developing new prospective customers and collaborating across cross-functional internal teams, ensuring target quotas are achieved and exceeded.

- Proven experience developing and maintaining accounts in the Manufacturing Vertical with clients across Germany

- Driven to successfully close large complex deals amid a mix of new business, established accounts and channel management

- Strong executive presence and communications skills; with effective Solution Selling skills into enterprise networking environments at the CXO levels.

- Strong Business plan development and forecasting experience

- Must be a self-starter with high energy and drive who takes initiative and works with limited direction

- A highly trusted business partner, who maintains and expect high standards for self and team

- An accomplished Account Executive with established account base, strong regional Customer and Channel Partner relationships

- Relevant industry/competitive knowledge

- Proven and verifiable track record in exceeding sales quotas; achieving Club

- Strong Competitive Industry and Product Knowledge with ability to articulate the Extreme Networks Business Value Proposition

- **Strong German language skills**

- **Candidates need to be located in Southern Germany.**

OTE is on a 50/50 split and is based on qualifications and experience between 140-160K.

[Extreme Networks Benefits](https://www.extremenetworks.com/about-extreme-networks/career/benefits-and-perks)

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
