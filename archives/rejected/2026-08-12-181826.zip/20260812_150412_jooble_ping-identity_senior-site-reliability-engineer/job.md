# Senior Site Reliability Engineer

Posted: 2026-08-07T14:16:49.9170000

## Rejection

- Category: tech_stack
- Reason: role does not mention Go/Golang or PHP

...experiences, and identity and access management. 
We are seeking a **Senior **Site Reliability Engineer to join the Recognize Platform team... ...closely with delivery engineers, product owners, and software **developers **across teams 
Build and maintain a scalable, automated...
