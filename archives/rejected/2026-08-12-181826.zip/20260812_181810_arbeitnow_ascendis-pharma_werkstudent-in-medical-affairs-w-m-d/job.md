# Werkstudent/in Medical Affairs (w/m/d)

Posted: 2026-08-12T14:20:08Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**Über uns**

Wir sind ein innovatives, wachstumsorientiertes biopharmazeutisches Unternehmen mit Fokus auf seltene Erkrankungen. Unser Ziel ist es, das Leben von Patientinnen und Patienten durch wissenschaftliche Exzellenz, innovative Therapien und eine enge Zusammenarbeit mit medizinischen Fachkreisen nachhaltig zu verbessern.

Zur Unterstützung unseres Medical Affairs Teams suchen wir ab sofort eine/n engagierte/n Werkstudent/in, die/der uns bei folgenden Aufgaben tatkräftig unterstützt:

**Deine Aufgaben**

· Administrative Unterstützung des Medical Affairs Teams

· Mitarbeit bei der Organisation medizinischer Veranstaltungen und Kongresse

· Recherche und Aufbereitung medizinisch-wissenschaftlicher Literatur und Publikationen

· Mitarbeit an Präsentationen und Übersichten

· Zusammenarbeit mit internen Abteilungen wie Marketing, Market Access und Sales

**Requirements**

**Dein Profil**

· Eingeschriebene/r Student/in der Medizin, Pharmazie, Biologie, Biochemie, Gesundheitswissenschaften oder eines vergleichbaren naturwissenschaftlichen Studiengangs

· Interesse an medizinisch-wissenschaftlichen Fragen

· Strukturierte, selbstständige und zuverlässige Arbeitsweise

· Sehr gute organisatorische Fähigkeiten, hohe Sorgfalt

· Sicherer Umgang mit MS Office (PowerPoint, Excel, Word)

· Sehr gute Deutsch- und Englischkenntnisse in Wort und Schrift

· Erste Erfahrungen im wissenschaftlichen Arbeiten oder Projektmanagement von Vorteil

**Benefits**

**Das bieten wir**

· Spannende Einblicke in die Medical Affairs-Arbeit eines innovativen Pharmaunternehmens

· Mitarbeit an Projekten im Bereich seltener Erkrankungen

· Eigenverantwortliche Aufgaben und die Chance, Ideen einzubringen

· Flexible Arbeitszeiten, die sich gut mit dem Studium vereinbaren lassen

· Remote-Arbeit bzw. hybrides Arbeiten möglich

**Interessiert?**

Wir freuen uns auf deine Bewerbung mit Lebenslauf und einem kurzen Motivationsschreiben.

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
