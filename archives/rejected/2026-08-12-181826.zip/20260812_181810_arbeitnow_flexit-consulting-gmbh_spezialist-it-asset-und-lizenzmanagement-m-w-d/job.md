# Spezialist IT-Asset- und Lizenzmanagement (m/w/d)

Posted: 2026-08-12T14:00:37Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Für unseren Kunden in Köln, ein Unternehmen tätig in der Banking-Branche, suchen wir in Festanstellung einen Kandidaten, der das Management von Softwarelizenzen, IT-Assets und IT-Kosten aktiv mitgestaltet. In dieser vielseitigen Rolle tragen Sie dazu bei, Transparenz über den Einsatz von IT-Ressourcen zu schaffen, Prozesse zu optimieren und eine wirtschaftliche Nutzung von Software- und Cloud-Lösungen sicherzustellen.

Als wichtige Schnittstelle zwischen IT, Einkauf, Finanzbereich und Fachabteilungen unterstützen Sie die nachhaltige Steuerung der IT-Landschaft und leisten einen wesentlichen Beitrag zur Kosten- und Compliance-Optimierung.

## Aufgaben

- Verantwortung für das Software Asset Management sowie die Verwaltung von IT-Assets über den gesamten Lebenszyklus hinweg

- Sicherstellung einer effizienten, regelkonformen und wirtschaftlichen Nutzung von Softwarelizenzen

- Überwachung, Analyse und Optimierung bestehender Lizenz- und Nutzungsmodelle

- Zusammenarbeit mit internen Stakeholdern bei Beschaffungs- und Vertragsprozessen im IT-Umfeld

- Unterstützung bei der Planung, Steuerung und Kontrolle von IT-Budgets und IT-Kosten

- Mitwirkung bei der Analyse und Optimierung von Cloud-Ausgaben sowie der Entwicklung von Kostentransparenz

- Enge Abstimmung mit Fachbereichen zur Ermittlung und Koordination von IT-Bedarfen

- Erstellung von Reports, Auswertungen und Entscheidungsgrundlagen für das Management

- Unterstützung bei der Einhaltung von Compliance-, Audit- und Governance-Anforderungen im IT-Umfeld

## Qualifikation

- Erfolgreich abgeschlossenes Studium im Bereich (Wirtschafts-)Informatik, Betriebswirtschaft oder eine vergleichbare Qualifikation

- Berufserfahrung im Software Asset Management, Lizenzmanagement, IT-Einkauf oder in einer vergleichbaren Funktion

- Gute Kenntnisse im Umgang mit Softwarelizenzmodellen, idealerweise im Microsoft-Umfeld

- Erfahrung mit IT-Kostenmanagement, Budgetplanung oder Cloud-Kostensteuerung von Vorteil

- Sicherer Umgang mit Microsoft Excel sowie idealerweise Erfahrung mit Asset-Management- oder Lizenzmanagement-Tools

- Strukturierte, eigenverantwortliche und lösungsorientierte Arbeitsweise

- Ausgeprägte Kommunikations- und Organisationsfähigkeiten

- Sehr gute Deutschkenntnisse sowie gute Englischkenntnisse in Wort und Schrift

## Benefits

- Eine verantwortungsvolle Position mit vielseitigen Aufgaben und hoher Eigenverantwortung

- Die Möglichkeit, Prozesse aktiv mitzugestalten und weiterzuentwickeln

- Flexible Arbeitszeiten sowie attraktive Homeoffice-Möglichkeiten

- Individuelle Weiterbildungs- und Entwicklungsperspektiven

- Langfristige berufliche Perspektive in einem modernen Arbeitsumfeld

- Betriebliche Altersvorsorge sowie weitere attraktive Zusatzleistungen

- Ein wertschätzendes und kollegiales Team mit kurzen Entscheidungswegen

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
