# Werkstudentin Retail Operations Manager (m/w/d)

Posted: 2026-08-12T14:30:09Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

### **Gestalte mit uns die Zukunft der Lederindustrie! 🌍✨**

Du hast keine Lust auf einen typischen Studi-Job, bei dem du nur zuarbeitest? Bei uns übernimmst du direkt Verantwortung für **deine eigene Gruppe von Stores**. Du arbeitest mit echten Geschäftsdaten und nimmst aktiv Einfluss darauf, wie erfolgreich unsere Filialen laufen.

Schon während deines Studiums sammelst du wertvolle Erfahrung in der **Leitung und Koordination von Teams und Standorten**. Als **Retail Operations Manager** (Werkstudentin) bist du ein zentraler Bestandteil unseres Retail-Teams. Von Rostock aus betreust du 5–6 unserer Stores, sorgst für reibungslose Abläufe und bist die kommunikative Schnittstelle zwischen Zentrale und Filialen. Dein Ziel: Überblick behalten, Strukturen schaffen und aktiv mitgestalten. 🚀

**Deine Mission**🧭

-

**Stores im Blick behalten **- Du betreust 5 - 6 Stores aus der Zentrale in Rostock und sorgst dafür, dass Prozesse, Standards und Abläufe eingehalten und weiterentwickelt werden.

-

**Zahlen verstehen & steuern** -** **Du arbeitest mit Kennzahlen (Umsätze, Warenbestände, Reportings), wertest diese aus und leitest daraus Handlungsempfehlungen ab.

-

**Kommunikation & Koordination **-** **Du bist Ansprechpartner:in für Store-Teams, interne Abteilungen und externe Partner und sorgst für einen klaren Informationsfluss.

-

**Organisation & Struktur **-** **Du unterstützt bei der Planung, Organisation und Nachbereitung von Store-relevanten Themen und bringst Ordnung in Prozesse und Dokumentationen.

-

**Meetings begleiten -** Du nimmst an Calls mit Store Managern und Team Leads teil und lernst, worauf es in der Führung ankommt.

#### **Wie du von uns profitierst **💪

-

**Karrierepfad:** Wir bilden dich mit dem Ziel aus, später als **Area Manager** groß einzusteigen.

-

**Leistung zählt:** Wir bewerten deine Entwicklung während deiner Werkstudententätigkeit aktiv, um dir frühzeitig Perspektiven für die Zeit nach dem Studium aufzuzeigen.

-

**Langfristigkeit:** Ein dauerhafter Verbleib im Unternehmen ist von uns absolut erwünscht.

-

Weiterbildung: Bei uns hast du die Chance an verschiedenen **internen und externen Trainings** teilzunehmen und relevante **Zertifizierungen** für deine berufliche Zukunft zu erwerben.

**Was Du mitbringen solltest 💼**

**Studium im wirtschaftlichen Bereich** - Idealerweise studierst du Betriebswirtschaft, Wirtschaftswissenschaften, Handelsmanagement oder einen vergleichbaren Studiengang.

**Struktur & Organisationstalent **-** **Du arbeitest strukturiert, organisiert und zuverlässig – auch wenn mehrere Stores gleichzeitig betreut werden.

**Zahlenaffinität & analytisches Denken** -** **Du hast ein gutes Zahlenverständnis und gehst sicher mit Auswertungen und Kennzahlen um.

**Kommunikationsstärke **-** **Du trittst sicher, freundlich und lösungsorientiert auf und hast ein gutes Gespür für Menschen.

**Support - **Du erhältst ein intensives Onboarding und tägliche Unterstützung durch deinen Team Lead – besonders am Anfang lassen wir dich nicht allein.
**Keine Verkaufsprofis gesucht -** Du brauchst keine umfangreiche Vorerfahrung im Handel.

**Gute Ausdrucksfähigkeit **-** **Du verfügst über gute Deutsch- und Englischkenntnisse in Wort und Schrift.

**Was Dich bei Gusti Leder erwartet**🌿

-

**Faire Vergütung **-** **Ein attraktiver Stundenlohn von 17 - 19 € zzgl. Bonusmodell, orientiert an deiner Leistung und Verantwortung.

-

**Außergewöhnliche Benefits** -** **Attraktive Mitarbeiterrabatte, Prämiensysteme und weitere Corporate Benefits.

-

**Nachhaltigkeit first **-** **Wir leben Slow Fashion und gestalten die Lederindustrie verantwortungsvoll und transparent.

-

**Gestaltungsfreiheit **-** **Deine Ideen zählen – du kannst aktiv mitprägen, wie wir arbeiten und als Unternehmen wahrgenommen werden.

-

**Praxisnahes Lernen** -** **Du erhältst echte Einblicke in Retail- und Storemanagement und kannst dein wirtschaftliches Wissen direkt anwenden.

-

**Teamkultur **-** **Flache Hierarchien, offene Kommunikation und regelmäßige Teamevents sorgen für ein starkes Miteinander.

-

**Flexible Arbeitszeiten **-** **Ideal mit deinem Studium vereinbar.

-

**Work-Life-Balance **-** **Flexible Arbeitszeiten und Yoga-Sessions unterstützen dein Wohlbefinden.

-

**Gute Anbindung **-** **Unser Standort befindet sich in unmittelbarer Nähe zum Rostocker Hauptbahnhof und ist somit bequem mit der S-Bahn oder Straßenbahn erreichbar.

-

**Energie für den Tag **- Zweimal pro Woche frisches Mittagessen.

-

**Frisches Extra **-** **Täglich frisches Obst, Kaffee, Tee und Wasser stehen dir kostenfrei zur Verfügung.

_____________________________________________________________________________________________________________________________

#### 📩**Interessiert?**

Wir freuen uns auf Deine Bewerbung über unser [Online-Formular](https://gustileder.recruitee.com/o/werkstudentin-storebetreuung-retail-operations-mwd/c/new). Die Bewerbung dauert nur 5 Minuten.

Solltest Du Fragen haben, ist Deine Ansprechpartnerin **Lea **über oder telefonisch unter 016098409558 erreichbar.

______________________________________________________________________________________________________________________________

*Weitere Informationen zur Datenverarbeitung im Bewerbungsverfahren findest Du hier:[ https://gusti-leder.de/policies/privacy-policy](https://gusti-leder.de/policies/privacy-policy)*

Im Rahmen des Bewerbungsprozesses übernehmen wir keine dafür anfallenden Reisekosten.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
