# IT Business Analyst (m/w/d)

Posted: 2026-08-12T14:00:36Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Für unseren Kunden in Köln suchen wir in Festanstellung einen **IT Business Analyst (m/w/d)**, der als Schnittstelle zwischen Fachbereichen und IT maßgeblich zur Digitalisierung und Optimierung von Geschäftsprozessen beiträgt.

In dieser vielseitigen Rolle analysieren Sie Anforderungen, entwickeln praxisnahe IT-Lösungen und begleiten deren Umsetzung bis zur erfolgreichen Einführung. Dabei arbeiten Sie eng mit unterschiedlichen Fachbereichen zusammen und sorgen für nachhaltige, effiziente und zukunftsfähige Prozesse.

## Aufgaben

- Beratung der Fachbereiche bei der Analyse, Optimierung und Digitalisierung von Geschäftsprozessen

- Erhebung, Strukturierung und Dokumentation fachlicher und technischer Anforderungen

- Entwicklung von Konzepten und Lösungsansätzen für neue oder bestehende IT-Anwendungen

- Sicherstellung der Einhaltung von Governance-, Qualitäts- und Dokumentationsstandards

- Steuerung und Begleitung von IT-Projekten von der Anforderungsaufnahme bis zur Implementierung

- Zusammenarbeit mit internen und externen Stakeholdern zur erfolgreichen Umsetzung von Lösungen

- Unterstützung bei der Weiterentwicklung von Daten- und Prozessstandards

- Verantwortung für die nachhaltige Einführung und Betreuung der umgesetzten Lösungen

- Erstellung von Entscheidungsgrundlagen, Fachkonzepten und Prozessdokumentationen

## Qualifikation

- Erfolgreich abgeschlossenes Studium im Bereich (Wirtschafts-)Informatik oder eine vergleichbare Qualifikation

- Mehrjährige Erfahrung als Business Analyst, IT Consultant oder in einer vergleichbaren Position

- Kenntnisse in Anforderungsmanagement, Prozessdesign und Projektmanagement

- Erfahrung in der Digitalisierung und Optimierung von Geschäftsprozessen

- Verständnis moderner IT-Architekturen und Unternehmensanwendungen

- Idealerweise erste Erfahrungen im Bereich Data Governance oder Datenmanagement

- Analytische Denkweise sowie eine strukturierte und lösungsorientierte Arbeitsweise

- Ausgeprägte Kommunikations- und Präsentationsfähigkeiten

- Sehr gute Deutschkenntnisse in Wort und Schrift

## Benefits

- Eine abwechslungsreiche Position mit hoher Eigenverantwortung und Gestaltungsspielraum

- Spannende Digitalisierungs- und Transformationsprojekte

- Flexible Arbeitszeiten und attraktive Möglichkeiten zum mobilen Arbeiten

- Individuelle Weiterbildungs- und Entwicklungsmöglichkeiten

- Ein modernes und wertschätzendes Arbeitsumfeld mit offener Unternehmenskultur

- Umfangreiche Gesundheits-, Vorsorge- und Mobilitätsangebote

- Attraktive Zusatzleistungen sowie langfristige Entwicklungsperspektiven

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
