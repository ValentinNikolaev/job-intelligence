# Pflichtpraktikant:in Marketing Content, Social Media & E-Commerce (m/w/d) für Premium Hundezubehör

Posted: 2026-08-11T15:00:25Z

## Rejection

- Category: tech_stack
- Reason: role does not mention Go/Golang or PHP

**Moin, wir sind William Walker.**

Hast du Lust, einen Einblick in eine der spannendsten Premium-Marken für Hundezubehör in Europa zu bekommen – und dabei hinter die Kulissen von Content, Social Media und E-Commerce zu schauen?

Wir wollen bis 2028 zur führenden Marke für Premium-Hundezubehör in Europa werden. Bisher wachsen wir vor allem direkt über unseren eigenen Onlineshop und begeistern tausende Hund-Mensch-Teams mit unseren Produkten.

Damit unsere Marke weiter so sichtbar und geliebt bleibt, brauchen wir starke Inhalte, eine lebendige Community und ein Einkaufserlebnis, das genauso hochwertig ist, wie unsere Produkte.

Genau hier kommst du ins Spiel. Als Praktikant:in unterstützt du direkt unsere Head of Marketing und arbeitest an den Themen mit, die unsere Marke jeden Tag ein Stück bekannter machen: Content Creator, User Generated Content, Influencer- & Affiliate-Kooperationen, organisches Social Media und der Ausbau unseres Onlineshops.

Unser Büro befindet sich in Lengenbostel (ca. 55km süd-östlich von Hamburg entfernt) – du kannst selbst entscheiden, ob du hybrid, also teils vor Ort und im Home Office arbeitest oder komplett remote unterwegs sein möchtest.

Du willst nicht nur zuschauen, sondern wirklich etwas lernen und mitgestalten? Dann lies weiter.

## Aufgaben

**Content, UGC & Creator-Kooperationen**

- Du planst und organisierst Content für Kampagnen und Produkt-Launches frühzeitig – damit wir pünktlich zum Kampagnen- bzw. Launch-Start genügend passendes Material haben

- Du begleitest den gesamten UGC-Prozess: von der Creator-Recherche über die Ansprache, das Aufsetzen von Verträgen und den Produktversand bis zur Content-Erstellung und - Organisation

- Du lernst dabei auch die Content-Erstellung selbst kennen – inklusive Schnitt und Bearbeitung

- Du sammelst, sichtest und sortierst eingehenden Content, damit wir jederzeit frisches Material für unsere Kanäle haben

**Influencer- & Affiliate-Kooperationen**

- Du identifizierst passende Influencer:innen und Affiliate-Partner:innen, sprichst sie an und baust langfristige Kooperationen mit auf

- Du übernimmst die komplette Abwicklung: von der ersten Ansprache über Konditionen und Absprachen bis zum Aufsetzen der Verträge

- Du koordinierst Briefings, Produktversand und Deadlines und bist Ansprechperson für unsere Kooperationspartner:innen

- Du übernimmst die Performance-Kontrolle: Du trackst die wichtigsten Kennzahlen, wertest den Erfolg jeder Influencer- und Affiliate-Kooperation aus und bereitest die Ergebnisse übersichtlich auf

- Du leitest aus den Auswertungen Handlungsempfehlungen ab – welche Partner:innen, Formate und Kanäle sich lohnen und wo wir nachjustieren sollten

**Instagram & Organic Social Media**

- Du unterstützt bei der Planung, Erstellung und Veröffentlichung von Content für Instagram und weitere organische Kanäle

- Du bringst eigene Ideen für Posts, Reels und Storys ein und setzt sie mit um

- Du hilfst beim Community Management – du beantwortest Kommentare und Nachrichten und sorgst dafür, dass sich unsere Community gesehen fühlt

- Du beobachtest Trends, Formate und Wettbewerber und bringst Inspiration ins Team

**E-Commerce & Shop Support**

- Du unterstützt beim Aufbau unseres Post-Purchase-Funnels – also allem, was nach dem Kauf passiert, um aus Käufer:innen echte Fans zu machen

- Du hilfst dabei, die Customer Journey nach dem Kauf zu verbessern (z. B. E-Mail-Flows, Bestellbestätigungen, Bewertungs- und Wiederkauf-Anstöße)

- Du unterstützt bei kleineren Aufgaben rund um unseren Onlineshop, damit das Einkaufserlebnis rund und hochwertig bleibt

**Warum diese Rolle wichtig ist**

- Du unterstützt direkt unsere Head of Marketing und bekommst tiefe Einblicke in das D2C-Marketing

- Du arbeitest an Themen mit, die einen sichtbaren Einfluss auf Reichweite, Community und Umsatz haben

- Du lernst, wie Content, Social Media, Kooperationen und E-Commerce ineinandergreifen – praxisnah und von Anfang an mit Verantwortung

- Du übernimmst eigene kleine Projekte, statt nur zuzuarbeiten

## Qualifikation

**Was du mitbringen solltest**

- Du absolvierst ein Studium (z. B. Marketing, Kommunikation, Medien, BWL oder Vergleichbares) und benötigst ein Pflichtpraktikum über 6 Monate

- Erste Berührungspunkte mit Social Media, Content oder Marketing – z. B. durch Studium, eigene Kanäle, Werkstudierendenjobs oder frühere Praktika

- Freude an Content, Storytelling und dem, was auf Social Media gerade passiert

- Strukturierte, zuverlässige und eigenverantwortliche Arbeitsweise

- Ein gutes Gespür für Ästhetik, Sprache und Marken

- Sehr gute Deutsch- und gute Englischkenntnisse

**Das wäre ein großes Plus**

- Erste Erfahrung mit Instagram-Content, UGC oder der Zusammenarbeit mit Creator:innen

- Grundkenntnisse in Adobe-Tools (z. B. Premiere Pro, Photoshop, Lightroom) oder Tools wie Canva, CapCut und der Meta Business Suite

- Lust, auch selbst vor die Kamera zu gehen – für Social-Media-Content und unsere Ads Interesse an E-Commerce und daran, wie ein Onlineshop wächst

- Eigene Begeisterung für Hunde und die Welt hochwertiger Hundeprodukte

## Benefits

🐶 **Office Dogs welcome** – war dir vermutlich schon klar

📚 **Echtes Lernen** – du bekommst Einblick in alle relevanten Marketing- und E-Commerce-Themen

🚀 **Viel Verantwortung** – du übernimmst eigene Projekte und arbeitest direkt mit der Head of Marketing zusammen

💬 **Direkte Kommunikation** – klare Worte statt Politik

🎓 **Persönliche Weiterentwicklung** – wir investieren in Menschen, die etwas bewegen wollen

📈 **Direkter Einfluss** – deine Ideen landen wirklich auf unseren Kanälen

❤️ **Sinnvolle Produkte** – wir schaffen Produkte, die Hund und Mensch näher zusammenbringen

**Also, bewirb dich noch heute,** wenn du Lust hast, hinter die Kulissen einer der spannendsten Premium-Marken für Hundezubehör zu schauen und Content, Social Media und E-Commerce hautnah mitzugestalten. Wir freuen uns darauf, dich kennenzulernen.

Dein William Walker Team

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
