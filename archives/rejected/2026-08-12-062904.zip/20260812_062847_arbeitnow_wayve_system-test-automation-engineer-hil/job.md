# System Test Automation Engineer, HIL

Posted: 2026-08-12T05:55:16Z

## Rejection

- Category: role_mismatch
- Reason: title is an obvious mismatch for a backend profile

## **About us **

Founded in 2017, Wayve is the leading developer of Embodied AI technology. Our advanced AI software and foundation models enable vehicles to perceive, understand, and navigate any complex environment, enhancing the usability and safety of automated driving systems.

Our vision is to create autonomy that propels the world forward. Our intelligent, mapless, and hardware-agnostic AI products are designed for automakers, accelerating the transition from assisted to automated driving.

In our fast-paced environment big problems ignite us—we embrace uncertainty, leaning into complex challenges to unlock groundbreaking solutions. We aim high and stay humble in our pursuit of excellence, constantly learning and evolving as we pave the way for a smarter, safer future.

At Wayve, your contributions matter. We value diversity, embrace new perspectives, and foster an inclusive work environment; we back each other to deliver impact.

Make Wayve the experience that defines your career!

## The Role

Wayve's Verification and Release Test team sits at the intersection of Hardware, Embedded Software, and Machine Learning Models. Testing spans component, system, and vehicle levels, and we pride ourselves on finding the most efficient and effective ways to deliver the most valuable results for the company.

As a System Test Automation Engineer, you'll independently own the design and delivery of automated verification for a defined area of our embedded software stack. You'll build robust, reusable test automation, drive failures to root cause across engineering boundaries, and steadily raise the bar on coverage, reliability, and traceability. This is a hands-on delivery role with room to grow into broader areas of the system including sensing and model-behaviour testing as the company and your experience evolve. The ideal candidate is a self-starter with a sharp eye for improvement across multiple engineering domains.

## Key Responsibilities

- Develop automation for system functionality tests at component, integration, and system levels, across software and hardware boundaries.

- Automate open-loop and closed-loop replay based Tests, reliability and fault-injection tests to support verification, release, coverage expansion, and debug workflows.

- Lead root-cause investigations for failures found during test campaigns, collaborating across hardware, software, and infrastructure teams.

- Optimise buildkite CI/CD-integrated test workflows for rapid, reliable, and repeatable execution.

- Integrate third-party verification tools including JAMA (requirements), MC/DC (coverage), and MISRA (style compliance); manage artefacts via Artifactory and Azure.

- Define and track KPIs and quality metrics for system testing, supporting data-driven validation and release decisions.

- Uncover software and hardware bugs through increased test coverage and report findings through JIRA.

- Identify and implement infrastructure improvements that enhance test coverage, failure traceability, and compliance reporting.

- Review, create, and adhere to Risk Assessments to ensure all testing activities are conducted safely and responsibly.

## About You

To set you up for success as a System Test Automation Engineer at Wayve, we're looking for the following skills and experience.

### Essential Skills & Experience

- Hands-on experience with system-level verification and validation in robotics, embedded software, or mechatronic systems, with a track record of delivering test automation independently.

- Experience with L2+ hands-off, L3, or L4 automated driving systems.

- Knowledge of consumer safety-rating protocols (e.g., Euro NCAP -AEB, LSS/LKA, ADAS scenarios), DCAS regulatory testing (UN R171), and automotive cybersecurity testing and standards (ISO/SAE 21434, UN R155).

- Experience with HiL testing and tooling using CAN, Ethernet, GMSL, dSPACE, Vector, Xylon, or similar.

- Strong proficiency in Python, including developing automation test frameworks with pytest.

- Proven ability in interface-level testing, including hardware/software interactions and embedded interfaces.

- Experience integrating software quality assurance tools and standards (ASPICE, SOTIF, ISO 26262, JAMA, X-RAY).

- Knowledge of open- and closed-loop HiL replay using dSPACE or other emulators.

- Proficient in CI/CD principles and related tooling (e.g., GitLab CI, Buildkite, Bazel).

- Experience with test automation dashboards, logging, and reporting infrastructure (e.g., Grafana, Looker, Datadog, JIRA).

- Experience developing or testing automotive software across embedded and system levels.

- Strong cross-functional communication skills; able to work collaboratively across software, hardware, autonomy, DevOps, and product teams.

### Desirable Skills & Experience

- Experience with autonomous vehicle systems, ADAS, or related technologies..

- Strong Python Automation and knowledge of dSPACE open and closed Loop HIL based replay Testing

- Experience contributing to continuous improvement of test methods, safety procedures, or operational efficiency.

- Awareness of data management and version control systems (e.g., Git, Buildkite, or similar).

- Familiarity with agentic AI coding tools (e.g., Cursor, Claude Code) and a demonstrated ability to use them to accelerate and optimise test development, debugging, and automation workflows.

This is a full-time role based in our office in Leonberg. At Wayve we want the best of all worlds so we operate a hybrid working policy that combines time together in our offices and workshops to fuel innovation, culture, relationships and learning, and time spent working from home.

Wayve is committed to creating an inclusive interview experience. If you require any accommodations or adjustments to participate fully in our interview process, please let us know.

We understand that everyone has a unique set of skills and experiences and that not everyone will meet all of the requirements listed above. If you’re passionate about self-driving cars and think you have what it takes to make a positive impact on the world, we encourage you to apply.

At Wayve we're committed to creating a diverse, fair and respectful culture that is inclusive of everyone based on their unique skills and perspectives, and regardless of sex, race, religion or belief, ethnic or national origin, disability, age, citizenship, marital, domestic or civil partnership status, sexual orientation, gender identity, veteran status, pregnancy or related condition (including breastfeeding) or any other basis as protected by applicable law.

For more information visit [Careers at Wayve. ](https://wayve.ai/careers/)

To learn more about what drives us, visit [Values at Wayve ](https://wayve.ai/careers/)

For US candidates only, please visit [E-Verify Notice](https://drive.google.com/file/d/1N46n3iN0AG8EPEO-hCanyyv7hzz8KgT_/view?usp=sharing) and [Participation and Right to Work](https://www.ussc.gov/sites/default/files/pdf/employment/RightToWork.pdf)

DISCLAIMER: We will not ask about marriage or pregnancy, care responsibilities or disabilities in any of our job adverts or interviews. However, we do look to capture information about care responsibilities, and disabilities among other diversity information as part of an optional DEI Monitoring form to help us identify areas of improvement in our hiring process and ensure that the process is inclusive and non-discriminatory.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
