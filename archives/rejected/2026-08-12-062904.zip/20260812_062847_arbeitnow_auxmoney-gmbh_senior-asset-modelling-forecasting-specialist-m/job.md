# Senior Asset Modelling & Forecasting Specialist (m/f/d)

Posted: 2026-08-11T23:09:39Z

## Rejection

- Category: tech_stack
- Reason: role does not mention Go/Golang or PHP

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
