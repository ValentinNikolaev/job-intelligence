# IT-Support (m/w/d) - 1441

Posted: 2026-08-11T15:00:26Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Zur Verstärkung unseres Managed Service Teams suchen wir einen **IT-Support-Techniker (m/w/d)**.

## Aufgaben

- Bereitstellung von Supportleistungen am Standort

- First- und Second-Level-Support für Anwender im Bereich Windows-Client, MS Office und Standardsoftware

- Mobile Device Management und Hardware-Support sowie Konferenzraum- und Meetingraum-Support

- Koordination von Hardware-Reparaturen mit externen Dienstleistern

- Unterstützung im Staging, Deployments und Asset-Management

- Unterstützung für Server- oder Netzwerkthemen vor Ort

## Qualifikation

- Erfahrung im Field Service oder Hard-/ Software-Support

- Gute Kenntnisse in der Fehleranalyse in Windows-Client-Umgebungen (OnPrem)

- Grundlegendes Wissen in Netzwerk- und Servertechnologien (z. B. Verkabelung, Neustarts, Patchen)

- Hohe Serviceorientierung, Teamfähigkeit und proaktives Handeln

- Sehr gute Englischkenntnisse in Wort und Schrift, Deutschkenntnisse von Vorteil

- Reisebereitschaft und Führerschein

- ITIL-Zertifizierung von Vorteil

## Benefits

- Persönliche Zusatzleistungen, flexibel auf deine Bedürfnisse

zugeschnitten – z. B. Jobticket, JobRad, Gympass oder andere

Zusatzleistungen, die individuell vereinbart werden können

- Sehr gutes und angenehmes Betriebsklima in einem dynamischen und internationalen Arbeitsumfeld

- Eine offene Kommunikationskultur mit flachen Hierarchien und schnellen Entscheidungsprozessen

- Unterstützung bei der beruflichen und persönlichen Weiterentwicklung

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
