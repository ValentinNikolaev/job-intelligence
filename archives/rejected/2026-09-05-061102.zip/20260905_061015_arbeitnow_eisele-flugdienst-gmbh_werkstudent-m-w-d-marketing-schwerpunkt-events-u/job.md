# Werkstudent (m/w/d) Marketing, Schwerpunkt Events und Social Media

Posted: 2026-09-04T23:30:09Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**Werkstudent (m/w/d) Marketing, Schwerpunkt Events und Social Media**

E-Aviation bringt unsere Kunden flexibel zu Geschäftsterminen oder stilvoll und individuell in den Urlaub, zu Events mit der Familie oder Freunden in Europa und darüber hinaus. Mit unserer breit aufgestellten Flotte aus modernen Privatjets können wir unterschiedlichste Ansprüche in puncto Streckenlänge und Passagierzahl ideal bedienen.

Als inhabergeführte Charter Airline bieten wir unseren Kunden die gleich hohen Sicherheitsstandards wie Linienfluggesellschaften.

Zusätzlich genießen unsere Kunden bei E-Aviation die besonderen Vorzüge eines privaten Flugdienstes: unsere persönliche, exklusive Betreuung verbunden mit einer individuellen Flugplanung, die sich ausschließlich nach dem Terminwünschen des Kunden richtet.

Ein Jet aus unserer E-Aviation Flotte ist dann startklar, wann der Kunde es wünscht.

Fliegen ist unsere Passion - werden auch Du ein Teil unseres Teams!

**Zur Unterstützung unseres Teams suchen wir ab sofort eine studentische Aushilfskraft (m/w/d) im Bereich Marketing und Events mit Schwerpunkt Social Media.**

Wenn Du gerne Inhalte entwickelst, Social Media nicht nur konsumierst, sondern aktiv mitgestalten möchtest und Lust auf ein vielseitiges Umfeld zwischen Kommunikation, Veranstaltungen und Marketing hast, freuen wir uns auf Dich.

**Das erwartet Dich bei uns:**

-

Ein junges Team mit freundschaftlichem und kollegialem Umgang

-

Verantwortungsvolle Aufgaben und eigene Projekte in einer spannenden, abwechslungsreichen und internationalen Branche

-

Flexible Arbeitszeiten und Homeoffice

-

Offene Unternehmenskultur mit flachen Hierarchien sowie kooperative Zusammenarbeit in einem motivierten Team

-

Individuelle und zukunftsorientierte Entwicklungsmöglichkeiten entsprechend Ihrer Qualifikation und Neigung

-

Ergonomische Arbeitsplätze, Parkmöglichkeiten in Büronähe und selbstverständlich kostenlose Getränke 🙂

**Deine Aufgaben:**

Bei uns übernimmst du eine abwechslungsreiche Mischung aus eigenen Verantwortungsbereichen und der Unterstützung spannender Marketingprojekte.

-

**Events**: Du unterstützt die Organisation unserer Veranstaltungen – insbesondere begleitest Du unser Firmenjubiläum von der Planung bis zur Durchführung

-

**Content-Erstellung:** Du erstellst Inhalte für LinkedIn, Facebook, Instagram und machst unsere Dienstleistung für unsere Zielgruppe greifbar

-

**Giveaways**: Du sorgst dafür, dass wir für Kundentermine und Veranstaltungen jederzeit mit passenden Giveaways ausgestattet sind

-

**Projekt-Support**: Du unterstützt unser Marketing-Team im Tagesgeschäft und packst dort mit an, wo Deine Unterstützung gebraucht wird

-

**Ideen einbringen**: Du entwickelst eigene Ideen und hilfst dabei, unser Marketing kontinuierlich weiterzuentwickeln und unsere Zielgruppe zu begeistern

-

Du studierst Marketing, Medien, Kommunikation, Betriebswirtschaftslehre oder ein vergleichbares Fachgebiet und begeisterst dich für digitale Themen sowie Social Media

-

Du arbeitest eigenverantwortlich, denkst mit und findest Dich schnell in neue Aufgaben ein

-

Du hast Freude am Schreiben und bereitest auch komplexe Themen verständlich auf

-

Du nutzt KI-Tools selbstverständlich und hast Lust, Dich in neue Themen und Tools einzuarbeiten

-

Du arbeitest strukturiert und sorgfältig, organisierst gerne, kommunizierst sicher und verfügst über sehr gute Deutsch- und Englischkenntnisse

-

Du hast idealerweise erste Erfahrungen im Marketing oder Eventmanagement gesammelt

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
