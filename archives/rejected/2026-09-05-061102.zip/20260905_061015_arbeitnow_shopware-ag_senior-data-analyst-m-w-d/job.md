# Senior Data Analyst (m/w/d)

Posted: 2026-09-05T02:30:18Z

## Rejection

- Category: language_requirement
- Reason: hard German language requirement without English green light

Shopware ist ein führendes E-Commerce-System, das es Unternehmen weltweit ermöglicht, im digitalen Handel schnell und effizient zu skalieren. Als zukunftsweisende Open-Source-Lösung wird Shopware bereits von einigen der größten europäischen Marken, Einzelhändlern und Herstellern im B2C- und B2B-Bereich eingesetzt.

**ARR, Umsatz, GMV.** Das sind die Kennzahlen, an denen sich unser Management und unsere Shareholder orientieren. Jemand muss die Verantwortung dafür übernehmen, was diese Kennzahlen tatsächlich bedeuten, entscheiden, wann ihre technische Definition angepasst werden muss, diese Änderungen in unserem Data Warehouse umsetzen und sicherstellen, dass die Menschen, die mit diesen Zahlen arbeiten, sie selbst erklären und vertreten können.

Genau darum geht es in dieser Rolle. Es ist keine klassische Reporting-Rolle, in der Anforderungen und Anfragen abgearbeitet werden. Stattdessen **übernimmst du die Verantwortung für das analytische Fundament unserer geschäftskritischen KPIs** – von der SQL-Logik im Data Warehouse bis hin zu den technischen Definitionen, auf die sich Finance und Management verlassen, wenn beispielsweise die Frage aufkommt, warum sich eine Kennzahl im vergangenen Monat verändert hat.

Diese Position ist Teil des Business Intelligence Teams und **kann vor Ort, hybrid oder vollständig remote innerhalb Deutschlands besetzt werden**. Dein Arbeitsort wird im Voraus vereinbart und bildet die Grundlage deines Arbeitsvertrags.

-

**KPI Ownership:** Du verantwortest die technischen Definitionen und die zugrunde liegende Logik unserer geschäftskritischen KPIs – allen voran ARR und Umsatz. Dabei geht es nicht nur darum, bestehende Definitionen zu pflegen. Du beurteilst, wann eine technische Definition angepasst werden muss, steuerst Änderungen durch unsere Governance- und Freigabeprozesse, setzt sie technisch um und stehst hinter dem Ergebnis – auch dann, wenn es im Rahmen eines Audits oder durch externe Stakeholder kritisch hinterfragt wird. Dazu gehört auch die Kommunikation: Du erklärst Definitionen und Änderungen proaktiv und verständlich – von operativen Teams bis hin zum Management.

-

**Technische Expertise und unsere Datenlandschaft:** Du entwickelst, debuggst und prüfst deine eigene analytische Logik. Deine fundierten SQL-Kenntnisse ermöglichen es dir, die benötigten Daten selbst zusammenzustellen, anstatt darauf warten zu müssen, dass andere sie bereitstellen. Du hast ein echtes End-to-End-Verständnis davon, wie Daten aus den Quellsystemen über das Data Warehouse bis ins Reporting gelangen. Dadurch kannst du unterscheiden, ob die Ursache eines Problems in den Daten, im Prozess oder in der Definition liegt. Du erkennst, wann ein Problem an der Quelle behoben werden muss, anstatt es lediglich im Reporting zu korrigieren. Gleichzeitig kannst du einen umfangreichen, laufenden Backlog eigenständig priorisieren und vom ersten Tag an selbstständig bearbeiten, ohne engmaschige Steuerung zu benötigen. Für unsere Pipelines oder die Plattform selbst bist du nicht verantwortlich – das übernehmen unsere Data Engineers, mit denen du eng zusammenarbeitest.

-

**Enabling statt reiner Umsetzung:** Du gestaltest Definitionen, Modelle und Reportings so, dass Stakeholder ihre weiterführenden Fragen selbst beantworten können, statt für jede einzelne Frage erneut auf BI angewiesen zu sein. Für Finance bedeutet das konkret: Du entwickelst die Datenbasis, Tools und Transparenz, die es dem Team ermöglichen, Themen vollständig selbst zu verantworten, die fachlich bei Finance liegen – beispielsweise den Monatsabschluss oder ARR-Korrekturen. BI verantwortet die Definition und die technische Umsetzung; Finance verantwortet den Prozess und die Kennzahl. Das Ziel ist ein Prozess, den Finance eigenständig durchführen kann.

-

**Governance als Change Management:** Gemeinsam mit dem Head of BI etablierst und verankerst du ein Governance-Framework für unsere geschäftskritischen KPIs. Ihr definiert, was Ownership auf Business- und BI-Seite konkret bedeutet, wie Definitionen dokumentiert, aktuell und audit-ready gehalten werden und wie Änderungen geprüft, entschieden und kommuniziert werden. Die eigentliche Herausforderung liegt dabei nicht in der Dokumentation, sondern in der Akzeptanz und Anwendung im Unternehmen. Du erhältst sowohl das Mandat als auch die Unterstützung des Leadership-Teams, um diese Veränderung voranzutreiben.

-

**Wissenstransfer:** Du teilst Workflows, Logiken und Arbeitsweisen mit dem Team. So stellst du sicher, dass die von dir etablierten Standards nicht nur bei dir liegen, sondern nachhaltig im gesamten Team verankert werden.

### Das bringst du mit:

-

Du verfügst über **mehrere Jahre Berufserfahrung im Bereich Business Intelligence oder Data Analytics.** Dabei hast du Themen bereits eigenständig von Anfang bis Ende verantwortet, anstatt lediglich nach vorgegebenen Anforderungen zu arbeiten.

-

**SQL ist ein zentraler Bestandteil dieser Rolle **und kein Nice-to-have**.** Du bist sicher darin, komplexe Logiken innerhalb eines mehrschichtigen **Data Warehouses** zu lesen, zu schreiben und zu debuggen. Dabei denkst du in Datenmodellen und übergreifenden Zusammenhängen, anstatt dich ausschließlich auf einzelne Queries zu konzentrieren.

-

Du verfügst über **fundierte Erfahrung mit einem modernen BI-Tool**. Wir arbeiten derzeit mit MS Power BI, weshalb Erfahrung mit Power BI besonders wertvoll ist.

-

Du hast Erfahrung mit **Business- oder Finanz-KPIs** und bist bereit, dich intensiv mit deren Definition und Berechnungslogik auseinanderzusetzen. Kenntnisse von SaaS-Kennzahlen wie ARR und NRR oder von Revenue Recognition sind ein großes Plus. Falls diese Themen für dich noch neu sind, erwarten wir echtes Interesse und die Bereitschaft, dich intensiv einzuarbeiten.

-

Du hast Erfahrung in der engen **Zusammenarbeit mit Finance oder anderen Business-Stakeholdern**. Du kannst Änderungen an Methoden und Berechnungslogiken auch nicht-technischen Kolleg:innen verständlich erklären und bist gleichzeitig in der Lage, deinen Ansatz zu diskutieren und fundiert zu vertreten, wenn er kritisch hinterfragt wird.

-

Du arbeitest strukturiert, organisierst dich sehr selbstständig und bringst ein hohes Maß an Eigeninitiative mit. Gleichzeitig hast du das nötige Selbstbewusstsein, Ergebnisse zu hinterfragen und klar anzusprechen, wenn du der Meinung bist, dass eine Zahl nicht korrekt ist.

-

Du verfügst über **sehr gute Englischkenntnisse** auf C1-Niveau. Deutschkenntnisse sind ein Plus.

**Nice to have**

-

Du hast Erfahrung mit dbt oder einem vergleichbaren Transformation Framework sowie mit versionskontrollierter Analytics-Arbeit. Wir bauen diese Arbeitsweisen aktuell weiter aus, weshalb entsprechende Erfahrung für uns besonders wertvoll ist.

-

Du hast bereits in einem SaaS- oder E-Commerce-Umfeld gearbeitet und kennst die typischen Datenstrukturen und Business-Fragestellungen, die mit diesen Geschäftsmodellen verbunden sind.

-

Du hast praktische Erfahrung mit Data Governance, Datenkatalogen oder der Dokumentation von KPIs. Dir ist bewusst, wie wichtig es ist, Definitionen und Verantwortlichkeiten für Daten im gesamten Unternehmen klar, nachvollziehbar und zugänglich zu machen.

-

Du hattest bereits Berührungspunkte mit Controlling-Themen, Due-Diligence-Prozessen, Audits oder Anforderungen aus dem Investor Reporting. Du verstehst, dass diese Bereiche eine verlässliche Datenbasis, konsistente Definitionen und ein hohes Maß an Genauigkeit erfordern.

### Das bieten wir dir:

-

**Unternehmenskultur:** Offene Kultur, flache Hierarchien, Eigeninitiative wird gefördert.

-

**Arbeitsverträge:** Unbefristete Anstellungen bieten langfristige Sicherheit.

-

**Flexibilität:** Flexible Arbeitszeiten und Optionen für mobiles Arbeiten und Full-Remote-Verträge.

-

**Ausstattung:** Freie Wahl der Arbeits-Hardware.

-

**Onboarding:** Gut strukturiertes Onboarding mit Unterstützung durch einen persönlichen "Buddy".

-

**Arbeitsumfeld:** Inspirierendes Umfeld mit engagierten Kollegen und einer dynamischen Gemeinschaft.

-

**Entwicklungsmöglichkeiten:** Vielfältige Chancen für persönliches Wachstum und Entwicklung.

-

**Zusatzleistungen:** Attraktive Benefits wie betriebliche Altersvorsorge, Gesundheitsprogramme und regelmäßige Teamevents.

... und vieles mehr!
Einen detaillierten Einblick bekommst du auf unserer [Karriereseite](https://careers.shopware.com/de/warum-shopware/bei-shopware-arbeiten/).

**Deine Ansprechperson für diese Stelle ist Josephine Scheffler und steht dir bei Fragen gerne zur Verfügung!**

Der Schutz deiner persönlichen Daten hat für uns oberste Priorität. Unsere Bewerberinformationen findest du [hier](https://www.shopware.com/de/datenschutz/bewerbende/).

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
