# Partnership Development Manager GSI DACH

Posted: 2026-09-05T02:40:10Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

## **About Mistral**

Mistral provides full-stack AI solutions: from frontier models to developer tools, applications, and compute. We partner with enterprises tackling the hardest problems—across high-stakes industries like finance, manufacturing, defense, healthcare, and the public sector—co-creating customized AI systems that they can run on their terms.

We are a dynamic, collaborative team passionate about AI and its potential to transform society. Our diverse workforce thrives in competitive environments and is committed to driving innovation. Our teams are distributed between Europe, North America, Asia and the Middle East. We are creative, low-ego and team-spirited.

## **Role Summary**

The Partnerships organization is accelerating its expansion globally. We now need the architecture to scale our delivery force through partnerships to meet the next wave of enterprise demand.

This is a high-impact role offering exceptional exposure to the European market, focusing on DACH (UKI & Nordics) and the opportunity to shape our partnership program from the ground up. You will work closely with Partnership & GTM leadership, Partner Solution Architects, and cross-functional teams to drive breakthrough co-sell motions, co-solutions, and joint go-to-market initiatives with strategic and regional partners.

This is a critical hybrid responsibility: Partner management across Europe for Strategic Partners while building regionally focussed partnerships to set up the foundations for future success.

In this role, you’ll report directly to the Europe GSI Director and will have functional accountability to our VP DACH, playing a vital role in co-defining and executing our regional go-to-market strategy.

## **What You Will Do**

## **Strategy & Architecture**

-

Architect and execute the GSI partner ecosystem model across DACH, establishing high-value frameworks that align enterprise strategic goals with scalable revenue models.

-

Define and institutionalize multi-year strategic roadmaps with major German Systems Integrators to accelerate co-selling motions, technical alignment, and joint pipeline expansion.

-

Drive ecosystem vision and governance, orchestrating financial growth targets, technical solutions integration, and transformative co-marketing programs.

## **Commercial Velocity**

-

Spearhead regional partner-led revenue generation, surpassing growth targets through systematic joint deal acceleration and high-impact GTM execution.

-

Establish executive alignment and field resolution standards across partner networks to maximize strategic velocity and eliminate friction in large enterprise deals.

-

Build comprehensive performance insights and analytical models to track partnership health, ROI, and long-term ecosystem value creation.

-

Scale SI delivery capabilities through specialized enablement programs, ensuring partners become force multipliers for Mistral AI enterprise deployment.

## **Ecosystem Interlock**

-

Embed robust co-sell engagement rules, attribution frameworks, and deal registration workflows across the DACH GTM organization to drive Tier 1 opportunity conversion.

-

Champion cross-functional collaboration across Solution Architects, Enablement, Marketing, and Product teams to champion seamless partnership delivery and pipeline maturity.

-

Lead Monthly Business Reviews and executive synchronization cadences with DACH regional leadership to sustain strategic alignment.

-

Provide strategic feedback loops to product and engineering leadership, aligning model evolution and deployment architectures with DACH enterprise needs.

## **About You**

**Education:** Bachelor's degree in Business, Computer Science, Information Technology, or a related field. An MBA or advanced degree is preferred.

**Location:** Munich preferred. We’ve offices in Munich. Expect travels within the DACH Region & to our HQ based in Paris.

**Experience - **You are a builder, added with:

-

**Technical Credibility:** Ability to understand and discuss AI/ML concepts, API integrations, and model deployment architectures. Experience with LLM platforms is a strong plus.

-

**Executive Stakeholder Management:** Experience working closely with C-level or senior leadership at partner organizations. High maturity in communication, influence, and prioritization.

-

**Market Expertise:** Strong network and understanding of the DACH technology ecosystem and regional variations.

-

**Scale and Ambiguity Mindset:** Experience in fast-growing environments. Comfortable navigating ambiguity and evolving priorities. Ability to operate with high autonomy and judgment.

-

**Industry Background:** Experience in enterprise software, SaaS, AI, or infrastructure industries. Exposure to AI, data, or developer-focused products is a strong plus.

-

**Languages:** Business fluent English and German.

## **What We Offer**

We offer a comprehensive benefits package designed to support your well-being, growth, and work-life balance. Benefits vary by country and may include healthcare coverage, parental leave, retirement plans, relocation support, wellness programs, meal and transportation allowances, and other location-specific perks.

For the most up-to-date details on benefits available in your location, please refer to our [Benefits page](https://app.notion.com/p/mistralai/Benefits-at-Mistral-36e6ba59a7fe836b93dd01737fcc27ef?source=copy_link).

## **Privacy Policy**

Your privacy matters to us. You can learn more about how we handle your personal data in our [Applicant Privacy Policy](https://legal.mistral.ai/terms/applicant-privacy-policy).

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
