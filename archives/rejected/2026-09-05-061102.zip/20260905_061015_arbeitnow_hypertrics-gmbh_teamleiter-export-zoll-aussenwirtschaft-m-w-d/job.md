# Teamleiter Export / Zoll & Außenwirtschaft (m/w/d)

Posted: 2026-09-05T02:30:16Z

## Rejection

- Category: tech_stack
- Reason: role does not mention Go/Golang or PHP

### **Teamleiter Export / Zoll & Außenwirtschaft (m/w/d)**

Standort: München | Vollzeit | Unbefristet

Für unseren Mandanten, ein inhabergeführtes, europaweit tätiges Familienunternehmen mit Sitz in München und Spezialisierung auf professionelle Reinigungsprodukte, Dosiertechnologie und ganzheitliche Hygienelösungen für Objektreinigung, Gesundheitswesen, Textil- und Küchenhygiene sowie Verkehrsmittelreinigung, suchen wir im exklusiven Auftrag zum nächstmöglichen Zeitpunkt einen **Teamleiter Export / Zoll & Außenwirtschaft (m/w/d)**. Das Unternehmen steht für ein familiäres, kollegiales Arbeitsumfeld, kurze Entscheidungswege und eine Unternehmenskultur, in der Eigenverantwortung und Mitgestaltung aktiv gelebt werden.

#### **Ihre Aufgaben**

-

**Teamführung:** Fachliche Führung, Motivation und Weiterentwicklung des Export-Teams – als Vorbild und Ansprechpartner für alle Fragen des operativen Tagesgeschäfts

-

**Operative Mitarbeit:** Aktive Einbindung in die Export- und Zollabwicklung – diese Position verbindet Führungsverantwortung mit operativer Tiefe

-

**Auftragsabwicklung:** Sicherstellung einer termingerechten und qualitativ hochwertigen Abwicklung aller Exportaufträge

-

**Zoll & Außenwirtschaft:** Zentraler Ansprechpartner für interne und externe Fragestellungen im Bereich Zoll und Außenwirtschaft – inklusive Sicherstellung der Einhaltung aller rechtlichen Vorgaben

-

**Prozessoptimierung:** Analyse und Optimierung bestehender Export- und Zollprozesse sowie Weiterentwicklung von Standards, Arbeitsanweisungen und Dokumentationen

-

**Projektarbeit:** Aktive Mitarbeit in bereichsübergreifenden Projekten

-

**Rechtsmonitoring:** Laufende Beobachtung gesetzlicher Änderungen im Export- und Zollrecht sowie Umsetzung erforderlicher Maßnahmen

#### **Ihr Profil**

-

**Fachliche Qualifikation:** Abgeschlossene kaufmännische Ausbildung – z. B. als Industriekaufmann, Kaufmann für Spedition und Logistikdienstleistung oder eine vergleichbare Qualifikation

-

**Berufserfahrung:** Mehrjährige Praxiserfahrung im Export- und Zollwesen mit fundierten Kenntnissen im Zoll-, Präferenz- und Außenwirtschaftsrecht

-

**Führungserfahrung:** Mehrjährige Erfahrung in der fachlichen Führung von Mitarbeitenden – strukturiert, motivierend und mit Hands-on-Mentalität

-

**Gefahrgut:** Kenntnisse der Gefahrgutvorschriften (ADR, IATA, IMDG) wünschenswert

-

**Sprachkompetenz:** Verhandlungssicheres Deutsch sowie sehr gute Englischkenntnisse in Wort und Schrift

-

**Persönlichkeit:** Kommunikationsstark, verantwortungsbewusst und teamorientiert – mit einer strukturierten, pragmatischen Arbeitsweise

#### **Ihre Vorteile**

-

**Sicherer Arbeitsplatz:** Unbefristete Festanstellung in einem wirtschaftlich gesunden, wachsenden Familienunternehmen

-

**Flexibilität:** Mobile-Office-Möglichkeit sowie flexible Arbeitszeiten für eine gesunde Work-Life-Balance

-

**Mobilität:** MVV-Zuschuss sowie JobRad-Leasing

-

**Gesundheit:** Betriebliche Gesundheitsförderung sowie kostenfreies Obst im Arbeitsalltag

-

**Altersvorsorge:** Betriebliche Altersversorgung sowie Berufsunfähigkeitsversicherung als solider Baustein der finanziellen Absicherung

-

**Weiterbildung:** Individuelle Weiterbildungsangebote zur gezielten fachlichen und persönlichen Entwicklung

-

**Teamkultur:** Regelmäßige Mitarbeiterevents, ein familiäres Miteinander und ein Arbeitsumfeld, in dem Sie wirklich etwas bewegen können

#### **Kontakt**

Hypertrics GmbH
Schürmannstraße 22a
45136 Essen

####

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
