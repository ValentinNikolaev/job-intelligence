# Technical Delivery Manager - Munich

Posted: 2026-09-04T23:40:05Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

## About Us

Legora is redefining how legal work gets done. Not built for lawyers, built with them. We work alongside the world’s best legal teams, who expect excellence, precision, and speed, and we hold ourselves to the same bar.

Our AI-native workspace lets legal professionals move faster, think more clearly, and operate with sharper precision. By analysing thousands of documents in minutes and powering end-to-end workflows, we cut through complexity, teams can focus on what matters: judgment, strategy, and outcomes.

1,000+ customers across 50+ countries trust us, including Cleary Gottlieb, Goodwin, Linklaters, White & Case, Dentons, and Barclays. We’ve scaled to** $100M+ in ARR**, with teams across Europe, North America and APAC, and continue to expand through acquisitions including Qura, Walter AI and Graceview.

We partner with world-class performers: including Aaron Judge and the New York Yankees, Ludvig Åberg (and his caddie), and campaigns featuring Jude Law.

Joining Legora means three things.

-

We **lean in: **ownership over titles, outcomes over intentions.

-

We **fight for excellence:** high standards, direct, ego-free feedback.

-

We** grow together:** as a team and with our customers.

Mission before ego. Everyone contributes. No one coasts.

If you’re driven by impact, pace, and raising the bar. This is the place.

**The Role**

As a Technical Delivery Manager at Legora, you will play a central role in ensuring customers successfully deploy, integrate, and adopt our AI-native platform. You'll lead end-to-end technical implementations, act as the primary technical point of contact, and shape how seamlessly new customers go live and scale within Legora.

**What You'll Be Doing**

-

Lead integration projects from kickoff through go-live, owning technical documentation, test plans, and rollout execution to ensure on-time, high-quality delivery

-

Serve as the dedicated technical point of contact during implementation and early adoption, including proactive monitoring and regular stakeholder updates through go-live and the post-rollout period

-

Configure and support customer environments including SSO, DMS integrations (iManage, SharePoint, NetDocuments), and API-based connections

-

Provide dedicated post-rollout technical support for enterprise clients, troubleshooting advanced issues and driving high customer satisfaction

-

Coordinate across Sales, Engineering, and Customer Success to align on requirements and ensure a smooth rollout experience

-

Deliver technical training and guidance to customer teams on configuration, workflows, and best practices

-

Feed insights from delivery projects back to product and engineering to improve future implementations

**Who You Are**

-

Proven experience in technical delivery, implementation, or a similar customer-facing technical role

-

Strong hands-on experience with SSO, authentication protocols, and enterprise integrations (DMS platforms, APIs)

-

Excellent project management skills with a structured, proactive approach to managing multiple parallel projects

-

Able to translate technical concepts clearly for non-technical audiences

-

Strong communicator who builds trusted relationships across customer and internal teams

-

Comfortable working autonomously in a fast-paced, high-growth environment

-

French language proficiency is an advantage, though not a requirement for this role

**Legora is an Equal Opportunity Employer**

At Legora, we believe great teams are built on diversity of thought and experience. We’re proud to be an equal opportunity employer and committed to creating an inclusive, high-performance culture where everyone can do their best work. We welcome people of all backgrounds and don’t discriminate based on race, color, religion, national origin, gender, gender identity or expression, sexual orientation, age, disability, veteran status, or any other characteristic protected by law.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
