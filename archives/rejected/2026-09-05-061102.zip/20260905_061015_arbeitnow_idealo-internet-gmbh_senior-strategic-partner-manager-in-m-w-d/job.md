# (Senior) Strategic Partner Manager:in (m|w|d)

Posted: 2026-09-04T23:30:31Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

idealo arbeitet mit einem breiten Spektrum des E-Commerce-Marktes zusammen - von internationalen Plattformen und großen Onlinehändlern bis hin zu Affiliate-Netzwerken, Agenturen und Technologiepartnern.

Im Mittelpunkt dieser Rolle steht die strategische Betreuung und Weiterentwicklung relevanter Affiliate-Advertiser. Du entwickelst bestehendes Geschäft, erschließt neue Umsatz- und Wachstumspotenziale, auch über ergänzende Lösungen wie Retail Media, und gestaltest langfristig erfolgreiche Partnerschaften.

Ergänzend entwickelst Du die Zusammenarbeit mit Netzwerken, Agenturen und weiteren Multiplikatoren weiter, um zusätzliche Geschäftspotenziale zu erschließen.

### Deine Aufgaben

-

Du verantwortest und entwickelst Dein Account-Portfolio eigenständig und priorisierst Deine Aktivitäten nach wirtschaftlichem Potenzial und strategischer Relevanz.

-

Du baust langfristige Beziehungen zu Deinen Partnern auf, verstehst ihre Geschäftsmodelle und entwickelst daraus konkrete Wachstums-, Monetarisierungs- und Cross-Selling-Ansätze.

-

Du trägst Verantwortung für Umsatz und Profitabilität Deiner Accounts und führst Vertrags- und Konditionsverhandlungen eigenständig.

-

Du steuerst Deine Partnerschaften datenbasiert anhand relevanter KPIs wie GMV, Conversion Rate, CPO/CPC, Approval- und Stornoquote und leitest daraus Optimierungs-, Skalierungs- und Verhandlungsansätze ab.

-

Du identifizierst zusätzliche Potenziale, z. B. über Retail Media, Sortimentsentwicklung oder strategische Projekte, und setzt diese gemeinsam mit Partnern und internen Expert:innen um.

-

Du arbeitest eng mit Product, Tech, Operations, Analytics, Retail Media und weiteren Sales-Bereichen zusammen.

-

Ergänzend entwickelst Du Kooperationen mit Affiliate-Netzwerken, Agenturen und Technologiepartnern, um zusätzliche Advertiser und skalierbare Geschäftspotenziale zu erschließen.

### Das bringst du mit

-

Du übernimmst Verantwortung und treibst Themen eigenständig voran.

-

Du verfügst über mehrjährige relevante Erfahrung im Partner Management, (Key) Account Management oder beratungsorientierten Vertrieb und hast bereits eigenständig kommerziell relevante Accounts verantwortet.

-

Du bringst ein gutes Verständnis für E-Commerce und Performance Marketing mit und kannst Kennzahlen wie CPO, CPC, CVR, KUR, Umsatz und Marge sicher für kommerzielle Entscheidungen nutzen. Erfahrung mit Affiliate Marketing oder Retail Media ist ein Plus.

-

Du kannst anhand konkreter Beispiele zeigen, wie Du Partnerbeziehungen entwickelt und Umsatz, Profitabilität oder strategischen Mehrwert gesteigert hast.

-

Du verbindest ausgeprägtes Account Management mit analytischem und kommerziellem Denken und kannst Partner überzeugend für neue Lösungen gewinnen.

-

Du kommunizierst und verhandelst sicher auf Deutsch und Englisch und trittst souverän gegenüber unterschiedlichen Stakeholdern und Entscheidungsebenen auf.

-

Du arbeitest eigenverantwortlich, strukturiert und ergebnisorientiert und setzt auch bei mehreren Accounts und Projekten klare Prioritäten.

-

Erfahrung mit CRM-Systemen, insbesondere Salesforce, ist von Vorteil.

Du erfüllst nicht alle Kriterien? Keine Sorge, wir suchen Mitarbeiter:innen, die uns mit ihrer Persönlichkeit überzeugen und motiviert sind, gemeinsam mit ihrem Team alles zu geben!

### **Bei idealo erwartet dich**

-

**Du willst dich weiterbilden? **Wir nehmen deine persönlichen Entwicklungsziele ernst und bieten dir neben unserem idealo Learning Hub, eLearning Angeboten (z.B. Udemy), Coachings & Mediation auch die Möglichkeit individuell von unserem Weiterbildungsbudget zu profitieren.

-

**Und was kann das Büro? **Unser Büro, im Herzen Berlins, bietet neben dem “Standard-Kicker” auch hervorragendes kostenfreies Mittagessen, sowie kostenfreien Kaffee, Limonade und Feierabend-Bier. Dabei kannst du auf unserer wunderschönen Dachterrasse mit Kolleg:innen aus unserer Unternehmensgruppe netzwerken.

-

**Du wünschst dir Unterstützung auch außerhalb der Arbeit? **Eine kostenlose Beratung, sowie Unterstützung in allen Lebenslagen (beruflich, privat, familiär, gesundheitlich etc.) bieten wir in Zusammenarbeit mit dem [pme-Familienservice](https://mein.familienservice.de/).

-

**Du willst auch mobil sein?** Mit Job-Bike oder Deutschlandticket kein Problem – und das ist auch noch umweltfreundlich!

-

**Du möchtest dich fit halten? **Hierzu bieten wir dir viele unterschiedliche Fitness- und Sportmöglichkeiten wie zum Beispiel eine Urban Sports oder Gympass Mitgliedschaft für deine ganz persönlichen Bedürfnisse an.

-

**Und was gibt es noch? **Selbstverständlich müssen Erfolge gefeiert werden! Neben Team-Events erwarten dich auch große Company-Events, bei denen wir keine Kosten und Mühen scheuen.

#LI-MR1

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
