# Principal Thermal Solutions Engineer - Munich, Germany

Posted: 2026-09-05T02:40:02Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**About Vinci**

We are building **Physics AI for hardware design**. Our software platform helps hardware designers and physics simulation engineers explore, analyze, and optimize hardware systems, leveraging cutting-edge AI to deliver ultrafast, accurate physics intelligence within the realities of engineering design workflows.

Our first product bridges the gap between the accuracy & determinism of traditional simulation and the speed & scaling of AI, and is redefining how the world’s most advanced semiconductors are designed, verified, built, brought to market and integrated in complex systems.

**Role Overview**

As a pivotal leader within our E**uropean Forward Deployment team**, you will drive the **adoption of Vinci’s platform **among the region's top engineering organizations. In this strategic role, you will **build, mentor, and guide **a high-performing team of thermal engineers dedicated to engaging prospective customers and demonstrating the transformative value of our software.

By acting as** trusted technical advisors**, you and your team will utilize deep simulation expertise to help enterprise customers **validate and optimize complex, real-world designs**. Through these collaborative engagements, you will champion Vinci's value proposition—showcasing how our platform delivers systemic improvements in thermal performance, product reliability, and accelerated time-to-market.

Leveraging strong fundamentals in **thermal physics and cooling strategies, **you will guide analyses of complex thermal management systems, fluid flow dynamics, and heat dissipation challenges. This includes both steady-state and transient thermal behavior. Your team will help customers **evaluate critical factors such as thermal risk, component reliability, power density, and cooling efficiency to architect cutting-edge thermal management systems for next-generation hardware.**

You will work closely with **customer engineering teams** to understand their technical challenges, provide expert guidance, and clearly articulate Vinci’s capabilities in solving real-world problems. Additionally, you will serve as a **key feedback channel t**o product and engineering teams, translating customer insights into actionable inputs that shape product direction and drive continuous improvement.

This is a **remote role, **with close collaboration with Sales, Product, and Engineering in Palo Alto, CA, USA. The role includes **moderate travel**, primarily within continental Europe. Some **infrequent intercontinental travel **may be required for discussions and collaboration with the US team**.**.

**Responsibilities**

-

**Build, lead, and scale a high-performing team of thermal engineers**, setting the technical direction, hiring, mentoring team members, and driving field execution across Europe.

-

**Collaborate closely with the sales team** to lead technical discussions, scope proof-of-concept (PoC) evaluations, and deliver compelling product demonstrations to prospective enterprise customers.

-

**Guide customer engineering teams through the evaluation phase** by overseeing simulation setup, running complex test cases, and interpreting results to explicitly prove Vinci’s technical and business value.

-

**Own customer enablement through onboarding, deployment pipeline and account expansion**, providing senior technical guidance, structured training sessions, and advanced troubleshooting.

-

**Provide product guidance and feedback, identify customer pain points and workflow bottlenecks**, partnering directly with internal product and engineering teams to transform field feedback into critical new product features.

-

**Represent Vinci at major industry conferences and semiconductor events**, engaging technically with key prospects and partners through technical presentations and live platform demonstrations.

-

Maintain a strong understanding of **competitive technologies, industry trends, and market positioning** to communicate Vinci’s differentiators effectively.

**Qualifications (Minimum Qualifications)**

-

**Education:** Degree in Mechanical Engineering, Electrical Engineering, or a closely related technical field.

-

**Technical depth:** Expert-level mastery of commercial simulation software (Flotherm, Ansys Icepak/Fluent, Simcenter STAR-CCM+, or equivalent), with 15+ years of hands-on experience in thermal management and cooling solutions — either as a practitioner running simulations, or as a technical account manager for commercial physics simulation software.

-

**Industry Domain:** Deep familiarity with semiconductor electronics packaging, advanced packaging technologies (e.g., 2.5D/3D IC), or foundry ecosystems.

-

**Customer Engagement:** Prior experience in dedicated customer-facing roles, with a strong ability to build trust and manage engineering client relationships.

-

**Automation & Scripting:** Practical programming experience using Python or C++ to automate workflows or parse simulation data.

-

**Leadership Impact:** Proven track record of prior managerial or technical leadership experience, with the ability to scale, mentor, and drive execution across engineering teams.

-

**Communication:** Elite interpersonal and communication skills, with a proven ability to distill complex physics and simulation results into clear, high-impact narratives for both deep technical panels and business-oriented executives.

**Preferred (Desirable Differentiators)**

-

**Multiphysics Breadth:** Familiarity with structural mechanical simulations (FEA/stress) and/or Electrical Signal Integrity and Power Integrity (SI/PI) workflows.

-

**Commercial Track Record:** Direct experience commercializing technical software—ideally electronic design automation (EDA) or CAE simulation tools—into major semiconductor and electronics enterprises.

-

**Go-To-Market Experience:** Prior experience explicitly within technical pre-sales, application engineering (FAE), or strategic technical sales environments.

-

**Emerging Tech Adjacency:** Ability to rapidly adopt and champion next-generation, physics-based workflows and AI-assisted design or simulation tools.

**Why Join Us**

-

Not just use AI, Be part of a team that is actively redefining how the next-generation silicon and hardware are architected.

-

Work at the absolute convergence of state of the art AI models, fundamental physics, and high-stakes enterprise

-

Collaborate with world-class engineers and researchers in a fast-moving startup environment.

Compensation: €120K – €130K

- • €120K – €130K

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
