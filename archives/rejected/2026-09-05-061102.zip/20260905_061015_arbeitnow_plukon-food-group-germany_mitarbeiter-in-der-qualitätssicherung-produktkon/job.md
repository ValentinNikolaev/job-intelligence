# Mitarbeiter in der Qualitätssicherung / Produktkontrolle (m/w/d)

Posted: 2026-09-05T02:30:30Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Zur Verstärkung unseres Teams an unserem Standort in **Brenz **suchen wir zum nächstmöglichen Zeitpunkt einen **Mitarbeiter in der Qualitätssicherung / Produktkontrolle (m/w/d)**

## **Informationen über unseren Betrieb**

Bei der Plukon Brenz GmbH verarbeiten wir mit großer Leidenschaft und Präzision Geflügel zu verschiedensten Produkten. Vor allem Hähnchenprodukte liegen aktuell im Trend. Frisch oder auch tiefgekühlt liefern wir unsere angesagten Geflügelartikel an führende Partner sowohl im deutschen Lebensmittelhandel als auch im Foodservice-Bereich.

## **Deine Tätigkeiten: **

-

Unterstützung des Qualitätswesens bei der Umsetzung der Qualitätsziele und Qualitätspolitik im Unternehmen

-

Durchführung von Maßnahmen zur Fehlervermeidung im Unternehmen

-

Laufende Fertigungsprozesse sowie Zwischen- und Endprodukte im Hinblick auf vorgeschriebene Richtwerte überprüfen

-

Überwachung aller Abteilungen hinsichtlich der Einhaltung der Hygienerichtlinien

## **Diese Qualifikationen solltest Du mitbringen:**

-

Qualifikation im Bereich der Lebensmitteltechnik wünschenswert oder artverwandte Ausbildung oder vergleichbare Eignung

-

Erste Berufserfahrung in der Lebensmittelindustrie wünschenswert

-

Guter Umgang mit MS-Office Anwendungen

-

Bereitschaft zur Schichtarbeit

-

Teamfähigkeit, Zuverlässigkeit und Flexibilität

-

Hohes Verantwortungs- und Qualitätsbewusstsein

## **Das bieten wir:**

-

Wir bieten Dir einen spannenden und abwechslungsreichen Vollzeitjob (alternativ Teilzeit - muss von den HR Managern angegeben werden).

-

Bei uns erwartet Dich ein sicherer Arbeitsplatz in einem internationalen Umfeld mit flachen Hierarchien und vielen freundlichen Kolleginnen und Kollegen.

-

Firmenfitness (wir bezuschussen eine Fitnessstudio Mitgliedschaft im Rahmen des EGYM Wellpass-Verbundes).

## **Haben wir Dein Interesse geweckt?**

Wenn Du Lust auf neue Herausforderungen hast, freuen wir uns Dich kennenzulernen. Bewirb Dich einfach über unseren Bewerbungsbutton und das entsprechende Bewerbungsformular. Wenn Du noch Fragen zu dieser Stelle hast, kannst Du uns telefonisch oder per E-Mail kontaktieren. Du erhältst so schnell wie möglich eine Rückmeldung.

**Plukon Brenz GmbH
**Frau Doreen Klimt
HR | Personalabteilung
Am Brenzer Kanal 2, 19306 Brenz
Telefon: (038757) 515-0

[Stellenangebote – Arbeiten bei Plukon Deutschland](https://jobs.plukon.de/stellenangebote#/?city=Brenz&page=1)

Akquise im Zusammenhang mit dieser Stellenausschreibung ist nicht erwünscht.

## **Bei Plukon bist Du Teil eines führenden europäischen Foodkonzerns**

Bei Plukon beschäftigt zu sein, bedeutet, an der verantwortungsvollen Ernährung von 265 Mio. Verbraucherinnen und Verbrauchern in Europa mitzuarbeiten. Unser Sortiment reicht von Mahlzeitkomponenten bis hin zu Fertiggerichten und Salaten. Die Zutaten hierfür sind Geflügelfleischprodukte (unsere Basis), aber immer öfter auch Gemüse und alternative Proteine. So haben wir Angebote für Geflügelfans, genauso wie für Flexitarierinnen und Flexitarier sowie für Vegetarierinnen und Vegetarier. Unsere Produkte findet Ihr in ganz Deutschland im Kühlregal von Supermärkten und Schnellrestaurants.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
