# Senior Frontend Developer (all genders)

Posted: 2026-09-04T23:40:11Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Hi there! Thanks for stopping by 👋

Are you actively looking for a new opportunity? Or just checking the market? Well… you might just be in the right place!

We are looking for a **Senior Frontend Developer** to join one of our squads where you will be supporting Lightspeed’s Hospitality product group on the mission to expand our reach into new markets and countries while enhancing our advanced hospitality commerce platform.

You will be joining the team driving the Lightspeed L- and G-series products, which power hospitality businesses across Europe and help them deliver exceptional guest experiences. Our mission is to stay ahead of customer needs and evolving regulations, while at the same time modernizing our technology stack to ensure these products remain reliable, scalable, and future-ready.

You will join an international, independent and collaborative team, continuously improving our engineering practices, infrastructure and codebase, all while keeping it fun. Most importantly, your work will directly shape the daily experience of business owners and hospitality guests.

**What you'll be responsible for:**

-

Working alongside some of the most brilliant minds in the industry, you will contribute to the L&G series product by building new features and improving the developer experience.

-

Create and ship beautiful, elegant, and functional web applications

-

Report to the Development Manager and have frequent interactions with Product Managers, Product Designers, and Platform Teams.

-

Take part in daily agile ceremonies, brainstorm on innovative ideas that challenge the *status quo*, and implement solutions.

-

Act as an advocate for the highest code quality and ownership while contributing to the health of the infrastructure.

-

Raise the bar and elevate your team by sharing knowledge and best practices while always seeking improvement and progress.

Feel free to take a look at our Tech Stack [here](https://stackshare.io/lightspeed/hospitality).

**What you'll be bringing to the team: **

-

Strong knowledge of JavaScript (ES6+), TypeScript and CSS

-

Knowledge of React.js or similar technologies

-

Ability to quickly navigate across multiple codebases using diverse frontend technologies (jQuery, Angular, React, ..)

-

Solid understanding of cross-browser/platform issues and solutions

-

Familiarity with writing unit & e2e tests and ensuring the highest coding standards

-

Communication skills in English

-

A Bachelor Degree in Computer Science or a related field

**Even better if you have, but not necessary:**

-

Experience in the development of mobile-first applications

-

Familiarity with modern cloud infrastructures and monitoring

-

A keen eye for UI/UX design

**Who you are:**

-

We look for problem solvers that do not shy away from tackling complexity and love critical thinkers

-

You have a strong will to learn, grow and get out of your comfort zone

-

You have great energy and passion for technology

**What’s in it for you**

Come live the Lightspeed experience...

-

Ability to do your job in a truly flexible environment;

-

Genuine career opportunities in a company that’s creating new jobs every day;

-

Work in a team big enough for growth but lean enough to make a real impact.

… and enjoy a range of benefits that’ll keep you happy and healthy:

-

Lightspeed share scheme (we are all owners)

-

Flexible working policy and unlimited paid time off (yes, you read that right)

-

Mental health online platform and counselling & coaching services

-

​​Health and wellness benefit

-

LinkedIn Learning license (learning is always ongoing)

-

Volunteer day to be able to give back to society!

*To all recruitment agencies: Lightspeed does not accept unsolicited agency resumes. If we have not directly engaged your company in writing to supply candidates for a specific vacancy, Lightspeed will not be responsible for any fees related to unsolicited resumes.*

*Lightspeed is a proud equal opportunity employer and we are committed to creating an inclusive and barrier-free workplace. Lightspeed welcomes and encourages applications from people with disabilities. Accommodations are available on request for candidates taking part in all aspects of the selection process.*

## **Where to from here?**

Obviously, this has to be mutually beneficial: we want you to step into a role you love, and we want to offer you a place you’re proud to come to every day. For a glimpse into our world check out our [career page here](https://www.lightspeedhq.com/careers/).

Lightspeed is building communities through commerce, and we need people from all backgrounds and lived experiences to do that. We were founded in 2005, in Montreal’s gay village and our original members were all part of the LGBTQ+ community. The ethos of our business has been about inclusion from the very beginning, and we strive to provide a workplace where everyone belongs.

## **Who we are:**

Powering the businesses that are the backbone of the global economy, Lightspeed's one-stop commerce platform helps merchants innovate to simplify, scale, and provide exceptional customer experiences. Our cloud commerce solution transforms and unifies online and physical operations, multichannel sales, expansion to new locations, global payments, financial solutions, and connection to supplier networks.

Founded in Montréal, Canada in 2005, Lightspeed is dual-listed on the New York Stock Exchange (NYSE: LSPD) and Toronto Stock Exchange (TSX: LSPD). With teams across North America, Europe, and Asia Pacific, the company serves retail, hospitality, and golf businesses in over 100 countries.

Lightspeed handles your information in accordance with our [Applicant Privacy Statement](https://www.lightspeedhq.com/legal/applicant-privacy-statement/).

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
