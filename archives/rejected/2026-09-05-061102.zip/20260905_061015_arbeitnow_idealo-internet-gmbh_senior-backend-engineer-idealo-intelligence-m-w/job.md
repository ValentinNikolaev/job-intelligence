# (Senior) Backend Engineer - idealo Intelligence (m|w|d)

Posted: 2026-09-04T23:30:31Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Als **(Senior) Backend Engineer** im **idealo Intelligence** Team entwickelst du die technische Grundlage, um unsere Nutzer besser zu verstehen und unseren Händlern datenbasierte Marketinglösungen bereitzustellen. Gemeinsam mit einem neu entstehenden Team baust du eine moderne Datenplattform auf und gestaltest Architektur, Systeme und Prozesse von Anfang an aktiv mit.

Die Position ist in Voll- oder Teilzeit verfügbar.

### Deine Aufgaben

-

Du entwickelst und betreibst Backend-Services sowie Data Workflows für die Verarbeitung, Anonymisierung und Anreicherung großer Datenmengen.

-

Du übernimmst Verantwortung für den gesamten Lifecycle deiner Services – von Architektur und Implementierung bis zum Betrieb in Produktion.

-

Du entwickelst Java- und Spring-Boot-Microservices und arbeitest mit eventgetriebenen Architekturen sowie cloud-nativen Technologien auf AWS.

-

Du sorgst durch automatisierte Tests, Code Reviews und Observability für eine hohe Softwarequalität.

-

Du nutzt AI-gestützte Entwicklungstools sinnvoll, um Produktivität und Codequalität zu verbessern.

-

Du arbeitest eng mit Product- und Engineering-Teams zusammen und teilst dein Wissen durch Pair Programming, Reviews und Dokumentation.

### Das bringst du mit

**Must-have**

-

Mehrjährige Erfahrung in der Backend- oder Plattformentwicklung mit Java.

-

Erfahrung mit Spring Boot oder vergleichbaren Frameworks.

-

Erfahrung mit Cloud-nativen Anwendungen und containerisierten Deployments (z. B. AWS, Kubernetes oder Docker).

-

Erfahrung mit eventgetriebenen Architekturen, beispielsweise Kafka.

-

Erfahrung mit PostgreSQL, MongoDB oder Redis.

-

Du hinterfragst Annahmen respektvoll und nutzt Daten sowie nachvollziehbare Argumente, um Ideen zu diskutieren. Sobald eine Entscheidung getroffen wurde, unterstützt du sie verbindlich, um Alignment und Momentum im Team sicherzustellen.

-

Gute Englischkenntnisse.

**Nice to have**

-

Erfahrung mit Datenpipelines, PySpark oder Apache Airflow.

-

Erfahrung im Betrieb produktiver Systeme.

-

Deutschkenntnisse.

Du erfüllst nicht alle Kriterien? Keine Sorge, wir suchen Mitarbeiter:innen, die uns mit ihrer Persönlichkeit überzeugen und motiviert sind, gemeinsam mit ihrem Team alles zu geben!

### **Bei idealo erwartet dich**

-

**Du willst dich weiterbilden? **Wir nehmen deine persönlichen Entwicklungsziele ernst und bieten dir neben unserem idealo Learning Hub, eLearning Angeboten (z.B. Udemy), Coachings & Mediation auch die Möglichkeit individuell von unserem Weiterbildungsbudget zu profitieren.

-

**Und was kann das Büro? **Unser Büro, im Herzen Berlins, bietet neben dem “Standard-Kicker” auch hervorragendes kostenfreies Mittagessen, sowie kostenfreien Kaffee, Limonade und Feierabend-Bier. Dabei kannst du auf unserer wunderschönen Dachterrasse mit Kolleg:innen aus unserer Unternehmensgruppe netzwerken.

-

**Du wünschst dir Unterstützung auch außerhalb der Arbeit? **Eine kostenlose Beratung, sowie Unterstützung in allen Lebenslagen (beruflich, privat, familiär, gesundheitlich etc.) bieten wir in Zusammenarbeit mit dem [pme-Familienservice](https://mein.familienservice.de/).

-

**Du willst auch mobil sein?** Mit Job-Bike oder Deutschlandticket kein Problem – und das ist auch noch umweltfreundlich!

-

**Du möchtest dich fit halten? **Hierzu bieten wir dir viele unterschiedliche Fitness- und Sportmöglichkeiten wie zum Beispiel eine Urban Sports oder Gympass Mitgliedschaft für deine ganz persönlichen Bedürfnisse an.

-

**Und was gibt es noch? **Selbstverständlich müssen Erfolge gefeiert werden! Neben Team-Events erwarten dich auch große Company-Events, bei denen wir keine Kosten und Mühen scheuen.

#LI-MW

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
