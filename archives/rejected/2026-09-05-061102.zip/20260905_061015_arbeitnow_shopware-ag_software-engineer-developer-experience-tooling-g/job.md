# Software Engineer – Developer Experience / Tooling (Golang/PHP) (m/w/d)

Posted: 2026-09-05T02:30:18Z

## Rejection

- Category: language_requirement
- Reason: hard German language requirement without English green light

Shopware ist eine international führende Open‑Commerce‑Plattform für ambitionierte Unternehmen im digitalen Handel. Mit einem API‑First‑Ansatz, maximaler Flexibilität und einer starken Community schaffen wir zukunftsorientierte E‑Commerce‑Lösungen. Unsere 450 Mitarbeitenden in ganz Europa teilen eine Leidenschaft für Innovation, Offenheit und Teamgeist.

**In dieser Rolle arbeitest du an Tools wie der [shopware-cli](http://github.com/shopware/shopware-cli),** die viele Entwickler täglich nutzen, um Shopware zu entwickeln, zu testen, bereitzustellen und zu betreiben. Diese Tools sind das Eingangstor zu unserem Open-Source-Ökosystem – und ihre Developer Experience prägt unmittelbar, wie Entwickler Shopware wahrnehmen.

Du hast klare Vorstellungen davon, wie sich eine gute CLI verhalten sollte? Du hast schon mit gh oder anderen CLI-Tools gearbeitet, die deinen Alltag deutlich einfacher gemacht haben, und dir dabei gedacht: „Genau so sollte sich das anfühlen“? Dann könnte diese Rolle genau das Richtige für dich sein. Als **Software Engineer im Developer Experience (DX) Tooling Team** arbeitest du an den Tools und technischen Grundlagen, mit denen Entwickler Shopware entwickeln, erweitern, testen und betreiben. Mit deinen Beiträgen gestaltest du unmittelbar mit, wie angenehm, effizient und zuverlässig die Entwicklung auf unserer Plattform ist.

Diese Position kann **vor Ort, hybrid oder vollständig remote** innerhalb Deutschlands oder in bestimmten europäischen Ländern, in denen wir registriert sind, besetzt werden. Dein **Arbeitsort** wird im Voraus abgestimmt und bildet die Grundlage deines **Arbeitsvertrags**.

-

**Du gestaltest Developer Workflows ganzheitlich** – vom lokalen Setup über CI/CD und Deployment bis hin zum laufenden Betrieb. Dabei beschäftigst du dich unter anderem mit Containerisierung, Cloud-Native-Praktiken, GitOps und Telemetrie, mit der wir überprüfen können, ob das, was wir entwickeln, auch tatsächlich funktioniert. Zunehmend bedeutet das auch, Tools so zu entwickeln, dass sie nicht nur für Menschen im Terminal, sondern ebenso für AI Agents und CI-Pipelines geeignet sind. Gleichzeitig nutzen wir selbst AI-Tools, um unsere Lösungen schneller und effizienter zu entwickeln und zu warten.

-

**Du entwickelst die Grundlagen unseres Open-Source-Ökosystems weiter** – von der CLI über APIs bis hin zu den Tools und Integrationen, die sie umgeben.

-

**Du setzt hohe Standards für Codequalität.** Gut getestet, sauber strukturiert und so entwickelt, dass der Code langfristig wartbar ist – nicht nur schnell ausgeliefert. Dazu gehören für uns auch klare Konventionen und Tooling, die dafür sorgen, dass diese Standards mit wachsendem Team und Codebestand erhalten bleiben.

-

**Du bringst dich aktiv in unsere Open-Source-Community ein.** Du reviewst Contributions, verbesserst Dokumentationen und stehst im Austausch mit den Entwickler, die deine Tools täglich nutzen.

-

**Du verbindest Teams und Perspektiven.** Du arbeitest eng mit unseren Core-, SaaS/PaaS-, Documentation- und Community-Teams zusammen, damit unser Tooling die tatsächlichen Bedürfnisse unserer Developer Community widerspiegelt.

### Das bringst du mit:

-

**Erfahrung mit Go ist ideal.** Eines der Tools, auf das wir aktuell einen besonderen Fokus legen, basiert auf Go. Du musst kein Go-Experte bzw. keine Go-Expertin sein – wichtiger sind deine Motivation und deine Fähigkeit, dich schnell in neue Technologien einzuarbeiten.

-

**PHP-Kenntnisse, idealerweise mit Symfony, sind ein starkes Plus.** Teile unseres Toolings, beispielsweise Deployment-Helfer, basieren direkt auf PHP. Gleichzeitig hilft dir dieses Wissen dabei, das Shopware-Ökosystem, für das unsere CLI entwickelt wird, noch besser zu verstehen.

-

**Du begeisterst dich wirklich für Developer Tools und hast Empathie für die Menschen, die sie verwenden.** Vielleicht hast du bereits an Projekten mit klarem DX-Fokus gearbeitet, eigene Side Projects entwickelt, zu CLIs oder Developer Tooling beigetragen – Open Source oder anderweitig – oder du bist einfach die Person im Team, die ein Issue erstellt, wenn ein Workflow unnötig umständlich ist.

-

**Du hast praktische Erfahrung darin, Developer Experience zu verbessern**, beispielsweise durch CLI-Tooling, Automatisierung, APIs, Scaffolding oder die Optimierung von Entwicklungsworkflows.

-

**Automatisierte Tests und CI-Workflows gehören für dich zum Engineering-Alltag.** Du hast ein gutes Gespür dafür, wie sich Tools nahtlos in bestehende Developer-Ökosysteme integrieren lassen.

-

**Du nutzt AI-gestützte Entwicklungsworkflows aktiv**, zum Beispiel beim Coding, bei Dokumentation oder Automatisierung. Gleichzeitig setzt du dich kritisch damit auseinander, wo AI Engineering tatsächlich effizienter macht – und wo nicht. Begriffe wie MCP oder AI Skills sind dir nicht fremd.

-

**Du arbeitest gerne offen und transparent.** Dein Code, deine Pull Requests und technische Entscheidungen sind für eine öffentliche Community sichtbar – und du fühlst dich mit dieser Transparenz wohl.

-

**Du kommunizierst klar und verbindlich**, insbesondere in der asynchronen Zusammenarbeit, und kannst sowohl mit internen Stakeholdern als auch mit externen Contributor erfolgreich zusammenarbeiten.

-

**Du verfügst über ausgezeichnete Englischkenntnisse** in Wort und Schrift. Deutschkenntnisse sind ein Plus, aber keine Voraussetzung.

**Bevor du dich bewirbst: **Nimm dir vor deiner Bewerbung etwa zehn Minuten Zeit: Installiere unsere shopware-cli, probiere einige Commands aus und wirf einen Blick in das [Repository](https://github.com/shopware/shopware-cli). Im Bewerbungsprozess werden wir dich fragen, **was du daran verändern würdest – und warum**.

Es lohnt sich also, dir schon vorher ein paar Gedanken dazu zu machen.

### Das bieten wir dir:

-

**Unternehmenskultur:** Offene Kultur, flache Hierarchien, Eigeninitiative wird gefördert.

-

**Arbeitsverträge:** Unbefristete Anstellungen bieten langfristige Sicherheit.

-

**Flexibilität:** Flexible Arbeitszeiten und Optionen für mobiles Arbeiten und Full-Remote-Verträge.

-

**Ausstattung:** Freie Wahl der Arbeits-Hardware.

-

**Onboarding:** Gut strukturiertes Onboarding mit Unterstützung durch einen persönlichen "Buddy".

-

**Arbeitsumfeld:** Inspirierendes Umfeld mit engagierten Kollegen und einer dynamischen Gemeinschaft.

-

**Entwicklungsmöglichkeiten:** Vielfältige Chancen für persönliches Wachstum und Entwicklung.

-

**Zusatzleistungen:** Attraktive Benefits wie betriebliche Altersvorsorge, Gesundheitsprogramme und regelmäßige Teamevents.

... und vieles mehr!
Einen detaillierten Einblick bekommst du auf unserer [Karriereseite](https://careers.shopware.com/de/warum-shopware/bei-shopware-arbeiten/).

**Deine Ansprechperson für diese Stelle ist Josephine Scheffler und steht dir bei Fragen gerne zur Verfügung!**

Der Schutz deiner persönlichen Daten hat für uns oberste Priorität. Unsere Bewerberinformationen findest du [hier](https://www.shopware.com/de/datenschutz/bewerbende/).

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
