# (Senior) Account Manager

Posted: 2026-09-04T23:40:11Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

*No previous experience in the sustainability space? Don't worry, we are happy to help you grow into an expert and thought leader at Root! This role requires presence in our Berlin office and both German and English language skills.*

## 🌎 What we do

## **We build software that helps companies along the food system get to Net Zero.**

~31% of global GHG emissions originate from food-related activities. For the first time in history, climate performance has become an overall business performance indicator. Enterprises are mandated by regulatory bodies to disclose their climate performance, which leads to increasing pressure from investors, competitors, retailers, and consumers to *prevent and reduce* their CO2e emissions. Over the next 10 years, companies have set ambitious reduction targets that need to be met. Enterprise software and new business processes can help.

We raised >€10m in funding, we launched our enterprise product, signed and onboarded some of the largest F&B players in Europe, and put together what we believe is the best-suited early stage tech team in Europe. Will you be the next to join us? 🚀

## 🔭 What you will work on

### **Your mission**Drive customer success as a trusted advisor and account manager for our enterprise customers. Own a portfolio end-to-end from onboarding and tool adoption through retention and ARR growth, co-developing new value propositions and building the trust-based relationships that turn customers into advocates.

### ***Over the next 12 months you will:***

-

**Grow annual contract values of existing enterprise customers**

-

Translate our impact into tangible business value for economic buyers.

-

Lead renewal negotiations and drive upsell opportunities with existing customers.

-

Expand our reach within global enterprises across new regions, teams, and decision-makers.

-

**Support customers' progress along their climate journey**

-

Build and nurture strong relationships with clients as their trusted climate advisor and single point of contact, coordinating internal expertise to deliver clear, actionable guidance on sustainability topics

-

Represent the customer voice and needs internally to provide input for product development.

-

Educate users and guide them toward measurable progress on their Net Zero journey.

-

**Boost farm-level data collection via the RootOS platform**

-

Onboard sustainability managers, farm technicians, and farmers to the platform and guide their data collection efforts.

-

Ensure high data integrity, partner with trusted farm-level data sources, and meet data coverage targets.

-

Collect, consolidate, and prioritize product feedback.

-

**Drive on-farm emissions reduction**

-

Analyze CO₂ emission patterns across farms, identify opportunities for reduction, and present actionable insights to our customers

-

Support sustainability teams and farm technicians (Erzeugerberater) in effectively communicating these measures to farmers.

## 🚀 You might be really good for this role if you

-

Have 3+ years of experience in customer-facing roles (ideally B2B SaaS, consulting, or startup/scale-up environments) where you built and nurtured strong client relationships end-to-end

-

Are hands-on, reliable, and detail-oriented. You thrive in fast-changing, early-stage environments, juggle multiple priorities, and ensure nothing falls through the cracks

-

Are people-centric and proactive. Empathetic, approachable, and able to communicate clearly while keeping customer outcomes and business priorities aligned

-

Speak excellent German (C2) and English (C1+)

You don't feel like you fulfill all the criteria? We get it: confidence can sometimes hold us back from applying for a job. But guess what?! There is no such thing as a 'perfect' candidate. The only thing you need to ensure along the recruiting process and beyond is that the problem that we are solving with Root is one you cannot wait to get out of bed for on Monday morning! 🤗

## 🦾 How we support you

-

You will work closely with *Alina*, our Account Management leader.

-

You will collaborate as part of a cross-disciplinary team that brings together sales and account managers, product experts and customer success specialists

-

We believe in the power of technology. We use best-in-class tools, software and AI solutions (Hubspot, Gong, Claude, Slack, Google Workspace, Notion)

## 🎢 Hiring Process

Our ambition is to offer you an end-to-end experience that is fast and uncomplicated - **we aim to keep the end-to-end process to 10 working days**. We send you prep material for each step and maximise transparency at every step.

*Root Global is an equal opportunity employer, which means we do not discriminate on the basis of race, colour, religion, marital status, age, national origin, ancestry, physical or mental disability, medical condition, pregnancy, genetic information, gender, sexual orientation, gender identity or expression. We celebrate diversity and are committed to creating an inclusive environment for all employees.*

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
