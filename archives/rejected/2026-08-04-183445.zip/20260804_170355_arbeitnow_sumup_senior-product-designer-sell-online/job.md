# Senior Product Designer - Sell Online

Posted: 2026-08-04T14:55:36Z

## Rejection

- Category: tech_stack
- Reason: role does not mention Go/Golang or PHP

# Senior Product Designer – Sell Online

## About the team

The Sell Online team builds the products that help small business owners run and grow their businesses online — from appointment bookings and online stores to customer management. We're a cross-functional design team embedded across multiple product squads, working closely with product managers and engineers to shape experiences used by millions of merchants worldwide. As we expand our portfolio and grow our engineering capacity, we're looking for a Senior Product Designer who can bring strong visual craft, product thinking, and the confidence to own complex design challenges across several product areas simultaneously.

🎥 Get a feel for our Berlin office: [Take a look](https://www.youtube.com/watch?v=9DG64C3moeQ)

## What you'll do

- Own end-to-end design across our Bookings and Online Store products — from early-stage concepts and user flows through to polished, high-fidelity UI ready for development

- Craft visually compelling interfaces, including iconography and illustrations, that raise the bar for quality and consistency across the portfolio

- Work across multiple squads simultaneously, collaborating closely with product managers, engineers and other designers to keep design and delivery in sync

- Contribute to and evolve our design system, ensuring consistency and scalability as the product portfolio grows

- Use qualitative research and user data to inform design decisions and validate solutions — bringing a user-centred lens to everything you ship

## You'll be great for this role if…

- You have a strong portfolio demonstrating end-to-end product design — from wireframes and user flows to high-fidelity UI — with a clear emphasis on visual craft, typography, and layout

- You have experience designing for customer-facing products on both web and mobile, ideally in e-commerce, bookings, or similar consumer contexts

- You have proven ability to work with and contribute to design systems at scale

- You are comfortable with managing multiple workstreams and stakeholders across different product areas at the same time

- You have a collaborative, curious mindset — someone who listens well, adapts quickly, and can navigate ambiguity without losing momentum

## Why you should join SumUp

🌎 Opportunity to work with SumUppers globally on large-scale fintech products used by millions of businesses worldwide, from our Berlin office. This involves an office-first setup
🌈 Commitment to Diversity and Inclusion: be part of a workplace that values and promotes diversity, fostering an inclusive environment where everyone's perspectives are respected and embraced
🚀 Enrolment onto our Virtual Stock Option programme: you will own a stake in SumUp's future success
📚 A dedicated annual L&D budget of €2000 for your individual development, which can be used to attend conferences and/or advance your career through further education
💶 A corporate pension scheme where we match up to 20% of your contributions
🏖 Generous time off: enjoy 28 days of paid leave plus public holidays and special leave days
🏋️ Numerous other benefits such as Urban Sports Club subsidy, Kita placement assistance, subsidised office lunches
🌴 Break4me: 1-month sabbatical after 3 years of service
🔗 Referral Bonus: earn additional rewards by referring talented individuals to join the SumUp team

## About SumUp

Be empowered to do more that matters.

At SumUp, we're on a mission to empower small businesses across the globe by providing simple and affordable tools that allow them to thrive. Today, over 4 million businesses in 37 markets rely on SumUp as their financial partner to manage payments, finance and customer relationships.

Our commitment to small businesses is reflected in [our diverse team](https://youtu.be/9DG64C3moeQ?si=YpcWuBNBTOQPzeLI) of over 3,000 SumUppers from over 90 nationalities, united by global collaboration and an innovative mindset. [Our core values](https://www.sumup.com/careers/culture/) lay the foundation for who we are and what we stand for, shaping our work culture and driving our success. We foster inclusivity and a continuous learning culture, providing a safe space for personal and professional growth. Our differences make us unique and strong as we strive to create an environment where everyone belongs and feels supported, no matter how they identify.

SumUp is proud to be an Equal Employment Opportunity employer, actively seeking and embracing diversity in our workforce. We don't make hiring or employment decisions based on race, colour, religion or religious belief, ethnic or national origin, nationality, sex, gender, gender identity, sexual orientation, disability, age or any other basis protected by applicable laws or prohibited by company policy. Our commitment extends beyond recruitment to creating a safe and respectful workplace where harassment of any form is strictly prohibited.

Discover more about our culture and opportunities on our [careers website](https://www.sumup.com/careers/), and follow our journey on [LinkedIn](https://www.linkedin.com/company/sumup/), [Instagram](https://www.instagram.com/insidesumup/), and

**Job Application Tip**

We recognise that candidates feel they need to meet 100% of the job criteria in order to apply for a job. Please note that this is only a guide. If you don’t tick every box, it’s ok too because it means you have room to learn and develop your career at SumUp.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
