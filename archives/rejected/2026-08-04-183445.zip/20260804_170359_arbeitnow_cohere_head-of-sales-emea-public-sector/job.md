# Head of Sales EMEA, Public Sector

Posted: 2026-08-04T14:40:13Z

## Rejection

- Category: language_requirement
- Reason: hard German language requirement without English green light

**Who are we?**

Cohere is the leading security-first enterprise AI company. We build cutting-edge foundation AI models and end-to-end products that are designed to solve real-world business problems.

We’re training and deploying frontier models for enterprises who are building AI systems. We believe that our work is instrumental to the widespread adoption of AI and we are looking for folks that want to be part of that.

We obsess over what we build. Each one of us is responsible for contributing to increasing the capabilities of our models and the value they drive for our customers. Cohere is a team of researchers, engineers, designers, and more, who are all passionate about their craft.

We are a global technology company co-headquartered in Toronto and San Francisco, with key offices in London, New York City, Montreal, Seoul, Germany and Paris. Join us!

**Head of EMEA Public Sector (Germany)**

**Why this role?**

As our Head of Sales EMEA Public Sector you will spearhead year-over-year revenue growth by developing and executing on enterprise level PUBSEC customer acquisition strategies across the region. You will drive long-term success through strategic development, coaching, and expanding Cohere’s presence in EMEA public sector, anchored in Defense. In this pivotal leadership role, you will cultivate and guide our EMEA PUBSEC sales team to exceed revenue targets and organizational goals, while fostering a culture of excellence and innovation.

Candidates must be based in Germany to be considered for this career opportunity.

As our Head of EMEA PUBSEC you will:

-

Develop, execute, and lead a comprehensive go-to-market growth strategy and sales plan for EMEA PUBSEC, driving revenue growth and market expansion working with the North American Public Sector and other regional sales teams.

-

Provide sales and operational leadership to Cohere’s EMEA PUBSEC sales team, ensuring alignment with company objectives and priorities.

-

Partner with Marketing, Product, and Engineering teams to synchronize sales efforts with broader company goals.

-

Represent Cohere at EMEA PUBSEC industry events, conferences, and networking opportunities, as well as with regulators and government agencies, in collaboration with other regional and global leaders in Cohere.

-

Manage and nurture relationships with government decision-makers and partners to ensure Cohere’s success in the region. Identify and pursue new business opportunities, negotiating and closing high-value deals.

-

Collaborate with global teams to strengthen anchor relationships and establish best practices for enterprise-level project implementations, ensuring strong client engagement throughout project lifecycles.

This career opportunity may be a good match for you if you:

-

Have 10+ years of PUBSEC sales and leadership experience leading go-to-market efforts and driving revenue growth for fast paced technology organizations.

-

Have an established network in Germany and EMEA region, including federal agencies, prime contractors, and industry associations.

-

Possess a proven track record of leading capture and sales efforts for consultative solution sales and business development efforts, with a deep understanding of regional procurement and budget cycles, customer success, and resource allocation.

-

Have exceptional communication and leadership skills, with the ability to build cross-functional relationships and influence at all levels.

-

Are comfortable operating in a matrix environment, coordinating efforts across cross-functional teams and regions without the need for a large direct organization.

-

Are a self-starter with an entrepreneurial mindset, capable of working independently, rolling up sleeves, and driving impact as a ‘builder.’

-

Experience in AI or a related industry is highly desirable.

-

English and German language skills are essential.

-

Must be based in Germany with willingness to travel (25-35%).

## **Full-Time Employees at Cohere enjoy these Perks:**

-

A weekly lunch stipend of $75/£75 or equivalent in your local currency for lunch.

-

Full health and dental benefits, including a separate budget for mental health.

-

RRSP matching, 401K, Pension Scheme.

-

100% Parental Leave top-up for up to 6 months, for either parent.

-

Annual enrichment benefits:

Arts & culture, fitness/wellness, quality time, and a workspace improvement credit.

Education & learning stipend for conferences, courses, and coaching.

-

6 weeks of paid vacation (30 working days!)

-

Budget for traveling to other offices if you are remote, plus an annual company offsite.

## **How and Where We Work:**

-

Cohere is remote-friendly. We have offices in Toronto, San Francisco, New York City, London, Paris, Montreal, and more coming soon.

-

For those in the office: a daily lunch program, plenty of snacks, and regular community and social events.

-

For those not near an office: a co-working benefit so you can work alongside others in your city.

-

Everyone receives a $500 home office stipend to set up your workspace properly.

If any of the above doesn’t line up exactly with your experience, we still encourage you to apply.

We strive to create an inclusive work environment for all; we welcome applicants from all backgrounds and are committed to providing equal opportunities. Should you require any accommodations during the recruitment process, please submit an[ Accommodations Request Form](https://docs.google.com/forms/d/12a6IrLdF3kI2nonKSr4tiFuz18rLQbaeYV-JM9L4o9Q/edit), and we will work together to meet your needs.

We may use AI-enabled tools to screen and assess applicants against the criteria for this position. This helps our recruiters identify potentially qualified candidates, but it doesn't limit the applications our recruiters may review or consider.

*Beware of Scams: Cohere will never ask for payment or third-party services (e.g., CV writing) as part of our hiring process. All legitimate roles are listed on the Cohere careers page and LinkedIn only, with all communications from Cohere employees coming from an ----- or ----- email alias. If jobs are viewed on other sites then please verify these through our *[*official careers*](https://cohere.com/careers)* page.*

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
