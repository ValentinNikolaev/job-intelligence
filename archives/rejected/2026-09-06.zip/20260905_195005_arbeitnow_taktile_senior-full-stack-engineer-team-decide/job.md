# Senior Full-Stack Engineer - Team Decide

Posted: 2026-09-05T11:40:08Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

## **About the Role**

Taktile empowers financial institutions to transform into truly AI-native organizations. We’re growing rapidly with enterprise customers across banks and insurance companies, and we’re looking for a a Senior Full-stack Engineer to join our engineering team. In Team Decide you'll focus on designing the distributed execution engine that runs customer workflows. You'll own critical systems end-to-end on a team where your decisions shape the product.

## **What You'll Do**

-

Build and operate backend services in Python on AWS — Lambda functions, DynamoDB, Aurora, and event-driven pipelines that handle real production traffic. You'll leverage agentic AI tools as part of your daily workflow.

-

Work on exciting AI initiatives such as MCP servers, agentic co-pilot

-

Tackle hard backend problems — latency, reliability, and scalability are everyday concerns.

-

Own your systems end-to-end: from architecture and implementation to deployment, monitoring, and incident response.

-

Make key architectural decisions — you'll have real authority over how things are built, not just what gets built.

-

Raise the bar for the team through code reviews, mentoring, and improving our development tooling and processes.

-

Work directly with Product and Design to shape what we build next.

## **Requirements**

-

At least 5 years of professional full-stack software engineering experience, with a proven track record of leading complex projects in a senior capacity (2+ years).

-

Deep expertise in React

-

Experience working with Design Systems to ensure a consistent UX among different parts of the product

-

Strong communication and collaboration skills, with the ability to align technical and non-technical stakeholders on a shared vision.

-

The ability to work in a hybrid model from our Berlin HQ, the London office, or the Iasi hub. Please note that relocation assistance is not provided for this role.

## **Ideal, But Not Required**

-

Strong system design skills — you're comfortable making architectural trade-offs and defending them

-

AWS Serverless experience at scale (Lambda, SAM, CloudFormation, DynamoDB, Aurora…)

## **Our Offer**

-

Work with colleagues that lift you up, challenge you, celebrate you and help you grow. We come from many different backgrounds, but what we have in common is the desire to operate at the very top of our fields. If you are similarly capable, caring, and driven, you'll find yourself at home here.

-

Experience a truly flat hierarchy and communicate directly with founding team members. Having an opinion and voicing your ideas is not only welcome but encouraged, especially when they challenge the status quo.

-

Learn from experienced mentors and achieve tremendous personal and professional growth. Get to know and leverage our network of leading tech investors and advisors around the globe.

-

Receive a top-of-market equity and cash compensation package.

-

Get access to a self-development budget you can use to e.g. attend conferences, buy books or take classes.

-

Receive a new Apple MacBook Pro, as well as meaningful home office set-up.

## **Our Stance**

-

We're eager to meet talented and driven candidates regardless of whether they tick all the boxes. We're looking for someone who will add to our culture, not just fit within it. We strongly encourage individuals from groups traditionally underestimated and underrepresented in tech to apply.

-

We seek to actively recognize and combat racism, sexism, ableism and ageism. We embrace and support all gender identities and expressions, and celebrate love in its many forms. We won't inquire about how you identify or if you've experienced discrimination, but if you want to tell your story, we are all ears.

## **About Us**

Taktile enables financial institutions to transform into AI-native organizations that are increasingly powered by autonomous agents.

With our modular Agentic Decision Platform, customers combine AI agents, rules, relevant context, and human oversight to safely automate and optimize their decisions—approving more customers, reimbursing claims instantly, stopping fraud before it spreads, and financing every business worth funding.

Founded in 2020, Taktile powers millions of decisions daily for institutions including Mercury, Monzo, Faire, and Pleo.

With offices in New York, Berlin, London, São Paulo, and Iași, the company has raised $184M from Growth Equity at Goldman Sachs Alternatives, Index Ventures, Tiger Global, Balderton Capital, and Y Combinator. Learn more at [taktile.com](http://taktile.com).

***About Your Employment**. Taktile operates through regional entities worldwide. Depending on the location of this role, your employment or engagement will be with Taktile LLC (US), Taktile GmbH (Germany), Taktile Ltd (UK), or Taktile SRL (Romania). The applicable entity will be confirmed during the offer process.*

***Your Privacy**. Taktile (“we” or “us”) is the controller of the personal data you provide during this application process. We collect and process your name, contact details, resume/CV, work history, education, and any other information you submit or that we obtain from publicly available sources or references.*

***How we use your data:** We process your personal data to evaluate your candidacy, communicate with you about the recruitment process, comply with legal obligations (such as right-to-work verification), and, with your consent, to consider you for future opportunities.*

***Legal basis (EU/UK applicants):** We rely on (i) pre-contractual steps at your request (GDPR/UK GDPR Art. 6(1)(b)), (ii) legal obligations (Art. 6(1)(c)), and (iii) our legitimate interest in evaluating candidates (Art. 6(1)(f)).*

***Retention:** If your application is unsuccessful, we retain your data for 12 months after the recruitment process concludes, unless you consent to longer retention. Successful candidates’ data becomes part of their employment records.*

***Your rights:** Depending on your location, you may have the right to access, correct, delete, or restrict the processing of your personal data, to data portability, and to withdraw consent.*

***Automated decision-making:** We use automated tools to assist in screening applications. No hiring decision is made solely by automated means without human review.*

***International transfers:** Your data may be transferred to and processed in the United States, Germany, the United Kingdom, or Romania. Where required, transfers are protected by Standard Contractual Clauses or other approved mechanisms.*

*By submitting your application, you acknowledge that you have read and understood Taktile’s Applicant Privacy Policy. To exercise your rights or ask questions, contact *Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
