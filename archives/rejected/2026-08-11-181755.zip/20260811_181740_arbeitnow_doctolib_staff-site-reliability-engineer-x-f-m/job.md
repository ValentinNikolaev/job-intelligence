# Staff Site Reliability Engineer (x/f/m)

Posted: 2026-08-11T14:55:09Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

### **Your Impact**

We are looking for a **Staff Site Reliability Engineer** to join our SRE team dedicated to platform reliability within Platform Engineering.

Your mission will be to act as a technical leader driving Doctolib's reliability and scalability at a European scale, ensuring our platform remains reliable, debuggable, and resilient across infrastructure, observability, and cross-cutting reliability initiatives. You will play a pivotal role in a team driving reliability standards across 170+ applications, contributing directly to supporting 520,000 health professionals and 90 million patients in their daily healthcare journey.

This role sits at the intersection of infrastructure, developer experience, and product engineering. You'll act as a technical leader and strategic partner to SREs, software engineers, and product teams, guiding decisions, mentoring engineers, and driving cross-cutting initiatives that elevate our operational maturity.

### **What you'll do**

Your responsibilities include but are not limited to:

- Lead large-scale cross-cutting reliability initiatives across the platform, spanning infrastructure automation, observability, and incident management

- Identify and drive improvements to incident detection, response, and postmortem analysis capabilities

- Define and evolve SLOs, error budgets, and alerting standards across multiple product teams

- Take part in the on-call rotation, and actively contribute to improving our on-call experience by refining alerting, reducing noise, and ensuring actionable telemetry

- Serve as a mentor and technical coach to senior engineers, helping elevate the craft of reliability engineering across the company

- Influence strategic decisions by providing technical guidance to leadership and representing reliability engineering in architectural reviews and platform discussions

- Partner with software engineering teams to embed reliability practices early in the development lifecycle

## **Who you are**

Before you read on: if you don't have the exact profile described below, but you feel this job description matches your skill set, we still encourage you to apply.

**You'll be a great fit if you:**

- Have extensive experience (8+ years) in SRE, platform engineering, or infrastructure roles within a large-scale, multi-team production environment

- Have proven experience with cloud platforms such as AWS, GCP, or Azure

- Have strong experience with containerization and orchestration technologies, Kubernetes is a must, its deployment and scaling strategies ecosystem

- Have implemented and operated SLIs, SLOs, and error budgets in production

- Have experience managing on-call rotations and leading incident response in high-stakes environments

- Have a strong systems engineering background with fluency in at least one backend programming language (e.g., Go, Python, Ruby)

- Have a proven ability to lead through influence: setting technical direction, driving consensus, and mentoring engineers across teams

- Are comfortable balancing long-term architecture work with fast, iterative improvements

- Have clear, concise communication skills, both written and verbal, with the ability to drive alignment in ambiguous environments

- Partner with feature teams to accelerate their production readiness, providing hands-on guidance on reliability best practices, launch reviews, and operational standards before go-live

- Are fluent in English

**It would be fantastic if you:**

- Have deep expertise in observability tooling and architecture (logging, tracing, metrics)

- Have experience designing and operating high-scale telemetry pipelines and working with developers to improve instrumentation quality

- Appreciate working in regulated environments, healthcare, fintech, or similar; at Doctolib, data privacy and compliance are part of every engineering decision

- Care about reliability enablement, golden paths, runbooks, shared libraries

## **Life at Doctolib Tech**

- Our solutions are built on a single fully cloud-native platform that supports web and mobile app interfaces, multiple languages, and is adapted to country and healthcare specialty requirements.

- Our stack is composed of Rails, TypeScript, Java, Python, Kotlin, Swift, and React Native.

- We leverage AI ethically across our products to empower patients and health professionals. Discover our AI vision[ here](https://careers.doctolib.com/ai-careers/).

Want to learn more about our tech culture and environment? Visit the[ Doctolib Tech site](https://careers.doctolib.com/tech-doctolib/).

## **What we offer**

- A Deutschlandticket (Germany-wide public transport pass) fully paid for by Doctolib

- 28 vacation days + 1 additional day for each full calendar year of employment (up to a maximum of 30 days)

- Work from abroad for up to 10 days per year thanks to our flexibility days policy

- Company health insurance with great supplementary benefits through our partner Allianz

- Company pension scheme (bAV) through Allianz with an employer subsidy of 40% (15% within the probationary period)

- The Doctolib Parent Care program, which includes one month additional parental leave and much more

- Enrollment in Doctolib's long-term employee value sharing plan called DoctoGrowth

- Free mental health and coaching services through our partner Moka.care

- Subsidized sports membership through our partner Urban Sports Club

- A flexible workplace policy offering both hybrid and office-based mode

- Alongside healthy snacks and our regular breakfast buffet, we provide a subsidized meal benefit

- For caregivers and workers with disabilities, a package including an adaptation of the remote policy, extra days off for medical reasons, and psychological support

- Relocation support in case of international mobility

- Access to the best AI tools for coding, development and dedicated training

## **Our interview process**

- Recruiter Interview

- System Design Interview

- Technical SRE Interview

- Behavioral Interview

- At least one reference check

We want your experience to be clear, respectful, and transparent. Learn more about our hiring process on our[ candidate experience page](https://careers.doctolib.com/tech-doctolib/getting-hired/).

## **Job details**

- Permanent position

- Tech stack: Kubernetes, Terraform, AWS / GCP, Prometheus, OpenTelemetry, Datadog, ArgoCD

- Full-time

- Berlin, Germany

- Hybrid work setup (up to 2 remote days per week)

- Start date: as soon as possible

## **We welcome everyone**

At Doctolib, we are committed to improving access to healthcare for everyone. This translates into our recruitment process. We evaluate candidates based solely on qualifications and motivation, without any form of discrimination.

The more diverse ideas are heard, the more our product will truly improve healthcare for all. You are welcome to apply to Doctolib, regardless of your gender, religion, age, sexual orientation, ethnicity, or disability.

To ensure equal opportunities, we invite you to exclude personal information (e.g., pictures, age) from your applications. If you require any accommodation, please let us know for support during the hiring process.

Join us in building the healthcare we all dream of!

## **Your data privacy**

*All information provided is processed by Doctolib for application management. For data processing details, click here:*[* **Germany*](https://doctolib.legal/B2C-Privacy-Policy-Career-DE)* |*[* **France*](https://doctolib.legal/B2C-Privacy-Policy-Career-FR)* |*[* **Italy*](https://doctolib.legal/B2C-Privacy-Policy-Career-IT)* |*[* **Netherlands*](https://doctolib.legal/B2C-Privacy-Policy-Career-COM)*. Please contact hr.dataprivacy(at)doctolib.com for inquiries or to exercise your rights.*

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
