# Senior Fullstack Developer / Technical Lead (m/w/d)

Posted: 2026-08-26T21:00:27Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Es gibt eine fertige, moderne Codebasis, und wir suchen jemanden, der sie übernimmt. Das ist die ehrliche Beschreibung dieser Stelle.

Du trägst ab dann die technische Verantwortung für das Produkt und schreibst dabei selbst den Code, von der Oberfläche bis in die serverlosen Backend-Strukturen. Abgestimmt wird direkt mit der Geschäftsführung, Zwischenebenen gibt es keine. Wichtiger als jedes Framework im Detail zu kennen ist uns, dass du Probleme löst und dich schnell in Unbekanntes einarbeitest.

## Aufgaben

- Du entscheidest, wie es technisch weitergeht, und setzt es selbst um.

- Du fixt die Bugs und verantwortest die Deployments.

- Wenn eine Messe morgens um acht den Anmeldestart hat, hältst du das System am Laufen.

- Im Frontend arbeitest du mit TypeScript und React 18, dazu Vite, TailwindCSS und shadcn/ui.

- Im Backend arbeitest du mit AWS Amplify Gen 2, serverlos auf AWS mit Lambda, DynamoDB und Cognito.

## Qualifikation

Du bist sicher in React und TypeScript.

- Du hast serverlos auf AWS gearbeitet, also mit Lambda, DynamoDB, Cognito und IAM Policies, und weißt, wie man ein Datenschema schneidet.

- Du schreibst den Code selbst, statt ihn zu verteilen.

- Du hast schon einmal ein System übernommen, das jemand anders gebaut hat.

- Schön, aber kein Muss: Erfahrung mit Zahlungsflüssen über Stripe inklusive Connect, Berührung mit Lokalisierung über i18next und mit Analytics über PostHog.

## Benefits

Das Jahresgehalt startet bei 50.000 Euro und geht bis 70.000 Euro, abhängig davon, was du mitbringst, oder du auch Equity willst. Wo du arbeitest, entscheidest du: dauerhaft remote ist möglich, das Büro im Technologiezentrum Wuppertal steht offen, und zu Events fahren wir gemeinsam raus. An Eventtagen richtet sich der Rhythmus nach dem Event, in den Wochen dazwischen teilst du dir die Zeit selbst ein.

Der eigentliche Unterschied zu einer größeren Firma ist ein anderer. Was du technisch entscheidest, ist entschieden, es gibt kein Gremium dahinter. Und was du baust, läuft ab dem nächsten Event bei echten Veranstaltern statt in einem Testsystem.

Wir freuen uns über Bewerbungen unabhängig von Alter, Geschlecht, Herkunft, Religion, Behinderung oder sexueller Identität. Ausgewählt wird nach Eignung.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
