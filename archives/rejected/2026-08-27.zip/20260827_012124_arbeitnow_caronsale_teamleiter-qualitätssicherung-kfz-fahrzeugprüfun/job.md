# Teamleiter Qualitätssicherung Kfz / Fahrzeugprüfung (m/w/d)

Posted: 2026-08-26T20:55:08Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Du hast Kfz-Fachwissen, weißt wie Qualitätsprozesse funktionieren – und willst ein Team führen, das beides zusammenbringt? Als Teamleiter Qualitätssicherung Kfz / Fahrzeugprüfung (m/w/d) bei CarOnSale stellst du sicher, dass unsere Fahrzeugberichte, Auktionen und Datenprozesse auf dem Niveau sind, das unsere Kunden und Partner erwarten.

**Standort:** Berlin Schöneberg – Du arbeitest vor Ort in unserem Büro, hybrid mit 3 Tagen Office und 2 Tagen Homeoffice.

### Über uns

CarOnSale ist das KI-gestützte System für den B2B-Gebrauchtwagenhandel in Europa. Über 40.000 Käufer aus mehr als 20 Ländern handeln auf unserer Plattform – und 85 % des Inventars ist exklusiv bei uns. Wir verbinden Software, Pricing-Intelligenz, Logistik und Finanzierung in einer Schicht – als Betriebssystem für eine ganze Branche.

***One Platform. One Profit Engine.***

### Deine Aufgaben:

- Du stellst sicher, dass **Teamziele und KPIs** erreicht werden – Genauigkeit, Effizienz und Timelines.

- Du überprüfst die Arbeitsergebnisse des Teams (Berichte, Datenpflege, Auktionsanpassungen) auf **Qualität und Standardeinhaltung**.

- Du **leitest dein Team im Tagesgeschäft** und führst fachlich bei komplexen oder kritischen Aufgaben und in arbeitsintensiven Phasen.

- Du **behältst unsere Prozesse im Blick **und** übernimmst Ownership**, wenn's hakt – gerade bei unseren großen Kunden sorgst du dafür, dass Probleme schnell auffallen, gelöst werden und der Prozess wieder auf Kurs kommt. Wo nötig, entwickelst du neue Prozesse.

- Du bringst dich in **Projekte** ein und **treibst die Weiterentwicklung** unserer Prozesse im Rahmen unseres **OKR-Frameworks** voran.

- Du **erstellst Arbeitspläne**, **priorisierst Aufgaben** und sorgst für einen strukturierten Ablauf.

- Du** kommunizierst regelmäßig** mit dem Team und vermittelst Updates, Best Practices und Feedback.

### Was du mitbringst:

- Abgeschlossene **Ausbildung oder Berufserfahrung im Kfz-Bereich** – z. B. als Kfz-Mechaniker, Kfz-Mechatroniker oder im automobilen Handel. **Alternativ**: Ausgeprägtes privates Interesse an Fahrzeugen und die Bereitschaft, dich intensiv in Fahrzeugbewertung und Qualitätsprüfung einzuarbeiten.

- **Hohes Ownership**: Du bist erster Ansprechpartner für dein Team, denkst aber auch teamübergreifend mit – wenn Prozesse brechen oder Fragen aufkommen, gehst du proaktiv ran und findest Lösungen.

- **Erfahrung in der Teamleitung** oder einer **vergleichbaren Führungsposition**, idealerweise in einem technischen oder qualitätssichernden Umfeld.

- **Erfahrung in der Qualitätssicherung**, idealerweise im Bereich Fahrzeuge oder Auktionen.

- Fähigkeit, **Teammitglieder zu motivieren**, zu fördern und klare Ziele zu setzen.

- Hohe **Eigenständigkeit **und **Verlässlichkeit **bei der Steuerung von Prozessen.

- **Sicheres Auftreten** und **Kommunikationsgeschick** mit internen und externen Stakeholdern.

- Sicherer **Umgang mit Office-Anwendungen** und schnelle Einarbeitung in neue Systeme.

- Sehr gute **Deutschkenntnisse in Wort und Schrift** (mind. C1), **Englischkenntnisse **(mind. B2).

### Was dich bei uns erwartet:

- Hybrides Arbeiten: 3 Tage Office, 2 Tage Homeoffice – plus 10 Tage „Work from Anywhere" pro Jahr

- 28 Tage Urlaub

- 2× jährlicher Career Development Cycle

- Betriebliche Altersvorsorge mit 20 % Arbeitgeberzuschuss

- 100% Übernahme des Deutschlandtickets

- FitX-Mitgliedschaft oder Urban Sports Club-Zuschuss

- Dienstrad-Leasing-Option

- Virtual Stock Options – du beteiligst dich am Erfolg

- Freie Tech-Wahl: Windows oder Apple

- Strukturiertes Onboarding mit Buddy-Programm und Social Events

- Gelebte Vielfalt: Prayer Room, hundefreundliches Büro, aktives Frauennetzwerk

**Bewirb dich jetzt – dein Lebenslauf reicht.**

Du erfüllst nicht jede Anforderung zu 100 %? Kein Problem. Wenn du Kfz-Know-how mitbringst, Prozesse im Griff hast und ein Team führen willst – meld dich.

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
