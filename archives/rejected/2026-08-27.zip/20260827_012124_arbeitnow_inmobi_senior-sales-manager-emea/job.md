# Senior Sales Manager - EMEA

Posted: 2026-08-26T23:45:23Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**InMobi Advertising** is a global technology leader helping marketers win the moments that matter. Our advertising platform reaches over 2 billion people across 150+ countries and turns real-time context into business outcomes, delivering results grounded in privacy-first principles. Trusted by 30,000+ brands and leading publishers, InMobi is where intelligence, creativity, and accountability converge. By combining lock screens, apps, TVs, and the open web with AI and machine learning, we deliver receptive attention, precise personalization, and measurable impact.

Through **Glance AI,** we are shaping AI Commerce, reimagining the future of e-commerce with inspiration-led discovery and shopping. Designed to seamlessly integrate into everyday consumer technology, Glance AI transforms every screen into a gateway for instant, personal, and joyful discovery. Spanning diverse categories such as fashion, beauty, travel, accessories, home décor, pets, and beyond, Glance AI delivers deeply personalized shopping experiences. With rich first-party data and unparalleled consumer access, it harnesses InMobi's global scale, insights, and targeting capabilities to create high impact, performance driven shopping journeys for brands worldwide.

Recognized as a Great Place to Work, and by MIT Technology Review, Fast Company's Top 10 Innovators, and more, InMobi is a workplace where bold ideas create global impact. Backed by investors including SoftBank, Kleiner Perkins, and Sherpalo Ventures, InMobi has offices across San Mateo, New York, London, Singapore, Tokyo, Seoul, Jakarta, Bengaluru and beyond.

At** InMobi Advertising**, you'll have the opportunity to shape how billions of users connect with content, commerce, and brands worldwide. To learn more, visit [www.inmobi.com](http://www.inmobi.com/)

**Overview of the Role:**

InMobi is seeking a passionate, ambitious, and driven Senior Sales Manager to drive new logo activation for InMobi's App Performance Solutions team across the DACH region and broader EMEA market. In this role, you'll be responsible for identifying, engaging, and closing high-value opportunities with some of the largest brands across non-gaming verticals. This is a high-impact, quota-carrying role ideal for a self-starter who thrives in a fast-paced, data-driven environment and is passionate about helping performance marketers scale through programmatic app advertising.

You'll join a high-performing team spanning EMEA Sales, Client Growth, and Media Buying under App Performance Solutions — a team that will actively support your growth and success within the InMobi programmatic sales ecosystem. This is an exciting opportunity to make a visible impact across the EMEA region for a high-growth App Performance Solutions business comprising an AI/ML-driven DSP, Owned and Operated Glance TV, and Performance CTV.

This is a role for true hunters — those who thrive on building pipelines from scratch, opening doors others can't, and turning cold conversations into long-term revenue partnerships.

*This is a fully remote role based in Germany. Proficiency in both German and English is required. Some travel is expected for client meetings, industry events, and in-person team sync-ups as needed.*

**The Impact You'll Make: **

As Senior Sales Manager, EMEA, you will be responsible for driving sales from a portfolio of Direct Brands and Performance Agencies across the DACH region by creating and selling effective App Performance Solutions. You will also actively participate in shaping InMobi's App Performance sales strategy, go-to-market approach, and execution plan across your key region within EMEA.

- Identify, acquire, advise, and develop new relationships with targeted, strategic brands, agencies, and partners that ensure the growth and long-term success of InMobi's suite of App Performance Solutions

- ** **Leverage your knowledge of the market landscape and InMobi's unique selling propositions and differentiators to develop new and enduring business with advertisers — including navigating the Programmatic and walled garden ecosystems to position InMobi App Performance Solutions as a must-have for brands' app growth and retention strategies

- ** **Maintain strong relationships with ecosystem influencers, MMPs, agencies, and partners to keep InMobi top of mind for their clients

- ** **Own the entire sales lifecycle — from outbound prospecting and inbound lead qualification to proposal building, nurturing, activation, and strategic growth consulting

- ** **Collaborate closely with cross-functional teams across Client Growth, Media Buying, Legal, Finance, Ecosystem Partnerships, and Product to ensure seamless onboarding, execution, and account handover to the Growth team

- ** **Represent InMobi App Performance Solutions at key industry events, conferences, and networking opportunities across EMEA to drive visibility and pipeline growth

- ** **Maintain a disciplined approach to pipeline management, leveraging CRM tools for accurate forecasting and performance tracking

- ** **Consistently exceed quarterly revenue targets through strategic account acquisition and strong client relationship management

**The Experience We Need: **

- ** Industry experience**. You bring 5+ years of hunting and selling experience to App businesses and Performance Agencies. You understand the challenges they face, can leverage your experience to develop compelling solutions, and have a track record of consistently meeting and exceeding revenue goals. You're known for building revenue where none existed — not just maintaining books of business, but creating them.

- ** An advertising technology expert**. You've spent at least 6+ years in ad tech and know the EMEA ecosystem well. Experience at a leading Performance DSP, Performance CTV, Ad Network, Rewarded Platform, MMP, or other online advertising company is required. You think deeply about clients' growth and retention challenges and know how to recommend the right solutions.

- ** A trusted advisor and consultant**. You have authentic communication skills and the ability to form consultative, credible, and long-standing relationships with your clients. In a marketplace flooded with vendors, your clients think of you first — not because you sold them, but because you solved for them.

- ** A high-energy, passionate self-starter**. You are highly self-motivated by nature, ambition is in your DNA, and you are extremely comfortable in a fast-paced, risk-taking, and often ambiguous environment.

- ** Analytically strong and a compelling storyteller**. You have strong analytical skills and the ability to peel back layers and find hidden opportunities. You don't just present numbers — you build narratives around them that move clients to action.

- ** A proactive problem solver**. You have a proven ability to solve customer pain points and technical challenges while proactively creating solutions through cross-functional collaboration.

- ** Eager, curious, and a fast learner**. You are naturally inquisitive, take a proactive approach, and seek out ways to support your colleagues. The ad tech landscape shifts constantly — signal loss, AI disruption, shifting buyer behaviour — and you lean in rather than wait for the dust to settle.

- ** Education**. A BA/BS degree in a relevant discipline is required, or equivalent professional experience. An MBA or Master's degree is a plus.

- ** Language**. Full professional proficiency in both German and English is required.

**At InMobi, you'll be surrounded by people who:**

- Think big and act fast — we're entrepreneurial, thrive in ambiguity, and love solving high-impact problems

- Are passionate, fanatically driven, and take immense pride in their work — we care deeply about the impact we create and continuously push our potential

- Own their outcomes — we take responsibility, make bold decisions, and execute with confidence

- Embrace freedom with accountability — we value autonomy and understand that trust comes with responsibility

- Believe in lifelong learning — we welcome feedback, challenge ourselves to grow, and aren't afraid to take smart risks

**Compensation & Benefits**

Our compensation philosophy enables us to provide a competitive salary that drives high performance while balancing business needs and pay equity. We determine compensation based on a wide variety of factors, including role, nature of experience, skills, and location.

**Salary Range (Germany):**

The base salary or fixed pay for this role ranges from **€132,500 to €167,250** (min to max of base salary). In addition to your base salary, you may be eligible to receive variable compensation in the form of an annual or quarterly performance bonus or sales incentive, as determined per InMobi policy.

*Note*: Our ranges may vary based on final location and region of roles in accordance with the geographical differentiation in pay scales in the country.

**Benefits: **

As an InMobi employee based in Germany, you will have access to our full EMEA benefits package. Detailed benefits information is available upon request and will be outlined in full during the hiring process.

**Equal Opportunity & Inclusion**

InMobi is an equal opportunity employer committed to fostering a diverse, inclusive, and equitable workplace. We welcome applications from all qualified individuals regardless of race, ethnic origin, gender, gender identity or expression, sexual orientation, religion or belief, disability, age, or any other characteristic protected under applicable law, including the German General Equal Treatment Act (Allgemeines Gleichbehandlungsgesetz — AGG).

InMobi is proud to provide reasonable accommodations to qualified individuals with disabilities throughout the hiring process and in the workplace. If you require an accommodation, please let us know, and we will work with you to meet your needs.

At InMobi, culture isn't a buzzword — it's an ethos woven by every InMobian, reflecting our diverse backgrounds and experiences. Howsoever you identify, and whatever background you bring with you, we invite you to apply if this role excites you.

**Data Privacy Notice (GDPR)**

In accordance with the General Data Protection Regulation (GDPR) and applicable German data protection law (Bundesdatenschutzgesetz — BDSG), InMobi collects and processes your personal data solely for the purpose of evaluating your application for this role.

Your data will be retained for the duration of the recruitment process and, where applicable, for a period thereafter in accordance with statutory retention obligations. Your data will not be shared with third parties outside of the recruitment process without your explicit consent.

You have the right to access, rectify, or request the deletion of your personal data at any time. To exercise your rights or for any data privacy enquiries, please contact: -----

*By submitting your application, you confirm that you have read and understood this data privacy notice and consent to the processing of your personal data for recruitment purposes.*

## **— DEUTSCHE FASSUNG —**

**InMobi Advertising** ist ein weltweit führendes Technologieunternehmen, das Marketingfachleuten hilft, die entscheidenden Momente zu gewinnen. Unsere Werbeplattform erreicht über 2 Milliarden Menschen in mehr als 150 Ländern und wandelt Echtzeitkontext in messbare Geschäftsergebnisse um – auf Basis datenschutzfreundlicher Grundsätze. InMobi genießt das Vertrauen von über 30.000 Marken und führenden Publishern und vereint Intelligenz, Kreativität und Verantwortlichkeit. Durch die Kombination von Sperrbildschirmen, Apps, Fernsehgeräten und dem offenen Web mit KI und maschinellem Lernen bieten wir aufmerksamkeitsstarke Werbeplatzierungen, präzise Personalisierung und messbare Wirkung.

Mit **Glance AI** gestalten wir die Zukunft des KI-gestützten Commerce neu und revolutionieren das E-Commerce-Erlebnis durch inspirationsgeleitete Entdeckung und Shopping. Glance AI ist darauf ausgelegt, sich nahtlos in alltägliche Verbrauchertechnologie zu integrieren und jeden Bildschirm in ein Tor für sofortige, persönliche und freudvolle Entdeckungen zu verwandeln. Glance AI bietet zutiefst personalisierte Einkaufserlebnisse in Bereichen wie Mode, Beauty, Reisen, Accessoires, Wohnen, Haustiere und mehr.

InMobi wurde als Great Place to Work ausgezeichnet und von MIT Technology Review sowie Fast Company zu den Top 10 Innovatoren gezählt. Mit Investoren wie SoftBank, Kleiner Perkins und Sherpalo Ventures unterhält InMobi Büros in San Mateo, New York, London, Singapur, Tokio, Seoul, Jakarta, Bengaluru und weiteren Standorten weltweit.

Besuchen Sie www.inmobi.com, um mehr zu erfahren.

**Über die Stelle:**

InMobi sucht eine/n leidenschaftliche/n, ambitionierte/n und ergebnisorientierte/n Senior Sales Manager, EMEA, der/die die Neukundengewinnung für das App Performance Solutions-Team von InMobi in der DACH-Region und dem gesamten EMEA-Markt vorantreibt. In dieser Rolle sind Sie verantwortlich für die Identifikation, Ansprache und den Abschluss hochwertiger Geschäftsmöglichkeiten mit einigen der größten Marken in Nicht-Gaming-Verticals.

Sie werden Teil eines leistungsstarken Teams aus EMEA-Vertrieb, Client Growth und Media Buying unter App Performance Solutions, das Sie in Ihrem Wachstum und Erfolg im InMobi-Ökosystem aktiv unterstützt. Dies ist eine aufregende Möglichkeit, sichtbaren Einfluss in der EMEA-Region zu erzielen – für ein wachstumsstarkes Geschäftsfeld, das einen KI/ML-gestützten DSP, Owned-and-Operated Glance TV und Performance CTV umfasst.

Diese Stelle richtet sich an echte Hunter – Menschen, die Pipeline aus dem Nichts aufbauen, Türen öffnen, die andere nicht öffnen können, und aus kalten Erstkontakten langfristige Umsatzpartnerschaften entwickeln.

*Diese Stelle ist eine vollständig remote ausgeübte Position mit Sitz in Deutschland. Fließende Kenntnisse in Deutsch und Englisch sind erforderlich. Gelegentliche Reisetätigkeit für Kundenmeetings, Branchenveranstaltungen und persönliche Team-Meetings wird erwartet.*

**Ihre Aufgaben:**

Als Senior Sales Manager, EMEA sind Sie verantwortlich für den Aufbau und die Entwicklung eines Portfolios aus Direktmarken und Performance-Agenturen in der DACH-Region durch den Verkauf effektiver App Performance Solutions. Darüber hinaus gestalten Sie aktiv die Vertriebsstrategie, den Go-to-Market-Ansatz und den Ausführungsplan von InMobi für Ihre Schlüsselregion innerhalb von EMEA mit.

- ** **Identifikation, Akquise, Beratung und Entwicklung neuer Beziehungen zu strategisch relevanten Marken, Agenturen und Partnern zur Sicherung des langfristigen Wachstums der App Performance Solutions von InMobi

- ** **Nutzung Ihrer Marktkenntnis und der einzigartigen Wettbewerbsvorteile von InMobi zur Entwicklung neuer und nachhaltiger Geschäftsbeziehungen mit Werbetreibenden – einschließlich der Navigation in programmatischen und Walled-Garden-Ökosystemen

- ** **Pflege von Beziehungen zu Ökosystem-Influencern, MMPs, Agenturen und Partnern, um InMobi bei deren Kunden stets präsent zu halten

- ** **Verantwortung für den gesamten Sales Lifecycle – von der Outbound-Prospektion und Inbound-Lead-Qualifizierung über die Angebotserstellung, Nurturing und Aktivierung bis hin zur strategischen Wachstumsberatung

- ** **Enge Zusammenarbeit mit funktionsübergreifenden Teams aus Client Growth, Media Buying, Legal, Finance, Ecosystem Partnerships und Product für ein reibungsloses Onboarding und die Übergabe an das Growth-Team

- ** **Repräsentation von InMobi App Performance Solutions bei wichtigen Branchenveranstaltungen, Konferenzen und Networking-Events in der gesamten EMEA-Region

- ** **Diszipliniertes Pipeline-Management unter Nutzung von CRM-Tools für präzise Prognosen und Performance-Tracking

- ** **Kontinuierliches Übertreffen der vierteljährlichen Umsatzziele durch strategische Neukundengewinnung und starkes Beziehungsmanagement

**Ihr Profil:**

- ** Branchenerfahrung**. Sie verfügen über 5+ Jahre Erfahrung im Hunting und Selling an App-Unternehmen und Performance-Agenturen. Sie kennen deren Herausforderungen und sind bekannt dafür, Umsatz aufzubauen – nicht nur Bestandsgeschäfte zu verwalten, sondern neue zu schaffen.

- ** Advertising Technology Expertis**e. Sie haben mindestens 6+ Jahre Erfahrung im Ad Tech und kennen das EMEA-Ökosystem sehr gut. Erfahrung bei einem führenden Performance DSP, Performance CTV, Ad Network, Rewarded Platform, MMP oder einem anderen Online-Werbunternehmen ist erforderlich.

- ** Vertrauenswürdiger Berater**. Sie verfügen über authentische Kommunikationsfähigkeiten und die Fähigkeit, schnell konsultative, glaubwürdige und langfristige Kundenbeziehungen aufzubauen. In einem Markt voller Anbieter denken Ihre Kunden zuerst an Sie – nicht weil Sie verkauft haben, sondern weil Sie Probleme gelöst haben.

- ** Hochenergetische/r, leidenschaftliche/r Self-Starter**. Sie sind von Natur aus hochmotiviert, Ehrgeiz liegt in Ihrer DNA, und Sie fühlen sich in einem schnelllebigen, risikofreudigen und oft mehrdeutigen Umfeld sehr wohl.

- ** Analytische Stärke und überzeugendes Storytelling**. Sie verfügen über starke analytische Fähigkeiten und die Fähigkeit, versteckte Chancen zu erkennen und daraus überzeugende Narrative zu entwickeln, die Kunden zum Handeln bewegen.

- ** Proaktive/r Problemlöser/in**. Sie haben nachgewiesene Fähigkeiten, Kundenschmerzpunkte und technische Herausforderungen zu lösen und durch funktionsübergreifende Zusammenarbeit Lösungen zu entwickeln.

- ** Wissbegierig und lernbereit**. Sie sind von Natur aus neugierig, handeln proaktiv und suchen aktiv nach Wegen, Ihre Kollegen zu unterstützen. Die Ad-Tech-Landschaft verändert sich ständig – Signal-Verlust, KI-Disruption, verändertes Käuferverhalten – und Sie engagieren sich aktiv statt abzuwarten.

- ** Ausbildung**. Ein Bachelor- oder Masterabschluss in einem relevanten Fachbereich ist erforderlich, oder gleichwertige Berufserfahrung. Ein MBA oder ein weiterführender Masterabschluss ist von Vorteil.

- ** Sprachen**. Verhandlungssichere Kenntnisse in Deutsch und Englisch sind zwingend erforderlich.

**Bei InMobi sind Sie umgeben von Menschen, die:**

- ** Groß denken und schnell handeln** — wir sind unternehmerisch, gedeihen in Mehrdeutigkeit und lösen gerne wirkungsvolle Probleme

- ** Leidenschaftlich sind und enormen Stolz auf ihre Arbeit legen** — wir kümmern uns tief um die Wirkung, die wir erzielen

- ** Ihre Ergebnisse verantworten** — wir übernehmen Verantwortung, treffen mutige Entscheidungen und handeln mit Überzeugung

- ** Freiheit mit Verantwortung verbinden** — wir schätzen Autonomie und verstehen, dass Vertrauen mit Verantwortung einhergeht

- ** An lebenslanges Lernen glauben** — wir begrüßen Feedback, fordern uns selbst heraus und scheuen keine klugen Risiken

**Vergütung & Benefits**

Unsere Vergütungsphilosophie ermöglicht es uns, wettbewerbsfähige Gehälter anzubieten, die Hochleistung fördern und gleichzeitig Geschäftsanforderungen sowie Lohngleichheit berücksichtigen. Die Vergütung wird auf Basis einer Vielzahl von Faktoren bestimmt, darunter die Rolle, die Art der Erfahrung, Fähigkeiten und der Standort.

**Gehaltsrahmen (Deutschland):**
Das Grundgehalt oder die Festvergütung für diese Stelle liegt zwischen **€132.500 und €167.250** (Minimum bis Maximum des Grundgehalts). Zusätzlich zum Grundgehalt können Sie variable Vergütung in Form eines jährlichen oder vierteljährlichen Leistungsbonus oder Sales Incentive erhalten, gemäß InMobi-Richtlinie.

******Unsere Gehaltsbänder können je nach finalem Standort und Region in Übereinstimmung mit den geografischen Unterschieden in den Gehaltsstrukturen des Landes variieren.

**Benefits:** Als InMobi-Mitarbeiter/in mit Sitz in Deutschland haben Sie Zugang zu unserem vollständigen EMEA-Leistungspaket. Detaillierte Informationen zu den Benefits sind auf Anfrage erhältlich und werden im Rahmen des Einstellungsprozesses vollständig dargelegt.

**Chancengleichheit & Inklusion**

InMobi ist ein Arbeitgeber, der Chancengleichheit fördert und sich einer vielfältigen, inklusiven und fairen Arbeitsumgebung verpflichtet hat. Wir begrüßen Bewerbungen von allen qualifizierten Personen unabhängig von Rasse, ethnischer Herkunft, Geschlecht, Geschlechtsidentität oder -ausdruck, sexueller Orientierung, Religion oder Weltanschauung, Behinderung, Alter oder anderen durch geltendes Recht geschützten Merkmalen, einschließlich des Allgemeinen Gleichbehandlungsgesetzes (AGG).

InMobi stellt gerne angemessene Vorkehrungen für qualifizierte Personen mit Behinderungen während des Einstellungsprozesses und am Arbeitsplatz bereit. Wenn Sie eine Vorkehrung benötigen, teilen Sie uns dies bitte mit.

Bei InMobi ist Kultur kein Schlagwort – sie ist ein Ethos, das von jedem InMobian geprägt wird und unsere vielfältigen Hintergründe und Erfahrungen widerspiegelt. Wie auch immer Sie sich identifizieren und welchen Hintergrund Sie mitbringen – wir laden Sie ein, sich zu bewerben, wenn diese Stelle Sie begeistert.

**Datenschutzhinweis (DSGVO)**

Gemäß der Datenschutz-Grundverordnung (DSGVO) und dem Bundesdatenschutzgesetz (BDSG) erhebt und verarbeitet InMobi Ihre personenbezogenen Daten ausschließlich zum Zweck der Bearbeitung Ihrer Bewerbung für diese Stelle.

Ihre Daten werden für die Dauer des Bewerbungsverfahrens und gegebenenfalls darüber hinaus entsprechend den gesetzlichen Aufbewahrungspflichten gespeichert. Ihre Daten werden ohne Ihre ausdrückliche Zustimmung nicht an Dritte außerhalb des Bewerbungsverfahrens weitergegeben.

Sie haben das Recht, jederzeit Auskunft über Ihre gespeicherten Daten zu erhalten, diese berichtigen oder löschen zu lassen. Für die Ausübung Ihrer Rechte oder bei datenschutzbezogenen Anfragen wenden Sie sich bitte an: -----

*Mit der Einreichung Ihrer Bewerbung bestätigen Sie, dass Sie diesen Datenschutzhinweis gelesen und verstanden haben und der Verarbeitung Ihrer personenbezogenen Daten für Zwecke des Bewerbungsverfahrens zustimmen.*

Besuchen Sie https://www.inmobi.com/company/careers, um mehr über unsere Kultur, Werte und weltweite Karrieremöglichkeiten zu erfahren.

**The InMobi Culture**

At InMobi, culture isn't a buzzword; it's an ethos woven by every InMobian, reflecting our diverse backgrounds and experiences.

We thrive on challenges and seize every opportunity for growth. Our core values — thinking big, being passionate, showing accountability, and taking ownership with freedom — guide us in every decision we make.

We believe in nurturing and investing in your development through continuous learning and career progression with our InMobi Live Your Potential program.

InMobi is proud to be an Equal Employment Opportunity employer and is committed to providing reasonable accommodations to qualified individuals with disabilities throughout the hiring process and in the workplace.

Visit [https://www.inmobi.com/company/careers](https://nam04.safelinks.protection.outlook.com/?url=https%3A%2F%2Fwww.inmobi.com%2Fcompany%2Fcareers&data=05%7C02%7Crichard.thomas%40inmobi.com%7Ce97eb886aa4d4c8e919608dc52d1cc2f%7C89359cf49e60409980c4775a0cfe27a7%7C0%7C0%7C638476308219536812%7CUnknown%7CTWFpbGZsb3d8eyJWIjoiMC4wLjAwMDAiLCJQIjoiV2luMzIiLCJBTiI6Ik1haWwiLCJXVCI6Mn0%3D%7C0%7C%7C%7C&sdata=FOJ4DKK6f1jjlteD9SlK%2FdMDUaZzdYsCFSU%2BX%2BvuCAo%3D&reserved=0) to better understand our benefits, values, and more!

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
