# Senior Financial Analyst (all genders)

Posted: 2026-08-26T23:09:55Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**Your challenge**

As a **Senior Financial Analyst (all genders)** focused on Commercial Finance & Revenue at Hubject, you'll be the key link between Finance and our Commercial teams and collaborate closely with the CFO and commercial leadership to shape how we understand, forecast, and grow revenue. You'll bring energy and ownership to a role that mixes rigorous analysis with hands-on business partnering. Also, you'll create transparency around our revenue drivers, support critical business decisions, and actively shape the way we report and forecast revenue.

**Why Hubject**

We develop ideas and deliver solutions for the eMobility market
We are working on the most important growth topics
We are an international team of very motivated eMobility enthusiasts

AND

We have over 30 benefits different categories:

-

Food & drinks (food subsidy on the Euref-Campus restaurants)

-

Mobility (BVG subsidy)

-

Health & sports (Urban sports membership M)

-

Equipment (Laptop etc)

-

Learning and development (yearly training budget and Udemy learning platform access)

-

Hubject Lifestyle (Voiio membership)

-

Family-friendly environment (flex working time)

**Your Tasks**

- Own revenue analyses, forecasts and ongoing reporting to management.
- Act as a trusted business partner to Sales, Product and Leadership on commercial decisions.
- Develop pricing, margin and profitability analyses with actionable recommendations.
- Build business cases and evaluate new business models, deals and partnerships.
- Analyze revenue drivers, customer segments and product profitability.
- Lead budgeting, forecasting and mid-term planning on the revenue side.
- Collaborate closely with Accounting on revenue recognition topics.
- Drive continuous improvement of KPIs, reporting structures and forecast models.
- Build strong, trust-based relationships across Finance, Commercial and Leadership, acting as a go-to partner for revenue-related questions.

**Your Profile**

- Degree in Business Administration, Finance, Controlling, or a related field.
- Several years of experience in Commercial Finance, Revenue Controlling, or FP&A.
- Solid understanding of revenue models, pricing, and deal structures.
- Proven experience business partnering with commercial functions and senior stakeholders, with the confidence to challenge and influence decision-making.
- Strong Excel and BI skills (e.g., Power BI, Tableau); ERP experience is a plus.
- Proactive, high-energy, and entrepreneurial mindset with a track record of taking ownership, driving topics independently, and thriving in a fast-paced environment.

**Language**

- Excellent communication skills and business fluency in **English **(company language).

**Start date**

- As soon as possible

**Location**

**Onsite** in Berlin

Hybrid set-up:

-

1-2 days per week at the office, rest remote from the comfort of your home :)

-

EUREF Campus in Schöneberg in Berlin - Europe's hotspot for green technology and eMobility

(Remote **within Germany** possible)

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
