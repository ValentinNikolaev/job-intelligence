# Mediengestalter/-in Digital und Print - Vollzeit (m/w/d)

Posted: 2026-08-26T19:47:30Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Bei Vertranium gestaltest du nicht einfach nur schöne Designs – du entwickelst systematisch Markenauftritte für zahlreiche Kunden, die täglich von Tausenden Menschen gesehen werden und den Erfolg unserer Kunden messbar mitprägen. Unser Ziel ist es, die Finanzdienstleistungsbranche kommunikativ neu zum bekanntesten Agentur- und Consulting-Unternehmen in der Branche zu entwickeln.

Dafür suchen wir kreative Persönlichkeiten mit einem hohen Anspruch an ihre Arbeit, die eigene Ideen einbringen, Verantwortung übernehmen und sich in ihrer Expertise kontinuierlich weiterentwickeln möchten. Bei uns bist du kein kleines Rädchen im System: Durch kurze Entscheidungswege, eine flache Hierarchie und unser starkes Wachstum kannst du sichtbar Einfluss nehmen und Projekte aktiv mitgestalten.

Wenn du deine Fähigkeiten auf das nächste Level bringen und gemeinsam mit einem ambitionierten Team etwas Außergewöhnliches aufbauen möchtest, freuen wir uns auf deine Bewerbung!

## Aufgaben

**✓** Entwicklung von spannenden neuen Markenentwicklungen und Kommunikationskonzepten

**✓** Logodesign und überzeugenden Corporate Designs

**✓** Webdesign

**✓** Umgang mit Wordpress Backend

**✓** Beratungsgespräche mit Kunden

**✓** Einfaches Video Editing + Video Cutting

**✓** Erstellung von minimalistischen Grafiken bis hin zu kreativen Illustrationen

**✓** Bildbearbeitung von Portraits, Büro Interiors und anderem Shootingmaterial

**✓** Gestaltung von Printprodukten, u.a. Broschüren, Flyer, Visitenkarten, Merchandise-Artikel etc.

**✓** Erstellung von Social Media Beiträgen

## Qualifikation

**✓** Wichtig: Du kannst strukturiert arbeiten und kannst vorhandenen Prozessen folgen

**✓** Du besitzt umfangreiche Fähigkeiten mit Adobe Illustrator, InDesign und Photoshop

**✓** Du hast ein abgeschlossenes Studium / Ausbildung oder bist Autodidakt und hast bereits Erfahrungen in einer Agentur oder in einer selbstständigen Tätigkeit sammeln können

**✓** Du hast bereits mindestens 2 Jahre Berufserfahrung in den Bereichen Mediengestaltung sammeln können und bist den oben genannten Aufgaben gewachsen

**✓** Du bist kreativ, teamfähig, hast ein Auge für Ästhetik und Details

**✓** Du besitzt eine gute Ausdrucksweise in Deutsch und Englisch

**✓** Du bist motiviert, Dich in einem jungen, schnell wachsenden Unternehmen zu verwirklichen und gemeinsam erfolgreich zu werden.

## Benefits

**✓** 3.000€ - 4.000€ Einstiegsgehalt

**✓** Unbefristeter Arbeitsvertrag

**✓** Neuer Firmencomputer (iMac / MacBook Pro)

**✓** Sehr gute Verkehrsanbindung

**✓** Weiterbildungen

**✓** Steigende Vergütungen: Wir legen besonders großen Wert darauf, einander wertzuschätzen. Leistungen, die einen steigenden Mehrwert erbringen, werden stets belohnt.

**✓** Gemeinsam wachsen: Unser Ziel ist, dass jede Person, die wir einstellen, gemeinsam mit uns persönlich, finanziell und fachlich wächst.

**✓** Motivierende Arbeitsatmosphäre: Unser kollegialer und familiärer Umgang untereinander sorgt dafür, dass wir alle am gleichen Strang ziehen, eigene Bestleistungen erzielen und vor allem auch persönlich wachsen können.

**✓** Sehr gute Aufstiegschancen: Über die nächsten Jahre werden wir durch unsere große Nachfrage und unserer flachen Hierarchie enorm expandieren. Dazu benötigen wir zukünftig garantiert mehr Experten und Führungskräfte, vorzugsweise immer aus den eigenen Reihen.

Art der Stelle: Vollzeit

Arbeitszeiten: Montag bis Freitag

Voraussichtliches Einstiegsdatum: sofort möglich

Keywords: Mediengestalter (m/w/d) im Raum Stuttgart

**✓** Kununu Top-Gehaltszufriedenheits Award 2025

**✓** 5-stellige monatliche Investments in Mitarbeiterweiterbildungen

**✓** Familiäre Erfolgskultur mit hochmotivierten Talenten

**Bewirb dich jetzt und werde Teil des Vertranium-Teams!**

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
