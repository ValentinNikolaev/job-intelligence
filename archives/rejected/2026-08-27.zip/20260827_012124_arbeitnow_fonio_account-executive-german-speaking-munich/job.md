# Account Executive (German-speaking - Munich)

Posted: 2026-08-26T23:40:24Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

# **Über fonio**

Wir sind in **weniger als 12 Monaten von 1 Mio. auf 10 Mio. US Dollar ARR gewachsen** und haben bereits jetzt über 10.000 Kunden.

Fonio ist der europäische Marktführer für KI-Sprachagenten für SMBs. Nun expandieren wir weltweit und in neue Produktbereiche.

Wir agieren schnell, glauben an ein hohes Maß an Ownership, leben direktes Feedback und verzichten auf Company-Politics und unnötige Meetings.

Werde Teil** einer der krassesten Wachstumsstories in Europa**.

# **Deine Rolle**

Als **Account Executive **bei fonio bist du **Closer durch und durch**. Du bekommst täglich warme, vorqualifizierte Leads und weißt, was damit zu tun ist. Und wenn die Pipeline mal dünn wird, wartest du nicht: Du jagst Deals selbst nach.

# **Das erwartet dich**

-

**Inbound-Demos:** 8–16 qualifizierte Demo-Termine pro Tag

-

**Quota Ownership:** Klare monatliche und quartalsweise Zielquoten.

-

**Lead-Management:** Strukturierte Follow-ups und saubere Pflege deiner Pipeline im CRM.

-

**Impact:** Mitarbeit an der Optimierung unserer Sales-Motion in einem schnell wachsenden Start-up.

# **Wen wir suchen**

-

**Mindestens 1 Jahr** Erfahrung in Transactional Sales, idealerweise B2B-SaaS-Sales (Startup oder Scaleup von Vorteil)

-

Nachweisbare Closing-Erfolge entlang eines klaren Funnels

-

Hohe Eigendisziplin, ausgeprägtes Verantwortungsbewusstsein und echter Antrieb, sich zu beweisen.

-

**Kommunikationstalent** und Naturtalent im **Storytelling**

-

**Deutsch** auf Muttersprachniveau; sehr gutes **Englisch**

# **Was wir bieten**

-

**€70.000-€120.000 **(Fixum + **ungedeckelte** Provision)

-

**Equity** - du baust mit, also sollst du auch etwas davon bekommen.

-

**Essen & Drinks** - im Wiener Office gehen Mittag- und Abendessen auf uns (plus alle Drinks, die dein Herz begehrt, und ja, wir haben auch Protein Bars und Vitamine).

-

Equipment deiner Wahl - whatever makes you happy.

-

**Unlimited Budget**, wenn der ROI stimmt

-

Regelmäßige Team-Offsites.

-

**Relocation Bonus**, falls du nach Wien relocaten möchtest.

# **Bewerbungsprozess**

-

15 min Kennenlernen

-

45 min Skill Interview mit Demo-Simulierung

-

20 min Culture Fit mit den Gründern

Bei Fragen, melde dich gerne bei unserem Recruiter, Max Herfert, unter + 49 151 1979 3432

Compensation: €70K – €120K • Offers Equity • Offers Commission

- • €70K – €120K • Offers Equity • Offers Commission

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
