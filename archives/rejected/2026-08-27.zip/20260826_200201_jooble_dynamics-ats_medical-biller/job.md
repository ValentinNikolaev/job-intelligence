# Medical Biller

Posted: 2026-08-19T20:13:40.2000000

## Rejection

- Category: stale
- Reason: published_at 2026-08-19T20:13:40.2000000 is older than 7 days

...the Manager or Supervisor. 

Skills Required 
Experience in billing edits, claim denials, and follow -up activities 
Strong **backend **billing experience, including Epic and insurance billing, claims processing, denial management and resolution 

Education/...
