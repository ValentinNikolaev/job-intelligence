# Working Student / Intern: Offensive Security Engineer (Red Team & AppSec) (f/m/x)

Posted: 2026-08-26T19:17:32Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**Cologne, Germany (Hybrid)**

**Team:** Engineering · **Reports to:** CTO · **Format:** Working Student (16–20h/week) or Internship (3–6 months)

**Join our red team**

ilert is a SaaS platform for alerting, on-call management and incident response that keeps digital services always on. Teams worldwide rely on us to stay up.

To keep it that way, we are building an **internal red team** that continuously tests our own products the way a real attacker would. And we're a genuinely interesting target: an attacker who silences ilert doesn't just steal data — they turn off the alarm while they work.

As a working student on our red team, you help us **find, prove, and get security issues fixed** in our own systems. You learn to think like an attacker, working closely with our team.

You don't need to arrive as a finished pentester. You need curiosity, a habit of taking things apart to understand them, and the care to handle what you find responsibly.

## Tasks

- **Test Our Apps and APIs:** Hunt for vulnerabilities in our web and mobile apps and APIs — from authentication and access control (IDOR) to injection, misconfigurations, and exposed secrets.

- **Re-test Past Findings:** Go back over findings from previous penetration tests and verify the fixes actually hold.

- **Automate Security Checks in CI:** Help build secret, dependency, and code scanning into our pipelines so issues surface early instead of late.

- **Review New Features Before They Ship:** Support security reviews as features are being built, not after.

- **Run Authorized Social Engineering:** Design and run phishing and pretexting exercises against our own team — always under a written scope signed off by the CTO beforehand, always debriefed as a learning exercise, never punitive. Then help us fix what the exercise exposed.

- **Poke at the AI:** We're building an AI SRE that investigates incidents and can execute actions on approval. Prompt injection, tool abuse, and agent-boundary testing are wide-open ground.

- **Document and Follow Through:** Write up findings clearly and reproducibly, then follow them through to a fix. We care as much about closing the gap as finding it.

## What you bring

- **Enrolled student**, ideally in computer science, IT security, or similar.

- **Genuine interest in offensive security** — you tinker, you break things to understand them, maybe you already play CTFs / Hack The Box / TryHackMe.

- **Basic grasp of how web apps and HTTP work** — requests, headers, auth, cookies/tokens.

- **Comfortable on the command line** and with at least one scripting language (Python, JS/TS, Go).

- **Careful and responsible with sensitive information.** This role comes with access and trust: you stay inside the agreed scope and handle what you find responsibly.

- **Fluent English** (our working language).

- **Able to be in our Cologne office regularly** — the role is hybrid, not remote.

**Bonus**

- Burp Suite or OWASP ZAP

- OWASP Top 10

- AWS / Kubernetes / CI-CD exposure

- Mobile app testing

- LLM and agent security — prompt injection, tool-use boundaries

- Your own CVEs or bug-bounty reports

- German language skills

## Benefits

- 🎯 **A Real Attack Surface:** Not a lab, not a CTF box. Production software that companies worldwide depend on during their worst moments.

- 🧨 **Get In Early:** The red team is being built right now. You're not inheriting someone else's checklist — you help shape how we do this.

- 🤖 **Unexplored Ground:** Agentic AI security is barely a discipline yet. You'd be doing original work on it, on a product that's actually shipping.

- 🏡 **Hybrid Freedom:** Our office in **Cologne Rheinauhafen** (3 days/week) plus work from home (2 days/week).

- 🕒 **Student-Centric:** Flexible hours around lectures and exam periods.

- 🎓 **Direct Mentorship:** You report to the CTO and work alongside experienced engineers who want to be shown where they got it wrong.

- 🌴 **Focus Culture:** We protect maker time, favor async, and keep meetings rare.

**We hire for curiosity and a builder's mentality, not a checklist.** If you have a writeup, a CTF profile, a disclosed vulnerability, or a tool you built — bring it. But if you're early and hungry and can show us something you took apart, we want to hear from you too.

*Keywords: Werkstudent IT-Security, Penetration Testing, Praktikum Cyber Security, Red Team, Application Security, Köln.*

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
