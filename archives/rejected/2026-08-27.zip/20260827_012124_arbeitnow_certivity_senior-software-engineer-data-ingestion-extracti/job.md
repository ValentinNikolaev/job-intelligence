# Senior Software Engineer – Data Ingestion & Extraction (m/f/d)

Posted: 2026-08-26T23:29:18Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**About the Job**

At Certivity, we are looking for a Senior Software Engineer (m/f/d) to join our Data team. You will design and build the services that extract structured data from regulatory documents, and the tooling that verifies this data is correct once it's in our systems. This is a chance to work on complex engineering challenges with massive real-world impact. You will work alongside a sharp, collaborative team and ship production systems end-to-end. If you are comfortable pairing with AI tools to write code and want to build systems that ingest, verify, and deliver data at scale, this role might be the right one for you.

**What you will do**

- Build and scale services that extract structured data from regulatory documents.
- Design and maintain tooling to ensure data correctness across ingestion pipelines.
- Deploy and operate containerized apps in cloud environments (AWS, Azure, or GCP).
- Pair with AI coding tools as part of your regular development workflow.
- Contribute to technical architecture and help shape the engineering culture.

**Your profile**

- 5+ years of professional software development experience.
- Strong skills in Python.
- "AI-native": comfortable and effective pairing with AI tools to write code.
- Hands-on experience with data extraction at scale.
- Senior-level experience with at least one major cloud provider (AWS, Google Cloud, or Azure).
- Proficiency with Git, CLI tools, and containerized deployments (Docker).
- Clear communicator who thrives in a collaborative, fast-paced environment.
- Comfortable working hybrid in our Munich office.

Nice to Have:

- Experience with regulatory or compliance data.
- Experience with ML pipelines or Large Language Models (LLMs).
- Full-stack skills (React, Angular, or Vue).

**Why us?**

- A vibrant in-office culture in Munich with the option for up to 60 % work from home.
- Flexible working hours.
- 30 vacation days per year (including 4 “company rest days” over christmas).
- 30 days of "workation" per year, within the EU and selected countries.
- High autonomy and flat hierarchies.
- EGYM Wellpass for unlimited access to fitness courses and gyms.
- Udemy access for educational videos.

**Closing**

Certivity is an equal opportunities employer. We are committed to equal employment opportunities regardless of race, religion, sexual orientation, age, marital status, disability, or gender identity. Please do not submit personal data revealing racial or ethnic origin, political opinions, religious or philosophical beliefs, trade union membership, data concerning your health, or data concerning your sexual orientation.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
