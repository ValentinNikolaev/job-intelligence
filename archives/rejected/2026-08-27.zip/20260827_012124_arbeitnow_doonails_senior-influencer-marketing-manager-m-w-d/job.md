# Senior Influencer Marketing Manager (m/w/d)

Posted: 2026-08-26T23:04:53Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**Hi, wir sind Doonails! 💅🏼**

Ein schnell wachsendes Beauty-Startup, das die Manikürewelt revolutioniert. Mit innovativen Produkten, einer starken Community und Präsenz im Online-Shop sowie bei führenden Retail-Partnern bringen wir Studio-Qualität direkt nach Hause, einfach, schnell und stilvoll.

Und genau hier kommst **DU** ins Spiel.

Um unsere Brand auf das nächste Level zu heben, suchen wir
einen **Senior Influencer Marketing Manager (m/w/d)** mit E-Commerce-Power und echter Leidenschaft für die Beauty-Branche.

**Deine Rolle & dein Impact ⚡️**

In dieser Position übernimmst du die operative Steuerung, Strategie und Weiterentwicklung unserer Influencer-Marketing-Aktivitäten im DACH-Raum. Mit einem eigenen monatlichen Budget setzt du performance-orientierte Kampagnen zielgerichtet um und bist das verbindende Element zwischen Creators, unserem Marketing-Team und der Brand Doonails.

**Deine zentralen Aufgaben 👩‍💻👨‍💻**

**Sourcing**

- Du scoutest eigenständig relevante Creator und triffst die Auswahl auf Basis von Brand Fit und Zielgruppe.

**Netzwerk**

- Du hältst den Kontakt zu Kooperationspartner:innen aktiv und entwickelst belastbare, langfristige Partnerschaften.

**Verhandlung**

- Du führst Preisverhandlungen und schließt Kooperationen selbstständig ab.

**Kampagnensteuerung & Budgetverantwortung**

- Du bist verantwortlich für Planung, Umsetzung und laufende Optimierung performanceorientierter Creator-Kampagnen und steuerst dabei dein eigenes monatliches Budget eigenverantwortlich.

**Reporting**

- Du wertest Kooperationen anhand relevanter Kennzahlen aus und leitest daraus Optimierungsmaßnahmen ab.

**Das bringst du mit 🤝**

- **Erfahrung:** Mindestens 2–4 Jahre Berufserfahrung im performancegetriebenen Influencer Marketing auf Brand- oder Agenturseite (idealerweise im E-Commerce und Beauty-Bereich).

- **Budget-Kompetenz: **Erprobter Umgang mit großen Budgets sowie ein starkes Zahlenverständnis.

- **Plattform- & Tool-Skills:** Fundiertes Know-how auf Instagram (TikTok & YouTube von Vorteil) sowie sicherer Umgang mit gängigen Influencer Marketing Tools (z.B. Storyclash, Linkster). Erste Erfahrungen mit AI-Tools sind ein Plus!

- **Netzwerk:** Idealerweise ein eigenes Netzwerk, das du direkt aktivieren kannst.

- **Ownership: **Hohes Maß an Eigenverantwortung, Hands-on-Mentalität und Organisationstalent

- **Kommunikation: **Sehr gute Deutsch- und Englischkenntnisse in Wort und Schrift.

**Deine Perspektive 📈**

Bei uns erwarten dich steile Lernkurven, große gestalterische Freiheit und ein dynamisches Team, das die Beauty-Welt neu denkt. Du übernimmst von Tag 1 echte Verantwortung und prägst das Wachstum einer der spannendsten D2C-Marken direkt mit.

**Was wir dir bieten 💝**

-

💸 Faire Bezahlung, angepasst an deine Qualifikation & Erfahrung

-

🤝 Ein echtes Ownership-Rollenprofil mit viel Vertrauen & Gestaltungsspielraum

-

🇪🇺 100 % Remote in Deutschland: arbeite flexibel von überall

-

📈 Wachstumspotenzial: übernimm Verantwortung & bring deine Ideen direkt ein

-

📚 1.300 € Weiterbildungsbudget pro Jahr für deine persönliche Entwicklung

-

🧘 Nilo Health, denn mentale Gesundheit ist uns wichtig und dein Zugang ist inklusive

-

💪🏼 Urban Sports Mitgliedschaft

-

💼 Co-Working-Space oder Homeoffice-Ausstattung? Wir übernehmen die Kosten!

-

🥳 Teamevents in ganz Europa, weil ein starkes Team alles ist

**Ready? Wir freuen uns auf dich! ✨**

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
