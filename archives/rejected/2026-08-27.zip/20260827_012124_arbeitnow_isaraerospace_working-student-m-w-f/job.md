# Working Student (m/w/f)

Posted: 2026-08-26T20:55:09Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**Mission Brief
**As a Working Student in Integrated Planning, you will support our team in coordinating and continuously improving production planning processes. You will contribute to the digitalization of our rocket production, help create transparency across planning activities and support the successful execution of our production plans.**
**

Your Role in Our Space Mission:

-

Support the Integrated Planning team in production planning and the coordination of activities across production teams

-

Contribute to the digitalization and continuous improvement of our internal rocket production processes

-

Support the implementation of systems and processes for tracking and recording production times

-

Collect, maintain and analyse production- and planning-related data and KPIs

-

Assist in analysing production processes, identifying improvement opportunities and deriving actionable recommendations

-

Support the development and maintenance of integrated production plans, schedules and planning tools

-

Help monitor planning risks, follow up on mitigation actions and support their implementation

-

Contribute to cross-functional projects, such as the further development of our Manufacturing Execution System

-

Prepare reports, presentations and decision-making materials for the Integrated Planning team

**Qualification Checklist **

****

-

Currently enrolled in a relevant bachelor’s or master’s degree (e.g. Industrial, Mechanical, Information or Aerospace Engineering)

-

IT affinity and enthusiasm for new space

-

Previous internship or working student position in fast-paced environments is desirable

-

Located in or near Munich as the job requires on site work

-

Fluency in German and English

****

**Benefits**

- **Subsidised lunch:** Stay energised with delicious, subsidised lunches every day

- **Public transport ticket:** Commute with ease using a fully financed Deutschlandticket

- **Sport Clubs membership:** Stay fit with our sponsored sports club memberships (EGYM Wellpass)

- **Free snacks and drinks:** Indulge in a variety of free snacks and beverages to keep you fuelled throughout the day

- **Physical and mental well-being:** Access via OpenUp the online support from certified psychologists and lifestyle experts at no cost to you and your family

- **And Much More!** Discover additional perks and benefits when you join our team.

**Who we are**

****

We are Isar Aerospace and we are at the forefront of New Space building a modern space business to enable faster, better and cheaper access to space.

Our mission is to help democratise space and use it for good in order to improve life on Earth now and for the future generations.

We are a fast-growing company aiming to provide sustainable and environmentally friendly launch solutions for small and medium-sized satellites and constellations into Low Earth Orbit. The company is privately funded by world-leading technology investors with strong commitment and support and our team is made of driven and talented people with a real passion for space innovation.

We're making rockets in a way that hasn't been done before disrupting a traditional industry. If you are up for the challenge, want to work on cutting-edge projects and be part of a team changing the world for better, come, join us and launch your career!

Want to find out more about us?

Visit [www.isaraerospace.com](http://www.isaraerospace.com/)

**Data Protection
**We process your personal data for the purpose of managing the recruitment process and assessing your application. For detailed information on how your data is processed, including your rights, please refer to our [Privacy Policy](https://isaraerospace.com/privacy-policy).

**Disclaimer
**Isar Aerospace SE is an equal-opportunity employer committed to fairness and inclusivity. We do not prioritize any specific religion, gender, nationality, or background. Due to security clearance requirements, affiliations with countries listed under § 13 para. 1 no. 17 SÜG may affect the application process. All qualified applicants are encouraged to apply.

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
