# SOC Architect - Chiplet

Posted: 2026-08-26T14:55:22Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Tenstorrent is leading the industry on cutting-edge AI technology, revolutionizing performance expectations, ease of use, and cost efficiency. With AI redefining the computing paradigm, solutions must evolve to unify innovations in software models, compilers, platforms, networking, and semiconductors. Our diverse team of technologists have developed a high performance RISC-V CPU from scratch, and share a passion for AI and a deep desire to build the best AI platform possible. We value collaboration, curiosity, and a commitment to solving hard problems. We are growing our team and looking for contributors of all seniorities.

The Architecture team at Tenstorrent is designing the central compute chiplet that powers our next generation automotive SoC. This role is about turning real world automotive and safety requirements into architecture that performs, scales, and ships fast and reliably. If you think silicon design should start with clarity and end with confidence, this is where your experience makes the biggest impact.

*This role is remote, based in Munich, Germany.*

*We welcome candidates at various experience levels for this role. During the interview process, candidates will be assessed for the appropriate level, and offers will align with that level, which may differ from the one in this posting.*

**Who You Are**

- Approach design with a systems mindset, always thinking in trade offs, not just specs and block diagrams.

- Bring deep knowledge of SoC architecture, from interconnects and I/O to memory and CPUs.

- Confident working within performance, power, and reliability constraints.

- Familiar with, or eager to dive into, functional safety, ISO 26262, and automotive grade design challenges.

**What We Need**

- Someone to architect and specify one or more chiplets in the robotics and automotive family.

- 5+ years of experience translating high level requirements into detailed architectural direction.

- Ability to identify impactful features that boost PPA, safety, and reliability, without adding unnecessary complexity.

- Willingness to collaborate across design, verification, software, and systems teams to keep execution moving.

**What You Will Learn**

- What it takes to architect a chiplet based SoC for automotive applications.

- How functional safety and reliability shape every design decision.

- How to integrate complex IP blocks and CPU subsystems into a coherent, shippable product.

- Why silicon architecture is a cross functional discipline, not just a collection of isolated blocks.

*Tenstorrent offers a highly competitive compensation package and benefits, and we are an equal opportunity employer.*

*This offer of employment is contingent upon the applicant being eligible to access U.S. export-controlled technology. Due to U.S. export laws, including those codified in the U.S. Export Administration Regulations (EAR), the Company is required to ensure compliance with these laws when transferring technology to nationals of certain countries (such as EAR Country Groups D:1, E1, and E2). These requirements apply to persons located in the U.S. and all countries outside the U.S. As the position offered will have direct and/or indirect access to information, systems, or technologies subject to these laws, the offer may be contingent upon your citizenship/permanent residency status or ability to obtain prior license approval from the U.S. Commerce Department or applicable federal agency. If employment is not possible due to U.S. export laws, any offer of employment will be rescinded.*

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
