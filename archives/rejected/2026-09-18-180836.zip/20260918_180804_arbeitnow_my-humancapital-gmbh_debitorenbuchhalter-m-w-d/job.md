# Debitorenbuchhalter (m/w/d)

Posted: 2026-09-18T17:00:34Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**Debitorenbuchhalter (m/w/d) gesucht – Vollzeit | München | Homeoffice-Möglichkeit**

Im Auftrag unseres Partnerunternehmens aus dem Öffentlichen Dienst suchen wir Sie zum nächstmöglichen Zeitpunkt als **„Debitorenbuchhalter (m/w/d)“.**

## **Aufgaben**

- Sie erstellen Ausgangsrechnungen und Gutschriften und sorgen für eine termingerechte Abwicklung

- Sie pflegen Debitoren- und Stammdaten sowie buchhaltungsrelevante Informationen in SAP

- Darüber hinaus übernehmen Sie Aufgaben im Forderungsmanagement und klären offene Posten

- Sie unterstützen bei Monatsabschlüssen sowie der Erstellung von Auswertungen und Reportings

- Zusätzlich arbeiten Sie eng mit internen Fachbereichen zusammen und tragen zu effizienten Buchhaltungsprozessen bei

## **Qualifikation**

- Sie verfügen über eine abgeschlossene Ausbildung als Steuerfachangestellter (m/w/d), Industriekaufmann (m/w/d), Kaufmann für Büromanagement (m/w/d) oder über eine vergleichbare Qualifikation im Finanz- oder Rechnungswesen

- Idealerweise bringen Sie Berufserfahrung als Debitorenbuchhalter (m/w/d), Finanzbuchhalter (m/w/d), Sachbearbeiter Debitorenbuchhaltung (m/w/d) oder Accountant (m/w/d) mit

- Erforderlich sind fundierte Kenntnisse in der Debitorenbuchhaltung sowie mindestens drei Jahre Berufserfahrung

- Zusätzlich verfügen Sie über gute Excel-Kenntnisse sowie Erfahrung im Umgang mit SAP

- Wichtig sind eine strukturierte Arbeitsweise, Teamfähigkeit sowie eine hohe Ergebnis- und Serviceorientierung

## **Benefits**

- **Work-Life-Balance**: Flexible Arbeitszeiten mit anteiliger Homeoffice-Möglichkeit

- **Sicherheit**: Langfristige Jobmöglichkeit bei einem krisensicheren Arbeitgeber im Öffentlichen Dienst

- **Moderner Arbeitgeber**: Das Unternehmen bietet Ihnen ein innovatives Arbeitsumfeld

- **Team**: Sympathische Kollegen, flache Hierarchien und schnelle Entscheidungswege

- **Entwicklung**: Firmenintern gibt es zahlreiche Weiterbildungs- und Entwicklungsmöglichkeiten

**Sie finden das Stellenprofil interessant?** Dann senden Sie uns einfach Ihre Unterlagen (Lebenslauf und Zeugnisse) zu. Für Rückfragen steht Ihnen **Simon Schneider** gerne unter **089 954 287 111** zur Verfügung.

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
