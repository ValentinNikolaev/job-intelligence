# Retail Team Lead (Berlin Flagship Store)

Posted: 2026-09-18T14:30:27Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**Join Tylko, Where Design Meets Technology**

Founded in Warsaw, Poland, in 2015, **Tylko **is redefining how we design, shop for, and experience furniture. Frustrated by mass-produced, one-size-fits-all solutions, the team created something smarter: bespoke storage that balances cutting-edge technology, premium craftsmanship, and sustainable production.

With millimetre-perfect precision, every piece is **made-to-order and crafted locally**, minimising waste and maximising longevity. The result? A new standard in furniture – one that fits your space, your style, and your life.

**Why It Matters**

We’re not just building furniture. We’re changing how people think about living with it. By merging technology and design, we help people create spaces that truly reflect who they are. If you believe that good design can make everyday life better, you’ll feel right at home here.

**How We Work**

We believe in small teams, big ideas, and simple processes. No endless paperwork, no silos. Just open communication, shared goals, and a healthy dose of curiosity. **We start small, think big, and move fast, because progress always beats perfection**.

At Tylko, collaboration and trust aren’t buzzwords — they’re how we work. From day one, you’re part of a team that makes real decisions and brings them to life together. You’ll have the freedom to share ideas, turn them into action, and shape the space around you literally. Here, learning isn’t a bonus. It’s part of the job.

**AI is part of how we work - it's not an add-on here**. We treat it like any other tool worth knowing: it helps us think, decide, and move faster. We're not looking for people who "know AI" - we're looking for people curious enough to rethink how they work altogether. You don't need to be an expert on day one - you need the drive to grow.

**About the Role**

As our Retail Team Lead at the Berlin Flagship Store, you’ll play a key role in creating a **high-performing team and an exceptional customer experience**. Working closely with the Store Manager, you’ll turn our commercial and operational goals into everyday results - inspiring the team, driving sales performance, and making sure every customer leaves with a great impression.

You’ll be a hands-on leader who brings energy to the team, sets the standard for excellent service, and helps every team member perform at their best. From hitting daily targets to creating a welcoming, inspiring in-store experience, you’ll have a direct impact on both our people and our business.

**What You’ll Do**

You’ll take ownership, make things happen, and see your impact. Specifically, you will:

-

Drive active selling on the floor to consistently achieve daily sales targets

-

Support the Store Manager in motivating the retail team to achieve daily sales, service, and operational objectives

-

Communicate priorities, targets, procedures, and feedback clearly to ensure the team remains aligned

-

Coach team members through regular feedback, on-the-job training, and individual development

-

Ensure efficient and continuous store operations, stepping up during the Store Manager's absence

-

Assist in implementing visual merchandising guidelines, product displays, and promotions

-

Oversee inventory management tasks including stock counts, replenishment, and loss prevention

#### **What we offer for this particular role**

-

A chance to shape Tylko’s flagship retail presence and influence our physical retail strategy

-

Competitive salary with performance-based bonus

-

Employee discount on Tylko products

-

Inspiring work environment in the heart of Berlin

-

Opportunity to grow within a fast-scaling European design brand

-

Access to training, development, and cross-team collaboration with HQ

**What we’re looking for**

-

+2 years of **experience in retail or gastronomy**, with a strong understanding of **sales and KPI management**

-

**Passion for design, furniture, and architecture** - supported by studies or strong personal interest

-

Excellent communication skills in **German** and **English** - approachable and confident - able to quickly build trust, understand customer needs, and offer thoughtful, personalised design advice

-

Skilled at **explaining technical product details in a simple, engaging, and passionate way**

-

Expertise in **retail operations**, encompassing opening/closing procedures, cash handling, inventory management, and compliance

-

Solid understanding of **customer service procedures**, handling complaints, returns, escalations, and service recovery

-

Hands-on experience in **visual merchandising** and delivering structured operational **training to team members**

-

Comfort in using POS systems, retail technology, scheduling tools, and CRM systems

-

**Readiness for stationary and shift work at our Berlin store**

**Ready to Design the Future with Us?**

If you’re looking for a place where your ideas matter, your curiosity is fuel, and your work has real impact — let’s talk. Join Tylko and help us make furniture smarter, homes happier, and everyday life a little more beautiful.

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
