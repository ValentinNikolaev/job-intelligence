# Junior Complaints & Compliance Specialist

Posted: 2026-09-18T14:55:16Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

# Complaints and Compliance Specialist

**Location:** Berlin (office first, full-time)

## The team

The Complaints team sits within Operations and works every day to make sure merchants who run their businesses on SumUp get fair, fast, and compliant resolutions whenever something goes wrong with a payment. As payment volumes grow, so does the complexity of the cases the team handles, from delayed payouts to disputed chargebacks, and this role exists to build the specialist skills needed to resolve these cases with precision and care. Joining now means learning the mechanics of payment processing from the ground up, working closely with Payment Operations, Risk, Engineering, and Finance, and helping shape how SumUp responds to some of its most sensitive merchant and regulatory moments.

## What you'll do

- Investigate and resolve merchant complaints tied to payment processing, including authorisations, settlements, payouts, and chargebacks

- Dig into processor logs, payment gateways, and payout systems to find the root cause of each issue and document the findings clearly

- Draft clear, compliant final responses to merchants that meet regulatory timelines and internal SLAs

- Work closely with Payment Operations, Risk, Engineering, and Finance to unblock complex cases

- Keep case documentation audit ready and flag emerging patterns or recurring issues to the wider team

- Contribute to playbooks and knowledge base articles that help the team resolve future cases faster

## You'll be great for this role if...

- Foundational understanding of payment processing, covering authorisations, settlements, payouts, and basic chargebacks

- Comfort working with a CRM or ticketing system, following SOPs, and keeping precise, audit ready documentation

- Strong written communication skills, with the ability to draft clear, customer friendly responses under regulatory constraints

- Ability to stay structured and calm under pressure, prioritising cases against strict deadlines and escalating appropriately

- Fluency in English and German, since this role involves communicating with merchants and stakeholders in both languages

## Why you should join SumUp

🌎 Opportunity to work with SumUppers globally on large-scale fintech products used by millions of businesses worldwide, from our Berlin office. This involves an office-first setup🌈 Commitment to Diversity and Inclusion: be part of a workplace that values and promotes diversity, fostering an inclusive environment where everyone's perspectives are respected and embraced📚 A dedicated annual L&D budget of €2000 for your individual development, which can be used to attend conferences and/or advance your career through further education💶 A corporate pension scheme where we match up to 20% of your contributions🏖 Generous time off: enjoy 28 days of paid leave plus public holidays and special leave days🎁 Numerous other benefits such as Urban Sports Club subsidy, Kita placement assistance, subsidised office lunches🌴 Break4me: 1-month sabbatical after 3 years of service🔗 Referral Bonus: earn additional rewards by referring talented individuals to join the SumUp team

## About SumUp

Be empowered to do more that matters.

At SumUp, we're on a mission to empower small businesses across the globe by providing simple and affordable tools that allow them to thrive. Today, over 4 million businesses in 38 markets rely on SumUp as their financial partner to manage payments, finance and customer relationships.

Our commitment to small businesses is reflected in [our diverse team](https://youtu.be/9DG64C3moeQ?si=YpcWuBNBTOQPzeLI) of over 3,000 SumUppers from over 90 nationalities, united by global collaboration and an innovative mindset. [Our core values](https://www.sumup.com/careers/culture/) lay the foundation for who we are and what we stand for, shaping our work culture and driving our success. We foster inclusivity and a continuous learning culture, providing a safe space for personal and professional growth. Our differences make us unique and strong as we strive to create an environment where everyone belongs and feels supported, no matter how they identify.

SumUp is proud to be an Equal Employment Opportunity employer, actively seeking and embracing diversity in our workforce. We don't make hiring or employment decisions based on race, colour, religion or religious belief, ethnic or national origin, nationality, sex, gender, gender identity, sexual orientation, disability, age or any other basis protected by applicable laws or prohibited by company policy. Our commitment extends beyond recruitment to creating a safe and respectful workplace where harassment of any form is strictly prohibited. Discover more about our culture and opportunities on our [careers website](https://www.sumup.com/careers/), and follow our journey on [LinkedIn](https://www.linkedin.com/company/sumup/), [Instagram](https://www.instagram.com/insidesumup/), and

**Job Application Tip**

We recognise that candidates feel they need to meet 100% of the job criteria in order to apply for a job. Please note that this is only a guide. If you don’t tick every box, it’s ok too because it means you have room to learn and develop your career at SumUp.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
