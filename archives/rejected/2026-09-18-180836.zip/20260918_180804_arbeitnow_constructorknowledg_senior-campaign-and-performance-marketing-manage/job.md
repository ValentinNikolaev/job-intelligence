# Senior Campaign and Performance Marketing Manager

Posted: 2026-09-18T14:55:03Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

### About Constructor

[Constructor](https://constructor.org/) is an international ecosystem spanning education, research, and technology. It includes [Constructor University Bremen](https://constructor.university/), Constructor Tech, [Constructor Knowledge](https://constructor.org/knowledge), and partner entities such as EBAC, working together to advance how knowledge is created, taught, and applied.

[Constructor Knowledge](https://constructor.org/knowledge) sits at the heart of this ecosystem — connecting students, faculty, partners, media, and industry across our entities and programmes.

### About the Role

We're looking for a hands on Senior Marketing Manager to own campaign strategy and execution across our multi channel, multi platform marketing operations. This is not a strategy only or purely managerial role; we need someone who can plan a campaign from scratch, build the tracking and data infrastructure behind it, and execute alongside the team. Strong technical fluency, structured thinking, and a bias toward doing over discussing are essential, along with the confidence to present campaign strategies and budgets to stakeholders and defend them.

### Key Responsibilities

**Campaign Strategy & Execution**

- Build multi channel, multi platform campaign and marketing plans from the ground up: audience, budget, channel mix, creative direction

- Execute hands on across performance channels (Google, Meta, LinkedIn, TikTok, etc.), not just oversee execution

- Run and interpret A/B tests, budget allocation, and continuous optimization

- Plan and adapt campaigns across international markets, different countries, audiences, and budgets, spanning both B2B and B2C contexts

**Technical & Data Infrastructure**

- Set up and maintain campaign tracking (pixels, UTMs, attribution) across platforms

- Contribute to building data warehouse / reporting infrastructure for campaign and budget analytics across channels

- Own reporting dashboards and translate data into clear, actionable recommendations

**Creative & Brand**

- Bring a strong eye for design; able to produce basic ad creatives independently, not just brief a designer

- Ensure creative and messaging consistency across campaigns and channels

**Cross-Functional Ownership**

- Propose and take ownership of campaign plans and marketing initiatives with minimal oversight

- Collaborate with a wide range of requesters and stakeholders: management, design, CRM, website, PR, events, and student recruitment teams, among others

- Adapt quickly to shifting priorities typical of a startup or scale up environment

### Requirements

- 5+ years in performance marketing / campaign management, ideally with agency experience

- Demonstrated hands on technical skill: platforms management (Google, Meta, LinkedIn, TikTok, etc.), tracking setup, analytics, data infrastructure for campaign reporting

- Experience working in startups or small, fast-moving teams; comfortable with ambiguity and multitasking

- Experience running international campaigns across multiple countries/continents simultaneously, and working in a multicultural, cross-country team environment

- Strong structured, analytical mindset; execution oriented over purely conceptual

- Basic creative production skills (Canva, CapCut, Figma, or similar)

- Self-driven learner who stays current on marketing technology and industry trends independently.

### What we offer

- A central role in a growing international ecosystem connecting education, research, and technology.

- Direct exposure to senior leadership, world-class academics, and international partners.

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
