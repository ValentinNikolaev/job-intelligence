# Social Client Solutions Manager (Paid social/ Meta Ads)

Posted: 2026-09-18T14:20:04Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**Job Title:** Social Client Solutions Manager, DACH

**Location:** Hamburg (Primary) or Munich (Secondary)

**Who We Are: **Channel Factory provides intelligent marketing solutions for the next generation of contextual safety, suitability, and performance for brands and agencies. Our platform helps marketers implement, automate, and scale their marketing programs across the world’s largest video library, YouTube, and emerging growth channels. We sit at the intersection of marketing and suitability with a mission of enabling the world’s top brands to consciously connect with the right audience in the right context.

**About the Role:** As a Social Client Solutions Manager, you will manage day-to-day client relationships and execute paid social media initiatives across our DACH portfolio. This role focuses on operational excellence, campaign optimization, and reliable client service. Rather than acting as a high-level strategic consultant on day one, you will leverage your hands-on platform knowledge to run successful campaigns, deliver clear performance insights, and support account growth. You will receive ongoing coaching and mentorship from regional leadership to continuously develop your client-facing presentation and consultative skills.

**Key Responsibilities**

- **Campaign Execution & Optimization:** Plan, launch, monitor, and optimize paid social campaigns to hit client KPIs, maintaining high operational quality across pacing and delivery.
- **Client Service & Support:** Serve as the main point of contact for day-to-day client queries, offering practical solutions and translating performance data into actionable recommendations.
- **Account Management:** Support client retention and growth by managing renewals, supporting account strategies, and identifying potential cross-sell or upsell opportunities.
- **Reporting & Insights:** Deliver clear post-campaign reporting, detailing campaign highlights, performance metrics, and future recommendations.
- **Internal Collaboration:** Partner closely with internal teams to streamline client onboarding, campaign setups, and knowledge-sharing on platform updates.

**What You Bring**

- **Experience:** Minimum of 2+ years of hands-on experience in Paid Social, campaign management, or performance marketing (agency experience within Social or Media teams preferred).
- **Platform Expertise:** Solid hands-on experience with Meta advertising platforms is essential. Experience with TikTok, Reddit, Snapchat, or LinkedIn is a strong bonus.
- **Operational Track Record:** Proven background in managing, optimizing, and reporting on paid social campaigns.
- **Client Readiness:** Strong communication skills with a desire to work directly with clients and grow your account management abilities.
- **Languages:** Fluency in German and strong proficiency in English. Additional languages are a plus.
- **Location:** Must be based in (or willing to relocate to) Hamburg or Munich.

**What You Get**

- 💰 Competitive salary + performance-based bonus scheme
- 🌴 30 days of paid holiday
- ✈️ Work-abroad allowance across any of our EMEA locations (in line with company policy)
- 💻 Brand new MacBook + 📱 iPhone with company-paid phone contract
- ☀️❄️ Summer & Winter company conferences across EMEA to connect with global teams
- 🩺 Comprehensive healthcare coverage
- 🌍 International environment with global career growth paths

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
