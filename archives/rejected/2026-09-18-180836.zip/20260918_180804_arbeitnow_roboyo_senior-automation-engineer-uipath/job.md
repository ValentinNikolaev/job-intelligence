# Senior Automation Engineer - UiPath

Posted: 2026-09-18T14:55:15Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**Roboyo AI is a category shaper in Applied AI and Agentic Automation. **We help leading enterprises move from automation projects and AI experiments into governed, production-grade systems that execute real work across workflows, processes, products and services.

Our heritage is in scaled enterprise automation; our future is Applied AI and Agentic Automation: autonomous agents, AI engineering squads, process orchestration, data and knowledge foundations, and human-in-the-loop governance embedded deeply into how our clients operate.

We are not here to sell AI theatre. We are here to turn AI into working systems, measurable outcomes and repeatable transformation programs.

**About the role**

We're looking for a Senior Automation Engineer to own the technical delivery of UiPath automation workstreams end-to-end — from design and development through testing and deployment — working with international clients across a distributed, global delivery environment.

**Responsibilities and tasks for this role **

- Design, develop, and deploy complex, scalable Intelligent Automation solutions using advanced UiPath capabilities, integrating with various APIs, databases, and enterprise systems.

- Act as a technical guide for junior and mid-level automation engineers within your pod. Assist the Tech Lead with rigorous peer code reviews to enforce coding standards and reusability.

- Discover, estimate and deliver Agentic AI solutions implementing the UiPath suite effectively.

- Actively participate in the CI/CD pipeline, writing and executing automated unit and integration tests to ensure flawless deployments and mitigate production risks.

- Take the lead on diagnosing and resolving complex technical defects, optimising performance bottlenecks, and stabilizing processes before handoff to support teams.

- Stay up to date on industry trends and best practices, and continuously improve consulting service offerings

**Must-have qualifications & competencies**

- 3+ years of hands-on experience in Intelligent Automation software engineering, with deep, demonstrable expertise in developing complex workflows in UiPath.

- Strong proficiency with UiPath Studio, Orchestrator, and REFramework

- UiPath Advanced RPA Developer certification

- Solid experience with Action Center, Coding agents and proven expertise in building Agentic AI solutions also leveraging Maestro

- Exceptional analytical skills with the ability to reverse-engineer legacy processes and design elegant, efficient modern architectures.

- Strong ability to articulate technical challenges and solutions clearly to both technical peers and project management.

**Nice to have qualifications & competencies**

- Exposure to consulting environments or client-facing roles

- Python coding skills or willingness to grow technical capabilities

- Interest in upskilling in related technologies such as process mining (e.g., Celonis, UiPath Process Mining), low-code platforms (e.g., Power Apps), conversational AI (e.g., Cognigy, Druid), or test automation (UiPath Test Suite)

- Experience in Automation Anywhere, Power Automate

**What we offer**

- Tailored development plan with career coaching

- Regular feedback – we value your opinion, and we appreciate new ideas

- International career and project opportunities

- Deepen your working knowledge of intelligent automation through our structured training courses

- Immerse yourself in an exciting, positive, and creative atmosphere and generate novel solutions to some of our client's most complex challenges

- Work in different international and cross-cultural teams for each project

We are an equal opportunity employer and value diversity at our company. We do not discriminate on the basis of race, religion, color, national origin, gender, sexual orientation, age, marital status, veteran status, or disability status.

**Privacy Notice:** By applying, you consent to the processing of your personal data for recruitment purposes in line with our Privacy Policy: [https://roboyo.global/data-privacy/](https://roboyo.global/data-privacy/)

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
