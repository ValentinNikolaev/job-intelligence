# Expert Solution Architect, AI & Enterprise (all genders)

Posted: 2026-09-18T14:40:05Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

## **About the Role**

You'll own the path from a corporate client's business problem to a target architecture the CIO signs and the CFO funds. Not one platform, the whole picture: CRM, data, integrations, custom software, and the agentic AI layer on top. You'll lead discovery with enterprise clients, structure what they actually need, design the solution, defend it in the steering committee, and hand delivery a scope that holds. This is an Expert seat: the architecture benchmark of our Consulting Practice, no people management.

## **What You'll Do**

-

**Lead** discovery and solution design on our enterprise engagements, turning ambiguous business problems into signed target architectures across CRM, data, custom software, and agentic AI

-

**Own** the architecture through delivery, so what you design in pre-sales is what gets built, without structural redesigns after signature

-

**Scope** six-figure engagements with estimates that hold, phasing that corporate procurement can sign, and risks named up front

-

**Build** the team's Solution Design Toolkit: discovery framework, architecture decision template, and an honest agentic-fit assessment that says where agents add value and where they don't

-

**Present** and defend architectures in front of CIOs, CFOs, and business unit heads, in German and English

-

**Create** reusable solution patterns (master data ownership between CRM and ERP, agent orchestration on HubSpot, data remediation before AI) that consultants and engineers actually use

-

**Partner** with our AI & Engineering Practice as the architecture counterpart: you own the solution design, they own the technical blueprint and the build

## **What You Bring**

**Must-haves**

-

6+ years in consulting or solution architecture, with at least 2 years personally owning solution design for enterprise clients on the advisory or vendor side, from discovery to signature

-

A track record of structuring ambiguous business problems into architecture options, scope, and risk, with artefacts you produced yourself and can walk us through

-

Architecture-level fluency across at least one enterprise CRM (HubSpot, Salesforce, or Dynamics), one ERP (SAP or Dynamics), data platforms (warehouse, CDP, or MDM), and integration patterns (event-driven, API, iPaaS or middleware)

-

At least one AI or agentic solution you designed or delivered that ran in production for a client, with business outcomes you can name and failures you can explain

-

Experience leading conversations with CIO, CFO, procurement, IT security, and business stakeholders inside corporate groups, including telling an executive no with a case behind it

-

Commercial judgment on scoping and estimating engagements, and ownership when estimates miss

-

German and English at full business fluency, with the ability to present the same architecture to a CFO and to a delivery team

**Nice-to-haves**

-

Hands-on HubSpot enterprise experience or HubSpot Solutions Architect certification (we fund it if you don't have it)

-

Direct experience with EU AI Act and DSGVO as design constraints in regulated industries (manufacturing, financial services, healthcare)

-

A background in one of our core client sectors: industrial manufacturing, building products, or B2B distribution

-

Talks, articles, or teaching on enterprise architecture or applied AI

## **Your Team**

You'll join the Strategy Consulting team within Thorit's Consulting Practice, which owns the strategy layer of our engagements. The Team Lead Strategy Consulting seat is currently open, so you'll report directly to the Practice Lead Consulting until it is filled. Day to day you'll work with our CRM Implementation and Managed Services teams, the Project Management Practice, and the AI & Engineering Practice in Böblingen and Lisbon, which builds what you design. Our company language is English.

## **Tech Stack**

-

**Core:** HubSpot (CRM, Marketing, Sales, Service, Operations Hub), Jira, Confluence, Forecast, Claude AI

-

**Architecture & design:** architecture decision records, C4 and sequence diagrams, Miro

-

**Enterprise landscape you design against:** SAP S/4HANA, Microsoft Dynamics 365, Salesforce, data warehouses (Snowflake, BigQuery), CDP and MDM concepts, iPaaS and custom middleware

-

**AI & agents:** LLM-based agents on Claude and other models, retrieval, orchestration frameworks, evaluation and guardrails; the engineering team builds with Claude Code and Cursor

## **What We Offer**

-

**31 days of paid vacation:** 30 days plus one additional company day each year, well above the German statutory minimum of 20

-

**Company pension (Allianz):** employer contribution from your second year, rising with tenure from €50 to €290 per month

-

**Lunch allowance:** €5 tax-free per working day via Lunchit, up to €100 per month, usable anywhere

-

**Business Bike:** bicycle leasing through payroll with full insurance and free brand choice

-

**Corporate Benefits:** discounts across several hundred brands for private use

-

**Hybrid Flex model:** two office days per week at our Böblingen HQ, the rest where you work best

-

**Real ownership:** direct client leadership on enterprise engagements, and a Practice that builds and operates agentic systems rather than presenting them

## **About Thorit**

Thorit is the AI & CRM consultancy for the agent-native enterprise. Agentic means software agents that act on goals instead of waiting for clicks; for an enterprise, that translates into less manual work and more margin. As a Diamond HubSpot Partner we work with enterprise B2B clients across the DACH market, building the agent layer on top of HubSpot and the systems around it, then operating it with them.

## **Ready to Apply?**

Send your application via Ashby. A cover letter is optional, but a concrete example of an enterprise engagement where you personally took a client's business problem through discovery to a signed target architecture, including what you scoped, what you told the client not to build, and how far delivery deviated from your design, is required.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
