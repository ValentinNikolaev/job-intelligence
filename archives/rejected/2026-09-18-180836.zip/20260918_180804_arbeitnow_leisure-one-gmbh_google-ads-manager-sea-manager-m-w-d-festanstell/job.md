# Google Ads Manager - SEA Manager (m/w/d) - Festanstellung Vollzeit

Posted: 2026-09-18T15:30:25Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Leisure One GmbH ist eine dynamische Agentur mit Fokus auf **Marketing, Strategie und digitales Wachstum**. Wir entwickeln kreative Kampagnen, datengetriebene Performance-Strategien und digitale Lösungen, die echte Erlebnisse schaffen.

Jetzt suchen wir **dich**, um unser Team mit deiner Expertise im **Performance Marketing** zu verstärken!

**Deine Mission**

Als **Google Ads Manager** bist du verantwortlich für die Konzeption, Umsetzung und Optimierung datengetriebener **Google Ads Strategien**. Du analysierst, testest und optimierst kontinuierlich Kampagnen, mit einem klaren Ziel: **Relevante Reichweite und messbare Ergebnisse** für unsere Kunden.

Bist Du bereit, Deine Karriere im digitalen Marketing auf das nächste Level zu heben und ein wesentlicher Teil unseres Erfolgs zu werden? Dann sende Deinen Lebenslauf und ein kurzes Anschreiben, in dem Du uns von Deiner Leidenschaft für digitales Marketing und Deinem Beitrag zu unserem Team erzählst.

## Aufgaben

- Entwicklung und Steuerung performance-getriebener Marketing-Kampagnen

- Kontinuierliche Analyse, Optimierung und Skalierung der Kampagnen anhand von KPIs & Conversion-Tracking

- Funnel-Optimierung und Budgetsteuerung A/B-Testing

- Audience-Segmentierung und datengetriebene Entscheidungen

- Enge Zusammenarbeit mit Content- und Creative-Teams für Performance-getriebene Assets

- Markt- und Wettbewerbsanalysen, um neue Trends und Strategien zu identifizieren

- Gesamtverantwortung für Tracking-Setups (u. a. Google Tag Manager, eTracker, server-side Tracking) und Sicherstellung einer sauberen Datenbasis

- KPI- und Conversion-Tracking sowie Verantwortung für die Erstellung, Pflege und Weiterentwicklung der Dashboards (Looker Studio, eTracker Dashboards, ggf. interne BI-Systeme)

## Qualifikation

- **Mehrjährige Erfahrung im Performance Marketing**, vorzugsweise in dynamischen Branchen

- **Fundierte Kenntnisse in Google Ads**

- Sicherer Umgang mit Google Analytics, GTM & Conversion Tracking, etracker

- Strategisches Denken und analytische Fähigkeiten zur Performance-Optimierung

- Kreatives Gespür für zielgruppengerechte Anzeigen & Messaging

- Erfahrung mit SEA & Retargeting-Strategien

- Hands-on-Mentalität, datengetriebener Ansatz und Lust auf eine dynamische Branche

- Deutsch als Muttersprache oder C1

## Benefits

Dein Impact & Unsere Benefits

Wir bieten dir mehr als nur einen Job – wir bieten dir den Freiraum, digitale Exzellenz in der Hospitality-Branche mitzugestalten.

- **Verantwortung ab Tag 1:** Dich erwartet eine abwechslungsreiche Schlüsselrolle in einem dynamischen Team, in dem deine Ideen nicht nur gehört, sondern aktiv umgesetzt werden.

- **Flexibilität, die zu deinem Leben passt:** Arbeite in einem modernen Arbeitsumfeld direkt im Herzen von **Hamburg-Eppendorf** oder nutze unsere flexiblen **Homeoffice-Optionen**.

- **Wachstum garantiert:** Wir unterstützen deine Karriere durch kontinuierliche Weiterbildung und attraktive Entwicklungsmöglichkeiten innerhalb des Unternehmens.

- **Innovation:** Gestalte zukunftsweisende Projekte mit und setze neue Standards im digitalen Projekt Engineering.

Deine Extras – Flexibel & Individuell

Zusätzlich zu einem attraktiven Gehalt profitierst du von einem **flexiblen Benefit-Budget**, das du ganz nach deinen persönlichen Bedürfnissen einsetzen kannst:

- **Mobilität:** Wir halten dich mobil und bezuschussen dein **Deutschlandticket** oder Jobticket für einen entspannten (und steuerfreien) Arbeitsweg.

- **Fitness & Wellness:** Dein Ausgleich ist uns wichtig. Mit dem **EGYM Wellpass** hast du Zugriff auf ein riesiges Netzwerk an Sport- und Wellness-Partnern – steuerfrei im Rahmen der Sachbezugsgrenze.

- **JobRad:** Lease dein Wunschrad bequem über uns und starte fit in den Tag – wir unterstützen dich mit einem attraktiven **monatlichen Arbeitgeberzuschuss** zur Leasingrate.

Werde ein Teil von Leisure One GmbH als Google Ads Manager (m/w/d) und gestalte die Zukunft des Online-Marketings in einem dynamischen Team mit.

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
