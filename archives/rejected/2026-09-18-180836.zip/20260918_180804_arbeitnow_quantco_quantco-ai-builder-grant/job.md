# QuantCo AI Builder Grant

Posted: 2026-09-18T14:25:19Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

QuantCo is offering up to ten AI Builder Grants to exceptional Bachelor’s and Master’s students enrolled at universities in Austria, Germany, and Switzerland. Grant recipients will receive a Max 5x subscription for Claude over five months, valued at over $500 per person to power their own AI projects, explore emerging tools, and gain exposure to state-of-the-art developments in artificial intelligence.

At QuantCo, our global teams of quants, AI and software engineers collaborate heavily with state-of-the-art AI tooling to build scalable, high-impact solutions for enterprise clients. We are introducing this grant to bridge the gap between academic environments and real-world coding best practices, helping eager students accelerate their technical skills outside the classroom. Whether you have previously competed in hackathons or are simply excited about building innovative projects, we encourage all ambitious students to apply and join us in shaping the AI transition.

To apply, please submit your CV and transcripts. We review applications on a rolling basis and will get back to you within a week of your submission. If you have any questions, please reach out to About QuantCo**

At QuantCo, we leverage expertise in data science, engineering, and economics to help organizations turn data into decisions. Started by 4 PhDs from Harvard and Stanford, we are now more than 180 professionals with extensive quantitative, engineering, and business experience. We are globally distributed with offices in Berlin, Boston, Cologne, Karlsruhe, London, Munich, San Francisco, and Zurich.

Our solutions include algorithmic pricing, data-driven claims management, and high-dimensional forecasting systems. Our customers include some of the largest financial, retail, and healthcare organizations in the US and Europe. We impact core business processes and decisions by combining advanced data-driven insights with scalable engineering solutions.

We are excited about writing mission-critical code that affects millions of people and impacts billions of dollars. If you feel the same way, we look forward to hearing from you.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
