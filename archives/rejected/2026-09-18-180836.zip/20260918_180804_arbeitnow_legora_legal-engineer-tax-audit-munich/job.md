# Legal Engineer - Tax & Audit, Munich

Posted: 2026-09-18T14:40:03Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

## About Us

Legora is redefining how legal work gets done. Not built for lawyers, built with them. We work alongside the world’s best legal teams, who expect excellence, precision, and speed, and we hold ourselves to the same bar.

Our AI-native workspace lets legal professionals move faster, think more clearly, and operate with sharper precision. By analysing thousands of documents in minutes and powering end-to-end workflows, we cut through complexity, teams can focus on what matters: judgment, strategy, and outcomes.

1,000+ customers across 50+ countries trust us, including Cleary Gottlieb, Goodwin, Linklaters, White & Case, Dentons, and Barclays. We’ve scaled to** $100M+ in ARR**, with teams across Europe, North America and APAC, and continue to expand through acquisitions including Qura, Walter AI and Graceview.

We partner with world-class performers: including Aaron Judge and the New York Yankees, Ludvig Åberg (and his caddie), and campaigns featuring Jude Law.

Joining Legora means three things.

-

We **lean in: **ownership over titles, outcomes over intentions.

-

We **fight for excellence:** high standards, direct, ego-free feedback.

-

We** grow together:** as a team and with our customers.

Mission before ego. Everyone contributes. No one coasts.

If you’re driven by impact, pace, and raising the bar. This is the place.

**What you’ll be doing**

Let's get the tricky part out of the way: this role doesn't fit neatly into a traditional box. It's part legal ops, part product specialist, part solutions architect, and part client whisperer. If you enjoy roles that stay static, this probably isn't it. Your mission is to help our clients, some of the most sophisticated tax and legal advisory teams in the world, get the absolute most out of our platform.

We are hiring for two of our teams. Our DACH team is focussed on working with Tax & Audit teams across the DACH market and our Benelux team is focussed on Tax & Audit teams across the Netherlands, Belgium and Luxembourg. Both are based out of our Munich office.

-

Acting as a thought partner to tax partners, legal advisory leaders, and consulting teams - building trusted relationships, addressing tricky pain points, and identifying high-value opportunities for them to scale their use of Legora across service lines and jurisdictions.

-

Working together with Go To Market and Customer Success in taking full ownership of client relationships - from running pilots with key practice areas, to onboarding new team members across tax, legal and consulting functions, and ultimately guiding firm-wide adoption across Big 4 and professional services firms.

-

Be the voice of tax and legal advisory users inside Legora - sharing insights from tax structuring teams, regulatory advisory practices, and legal consulting functions that directly inform product development, roadmap priorities, and strategic direction.

-

Delivering clear, confident product demos and training that bring the power of our platform to life - whether you're presenting to a tax partner, rolling out to a global advisory team, or training legal consulting professionals.

-

Documenting best practices from leading professional services firms, contribute to the development of scalable playbooks, and help shape how we grow this function globally.

-

Confidently helping tax and legal advisory teams navigate one of the biggest shifts in how professional services operate - from evaluating the ROI and competitive advantage of AI to clearly mapping how AI will impact different service lines, from tax compliance to regulatory advisory.

**What you bring**

You come from the world of tax and legal advisory; but you've never been content with how things have always been done. You may have trained at a Big 4 firm, working across tax structuring, legal advisory, or consulting. Perhaps you've specialised in legal operations, innovation, or technology implementation within a professional services environment. Maybe you've even moved into legal tech or consultancy, helping advisory teams modernise and scale. Either way, you know how tax and legal advisory teams think, work, and (sometimes) struggle and you're ready to help them level up with technology.

You'll thrive in this role if you:

-

Have a background in law or tax, with experience at a Big 4 firm or leading professional services practice gained in the DACH or Benelux market - ideally with exposure to multiple service lines, jurisdictions, or innovation initiatives.

-

Bring a fluent language skill relevant to the DACH or Benelux market (either German, Dutch/Flemish or French).

-

Are tech-curious and product-savvy. Not necessarily a coder, but passionate about navigating technical conversations, especially around things like generative AI, technology implementation, innovation and productivity.

-

Communicate clearly and confidently with diverse stakeholders, from tax partners to consulting leaders, and from lawyers to engineers. I.e. translating across disciplines is second nature to you.

-

Bring structure to ambiguity and energy to complexity; and enjoy being the calm, credible presence in a fast-moving environment.

-

Understand how to evaluate and improve existing processes as a direct result of new and emerging technologies - whether that's streamlining tax compliance workflows, enhancing regulatory analysis, or improving multi-jurisdictional advisory work.

-

Are proactive, self-directed, and comfortable juggling multiple client relationships at once.

-

Care deeply about quality, but don't get stuck in perfectionism - you get things done, and you make them better over time.

-

Understand the commercial realities of professional services: leveraging teams efficiently, demonstrating value to clients, managing complex multi-jurisdictional matters, and balancing technical excellence with commercial delivery.

**Legora is an Equal Opportunity Employer**

At Legora, we believe great teams are built on diversity of thought and experience. We’re proud to be an equal opportunity employer and committed to creating an inclusive, high-performance culture where everyone can do their best work. We welcome people of all backgrounds and don’t discriminate based on race, color, religion, national origin, gender, gender identity or expression, sexual orientation, age, disability, veteran status, or any other characteristic protected by law.

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
