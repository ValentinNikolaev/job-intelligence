# Dutch speaking Support Specialist

Posted: 2026-09-18T14:40:11Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**Hi there! Thanks for stopping by 👋**

Are you actively looking for a new opportunity? Or just checking the market? Well… you might just be in the right place!

As part of Lightspeed’s Support team, you will be the first point of contact for our customers who need assistance, helping with a wide variety of requests all the way from general education to hardware/software investigation and everything in between.

Working closely with various global teams at Lightspeed, you will investigate, troubleshoot, test and resolve issues that our hospitality customers may be facing during service.

### **What you’ll be doing:**

-

Working with a truly global, multi-language 24x7 team across APAC, EMEA and NOAM

-

Flexibility on working days and shifts (weekends included)

-

Have enthusiastic, positive and knowledgeable interactions with our Hospitality customers, partners and Lightspeed team members, maintaining Lightspeed's Gold Class standard for support via phone, chat and email.

-

Use consistent troubleshooting techniques to quickly and efficiently identify the source of customer issues and provide a prompt and appropriate solution

-

Work within our customer support platforms to document, track and resolve interactions

-

Assist with the identification, reproduction and escalation of product issues and bugs to the Quality Assurance team, tracking through to resolution with each customer, partner and Lightspeed team member

-

Advocate and promote improvements to our products and services

-

Operating within a roster/schedule to ensure high availability of our assistance for our customers (In collaboration with your manager)

**What you’ll be bringing to the team:**

-

Previous customer service experience and/or technical support Strong attention to detail with an emphasis on providing an exceptional customer experience

-

Excellent verbal and written communication skills in **Dutch & English**

-

Basic experience using common online, mobile and desktop platforms; iOS, Android, OSX, Windows

**Even better if you have, but not necessary:**

-

Experience interacting with customers through Phone, Email, Ticketing and Live Chat platforms

-

Experience or knowledge of the Hospitality industry

-

Experience supporting a SaaS product

-

Experience supporting an iOS application

-

Computer networking experience or interest

**Even better if you have, but not necessary**

-

Passion in technology;

-

Working knowledge of Mac OS and basic knowledge of HTML/CSS;

-

Hospitality experience;

-

Dutch or French written and verbal communication skills;

We know that people are more than what’s on their CV. If you’re unsure that you have the right profile for the role... hit the ‘Apply’ button and give it a try!
**Please make sure to apply with a CV in English.**

**
What’s in it for you:**

-

Unlimited Annual Leave with our PTO scheme

-

400€ annually towards Health and Wellbeing

-

Dental cover

-

Private healthcare

-

Optical cover

-

Opportunity to join a growing team, in a fast-paced, high-growth company

-

Work with a team of incredibly talented and forward-thinking people!

-

Work for a team that values hard work, and knows how to celebrate the wins

-

Amazing benefits & perks, including equity for all Lightspeeders

In short, an opportunity to learn, expand your skill set, forge wonderful relationships and make your mark within the diverse and inclusive Lightspeed family, a true Canadian tech success story.

*To all recruitment agencies: Lightspeed does not accept unsolicited agency resumes. If we have not directly engaged your company in writing to supply candidates for a specific vacancy, Lightspeed will not be responsible for any fees related to unsolicited resumes.*

*Lightspeed is a proud equal opportunity employer and we are committed to creating an inclusive and barrier-free workplace. Lightspeed welcomes and encourages applications from people with disabilities. Accommodations are available on request for candidates taking part in all aspects of the selection process.*

## **Where to from here?**

Obviously, this has to be mutually beneficial: we want you to step into a role you love, and we want to offer you a place you’re proud to come to every day. For a glimpse into our world check out our [career page here](https://www.lightspeedhq.com/careers/).

Lightspeed is building communities through commerce, and we need people from all backgrounds and lived experiences to do that. We were founded in 2005, in Montreal’s gay village and our original members were all part of the LGBTQ+ community. The ethos of our business has been about inclusion from the very beginning, and we strive to provide a workplace where everyone belongs.

## **Who we are:**

Powering the businesses that are the backbone of the global economy, Lightspeed's one-stop commerce platform helps merchants innovate to simplify, scale, and provide exceptional customer experiences. Our cloud commerce solution transforms and unifies online and physical operations, multichannel sales, expansion to new locations, global payments, financial solutions, and connection to supplier networks.

Founded in Montréal, Canada in 2005, Lightspeed is dual-listed on the New York Stock Exchange (NYSE: LSPD) and Toronto Stock Exchange (TSX: LSPD). With teams across North America, Europe, and Asia Pacific, the company serves retail, hospitality, and golf businesses in over 100 countries.

Lightspeed handles your information in accordance with our [Applicant Privacy Statement](https://www.lightspeedhq.com/legal/applicant-privacy-statement/).

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
