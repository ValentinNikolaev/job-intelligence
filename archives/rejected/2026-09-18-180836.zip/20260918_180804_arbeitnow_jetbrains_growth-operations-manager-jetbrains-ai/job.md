# Growth Operations Manager (JetBrains AI)

Posted: 2026-09-18T14:55:13Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

You enjoy turning messy signals into clear action. You look at product usage, marketing engagement, and account activity and immediately start thinking about what should happen next.

You care about building systems that help teams move faster, make better decisions, and focus on the opportunities that matter most. If you like connecting data, processes, and people to create measurable business impact, this role is for you.

## **About JetBrains**

We create intelligent software development tools for developers and teams. More than 15 million users, over 300,000 companies, and 88 of the Fortune Global Top 100 companies rely on our products to solve real, complex problems. Our mission is simple: make development teams more productive and AI adoptable at scale.

## **About the role**

We're building an AI-native platform for software development that connects developer workflows, team collaboration, and organizational governance into a single system. It will serve as the execution and control layer for AI-driven software development and is a key part of how we see the future of the industry.

As adoption grows, we're looking for someone to own the systems that connect product and marketing signals with commercial action. The goal is simple: help the right users and accounts reach the right people at the right time.

You'll own the workflow that turns product usage, marketing engagement, account activity, and buying signals into qualified opportunities. You'll work across product, marketing, sales, analytics, and operations teams to build the processes, automation, and feedback loops that help us learn faster and improve conversion over time.

This is a hands-on role with plenty of ownership. You'll help define how our commercial engine works as we build a new business around one of JetBrains' most strategic investments.

### **Your day-to-day**

- Own the end-to-end process that turns product, marketing, and account signals into qualified sales opportunities.

- Define and improve qualification criteria using product usage, engagement, intent, and commercial data.

- Build and maintain routing rules that connect signals with the right sales and SDR owners.

- Improve how quickly and effectively opportunities move from signal detection to commercial engagement.

- Maintain high-quality lead and account data through enrichment, segmentation, consolidation, and cleanup processes.

- Partner with product, marketing, sales, analytics, and operations teams to improve workflows and automation.

- Create feedback loops that connect sales outcomes with product and marketing signals.

- Identify bottlenecks in the funnel and fix them through process changes, automation, reporting, or data improvements.

- Translate business needs into clear requirements for CRM workflows, integrations, dashboards, and operational tooling.

- Measure the effectiveness of qualification, routing, and engagement processes and continuously improve them.

## **What you'll bring**

- A strong sense of ownership and a desire to improve systems rather than work around them.

- Good commercial judgment and the ability to distinguish genuine buying intent from noise.

- An analytical mindset that helps you turn data into practical decisions.

- Comfort working independently in environments where not everything is defined yet.

- A bias toward action. You like testing ideas, learning from results, and iterating quickly.

- Strong collaboration skills and the ability to build trust across different teams and functions.

- Attention to detail without losing sight of the bigger picture.

- Curiosity about how product adoption, customer behavior, and commercial outcomes connect.

## **What you'll need**

- Experience in growth operations, revenue operations, sales operations, sales strategy, or a similar role in a B2B software or technology company.

- A solid understanding of sales and marketing funnels, including qualification, Sales Development Representative workflows, account prioritization, pipeline creation, and conversion tracking.

- The ability to define qualification frameworks, routing logic, and operational processes that can be implemented and scaled.

- Experience working with CRM platforms, marketing automation tools, sales engagement platforms, enrichment tools, analytics systems, or workflow automation solutions.

- Confidence working with product usage, account, marketing, and sales data.

- The ability to translate business requirements into operational or technical solutions.

- Experience partnering closely with commercial teams and improving the processes they rely on every day.

## **What success looks like**

After your first year, the process for turning product and marketing signals into sales action is faster, clearer, and trusted by the teams using it.

Sales and SDR teams know they're receiving higher-quality opportunities. Product and marketing teams have better visibility into which signals actually predict conversion. Leadership has a clearer view of funnel performance and where to invest.

Most importantly, the system continuously improves because the feedback loops, data quality, and operational foundations are in place.

## **Why join JetBrains?**

- Strong base salary. We offer competitive pay that reflects your skills and experience.

- Flexible work location. Enjoy the freedom to work from home or from the office.

- Remote work. Spend up to 30 days per year working remotely from abroad.

- Extra time off. More days to relax, recharge, and do the things you love.

- Medical insurance allowance. Enjoy peace of mind for you and your family

- Learning and development opportunities. Access to conferences, courses, and language classes.

- Relocation support.** **We help make your move as smooth and stress-free as possible.

- Language classes. Pick up the local language or sharpen your English skills.

- Fuel your day. Enjoy a hot meal or receive a lunch allowance on workdays.

- Mental health support. To help you feel your best, we provide easy access to professional mental health services.

- Sports benefit. Enjoy an on-site gym or sports club stipend.

- Internal events. Join company-wide celebrations and team gatherings.

*Some benefits may vary depending on location.

#LI-HYBRID
#LI-JP1

**We are an equal opportunity employer**

We know great ideas can come from anyone, anywhere. That’s why we do our best to create an open and inclusive workplace – one that welcomes everyone regardless of their background, identity, religion, age, accessibility needs, or orientation.

*We process the data provided in your job application in accordance with the [Recruitment Privacy Policy.](https://www.jetbrains.com/legal/docs/privacy/privacy-recruitment/)*

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
