# Director of Field Operations (f/m/d)

Posted: 2026-09-18T14:40:13Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**We see the potential inside everything and everyone. Starting with you.**

Orbem uses AI to industrialize MRI, delivering non-invasive insight into everything from fruits to eggs to the human body. We are transforming what is becoming the world's largest biological dataset into actionable intelligence to reduce waste, increase quality, and accelerate the shift toward a more sustainable and healthier future.

Headquartered and founded in Munich, Germany, with an office now in Houston, Texas, our world-class team is scaling inside-out technology to transform how humanity sees and understands biological matter.

**Help us see what's possible. Join us.**

# **Your Role**

**You will own how Orbem shows up at customer sites — installing, servicing, and maintaining multi-million-euro imaging systems that sit at the heart of our customers’ production lines.** When our systems run, our customers run. When they don’t, the cost is measured in lost production days. **Field Operations is where our technology meets reality, and you own that interface.**

Field Operations spans Europe and the US, with regional teams on both sides of the Atlantic. A lot has already been built: dedicated Field Engineers and Project Managers, regional leadership, and real investment in SOPs, planning, and tooling. The next step is maturity — turning what exists into an operation that runs consistently across every site, every partner, and every geography, and that scales without depending on individual heroics.

You inherit that and the mandate to shape what comes next. We are expanding fast into new verticals and geographies, and installation and service quality is one of the few things that can either unlock or throttle that growth. This is a role for someone equally at home setting the operating model and being close to the work itself — credible with a customer's engineers and with our executive team on the same day — and who is unwilling to let the same problem happen twice.

##
**Your Day to Day**

**Running Operations (≈ 40%)**

-

Own end-to-end delivery of installations, on-site service, and scheduled maintenance across Europe and the US — on time, on budget, and at a quality level appropriate to assets worth more than €1M each.

-

Empower and enable Regional Leaders and Project Managers to flawlessly orchestrate complex site deliveries involving customers, MRI suppliers, and automation partners.

-

Be the escalation point that actually resolves things — including on site, out of hours, when a go-live is at risk.

-

Own the operational KPIs and the commitments we make to customers, and keep Technical Customer Support, Business Development, and the executive team informed.

**Building the Operating System (≈ 35%)**

-

Raise SOP maturity — across our own team, our partners, and our customers’ contractors.

-

Implement a continuous improvement engine together with the Operational Excellence team.

-

Leverage and drive the tooling and data we need to run this at scale — field service management, installation and service documentation, spare parts and capacity planning — and make sure people actually use it.

-

Build the quality and safety standards our engineers work to, and hold the line on them under schedule pressure.

**Leading and Scaling the Team (≈ 25%)**

-

Lead and develop the whole team — Field Engineers, Project Managers, and regional leads alike — building the depth and ownership that lets each region run well without you in the detail.

-

Design the organisation ahead of the growth curve: hire, structure, and re-structure as we add verticals and geographies, and find the right mix of own team, partner networks, and variable capacity models to absorb fluctuating demand.

-

Define and operationalize the Field Operations roadmap, and translate it into a capacity and hiring plan the business can commit to.

-

Build the culture: high standards, low ego, no blame, and a bias toward fixing things properly.

## **How You Fit In**

-

You report to the Chief Operating Officer and lead Field Operations through two regional team leads, with Field Engineers delivering installation, on-site service, and maintenance work and Project Managers coordinating customers, partners, and internal teams. The team will keep growing as we roll out new geographies and products.

-

You work closely with Technical Customer Support, Operational Excellence, Supply Chain, Hardware, Product, and Business Development, and you own our operational relationship with our equipment and automation partners.

-

You are part of the wider operations leadership team and contribute to decisions well beyond your own function.

##
**Your Experiences and Skills**

-

**10+ years in field or service operations. **You have led installation, on-site service, and maintenance operations for complex technical products.

-

**Hardware plus service business models. **You understand a business where the machine is only half the promise and installation, uptime, and maintenance are the other half.

-

**Experience at operational scale. **You have worked inside an organisation that had already solved this properly — mature SOPs, field service tooling, quality processes, clear team structures — and you know what “good” actually looks like, not just in theory.

-

**Multi-region leadership. **You have built and led geographically distributed teams and developed team leads into strong operational leaders.

-

**Hands-on and strategic. **You can design the operating model and the roadmap, and you will also get on a plane and stand on a site on short notice when the situation calls for it.

-

**Continuous improvement as a reflex. **You see every error as an opportunity and an obligation to be better next time, and you have the methods to back that up.

-

**Technical fluency. **You can engage credibly on site planning, requirement specifications, and installation and commissioning detail, and hold your own with engineers, suppliers, and customers’ technical teams.

-

**Drive and proactiveness. **You move before being asked, chase ambiguity down rather than escalating it up, and you are comfortable making decisions with incomplete information.

-

**Senior communicator. **You build trust with customers, partners, and internal stakeholders, and you can deliver difficult messages without damaging the relationship.

-

**Practicalities. **Willingness to travel to European and US sites, and an EU Class B driver’s licence. Fluent in English; additional languages (German, Spanish, Italian, French) are a plus.

##
**What Makes You Stand Out**

-

Experience in a venture-capital-backed, private-equity-backed or similarly execution-driven environment, where operational discipline, cost, and delivery commitments were tracked seriously.

-

You have taken a field operations function through a step change in scale — doubling geographies, product lines, or installed base — and can describe what broke and what you did about it.

-

Formal continuous improvement or quality credentials (Lean, Six Sigma, or equivalent) that you have actually applied to a service organisation.

-

Hands-on experience implementing field service management or service data tooling, including getting a team to adopt it.

-

Experience in a high-growth deep-tech or capital-equipment company, where the product was still changing underneath the operation.

-

You are obsessed with customer experience and can point to the operational choices you made to protect it.

## **What We Offer**

**International Environment:**

-

Join a team with 40+ nationalities across 5 continents, all driven by a shared purpose: shedding light on the world’s toughest challenges.

**Comprehensive Benefits:**

-

Stock Options: Share in Orbem’s success.

-

Relocation Support: Seamless support for your move to Germany.

-

Learning & Development: €1,750 annual budget for personal growth.

-

Fitness Membership: Access to Urban Sports Club, Wellhub or Wellpass.

-

Childcare Reimbursement: Support for Kita/Kindergarten fees.

-

Deutschland Ticket: Full coverage of public transportation.

**Work-Life Integration:**

-

Flexible Hours & Home Office: Work when and where it suits you.

-

WFH Perks: Get €185 to upgrade your home office + an external monitor on us!

-

30 Days Paid Leave: Plenty of time to recharge.

-

Personal Leave: Flexibility for life’s important moments.

-

Work From Anywhere: Experience new cultures and environments for up to 60 days per year.

**Make a Difference:**

Join an ambitious, fast-growing team working on breakthrough technology. In our scale-up environment, you'll have the freedom to lead your projects and make an impact. We provide a platform for you to explore, innovate, and define your vision for the future. At Orbem, we're committed to helping you discover your strengths, and while we aim to teach you, we also want to learn from you.

**Your Team:**

You'll become part of our diverse and international team. Learn more about the team members, their work, and challenges here: [https://orbem.ai/company/](https://orbem.ai/company/)

*At Orbem, we're committed to building a smart, diverse team, and we recognize that self-doubt can prevent talented individuals from applying. If you feel you don't meet every requirement, we'd love to hear from you anyway!*

Compensation: €120K – €135K • €120K – €180K Equity

- • Compensation Range €120K – €135K • €120K – €180K Equity

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
