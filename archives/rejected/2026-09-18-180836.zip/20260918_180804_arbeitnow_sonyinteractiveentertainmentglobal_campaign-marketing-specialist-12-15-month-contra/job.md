# Campaign Marketing Specialist (12-15 Month Contract)

Posted: 2026-09-18T14:55:13Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**Why Sony Interactive Entertainment?**

Sony Interactive Entertainment isn’t just the Best Place to Play — it’s also the Best Place to Work. Sony Interactive Entertainment (SIE) is the company behind the PlayStation brand. As a subsidiary of Sony Group Corporation, we’re part of a proud legacy of innovation and excellence. SIE is a dynamic technology company, delivering cutting-edge hardware and network services to more than 100 million people and an entertainment leader, home to some of the most beloved and recognizable intellectual properties (IP) in the world. Our role at SIE is to create and nurture the experiences under the PlayStation brand, a name synonymous with entertainment excellence and creativity.

**Role Overview: **

The Campaign Marketing Specialist supports the local implementation of PlayStation's global and local marketing priorities across Brand, Hardware, Exclusive Games, Third Party games, Peripherals and Services in Germany, Austria and Switzerland. Working closely with Campaign Managers and the wider marketing team, you will coordinate campaign tasks, localisation, assets, timelines, reporting and day-to-day delivery so that campaigns are accurate, relevant to local audiences and delivered on time.

**What you’ll be doing:**

- Support Campaign Marketing Managers across the campaign lifecycle, from audience insight and agency briefing through localisation, multichannel execution and post-campaign evaluation.

- Maintain campaign plans, timelines, status updates, deliverable lists and approval trackers, following up with contributors to keep work on schedule.

- Coordinate the localisation, adaptation, quality checking and delivery of global campaign assets and product information for the GSA market.

- Work with Global Brand Marketing teams to gather campaign materials, share local requirements and circulate relevant information to internal teams.

- Prepare inputs for agency briefs and coordinate day-to-day follow-up with creative, media and other agency partners under the direction of the relevant Campaign Marketing Manager.

- Support the development and timely delivery of campaign materials for retail and other channel partners.

- Help ensure that PlayStation brand and game IP assets follow relevant brand guidelines and complete the required approval processes.

- Gather existing player insights, local market context and competitor activity, and turn the information into clear summaries for campaign planning.

- Support the local implementation of global Third Party marketing partnerships and coordinate agreed deliverables with internal and external partners.

- Prepare regular and ad hoc campaign status reports for local, regional and global stakeholders.

- Support post-campaign analysis by collecting results, campaign outputs, learnings and performance against agreed objectives and KPIs.

- Provide campaign administration support, including budget tracking, purchase requisitions and purchase orders, invoice follow-up, open commitment checks and forecast inputs.

- Support the local age-rating process with the USK, including preparation of submission materials and forwarding test results to the relevant global teams.

- Participate in local and regional working groups and represent player needs when coordinating assigned campaign tasks.

**What we’re looking for:**

- At least 2+ years experience gained in marketing, campaign management or an agency environment, ideally for a consumer-facing brand.

- Strong organisational and project coordination skills, with the ability to manage several tasks, prioritise work and adapt when requirements change.

- Clear written, verbal and presentation skills, with professional fluency in German and English.

- High attention to detail and a reliable approach to timelines, documentation and approval processes.

- A collaborative working style and confidence coordinating with internal teams, agencies and external partners.

- Ability to work independently on assigned tasks, take initiative and raise risks or dependencies early.

- Interest in consumer and player insights, with the ability to use data and campaign results to support practical recommendations.

- Experience working in an international or cross-functional environment is an advantage.

- A genuine interest in video games and interactive entertainment, or relevant industry experience, would be beneficial.

**Desirable**:

- A genuine interest and/or passion for gaming, entertainment, or digital consumer brands.

- Experience working within the gaming, technology, entertainment, or media industries.

**What we can offer:**

- Work on one of the world's most iconic entertainment brands with genuine European market impact

- Campaign ownership across the full PlayStation portfolio in a key territory

- Close collaboration with global teams and direct exposure to global marketing strategy

- Small, high-performing team with strong collaborative culture

- Fast-moving, varied role across multiple product categories and gaming genres

Please note, Sony Interactive Entertainment conducts background checks at the offer stage for all new employees (which may include criminal background checks for some roles) and will need to process personal information to support these checks.

Please refer to our [Candidate Privacy Notice](https://www.playstation.com/legal/careers-privacy-notice/) for more information about what personal information we collect, how we use it, who we share it with, and your data protection rights.

**Equal Opportunity Statement:**

*Sony is an Equal Opportunity Employer. All persons will receive consideration for employment without regard to gender (including gender identity, gender expression and gender reassignment), race (including colour, nationality, ethnic or national origin), religion or belief, marital or civil partnership status, disability, age, sexual orientation, pregnancy, maternity or parental status, trade union membership or membership in any other legally protected category.*

*We strive to create an inclusive environment, empower employees and embrace diversity. We encourage everyone to respond. *

*Sony Interactive Entertainment is a Fair Chance employer and qualified applicants with arrest and conviction records will be considered for employment.*

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
