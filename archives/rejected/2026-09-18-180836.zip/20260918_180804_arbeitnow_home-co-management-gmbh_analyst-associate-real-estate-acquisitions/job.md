# Analyst/Associate Real Estate Acquisitions

Posted: 2026-09-18T17:00:31Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Home & Co is a vertically integrated real estate investor and operator in the German purpose-built student accommodation (PBSA) and micro-living sector. It is majority-owned by TPG Real Estate.

Home & Co is hiring an analyst/associate for its Acquisitions & Asset Management team in Berlin or Franfurt/Main to work on live and prospective transactions. The firm has the mandate to acquire across the risk spectrum, from loan enforcement and special situations to standing, income-producing assets.

## Aufgaben

· Financial modelling, underwriting and valuation of potential acquisitions

· Market, sector and competitor benchmarking and analysis

· Preparation of investment memoranda and committee papers for live and prospective transactions

· Support of due diligence (commercial, technical, legal and ESG), including coordination with external advisers

· Ownership of asset management initiatives across the existing portfolio

· Liaison with brokers, lenders, advisers and internal operations and development teams

## Qualifikation

· A completed bachelor's or master's degree in finance, economics, real estate or a related field

· Demonstrated transaction experience in investment banking, private equity, real estate or a related field (2+ years)

· Strong financial modelling and analytical skills (this will be tested)

· Fluency in German and English

Home & Co is headquartered in Berlin, owns more than 2,850 apartments across 12 German cities, and is expanding its portfolio. It operates across the value chain in-house and leads its own transactions. Home & Co is majority-owned by TPG, a leading global alternative asset manager with more than USD 300 billion in assets under management. Through TPG Real Estate's opportunistic fund series, Home & Co draws on substantial discretionary equity.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
