# Solution Consultant, Supply Chain - Germany

Posted: 2026-09-18T14:24:14Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**Join Pigment: The AI Platform Redefining Business Planning**

Pigment is the AI-powered business planning and performance management platform built for agility and scale. We connect people, data, and processes in one intuitive, feature-rich solution, empowering every team—from Finance to HR—to build, adapt, and align strategic plans in real time.

Founded in 2019, Pigment is one of the fastest-growing SaaS companies globally. Industry leaders like Unilever, Snowflake, Siemens, and DPD use Pigment daily to make more informed decisions and confidently navigate any scenario.

With a team of 600+ across Paris, London, New York, Toronto, San Francisco and Austin, we've raised nearly $400M from top-tier investors and were named a Visionary in the 2024 Gartner® Magic Quadrant™ for Financial Planning Software.

At Pigment, we take smart risks, celebrate bold ideas, and challenge the status quo—all while working as one team. If you're driven by innovation and ready to make an impact at scale, we’d love to hear from you.

**What you'll do:**

As a Supply Chain Solutions Consultant, you will partner with Account Executives to shape the vision of prospects and existing clients, and present Pigment's thought leadership around Supply Chain Planning. You act as a trusted advisor who bridges operational supply chain expertise with the power of a modern planning platform.

You will be focused on:

-

**Discovery:** Deeply understand supply chain planning challenges - demand forecasting, S&OP/IBP, inventory planning, capacity planning - and help prospects articulate their goals and future vision. Build strong relationships with operations, supply chain, and finance stakeholders.

-

**Create value:** Challenge the status quo of legacy supply chain planning tools (Excel, disconnected point solutions) and demonstrate how Pigment enables a more integrated, agile planning approach - backed by customer success stories from CPG, Retail, Manufacturing, or Life Sciences.

-

**Product demonstrations:** Master Pigment's capabilities to address supply chain use cases through tailored demos - covering demand planning, supply planning, scenario modeling, and cross-functional alignment between supply chain and finance.

-

**Workshops:** Facilitate discovery and visioning workshops with key supply chain and finance stakeholders to co-design their future planning process. Present proposed solutions to executive audiences (VP Supply Chain, CFO, COO).

-

**Cross-functional collaboration:** Work closely with Product, Marketing, and Customer Success to relay supply chain market needs, contribute to the product roadmap, and improve the overall customer experience.

**Who you are:**

-

**Proven pre-sales experience** (Solutions Consultant, Sales Engineer, or similar) on enterprise planning tools with a supply chain dimension - e.g. o9 Solutions, Kinaxis, Blue Yonder, Anaplan, Board, or comparable platforms

-

**Strong supply chain domain knowledge:** solid understanding of planning processes such as S&OP/IBP, demand planning, inventory optimization, production planning, or supply network planning

-

**Background and/or degree** in Supply Chain, Operations Management, Industrial Engineering, or a related field

-

**Compelling storyteller:** ability to translate complex supply chain planning challenges into clear, differentiated product demonstrations for both operational and executive audiences

-

**Multi-stakeholder agility:** comfortable engaging with Supply Chain Planners, Operations Managers, Finance Business Partners, and C-level executives in the same deal cycle

-

**Experienced in CPG, Retail, Life Sciences, or Manufacturing** verticals - you speak the language of these industries

-

Advanced problem-solving and troubleshooting skills

-

Comfortable working in a fast-paced, high-growth environment

-

Travel up to 25% of the time

**How We Work:**

**How we work**

-

**Thrive Together:** We can only win as a team. We are all founders and do the right thing for our peers, Pigment customers, partners, and the planet

-

**Never Settle:** We aim to become the best at what we do by delivering with rigor and ambition every day

-

**Go for it:** We are biased towards action. Every action leads to learning and these learnings get us one step closer to our mission

-

**Be real, be humble:** We are generous with our feedback, open to change our views and we approach it with empathy knowing everyone is trying to do the best for Pigment

**What We Offer: **

-

Competitive compensation package

-

Stock options to ensure you have a stake in Pigment's growth

-

Comprehensive benefits, including medical, dental, & vision insurance coverage

-

We encourage you to take the time you need. When you work hard, we know you also need to rest, which is why we offer generous time off and parental leave policies

-

Along with one company offsite every year, we have brand new offices at the heart of major cities including New York, Toronto, Paris, and London

-

High-end equipment to do your work in the best conditions

*We conduct background checks as part of our hiring process, in accordance with applicable laws and regulations in the countries where we operate. This may include verification of employment history, education, and, where legally permitted, criminal records. Any checks will be conducted lawfully prior to formal employment contracts being signed, with candidate consent, and information will be treated confidentially.*

*Pigment is an equal opportunity employer. We believe diversity is a strength and fosters innovation. We are committed to enabling everyone to feel included and valued at the workplace. All qualified applicants will receive consideration for employment without regard to age, color, family, gender identity, marital status, national origin, physical or mental disability, sex (including pregnancy), sexual orientation, social origin, or any other characteristic protected by applicable laws. We may process your personal data in accordance with our **[HR Data Protection Notice](https://get.pigment.com/hubfs/Legal/Applicant%20data%20protection%20notice%20-%20may%202026.pdf)**.*

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
