# Real Estate Acquisitions - Off-cycle Internship

Posted: 2026-09-18T17:00:31Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Home & Co is a vertically integrated real estate investor and operator in the German purpose-built student accommodation (PBSA) and micro-living sector. It is majority-owned by TPG Real Estate.

We are hiring an intern on rolling basis (off-cycle / on-cycle) in our Acquisitions & Asset Management team, working on live and prospective transactions. The firm has the mandate to acquire across the risk spectrum, from loan enforcement and special situations to standing, income-producing assets. Strong performers may be considered for a permanent position.

## Aufgaben

- Financial modelling, underwriting and valuation of potential acquisitions

- Market, sector and competitor research

- Preparation of investment memoranda and committee papers for live and prospective transactions

- Support of due diligence (commercial, technical, legal and ESG)

- Support of asset management across the existing portfolio

- Liaison with internal operations and development teams

## Qualifikation

- A completed bachelor's degree, or a master's in progress or completed, in finance, economics, real estate or a related field

- Prior internship experience in investment banking, private equity, real estate or a related field

- Strong financial modelling and analytical skills (this will be tested)

- Fluency in German and English

## Benefits

- Location: Berlin/Frankfurt; on-site

- Focus: Private Equity Real Estate / Acquisitions (student housing)

- Duration: minimum commitment of 3 months; preference for a 6-month internship

- Start date: on a rolling basis

- Benefits: market-standard compensation. Well-performing interns have chances to be offered a full-time position - subject to staffing needs

Home & Co is headquartered in Berlin, owns more than 2,850 apartments across 12 German cities, and is expanding its portfolio. It operates across the value chain in-house and leads its own transactions. Home & Co is majority-owned by TPG, a leading global alternative asset manager with more than USD 300 billion in assets under management. Through TPG Real Estate's opportunistic fund series, Home & Co draws on substantial discretionary equity.

If sounds like you, we look forward to receiving your application.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
