# MTLA (Mensch) – Labormedizin, Klinische Chemie & Hämatologie | Labor Mainz

Posted: 2026-09-18T14:30:14Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

### **Werde Teil eines innovativen Labors in Mainz!**

Möchtest du in einem **hochmodernen Labor** arbeiten, in dem die **neuesten Technologien** eingesetzt werden, um medizinische Durchbrüche zu ermöglichen? Du bist **MTLA (Medizinisch-technischer Laborassistent)** und hast Lust, in einem dynamischen Team präzise Diagnosen zu ermöglichen? Dann ist diese Position perfekt für dich!

### **Deine Aufgaben:**

-

**Automatisierte Analysen** in **klinischer Chemie & Hämatologie** (z. B. Blutbildanalytik, Hormone, Tumormarker)

-

Durchführung globaler **Gerinnungsparameter & Serumelektrophoresen**

-

**Manuelle Differenzierung pathologischer Blutbilder & Parasitendiagnostik**

-

**Qualitätsmanagement & technische Validierung** der Laborergebnisse

-

Arbeiten mit einer **vollautomatischen Laborstraße & modernsten Analysegeräten**

### **Dein Profil:**

✔ **MTLA-Abschluss (Medizinisch-technischer Laborassistent)**
✔ **Erfahrung in Labormedizin, klinischer Chemie oder Hämatologie** von Vorteil
✔ Präzise, selbstständige & verantwortungsbewusste Arbeitsweise
✔ Teamplayer mit sehr guten Deutschkenntnissen (**mind. C1-Niveau**)

### ** Deine Vorteile:**

-

** Attraktive Vergütung + Weihnachtsgeld + Zuschläge für Samstagsdienste**

-

** Flexible Arbeitszeiten – Keine Nacht- & Sonntagsdienste**

-

** Hochmoderne Labortechnik & innovative Methoden**

-

** Regelmäßige Fortbildungen & exzellente Einarbeitung**

-

** Gesundheitsleistungen, Fitnessstudio-Vergünstigungen & Firmenevents**

-

** Top-Verkehrsanbindung, kostenfreier Parkplatz & JobTicket**

-

** Deine Chance, Teil eines exzellenten Laborteams in Mainz zu werden!**

-

** Jetzt bewerben & Karriere in der Labormedizin starten!**

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
