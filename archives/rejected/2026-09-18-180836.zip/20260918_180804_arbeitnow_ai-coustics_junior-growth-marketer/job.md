# Junior Growth Marketer

Posted: 2026-09-18T15:30:26Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**Voice is becoming the primary interface for technology.** For the first time in history, we can use natural language to control and interact with our devices, services, and applications, and we’re only at the beginning of the adoption of Voice and Physical AI across industries. Current voice interactions, however, still lack a fundamental human skill: nuanced understanding of audio scenes and environments. Navigating complex auditory scenes, distinguishing between multiple voices, or focusing on a main speaker are all part of the challenge of “**teaching machines to hear like human beings.**”

At ai-coustics, we’re building **the audio intelligence layer** and developer tooling to enable more robust and intelligent voice agents and Physical AI applications. Today, Voice AI companies like **PolyAI, LiveKit, Telnyx, AssemblyAI or Telli** use our SDK to prepare their agents for real-world acoustic challenges. Our models power thousands of agents worldwide and process millions of hours each month.

We are backed by **leading early-stage investors** including **Connect Ventures, Partech, Inovia Capital**, as well as angel investors from **HuggingFace, DeepMind** and **Amazon** with deep expertise in AI and developer infrastructure. These partners share our vision and are helping us build a world-class team operating with **high levels of responsibility and velocity**. We look for people who take ownership, think systemically, and want to solve challenging real-world problems in close collaboration with our customers.

**About the role**

We have a small but mighty marketing team that produce excellent content and campaigns — launches, videos, case studies, and a brand that punches above our size. What we need is someone who can ensure that these reach the right people at the right time and build a growth engine around them.

That's this role. You'll drive the growth side of marketing at ai-coustics: the measurement that tells us what's working, the new channel experiments that help us expand reach, and the funnel that converts signups into active and happy developers. You'll also be the bridge into sales — surfacing the accounts worth chasing, and turning our content into the material that helps close them.

## Tasks

- **Funnel and conversion** — Manage the path from content to signup to activated user: CTA strategy by channel, landing pages, onboarding flow.

- **Lifecycle and email** — Build the email programme looking at onboarding, activation, re-engagement, launch sends.

- **Organic discovery** — Run SEO and GEO as a continuous programme, including how we surface inside LLMs.

- **Experimentation** — Run a steady cadence of tests across pages, messaging and channels, including our first paid experiments. Form a hypothesis, ship it, evaluate, and expand.

- **Account-based marketing** — Work with our sales and partnerships team to identify and outreach to our target accounts, build and act on intent signals on our website and product, building sales enablement materials and personalised campaigns that capture their attention.

- **Measurement and attribution** — Own the analytics layer and reporting across PostHog and HubSpot: the events, funnels and dashboards that show where developers and accounts come from, and where they drop off.

- **AI-native operations** — Build agents and automations into your own workflows, from research and reporting to campaign ops.

## Requirements

- 1–3 years in growth, lifecycle, performance or product marketing, where you personally owned a channel or a funnel and can show what changed because of you.

- Genuinely comfortable with data. You can set up event tracking, build a funnel in a product analytics tool, interrogate a CRM, and spot when a number is lying to you.

- Hands-on with the tooling: product analytics (we use PostHog), CRM and marketing automation (HubSpot), and the CMS and email tools around them.

- You use AI daily as an operational tool, not an experiment. You build workflows with it, and you have opinions about where it helps and where it produces noise.

- You write clearly — well enough to ship an email sequence, a landing page or a sales one-pager without a handoff. Not a content specialist, but you know what great looks like.

- You've worked alongside sales in a B2B setting and understand that marketing's job is pipeline, not traffic. You'd rather review customer call notes than guess what buyers care about.

- Comfortable working with engineers to get things shipped — tracking implemented, signup flow changed, site fixed. You can write a clear ticket, and hold your ground on why it matters.

- Fast learner with high agency. You're joining a function with no established playbook, and your instinct is to go and find out rather than wait to be briefed.

- Comfortable marketing to developers, or clearly motivated to learn how. Our audience is engineers building voice products, and they are unusually good at ignoring marketing.

- Working language is English.

## Benefits

- Opportunity to work at a **rapidly growing Voice AI startup**, backed by top investors.

- **Compensation and equity:** Competitive salary package, additional benefits and stock options, enabling you to take part in the company’s success.

- **Startup Culture:** Dynamic, fast-paced environment with passionate and collaborative colleagues.

- **High Impact:** Groundbreaking startup at a pivotal growth stage, making a real difference in how people experience audio.

- **Ownership & Autonomy:** Take full ownership of projects and ship fast.

- **Work With the Best:** World-class team of engineers and builders with ample room for professional growth.

- **Contribute to the Future:** Define the landscape of Voice AI technology.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
