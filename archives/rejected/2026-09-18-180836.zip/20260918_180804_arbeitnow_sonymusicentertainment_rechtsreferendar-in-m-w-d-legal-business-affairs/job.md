# Rechtsreferendar:in (m/w/d) Legal & Business Affairs

Posted: 2026-09-18T14:55:09Z

## Rejection

- Category: tech_stack
- Reason: role does not mention Go/Golang or PHP

(Berlin, ab Juli 2027, für je 3 Monate, Vollzeit)

*Du interessierst dich für den legal stuff hinter dem Musikbusiness? Stehst kurz vor dem Abschluss des Referendariats und willst endlich loslegen? Bist engagiert und kreativ? Dann suchen wir dich.*

**Was du machst**

- Du überprüfst und ergänzt bestehende Verträge und Vereinbarungen – von Künstler- und Bandübernahmeverträgen bis Mitschnitts- und Senderechtsvereinbarungen.

- Du entwirfst gutachterliche Stellungnahmen und bereitest Vertragsabschlüsse vor.

- Du gehst auch alle weiteren Projekte in den Bereichen des Markenrechts, Urheberrechts und UWG mit Begeisterung an.

**Wer du bist**

- Du hast deinen Schwerpunkt auf Medien- oder Wirtschaftsrecht gelegt.

- Du willst deine Wahlstation bei uns absolvieren. Vielleicht hast du auch bereits Erfahrung aus anderen Praktika.

- Dein Deutsch und Englisch kann sich hören lassen.

- Microsoft 365 kannst du.

- Du denkst analytisch und arbeitest strukturiert.

- Du bist zielstrebig, einsatzfreudig und kommunikationsstark.

**
Wir bieten dir**** **

Raum für Vielfalt und Raum für Innovation.
Möglichkeiten für deine Ideen.
Rabatt auf viele Produkte der Sony Corporation.  
Die Chance, dich zu beweisen. Und Herausforderung von Anfang an.  

**
Wie du dich bewirbst**

Ohne Foto und Alter. Auch Familienstand, deine Herkunft, Zeugnisse, die Jobs deiner Eltern und ähnliche Merkmale benötigen wir nicht.

Zeige uns in einem CV (ggf. mit Anschreiben in einer Datei) was dich ausmacht, was du kannst und warum Sony Music mit dir besser klingt!

Wir freuen uns auf dich. 
Sony Music sounds better with you. 

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
