# Paid Search Lead (Experimentation & Measurement)

Posted: 2026-09-18T14:55:10Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

## **The role**

We are looking for a highly strategic and analytical Marketing Measurement & Testing Lead (Individual Contributor), Paid Search (m/f/x) to drive the evolution of our Paid Search advertising efforts. This is a high-impact individual contributor role, sitting at the intersection of performance marketing, ad tech, and automation. As a key expert within the team, you will own the global testing and measurement strategy for Paid Search, ensuring data-driven decision-making that unlocks new growth opportunities. You will play a critical role in budgeting, infrastructure development, and automation, collaborating with cross-functional teams to ensure Paid Search operates at peak efficiency.

##

## **Your impact **

As Marketing Measurement & Testing Lead, Paid Search, you will drive key initiatives across four strategic areas:

Platform Leadership & Innovation

- Serve as the go-to expert on Paid Search, providing strategic guidance on Google Ads (Search, Shopping, AI Max), with a deep understanding of platform mechanics, auction dynamics, and optimisation levers.

- Anticipate and adapt to platform updates, leveraging industry trends and data insights to drive continuous innovation and stay ahead of the curve.

- Collaborate with platform partners to pilot new solutions, enhance measurement capabilities, and improve efficiency.

- Advise and collaborate with the Paid Search Campaign Ops team, ensuring platform strategies are optimised with best-in-class practices and advanced ad tech solutions.

Measurement & Testing

- Own the Paid Search experimentation roadmap, spanning bidding signal optimization, landing pages, and audience and keyword targeting, with a clear framework for rigour, scalability, and cross-team knowledge-sharing.

- Develop and refine experimentation frameworks, including A/B tests, Incrementality lift tests (Geo lift / conversion/user based tests), and attribution modelling.

- Analyse test results to inform data-driven decisions and uncover new growth opportunities.

- Collaborate with analytics, data and Strategy & Operations teams to continuously align on testing timeline and priorities.

- Ensure proper budgeting processes, including daily and weekly pacing, are aligned with strategic goals and seasonality.

Automation & Infrastructure

- Partner with Product and AdTech on the development of measurement infrastructure, attribution models, automation tooling, and campaign technology, acting as the primary Paid Search voice in cross-functional initiatives.

- Own and develop the automation of reporting for key tests, performance tracking and measurement.

- Drive adoption of scripts, AI-native platform features, and internal tools to systematically reduce manual overhead and scale high-performing activity.

- Ensure automation efforts align with overall business objectives and drive operational efficiencies.

Channel Performance & Strategy

- De-average performance across keywords, queries, devices, audiences, geos, landing pages, offers, and ad copy, setting the standard for analytical depth across international markets and portfolio of brands.

- Challenge and influence global and local stakeholders, including senior leadership, constructively driving alignment across Analytics, Strategy & Operations, Product, and AdTech.

## **You are…**

- A sought-after expert in Paid Search strategy and campaign management (Google Ads and Bing Ads in text search, PMAX, Shopping, and AI Max), consulted by peers and capable of influencing senior stakeholders with a clear point of view

- Deeply fluent in performance marketing metrics (CPC, CVR, CTR, CAC, LTV) with a proven ability to translate data into strategic decisions and scalable improvements

- Entrepreneurial in mindset, you see opportunities rather than problems, and proactively challenge the status quo to drive step-change improvements

- A strong analytical thinker, comfortable independently building complex models and surfacing insights others wouldn't find

- Energised by working at the intersection of performance marketing and technology, with a genuine interest in measurement, attribution, and automation

- Able to communicate complex performance narratives with clarity and conviction to all levels, including senior leadership

- Comfortable operating with a high degree of autonomy in a global, matrixed organisation

##

## **At a minimum, you have......**

- An excellent degree in Marketing, Business, Analytics, or a related field

- 7+ years of hands-on experience in Paid Search, either from an agency or client-side role

- Proven track record of owning or leading a structured experimentation programme, with clear frameworks for testing, measurement, and knowledge-sharing

- Strong analytical skills, translating complex data into actionable insights and scalable improvements

- Experience partnering with Product or AdTech teams on measurement, infrastructure, or tooling initiatives

- Proven ability to lead high-impact initiatives and drive measurable results across large-scale, international accounts

- Experience with incrementality testing, attribution modelling, or conversion lift studies

- Experience driving automation and AI adoption (scripts, tools, or platform features) to scale operations

- Hands on experience with Google Ads (Search, Shopping, Performance Max)

## **What we offer**

Elevate your lifestyle! Join one of Europe's fastest-growing tech powerhouses in a dynamic phase of expansion.

- Immerse yourself in a diverse global community of 90+ nationalities.

- Enjoy a competitive compensation package that goes beyond the norm, with perks like a HelloFresh- subsidized Pension Scheme, Berlin relocation support, and a Hybrid working model.

- Elevate your lifestyle with exclusive discounts on your weekly HelloFresh box and office meals.

- Invest in your growth with an annual learning & development budget, German language learning budget, and access to the HelloFresh Academy.

- Plus, we've got your well-being covered with mental health support, transportation perks, and working-parent-friendly benefits. From our 24/7 gym access,wellbeing platforms like Headspace and Spill, to sabbatical leave options, HelloFresh is not just a workplace; it's a lifestyle of perks and possibilities!

##

## **Are you up for the challenge?**

Please submit your complete application below including your salary expectations and earliest starting date.

After submitting an application our team will review this and get back to you within 5 business days.

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
