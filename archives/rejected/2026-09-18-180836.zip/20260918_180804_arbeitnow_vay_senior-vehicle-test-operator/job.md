# Senior Vehicle Test Operator

Posted: 2026-09-18T14:55:09Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Ever imagined saying, “I helped launch the future of transportation”?

We’re rewriting the rules of urban mobility. At Vay, customers tap a button and a car arrives - with no one inside - powered by our world-first Remote Driving technology on real public streets.

We’re live in Las Vegas and scaling fast, powered by a strategic investment of up to $410 million from [Grab](https://www.grab.com/sg/). Our mission is simple: replace private car ownership with a faster, cleaner, door-to-door mobility model. If you want to build something real, visible, and genuinely transformative, you’ll feel right at home here.

**Curious to experience Vay yourself? Use the code *VAYCANDIDATE* for $10 off your first trip in Las Vegas! Download the "Vay" app from the Apple or Google Play store & off you go! **

#### **What’s happening at Vay**

- First to roll out vehicles in both Europe and the USA on public roads without a human being inside & currently the 2nd largest commercial, driverless car fleet in the Western World.

- We've partnered with [Kodiak](https://kodiak.ai/) to bring remote-driving technology to autonomous trucks in the US, showcasing our ability to integrate our system into heavy-duty commercial vehicles and expand the applications of our tech across the US.

- We’ve completed 10’s of thousands of trips so far and are busy multiplying our Las Vegas fleet just to meet demand!

- **...And soon we’ll be expanding across the US & Europe 🚀**

#### ***Why this role is exciting***

We’re looking for an experienced **Senior Vehicle** **Test Operator** to join our team in Berlin and help test the technology behind Vay’s remotely driven vehicles.

Testing at Vay happens on real vehicles, across real-world driving environments. As a **Senior Vehicle Test Operator**, you’ll be among the first people to test new vehicle software and hardware, both through manual driving and remote operation.

You’ll execute vehicle-level tests, troubleshoot issues using automotive diagnostic tools, collect and analyse test data, and work closely with our engineers to identify and resolve problems before changes are released.

This is a hands-on role for someone who enjoys working with vehicles and technology, understands how to test systematically, and takes pride in getting the details right.

#### ***What you'll be driving***

- Execute vehicle-level testing across software, hardware and driving systems

- Flash ECUs and troubleshoot vehicle issues using OBD, CAN traces and other diagnostic tools

- Use CANoe or similar tools to investigate and debug vehicle behaviour

- Collect test data and provide clear, structured test reports

- Identify, reproduce and document software and hardware bugs

- Verify that systems perform consistently against defined requirements

- Work closely with engineering teams to investigate issues and validate solutions

- Support both manual and remote vehicle testing

#### ***This might be a great fit, if***

- 3+ years of experience in automotive testing, vehicle testing, test operations or a related technical field

- Experience with automotive communication protocols and diagnostics, particularly CAN and OBD

- Experience using CANoe or similar automotive testing and diagnostic tools

- Confidence troubleshooting technical issues and documenting findings clearly

- Strong attention to detail across testing, bug reporting and test documentation

- An EU driving licence, a clean driving record and at least 5 years of driving experience

- Confidence driving safely and responsibly in different testing scenarios

- The ability to work independently, prioritise effectively and take ownership of your work

- An interest in remotely driven, autonomous or connected vehicle technology

- Good working English

#### *Nice to have*

- Safety driver or test driver training

- Experience with Jira or other bug-tracking tools

- A technical qualification or background in automotive, electronics, mechatronics or a related field

- Experience working in a fast-moving engineering or product development environment

**This role will be based onsite in Berlin. We welcome all applications, but please only apply if you already live in Berlin or are willing to relocate**

#### ***Why choose Vay***

💪 A global team of smart, motivated people from 30+ countries who love tackling hard problems and turning bold ideas into reality

🌍 Huge scope for impact in a fast paced environment

💰 EIP stock options: A stake in Vay’s future - not just a salary

🌴 Unlimited Paid Vacation Days

🎫 Subsidised Deutschland ticket (Berlin)

🏋️‍♂️ Subsidised Urban Sports Club or FitX Membership

🚗 All Vay team members receive 30% off their Vay rides

🛍️ Exclusive external discounts

💼 €350 Home Office Set-up

✈️ Relocation financial assistance when relocating to Berlin

📚 Fully funded German Lessons

🎊 Regular team events throughout the year

For more information on Vay’s physical demands, working environments and safety requirements, you can review this [link](https://docs.google.com/document/d/1swEohclBwsOgx37G4NHE2szYCA6avS_aQX_WSJ7Ih8k/edit?tab=t.0#heading=h.6dlrur2mwcd9). We’ll also cover anything specific to this role during the first interview.

We’d love to stay connected for future opportunities, so feel free to include your LinkedIn profile when you apply.

We welcome applications from all backgrounds and experiences. If you’re excited about shaping something truly groundbreaking, we’d be happy to hear from you.

####

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
