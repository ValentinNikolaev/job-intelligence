# Senior Data Engineer, Analytical Data Platform, Inteligent Platforms (all genders)

Posted: 2026-09-18T14:55:10Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

## About the role

At HelloFresh, data is at the heart of everything we do — from the moment a customer places an order to the way we forecast demand, optimize our supply chain, and personalize experiences for millions of people. Making that data fast, reliable, and available is what our Data Platform makes possible.

We are looking for a Senior Data Platform Engineer to join our Data Platform team of 7 — the squad responsible for the infrastructure that powers our entire data ecosystem. You'll own the compute, orchestration, and storage systems that data and analytics teams depend on every day, and lead the evolution of our platform toward a more governed, scalable, and cloud-native architecture.

This is a hands-on engineering role at the core of our platform. You'll drive our migration to Databricks Unity Catalog and Terraform-managed workspaces, sunset legacy systems, and help define the patterns that make it easy for teams across the company to build and run data workloads reliably and cost-efficiently.

## What you'll do

- Lead our Databricks Unity Catalog migration. Own the transition from legacy Databricks workspaces to Unity Catalog and Terraformenabled workspaces — ensuring governance, lineage, and access control are built into the platform from the start.

- Own our Kubernetesbased compute platform. Manage the Kubernetes infrastructure that provides compute for Spark and Airflow jobs, keeping it reliable, efficient, and easy to build on.

- Build and maintain infrastructureascode. Own our Terraform modules and GitHub Actions pipelines, and set the standard for how infrastructure is provisioned and managed across the platform.

- Ensure platform reliability and observability. Keep critical data paths highly available, improve operational maturity, and invest in automation so the platform runs with minimal manual intervention.

- Collaborate across the data org. Partner with data engineering and analytics teams to ensure clean handover points and that platform changes enable rather than block downstream work.

## What you'll bring

- Strong Python and Terraform skills, with a track record of building and operating production data infrastructure SQL knowledge is a plus

- Hands-on experience with Databricks — Unity Catalog experience is a strong plus.

- Deep familiarity with Spark and distributed compute.

- Experience orchestrating workflows with Airflow in production environments.

- Proficiency with AWS infrastructure.

- Experience managing Kubernetes clusters for data workloads.

- A strong ownership mindset — you care about reliability, efficiency, and the developer experience of the teams you serve.

### Nice to have

- Experience with Snowflake and large-scale data migrations.

- Familiarity with data lakehouse architectures.

- Prior experience contributing to internal developer platforms.

## What we offer

Compensation & Financial Wellbeing

- You’ll receive a competitive salary package, including a HelloFresh-subsidized pension scheme.

- Enjoy savings on your weekly HelloFresh box.

- Save with discount schemes with corporate benefits and Vorteile.

Health & Wellbeing

- Support your mental wellbeing with access to platforms like Headspace and Spill.

- Stay active with 24/7 office gym access, a discounted Urban Sports Club membership, and other wellbeing resources.

Flexibility & Work-Life

- Balance your life with our flexible hybrid model.

- Recharge with sabbatical leave options in addition to standard time off.

- Get to work with ease through sustainable travel perks and transportation benefits.

Career & Development

- Embrace "Learning Never Stops" with internal training, the HelloFresh Academy, and a dedicated budget for German language courses.

Culture & Environment

- Enjoy tasty in-office meal deals and fresh food options.

- We support working families with parent-friendly policies, an in-office kids corner, and an on-site babysitter.

#Data

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
