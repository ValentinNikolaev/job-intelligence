# Programmatic Manager Display & Paid Social (m/w/d)

Posted: 2026-09-18T14:30:11Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

## Werde Teil eines starken Teams bei emetriq!

emetriq, Teil der Deutschen Telekom AG, bietet datengetriebene Online-Advertising-Lösungen und setzt sich für fairen Datenzugang als Treibstoff für Innovation und Vielfalt ein. Mit unserer Expertise und Technologiekompetenz steigern wir die Präzision und Relevanz von Online-Werbung. Als Initiatoren des größten kollaborativen Datenpools in Deutschland vereinen wir über 100 Data- und Mediaexperten.

Im Team Magenta fungieren wir zudem als exklusive Programmatic & Paid Social Media Agentur für die Deutsche Telekom. Von Awareness bis Performance: Wir entwickeln digitale Mediapläne und steuern Kampagnen entlang des gesamten Marketing Funnels.

Zur Verstärkung unseres Teams suchen wir in **Bonn oder Hamburg** ab sofort einen **Programmatic Manager Display & Paid Social (m/w/d) **in Vollzeit. In dieser übergreifenden Rolle arbeitest du für unseren Kunden die Deutsche Telekom im Privatkundenbereich und verbindest operatives Kampagnenverständnis mit strategischer Mitgestaltung und einem Fokus auf Performance. Du begleitest bestehende Maßnahmen, Set-ups und Prozesse fachlich, hinterfragst sie konstruktiv und entwickelst sie gemeinsam mit erfahrenen Kolleg:innen und den operativen Kampagnenteams bei emetriq weiter, um Conversion, Effizienz und Wachstum nachhaltig zu steigern.

## Wie du uns helfen kannst

-

**Briefing und fachliche Abstimmung:**
Du übersetzt fachliche und strategische Ziele in klare Anforderungen für die operativen Teams und begleitest die Umsetzung im engen Austausch.

-

**Übergreifende Kampagnenbegleitung:**
Du begleitest performanceorientierte Programmatic-Display- und Paid-Social-Maßnahmen und sorgst gemeinsam mit dem Team dafür, dass Ziele, Planung, operative Umsetzung und Optimierung sinnvoll zusammenspielen.

-

**Operative Qualitätssicherung:**
Du prüfst Set-ups, Targetings, Budgetverteilungen und Optimierungsmaßnahmen und kannst fachlich einschätzen, ob die operative Umsetzung zu den definierten Performance-Zielen passt.

-

**Analyse und Weiterentwicklung:**
Du analysierst Kampagnenergebnisse, hinterfragst bestehende Maßnahmen und Prozesse und entwickelst gemeinsam mit erfahrenen Kolleg:innen und den operativen Kampagnenteams Verbesserungsansätze zur Steigerung von Effizienz, Conversion und Wachstum.

-

**Strategische Beratung:**
Du bringst dich in die strategische Beratung interner Stakeholder zu Mediaplänen, Zielgruppen, Kampagnenlogiken, Budgeteinsatz und kanalübergreifenden Performance-Marketing Fragestellungen ein. Dabei führst du bestehende Maßnahmen und Prozesse nicht einfach fort, sondern hinterfragst sie konstruktiv und entwickelst neue, wirkungsvollere Lösungen.

-

**Testing und Innovation:**
Du entwickelst gemeinsam mit dem Team Testansätze für Zielgruppen, Creatives, Plattformen und Optimierungslogiken und unterstützt bei der Bewertung ihrer Wirkung auf Performance, Conversion, Effizienz und Skalierung.

-

**Kanalübergreifende Perspektive:**
Du betrachtest Programmatic Display und Paid Social im Zusammenspiel mit weiteren Kanälen und wirkst an integrierten Empfehlungen entlang der Kommunikations- und Performance-Ziele mit.

-

**Präsentation und Stakeholder-Management:**
Du bereitest Ergebnisse, Analysen und Empfehlungen verständlich auf und präsentierst sie gegenüber Entscheidungsträger:innen und internen Fachbereichen.

-

**Standards und Prozesse:**
Du bringst eigene Ideen zur Weiterentwicklung bestehender Arbeitsweisen, Qualitätsstandards und Prozesse ein und unterstützt dabei, erfolgreiche Ansätze nachhaltig im Team zu verankern.

## Was du mitbringst

-

**Mediaexpertise:**
Du hast bereits Erfahrung in Programmatic Display, Paid Social oder im digitalen Kampagnenmanagement gesammelt und kennst die Anforderungen an Planung, Umsetzung und Optimierung performanceorientierter Kampagnen.

-

**Operatives Verständnis:**
Du verstehst Kampagnensetups, Targeting-, Bidding- und Optimierungslogiken und kannst die operative Umsetzung fachlich einordnen, ohne die Kampagnen selbst täglich zu steuern.

-

**Strategisches Denken:**
Du kannst Kampagnenergebnisse und operative Fragestellungen in einen größeren Zusammenhang einordnen und möchtest dich in der strategischen Beratung und performanceorientierten Kampagnenentwicklung weiterentwickeln.

-

**Analytische Stärke:**
Du arbeitest datenbasiert, erkennst Zusammenhänge und leitest aus Kampagnen- und Performance-Daten sinnvolle nächste Schritte ab.

-

**Kritischer Blick:**
Du hinterfragst bestehende Maßnahmen und Prozesse konstruktiv, identifizierst Verbesserungspotenziale und bringst eigene Ideen zur Weiterentwicklung ein.

-

**Steuerungs- und Beratungskompetenz:**
Du kannst fachliche Anforderungen klar formulieren, operative Teams verlässlich begleiten und dich sicher mit unterschiedlichen Stakeholdern abstimmen.

-

**Plattformverständnis:**
Du hast Erfahrung mit relevanten DSPs wie DV360, adform, TTD oder Amazon DSP sowie Paid-Social-Plattformen wie Meta, TikTok, Snap oder Pinterest und kennst die grundlegenden Mechaniken der performanceorientierten Kampagnensteuerung.

-

**Kommunikationsstärke:**
Du kannst komplexe Zusammenhänge verständlich vermitteln, Empfehlungen nachvollziehbar begründen und Ergebnisse sicher vor unterschiedlichen Ansprechpartner:innen präsentieren.

-

**Eigenverantwortung und Organisation:**
Du arbeitest strukturiert, zuverlässig und selbstständig und behältst auch bei mehreren parallelen Themen den Überblick.

-

**Sprachkenntnisse:**
Sehr gute Deutsch- und Englischkenntnisse in Wort und Schrift runden dein Profil ab.

## Was uns besonders macht

Wir bei emetriq sind ein Team von Experten, das mit Leidenschaft und Fachkenntnissen zusammenarbeitet, um das Unternehmen und uns selbst weiterzuentwickeln. Unsere Werte basieren auf Vertrauen, Agilität, Selbstorganisation und Eigenverantwortung – ohne starre Hierarchien, dafür mit klaren Entwicklungsmöglichkeiten.

Mut zur Veränderung, Arbeiten auf Augenhöhe und teamübergreifende Zusammenarbeit prägen unsere Kultur. **Wir suchen Menschen, die unsere Motivation und Begeisterung teilen.**

## Unsere Benefits

-

**Hybrides Arbeiten**: Dein Hauptstandort ist Bonn oder Hamburg: In Bonn bist du zweimal pro Woche vor Ort und gelegentlich in Hamburg. In Hamburg arbeitest du in der Regel einmal pro Woche im Büro und mindestens einmal im Monat in Bonn. An den übrigen Tagen entscheidest du selbst, ob du im Büro oder von zu Hause arbeitest.

-

**Flexible Arbeitszeiten**: Keine Kernarbeitszeiten – 9 to 5 ist eine Möglichkeit, aber nicht die einzige

-

**Mobilität**: Unterstützung durch JobRad und Deutschlandticket

-

**Mentale Gesundheit mit OpenUp**: Anonyme, kostenlose Unterstützung durch Psycholog:innen

-

**Vergünstigungen**: Personalkaufpreise für Telekomprodukte und eine Benefit-Card ohne Zuzahlung

-

**Teamspirit und Events**: Workshops, Strategietage, Teamabende, Sportevents und gemeinsames Feierabendbier auf der Dachterrasse

-

**Verpflegung**: Getränke, Siebträgermaschine, Snacks und Dachterrasse inklusive

**Klingt nach deiner nächsten Herausforderung?** Dann freuen wir uns auf deine Bewerbung und darauf, gemeinsam die Zukunft des Programmatic Advertising zu gestalten!

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
