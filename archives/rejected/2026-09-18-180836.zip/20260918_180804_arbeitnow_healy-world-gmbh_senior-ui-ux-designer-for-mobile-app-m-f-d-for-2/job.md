# (Senior) UI/UX Designer for Mobile App (m/f/d) | for 2 month

Posted: 2026-09-18T14:10:03Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**JOB DESCRIPTION**

At Healy World, we are revolutionizing the way people experience technology in their daily lives. Our mission is to improve the well-being and health of our users through innovative digital solutions. In our dynamic team in Berlin, we are looking for a creative mind to help us develop intuitive and user-friendly design solutions.

As a **(Senior) UI/UX Designer for Mobile Apps (m/f/d),** you play a key role in the design of our digital products. You are responsible for developing appealing user interfaces and ensuring an optimal user experience. Your creative eye and technical know-how help us create products that are both functional and visually impressive.

**YOUR MISSION**

- **Responsibility for the Look & Feel**: You ensure an appealing design of our mobile app and an excellent user experience.
- **Design of UI elements, interactions, and screens**: You create intuitive user interfaces and interactions that our users will love
- **Evolution of our UI Guidelines**: With your eye for aesthetics, you further develop our UI guidelines, including colors, typography, icons, animations, and interaction principles
- **Creation of user flows, new features, and designs**: You maximize user engagement by designing innovative user flows and features
- **Development of a consistent user-centered user experience**: You ensure that our designs are always user-centered, providing a consistent experience across all products
- **Creation of prototypes**: For quick testing and validation of your design ideas, you create prototypes

**YOUR PROFILE**

- **Degree**: Completed degree in Communication Design, Design, or related fields
- **Design Tool Skills**: Excellent skills in Sketch and Figma
- **Experience with Product Launches**: Experience in supporting multiple product launches and knowledge of what is necessary to create outstanding interface designs
- **Familiarity with UI Guidelines**: Familiar with Apple's and Google's UI guidelines and always up-to-date with new trends and design guidelines
- **Communication Skills**: Excellent communication, presentation, and interpersonal skills
- **Rive Animations**: Experience in creating dynamic and engaging Rive animations that uniquely enhance our user experience
- **Language Skills**: Business fluent written and spoken English are required

**THAT'S WHAT WE OFFER YOU!**

- **Flexibility:** Work-life balance with the possibility to work **fully (100%)** remote from Germany
- **Workspace:** Innovative office with state-of-the-art technology and ergonomic, height-adjustable desks
- **Culture:** Inspiring corporate culture with an international team, diversity, and flat hierarchies for idea exchange and quick decision-making
- **Catering: **free fresh fruit as well as non-alcoholic drinks (water dispenser, Fritz-Kola, etc.) and a wide selection of coffee options, canteen allowance
- **Continuous Improvement:** We continuously work on enhancing and optimizing our benefits to make your workday more enjoyable and enriching

**ARE YOU READY TO BE PART OF OUR TEAM?**

ARE YOU READY TO BE PART OF OUR TEAM?

If you've made it this far, then we're sure we share something special - an enthusiasm for the exciting opportunity to be part of our Healy World team! We're thrilled that we've piqued your interest and want you to feel right at home with us right from the start.
Your way to us is very simple: Send us your detailed application and your earliest possible starting date. If you have any questions or need further information, our recruiting team will be happy to help you by e-mail at . We are excited to meet you and look forward to exploring the opportunities at Healy World with you.
Visit our job portal to explore other vacancies you haven't seen yet: [https://healy-world-gmbh.jobs.personio.de/.](https://healy-world-gmbh.jobs.personio.de/)

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
