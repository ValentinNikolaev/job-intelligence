# Senior Marketing Data Analyst Pricing (all genders)

Posted: 2026-09-18T14:55:10Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

## The role

As a **Senior Marketing Data Analyst** on our **Pricing Analytics** team within the Global **Marketing Analytics** organisation, you'll play a pivotal role in driving data-informed pricing and discount decisions at HelloFresh. Based in our Berlin Headquarters, you'll help build best-in-class analytics to support price and discount strategy across HelloFresh's brands — turning data into strategic recommendations, challenging the status quo, and directly shaping how our global brands price, grow, and operate.

Reporting to the Associate Director of Pricing Analytics, you'll partner closely with the commercial Pricing & Discount Strategy team and stakeholders across Product, Engineering, ML&AI, and Finance. You'll bring the toolkit of a data scientist — experimentation, causal inference, and modeling — and the judgment to turn it into decisions. As our scope expands, there's room to grow into broader **Market Insights** work supporting senior leadership across our 15+ markets.

## What You'll Do

- **Own price and discount experiments end to end** — frame the hypothesis, design the test, size it, launch it through our always-on testing program, and deliver the readout.

- **Model how customers respond to price and promotions** — price elasticity, geo-segmented pricing, discount and promo effects, and ML-assisted discount recommendations.

- **Apply causal inference** — incrementality and quasi-experimental methods (difference-in-differences, synthetic control, matching) — to measure true impact where a clean A/B test isn't possible.

- **Ship analysis as data products** — production pipelines and self-serve apps (Databricks, SQL, Python, Streamlit) that stakeholders use directly, not one-off notebooks.

- **Build and enhance reporting and visualization assets** that support day-to-day pricing decisions and strengthen performance oversight.

- **Communicate complex technical findings** as clear recommendations and tangible next steps for commercial leaders without a technical background.

- **Collaborate with data science, finance, and marketing** to measure discount impact consistently across gross and net revenue and short- and long-term customer profitability.

- **Collaborate with and mentor analysts** within the team, championing scalable, automated, and reproducible ways of working.

- **As scope grows**, measure, benchmark, and monitor brand and market performance and help inform Marketing budgets — contributing to the Market Insights agenda alongside senior stakeholders.

## What You'll Bring

- A **motivated, collaborative mindset** with strong team-working skills and a passion for solving complex business problems.

- **4+ years of experience** in data science, analytics, or a related quantitative field — ideally in a fast-paced B2C or subscription business.

- **Strong SQL and Python** (required) — you're comfortable owning an analysis end to end.

- A foundation in **experimental design and A/B testing**, including how to size a test and choose primary and guardrail metrics.

- Working knowledge of **causal inference and econometrics** — price elasticity, incrementality, and quasi-experimental methods.

- Solid **applied statistics**, and familiarity with common **machine-learning** methods (regression, trees, clustering; uplift / heterogeneous-effects a plus) — with the judgment to know when a method genuinely helps and when a simpler approach is better.

- A strong understanding of **Marketing and Growth metrics** and how they connect to overall business performance.

- Comfort in a **modern data stack** (Databricks / Spark / a SQL warehouse) and a visualization tool (**Tableau**, Looker, or Power BI; or apps built in Streamlit).

- A **results-oriented, structured approach**, able to turn vague or ambiguous business questions into clear analytical frameworks and insights.

- Proven **project ownership and stakeholder management**, especially in senior or cross-functional settings.

- **Excellent communication skills in English**, with the ability to explain analytical concepts to non-technical audiences and influence decision-making.

Nice to have:

- Pricing, discounting, or marketing-analytics domain experience.

- Market Insights / market-benchmarking experience supporting senior leadership.

- Bayesian or hierarchical / mixed-effects modeling.

- GenAI / LLM tooling for analytics (e.g., natural-language-to-SQL, agent or assistant surfaces).

## What we offer

Elevate your lifestyle! Join one of Europe's fastest-growing tech powerhouses in a dynamic phase of expansion.

- Immerse yourself in a diverse global community of 90+ nationalities.

- Enjoy a competitive compensation package that goes beyond the norm, with perks like a HelloFresh-subsidized Pension Scheme, Berlin relocation support, and a Hybrid working model.

- Exclusive discounts on your weekly HelloFresh box and office meals.

- Invest in your growth with an annual learning & development budget, German language learning budget, and access to the HelloFresh Academy.

- Plus, we've got your well-being covered with mental health support, transportation perks, and working-parent-friendly benefits. From our 24/7 gym access, wellbeing platforms like Headspace and Spill, to sabbatical leave options, HelloFresh is not just a workplace; it's a lifestyle of perks and possibilities!

## Are you up for the challenge?

Please submit your complete application below including your salary expectations and earliest starting date.

#JD1002

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
