# Growth manager (JetBrains AI)

Posted: 2026-09-18T14:55:13Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

At JetBrains, we’re building an AI-native platform for software development that connects developer workflows, team-level collaboration, and organizational control into a single coherent system. This platform will serve as the execution and governance layer for AI-driven development, deeply integrated with developer tools but designed to work across teams, products, and environments. This is a long-term strategic investment for JetBrains and a key pillar of our vision for the future of software development.

We’re looking for a Growth Manager to own the acquisition, onboarding, and activation journey of JetBrains AI for teams and organizations.

In this role, you’ll help users discover JetBrains AI through JetBrains product surfaces, clarify its value in their development workflows, and reach meaningful product usage as quickly as possible.

You’ll work on product entry points, trial starts, demo and sandbox experiences, onboarding flows, setup journeys, guided education, and activation experiments that help the right audience become active JetBrains AI users.

### **Key responsibilities:**

- Own the acquisition, onboarding, and activation journey of JetBrains AI for teams and organizations.

- Define, measure, and improve the path from relevant product entry points to meaningful product usage.

- Optimize acquisition flows across JetBrains entry points, including IDEs, desktop products, plugins, account flows, contextual prompts, and others.

- Create and improve self-service paths into JetBrains AI, including trial starts, guided demos, sandbox experiences, interactive walkthroughs, and setup flows.

- Design and iterate on onboarding, guided product education, first-run experiences, contextual prompts, empty states, and other moments that help users discover value.

- Identify friction points across entry, signup, setup, onboarding, trial, and first-use flows, and turn them into clear product opportunities.

- Lead experiments aimed at improving acquisition conversion, onboarding completion, trial-to-active conversion, activation, and early repeated usage.

- Partner with the Marketing department on acquisition journeys, campaign-to-product continuity, life cycle flows, and the transition from marketing touchpoints to product experience.

- Partner with monetization specialists on trial experience, upgrade prompts, usage limits, and commercial constraints.

- Work closely with design, engineering, analytics, research, marketing, monetization, and other product teams to ship measurable improvements to the early user journey.

- Establish clear growth hypotheses, prioritize experiments, analyze results, and turn learnings into product and business decisions.

** **

### **We’ll be happy to have you on our team if you:**

- Have experience in onboarding, activation, and driving product-led growth in developer tools, SaaS, or AI products.

- Have worked on improving acquisition-to-activation funnels, product entry points, onboarding flows, trial experiences, or new-user experiences.

- Understand how to connect marketing touchpoints with product-side acquisition into a coherent user journey.

- Are comfortable using product analytics, funnels, cohorts, segmentation, and qualitative insights to understand user behavior.

- Have experience designing, running, and interpreting product experiments.

- Can translate ambiguous growth problems into focused hypotheses, product changes, and measurable outcomes.

- Understand how to help users reach value quickly without relying on heavy sales assistance or manual onboarding.

- Have strong UX judgment and care about reducing friction, clarifying value, and building trust with users.

- Can collaborate effectively with engineering, design, analytics, marketing, monetization, research, and other product teams.

- Communicate clearly and can align stakeholders around funnel insights, growth priorities, and experiment results.

### **We’ll be especially thrilled if you:**

- Have experience with AI-powered products, developer tools, IDEs, DevOps platforms, or software engineering workflows.

- Have designed acquisition, onboarding, or activation experiences for complex technical products.

- Have worked on product-led acquisition from owned product surfaces, such as in-app prompts, contextual entry points, trial starts, demos, sandboxes, and interactive walkthroughs.

- Understand product-led growth in B2B or prosumer products, especially where individual users can influence wider adoption.

- Are familiar with behavioral analytics tools, experimentation platforms, funnel analysis, cohort analysis, and activation modeling.

- Have a strong intuition for developer audiences and understand their expectations around control, transparency, low friction, and practical value.

### **
Why join JetBrains? **

- Strong base salary. We offer competitive pay that reflects your skills and experience.

- Flexible work location. Enjoy the freedom to work from home or from the office.

- Remote work. Spend up to 30 days per year working remotely from abroad.

- Extra time off. More days to relax, recharge, and do the things you love.

- Medical insurance allowance. Enjoy peace of mind for you and your family

- Learning and development opportunities. Access to conferences, courses, and language classes.

- Language classes. Pick up the local language or sharpen your English skills.

- Fuel your day. Enjoy a hot meal or receive a lunch allowance on workdays.

- Mental health support. To help you feel your best, we provide easy access to professional mental health services.

- Sports benefit. Enjoy an on-site gym or sports club stipend.

- Internal events. Join company-wide celebrations and team gatherings.

*Some benefits may vary depending on location.

x

#LI-KL1

**We are an equal opportunity employer**

We know great ideas can come from anyone, anywhere. That’s why we do our best to create an open and inclusive workplace – one that welcomes everyone regardless of their background, identity, religion, age, accessibility needs, or orientation.

*We process the data provided in your job application in accordance with the [Recruitment Privacy Policy.](https://www.jetbrains.com/legal/docs/privacy/privacy-recruitment/)*

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
