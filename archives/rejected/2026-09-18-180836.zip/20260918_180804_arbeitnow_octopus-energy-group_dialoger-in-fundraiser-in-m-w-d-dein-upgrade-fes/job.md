# Dialoger*in / Fundraiser*in (m/w/d) Dein Upgrade: Festanstellung

Posted: 2026-09-18T14:24:51Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

### Gutes Geld verdienen und trotzdem gut schlafen?

Du willst keinen Sales-Job, bei dem du dich jeden Tag aufs Neue überwinden musst, hinter deinem Produkt zu stehen? Du willst Menschen begeistern, gute Gespräche führen und dabei richtig gutes Geld verdienen?

Dann könnte das hier dein nächster Sales-Job sein.

### Face-to-Face Sales mit echtem Mehrwert

Bei Octopus Energy sprichst du Menschen** **direkt am Point of Sale an und begeisterst sie für erneuerbare Energie. Du erkennst, was sie brauchen, beantwortest ihre Fragen und zeigst ihnen, welches Angebot zu ihnen passt.

Kein Klinkenputzen, keine kalten Füße und kein Verkauf um jeden Preis: Du arbeitest warm und trocken in gut besuchten Einkaufscentern – gemeinsam mit deinem Team und mit einem Produkt, hinter dem du stehen kannst.

### Was du davon hast?

**3.000–4.000 € brutto monatlich** durch sicheres Fixgehalt und ungedeckelte Provision – deine Leistung zahlt sich aus. Dazu kommen 30 Tage Urlaub, ein unbefristeter Vertrag und jede Menge Benefits.

Du kannst Sales. Wir geben dir ein Produkt mit Purpose dazu.

**Das bist du (Deine Superkräfte):**

- **Offenheit:** Du gehst gerne, offen und ohne Zögern auf Menschen zu.

- **Kommunikationstalent:** Ein „Nein“ wirft dich nicht aus der Bahn, sondern motiviert dich. Mit sehr guten Deutschkenntnissen (mindestens C1) berätst du unsere Kund*innen am Point of Sale persönlich und erklärst auch komplexe Themen verständlich.

- **Dein Hintergrund:** Egal ob Greenpeace, WWF, eine F2F-Agentur oder Promotion, Hauptsache, du hast Energie und Herzblut für das, was du tust.

**Der ehrliche Deal (Wir spielen mit offenen Karten):**

Ja, die Fläche ist intensiv.
Du bist 8 Stunden auf den Beinen und sprichst aktiv rund 200 Menschen am Tag an.
Ablehnung gehört im Vertrieb einfach dazu, deshalb ist deine mentale Stärke dein wichtigstes Werkzeug.

Aber der große Unterschied zum klassischen Infostand: Du wirst hier nicht allein gelassen. Unser Team fängt dich auf, und jedes erfolgreiche Gespräch bringt dich spürbar weiter, auf dem Konto, im Team und in deiner persönlichen Entwicklung.

**Das kriegst du von uns:**

- **Sicherheit:** Eine echte Festanstellung statt eines unsicheren Minijobs oder reiner Honorarbasis.

- **3.000–4.000 € brutto monatlich:** Sicheres Fixgehalt plus ungedeckelte Provision.

- **Echte Perspektiven:** Klarer, transparenter Aufstieg vom Hero zur Teamleitung und weiter.

- **Kultur mit Herz:** Ein lebendiges, herzliches Team und eine Marke mit echter Haltung, hinter der du voll und ganz stehen kannst.

Deine Benefits bei uns:

✅ Vergünstigungen & Vorsorge:

- Aktienoptionen der Octopus Energy Group Ltd.

- Vergünstigte Konditionen für unsere Strom- und Gastarife

- Monatlicher Zuschuss zum Nahverkehrsticket

- Monatlicher Zuschuss zum Mittagessen

- Vergünstigtes Fahrradleasing

- Betriebliche Altersvorsorge
- Nachhaltig unterwegs mit unserem E-Auto-Leasing

✅ Familie

- Beratungsangebote und Unterstützung bei Kinderbetreuung über HeyNanny

- Monatlicher Zuschuss zur Kinderbetreuung

- Elterngeld-Bonus: Wir stocken dein Elterngeld für** 3 Monate **auf, damit du deine Elternzeit entspannter genießen kannst

✅ Sport & Gesundheit

- Zuzahlungen zu Fitness- Angeboten über Wellpass

- Förderung deines mentalen Wohlbefindens mit unserem Partner Open Up

✅ Lernen & Weiterbildung

- Attraktive Weiterbildungsmöglichkeiten und Aufstiegsmöglichkeiten

- Kostenlose Sprachkurse über Busuu

✅ Extra Goodies

- Gutschein zu deinem Geburtstag

Bewirb dich in nur 2 Minuten, ganz ohne langes Anschreiben:

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
