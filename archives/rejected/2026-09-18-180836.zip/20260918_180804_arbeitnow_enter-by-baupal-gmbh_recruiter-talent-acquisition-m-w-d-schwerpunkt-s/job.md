# Recruiter / Talent Acquisition (m/w/d) - Schwerpunkt Sales Recruiting

Posted: 2026-09-18T16:30:41Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

## Die steigenden Energiekosten treffen jeden Haushalt. Wir senken, was gerade am meisten wehtut.

Enter ist die Antwort auf eine Frage, die sich gerade Millionen Hausbesitzer stellen: Nicht ob ihr Haus elektrifiziert wird – sondern wie, und mit wem. Bei steigenden Energiekosten helfen wir Haushalten durch die Installation der richtigen Wärmepumpen und PV-Anlagen jährlich um die 1.500€ einzusparen.

Als Deutschlands führender Energieberater mit über 40 Millionen Euro Funding und über 90 Mitarbeitern sind wir erfahrene Pioniere in einem Markt, der gerade erst so richtig losgeht.

Enter. Jetzt ist der Moment.

## Die Fakten.

- Start: 15.10.

- Gehalt: €40.000-50.000 brutto pro Jahr

- Arbeitsort: Büro an der Spree (Schlesische Str. 26, 10997 Berlin)

- Homeoffice Möglichkeiten

- Arbeitszeit: Vollzeit (40h/w) und flexible Arbeitszeiten (spätester Beginn um 9:30 Uhr)

- Benefits: Learning-Budget, Urban Sports Clubs, Jobticket- oder Kita-Zuschuss; Betriebliche Altersvorsorge; Team-Events, die nicht langweilig werden

## Was Du machen wirst.

Du gestaltest mit unserem People Lead das Wachstum unseres Sales Teams.

- End-to-End Recruiting mit Fokus auf Sales-Positionen (Pre-Sales & Sales Manager, unterstützend für weitere Rollen)

- Active Sourcing als Kernaufgabe: gezielte Direktansprache über LinkedIn Recruiter & weitere Kanäle

- Screening von Bewerbungen und Führen von Erstgesprächen

- Aufbau und Pflege eines warmen Talentpools

- Enge Zusammenarbeit mit den Hiring Managern im Sales-Team

- Erstellung und laufende Optimierung von Stellenausschreibungen

- Mitwirkung an Recruiting-Kampagnen (Multi-Channel-Postings, Social Media)

- Recruiting-Ops in Personio: sauberer Prozess, klare Zahlen, verlässliches Reporting

- Je nach Kapazität: Unterstützung bei weiteren People Themen

## Was Du mitbringen solltest.

- Mind. 1 Jahr Erfahrung im Recruiting, davon nachweisbare Praxis im Active Sourcing

- Idealerweise Erfahrung im Sales Recruiting bzw. in einem wettbewerbsintensiven, schnelllebigen Umfeld

- Sicherer Umgang mit LinkedIn Recruiter und gängigen Sourcing-Tools

- Du hast ein gutes Gespür für Menschen und deren Motivation und bist verhandlungssicher

- Du behältst auch bei mehreren offenen Stellen gleichzeitig den Überblick

- Fließendes Deutsch (unsere Unternehmenssprache), gutes Englisch von Vorteil

- Erfahrung mit Personio oder einem vergleichbaren ATS ist ein Plus

## Warum Du Dich jetzt bewerben solltest.

Bei uns zählen Eigenverantwortung, Exzellenz und Energie. Wir denken in Ergebnissen und fordern uns gegenseitig heraus, um Deutschlands führende Kraft in der Umsetzung von energetischen Sanierungen zu werden. Wenn dich das abholt, melde dich.

- **Das Timing ist perfekt.** Werde jetzt Teil von einem der schnellst wachsenden Energie-Startups Deutschlands - finanziert von Europas bekanntesten Venture Capitals

- Arbeite gemeinsam mit ambitionierten Kollegen in einem Umfeld mit spürbarem Momentum

- Unbegrenzte Lernmöglichkeiten und vielseitige Aufstiegschancen

- Spreeblick statt Hinterhof: unser Büro liegt direkt am Wasser, mitten in Kreuzberg

- Individuelles Benefit: Learning-Budget, Urban Sports Clubs, Jobticket- oder Kita-Zuschuss

- Betriebliche Altersvorsorge für deine sichere Zukunft

- Team-Events, die nicht langweilig werden

## Unser Bewerbungsprozess.

Daniel (People Lead) ist Dein Ansprechpartner für diese Rolle.

So geht's weiter:

- **45 Minuten Erstgespräch mit Daniel** (virtuell) – innerhalb einer Woche nach Deiner Bewerbung

- **60 Minuten mit Daniel** (People Lead) und Justus (HRBP) **vor Ort** bei uns im Büro in Kreuzberg

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
