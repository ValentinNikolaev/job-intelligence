# Senior Legal Counsel (m/w/d) – Perspektive General Counsel

Posted: 2026-09-18T14:09:39Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**Deine Aufgaben**

Du übernimmst bei **ryd** eine etablierte Rechtsfunktion in Nachfolge unserer langjährigen General Counsel und berichtest **direkt an den Chairman von ryd**.

Die wesentlichen Strukturen und Prozesse der Rechtsfunktion sind aufgebaut. Du übernimmst diese im Rahmen einer strukturierten Übergabe, führst sie eigenverantwortlich fort und entwickelst sie mit dem Unternehmen weiter. Als zentrale rechtliche Ansprechperson berätst Du die Geschäftsleitung, den Chairman und die Fachbereiche und begleitest ryd bei seinem weiteren Wachstum und der internationalen Expansion.

Die Position ist bewusst mit einer klaren Entwicklungsperspektive angelegt: **Ziel ist die Weiterentwicklung zum General Counsel innerhalb von spätestens 18 Monaten.** Voraussetzung hierfür ist die erfolgreiche Übernahme der Gesamtverantwortung für die Rechtsfunktion – einschließlich der gesellschaftsrechtlichen Themen sowie der Gremien- und Gesellschafterarbeit. Die konkreten Verantwortungsbereiche, Entwicklungsschritte und Ziele werden zu Beginn gemeinsam mit dem Chairman festgelegt.

- Umfassende rechtliche Beratung der Geschäftsleitung, des Chairman und der Fachbereiche in allen für ryd relevanten Rechtsgebieten, insbesondere im Gesellschafts-, Handels-, Vertrags-, Wettbewerbs-, Zivil- und Arbeitsrecht
- Gestaltung, Prüfung und Verhandlung nationaler und internationaler Verträge in deutscher und englischer Sprache sowie Verantwortung für das Vertragsmanagement
- Rechtliche Begleitung gesellschaftsrechtlicher Themen, einschließlich Finanzierungsrunden, Transaktionen, Due-Diligence-Prozessen und Veränderungen der Konzernstruktur
- Vorbereitung und rechtliche Begleitung der Gremien- und Gesellschafterarbeit
- Rechtliche Betreuung der Auslandsgesellschaften sowie Begleitung des Eintritts von ryd in neue Märkte
- Verantwortung für AGB, Nutzungsbedingungen und die rechtlichen Rahmenbedingungen unserer App-, Web- und digitalen Produkte
- Verantwortung für die Datenschutz-Compliance sowie Betreuung marken-, urheber- und sonstiger immaterialgüterrechtlicher Fragestellungen
- Rechtliche Begleitung unserer Payment-Produkte und Geschäftsmodelle in Zusammenarbeit mit Banken, Zahlungsdienstleistern und weiteren regulierten Partnern
- Bewertung der rechtlichen und regulatorischen Anforderungen bei der Entwicklung neuer Produkte, Geschäftsmodelle und Märkte
- Arbeitsrechtliche Beratung der Geschäftsleitung und enge Zusammenarbeit mit HR
- Betreuung von Rechtsstreitigkeiten sowie Auswahl, Beauftragung und Steuerung externer Kanzleien
- Weiterentwicklung der Legal-Prozesse, Vertragsstandards und internen Governance-Strukturen mit dem Wachstum von ryd

**Deine Qualifikationen**

- Volljurist:in mit mehrjähriger einschlägiger Berufserfahrung in einem Unternehmen und/oder einer wirtschaftsrechtlich ausgerichteten Kanzlei
- Breite generalistische juristische Aufstellung und ausgeprägtes Verständnis für wirtschaftliche und unternehmerische Zusammenhänge
- Erfahrung in der eigenständigen Gestaltung und Verhandlung komplexer Verträge
- Fähigkeit, rechtliche Risiken klar einzuordnen und zugleich pragmatische und geschäftsorientierte Lösungen zu entwickeln
- Hoher Grad an Eigenständigkeit, Verantwortungsbewusstsein und die Bereitschaft, Themen konsequent bis zum Abschluss zu führen
- Souveränes Auftreten gegenüber Geschäftsleitung, Gesellschaftern, Geschäftspartnern und externen Beratern
- Sehr gute Deutsch- und Englischkenntnisse in Wort und Schrift; weitere Sprachen sind willkommen
- Fundierte Kenntnisse im Datenschutzrecht
- Idealerweise Erfahrung im Payment-, FinTech-, Mobility-, Plattform- oder technologiegetriebenen Umfeld
- Interesse daran, eine bestehende Rechtsfunktion weiterzuentwickeln und perspektivisch als General Counsel die Gesamtverantwortung zu übernehmen

**Was wir dir bieten**

-

#shapingryd ist einer unserer Werte – wir entwickeln uns gemeinsam vom Start-up zum Scale-up, und du gestaltest mit, wie CS & Operations bei ryd skalieren.

-

Wettbewerbsfähiges Gehalt, betriebliche Altersvorsorge und ein solides Budget, um Top-Talente einzustellen und die Tools zu beschaffen, die du brauchst.

-

Wir investieren in deine Entwicklung – Mentoring durch das Leadership-Team, Coaching für das Skalieren von Operations und kontinuierliche Weiterbildungsmöglichkeiten.

-

Jährliches Weiterbildungsbudget für deine fachliche Entwicklung – schreibe deine eigene Erfolgsgeschichte.

**Kontakt**

Caroline da Silva Fischer
HR Generalist

ryd GmbH | Landsberger Str. 94 | 80339 Munich, Germany |
[ryd.one |](http://ryd.one/)

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
