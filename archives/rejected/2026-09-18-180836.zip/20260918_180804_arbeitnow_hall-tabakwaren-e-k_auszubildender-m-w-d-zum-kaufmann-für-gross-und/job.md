# Auszubildender (m/w/d) zum Kaufmann für Groß- und Außenhandelsmanagement in Plaidt

Posted: 2026-09-18T14:30:09Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

***Hall Tabakwaren* ist bundesweit in aller Munde.** 1903 als Ladengeschäft für Zigarren, Rauchtabak und Zigaretten gegründet, sind wir heute einer der führenden Tabakwarengroßhändler in Deutschland. In unserem in 5. Generation inhabergeführten Familienunternehmen sorgen über 750 Mitarbeiterinnen und Mitarbeiter in 11 Niederlassungen mit 350 firmeneigenen Fahrzeugen und 30.000 Cigarettenautomaten dafür, dass Menschen im gesamten Bundesgebiet schnell, sicher und zuverlässig zu ihrer Lieblingsmarke kommen. Mit unserer Erfahrung, unserer Leidenschaft und unserem Engagement – auch für unsere rund 5.000 Einzelhandelskunden – erwirtschaften wir jährlich mehr als 1,2 Milliarden Euro Umsatz. Und wir wachsen weiter, gerne mit Ihnen als

** **

**Auszubildender (m/w/d) zum Kaufmann für Groß- und Außenhandelsmanagement in Plaidt**

** **

**Hier gehst Du ans Werk:**

-

Im Rahmen deiner dreijährigen Ausbildung wechselst du regelmäßig zwischen unseren Abteilungen und erhältst wertvolle Einblicke in die Buchhaltung, den Vertrieb, unser Lager sowie in unseren gesamten Innen- und Außendienst.

-

Deine freundlichen Kolleginnen und Kollegen bringen dir bei, wie Rechnungswesen in der Praxis funktioniert und worauf es bei der Steuerung und Verwaltung unserer betrieblichen Abläufe ankommt.

-

Außerdem lernst du, wie du neue Kunden gewinnst und dafür sorgst, dass bestehende Kunden langfristig mit uns zufrieden sind.

-

Bald hast du dir jede Menge Können und Fachwissen angeeignet und bist bestens vorbereitet, neue, verantwortungsvolle Aufgaben bei uns zu übernehmen.

**So entfachst Du unser Feuer:**

Du hast einen Real- oder Hauptschulabschluss oder bist kurz davor, ihn zu bekommen. Außerdem interessieren dich wirtschaftliche Zusammenhänge, du kannst gut rechnen und dich schriftlich ausdrücken. Es wäre super, wenn du schon Kenntnisse in Microsoft Office besitzt, um leichter in unser EDV-System zu starten. Pünktlichkeit und gute Umgangsformen sind für dich selbstverständlich und zudem hast du Spaß an Teamarbeit.

**Deine Ausbildungsvorteile bei uns:**

++ Sehr abwechslungsreiche Ausbildung ++ Überdurchschnittliche Ausbildungsvergütung ++ Viel Eigenverantwortung ++ Übernahme nach Ausbildung erwünscht ++ 28 Tage Urlaub im Jahr ++

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
