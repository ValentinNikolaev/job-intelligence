# Business and Legal Affairs Manager, The Orchard

Posted: 2026-09-18T14:55:09Z

## Rejection

- Category: language_requirement
- Reason: hard German language requirement without English green light

Bei The Orchard ist ab sofort eine Position im Bereich Business and Legal Affairs zu besetzen – an unserem Standort Berlin. Als Volljurist:in unterstützt Du das Tagesgeschäft und die rechtlichen Anforderungen unseres Business- und Legal-Affairs-Teams.

The Orchard ist ein führendes Unternehmen für Musikvertrieb und Artist Services mit Sitz in New York und in 45 Märkten weltweit tätig – im Vertrieb unabhängiger Künstler:innen wie Bad Bunny, Gorillaz und Raye. Mit modernsten Abläufen und einem einzigartigen globalen Team arbeiten wir mit Labels jeder Größe zusammen und machen deren Musik und Videos bei Hunderten von digitalen und physischen Händlern rund um den Globus verfügbar.

Leidenschaft für Musik und die Musikbranche ist ein Muss. Mit Deinem professionellen und souveränen Auftreten baust Du starke Beziehungen zu Kolleg:innen und externen Kund:innen auf und pflegst diese. Dafür schaffen wir ein angenehmes, offenes und inspirierendes Umfeld, das Produktivität und Kreativität fördert.

Das Team von The Orchard trifft sich von Montag bis Donnerstag im Büro. Freitags wird in der Regel im Homeoffice gearbeitet.

**Was du tun wirst:**

- Entwerfen, Verhandeln und Finalisieren von Vertriebsverträgen mit Labels und Künstler:innen.

- Entwerfen, Verhandeln und Finalisieren von Musikverlags- und Merchandising-Verträgen.

- Entwerfen, Verhandeln und Finalisieren von Vertragsänderungen, Abtretungen und Kündigungen nach Bedarf.

- Unterstützung bei Mergers & Acquisitions im deutschen Markt.

- Beratung der Business- und globalen Legal-Teams zu Fragestellungen des deutschen Rechts und der hiesigen Praxis.

- Mitarbeit im globalen Legal-Team, um Stakeholder:innen vor Ort rechtlich zu beraten.

- Mitwirkung bei der Erstellung, Optimierung und Aktualisierung von Standardvertragsmustern.

- Mitverantwortung für die Bearbeitung und Beilegung rechtlicher Ansprüche.

**Wer du bist:**

- Juristischer Abschluss und 2–4 Jahre Berufserfahrung in einer vergleichbaren Position und Branche.

- Fundierte Kenntnisse des deutschen Musikrechts.

- Erfahrung mit Vertriebsverträgen.

- Ausgezeichnete mündliche und schriftliche Kommunikationsfähigkeiten.

- Ausgezeichnete Fähigkeiten in der Vertragsgestaltung.

- Fundiertes Fachwissen in allen Facetten des Musikgeschäfts.

- Ausgeprägtes Organisationstalent mit der Fähigkeit, eine Vielzahl von Projekten im Blick zu behalten, zu priorisieren und sich auf wechselnde Prioritäten einzustellen.

- Ausgeprägt selbstständige Arbeitsweise und nachweisliche Erfahrung im erfolgreichen Abschluss von Deals.

**English Translation:**

The Orchard has an immediate opening in Business and Legal Affairs at our Berlin office. As a qualified lawyer, you will support the day-to-day legal needs and requirements of our Business and Legal Affairs team.

The Orchard is a leading music distribution and artist services company headquartered in New York and operating in 45 markets worldwide – distributing music from independent artists including Bad Bunny, Gorillaz, and Raye. With cutting-edge operations and an unparalleled global team, we partner with labels of all sizes to make their music and video available across hundreds of digital and physical retailers around the world.

A passion for music and the music industry is a must. Your professional and confident approach will enable you to build and maintain strong relationships with your colleagues and external clients. In turn, we provide a comfortable, social, and engaging environment that encourages productivity and creativity.

**What You’ll Do: **

- Drafting, negotiating, and finalising label and artist distribution agreements.

- Drafting, negotiating, and finalising music publishing and merchandising agreements.

- Drafting, negotiating, and finalising amendments, assignments, and terminations as needed.

- Assistance with mergers and acquisitions in the German market.

- Advising the business and global legal teams on issues particular to German law and practice.

- Working within the global legal team to provide in-territory legal advice to stakeholders.

- Assisting to create, refine, and update standard contract forms.

- Co-managing legal claim resolution processes.

### Who You Are:

- Law Degree and 2-4 years of experience in a similar position and industry.

- Thorough knowledge of German music law.

- Experience with distribution contracts.

- Excellent verbal and written communication skills.

- Excellent drafting skills.

- Specialised knowledge throughout all facets of the music business.

- Highly organised with an ability to track and prioritise a high volume of projects and adjust to changing priorities.

- Strong autonomous working style with a proven ability to close deals.

**Equal Opportunities**

As an active part of a culturally and socially diverse society, Sony Music’s aim is that our workforce is diverse and inclusive. Sony Music is an equal opportunity employer and supports workforce diversity.

We employ, retain, promote and otherwise treat all employees and job applicants according to their merit, qualifications, competence and talent. We apply this policy without regard to any individual’s sex, race, religion, origin, age, sexual orientation, marital status, medical condition or disability.

**Privacy Policy**

Please click [here](https://www.sonymusic.com/privacy-policy/) to read our privacy policy before beginning the application process as you will need to agree to the terms of the policy before submitting your information.

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
