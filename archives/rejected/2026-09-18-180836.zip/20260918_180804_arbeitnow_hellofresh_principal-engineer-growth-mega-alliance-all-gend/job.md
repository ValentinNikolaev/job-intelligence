# Principal Engineer, Growth Mega Alliance (all genders)

Posted: 2026-09-18T14:55:10Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

## **The Role**

The Growth Mega Alliance (GMA) builds the platforms that power how HelloFresh acquires, converts, and retains customers across 18 markets and multiple brands, across five pillars: AdTech, Conversions, Payments, Communications, and Customer Value Optimization (CVO).

As Principal Engineer, you are the technical visionary for these platforms. You define architectural direction across all five pillars, lead the most consequential cross-cutting initiatives, and raise the technical bar for the entire organization. This is a hands-on leadership role - you code, review, and design alongside the senior and staff engineers who look to you as the technical lead.

## **What You'll Do**

### **GenAI & Agentic Engineering Leadership**

- Own GMA's GenAI strategy: identify the highest-leverage opportunities across all five pillars where AI/ML unlocks step-change outcomes, for both engineering productivity and customer-facing capabilities.

- Establish agentic development workflows — where specs drive AI-assisted code generation — and scale them from early adopters to standard practice. Build the guardrails and reference architectures that enable squads to work AI-natively.

- Develop and articulate a clear point of view on how engineering teams need to evolve in skills, process, and culture to realize the gains that agentic tools make possible.

### **Growth Platform Architecture**

- Own the long-term technical architecture across GMA's five pillars: real-time personalization, experimentation at scale, AI/ML-driven automation, and cross-pillar data integrity.

- Lead the most complex architectural decisions (shared identity schemas, experiment assignment, AdTech-to-Conversions signal loops, payment authorization flows) and drive migrations with large impact.

- Ensure GMA platforms integrate cleanly with internal infrastructure and meet reliability, latency, and observability requirements at a global scale.

### **Experimentation & Personalization**

- Define GMA's experimentation strategy and execution framework to optimize experimentation-based decision-making at scale.

- Own the data path from customer event to business decision: instrumentation standards, identity resolution, attribution windows, and signal quality.

### **Technical Strategy & Cross-Alliance Collaboration**

- Define GMA's multi-year technical vision and communicate it with the precision engineers need and the clarity executives can act on. Represent GMA in company-wide programs.

- Partner with Intelligent Platforms, Consumer, and Operations Mega Alliances to drive shared architectural standards and prevent fragmentation.

### **Mentorship & Engineering Culture**

- Coach and grow Staff and Senior Engineers across all five pillars. Foster engineering excellence through rigorous design review, strong observability practice, and honest post-incident learning.

- Champion AI-native development workflows, TDD, DDD, and DevSecOps. Set the written communication standard through your design docs and architectural decision records.

## **What You'll Bring**

### **GenAI & Agentic Engineering**

- Practical, hands-on experience with AI coding agents (e.g., Claude Code, Cursor, GitHub Copilot, OpenCode) in production or near-production environments — not just experimentation.

- Experience integrating GenAI into customer-facing products or internal business processes at scale, with a clear point of view on the team and cultural changes required to realize the productivity gains.

### **Growth Domain Expertise**

- Deep familiarity with at least two of: AdTech / paid media infrastructure, funnel optimization, payment orchestration, CRM and lifecycle communications, or pricing and incentive optimization.

- Fluent in growth domain constraints: PSP behavior, consent and privacy requirements across markets, deliverability limits, attribution windows, and incrementality measurement. Experience in a multi-market subscription or e-commerce business preferred.

### **Technical Depth**

- ~10+ years in software engineering, with ~5+ years at principal level in a high-growth, cloud-native environment.

- Expert in distributed systems, microservices, and event-driven patterns (Kafka). Deep AWS experience. Strong proficiency in Go, Kotlin, Python, or TypeScript.

- Track record of designing and operating large-scale, multi-region systems. Comfortable doing hands-on architectural reviews and solving critical bottlenecks directly.

- Working knowledge of experimentation design and analysis; able to work directly with data (SQL, BI tooling) and trace the full signal chain from instrumentation to business metric.

### **Ways of Working**

- Exceptional written communication — your documents make complexity smaller, not larger.

- Able to influence without authority; direct, low-ego, and comfortable disagreeing with senior stakeholders while keeping the relationship intact.

- Fluent English. German is a bonus.

## **What Success Looks Like**

**3 months — **You have mapped GMA's critical architectural dependencies and GenAI opportunities, conducted design reviews across multiple pillars, and established a point of view on the highest-leverage technical bets for the year.

**6 months — **Your architectural direction is reflected in roadmaps. GMA's first AI-native workflows are in production. At least one cross-pillar initiative is running under your technical ownership with clear instrumentation.

**12 months — **GMA's platforms are measurably more scalable, observable, and AI-capable. Engineering standards are set and followed. You are the person leaders across HelloTech bring their hardest growth-engineering problems to.

## **Why Work With Us**

- **Make an Impact: **GMA's platforms touch every customer HelloFresh acquires and every euro it collects. Your decisions move top-line numbers at a company that has changed the way millions of people eat.

- **Real Scope: **You own technical direction, make consequential architectural calls, and ship things that matter — at a scale that makes the problems genuinely hard.

- **AI at the Frontier: **You will have the mandate, resources, and organizational support to lead AI-native engineering transformation — not advocate for it from the sidelines.

- **Direct Access: **You work daily with engineering, product, and business leadership, with the visibility and accountability that implies.

- **Learn & Grow: **Annual learning budget, HelloFresh Academy, and internal mobility across a large, technically ambitious engineering organization.

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
