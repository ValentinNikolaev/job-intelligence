# Werkstudent:in Fullstack Developer - ERP & Prozessautomatisierung (m/w/d)

Posted: 2026-09-18T14:10:01Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**Deine Aufgaben**

- **Du unterstützt uns bei der Weiterentwicklung** unserer Webshop-, ERP- und Warehouse-Tools – vom Frontend bis zum Backend.
- **Du entwickelst gemeinsam mit unserem Team **neue Funktionen mit Technologien wie React/Next.js, Vue/Nuxt, TypeScript und Node.js.
- **Du hilfst dabei, Schnittstellen zwischen Webshop, ERP, Versanddienstleistern** und Lieferanten weiterzuentwickeln.
- **Du analysierst bestehende Prozesse und bringst eigene Ideen ein,** wie wir Abläufe durch Software und Automatisierung verbessern können und unterstützt bei der Umsetzung von Prozessen aus Lager, Versand und Einkauf.
- **Du arbeitest mit modernen KI- und LLM-Tools** und unterstützt bei deren Einsatz für z. B. Belegerkennung, Datenextraktion oder die Automatisierung von Workflows.

**Dein Profil**

- **Du studierst Informatik**, Software Engineering, Wirtschaftsinformatik oder einen vergleichbaren Studiengang.
- **Du hast erste Erfahrung in der Webentwicklung**, idealerweise mit React, Vue oder TypeScript.
- **Du hast Interesse an Fullstack-Entwicklung** und möchtest deine Kenntnisse im Frontend und Backend weiter ausbauen.
- **Grundkenntnisse in Datenbanken und APIs** sind von Vorteil.
- **Du interessierst dich dafür, wie Software reale Geschäftsprozesse **wie Lager, Versand, Einkauf und Buchhaltung abbildet.
- **Du hast Lust, neue Technologien auszuprobieren** und dich beispielsweise mit KI- und LLM-Anwendungen zu beschäftigen.
- **Du arbeitest selbstständig, zuverlässig** und gerne im Team.
- **Du bringst Neugier mit** und hast keine Angst davor, dich in neue Themen einzuarbeiten.

**Warum wir?**

- **Wertschätzung ****u****nd Teamgeist:**** **Wir schaffen ein unterstützendes Umfeld, in dem deine Passion und Eigenverantwortung geschätzt werden.
- **Gestaltungsfreiheit in einem dynamischen Umfeld:** Hier kannst du deine Ideen sofort umsetzen und aktiv zum Erfolg beitragen!
- **Persönliche und berufliche Weiterentwicklung:** Bei uns hast du hervorragende Aussichten auf berufliche Weiterentwicklung - wir setzen auf den langfristigen Aufbau unseres Teams.
- **Attraktive Vergütung:**** **Wir honorieren deine Arbeit mit einer Vergütung, die sich sehen lassen kann.
- **Work-Life-Balance:**** **Modernes Arbeitsumfeld, mobiles Arbeiten und flexible Arbeitszeiten sind unser Standard.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
