# EDI Developer/ Technical Lead

Posted: 2026-09-18T15:01:47Z

## Rejection

- Category: language_requirement
- Reason: hard German language requirement without English green light

## Tasks

EDI Developer/Technical lead

Location: Stuttgart, Germany ( Remote) Occasional travel to client sites at Stuttgart.

**Duration: 12months+ Contract with Possible extension**

**Experience:** 5-10 Years

**Job Summary**

We are seeking an experienced EDI Axway TSIM Developer/Consultant with strong expertise in EDI/B2B integrations, EDI platform operations, mapping development, partner onboarding, and production support. The candidate will be responsible for designing, implement, ting, monitoring, and supporting EDI integrations across customers, suppliers, and ERP systems.

**Responsibilities**

- Analyze business requirements and implement EDI integration solutions using Axway TSIM.

- Develop, support, and optimize EDI mappings and interfaces.

- Monitor EDI message flows and resolve production issues.

- Configure and support trading partner onboarding and communication setups.

- Perform incident management, problem management, and root cause analysis.

- Prepare technical specifications, mapping documents, and solution designs.

- Conduct testing, partner certification, go-live, and production support activities.

- Participating in or leading EDI and integration projects.

- Collaborate with business teams, customers, suppliers, and external partners throughout project delivery.

## Requirements

**Required Skills**

- 5+ years of experience in EDI/B2B integration and support.

- Hands-on experience with Axway TSIM and SAP PO, SAP Integration Suite / SAP CI

- Strong knowledge of EDIFACT, ANSI X12, VDA, and Odette standards.

- Experience with automotive messages such as DELFOR, DELJIT, DESADV, INVOIC, and ORDERS.

- Experience with EDI mapping technologies and structured data formats (XML, XSLT, IDOC, JSON, CSV).

- Knowledge of communication protocols: AS2, OFTP2, SFTP, HTTPS, SOAP, and REST APIs.

- Good Understanding of SAP business processes (MM, SD, Logistics, Finance) and ERP integrations.

- Strong troubleshooting, monitoring, incident management, and root cause analysis skills.

- German: business fluent / negotiation level

**Must -Have**

- Experience with SAP PO/PI and SAP Integration Suite (CPI/CI).

- Knowledge of API-led and hybrid integration architectures.

- Automotive industry experience and knowledge of supplier integrations.

- Experience in international IT projects.

- Familiarity with Agile and Waterfall methodologies.

**Education**

- Bachelor's degree in Computer Science, Information Technology, Engineering, or a related field.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
