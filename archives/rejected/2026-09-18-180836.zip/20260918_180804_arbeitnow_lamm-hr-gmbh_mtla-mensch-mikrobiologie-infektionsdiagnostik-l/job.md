# MTLA (Mensch) – Mikrobiologie, Infektionsdiagnostik & Labormedizin | Labor Mainz

Posted: 2026-09-18T14:30:14Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

### **Starte durch in der Mikrobiologie!**

Du bist MTLA (Medizinisch-technischer Laborassistent) und hast eine Leidenschaft für mikrobiologische Diagnostik? In einem hochmodernen Labor in Mainz kannst du mit den neuesten Technologien arbeiten und täglich zur medizinischen Präzision und Patientensicherheit beitragen.

### **Deine Aufgaben:**

-

Probenverarbeitung (Stuhl, Urin, Trinkwasser, Varia)

-

Bakterienkulturen anzüchten und identifizieren (Koloniemorphologie, Mikroskopie, biochemische Tests)

-

Pilzdiagnostik (Dermatophyten, Hefepilze, Schimmelpilze)

-

Mikroskopischer und immunologischer Nachweis von Parasiten und Amöben

-

Keimidentifizierung mit MALDI-TOF und Vitek-XL sowie Empfindlichkeitsbestimmung

-

Mikrobiologische Trinkwasseranalysen (Legionellen, Pseudomonaden, Koloniezahl)

-

Qualitätsmanagement (interne und externe Qualitätskontrollen, SOP-Erstellung)

### **Dein Profil:**

-

Abschluss als MTLA (Medizinisch-technischer Laborassistent)

-

Erfahrung in Mikrobiologie, Labormedizin oder Infektionsdiagnostik von Vorteil

-

Selbstständige, sorgfältige und teamorientierte Arbeitsweise

-

Sehr gute Deutschkenntnisse (mindestens C1-Niveau)

### **Deine Vorteile:**

-

Attraktive Vergütung inklusive Weihnachtsgeld und Zuschüsse

-

Geregelte Arbeitszeiten ohne Nacht- und Sonntagsdienste

-

Umfassende Einarbeitung und Fortbildungen

-

Modernste Laborausstattung und innovative Diagnostikverfahren

-

JobRad, JobTicket und kostenfreier Firmenparkplatz

-

Betriebliche Altersvorsorge und Gesundheitsangebote

-

Betriebsverpflegung mit Essenszuschuss

-

Firmenfitness mit EGYM Wellpass und regelmäßige Firmenevents

**Jetzt bewerben und Karriere in der Mikrobiologie starten!**

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
