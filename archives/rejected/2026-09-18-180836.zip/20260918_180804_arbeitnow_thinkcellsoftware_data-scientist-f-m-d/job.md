# Data Scientist (f/m/d)

Posted: 2026-09-18T14:55:16Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**Data Scientist**** - Join Our Innovative Team at think-cell Software**

**Our Story**
At thinkcell, we create powerful software solutions that help professionals be more efficient and productive. Founded in 2002 and based in Berlin, our tools integrate seamlessly with Microsoft Office to help users create presentations, charts, and diagrams with ease. Our dynamic, international team values creativity, collaboration, and technical excellence.

**What You Will Do** 

We're a Data Team that operates like a scaleup within an established company: real ownership, short decision paths, and room to shape things. No corporate bureaucracy – but the resources of a mature business. Our team is made up of experienced senior individual contributors who work independently, challenge each other constructively, and collaborate closely on solving complex problems. It is an environment with a high level of trust, autonomy, and strong opportunities to learn from experienced peers across both technical and business topics.

You don't just analyze – you drive. You proactively identify gaps, inefficiencies, and opportunities for improvement, build the foundations to answer questions, and make sure stakeholders don't just receive dashboards, but know what to do with them.

**Key Responsibilities:**

- Translate complex product and business questions into structured analytical, statistical, and machine-learning approaches

- Develop predictive and diagnostic models and derive robust signals from customer, product, and behavioural data

- Own solutions end to end - from outcome definition, feature engineering, and validation to operationalization, monitoring, and continuous improvement

- Design analyses that identify meaningful drivers, test assumptions, and quantify uncertainty

- Create reusable analytical assets, including models, scores, features, and evaluation frameworks

- Partner with Product, Marketing, Commercial, and other teams to turn complex findings into clear decisions and actions

**You will be great for this position if you have** 

- 3+ years of experience in Data Science, Advanced Analytics, or a comparable role

- Strong SQL and Python skills, including experience with common data science and machine-learning libraries

- Solid knowledge of statistical and predictive modelling, feature engineering, and model evaluation

- Experience operationalizing analytical models for recurring business use

- A strong understanding of validation, data leakage, bias, uncertainty, and model limitations

- A pragmatic approach focused on the simplest reliable solution

- Strong stakeholder management skills and the ability to challenge assumptions and communicate what data can and cannot support

- A proactive, ownership-driven way of working

**Our Values**

As part of our team, you will embody and help shape the following principles that define us: 

**Forward Thinking**: We embrace change and challenge the status quo.

**Ownership**: We take pride in our work and learn from our mistakes.

**Customer First**: We prioritize delivering lasting value.

**Unified Team**: We foster collaboration, respect, and integrity.

**Strive for Excellence**: We set ambitious goals and pursue quality.

We believe in a human hiring process, every application is personally reviewed.

**Why is think-cell the right place for you?**

We empower over 1.3 million users across 35,000 companies, including top consulting firms and major global enterprises. With offices in Berlin, Munich, Denver, Boston, London, Tokyo, and Dubai, we’re a diverse team of over 240 people, committed to innovation and excellence.

thinkcell is more than a job – it's a chance to be part of an innovative, inclusive team that values collaboration and growth. We encourage applicants from all backgrounds to apply. Together, we can shape the future of productivity software. We can’t wait to see what you’ll bring to the team!

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
