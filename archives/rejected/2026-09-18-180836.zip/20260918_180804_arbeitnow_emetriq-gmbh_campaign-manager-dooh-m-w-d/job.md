# Campaign Manager DOOH (m/w/d)

Posted: 2026-09-18T14:30:11Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

## Werde Teil eines starken Teams bei emetriq!

emetriq, Teil der Deutschen Telekom AG, bietet datengetriebene Online-Advertising-Lösungen und setzt sich für fairen Datenzugang als Treibstoff für Innovation und Vielfalt ein. Mit unserer Expertise und Technologiekompetenz steigern wir die Präzision und Relevanz von Online-Werbung. Als Initiatoren des größten kollaborativen Datenpools in Deutschland vereinen wir über 100 Data- und Mediaexperten.

Im Geschäftsbereich T-Ads verbinden wir Daten, Technologie und digitale Werbeflächen, um Werbung relevanter und messbarer zu machen. Dafür kombinieren wir anonymisierte Daten aus der TV- und App-Nutzung mit einem der größten Consented-Datenpools Deutschlands. Die T Advertising Platform ergänzt diese Datenbasis um exklusive Telco-Daten aus 27 Millionen anonymisierten Profilen und smarte Geo-Aktivierung. So unterstützen wir Unternehmen dabei, die richtigen Zielgruppen über verschiedene digitale Kanäle zu erreichen und ihre Kampagnen wirkungsvoll auszusteuern.

Zur Verstärkung unseres **T-Ads Teams** suchen wir ab sofort einen engagierten **Campaign Manager DOOH (m/w/d)** in Vollzeit. In dieser Position sorgst du dafür, dass programmatische Digital-Out-of-Home-Kampagnen von der Planung bis zum Reporting reibungslos umgesetzt werden. Mit deinem Know-how in Kampagnenmanagement, AdTech und Kundenbetreuung schaffst du die Grundlage für erfolgreiche Kampagnen und eine vertrauensvolle Zusammenarbeit mit unseren Kunden und internen Teams.

## Wie du uns helfen kannst

-

**Kampagnen professionell umsetzen: **Du prüfst Aufträge auf ihre Machbarkeit, erstellst Auftragsbestätigungen und buchst Kampagnen in unseren Systemen.

-

**Kampagnensteuerung: **Du richtest **programmatische DOOH-Kampagnen** über DSPs ein, steuerst deren Auslieferung und begleitest sie über den gesamten Kampagnen-Lifecycle

**Unterstützung:** Du bist die erste Ansprechperson für unser Sales-Team und unterstützt bei der erfolgreichen Umsetzung von **DOOH-Kampagnen**

-

**Kunden und Partner betreuen: **Du beantwortest Kundenanfragen und koordinierst die Zusammenarbeit zwischen **Sales, Marketing** und weiteren Stakeholdern

-

**Kampagnenerfolge sichtbar machen: **Du analysierst Kampagnendaten, erstellst Reportings und leitest Optimierungspotenziale für zukünftige Kampagnen ab.

-

**Prozesse weiterentwickeln: **Du bringst Ideen zur Optimierung unserer Kampagnenprozesse ein und sorgst für effiziente Abläufe

## Was du mitbringst

-

**Erfahrung im Kampagnenmanagement: **Du verfügst über mehrjährige Erfahrung im **Kampagnenmanagement**, idealerweise im Bereich **DOOH** oder programmatische Werbung

-

**Know-how im AdTech-Umfeld: **Du arbeitest sicher mit **DOOH-/DSP-Plattformen**, Ad-Servern sowie idealerweise mit **SSPs, DSPs** und DOOH-CMS-Systemen

-

**Analytisches Verständnis: **Du gehst sicher mit **Kampagnendaten, KPIs und Reporting-Tools** um und leitest daraus fundierte Erkenntnisse ab

-

**Kundenorientierung und Kommunikation: **Du überzeugst durch eine hohe Serviceorientierung und arbeitest souverän mit internen und externen Partner zusammen

-

**Strukturierte Arbeitsweise: **Du arbeitest eigenverantwortlich, sorgfältig und behältst auch bei mehreren Projekten und engen Timelines den Überblick.

-

**Sicherer Umgang mit modernen Tools: **Du nutzt **MS Office**, insbesondere Excel und PowerPoint, sicher. Erfahrungen mit **KI-Tools** sind ein Plus.

## Was uns besonders macht

Wir bei emetriq sind ein Team aus Experten, die gemeinsam wachsen und das Unternehmen voranbringen möchten. Unsere Arbeit basiert auf Vertrauen, Agilität, Selbstorganisation und Eigenverantwortung – ohne starre Hierarchien, aber mit klaren Entwicklungsperspektiven. Mut zur Veränderung, Arbeiten auf Augenhöhe und teamübergreifende Zusammenarbeit prägen unsere Kultur.

**Wir suchen Menschen, die unsere Leidenschaft für Daten und Innovation teilen.** Perfektion ist nicht unser Ziel, aber Engagement und kontinuierliche Weiterentwicklung – Schritt für Schritt.

## Unsere Benefits

-

**Hybrides Arbeiten:** Einmal pro Woche im Büro zur intensiven Zusammenarbeit. An den anderen Tagen entscheidest du selbst, ob du im Büro oder von zuhause arbeitest

-

**Flexible Arbeitszeiten:** Keine festen Kernzeiten – arbeite nach deinen eigenen Bedürfnissen

-

**Mobilität:** Unterstützung durch JobRad und das Deutschlandticket

-

**Mentale Gesundheit mit OpenUp**: Anonyme, kostenlose Unterstützung durch Psycholog:innen

-

**Vergünstigungen:** Telekom-Produkte zu attraktiven Konditionen und eine Benefit-Card ohne Zuzahlung

-

**Teamgeist und Events:** Von Workshops und Strategietagen bis hin zu Sport-Events und Feierabendtreffen auf unserer Dachterrasse

-

**Verpflegung:** Kostenlose Getränke, Siebträgermaschine, Snacks und eine Dachterrasse mit Aussicht

**Klingt das nach deinem nächsten Schritt?** Dann freuen wir uns auf deine Bewerbung und darauf, gemeinsam die Zukunft des datengetriebenen Marketings zu gestalten!

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
