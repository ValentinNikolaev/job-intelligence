# Senior Google Ads Specialist | International Ecommerce | Berlin ASAP

Posted: 2026-09-18T14:30:25Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

ennovationHUB is a fast-growing international e-commerce group operating in the home & living category, with a strong focus on furniture. From our hubs in Belgrade, Barcelona, and London, we serve customers across the UK, North America, EU, and APAC.

As we scale toward €160m+ annual revenue by 2027, we are looking for a Senior Google Ads Specialist to join us ASAP and take ownership of the Google Ads performance of one of our brands within our portfolio, with direct accountability for growth, efficiency, and profitability.

This is not a typical agency PPC role focused on managing a handful of campaigns. You will be working inside a multi-brand international e-commerce group with significant advertising budgets, multiple markets, and direct visibility into how your work impacts revenue and profitability.

Google Ads is a core part of our growth strategy. We operate across multiple countries and brands, creating both complexity and opportunity. We are looking for people who enjoy working with large datasets, finding performance opportunities, and continuously improving results through testing, analysis, and execution.

You will work closely with our Head of Performance Marketing, creative team, and data specialists to ensure campaigns are not only performing well today but continue to scale efficiently as the business grows.

-

Take ownership of Google Ads performance for one e-commerce brand across multiple international markets

-

Manage and optimise Google Ads campaigns across Search, Shopping, Performance Max, and other relevant campaign types

-

Monitor and improve key performance metrics including ROAS, CPA, conversion rate, revenue, and profitability

-

Be directly accountable for growth, efficiency, and performance within your portfolio

-

Identify growth opportunities across products, categories, markets, and audience segments

-

Analyse campaign data and turn insights into actionable recommendations

-

Conduct account audits and implement ongoing optimisation initiatives

-

Work closely with developers and analytics teams to ensure accurate tracking and measurement

-

Collaborate with creative and content teams to improve ad performance and landing page effectiveness

-

Support budget planning, forecasting, and performance reporting

-

Stay current with platform developments, AI-driven advertising features, and industry best practices

-

Contribute to testing strategies and experimentation frameworks that improve long-term account performance

You will not be joining a business that is trying to figure out whether Google Ads works. It already does. Your role is to help us take performance to the next level by identifying opportunities, improving efficiency, and scaling what works. We operate in a competitive e-commerce environment where small improvements can have a significant impact.

You will be working with experienced colleagues who move quickly and care about results. We value people who can think independently, challenge assumptions with data, and take ownership of outcomes. This is not a support role and it is not a reporting role. You will be trusted to make decisions, own results, and have a direct impact on the growth of the business.

This role is strictly for candidates with in-house e-commerce experience. Candidates whose primary Google Ads experience comes from agencies, consultancies, or freelance work will not be considered.

We are looking for people who have owned performance outcomes inside an e-commerce business, where success is measured by revenue, profitability, customer acquisition, and long-term growth rather than client management and campaign delivery. You should have experience working directly within a commercial business and be comfortable taking ownership of results, not simply providing recommendations.

**Our Ideal Candidate Will Have:**

-

2+ years of hands-on experience managing Google Ads campaigns

-

Proven hands-on experience managing Google Ads for an e-commerce business, with direct responsibility for performance and profitability

-

Strong experience with Search, Shopping, and Performance Max campaigns

-

Proven experience working as part of an in-house e-commerce team rather than as an agency, consultant, or freelancer

-

Comfortable analysing large datasets and identifying actionable insights

-

Strong understanding of attribution, tracking, and performance measurement

-

Familiarity with Google Analytics 4, Google Tag Manager, and Google Merchant Center

-

Highly analytical with strong attention to detail

-

Fluent in English, both written and spoken

-

Comfortable working in a fast-moving environment with changing priorities

-

Curious, proactive, and focused on continuous improvement

-

Able to take ownership and make decisions independently

-

We are actively pushing AI and automation across the business, so you need to be comfortable working in that direction and not resistant to change

-

Senior, but practical

-

Data-driven without becoming overly theoretical

-

Comfortable taking ownership and making decisions

-

Naturally curious and always looking for performance improvements

-

Focused on outcomes rather than activity

-

Able to balance strategic thinking with hands-on execution

-

Motivated by building and scaling rather than simply maintaining campaigns

-

Available to start immediately / ASAP

We are investing in building a stronger presence there and expect it to become an increasingly important location for our team over time. Our wider team is spread across London, Belgrade, Barcelona, Frankfurt, Oxfordshire, Istanbul, and Guangzhou.

The role requires travel approximately every 4-8 weeks to Belgrade, Barcelona, London, or other team locations for planning sessions, workshops, team gatherings, and strategic discussions. While most work is done remotely, we believe that spending time together in person remains valuable, particularly as the company continues to scale.

This is a long-term opportunity for someone who wants to play a meaningful role in scaling an international e-commerce business over the coming years.

**In Our Culture at ennovationHUB, We Value: **

-

Accountability over excuses

-

Execution over talk

-

Clarity over politics

-

Learning through doing

We welcome people from diverse backgrounds. What matters most is doing the work well, taking ownership, and helping the business move forward.

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
