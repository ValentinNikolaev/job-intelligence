# Entrepreneur in Residence/Product Lead (Project Thinkrail)

Posted: 2026-09-18T14:55:13Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

At JetBrains, code is our passion. Ever since we started, back in 2000, we have strived to make the strongest, most effective developer tools on earth. By automating routine checks and corrections, our tools speed up production, freeing developers to grow, discover, and create.

ThinkRail is an innovative project within JetBrains' Innovation Hub. Its aim is to develop a declarative programming language tailored to AI-spec-driven development. Our goal is to build an infrastructure that enables the efficient creation of complex systems with AI, while maintaining the trust of users and flexibility in the results.

Thinkrail ([GitHub](https://github.com/JetBrains/thinkrail), [Blog, ](https://thinkrail.ai/blog/)[Website](https://thinkrail.ai)) is now open source and in alpha, and we’re entering the next stage of the product’s development: initial market penetration. We’re focused on bringing it into real-world projects and turning it into a robust, production-ready system. To help us get there, we’re looking for an Entrepreneur in Residence to join the team. You’d be joining at an early stage, with plenty of opportunity to influence the product as it continues to evolve.

**About the role**

We are looking for an Entrepreneur in Residence/Product Lead to work alongside the technical founder and own the product strategy for Thinkrail.

This is not a traditional product management role. Your focus will be on deeply understanding real developer workflows: where specs, architecture, and code break down, what causes friction, and what problems are actually worth solving. You will translate these insights into concrete product requirements and priorities.

### **In this role, you will:**

- Own the product strategy: Define the direction, validate key hypotheses, and decide what to build first.

- Run continuous discovery: Talk to developers and customers to understand real workflows, pain points, and opportunities.

- Define the initial scope: Identify the ICP, core use cases, and priorities for zero-to-one development.

- Shape GTM: Help define positioning, messaging, launch, and go-to-market strategy.

- Track the ecosystem: Stay close to competitors, adjacent tools, AI developments, and market trends

- Work closely with engineering: Keep a small team focused, aligned, and moving quickly in a highly ambiguous environment

### We will be happy to have you on our team if you have:

- 8+ years of product management experience with end-to-end ownership of strategy, discovery, and delivery

- Startup experience is a must, ideally in a small team, with a strong track record of building and shipping zero-to-one

- Experience with developer tools or AI products is required

- High autonomy, speed, and comfort making decisions with limited information

- Strong technical fluency and the ability to work closely with engineers. Coding experience is a plus

- Founder, co-founder, C-level, or similar experience is a strong advantage

- Experience with GTM, marketing, launches, developer advocacy, or public speaking is also a plus

### **Why join Project Thinkrail?**

- Foundational work: Help define a new direction in developer tooling at the intersection of programming languages and AI.

- Deep technical problems: Work on language design, formal specs, tooling, and AI agents – not surface-level features.

- Real ownership: Own the product’s strategy and direction, working in a role closer to that of a founder than a classic PM.

- JetBrains environment: Enjoy startup-level autonomy with JetBrains’ engineering culture and long-term mindset.

#LI-YY1

**We are an equal opportunity employer**

We know great ideas can come from anyone, anywhere. That’s why we do our best to create an open and inclusive workplace – one that welcomes everyone regardless of their background, identity, religion, age, accessibility needs, or orientation.

*We process the data provided in your job application in accordance with the [Recruitment Privacy Policy.](https://www.jetbrains.com/legal/docs/privacy/privacy-recruitment/)*

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
