# Auszubildender (m/w/d) Fachkraft für Lagerlogistik in Plaidt

Posted: 2026-09-18T14:30:09Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

***Hall Tabakwaren* ist bundesweit in aller Munde.** 1903 als Ladengeschäft für Zigarren, Rauchtabak und Zigaretten gegründet, sind wir heute einer der führenden Tabakwarengroßhändler in Deutschland. In unserem in 5. Generation inhabergeführten Familienunternehmen sorgen über 750 Mitarbeiterinnen und Mitarbeiter in 11 Niederlassungen mit 350 firmeneigenen Fahrzeugen und 30.000 Cigarettenautomaten dafür, dass Menschen im gesamten Bundesgebiet schnell, sicher und zuverlässig zu ihrer Lieblingsmarke kommen. Mit unserer Erfahrung, unserer Leidenschaft und unserem Engagement – auch für unsere rund 5.000 Einzelhandelskunden – erwirtschaften wir jährlich mehr als 1,2 Milliarden Euro Umsatz. Und wir wachsen weiter, gerne mit Ihnen als

**Auszubildender (m/w/d) Fachkraft für Lagerlogistik in Plaidt**

** **

**Hier gehst Du ans Werk:**

-

Während deiner dreijährigen Ausbildung bringen dir deine Teamkollegen bei, wie du Ware richtig kommissionierst, verpackst, lagerst und für den Weitertransport vorbereitest.

-

Du lernst wie wir mit Hilfe eines geschlossenen Warenwirtschaftssystems unsere kompletten Lagerprozesse steuern und kontrollieren.

-

Bald sorgst du für reibungslose Abläufe in unserem Lager, von der Anlieferung bis zum Warenausgang.

-

Du absolvierst also eine echte 360-Grad-Ausbildung mit besten Zukunftsaussichten.

**So entfachst Du unser Feuer:**

Du hast einen Real- oder Hauptschulabschluss oder bist kurz davor, ihn zu bekommen. Körperliche Arbeit macht dir nichts aus und du kannst gut rechnen. Es wäre super, wenn du bereits Kenntnisse in Microsoft Office besitzt, und vielleicht schon einen Führerschein. Pünktlichkeit ist für dich selbstverständlich und du magst es gerne sauber und ordentlich. Außerdem arbeitest du gerne im Team.

**Deine Ausbildungsvorteile bei uns:**

++ Sehr abwechslungsreiche Ausbildung ++ Überdurchschnittliche Ausbildungsvergütung ++ Viel Eigenverantwortung ++ Übernahme nach Ausbildung erwünscht ++ 28 Tage Urlaub im Jahr ++

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
