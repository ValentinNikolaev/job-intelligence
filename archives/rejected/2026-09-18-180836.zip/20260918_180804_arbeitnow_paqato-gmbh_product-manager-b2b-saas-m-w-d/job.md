# Product Manager (B2B/SaaS) m/w/d

Posted: 2026-09-18T14:30:33Z

## Rejection

- Category: tech_stack
- Reason: role does not mention Go/Golang or PHP

**PAQATO** ist eine After-Sales-Experience-Plattform für Onlineshops. Wir unterstützen Unternehmen dabei, ihren Kundinnen und Kunden nach dem Kauf ein besseres Erlebnis zu bieten — von personalisierten Versandbenachrichtigungen über Tracking-Seiten im eigenen Shop bis hin zu effizientem Versandcontrolling und smarter Post-Purchase-Kommunikation.

Für unser Team suchen wir eine engagierte, strategisch denkende und gleichzeitig hands-on arbeitende Persönlichkeit als **Product Manager B2B/SaaS** (m/w/d).

In dieser Rolle verantwortest du unser Produkt von der Idee bis zum Release und bist die zentrale Schnittstelle zwischen Geschäftsführung, Entwicklung, Customer Success, Sales, Marketing und unseren Kundinnen und Kunden.

Du übersetzt Kundenbedürfnisse, Marktanforderungen und Unternehmensziele in eine klare Produktstrategie, priorisierte Roadmap und umsetzbare Anforderungen für unser Delivery-Team.

## Aufgaben

Bei **PAQATO** übernimmst du eine verantwortungsvolle Rolle mit viel Gestaltungsspielraum. Du arbeitest nah an unseren Kundinnen und Kunden, verstehst ihre Herausforderungen und leitest daraus konkrete Produktentscheidungen ab. Gleichzeitig bist du tief in die operative Umsetzung eingebunden: Du priorisierst das Backlog, schreibst User Stories, stimmst Anforderungen mit Tech und UX ab, testest Features und begleitest Releases bis zur erfolgreichen Kommunikation.

Du bist nicht nur strategische:r Produktdenker:in, sondern auch operative:r Umsetzer:in. Du sorgst dafür, dass aus Ideen marktfähige Lösungen werden — klar priorisiert, sauber spezifiziert und mit echtem Mehrwert für unsere Kundinnen und Kunden.

- Du verantwortest die Produktstrategie, Produktvision und Roadmap für PAQATO und stellst sicher, dass Produktentscheidungen auf Unternehmensziele einzahlen

- Du priorisierst das Delivery Backlog und triffst fundierte Trade-off-Entscheidungen zwischen Kundenwünschen, technischem Aufwand, wirtschaftlicher Machbarkeit und strategischem Nutzen

- Du führst eigenständig Kundengespräche, Discovery-Interviews und Anforderungsanalysen durch und leitest daraus konkrete Produktanforderungen ab

- Du übersetzt Anforderungen in klare User Stories, Akzeptanzkriterien und umsetzbare Tickets für das Entwicklungsteam

- Du bist erste Ansprechperson für Rückfragen aus der Entwicklung und bewertest gemeinsam mit Tech Lead und UX die technische und fachliche Machbarkeit

- Du begleitest Features von der Konzeption über die Umsetzung bis hin zu Testing, QA, Abnahme und Release

- Du koordinierst Go-to-Market- und Launch-Kommunikation gemeinsam mit Customer Success und Marketing

- Du erstellst bzw. koordinierst Release Notes, Produktdokumentation und kundennahe Produktkommunikation

- Du analysierst Markt, Wettbewerb und Kundenfeedback und entwickelst daraus Impulse für die Weiterentwicklung unseres Produkts

- Du arbeitest eng mit Geschäftsführung, Tech, UX, Customer Success, Sales und Marketing zusammen und sorgst für Transparenz über Prioritäten, Fortschritte und Entscheidungen

- Du nutzt moderne Tools, KI-Anwendungen und Automatisierungen, um Produktarbeit effizienter, strukturierter und wirkungsvoller zu gestalten

## Qualifikation

- Du hast ein erfolgreich abgeschlossenes Studium im Bereich Wirtschaftsinformatik, Informatik, Betriebswirtschaft oder eine vergleichbare Qualifikation

- Du bringst mindestens 2–4 Jahre Erfahrung als Product Manager oder Product Owner mit, idealerweise in einem B2B-SaaS-Umfeld

- Du hast Erfahrung in der strategischen Produktverantwortung, Roadmap-Arbeit und Marktpositionierung

- Du bist sicher im Backlog-Management, in der Priorisierung sowie im Schreiben von User Stories und Akzeptanzkriterien

- Du hast ein gutes technisches Grundverständnis für Webanwendungen, APIs und Datenmodelle und kannst mit Entwickler:innen auf Augenhöhe über Machbarkeit sprechen

- Du bist bereit, Features selbst zu testen, kritisch zu prüfen und sauber abzunehmen

- Du arbeitest strukturiert, eigenverantwortlich und lösungsorientiert — gleichzeitig bist du hands-on und packst operative Themen aktiv mit an

- Du trittst sicher in Meetings auf und kannst unterschiedliche Stakeholder klar abholen, moderieren und zusammenbringen

- Du kennst agile Arbeitsweisen wie Kanban oder Scrum und hast Erfahrung mit Tools wie Jira, Confluence, Notion oder vergleichbaren Systemen

- Du hast Freude daran, Kundengespräche zu führen, Nutzerbedürfnisse zu verstehen und daraus echte Produktverbesserungen abzuleiten

- Du gehst sicher mit LLM-Tools, KI-Anwendungen und Workflow-Automatisierung im Arbeitsalltag um oder hast großes Interesse, diese aktiv zu nutzen

- Du kommunizierst verhandlungssicher auf Deutsch und sicher auf Englisch

**Nice to have**

- Erfahrung im Bereich E-Commerce, Versand, Post-Purchase-Kommunikation oder Logistik

- Erfahrung mit Produktkennzahlen und Zusammenarbeit mit Data Analytics

- Erfahrung mit groben Mockups oder Prototypen, z. B. in Figma oder KI-gestützt

- Erfahrung mit Informationssicherheit, Datenschutz oder ISMS-Themen

- Grundkenntnisse in GitHub oder technischen Produkt-Workflows

- Erfahrung in der Erstellung von Produktvideos, Hilfedokumentation oder Release-Kommunikation

- Erfahrung in der fachlichen Anleitung von Werkstudierenden oder juniorigen Teammitgliedern

## Benefits

- **Hands-On Teamspirit:** Unser Team besteht aus Allstars, die gemeinsam wachsen wollen - wir suchen Talente, die Themen eigenverantwortlich und selbstständig vorantreiben und dabei nie den Teamerfolg aus den Augen verlieren

- **Flexible Arbeitszeiten & Arbeitsort:** Ob Homeoffice oder Büro – wir finden gemeinsam das passende Arbeitsmodell,

- **Teamevents:** Ob beim Tischtennis-Match, beim Feierabendbier oder anderen gemeinsamen Aktivitäten - der Spaß darf bei uns nicht fehlen

- **Spannende Location:** Am [whyit] Campus sind viele Unternehmen mit Tech-Schwerpunkt zuhause. Hier profitieren wir von Nachbarschafts-Kooperationen und vielen kreativen Köpfen

- **Unsere Mission:** Wir sorgen tagtäglich mit unserem Tool für eine ‘Customer Happiness’, was spürbar ist und uns noch mehr Power gibt.

- Eine verantwortungsvolle Produktrolle mit viel Gestaltungsspielraum

- Direkter Einfluss auf Roadmap, Priorisierung und Produktentwicklung

- Kurze Entscheidungswege und ein Umfeld, in dem du Ideen aktiv einbringen kannst

- Viel Raum für eigenverantwortliches Arbeiten und Weiterentwicklung

- Moderne Tools, agile Arbeitsweisen und Offenheit für KI-gestützte Prozesse

- Die Möglichkeit, ein Produkt mitzugestalten, das für unsere Kundinnen und Kunden echten Mehrwert schafft

Wenn du Lust hast, Produktstrategie und operative Umsetzung miteinander zu verbinden, Kundennähe genauso wichtig findest wie klare Priorisierung und gerne in einem dynamischen B2B-SaaS-Umfeld Verantwortung übernimmst, freuen wir uns darauf, dich kennenzulernen.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
