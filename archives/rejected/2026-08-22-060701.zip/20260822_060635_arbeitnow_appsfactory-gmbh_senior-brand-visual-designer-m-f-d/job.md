# Senior Brand / Visual Designer (m/f/d)

Posted: 2026-08-21T23:10:20Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**#NEWISBEAUTIFUL**

Your mission

You are a confident visual designer, creative storyteller and cultural thinker. You drive the creative output of brand-focused projects and work closely with teams and clients to develop strong brand narratives, identities and experiences.

Brands today function less as static identities and more as operating systems: adaptive, scalable, and increasingly dynamic across digital products and services. Your role is to help define, design and implement such systems – ensuring they perform reliably across channels, platforms, and use cases.

**Deine Aufgaben**

-

Lead the creative development of brand identities, from strategic foundations to visual execution.

-

Develop brand narratives and creative routes, translating strategy into expressive and scalable visual systems.

-

Guide and mentor designers, ensuring high craft quality and conceptual clarity.

-

Work with global brands, publishing houses and public institutions (e.g. healthcare, cities, universities) on complex branding challenges.

-

Translate brand strategies into digital products and cohesive brand experiences across touchpoints.

-

Collaborate closely with strategy, product and technology teams to ensure consistency and impact.

-

Present ideas clearly and confidently to clients, enabling alignment and decision-making.

-

Prepare remote and on-side workshops and are willing to facilitate them together with our Design Directors.

-

Contribute to and evolve design systems that function as operational brand platforms, not static guidelines.

-

Take ownership of projects with a hands-on mentality, from concept to delivery.

**Dein Profil**

Your Profile

-

6+ years of experience in brand and visual design, ideally within a design agency environment.

-

Strong portfolio demonstrating brand thinking, visual excellence, and conceptual depth.

-

Proven ability to connect strategy, storytelling and design execution.

-

Deep understanding of visual identity systems, typography, layout and color across digital and physical applications – including designing with and for AI-driven systems.

-

Strong knowledge of design systems and digital products, how brands scale across platforms.

-

Experience leading creative workstreams and mentoring designers.

-

Ability to apply methodical brand development frameworks and navigate different project phases with clarity and rigor.

-

A visionary mindset – you embrace the culture and actively challenge and elevate the work.

-

Hands-on, pragmatic approach paired with a positive, business-oriented mindset.

-

Thanks to your communication skills you contribute to our trust- and respectful feedback mentality.

-

Excellent communication skills in English (German is a plus).

Big plus

-

You are already a professional in leveraging AI-assisted tools, automated workflows and emerging software to enhance creative exploration, efficiency and quality.

-

Experience in overarching motion design principles that translate brand values into movement and make them scalable for all touchpoints.

-

Strong understanding of current accessibility standards and their impact on brand and design systems.

**Was wir dir bieten**

- Participation as a central team member of a dynamic design consultancy, self-determined and independent work with direct connection to our partners, management and colleagues
- The best team in the world :)
- Flat hierarchies and the opportunity to contribute and implement your own ideas
- A lot of personal responsibility, room for creativity and personal development, and thus the chance to grow together with the company
- 30 days paid vacation, hybrid-work, a dog-friendly office and meditation to promote work-life balance
- We balance work with family and private life (with a potential four day week if needed)
- Benefits as Urban Sports Club, food club, regular team gatherings
- Inhouse coaching and mentoring

**Wir freuen uns, dich kennenzulernen!**

We value diversity and therefore welcome all applications – regardless of gender, nationality, ethnic and social origin, religion/beliefs, disability, age, and sexual orientation and identity.

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
