# Intern Consultancy / Public Sector (m/w/d)

Posted: 2026-08-21T23:20:14Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Wir suchen eine:n **Praktikant:in Communications Consultant (m/w/d) (6 Monate)** für unsere Digitalberatung in Berlin

In unserem Praktikum im Bereich Communication Consultancy arbeitest du an Projekten für Ministerien, Startups und Verbände. Du unterstützt bei der Pflege von Websites, erstellst Social-Media-Content, wirkst an Reportings mit und entwickelst gemeinsam mit dem Team Kommunikations- und Kreativkonzepte. Dabei erhältst du Einblicke in strategische Beratung und lernst, wie digitale Kommunikation wirkungsvoll geplant und umgesetzt wird.

**Deine Aufgaben**

-

Du pflegst und entwickelst Websites weiter (Content-Updates, Struktur, SEO-Basics)

-

Erstellung von Social-Media-Content, inklusive Texte, einfache Visual-Briefings und Redaktionsplanung

-

Du unterstützt bei Reportings und Performance-Analysen

-

Mitarbeit an Kommunikations- und Kreativkonzepten

-

Du recherchierst zu politischen, gesellschaftlichen und digitalen Themen

-

Vorbereitung von Präsentationen und Kundentermine

**Dein Profil**

-

Du studierst Kommunikation, Medien, Politik, Wirtschaft oder vergleichbar

-

Interesse an politischer Kommunikation, Startup-Ökosystem und Verbandsarbeit

-

Sehr gutes Sprachgefühl in Deutsch und sicherer Umgang mit Social Media

-

Strukturierte, eigenständige Arbeitsweise

-

Neugier, analytisches Denken und Lust, Verantwortung zu übernehmen

**Unsere Benefits**

💝 **Social Impact:** 2 zusätzliche Volunteering Days, um dich für dein Herzensprojekt einzusetzen.

💖 **Mental Health:** 3 Wellnessdays zusätzlich zu deinen Urlaubstagen, Mental Health First Aider Programme zur Förderung deiner mentalen Gesundheit sowie ein Employee Assistance Program.

♻ **Nachhaltigkeit:** Unsere Büros nutzen erneuerbare Energien, daher arbeitest du bei uns CO₂-neutral.

🎓 **Academy:** Weiterbildungs- & Entwicklungsmöglichkeiten durch unser Netzwerk und unsere hauseigene Academy.

💼 **Learning Allowance:** 40h pro Jahr zusätzlich zum gesetzlichen Bildungsurlaub, um dich persönlich & beruflich weiterzuentwickeln.

🛍️ **Corporate Benefits:** Zugriff auf exklusive Mitarbeiterrabatte über unsere Corporate Benefits Plattform.

💌 **Company Pension Plan:** Betriebliche Altersvorsorge als Baustein für deine finanzielle Sicherheit.

✈️ **Workation:** Du hast die Möglichkeit, temporär aus dem Ausland zu arbeiten.

💸 **Freunde werben Freunde:** Empfiehl neue Talente und sichere dir eine Prämie bei erfolgreicher Einstellung.

🐶 **Office Dogs:** Die flauschigen Wegbegleiter sind im Büro erlaubt.

**Vielfalt, Chancengleichheit & Inklusion bei dentsu/RCKT**

**Bei dentsu/RCKT stehen Diversity, Equity & Inclusion (DEI) im Mittelpunkt unserer Vision: „An der Spitze menschenzentrierter Transformationen stehen, die die Gesellschaft prägen.“**

Wir schätzen die einzigartigen Talente und Perspektiven jedes Einzelnen und heißen Bewerber:innen unabhängig von Geschlecht, Geschlechtsidentität, Nationalität, Religion, ethnischer Herkunft, kulturellem Hintergrund, sexueller Orientierung, Alter, körperlicher oder geistiger Fähigkeiten.

Indem wir vielfältige Perspektiven einbinden, schaffen wir echten Wandel und nachhaltiges Wachstum –für unsere Mitarbeitenden, unsere Kunden und die Gesellschaft. Unsere Einstellungsentscheidungen basieren ausschließlich auf Qualifikationen und den Anforderungen der jeweiligen Rolle, um ein Arbeitsumfeld frei von Diskriminierung und Belästigung zu gewährleisten.

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
