# Projektmanager Software und Automatisierung (m/w/d)

Posted: 2026-08-21T23:30:20Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

### Projektmanager Software und Automatisierung (m/w/d)

Bei unserem namhaften Kunden im Raum Aalen - einem führenden Unternehmen der Hightechindustrie - bietet sich diese einmalige Perspektive im Rahmen der Arbeitnehmerüberlassung mit der Option auf Übernahme.

### Dein zukünftiger Tätigkeitsbereich

-

Sie werden ein aktives Anforderungsmanagement an die IT-Systeme im Produktionsumfeld aus verschiedenen Teilprojekten durchführen und dabei im Team die Anforderungen an die IT-Systeme ermitteln, strukturieren und priorisieren

-

Darüber hinaus werden Sie die effektive Realisierung der Projekte in einer agilen Soft- und Hardware-Entwicklungsorganisation zuverlässig und abgestimmt mit den Projektbeteiligten steuern

-

Sie stellen eine wichtige Schnittstelle zu unseren internen Kunden in Bezug auf Reporting, Dokumentation, Planung und Tracking dar und die Umsetzung der Teilprojekte entsprechend der definierten Vorgaben mit großem Engagement sicher

-

Sie bringen Ihre Erfahrungen und Erkenntnisse in den ständigen Verbesserungsprozess der Soft- und Hardwareentwicklung ein

### Das zeichnet Dich aus

-

Abgeschlossenes Studium Informatik (m/w/d), Elektrotechnik, Physik oder vergleichbar

-

Mehrjährige Berufserfahrung in komplexen Software- und Automatisierungsprojekten, sowohl bei klassischer als auch bei agiler Vorgehensweise

-

Kenntnisse im Projektmanagement, idealerweise durch eine IPMA® Zertifizierung nachgewiesen

-

Sicheres Auftreten, Kommunikationsstärke und Durchsetzungsvermögen sowie Präsentations- und Moderationskenntnisse

-

Sehr gute Deutsch- und Englischkenntnisse (C1)

-

**For international applicants:** Please note that the business language is **German**. C1 level is mandatory and must have for this position

### Deine berufliche Zukunft

-

**Vergütung: **Übertarifliche Bezahlung zuzüglich Branchenzuschläge

-

**Work-Life-Balance:** Uns ist die Vereinbarkeit von Job und Familie sehr wichtig, daher sind 30 Tage Urlaub und ein Gleitzeitkonto selbstverständlich

-

**Karriere bei Top Unternehmen:** Freue dich auf langfristige Einsätze bei renommierten Unternehmen der Region mit echter Übernahmeoption!

-

**Mitarbeiter-Benefits:** Profitiere von betrieblichen Zusatzleistungen wie Weihnachtsgeld, Urlaubsgeld, bezuschusste betriebliche Altersvorsorge und VWL

-

**Wachsendes Unternehmen: **Mit starkem Auftragseingang und Dynamik

-

**Firmenveranstaltungen: **Freu Dich auf das traditionelle jährliche encontec-Standortfest

-

**Persönliche Betreuung:** Dein persönlicher Ansprechpartner steht Dir jederzeit zur Seite und kümmert sich um all Deine Anliegen

### **Stellendetails**

**Arbeitsort:** Oberkochen
**Arbeitszeit:** 40-Stunden-Woche

**Vertragsart:** Arbeitnehmerüberlassung

**Dauer: **12 Monate

**Startdatum: **sofort oder nach Absprache

Du hast Lust in einem Team zu arbeiten, bei dem partnerschaftliches Miteinander an erster Stelle steht?

Gerne laden wir Dich zu einem Gespräch ein, um Dich persönlich kennenzulernen und Dir die weiteren Schritte auf Deinem Weg zu encontec zu erläutern.

Wir freuen uns auf Dich!

**Dein Kontakt zu uns**

Bastian Heidenfelder

Talentmanager / Account Manager

encontec GmbH

Heidenheimer Str. 104

73447 Oberkochen

Tel.: +49 (0)162 2949990

E-Mail: Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
