# AI & Data Platform Lead (m/f/d)

Posted: 2026-08-21T23:55:31Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**Mission Brief**

Isar Aerospace is building the launch company Europe needs: fast, vertically integrated, technically ambitious, and execution-driven.

As we scale manufacturing, launch operations, engineering, and business functions, the amount of data generated across the company is growing rapidly. Today, valuable information exists across ERP, PLM, MES, project management, collaboration, finance, people, and operational systems. Turning that data into actionable insight requires a modern AI & Data Platform built on strong ownership, governance, interoperability, and practical business value.

We are looking for the first dedicated member of our AI & Data Platform capability.

This is a hands-on individual contributor role with significant ownership and visibility. You will help define the foundations of Isar's future data platform while delivering tangible outcomes such as executive dashboards, governed datasets, data pipelines, AI-enabled workflows, and reusable platform capabilities.

Over time, this capability is expected to grow. While people management experience is not required, we are particularly interested in candidates with the potential and ambition to evolve into a future leadership role as the AI & Data Platform organization scales.

Your Role in Our Space Mission:

** **

Build the foundations that allow Isar Aerospace to make faster, better, and more scalable decisions through trusted data and applied AI.

You will help transform fragmented information from enterprise and operational systems into governed data products, executive insights, and reusable platform capabilities that improve visibility, execution, and decision-making across the business.

**Build the AI & Data Platform**

- Design and implement the first generation of Isar's AI & Data Platform.

- Develop data ingestion, transformation, and modeling pipelines across priority business and operational domains.

- Create and maintain structured data layers, semantic models, KPI definitions, and reusable reporting assets.

- Establish monitoring, documentation, and operational standards for data products.

- Help define the long-term target architecture and platform roadmap.

**Executive Analytics & Business Intelligence**

- Build executive dashboards and management reporting capabilities.

- Work closely with the CEO Office and business stakeholders to define KPIs, ownership models, and source-of-record principles.

- Translate leadership questions into trusted datasets and actionable insights.

- Improve observability across launch, manufacturing, commercial, finance, and people domains.

**AI Enablement**

- Evaluate and implement practical AI use cases that create measurable business value.

- Support the rollout of AI-enabled workflows, automation opportunities, and AI-assisted engineering and business processes.

- Contribute to the development of an AI-first data and technology landscape.

- Help establish responsible governance for AI-related capabilities and datasets.

**Data Governance & Ownership**

- Partner with data owners across Engineering, Manufacturing, Supply Chain, Finance, HR, Quality, and Launch Operations.

- Help define data ownership, quality standards, business definitions, and governance processes.

- Improve traceability from executive metrics back to underlying systems and records.

- Contribute to master data, metadata, and semantic-layer standards.

**Strategic Growth**

- Act as a founding member of the future AI & Data Platform team.

- Identify capability gaps, tooling needs, and future hiring requirements.

- Help shape the operating model of the future function.

- Mentor future team members as the capability expands.

**Qualification Checklist**

- Strong hands-on experience building data platforms, analytics solutions, or data engineering capabilities.

- Proven experience with modern cloud data architectures, data warehouses, lakehouses, or analytics platforms.

- Experience designing and building data pipelines, ingestion processes, and semantic models.

- Strong business intelligence experience with tools such as Power BI or similar platforms.

- Practical understanding of data governance, KPI ownership, and data quality management.

- Experience working directly with business stakeholders and executive audiences.

- Strong engineering mindset with the ability to move between architecture discussions and hands-on implementation.

- Fluent English.

** **

Bonus skills

- Experience with Data Platform and Warehouse ecosystems.

- Experience integrating ERP, MES, PLM, CRM, HR, or manufacturing-related systems.

- Experience in aerospace, advanced manufacturing, automotive, defense, or other complex engineering environments.

- Experience applying AI to operational, engineering, or business processes.

- Previous experience as a technical lead, team lead, or founding member of a platform/data organization.

**Benefits **

- **Employee Participation Program: **Share in our success through our virtual company share program

- **30 days of vacation: **Enjoy the days off to relax and recharge

- **Company pension plan:** Secure your future with our company pension plan, featuring a 20% employer contribution after the probation period

- **Subsidised lunch:** Stay energised with delicious, subsidised lunches every day

- **Public transport ticket: **Commute with ease using a fully financed Deutschlandticket

- **Sport Clubs membership: **Stay fit with our sponsored sports club memberships (EGYM Wellpass)

- **Individual learning allowance:** Grow your skills with an individual learning budget granted after the probation period

- **Childcare allowance:** Receive a childcare allowance for your non-school-age children

- **And Much More!** Discover additional perks and benefits when you join our team

**Who we are**

****

We are Isar Aerospace and we are at the forefront of New Space building a modern space business to enable faster, better and cheaper access to space.

Our mission is to help democratise space and use it for good in order to improve life on Earth now and for the future generations.

We are a fast-growing company aiming to provide sustainable and environmentally friendly launch solutions for small and medium-sized satellites and constellations into Low Earth Orbit. The company is privately funded by world-leading technology investors with strong commitment and support and our team is made of driven and talented people with a real passion for space innovation.

We're making rockets in a way that hasn't been done before disrupting a traditional industry. If you are up for the challenge, want to work on cutting-edge projects and be part of a team changing the world for better, come, join us and launch your career!

Want to find out more about us?

Visit [www.isaraerospace.com](http://www.isaraerospace.com/)

**Data Protection
**We process your personal data for the purpose of managing the recruitment process and assessing your application. For detailed information on how your data is processed, including your rights, please refer to our [Privacy Policy](https://isaraerospace.com/privacy-policy).

**Disclaimer
**Isar Aerospace SE is an equal-opportunity employer committed to fairness and inclusivity. We do not prioritize any specific religion, gender, nationality, or background. Due to security clearance requirements, affiliations with countries listed under § 13 para. 1 no. 17 SÜG may affect the application process. All qualified applicants are encouraged to apply.

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
