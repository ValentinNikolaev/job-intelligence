# Strategischer Einkäufer Software und IT (m/w/d)

Posted: 2026-08-21T23:30:20Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

### Strategischer Einkäufer Software und IT (m/w/d)

Bei unserem namhaften Kunden im Raum Aalen - einem führenden Unternehmen der Hightechindustrie - bietet sich diese einmalige Perspektive im Rahmen der Arbeitnehmerüberlassung mit der Option auf Übernahme.

### Dein zukünftiger Tätigkeitsbereich

-

Verantwortung für den gesamten Einkaufsprozess von Softwareprodukten und - dienstleistungen

-

Analyse und Bewertung von Angeboten sowie Verhandlungen

-

Aufbau und Pflege von Beziehungen zu Softwareanbietern und -entwicklern

-

Durchführung von Marktanalysen

-

Zusammenarbeit mit internen Abteilungen, um den Bedarf an Softwarelösungen zu ermitteln und zu planen

-

Überwachung und Verwaltung von Verträgen und Lizenzvereinbarungen sowie Riskmanagement

-

Strategische Einkaufsverantwortung für weitere Materialgruppe(n), im Bereich Elektronik, Mechanik und Optik

### Das zeichnet Dich aus

-

Abgeschlossenes Studium Betriebswirtschaft (m/w/d), Informatik oder vergleichbar

-

Mehrjährige Erfahrung im Einkauf von Software oder IT-Dienstleistungen

-

Ausgeprägte Verhandlungs- und Kommunikationsfähigkeiten

-

Kenntnisse im Vertragsmanagement und in Lizenzvereinbarungen

-

Analytisches Denkvermögen und Fähigkeit zur strategischen Planung

-

Sehr gute Deutsch- und Englischkenntnisse (C1)

-

**For international applicants:** Please note that the business language is **German**. C1 level is mandatory and must have for this position

### Deine berufliche Zukunft

-

**Vergütung: **Übertarifliche Bezahlung zuzüglich Branchenzuschläge

-

**Work-Life-Balance:** Uns ist die Vereinbarkeit von Job und Familie sehr wichtig, daher sind 30 Tage Urlaub und ein Gleitzeitkonto selbstverständlich

-

**Karriere bei Top Unternehmen:** Freue dich auf langfristige Einsätze bei renommierten Unternehmen der Region mit echter Übernahmeoption!

-

**Mitarbeiter-Benefits:** Profitiere von betrieblichen Zusatzleistungen wie Weihnachtsgeld, Urlaubsgeld, bezuschusste betriebliche Altersvorsorge und VWL

-

**Wachsendes Unternehmen: **Mit starkem Auftragseingang und Dynamik

-

**Firmenveranstaltungen: **Freu Dich auf das traditionelle jährliche encontec-Standortfest

-

**Persönliche Betreuung:** Dein persönlicher Ansprechpartner steht Dir jederzeit zur Seite und kümmert sich um all Deine Anliegen

### **Stellendetails**

**Arbeitsort:** Oberkochen
**Arbeitszeit:** 35-Stunden-Woche

**Vertragsart:** Arbeitnehmerüberlassung

**Dauer: **18 Monate, mit der Option auf Verlängerung

**Startdatum: **sofort oder nach Absprache

Du hast Lust in einem Team zu arbeiten, bei dem partnerschaftliches Miteinander an erster Stelle steht?

Gerne laden wir Dich zu einem Gespräch ein, um Dich persönlich kennenzulernen und Dir die weiteren Schritte auf Deinem Weg zu encontec zu erläutern.

Wir freuen uns auf Dich!

**Dein Kontakt zu uns**

Bastian Heidenfelder

Talentmanager / Account Manager

encontec GmbH

Heidenheimer Str. 104

73447 Oberkochen

Tel.: +49 (0)162 2949990

E-Mail: Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
