# Mitarbeiter für Obst & Gemüse/ Qualityselector fruits and vegetables (m/w/d)

Posted: 2026-08-21T23:40:22Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Als **Qualitätsmitarbeiter:in für Obst & Gemüse** trägst du die Verantwortung für die kontinuierliche Sicherstellung der Produktqualität in unserem Obst- und Gemüsebereich. Du bist ein entscheidender Teil unseres Logistikprozesses und sorgst dafür, dass unsere Kund:innen stets frische und einwandfreie Ware erhalten.

Die Stelle befindet sich in Garching bei München und ist in Vollzeit zu besetzen.

**Was wir dir bieten**

-

Monatliches Fixgehalt von 2500 Euro

-

Zusätzlich pro Arbeitstag 9,- Essenszulagen

-

Zusätzlich pro Arbeitstag 5,- Fahrtkostenzuschlag

-

Bezahlte Überstunden

-

2x jährlich einen Gutschein in Höhe von je 300,00€

-

10% Discount in Form von Knuspr Credits (Cashback)

-

Freie Lieferung an die Heimatadresse unter dem Mindestbestellwert

-

Knuspr Premium Account

-

Beste Rabatte bei CorporateBenefits (Fitness, Reisen, Tickets, Shopping, uvm.)

**Deine Aufgaben**

-

Qualitätskontrolle: Prüfung von Ware (Fokus Obst & Gemüse) bei Anlieferung und im Bestand

-

Lagersteuerung: Überwachung von Reifegraden, Lagerplätzen und Einhaltung des FIFO-Prinzips

-

Sicherung: Dokumentation von Prüfergebnissen und Gewährleistung der Rückverfolgbarkeit

-

Produktselektion: Aktive Auswahl der besten Waren für den Verkauf

-

Optimierung: Implementierung und Nachverfolgung von Korrekturmaßnahmen

-

Reklamationsmanagement: Bearbeitung von Kundenfeedback in enger Abstimmung mit dem Team

**Das bringst du mit**

-

Bestenfalls bringst du Erfahrung im Umgang mit Obst und Gemüse mit, z.B. aus dem Einzelhandel bei Aldi/Lidl/ Rewe oder aus dem Großhandel

-

Gutes Auge für Qualität und Frische

-

Kommunikationsstärke und Teamfähigkeit

-

Bereitschaft in der Kühle zu arbeiten bei bis zu 3 Grad Celsius

-

Bereitschaft zur Schichtarbeit von Montag bis Sonntag

-

Gute Englischkenntnisse, alternativ gute Deutschkenntnisse

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
