# Product Owner Softwareentwicklung (m/w/d)

Posted: 2026-08-21T23:30:20Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

### Product Owner Softwareentwicklung (m/w/d)

Bei unserem namhaften Kunden im Raum Aalen - einem führenden Unternehmen der Hightechindustrie - bietet sich diese einmalige Perspektive im Rahmen der Arbeitnehmerüberlassung mit der Option auf Übernahme.

### Dein zukünftiger Tätigkeitsbereich

-

Die Product-Vision einer anspruchsvollen Software für die Produktion von optischen High-Tech Systemen zusammen mit dem Scrum-Team weiterentwickeln

-

Die Entwicklung eines oder mehrerer Softwareprodukte im Umfeld komplexer Produktionsprozesse verantworten

-

Die Anforderungsaufnahme bei Produktion- und Entwicklungsabteilungen leiten und in einem Product Backlog in einzelne Entwicklungsaufgeben herunterbrechen, dokumentieren und priorisieren

-

Als Ansprechpartner für die Klärung von fachlichen Rückfragen agieren - Aufwände zusammen mit dem Team abschätzen und bei der Planung von Sprints unterstützen

-

Eine Schnittstelle für die agile und klassische Projektwelt für die Stakeholder schaffen, um sowohl kurzfristige Sprintplanung als auch langfristige Meilensteinplanung zu ermöglichen

-

Die Einführung von Softwareprodukten in der Produktion durchführen und als Ansprechpartner bei Problemen fungieren

-

Die Abstimmung mit den anderen Scrum Teams zur weiteren Standardisierung von Architekturen durchführen und als Servant Leader ein selbstorganisiertes Team unterstützen

### Das zeichnet Dich aus

-

Abgeschlossenes Studium Informatik (m/w/d), alternativ ein naturwissenschaftliches oder ingenieurwissenschaftliches Studium oder vergleichbar

-

Erfahrung in der Leitung von Softwareprojekten, der Analyse von Anforderungen und fundierte Kenntnisse in der Softwareentwicklung

-

Erfahrung in der Mitarbeit in agilen Teams sowie Erfahrung in der Rolle als Product Owner

-

Ein hohes Prozessverständnis und die Fähigkeit komplexe Probleme einfach zu abstrahieren (z.B. mittels Diagramme)

-

Gute Deutsch- und Englischkenntnisse (B2)

-

**For international applicants:** Please note that the business language is **German**. B2 level is mandatory and must have for this position

### Deine berufliche Zukunft

-

**Vergütung: **Übertarifliche Bezahlung zuzüglich Branchenzuschläge

-

**Work-Life-Balance:** Uns ist die Vereinbarkeit von Job und Familie sehr wichtig, daher sind 30 Tage Urlaub und ein Gleitzeitkonto selbstverständlich

-

**Karriere bei Top Unternehmen:** Freue dich auf langfristige Einsätze bei renommierten Unternehmen der Region mit echter Übernahmeoption!

-

**Mitarbeiter-Benefits:** Profitiere von betrieblichen Zusatzleistungen wie Weihnachtsgeld, Urlaubsgeld, bezuschusste betriebliche Altersvorsorge und VWL

-

**Wachsendes Unternehmen: **Mit starkem Auftragseingang und Dynamik

-

**Firmenveranstaltungen: **Freu Dich auf das traditionelle jährliche encontec-Standortfest

-

**Persönliche Betreuung:** Dein persönlicher Ansprechpartner steht Dir jederzeit zur Seite und kümmert sich um all Deine Anliegen

### **Stellendetails**

**Arbeitsort:** Oberkochen
**Arbeitszeit:** 40-Stunden-Woche

**Vertragsart:** Arbeitnehmerüberlassung

**Dauer: **12 Monate

**Startdatum: **sofort oder nach Absprache

Du hast Lust in einem Team zu arbeiten, bei dem partnerschaftliches Miteinander an erster Stelle steht?

Gerne laden wir Dich zu einem Gespräch ein, um Dich persönlich kennenzulernen und Dir die weiteren Schritte auf Deinem Weg zu encontec zu erläutern.

Wir freuen uns auf Dich!

**Dein Kontakt zu uns**

Bastian Heidenfelder

Talentmanager / Account Manager

encontec GmbH

Heidenheimer Str. 104

73447 Oberkochen

Tel.: +49 (0)162 2949990

E-Mail: Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
