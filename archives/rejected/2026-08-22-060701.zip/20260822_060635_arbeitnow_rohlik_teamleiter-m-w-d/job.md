# Teamleiter (m/w/d)

Posted: 2026-08-21T23:40:22Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Unser Herz schlägt für hochwertige Lebensmittel. Unser Motto is(s)t: Eat well, Live well

Die Stelle befindet sich in Bischofsheim bei Mainz (Gewerbegebiet) und ist in Vollzeit zu besetzen.

**Auf was du dich freuen kannst:**

-

Monatliches Fixgehalt

-

Zusätzlich pro Arbeitstag 9,- Essenszulagen

-

Zusätzlich pro Arbeitstag 5,- Fahrtkostenzuschlag

-

2x jährlich einen Gutschein in Höhe von je 300,00€

-

Knuspr Xtra Account und 10% Rabatt als Knuspr Credits (Cashback)

-

Tolle Rabatte über CorporateBenefits (Fitness, Reisen, Tickets, Shopping, uvm.)

**Deine Aufgaben:**

-

Du verantwortest die Führung eines Teams inklusive Personalsteuerung und Planung im Warenausgang oder Wareneingang

-

Du sorgst für eine optimale Auslastung deiner Mitarbeitenden (bis zu 50 Personen) in deiner Schicht

-

Die Steuerung und Überwachung der Einarbeitung neuer Mitarbeitender

-

Zusammen mit dem Kundenservice findest du Lösungen bei Nachbestellungen und Fehlerbehebungen

-

Du passt die Verfügbarkeit und Auslastung von Lieferslots an und überwachst diese

-

Sicherstellung der Arbeits- und Sicherheitsvorschriften sowie der Lieferfristen

-

In Zusammenarbeit mit den Area Managern förderst du die Mitarbeitenden und unterstützt ihr Wachstum

**Das bringst du mit:**

-

Eine abgeschlossene Ausbildung im Bereich Logistik, Gastronomie oder Einzelhandel, z.B. als Fachkraft für Lagerlogistik, Einzelhandelskaufmann, Verkäufer, etc. oder alternativ einschlägige Berufserfahrung in einem vergleichbaren Umfeld, z.B. in der Produktion oder im operativen Geschäft

-

Erfahrung als Führungskraft mit Teams ab 30 Personen

-

Bereitschaft zur Schichtarbeit im 3 Schicht System von Montag bis Samstag (5 Tage Woche zwischen 0 und 22 Uhr)

-

Kommunikationsstärke sowie eine proaktive, gut organisierte und stressresistente Herangehensweise

-

Du kannst mit Kennzahlen umgehen und diese Erstellen und Auswerten

-

Flüssige Englischkenntnisse, weitere Sprachkenntnisse wie z.B. Russisch oder Rumänisch sind von Vorteil

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
