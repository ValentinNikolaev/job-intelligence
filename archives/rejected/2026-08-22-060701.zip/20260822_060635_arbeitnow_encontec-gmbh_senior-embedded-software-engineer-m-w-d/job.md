# Senior Embedded Software Engineer (m/w/d)

Posted: 2026-08-21T23:30:20Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

## **Senior Embedded Software Engineer (m/w/d)**

Willkommen in der faszinierenden Welt der **Optronics!**
Komm in unser Team und profitiere von unseren zahlreichen **Benefits!**

### Dein zukünftiger Tätigkeitsbereich

-

Konzeption, Entwicklung und Pflege einer querschnittlichen Softwareplattform für Optronische Sichtsysteme

-

Requirements Engineering und Softwarespezifikation

-

Querschnittliche und spezifische Weiterentwicklung der Plattform und der zugehörigen Entwicklungsprozesse

-

Middleware-Programing zur Automatisierung verteilter Systeme mit CAN-Bus und Ethernet

-

Objektorientierte Entwicklung in C++

-

Agile Planung und Umsetzung der Softwareentwicklung im Team

-

Nutzung moderner Software- und Web-Technologien (z.B. Git, Jira, Confluence CMake, Catch2, Sqlite, Buildroot, Enterprise Architect)

### Das zeichnet Dich aus

-

Abgeschlossenes Studium Informatik (m/w/d), Elektrotechnik, Ingenieurwesen oder vergleichbar

-

Langjährige Berufserfahrung in der Software-Architekturbeschreibung mit UML in Enterprise Architect, Objektorientierte Software-Entwicklung mit C++(17/23) für Buildroot Linux, QNX und FreeRTOS

-

Kenntnisse im Requirements Engineering und Spezifikationserstellung in DOORS

-

Kenntnisse Middleware-Programing in mindestens einer der folgenden Technologien MQTT, DDS, CANopen

-

Idealerweise Kenntnisse rund um Multi-Processing auf "System on Chip" Architekturen (Xilinx Zynq Ultrascale MPSoC Plattformen)

-

Kenntnisse in der Entwicklung von Unit- und Component Tests

-

Sehr gute Deutsch- und Englischkenntnisse (C1)

-

**For international applicants:** Please note that the business language is German. C1 level is mandatory and must have for this position

### Deine berufliche Zukunft

-

**Vergütung: **Übertarifliche Bezahlung zuzüglich Branchenzuschläge

-

**Work-Life-Balance:** Uns ist die Vereinbarkeit von Job und Familie sehr wichtig, daher sind bis zu 30 Tage Urlaub und ein Gleitzeitkonto selbstverständlich

-

**Karriere bei Top Unternehmen:** Freue dich auf langfristige Einsätze bei renommierten Unternehmen der Region mit echter Übernahmeoption!

-

**Mitarbeiter-Benefits:** Profitiere von betrieblichen Zusatzleistungen wie Weihnachtsgeld, Urlaubsgeld, Jobrad, bezuschusste betriebliche Altersvorsorge und VWL

-

**Wachsendes Unternehmen: **Mit starkem Auftragseingang und Dynamik

-

**Firmenveranstaltungen: **Freu Dich auf das traditionelle jährliche encontec-Standortfest

-

**Persönliche Betreuung:** Dein persönlicher Ansprechpartner steht Dir jederzeit zur Seite und kümmert sich um all Deine Anliegen

**Arbeitsort:** Aalen

**Arbeitszeit:** 35-Stunden-Woche

**Vertragsart:** Arbeitnehmerüberlassung

**Startdatum: **sofort oder nach Absprache

Du hast Lust in einem Team zu arbeiten, bei dem partnerschaftliches Miteinander an erster Stelle steht?

Gerne laden wir Dich zu einem Gespräch ein, um Dich persönlich kennenzulernen und Dir die weiteren Schritte auf Deinem Weg zu encontec zu erläutern.

Wir freuen uns auf Dich!

**Dein Kontakt zu uns
**
Bastian Heidenfelder

Talentmanager / Account Manager

encontec GmbH

Heidenheimer Str. 104

73447 Oberkochen

Tel.: +49 (0)162 2949990

E-Mail: Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
