# Steuerfachangestellte/r (m/w/d)

Posted: 2026-08-21T21:30:35Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Du möchtest nicht nur Zahlen bearbeiten, sondern Mandantinnen und Mandanten wirklich weiterbringen? Du arbeitest gerne strukturiert, verantwortungsvoll und mit modernen digitalen Tools?

Dann passt du zu uns.

Die **JSR Steuerberatungsgesellschaft mbH** ist eine moderne Steuerkanzlei im Herzen Berlins. Wir verbinden fundierte steuerliche Beratung mit persönlicher Betreuung und digitalen Lösungen. Unser Anspruch: Wir denken strategisch und langfristig – für unsere Mandantinnen und Mandanten und für unser Team.

## Aufgaben

- Du bearbeitest die laufende Finanzbuchhaltung unserer Mandantinnen und Mandanten.

- Du erstellst Umsatzsteuervoranmeldungen und unterstützt bei steuerlichen Auswertungen.

- Du wirkst bei der Erstellung von Jahresabschlüssen und Steuererklärungen mit.

- Du kommunizierst mit Finanzämtern und anderen Behörden.

- Du betreust unsere Mandantinnen und Mandanten zuverlässig im Tagesgeschäft.

- Du arbeitest dich – je nach Erfahrung und Interesse – in weitere Themen wie Lohnbuchhaltung oder digitale Buchführungsprozesse ein.

- Du nutzt moderne Software und digitale Abläufe, um deine Arbeit effizient und transparent zu gestalten.

## Qualifikation

- Eine abgeschlossene Ausbildung als Steuerfachangestellte/r (m/w/d).

- Erste Berufserfahrung in einer Steuerkanzlei ist von Vorteil, aber nicht zwingend erforderlich.

- Freude an Zahlen, steuerlichen Fragestellungen und sorgfältigem Arbeiten.

- Einen sicheren Umgang mit MS Office und idealerweise Erfahrung mit DATEV.

- Eine strukturierte, zuverlässige und eigenständige Arbeitsweise.

- Freude an persönlicher Kommunikation und einem vertrauensvollen Umgang mit Mandantinnen und Mandanten.

- Offenheit für digitale Arbeitsweisen und den Anspruch, dich fachlich weiterzuentwickeln.

## Benefits

**Das erwartet dich bei JSR**

Persönliche Betreuung statt Kanzlei von der Stange

Du arbeitest in einem Umfeld, in dem Kommunikation auf Augenhöhe und verlässliche Zusammenarbeit zählen.

Digitale Prozesse, die dir den Alltag erleichtern

Wir setzen auf moderne Tools, strukturierte Abläufe und sichere digitale Zusammenarbeit – in der Kanzlei und online.

Abwechslungsreiche Mandate

Unsere Mandantinnen und Mandanten kommen unter anderem aus den Bereichen Handwerk, freie Berufe, Immobilien und Entertainment. Dadurch bleibt deine Arbeit vielseitig und nah an unterschiedlichen unternehmerischen Lebenswelten.

Raum für Entwicklung

Wir möchten, dass du deine Stärken einbringen und dich fachlich wie persönlich weiterentwickeln kannst. Welche Aufgaben du langfristig übernimmst, gestalten wir gemeinsam.

Ein Team mit Anspruch und Haltung

Wir verbinden Fachkompetenz, persönliche Beratung und moderne Lösungen. Dabei arbeiten wir verlässlich, klar und mit Blick auf langfristige Beziehungen.

Dein Arbeitsplatz

- **Arbeitsort:** Berlin

- **Beschäftigungsumfang:** Vollzeit oder Teilzeit

- **Arbeitsweise:** digital, persönlich und strukturiert

- **Start:** zum nächstmöglichen Zeitpunkt

Dann freuen wir uns, dich kennenzulernen.

Bei Fragen erreichst du uns unter:

**030 / 40 39 34 10**

**JSR Steuerberatungsgesellschaft mbH**

Berlin

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
