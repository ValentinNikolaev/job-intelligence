# Working Student - AI Platform and Enablement (m/f/d)

Posted: 2026-08-21T23:55:31Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**Mission Brief **

Isar Aerospace is building the launch company Europe needs: fast, vertically integrated, technically ambitious, and execution-driven.

We are currently building up our internal AI stack, including a self-managed inference endpoint for deploying open-source models on virtual machines. We are looking for a technically curious working student who can help operate and continuously improve this setup while staying close to the newest models, tools, and agentic best practices.

This is a hands-on role for someone who enjoys making AI systems work reliably, exploring new capabilities, and identifying practical opportunities to automate engineering and business workflows.

Your Role in Our Space Mission:

Help keep Isar Aerospace's internal AI stack current, reliable, and useful, while exploring tools and workflows that make modern AI accessible to teams across the company.

**Support with operation and maintaining the AI Stack**

- Support with the maintenance of the self-managed inference environment used to deploy open-source AI models.

- Update and test deployed models, Docker images, and supporting services.

- Configure and maintain the model gateway, including model routing and endpoint settings.

- Support integrations through REST APIs, MCP servers, and related interfaces.

**Evaluate models and tools**

- Track relevant developments in open-source models, inference tooling, and agentic workflows.

- Run practical evaluations and recommend changes based on quality, usability, reliability, and resource requirements.

- Help maintain concise documentation so the stack can be operated and used consistently.

**Client tools and automation (optional) **

- Curate and test useful client tools that work with the internal endpoint, such as coding harnesses, developer tools, and automation platforms including n8n.

- Explore the Microsoft agent platform, including Microsoft 365 Copilot agents and Copilot Studio, and build selected workflows or agents for internal use.

- Identify repetitive or information-heavy tasks that are worthwhile to automate, then prototype pragmatic solutions with relevant teams.

**Qualification Checklist **

- Currently enrolled in computer science, data science, software engineering, information systems, or a related technical field.

- Hands-on experience with Linux, Docker and basic service operations.

- Ability to work with REST APIs and setting up or integrating services such as MCP servers.

- Basic programming or scripting skills, for example in Python, Bash, or a comparable language.

- A strong personal interest in the latest AI models, developer tools, and agentic best practices, ideally demonstrated through projects, studies, or your own experimentation.

- A practical mindset and an eye for tasks that can be meaningfully automated.

- Structured, reliable working style and willingness to document what you build and maintain.

- Fluent English.

Bonus Skills

- Experience running local or hosted language models and working with inference servers or model gateways.

- Familiarity with AI gateways, open-source models, GPU-backed workloads, Docker Compose, CI/CD, observability, or secrets management.

- Experience with coding agents, automation platforms such as n8n, or Microsoft Copilot Studio.

- Previous AI, infrastructure, developer tooling, or workflow automation projects.

**Benefits **

- **Employee Participation Program:** Share in our success through our virtual company share program

- **30 days of vacation: **Enjoy the days off to relax and recharge

- **Company pension plan:** Secure your future with our company pension plan, featuring a 20% employer contribution after the probation period

- **Subsidised lunch:** Stay energised with delicious, subsidised lunches every day

- **Public transport ticket:** Commute with ease using a fully financed Deutschlandticket

- **Rental clothing with laundry service:** Enjoy hassle-free workwear with our convenient rental clothing and laundry service

- **Sport Clubs membership:** Stay fit with our sponsored sports club memberships (EGYM Wellpass)

- **Individual learning allowance:** Grow your skills with an individual learning budget granted after the probation period

- **Childcare allowance:** Receive a childcare allowance for your non-school-age children

- **And Much More!** Discover additional perks and benefits when you join our team.

**Who we are**

****

We are Isar Aerospace and we are at the forefront of New Space building a modern space business to enable faster, better and cheaper access to space.

Our mission is to help democratise space and use it for good in order to improve life on Earth now and for the future generations.

We are a fast-growing company aiming to provide sustainable and environmentally friendly launch solutions for small and medium-sized satellites and constellations into Low Earth Orbit. The company is privately funded by world-leading technology investors with strong commitment and support and our team is made of driven and talented people with a real passion for space innovation.

We're making rockets in a way that hasn't been done before disrupting a traditional industry. If you are up for the challenge, want to work on cutting-edge projects and be part of a team changing the world for better, come, join us and launch your career!

Want to find out more about us?

Visit [www.isaraerospace.com](http://www.isaraerospace.com/)

**Data Protection
**We process your personal data for the purpose of managing the recruitment process and assessing your application. For detailed information on how your data is processed, including your rights, please refer to our [Privacy Policy](https://isaraerospace.com/privacy-policy).

**Disclaimer
**Isar Aerospace SE is an equal-opportunity employer committed to fairness and inclusivity. We do not prioritize any specific religion, gender, nationality, or background. Due to security clearance requirements, affiliations with countries listed under § 13 para. 1 no. 17 SÜG may affect the application process. All qualified applicants are encouraged to apply.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
