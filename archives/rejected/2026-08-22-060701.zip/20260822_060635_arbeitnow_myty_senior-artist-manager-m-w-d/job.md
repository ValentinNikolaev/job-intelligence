# (Senior) Artist Manager (m/w/d)

Posted: 2026-08-22T02:09:15Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

** Intro**

**Du hast Erfahrung, bist richtig motiviert und willst mit SESAMY die besten Matches zwischen Talents & Top-Brands schaffen? ****We’d love to meet you!**

**Summary**

Du hast Erfahrung im Management von Content Creator:innen und in der Steuerung digitaler Kampagnen? Du verstehst Marken, Menschen, Fashion und Medien – und hast Spaß daran, Karrieren aufzubauen und Kooperationen zum Erfolg zu führen? Bei SESAMY arbeitest du an der Schnittstelle von Talentstrategie, Kreativität und Markenkommunikation. Du hältst die Fäden in der Hand – und bringst Talents, Kund:innen und Teams auf den Punkt zusammen.

**Description**

Was du bei uns machst

-

Betreuung unserer Talents im kompletten Sales-Prozess – von Briefing über Angebot und Verhandlung bis zum erfolgreichen Abschluss.

-

Strategische Beratung & Karriereplanung: Ganzheitliche Talentführung, Analyse von Markenfits, Zielgruppen & Content-Potenzialen sowie Entwicklung maßgeschneiderter Wachstumsstrategien (Luxus, Fashion, Beauty, Lifestyle).

-

Aufbau und Ausbau von Marken- und Agenturbeziehungen, proaktives Pitching in Luxus, Lifestyle & Fashion, Akquise neuer Partner:innen sowie Mitentwicklung kreativer Kampagnenkonzepte.

-

Eigenständige Planung, Umsetzung und Nachbereitung von Kampagnen – inklusive Verantwortung für Timings, Budgets und Qualitätsstandards.

-

Eigenständige Verhandlung von Verträgen, Timings und Budgets, Kontrolle von Rechnungsprozessen, Erstellung von Performance-Reportings sowie Unterstützung von Junior-Rollen.

Was du mitbringst

-

mind. 3 Jahre Berufserfahrung im Talent Management, der Kund:innenbetreuung, im Influencer Marketing oder Kampagnenmanagement (idealerweise im Luxus-, Fashion- oder Lifestyle-Umfeld).

-

Strukturierte, verlässliche Arbeitsweise mit Sinn fürs Detail – auch in hektischen Phasen behältst du Timings, Budgets und Verträge sicher im Blick.

-

Leidenschaft für die Creator Economy, Social Media (Instagram, TikTok, YouTube) und Gespür für stimmige Marken-Fits.

-

Verantwortungsbewusstsein, Mitdenken und lösungsorientiertes Handeln mit dem nötigen Fingerspitzengefühl im Umgang mit Persönlichkeiten.

-

Sicherer Umgang mit Zahlen, Excel, KPIs & Organisationstools.

-

Flexibilität und Freude daran, deine Talents bei Vor-Ort-Terminen, PR-Aktivierungen und Events zu begleiten.

-

Sehr gute Deutsch- und Englischkenntnisse in Wort und Schrift, um mit internationalen Talenten und Kund*innen zu kommunizieren.

Was dich bei SESAMY erwartet

-

Spannendes Portfolio führender Talents und Kund:innen aus Luxus, Fashion, Beauty, Travel & Lifestyle.

-

Wir investieren in dein Wachstum: Wir bieten dir eine Plattform, auf der du unternehmerisch agieren kannst. Du begleitest komplexe Kampagnen von der ersten Idee bis zum Abschluss und entwickelst dich durch die tägliche Herausforderung an der Schnittstelle zwischen Sport und Business eigenständig weiter.

-

Ein monatlicher Zuschuss für die Urban Sports Club Mitgliedschaft oder das Deutschlandticket – such dir einfach aus, was besser für dich passt!

-

30 Tage Urlaub

-

Modernes Arbeiten mit Remote-Option und schönen Offices in Berlin und anderen MYTY Standorten in Deutschland

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
