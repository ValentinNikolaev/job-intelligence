# Senior Business Development Manager (DACH) - Germany

Posted: 2026-08-15T02:20:28Z

## Rejection

- Category: tech_stack
- Reason: role does not mention Go/Golang or PHP

### About AIRS Medical

AIRS Medical is a fast-growing healthcare technology company founded in 2018 and headquartered in Seoul, South Korea, with rapidly expanding operations across the U.S., EMEA, and Japan. Built on the belief that technology should help prevent illness, not just treat it, AIRS Medical empowers people to live healthier, longer lives.

Our flagship solution, **SwiftMR**, is an FDA-cleared, cloud-based AI software solution designed to accelerate MRI scans by up to 50% without compromising diagnostic quality. Trusted by more than 350 hospitals and imaging centers across the U.S., including Lumexa Imaging, Northwestern Medicine, and MedStar Health / Georgetown University, SwiftMR helps improve imaging efficiency, patient comfort, and clinical workflows.

AIRS Medical has been recognized with Frost & Sullivan’s Technology Innovation Leadership Awards in 2023 and 2024 and as the winner of the Facebook AI Research and NYU Langone Health fastMRI Challenge in 2019 and 2020, underscoring our leadership in deep learning and medical imaging AI.

As we continue our global expansion, AIRS Medical remains committed to advancing AI and robotics innovations that enhance patient care, support healthcare professionals, and redefine diagnostic efficiency.

**Requirements**

### Roles & Responsibilities

We are looking for a **Business Development Manager – Germany & DACH** to drive AIRS Medical’s commercial growth across Germany and the broader DACH region.

In this role, you will develop relationships with hospitals, imaging centers, radiology groups, distributors, and strategic partners while identifying new opportunities for SwiftMR and AIRS Medical’s growing portfolio of medical AI solutions.

The ideal candidate combines strong business development and sales capabilities with a solid understanding of the healthcare and radiology environment. Experience working with **hospitals, radiologists, radiology departments, or medical imaging organizations** will be particularly valuable.

- Develop and execute business development and go-to-market strategies for **Germany and the broader DACH market**, with Germany as the primary focus.
- Identify and pursue new business opportunities across hospitals, radiology groups, imaging centers, healthcare networks, and other relevant healthcare organizations.
- Build relationships with key stakeholders, including **radiologists, radiology department leaders, hospital management, procurement teams, IT departments, and clinical decision-makers**.
- Develop and manage partnerships with distributors, strategic business partners, technology partners, and reference sites.
- Manage the full commercial pipeline from lead generation and qualification through product presentation, evaluation, negotiation, and closing.
- Understand customer needs and clinical workflows and effectively communicate the value of AIRS Medical’s AI solutions within the radiology environment.
- Work closely with clinical and technical teams to support discussions involving **MRI workflows, PACS, DICOM, hospital IT environments, and SaaS/cloud-based solutions**.
- Plan and execute sales and marketing activities to generate qualified opportunities and establish relationships with early adopters and key opinion leaders.
- Support and manage assigned partners throughout onboarding, training, pipeline development, and customer engagement.
- Manage partnership discussions, including sales positioning, target customer alignment, pricing, commercial terms, and contract negotiations.
- Analyze market trends, competitor activity, customer feedback, and pipeline data to identify opportunities and continuously improve commercial strategy.
- Maintain accurate pipeline and forecasting information through CRM tools and provide clear market insights to regional and global leadership.
-

### Qualifications

- BA/BS degree or equivalent professional experience.
- **8–12 years of experience** in business development, healthcare sales, partnership development, channel sales, or a related commercial role.
- **Fluent/native-level German and professional fluency in English are required.**
- Strong experience working with **hospitals, radiology departments, imaging centers, radiologists, or other healthcare providers**.
- Demonstrated ability to develop customer relationships and navigate complex B2B or healthcare sales processes.
- Excellent verbal and written communication skills with the ability to communicate effectively with clinical, technical, and business stakeholders.
- Strong presentation and negotiation skills, including the ability to communicate the value of technical products to different audiences.
- Proven ability to manage multiple customers, partners, and commercial opportunities simultaneously while maintaining strong attention to detail.
- Proactive and entrepreneurial mindset with the ability to work independently and take ownership of the assigned market.
- Comfortable working in a dynamic, international, and rapidly growing organization.
- Willingness to travel regularly within Germany and occasionally across the broader DACH region and Europe.
- Experience with CRM software such as Salesforce and proficiency with MS Office/Google Workspace/Slack/Notion

**Benefits**

### Work Conditions and Environment

- **Employment type:** Full-time
- **Location:** Germany
- Remote/home-office based, with regular business travel within Germany and the DACH region
- Collaborate with colleagues across Europe, Korea, the U.S., Japan, and other global markets
- Paid Time Off (**30 days**)
- Onboarding gifts and home office supplies
- Training & Development opportunities
- Opportunity to play a key role in expanding an innovative medical AI solution across the German and DACH healthcare market

### Hiring Process

- Document Screening
- Cognitive Assessment
- Competency-based Interview (Hiring Manager & HR)
- Competency-based Interview (Peer Interview & HR)
- Culture-fit Interview (CEO)
- Onboarding

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
