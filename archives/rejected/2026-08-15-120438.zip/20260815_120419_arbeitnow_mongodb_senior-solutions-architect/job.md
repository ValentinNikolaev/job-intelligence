# Senior Solutions Architect

Posted: 2026-08-15T02:55:15Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

We are looking for passionate technologists to join our Pre-Sales organization to ensure that our growth is grounded and guided by strong technical alignment with our platform and the needs of our customers.

MongoDB Pre-Sales Solution Architects are responsible for guiding our customers and users to design and build reliable, scalable systems using our data platform. Our team is made up of seasoned technical sales professionals, software architects, entrepreneurs, and developers who take direct responsibility for customer success, including the design of their software, deployment, and operations. You'll work closely with our sales executives, helping customers solve business problems by leveraging our solutions, playing a key role in winning deals and driving the business forward. You'll be a trusted advisor to a wide range of users from startups to the world's largest enterprise IT organizations.

This role will be based remotely in Germany.

### As an ideal candidate, you will have:

- Ideally 8 to 11 years of related experience in a customer facing role, with 5 to 7 years of experience in pre-sales with enterprise software

- Minimum of 3 years experience with modern scripting languages (e.g. Python, Node.js, SQL) and/or popular programming languages (e.g. C/C++, Java, C#) in a professional capacity

- Experience designing with scalable and highly available distributed systems in the cloud and on-prem

- Demonstrated ability to work with customers to review complex architecture of existing applications, providing guidance on how to improve by leveraging technology

- Excellent presentation, communication, and interpersonal skills, with the ability to convey complex technical and business concepts in a clear and compelling manner to technology and business leadership

- Ability to strategize with sales teams and provide recommendations on how to drive a multi-threaded account strategy, aligning other MongoDB and ecosystem resources to move towards a mutually beneficial account plan

- The ability to travel up to 25%

- A Bachelor’s degree or equivalent work experience

### You may also have:

- Experience selling databases and/or deploying applications with any of the major cloud providers

- Experience with database programming and data models

- Experience in data engineering or AI/ML projects

- Experience in transforming legacy systems and platforms into modern, scalable, and efficient technology stacks

- Understanding of popular sales methodologies/ frameworks such as MEDDPICC/ Command of the Message

- A MongoDB Certification

- A Cloud Provider Certification

### What you do at MongoDB:

In this role, you will work on complex opportunities where analysis of situations or data requires an in-depth evaluation of various factors. You will:

- Design and Architect: Design scalable and performant applications, systems and infrastructure for large software projects leveraging MongoDB

- Customer Advising and Value Articulation: Guide customers on architecture patterns and optimisation strategies for MongoDB, while clearly communicating its business value to the relevant stakeholders

- Sales Partnership: Collaborate with the sales team to drive account success through account planning, opportunity prioritization/qualification and pipeline generation strategy, while taking ownership of the technical aspects (including but not limited to technical discovery, demos, proof of value, presentations, sizing and documentation)

- Demand Generation: Proactively generate demand within the sales territory through self-driven technical initiatives, participation in events such as industry trade shows and account-based marketing events

- Customer Success: Foster strong customer relationships, build champions and ensure customer success and satisfaction

- Innovation and Improvement: Continuously seek opportunities to innovate and improve MongoDB solutions and processes (e.g. by relaying field feedback to the product team), as well as proactively mentor other Solutions Consulting team members

- Personal Training and Development: Engage in ongoing training and professional development to stay abreast of MongoDB product suite as well as industry trends

### What you will learn:

MongoDB Product Suite Mastery:

- Core Database Server: Master the fundamentals and advanced features of MongoDB's core database

- Atlas and Advanced Services: Gain expertise in Atlas (fully managed cloud database service), Atlas Stream Processing, Atlas Data Lake, Atlas Full-Text Search, Atlas Vector Search, and Charts

- Relational Migrator: Learn to migrate from relational databases seamlessly

Market-Relevant Technologies:

- Hyperscaler Ecosystem: Gain expertise in designing complex systems utilizing cloud services on hyperscaler platforms

- Complementary Technologies: Enhance your skills with partner and complementary technologies such as Apache Kafka and Kubernetes

Modern Architecture Design:

- Design Patterns and Methodologies: Embrace best practices in microservices, DevOps, cloud, and security

- Cutting Edge RAG and AI Architectures: Help customers on their generative AI journeys and working with industry leading partners in the space

Sales Techniques and Soft Skills:

- Effective Communication: Master presentations, demonstrations, and whiteboarding

- Client Interaction: Develop strategies for discovery and objection handling

Industry Insights:

- Diverse Market Verticals: Gain exposure to a broad spectrum of interesting use cases across various industries

### About MongoDB

MongoDB is built for change, empowering our customers and our people to innovate at the speed of the market. We have redefined the data platform for the AI era, enabling builders to create, transform, and disrupt industries with software. MongoDB’s unified data platform, the most widely available, globally distributed data platform on the market, helps organizations modernize legacy workloads, embrace innovation, and unleash AI. Our cloud-native platform, MongoDB Atlas, is the only globally distributed, multi-cloud data platform and is available across AWS, Google Cloud, and Microsoft Azure.

With offices worldwide and over 67,000 customers, including 75% of the Fortune 100 and AI-native startups, relying on MongoDB for their most important applications, we’re powering the next era of software.

Our compass at MongoDB is our [Leadership Commitment,](https://www.mongodb.com/company) guiding how and why we make decisions, show up for each other, and win. It’s what makes us MongoDB.

To drive the personal growth and business impact of our employees, we’re committed to developing a supportive and enriching culture for everyone. [From employee affinity groups, to fertility assistance and a generous parental leave policy](https://www.mongodb.com/company/blog/culture/employee-benefits-that-make-a-difference-at-mongodb), we value our employees’ wellbeing and want to support them along every step of their professional and personal journeys.[ Learn more about what it’s like to work at MongoDB](https://www.mongodb.com/blog/channel/culture), and help us make an impact on the world!

MongoDB is committed to providing any necessary accommodations for individuals with disabilities within our application and interview process. To request an accommodation due to a disability, please inform your recruiter.

MongoDB is an equal opportunities employer.

*Req ID: 3273517777*

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
