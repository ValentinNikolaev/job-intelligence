# QA Engineer Mobile

Posted: 2026-08-15T02:30:10Z

## Rejection

- Category: role_mismatch
- Reason: title is an obvious mismatch for a backend profile

### **About ScholarshipOwl**

ScholarshipOwl is the largest scholarship marketplace in the US, using AI to connect 14 million students who are looking for scholarships with companies that are looking for students. Our mission is to make education financing more accessible and engaging, while giving brands a way to connect with the next generation.

We’re powered by AI technology that simplifies scholarship discovery, streamlines the application process, and delivers measurable results for both students and partners. Whether it’s helping students secure funding or enabling brands to run impactful campaigns, we’re reshaping how education is funded — and discovered.

### **The Role**

We’re looking for a highly skilled and innovative **Mobile QA Engineer** to lead end-to-end quality assurance, test automation, and release stability for our ScholarshipOwl Flutter mobile appand its integration with our GraphQL API. You’ll play a pivotal role in ensuring rapid, regression-free delivery across iOS, Android, and Shorebird OTA updates for millions of students.

In this role, you will champion the "new generation" of quality engineering. Beyond traditional test automation, you will leverage modern AI coding assistants (such as Cursor, Copilot, ChatGPT, Claude, and Gemini) as your primary force multiplier to achieve maximum test coverage at unmatched speed. Working closely with mobile and backend teams across a modern multi-service architecture, you will shift quality left, auditing Figma specs before sprint commitments, reviewing PRs, and maintaining continuous quality gates in our CI/CD pipelines.

### **What You’ll Do**

-

**End-to-End Web Automation:** Build, maintain, and execute parallelized E2E smoke and regression test pipelines using Patrol integrated directly into Codemagic and GitLab CI pipeline.

-

**API & Contract QA:** Establish automated contract and API integration testing to validate GraphQL schema updates against mobile query requirements, guaranteeing zero breaking changes.

-

**AI Integration:** Deeply integrate AI tools (Cursor, Copilot, ChatGPT, Claude, Gemini) into daily workflows to generate Patrol scripts directly from Figma specs, synthesize complex mock payloads, and automate log triage to double QA efficiency.

-

**Shift-Left Quality Champion:** Review feature specs in Figma and GraphQL schema definitions early to catch edge cases, logic gaps, and design flaws before sprint commitments and development begin. Participate actively in PR reviews.

-

**System Observability & Triage:** Monitor build health, Firebase Remote Config/Analytics, Sentry error logs, and GCP Cloud Run logs to triage issues across Flutter BLoC/UI state, GraphQL resolvers, and backend services, logging rich GitLab issues with dev-ready context.

-

**Exploratory & Release Testing:** Conduct testing across iOS Simulators, Android Emulators, physical devices, TestFlight, Google Play Console internal tracks, and Shorebird OTA hot-patches.

-

**Component Testing:** Utilize Flutter Storybook to conduct visual regression and component-level testing early in the release lifecycle.

### Required Qualifications (Must Haves)

-

**Experience Level:** 3+ years of professional experience in Mobile QA Engineering / Test Automation, with at least 1+ year actively incorporating AI coding tools into daily workflows.

-

**Mobile Automation Mastery:** Hands-on experience with Flutter automation frameworks (Patrol, Flutter Integration Test, or strong Appium/XCUITest/Espresso skills with eager readiness to master Patrol).

-

**API & Schema Verification:** Proficiency in testing GraphQL APIs (Bruno, Postman, Playwright, or HTTP clients), including schema validation, headers, and JWT auth flows.

-

**Mobile Ecosystem & Design:** Comfort inspecting Figma files for UI specs/design tokens, using Xcode/Android Studio tools, managing Firebase Remote Config & feature flags, and navigating mobile app deployment lifecycles (Apple App Store / TestFlight, Google Play Console internal testing).

-

**CI/CD & Mobile DevOps:** Experience with mobile CI/CD tools (Codemagic, GitLab CI) and Git/GitLab workflows.

-

**Education:** Bachelor’s degree in Computer Science, Software Engineering, or equivalent practical experience in software development / test automation.

-

**Communication:** Clear, concise async communication skills in written and spoken English for bug reporting, documentation, and remote collaboration.

### Nice to Have

-

**AI-Native Focus:** Advanced proficiency loading architecture specs, GraphQL schemas, and UI design tokens into AI models to auto-generate test cases, Patrol page objects, and mock payloads.

-

**Dart & Component Testing:** Direct Dart / Flutter coding ability to write unit and widget tests in-repo, as well as Flutter Storybook experience.

-

**OTA & Scripting:** Experience with Shorebird (OTA hot patching for Flutter) or basic TypeScript / Bun experience for writing Bruno test collections or schema scripts.

-

**Cloud Infrastructure & Feature Flags:** Exposure to GCP (Cloud Run, Cloud Logging) and Unleash feature flag management.

-

**Certifications:** Certifications in Quality Engineering, Mobile Testing, or AI-Assisted Software Engineering.

### Bonus Skills (The "X-Factor")

-

**Cross-Platform & GraphQL Experience:** Prior experience testing cross-platform Flutter applications connected to GraphQL backends in fast-paced product companies.

-

**Consumer Mobile SaaS:** Previous experience testing consumer mobile apps, EdTech platforms, subscription/billing systems (Stripe, in-app purchases), or user onboarding funnels.

### Why Join ScholarshipOwl?

-

**Mission-Driven Work** – Build technology that helps students unlock education opportunities

-

**Fully Remote ** – Work from anywhere while collaborating with a global team

-

**High Impact & Ownership** – Small team, big challenges, real autonomy

-

**Unlimited PTO** – Take time when you need it, we trust you

-

**Coworking Budget** – $200/month to invest in your ideal coworking workspace

-

**Continuous Learning Culture** – We support curiosity, experimentation, and growth

-

**Hardware Budget** – Up to $1,600 to invest in your ideal computer.

-

**Annual Company Off-sites** – Meet your teammates in person and connect beyond the screen

*Ready to lead and build something meaningful?*

*Apply now and help us shape the future of AI-powered education.*

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
