# Software Architect (m/f/d)

Posted: 2026-08-15T02:30:13Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

We are seeking an experienced and passionate Software Architect to join our growing software organization at Quantum Systems. In this role, you will be responsible for defining, guiding, and evolving the overall software architecture across our unmanned systems — from embedded software on the drone to ground control systems and cloud-based services.
You will work closely with engineering teams across the globe to ensure scalable, robust, and future-proof software solutions.

#### **What is your Day to Day Mission:**

-

Define, own, and continuously evolve end-to-end software architectures spanning embedded systems, ground control software, and cloud platforms

-

Collaborate closely with the Lead Software Architect to align architectural decisions across products and domains

-

Guide and support agile development teams in architectural topics, best practices, and technical decision-making

-

Ensure consistency, scalability, security, and maintainability across all software layers

-

Act as a technical sparring partner for engineering, product, and system teams

-

Evaluate technologies, frameworks, and tools and drive architectural improvements

-

Support integration between airborne, ground, and cloud systems

-

Contribute to the continuous improvement of our global and agile software organization

#### **
**

#### **What you bring to the team:**

-

Bachelor’s or Master’s degree in Computer Science, Software Engineering, or a related field

-

Minimum 5 years of professional software development experience, including at least 3 years in a Software Architect role

-

Strong experience with embedded software development

-

Proficiency in C++, C, and/or Rust

-

Solid understanding of system architecture across embedded, distributed, and cloud-based systems

-

Experience working in agile, globally distributed teams

-

Strong communication skills and the ability to explain complex technical concepts to diverse stakeholders

-

Structured, analytical mindset with a hands-on attitude

-

Ability to work independently while collaborating closely with architects and development teams

#### **Why Quantum-Systems:**

-

We believe in the power of combined efforts: straightforward tech expertise paired with a customer-centric focus.

-

We are industry pioneers who are ambitious, bold, and visionary.

-

We push limits, think outside-the-box and strive for technological excellence to shape the future of aerial data.

-

We promise to be your runway for individual and professional growth.

**
**

#### **Our benefits:**

-

**Company pension scheme: **We support you so that you can already make provisions for later.

-

**Flexible working hours: **With trust-based working hours, you are not only responsible for your working hours, but also for your work-life balance.

-

**Mobile working: **If it gets too turbulent for you in our office, you can get the necessary balance through mobile working.

-

**Bike-Leasing: **We support you in staying environmentally mobile and healthy.

-

**Corporate Benefits: **Your opportunity for attractive offers and discounts from well-known suppliers and brands, e.g. Adidas, Apple, Expedia.

-

**Employee events: **We not only want to grow together, but also celebrate our successes together.

-

**Lunch-Card: **Be powerful with delicious energy, daily lunch budget is sponsored.

-

**Company Shuttle:** Enjoy our convenient shuttle service that picks you up from Pasing in Munich and brings you to our location, with return trips at the end of the workday.

#### **About us:**

Quantum Systems specialises in the development, design, and production of small Unmanned Aerial Systems (sUAS). The company’s range of electric vertical take-off and landing (eVTOL) sUAS are built to maximize range and versatility and to provide operators with a seamless user experience. By integrating cutting-edge software capabilities, like edge computing and real-time AI-powered data processing, Quantum Systems is building next-generation UAS for clients in defence, security, public sectors.

#### **Our commitment:**

We are an open-minded company that not only values diversity, but actively promotes it. Regardless of gender, age, ethnic origin, religion, sexual orientation or disability, we firmly believe that the diversity of our employees is an essential part of our success.

At our company, every voice is heard and every perspective is valued. We believe that our differences enrich us and help us to find creative solutions and generate innovative ideas. We pride ourselves on creating an inclusive work environment where all employees can reach their full potential.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
