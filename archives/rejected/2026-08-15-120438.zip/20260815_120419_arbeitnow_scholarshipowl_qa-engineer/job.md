# QA Engineer

Posted: 2026-08-15T02:30:10Z

## Rejection

- Category: role_mismatch
- Reason: title is an obvious mismatch for a backend profile

### **About ScholarshipOwl**

ScholarshipOwl is the largest scholarship marketplace in the US, using AI to connect 14 million students who are looking for scholarships with companies that are looking for students. Our mission is to make education financing more accessible and engaging, while giving brands a way to connect with the next generation.

We’re powered by AI technology that simplifies scholarship discovery, streamlines the application process, and delivers measurable results for both students and partners. Whether it’s helping students secure funding or enabling brands to run impactful campaigns, we’re reshaping how education is funded — and discovered.

### **The Role**

We’re looking for a highly skilled and innovative **QA Engineer** to lead end-to-end quality assurance, test automation, and release verification across our web platforms and supporting microservices. You’ll play a pivotal role in ensuring zero-regression web releases, fast user conversion funnel performance, and seamless multi-service integrations for millions of students.

In this role, you will champion the "new generation" of quality engineering. Beyond traditional test automation, you will leverage modern AI coding assistants (such as Cursor, Copilot, ChatGPT, Claude, and Gemini) as your primary force multiplier to achieve maximum test coverage at unmatched speed. Working closely with frontend and backend teams across a modern multi-service architecture, you will shift quality left, auditing Figma specs before sprint commitments, reviewing PRs, and maintaining continuous quality gates in our CI/CD pipelines.

### **What You’ll Do**

-

**End-to-End Web Automation:** Build, maintain, and execute parallelized E2E smoke and regression test suites using Playwright and TypeScript, integrated directly into GitLab CI pipelines.

-

**API & Contract QA:** Establish automated schema and contract test coverage across our platform, guaranteeing zero breaking changes for web users.

-

**AI Integration:** Deeply integrate AI tools (Cursor, Copilot, ChatGPT, Claude, Gemini) into daily workflows to generate Playwright scripts directly from Figma specs, synthesize complex mock payloads, and automate log triage to double QA efficiency.

-

**Shift-Left Quality Champion:** Audit Figma design specs, UX flows, and API contracts early to catch edge cases, logic gaps, and design flaws before sprint commitments and development begin. Participate actively in PR reviews.

-

**System Observability & Triage:** Monitor build health, Sentry error logs, GCP Cloud Run logs, and Network profiling tools to isolate bugs rapidly between Nuxt frontend state, GraphQL resolvers, and Laravel backend MySQL databases.

-

**Asynchronous Integration Verification:** Validate complex messaging and outreach workflows.

-

**Component Testing:** Utilize Vitest and Storybook to conduct visual regression and component-level testing early in the release lifecycle.

### Required Qualifications (Must Haves)

-

**3+ years** of professional experience in Web QA Engineering / Test Automation, with at least 1+ year actively incorporating AI coding tools into daily workflows..

-

**Web Automation Mastery:** Strong hands-on experience with Playwright (or Cypress/Selenium with TypeScript/JavaScript) for automated E2E, visual regression, and cross-browser testing.

-

**API & Schema Verification:** Practical experience testing GraphQL and REST / JSON:API endpoints using Bruno, Postman, or script-based test collections.

-

**Web Ecosystem & Profiling:** Proficiency inspecting Nuxt/Vue DOM elements, inspecting Figma design specs/tokens, and utilizing Browser DevTools & Network profiling.

-

**CI/CD & Pipeline Integration:** Experience integrating automated test runs into Git/GitLab CI pipelines and configuring test reporters (e.g., HTML/JUnit).

-

**Education:** Bachelor’s degree in Computer Science, Software Engineering, or equivalent practical experience in software development / test automation.

-

**Communication:** Clear, concise async communication skills in written and spoken English for bug reporting, documentation, and remote collaboration.

### Nice to Have

-

**AI-Native Focus:** Advanced proficiency loading architecture specs, schemas, and UI design tokens into AI models to auto-generate Page Object Models and edge-case scenarios.

-

**TypeScript & Component Testing:** Direct TypeScript, Vue 3, and Nuxt coding knowledge for writing component tests in Vitest and Storybook.

-

**Messaging & AI Service QA:** Experience testing asynchronous messaging workflows (Twilio webhooks, SMS/RCS) or evaluating generative AI/LLM integration outputs (e.g., Gemini AI).

-

**Cloud Infrastructure & Feature Flags:** Exposure to Docker, GCP (Cloud Run, Cloud Build), and Unleash feature flag management.

-

**Certifications** in Quality Engineering, Web Testing, or AI-Assisted Software Engineering.

### Bonus Skills (The "X-Factor")

-

**Backend Stack Familiarity:** Ability to read and debug PHP/Laravel core code and Bun/Node runtimes to assist engineering teams during multi-service bug isolation.

-

**High-Traffic Consumer SaaS:** Previous experience testing consumer SaaS web applications, complex user conversion funnels, EdTech platforms, or subscription/stripe billing flows.

### Why Join ScholarshipOwl?

-

**Mission-Driven Work** – Build technology that helps students unlock education opportunities

-

**Fully Remote ** – Work from anywhere while collaborating with a global team

-

**High Impact & Ownership** – Small team, big challenges, real autonomy

-

**Unlimited PTO** – Take time when you need it, we trust you

-

**Coworking Budget** – $200/month to invest in your ideal coworking workspace

-

**Continuous Learning Culture** – We support curiosity, experimentation, and growth

-

**Hardware Budget** – Up to $1,600 to invest in your ideal computer.

-

**Annual Company Off-sites** – Meet your teammates in person and connect beyond the screen

*Ready to lead and build something meaningful?*

*Apply now and help us shape the future of AI-powered education.*

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
