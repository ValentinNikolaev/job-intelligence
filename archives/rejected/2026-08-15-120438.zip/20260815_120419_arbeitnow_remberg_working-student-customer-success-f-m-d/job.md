# Working Student - Customer Success (f/m/d)

Posted: 2026-08-15T02:40:17Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**At remberg, you’ll help to keep the world running.**

Everything that gets produced relies on a maintenance team behind the scenes that keeps the machines, equipment and infrastructure running. We are helping these teams by simplifying their work with modern, agentic maintenance software. At remberg, we are serving clients like Remondis, Würth, Edeka, Rotkäppchen and 300+ more.

Supported by the visionary founders of category-defining businesses such as Celonis, Dash0, UiPath, Personio and Forto, as well as leading investors like Earlybird, Speedinvest, Oxx, Acton, and Fly Ventures, remberg is positioned to be the European category leader for modern, agentic maintenance software.

**YOUR ROLE & RESPONSIBILITIES**

This position is office-based (hybrid) in Munich.

As a Customer Success Working Student, you will support our Customer Success team in ensuring that customers make the most out of the remberg software.

-

**Help Center:** Build and continuously improve our Help Center content. A well-structured, self-serve knowledge base is what enables us to grow our low-touch customer base fast - your work here directly reduces ticket volume and lets customers help themselves, in any market we enter.

-

**Customer Support:** Own incoming support tickets and respond to customer inquiries across our growing base. As we scale across multiple geographies, fast and reliable support becomes a core driver of retention - you'll help us keep response quality high while we shape and adapt the processes and channels that let us serve more customers efficiently.

-

**Data & Analytics:** Continuously develop and maintain our Amplitude dashboards and contribute to data-driven insights across the team.

-

**Presentations & QBRs:** Support the team in preparing presentations for Quarterly Business Reviews (QBRs), Academy sessions, and other internal and external formats.

-

**Customer Success Initiatives:** Contribute to initiatives that drive product adoption, identify upselling opportunities, and prevent churn. Act as the voice of the customer, helping to translate their needs into product requirements.

**YOUR PROFILE**

You thrive in a fast-paced, dynamic environment and have already demonstrated in a similar role that you can work independently, data-driven, reliably, and in a structured manner.

-

Currently enrolled in at least the 3rd semester of a Bachelor’s program in business/social sciences, informatics, software engineering, industrial engineering, or a comparable field of study.

-

Strong analytical skills, a high level of responsibility, and a goal-oriented work style.

-

High technical affinity; experience with tools like Amplitude, Airtable, or Intercom is a plus.

-

Solid MS Excel skills and ideally a basic understanding of programming languages

-

Fluency in German (C2) and English (C1), both written and spoken.

### EVERYTHING YOU NEED TO THRIVE

-

💰 **Competitive compensation package**: Enjoy a salary, benefits, and equity*, with annual reviews.

-

**💻 State-of-the-art tools and equipment** for a modern and efficient setup.

-

**🍏 Health and wellness benefits**: Access to Nilo Health, JobRad*, and your choice between a GUUD card or Wellpass / Urban Sports Club for sports and fitness.

-

**🥨 Prime office location & culture**: Our office is in the heart of Munich, near the main train station, making it easily accessible for commuters and travelers. Our office is always lively, with 3 days/week in the office.

-

**🌞 Work-from-anywhere flexibility**: You can work remotely for up to 3 months per year.

-

**🌴 Attractive Compensation & Benefits**: In addition to a competitive salary, you'll enjoy different company benefits and 30 vacation days*.

-

📚 **Continuous learning**: Get a €1,500 development budget plus 1 day of educational leave per year.*

-

🤝 **Volunteering day**: 1 paid day per year to give back to a cause you care about.

*Some perks apply to permanent full-time employees only.

### ABOUT US

remberg is a fast-growing start-up based in Munich. Founded in 2018 as a spin-off from TU Munich & CDTM. We help industrial companies to keep the physical world running by simplifying maintenance with modern, agentic software. Today, we are serving clients like Remondis, Würth, Edeka, Rotkäppchen and 300+ more. With ~28 M € capital raised by the visionary founders of category-defining businesses such as Celonis, Dash0, UiPath, Personio and Forto, as well as leading investors like Earlybird, Speedinvest, Oxx, Acton, and Fly Ventures, remberg is positioned to be the European category leader for modern, agentic maintenance software (CMMS/EAM).

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
