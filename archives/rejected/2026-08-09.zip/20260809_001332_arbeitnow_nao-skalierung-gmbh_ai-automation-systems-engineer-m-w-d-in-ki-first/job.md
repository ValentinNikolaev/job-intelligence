# AI Automation & Systems Engineer (m/w/d) in KI-First-Marketing-Agentur

Posted: 2026-08-08T22:00:24Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Wir sind eine Boutique-Marketing-Agentur für Coaches & Berater.

Unser Ziel ist es, unsere Agentur zu einer KI-First-Agentur umzubauen, in der alle standardisierbaren Prozesse von KI übernommen werden. Es wird einen kleinen Teil hochspezialisierter Menschen geben, die die KI steuern und führen.

Hierfür suchen wir eine Person, die den Wechsel maßgeblich leitet. Diese Rolle entscheidet maßgeblich darüber, wie unser Unternehmen in den nächsten zehn Jahren arbeitet.

Gemeinsam mit unserem Geschäftsführer baust du die Agentur strategisch um, während du den Prozess operativ leitest und umsetzt.

## Aufgaben

- Du analysierst bestehende Unternehmens- und Marketingprozesse, identifizierst Ineffizienzen und entwickelst skalierbare, effiziente Workflows und Prozesse für alle Bereiche unseres Unternehmens.

- Du entwickelst, implementierst und optimierst KI-Agenten, Automatisierungen und interne Softwarelösungen mit modernen Technologien wie n8n, APIs, LLMs und weiteren KI-Tools.

- Du transformierst manuelle Unternehmensprozesse in intelligente, KI-gestützte Systeme und Automatisierungen, sodass sich unsere Mitarbeiter auf strategische, kreative und wertschöpfende Aufgaben konzentrieren können.

- Du identifizierst konsequent alle wiederkehrenden Tätigkeiten im Unternehmen und entwickelst Lösungen, um diese durch Automatisierungen, KI-Agenten oder neue Workflows zu ersetzen oder deutlich zu vereinfachen.

- Du standardisierst und dokumentierst Prozesse (SOPs) und sorgst dafür, dass diese nachhaltig im Unternehmen eingeführt und gelebt werden.

- Du arbeitest eng mit allen Teams zusammen, verstehst ihre Herausforderungen und entwickelst Systeme, die ihre tägliche Arbeit einfacher, schneller und skalierbarer machen.

- Experimentieren ausdrücklich erwünscht. Ein Teil deiner Aufgabe ist es, neue Technologien zu testen, zu bewerten und produktiv einzusetzen. Wir erwarten nicht, dass du alles weißt, sondern dass du neugierig bist und gerne Neues ausprobierst.

- Deine Rolle erfordert extrem viel Eigenverantwortung. Es ist deine Aufgabe, mit offenen Augen durch das Unternehmen, durch die Systeme zu gehen und Ineffizienzen zu erkennen und eigenständig zu beseitigen.

## Qualifikation

- 5-10 Jahre Berufserfahrung

- Du hast bereits komplexe Unternehmensprozesse aufgebaut und skaliert. Idealerweise in einer Marketingagentur, einem SaaS-Unternehmen, einem Tech-Unternehmen oder einem schnell wachsenden Scale-up.

- Du hast bereits Führungsverantwortung übernommen und Menschen geführt

- Du weißt, wie man exzellente Prozesse aufbaut: Von der Konzeption über die operative Einführung bis hin zur erfolgreichen Etablierung im Team.

- Du liebst Prozesse, erkennst Ineffizienzen sofort und hast den Anspruch, wiederkehrende Arbeiten dauerhaft zu eliminieren.

- Du beschäftigst dich seit mehreren Jahren intensiv mit KI, Automatisierung und AI Engineering. Du hast bereits komplexe KI-Workflows und Agentensysteme entwickelt, idealerweise mit Tools wie n8n, Claude Code, Cursor, Make oder vergleichbaren Technologien und verfolgst die neuesten Entwicklungen im KI-Bereich kontinuierlich.

- Du verfügst über einen Hintergrund in Softwareentwicklung oder Programmierung und verstehst Code, APIs und technische Zusammenhänge weit über No-Code-Automatisierungen hinaus.

- Du besitzt eine außergewöhnlich schnelle Auffassungsgabe, erkennst komplexe Zusammenhänge schnell und arbeitest dich eigenständig in neue Themen, Technologien und Systeme ein.

- Du denkst radikal in AI first: Nicht: Wie kann ich den Prozess automatisieren, sondern: wie können wir den Prozess automatisieren und die KI übernehmen lassen, ohne menschliches Eingreifen.

- Du hast schon privat für dich ein Agentensystem aufgebaut, das so manch nervige Aufgabe für dich erledigt

- Kommunikationsstärke: Du kannst komplexe technische Themen verständlich vermitteln und begeisterst andere dafür, neue Prozesse, Automatisierungen und KI-Systeme erfolgreich zu nutzen.

## Benefits

- Gestalte die KI-First-Agentur: Du baust nicht einzelne Automatisierungen, sondern entwickelst das KI-Betriebssystem eines Unternehmens, das neue Maßstäbe im Markt setzen will.

- Maximale Gestaltungsmöglichkeiten: Du erhältst viel Verantwortung, kurze Entscheidungswege und die Freiheit, Prozesse, Systeme und KI-Agenten eigenständig zu entwickeln und umzusetzen.

- Token-Flatrate :) Wir wollen dich in deiner Arbeit unterstützen und werden dir die Arbeit mit jedem KI Modell ermöglichen.

- High-Performance-Team – Du arbeitest mit einem ambitionierten Team, das hohe Ansprüche an Qualität hat, Verantwortung übernimmt und sich gegenseitig fordert, unterstützt und kontinuierlich weiterentwickelt.

- Persönliche und fachliche Weiterentwicklung: Wir investieren gezielt in deine Weiterbildung im Bereich KI, Automatisierung, Softwareentwicklung und Unternehmenssysteme und ermöglichen dir den Zugang zu relevanten Kursen, Events und Fachkonferenzen.

- Direkter Einfluss auf den Unternehmenserfolg: Deine Systeme, Prozesse und KI-Agenten beeinflussen unmittelbar die Effizienz und Skalierbarkeit unseres gesamten Unternehmens.

- Jährliche Workation: Arbeite gemeinsam mit dem Team an inspirierenden Orten und verbinde intensive Zusammenarbeit mit gemeinsamen Erlebnissen.

- Modernes Büro im Süden Hamburgs mit Homeoffice-Möglichkeit.

- Vertrauensarbeitszeit – Wir bewerten Ergebnisse statt Anwesenheit und geben dir den Freiraum, deine Arbeit eigenverantwortlich zu organisieren.

Wenn du glaubst, dass du die richtige Person für diese Schlüsselrolle bist, freuen wir uns auf deine Bewerbung. Bitte nenne uns dabei deine Gehaltsvorstellung und deinen frühestmöglichen Eintrittstermin.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
