# Hardware-Entwickler / Elektronikentwickler (m/w/d)

Posted: 2026-08-08T20:30:20Z

## Rejection

- Category: language_requirement
- Reason: hard German language requirement without English green light

#### Hardware-Entwickler / Elektronikentwickler (m/w/d)

-

**Standort: Berlin | Vollzeit | Unbefristet**

Für unseren Mandanten, ein seit über 80 Jahren international führendes, familiengeführtes Unternehmen im Bereich elektronischer Mess- und Regelungstechnik – mit einem klaren Fokus auf Innovation, Präzision und technologische Spitzenleistung – suchen wir im exklusiven Auftrag zum nächstmöglichen Zeitpunkt einen **Hardware-Entwickler (m/w/d)**. Das Unternehmen bietet Ihnen eine technisch anspruchsvolle Entwicklerposition mit echter Produktverantwortung – von der ersten Idee bis zur Fertigungsreife – in einem kollegialen Team, das Qualität und Innovationsgeist aktiv lebt.

#### **Ihre Aufgaben**

-

**Schaltungsentwicklung:** Eigenverantwortliche Entwicklung analoger und Mixed-Signal-Schaltungen nach Kundenanforderungen – mit Herzblut, Detailliebe und analytischer Präzision

-

**Konzeptentwicklung:** Erarbeitung neuer Konzepte sowie Verbesserung bestehender Konzepte für die industrielle Messtechnik auf höchstem technischem Niveau

-

**Hardware-Engineering:** Aktive Mitwirkung in allen Phasen des Hardware-Engineering-Prozesses – von der Konzeption über das Design bis zur Verifikation

-

**Analyse & Verifikation:** Eigenverantwortliche Analyse und Verifikation von Neu- und Re-Designs zur Sicherstellung höchster Qualitäts- und Funktionsstandards

-

**Produktverantwortung:** Vollständige Betreuung des eigenen Produkts von der ersten Idee bis zur abgeschlossenen Fertigungsreife

#### **Ihr Profil**

-

**Fachliche Qualifikation:** Abgeschlossenes Studium der Elektrotechnik, Nachrichtentechnik oder einer vergleichbaren technischen Fachrichtung

-

**Fachkenntnisse:** Fundierte theoretische und praktische Kenntnisse in analoger Schaltungstechnik – Sie denken in Schaltungen, nicht in Standardlösungen

-

**Innovationsanspruch:** Konventionelle Lösungen genügen Ihrem Qualitätsanspruch nicht – Sie suchen stets den technisch überzeugenden Weg

-

**Arbeitsweise:** Analytisch, strukturiert und mit einem ausgeprägten Sinn für technische Details – auch bei komplexen Entwicklungsaufgaben behalten Sie den Überblick

-

**Persönlichkeit:** Kommunikationsstark, teamfähig und mit echtem Enthusiasmus für die Entwicklung elektronischer Systeme

-

**Sprachkompetenz:** Deutschkenntnisse auf muttersprachlichem Niveau

#### **Ihre Vorteile**

-

**Geregelte Arbeitszeiten:** 1-Schichtbetrieb mit flexibler Zeiteinteilung Montag bis Freitag zwischen 6 und 19 Uhr – für eine echte Vereinbarkeit von Beruf und Privatleben

-

**Erholungszeit:** 30 Urlaubstage für eine nachhaltige Work-Life-Balance

-

**Vergütung:** Urlaubs- und Weihnachtsgeld sowie variable Zusatzleistungen als verlässliche Ergänzung zur Grundvergütung

-

**Gesundheit:** Betriebliche Krankenversicherung mit zusätzlichen Leistungen für Ihre gesundheitliche Absicherung

-

**Moderner Arbeitsplatz:** Zeitgemäß ausgestattete Entwicklungsumgebung mit modernsten Technologien und Werkzeugen

-

**Sport & Verpflegung:** Sportangebote direkt im Haus sowie Zuschuss für Snacks und Mahlzeiten

-

**Mobilität:** Kostenfreie E-Bike-Ladestation sowie sehr gute Verkehrsanbindung am Berliner Standort

-

**Weiterbildung:** Individuelle Schulungs- und Weiterbildungsmöglichkeiten zur gezielten fachlichen Weiterentwicklung im technologischen Umfeld

#### **Kontakt**

Hypertrics GmbH
Schürmannstraße 22a
45136 Essen

####

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
