# Softwareentwickler Automatisierungstechnik / SPS-Programmierer (m/w/d)

Posted: 2026-08-08T20:30:06Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**Softwareentwickler Automatisierungstechnik / SPS-Programmierer (m/w/d)**

Standort: Krefeld | Vollzeit (40 h Woche) | unbefristet

SPS-Programmierung | Automatisierungstechnik | Visualisierung | Steuerungstechnik

**CERTUSS** ist Teil des japanischen Miura-Konzerns und bewahrt dabei bewusst eine familiäre, mittelständisch geprägte Unternehmenskultur. Ein enger Austausch, kurze Entscheidungswege und ein hohes Maß an Verantwortung prägen die tägliche Zusammenarbeit. Als einer der weltweit führenden Hersteller von kompakten, effizienten Dampferzeugern kommen unsere Anlagen in mehr als 90 Industriezweigen zum Einsatz – von der Lebensmittelproduktion über Chemie und Pharma bis hin zur Automobil- und Textilindustrie.

Sie begeistern sich für Automatisierungstechnik und entwickeln gerne intelligente Steuerungslösungen? Sie möchten Ihre Ideen in einem technisch anspruchsvollen Umfeld einbringen und an Produkten arbeiten, die weltweit eingesetzt werden? Dann werden Sie Teil unseres Teams und gestalten Sie die Weiterentwicklung unserer Automatisierungs- und Steuerungssysteme aktiv mit.

**Wir bieten**

• attraktive, marktgerechte Vergütung
• unbefristete Vollzeitstelle mit 40-Stunden-Woche
• 30 Urlaubstage & faire Überstundenregelung
• Urlaubs- & Weihnachtsgeld, JobRad, Geburtstagsgeschenk, Betriebsfeiern, vermögenswirksame Leistungen & Zuschuss zur betrieblichen Altersvorsorge – über den gesetzlichen Zuschuss hinaus
• wertschätzende Unternehmenskultur mit kurzen Entscheidungswegen – kein Konzernklima, sondern echter Zusammenhalt
• internationales Umfeld mit familiären Strukturen – Sie kennen Ihre Ansprechpartner und werden selbst gekannt
• strukturierte Einarbeitung und ein Team, das Sie vom ersten Tag an unterstützt
• Möglichkeit zum mobilen Arbeiten nach erfolgreicher Einarbeitung und nach Absprache
• moderne Arbeitsplatzausstattung und zeitgemäße Entwicklungstools
• Unser Standort in Krefeld ist gut erreichbar – per Auto (kostenfreie Parkplätze auf dem Firmengelände) und per ÖPNV

**Ihre Aufgaben**

Als Softwareentwickler Automatisierungstechnik (m/w/d) entwickeln und optimieren Sie unsere Steuerungs- und Automatisierungslösungen für industrielle Dampferzeugersysteme und begleiten diese von der Entwicklung bis zur Inbetriebnahme.

• Entwicklung und Weiterentwicklung von SPS-Software für unsere Dampferzeuger und Anlagen

• Programmierung und Optimierung von Steuerungs- und Automatisierungslösungen

• Erstellung und Weiterentwicklung von Visualisierungen

• Analyse, Fehlersuche und Debugging bestehender Softwarelösungen

• Durchführung von Tests sowie Unterstützung bei Inbetriebnahmen

• Erstellung technischer Dokumentationen

• Enge Zusammenarbeit mit den Bereichen Konstruktion, Elektrotechnik, Produktion und Service

**Ihr Profil**

• Erfolgreich abgeschlossene Weiterbildung zum Techniker (m/w/d), ein Studium oder eine vergleichbare Qualifikation in den Bereichen Automatisierungstechnik, Mechatronik, Elektrotechnik, Maschinenbau oder Industrie-Informatik

• Erfahrung in der SPS-Programmierung und der Entwicklung von Automatisierungslösungen

• Kenntnisse in mindestens einem gängigen SPS-Programmiersystem, z. B. Codesys oder Siemens TIA Portal – Programmiersprache ST

• Erfahrung in der Erstellung von Visualisierungen sowie im Umgang mit industriellen Steuerungssystemen von Vorteil

• Ausgeprägte Fähigkeiten bei Fehlersuche, Analyse und Debugging

• Interesse an technischen Zusammenhängen sowie an der Weiterentwicklung bestehender Automatisierungslösungen

• Strukturierte, selbstständige und lösungsorientierte Arbeitsweise

• Teamfähigkeit, Kommunikationsstärke und ein hohes Qualitätsbewusstsein

• Gute Deutschkenntnisse sowie Englischkenntnisse für die technische Dokumentation

**Jetzt bewerben!**

Es erwartet Sie ein engagiertes Team, das Sie herzlich willkommen heißt!

Wir freuen uns auf Ihre Bewerbung – am liebsten noch heute!

Werden Sie Teil von **CERTUSS** – einem Unternehmen, das seit 1957 zuverlässig und vertrauensvoll handelt und gemeinsam mit Ihnen weiterwachsen möchte.

Bitte nennen Sie uns Ihr frühestes Eintrittsdatum und Ihren Gehaltswunsch. Bewerben Sie sich über unser digitales Bewerbungsformular.

**CERTUSS **GmbH – Hafenstraße 65, 47809 Krefeld

**[www.wirmachendampf.com](http://www.wirmachendampf.com/) | [www.certuss.com](http://www.certuss.com/)**

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
