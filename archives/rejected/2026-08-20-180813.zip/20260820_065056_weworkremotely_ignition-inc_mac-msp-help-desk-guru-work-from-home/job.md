# Mac MSP Help Desk Guru (work from home)

Posted: 2026-05-28T07:25:37Z

## Rejection

- Category: stale
- Reason: published_at 2026-05-28T07:25:37Z is older than 7 days

**Headquarters:** ignitionit.com

**URL:** [https://ignitionit.com](https://ignitionit.com)

**APPLY HERE: https://go.cultureindex.com/p/bLvP56CvGHU**

**Fully Remote · Work from home · Full-time (Eastern or Pacific time zones) · Apple-first **

**TL;DR**

ignitionit.com is a seasoned, Apple-first MSP — in business for almost 30 years — and we're hiring a Help Desk Technician to be the friendly, capable first voice our clients reach when something isn't working. This position is a remote, work-from-home, full-time role.

We've written this as a junior-to-mid-level job description because that's where most great people start on our team. But if you're more seasoned — comfortable in identity, MDM, or security work — don't scroll past. We'd be delighted to find someone who can step in higher up the ladder, and we'll happily talk about a more senior scope and comp if that's you.

**What the actual job???**

Unlike many IT shops, we believe that the technology is the tactic. The actual job is making people feel taken care of. One of our core values is “49% tech support, 51% human support.”

You'll succeed by configuring devices, resetting access, untangling email, and chasing down the gremlin that's been haunting someone's conference room. But you'll know you succeeded when a client exhales and says, “Thank goodness you're on it!” That Warm Fuzzy Feeling™ is the actual product. The green lights on the dashboard are just how we get there.

In a typical week, you might:

-

Onboard a new hire at a fast-growing startup: provision their Mac, set up their Google Workspace or Microsoft 365 accounts, enroll the device in MDM, and make sure day one feels effortless.

-

Offboard a departing employee cleanly — recover the laptop, revoke access, and close the loop so nothing's left dangling. All boxes checked, ticket notated and closed, client followed up with.

-

Field a "my email stopped working" ticket that turns out to be a DNS thing, a phishing-filter thing, or a "they changed their password on their phone three weeks ago" thing.

-

Help a family office or RIA get a touchy Zoom Room or conference-room AV setup behaving before a meeting — over the phone.

-

Triage the queue so phones get answered fast, emails don't rot, and nobody feels forgotten — even when the honest answer is, “We're on it, but here's the realistic timeline."

⠀ You'll be the front line: helping with what you can, researching what you can't, and pinging the rest of the team when you're genuinely stuck. That last part is a skill, not a weakness — knowing when to ask is half the job.

**About ignitionit.com**

We're one of the oldest Apple Technical Partners on the planet, and one of the only certified Apple Premier Partners — that’s kinda like getting knighted by the ghost of Steve Jobs. We started where you’d expect to find Macs (creative agencies, non-profits, education) but our primary clients today are cutting-edge, venture-backed AI SaaS startups, VC and private equity firms, registered investment advisors — many of them operating under stringent compliance expectations (SOC 2, SEC). That means we hold ourselves to a higher standard than the scrappy shop we started as. Polished, reliable, security-minded work is the baseline now — but always with a smile!

What hasn't changed: relationships are still our most valuable currency — with clients, with vendors, and with each other. We're a tight, supportive team. We teach each other what we know, cover for each other when life throws a punch, and care a little too much about doing things the right way. We're still a bit weird, and our clients seem to like us that way.

We move fast, priorities shift, it’s not always documented (whatever it is), our tool set and list of supported platforms is sprawling, and some days the to-do list is longer than you'd like. If you can stay warm under pressure, create order out of chaos, learn new stuff fast because you love it, and speak up when you need help, you'll thrive here.

If you need a rigid, fully-documented, never-changes environment where nobody trusts you with admin access, where you will be micro-managed so you never have to wonder whether or not you’re doing the right thing, this isn't it. You’ll have a ton of independence on our team, and freedom to use your best judgment to get the ball over the finish line, but that also means we expect you to be naturally responsible, honest, and highly accountable — to yourself, your teammates, and the clients. As they say, the price of freedom is eternal vigilance.

**The tech you'll work with (and grow into)**

Day one, you'll be living in:

-

Apple at the core — macOS, iOS, Apple Business Manager, and MDM (Jamf / Iru / Intune / Workspace ONE / and more)

-

Yes, PCs too — about one-third of our users are driving Windows

-

Google Workspace and Microsoft 365 admin consoles

-

Identity and access — SSO, MFA, and security keys (Okta, Entra ID, Yubikey, and friends)

-

Lots of other security tools — our stack is constantly evolving and may vary from client to client

-

The everyday productivity stack — Slack, Zoom, conference-room AV, networking basics (Meraki), and endpoint tooling

⠀ You don't need to know all of this. You need to be the kind of person who wants to. As you grow, there's a clear path into infrastructure administration, project architecture and implementation, and — for the right person — security and compliance work (phishing simulations, endpoint detection, SOC 2 / CIS / SEC readiness, due diligence questionnaire support, etc.). That's where our most senior people live, and it's wide open.

**Who we hope you are**

The hard requirements — we won't move forward unless you:

-

Can work standard business hours in Eastern or Pacific time zones (we currently need both)

-

Have a quiet home workspace and reliable broadband

-

Have proven Apple aptitude — you actually use and like the Apple ecosystem

-

Have at least 2 years of IT support experience on the job. Go-getters who are just getting started and can prove they have a deep, demonstrable history of teaching themselves technology for the sheer joy of it might also make the cut.

⠀ Everything else — and this is the longer list, on purpose. We figure technical skills are teachable; character takes a lot longer. So we're looking for someone who:

-

Genuinely cares — about clients, teammates, and doing right by people

-

Loves to learn, and proves it in how they spend their time

-

Reads, and writes clearly — clear writing is clear thinking, and you'll do a lot of it

-

Stays calm and kind with a frustrated person on the other end of the line

-

Can tell the difference between good customer service and fantastic customer service, and refuses to settle for the former

-

Notices when something's being done inefficiently and fixes it (you may boast about it later, that’s fine)

-

Proofreads their own work (yes, we noticed whether you proofread your application)

-

Has a sense of humor, and doesn't take themselves too seriously

**Regarding AI**

Our company founder/CEO is headquartered in the Bay Area. We work with innovative, ambitious companies developing AI products. Our team members hold a range of opinions about whether AI is “good or bad” for humans, but at the end of the day, we embrace the plain fact that it is here, we must embrace it to evolve, and our clients increasingly depend on us to help them embrace it, too, to help them evolve and stay competitive.

Our CEO's opinion: AI will not replace human labor any time soon; rather, AI is a new opportunity to either (a) get things done faster, or (b) get a much higher quality of output than before. If you’re an AI tinkerer, great! We want to hear how you’re using it and see your latest vibe project. If you’re allergic to AI or have no interest in learning new habits to work effectively with it, this is not the place for you.

**Compensation & logistics**

-

Base salary: For applicants closer to the junior side who are located in the USA, $50,000–$65,000/yr, depending on experience level and your local geographical price index. With experience, comp goes up from there. Genuinely experienced, more senior candidates can be slotted higher — let's talk. Applicants outside the USA will be compensated according to your local employment market.

-

Type & location: Full-time, work from home, fully remote. Eastern or Pacific time zones.

-

Benefits: Medical / dental / vision for the employee, 401(k) with employer contribution, 2 weeks of PTO annually to start, and a stipend for your home internet.

**How to apply**

The first step is really easy and only takes 10 minutes — no resume, no cover letter, no essays. Here's how:

-

Take[ this online Culture Index assessment ](https://go.cultureindex.com/p/bLvP56CvGHU)(about 10 minutes): We use it to screen for people whose natural wiring fits how our team works.

-

If your profile lines up with what we're looking for, we'll reach out and ask you to complete a 60-minute TestGorilla assessment for critical thinking skills, send us your resume, and maybe a couple of other items.

-

From there, we conduct between 2-4 video interviews. One of these might be a live technical assessment.

If the Culture Index step feels like a strange way to start a job application — that's kind of the point. Remember the phrase Think Different?

Ignition is an equal opportunity employer. We welcome and will consider all qualified applicants. Good luck in your search — and may the Force be with you!

**To apply:** [https://weworkremotely.com/remote-jobs/ignition-inc-mac-msp-help-desk-guru-work-from-home](https://weworkremotely.com/remote-jobs/ignition-inc-mac-msp-help-desk-guru-work-from-home)
