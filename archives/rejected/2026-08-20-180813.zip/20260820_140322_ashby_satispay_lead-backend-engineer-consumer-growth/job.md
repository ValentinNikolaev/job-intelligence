# Lead Backend Engineer - Consumer Growth

Posted: 2026-07-15T07:19:01.686+00:00

## Rejection

- Category: stale
- Reason: published_at 2026-07-15T07:19:01.686+00:00 is older than 7 days

Lead Backend Engineer - Consumer Growth



About us

Satispay began by rethinking the simple act of a payment to remove the friction from our daily routines. But we didn’t stop there. Today, we are building a complete financial platform designed to empower people and concretely improve their lives.

By giving our 6 million users a clear, open path to pay, save, and invest, we are evolving into the definitive destination for every financial need.

You'll be joining the Consumer Growth team. We own the systems that power the end-to-end consumer experience on Satispay - from the moment someone signs up to the day they leave. Our mandate is growth: maximising the number of consumers joining the platform and driving engagement through marketing campaigns and Satispay Points



What you’ll be doing

As a Lead Backend Engineer in the Consumer Growth Team, you'll play a critical role in shaping the technical direction of the team. This is an individual contributor (IC) role - you'll lead through technical excellence and influence, not through direct reports or people management. You will be responsible for the technical quality and delivery of complex systems, collaborating closely with other teams.

Here’s what your day-to-day will look like:

 - Build and ship. You will design, implement, and operate services that power the Satispay consumer experience - from payment flows and identity verification to loyalty and engagement features. You'll work across the full lifecycle: from API design and data modelling to production rollouts and on-call ownership.

 - Cross-team technical leadership. You will drive technical analysis for projects that cut across multiple teams, lead design discussions, and produce documentation that gives stakeholders and other teams a clear, reviewable picture of every design before build begins.

 - Foster engineering excellence. You will raise the quality bar across mobile and backend development: rigorous testing strategies, safe progressive rollouts, and proactive elimination of technical debt in a codebase that ships 2M+ daily payments. You'll champion simplicity and maintainability in services that other pods depend on.

 - Mentor and develop. You will provide technical guidance to junior and mid-level engineers in the Consumer Growth teams, helping them navigate cross-service dependencies, adopt sound event-driven patterns, and build a shared instinct for operational excellence.

Expect challenges, collaboration, and the freedom to bring your ideas to life. Our tech stack includes (but it’s not limited to) PostgreSQL, Java, Spring Boot. We rely on AWS for our infrastructure, with microservices deployed on EC2/ECS, S3 for storage, AWS Lambda for serverless functions, and Kinesis and ElasticSearch for log streaming. You'll take ownership of your work from start to finish.



Who we’re looking for

We need a proven problem-solver who takes initiative, excels in cross-team collaboration, and is a technical quality champion. Does it sound like you?

 - Extensive experience: You have at least 5 years of related experience in back-end software engineering. You have a proven track record of working with microservices and cloud environments (AWS is a plus) in high-paced, mission-critical contexts.

 - Technical depth: You possess deep experience with Java and Spring Boot. You have a strong understanding of distributed systems and how to manage external dependencies (like banking protocols) effectively.

 - Structured communication: You are able to communicate complex technical concepts clearly and convincingly. You excel at coordinating implementations with other teams and building trust with various stakeholders.

 - Impact mindset: You are focused on delivering software that meets evolving user needs. You are adaptable, avoid analysis paralysis, and "go the extra mile" to optimize systems beyond the initial requirements.

 - Passion and language skills: You are passionate about FinTech and fluent in English.

Don't worry if you don't tick every box. We believe in the power of different viewpoints and strengths. Your unique perspective is important as we build something special. If you're passionate and can make a difference, we truly encourage you to apply.



CareAbout: how we support your impact

We move fast, and evolution never stops. It’s a fun ride, but it can be challenging. To make sure our people truly thrive, we’re committed to making their lives easier, both in the office and out in the world. That’s why we created CareAbout:

 - ❤️ Health (Private insurance for you and your family, psychological support with Serenis, mental health workshops)

 - 💰 Financial resources (Stock Option Plan, Meal vouchers, Relocation support if you’re moving countries)

 - ⚙️ Growth and development (Professional development programs, Internal mobility, Language courses with Preply)

 - 🌱 Flexibility (Unlimited PTO, Hybrid working policy*, Flexible working hours)

 - 👨‍👩‍👧 Family (Enhanced parental leave, Additional leave for child sickness)

*We embrace three days per week in-office (Tuesday and Thursday + 1 of your choice), with the option to request extra remote time.



Salary: €51,000 - €66,500 gross per annum

This range is set using objective, gender-neutral criteria for the role's core requirements. However, we do not believe in putting a ceiling on talent. The final compensation package is tailored according to your unique experience and expertise. If your skills go beyond the standard profile, apply anyway so we can discuss a package that reflects your true value.



Equal opportunity employer
At Satispay, we're proud to be an equal opportunity employer. We celebrate diversity and inclusion, welcoming individuals of all backgrounds. This opportunity is open to everyone, regardless - for instance - of race, colour, religion, sex, gender identity, sexual orientation, and national origin. 
Join us in a workplace where everyone belongs!



Learn more about us
Our values and pillars aren’t just fancy words on a page - they really shape everything we do. 
Explore them here https://www.satispay.com/en-it/work-at-satispay/.



#LI-VR1

#LI-Hybrid







By submitting this application, I acknowledge that I have read and understood the content of the Privacy Policy https://www.satispay.com/en-it/legal-hub/privacy-policy/candidates/
