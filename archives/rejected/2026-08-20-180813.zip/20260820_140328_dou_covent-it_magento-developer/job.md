# Magento Developer

Posted: 2026-08-18

## Rejection

- Category: tech_stack
- Reason: WordPress vacancies are ignored

About the project:
Type: **E-commerce**

- International platform, which provides tools for setting up an online store:
- A fully customized browsing experience;
- optimization of international checkout processes;
- handling all logistical aspects of cross-border selling;
- marketing strategy support.

We’re looking for a Senior/Middle full-stack developer with end-to-end experience developing web applications, and working in a complex, cloud-based environment.

**Responsibilities**
The job will include the development of new functionality for leading PHP-based e-commerce systems. Therefore, experience with developing extensions for leading PHP-based platforms (such as Magento, X-Cart, OpenCart, etc.) is a huge plus.

**Requirements**

- At least 3 years of proven experience developing end to end web applications using PHP / MySQL/;
- Hands-on experience and understanding of client-side technologies: JavaScript / Ajax/ JSON / HTML / CSS;
- Good experience with Linux;
- Strong understanding of HTTP protocol and Web technologies
- Firm understanding of systems integration concepts and API implementation (RESTful services)
- High-performance tuning and troubleshooting capabilities;
- Good level of English, high level of written and conversational skills;
- Strong communication skills with the ability to convey complex technical concepts to both technical and non-technical audiences

**Will be an advantage**

- Experience with developing and integrating Magento extensions— a huge
- advantage;
- Previous experience with B2B integrations — strong advantage;
- Any sort of big contribution to an open-source project online — an advantage;
- Experience with Tools (unit testing, logging, caching, packaging) — an advantage;
- WordPress(WooCommecre) — an advantage;

**Working conditions:**

- An 8-hour working day without a fixed timetable
- Paid vacation and sick leave
- English courses and international communication with specialists from the connected area
- Medical insurance
