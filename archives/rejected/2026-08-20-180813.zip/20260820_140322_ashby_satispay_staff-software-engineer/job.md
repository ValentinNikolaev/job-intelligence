# Staff Software Engineer

Posted: 2026-06-26T10:58:02.375+00:00

## Rejection

- Category: stale
- Reason: published_at 2026-06-26T10:58:02.375+00:00 is older than 7 days

About us 

Satispay began by rethinking the simple act of a payment to remove the friction from our daily routines. But we didn’t stop there. Today, we are building a complete financial platform designed to empower people and concretely improve their lives. By giving our 6 million users a clear, open path to pay, save, and invest, we are evolving into the definitive destination for every financial need.



What you'll be doing 

As our Staff Software Engineer, you’ll be the person who defines the long-term technical vision for one of our domains, architecting complex subsystems that power our features and leading efficient initiatives that directly empower millions of users to reach their financial goals. Here's what your day-to-day will look like:

 - Define Technical Strategy - You will architect complex subsystems that power our features, with cross-product considerations, leading efficient initiatives impacting multiple groups.

 - Advance the Architecture - Design and build scalable, high-quality systems that solve complex financial engineering problems, including managing and simplifying the most complex back-end systems.

 - Technical Thought Leadership - Build cross-organizational relationships to drive technical alignment, represent the technical vision externally and internally, and stay ahead of emerging technology trends in FinTech.

 - Develop Talent - Develop the next generation of technical leaders and champion a culture of high-quality engineering and continuous improvement.

 - Generate Impact - Play a vital role in helping users reach their financial goals through your contributions to the back-end infrastructure, directly contributing to Satispay's mission.

Our tech stack includes (but it’s not limited to) PostgreSQL, Java, Spring Boot. We rely on AWS for our infrastructure, with microservices deployed on EC2/ECS, S3 for storage, AWS Lambda for serverless functions, and Kinesis and ElasticSearch for log streaming. You'll take ownership of your work from start to finish.



Who we're looking for 

We need a visionary problem-solver, who excels in cross-team collaboration with deep expertise. Does this sound like you?

 - Extensive Experience - You have at least 7 years of related experience in back-end software engineering. You have a proven track record of architecting and maintaining microservices in a high-paced environment, building high-throughput systems capable of serving millions of users with high availability.

 - Tech Expertise - You possess a deep experience working with Java and a strong understanding of cloud platforms (AWS is a plus), capable of handling the most complex technical challenges.

 - Strategic Communication - You are able to communicate in a structured and convincing manner, adapting your style to build trust positively and professionally with various stakeholders, capable of building cross-organizational relationships for technical alignment.

 - Thought Leadership - You have a proven ability to generate intellectual property and thought leadership. You identify and capitalize on emerging technology trends, and act as a technical reference point for the team, providing guidance and expertise when needed.

 - Passion and Language Skills - You are passionate about FinTech or startup environments and fluent in English.

Don't worry if you don't tick every box. We believe in the power of different viewpoints and strengths. Your unique perspective is important as we build something special. If you're passionate and can make a difference, we truly encourage you to apply.

CareAbout: how we support your impact 

We move fast, and evolution never stops. It’s a fun ride, but it can be challenging. To make sure our people truly thrive, we’re committed to making their lives easier, both in the office and out in the world. That’s why we created CareAbout:

 - ❤️ Health (Private insurance and health coverage for you and your family, psychological support with Serenis, mental health workshops)

 - 💰 Financial resources (Stock Option Plan, Meal vouchers, Relocation support if you’re moving countries)

 - ⚙️ Growth and development (Professional development programs, Internal mobility, Language courses with Preply)

 - 🌱 Flexibility (Unlimited PTO, Hybrid working policy*, Flexible working hours)

 - 👨‍👩‍👧 Family (Enhanced parental leave, Additional leave for child sickness)

*We embrace three days per week in-office (Tuesday and Thursday + 1 of your choice), with the option to request extra remote time.



Salary: €64,000- €88,000 gross per annum
This range is set using objective, gender-neutral criteria for the role's core requirements. However, we do not believe in putting a ceiling on talent. The final compensation package is tailored according to your unique experience and expertise. If your skills go beyond the standard profile, apply anyway so we can discuss a package that reflects your true value.



Equal Opportunity Employer 

At Satispay, we're proud to be an equal opportunity employer. We celebrate diversity and inclusion, welcoming individuals of all backgrounds. This opportunity is open to everyone, regardless - for instance - of race, colour, religion, sex, gender identity, sexual orientation, and national origin. Join us in a workplace where everyone belongs!



Learn more about us 

Our values and pillars aren’t just fancy words on a page - they really shape everything we do. Explore them here https://www.satispay.com/en-it/work-at-satispay/.



#LI-VR1

#LI-Hybrid







By submitting this application, I acknowledge that I have read and understood the content of the Privacy Policy https://www.satispay.com/en-it/legal-hub/privacy-policy/candidates/
