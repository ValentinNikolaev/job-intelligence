# Backend Engineer, Core Technology

Posted: 2026-07-22T07:01:13Z

## Rejection

- Category: stale
- Reason: published_at 2026-07-22T07:01:13Z is older than 7 days

**Headquarters:** US-Remote, Chicago, Seattle, San Francisco

## Who we are

### About Stripe

Stripe is a financial infrastructure platform for businesses. Millions of companies—from the world's largest enterprises to the most ambitious startups—use Stripe to accept payments, grow their revenue, and accelerate new business opportunities. Our mission is to increase the GDP of the internet, and we have a staggering amount of work ahead. That means you have an unprecedented opportunity to put the global economy within everyone's reach while doing the most important work of your career.

### About the team

Stripe Infrastructure is responsible for the reliability, scale, performance, and cost of Stripe's systems and the productivity and sentiment of Stripe's people.

You may work on a wide variety of critical business areas including:

- Core Infrastructure—We're the home for Stripe's critical tier0 infrastructure systems (Compute, Networking, DocumentDB, Distributed Caching and High assurance engineering). We build the foundational platform for Stripe products and services to allow them to operate at scale. We drive reliability, availability, efficiency, and scalability of these systems.

- Developer Infrastructure—We're responsible for the productivity of all developers at Stripe. Ensure Stripe's engineers have a reliable, fast, and easy-to-use inner dev loop to maximize productivity while building everything from low-latency microservices to large-scale data pipelines and machine learning models.

- Data Infrastructure—We're responsible for offering data serving infrastructure spanning across data warehouse analytics, streaming analytics, and search capabilities. The stack is supported by a collection of internally developed large-scale distributed services and several popular open-source technologies like Trino/Presto, Apache Pinot, Hive Metastore, ElasticSearch etc. The systems we own support all of the data serving needs of high-scale services and thousands of individual Stripes across the company.

- Admin Platform—We empower Stripes to quickly build secure and delightful internal products in service of their users.

- Service Platform—We enable engineering teams at Stripe to easily write and ship useful services that correctly, reliably, and efficiently leverage platform capabilities.

- Developer Productivity AI—We're responsible for doubling Stripe's engineering velocity through effective use of LLMs. We own Minions, Stripe's one-shot, end-to-end coding agents.

Team matching—exact team matching for one of the subteams will begin during final stages. Please note we may also consider you for different orgs based on your experience, location, etc. Find more information on our team matching process [here](https://docs.google.com/document/d/1zvJkO2c7GzukHG-_oqc5wbOLajpuh5FjbmZPcZPU1o0/edit?tab=t.0#heading=h.x8j6mm75yuwr).

## What you'll do

You'll work on projects that span technologies, systems, and processes where you'll design, build, test, and ship great code every day.

### Responsibilities

- Build a great customer experience for internal and external Stripe teams using our infrastructure

- Participate in roadmap planning and prioritization

- Deliver value through a strong collaborative approach with multiple customers and stakeholders across Stripe

- Debug production issues across services and several levels of the stack

## Who you are

We're looking for someone who meets the minimum requirements to be considered for the role. If you meet these requirements, you are encouraged to apply. The preferred qualifications are a bonus, not a requirement.

### Minimum requirements

- Strong software engineering skills and a passion for one of the areas above

- Ability to write high-quality code (in programming languages like Go, Java, C/C++ etc.)

- 2–12+ years of professional hands-on software development experience, able to write well-factored algorithms and have experience with commonly used data structures and algorithms

- Hands-on experience contributing to or building large-scale distributed systems

- Strong collaboration skills, can work across workstreams within your team and contribute to your peers' success

- Customer obsession, ability to articulate and represent customer experience in various forums to drive the right outcome

- Have the ability to thrive on a high level of autonomy and responsibility, and think of yourself as entrepreneurial

### Preferred qualifications

- Experience optimizing the end-to-end performance of distributed systems

- Focus on the needs of our users, both internal and external

- Hold yourself and others to a high bar when working with production

**To apply:** [https://weworkremotely.com/remote-jobs/stripe-backend-engineer-core-technology](https://weworkremotely.com/remote-jobs/stripe-backend-engineer-core-technology)
