# Senior Software Engineer, Sandboxes (EU or East Coast Preferred)

Posted: 2026-08-12T15:44:37.684+00:00

## Rejection

- Category: stale
- Reason: published_at 2026-08-12T15:44:37.684+00:00 is older than 7 days

ABOUT DOCKER

Docker has been one of the most loved brands in developer tooling, trusted by more than 20 million monthly users and over 20 billion container image pulls. From solo founders to the world's largest companies, developers rely on Docker to build, share, and run their applications across our suite of products including Docker Desktop, Docker Hub, and Docker Scout.

We are a globally distributed, remote-first team building the tools that define how software gets built and delivered. As AI agents redefine software development, Docker is at the center of that shift, providing the sandboxed environments, verified images, and secure infrastructure that make autonomous workflows trustworthy by default.

_______________________________________________________________________



The Docker Sandboxes team is building the runtime that lets AI coding agents run safely on a developer's machine: disposable, isolated microVM sandboxes that each get their own Docker daemon, filesystem, and network. 

This is the core of Docker's sbx product: developers can give an agent the autonomy it needs to get real work done without it ever touching the host, and tear the whole environment down when it's finished.

The successful candidate is a technical, product-minded engineer with deep experience building secure, isolated runtime environments (sandboxes, containers, or VMs) and a track record of shipping and owning that kind of infrastructure in production at scale. They think naturally about isolation and security boundaries, understand the tradeoffs involved in running untrusted or semi-trusted workloads safely, and can reason confidently about a system that spans multiple surface areas.

They can drive clarity and consensus on hard, ambiguous problems that cross team and component boundaries, raise the bar for engineering quality wherever they work, thrive in a remote-first environment, communicate clearly across time zones, work with our users, while bringing curiosity and craftsmanship to hard problems.

Please note: this role is currently prioritizing candidates currently located in the Eastern time zone (US or Canada), or in the EU. 




RESPONSIBILITIES

 - Design, develop, and lead improvements to the sandboxes product across agent integration, tool permissions, and developer-facing workflows.

 - Investigate and resolve correctness, performance, and stability issues in the agent integration layer across macOS, Windows, and Linux.

 - Drive the reliability and performance of sandbox creation, session management, and teardown for AI agent workloads.

 - Collaborate with peers, Product, and adjacent teams to evolve the architecture as requirements grow.

 - Mentor engineers on the team and set the bar in design reviews and code reviews.

 - Engage with the open source and agentic development community around sandboxing, MCP, and related ecosystems.

 - Participate in on-call rotations and respond to critical stability issues affecting users.

 - Document your work clearly and share knowledge with the rest of the team.




QUALIFICATIONS

 - 8+ years of software engineering experience, with demonstrated technical leadership on production systems at scale.

 - Bachelor’s degree in Computer Science, Engineering, or a related field, or equivalent practical experience

 - Experience building developer tools, desktop applications, or runtime infrastructure used directly by developers.

 - Familiarity with the agentic software development ecosystem: how coding agents work and how tools like Claude Code, Codex, or similar agents interact with their environment.

 - Ability to reason about isolation and security boundaries: what a sandbox should and shouldn't expose, and how to make safe defaults obvious to users.

 - Experience driving architecture and technical strategy across multiple engineers or teams.

 - Strong written and verbal communication skills.

 - Comfortable working with a high degree of autonomy in a remote-first environment.




WHAT TO EXPECT


FIRST 30 DAYS

 - Build an understanding of our codebase.

 - Meet the people on your team and those adjacent to it.

 - Build an understanding of the products we are shipping and our near-term technical priorities.

 - Deliver small fixes or improvements.


FIRST 90 DAYS

 - Lead the design and development of a significant improvement or feature of the local sandboxes stack.

 - Engage with our open source project and the relevant upstream communities.

 - Shape the team's technical direction, and drive architecture discussions.


ONE YEAR OUTLOOK (FIRST YEAR)

 - Deliver measurable improvements to the correctness and performance of sandboxes.

 - Become a recognized technical owner of key parts of the codebase and a go-to technical leader for the local runtime.

 - Help us define the longer-term technical strategy for the filesystem layer in a way that fits with Product and Business goals, and rally the team behind it.



Docker considers visa sponsorship on a case-by-case basis based on business needs.



Compensation & Equity

EU: €94,040 – €155,650+ equity

United States: $160,900 – $260,700 + equity

______________________________________________________________________




POSTING INFORMATION

 - Open vacancy: This posting is for an existing open role.

 - AI in hiring: Docker may use AI-assisted tools during our recruiting process.

 - Interview recordings: Candidates will be invited to opt in to interview recordings to support interviewer calibration and consistent evaluations. Recordings are optional and require explicit consent.

______________________________________________________________________




PERKS & BENEFITS

 - Remote-first by design – Work from your home, with offices in Seattle and Paris for connection and collaboration.

 - Flexibility that fits your life – We trust you to manage your schedule while delivering great work.

 - Time to recharge – Generous PTO, designated quarterly Whaleness Days, and a designated end-of-year Whaleness break.

 - Home office support – Set up your workspace for comfort and success.

 - Technology stipend – Equivalent to US$100 net per month to help support your work.

 - Learning & development – Annual stipend for conferences, courses, certifications, and continued learning.

 - Parental leave – 16 weeks of paid parental leave after six months of employment.

 - Equity for all full-time employees – Share in Docker's long-term success as we continue to grow.

 - Comprehensive benefits – Medical, retirement, and paid holidays vary by country.

 - Docker swag – Because representing the whale never gets old.



Docker is proud to be an equal opportunity employer. We are committed to building a team that reflects a broad range of backgrounds, experiences, and perspectives. We believe diverse teams build better products, make better decisions, and better serve our global community.



#LI-REMOTE
