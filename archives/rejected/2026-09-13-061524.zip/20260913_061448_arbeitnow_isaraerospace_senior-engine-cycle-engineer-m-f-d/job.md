# Senior Engine Cycle Engineer (m/f/d)

Posted: 2026-09-12T17:55:16Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**Mission Brief **

You will own the engine cycle and the top level technical architecture of a pump fed liquid rocket engine. As the responsible engineer you translate mission and vehicle needs into an integrated engine design, establish the key performance trades, and make sure every major sub system converges on one coherent, testable and manufacturable solution.

Your Role in Our Space Mission:

- Build, maintain and validate engine cycle models across nominal, throttled and off nominal operating conditions, including start up and shutdown transients.

- Lead cycle trade studies and sensitivity analyses to optimise performance and identify design drivers, constraints and technical risks.

- Perform top level engine sizing and define the principal operating points and component interface conditions.

- Drive architecture and design trade offs across combustion devices, turbomachinery, valves, feed systems, ignition, controls, structures, thermal management and engine layout.

- Own the top level engine requirements, assumptions, interface definitions and technical budgets.

- Act as the technical decision driver for cross functional design issues, and keep decisions documented, traceable and backed by analysis and test evidence.

- Own the technical development roadmap and timeline: guide design iterations, prioritise maturation activities, and define the analyses, breadboards and tests that retire the highest risks.

- Coordinate technical reviews and give clear recommendations to Propulsion leadership and to the programme and vehicle teams.

**Qualification Checklist
**

- MSc in aerospace engineering, mechanical engineering or a comparable technical discipline, or equivalent professional experience.

- Several years in liquid rocket engine development, with real responsibility for engine cycle analysis, engine architecture or propulsion system integration.

- Hands on experience with high pressure, pump fed liquid rocket engine cycles: designing, analysing, developing or testing them.

- Excellent understanding of engine cycles, thermodynamics, fluid dynamics and turbomachinery power balance.

- Steady state cycle modelling, top level engine sizing and performance prediction.

- Experience planning and coordinating multidisciplinary engine development or test campaigns, and driving a technical roadmap to agreed timelines.

- Proficiency in Python, MATLAB or a comparable programming language.

- Strong technical ownership and systems thinking, and the confidence to decide with incomplete information.

- Fluent in English.

- Willingness to travel occasionally for test and launch operations.

Bonus Skills

- Experience with transient cycle modelling: start up, shutdown, throttling and off nominal conditions.

- Experience taking an engine design from cycle definition and system level trades into hardware and test.

- Experience analysing engine control, operability, stability or failure cases.

- Enough breadth across valves, feed systems, ignition, controls, structures and thermal management to arbitrate trade offs between those disciplines.

- Experience correlating models against hot fire test data.

**Benefits **

- **Employee Participation Program:** Share in our success through our virtual company share program

- **30 days of vacation: **Enjoy the days off to relax and recharge

- **Company pension plan:** Secure your future with our company pension plan, featuring a 20% employer contribution after the probation period

- **Subsidised lunch:** Stay energised with delicious, subsidised lunches every day

- **Public transport ticket:** Commute with ease using a fully financed Deutschlandticket

- **Rental clothing with laundry service:** Enjoy hassle-free workwear with our convenient rental clothing and laundry service

- **Sport Clubs membership:** Stay fit with our sponsored sports club memberships (EGYM Wellpass)

- **Individual learning allowance:** Grow your skills with an individual learning budget granted after the probation period

- **Childcare allowance:** Receive a childcare allowance for your non-school-age children

- **And Much More!** Discover additional perks and benefits when you join our team.

**Who we are**

****

We are Isar Aerospace and we are at the forefront of New Space building a modern space business to enable faster, better and cheaper access to space.

Our mission is to help democratise space and use it for good in order to improve life on Earth now and for the future generations.

We are a fast-growing company aiming to provide sustainable and environmentally friendly launch solutions for small and medium-sized satellites and constellations into Low Earth Orbit. The company is privately funded by world-leading technology investors with strong commitment and support and our team is made of driven and talented people with a real passion for space innovation.

We're making rockets in a way that hasn't been done before disrupting a traditional industry. If you are up for the challenge, want to work on cutting-edge projects and be part of a team changing the world for better, come, join us and launch your career!

Want to find out more about us?

Visit [www.isaraerospace.com](http://www.isaraerospace.com/)

**Data Protection
**We process your personal data for the purpose of managing the recruitment process and assessing your application. For detailed information on how your data is processed, including your rights, please refer to our [Privacy Policy](https://isaraerospace.com/privacy-policy).

**Disclaimer
**Isar Aerospace SE is an equal-opportunity employer committed to fairness and inclusivity. We do not prioritize any specific religion, gender, nationality, or background. Due to security clearance requirements, affiliations with countries listed under § 13 para. 1 no. 17 SÜG may affect the application process. All qualified applicants are encouraged to apply.

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
