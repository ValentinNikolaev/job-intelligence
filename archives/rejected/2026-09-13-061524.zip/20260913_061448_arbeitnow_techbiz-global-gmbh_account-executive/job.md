# Account Executive

Posted: 2026-09-12T23:30:26Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

At TechBiz Global, we are providing recruitment service to our TOP clients from our portfolio. We are currently looking for a Account Executive to join one of our clients' team.

To further drive this growth, we are looking for a Full-Cycle Account Executive (m/f/d) who will be responsible for the entire sales process – from initial contact and consultation to successful closing – and take our sales to the next level 🚀

-

You already have initial experience as an Account Executive - ideally in the B2B SaaS environment.

-

Ideally, you have already worked with HubSpot – but more important to us is that you use comparable CRM systems securely and maintain them properly.

-

You are characterized by a structured and organized way of working.

-

You speak German at a native speaker level and English at a B2 level.

-

You are career-driven and motivated to take on responsibility.

-

You are a real team player.

**Tasks**

-

You are responsible for the entire sales process – from the initial contact to the closing.

-

You conduct compelling product demos and consultations with qualified and self-generated leads.

-

You actively build your pipeline , develop it strategically, and keep it clean in HubSpot.

-

You work closely with Customer Success and Product , and directly incorporate customer feedback into positioning and product development.

-

You know your sales KPIs , control your funnel based on data, and continuously optimize your conversion output.

-

You actively contribute to the further development of our sales playbooks and processes.

Benefits

-

Clear development roadmap

-

Employee benefits such as Wellhub or Deutschland-Ticket

-

Yearly Company Offsite

-

Weekly Team Breakfast & Bi-Weekly Lunch

-

Regular team events

-

Cool office in Berlin with ping pong & darts

-

An ambitious, friendly, and honest team

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
