# Product Engineer (Full-Stack)

Posted: 2026-09-12T20:32:45Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**Our mission**

Bounti is building the AI-native infrastructure layer for frontline teams, spanning training, audits, and autonomous operations. We partner with multi-location operators in frontline industries such as hospitality.

We're hiring a **Product Engineer** to join our product team in Berlin. This is a hands-on role for someone who wants to work across the whole product: the mobile app, the web app, and the API behind them. You'll ship to customers in your first week and be trusted with features end to end well before your first year.

**What you'll do**

- **Build and ship features across the app and the backend.** Our mobile app is React Native, the web app is Next.js, and the API is Node and Postgres. You'll touch all of it.
- **Work independently once you're ramped.** You'll take features from spec through to release without close supervision, and stay with them after they ship.
- **Fix what customers report.** Bugs and customer-reported issues sit with the team that built the feature, and that includes you.
- **Build internal tooling** that empowers the sales and support teams to answer their own questions.
- **Talk to the people using what you build.** You'll have direct access to operators and frontline users, and we expect you to use it.

**Your profile**

- You have **around two to five years of professional experience** building and shipping web or mobile products. What matters is what you've shipped, not the number.
- You have **product sense**: you care about UX, clarity, and the details that make software feel right, and you bring ideas forward rather than waiting to be handed a ticket.
- You are **comfortable across the stack**, or comfortable on one side and genuinely curious about the other. We don't split frontend and backend here.
- You **ask questions early**. On a team this size, saying you're stuck is more useful than working around it quietly.
- You **work with agents and stay accountable for the output**. We build with Claude Code and Cursor daily, and we care that you can tell good output from plausible output and explain why the code does what it does.
- You have **experience with our stack**, or you're willing to learn it: TypeScript, React, Next.js, React Native, Node.js, Postgres, Prisma.
**Bonus points if you have:**

- Built AI product features (LLMs, agents, workflows, evaluation)
- Mobile experience, particularly React Native or Expo
- Worked somewhere small enough that you saw features go from idea to customer
You'll work extremely closely with:

- Emanuele (VP of Engineering)
- Feng, Çağatay (Senior Product Engineers)
- Yannick (Product Engineer)
- Ziar (Designer and Co-Founder)
...and often with **Deniz** (Co-Founder), who brings constant customer perspective.
This is a small, high-trust team. Low ego, high standards, lots of shipping.

**Why us?**

- **Grow fast, with support:** you'll work directly alongside senior engineers who review your code and expect you to review theirs.
- **Real societal impact:** we're building for the 80% of the workforce that doesn't sit at a desk, and software has ignored them for too long.
- **Design-focused culture:** craft matters here. You'll build software you're proud to show.
- **Customer obsession:** we build what serves operators and frontline teams, not engineering for engineering's sake.
- **Backed by exceptional investors:** top-tier VCs and investors including the founders of Framer and Indeed.
- **Berlin setup:** great office location, top equipment, 30 days holiday, impact from day 0.
We embrace diversity and hire people based on their ability to perform a job. People of any race, gender, gender expression, sexual orientation, religion, age, disability, political opinion, or marital status are welcome at Bounti.

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
