# Senior Director IT (f/m/d)

Posted: 2026-09-12T20:40:08Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**About us**

We see the semiconductor industry as a realm of possibility. We see opportunity. We see the profound impact that our graphene solutions will have in transforming the industry. We invite you to join us in driving change with our fundamentally human-centered approach, uniting bright minds around a shared vision. The vision is: Prove to everybody that you can make a fundamental change. Prove with your knowledge and skills how things can be done differently. Together, we can change the paradigm of how the world connects

**About our technology**

The semiconductor industry’s growing demand for more powerful chips with higher bandwidth and lower power finds its solution in our technology. We connect chips to high-throughput, low-delay computing networks. The key lies in harnessing the physical properties of graphene to combine electronic computing with photonic communication, allowing countless chips to interact almost as if they were one. Our graphene photonic innovation increases computing power and efficiency to a new order of magnitude

**In short,** we connect chips to create powerful and energy-efficient networks, overcoming connectivity limitations in the semiconductor industry. We deliver the graphene solution

**The Role**

We are looking for an experienced and visionary **Senior Director IT** to build and lead our IT organization and technology foundation as we enter an exciting phase of growth.

This is a broad leadership role with responsibility for **enterprise IT, engineering IT, cybersecurity, data, AI, architecture, and technology governance**. As a member of the Senior Leadership Team, you will work closely with the CFO, CTO, Engineering, and Fab-IT leadership to ensure technology is a strategic enabler of the business.

**To join our team, you should be excited to:**

-

Define and execute the company-wide **IT and technology strategy**, ensuring a scalable, secure, and modern technology landscape.

-

Own core enterprise IT capabilities including **workplace, identity & access, networks, cloud/infrastructure, and business applications**.

-

Lead the IT environments supporting **Engineering**, including laboratory IT, EDA environments, and technical connectivity with OT and external partners.

-

Establish the technical **cybersecurity and data protection** capabilities in close collaboration with the CISO/ISMS, DPO, and Audit functions.

-

Build the company's **enterprise architecture, technology portfolio, and vendor governance** frameworks.

-

Develop the **data and AI foundation**, including AI platforms, governance, and high-impact AI use cases across the business and engineering organization.

-

Build and scale the IT organization, including **hiring key leaders, establishing the operating model, and developing high-performing teams**.

-

Establish strong operational processes, governance, and service standards that can support rapid company growth.

-

Act as a strategic technology partner to senior leadership and ensure close collaboration with Engineering and Fab-IT.

**Your Qualifications**

-

Proven senior leadership experience in **IT, technology, or digital organizations**, ideally in a high-tech, engineering-driven, or semiconductor environment.

-

Experience leading broad IT landscapes and building organizations and capabilities in a **high-growth or greenfield environment**.

-

Strong understanding of enterprise IT, cloud, infrastructure, cybersecurity, data, and modern technology architectures.

-

Experience with **AI strategy, data platforms, or digital transformation** is highly valued.

-

Strong strategic thinking combined with a **hands-on, pragmatic, and execution-oriented mindset**.

-

Excellent leadership and stakeholder management skills, with the ability to work effectively with both technical experts and executive leadership.

-

A strong track record of **building teams, driving transformation, and creating scalable technology organizations**.

This is a unique opportunity to **shape the IT organization and technology foundation of a growing, technology-intensive company** and to play a key role in enabling its next phase of growth.

**Our work culture**

**People Over Processes.** At Black Semiconductor, flexibility is key—we ensure work adapts to life, not the other way around. We champion work-life harmony, where careers are meaningful and enriching. Our processes are human-centric, allowing you to focus on what matters

**Let’s grow together.** Your potential is our priority. We provide the autonomy to make a lasting impact and nurture your growth through a culture of continuous learning. We invest in your journey for professional and personal development

**Your Health and Future Matter.** Your well-being is paramount. We offer a comprehensive benefits package with outstanding insurance, pension and virtual stock options for your mental, physical, and financial health. Your peace of mind is our priority - in the present and future

**We Live Openness.** Collaboration and inclusivity are the cornerstones of our culture. We practice openness, fostering trust and respect. Individuality is our collective strength, fueling innovation and driving us forward

**We connect chips – and people.** We encourage qualified individuals from any background to apply. We foster an inclusive and supportive work environment that values collaboration, innovation, and growth. Join our team and be part of an organization dedicated to making a difference in the industry

**Can you picture yourself in this Role and our Company? Let’s connect!**

*If your application results in an employment relationship, your Applicant Data will be transferred to our personnel records and processed in accordance with applicable legal requirements; otherwise, your Applicant Data will be retained for up to six (6) months after completion of the recruitment process. *[*Read more about our privacy policy here. *](https://www.blacksemi.com/privacy-policy)

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
