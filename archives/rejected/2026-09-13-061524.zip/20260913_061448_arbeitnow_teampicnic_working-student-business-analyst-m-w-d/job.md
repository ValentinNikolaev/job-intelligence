# Working Student - Business Analyst (m/w/d)

Posted: 2026-09-12T17:55:10Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

## Kurz und knapp** **

Als Business Analyst Werkstudent:in bei Picnic bist du an vorderster Front der Innovation und stellst dich komplexen Herausforderungen mit bahnbrechenden Lösungen. Diese Rolle dreht sich um Innovation – du analysierst Daten, deckst Wachstumspotenziale auf und entwickelst strategische Lösungen, die unser Geschäftsmodell vorantreiben, Grenzen verschieben und das Einkaufserlebnis neu denken. Du wirst Teil eines dynamischen und kooperativen Teams in einem schnelllebigen, innovativen Umfeld.

## Das erwartet dich

-

**Von Daten zu Business-Insights**: Arbeite an echten Business Cases, analysiere datenbasierte Fragestellungen und gestalte unser Geschäftsmodell aktiv mit. Bereit, echten Impact zu schaffen?

-

**Ermögliche**: Erreiche operative Exzellenz, indem du Herausforderungen mit einem datengetriebenen und analytischen Ansatz meisterst

-

**Entwickle**: Erstelle und optimiere Modelle für Verbesserungen in Echtzeit

-

**Kommuniziere**: Arbeite effektiv mit verschiedenen Teams zusammen, um wirkungsvolle und nachhaltige Lösungen zu liefern

-

**Übernimm Verantwortung**: Zeige Initiative, indem du den Status quo in Frage stellst und Prozesse neu denkst. Nur weil es immer so gemacht wurde, heißt das nicht, dass es der beste Weg ist. Probier’s aus!

## In welchen Bereichen kannst du deine Power zeigen?

Von tag eins wirst du in einem dieser Bereiche anfangen, um dort deiner Kreativität beim Prbleme lösen freien lauf zu lassen:

- **Consumer** - Treibe unser Wachstum durch Preisgestaltung, Lieferantenstrategie und unsere Marktstrategie voran. Konkret? Zum Beispiel das Gestalten unseres Markteintritt in neue Städte. Deine Entscheidungen prägen, wie Millionen von Kunden Picnic erleben.

- **Logistics **- Baue Picnics Logistik Puzzle auf und aus. Was kannst du dir darunter vorstellen? Robotergestützte Abwicklung, Nachfrageprognosen, Routenoptimierung in ganz Europa und vieles mehr.

Teil des Recruitingprozesses ist es, dich einem dieser Bereiche zuzuordnen.

## Das bringst du mit

- **Masterstudium **in einem quantitativen Feld (z.B. Wirtschaftsingenieurwesen, Engineering, Technology & Management, Business Analytics, oder Ähnliches)

- Erfahrung in schnelllebigen und dynamischen Umgebungen

- Projekte im Bereich Datenanalyse durchgeführt

- Erfahrung in der Unternehmensberatung gesammelt (großes Plus)

- Du kannst komplexe analytische Konzepte verständlich für verschiedene Stakeholder erklären

- Kommunikationsfähigkeiten, die abstrakte Pläne in greifbare Informationen umwandeln

- Sprichst fließend Englisch; Deutschkenntnisse sind ein Plus

- Sicher im Umgang mit SQL und Python oder motiviert, es zu lernen

- Mindestens 16 Stunden pro Woche für mindestens 4 Monate verfügbar

➡ Bitte reiche deine Bewerbung auf **Englisch **ein, da unser Recruiting-Prozess auf Englisch stattfindet

Abhängig von deiner Performance können wir über weitere (Vollzeit) Möglichkeiten bei Picnic sprechen!

## Darauf kannst du dich freuen

**💰Attraktives Paket
**Wir bieten ein attraktives Gehalt von 15,50 € pro Stunde (Master) und sammelst spannende Praxiserfahrung.

**🚀Jeder Experte war einmal ein Anfänger!**
Du wirst viele Gelegenheiten haben, dich selbst herauszufordern und zu wachsen, darunter die Picnic Tech Academy, Lunch & Learn-Sessions und maßgeschneiderte Soft-Skills-Trainings. Wir bieten auch kostenlose wöchentliche professionelle Sprachkurse an.

**🌍Mach einen Unterschied****
**Du wirst in einer großartigen Startup-Umgebung arbeiten, mit der Freiheit, eigene Projekte voranzutreiben und sichtbare Erfolge zu erzielen. Mit unseren vollelektrischen Fahrzeugen und unserem nachhaltigen Geschäftsmodell trägst du auch dazu bei, die Welt zu einem besseren Ort zu machen!

**🤝Teamwork makes the dream work****
**Mit mehr als 80 Nationalitäten in 3 Ländern bist du Teil eines vielfältigen Unternehmens, mit vielen coolen Aktivitäten, bei denen du mitmachen kannst – von Spieleabenden über After-Work-Drinks bis hin zu unserem Firmenskitrip und mehr!

**🥗Frisches Mittagessen, Kaffee und Snacks****
**In unseren Büros erwartet dich jeden Tag ein frisches Mittagessen sowie eine Auswahl an Snacks und Kaffee, um dein Energielevel aufrechtzuerhalten.

**💪Bleib gesund****
**Mentale Gesundheit ist wichtig. Neben der Möglichkeit, mit Picnic-Kolleg:innen zu sprechen, die als vertrauliche Berater:innen fungieren, gibt dir unsere Zusammenarbeit mit OpenUp einfachen Zugang zu professionellen Psycholog:innen sowie zu Workshops und Materialien.
Es gibt viele Sportgemeinschaften und Veranstaltungen, bei denen du mitmachen kannst – von Beachvolleyball über Yoga bis hin zum Klettern!

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
