# Corporate Security Engineer

Posted: 2026-09-12T23:40:09Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

*Superhuman offers a dynamic hybrid working model for this role. This flexible approach gives team members the best of both worlds: plenty of focus time along with in-person collaboration that helps foster trust, innovation, and a strong team culture.*

# About Superhuman

Grammarly is now part of Superhuman, the AI productivity platform on a mission to unlock the superhuman potential in everyone. The Superhuman suite of apps and agents brings AI wherever people work, integrating with over 1 million applications and websites. The company’s products include Grammarly’s writing assistance, Superhuman Docs’ collaborative workspaces, Mail’s inbox management, and Go, the proactive AI assistant that understands context and delivers help automatically. Founded in 2009, Superhuman empowers over 40 million people, 50,000 organizations, and 3,000 educational institutions worldwide to eliminate busywork and focus on what matters. Learn more at [superhuman.com](http://superhuman.com).

# The Opportunity

Superhuman is on a mission to build the fastest, most delightful productivity experiences powered by AI. As we scale rapidly, our internal technology operations must evolve to match our ambition.

We’re looking for a Security Engineer to join our Corporate Technology team. Our commitment to user trust is unwavering, and this new team member will play a crucial role in protecting Superhuman’s corporate environment and the infrastructure that millions of users depend on. Working closely with the Corporate Infrastructure team, you will harden and secure the systems our employees rely on every day, Identity and Access Management, Endpoint Management, SaaS platforms, and Networking, while ensuring that security enables speed rather than slowing it down.

This is an opportunity to build and maintain critical security programs, including Insider Risk, Threat and Vulnerability Management, and Third-Party Risk. You’ll leverage AI to build smarter security controls and processes, and help define how AI itself is secured across our corporate infrastructure. Your work will empower employees to move fast while maintaining a high bar for corporate security.

In this role, you will:

-

Design, build, and maintain corporate security controls that enable employees to move fast with confidence, making the secure path the easiest path.

-

Develop security standards, guidelines, and policies in collaboration with the Governance, Risk, and Compliance (GRC) team.

-

Leverage AI to build and scale security controls, automate security processes, and accelerate threat detection and response across our corporate infrastructure.

-

Define and implement AI security standards for the corporate environment, ensuring employees can safely adopt AI-powered tools and workflows.

-

Perform risk assessments and security assurance on systems that support Superhuman’s business operations: IdP, operating systems, desktop applications, SaaS solutions, and network infrastructure (ZTNA, CASB, VPN).

-

Lead the design and execution of a corporate Zero Trust architecture, working across identity, endpoint, and network security.

-

Drive the remediation of security vulnerabilities identified through assessments.

-

Evaluate and implement cutting-edge enterprise security technology to continuously strengthen our security posture.

# Qualifications

-

Has 6+ years of experience working on a Security team in corporate security, enterprise security, or a related domain for a SaaS company.

-

Expert-level understanding and experience in at least two corporate security domains: Identity and Access Management, Endpoint Management, SaaS platforms, and Networking.

-

Strong experience with data protection technologies (DSPM, discovery, masking, access controls, DLP, backup).

-

Strong experience with assessing the configuration of common SaaS applications (SSPM), such as Salesforce, Workday, Coupa.

-

Strong experience with both MacOS and Windows endpoint security.

-

Familiarity with AI security principles and practical knowledge of how to secure AI adoption in a corporate environment.

-

Demonstrated experience using AI to build security controls, automate security processes, or scale security operations.

-

Ability to assess risk in ambiguous situations and make balanced security decisions that consider both offensive and defensive perspectives.

-

Strong communication skills with the ability to influence stakeholders and manage up effectively.

-

A mindset that security should enable speed, experience designing controls that protect without creating unnecessary friction.

# Support for you, professionally and personally

-

*Professional Growth:* We believe that autonomy and trust are key to empowering our team members to do their best, most innovative work in a way that aligns with their interests, talents, and well-being

-

*A connected team:* Superhuman builds a product that helps people connect, and we apply this mindset to our own team. Our remote-first, hybrid model enables a highly collaborative culture rooted in our values. We work to foster belonging among team members in a variety of ways. This includes our team member resource groups, Superhuman Circles, which promote connection among those with shared identities including BIPOC and LGBTQIA+ team members, women, and parents. We also celebrate our colleagues and accomplishments with global, local, and team-specific programs.

-

*Comprehensive benefits for candidates based in Germany: *Superhuman offers all team members competitive pay along with a benefits package encompassing life care (including mental health care and risk benefits) and ample and defined time off. We also offer support to set up a home office, wellness and pet care stipends, learning and development opportunities, and more.

-

*Relocation Support: *Superhuman provides relocation support to make your move to Berlin seamless. Our package includes visa assistance, destination services to help you and your family settle in comfortably, and a relocation bonus to cover additional expenses, such as temporary housing.

# We encourage you to apply

At Superhuman, we value our differences, and we encourage all—especially those whose identities are traditionally underrepresented in tech organizations—to apply. Superhuman is an equal opportunity company. We do not discriminate on the basis of race or ethnic origin, religion or belief, color, gender expression or identity, sexual orientation, sexual identity, national origin, citizenship, age, marital status, veteran status, disability status, criminal prosecution, judgment in a criminal case, or any other characteristic protected by law.

For more details about the personal data Superhuman collects during the recruitment process, for what purposes, and how you can address your rights, please see the Superhuman Data Privacy Notice for Candidates [here](https://superhuman.com/media-resources/candidate-data-privacy).

Compensation: €125K – €170K

- • €125K – €170K

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
