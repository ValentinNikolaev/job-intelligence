# Commercial & Analytics Projects - Mid-Level (m/w/d)

Posted: 2026-09-12T17:55:09Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

*Only about 1% of our applicants end up in the offer stage. To increase your chances, give yourself a competitive edge and come fully prepared!*

## In a nutshell

As we are building the best milkman on earth, we are looking for sharp minds that can help us further shape Picnic as we expand across Europe. We are looking for experienced hires with a background in top strategy consulting, private equity, investment banking, e-commerce or commercial roles, that can help us capitalize on the many growth opportunities Picnic has.

## **Tricks of the trade**

- **Lead with ambition**: Bring your relentless determination, creativity, and grit. Take the driver’s seat and redefine the grocery shopping experience for millions. You will be expected to think independently, move fast, and deliver results.

- **Steep learning curve**: Your growth comes from owning real problems, testing your ideas, learning from your mistakes and starting again. You'll move at a pace that accelerates your growth like nowhere else.

- **Solve real-life puzzles**: Spot opportunities, use tools at the forefront of technology, and own the outcome end to end. Not just making slides, but building the solution yourself.

- **Innovate across borders**: You’ll collaborate with teams across the Netherlands, Germany, and France, tackling challenges that redefine how Picnic operates at a European scale.

- **High-performance environment**: You’ll work alongside some of the best teams in analytics and tech, people who set a high bar and expect you to do the same.

## Your superpowers

- Master’s degree in Econometrics, Engineering, Finance, Math or an equivalent quantitative study

- 2-5 years of work experience in top tier management consulting, PE, investment banking, retail topics and hands-on deal experience

- Out-of-the-box thinking and initiative: hands-on, nothing-is-impossible mindset

- Strong communication skills in German and English, allowing you to explain complex analytical concepts in a simple and practical way

- Proficient with SQL and Python or excited to learn

## **Picnic Perks **

🏆 **Rewarding Impact from Day One**

You’ll receive an attractive compensation package, designed to reward your ambition, drive, and the direct impact you’ll make from your very first project.

**🍎Learning & development **

You'll always have something to learn with us! You’ll benefit from opportunities like Lepaya training for polishing soft skills or Picnic Tech Academy training in case you want to learn new skills other than what you already know. We also offer free access to trained psychologists via our OpenUp partner, and German language classes if you’d like to get your experience in Germany to the next level.

**🗺️Relocation**

If you’re moving from another country to join Picnic we make it as smooth as possible for you. We’ll cover your flight costs and a first month's accommodation.

**🥗Fresh Lunch, coffee, and snacks **

Our offices are equipped with fully-fledged coffee bars and a kitchen. We get delicious fresh and warm lunches every day so you can keep your energy up.

**⛳All the rest **

At Picnic you get 30 holidays, we cover your travel expenses and offer a pension plan. And your phone and laptop are on us, of course.

## FAQ

**Which team will I join?**

At Picnic, we build almost everything in-house. This means that we have plenty of opportunities for you in terms of project topics. Your interest lies in consumer topics like pricing, assortment, customer life time value? Or rather in logistics, supply chain, automated warehousing areas? Or you'd love going adventurous into new areas as long as you're solving real world problems? Let's talk and figure it out where there's the best match.

**What are the long term opportunities for this role? What happens after I'm done with a project?**

You get full accountability from the start: from shaping the strategy and driving step-change improvements, to collaborating with multiple teams to achieve tangible business results.

At Picnic, the long-term opportunity isn't just a role—it’s a platform to shape your own career trajectory with real ownership, business impact, and fast growth. Hence the career paths are as diverse as your ambitions. Depending on your interests and strengths, these are most common career paths we’ve seen so far:

- Given our scale-up environment, many projects tend to grow in scope and complexity under your responsibility and you naturally grow a team around you in order to take your project to a next level.

- As you grow, you’ll deepen your understanding of the business, build a strong internal network, and prove your ability to lead impactful projects. Once you feel you’ve learned everything in your scope and your projects have been successfully implemented, you can switch to complete different areas of Picnic. We have numerous colleagues that have switched from Commercial to Fulfillment, or from Distribution to Customer and many other examples.

**In what language should I apply?**

Please send your application in English.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
