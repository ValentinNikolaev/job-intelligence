# Backend Engineer - Senior

Posted: 2026-09-12T20:32:45Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**Our mission**

Bounti is building the AI-native infrastructure layer for frontline teams, spanning training, audits, and autonomous operations. We partner with multi-location operators in frontline industries such as hospitality.
Behind the product sits a backend that has grown quickly: a Node and Postgres API, background workers, queues, and the AI pipelines powering our product. We're hiring a **Senior Backend Engineer** to own that layer as we scale it.

**What you'll do**

- **Own the backend behind the product:** API design, data modelling, query performance, and the decisions that get harder to reverse the longer we leave them.
- **Run everything asynchronous:** queues, background jobs, scheduled work, and the retry and failure behaviour that keeps a short outage from becoming a long one.
- **Own the AI pipelines:** the ones running today and the next set of features we build on top of them, including versioned prompts, evaluation, cost and latency budgets, and graceful behaviour when a model provider has a bad day.
- **Move data where it needs to go:** reporting and analytics pipelines that give operators a trustworthy picture across dozens of locations.
- **Connect Bounti to the systems customers already run:** POS, scheduling, payroll, and whatever comes next. Build a shared layer rather than one-off connectors, so each new partner costs less than the last.
- **Make failure visible and recoverable:** idempotency, reconciliation, per-customer alerting, and drift detection when a partner API misreports state.
- **Own the partner relationship on the technical side:** sandbox access, certification programmes, API reviews.
- **Build internal tooling** that empowers the CS team to diagnose failed syncs and enable integrations.

**Your profile**

- You have **built and operated production backend systems** and stayed around long enough to live with your decisions.
- You **think in partial failure and eventual consistency by default**. Retries, idempotency, and reconciliation are your starting assumptions, not things you add after the first incident.
- You have **worked against APIs you did not control**, and you can tell specific stories about what went wrong.
- You are **patient with vendors**, whether that is a POS company or a model provider. A real part of this job happens on someone else's timeline.
- You **work with agents and stay accountable for the output**. We build with Claude Code and Cursor daily. Generating code is the easy part, and we care that you can tell good output from plausible output, and that what lands in the repo is coherent and maintainable regardless of who or what wrote it.
- You are **pragmatic about scope**: you know which abstraction is worth building now and which one is speculative.
- Experience with our stack is a plus: **TypeScript, Node.js, Postgres, Prisma, Kubernetes**.
**Bonus points if you have:**

- Run LLM features in production, including evaluation and cost control
- Built observability for systems you did not fully control
- Worked through a partner certification or app review process end to end
- Experience in hospitality, retail, or workforce tooling
You'll work extremely closely with:

- Emanuele (VP of Engineering)
- Dilan (VP of Customer Success)
- Feng, Çağatay (Senior Product Engineers)
- Yannick (Product Engineer)
This is a small, high-trust team. Low ego, high standards, lots of shipping.

**Why us?**

- **Real ownership:** this is a capability nobody owns today. You define what it becomes.
- **Real societal impact:** we're building for the 80% of the workforce that doesn't sit at a desk, and software has ignored them for too long.
- **Customer obsession:** we build what serves operators and frontline teams, not engineering for engineering's sake.
- **Backed by exceptional investors:** top-tier VCs and investors including the founders of Framer and Indeed.
- **Berlin setup:** great office location, top equipment, 30 days holiday, impact from day 0.
We embrace diversity and hire people based on their ability to perform a job. People of any race, gender, gender expression, sexual orientation, religion, age, disability, political opinion, or marital status are welcome at Bounti.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
