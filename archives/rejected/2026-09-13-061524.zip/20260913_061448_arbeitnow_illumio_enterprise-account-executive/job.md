# Enterprise Account Executive

Posted: 2026-09-12T20:40:07Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

## Onwards Together!

Illumio is the leader in ransomware and breach containment, redefining how organizations contain cyberattacks and enable operational resilience. Powered by the Illumio AI Security Graph, our breach containment platform identifies and contains threats across hybrid multi-cloud environments – stopping the spread of attacks before they become disasters.

Recognized as a Leader in the Forrester Wave™ for Microsegmentation, Illumio enables Zero Trust, strengthening cyber resilience for the infrastructure, systems, and organizations that keep the world running.

## Location: Germany (Remote)

**Our Team's Vision:**

Illumio’s Sales team is building the next chapter of cybersecurity by helping organizations contain breaches, stop lateral movement, and build cyber resilience across hybrid, cloud, endpoint, and critical environments. We partner with some of the world’s most complex enterprises to connect Illumio’s breach containment platform to measurable business outcomes—from ransomware containment and Zero Trust Segmentation to application visibility, cloud modernization, and resilience in the AI era.

By joining our high-growth Sales organization, you will work alongside driven, collaborative professionals who are passionate about helping customers reduce cyber risk and protect what matters most. Our team brings curiosity, accountability, and executive-level storytelling to every customer conversation, helping organizations understand their environments, prioritize risk, and take action before attacks become cyber disasters. If you are motivated by meaningful customer impact, continuous growth, and the opportunity to help define the future of breach containment, Illumio is the place to build your next chapter.

## **Your Impact:**

-

Serve as an Enterprise Account Executive in the Illumio field organization, finding and creating new sales opportunities within our target accounts and leading a virtual team of Illumio people and external partners to win those opportunities

-

Create and execute a territory plan on your target accounts and approach to “landing and expanding," and prospect into these target accounts with the goal of engaging potential champions and sponsors to find and create an opportunity

-

Able to drive a regional sales plan that incorporates tight collaboration between ADRs, partner account managers, customer success advisors and extended field team resources

-

Accurately forecast the business objectives of your clients and Illumio

-

Identify, engage, and build relationships with resellers, system integrators and other partners

## **Your Toolkit:**

-

8+ years of full cycle sales enterprise selling with strong background in security and or networking software, including 5+ years of co-selling experience with a strong partner network

-

Deliver compelling “teaching conversations” that are well tailored to each prospect’s situation

-

Able to engage with urgency and capitalizing on all potential channels to sell Illumio

-

Knows how to ask the right questions, strong listener and technically savvy to understand the solution

-

Successful track record of successful selling to the C-suite (all lines of business) with a strong rolodex of contacts in region

-

Experience in a fast-paced company with the ability to adapt as needed

#LI-SL1 #LI-REMOTE

##

**Our Commitment**

Illumio believes that an environment of unique backgrounds, experiences, viewpoints, and individual contributions creates a culture of belonging, drives our future, and makes us stronger together in support of our customers and their success.

*All official job offers from our company are extended directly by our recruitment team and will be sent through an official E-Signature document for your review and signature. Please be aware that we do not ask for any personal information in the process of extending offers of employment, such as financial details or social security numbers. Upon acceptance of any offer, we will request such information as part of the onboarding process prior to or on your first day of employment, and only after completing a background check through an authorized third-party vendor. If you receive any communication asking for personal details outside of these processes, please contact us immediately to verify the authenticity of the request. Your security is important to us, and we are committed to a safe and transparent hiring experience.*

*For roles in San Francisco and Los Angeles: Pursuant to the San Francisco Fair Chance Ordinance and the Los Angeles Fair Chance Initiative for Hiring, Illumio will consider for employment qualified applicants with arrest and conviction records.*

Compensation: €96K – €120K • Offers Equity • Offers Commission

- • Estimated Base Salary €96K – €120K • Offers Equity • Offers Commission

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
