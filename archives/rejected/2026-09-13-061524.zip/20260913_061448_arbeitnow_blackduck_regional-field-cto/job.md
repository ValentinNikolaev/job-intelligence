# Regional Field CTO

Posted: 2026-09-12T17:55:08Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Black Duck Software, Inc. helps organizations build secure, high-quality software, minimizing risks while maximizing speed and productivity. Black Duck, a recognized pioneer in application security, provides SAST, SCA, and DAST solutions that enable teams to quickly find and fix vulnerabilities and defects in proprietary code, open source components, and application behavior. With a combination of industry-leading tools, services, and expertise, only Black Duck helps organizations maximize security and quality in DevSecOps and throughout the software development life cycle.

**Regional Field Chief Technology Officer**

**Location: EMEA, Remote (Black Duck has entities in UK, Germany, Netherlands, France, Italy, Ireland, Finland, Sweden)**

Black Duck® meets the board-level risks of modern software with True Scale Application Security, ensuring uncompromised trust in software for the regulated, AI-powered world. Only Black Duck solutions free organizations from tradeoffs between speed, accuracy, and compliance at scale while eliminating security, regulatory, and licensing risks. Whether in the cloud or on premises, Black Duck is the only choice for securing mission-critical software everywhere code happens. With Black Duck, security leaders can make smarter decisions and unleash business innovation with confidence.

We are looking for a Regional Field Chief Technology Officer to serve as a senior technical executive, trusted advisor, and public voice of our technology strategy in the market. In this role, the Regional Field CTO will operate at the intersection of technology, sales, and the customer — engaging directly with C-level and technical leaders at our most strategic customer accounts, translating our AI-driven platform capabilities into credible technical narratives, and representing the company as a thought leader across the industry. This is a customer-facing, pre-sales technical leadership role reporting to the VP of Sales Engineering, with a dotted line to Product & Technology.

**Responsibilities**:

- Serve as trusted technical advisor and recurring executive sponsor for C-level and senior technical stakeholders at strategic, enterprise, federal and other key accounts — pivoting fluidly between business strategy conversations, risk, compliance, and deep technical architecture reviews.

- Lead highly visible, multidisciplinary technical engagements of strategic importance across the region, including executive briefings, architecture reviews, whiteboard sessions, customer advisory feedback loops, and partner or analyst-facing discussions.

- Represent Black Duck as a technical evangelist for the platform and roadmap within a region, delivering keynotes, webinars, whitepapers, and thought leadership content at industry events, and representing the company externally with press, analysts, and partners.

- Translate Black Duck platform AI/ML, detection engine, and platform architecture capabilities into clear, credible narratives for both technical and executive audiences, speaking candidly to responsible AI practices such as data privacy, model governance, and human-in-the-loop controls.

- Partner with Sales and Presales leadership on the region’s most strategic and enterprise opportunities, leading technical deep-dives, architecture reviews, whiteboard sessions, and executive briefings, and advising on the technical implications of new product launches, roadmap changes, and competitive positioning.

- Support RFPs and security questionnaires with authoritative technical input, and articulate competitive and technical differentiation, including nuanced comparisons of AI/ML capabilities against alternatives in the market.

- Proactively engage strategic accounts to strengthen technical trust, identify expansion opportunities, mitigate renewal risk, and guide customers toward secure software development and application security maturity.

- Identify and solve problems of strategic or industry scope, using innovative approaches to remove technical barriers, strengthen customer confidence, and improve business outcomes.

- Provide field-informed guidance on emerging AI-assisted software development, agentic workflows, application security trends, and competitive market dynamics that may influence Black Duck strategy or customer adoption.

- Capture, synthesize, and escalate regional customer, partner, and market feedback into actionable input for Product, Engineering, and Sales systematically capturing technical objections and influencing the roadmap, packaging, launch readiness, and go-to-market strategy.

- Coach, enable, and review technical storytelling by sales engineers and account executives, including how to explain AI features accurately without overclaiming.

**Qualifications and Experience Required**:

- 15+ years in a senior technical leadership role (CTO, Sales Engineering leader, Principal Architect, or equivalent), including several years in a customer-facing or field/pre-sales capacity.

- Proven track record engaging and influencing C-level and senior technical audiences at enterprise organizations, with demonstrated success across complex enterprise sales cycles.

- Domain expertise in application security (SAST, SCA, DAST), enterprise architecture, cloud/SaaS platforms, APIs and integrations, and security best practices.

- Deep, practical understanding of AI/ML concepts as applied to security (e.g., anomaly detection, large language models, behavioral analytics, AI-assisted software development, agentic workflows), along with a candid grasp of their limitations and the practical limitations and controls needed for responsible adoption.

- Demonstrated success negotiating with and influencing executive leadership, significant customers, partners, analysts, or vendors to shape technical decisions and business outcomes.

- Ability to exercise wide latitude in determining objectives and approaches for complex, critical assignments with material regional, functional, or market impact.

- Experience shaping standards, methods, practices, or market-facing technical narratives within an industry or discipline.

- Proven ability to translate complex technical concepts into clear stories for both executive and highly technical audiences, including customers, partners, press, analysts, and internal stakeholders.

- Demonstrated industry presence — conference speaking, published thought leadership, active contribution to industry/analyst communities, customer advisory leadership, or comparable external technical influence.

- Exceptional written and verbal communication skills, able to translate complex technical concepts for both technical and executive audiences.

- Willingness and ability to travel up to 50% to customer sites and industry events.

- Bachelor's degree in Computer Science, Engineering, Cybersecurity, or a related field, or equivalent practical experience.

**Preferred Qualifications:**

- MBA or other advanced degree.

*Black Duck is an equal opportunity employer. We consider all applicants for employment without regard to race, color, national origin, religion, sex, gender identity or expression, age, disability, sexual orientation, veteran or military service status, or any other characteristic protected by applicable law. Black Duck complies with all applicable laws prohibiting employment discrimination in every jurisdiction where it operates and provides reasonable accommodations to individuals with disabilities in accordance with applicable law.*

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
