# Senior Product Manager (Full Remote - Europe)

Posted: 2026-09-12T20:40:13Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

# Our Vision & Products

***🚀 EverAI — Building the Future of AI Companionship***

*One of the Top 15 Largest & Fastest-Growing AI Companies in the World*

*50 Million Users in 2 years — Help Us Reach 100M first, 500M next*

At **EverAI**, we’re shaping what it means to connect with AI. With **50 million users and counting**, we're not just building products — we're creating entirely new categories.

Our flagship product is the **world’s largest AI companionship platform**, redefining relationships for millions. It is governed by our proprietary moderation system, EverGuard — an internal AI designed to ensure everything we build is **safe, ethical, and human-first**.

*And we’re only just getting started!*

# Our Team

We are an enthusiastic, passionate and hardworking team of ≈ 100 people. Our founding team has strong entrepreneurial experience building and scaling web products from 0 to IPO.

**Alexis Soulopoulos **[CEO]

*• 10+ years in Tech Executive Leadership*

*• Co-Founder Mad Paws Holdings (from 0 to IPO)*

*• Forbes 30 under 30 + Deloitte TechFast50 ’22 & ‘23*

**Michael Monin** [Co-founder & CTO]

*• 10+ years as CTO / COO (web2/web3), 3 years in AI/LLM*

*• Serial-entrepreneur: MTK Digital (exited / 0->$20m revenue) and Zipchat (AI Chatbot for E-commerce brands)*

**Thomas Lacroix **[Co-founder & CMO]

*• 8+ years in Customer Acquisition & E-commerce Growth*

*• Serial-entrepreneur: Curatible (sold to Blackstone) and MTK Digital (exited / 0->$20m revenue)*

**Maruša Fasano **[CFO/Legal]

*• 25+ years in Finance, Strategy, M&A*

*• Ex-CFO/M&A @Curatible (exited to Blackstone)*

*• Ex-President of the Board @SotremoSA (exited)*

*• Co-founder/CFO @SoftOne (exited)*

# Your Role

Most Product Manager roles are built around specs and handoffs, waiting on a designer's mockup, an engineer's sprint slot, a data analyst's report.

**This role is built differently: **we're hiring a** PM who does more than decide what should be built.** You'll steer a developer squad end to end: investigating opportunities, analyzing user behaviour, prototyping solutions with AI, contributing code, launching experiments, and improving what reaches production.

You'll work directly with Pierre Gerbaud, Product Lead, and Michael Monin, our Co-founder & CTO, on a product already used by more than 50 million people and growing toward 100 million users.

At this scale, every small improvement can create significant impact, and you'll have the space to spot these opportunities and act on them quickly.

**If your first instinct is to test an idea by making it real, this is your role.**

# Your Responsibilities

-

**Own the work end to end, not just a piece of it:** Understand the problem, choose an approach, build the solution (AI-assisted coding, opening pull requests, working with internal tools), launch it, measure it, and iterate with as few handoffs as possible;

-

**Build with AI every day:** Use AI tools for research, analysis, prototyping, and debugging; as a genuine part of how you think and work, evolving with the tools as they improve;

-

**Decide what's worth pursuing, and test it fast:** When a dozen directions look plausible and there are more ideas than time, identify the opportunities that matter most and design the smallest meaningful experiment to test your assumptions;

-

**Let the results determine what happens next:** Define success before you build, analyse the outcome once the experiment is live, and use what you learn to improve, expand, or stop what you shipped;

-

**Work embedded in a software engineering squad:** partner directly with Leads, Co-founders, designers, and engineers to define and deliver priority projects, and communicate progress and decisions to all relevant stakeholders;

-

**Keep momentum high:** Surface blockers the moment they appear, challenge assumptions directly regardless of who made them, and find another route forward when the obvious one is blocked;

# Your Qualifications

-

**You build with AI:** you’ve personally built and shipped a functional feature, experiment, prototype, workflow, or tool using AI coding tools. Claude Code, Cursor, Codex, or similar tools are already part of how you work everyday;

-

**You use data to make product decisions:** you can name the metrics you want to influence, explain why it matters, and say whether your work actually moved them. You’ve run A/B tests, product experiments, data deep-dives, or lightweight user research and used the findings to shape what was built next;

-

**You explore AI independently: **you actively seek out and experiment with new tools and techniques without waiting for a project or manager to require them;

-

**You take ownership and move without waiting for certainty:** comfortable with ambiguity, you create clarity by investigating, building, testing, and learning rather than waiting for a complete brief. You balance execution against planning, address blockers early, and take responsibility for the outcome rather than waiting to be told what to do, caring more about reaching the right result than following a fixed process;

-

**You communicate clearly and collaborate directly:** you work effectively with designers, engineers, and other stakeholders, ask the right questions, challenge assumptions constructively, and are fully fluent in English;

-

**You care about the user experience**: you take pride in the quality of what reaches users, and pay attention to whether the product is useful, intuitive, and engaging;

-

**You are comfortable with the product category:** you are fully comfortable building products based on uncensored models and content;

### Bonus points

-

You have enough design fluency to prompt a usable UI independently

-

You’ve worked at a fast-scaling D2C/consumer tech company or scale-up

-

You have experience on consumer-facing features

-

You have experience in Entertainment, Avatars, Gaming, or any high-touch media industry

# Why EverAI?

📈 **Exponential Growth**: From 50M users in 2 years, to 100M next — and 500M beyond

🚀 **Track Record of Category-Creating Innovation**: We consistently launch **world-first AI applications** — setting the pace, not following it

🌍 **Global Impact**: Top-tier user growth, real-world adoption, and cultural relevance

🧠 **Proven Leadership**: A senior team that’s **launched, scaled, and exited & IPO’d multiple scale ups** — now fully focused on reshaping AI companionship

👥 **Elite Remote Team**: 100% remote and built to win — world-class talent from **Tier 1 tech companies**, with a culture of ownership, velocity, and radical creativity

🛡️ **Ethical Core**: Our AI ecosystem is governed by **EverGuard, our proprietary AI moderation technology**, ensuring responsible development at scale

# What We Offer

✍️ **Contract Type:** We prefer B2B, but we’re flexible, what matters is long-term commitment and impact
📍 **Work From Anywhere:** Fully remote. Choose the environment where you do your best work
🏝️ **Paid Time Off:** 4 weeks (20 working days) of PTO per year to recharge and reset
👨‍👩‍👧‍👦 **Annual Gathering:** A yearly in-person meetup to connect, brainstorm, and celebrate wins together
❤️‍🩹 **Health & Wellness Support: **Monthly allowance of** **100 USD for health insurance expenses & access to unlimited 1:1 sessions with psychologists and lifestyle experts through *OpenUp *(also available to up to three of your family members)
🏢 **Co-Working Space Budget:** Work from a co-working space up to twice per month (35 EUR / 40 USD per visit) to stay inspired and connected
📚 **Learning Budget:** Dedicated funds to support your professional growth: courses, books, conferences, events, or certifications
💻 **Company Laptop & Equipment:** Laptop provided + monitor budget up to 250 USD + keyboard/mouse/mic/headphones budget up to 150 USD
⚡ **AI Tools Access:** Premium access to ChatGPT, Cursor, Hugging Face, Claude Code, and any other tool needed to excel at your job, power your ideas and workflows

**** 💸 Compensation:** Our salary ranges are set based on role level, scope, location, and market data, and applied consistently regardless of candidate background or negotiation history. The final offer within the published range reflects assessed experience and scope.*

# 🎯 Top Tier Talent Is Our Multiplier

We’re a fully remote group of **A-players from Tier 1 tech**, led by an exec team who’ve **launched, scaled, and exited multiple companies**. We move fast, and care deeply about what we build — and who we build it with.

We’re looking for **exceptional talent** ready to ship & distribute world-first AI products at scale, fast, and co-create with us this category-defining business.

**If that’s you — reach out and apply!**

## **💡 External Referral Program**

**Know someone who could be a great fit for this role?** You can refer them through the **EverAI External Referral Program** and earn a bonus of **up to 2,500 USD** if they’re hired. [Submit a referral here.](https://docs.google.com/forms/d/e/1FAIpQLSeuvD8GKtVT8Q33nsdF691LTEAFRErTK4JPyFrZlLMaWF82GQ/viewform?usp=preview)

Compensation: €75K – €125K

- • Estimated Base Salary €75K – €125K

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
