# Werkstudent Talent Acquisition (m/w/d)

Posted: 2026-09-12T17:55:10Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

## **Kurz und knapp**

Unsere Werkstudent:innen sind dafür verantwortlich, die besten Talente der Welt zu finden und von Picnic zu überzeugen. Du verfügst über hervorragende Schreibfähigkeiten, bist begeistert, wenn du die richtigen Profile findest, und weißt, wie du diese am besten für die Herausforderungen bei Picnic begeistern kannst. Du verstehst die Profile, nach denen wir suchen, und weißt, wie wichtig es ist, die richtigen Leute für Picnic zu finden. Wir sind dabei auf der Suche nach jemandem, der uns im besten Fall **20 Stunden die Woche** unterstützen würde.

## **Das erwartet dich**

- **Anforderungsanalyse:** Du arbeitest eng mit unseren Recruiter:innen und verschiedenen internen Stakeholdern zusammen, um die Anforderungen der offenen Vakanzen zu verstehen

- **Candidate Sourcing:** Du suchst nach potenziellen Kandidat:innen und sprichst diese durch die Nutzung von LinkedIn Search und anderen Suchtechniken an

- **Talentaufbau:** Du erarbeitest Strategien zum Aufbau von Talentpipelines

- **Ideenentwicklung:** Du bringst Ideen und Input mit, die sich positiv auf die Talentpipelines auswirken

## **Das bringst du mit**

- Du studierst Psychologie, HR Management, BWL oder ähnliches und befindest dich am Ende deines Bachelor- oder Anfang deines Masterstudiums

- Du bringst idealerweise erste Erfahrung im Active Sourcing und Recruiting mit oder hast Lust, dich in die Themen einzuarbeiten

- Du bist ambitioniert und bringst coole Ideen mit

- Ausgezeichnete mündliche und schriftliche Kommunikationsfähigkeiten auf Deutsch und Englisch

- Du bist ein Teamplayer und bringst ausgeprägte organisatorische Fähigkeiten mit, sowie eine Liebe zum Detail

- Du bist bereit, zwei Tage pro Woche in unserem brandneuen Büro in Hamburg zu arbeiten

## **Darauf kannst du dich freuen **

- **Starte mit uns durch: **Werde Teil unseres internationalen Teams in einem Umfeld, das echtes Wachstum und eine „Act like an Owner“-Mentalität fördert. Bei uns hast du die Chance, Projekte eigenverantwortlich voranzutreiben, neue Ideen zu testen und direkt miterleben zu können, wie deine Arbeit in unserem schnell wachsenden Unternehmen Wirkung zeigt.

- **Verpflegung: **Genieße jeden Tag ein frisches, kostenloses Frühstück und Mittagessen in unserem Büro, dazu gibt es reichlich Snacks und Obst für den Energiekick zwischendurch.

- **Unvergessliche Momente:** Von unserem legendären jährlichen Ski-Trip über Weihnachtsfeiern bis hin zu Auftritten unserer eigenen Picnic-Band: Wir feiern unsere Erfolge gemeinsam.

- **Ein moderner Workspace:** Unser neu renoviertes Büro ist auf Zusammenarbeit ausgelegt und bietet dir flexible Arbeitszeiten sowie 30 Urlaubstage (bei einer 40-Stunden-Woche).

- **Wohlbefinden & Gleichgewicht:** Wir bieten dir professionelle Unterstützung für deine mentale Gesundheit mit OpenUp. Und dank unseres hundefreundlichen Büros ist dein vierbeiniger Begleiter nach Absprache willkommen.

- **Die Basics:** Wir stellen dir alles für deinen Erfolg bereit - inklusive Laptop sowie Zugang zu exklusiven Rabatten (Corporate Benefits) für Reisen, Technik und vieles mehr.

- **Nachhaltigkeit als Kern:** Werde Teil der Revolution. Du trägst zu einer grüneren Zukunft bei – durch unsere 100 % elektrische Flotte und unsere Lieferkette, die Lebensmittelverschwendung reduziert.

- **Attraktive Vergütung:** Als WerkstudentIn verdienst du 14,75 €/Std. (Bachelor) bzw. 15,50 €/Std. (Master) und sammelst spannende Praxiserfahrung.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
