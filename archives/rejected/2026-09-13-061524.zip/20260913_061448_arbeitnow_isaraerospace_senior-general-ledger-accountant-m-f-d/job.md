# Senior General Ledger Accountant (m/f/d)

Posted: 2026-09-12T17:55:16Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**Mission Brief **

This is an exciting opportunity to join Isar Aerospace in a key role.

You will be responsible for proper financial accounting, the preparation of financial statements, and the ongoing optimization and digitization of accounting processes in an international SAP S/4HANA environment.

**Your Role in Our Space Mission: **

- Record payment transactions and bank activities: Ensure timely and accurate bank reconciliations

- Support cost control and invoice approvals: Collaborate with managers to control expenses and handle invoice approvals

- Maintain accurate asset records: Perform asset accounting, reconcile balance sheets, and manage intercompany accounts

- Assistance with the preparation of monthly, quarterly and annual financial statements under HGB and Local GAAP

- Responsibility for the general ledger, provisions, accruals, and balance sheet reconciliations.

- Participation in SAP rollouts, system optimizations, and finance projects

- Conducting intercompany reconciliations and providing support to international subsidiaries.

- Close coordination with Operations and Controlling on project- and performance-related accounting matters

- Close collaboration with Group Accounting for Reportings

- Collaboration with IT, Controlling, Tax, and international shared-service organizations

**Qualification Checklist **

- A college degree with a major in finance, accounting, or a comparable qualification

- At least 5 years of professional experience in accounting at an international company

- Very good knowledge of the German Commercial Code (HGB / US-GAAP)

- Reliable and detail-oriented with a commitment to accuracy

- In-depth knowledge of SAP, preferably SAP S/4HANA FI / MM & MS Office

- Experience with process management and digital transformation projects

- High level of personal responsibility and analytical thinking

- A structured and solution-oriented approach to work

- Confident demeanor when interacting with management and other departments

- Strong communication and teamwork skills

- Affinity for digital processes and change

- Possess excellent written and spoken English language skills

**Benefits **

- **Employee Participation Program:** Share in our success through our virtual company share program

- **30 days of vacation: **Enjoy the days off to relax and recharge

- **Company pension plan:** Secure your future with our company pension plan, featuring a 20% employer contribution after the probation period

- **Subsidised lunch:** Stay energised with delicious, subsidised lunches every day

- **Public transport ticket:** Commute with ease using a fully financed Deutschlandticket

- **Rental clothing with laundry service:** Enjoy hassle-free workwear with our convenient rental clothing and laundry service

- **Sport Clubs membership:** Stay fit with our sponsored sports club memberships (EGYM Wellpass)

- **Individual learning allowance:** Grow your skills with an individual learning budget granted after the probation period

- **Childcare allowance:** Receive a childcare allowance for your non-school-age children

- **And Much More!** Discover additional perks and benefits when you join our team.

**Who we are**

****

We are Isar Aerospace and we are at the forefront of New Space building a modern space business to enable faster, better and cheaper access to space.

Our mission is to help democratise space and use it for good in order to improve life on Earth now and for the future generations.

We are a fast-growing company aiming to provide sustainable and environmentally friendly launch solutions for small and medium-sized satellites and constellations into Low Earth Orbit. The company is privately funded by world-leading technology investors with strong commitment and support and our team is made of driven and talented people with a real passion for space innovation.

We're making rockets in a way that hasn't been done before disrupting a traditional industry. If you are up for the challenge, want to work on cutting-edge projects and be part of a team changing the world for better, come, join us and launch your career!

Want to find out more about us?

Visit [www.isaraerospace.com](http://www.isaraerospace.com/)

**Data Protection
**We process your personal data for the purpose of managing the recruitment process and assessing your application. For detailed information on how your data is processed, including your rights, please refer to our [Privacy Policy](https://isaraerospace.com/privacy-policy).

**Disclaimer**

Isar Aerospace SE is an equal-opportunity employer committed to fairness and inclusivity. We do not prioritize any specific religion, gender, nationality, or background. Due to security clearance requirements, affiliations with countries listed under § 13 para. 1 no. 17 SÜG may affect the application process. All qualified applicants are encouraged to apply.

**Metaview**
We use Metaview to record interview audio so our team can review it later and stay focused during the conversation. We will record interviews only if you opt in. Please note that we will request your consent separately during the interview process. Participation is completely voluntary and will not affect your application in any way. For more information on how we process your personal data, please see our [Privacy Policy](https://deu01.safelinks.protection.outlook.com/?url=https%3A%2F%2Fisaraerospace.com%2Fprivacy-policy&data=05%7C02%7Cbritta.bonn%40ext.isaraerospace.com%7Cbf5a1173fd434834ab1c08dea5c061eb%7C50154d7ed4fe4770bb43bf09a927cc45%7C0%7C0%7C639130442882001477%7CUnknown%7CTWFpbGZsb3d8eyJFbXB0eU1hcGkiOnRydWUsIlYiOiIwLjAuMDAwMCIsIlAiOiJXaW4zMiIsIkFOIjoiTWFpbCIsIldUIjoyfQ%3D%3D%7C0%7C%7C%7C&sdata=l1vw27o02fEuCFAICyAHO91ObS%2FjnXDl5woYeGiSRek%3D&reserved=0).

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
