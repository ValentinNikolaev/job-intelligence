# Business Development Manager Healthcare Partnerships (m/w/d)

Posted: 2026-09-12T20:30:34Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Über CareSteps

Internationale Pflegefachkräfte bringen wertvolle Erfahrung mit. Damit sie in Deutschland in ihrem Beruf arbeiten können, brauchen sie die passende Unterstützung auf dem Weg zur Anerkennung.

CareSteps begleitet sie dabei mit gezielten Qualifizierungsangeboten und Vorbereitungskursen auf die Kenntnisprüfung. Als Marke des AZAV-zertifizierten Bildungsträgers StartSteps verbinden wir Bildung mit konkreten beruflichen Perspektiven.

Für den Ausbau unseres Partnernetzwerks suchen wir eine vertriebsstarke Persönlichkeit, die Beziehungen zu Gesundheitseinrichtungen und internationalen Personalvermittlungen aufbaut und daraus langfristige Zusammenarbeit entwickelt.

## Tasks

Deine Aufgaben

- **Neue Partner gewinnen:** Du identifizierst und überzeugst Krankenhäuser, Pflegeheimbetreiber, Rehakliniken und internationale Personalvermittlungen von unseren Qualifizierungsangeboten.

- **Den Vertrieb eigenständig steuern:** Von der ersten Ansprache über Beratung und Angebotserstellung bis zum Vertragsabschluss verantwortest du den gesamten Vertriebsprozess.

- **Bedarf in Kursbuchungen übersetzen:** Du verstehst die Anerkennungs- und Qualifizierungsbedarfe unserer Partner und stimmst passende Angebote mit unserem Bildungsteam ab.

- **Partnerschaften weiterentwickeln:** Du begleitest gewonnene Partner und baust eine Zusammenarbeit auf, aus der regelmäßig neue Teilnehmende in unsere Kurse kommen.

- **Eine verlässliche Pipeline aufbauen:** Du dokumentierst Kontakte, nächste Schritte und Ergebnisse im CRM und behältst Umsatzpotenziale und geplante Kursstarts im Blick.

- **CareSteps im Markt vertreten:** Du knüpfst Kontakte auf Fachveranstaltungen, in Branchennetzwerken und bei Partnerbesuchen.

- **Unser Wachstum mitgestalten:** Du arbeitest direkt mit der Geschäftsführung zusammen und bringst Rückmeldungen aus dem Markt in die Weiterentwicklung unserer Angebote ein.

## Requirements

Dein Profil

- Du hast Erfahrung im B2B-Vertrieb, Business Development oder Key Account Management – idealerweise im Gesundheitswesen, in der internationalen Fachkräftevermittlung oder bei einem Bildungsanbieter.

- Du kannst zeigen, wie du selbst neue Kunden gewonnen und Geschäftsbeziehungen aufgebaut hast.

- Du verstehst die Herausforderungen von Gesundheitseinrichtungen bei der Beschäftigung internationaler Pflegefachkräfte oder bist bereit, dich schnell und gründlich einzuarbeiten.

- Bestehende Kontakte zu Krankenhäusern, Pflegeeinrichtungen oder Personalvermittlungen sind ein großes Plus.

- Kenntnisse rund um berufliche Anerkennung, Kenntnisprüfung und Fördermöglichkeiten sind willkommen.

- Du gehst aktiv auf Menschen zu, verhandelst sicher und bleibst auch bei längeren Entscheidungsprozessen verbindlich dran.

- Du arbeitest eigenständig, strukturiert und ergebnisorientiert.

- Du kommunizierst verhandlungssicher auf Deutsch und sicher auf Englisch und bist bereit, Partner innerhalb Deutschlands zu besuchen.

## Benefits

Was dich erwartet

- **Eine Aufgabe mit gesellschaftlicher Wirkung:** Du hilfst internationalen Pflegefachkräften, beruflich anzukommen, und Gesundheitseinrichtungen, qualifiziertes Personal einzusetzen.

- **Viel Gestaltungsspielraum:** Du prägst den Aufbau unseres B2B-Vertriebs und unseres Partnernetzwerks.

- **Direkte Zusammenarbeit mit der Geschäftsführung:** Kurze Entscheidungswege und Raum für eigene Ideen.

- **Eine bestehende Grundlage:** Du baust auf zertifizierten Bildungsangeboten, laufenden Kursen und ersten Partnerschaften auf.

- **Sichtbare Ergebnisse:** Dein Erfolg zeigt sich in aktiven Partnerschaften, tatsächlichen Kursstarts und langfristigen Kundenbeziehungen.

Interesse?

Schick uns deinen Lebenslauf oder dein LinkedIn-Profil und ein paar kurze Sätze dazu, welche relevante Vertriebs- oder Branchenerfahrung du mitbringst. Ein ausführliches Anschreiben ist nicht nötig.

Wir freuen uns darauf, dich kennenzulernen.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
