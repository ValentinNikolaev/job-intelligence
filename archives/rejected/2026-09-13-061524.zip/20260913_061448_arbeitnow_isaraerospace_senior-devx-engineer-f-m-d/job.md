# Senior DevX Engineer (f/m/d)

Posted: 2026-09-12T17:55:16Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**Your Mission**

As a Senior DevX Engineer, you will play a key role in building and evolving the Software Platform capabilities used across Ground Systems. You will enable engineering teams with scalable, secure, and efficient development workflows while continuously improving developer productivity and software delivery. You will own and evolve core engineering enablement platforms and practices, as well as automate recurring workloads and monitor system performance and reliability

Your mission is to create an engineering ecosystem that accelerates software delivery, improves quality, enhances collaboration, and enables teams to focus on delivering business value.

More specifically, you will:

- Own and continuously evolve software platform capabilities enabling secure, reliable, and efficient software delivery

- Champion GitOps-based delivery practices using tools such as ArgoCD and GitLab CI/CD

- Design, implement, and maintain scalable CI/CD pipelines and reusable pipeline templates that enable reliable software delivery across multiple projects.

- Automate cloud and on-premises infrastructure provisioning and management using Infrastructure as Code (IaC) and scripting.

- Define and promote software quality standards

- Implement monitoring and observability solutions to ensure system reliability, availability, and fast incident response.

- Establish and lead engineering communities of practice and drive adoption of platform standards across Ground Software Platform.

- Create and maintain technical documentation, standards, and operational playbooks to promote consistency across teams.

- Coach and mentor development teams on DevOps practices, CI/CD, software quality, automation, and platform capabilities.

- Apply Site Reliability Engineering practices including service level objectives (SLOs), error budgets, incident management, and operational excellence

**Who you are and what you have**

- Bachelor's or Master's degree in Computer Science, Software Engineering, Information Technology, or a related discipline.

- 5+ years of experience in DevOps, Platform Engineering, Site Reliability Engineering, or Software Infrastructure roles.

- Strong hands-on experience with CI/CD practices and platforms, including GitLab CI/CD and ArgoCD.

- Experience designing and operating scalable CI/CD platforms, automation frameworks, and developer enablement solutions

- Deep understanding of Microsoft Azure and cloud-native platform architectures

- Expert-level automation skills using Python, PowerShell, and Bash to automate platform operations and engineering workflows.

- Experience with Infrastructure as Code (IaC) tools, like Terraform, Helm, and Ansible.

- Familiarity with containerization and orchestration technologies, such as Kubernetes.

- Experience building developer tooling, engineering platforms, or Developer Experience (DevX) solutions.

- Strong knowledge of monitoring, observability, reliability engineering, and incident management practices

- Experience facilitating technical workshops, mentoring engineers, and promoting knowledge sharing across teams.

- Strong communication, collaboration, and stakeholder management skills.

Nice to Have (Optional):

- Experience implementing AI-assisted software development workflows and engineering productivity tooling.

- Experience in aerospace, mission-critical, or highly regulated engineering environments.

- Experience building and managing internal developer platforms.

**Benefits **

- **Employee Participation Program:** Share in our success through our virtual company share program

- **30 days of vacation: **Enjoy the days off to relax and recharge

- **Company pension plan:** Secure your future with our company pension plan, featuring a 20% employer contribution after the probation period

- **Subsidised lunch:** Stay energised with delicious, subsidised lunches every day

- **Public transport ticket:** Commute with ease using a fully financed Deutschlandticket

- **Rental clothing with laundry service:** Enjoy hassle-free workwear with our convenient rental clothing and laundry service

- **Sport Clubs membership:** Stay fit with our sponsored sports club memberships (EGYM Wellpass)

- **Individual learning allowance:** Grow your skills with an individual learning budget granted after the probation period

- **Childcare allowance:** Receive a childcare allowance for your non-school-age children

- **And Much More!** Discover additional perks and benefits when you join our team.

**Who we are**

****

We are Isar Aerospace and we are at the forefront of New Space building a modern space business to enable faster, better and cheaper access to space.

Our mission is to help democratise space and use it for good in order to improve life on Earth now and for the future generations.

We are a fast-growing company aiming to provide sustainable and environmentally friendly launch solutions for small and medium-sized satellites and constellations into Low Earth Orbit. The company is privately funded by world-leading technology investors with strong commitment and support and our team is made of driven and talented people with a real passion for space innovation.

We're making rockets in a way that hasn't been done before disrupting a traditional industry. If you are up for the challenge, want to work on cutting-edge projects and be part of a team changing the world for better, come, join us and launch your career!

Want to find out more about us?

Visit [www.isaraerospace.com](http://www.isaraerospace.com/)

**Data Protection
**We process your personal data for the purpose of managing the recruitment process and assessing your application. For detailed information on how your data is processed, including your rights, please refer to our [Privacy Policy](https://isaraerospace.com/privacy-policy).

**Disclaimer
**Isar Aerospace SE is an equal-opportunity employer committed to fairness and inclusivity. We do not prioritize any specific religion, gender, nationality, or background. Due to security clearance requirements, affiliations with countries listed under § 13 para. 1 no. 17 SÜG may affect the application process. All qualified applicants are encouraged to apply.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
