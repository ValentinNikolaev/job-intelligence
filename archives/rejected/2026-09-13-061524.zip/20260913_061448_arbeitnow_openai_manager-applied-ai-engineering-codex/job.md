# Manager, Applied AI Engineering (Codex)

Posted: 2026-09-12T20:40:13Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

### **About the Team**

The Applied AI Engineering team is responsible for helping customers turn frontier AI capabilities into real products, workflows, and business impact. We act as trusted technical partners across solution design, architecture, implementation, evaluation, and adoption, working alongside customers to build and scale effective AI applications with OpenAI’s technologies.

The Codex Applied AI Engineering team focuses on helping organizations transform how software is built with AI. We partner directly with engineering teams and technical leaders to integrate Codex into their software development lifecycle — from identifying high-impact use cases and designing AI-enabled workflows to implementation, evaluation, and scaled adoption. Our work helps ensure AI-powered software development is effective, reliable, secure, and deeply integrated into how engineering organizations operate.

### **
About the Role**

We are seeking an experienced technical leader to join as **Manager, Applied AI Engineering (Codex)**, leading a team of Applied AI Engineers responsible for driving successful Codex adoption across strategic customers. Your team will work hands-on with customer engineering organizations to design and build AI-enabled development workflows, solve complex implementation challenges, and establish scalable patterns for AI-powered software development.

As a manager, you will shape how these technical engagements operate at scale — setting strategy, coaching engineers, determining where the team can have the greatest impact, and ensuring consistently strong execution across customers. You will serve as both a people leader and senior technical advisor, partnering closely with Sales, Product, Research, and Engineering to translate customer needs and real-world usage into better technical approaches, reusable patterns, and product insights.

Success in this role will be measured by meaningful and sustained Codex adoption, successful customer outcomes, and the creation of repeatable technical patterns that help engineering organizations get more value from AI.

This role is open in our Munich and Berlin offices. We use a hybrid work model of 3 days in the office per week and offer relocation assistance to new employees.

### **
In This Role, You Will**

-

Lead, hire, and mentor a high-performing team of Applied AI Engineers supporting Codex customers across strategic accounts.

-

Own the operating model and technical engagement strategy for Codex Applied AI Engineering, helping customers move from initial exploration to meaningful, scaled adoption.

-

Guide teams in designing and implementing AI-enhanced development workflows, agentic systems, automations, evaluations, and scalable application architectures.

-

Act as the senior technical escalation point and thought partner for complex customer implementations and engineering challenges.

-

Partner with Sales, Product, Research, and Engineering teams to align customer outcomes with product direction and roadmap priorities.

-

Establish repeatable technical patterns, playbooks, reference architectures, and best practices that enable broader adoption of AI-powered software development.

-

Coach Applied AI Engineers to operate as trusted technical partners to engineering leaders, executives, and highly technical customer teams.

-

Synthesize insights from customer engagements and translate them into actionable feedback for Product, Research, and Engineering.

-

Develop a deep understanding of how customers are using Codex, where they encounter friction, and where new technical approaches or product capabilities could unlock greater impact.

-

Champion safe, reliable, and effective adoption of AI-powered development workflows across industries.

### **
You’ll Thrive in This Role If You**

-

Have 8+ years of experience in deeply technical, customer-facing roles such as applied engineering, solutions architecture, deployment engineering, technical consulting, or similar roles.

-

Have 2+ years of experience leading technical teams, including hiring, mentoring, and developing engineers.

-

Have experience building or deploying generative AI, developer platforms, agentic systems, or cloud-based software solutions in production environments.

-

Possess strong hands-on software engineering experience and fluency with programming languages such as Python or JavaScript.

-

Understand modern software development lifecycles and have strong intuition for how AI and coding agents can change how software is designed, built, tested, and maintained.

-

Can work directly with customer engineering teams to understand ambiguous problems, develop technical approaches, and turn ideas into working solutions.

-

Are an effective communicator who can translate complex technical and business topics for both engineering teams and executive stakeholders.

-

Thrive in ambiguous, fast-moving environments and enjoy building new operating models, technical patterns, and teams from first principles.

-

Demonstrate strong ownership, humility, technical judgment, and a commitment to helping both customers and teammates succeed.

-

Are personally committed to fostering the safe and beneficial development of AI.

**About OpenAI**

OpenAI is an AI research and deployment company dedicated to ensuring that general-purpose artificial intelligence benefits all of humanity. We push the boundaries of the capabilities of AI systems and seek to safely deploy them to the world through our products. AI is an extremely powerful tool that must be created with safety and human needs at its core, and to achieve our mission, we must encompass and value the many different perspectives, voices, and experiences that form the full spectrum of humanity.

We are an equal opportunity employer, and we do not discriminate on the basis of race, religion, color, national origin, sex, sexual orientation, age, veteran status, disability, genetic information, or other applicable legally protected characteristic.

For additional information, please see [OpenAI’s Affirmative Action and Equal Employment Opportunity Policy Statement](https://cdn.openai.com/policies/eeo-policy-statement.pdf).

Background checks for applicants will be administered in accordance with applicable law, and qualified applicants with arrest or conviction records will be considered for employment consistent with those laws, including the San Francisco Fair Chance Ordinance, the Los Angeles County Fair Chance Ordinance for Employers, and the California Fair Chance Act, for US-based candidates. For unincorporated Los Angeles County workers: we reasonably believe that criminal history may have a direct, adverse and negative relationship with the following job duties, potentially resulting in the withdrawal of a conditional offer of employment: protect computer hardware entrusted to you from theft, loss or damage; return all computer hardware in your possession (including the data contained therein) upon termination of employment or end of assignment; and maintain the confidentiality of proprietary, confidential, and non-public information. In addition, job duties require access to secure and protected information technology systems and related data security obligations.

To notify OpenAI that you believe this job posting is non-compliant, please submit a report through [this form](https://form.asana.com/?d=57018692298241&k=5MqR40fZd7jlxVUh5J-UeA). No response will be provided to inquiries unrelated to job posting compliance.

We are committed to providing reasonable accommodations to applicants with disabilities, and requests can be made via this [link](https://form.asana.com/?k=bQ7w9h3iexRlicUdWRiwvg&d=57018692298241).

[OpenAI Global Applicant Privacy Policy](https://cdn.openai.com/policies/global-employee-and-contractor-privacy-policy.pdf)

At OpenAI, we believe artificial intelligence has the potential to help people solve immense global challenges, and we want the upside of AI to be widely shared. Join us in shaping the future of technology.

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
