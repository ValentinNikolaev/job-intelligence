# Senior Product Manager (m/w/d)

Posted: 2026-09-12T17:55:13Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Du willst kein Feature-Team mehr moderieren. Du willst an den Zahlen gemessen werden. Conversion im Kaufprozess, API-Integrationen mit Partnern, neue Services auf der Plattform: Du priorisierst selbst, und du belegst mit Daten, warum.

**Standort:** Berlin Schöneberg – Du arbeitest vor Ort in unserem Büro, hybrid mit 3 Tagen Office und 2 Tagen Homeoffice.

### Über uns

CarOnSale ist die KI-gestützte Plattform für den B2B-Gebrauchtwagenhandel in Europa. Über 40.000 Käufer aus mehr als 20 Ländern handeln auf unserer Plattform – und 85 % des Inventars ist exklusiv bei uns. Wir verbinden Software, Pricing-Intelligenz, Logistik und Finanzierung in einer Schicht – als Betriebssystem für eine ganze Branche.

***One Platform. One Profit Engine.***

### Deine Aufgaben

- Du verantwortest einen eigenen Produktbereich end-to-end – von der Problemidentifikation über die Lösung bis zum Launch und zur Messung.

- Du steigerst die Conversion entlang des gesamten Kaufprozesses: Du findest die Stellen, an denen Händler abspringen, stellst Hypothesen auf und belegst mit Experimenten, was wirkt.

- Du baust API-Integrationen mit Partnern aus Finanzierung, Logistik und Services – von der technischen Spezifikation bis zum Rollout.

- Du steuerst Partnerschaften auf Produktseite: Du bewertest, welche Integration Volumen bringt, führst die Gespräche und hältst die Umsetzung nach.

- Du arbeitest direkt mit Engineering, Design, Sales und Operations und sorgst dafür, dass Entscheidungen mit Daten getroffen werden, nicht mit Meinungen.

- Du definierst die KPIs deines Bereichs, verfolgst sie selbst und leitest daraus die nächste Priorität ab.

###

### Was du mitbringst

- 4–6 Jahre Produktmanagement-Erfahrung in einem digitalen B2B-Marktplatz-, Plattform- oder E-Commerce-Umfeld

- Nachweisbare Erfolge in der Conversion-Optimierung – du kannst konkret erklären, was du verändert hast und was es gebracht hat

- Erfahrung mit API-Integrationen: Du verstehst, wie Systeme miteinander sprechen, und kannst mit Engineering auf Augenhöhe spezifizieren

- Erfahrung im Management von Partnerschaften auf Produktseite – Auswahl, Verhandlung, technische Anbindung, Nachhalten

- Ausgeprägte analytische Arbeitsweise: Du arbeitest selbst mit Daten, statt sie anzufordern, und triffst Entscheidungen auf dieser Basis

- Starke Problemlösungskompetenz und Eigeninitiative: Du identifizierst Probleme selbst, bevor sie jemand auf deinen Tisch legt, und löst sie eigenständig

- Kommunikationsstärke: Du machst komplexe Themen verständlich, für Engineering genauso wie für Händler und Leadership

- Deutsch auf C2-Niveau und Englisch verhandlungssicher

- Sicherer Umgang mit agilen Methoden (Scrum/Kanban) und Tools wie Jira und Confluence

- KI-affine Arbeitsweise – du nutzt Tools wie Claude, ChatGPT oder Copilot aktiv im Arbeitsalltag

**Von Vorteil**

- Erfahrung mit Checkout-, Payment- oder Finanzierungsprozessen (z. B. BNPL)

- Erfahrung im Automotive-Umfeld oder mit Risikomanagement

###

### Was dich bei uns erwartet

- Hybrides Arbeiten: 3 Tage Office, 2 Tage Homeoffice – plus 10 Tage „Work from Anywhere" pro Jahr

- 28 Tage Urlaub

- 2× jährliches Karriere- & Entwicklungsgespräch

- Betriebliche Altersvorsorge mit 20 % Arbeitgeberzuschuss

- Bezahltes Deutschlandticket

- FitX-Mitgliedschaft oder Urban Sports Club-Zuschuss

- Virtual Stock Options – du beteiligst dich am Erfolg

- Moderne IT-Ausstattung für dein tägliches Arbeiten

- Strukturiertes Onboarding mit Buddy-Programm und Social Events

- Gelebte Vielfalt: aktives Frauennetzwerk, Meditations- & Gebetsraum, hundefreundliches Büro

**Bewirb dich jetzt – dein Lebenslauf reicht.**

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
