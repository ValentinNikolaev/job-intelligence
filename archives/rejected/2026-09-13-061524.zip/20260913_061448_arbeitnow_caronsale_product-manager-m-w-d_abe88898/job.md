# Product Manager (m/w/d)

Posted: 2026-09-12T17:55:13Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Die meisten Product-Rollen auf deinem Level geben dir ein Backlog und einen Sprint. Diese gibt dir eine Frage: Warum springt ein Händler zwischen Gebot und Kauf ab? Du gehst in die Daten, sprichst mit Kunden, baust die Lösung mit Engineering und misst, ob es gewirkt hat.

**Standort:** München – Du arbeitest vor Ort in unserem Büro, hybrid mit 3 Tagen Office und 2 Tagen Homeoffice.

###

### Über uns

CarOnSale ist die KI-gestützte Plattform für den B2B-Gebrauchtwagenhandel in Europa. Über 40.000 Käufer aus mehr als 20 Ländern handeln auf unserer Plattform – und 85 % des Inventars ist exklusiv bei uns. Wir verbinden Software, Pricing-Intelligenz, Logistik und Finanzierung in einer Schicht – als Betriebssystem für eine ganze Branche.

***One Platform. One Profit Engine.***

###

### Deine Aufgaben

- Du verantwortest Features und Verbesserungen in deinem Produktbereich – von der Anforderung über die Umsetzung mit Engineering bis zum Launch.

- Du analysierst, wo Händler im Kaufprozess abspringen, und entwickelst Maßnahmen, die die Conversion messbar erhöhen.

- Du arbeitest an der technischen Anbindung von Partnern und begleitest API-Integrationen gemeinsam mit Engineering.

- Du sprichst regelmäßig mit Händlern, sammelst Feedback strukturiert ein und übersetzt es in konkrete Anforderungen.

- Du pflegst und priorisierst dein Backlog eigenständig und begründest deine Priorisierung mit Daten.

- Du verfolgst die KPIs deiner Features nach dem Launch und leitest daraus die nächsten Schritte ab.

### Was du mitbringst

- 2–4 Jahre Erfahrung im Produktmanagement oder als Product Owner, idealerweise in einem digitalen B2B-, Plattform- oder E-Commerce-Umfeld

- Erste Erfahrung in der Conversion-Optimierung – du hast schon Funnel analysiert und Verbesserungen umgesetzt

- Technisches Verständnis für API-Integrationen: Du musst nicht selbst entwickeln, aber verstehen, worüber Engineering spricht

- Ausgeprägte analytische Arbeitsweise: Du arbeitest selbst mit Daten und leitest daraus Entscheidungen ab

- Starke Problemlösungskompetenz und Eigeninitiative: Du wartest nicht auf Aufgaben, sondern erkennst selbst, wo es hakt

- Kommunikationsstärke: Du erklärst komplexe Themen verständlich und arbeitest gern direkt mit Kunden

- Deutsch auf C2-Niveau und Englisch verhandlungssicher

- Sicherer Umgang mit agilen Methoden (Scrum/Kanban) und Tools wie Jira und Confluence

- KI-affine Arbeitsweise – du nutzt Tools wie Claude, ChatGPT oder Copilot aktiv im Arbeitsalltag

**Von Vorteil**

- Erfahrung mit Checkout-, Payment- oder Finanzierungsprozessen (z. B. BNPL)

- Erste Berührungspunkte mit Partnerschaften oder dem Automotive-Umfeld

###

### Was dich bei uns erwartet

- Hybrides Arbeiten: 3 Tage Office, 2 Tage Homeoffice – plus 10 Tage „Work from Anywhere" pro Jahr

- 28 Tage Urlaub

- 2× jährliches Karriere- & Entwicklungsgespräch

- Betriebliche Altersvorsorge mit 20 % Arbeitgeberzuschuss

- Bezahltes Deutschlandticket

- FitX-Mitgliedschaft oder Urban Sports Club-Zuschuss

- Virtual Stock Options – du beteiligst dich am Erfolg

- Moderne IT-Ausstattung für dein tägliches Arbeiten

- Strukturiertes Onboarding mit Buddy-Programm und Social Events

- Gelebte Vielfalt: aktives Frauennetzwerk

**Bewirb dich jetzt – dein Lebenslauf reicht.**

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
