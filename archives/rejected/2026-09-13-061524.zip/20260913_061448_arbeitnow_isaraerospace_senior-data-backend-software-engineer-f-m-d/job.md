# Senior Data & Backend Software Engineer (f/m/d)

Posted: 2026-09-12T17:55:16Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**Mission Brief**

Join us in building the systems and software that empowers our engineering and operation departments to analyze flight data and make data-driven decisions. As a Data & Backend Software Engineer, you will help transform large volumes of structured and unstructured data into reliable, accessible, and actionable information. Your work will enable data-driven decision-making across the company and unlock insights that drive innovation and operational excellence.

**Your Role in Our Space Mission**:

As part of our Data and Analytics team, you will design, develop, and operate the systems that ingest, process, store, and serve data at scale.

You will:

- Build modern, scalable, and high-performance solutions for our engineering and operation platform.

- Strong understanding and at least 6 years of hands-on experience in one of the following languages: C#, Java, Rust, Python.  

- Define data ingestion, processing, storage, and access patterns to ensure reliability, scalability, and maintainability.

- Develop data services, APIs, pipelines, and data products that make data available to engineers, analysts, and business stakeholders.

- Design and implement robust ETL/ELT processes to ingest and transform data from a wide variety of sources.

- Contribute to data architecture, modeling, and storage decisions to ensure consistency, availability, low latency, and long-term sustainability of the platform.

- Ensure data quality and integrity through validation processes, monitoring, and adherence to data governance principles.

- Provide observability and monitoring of platform components, enabling rapid detection and resolution of issues.

- Author and maintain architectural documentation, technical specifications, and user-facing documentation.

- Collaborate with cross-functional teams to understand data needs and deliver impactful solutions.

- Guide less experienced engineers by sharing your knowledge and know-how, promoting engineering best practices and continuous learning.

**Qualification Checklist** 

- A degree in software engineering, computer science, data science or similar 

- Strong experience with batch and streaming data processing

- Good understanding of time-series data concepts, including sampling rates, decimation, signal integrity, and frequency-domain analysis

- Practical experience in optimizing and efficient implementation of native data processing and DataFrame-based processing

- Excellent skills in querying, transforming, and optimizing large-scale datasets

- Solid understanding of modern data architectures, including Lakehouse, Data Warehouse, and Medallion Architecture patterns

- Hands-on experience with analytical storage technologies such as Delta Lake and Apache Iceberg

- Experience with Apache Kafka and event-driven architectures

- Experience with modern data platforms such as Microsoft Fabric, Azure Data Factory, Databricks, or Snowflake

- Strong understanding of software engineering principles, including maintainability, testing, and automation

- Understanding of cloud infrastructure, networking concepts, and platform operations

- Experience with Protobuf encoding and columnar file formats (Parquet, Arrow, Zarr, Arrow Flight)

- Experience with observability, monitoring, and telemetry solutions

- Experience with OLAP databases and/or TSDBs (like ClickHouse, Apache Druid, InfluxDB)

- Ability to communicate technical concepts effectively and collaborate across disciplines

**Bonus Skills: **

- Experience working with large-scale engineering, manufacturing, or telemetry datasets.

- Familiarity with DevOps practices, CI/CD pipelines, and Infrastructure as Code (IaC).

- Experience with stream processing frameworks like Apache Flink

**Benefits **

- **Employee Participation Program:** Share in our success through our virtual company share program

- **30 days of vacation: **Enjoy the days off to relax and recharge

- **Company pension plan:** Secure your future with our company pension plan, featuring a 20% employer contribution after the probation period

- **Subsidised lunch:** Stay energised with delicious, subsidised lunches every day

- **Public transport ticket:** Commute with ease using a fully financed Deutschlandticket

- **Rental clothing with laundry service:** Enjoy hassle-free workwear with our convenient rental clothing and laundry service

- **Sport Clubs membership:** Stay fit with our sponsored sports club memberships (EGYM Wellpass)

- **Individual learning allowance:** Grow your skills with an individual learning budget granted after the probation period

- **Childcare allowance:** Receive a childcare allowance for your non-school-age children

- **And Much More!** Discover additional perks and benefits when you join our team.

**Who we are**

****

We are Isar Aerospace and we are at the forefront of New Space building a modern space business to enable faster, better and cheaper access to space.

Our mission is to help democratise space and use it for good in order to improve life on Earth now and for the future generations.

We are a fast-growing company aiming to provide sustainable and environmentally friendly launch solutions for small and medium-sized satellites and constellations into Low Earth Orbit. The company is privately funded by world-leading technology investors with strong commitment and support and our team is made of driven and talented people with a real passion for space innovation.

We're making rockets in a way that hasn't been done before disrupting a traditional industry. If you are up for the challenge, want to work on cutting-edge projects and be part of a team changing the world for better, come, join us and launch your career!

Want to find out more about us?

Visit [www.isaraerospace.com](http://www.isaraerospace.com/)

**Data Protection
**We process your personal data for the purpose of managing the recruitment process and assessing your application. For detailed information on how your data is processed, including your rights, please refer to our [Privacy Policy](https://isaraerospace.com/privacy-policy).

**Disclaimer
**Isar Aerospace SE is an equal-opportunity employer committed to fairness and inclusivity. We do not prioritize any specific religion, gender, nationality, or background. Due to security clearance requirements, affiliations with countries listed under § 13 para. 1 no. 17 SÜG may affect the application process. All qualified applicants are encouraged to apply.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
