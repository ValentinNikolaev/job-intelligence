# Senior Accountant ERP & Digitalisierung (m/w/d) Dynamics 365

Posted: 2026-09-12T23:30:12Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Finance trifft Digitalisierung.

Du möchtest deine Finance Expertise einsetzen, um **digitale Prozesse voranzutreiben** & **moderne ERP Systeme** aktiv mitzugestalten?

Dann bist du hier richtig.

Unser Kunde ist ein **global etabliertes Familienunternehmen **mit rund 1.200 Mitarbeitenden an über 20 Standorten weltweit.
Die **internationale Gruppe** verbindet Innovation und Nachhaltigkeit mit einer familiären Unternehmenskultur & kurzen Entscheidungswegen.

Als **Senior Accountant ERP & Digitalisierung (m/w/d) **gestaltest du die digitale Weiterentwicklung der Finance Landschaft aktiv mit & bist zentrale Ansprechperson für ERP Prozesse innerhalb der internationalen Gruppe.

**🏅 DEINE BENEFITS:**

-

**Hybrides, flexibles Arbeiten:** Bis zu 2 Tage Homeoffice & Gleitzeitmodell

-

**Weiterentwicklung:** Individuelle Weiterbildungen, Sprachkurse & interne Entwicklungsmöglichkeiten

-

**Onboarding:** Individuelle Einarbeitung mit Schulungen, Softwaretrainings und Einblicken in verschiedene Gesellschaften sowie Abteilungen

-

**Gesundheit:** Wöchentliches Rückentraining während der Arbeitszeit, Betriebsarzt & Masseur

-

**Mobilität:** Unterstützung bei Deutschlandticket & kostenlose Parkmöglichkeiten

-

**Verpflegung:** Hauseigenes Betriebsrestaurant mit regionalen Gerichten zu vergünstigten Preisen.

-

**Mobilität:** Zuschuss zum Deutschlandticket & kostenfreier Parkplatz

-

**Kultur:** Familiäres Umfeld, verschiedene Firmen-, Sport- & Teamevents & familiäres Miteinander

-

**Attraktive Vergütung:** Leistungsgerechtes Gehalt sowie Urlaubs- & Weihnachtsgeld

**🧩 DEINE AUFGABEN:**

Als **Senior Accountant ERP & Digitalisierung** gestaltest du die Weiterentwicklung moderner Finance Abläufe, treibst gruppenweite ERP Lösungen voran und fungierst als **zentrale Schnittstelle zwischen Finance und IT**.

🔍 Das bedeutet konkret:

**ERP Verantwortung:** Modulverantwortung für Finance Prozesse in Microsoft Dynamics 365 für bestehende & zukünftige Gesellschaften der Unternehmensgruppe

**Systementwicklung:** Konfiguration sowie Weiterentwicklung von ERP Prozessen, Schnittstellen und digitalen Finance Lösungen

**Prozessoptimierung:** Analyse & Weiterentwicklung von Geschäftsprozessen mit Schwerpunkt Rechnungswesen, Konsolidierung und Treasury

**Digitalisierungsprojekte:** Mitarbeit & Teilprojektverantwortung bei Finance Transformation Projekten, z.B. bei der Einführung neuer Workflows oder Automatisierungen

**Projektsteuerung:** Begleitung von Go Lives, Rollouts & Weiterentwicklungen der Finance IT Landschaft

**Schnittstellenmanagement:** Enge Zusammenarbeit mit Finance Teams, Dynamics 365 Spezialisten und externen Beratungspartnern zur Umsetzung gemeinsamer Projekte

**Anforderungsmanagement:** Aufnahme, Bewertung und Übersetzung von Finance Anforderungen in technische Lösungen

-

**Ausbildung:** Abgeschlossenes Studium (z.B. BWL, Finance, Wirtschaftsinformatik) oder kaufmännische Ausbildung mit Weiterbildung im Finanzbereich

-

**Finance Expertise:** Mehrjährige Erfahrung in der Finanzbuchhaltung mit fundiertem Verständnis für Finance Prozesse, Buchungslogiken sowie Monats- & Jahresabschlüsse

-

**Sprache:** Sehr gute Deutsch- & Englischkenntnisse

-

**Systemkenntnisse:** Sicherer Umgang mit MS Office & gängigen ERP Systemen, idealerweise Microsoft Dynamics 365

-

**Erste Erfahrung in Digitalisierungsprojekten** & Interesse an der Weiterentwicklung von Prozessen sowie Systemen

-

**Nice to haves:**

Erfahrung mit Lucanet oder Serrala CM Pro
Scrum Kenntnisse bzw. agile Projekterfahrung

Klingt nach der **beruflichen Herausforderung, die du suchst**?

Dann schick uns deinen Lebenslauf & wir sprechen in einem kurzen Telefonat über die Position, das Team und deinen möglichen nächsten Karriereschritt – als **Senior Accountant ERP & Digitalisierung (m/w/d)**.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
