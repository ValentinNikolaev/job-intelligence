# (Senior) Account Executive SMB | DACH Market (m/w/d)

Posted: 2026-09-12T17:55:04Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**Bei Superchat gestalten wir neu, wie Unternehmen mit ihren Kund:innen kommunizieren. KI wird dabei immer mehr zum Motor dieser Kommunikation. Integrationen sind das, was diesem Motor echte Power gibt: die Daten, Tools und Systeme, die aus einem cleveren AI-Agenten einen machen, der Prozesse wirklich automatisiert und Probleme löst.**

Gegründet im Jahr 2020, ist Superchat heute die Plattform für über **10.000 Unternehmen weltweit** - von bekannten Marken wie Allianz, Auto1, Enpal, Danone und GASAG bis hin zu kleinen Unternehmen, Zahnarztpraxen und Solo-Founder:innen, die professioneller auftreten möchten.

Inzwischen laufen täglich **Millionen von Nachrichten** über Superchat.

Gestartet sind wir als Unified Inbox – ein zentraler Ort für alle Kommunikationskanäle wie WhatsApp, E-Mail, SMS oder Instagram. Mit dem Aufstieg von ChatGPT begann unser nächstes Kapitel: AI Agents, die über Chat, E-Mail und Voice in einer Qualität kommunizieren, die mit den besten menschlichen Teams mithalten kann.

Heute sind wir ein Team von rund **100 Mitarbeitenden**, arbeiten profitabel und haben insgesamt **18 Millionen Euro Funding** eingesammelt (unsere letzte Finanzierungsrunde liegt bereits 4,5 Jahre zurück – seitdem wachsen wir aus eigener Kraft weiter).

Unser Hauptsitz ist in Berlin.

*In dieser Rolle bist du verantwortlich für den gesamten Sales-Zyklus im DACH-Markt. Du bearbeitest warme Inbound-Anfragen und akquirierst gleichzeitig eigenständig neue Leads, vereinbarst und führst Demo-Termine durch und begleitest den gesamten Prozess bis zum erfolgreichen Abschluss. Darüber hinaus unterstützt du bei der technischen Implementierung, um sicherzustellen, dass neue Kund:innen erfolgreich starten.*

#### **Who We Want**

**2-3 Jahre B2B Sales Experience.
**Du hast bereits mehrere Jahre im B2B-Vertrieb gearbeitet und kennst den gesamten Sales-Zyklus von der Akquise bis zum Abschluss aus erster Hand.

**Self-Confident.
**Du glaubst an deine Fähigkeit, ein Gespräch zu führen und abzuschließen, ohne dabei arrogant zu wirken.

**Self-Starter.
**Du baust dir deine eigene Pipeline auf, statt auf eingehende Leads zu warten, und nutzt eine ruhige Woche, um noch aktiver zu prospektieren.

**Coachable.
**Du nimmst direktes Feedback an, ohne defensiv zu werden, und wendest es sichtbar im nächsten Gespräch an.

**Resilient.
**Du erholst dich schnell von einem verlorenen Deal oder einer schwierigen Woche und hältst deine Aktivität konstant hoch.

**Fast Learner.
**Du arbeitest dich schnell in ein technisches Produkt ein und kannst es Kund:innen verständlich erklären.

**Structured.
**Du hältst deine Pipeline sauber und deine CRM-Notizen zuverlässig, ohne dass man dir hinterherlaufen muss.

**Strong communicator.
**Du sprichst muttersprachliches Deutsch und verfügst über sehr gute Englischkenntnisse.

#### Who We Don’t Want

**Relies on leads being handed over.**
Du bist darauf angewiesen, dass Leads dir zugeteilt werden, und kannst oder willst nicht selbst aktiv Kund:innen akquirieren.

**Gets defensive with feedback.**
Du reagierst bei direktem Feedback defensiv, statt es anzunehmen und dich weiterzuentwickeln.

**Weak written communication.**
Du drückst dich schriftlich nicht klar und professionell aus.

**In it for the paycheck alone.**
Du jagst nur dem Gehalt hinterher und bringst kein echtes Interesse am Handwerk des Verkaufens mit.

#### Your Day To Day

Demos & Product Presentation (ca. 80%)

- Du überzeugst Prospects davon, an einer Produktpräsentation teilzunehmen, und vereinbarst entsprechende Termine

- Du präsentierst die Fähigkeiten von Superchat überzeugend und zeigst Kund:innen, wie das Produkt ihre konkreten Herausforderungen löst

Lead Sourcing & Prospecting (ca. 10%)

- Du generierst eigenständig neue Pipeline, unabhängig von eingehenden Leads, und identifizierst passende Zielkund:innen im DACH-Markt

Closing (ca. 10%)

- Du überzeugst Prospects davon, einen Vertrag zu unterschreiben, und führst den Sales-Zyklus erfolgreich zum Abschluss

#### Stakeholders

**Kund:innen:** deine wichtigste Ansprechgruppe im täglichen Austausch - von der ersten Ansprache über Demos bis zum Abschluss
**Sales Team:** für gemeinsames Training, Knowledge-Sharing und den Austausch von Best Practices im Sales-Zyklus
**Customer Success Team:** für die Übergabe nach erfolgreichem Abschluss und einen reibungslosen Start ins Onboarding

#### Why People Choose Us

- Wir glauben an Zusammenarbeit vor Ort: Wir sind gerne gemeinsam im Berliner Office. Genau dort entstehen die besten Ideen, Entscheidungen werden schneller getroffen, wir lernen voneinander und wachsen als Team enger zusammen. Etwas Flexibilität für Remote Work bieten wir, aber unser Default und unsere Energie liegen im gemeinsamen Office-Alltag

- Wir sind ein internationales Team mit unterschiedlichsten kulturellen Hintergründen und Sprachen - Offenheit, gegenseitiger Respekt und der Austausch verschiedener Perspektiven prägen unsere Zusammenarbeit

- Wir schätzen Ambition und Motivation - wir suchen Menschen, die Verantwortung übernehmen, Initiative zeigen und Lust haben, sich schnell weiterzuentwickeln

- Wir arbeiten mit hoher Eigenverantwortung und einer starken Lernmentalität - Fragen stellen, neugierig bleiben und sich kontinuierlich verbessern gehört bei uns dazu

- Wir legen Wert auf Humbleness und Teamgeist - no Ego, offenes Feedback und die Bereitschaft voneinander zu lernen sind uns wichtiger als Titel

**Benefits & culture**

- Du hast die Wahl zwischen einer Urban Sports Club/John Reed Mitgliedschaft oder Fahrkarten/Dance-Abo

- Regelmäßige Firmen- und Teamevents

- Jährliches Budget für persönliche Weiterbildung in Höhe von 500 € für zum Beispiel Konferenzen, Kurse, Bücher, Karrierecoach usw.

- Eine integrative und aufregende Start-up-Kultur, die schnelles berufliches und persönliches Wachstum ermöglicht

- Schönes Büro im Herzen von Berlin (Prenzlauer Allee 242) mit kostenlosen Snacks, Getränken und bester Ausstattung

**We want to build a community, not just a company.**

Uns ist wichtig, ein Umfeld zu schaffen, in dem Menschen wirklich gerne Zeit miteinander verbringen - egal ob beim HYROX-Training, Golfen, Beer-Pong-Turnieren, Running Clubs, Warhammer, gemeinsamen Wochenendaktivitäten oder welcher Community auch immer du hier aufbauen möchtest!

**Wir sind davon überzeugt, dass Diversität Unternehmen besser macht. Wir freuen uns über alle Bewerber:innen. Unabhängig von Gender, Herkunft, Nationalität oder Glaube. Fühl dich frei und schicke uns gerne deine Bewerbung!**

**Mit deiner Bewerbung stimmst du unseren Datenschutzrichtlinien zu.**

**Wir freuen uns auf deine Bewerbung! 🙂**

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
