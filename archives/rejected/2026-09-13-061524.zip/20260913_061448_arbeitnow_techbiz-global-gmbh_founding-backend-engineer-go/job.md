# Founding Backend Engineer(Go)

Posted: 2026-09-12T23:30:26Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

At TechBiz Global, we are providing recruitment service to our TOP clients from our portfolio. We are currently seeking a **Founding Backend Engineer(Go) **to join one of our **clients**' team in Berlin. If you're looking for an exciting opportunity to grow in a innovative environment, this could be the perfect fit for you.

**Key Responsibilities:**

-

Develop and maintain backend applications using Go

-

Design and optimize cloud-based solutions using AWS services (EC2, Lambda, S3, SQS, SNS, etc.)

-

Design, use and manage databases, including PostgreSQL, Neo4J, Redis, and Elasticsearch

-

Develop, manage, and optimize containerized applications using Docker

-

Automate processes using Bash/Python scripting

-

Optimize and maintain RESTful APIs, ensuring security and performance

-

Work closely with frontend engineers, DevOps, and product team to deliver robust applications

-

Monitor, debug, and improve backend performance, reliability, and scalability

-

Implement caching, messaging queues, and event-driven architectures where needed

-

Build whole platform from scratch

-

**5+ years **of** GoLang **experience

-

Hands-on coding mentality; **can build things from scratch and familiar with different architectures**

-

Hands-on experience with **Docker, Kubernetes** (EKS) and containerized workloads

-

Experience designing **RESTful** and **gRPC** APIs and using frameworks like **Gin**

-

Hands-on experience with messaging systems (e.g., **SQS**, **Kafka**)

-

Experience with **CI/CD pipelines** (GitHub Actions or similar)

-

Experience operating **PostgreSQL (RDS / Aurora), Neo4J(or similar)**

-

Experience with **AI agents**, LLM-based systems, MCP, RAG, Prompts, Embeddings, Vector, etc

-

Experience with **AI stack**(AWS Bedrock, LangChain, pgvector or similar)

-

Experience with **Infrastructure as Code** (Terraform)

-

Experience with **monitoring, logging, observability** (Grafana, OpenTelemetry, Prometheus)

-

Ability to **troubleshoot** production issues end to end

-

Experience with **Coding CoPilots**(Claude Code, GitHub Copilot, AWS CodeWhisperer, Codex, etc.)

-

Experience supporting **production SaaS platforms**

-

Strong understanding of **SaaS integrations** and app-to-app permission flows

-

High ownership mentality, startup mindset, and ability to move quickly

-

Experience in **startup or scale-up environments**

-

Low ego, high commitment, and a **true tech startup mentality**

-

Strong **problem-solving skills** and ability to work in a collaborative environment

-

Excellent **English** communication skills

**Nice-to-have requirements:**

-

Experience working with **Java**

-

Ability to code in **Python**

-

Experience with security architecture, identity security, or **security engineering**

-

Familiarity with **compliance frameworks** (NIS2, DORA, ISO 27001, SOC 2)

-

Experience with **AWS** in production environments

-

Exposure to **graph-based modeling** (identity graph, access graph, risk graph)

-

Familiarity with **compliance frameworks** (NIS2, DORA, ISO 27001, SOC 2)

-

Understanding of **OAuth/OIDC, API tokens, IdP, scopes, SSO, SCIM, roles, RBAC/ABAC, service accounts**

-

Familiarity with cloud identity and security controls (e.g. **IAM, CloudTrail, Azure Active Directory / Entra ID**)

-

Hands-on with SIEM platforms such as **Splunk, Microsoft Sentinel, or IBM QRadar**

-

Experience designing **permission models, identity graphs, or access control frameworks**

-

Knowledge of tokenization, **Zero Trust principles**, least privilege, and continuous verification

-

Experience with Security related to **AI/LLM systems, agent logic, or willingness to learn fast**

-

Familiarity with **AI agent behavior**, LLM security, or agent sandboxing

-

Previous experience in **cybersecurity**, identity startups

-

You are a fan of **rock or metal** music

-

Excellent **German** communication skills

**Benefits:**

-

**Founding Team Member Equity** — ESOPs in a cybersecurity company

-

**Competitive Compensation** — salary aligned with market, flexible early-stage arrangements possible

-

**Founding Team Member Status** — shape the company from day one and own critical technical decisions

-

**Fresh Funding Secured** — immediate runway to build, hire, and execute fast

-

**Security Contribution** — contribute to security architecture across identity, AI agents, and enforcement

-

**High Autonomy** — freedom to design and build without corporate overhead

-

**Work with a Technical CEO and CPTO** — fast iteration, strong alignment, clear direction

-

**Cutting-Edge Domain** — identity security, SaaS-to-SaaS access, AI agent governance

-

**Massive Learning Curve** — quickly gain depth in cybersecurity, identity, and AI systems

-

**Fast Career Path** — opportunity evolve into leadership as we scale the engineering team

-

**Berlin Location** — top-tier tech environment with strong cybersecurity and AI ecosystems

-

**Direct Impact** — your architecture and code become the foundation of the entire platform

-

**Best Equipment and Tools** - High quality equipment and modern tools to help you do your best work from day one

-

**Team Offsites - **Regular team offsites designed to build strong connections, alignment, and shared momentum

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
