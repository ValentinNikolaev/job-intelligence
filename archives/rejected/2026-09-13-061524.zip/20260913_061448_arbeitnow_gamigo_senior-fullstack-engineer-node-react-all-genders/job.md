# (Senior) Fullstack Engineer - Node / React (all genders)

Posted: 2026-09-12T20:20:22Z

## Rejection

- Category: tech_stack
- Reason: role does not mention Go/Golang or PHP

To strengthen our team, gamigo group is looking for a Senior Fullstack Engineer (all genders) to join as soon as possible, full-time, based in Germany.

**About the role**

As a Senior Fullstack Engineer, you will build and evolve our casual gaming eCommerce platform end-to-end, driving technical direction with broad expertise across web and cloud systems.

- Actively shape and evolve our code structure and architecture, and drive technical decisions forward
- Design and implement new features for our casual eCommerce platforms, from architecture through deployment andmonitoring
- Build performant, reliable and secure backend services with Node.js, TypeScript and NestJS
- Develop frontends with Next.js and React, optimized for page speed and SEO
- Ensure high availability and performance of our production systems
- Improve observability, code quality and code structure
- Mentor colleagues, review code and share knowledge across the team
- Suggest new ideas to improve our products for our customers
- Identify technical risks and obstacles early, and take ownership of solving them

**Requirements**

- Bachelor's degree in Software Engineering, Computer Science or equivalent professional experience
- Senior engineering experience with RESTful APIs and single page applications
- Proven track record of driving architecture and code structure in a production system
- Strong experience with Node.js and TypeScript, including NestJS
- Solid experience with Next.js and React
- Experience with Google Cloud or comparable cloud infrastructure (e.g. Cloud Run or similar container platforms)
- Good knowledge of PostgreSQL or another SQL database, and TypeORM or another ORM
- Experience optimizing web pages for speed and SEO
- Ability to work independently, set priorities and move topics forward with little supervision
- Excellent critical and analytical skills
- Strong written and verbal English communication skills
- Comfortable working in an agile environment with common Scrum ceremonies

**What would be a plus**

- Experience with GitLab CI/CD or comparable pipelines
- Experience with observability tooling (OpenTelemetry, tracing, metrics, logging)
- Experience with eCommerce or payment/subscription integrations
- Knowledge of containers (e.g. Docker) and Kubernetes
- Written and verbal German communication skills

**Benefits**

Choose from a wide range of perks through our **flexible benefits system** that fit your lifestyle: subsidies for your public transport pass, bike rental, internet bill, gym memberships, or services like HelloFresh, Etepetete, and more!

- Contributions to your company pension scheme and disability insurance to keep you covered long-term
- Access to NILO, our health care platform, supporting your physical and mental well-being
- Enjoy exclusive employee discounts – because we value your hard work!
- Wear what makes you feel comfortable: our dress code is casual
- Enjoy up to 5 weeks of Workcation per year – work remotely from inspiring locations around the world!
- Be part of an international team with like-minded colleagues from over 30 countries – diversity and shared goals included!
- Regular team events and company parties to keep the fun going.
- Challenging tasks with real responsibility and the freedom to grow in our dynamic environment.

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
