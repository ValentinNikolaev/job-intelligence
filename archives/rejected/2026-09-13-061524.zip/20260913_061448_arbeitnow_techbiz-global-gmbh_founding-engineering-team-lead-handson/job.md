# Founding Engineering Team Lead (HandsOn)

Posted: 2026-09-12T23:30:26Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

At TechBiz Global, we are providing recruitment service to our TOP clients from our portfolio. We are currently seeking a **Founding Engineering Team Lead **to join one of our **clients**' team in Berlin. If you're looking for an exciting opportunity to grow in a innovative environment, this could be the perfect fit for you.

**Key Responsibilities:**

-

Lead and grow a small, high-performing engineering team while remaining hands-on

-

Design, build, and review production backend and platform code alongside the team

-

Own delivery of the engineering roadmap, balancing speed, quality, and security

-

Act as a technical leader by setting architecture direction and enforcing engineering standards

-

Contribute directly to critical features, integrations, and platform foundations

-

Establish lightweight engineering processes that enable fast execution without bureaucracy

-

Mentor engineers through code reviews, pairing, and technical guidance

-

Contribute hands-on in design and build architecture, configure systems, code 70% of the time in GoLang.

-

Remove blockers and unblock delivery across backend, frontend, data, and DevOps

-

Collaborate closely with CEO, CPTO, and product leadership on technical and execution decisions

-

Support hiring, onboarding, and technical evaluation of engineers

-

Foster a culture of ownership, pragmatism, and low ego

-

Build whole Security platform setup from scratch

-

Partner closely with backend and AI engineers to design secure service boundaries and deployment models

-

Troubleshoot and resolve complex production incidents across infrastructure, networking, and application layers

-

Build PoCs and validate infrastructure and security design decisions in an early-stage environment

-

Support compliance readiness by enabling controls, logging, and evidence collection for security frameworks

-

Continuously improve platform cost efficiency, reliability, and operational maturity

-

This role reports directly to CEO & CPTO

**Must have skills:**

-

**10+ years** of professional software engineering experience

-

**3+ years** of experience leading engineering teams **while remaining hands-on**

-

**3+ years **of** GoLang **experience

-

**3+ years **experience with **AWS** in production environments

-

Strong **code quality** bar and experience with architectural reviews

-

Ability to context-switch between technical **topics and people leadership**

-

Strong execution mindset and comfort operating under **ambiguity**

-

Hands-on coding mentality; **can build things from scratch **including security architecture yourself

-

Hands-on experience with **Docker, Kubernetes** (EKS) and containerized workloads

-

Experience with **CI/CD pipelines** (GitHub Actions or similar)

-

Experience with **monitoring, logging, observability** (Grafana, OpenTelemetry, Prometheus)

-

Experience with **Coding CoPilots **(Claude Code, GitHub Copilot, AWS CodeWhisperer, Codex, etc.)

-

Knowledge of Experience supporting **production SaaS platforms**

-

High ownership mentality, startup mindset, and ability to **move quickly**

-

Experience in **startup or scale-up environments**

-

Low ego, high commitment, and a **true tech startup mentality**

-

Excellent **English** communication skills

**Nice-to-have requirements:**

-

Previous experience as a founding or **early-stage** Engineering Manager

-

Experience in **cybersecurity**, identity, or enterprise SaaS platforms

-

Exposure to **DevOps, SRE, or data engineering**

-

Experience **scaling teams** and systems simultaneously

-

Experience with security architecture, identity security, or **security engineering**

-

Familiarity with **compliance frameworks** (NIS2, DORA, ISO 27001, SOC 2)

-

Understanding of **OAuth/OIDC, API tokens, IdP, scopes, SSO, SCIM, roles, RBAC/ABAC, service accounts**

-

Familiarity with cloud identity and security controls (e.g. **IAM, CloudTrail, Azure Active Directory / Entra ID**)

-

Hands-on with SIEM platforms such as **Splunk, Microsoft Sentinel, or IBM QRadar**

-

Experience designing **permission models, identity graphs, or access control frameworks**

-

Knowledge of tokenization, **Zero Trust principles**, least privilege, and continuous verification

-

Experience with Security related to **AI/LLM systems, agent logic, or willingness to learn fast**

-

Familiarity with **AI agent behavior**, LLM security, or agent sandboxing

-

Previous experience in **cybersecurity**, identity startups

-

You are a fan of **rock or metal** music

-

Excellent **German** communication skills

**Benefits:**

-

**Founding Team Member Equity** — ESOPs in a well funded cybersecurity company.

-

**Competitive Compensation** — salary aligned with market, flexible early-stage arrangements possible.

-

**Founding Team Member Status** — shape the company from day one and own critical security technical decisions.

-

**Fresh Funding Secured** — immediate runway to build, hire, and execute fast.

-

**Security Contribution** — contribute to security tech architecture across identity, AI agents, and enforcement.

-

**High Autonomy** — freedom to design and build without corporate overhead.

-

**Work with a Technical CEO and CPTO** — fast iteration, strong alignment, clear direction.

-

**Cutting-Edge Domain** — identity security, SaaS-to-SaaS access, AI agent governance.

-

**Massive Learning Curve** — quickly gain depth in cybersecurity, identity, and AI systems.

-

**Fast Career Path** — opportunity evolve into higher leadership as we scale the engineering team

-

**Berlin Location** — top-tier tech environment with strong cybersecurity and AI ecosystems.

-

**Direct Impact** — your architecture and code become the foundation of the entire platform.

-

**Best Equipment and Tools** - High quality equipment and modern tools to help you do your best work from day one.

-

**Team Offsites - **Regular team offsites designed to build strong connections, alignment, and shared momentum.

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
