# Freelance Senior Product Manager / Product Consultant (w/m/d) – Abrechnung & ERP | Remote

Posted: 2026-09-12T23:30:07Z

## Rejection

- Category: tech_stack
- Reason: role does not mention Go/Golang or PHP

**Du möchtest ein klar definiertes Produktprojekt übernehmen, komplexe Fachprozesse strukturieren und Anforderungen in konkrete Produktlösungen für eine eigens entwickelte ERP-Software übersetzen? Dann suchen wir Dich für ein freiberufliches Projektmandat als:**

**Freelance Product Manager (w/m/d) - Abrechnung & ERP - 3 bis 6 Monate

**Die **Arsipa Gruppe** ist eine schnell wachsende Unternehmensgruppe im Bereich Health, Safety & Environment, unterstützt von Warburg Pincus. Mit über 1.000 Mitarbeitenden, 20+ Tochtergesellschaften und 48 Standorten in Deutschland und Österreich bauen wir im Rahmen einer klaren Buy-&-Build-Strategie eine skalierbare Plattform mit nachhaltiger Wertschöpfung. Unser Ziel: eine der führenden Anbieterinnen im deutschsprachigen Markt - unterstützt durch zentrale Funktionen wie Finance, HR, Marketing und IT am Standort Berlin.

**Das Projekt:**

Für die Weiterentwicklung unserer Softwarelösung ginisuite suchen wir freiberufliche Unterstützung für ein zeitlich befristetes Produktprojekt. Der Projektstart ist zum **01.10.2026** vorgesehen. Die geplante Projektlaufzeit beträgt zunächst **drei bis sechs Monate**.

Die ginisuite ist unsere eigens entwickelte ERP-/PVS-Lösung für Arbeitsmedizin und Arbeitssicherheit. Im Fokus des Projekts steht die fachliche und produktseitige Weiterentwicklung ausgewählter Module in den Bereichen **Vertragsmanagement, Abrechnung, Zeiterfassung und Buchhaltung**.

Zu den Projektinhalten gehören die Analyse bestehender Fachprozesse, die Entwicklung geeigneter Lösungskonzepte sowie die Übersetzung fachlicher Anforderungen in umsetzbare User Stories und Tickets. Darüber hinaus umfasst das Mandat die fachliche Begleitung ausgewählter Themen bis zur Qualitätssicherung, Veröffentlichung, Datenmigration und Einführung.

Die Zusammenarbeit erfolgt grundsätzlich **remote innerhalb Deutschlands** auf freiberuflicher Basis mit eigenverantwortlicher Zeiteinteilung und klar vereinbarten Projektergebnissen. Bei Bedarf können einzelne projektbezogene Termine innerhalb Deutschlands erforderlich sein, voraussichtlich etwa einmal pro Monat und nach vorheriger Abstimmung.

**Dein Projektinhalte:**

**Fachliche Konzeption und Produktentwicklung**

-

Analyse bestehender Prozesse und Systemlandschaften in den Bereichen Vertragsmanagement, Abrechnung, Zeiterfassung und Buchhaltung

-

Identifikation und Priorisierung fachlicher Optimierungspotenziale auf Grundlage der vereinbarten Projektziele

-

Entwicklung geeigneter Lösungsansätze und konkreter Empfehlungen für die Weiterentwicklung ausgewählter ginisuite-Module

-

Erstellung nachvollziehbarer Fachkonzepte, User Stories, Akzeptanzkriterien und Tickets als Grundlage für die technische Umsetzung

-

Übersetzung komplexer fachlicher Anforderungen in klare und umsetzbare Produktentscheidungen

** Umsetzungs- & Rolloutbegleitung**

-

Fachliche Begleitung der im Projekt vereinbarten Entwicklungspakete

-

Vorbereitung und Durchführung fachlicher Qualitätssicherungen

-

Projektbezogene Unterstützung bei Release-Vorbereitungen, Datenmigrationen und Rollouts

-

Dokumentation der erarbeiteten Konzepte, Entscheidungen und Projektergebnisse

-

Strukturierte Übergabe der vereinbarten Ergebnisse an die zuständigen Ansprechpartner:innen bei Arsipa

**Projektbezogene Abstimmung**

-

Selbstständige Planung und Umsetzung der eigenen Projektaktivitäten innerhalb des vereinbarten Zeitraums

-

Projektbezogene Abstimmung mit dem Lead Product Manager, dem CTO und weiteren relevanten Ansprechpartner:innen

-

Aufnahme fachlicher Anforderungen ausgewählter Tochtergesellschaften

-

Fachlicher Austausch mit dem Entwicklungsteam sowie internen und externen Projektbeteiligten, beispielsweise aus dem Data-Warehouse-Umfeld

-

Transparente Abstimmung zu Projektfortschritt, Ergebnissen, Abhängigkeiten und fachlichen Entscheidungsbedarfen

-

Einbringung eigener methodischer Ansätze und fachlicher Empfehlungen

**Dein Profil:**

-

Fundierte Erfahrung als Product Manager:in, Product Owner:in, Product Consultant oder in einer vergleichbaren produktbezogenen Projektfunktion

-

Nachweisbare Projekterfahrung in den Bereichen Rechnungswesen, ERP, Abrechnung oder vergleichbaren B2B-Softwarelösungen

-

Erfahrung in der Analyse komplexer Fachprozesse und deren Übersetzung in konkrete Produktanforderungen

-

Sicherer Umgang mit User Stories, Tickets, Akzeptanzkriterien und fachlichen Produktkonzepten

-

Technisches Verständnis in den Bereichen Datenmigration, Datenanalyse und Softwareentwicklung

-

Sehr gute Deutsch- und Englischkenntnisse

-

Selbstständige, strukturierte und ergebnisorientierte Arbeitsweise

**Hilfreich für das Projekt sind außerdem:**

-

Erfahrung in SaaS-, Plattform- oder ERP-nahen Projekten

-

Kenntnisse cloudbasierter Plattformen, APIs, Integrationen oder verteilter Systeme

-

Verständnis für Softwarearchitektur, Microservices oder containerbasierte Systemlandschaften

-

Erfahrung im Umgang mit Legacy-Systemen und Migrationen zwischen Bestands- und Zielsystemen

-

Projekterfahrung in Multi-Entity-, Private-Equity-, Buy-&-Build- oder vergleichbaren Wachstumsumfeldern

-

Kenntnisse in den Bereichen Occupational Health & Safety, Arbeitsmedizin oder Arbeitssicherheit

-

Interim-, Freelancer- oder Beratungserfahrung im Product-Management-Umfeld

**Rahmenbedingungen des Projekts:**

-

Freiberufliche Zusammenarbeit auf Projektbasis

-

Projektstart zum **01.10.2026**

-

Geplante Projektlaufzeit von zunächst **drei bis sechs Monaten**

-

Voraussichtlicher Projektumfang von ca. **30 bis 40 Stunden pro Woche**

-

Remote innerhalb Deutschlands mit eigenverantwortlicher Zeiteinteilung

-

Einzelne projektbezogene Termine innerhalb Deutschlands können bei Bedarf und nach vorheriger Abstimmung erforderlich sein

-

Vergütung auf Basis eines individuell vereinbarten Stunden- oder Tagessatzes gegen Rechnungsstellung

-

Zusammenarbeit auf Basis klar definierter Projektziele und Projektergebnisse, nicht im Rahmen einer Festanstellung

**Was Dich bei diesem Projekt erwartet:**

-

**Klar definiertes Produktmandat:** Ein zeitlich befristetes Projekt mit konkretem Fokus auf die Weiterentwicklung ausgewählter ERP- und Abrechnungsmodule

-

**Remote und flexible Umsetzung:** Die Projektleistung kann grundsätzlich remote erbracht und zeitlich eigenverantwortlich organisiert werden

-

**Relevanter Gestaltungsspielraum:** Du entwickelst eigene fachliche Lösungsansätze und bringst Deine Produkt- und Projekterfahrung gezielt ein

-

**Direkter Zugang zu relevanten Informationen:** Für eine effiziente Projektumsetzung erhältst Du die erforderlichen Informationen zu Fachprozessen, Systemen und Projektzielen

-

**Anspruchsvolles Technologieumfeld:** Das Projekt verbindet ERP, Abrechnung, Datenmigration, Softwareentwicklung und operative Fachprozesse

-

**Dynamisches Wachstumsumfeld:** Die ginisuite ist Teil einer PE-backed Buy-&-Build-Plattform mit zahlreichen Gesellschaften und unterschiedlichen fachlichen Anforderungen

-

**Professionelle Projektzusammenarbeit:** Dich erwarten klare Ansprechpartner:innen, strukturierte Abstimmungen und gemeinsam definierte Projektergebnisse

**Unser Auswahlprozess:**

In einem fachlichen Austausch besprechen wir Deine relevante Projekterfahrung, Verfügbarkeit, mögliche Projektkapazität, Arbeitsweise und Honorarvorstellung. Außerdem erhältst Du weitere Informationen zum Projektkontext, zur ginisuite und zu den angestrebten Projektergebnissen.

**Bitte sende uns für die erste Einschätzung:**

-

Dein aktuelles Freelancer-Profil

-

Deine Verfügbarkeit ab dem 01.10.2026

-

Deine mögliche Projektkapazität

-

Deinen gewünschten Stunden- oder Tagessatz

-

Relevante Referenzprojekte, insbesondere im ERP-, Abrechnungs- oder B2B-Softwareumfeld

Für weitere Fragen stehen wir Dir gerne jederzeit zur Verfügung!
Du erreichst das Group Talent-Acquisition-Team der Arsipa-Gruppe unter **.**

**Werde Teil unserer spannenden Reise bei der Arsipa Gruppe - Wir freuen uns auf Dich!**

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
