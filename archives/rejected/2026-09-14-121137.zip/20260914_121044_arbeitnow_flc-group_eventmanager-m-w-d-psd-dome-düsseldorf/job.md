# Eventmanager (m/w/d)-PSD Dome Düsseldorf

Posted: 2026-09-14T10:31:04Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Eventmanager (m/w/d) – PSD Dome Düsseldorf

Sie lieben Events, haben aber genug davon, dass in letzter Minute alles über den Haufen geworfen wird? Von unklaren Zuständigkeiten zwischen Technik, Catering und Sicherheit, spontanen Sonderwünschen der Veranstalter und dem Gefühl, immer als Einzelkämpfer die Fäden zusammenhalten zu müssen?

Im PSD Dome arbeiten Sie anders. Als feste Spielstätte von Fortuna Düsseldorf und Location für Konzerte, Firmenevents und Sonderveranstaltungen laufen bei uns Prozesse nach klaren Abläufen: eingespielte Partner, definierte Zuständigkeiten und ein Team, das an Veranstaltungstagen Hand in Hand arbeitet. Der Fokus liegt auf einer sauberen, vorausschauenden Planung – nicht auf ständigem Improvisieren unter Zeitdruck.

Was Sie bei uns erwartet, ist eine Aufgabe mit sichtbarem Ergebnis: Sie sorgen dafür, dass Tausende Besucher:innen an Spiel- und Veranstaltungstagen ein rundes Erlebnis haben – von der ersten Planung bis zum letzten Handgriff vor Ort. Das gibt der Arbeit einen Sinn, den man in kleineren Eventformaten oft vermisst.

Wenn Sie Ihre Erfahrung mit Struktur, Ruhe und Verantwortung für große Veranstaltungen einbringen möchten, freuen wir uns auf Sie.

Wir von FLC-GROUP stehen für professionelle Abläufe, frische Küche und echte Leidenschaft für gute Veranstaltungen. Als Arbeitgeber für den PSD Dome in Düsseldorf verantworten wir Catering, Gastronomie und Event-Organisation rund um Spiel- und Veranstaltungstage.

Für den PSD Dome suchen wir ab sofort einen engagierten Eventmanager (m/w/d), der mit Erfahrung, Organisationstalent und Teamgeist unser Team verstärkt.

Bei uns arbeiten Sie in einem dynamischen Umfeld mit klaren Abläufen, einem eingespielten Team und abwechslungsreichen Aufgaben rund um Sport-, Konzert- und Firmenevents.

Wir freuen uns ausdrücklich über Bewerbungen von Menschen unabhängig von Geschlecht, Herkunft, Alter, Religion oder einer Behinderung. Vielfalt und gegenseitiger Respekt sind für uns selbstverständlich.

## Aufgaben

-Planung, Koordination und Durchführung von Veranstaltungen im PSD Dome (Spieltage, Konzerte, Firmen- und Sonderevents)

-Zentrale/r Ansprechpartner/in für Veranstalter, Dienstleister und interne Abteilungen (Catering, Technik, Sicherheit, Reinigung)

-Erstellung und Überwachung von Ablauf- und Zeitplänen sowie Budgets für einzelne Veranstaltungen

-Steuerung externer Dienstleister und Partner vor, während und nach Events

-Sicherstellung eines reibungslosen Ablaufs vor Ort inklusive Nachbereitung und Auswertung

-Enge Abstimmung mit dem Team, um Standards und Prozesse kontinuierlich zu verbessern

## Qualifikation

-Abgeschlossene Ausbildung oder Studium im Bereich Eventmanagement, Veranstaltungswirtschaft, Hotellerie/Gastronomie oder vergleichbare Qualifikation

Berufserfahrung in der Organisation von Veranstaltungen, idealerweise im Sport-, Konzert- oder Messebereich

-Organisationstalent, Belastbarkeit und Ruhe auch bei hohem Besucheraufkommen

-Kommunikationsstärke im Umgang mit Veranstaltern, Dienstleistern und Kolleg:innen

-Bereitschaft zu Arbeitszeiten an Wochenenden und Abenden, abhängig vom Veranstaltungskalender

-Sicherer Umgang mit MS Office; Führerschein Klasse B von Vorteil

## Benefits

- Eine verantwortungsvolle Position an einer der bekanntesten Veranstaltungslocations in Düsseldorf

- Ein strukturiertes Arbeitsumfeld mit kurzen Entscheidungswegen und einem eingespielten Team

- Raum für eigene Ideen und die Weiterentwicklung von Prozessen und Standards

Haben wir Ihr Interesse geweckt? Dann freuen wir uns auf Ihre Bewerbung.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
