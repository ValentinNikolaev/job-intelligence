# Senior KI-Experte / AI & Automation (m/w/d) | Ab sofort | Vollzeit

Posted: 2026-09-14T07:20:11Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Standort: Kiefersfelden / Oberbayern
Ab sofort | Vollzeit | Direktes Reporting an die Geschäftsführung

**Gestalte mit uns die Zukunft der KI bei tempLED**

tempLED entwickelt, produziert und montiert intelligente LED-Beleuchtungslösungen für Industrie, Gewerbe und Logistik. Als mittelständisches Technologieunternehmen möchten wir den nächsten Schritt gehen und Künstliche Intelligenz konsequent in unsere Produkte, Services und internen Prozesse integrieren.

Dafür suchen wir keine klassische IT-Position.

Wir suchen eine erfahrene Persönlichkeit, die gemeinsam mit unserer Geschäftsführung die KI-Aktivitäten bei tempLED aufbaut, konkrete Anwendungen entwickelt und neue Ideen schnell in die Praxis bringt.

**Deine Aufgaben**

Du identifizierst gemeinsam mit den Fachbereichen die größten Potenziale für den Einsatz von KI und setzt daraus konkrete Lösungen um. Dazu gehören insbesondere:

· Aufbau einer langfristigen und praxisorientierten KI-Strategie für tempLED

· Analyse, Entwicklung und Umsetzung KI-gestützter Prozessautomatisierungen

· Integration von LLMs und intelligenten Assistenzsystemen in bestehende Arbeitsabläufe

· Konzeption neuer KI-Funktionen und digitaler Services rund um unsere Produkte

· Auswahl und Integration geeigneter KI-Tools, Plattformen, APIs und Technologien

· Entwicklung von Prototypen und deren Überführung in produktiv nutzbare Lösungen

· Enge Zusammenarbeit mit der Geschäftsführung und den Abteilungsleitern bei der Priorisierung und Umsetzung neuer KI-Initiativen

**Was du mitbringst**

Entscheidend ist für uns nicht der perfekte Lebenslauf, sondern dass du Technologie verstehst und daraus funktionierende Lösungen entwickeln kannst.

Idealerweise bringst du mit:** **

• mehrjährige Erfahrung in Softwareentwicklung, KI, Automatisierung oder einem vergleichbaren technischen Umfeld

• praktische Erfahrung mit modernen KI-Technologien und LLMs

• Erfahrung mit APIs, Datenverarbeitung, Automatisierungsplattformen und der Integration unterschiedlicher Systeme

• gutes Verständnis moderner Softwarearchitekturen und digitaler Prozesse

• die Fähigkeit, eigenständig Prototypen und Lösungen zu entwickeln

• Erfahrung darin, technische Möglichkeiten in konkrete wirtschaftliche Anwendungen zu übersetzen

• analytisches und unternehmerisches Denken sowie eine ausgeprägte Hands-On-Mentalität

• Strukturierte, selbständige und zuverlässige Arbeitsweise sowie Freude daran, mit vielen Schnittstellen zusammenzuarbeiten

• Erfahrung aus der Automobil-, Software-, Entwicklungs- oder Technologiebranche ist für uns besonders interessant.

**
**

**Was dich bei tempLED erwartet**

Bei uns bekommst du die Möglichkeit, das Thema KI von Anfang an entscheidend mitzugestalten. Du arbeitest direkt mit der Geschäftsführung, hast kurze Entscheidungswege und erhältst den notwendigen Freiraum, um aus Ideen funktionierende Lösungen zu machen.

**

Dich erwarten**

• Vergünstigungen im Kaiserreich in Kiefersfelden (u.a. Rabatte für Gym-Mitgliedschaft)

• Ergonomische und moderne Büroausstattung

• Flexible Arbeitszeiten

• Weiterbildungsmöglichkeiten

• Regelmäßig stattfindende Teamevents

• Kostenfreie, großzügige Auswahl an Getränken und Snacks

• Tatsächliches Mitwirken, die Industrie in Europa ein Stückchen grüner zu gestalten

**
**

**Interesse?**

Du möchtest KI nicht nur beobachten oder darüber sprechen, sondern konkret einsetzen und damit ein Unternehmen verändern? Dann möchten wir dich kennenlernen. Wir freuen uns auf ein unverbindliches und vertrauliches Gespräch. Sende deine Bewerbungsunterlagen, inkl. Gehaltsvorstellung und frühestem Starttermin gerne an Frau Tiziana Ricco.

**Tiziana Ricco**

Human Resources

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
