# Regional Marketing Manager (m/w/d)

Posted: 2026-09-14T09:30:31Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**Du denkst nicht nur bis zum Regal – sondern bis zum Kunden.**

Marketing kann schöne Bilder produzieren.

Du weißt aber: Gute Arbeit entsteht dann, wenn Produkte, Märkte, Kunden und Vertrieb wirklich zusammenkommen.

Genau hier kommst du ins Spiel.

Bei Simpson Strong-Tie entwickeln wir Lösungen, die dabei helfen, Gebäude sicherer, stärker und langlebiger zu machen. Hinter unseren Produkten steckt jede Menge Engineering, Know-how und der Anspruch, Dinge kontinuierlich besser zu machen.

## Aufgaben

Damit aus starken Ideen und durchdachten Lösungen echte Markterfolge werden, suchen wir dich als **Regional Marketing Manager (m/w/d)**.

Du übernimmst eine Schlüsselrolle zwischen **Produktmanagement, Marketing und Vertrieb** – und bekommst den Raum, Themen nicht einfach nur zu verwalten, sondern aktiv weiterzuentwickeln.

**Was dich bei uns erwartet**

Du bist nicht „nur Marketing“.

Du bist auch nicht „nur Produktmanagement“.

Du verbindest beides.

Gemeinsam mit deinem Team, dem Vertrieb und unseren europäischen Kolleginnen und Kollegen entwickelst du Ideen und Maßnahmen, die unsere Produkte und unsere Marke im deutschen Markt nach vorne bringen.

Konkret bedeutet das:

- Du entwickelst unsere lokale Produkt- und Marketingstrategie weiter und machst daraus konkrete Maßnahmen.

- Du behältst unser Produktportfolio im Blick, erkennst Potenziale und bringst neue Produkte erfolgreich in den Markt.

- Du entwickelst Go-to-Market-Pläne, Kampagnen und Kommunikationsmaßnahmen, die nicht nur gut aussehen, sondern Wirkung zeigen.

- Du arbeitest eng mit Sales zusammen und sorgst dafür, dass Marketing und Vertrieb wirklich an einem Strang ziehen.

- Du verantwortest Trade-Marketing-Aktivitäten – von Aktionen und Events bis hin zu Messen und kundenorientierten Maßnahmen.

- Du entwickelst unsere Markenkommunikation über verschiedene Touchpoints hinweg weiter.

- Du arbeitest mit externen Agenturen und Partnern zusammen und steuerst Projekte eigenverantwortlich.

- Du planst und verantwortest dein Budget.

- Du führst und entwickelst dein Team und schaffst ein Umfeld, in dem gute Ideen entstehen können.

- Du bist Teil eines internationalen Netzwerks und arbeitest eng mit unseren europäischen Teams zusammen.

Kurz gesagt: **Du verbindest Strategie mit Umsetzung und Ideen mit Wirkung.**

## Qualifikation

**Was du mitbringen solltest**

Du musst nicht in jede einzelne Box passen.

Aber du solltest Lust darauf haben, Verantwortung zu übernehmen und Dinge voranzutreiben.

Idealerweise bringst du mit:

- Mindestens drei Jahre Führungserfahrung und mehrjährige Erfahrung im Produktmanagement, Marketing oder in einer vergleichbaren Schnittstellenfunktion.

- Erfahrung darin, Produkte und Marken strategisch weiterzuentwickeln und gleichzeitig operativ ins Doing zu kommen.

- Ein gutes Verständnis für Märkte, Kunden und Vertriebsstrukturen.

- Erfahrung mit Go-to-Market-Strategien, Produkteinführungen und Marketingkampagnen.

- Ein analytisches Mindset und die Fähigkeit, aus Daten und Marktinformationen gute Entscheidungen abzuleiten.

- Freude an Zusammenarbeit über Abteilungs- und Ländergrenzen hinweg.

- Sehr gute Kommunikationsfähigkeiten und die Fähigkeit, unterschiedliche Menschen für eine Idee zu gewinnen.

- Ein Studium oder eine vergleichbare Qualifikation im Bereich Marketing, Wirtschaft, Engineering oder einem ähnlichen Umfeld.

- Hervorragende Deutsch- und Englischkenntnisse

Erfahrung in der Bau-, Handwerks- oder Industriebranche ist hilfreich – aber nicht alles.

**Entscheidend ist für uns, dass du neugierig bist, Zusammenhänge verstehst und Lust hast, etwas zu bewegen.**

## Benefits

**Was dich bei Simpson Strong-Tie erwartet**

Wir sind ein internationales Unternehmen mit einer klaren Mission: Lösungen entwickeln, die das Bauen sicherer und besser machen.

Und gleichzeitig sind wir überzeugt: Gute Ergebnisse entstehen nicht durch starre Hierarchien oder endlose Abstimmungsschleifen.

Sondern durch Menschen, die Verantwortung übernehmen dürfen.

Die Fragen stellen.

Die Ideen haben.

Und die den Mut haben, Dinge auch einmal anders zu machen.

Bei uns erwartet dich:

**Raum für Gestaltung**

Du übernimmst eine Rolle mit echtem Einfluss auf Produkt, Marke und Marktentwicklung.

**Ein starkes Team**

Du arbeitest mit Menschen zusammen, die ihr Handwerk verstehen – im Marketing genauso wie im Vertrieb, Produktmanagement und Engineering.

**Internationales Umfeld**

Du bist lokal nah am Markt und gleichzeitig Teil eines europäischen und globalen Netzwerks.

**Produkte mit Substanz**

Wir verkaufen keine kurzfristigen Trends. Unsere Lösungen tragen dazu bei, Gebäude und Konstruktionen sicherer und stärker zu machen.

**Entwicklung statt Stillstand**

Wir wollen besser werden – als Unternehmen und als Menschen. Deshalb bekommst du die Möglichkeit, Verantwortung zu übernehmen und dich weiterzuentwickeln.

**Klingt nach deinem nächsten Schritt?**

Dann freuen wir uns darauf, dich kennenzulernen.

Egal, ob dein Lebenslauf exakt diesem Profil entspricht oder dein Weg etwas anders aussieht: Wenn du denkst, dass du mit deiner Erfahrung, deiner Energie und deinen Ideen gut zu uns passt, dann bewirb dich.

**Let’s build something stronger. Together.**

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
