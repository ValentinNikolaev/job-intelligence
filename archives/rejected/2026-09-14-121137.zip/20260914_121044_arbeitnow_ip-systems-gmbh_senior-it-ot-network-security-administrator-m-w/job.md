# Senior IT-/OT Network & Security Administrator (m/w/d), Ref. 1380

Posted: 2026-09-14T10:00:31Z

## Rejection

- Category: tech_stack
- Reason: role does not mention Go/Golang or PHP

**IP Systems GmbH**

- **Gründung & Fokus:** 1999 gegründete Ingenieur- und Beratungsgesellschaft mit Schwerpunkt Telekommunikation und IT

- **Kunden:** Telekommunikation, Medien & Rundfunk, Transport & Logistik sowie öffentlicher Sektor

**Leistungen:**

- Fach- und Projektmanagement-Unterstützung

- Produkt- und Technologieeinführung

- Programm- und Projektsteuerung

- IT Security Services

- Professional Services sowie Programm- und Projektmanagement (klassisch, agil, hybrid)

**Kompetenz & Ansatz:**

- Multidisziplinäre Teams aus erfahrenen Ingenieuren, Informatikern und Wirtschaftsexperten

- Praxisnah, pragmatisch und lösungsorientiert

- Begleitung über den gesamten Lifecycle: von Konzeption und Einführung bis Implementierung und Betrieb

## Aufgaben

- Administration, Konzeption und Weiterentwicklung von IT- und OT-Infrastrukturen in industriellen Umgebungen

- Administration und Implementierung von Firewalls verschiedener Hersteller, insbesondere Cisco, Fortinet, Sophos, Stormshield und Hirschmann

- Administration und Optimierung von IT-/OT-Netzwerken auf Basis von Cisco, Hirschmann, LANCOM, Huawei und weiteren Netzwerkkomponenten

- Konzeption und Implementierung von OT-Netzwerkarchitekturen sowie Segmentierung nach dem Purdue Model

- Planung, Aufbau und Administration von OT-DMZ-Infrastrukturen

- Implementierung und Administration von Netzwerk- und Host-Monitoring-Lösungen, z. B. CheckMK, Security Onion, Trisul, HiVision und WhatsUp Gold

- Administration und Absicherung von Active-Directory-Umgebungen im IT- und OT-Bereich

- Administration von Windows- und Linux-Systemen sowie Datenbankumgebungen (MS SQL, MySQL)

- Administration und Absicherung von SCADA-, MES- und PDMS-Systemen, insbesondere GE Fanuc Proficy iFIX und Siemens PCS7

- Planung und Umsetzung von Industrial Cyber Security Maßnahmen

- Durchführung und Begleitung von Security Assessments, Risikoanalysen und Hardening-Maßnahmen nach etablierten Standards und Best Practices

- Implementierung von CIS Hardening Guidelines in IT-/OT-Umgebungen

- Entwicklung und Einführung von Cyber-Security-Prozessen, beispielsweise Incident Response, Risk Management und Technical Design Authority

- Konzeption und Umsetzung von IT-/OT-Schnittstellen und Sicherheitskonzepten

- Unterstützung bei der Integration von SIEM-, Asset-Discovery-, Netzwerk- und Host-Monitoring-Lösungen

- Begleitung von System- und Infrastruktur-Updates sowie Migrationen in produktionskritischen Umgebungen

- Technische Beratung und Unterstützung von Kunden und Projektteams im Bereich OT-Security und industrielle Netzwerktechnik

- Erstellung und Pflege von technischen Dokumentationen, Richtlinien und Testverfahren

## Qualifikation

- Abgeschlossenes Studium oder Ausbildung im Bereich IT, Netzwerktechnik, Automatisierungstechnik, Elektrotechnik oder eine vergleichbare Qualifikation

- Mehrjährige Berufserfahrung in der Administration und Konzeption von IT-/OT-Infrastrukturen

- Fundierte Kenntnisse in Netzwerk- und Firewall-Technologien

- Erfahrung im Bereich Industrial Cyber Security / OT Security

- Sehr gute Kenntnisse in der Administration von Windows- und Linux-Systemen

- Erfahrung mit Active Directory und Netzwerk-/Host-Monitoring

- Kenntnisse industrieller Systeme und Protokolle sowie Erfahrung mit SCADA-, MES- und Prozessleitsystemen

- Erfahrung in der Netzwerksegmentierung und Absicherung industrieller Umgebungen

- Kenntnisse des Purdue Enterprise Reference Architecture Models

- Erfahrung mit Security Frameworks, Hardening Guidelines sowie Risiko- und Incident-Management

**Wünschenswert:**

- GICSP – Global Industrial Cyber Security Professional

- GCIH – GIAC Certified Incident Handler

- GPEN – GIAC Penetration Tester

- GXPN – GIAC Exploit Researcher & Advanced Penetration Tester

- GCFA – GIAC Certified Forensic Analyst

- GCDA – GIAC Certified Detection Analyst

**Technisches Umfeld**

- Netzwerk: Cisco, Hirschmann, LANCOM, D-Link, Huawei

- Firewalls: Cisco, Fortinet, Sophos, Stormshield, Hirschmann

- Monitoring: CheckMK, Security Onion, Trisul, HiVision, WhatsUp Gold

- Security: CIS Hardening, SIEM, Asset Discovery, Incident Response, Risk Management

- Betriebssysteme: Windows Server, Windows 10/11, Linux (CentOS, Ubuntu, Debian, RHEL)

- Directory Services: Windows Active Directory

- Datenbanken: MS SQL, MySQL

- OT/SCADA: Siemens PCS7, GE Fanuc Proficy iFIX, ACRON MES/PDMS

- Netzwerktechnik: SHDSL / Keymile SCADA

## Benefits

**Das bieten wir Dir:**

- Abwechslungsreiche Projektarbeit in unserem Kundenumfeld mit starkem Technologiebezug

- Individuelle Förderung in Form von fachspezifischen Weiterbildungen und Zertifizierungen (wie Work­shops, Schul­ungen und Trainings)

- Einfache Kommunikationswege auf verschiedenen Verantwortungsebenen

- Flache Hierarchien innerhalb unseres Unternehmens mit fami­liärer und produktiver Atmos­phäre

- Beteiligung am Unternehmenserfolg

- Hybrides Arbeiten mit flexiblen Arbeitszeiten

- Individuelle technische Arbeitsausstattung

- Zugang zu unserer Corporate Benefits-Plattform, quartalsweise Firmenveranstaltungen

- Einen unbefristeten Arbeitsvertrag mit 30 Urlaubstage, Heiligabend und Silvester sind zusätzlich arbeitsfrei

Fühlst Du dich angesprochen und findest Du dich in der Beschreibung wieder? Wir freuen uns über deine vollständigen Bewerbungsunterlagen mit **Referenz** ***1380***.

Wir sind sehr gespannt auf die Bewerbung!

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
