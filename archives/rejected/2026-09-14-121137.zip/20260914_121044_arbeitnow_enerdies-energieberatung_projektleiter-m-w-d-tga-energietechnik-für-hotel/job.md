# Projektleiter (m/w/d) TGA / Energietechnik für Hotels

Posted: 2026-09-14T07:00:36Z

## Rejection

- Category: tech_stack
- Reason: role does not mention Go/Golang or PHP

Sie begleiten Hotels bei der technischen und energetischen Weiterentwicklung ihrer Gebäude und Anlagen. Dabei verbinden Sie technische Planung mit Projektleitung und begleiten unsere Kunden von der ersten Bestandsaufnahme über die Entwicklung geeigneter Lösungen bis zur Umsetzung.

Im Mittelpunkt stehen die technische Gebäudeausrüstung und moderne Energietechnik – zum Beispiel Heizungsanlagen, Wärmepumpen, PV, Speicher und intelligente Energiesteuerung. Sie müssen dabei nicht aus der klassischen Energieberatung kommen: Entscheidend sind technisches Verständnis, Interesse an Gebäudetechnik und die Fähigkeit, Projekte strukturiert voranzubringen.

## Aufgaben

• Sie übernehmen technische Projekte für unsere Hotelkunden – von der Bestandsaufnahme über die Planung bis zur Begleitung der Umsetzung.

• Sie führen Vor-Ort-Begehungen durch, analysieren vorhandene Heizungs- und Gebäudetechnik und entwickeln gemeinsam mit unserem Team passende technische Lösungen.

• Sie planen und bewerten beispielsweise Heizungsanlagen, Wärmepumpen, PV-Anlagen, Batteriespeicher und weitere Komponenten der technischen Gebäudeausrüstung.

• Sie begleiten die Umsetzung, stimmen sich mit Fachunternehmen und Kunden ab, prüfen technische Angebote und behalten Termine, Qualität und Kosten im Blick.

• Sie arbeiten an unseren Lösungen zur intelligenten Energiesteuerung von Hotels mit und bringen Ihr technisches Verständnis in die Weiterentwicklung ein.

• Sie erklären unseren Kunden technische Zusammenhänge und Empfehlungen verständlich und begleiten sie als zentraler Ansprechpartner durch das Projekt.

## Qualifikation

**Erforderlich:**

• Studium, Techniker- oder vergleichbare Qualifikation im Bereich Versorgungstechnik, TGA, Gebäudetechnik, Energietechnik, Bauingenieurwesen oder einem verwandten technischen Bereich

• Gutes technisches Verständnis für Gebäude und deren Anlagentechnik

• Interesse daran, technische Projekte eigenverantwortlich zu übernehmen und weiterzuentwickeln

• Gute Kommunikationsfähigkeit – Sie können technische Zusammenhänge verständlich erklären und treten gegenüber Kunden und Fachunternehmen sicher auf

• Strukturierte, eigenverantwortliche und lösungsorientierte Arbeitsweise

• Bereitschaft zu Vor-Ort-Terminen bei Hotelkunden deutschlandweit

**Von Vorteil – aber keine Voraussetzung:**

• Erfahrung in der technischen Projekt- oder Bauleitung

• Kenntnisse in Heizungs-, Klima-, Lüftungs- oder Regelungstechnik

• Erfahrung mit Wärmepumpen, PV, Batteriespeichern oder Gebäudeautomation

• Erfahrung in der Energieberatung oder energetischen Gebäudeplanung

• Kenntnisse im Fördermittelbereich (BEG, KfW, BAFA)

• Erfahrung mit Energieberatungs- oder Planungstools

## Benefits

• **100 % Homeoffice mit flexibler Arbeitszeitgestaltung:** Sie arbeiten vollständig remote und organisieren Ihre Arbeit eigenverantwortlich – ideal, um Beruf und Privatleben in Einklang zu bringen.

• **Gestaltungsspielraum und Verantwortung:** Sie übernehmen eine Schlüsselrolle in unseren Projekten, bringen eigene Ideen ein und gestalten die Zusammenarbeit mit unseren Kunden aktiv mit.

• **Verlässliche Weiterentwicklung:** Wir stellen Ihnen ein festes Weiterbildungsbudget zur Verfügung – für Seminare, Coachings oder Fachfortbildungen, die Sie beruflich und persönlich weiterbringen.

• **Erfolgsabhängige Vergütung:**

Je erfolgreicher Sie unsere Kunden durch den Beratungsprozess führen, desto

stärker wirkt sich das auch auf Ihr Einkommen aus – Leistung zahlt sich bei uns

aus.

• **Sinnstiftende Tätigkeit in einer zukunftssicheren Branche:** Sie begleiten Hotels auf dem Weg in eine nachhaltigere Zukunft – und tragen damit aktiv zur Transformation der Branche bei.

• **Langfristige Perspektive:** Bei gegenseitigem Interesse entwickeln wir Ihre Rolle weiter – mit wachsender Verantwortung und spannenden Projekten.

Dann freuen wir uns auf Ihre Bewerbung!

Wir suchen eine Persönlichkeit, die nicht nur fachlich überzeugt, sondern auch Freude daran hat, komplexe Inhalte einfach zu erklären, Verantwortung zu übernehmen und Projekte mit Energie und Weitblick zum Erfolg zu führen. Wenn Sie gerne kommunizieren, strukturiert denken, pragmatisch handeln und sich in anspruchsvollen Aufgaben wohlfühlen, könnte das hier genau die richtige Stelle für Sie sein.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
