# Telefonberater (m/w/d) spirituelle und esoterische Beratung

Posted: 2026-09-14T08:00:39Z

## Rejection

- Category: tech_stack
- Reason: role does not mention Go/Golang or PHP

Willkommen bei ZUNA Media! Wir sind ein innovatives Unternehmen im Bereich der digitalen Dienstleistungen, das sich auf Online-Kommunikation und Kundeninteraktion spezialisiert hat. Zur Verstärkung unseres Teams suchen wir einen engagierten Telefonberater (m/w/d) für spirituelle und esoterische Beratung. Bei uns hast du die Möglichkeit, flexibel von zu Hause aus zu arbeiten und dabei Teil eines dynamischen Netzwerks von unabhängigen Profis zu werden. Wir legen großen Wert auf Zuverlässigkeit, Qualität und respektvollen Umgang miteinander. Unser strukturiertes Onboarding und die modernen digitalen Tools unterstützen dich dabei, erfolgreich in deiner Rolle zu wachsen. Wenn du Leidenschaft für Kommunikation und eine Affinität zu spirituellen Themen hast, dann bist du bei uns genau richtig. Werde Teil unserer Mission, flexible und professionelle Arbeitsmöglichkeiten mit erstklassigen Kommunikationsservices zu vereinen!

## Aufgaben

- Telefonische Beratung und Unterstützung von Kunden zu spirituellen und esoterischen Themen anbieten.

- Kundenanfragen freundlich und professionell per Telefon beantworten und bearbeiten.

- Aufbau einer vertrauensvollen Beziehung zu Kunden durch empathisches Zuhören und individuelle Beratung.

- Einhaltung von Unternehmensrichtlinien und Standards für qualitativ hochwertige Kommunikation sicherstellen.

## Qualifikation

- Erfahrung in der spirituellen und esoterischen Beratung

- Exzellente Kommunikationsfähigkeiten auf Deutsch

- Hohes Maß an Einfühlungsvermögen und Geduld

- Selbstständiges Arbeiten und Zuverlässigkeit

- Flexibilität und Bereitschaft zu wechselnden Arbeitszeiten

## Benefits

**100 % Homeoffice:** Du kannst ortsunabhängig arbeiten.

**Flexible Zeiteinteilung:** Die Tätigkeit lässt sich flexibel in deinen Alltag integrieren.

**Strukturierte Einarbeitung:** Du erhältst alle notwendigen Informationen und Richtlinien vor deinem Start.

**Persönliche Ansprechpartner:** Bei Fragen steht dir unser Team zur Verfügung.

**Mehrere Projekte:** Je nach Verfügbarkeit und Eignung besteht die Möglichkeit, auf unterschiedlichen Kommunikationsprojekten eingesetzt zu werden.

**Leistungsbezogene Vergütung:** Die Vergütung richtet sich nach dem jeweiligen Projekt und der erbrachten Leistung. Die konkreten Konditionen werden vor Projektstart transparent mitgeteilt.

Entdecke deine Leidenschaft in der spirituellen Telefonberatung bei ZUNA Media. Arbeite flexibel und remote, während du Menschen mit Einfühlungsvermögen und Expertise unterstützt. Bewirb dich jetzt!

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
