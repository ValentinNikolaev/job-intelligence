# Product Owner (m/w/d)

Posted: 2026-09-14T10:31:03Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Sie kennen die Bedürfnisse ihrer Kunden und verstehen es diese in technische Innovationen und wirtschaftliche Geschäftsmodelle zu überführen. Sie übernehmen die Verantwortung für Ihren Produktbereich mit einer klaren Vision und kommunizieren diese intern wie extern mit Leidenschaft. Mit Ihrer strategischen Denkweise finden Sie immer die passende Lösung, um sowohl Kundenanforderungen als auch Unternehmensziele erfolgreich umzusetzen.

## Aufgaben

- Sie übernehmen die Verantwortung für Ihre Produktgruppe sowie das zugehörige Geschäftsmodell

- Sie analysieren Märkte und Trends im Umfeld industrieller Ultraschall-Durchflusssensoren und identifizieren neue Potenziale

- Sie entwickeln Produktvisionen und leiten daraus strategische Roadmaps ab

- Sie betreuen und entwickeln das Produktportfolio bestehend aus Standard-, OEM- und kundenspezifischen Lösungen weiter

- Sie entwickeln gemeinsam mit dem Produkt-Lifecycle-Management geeignete Go-to-Market- und Sales-Strategien

- Sie steuern Projekte sowie die laufende Produktbetreuung unter Berücksichtigung von Qualität, Terminen, Kosten und Lieferfähigkeit

## Qualifikation

- Sie verfügen über ein abgeschlossenes technisches, wirtschaftstechnisches oder vergleichbares StudiumSie bringen erste Berufserfahrung (ca. 1–5 Jahre) im technischen Produktmanagement oder im B2B-Umfeld mit

- Sie besitzen ein gutes Verständnis für technische Produkte, industrielle Prozesse oder erklärungsbedürftige Technologien

- Sie zeichnen sich durch eine eigenständige, zielorientierte und verantwortungsvolle Arbeitsweise mit hoher Kundenorientierung aus

- Sie überzeugen mit Kommunikationsgeschick in Deutsch und Englisch (fließend in Wort und Schrift)

## Benefits

- Ein **unbefristeter Arbeitsvertrag**, in einem inhabergeführten, international agierenden und wachsenden Technologieunternehmen, welches am Markt als Lösungsspezialist in der Ultraschallmesstechnik etabliert ist

- **30 Tage Urlaub, flexible Arbeitszeitgestaltung** und die Möglichkeit des mobilen Arbeitens

- Eine **strukturierte Einarbeitung** und Betreuung durch eine:n Mentor:in sowie regelmäßige **Weiterbildungsmaßnahmen**

- Abwechslungsreiche, anspruchsvolle und vielseitige Aufgabe im B2B IndustrieumfeldFlache Hierarchien und kurze Entscheidungswege

- **Attraktiver Arbeitgeberzuschuss** zur betrieblichen Altersvorsorge und verschiedene MitarbeiterveranstaltungenRegelmäßige **Gesundheitsaktionen**

- Eine moderne Arbeitsumgebung mit ergonomischen Arbeitsplätzen, flexiblen Arbeitsbereichen und innovativer Technologie

- Ein innovatives und dynamisches Arbeitsumfeld, eine vertrauensvolle Unternehmenskultur, die sich durch ein offenes und konstruktives Miteinander auszeichnetPersönlicher Freiraum mit einem hohen Maß an Eigenverantwortung

- **Gute Erreichbarkeit** mit den öffentlichen Verkehrsmitteln

Wollen Sie mehr erfahren oder sich direkt bewerben? Dann zögern Sie bitte nicht uns anzurufen!Oder senden Sie gleich Ihre Bewerbung mit Lebenslauf, Zeugnissen, Verfügbarkeit und Gehaltsvorstellungen zu.

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
