# Senior Social Media Manager

Posted: 2026-09-14T09:30:31Z

## Rejection

- Category: tech_stack
- Reason: role does not mention Go/Golang or PHP

**Senior Social Media Manager (m/w/d) – Vollzeit, 100 % remote**

PAJ ist einer der führenden Hersteller, Vertrieb und Berater rund um das Thema GPS-Ortung mit Sitz in Windeck-Hurst. Wir bieten GPS-Tracker für beinahe jeden Einsatzbereich an. PAJ ist ein sehr dynamisches und wachsendes Unternehmen mit vielen kreativen und engagierten Köpfen, innerhalb und außerhalb Deutschlands. Eine offene Kommunikationskultur und tolle Persönlichkeiten machen uns zu dem, wer wir sind.

Wenn Du Abwechslung und Herausforderungen liebst, dann gehörst Du zu uns!

**Deine Aufgaben**

- Du entwickelst eine klare Strategie und Vision für unsere Social-Media-Kanäle (Instagram, TikTok, Facebook, YouTube, LinkedIn) und setzt sie um

- Du baust einen einheitlichen Auftritt über alle Kanäle auf (Tonalität, Look, Content-Formate)

- Du planst und verantwortest den Redaktionsplan und produzierst Content selbst oder steuerst die Produktion

- Du testest verschiedene Formate und Strategien, misst die Ergebnisse und passt an

- Du steuerst Kooperationen mit Influencern und Creatorn

- Du arbeitest eng mit Marketing, Grafik und Video zusammen

- Du berichtest regelmäßig über Reichweite, Engagement und Ergebnisse

**Das bringst du mit**

- Mindestens 2–3 Jahre Erfahrung im Social Media Management, idealerweise im E-Commerce oder für ein Produkt-Unternehmen

- Du kannst strategisch denken und gleichzeitig selbst umsetzen

- Du hast nachweisbare Erfolge beim Aufbau von Kanälen oder Communities

- Deutsch auf Muttersprachniveau, B2-C1 Englisch für die interne Kommunikation

- Sicherer Umgang mit gängigen Tools für Planung, Analyse und Content-Erstellung (z. B. Meta Business Suite, Canva, CapCut oder ähnliche)

- Gespür für Trends, Bild und Sprache

- Selbstständige und strukturierte Arbeitsweise, da du komplett remote arbeitest

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
