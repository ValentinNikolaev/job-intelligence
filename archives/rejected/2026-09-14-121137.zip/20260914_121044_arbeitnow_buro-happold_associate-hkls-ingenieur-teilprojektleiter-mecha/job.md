# Associate HKLS Ingenieur / Teilprojektleiter mechanische Gewerke (m/w/d)

Posted: 2026-09-14T11:00:27Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Als Associate Engineer übernimmst Du eine Schlüsselrolle bei der erfolgreichen Umsetzung unserer Projekte. Du verantwortest die technische und organisatorische Steuerung komplexer Gebäudeprojekte, führst multidisziplinäre Projektteams und arbeitest eng mit Kunden, Architekt:innen und weiteren Stakeholdern zusammen.

Neben Deiner technischen Expertise bringst Du Leadership, unternehmerisches Denken und die Fähigkeit mit, langfristige Kundenbeziehungen aufzubauen und weiterzuentwickeln.

## Aufgaben

- Verantwortung für die Planung und erfolgreiche Umsetzung anspruchsvoller Gebäudeprojekte

- FührungundKoordinationinterdisziplinärerProjektteams

- Steuerung von Projektumfang, Qualität, Kosten und Terminen

- Entwicklung technischer Strategien und Projektlösungen gemeinsam mit Kunden und Projektpartnern

- Aktive Betreuung und Weiterentwicklung von Kundenbeziehungen

- Leitung von Projektbesprechungen sowie Vertretung von Buro Happold gegenüber Kunden und Stakeholdern

- Unterstützung bei der Angebotsbearbeitung und Projektakquise

- Förderung und Entwicklung vonKolleg:innendurch Mentoring und fachliche Führung

- Beitrag zur strategischen Weiterentwicklung des Berliner MEP-Teams

## Qualifikation

- Abgeschlossenes Studium im Bereich Versorgungstechnik, Gebäudetechnik, Energietechnik oder eine vergleichbare Qualifikation

- Umfangreiche Kenntnisse der HOAI und mehrjährige Berufserfahrung in der Planung und Steuerung komplexer Gebäudeprojekte

- Erfahrung in Projektleitung und Stakeholder-Management

- Fundiertes Verständnis von Projektwirtschaftlichkeit, Kostensteuerung und Terminmanagement

- AusgeprägteKommunikations- undPräsentationsfähigkeiten

- Erfahrung in der Führung, Entwicklung und Motivation von Projektteams

- Unternehmerisches Denken sowie Freude am Aufbau langfristiger Kundenbeziehungen

- Sehr gute Deutschkenntnisse sowie gute Englischkenntnisse

## Benefits

**Flexibilität& Wellbeing**

Flexible und hybride Arbeitsmodelle, Wellbeing-Initiativen und Unterstützungsangebote, die Dir helfen, Beruf und Privatleben in Einklang zu bringen.

**Meaningful Work & Global Collaboration**

Die Möglichkeit, an spannenden und herausfordernden Projekten mit lokalem und internationalem Einfluss zu arbeiten und dabei mit multidisziplinären Teams aus unserem globalen Netzwerk zusammenzuarbeiten.

**Learning, Development & Career Growth**

Klare Karrierepfade, regelmäßige Entwicklungsgespräche sowie interne und externe Weiterbildungsmöglichkeiten zur Unterstützung Deiner fachlichen und persönlichen Entwicklung.

**Reward & Recognition**

Regelmäßige Gehaltsüberprüfungen sowie leistungsbezogene Bonusmöglichkeiten, die Deinen Beitrag und Erfolg anerkennen.

**Inclusive Culture & Community**

Ein kollaboratives und inklusives Umfeld mit zahlreichen Möglichkeiten zum Wissensaustausch, Networking sowie regelmäßigen Team- und Community-Events.

**Innovation & International Opportunities**

Die Chance, eigene Ideen einzubringen, Verantwortung zu übernehmen und internationale Entwicklungs- und Karrieremöglichkeiten zu nutzen.

**Agile Working Environment**

Flache Hierarchien und kurze Entscheidungswege, die schnelle Zusammenarbeit und eigenverantwortliches Arbeiten ermöglichen.

**Zusätzlich in Deutschland**

30 Urlaubstage

- Zugang zu unserem Mental Wellbeing Programme

- Flexibles Benefitprogramm für Fitness, Mobilität, Altersvorsorge und mehr

- Sprachkurse

- Lunch Roulette

- Young Employee Forum

- Regelmäßige Team- und Social Events

**Bereit für den nächsten Schritt? - Wir freuen uns auf Deine Bewerbung.**

Werde Teil unseres Hamburger Teams und gestalte mit uns nachhaltige Lösungen für die Herausforderungen der gebauten Umwelt.

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
