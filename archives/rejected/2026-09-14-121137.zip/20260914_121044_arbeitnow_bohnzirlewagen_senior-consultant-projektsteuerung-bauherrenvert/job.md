# Senior Consultant - Projektsteuerung & Bauherrenvertretung (w/m/d)

Posted: 2026-09-14T09:00:39Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**BOHNZIRLEWAGEN** berät und vertritt Bauherren bei anspruchsvollen Immobilienprojekten – von der strategischen Projektentwicklung bis zur technischen Realisierung. Wir arbeiten für private und öffentliche Auftraggeber und übernehmen Verantwortung dort, wo Projekte komplex werden.

Dabei kannst Du Dich in Projekten in allen Phasen des Immobilienlebenszyklus einbringen – vom visionären Neubau über den effizienten Betrieb bis hin zur nachhaltigen Bestandsentwicklung. Bei BOHNZIRLEWAGEN hast Du die Möglichkeit, in einem gefestigten und ideenoffenen Team an herausfordernden und abwechslungsreichen Projekten mitzuwirken, Deine Karriere aktiv zu gestalten und nachhaltige Veränderungen zu bewirken.

Wir suchen Verstärkung für unser Team in **Düsseldorf**: Zum nächstmöglichen Zeitpunkt suchen wir einen erfahrenen **Senior Consultant (w/m/d)** für die Bereiche **Projektsteuerung, Projektmanagement und Technische Bauherrenvertretung**.

## Aufgaben

- **Projektmanagement:** Du leitest und steuerst selbstständig komplexe Immobilienprojekte und übernimmst technische und fachliche Verantwortung bei Neubau-, Modernisierungs-, Nutzungsänderungs- und Instandsetzungsmaßnahmen.

- **Bauherrenvertretung:** Du übernimmst die externe technische Bauherrenvertretung und vertrittst die Interessen unserer Auftraggeber im Projekt**.**

- **Verträge & Vergabe**: Du bereitest Leistungsbilder, Leistungsverzeichnisse und Vertragsinhalte vor und stimmst diese mit den Projektbeteiligten ab.

- **Stakeholder-Management:** Du vertrittst die Interessen unserer Auftraggeber souverän gegenüber Planern, Behörden, ausführenden Unternehmen und weiteren Projektbeteiligten.

- **Ziel- und Erfolgskontrolle:** Du definierst und steuerst gemeinsam mit unseren Auftraggebern die Projektziele hinsichtlich Kosten, Terminen, Qualitäten und Organisation**.**

- **Koordination**: Du steuerst und koordinierst interne und externe Partner sowie die weiteren Projektbeteiligten.

## Qualifikation

- **Bildung**: Abgeschlossenes Studium im Bereich Architektur, Bauingenieurwesen, Wirtschaftsingenieurwesen, Projektmanagement oder vergleichbarer Fachrichtungen.

- **Erfahrung:** Mindestens fünf Jahre relevante Berufserfahrung im Projektmanagement / Projektsteuerung, der Bauplanung oder der Bauüberwachung von Hochbauprojekten.

- **Fachwissen**: Fundierte Kenntnisse in bautechnischen und architektonischen Belangen sowie im Kosten-, Termin- und Qualitätsmanagement und der Durchführung von Vergabeverfahren.

- **Persönlichkeit:** Du trittst gegenüber Bauherren, Planern und ausführenden Unternehmen sicher und verbindlich auf, kannst unterschiedliche Interessen zusammenführen und behältst auch in anspruchsvollen Projektsituationen den Überblick.

- **Arbeitsweise:** Du arbeitest strukturiert, selbstständig und präzise, übernimmst Verantwortung und schätzt die Zusammenarbeit in interdisziplinären Teams.

- **Sprachkenntnisse**: Sehr gute Deutschkenntnisse (min. C1), sichere Ausdrucksfähigkeit in Wort und Schrift.

- **Technische Fähigkeiten**: Sehr gute IT-Kenntnisse (MS Office) und Erfahrung mit branchentypischer Software (Kostencontrolling, Terminplanung).

## Benefits

- **Verantwortung & Gestaltungsspielraum:** Du übernimmst echte Projektverantwortung und erhältst den Freiraum, Projekte und Themen aktiv mitzugestalten.

- **Direkte Wege:** Du arbeitest in überschaubaren Teams mit kurzen Entscheidungswegen und direktem Austausch mit der Geschäftsführung.

- **Projekte & Kunden:** Dich erwarten anspruchsvolle und abwechslungsreiche Immobilienprojekte für unterschiedliche private und öffentliche Auftraggeber.

- **Entwicklung:** Wir unterstützen Deine fachliche und persönliche Weiterentwicklung und bieten Dir die Möglichkeit, eigene Themen und Kundenbeziehungen aufzubauen.

- **Flexibilität**: 30 Tage Urlaub, flexible Arbeitszeiten und die Möglichkeit zum mobilen Arbeiten.

- **Team & Standort:** Ein gefestigtes, ideenoffenes Team, ein modernes Büro im Herzen Düsseldorfs sowie gemeinsame Mitarbeiter- und Freizeitevents.

Haben wir Dein Interesse geweckt? Dann freuen wir uns auf Deine aussagekräftige Bewerbung in **einer PDF-Datei**, inklusive möglichem Eintrittstermin und Gehaltsvorstellung. Mehr über uns als Arbeitgeber und unsere Dienstleistungen findest Du auf unserer Website.

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
