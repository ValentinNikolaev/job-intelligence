# Grafikdesigner:in Digital & Print in Teilzeit 50-75% (m/w/d)

Posted: 2026-09-14T11:00:27Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**gold&kind Boutique Branding Studio – Lindau – München - hybrid**

gold&kind ist ein Boutique-Designstudio, das Marken in Bewegung bringt. Sichtbar, zukunftsfähig und strukturiert. Unser Fokus liegt auf Brand-Management und Brand-Design für Unternehmen im Wandel. Wir arbeiten für renommierte Kunden im Bereich Hospitality und Lifestyle und unterstützen Premiummarken dabei, ihre Markenidentität neu aufzustellen und nachhaltig sichtbar zu bleiben.

Mit viel Liebe zum Detail, einem klaren Gespür für Ästhetik und strategischem Weitblick entwickeln wir Designs, die nicht nur gut aussehen, sondern echte Wirkung erzielen.

**Jetzt suchen wir dich als Unterstützung im Bereich Grafik Design 🪩**

**Deine Mission**

Du entwickelst starke visuelle Lösungen für unsere Kunden und begleitest Designprojekte eigenständig von der Idee bis zur Umsetzung. Dabei bist du nicht nur gestalterisch verantwortlich, sondern auch direkte:r Ansprechpartner:in für unsere Kunden.

Du verstehst Briefings, denkst konzeptionell mit, bringst deine eigenen Ideen ein und sorgst dafür, dass Projekte gestalterisch, organisatorisch und kommunikativ auf hohem Niveau umgesetzt werden.

## Aufgaben

**Deine Aufgaben**

- Du entwickelst und gestaltest eigenständig Markenauftritte und Kommunikationsmittel für unsere Kunden – digital und print.

- Du übernimmst Designprojekte vom Briefing über Konzeption und Gestaltung bis zur finalen Umsetzung.

- Du bist im direkten Austausch mit unseren Kunden

- Du erstellst Präsentationen, Editorial Designs, Social-Media-Assets, Printmedien anhand bestehender Brand-Manuals.

- Du koordinierst Feedback- und Korrekturschleifen und behältst Timings, Anforderungen und nächste Schritte selbstständig im Blick.

- Du bringst dich aktiv mit Ideen und gestalterischen Impulsen ein.

## Qualifikation

**Was wir uns wünschen**

- Gestalterische Stärke: Du hast ein ausgeprägtes Gespür für Typografie, Layout-Systeme und hochwertige Markenästhetik.

- Eigenverantwortung: Du kannst ein Projekt selbstständig übernehmen, strukturieren und zuverlässig zum Ergebnis führen.

- Kommunikationsstärke: Du fühlst dich im direkten Kundenkontakt wohl, kannst deine Gestaltung begründen und kommunizierst klar, freundlich und professionell.

- Konzeptionelles Denken: Du setzt nicht nur um, sondern verstehst Marken, hinterfragst Briefings und entwickelst eigene Ideen.

- Organisationstalent: Auch bei mehreren parallelen Projekten behältst du Timings, Feedback und To-dos im Blick.

- Qualitätsanspruch: Du hast ein Auge fürs Detail und gibst dich nicht mit „sieht ganz gut aus“ zufrieden.

**Dein Background**

- Abgeschlossene Ausbildung Mediengestalter:in Digital&Print oder vergleichbare Qualifikation.

- Idealerweise mindestens 2 Jahre Berufserfahrung im Design- oder Agenturumfeld

- Sicherer Umgang mit Adobe Creative Cloud, insbesondere InDesign, Illustrator und Photoshop, sowie mit Figma.

- Erfahrung mit Adobe After Effects von Vorteil.

- Die Abläufe einer saubere Druckvorstufe sind dir bekannt und du beherrschst eine saubere Reinzeichnung.

- Sehr gutes Deutsch in Wort und Schrift für die direkte Kommunikation mit unseren Kunden.

## Benefits

**Was dich bei gold&kind erwartet**

- **Ein kreatives Umfeld, das Marken neu definiert, mit Design auf höchstem Niveau und echtem Herzblut.**

- **Remote first. Homeoffice ist bei uns die Regel. Für ausgewählte Kundentermine, Workshops oder besondere Projektphasen treffen wir uns bei Bedarf persönlich im Büro.**

- **Direkte Zusammenarbeit erfahrene Brand- und Kommunikationsdesignerin mit über 10 Jahren Branchenerfahrung im Luxus- und Lifestyle-Segment.**

- **Tiefe Einblicke in die Arbeit für Premiumkunden. Von der strategischen Markenentwicklung bis zum performanten Branding.**

- **Verantwortung ab Tag 1, du bist fester Bestandteil des Studios und kannst dich hier wirklich weiterentwickeln**

- **Boutique-Feeling mit großem Impact. Kleine Teams, große Ideen und Projekte, die wirklich etwas bewegen.**

Bereit, Teil von gold&kind zu werden? Dann bewirb dich jetzt!

**Wir freuen uns darauf, dich kennenzulernen! 🪩**

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
