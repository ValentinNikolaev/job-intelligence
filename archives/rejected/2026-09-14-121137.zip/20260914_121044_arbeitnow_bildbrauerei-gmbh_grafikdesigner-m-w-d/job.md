# Grafikdesigner (m/w/d)

Posted: 2026-09-14T10:00:31Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Hand aufs Herz: Wir sind eine Kreativagentur mit richtig guten Ideen, starken Kunden und einem Team, das brennt. Was uns manchmal fehlt? Jemand, der aus einer geilen Idee ein geiles Layout macht, vom ersten Scribble bis zur druckfertigen Datei, sauber und in Top-Qualität.

Wir suchen eine Person, die Typo, Raster und Farbe im Griff hat, die weiß, wie ein PDF wirklich in die Druckerei geht, und die Bock hat, mit KI zu arbeiten statt sich davor zu fürchten. Wenn du gleichzeitig strukturiert und gestalterisch bist und KI nicht für ein Autokennzeichen hältst, lies weiter.

## Aufgaben

- Du gestaltest von Print bis Digital: Anzeigen, Plakate, Broschüren, Social Assets, Kampagnen, Präsentationen und alles, was sonst noch auf unserem Tisch landet.

- Du setzt Konzepte sauber um, von der ersten Idee bis zur finalen Reinzeichnung, druckfertig und ohne böse Überraschungen in der Vorstufe.

- Du bist fit in Print: Formate, Beschnitt, CMYK, Farbprofile, Sonderfarben. Du weißt, was die Druckerei braucht, bevor sie fragt.

- Du arbeitest eng mit Kreativteam, Kund:innen und Kolleg:innen zusammen und sorgst dafür, dass aus einem Briefing ein Ergebnis wird, das sitzt.

- Du nutzt KI aktiv im Alltag: für Bildgenerierung, Mockups, Varianten, Reinzeichnungskram und überall dort, wo es dir Arbeit abnimmt.

- Du hältst unsere Marken und die unserer Kund:innen konsistent und traust dich trotzdem, Dinge besser zu machen.

## Qualifikation

- Du hast eine gestalterische Ausbildung oder ein Studium (Mediengestaltung, Kommunikationsdesign o. ä.).

- Ein bisschen Praxiserfahrung bringst du mit: Du hast schon echte Projekte umgesetzt und weißt, wie Agenturalltag tickt.

- Adobe CC (InDesign, Photoshop, Illustrator) sitzt, InDesign besonders, weil Print bei uns kein Nebenschauplatz ist.

- Print ist deine Komfortzone: Reinzeichnung, Druckvorstufe und Produktion machen dir keine Angst, sondern Spaß.

- Digital ist kein Fremdwort: Social Formate, ein Gespür für Web und ein paar Motion Basics sind ein Plus.

- KI nutzt du entweder schon aktiv oder du hast richtig Bock, dich reinzufuchsen. Offenheit ist hier Pflicht, nicht Kür.

- Du arbeitest sauber, strukturiert und hältst Deadlines, auch wenn's mal eng wird.

## Benefits

Projekte, bei denen du abends denkst: „Das war heute wirklich cool", mit namhaften Kund:innen aus Sport, Politik, Gesundheit, Tech und mehr.

- Ein Team, das sich nicht zu ernst nimmt, aber die Arbeit sehr ernst nimmt.

- KI ist bei uns kein Buzzword, sondern Tagesgeschäft, mit Zugang zu aktuellen Tools und Raum zum Experimentieren.

- Kurze Entscheidungswege: Wenn du eine gute Idee hast, braucht es keine sechs Meetings, bis etwas passiert.

- Modernes Büro in Heidelberg, flexible Arbeitszeiten und das Gefühl, eine wachsende Agentur aktiv mitzubauen.

- Kein Corporate-Wahnsinn, dafür echte Verantwortung ab Tag eins.

- Betriebliche Altersvorsorge ist uns wichtig, damit wir schon heute in deine Zukunft investieren und du in unsere.

- Jobrad, damit du entspannt und nachhaltig zur Arbeit kommst.

- Natürlich gibt es bei uns auch top Kaffee, Getränke und coole Teamevents.

Klingt nach dir? Dann schick uns dein Portfolio, ein paar Arbeitsproben und gerne ein paar Zeilen, warum du Bock hast. Kein Anschreiben-Roman nötig. Wir wollen wissen, wer du bist, nicht, wie gut du Floskeln googeln kannst.

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
