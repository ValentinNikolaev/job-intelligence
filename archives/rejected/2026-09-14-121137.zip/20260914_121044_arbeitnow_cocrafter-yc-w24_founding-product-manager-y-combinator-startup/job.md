# Founding Product Manager (Y Combinator Startup)

Posted: 2026-09-14T06:30:36Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Wir sind **CoCrafter (YC W24)**, ein schnell wachsendes Münchner Startup mit der Mission, Kernprozesse der Bauindustrie grundlegend zu ändern.

Die Bauwirtschaft ist das Rückgrat der deutschen und europäischen Wirtschaft – und dennoch wurde sie von der Digitalisierung weitgehend übersehen. Das Ergebnis? **Ineffiziente Prozesse** und **viel ungenutztes Potenzial.**

CoCrafter baut das Operating System (OS) für Subcontractor Management und zählt deutschlandweit bereits zahlreiche mittelständische Bau- und Handwerksbetriebe zu seinen Kunden.

Wir sind mit **1.8m€** von **Y Combinator, 10x Founders und weiteren Top-Investoren** finanziert – und sind damit bereit für den nächsten großen Wachstumsschritt.

**Werde Teil unseres Teams und gestalte mit uns die Zukunft der Bauindustrie! 🚀**

## Aufgaben

Wir suchen Dich für als unseren ersten **Product Manager #1** – Du solltest schnell lernen können und den Herausforderungen eines Startups gewachsen sein. Du planst und entwickelst aus Kundengesprächen ein Produkt, das unsere Kunden voranbringt. Du wirst eigene Features end-to-end denken, designen und entwickeln, und dabei eng mit unserem Tech-Team zusammenarbeiten. Du bist in CoCrafters kreativstem Team und viel in Anwendungsgesprächen mit unseren Usern, konzeptueller Umsetzung und UX/Design in Berührung. Du arbeitest direkt mit unserem Co-Founder und CPO Philipp zusammen.

**Verantwortlichkeiten**

- Product Ownership**:** Du bekommst eine end-to-end Verantwortlichkeit für eigene Product-Streams.

- Customer Discovery: Direkter Kundenkontakt im Zusammenspiel mit unserem Customer Success. Du wirst eigene Kunden auch in der Implementierung von Features leaden.

- Project Management: Da einige Features von uns sehr komplex sind, ist ein gutes Projektmanagement unabdingbar.

## Qualifikation

- Idealerweise praktische Erfahrungen im Product Management.

- Gutes technisches Verständnis (Software Engineering ist aber nicht notwendig).

- Von Vorteil: Kenntnisse oder Erfahrung in der Handwerks- und/oder Baubranche.

- Proaktive Arbeitsweise und die Fähigkeit, eigenständig Initiative zu ergreifen.

- Freude an der Arbeit in einem schnelllebigen und dynamischen Umfeld.

- Fließende Deutschkenntnisse auf Muttersprachenniveau (oder vergleichbar).

- **Start:** Ab sofort.

## Benefits

🦸‍♀️ **Ein erstklassiges Netzwerk** aus Gründern, Investoren und Mentoren für deine persönliche und berufliche Weiterentwicklung

💸 **Attraktive Vergütung** inklusive **Unternehmensanteilen (ESOP)** – Du profitierst von unserem Erfolg

🏖️ **28 Tage Urlaub** pro Jahr für Deine Erholung

🏋️‍♂️ **Fitness-Zuschuss**, damit Du Dich auch außerhalb des Büros auspowern oder entspannen kannst 😉

⛰️ **Team-Events** wie Bowling, Minigolf, Offsites und regelmäßige Feedback-Sessions

☕️ **Ein wunderschönes Büro** im Herzen Münchens (Maxvorstadt)

*🚀* ***Warum du Teil von CoCrafter werden solltest*** *🚀*

🔥 **Impact:** In weniger als einem Jahr haben wir ein Produkt geschaffen, das essentiell für unsere Kunden ist. Mit Deiner Arbeit wirst Du eine gesamte Branche neu definieren!

📈 **Wachstum:** Der Einstieg in ein Start-up in der frühen Phase ist eine einmalige Gelegenheit. Werde Teil eines schnell wachsenden Teams und übernimm eine Schlüsselrolle in dieser Entwicklung!

🤝 **Team:** Wir sind ein **interdisziplinäres, dynamisches und unterstützendes Team**, das mit Leidenschaft etwas Außergewöhnliches aufbaut. Werde Teil von CoCrafter und entwickle Dich **sowohl persönlich als auch beruflich** weiter!

🚀 **Let’s build the future of construction together!**

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
