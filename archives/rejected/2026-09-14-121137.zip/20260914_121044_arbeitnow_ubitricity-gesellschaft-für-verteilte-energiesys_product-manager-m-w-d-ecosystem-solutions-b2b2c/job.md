# Product Manager (m/w/d) – Ecosystem Solutions (B2B2C)

Posted: 2026-09-14T10:31:03Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

## Your Mission

The transport revolution is on the horizon, presenting significant challenges and opportunities in the mobility sector.

We're focused on delivering the right charge points at the right time and place. As the UK's leading public EV charging provider, ubitricity collaborates with local authorities to install and operate charging solutions for electric vehicles in public spaces.

To rapidly expand the charging infrastructure, we operate lamppost, AC fast, and DC rapid charge points across Germany, the UK, France and the Netherlands. As a Product Manager in our Ecosystem team, you'll help advance e-mobility and build an efficient, accessible charging network for everyone.

**Your Mission**

Put the EV driver at the center of everything we build. You'll own and evolve the ecosystem services and integrations — connecting our teams, markets and suppliers — that make charging effortless and reliable for every driver, from the moment they plug in to the moment they pay, while keeping operations running smoothly, priorities aligned, and a complex software environment continuously improving.

## Your Tasks

- Drive development and evolution of key ecosystem components, integrations and services, ensuring they deliver value for EV drivers and the business.

- Own the budget for development and design initiatives in your area.

- Shapen and coordinate API and system integrations across internal teams and external suppliers and stakeholders, and facilitate alignment between Software, Hardware, Operations, Commercial and partners, ensuring a seamless experience for drivers.

- Take ownership of product quality in your area, continuously improving how work is planned, shipped and maintained.

- Proactively identify customer pain points, operational challenges and market opportunities, and translate them into product improvements and new initiatives.

- Prioritise work using value-based frameworks, considering customer impact, business value and strategic goals, in a multi-stakeholder environment.

- Translate customers’, business and technical needs into clear requirements and user stories.

- Support iterative delivery and small pilots, and equip local markets with the tooling, documentation and support they need to move fast.

- Work closely with engineers day to day to clarify scope, answer questions and make implementation trade-offs.

- Run Scrum processes for the development team and coordinate work packages with internal colleagues.

- Prototype new feature UI/UX directly in our live application using AI coding tools such as GitHub Copilot to validate ideas before engineering builds them.

## Your profile

- 3+ years as a Technical Product Manager or similar, working on platforms, APIs, integrations or internal tools — ideally in the EV industry, energy, IoT or hardware-software ecosystems.

- Technically comfortable, well beyond spreadsheet tools — able to work with APIs, dashboards and low-/no-code platforms without needing to write production code.

- Comfortable using AI tools such as GitHub Copilot in daily work

- Strong stakeholder management, clear, structured communicator who can bridge engineering, operations, commercial teams, partners and customers.

- Data-driven problem solver with strong analytical thinking and UX focus for internal Stakeholder and external customers.

- Demonstrated ability to proactively identify opportunities, define solutions and drive initiatives from concept through delivery

- Comfortable operating in complex, multi-stakeholder service environments.

- Collaborative, pragmatic and adaptable in a small, fast-evolving organization.

- English C1 required; German is a plus.

## Our Offer

- Real impact: products that move the sustainable mobility transition forward, at a company with a well-established and uniquely placed position in the sector.

- Real ownership: short decision paths, fast execution, and room to define, evaluate and improve systems and processes across the business.

- Close collaboration with teams in Berlin, London and Amsterdam, inside an agile company backed by a leading global energy company.

- Genuine growth: a fast-growing environment with exciting development opportunities and the scope to shape your own challenging projects.

- Flexible, hybrid-by-default working (3 days in the office, 2 days remote), plus up to 4 weeks a year remote work from anywhere.

- A centrally located office in the heart of Berlin.

- A team that genuinely loves what it does.
**Statement on diversity**

We take pride in being a diverse organisation with a strong diversity and inclusion culture. We believe that everyone is different, and that difference brings value. Inclusion and inclusive behaviours are at the heart of effective collaboration, be it with team members, colleagues in other parts of our company, or with our customers. Every voice is heard.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
