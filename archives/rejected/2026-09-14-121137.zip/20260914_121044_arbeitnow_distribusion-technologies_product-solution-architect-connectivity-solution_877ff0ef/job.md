# Product Solution Architect, Connectivity Solutions (all genders)

Posted: 2026-09-14T07:20:11Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**Distribusion** is the world’s leading ground transportation marketplace and gives travelers seamless access to ground transportation online, from search to ticket purchase. We have built a cutting-edge B2B technology platform that connects bus, rail, and ferry operators in 70+ countries with the biggest online retailers, including Google Maps and [Booking.com](http://Booking.com).

We are shaping the future of travel and building the largest global network of transport providers and retailers. We are one of the fastest-growing startups in travel, backed by two leading VCs (TQ Ventures & Lightrock), and now, following our recent $80m Series C funding, we are ready to push beyond.

As a **Product Solution Architect**, you translate complex, multi-team requirements into scalable, platform-ready concepts, from requirements gathering and product design through to technical architecture, without hands-on coding. You work with client-facing teams to solve client needs while keeping products coherent across tech verticals. You champion clean concepts, drive down technical debt, and advise engineering teams by analyzing codebases, evaluating standards, and guiding features to high-quality delivery.

#### **What you will do:**

-

Architecture & System Blueprints: Define high-level platform concepts, system topologies, and technical blueprints that resolve cross-domain dependencies while systematically reducing tech debt.

-

Requirements & Product Design: Partner with stakeholders to translate vague business needs into well-structured, platform-ready functional designs and technical specifications.

-

Technical Advisory & Quality Governance: Analyze existing codebases and implementation standards to advise engineering teams, enforce best practices, and resolve technical blockers.

-

Project & Delivery Alignment: Steer feature initiatives from concept to production, ensuring cross-team synchronization and timely delivery against platform milestones.**
**

**Workplace:**

We are a remote-first company with teams located around the Globe and a HQ in Berlin.

**Who you are:**

-

7+ years in software engineering or technical architecture, including 3+ years working as a solution, platform, or enterprise architect.

-

Proven experience designing platform-level architectures and system blueprints for products spanning multiple teams and domains.

-

Strong grounding in software design patterns, distributed systems, API design, and integration architecture.

-

Demonstrated ability to read and evaluate existing codebases to assess technical debt, risk, and implementation quality.

-

Strong analytical and communication skills, able to translate ambiguous business requirements into clear functional and technical specifications.

-

Experience steering cross-functional delivery and aligning engineering, product, and business stakeholders without formal line-management authority.

-

Bachelor's or Master's degree in Computer Science, Engineering, or a related field, or equivalent practical experience.

**Nice to Have**

-

Experience in travel, mobility, or e-commerce distribution platforms.

-

Familiarity with domain-driven design and large-scale platform migrations or modernization initiatives.

-

Prior experience in a technical advisory, architecture guild, or platform governance function.

**
**

**What you can expect:**

-

You will join a fast-paced travel tech company and take on a rapidly growing industry.

-

You will take on ownership and responsibility from day one and have a direct impact on the success of the company.

-

We value agility! We’re constantly updating our tech stack and offer the best possible tools to ensure all of our in-house engineers, partners, and carriers benefit from cutting-edge, efficient solutions.

-

You will work with global companies. Our product attracts the biggest names in travel technology, such as Booking.com, Google Maps, and national carriers like Amtrak, Deutsche Bahn, Renfe, and SNCF.

-

You will join an international team of talented and driven people with a clear mission. Expect your colleagues to inspire, support and challenge you every day!

-

We offer flexible and remote working conditions, relocation opportunities, and career growth in a small and developing company.

***
***

***Our hiring team for this role:****
Your Talent Partner (TP) and point of contact is Anh Do, and the Hiring Manager (HM) is Mathias Leppmeier*.*
For any queries, contact your Talent Partner at (**

*Do you want to work on a product that is used by millions of people daily with a high load, availability and scalability, and most advanced technology? *Come join us!

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
