# Leitung Bewerbertelefonie (m/w/d)

Posted: 2026-09-14T06:30:35Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Wir verstehen uns als eine Fusion aus Agentur und Unternehmensberatung. Bei uns lebst du die Mischung aus Kreativität, Strategie und Beratung.

**Was uns ausmacht?**

expectleads.® macht insbesondere das Team aus, jede Person verfolgt hier ambitionierte Ziele und unterstützt sich gegenseitig, diese zu erreichen. Unser modernes Office in Erlangen bietet Raum für Spaß und Kreativität und schafft dabei trotzdem eine professionelle und zielorientierte Atmosphäre.

Wir unterstützen mittelständische und große Unternehmen dabei, der bestmögliche Arbeitgeber zu werden und dies auch sichtbar zu machen.

**Deine Chancen bei uns:**

Du übernimmst die Verantwortung für den Bereich, der über Erfolg oder Misserfolg unserer Kundenprojekte entscheidet: den Erstkontakt zum Bewerber. Du führst ein Team von 8 bis 12 HR-Telefonisten, machst es jeden Monat besser und steuerst es über klare Zahlen. 🚀

## Aufgaben

- **Führung deines Teams:** Du führst, entwickelst und steuerst unsere HR-Telefonisten, führst regelmäßige 1:1s, setzt klare Ziele und hältst dein Team in der Umsetzung.

- **Qualitätssicherung und Coaching:** Du hörst Gespräche mit, gibst konkretes Feedback, entwickelst Gesprächsleitfäden weiter und sorgst dafür, dass jeder Bewerber die gleiche hohe Gesprächsqualität erlebt.

- **Steuerung über Kennzahlen:** Du verantwortest die KPIs deines Bereichs (Erreichungsquote, Qualifizierungsquote, Weiterleitungsquote, Bearbeitungszeit) und leitest daraus konkrete Maßnahmen ab.

- **Prozess- und Systemverantwortung:** Du optimierst Abläufe, Tools und die Bewerberdatenbank und hältst die Schnittstelle zu Projektmanagement und Kundenbetreuung sauber.

- **Aufbau des Teams:** Du rekrutierst, onboardest und entwickelst neue Telefonisten und skalierst den Bereich mit unserem Wachstum mit.

## Qualifikation

- Du hast bereits Erfahrung in der telefonischen Kommunikation, im Vertrieb oder im Recruiting und bist selbst am Telefon stark

- Du hast erste Führungserfahrung oder willst den nächsten Schritt in die Führung gehen

- Du traust dir zu, ein Team von 8 bis 12 Personen zu steuern und für dessen Ergebnisse geradezustehenDu denkst in Zahlen, erkennst Muster in Kennzahlen und leitest daraus Entscheidungen ab statt Meinungen

- Du denkst in Zahlen, erkennst Muster in Kennzahlen und leitest daraus Entscheidungen ab statt Meinungen

- Du gibst klares, direktes Feedback und ziehst Menschen nach oben, statt es ihnen recht zu machen

- Du kommunizierst klar, strukturiert und überzeugend, am Telefon wie schriftlich

- Ordnung, Struktur und saubere Prozesse sind für dich Selbstverständlichkeit

- Du bist offen, positiv und gehst neue Herausforderungen mit Neugier und Motivation an

- Du beherrschst die deutsche Sprache in Wort und Schrift auf exzellentem Niveau

- Du lebst in Erlangen, Nürnberg oder Umgebung

- Und: Du bist bereit, auch **nachmittags und abends** präsent zu sein, denn genau dann läuft dein Team 😃

## Benefits

- Attraktives Gehalt + Ungedeckelte Provision

- Leistungsorientiertes Bonisystem - wenn dein Team performt, profitierst du auch davon

- Hohe Lernkurve. Intensive Einarbeitung und regelmäßige, produktive Coachings

- Arbeiten in einem sehr ambitionierten Team mit klarer Vision

- Du bekommst schnell eine sehr hohe Verantwortung übertragen, damit du direkt loslegen kannst

- 600€ Gesundheitsbudget im Jahr

- Feedback-Kultur und Innovation werden hier groß geschrieben

- Monatliche Grill- und Teamabende

- Professionelle und zielorientierte Atmosphäre

- Neueste Apple-Geräte

**Für uns selbstverständlich:**

- Wasser und Kaffee selbstverständlich

- Ein strukturiertes Onboarding

- Offene Kommunikation

- Leistungsorientiertes und gutes Gehalt

Diese Position ist keine Verwaltungsrolle. Du verantwortest den Bereich, an dem sich unsere Arbeit für unsere Kunden am Ende messen lässt: ob aus Bewerbern echte Kandidaten werden. 8 bis 12 Menschen arbeiten jeden Tag mit deinen Leitfäden, deinem Feedback und deinen Zielen. Wenn du gut bist, merkt man das in unseren Zahlen sofort. Wenn du nicht gut bist, auch.

Genau deshalb bekommst du hier in zwölf Monaten mehr echte Führungserfahrung als in vielen Konzernen in fünf Jahren: volle Verantwortung, klare Kennzahlen, direktes Feedback und ein Geschäftsführer, der dich fordert und entwickelt.

Wenn du Lust auf eine Stelle hast, auf der du dich **sowohl persönlich als auch fachlich extrem weiterentwickelst** und eine der wichtigsten Verantwortungen in unserem Unternehmen übernehmen willst, dann trag dich jetzt ein.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
