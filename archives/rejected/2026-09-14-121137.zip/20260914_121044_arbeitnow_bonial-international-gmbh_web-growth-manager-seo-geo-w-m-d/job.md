# Web Growth Manager – SEO & GEO (w/m/d)

Posted: 2026-09-14T09:20:17Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

bonial ist Teil der Axel Springer SE und verändert als führender „Drive-to-Store“-Partner in Deutschland und Frankreich die Einzelhandelslandschaft. Über unsere Plattformen „[kaufDA](https://www.kaufda.de/)“ und „[MeinProspekt](https://www.meinprospekt.de/)“ in Deutschland sowie „[bonial](https://www.bonial.fr/)“ in Frankreich verbinden wir Millionen von Nutzer:innen mit ihren Lieblingsgeschäften und -marken – und erzielen so jeden Tag spürbare Wirkung.

Wir befinden uns mitten in einer spannenden Wachstumsphase, skalieren rasant und verändern die Art und Weise, wie Menschen den Einzelhandel entdecken. Bei bonial arbeiten wir in einem leistungsorientierten, dynamischen Umfeld, das von motivierten, ergebnisorientierten Persönlichkeiten geprägt ist, die mit Leidenschaft etwas bewegen wollen. Wenn Du Teil eines dynamischen Teams werden möchtest, das die Zukunft des Einzelhandels gestaltet, freuen wir uns, Dich kennenzulernen.

bonial heißt sowohl **Voll- als auch Teilzeit-Mitarbeiter:innen** willkommen!

Search verändert sich. Nutzer entdecken Marken, Produkte und lokale Angebote nicht mehr nur über klassische Google-Suchergebnisse, sondern zunehmend auch über AI Search und generative Antwortsysteme.

Als **Web Growth Manager – SEO & GEO** treibst du das nachhaltige organische Wachstum unserer Web-Plattformen **kaufDA, MeinProspekt und bonial.fr** voran.

Dein Schwerpunkt liegt auf **Search Engine Optimization (SEO) und Generative Engine Optimization (GEO)**. Gleichzeitig denkst Du über Rankings und Traffic hinaus: Du identifizierst Wachstumspotenziale entlang der gesamten User Journey und entwickelst gemeinsam mit Product, Development, Editorial Content und BI unsere Plattformen kontinuierlich weiter.

Bei uns bedeutet SEO nicht nur Keywords, Titles oder Content-Optimierung. Du arbeitest an großen Plattformen mit Millionen von URLs, entwickelst skalierbare Lösungen und kannst die Zukunft von Search und Web Growth aktiv mitgestalten.

**Deine Aufgaben:**

-

Du treibst das **organische Wachstum** von kaufDA, MeinProspekt und bonial.fr voran.

-

Du entwickelst unsere **SEO- und GEO-Strategie** weiter und leitest daraus konkrete Maßnahmen und Projekte ab.

-

Du optimierst unsere Sichtbarkeit sowohl in der **klassischen Google-Suche als auch in AI Search und generativen Antwortsystemen** wie Google AI Overviews, ChatGPT, Gemini oder Perplexity.

-

Du identifizierst Wachstumspotenziale rund um **Content, Landingpages, interne Verlinkung, technische SEO, UX und Conversion**.

-

Du verantwortest Web-Growth-Projekte von der **Analyse und Priorisierung über die Umsetzung bis zur Erfolgsmessung**.

-

Du arbeitest eng mit **Product & Development** zusammen und bringst SEO-, GEO- und Growth-Anforderungen in die Produktentwicklung und technische Roadmap ein.

-

Du analysierst Search-, User- und Performance-Daten, entwickelst Hypothesen und leitest daraus konkrete Optimierungen und Tests ab.

-

Du entwickelst skalierbare Lösungen für unsere Seitentypen und Templates und behältst dabei technische Qualität, Content und User Experience im Blick.

-

Du beobachtest Veränderungen im **Search-Ökosystem, bei AI Search und im Nutzerverhalten** und testest neue Ansätze frühzeitig.

**Dein Profil:**

-

Du bringst praktische Erfahrung im Bereich **SEO** mit und hast bereits eigenständig Optimierungsprojekte verantwortet.

-

Du hast ein gutes Verständnis von **Onpage SEO, Content SEO, Search Intent und interner Verlinkung**.

-

Du interessierst Dich für **GEO, AI Search und LLMs** und möchtest diesen Bereich aktiv mitgestalten. Praktische GEO-Erfahrung ist ein Plus, aber keine Voraussetzung.

-

Du denkst über Rankings hinaus und interessierst Dich auch für **UX, CRO, Product und Web Growth**.

-

Du arbeitest gerne datengetrieben und nutzt Daten, um Potenziale zu erkennen, Maßnahmen zu priorisieren und deren Impact zu messen.

-

Du hast Erfahrung mit Tools wie **Google Search Console, Screaming Frog, Sistrix oder vergleichbaren SEO-Plattformen**.

-

Du arbeitest gerne cross-funktional und kannst SEO- und Growth-Anforderungen gemeinsam mit Product, Development und Content in konkrete Lösungen übersetzen.

-

Grundkenntnisse in **HTML, CSS und Web-Technologien** sind von Vorteil.

-

Du kommunizierst sicher auf **Deutsch (min. C2) und Englisch**.

#### **Was uns besonders wichtig ist**

Du arbeitest **proaktiv, neugierig und eigenverantwortlich** und hast Lust, Dinge auszuprobieren und weiterzuentwickeln.

Du musst nicht jeden einzelnen Punkt erfüllen. Wenn Du ein starkes SEO-Fundament mitbringst und Dich gemeinsam mit uns in Richtung **GEO, AI Search und Web Growth** weiterentwickeln möchtest, freuen wir uns auf Deine Bewerbung.

**Was wir Dir bieten können: **

**High-Growth Story** – bonial ist ein wachstumsstarkes und dynamisches Unternehmen mit dauerhaftem Potenzial für die Zukunft. Wir sind eines der führenden Unternehmen und eine treibende Kraft in einer Branche, die gerade einen massiven, einmaligen Wandel von Print zu Digital erlebt.

**Innovation & Tech** – Wir sind ein High-Tech-Unternehmen mit Fokus auf innovative Technologien. Wir nutzen KI und andere Tools, um Produktivität und Effizienz zu steigern. Damit verbessern wir kontinuierlich die Leistung unseres Unternehmens und aller, die hier arbeiten – und erzielen gleichzeitig Ergebnisse für unsere Kund:innen und Nutzer:innen.
**Spannendes Umfeld für Deine berufliche Entwicklung** – Wir unterstützen Dich stark in Deiner beruflichen Entwicklung, gestützt von einer Feedback-Kultur, die Dir hilft, Deine Stärken und Chancen zu erkennen.

**Diversität** - Wir sind stolz darauf, ein Arbeitsplatz für Chancengleichheit zu sein, an dem wir es jeder Person ermöglichen möchten, ihr wahres selbst zu zeigen. Wir setzten uns für gleiche Beschäftigungsmöglichkeiten ein, und dafür, ein Safe Space zu sein unabhängig von ethnischer Herkunft, Religion, Geschlecht, sexueller Orientierung, Alter, Behinderung, Gender, Geschlechtsidentität oder Geschlechtsausdruck.

**Wohlbefinden** - Für uns ist mentale Gesundheit genauso wichtig wie Fitness. Deshalb bieten wir Dir einen kostenlosen Zugang zu nilo.health, einer App für mentale Gesundheit, an. Außerdem brauchst Du Dir keine Sorgen um Deine Rente machen, denn wir bezuschussen Deine betriebliche Altersvorsorge. Zusätzlich zu unserem internen Fitnesstudio, übernehmen wir auch einen Teil der Kosten für Urban Sports Club.

**Nachhaltigkeit** - Dir liegt das Thema Nachhaltigkeit am Herzen? Uns auch! Zusammen mit unserem Green Team bieten wir Dir die Möglichkeit, Dich in Projekten zu Nachhaltigkeit und Umweltschutz zu engagieren. Gemeinsam wollen wir unseren Beitrag leisten und den Planeten so positiv beeinflussen, wie wir nur können.

**Flexibilität** – Aktuell haben wir eine Regelung, die wöchentlich bis zu 20% mobiles Arbeiten innerhalb Deutschlands ermöglicht. Dazu darfst Du 30 Tage pro Jahr aus dem Ausland arbeiten. Zusätzlich bieten wir 28 Urlaubstage. Pro Kalenderjahr kommen ein weiterer Urlaubstag hinzu (bis zu maximal 30 Tage) sowie zusätzliche freie Tage für besondere Anlässe (z. B. Umzug, Mitarbeit an einem sozialen Projekt etc.).*

**Modernes** **Büro** - Wir haben ein eigenes und voll ausgestattetes Fitnessstudio, eine Dachterrasse für Team Events und Mittagspausen in der Sonne, sowie Zen Rooms, in denen Mitarbeitende beten, entspannen oder einfach eine ruhige Minute finden können.

**Kostenloses** **Mittagessen** - Wenn Du im Büro bist, bieten wir Dir verschiedene Optionen für ein Mittagessen an, und das Mittagessen geht auf uns! Du kannst in dem nahliegenden Partner-Restaurant essen gehen! Natürlich sind auch heiße sowie kalte Getränke, Obst und andere Snacks im Büro für unsere Mitarbeiter:innen kostenlos.*

**Soziale Kultur** - Ein gutes Miteinander ist uns wichtig, weshalb wir Wert auf eine Kultur legen, die dazu einlädt, miteinander ins Gespräch zu kommen, gute Arbeitsbeziehungen aufzubauen und sich gemeinschaftlich an Projekten zu beteiligen. Wir bieten außerdem regelmäßig optionale Events an, um dies weiter zu unterstützen.

**Partner für den Handel** – Wir ermöglichen es Händler:innen, ihre Kund:innen auf die effizienteste und wirkungsvollste Weise zu erreichen. Wir sehen uns als wichtigen Geschäftspartner für den Handel und – wie in unserer Unternehmensvision betont – „Bereichern wir das lokale Einkaufen für alle. Jeden Tag.“

**Hört sich das gut an für Dich? Wir freuen uns von Dir zu hören!**

Als Teil der Axel Springer Gruppe orientieren wir uns zusätzlich an den [Axel Springer Essentials](https://www.axelspringer.com/de/was-uns-ausmacht).

Besuche uns gerne auch auf unserer [bonial_people](https://www.instagram.com/bonial_people/?hl=en) Instagram Seite oder erfahre mehr über unsere bonial-Kultur unter [bonial Medium](https://medium.com/insidebonial).

*gemäß unseren aktuell gültigen Betriebsvereinbarungen

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
