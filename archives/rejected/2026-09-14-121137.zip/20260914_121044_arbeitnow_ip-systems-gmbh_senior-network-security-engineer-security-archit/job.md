# Senior Network & Security Engineer / Security Architect (m/w/d), Ref. 1381

Posted: 2026-09-14T11:00:27Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**IP Systems GmbH**

- **Gründung & Fokus:** 1999 gegründete Ingenieur- und Beratungsgesellschaft mit Schwerpunkt Telekommunikation und IT

- **Kunden:** Telekommunikation, Medien & Rundfunk, Transport & Logistik sowie öffentlicher Sektor

**Leistungen:**

- Fach- und Projektmanagement-Unterstützung

- Produkt- und Technologieeinführung

- Programm- und Projektsteuerung

- IT Security Services

- Professional Services sowie Programm- und Projektmanagement (klassisch, agil, hybrid)

**Kompetenz & Ansatz:**

- Multidisziplinäre Teams aus erfahrenen Ingenieuren, Informatikern und Wirtschaftsexperten

- Praxisnah, pragmatisch und lösungsorientiert

- Begleitung über den gesamten Lifecycle: von Konzeption und Einführung bis Implementierung und Betrieb

## Aufgaben

- Planung, Konzeption, Implementierung und Weiterentwicklung komplexer **Netzwerk- und Security-Infrastrukturen**

- Analyse bestehender Netzwerk- und Sicherheitsarchitekturen sowie Entwicklung und Umsetzung von **Optimierungs- und Migrationskonzepten**

- Konzeption und Migration von **Firewall- und Perimeter-Infrastrukturen**, insbesondere im Umfeld von Fortinet, Cisco, Palo Alto und Juniper

- Administration und Weiterentwicklung von **LAN-, WAN- und WLAN-Infrastrukturen**

- Planung und Umsetzung von **Security-Standards und Netzwerkarchitekturen** für nationale und internationale Standorte

- Entwicklung und Implementierung von Firewall-Policies, Security-Funktionen und Sicherheitsstandards

- Konzeption und Einführung von **Security-Management- und Monitoring-Lösungen**, u. a. FortiManager und FortiAnalyzer

- Unterstützung beim Aufbau, der Weiterentwicklung und dem Betrieb von **Security Operation Centern (SOC)**

- Analyse und Behebung komplexer Störungen im Netzwerk- und Security-Umfeld sowie Übernahme von **3rd-Level-Support und Eskalationen**

- Durchführung und Begleitung von **Migrationen und Rollouts** in komplexen und verteilten IT-Infrastrukturen

- Monitoring der Netzwerk- und Security-Infrastruktur zur Sicherstellung von **Verfügbarkeit, Stabilität und Sicherheit**

- Technische Beratung bei der Auswahl und Einführung neuer Security- und Netzwerktechnologien

- Durchführung von Trainings und Wissenstransfers für technische Teams und SOC-Mitarbeitende

- Übernahme von **Teilprojektleitungsaufgaben** sowie Koordination technischer Arbeitspakete und beteiligter Teams

- Abstimmung mit internen und externen Stakeholdern sowie technischen Fachbereichen

## Qualifikation

- Abgeschlossene Ausbildung im IT-Umfeld, idealerweise als Informationstechnischer Assistent (ITA) oder vergleichbare Qualifikation

- Mehrjährige Berufserfahrung im Bereich Netzwerk, IT-Security und Netzwerkadministration

- Fundierte Kenntnisse in der Planung, Konzeption und im Betrieb von Netzwerk- und Security-Infrastrukturen

- Sehr gute Kenntnisse im Umgang mit Fortinet- und Cisco-Technologien

- Erfahrung mit weiteren Herstellern wie Palo Alto, Juniper und Aruba von Vorteil

- Kenntnisse in Firewall-Architekturen, Firewall-Migrationen und Security Policies

- Erfahrung mit LAN, WAN, WLAN, Routing und Switching

- Kenntnisse in Netzwerkprotokollen und Routing-Technologien, beispielsweise OSPF und BFD

- Erfahrung mit 802.1X, SSO, Proxy-Lösungen und Security-Monitoring

- Erfahrung im SOC-Umfeld sowie im Betrieb und der Weiterentwicklung von Security-Infrastrukturen

- Kenntnisse im Bereich Troubleshooting und 3rd-Level-Support

- Erfahrung in der Erstellung und Umsetzung technischer Standards und Architekturvorgaben

**Zertifizierungen**

- Cisco **CCNP Routing & Switching (Must have)**

- Fortinet **FCNSP**

- Fortinet **NSE 1 / NSE 2**

- Fortinet **NSE 7**

**Persönliche Anforderungen**

- Fähigkeit, komplexe technische Sachverhalte verständlich aufzubereiten

- Bereitschaft zur Übernahme von Verantwortung in anspruchsvollen Netzwerk- und Security-Projekten

**Besonders relevante Projekterfahrung**

Der Schwerpunkt der Tätigkeit liegt auf der Konzeption, Migration und dem Betrieb moderner Netzwerk- und Security-Infrastrukturen. Dabei bestehen umfangreiche Erfahrungen mit Firewall- und Netzwerkumgebungen von Fortinet, Cisco, Palo Alto, Juniper und Aruba. Darüber hinaus verfügt der Stelleninhaber über praktische Erfahrung im Aufbau und der Weiterentwicklung von Security Operation Centern.

## Benefits

**Das bieten wir Dir:**

- Abwechslungsreiche Projektarbeit in unserem Kundenumfeld mit starkem Technologiebezug

- Individuelle Förderung in Form von fachspezifischen Weiterbildungen und Zertifizierungen (wie Work­shops, Schul­ungen und Trainings)

- Einfache Kommunikationswege auf verschiedenen Verantwortungsebenen

- Flache Hierarchien innerhalb unseres Unternehmens mit fami­liärer und produktiver Atmos­phäre

- Beteiligung am Unternehmenserfolg

- Hybrides Arbeiten mit flexiblen Arbeitszeiten

- Individuelle technische Arbeitsausstattung

- Zugang zu unserer Corporate Benefits-Plattform, quartalsweise Firmenveranstaltungen

- Einen unbefristeten Arbeitsvertrag mit 30 Urlaubstage, Heiligabend und Silvester sind zusätzlich arbeitsfrei

Fühlst Du dich angesprochen und findest Du dich in der Beschreibung wieder? Wir freuen uns über deine vollständigen Bewerbungsunterlagen mit **Referenz** ***1381***.

Wir sind sehr gespannt auf die Bewerbung!

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
