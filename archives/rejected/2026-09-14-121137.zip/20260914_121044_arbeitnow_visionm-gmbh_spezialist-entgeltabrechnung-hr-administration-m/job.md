# Spezialist Entgeltabrechnung & HR Administration (m/w/d)

Posted: 2026-09-14T08:30:34Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Für ein international aufgestelltes Technologieunternehmen mit mehreren deutschen Standorten suchen wir eine erfahrene Fachkraft für die vollständige Entgeltabrechnung und die ergänzende HR-Administration.

Die Position verbindet eigenständige Payroll-Verantwortung mit Zeitwirtschaft, Reporting, administrativen Aufgaben und der Mitwirkung an HR-Projekten.

## Aufgaben

- Sie führen die monatliche Entgeltabrechnung für einen definierten Mitarbeiterkreis eigenständig durch.

- Sie pflegen abrechnungsrelevante Personal- und Vergütungsdaten in den eingesetzten HR-Systemen.

- Sie erstellen Auswertungen, Reports, Bescheinigungen und Rückstellungen und bereiten Ergebnisse verständlich auf.

- Sie bearbeiten Themen der Zeitwirtschaft und prüfen Schnittstellen beziehungsweise Datenübergaben zur Entgeltabrechnung.

- Sie unterstützen bei Ein- und Austritten, digitalen Personalakten und weiteren administrativen HR-Prozessen.

- Sie wirken an der Optimierung und Digitalisierung von Payroll- und HR-Prozessen mit

## Qualifikation

- Sie verfügen über eine abgeschlossene kaufmännische Ausbildung, idealerweise ergänzt um eine Weiterbildung in der Lohn- und Gehaltsabrechnung.

- Sie bringen mehrjährige Erfahrung in der eigenständigen Entgeltabrechnung mit.

- Sie beherrschen die relevanten Grundlagen des Lohnsteuer- und Sozialversicherungsrechts.

- Sie arbeiten präzise, strukturiert, sorgfältig und diskret und verfügen über eine ausgeprägte Zahlenaffinität.

- Sie besitzen Erfahrung mit einem Abrechnungssystem, idealerweise P&I LOGA, sowie gute MS-Office- und Excel-Kenntnisse.

- Sie arbeiten serviceorientiert im Team und sind bereit, Wissen zu teilen und Prozesse weiterzuentwickeln.

## Benefits

- 30 Urlaubstage

- Mobiles Arbeiten im Rahmen einer grundsätzlich vorgesehenen 3/2-Regelung

- Gleitzeitregelungen

Wenn Sie die vollständige Entgeltabrechnung sicher beherrschen und zusätzlich administrative HR-Themen übernehmen möchten, freuen wir uns auf Ihre Bewerbung.

Bei Fragen steht Ihnen Sandra Heinrich unter der Rufnummer +49 179 3224223 gern zur Verfügung.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
