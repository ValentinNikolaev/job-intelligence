# Senior Strategic Solutions Consultant (AI)

Posted: 2026-09-14T08:55:04Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Celonis is the trusted platform to industrialize Enterprise AI. At our core is the Celonis Context Model — which combines process data, business knowledge, and intelligence into a living digital twin of the enterprise that AI can actually understand, turning AI's operational blind spots into operational clarity. World's leading companies trust Celonis and its global ecosystem of partners to make their AI agents, people, systems, and processes work together, achieving transformational outcomes. We believe there's a massive opportunity to unlock global productivity and sustainability by giving AI the context to understand how every business process really works. Join our mission to make processes work for people, companies, and the planet.

**The Team:**

As a Senior Strategic Solutions Consultant (internal title: Senior Applied Value Engineer )you push the envelope in solving mission-critical problems for our customers. You will work with our most strategic customers, understand their strategy and key challenges, and build Celonis solutions using cutting-edge AI technologies from market leaders such as Microsoft and OpenAI. With Celonis’ market-leading Process Intelligence (PI) Platform we feed operational context to AI so it understands our customers’ businesses and enables them to industrialize AI unlocking real ROI on AI deployments and at scale. There is no AI without PI. You will prototype these solutions, demonstrate their value to executives, and ensure successful implementation, adoption and value realization to increase Celonis' footprint at those customers.

**The Role:**

As Senior Applied Value Engineer, you are a strategic pioneer leading the charge in solving complex, business-critical problems for our customers. Working with our most strategic global accounts, you will diagnose their strategy and key operational challenges to **discover and build tailored, domain-specific use cases**. You will architect and prototype **state-of-the-art AI and technical solutions** on the Celonis platform, demonstrate their business impact to C-suite Executives, and ensure successful implementation, adoption, and value realization.

**Native-level German proficiency is required for this role. Candidates must be able to lead customer workshops, conduct executive presentations, and manage stakeholder interactions in German.**

**The work you’ll do:**

- **Discovery & Advanced AI Solutioning:** Act as the foremost Celonis product and domain positioning expert. Seamlessly translate deep domain expertise and complex customer requirements into flawless enterprise architecture. You will lead technical discovery to architect, prototype, and build bespoke, state-of-the-art AI solutions targeting nuanced operational pain points.

- **AI Solution Development:** Lead the end-to-end execution of high-stakes Proof-of-Value (PoV) projects. Architect and deliver highly secure, scalable LLM/agent systems with advanced RAG, tools, and strict guardrails; integrating flawlessly with rigid enterprise data, identity, and compliance frameworks.

- **Value Selling & Realization:** Act as a trusted advisor, maintaining active involvement with strategic accounts to ensure programmatic value realization until agreed-upon value, massive adoption thresholds, and operational transformations are achieved.

- **Domain & Industry Specialization:** Leverage deep domain expertise combined with cross-system, AI-driven solutioning to architect industry-specific E2E solutions. You will codify this work into reusable methodology and globally scalable assets to accelerate time-to-value and mentor junior peers.

**The qualifications you need:**

- **Executive-Facing Presales & Value Engineering (5+ years):** Demonstrated experience independently owning the technical close and driving compelling AI transformation narratives. Requires a proven background in accountable PoV execution, complex ROI/TCO modeling, and showcasing the "Art of the Possible" by pitching visionary solutions to hidden problems—with a clear track record of driving projects all the way through to achieved value.

- **Domain & Industry Expertise:** Comprehensive knowledge of core operational workflows and industry landscapes (e.g., supply chain, finance). You can speak the language of C-suite executives and seamlessly connect complex, systemic bottlenecks to strategic AI solutions.

- **Software/Data Engineering: **Python proficiency, modular API design, creating reusable libraries, advanced SQL, and scalable data integration using ML/AI frameworks (PyTorch, TensorFlow, scikit-learn, XGBoost, Hugging Face).

- **Strong presentation skills** to both internal and external stakeholders (including executives), whether whiteboarding sessions or formal readouts and demos.

- **Degree:** Masters Degree in computer science, engineering, mathematics or related fields, or equivalent work experience preferred.

- **Native-level or near-native German language skills (written and spoken), with the ability to confidently engage German-speaking customers, facilitate workshops, and present to executive stakeholders.**

**What Celonis can offer you:**

- Pioneer Innovation: Work with the global leader in Process Mining and the Process Intelligence Graph to shape the future of AI-driven business operations.

- Ownership from Day 1: Every full-time "Celonaut" is an owner, receiving Restricted Stock Units (RSUs) and merit-based refresh grants.

- Unrivaled Family Support: Benefit from our inclusive parental leave policy—24 weeks of fully paid leave for primary carers and 12 weeks for supporting carers, available from your first day of employment.

- Work-Life Integration: Enjoy Unlimited PTO (in applicable regions) and generous PTO globally, as well as a flexible hybrid work model that balances remote focus with vibrant office collaboration.

- Continuous Growth: Elevate your skills through our 70-20-10 learning framework, mentorship programs, and access to a dedicated learning platform.

- Holistic Well-being: Prioritize your health with subsidized Wellhub memberships, mental health counseling, and dedicated "Wellness Weeks" that prioritize work/life balance.

- Drive Sustainability: Participate in annual Impact Days, where you receive paid time off to volunteer for community and environmental causes with your local office, or virtually.

- Global Inclusion & Belonging: Find community through our Inclusion Think Tank and participate in our annual Inclusion Days, ensuring every voice is heard and valued.

- Value-Driven Impact: Join a mission-led organization where our core values—Live for Customer Value, The Best Team Wins, We Own It, and Earth Is Our Future—drive every decision.

**About Us:**

Celonis is the trusted platform to industrialize Enterprise AI, empowering organizations to analyze, design, and operate AI-driven processes. The Celonis Platform is powered by the Celonis Context Model, which combines process data, business knowledge, and intelligence to create a living digital twin of the enterprise that AI can understand — turning AI’s operational blind spots into operational clarity. Industry-leading companies around the world trust Celonis and its global ecosystem of partners to make their AI agents, people, systems, and processes work together, achieving transformational outcomes. Celonis is headquartered in Munich, Germany, and New York City, USA, with more than 20 offices worldwide.

Get familiar with the Celonis Process Intelligence Platform by watching this [video](https://www.youtube.com/watch?v=YR5oRJGhJYg&list=PLuVor-ZUD4pnM6G33C5D0tjXUvlTPYBRe).

**Celonis Inclusion Statement:**

At Celonis, we believe our people make us who we are and that “The Best Team Wins”. We know that the best teams are made up of people who bring different perspectives to the table. And when everyone feels included, able to speak up and knows their voice is heard - that's when creativity and innovation happen.**
**

**Your Privacy:**

Any information you submit to Celonis as part of your application will be processed in accordance with Celonis’ [Accessibility and Candidate Notices](https://www.celonis.com/careers/candidate-notices)

By submitting this application, you confirm that you agree to the storing and processing of your personal data by Celonis as described in our [Privacy Notice for the Application and Hiring Process](https://www.celonis.com/careers/privacy-notice/).

Please be aware of common job offer scams, impersonators and frauds. Learn more [here](https://www.celonis.com/careers/fraud-alert/).

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
