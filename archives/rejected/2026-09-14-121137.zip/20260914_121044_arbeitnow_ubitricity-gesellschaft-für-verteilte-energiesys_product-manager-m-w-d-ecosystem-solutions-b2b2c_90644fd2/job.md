# Product Manager (m/w/d) – Ecosystem Solutions (B2B2C)

Posted: 2026-09-14T10:31:03Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

## Deine Aufgaben

Die Mobilitätswende ist in vollem Gange und bringt große Herausforderungen sowie Chancen für die Zukunft der Elektromobilität mit sich.

Unser Ziel ist es, die passende Ladeinfrastruktur zur richtigen Zeit am richtigen Ort bereitzustellen. Als führender Anbieter öffentlicher Ladeinfrastruktur in Großbritannien arbeitet ubitricity gemeinsam mit Kommunen daran, Ladelösungen für Elektrofahrzeuge im öffentlichen Raum zu installieren und zu betreiben.

Um den Ausbau der Ladeinfrastruktur weiter zu beschleunigen, betreiben wir Laternenladepunkte, AC-Schnellladepunkte und DC-Schnellladestationen in Deutschland, Großbritannien, Frankreich und den Niederlanden. Als Product Manager im Ecosystem Team gestaltest du aktiv die Zukunft der Elektromobilität und sorgst dafür, dass das Laden von Elektrofahrzeugen für unsere Kund:innen einfach, zuverlässig und zugänglich wird.

**Deine Mission**

Du stellst die Bedürfnisse der Fahrer:innen von Elektrofahrzeugen in den Mittelpunkt aller Produktentscheidungen. Du verantwortest die Weiterentwicklung unserer Ökosystem-Services und Integrationen und sorgst dafür, dass das Ladeerlebnis vom Einstecken des Ladekabels bis zur erfolgreichen Bezahlung reibungslos funktioniert.

Dabei verbindest du interne Teams, Märkte und externe Partner zu einem leistungsfähigen Ökosystem, das Kundenzufriedenheit, operative Exzellenz und nachhaltiges Wachstum gleichermaßen fördert.

## Deine Aufgaben

- Du entwickelst zentrale Komponenten, Services und Integrationen unseres Charging Ecosystems weiter und stellst sicher, dass sie einen messbaren Mehrwert für Fahrer:innen und das Unternehmen schaffen.

- Du verantwortest das Budget für Entwicklungs- und Designinitiativen in deinem Produktbereich.

- Du steuerst API- und Systemintegrationen mit internen Teams sowie externen Partnern und Lieferanten und sorgst für eine nahtlose Customer Journey.

- Du arbeitest eng mit den Bereichen Software, Hardware, Operations und Commercial zusammen, um ein erstklassiges Ladeerlebnis zu schaffen.

- Du identifizierst proaktiv Kundenbedürfnisse, operative Herausforderungen und Marktchancen und leitest daraus neue Produktverbesserungen und Initiativen ab.

- Du priorisierst Anforderungen anhand von Kundennutzen, Business Value und strategischer Relevanz in einem Umfeld mit zahlreichen Stakeholdern.

- Du übersetzt Kunden-, Geschäfts- und technische Anforderungen in klare User Stories und umsetzbare Produktanforderungen.

- Du unterstützt iterative Produktentwicklungen und Pilotprojekte und befähigst lokale Märkte durch geeignete Tools, Dokumentationen und Prozesse.

- Du arbeitest eng mit Engineers zusammen, um Anforderungen zu konkretisieren, Entscheidungen zu treffen und pragmatische Lösungen zu finden.

- Du verantwortest die Qualität deines Produktbereichs und optimierst kontinuierlich die Art und Weise, wie Produkte entwickelt, ausgeliefert und betrieben werden.

- Du moderierst Scrum-Prozesse im Entwicklungsteam und koordinierst Arbeitspakete mit internen Stakeholdern.

- Du entwickelst und validierst neue UI-/UX-Konzepte direkt in unseren Anwendungen mit Unterstützung moderner KI-Tools wie GitHub Copilot, bevor diese technisch umgesetzt werden.

## Dein Profil

- Mindestens 3 Jahre Erfahrung als Technical Product Manager oder in einer vergleichbaren Rolle, idealerweise im Bereich Elektromobilität, Energie, IoT oder Hardware-Software-Ökosysteme.

- Technisches Verständnis über klassische Reporting- und Spreadsheet-Tools hinaus. Du arbeitest sicher mit APIs, Dashboards sowie Low-Code- oder No-Code-Plattformen, ohne selbst produktiven Code schreiben zu müssen.

- Souveräner Umgang mit KI-gestützten Tools wie GitHub Copilot im Arbeitsalltag.

- Ausgeprägte Kommunikations- und Stakeholder-Management-Fähigkeiten mit der Fähigkeit, technische und nicht-technische Zielgruppen zusammenzubringen.

- Starke Kundenorientierung und ausgeprägtes kommerzielles Verständnis mit der Fähigkeit, Produktentscheidungen aus Nutzersicht und unter wirtschaftlichen Gesichtspunkten zu treffen.

- Analytische und datengetriebene Arbeitsweise kombiniert mit einem hohen Qualitäts- und UX-Anspruch.

- Nachweisliche Erfahrung darin, Chancen zu erkennen, Lösungen zu entwickeln und Projekte eigenständig von der Idee bis zur Umsetzung voranzutreiben.

- Freude an komplexen Service- und Plattformumgebungen mit vielen internen und externen Stakeholdern.

- Pragmatische, kollaborative und anpassungsfähige Persönlichkeit.

- Englischkenntnisse auf C1-Niveau; Deutschkenntnisse sind von Vorteil.

## Unser Angebot

- Produkte mit echtem Einfluss auf die nachhaltige Mobilitätswende in einem etablierten und hervorragend positionierten Unternehmen.

- Große Gestaltungsmöglichkeiten, kurze Entscheidungswege und schnelle Umsetzung.

- Enge Zusammenarbeit mit Teams in Berlin, London und Amsterdam in einem agilen Umfeld, unterstützt durch eines der weltweit führenden Energieunternehmen.

- Spannende Entwicklungsmöglichkeiten in einem dynamisch wachsenden Unternehmen.

- Flexibles hybrides Arbeiten (3 Tage Büro, 2 Tage Remote) sowie bis zu 4 Wochen Remote Work pro Jahr aus dem Ausland.

- Ein zentral gelegenes Büro im Herzen Berlins.

- Ein Team, das mit Leidenschaft an der Zukunft der Elektromobilität arbeitet.

**Vielfalt und Inklusion**

Wir sind stolz auf unsere vielfältige Unternehmenskultur und sind überzeugt, dass unterschiedliche Perspektiven Innovation und Erfolg fördern. Inklusion und gegenseitiger Respekt bilden die Grundlage unserer Zusammenarbeit, unabhängig davon, ob wir mit Kolleg:innen, Partnern oder Kund:innen arbeiten. Jede Stimme zählt und wird gehört.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
