# Werkstudent:in Design & Social Media Assistenz (m/w/d)

Posted: 2026-09-14T09:00:39Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**gold&kind Boutique Branding Studio – Lindau – München - hybrid**

gold&kind ist ein Boutique-Designstudio, das Marken in Bewegung bringt. Sichtbar, zukunftsfähig und strukturiert. Unser Fokus liegt auf Brand-Management und Brand-Design für Unternehmen im Wandel. Wir arbeiten für renommierte Kunden im Bereich Hospitality und Lifestyle und unterstützen Premiummarken dabei, ihre Markenidentität neu aufzustellen und nachhaltig sichtbar zu bleiben.

Mit viel Liebe zum Detail, einem klaren Gespür für Ästhetik und strategischem Weitblick entwickeln wir Designs, die nicht nur gut aussehen, sondern echte Wirkung erzielen.

**Jetzt suchen wir dich als Unterstützung im Bereich Design & Social Media Assistenz! 🚀**

**Deine Mission**

Du arbeitest eng mit der Geschäftsführung zusammen und bringst Entlastung ins Tagesgeschäft. Ob Instagram-Post, LinkedIn-Content, Workshop-Präsentation oder Grafikprojekt. Mit deinem Gespür für Design und Struktur trägst du dazu bei, gold&kind sichtbar und stark aufzustellen.

## Aufgaben

**Deine Aufgaben**

- Du erstellst und bearbeitest markenkonforme Creatives wie Karussells, Reels und Slides und achtest darauf, dass Ästhetik und Tonalität unseren Standards entsprechen.

- Du pflegst und entwickelst unsere Designvorlagen und Markenstandards kontinuierlich weiter.

- Du unterstützt bei der Auswahl und Bearbeitung von Bildmaterial für interne und externe Projekte.

- Du bearbeitest täglich unser E-Mail-Postfach, koordinierst Projektanfragen und dokumentierst Freigaben strukturiert.

- Du unterstützt bei der Organisation und visuellen Vorbereitung unserer Workshops und stellst sicher, dass alle Unterlagen im Corporate Design gestaltet und vollständig vorbereitet sind.

- Du planst und postest eigenständig Inhalte auf Instagram und LinkedIn.

## Qualifikation

**Was wir uns wünschen**

- Gestalterisches Feingefühl: Du erkennst auf den ersten Blick, was „on brand“ ist – und bringst ein Auge fürs Detail mit.

- Eigeninitiative: Du wartest nicht nur auf Aufgaben, sondern fragst dich: "Wie kann ich heute für gold&kind Impact schaffen?"

- Kommunikationsstärke: Klar, freundlich, lösungsorientiert. Intern und gegenüber unseren Kunden.

- Organisationstalent: Du strukturierst und organisierst deine Projekte und Aufgaben eigenständig und gewissenhaft.

- Ownership: Deine Aufgaben sind dein Projekt. Du denkst mit, steuerst selbst und lieferst verlässlich ab.

**Dein Background**

- Laufendes Studium im Bereich Kommunikationsdesign, Mediendesign, Marketing oder Vergleichbares

- Erfahrung mit Figma, Canva Pro oder Adobe-Programmen (After Effects nice to have)

- Erste Erfahrung im Social Media Management oder Content Creation von Vorteil

- Verfügbarkeit: Ca. 16–20 Stunden/Woche, flexibel planbar

## Benefits

**Was dich bei gold&kind erwartet**

- **Ein kreatives Umfeld, das Marken neu definiert, mit Design auf höchstem Niveau und echtem Herzblut.**

- **Direkte Zusammenarbeit erfahrene Brand- und Kommunikationsdesignerin mit über 10 Jahren Branchenerfahrung im Luxus- und Lifestyle-Segment.**

- **Tiefe Einblicke in die Arbeit für Premiumkunden. Von der strategischen Markenentwicklung bis zum performanten Branding.**

- **Verantwortung ab Tag 1, du bist fester Bestandteil des Studios und kannst dich hier wirklich weiterentwickeln**

- **Boutique-Feeling mit großem Impact. Kleine Teams, große Ideen und Projekte, die wirklich etwas bewegen.**

Bereit, Teil von gold&kind zu werden? Dann bewirb dich jetzt!

**Wir freuen uns darauf, dich kennenzulernen! 🪩**

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
