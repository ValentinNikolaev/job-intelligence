# Trade Marketing & Brand Activation Specialist (m/w/d)

Posted: 2026-09-14T06:30:36Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**Über Crevel**

Du wirst Teil von Crevel Europe, einem globalen Importeur für mexikanische und amerikanische Lebensmittel in Europa. Mit einem Portfolio von mehr als 1.500 Produkten – von Mainstream- bis zu unabhängigen Marken – arbeiten wir mit B2B-Kunden in 33 europäischen Ländern. Wir gelten als Maßstab für den internationalen Lebensmittelimport in Europa!

Du willst nicht nur Kampagnen planen, sondern sehen, wie deine Ideen im Regal, beim Kunden und am POS tatsächlich ankommen? Dann werde Teil von Crevel als Trade Marketing & Brand Activation Manager und bring unser Portfolio im deutschen Handel auf die Straße.

## Aufgaben

**Deine Rolle**

Du übersetzt unsere Markenstrategie in wirksame Launches, überzeugende Kundenunterlagen und starke POS-Präsenz – über Modern Trade, Discounter, Super- und Hypermärkte, Restposten und ausgewählte traditionelle Kanäle hinweg. Du bist die Verbindung zwischen Marke, Vertrieb und Umsetzung.

**Was du machst**

🎯 Channel-Strategie & Umsetzung – du übersetzt Markenprioritäten in konkrete Aktivierungspläne pro Kunde und Kanal

🚀 Launches & Promotions – von der Idee bis zum fertigen Launch-Paket inkl. POS-Material, Sampling und Zweitplatzierungen

🤝 Kundenpräsentationen & Sales-Support – du erstellst Decks, Launch-Sheets und Verkaufsunterlagen, die beim Kunden wirklich überzeugen

🌍 Markenadaption für den deutschen Markt – du machst internationale Konzepte für den lokalen Handel relevant und umsetzbar

🔗 Schnittstellen- & Agentursteuerung – du koordinierst Sales, Design, Einkauf, Supply Chain und externe Partner

📊 Performance Tracking – du behältst KPIs im Blick und lernst aus jeder Aktivierung

## Qualifikation

**Was du mitbringst**

✔️ Abgeschlossenes Studium in Marketing, BWL oder vergleichbar

✔️ 4–6+ Jahre Erfahrung in Trade Marketing, Shopper Marketing oder Channel Marketing, idealerweise im FMCG-Bereich (Food/Beverage/Consumer Goods von Vorteil)

✔️ Erfahrung mit Sell-in/Sell-out-Support, Launches und POS-Konzepten

✔️ Sattelfest in PowerPoint & Excel

✔️ Deutsch auf muttersprachlichem Niveau, sehr gutes Business-Englisch – Spanisch ist ein Plus

✔️ Hands-on-Mentalität, Organisationstalent und Lust, in einem schlanken, unternehmerischen Umfeld Verantwortung zu übernehmen

**Warum Crevel?**

Bei uns bekommst du echten Gestaltungsspielraum, kurze Wege und die Möglichkeit, direkt zu sehen, was deine Arbeit bewirkt.

Klingt nach dir? Dann freuen wir uns auf deine Bewerbung!

#TradeMarketing #FMCG #Jobs #Marketing #Deutschland #Crevel

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
