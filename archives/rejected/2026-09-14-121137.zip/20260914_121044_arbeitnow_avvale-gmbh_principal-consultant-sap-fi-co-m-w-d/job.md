# Principal Consultant SAP FI/CO (m/w/d)

Posted: 2026-09-14T10:00:31Z

## Rejection

- Category: language_requirement
- Reason: hard German language requirement without English green light

Tauche ein in ein Universum grenzenloser Möglichkeiten und gestalte aktiv unsere gemeinsame Zukunft mit - werde Teil von Avvale in Deutschland!

Um das Potenzial unserer Kunden optimal zu nutzen und unser SAP-Beratungsportfolio weiterzuentwickeln, suchen wir einen Principal Consultant SAP FI/CO (m/w/d), der umfassende SAP-Expertise mit strategischem Denken, ausgeprägter Kundenorientierung und hoher Eigenverantwortung verbindet.

Als Principal Consultant übernimmst du eine zentrale Rolle in anspruchsvollen SAP-Transformations- und S/4HANA Projekten. Du berätst unsere Kunden auf fachlicher und strategischer Ebene, entwickelst zukunftsfähige Lösungskonzepte und übernimmst Verantwortung für deren erfolgreiche Umsetzung. Gleichzeitig bringst du deine Erfahrung aktiv in die Weiterentwicklung unseres Teams und unseres SAP Finance Beratungsportfolios ein.

## Aufgaben

- Du übernimmst die fachliche Verantwortung in anspruchsvollen SAP FI/CO- und S/4HANA-Projekten, von der Analyse und Konzeption bis zur erfolgreichen Implementierung

- Du berätst unsere Kunden strategisch und fachlich bei der Optimierung und Digitalisierung ihrer Finance und Controlling Prozesse

- Du konzipierst ganzheitliche SAP-Lösungsarchitekturen und entwickelst nachhaltige Lösungskonzepte unter Berücksichtigung bestehender Systemlandschaften und Geschäftsanforderungen

- Du steuerst eigenverantwortlich komplexe Workstreams und übernimmst eine führende Rolle an der Schnittstelle zwischen Fachbereich, IT und Projektmanagement

- Du begleitest S/4HANA-Transformationen und Migrationen und bringst deine Erfahrung bei der Gestaltung zukünftiger Finance-Prozesse ein

- Du fungierst als fachliche Ansprechperson für unsere Kunden und baust langfristige, vertrauensvolle Kundenbeziehungen auf

- Du unterstützt bei Presales-Aktivitäten, Workshops, Angeboten und der Entwicklung neuer Beratungsansätze und Geschäftsmöglichkeiten

- Du übernimmst fachliches Mentoring für Consultants und Senior Consultants und unterstützt sie bei ihrer fachlichen und persönlichen Weiterentwicklung

- Du arbeitest eng mit unseren nationalen und internationalen Teams zusammen und bringst Best Practices sowie neue SAP-Technologien aktiv in unsere Projekte ein

- Als Teil unseres Enterprise Operations Teams gestaltest du die Weiterentwicklung unseres SAP-FI/CO-Portfolios und unserer Beratungsleistungen aktiv mit

## Qualifikation

- Erfolgreich abgeschlossenes Studium im Bereich Betriebswirtschaftslehre, Wirtschaftsinformatik oder eine vergleichbare Qualifikation

- Mehrjährige, fundierte Berufserfahrung im SAP Consulting mit Schwerpunkt SAP FI und/oder CO

- Tiefgehende Kenntnisse finanzwirtschaftlicher und controllingbezogener Geschäftsprozesse sowie deren Abbildung in SAP

- Umfangreiche Erfahrung mit SAP S/4HANA und idealerweise mehreren Implementierungs-, Transformations- oder Migrationsprojekten

- Erfahrung in der fachlichen Leitung von Projektteams oder Workstreams sowie in der Steuerung komplexer Kundenanforderungen

- Ausgeprägte Fähigkeit, komplexe fachliche und technische Zusammenhänge zu analysieren und daraus nachhaltige Lösungskonzepte zu entwickeln

- Souveränes Auftreten auf Kunden- und Managementebene sowie ausgeprägte Beratungs- und Kommunikationskompetenz

- Erfahrung im Presales, in der Angebotserstellung oder im Business Development ist von Vorteil

- Freude daran, Wissen weiterzugeben und weniger erfahrene Kolleginnen und Kollegen fachlich zu begleiten

- Fließende Deutschkenntnisse und sehr gute Englischkenntnisse

- Strukturierte und eigenverantwortliche Arbeitsweise sowie ausgeprägte konzeptionelle und analytische Fähigkeiten

- Flexibilität, Reisebereitschaft und eine hohe Kunden- und Ergebnisorientierung runden dein Profil ab

## Benefits

- Arbeitsmodell nach Deinen Bedürfnissen: Genieße Flexibilität durch flexible Arbeitszeiten und einen Mobile Office Vertrag.

- Attraktives Vergütungspaket: Neben einem wettbewerbsfähigen Grundgehalt bieten wir Dir die Option auf einen Firmenwagen sowie großzügige Beiträge zur betrieblichen Altersvorsorge.

- Mobilitätsoptionen: Profitiere von einem Firmenwagen für Deine flexible und komfortable Mobilität im Arbeitsalltag sowie von einem Zuschuss zum Leasing eines E-Bikes im Rahmen unseres Dienstrad-Programms.

- Agile Unternehmensstruktur: Bei uns genießt Du die Freiheit, Verantwortung zu übernehmen, eigene Ideen einzubringen und die Weiterentwicklung unseres Beratungsportfolios aktiv mitzugestalten. Dabei profitierst Du von flachen Hierarchien und kurzen Entscheidungswegen.

- Individuelle Karrierebegleitung und fokussierte Entwicklung: Persönliches Mentoring und zielgerichtete Entwicklungsgespräche bilden die Grundlage für kontinuierliche berufliche Entwicklung und neue Verantwortungsbereiche.

- Individuell gestaltbare Weiterbildung: Du erhältst bei uns die Freiheit, aus einer Reihe von Weiterbildungsinitiativen diejenigen auszuwählen, die Deinen beruflichen und persönlichen Entwicklungszielen entsprechen.

- Internationales Netzwerk und Team-Events: Tausche Dich innerhalb eines globalen Kolleg aus und nimm an regelmäßigen Firmenevents teil.

Wir suchen Dich!

Starte mit uns in eine aufregende neue Beratungszeit und gestalte aktiv unsere gemeinsame Zukunft mit.

In Deutschland erstrecken sich unsere Dienst- und Beratungsleistungen über eine breite Palette von Branchen und Themen, wobei unsere besondere Kompetenz im SAP-Umfeld liegt. Unsere Schwerpunkte umfassen SAP ERP Consulting & S/4HANA Migration, Digital Experience & Cloud Innovations, System Integration sowie Application Lifecycle Management.

Unser Leistungsportfolio reicht von der Implementierung und Maintenance führender SAP-Lösungen bis hin zur Planung und Entwicklung maßgeschneiderter digitaler Plattformen. Darüber hinaus bieten wir umfassende Beratungsleistungen im Test-, Incident- und Change-Management.

Werde Teil von Avvale und gestalte mit uns die nächste Generation digitaler Transformation.

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
