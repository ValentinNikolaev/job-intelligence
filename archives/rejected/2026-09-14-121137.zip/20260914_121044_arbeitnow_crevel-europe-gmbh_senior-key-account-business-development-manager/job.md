# Senior Key Account & Business Development Manager (m/w/d)

Posted: 2026-09-14T06:30:36Z

## Rejection

- Category: tech_stack
- Reason: role does not mention Go/Golang or PHP

Du wirst Teil von Crevel Europe, einem globalen Importeur für mexikanische und amerikanische Lebensmittel in Europa. Mit einem Portfolio von mehr als 1.500 Produkten – von Mainstream- bis zu unabhängigen Marken – arbeiten wir mit B2B-Kunden in 33 europäischen Ländern. Wir gelten als Maßstab für den internationalen Lebensmittelimport in Europa!

Für die nächste Wachstumsphase in Deutschland suchen wir jemanden, der neue Kunden gewinnt, Kanäle erschließt und starke Handelsbeziehungen aufbaut – und der dabei den gesamten Prozess seiner Accounts eigenständig von Anfang bis Ende verantwortet.

## Aufgaben

Du verbindest strategisches Key Account Management mit proaktivem Business Development - von der ersten Chance bis zum erfolgreichen Sell-in und der eigenständigen, laufenden Betreuung deiner Kunden. Du berichtest an den Head of Commercial DACH und arbeitest im Team mit zwei weiteren Key Account Managern, verantwortest aber deine eigenen Accounts vollständig von A bis Z.

Neukunden & Kanäle Du baust dir deine eigene Pipeline auf und erschließt neue Kunden in LEH, Discount, Drogerie, Großhandel, Foodservice und E-Commerce.

Key Account Management Du verantwortest Umsatz, Marge und Listungen bei deinen strategischen Kunden und baust vertrauensvolle Beziehungen zu Einkäufern auf.

Sell-in & Launches Du entwickelst überzeugende Sell-in-Stories und bringst gemeinsam mit Trade Marketing neue Produkte und Aktivierungen erfolgreich in den Handel.

Eigenständige Kundenbetreuung Die Kunden, die du gewinnst, betreust du eigenständig über den gesamten Zyklus - inklusive administrativer Aufgaben wie Rechnungsstellung (über unser ERP-System Odoo). Bei uns liegt die Verantwortung für einen Account bei einer Person, nicht verteilt über mehrere Abteilungen.

Reisetätigkeit Du besuchst deine Kunden regelmäßig vor Ort in Deutschland - die Reisetätigkeit richtet sich nach den Kunden, die du betreust.

## Qualifikation

**Was du mitbringst**

- 5+ Jahre Erfahrung im Key Account Management, Business Development oder Vertrieb in FMCG, Food, Beverage oder Consumer Goods

- Erfahrung mit deutschen Handelskanälen (LEH, Discount, Drogerie, Großhandel, Foodservice oder E-Commerce), idealerweise mit direktem Buyer-Kontakt

- Nachweisbare Erfolge in der Neukundengewinnung oder im Ausbau bestehender Accounts

- Hands-on-Mentalität: Du bist es gewohnt, deine Accounts eigenständig zu managen - von der Verhandlung bis zur Administration - statt Aufgaben an andere Abteilungen abzugeben

- Dynamisch, flexibel und komfortabel in einer schlanken Startup-Struktur

- Erfahrung mit ERP-Systemen (Odoo von Vorteil, aber kein Muss)

- Reisebereitschaft innerhalb Deutschlands

- Wohnsitz in Deutschland

- Deutsch auf muttersprachlichem Niveau, sehr gutes Business-Englisch; Spanisch von Vorteil

- Lust auf eine unternehmerische Umgebung mit kurzen Entscheidungswegen

## Benefits

**Was dich erwartet**

- Direkter Zugang zu den Gründern und der Geschäftsführung

- Ein internationales Markenportfolio mit viel Entwicklungspotenzial

- Echte Verantwortung ab Tag 1 – keine Konzern-Bürokratie, sondern schnelle Entscheidungen

- Ein eingespieltes Team aus drei Key Account Managern, die eng zusammenarbeiten

- Remote-Arbeit von überall in Deutschland

**Bewerbungsprozess**

Kurzes Screening-Gespräch mit HR, danach eine Case Study mit dem Commercial-Team.

Interessiert? Wir freuen uns auf deine Bewerbung!

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
