# Social Media Marketing Manager / Digital Marketing Manager (w/m/d)

Posted: 2026-09-14T09:30:30Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**Werde Teil von MALUU – Unser junges Label braucht deine kreativen Ideen!**

Du liebst Social Media, denkst in Stories, Reels und Kampagnen? Du hast ein Gespür für Trends und weißt, wie man mit cleverem Digital Marketing Reichweite generiert? Perfekt – wir suchen einen kreativen **Social Media Manager / Digital Marketing Manager (w/m/d)** für unsere Marke **MALUU**, der mit frischen Ideen, Know-how und Leidenschaft unser junges Label noch sichtbarer und einzigartiger macht.

MALUU ist kleines, kreatives Familienunternehmen im Rhein-Neckar-Kreis (Nähe Speyer) mit echten StartUp-Vibes. Als Teil von uns wirst du unsere Marke aktiv mitgestalten, unsere Community ausbauen und unsere Online-Präsenz auf das nächste Level bringen.

## Aufgaben

- Du erstellst abwechslungsreichen Content und kreative Content-Strategien für unsere digitalen Plattformen mit Texten, Bildern, Reels und Videos anhand unseres Redaktionsplans und in enger Abstimmung mit der Geschäftsleitung

- Du entwickelst und steuerst kreative Social Media Kampagnen für unsere Kanäle

- Du betreust unsere Community und baust den Austausch mit Followern und potenziellen Kund:innen weiter aus

- Du betreust und optimierst unsere Website inkl. Content-Management, SEO und Frontend

- Du bringst kreative Impulse für unsere Online-Strategie ein und hältst uns bei Trends und Tools up to date

- Du analysierst Erfolge, Reichweiten und KPIs – und leitest daraus neue Ideen und Optimierungen ab

- Du planst, steuerst und optimierst Performance-Marketing-Kampagnen, insbesondere über **Google Ads und Social Ads**

- Du entwickelst und setzt regelmäßige Newsletter um

## Qualifikation

- Du verfügst über ein abgeschlossenes Studium oder eine vergleichbare Ausbildung in den Bereichen Marketing, Kommunikation, PR oder einem vergleichbaren Fachgebiet

- Du konntest bereits mind. 2 Jahre Berufserfahrung als Social Media Manager, Digital Marketing Manager oder in einem vergleichbaren Aufgabengebiet sammeln

- Deine Eigeninitiative und offene Kommunikation ermöglichen dir die eigenverantwortliche Erstellung von Inhalten, Fotos und Videos nach unseren CI-Vorgaben

- Du bist analytisch stark, arbeitest strukturiert und kannst eigenverantwortlich Projekte umsetzen

- Du bist zuverlässig, proaktiv und lösungsorientiert

- Du hast eine kreative Art in Verbindung mit einer sehr guten Schreib- und Kommunikationsfähigkeit in Deutsch und Englisch

- Der Umgang mit CMS (Typo3, WordPress) und Tools wie Canva, Adobe Creative Suite sowie der META Business Suite ist dir vertraut

- Reisebereitschaft für unsere Fachmessen

## Benefits

- Ein kreatives, motiviertes Team und flache Hierarchien

- Ein ansprechendes Kreativbüro mit moderner Austattung

- Ein junges Label mit viel Potenzial, das du von Anfang an mitprägen kannst

- Spannende Projekte, abwechslungsreiche Aufgaben und jede Menge kreativer Freiraum

- Eigenverantwortliches Arbeiten

- Flexible Arbeitszeiten nach Absprache

- Leistungsgerechte Bezahlung

- 30 Tage Urlaub auf Basis einer 5-Tage-Woche

Das klingt genau nach deiner Welt? Super – dann freuen wir uns sehr darauf, dich kennenzulernen!

Damit wir direkt einen echten Eindruck von dir bekommen, bewirb dich gerne auch **mit einem kurzen Bewerbungsvideo**. ( z.B. als Downloadlink zu deiner E-Mail)

Erzähl uns darin, wer du bist, was dich motiviert und warum du Lust hast, unser Marketing mitzugestalten. Ganz unkompliziert, authentisch und gern kreativ – so wie du bist.

Wir sind gespannt auf deine Persönlichkeit, deine Energie und deine Ideen – und freuen uns darauf, dich schon bald zu sehen!

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
