# (Senior) Full-Stack Engineer (all genders)

Posted: 2026-09-14T10:00:29Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Ark builds AI platforms for public administrations, starting with climate action and expanding into other administrative workflows. More than 60 cities, counties and states use our products, including Munich, Berlin and Schleswig-Holstein. We have won the German Startup Award 2026 and raised €2.4 million in pre-seed funding.

## Tasks

Build tools for emissions analysis, cross-department project coordination and administrative automation. Work closely with engineering, product and customer success.

- Own features end to end: from understanding the user problem to imple-mentation, release and iteration.

- Deliver reliable software: make pragmatic technical decisions, with security, tests and maintainability built in.

- Strengthen engineering: contribute through code reviews and improvements to our development workflow.

We welcome mid-level and senior engineers. At senior level, you will also guide architectural decisions and mentor colleagues. This is a hands-on role, not a management position.

## Requirements

- You have shipped and maintained web applications across frontend and backend.

- You work with TypeScript, React, NestJS (Node.js) and PostgreSQL.

- You turn ambiguous requirements into manageable tasks, flag uncertainty early and seek feedback.

- You want to improve public-sector work. Climate or GovTech experience is not required.

Nice to have: Cloud infrastructure, Kubernetes, CI/CD, data pipelines or AI-powered features.

## Benefits

- Influence on product direction and technical decisions.

- Salary based on experience and responsibility, plus virtual employee participation (VSOP).

- 30 days of paid annual leave.

- Direct feedback, shared learning and team events.

- EGYM Wellpass / Urban Sports Club membership, bike leasing and discounts on sustainability brands.

We are looking forward your application! Project or code samples are welcome, not required. You do not need to tick every box to apply.

We can currently only hire candidates based in the EU or authorised to work here.

Ark is an equal opportunity employer. We welcome applicants of all backgrounds.

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
