# Ingenieur HKLS (m/w/d)

Posted: 2026-09-14T08:00:41Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Als Mechanical Engineer bist Du ein wichtiger Teil unserer Projektteams und unterstützt die Planung und Entwicklung technischer Lösungen für anspruchsvolle Gebäudeprojekte. Gemeinsam mit erfahrenen Kolleg:innen arbeitest Du an der Auslegung und Umsetzung mechanischer Gebäudetechnik und sammelst wertvolle Erfahrungen über verschiedene Projektphasen hinweg.

Du erhältst die Möglichkeit, Deine technische Expertise kontinuierlich auszubauen und Verantwortung in komplexen Projekten zu übernehmen.

## Aufgaben

- Mitarbeit bei der Planung und Auslegung mechanischer Gebäudetechnik für anspruchsvolle Projekte

- Unterstützung bei der Entwicklung technischer Konzepte in verschiedenen Leistungsphasen nach HOAI

- Durchführung technischer Berechnungen und Analysen

- Erstellung und Pflege von BIM-Modellen sowie Planungsunterlagen

- Mitwirkung bei Ausschreibungen und Vergabeprozessen

- Zusammenarbeit mit interdisziplinären Projektteams sowie externen Projektbeteiligten

- Unterstützung bei der Koordination technischer Schnittstellen zwischen verschiedenen Gewerken

- Mitwirkung an nachhaltigen und innovativen Planungslösungen

## Qualifikation

- Abgeschlossenes Studium im Bereich Versorgungstechnik, Gebäudetechnik, Energietechnik oder eine vergleichbare Qualifikation

- Erste relevante Berufserfahrung in einem Planungs- oder Ingenieurbüro

- Grundkenntnisse der relevanten Normen und Regelwerke

- Interesse an BIM-basierten Planungsmethoden, idealerweise mit ersten Erfahrungen in Revit und/oder MagiCAD

- Begeisterung für technische Herausforderungen und nachhaltige Gebäudetechnik

- Freude an Teamarbeit und interdisziplinärer Zusammenarbeit

- Sehr gute Deutschkenntnisse sowie gute Englischkenntnisse

## Benefits

**Flexibilität& Wellbeing**

Flexible und hybride Arbeitsmodelle, Wellbeing-Initiativen und Unterstützungsangebote, die Dir helfen, Beruf und Privatleben in Einklang zu bringen.

**Meaningful Work & Global Collaboration**

Die Möglichkeit, an spannenden und herausfordernden Projekten mit lokalem und internationalem Einfluss zu arbeiten und dabei mit multidisziplinären Teams aus unserem globalen Netzwerk zusammenzuarbeiten.

**Learning, Development & Career Growth**

Klare Karrierepfade, regelmäßige Entwicklungsgespräche sowie interne und externe Weiterbildungsmöglichkeiten zur Unterstützung Deiner fachlichen und persönlichen Entwicklung.

**Reward & Recognition**

Regelmäßige Gehaltsüberprüfungen sowie leistungsbezogene Bonusmöglichkeiten, die Deinen Beitrag und Erfolg anerkennen.

**Inclusive Culture & Community**

Ein kollaboratives und inklusives Umfeld mit zahlreichen Möglichkeiten zum Wissensaustausch, Networking sowie regelmäßigen Team- und Community-Events.

**Innovation & International Opportunities**

Die Chance, eigene Ideen einzubringen, Verantwortung zu übernehmen und internationale Entwicklungs- und Karrieremöglichkeiten zu nutzen.

**Agile Working Environment**

Flache Hierarchien und kurze Entscheidungswege, die schnelle Zusammenarbeit und eigenverantwortliches Arbeiten ermöglichen.

**Zusätzlich in Deutschland**

- 30 Urlaubstage

- Zugang zu unserem Mental Wellbeing Programme

- Flexibles Benefitprogramm für Fitness, Mobilität, Altersvorsorge und mehr

- Sprachkurse

- Lunch Roulette

- Young Employee Forum

- Regelmäßige Team- und Social Events

**Bereit für den nächsten Schritt? - Wir freuen uns auf Deine Bewerbung.**

Werde Teil unseres Berliner Teams und gestalte mit uns nachhaltige Lösungen für die Herausforderungen der gebauten Umwelt.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
