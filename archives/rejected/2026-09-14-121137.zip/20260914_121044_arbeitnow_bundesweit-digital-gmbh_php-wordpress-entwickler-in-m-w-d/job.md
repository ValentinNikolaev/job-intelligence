# PHP/WordPress Entwickler*in (m/w/d)

Posted: 2026-09-14T10:00:30Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Wir suchen ab sofort Unterstützung im Team im Bereich PHP/WordPress Entwicklung.

Das ist genau dein Thema und du bringst bereits Erfahrung mit? Dann freuen wir uns auf deine Bewerbung!

## Aufgaben

Aktive Mitarbeit als auch Unterstützung bei folgenden Aufgaben:

- Entwicklung und Betrieb von Websites und Webanwendungen, von der Einrichtung bis zum laufenden Betrieb mit allem, was dazu gehört

- Betreuung von Kundenprojekten: Neuentwicklungen, Umbauten, Wartung und Support

- Anbindung externer Schnittstellen und APIs

## Qualifikation

**Must-Have:**

- Fundierte WordPress/PHP Kenntnisse

- Routine in der Teamarbeit mit Git und GitHub

- Kenntnisse im Serverbetrieb: SSH, Logs, Domains, Hosting

- Erfahrung im Einsatz von KI-Werkzeugen wie Claude Code, verbunden mit einem kritischen Blick auf die Ergebnisse

- Sehr gute Deutschkenntnisse (Verhandlungssicher) für die Kommunikation mit Kunden

- Eigeniniative und Kommunikationsfähigkeit

**Good to Know:**

- Laravel, Livewire, Tailwind

## Benefits

- Freiheit, Vertrauen und Verantwortung für die Aufgaben, für die wir dich einstellen

- Flexibilität bei Arbeitszeit und -ort, damit Karriere und persönliches Leben zusammenpassen

- Weiterbildungen — dauerhaft neue Fähigkeiten zu erwerben, ist wichtiger denn je

- Anständiges Equipment: Gute Geräte sind bei uns ein Must-have, kein Sonderfall

**Was dich erwartet:**

Ein kleines Team mit kurzen Entscheidungswegen und direktem Kontakt zu Kunden und Produkt. Wir arbeiten eigenverantwortlich und legen Wert auf Rückfragen zum richtigen Zeitpunkt sowie auf nachvollziehbare Ergebnisse.

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
