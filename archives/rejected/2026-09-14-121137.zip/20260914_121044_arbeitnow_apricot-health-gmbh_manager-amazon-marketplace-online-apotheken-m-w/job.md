# Manager Amazon Marketplace & Online-Apotheken (m/w/d)

Posted: 2026-09-14T10:00:31Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Apriwell ist ein schnell wachsendes Consumer-Health-Unternehmen. Wir geben Menschen mit häufigen, wiederkehrenden Beschwerden ihre Freiheit zurück.

Dieses Ziel erreichen wir durch die Kombination aus patentierten, verschreibungsfreien Therapeutika und modernster digitaler Versorgung. Unser Ansatz funktioniert: Das belegen über 100.000 Kunden, mehr als 4.000 5-Sterne-Bewertungen und über 15 publizierte klinische Studien.

Für Dich heißt das: Nachfrage und Kundenzufriedenheit sind vorhanden, auf Amazon sind wir seit mehreren Jahren aktiv und alle relevanten Online-Apotheken sind bereits angebunden. Du startest nicht bei null, sondern hast das ideale Fundament zur weiteren Skalierung.

**Die Rolle**

Als **Marketplace Manager** verantwortest Du den strategischen und operativen Ausbau unserer externen Vertriebskanäle Amazon (3P) und Online-Apotheken (1P)(z.B. Shop Apotheke und DocMorris).

Du steuerst strategisch unsere Performance-Agentur für Amazon PPC & DSP, hebst Conversion-Potenziale im Listing durch kontinuierliche A/B-Tests und nutzt Retail Media sowie gezielte WKZ-Aktionen, um den Sell-out auf den Plattformen zu maximieren. Du hast alle Hebel selbst in der Hand: Pricing, Promotions, Bestände, Listing-Content und Kampagnenbudgets - und erzielst damit profitables Wachstum.

## Aufgaben

**Amazon Marktplatz-Wachstum**

- Du treibst das profitable Wachstum auf Amazon voran, indem du unsere Performance-Agentur für PPC und DSP strategisch führst, Budgets allozierst und Kampagnen anhand klarer KPIs (Umsatz, ACOS, TACOS, Deckungsbeitrag) kontinuierlich weiterentwickelst.

- Du steigerst Sichtbarkeit und Abverkauf durch datengetriebene Listing-Optimierung auf Basis fundierter Keyword-, Wettbewerbs- und Conversion-Analysen und AB-Tests.

- Du entwickelst gezielte Promotions sowie Launch-Strategien (z. B. Prime Day, Coupons), behältst Bestände und Account Health proaktiv im Blick und löst marktplatzspezifische Support- und Richtlinienfälle zügig, um eine reibungslose Skalierung zu sichern.

**Skalierung Online-Apotheken**

- Du entwickelst unsere Partner Online-Apotheken (z. B. Shop Apotheke, DocMorris) kontinuierlich weiter und hebst Umsatzpotenziale durch den gezielten Einsatz von Retail Media, WKZ und verkaufsstarken Aktionen.

- Du planst, verhandelst und steuerst den gezielten Einsatz von Retail Media, Sponsored Ads, WKZ und Plattform-Promotions für maximalen Sell-out.

- Du stellst exzellenten Content, optimierte Suchbegriffe und überzeugendes Bildmaterial auf den E-Pharma-Plattformen sicher, um Rankings und Conversion Rates stetig zu verbessern.

**Kommerzielle Steuerung**

- Du steuerst die vorausschauende Absatz- und Bedarfsplanung für Deine Kanäle und arbeitest eng mit der Supply Chain zusammen.

- Du analysierst Vertriebskennzahlen, Margen und Werbeeffizienzen, leitest daraus klare Wachstumsmaßnahmen ab und stimmst Dich eng mit Marketing, Finance und Geschäftsführung ab.

## Qualifikation

- Mehrjährige relevante Berufserfahrung im Amazon Marketplace Management, idealerweise im Bereich Consumer Health (OTC, Beauty, NEM).

- Fundiertes Verständnis von Listing-, Ranking- und Conversion-Mechanismen sowie nachweisbare Erfahrung in der Steuerung von Amazon Advertising (idealerweise inkl. Agenturführung).

- Ein ausgeprägtes kommerzielles Verständnis mit einem ganzheitlichen Blick auf Umsatzwachstum, Werbekosten (ACOS/TACOS) und Deckungsbeiträge.

- Verbindliches und überzeugendes Auftreten in Verhandlungen (z. B. zu WKZ, Konditionen, Aktionen) sowie die Fähigkeit, Partnerschaften auf Augenhöhe aufzubauen.

- Ausgeprägte Eigeninitiative, Hands-on-Mentalität und die Fähigkeit, Systeme und Prozesse eigenständig von Grund auf zu etablieren.

- Sicherer, routinierter Umgang mit Daten, KPIs und digitalen Analyse-Tools (insb. Excel / Google Sheets).

- Verhandlungssicheres Deutsch (unerlässlich für unsere Apotheken- und Großhandelspartner).

## Benefits

- Volle Ownership (Budgets, Ressourcen, strategische Initiativen) und maximaler Gestaltungsspielraum

- Bestmögliches Setup an Tools in einer datengetriebenen, AI-enabled Organisation mit einem sehr erfahrenen Team

- Ein attraktives Vergütungspaket bestehend aus marktgerechtem Fixgehalt und einer leistungsabhängigen Komponente

- Flexible Arbeitszeiten, Weiterbildungsbudget und regelmäßige gemeinsame Team-Lunches

- Ein positives Umfeld mit erfahrenen und motivierten Mitarbeitern, in dem Du wachsen wirst

Auch wenn nicht alle Punkte auf Dich zutreffen, freuen wir uns Dich kennenzulernen und über die Möglichkeit einer Zusammenarbeit mit Dir zu sprechen.

Bewirb Dich jetzt!

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
