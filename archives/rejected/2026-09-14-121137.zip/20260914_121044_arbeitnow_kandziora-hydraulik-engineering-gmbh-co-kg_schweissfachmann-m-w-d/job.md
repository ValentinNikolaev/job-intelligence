# Schweißfachmann (m/w/d)

Posted: 2026-09-14T11:00:27Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Werden Sie Teil von Kandziora Hydraulik Engineering – einem innovativen und zukunftsorientierten Arbeitgeber im Bereich der Hydrauliktechnik! Bei uns profitieren Sie nicht nur von einer leistungsgerechten Bezahlung und einem sicheren Arbeitsplatz, sondern auch von zahlreichen weiteren Vorteilen:

## Aufgaben

- Übernahme der Schweißaufsicht

- Optimierung der Schweißprozesse

- Sicherstellung von Qualitäts- und Sicherheitsstandards im Schweißen

- Erstellung von Schweiß- und Prüfplänen

- Durchführung von Prüfungen und Schulungen

**Qualitätssicherung:**

- Durchführung von Zeichnungskontrollen

- Erstellung von projektbezogenen Qualitätsplänen

- Durchführung von Qualitätskontrollen

- Schulung von Mitarbeitern im Bereich Qualitätssicherung

**Zertifizierungen:**

- Unterstützung bei der Organisation und Durchführung von Überwachungsaudits und Rezertifizierungen (ISO 9001, DIN EN ISO 3834-2, EN 1090 etc.)

- Qualifizierung von Lieferanten

- Unterstützung bei der Erstellung von Dokumenten für Zertifizierungen

## Qualifikation

- Abgeschlossene Ausbildung zum Techniker (m/w/d)

Weiterbildung zum Schweißfachmann oder Schweißfachingenieur (m/w/d)

- Berufserfahrung als Schweißaufsichtsperson

- Selbstständige, team- und kostenorientierte Arbeitsweise

- Sicherer Umgang mit den Microsoft Office-Programmen

## Benefits

**Ihre Benefits bei Kandziora:**

Wir bieten Ihnen ein sicheres und **unbefristetes Arbeitsverhältnis** sowie eine attraktive und **leistungsbezogene Vergütung.**

Zusätzlich erhalten Sie ein **13. Monatsgehalt** in Form einer Urlaubs- und Weihnachtsgratifikation.

Mit unserer **betrieblichen Altersvorsorge** unterstützen wir Sie dabei, für Ihre Zukunft vorzusorgen.

Damit Sie sich von Anfang an gut bei uns zurechtfinden, begleiten wir Sie mit einer umfassenden und **sorgfältigen Einarbeitung.** Darüber hinaus bieten wir Ihnen vielfältige **Weiterbildungsmöglichkeiten** für Ihre persönliche und berufliche Entwicklung.

Bei uns erwartet Sie ein **zukunftssicherer Arbeitsplatz** in einem stetig wachsenden Unternehmen.

Bei gemeinsamen **Firmenevents** lernen Sie Ihre Kolleginnen und Kollegen auch außerhalb des Arbeitsalltags besser kennen.

Zusätzlich profitieren Sie von attraktiven Mitarbeiter-Benefits wie **Bike-Leasing** und **Tankgutscheinen**. Mit dem **EGYM Wellpass** unterstützen wir Sie dabei, gesund und fit zu bleiben.

Freuen Sie sich auf ein **familiäres Arbeitsumfeld,** ein starkes Miteinander und kurze Entscheidungswege.

Nutzen Sie die Gelegenheit, Teil eines dynamischen Teams bei Kandziora Hydraulik Engineering zu werden und Ihre Expertise in einem innovativen Umfeld einzubringen. Wir freuen uns auf Ihre Bewerbung und darauf, gemeinsam mit Ihnen die Zukunft der Hydrauliktechnik zu gestalten. Bewerben Sie sich jetzt und profitieren Sie von einem sicheren Arbeitsplatz mit vielfältigen Entwicklungsmöglichkeiten!

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
