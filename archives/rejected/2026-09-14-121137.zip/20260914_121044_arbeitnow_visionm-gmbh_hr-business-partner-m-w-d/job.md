# HR Business Partner (m/w/d)

Posted: 2026-09-14T08:00:41Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Für ein international aufgestelltes Technologieunternehmen mit mehreren deutschen Standorten suchen wir einen Human Resources Business Partner. In dieser Rolle beraten Sie Führungskräfte und Mitarbeitende eines technisch geprägten Bereichs und gestalten HR-Themen von der operativen Betreuung bis zu Organisationsentwicklung und Veränderungsprozessen.

## Aufgaben

- Sie beraten und coachen Führungskräfte in allen relevanten HR-Fragestellungen.

- Sie begleiten Mitarbeiterbeziehungen sowie arbeits- und betriebsverfassungsrechtliche Themen und arbeiten vertrauensvoll mit Interessenvertretungen zusammen.

- Sie gestalten Organisationsentwicklungs-, Change-Management-, Performance-Management- und Personalentwicklungsprozesse.

- Sie setzen HR-Projekte um und verbessern Richtlinien, Prozesse und Standards.

- Sie unterstützen konzernweite HR-Initiativen sowie Transformations-, Restrukturierungs- und vergleichbare Veränderungsvorhaben.

- Sie begleiten Personalbedarfsplanung, Recruiting und Onboarding

## Qualifikation

- Sie verfügen über ein abgeschlossenes Studium, vorzugsweise mit Schwerpunkt Personal, oder eine vergleichbare Qualifikation.

- Sie bringen mehrjährige Erfahrung in der operativen Personalarbeit, idealerweise in einem international geprägten Umfeld, mit.

- Sie besitzen fundierte Kenntnisse im Arbeits-, Sozialversicherungs- und Betriebsverfassungsrecht.

- Sie arbeiten selbstständig, lösungsorientiert und belastbar und verfügen über Beratungskompetenz sowie diplomatisches Geschick.

- Sie haben Erfahrung in Personalgewinnung, Personalentwicklung, Organisationsentwicklung oder Change-Management.

- Sie kommunizieren sehr sicher auf Deutsch und Englisch und beherrschen MS Office; SAP-SuccessFactors-Kenntnisse sind wünschenswert.

- Sie sind reisebereit und schätzen die standortübergreifende Zusammenarbeit.

## Benefits

- 30 Urlaubstage

- Mobiles Arbeiten im Rahmen einer grundsätzlich vorgesehenen 3/2-Regelung

- Flexible Gleitzeitregelungen

Wenn Sie HR als strategischer und operativer Partner wirksam gestalten möchten, freuen wir uns auf Ihre Bewerbung!

Für Fragen steht Ihnen Sandra Heinrich unter der Rufnummer +49 179 3224223.

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
