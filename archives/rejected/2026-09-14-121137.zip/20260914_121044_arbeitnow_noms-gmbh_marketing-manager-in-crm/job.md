# Marketing Manager*in CRM

Posted: 2026-09-14T08:30:35Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Wir sind noms+, die grüne Pet Care Brand aus Deutschland: Zahnpflege, Parasitenschutz, Supplements und Snacks für Hunde und Katzen, PETA approved vegan & tierversuchsfrei und made in Germany. Wir verkaufen direkt an Tierhaltende (D2C) über unseren eigenen Onlineshop, Amazon und den Handel und wollen, dass jeder Kontakt mit noms+ sich richtig gut anfühlt.

Genau dafür suchen wir Dich: Du wirst der Kopf hinter unserer Customer Journey. Du sorgst dafür, dass unsere Kunden vor und nach dem Kauf ein Erlebnis haben, das im Gedächtnis bleibt.

## Aufgaben

- Du verantwortest die komplette Customer Journey: Was erlebt der Kunde, an welchem Punkt und warum.

- Du gestaltest das Unboxing-Erlebnis: Kartons, Beileger, Flyer, Grußkarten, Produktpräsentation.

- Du konzipierst und betreust unsere E-Mail-Journey über den gesamten Lebenszyklus: Onboarding, Nachkauf, Reaktivierung.

- Du analysierst Touchpoints, findest die Lücken und leitest daraus konkrete Verbesserungen ab.

- Du setzt Designs eigenständig in Canva, Affinity o.Ä. um, von der Idee bis zum fertigen Asset.

- Du nutzt AI-Tools, um schneller zu konzipieren, zu texten und zu gestalten.

- Du arbeitest eigenverantwortlich und stehst im direkten Austausch mit den Gründern

## Qualifikation

- Erfahrung im Marketing, Brand, CRM oder E-Commerce.

- Sehr gute Canva-Kenntnisse, Du setzt Designs selbstständig um.

- Erfahrung mit E-Mail-Marketing oder Tools wie Klaviyo, Copywriting oder D2C.

- Ein feines Gespür für Marke, Gestaltung und Kundenerlebnis.

- Du bist AI-affin und arbeitest gerne mit neuen Tools.

- Du arbeitest strukturiert, selbstständig und denkst vom Kunden her.

- Du wohnst im Großraum Hannover.

Schön, aber kein Muss

- Du hast selbst einen Hund und kennst unsere Zielgruppe aus dem echten Leben.

## Benefits

- Remote-first, Du arbeitest von zu Hause. Perspektivisch 1 bis 2 Tage pro Woche gemeinsam im Office in Hannover zum Austausch.

- Ein kleines, schnelles Team mit kurzen Wegen und echtem Gestaltungsspielraum.

- Moderne Tools und volle Freiheit mit AI zu arbeiten.

- Mitarbeiterrabatt auf unsere Produkte und einen hundefreundlichen Arbeitsplatz.

Klingt nach Dir?

Dann schick uns Deine Bewerbung, gerne mit ein paar Beispielen aus Deinem Portfolio oder Deinen Canva-Designs. Zeig uns lieber Deine Arbeit als ein langes Anschreiben. :)

Liebe Grüße

Sunna & Lukas

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
