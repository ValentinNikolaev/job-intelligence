# Senior Project Manager - Ground Systems (m/f/d)

Posted: 2026-08-08T23:55:28Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**Mission Brief **

We deliver the half of the rocket that stays on the ground. As Senior Project Manager in the Ground Systems department at Isar Aerospace, you will be managing the establishment and deployment of mid- to large-scale test and launch facilities. Situated in Munich, you will be playing a key role in managing the project from the initiation, over all engineering phases, through construction and commissioning until handing over to the on-site operations crew. The multidisciplinary team you will be working with consists of highly motivated engineers with an international background, fulfilling technical and co-ordinational roles in the project. You will coordinate timeline, costs, risks and top-level requirements with internal and external stakeholders, reporting to senior management.

Your Role in Our Space Mission:

- Technically manage a multidisciplinary, cross-functional project team, covering multiple departments

- Manage an international constellation of internal and external stakeholders including contract setup and negotiation

- Be responsible for reporting on the project status to management regarding ambitious timelines, budgets and top-level risks of the project

- Ability to identify, assess and mitigate technical, financial and operational risks early and proactively

- Closely collaborate with our internal customers of the rocket systems, using your technical know-how to realise the project according to set scope and timeline

- Contribute to the establishment of new sites for Isar Aerospace by working closely together with service departments

- Setup and improve workflows, processes, structures where necessary, to expedite project execution in collaboration with team managers across departments

**Qualification Checklist **

- B. Sc. or M.Sc. degree in mechanical/ civil/ aerospace / chemical engineering or an equivalent qualification

- About 5 years of relevant work experience in at least one of the following fields: systems engineering, project management, process plant, propulsion test bench or launch base design, and infrastructure/construction projects or similar

- Experience working in and/or managing complex, international, infrastructure/ process plant projects or similar

- Experience of working in a regulatory environment, ideally internationally, to ensure Compliance, Safety and Certification of the facility

- Knowledge of the project management toolkit to initiate, realise and close-out facility projects

- Quick grasp of technical and managerial problems and ability to quickly conduct sound trade-offs

- Reliable coordinator between stakeholders and engineers with confident demeanor, while keeping the project team motivated and unified

- Willingness to travel internationally

- English fluent

Bonus Skills

- German language skills

- Technical expertise in the aerospace sector, understanding of rocket launch systems and ground infrastructure of launch systems

- Project management certification: PMI-PMP, AXELOS-PRINCE2, APM-PMQ, IPMA Level D/C or similar

**Benefits **

- **Employee Participation Program: **Share in our success through our virtual company share program

- **30 days of vacation: **Enjoy the days off to relax and recharge

- **Company pension plan:** Secure your future with our company pension plan, featuring a 20% employer contribution after the probation period

- **Subsidised lunch:** Stay energised with delicious, subsidised lunches every day

- **Public transport ticket: **Commute with ease using a fully financed Deutschlandticket

- **Sport Clubs membership: **Stay fit with our sponsored sports club memberships (EGYM Wellpass)

- **Individual learning allowance:** Grow your skills with an individual learning budget granted after the probation period

- **Childcare allowance:** Receive a childcare allowance for your non-school-age children

- **And Much More!** Discover additional perks and benefits when you join our team

**Who we are**

****

We are Isar Aerospace and we are at the forefront of New Space building a modern space business to enable faster, better and cheaper access to space.

Our mission is to help democratise space and use it for good in order to improve life on Earth now and for the future generations.

We are a fast-growing company aiming to provide sustainable and environmentally friendly launch solutions for small and medium-sized satellites and constellations into Low Earth Orbit. The company is privately funded by world-leading technology investors with strong commitment and support and our team is made of driven and talented people with a real passion for space innovation.

We're making rockets in a way that hasn't been done before disrupting a traditional industry. If you are up for the challenge, want to work on cutting-edge projects and be part of a team changing the world for better, come, join us and launch your career!

Want to find out more about us?

Visit [www.isaraerospace.com](http://www.isaraerospace.com/)

**Disclaimer**

Isar Aerospace SE is an equal-opportunity employer committed to fairness and inclusivity. We do not prioritize any specific religion, gender, nationality, or background. Due to security clearance requirements, affiliations with countries listed under § 13 para. 1 no. 17 SÜG may affect the application process. All qualified applicants are encouraged to apply.

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
