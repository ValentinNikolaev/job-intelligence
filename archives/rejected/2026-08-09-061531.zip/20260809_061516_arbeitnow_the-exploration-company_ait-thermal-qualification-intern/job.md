# AIT Thermal & Qualification Intern

Posted: 2026-08-08T20:40:23Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Here at The Exploration Company, we are developing, producing, and operating Nyx, a modular and reusable space orbital vehicle that can eventually be refuelled in orbit and that can carry cargo - and potentially humans in the longer run.

**Your mission:**

Here at the The Exploration Company we are developing, producing, and operating Nyx, a modular and reusable space orbital vehicle that can eventually be refueled in orbit, and which carries cargo - and potentially humans in the longer run.

We want you as a talented AIT intern to help us in our mission by qualifying thermo-mechanical process for the Flight Model 1 and for the preparation of the integration of the flight model.

You will be successful in this role if you are able to help us:

-

Defining qualification plan

-

Supporting the Thermal Control System setup preparation and test

-

Defining the integration and test sequence

-

Procuring parts for the test

-

Procedures writing

**Tasks:**

Your role will be continuously evolving, but day to day your duties will include:

-

You will support the qualification of several processes (e.g. bonding and calibration of sensors, validation of foam fixation withing the Capsule)

-

You will support in testing the qualification either internally or externally, included the coordination with all stakeholders

-

You will prepare the test plan and the procedures, and also the coupons for testing

-

You will support the Active Thermal Control System integration and test

-

You will be supporting the procurement of tools needed

-

You will be supporting the writing of the procedures detailing the qualification, Integration and test operations

-

You will take care of improving the processes and procedure with the lessons learnt of the previous operations

-

You may have to support the team in other factory setup as we are a growing company, the perimeter can evolve along the mission.

**What we would love to see from you:**

-

Studying for an Engineering degree (Master) in mechanical science or equivalent

-

Experience with CAD software preferably with Siemens NX

-

Past experience with thermal setup will be a plus

-

Expierence in procedure writing with a MES and in inventory management with an ERP

-

Past experience in cleanroom environment will be a plus

-

Experience with fluidic/harness routing in Siemens NX a strong plus

-

Willingness to contribute to build and support a new team

-

Independent, organized and rigorous

-

Hands-on approach

-

Inventive and problem solver

-

Team spirit

**Skills and Behaviours**

-

Good organizing and prioritization of tasks

-

Positive and flexible attitude to get the job done

-

Ability to communicate at all levels of the business

-

Demonstrates behaviors consistent with The Exploration Company’s core values of Commitment, Innovation, Trust, Quality, and Teamwork

**Why you should join us!**

What makes us special here at The Exploration Company and why we think you will enjoy working here is:

-

We’re Agile - we make decisions fast whilst keeping our goals and systems in mind

-

We’re Open and Collaborative - we are transparent about risks and obstacles, so that we can cooperate to overcome them

-

We have a lot of Fun - we refuel our energy knowing we are democratising space. It’s a wonderful and rare opportunity, are YOU up for the challenge?

We'd love to hear from you if you wish to be a part of our journey. Please submit your CV now for immediate consideration and we will be in touch shortly.

*The Exploration Company is an equal opportunity employer and values diversity. We do not discriminate based on race, religion, colour, national origin, gender, sexual orientation, age, marital status or disability status. Relocation assistance is provided for those willing to relocate including visa sponsorship where applicable. *

*
All offers are contingent upon the successful completion of a background check, which will be subject to the country, role, and project you applied for. By submitting your application, you acknowledge and agree that any offer of employment may be conditional upon successful condition of this check. The Exploration Company partners with Zinc Work Limited located in the UK (Zinc), a third-party provider, to ensure this process as efficient and transparent as possible.

If applicable, you will receive an email from Zinc upon acceptance of your offer with a link to a secure portal where you can provide the required information to Zinc. *

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
