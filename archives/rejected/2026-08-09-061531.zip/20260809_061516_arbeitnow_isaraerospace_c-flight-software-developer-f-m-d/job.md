# C++ Flight Software Developer (f/m/d)

Posted: 2026-08-08T23:55:28Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

# **Mission Brief **

Join our Flight Software team and help develop the software that governs vehicle behaviour throughout all phases of flight, from launch through mission completion. You will design, implement and verify flight software, including vehicle state machines, mission sequencing, autonomy functions and vehicle control software, working closely with systems, avionics and GNC engineers.

## Your Role in Our Space Mission:

- Design and implement vehicle flight modes, state machines and mission sequencing logic.

- Develop software that coordinates and controls vehicle behaviour throughout the mission.

- Translate system-level requirements into robust, maintainable and well-tested software solutions.

- Contribute to flight software architecture, component interfaces and platform evolution.

- Develop and maintain simulation environments used for software development and verification.

- Implement and integrate algorithms into production flight software.

- Develop tools and automation using Python and MATLAB.

- Investigate and resolve software defects, including subtle edge cases and operationally specific issues.

# **Qualification Checklist**

- Strong software development skills in C++.

- Experience designing and maintaining software systems of meaningful complexity.

- Understanding of software architecture, testing and debugging techniques.

- Experience working in Linux-based development environments.

- Strong analytical and problem-solving skills and the ability to learn new technical domains quickly.

- Ability to work effectively in multidisciplinary engineering teams.

- Disciplined, detail-oriented engineering mindset with the persistence to drive issues to root cause.

- Commitment to producing high-quality software and continuously improving code and engineering processes.

## Bonus Skills

- Experience in aerospace, robotics, autonomous systems, simulation, control systems, safety-critical software or embedded systems.

- Experience with MATLAB/Simulink, Git, CI/CD, SIL or HIL environments.

# **Benefits **

- **Employee Participation Program: **Share in our success through our virtual company share program

- **30 days of vacation: **Enjoy the days off to relax and recharge

- **Company pension plan:** Secure your future with our company pension plan, featuring a 20% employer contribution after the probation period

- **Subsidised lunch:** Stay energised with delicious, subsidised lunches every day

- **Public transport ticket: **Commute with ease using a fully financed Deutschlandticket

- **Sport Clubs membership: **Stay fit with our sponsored sports club memberships (EGYM Wellpass)

- **Individual learning allowance:** Grow your skills with an individual learning budget granted after the probation period

- **Childcare allowance:** Receive a childcare allowance for your non-school-age children

- **And Much More!** Discover additional perks and benefits when you join our team

# **Who we are**

****

We are Isar Aerospace and we are at the forefront of New Space building a modern space business to enable faster, better and cheaper access to space.

Our mission is to help democratise space and use it for good in order to improve life on Earth now and for the future generations.

We are a fast-growing company aiming to provide sustainable and environmentally friendly launch solutions for small and medium-sized satellites and constellations into Low Earth Orbit. The company is privately funded by world-leading technology investors with strong commitment and support and our team is made of driven and talented people with a real passion for space innovation.

We're making rockets in a way that hasn't been done before disrupting a traditional industry. If you are up for the challenge, want to work on cutting-edge projects and be part of a team changing the world for better, come, join us and launch your career!

Want to find out more about us?

Visit [www.isaraerospace.com](http://www.isaraerospace.com/)

**Data Protection
**We process your personal data for the purpose of managing the recruitment process and assessing your application. For detailed information on how your data is processed, including your rights, please refer to our [Privacy Policy](https://isaraerospace.com/privacy-policy).

**Disclaimer
**Isar Aerospace SE is an equal-opportunity employer committed to fairness and inclusivity. We do not prioritize any specific religion, gender, nationality, or background. Due to security clearance requirements, affiliations with countries listed under § 13 para. 1 no. 17 SÜG may affect the application process. All qualified applicants are encouraged to apply.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
