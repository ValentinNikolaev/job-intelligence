# Program Director (m/f/d)

Posted: 2026-08-08T23:55:28Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**Mission Brief **

As Program Director, you are accountable for delivering Isar Aerospace's Spectrum launch vehicle on schedule. You own the integrated program timeline, drive execution across all departments, and ensure alignment of technical, resource, and business priorities to achieve key development and flight milestones.

As the leader of the Program Management function, you provide functional guidance to Program Managers embedded within the technical departments, establishing common planning, reporting, and execution standards across Spectrum.

Your Role in Our Space Mission:

- Own the integrated Spectrum program schedule and maintain the master roadmap across all development, qualification, production, and launch activities

- Identify, monitor, and drive resolution of critical path items, schedule risks, and cross-functional dependencies

- Lead program planning, milestone management, and program reviews to ensure timely delivery of key objectives

- Drive execution across engineering, manufacturing, supply chain, test, and launch operations

- Provide regular program status, schedule forecasts, and recovery plans to Executive Leadership

- Enable rapid decision-making by highlighting risks, trade-offs, and opportunities impacting schedule and program objectives

- Lead the Program Management function across Spectrum and provide functional direction to Program Managers through a matrix organization

- Establish and continuously improve planning, reporting, risk management, and governance processes across the company

- Facilitate alignment between Directors, Vice Presidents, Program Managers, and Executive Leadership to ensure successful execution of the Spectrum roadmap

**Qualification Checklist **

- M.Sc. in Aerospace Engineering, Mechanical Engineering, Systems Engineering, Business Engineering, or a related technical discipline (or equivalent experience)

- 15+ years of experience leading complex technical development programs in aerospace, space, defense, automotive, or similar high-technology industries

- Proven track record of delivering highly complex products on aggressive schedules

- Extensive experience in integrated master scheduling, critical path management, risk management, and cross-functional leadership

- Experience leading program management teams and matrix organizations

- Strong communication and stakeholder management skills, including Executive Leadership engagement

- Ability to operate effectively in a fast-paced environment with evolving priorities and demanding timelines

- Proficiency in English; German is a plus

**Benefits **

- **Employee Participation Program:** Share in our success through our virtual company share program

- **30 days of vacation: **Enjoy the days off to relax and recharge

- **Company pension plan:** Secure your future with our company pension plan, featuring a 20% employer contribution after the probation period

- **Subsidised lunch:** Stay energised with delicious, subsidised lunches every day

- **Public transport ticket:** Commute with ease using a fully financed Deutschlandticket

- **Rental clothing with laundry service:** Enjoy hassle-free workwear with our convenient rental clothing and laundry service

- **Sport Clubs membership:** Stay fit with our sponsored sports club memberships (EGYM Wellpass)

- **Individual learning allowance:** Grow your skills with an individual learning budget granted after the probation period

- **Childcare allowance:** Receive a childcare allowance for your non-school-age children

- **And Much More!** Discover additional perks and benefits when you join our team.

**Who we are**

****

We are Isar Aerospace and we are at the forefront of New Space building a modern space business to enable faster, better and cheaper access to space.

Our mission is to help democratise space and use it for good in order to improve life on Earth now and for the future generations.

We are a fast-growing company aiming to provide sustainable and environmentally friendly launch solutions for small and medium-sized satellites and constellations into Low Earth Orbit. The company is privately funded by world-leading technology investors with strong commitment and support and our team is made of driven and talented people with a real passion for space innovation.

We're making rockets in a way that hasn't been done before disrupting a traditional industry. If you are up for the challenge, want to work on cutting-edge projects and be part of a team changing the world for better, come, join us and launch your career!

Want to find out more about us?

Visit [www.isaraerospace.com](http://www.isaraerospace.com/)

**Data Protection
**We process your personal data for the purpose of managing the recruitment process and assessing your application. For detailed information on how your data is processed, including your rights, please refer to our [Privacy Policy](https://isaraerospace.com/privacy-policy).

**Disclaimer
**Isar Aerospace SE is an equal-opportunity employer committed to fairness and inclusivity. We do not prioritize any specific religion, gender, nationality, or background. Due to security clearance requirements, affiliations with countries listed under § 13 para. 1 no. 17 SÜG may affect the application process. All qualified applicants are encouraged to apply.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
