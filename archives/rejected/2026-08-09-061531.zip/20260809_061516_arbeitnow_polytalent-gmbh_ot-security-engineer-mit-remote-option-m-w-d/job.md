# OT Security Engineer mit Remote-Option (m/w/d)

Posted: 2026-08-08T23:30:25Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

PolyTALENT vermittelt direkt an ein etabliertes Unternehmen der **erneuerbaren Energien**, das seine **Biogas- und Industrieanlagen** sicherheitstechnisch weiter ausbaut. Gesucht wird ein **OT Security Engineer (m/w/d)**, der OT-/ICS-Sicherheitsmaßnahmen in produktionsnahen Umgebungen plant, technisch umsetzt und mit IT, Automatisierung und externen Partnern wirksam verzahnt.

Die Rolle ist ideal für Fachkräfte aus **OT Security, Industrial Cyber Security, Automatisierungstechnik, Leittechnik, SPS, SCADA oder Netzwerktechnik**, die industrielle Systeme absichern und nachhaltig weiterentwickeln möchten. Der Einsatz ist **überwiegend remote**, mit gelegentlichen Vor-Ort-Terminen an Standorten im **Raum Berlin, Brandenburg und Ostdeutschland**.

### Benefits

-

**Überwiegend remote** arbeiten mit planbaren Vor-Ort-Einsätzen in der Region

-

**Unbefristete Festanstellung** in einer stabilen Zukunftsbranche der erneuerbaren Energien

-

**30 Urlaubstage** für verlässliche Erholung und planbare Auszeiten

-

**Flexible Arbeitszeiten** mit Gleitzeitmodell für mehr Gestaltungsfreiheit

-

**Betriebliche Altersvorsorge** mit zusätzlicher Absicherung

-

**Bike-Leasing** für berufliche und private Nutzung

-

**EGYM Wellpass** für Fitness- und Gesundheitsangebote

-

**Zusätzlicher Mehrwert** über eine Mastercard-Lösung des Arbeitgebers

-

**Jubiläumsgratifikation** sowie regelmäßige Unternehmensveranstaltungen

-

**Strukturierte Feedbackgespräche** und ein langfristig orientiertes Arbeitsumfeld

### Aufgaben

-

Technische **Absicherung und Weiterentwicklung von OT-Umgebungen** an Biogasanlagenstandorten

-

Erarbeitung und Umsetzung von **OT-/ICS-Sicherheitskonzepten** für produktionsnahe Systeme

-

Analyse von Risiken und Schwachstellen in **OT, ICS und angrenzender IT-Infrastruktur**

-

Konzeption von **Netzwerksegmentierung, Zonen-/Conduits-Modellen** und sicherem Systemzugriff

-

Einführung und Optimierung von **Remote-Access-Lösungen** für Servicepartner und externe Dienstleister

-

Mitwirkung an **Backup-, Restore- und Notfallkonzepten** für kritische Anlagen- und Leitsysteme

-

Abstimmung mit **IT, Automatisierung, Leittechnik, Anlagentechnik** und externen Partnern

-

Pflege technischer **Dokumentationen, Sicherheitsrichtlinien und Betriebsprozesse**

-

Gelegentliche Vor-Ort-Termine an Anlagenstandorten in **Berlin, Brandenburg und Ostdeutschland**

### Profil

-

Mehrjährige Praxiserfahrung in **OT Security, Industrial Security, Automatisierung, Leittechnik, Netzwerktechnik oder IT/OT**

-

Gutes Verständnis industrieller Systeme wie **SPS, SCADA, HMI, Leitsysteme oder Fernwirktechnik**

-

Praxis mit **Netzwerksegmentierung, sicherem Fernzugriff** sowie Backup-/Restore-Konzepten

-

Erfahrung z. B. als **OT Security Engineer (m/w/d)**, **ICS Security Engineer (m/w/d)**, **Automatisierungsingenieur (m/w/d)**, **Netzwerkingenieur (m/w/d)** oder **Leittechniker (m/w/d)**

-

Idealerweise Kenntnisse in **IEC 62443**, **ISO 27001** oder vergleichbaren Sicherheitsstandards

-

Sehr gute **Deutschkenntnisse** sowie gutes Englisch für technische Abstimmungen

-

Strukturierte, eigenverantwortliche und lösungsorientierte Arbeitsweise im technischen Umfeld

-

**Reisebereitschaft von ca. 20 %** für regionale Einsätze an Anlagenstandorten

-

Wohnsitz oder gute Erreichbarkeit im **Raum Berlin, Brandenburg oder Ostdeutschland**

### Ansprechpartner

Bei Interesse oder Rückfragen wenden Sie sich bitte an:
PolyTALENT GmbH
Daniel Rogov
+49 1588 8630954

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
