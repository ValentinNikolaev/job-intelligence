# Senior Partner Enablement Associate (x/f/m)

Posted: 2026-08-08T20:55:27Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Wir suchen Dich als **Senior Associate Partner Enablement (x/f/m)** als Unterstützung für das **Partner Operations & Performance** Team in **Berlin oder München.**

Du entwickelst und implementierst Trainings- und Zertifizierungsprogramme sowie Lernformate für unsere IT-Service Partner, um Produkt- und Prozess-Know-how exzellent sicherzustellen und so ein hervorragendes Kundenerlebnis beim Onboarding unserer Produkte zu gewährleisten. Als Schnittstelle zwischen IT-Service Partnern und den internen Teams sorgst Du für ein nachhaltiges Wissensmanagement. KI-gestütztes Arbeiten ist Teil unserer DNA – Du bringst die Neugier und den Pragmatismus mit, diese Technologien täglich für exzellente operative Ergebnisse zu nutzen, operativen Output zu skalieren und Prozesse effizienter zu machen.

**Deine Aufgaben**

- **Entwicklung & Durchführung von Partner-Trainingsprogrammen: **Du konzipierst initiale und kontinuierliche Trainings rund um Doctolib-Produkte, technische Anforderungen, Onboarding-Prozesse und Tools, und erstellst zielgruppengerechte Materialien und Formate

- **Wissensmanagement & Befähigung:** Du stellst sicher, dass IT-Service-Partner über das notwendige Know-how verfügen und wissen, wo sie relevantes Wissen finden, um alle Onboarding-Aufgaben erfolgreich zu meistern.

- **Aufbau & Pflege eines Zertifizierungssystems: **Du entwickelst ein strukturiertes Zertifizierungs- und Re-Zertifizierungssystem und schaffst so eine verlässliche Grundlage für einheitliche Qualitätsstandards.

- **Reporting & datenbasierte Weiterentwicklung: **Du erstellst Reportings zu Trainingserfolgen und Wissensdefiziten, leitest daraus Maßnahmen ab und verbesserst die Enablement-Programme kontinuierlich basierend auf Partner-Feedback, Produktentwicklungen und Qualitätsaudits.

- **Service-Partner Entwicklung & Stakeholder-Kollaboration:** Du arbeitest eng mit internen Stakeholdern zusammen und stellst sicher, dass IT-Service-Partner als überzeugte Markenbotschafter:innen agieren und unsere Kunden begeistern.

**Dein Profil**

*Du bist der festen Überzeugung, dass Du genau das mitbringst, was es für die Position braucht? Dann ermutigen wir Dich, Dich zu bewerben. Selbst wenn Du nicht jede Anforderung erfüllst, bist Du vielleicht genau die/der richtige zukünftige Doctoliber:in für diese oder andere Stellen!*

**Um Teil unseres Teams zu werden, bringst Du Folgendes mit:**

- Mehrjährige Erfahrung im Bereich Learning & Development, Training oder Enablement

- Starke Kommunikationsfähigkeiten & Spaß an der Wissensvermittlung

- Didaktische Fähigkeiten & Erfahrung mit E-Learning Tools, LMS/Trainings-Plattformen

- Erfahrung in der Entwicklung von Schulungsprogrammen

- Prozess- und qualitätsorientierte Arbeitsweise

- Verhandlungssichere Deutsch- und Englischkenntnisse

**Besonders interessant sind für uns außerdem:**

- Erfahrung im Gesundheitswesen oder eHealth

- Erfahrung im Partner Management

- Zertifizierung in Training/Coaching (Train-the-Trainer, etc.)

**Was wir Dir bieten**

- Ein von Doctolib gesponsertes Deutschlandticket, wenn Du aus dem Büro oder im Hybridmodus arbeitest

- 28 Urlaubstage + 1 Tag zusätzlich für jedes volle Beschäftigungs-Kalenderjahr (max. 30 Tage)

- Die Möglichkeit, 10 Tage im Jahr aus dem Ausland zu arbeiten

- Eine betriebliche Krankenzusatzversicherung mit individuellen Zusatzleistungen (u.a. Zahnreinigung u.v.m.)

- Eine betriebliche Altersvorsorge (bAV) mit einem Arbeitgeberzuschuss von 40 % (15 % während der Probezeit)

- Teilnahme an Doctolibs langfristigem Mitarbeiterbeteiligungsprogramm DoctoGrowth

- Das Doctolib Parent Care Programm, das extra Elternzeit (1 Monat) u.v.m. enthält

- Kostenlose Mental Health- und Coaching-Sessions über einen externen Partner

- Zusätzlich zu gesunden Snacks und einem regelmäßigen Frühstücksbuffet, bieten wir Essensgutscheine

- Ein gefördertes Sportangebot mit unserem Partner Urban Sports Club

- Für pflegende Betreuungspersonen und Beschäftigte mit Behinderungen gibt es ein Angebot, das flexiblere Arbeitszeiten, zusätzliche Freistellung aus medizinischen Gründen und psychologische Unterstützung beinhaltet

**Der Interviewprozess**

- Call mit Talent

- Kennenlernen mit dem Head of Partner Operations & Performance

- Fallstudie mit dem Head of Partner Operations & Performance, einem:einer Peer und Director of Operations

- Mindestens zwei Referenzprüfungen via Telefon

**Job Details**

- Festanstellung

- Vollzeit

- Berlin oder München

- Ab sofort

- Hybride Arbeitsweise (3 Tage Office / Woche)

*Wir verfolgen die Vision, die Gesundheit aller zu verbessern. Dies spiegelt sich auch im Recruiting wider. Wir evaluieren Bewerbungen ausschließlich auf der Grundlage von Qualifikation und Motivation. Diskriminierung wird bei uns nicht toleriert.*

*Je diverser unser Team und die Ideen sind, desto mehr wird unser Produkt die Gesundheit unserer Nutzer:innen verbessern können. Deshalb laden wir Dich ein, Dich bei uns zu bewerben, unabhängig von Geschlecht, Religion, Alter, sexueller Orientierung, ethnischer Herkunft oder Behinderung.*

*Um Chancengleichheit zu gewährleisten, kannst Du in Deiner Bewerbung auf Angaben wie Fotos, Alter, etc. verzichten. Lass uns bitte wissen, welche Vorkehrungen wir treffen können, um Dich bestmöglich zu unterstützen. Wir freuen uns, mit Dir das Gesundheitswesen zu digitalisieren!*

*Alle bereitgestellten Informationen werden von Doctolib für das Bewerbungsmanagement verarbeitet. Für Details zur Datenverarbeitung klicke bitte [hier](https://doctolib.legal/B2C-Privacy-Policy-Career-DE).*

*Bei Fragen oder wenn Du Deine Rechte wahrnehmen möchtest, wende Dich bitte an hr.dataprivacy(at)doctolib.com.*

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
