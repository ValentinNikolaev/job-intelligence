# Launcher Propulsion Engineer

Posted: 2026-08-08T20:40:23Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Here at The Exploration Company, we are developing, producing, and operating Nyx, a modular and reusable space orbital vehicle that can eventually be refuelled in orbit and that can carry cargo - and potentially humans in the longer run.

Our Future Projects unit is dedicated to expanding and complementing these capabilities by conceptualizing and pre-developing new technologies, products and programs.

We want you as a talented propulsion system engineer to help us conceptualize new launch and space trasportation solutions, to mature critical technologies and drive the projects towards implementation stage. You will be part of the Launch Systems Team in the Future Programs Department, and will report to the Lead Launcher Programs.

## Key Responsibilities

In your capacity as a Future Projects Propulsion System Engineer, your role will be continuously evolving, but day to day your duties will include:

-

Define propulsion system architectures for future projects within the TEC launcher programs, including, but not limited:

-

Perform trade-offs and technical investigations at system and subsystem level.

-

Define system-level requirements and ensure flow down and consistency of lower-level requirements.

-

Define concept of operations and operational procedures for propulsion systems

-

Define and maintain the functional and product breakdown of the system.

-

Create and maintain the technical budgets (mass, propellant, inert gas, power, etc.).

-

Contribute to the development, V&V and industrialization plan.

-

Contribute to the MAIT concept trade-offs

-

Contribute to the co-engineering sessions between the engineering team and potential external partners (setup the agenda, coordinate priorities, take decisions, take the MoM, track the actions).

-

Own propulsion-specific future projects, work packages and bids within the launcher programs

-

Support the commercial and program teams in writing and negotiating proposals for Future Projects.

-

Provide propulsion system related project work

-

Coordinate datapack definition and delivery, RIDs management and day-to-day work with subcontractors

## What we would love to see from you

In the role of Future Projects System Engineer ideally, you will have the following:

-

Advanced degree (MSc) in aerospace engineering, systems engineering, or another related field.

-

5+ years of experience in the aerospace industry, preferably in a launch system program

-

Experience in early development phase (Phase 0/A/B) propulsion system engineering

-

Good knowledge in programming (Python, Fortran, Matlab...).

-

Experience with EcosimPro or comparable analysis tools

-

Hands-on operational experience in propulsion testing or launch

-

Fluent in English. German, French and Italian is an asset.

Skills and Behaviors:

-

Strong oral and written communication skills.

-

Strong analysis and problem-solving skills.

-

Strong organizing and prioritization of tasks.

-

Positive and flexible attitude to get the job done.

-

Ability to communicate at all levels of the business.

-

Demonstrates behaviors consistent with The Exploration Company’s core values of Vision, Competence, Integrity and Passion.

-

Space enthusiast: ready to change the European space industry.

**Why you should join us!**

What makes us special here at The Exploration Company and why we think you will enjoy working here is:

-

We’re Agile - we make decisions fast whilst keeping our goals and systems in mind

-

We’re Open and Collaborative - we are transparent about risks and obstacles, so that we can cooperate to overcome them

-

We have a lot of Fun - we refuel our energy knowing we are democratising space. It’s a wonderful and rare opportunity, are YOU up for the challenge?

We'd love to hear from you if you wish to be a part of our journey. Please submit your CV now for immediate consideration and we will be in touch shortly.

*The Exploration Company is an equal opportunity employer and values diversity. We do not discriminate based on race, religion, colour, national origin, gender, sexual orientation, age, marital status or disability status. Relocation assistance is provided for those willing to relocate including visa sponsorship where applicable. *

*
All offers are contingent upon the successful completion of a background check, which will be subject to the country, role, and project you applied for. By submitting your application, you acknowledge and agree that any offer of employment may be conditional upon successful condition of this check. The Exploration Company partners with Zinc Work Limited located in the UK (Zinc), a third-party provider, to ensure this process as efficient and transparent as possible.

If applicable, you will receive an email from Zinc upon acceptance of your offer with a link to a secure portal where you can provide the required information to Zinc. *

Compensation: €72.5K – €100K

- • €72.5K – €100K

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
