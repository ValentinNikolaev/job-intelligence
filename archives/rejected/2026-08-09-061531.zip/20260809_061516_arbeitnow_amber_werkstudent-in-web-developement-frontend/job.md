# Werkstudent*in - Web Developement / Frontend

Posted: 2026-08-08T20:40:23Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**Aus Europa, für Europa – Wir bauen Europas Business-KI.**

Wir sind amber, ein wachsendes und innovatives KI-Startup. KMUs profitieren davon, wenn internes Wissen sofort nutzbar wird und intelligente Agenten darauf reagieren können. Wir glauben an eine Zukunft, in der Business-KI, einschließlich Agenten, in einer gemeinsamen Plattform zusammenarbeitet, sodass Teams schneller arbeiten, Übergaben nahtlos erfolgen und das Know-how im Unternehmen bleibt.

Als **Web Developement / Frontend – Werkstudent:in (F/M/*)** bei amber unterstützt du unser Team bei der Betreuung und Weiterentwicklung unserer Website sowie bei der Frontend-Entwicklung unserer Kern-Technologien. Du sammelst wertvolle Praxiserfahrung in einem wachsenden SaaS-Unternehmen, arbeitest mit modernen Technologien und entwickelst dich fachlich und persönlich weiter.

Wenn du neben deinem Studium Lust hast, an einem innovativen SaaS-Produkt mitzuarbeiten, dann melde dich jetzt bei uns!

## Deine Aufgaben

-

Du betreust unsere Website und übernimmst kleinere Anpassungen und Content-Pflege in enger Abstimmung mit unserem Team

-

Du unterstützt im Frontend Web Development bei der Weiterentwicklung unserer Kern-Technologien

-

Du implementierst Prototypen zur Evaluierung neuer Technologien und bringst eigene Ideen ein

-

Du arbeitest eng mit Engineering und Marketing zusammen und sorgst dafür, dass unsere Web-Auftritte technisch sauber und aktuell bleiben

-

Du hilfst dabei, wiederkehrende Aufgaben rund um die Website zu strukturieren und wo möglich zu automatisieren

## Deine Qualifikationen

-

Du bist eingeschriebene:r Student:in, idealerweise in Informatik, Medieninformatik oder einem vergleichbaren Studiengang

-

Du bringst erste Erfahrung mit Frontend-Frameworks (React, Vue.js) mit

-

Du hast erste Berührungspunkte mit CMS-Systemen (Strapi, WordPress o. ä.)

-

Du hast solide Grundlagen in HTML, CSS und JavaScript/TypeScript

-

Du arbeitest zuverlässig und strukturiert und hast Lust, dich in neue Technologien einzuarbeiten

-

Du kommunizierst klar auf Deutsch und Englisch und arbeitest gerne im Team

## Deine Benefits

-

Team Offsites – Da du in einem internationalen Team arbeiten wirst, treffen wir uns zweimal im Jahr alle zusammen irgendwo in Europa

-

Wir leben ein hybrides Arbeitsmodell: Wir sind der Meinung, dass es wichtig ist, regelmäßig in Person zusammenzuarbeiten

-

Damit du vor Ort auch gut versorgt bist, gibt es bei uns jeden Arbeitstag vor Ort digitale, steuerfreie Essensgutscheine direkt aufs Handy

-

Sammle echte Praxiserfahrung in einem KI-Startup und baue deine Fähigkeiten Schritt für Schritt aus – mit Perspektive auf Abschlussarbeit oder Einstieg nach dem Studium

-

Wir fördern deine persönliche Entwicklung durch Weiterbildung und Raum für Eigenverantwortung

-

Ein Team von motivierten Leuten, die Bock haben, KI-Lösungen auch für mittelständische Unternehmen zugänglich zu machen

-

Arbeite mit den neuesten Technologien und Tools

**Ein paar Worte zum Schluss**

Klingt spannend? Dann hilf uns jetzt und schick uns einfach kurz deinen CV oder dein LinkedIn-Profil. Wir freuen uns auf dich!

Bitte beachte: Für diese Position berücksichtigen wir ausschließlich Bewerber:innen mit Wohnsitz in Deutschland.

**Let's go big together** 🚀

Compensation: €18 – €20 per hour

- • €18 – €20 per hour

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
