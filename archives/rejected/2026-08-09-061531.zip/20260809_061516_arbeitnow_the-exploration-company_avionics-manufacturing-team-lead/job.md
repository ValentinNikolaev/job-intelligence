# Avionics Manufacturing Team Lead

Posted: 2026-08-08T20:40:23Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Here at The Exploration Company, we are developing, producing, and operating Nyx, a modular and reusable space orbital vehicle that can eventually be refuelled in orbit and that can carry cargo - and potentially humans in the longer run.

The Avionics Manufacturing Team Lead will be responsible for managing a team of technicians to assemble, integrate, and test avionics equipment for the Nyx spacecraft, ensuring that schedule, quality, and process discipline are maintained at every stage of production.

**Key Responsibilities**

-

**Team Management & Daily Operations**

-

Lead and coordinate a team of avionics technicians across assembly, integration, and test activities.

-

Plan, prioritise, and assign weekly tasks to meet programme milestones.

-

Conduct regular team meetings and maintain a visible schedule to track progress and flag risks early.

-

Serve as the first point of escalation for technical and workload issues within the team.

-

Be available for the team to help and solve problems in the workshop (avionics lab)

-

**Schedule & Quality Control**

-

Maintain a detailed short-term production schedule, tracking task completion against plan.

-

Enforce quality standards throughout the assembly and integration process, ensuring deliverables meet defined acceptance criteria.

-

Balance throughput and quality, escalating trade-offs to engineering management when necessary.

-

**Manufacturing Process Definition**

-

Define, document, and continuously improve manufacturing and assembly procedures for avionics equipment.

-

Develop work instructions, and test procedures in coordination with design and quality engineers.

-

Identify process bottlenecks and implement solutions to increase build efficiency without compromising quality.

-

**Interface with Design & Engineering Teams**

-

Act as the primary manufacturing interface to avionics design engineers, translating design intent into executable production tasks.

-

Participate in design reviews (PDR, CDR, TRR) and provide manufacturing readiness inputs.

-

**Documentation & Compliance**

-

Ensure all manufacturing activities are fully documented and traceable.

-

Maintain build records, non-conformance reports, and configuration control logs.

-

Ensure compliance with applicable space-grade standards (ECSS, NASA-STD) and internal quality procedures.

**Required Qualifications**

-

Bachelor's or Master's degree in Electrical Engineering, Electronics, Aerospace Engineering, or a related field.

-

Minimum 4–6 years of hands-on experience in electronics or avionics assembly, integration, and test.

-

Demonstrated experience managing or leading a team of technicians in a production or integration environment.

-

Proven ability to maintain schedule adherence under pressure while upholding high quality standards.

-

Strong understanding of avionics systems and electronics assembly processes (PCB assembly, harness routing, connector crimping, conformal coating, etc.).

-

Experience defining and writing manufacturing procedures, work instructions, and test protocols.

-

Ability to read and interpret electrical schematics, assembly drawings, and ICD documents.

-

Fluent in English; strong communication skills for cross-functional coordination. German languange is big plus.

**Desirable Skills**

-

Previous experience in the space, defence, or aerospace sector.

-

Familiarity with ECSS/NASA standards and derating practices for space hardware.

-

Experience with quality management systems such as EN9100 or ISO 9001 — knowledge of audits, NCR processes, and quality gates is a strong plus.

-

Knowledge of environmental testing requirements: vibration, thermal vacuum, EMC.

-

Experience interfacing with design teams during early-stage product development.

**Why you should join us!**

What makes us special here at The Exploration Company and why we think you will enjoy working here is:

-

We’re Agile - we make decisions fast whilst keeping our goals and systems in mind

-

We’re Open and Collaborative - we are transparent about risks and obstacles, so that we can cooperate to overcome them

-

We have a lot of Fun - we refuel our energy knowing we are democratising space. It’s a wonderful and rare opportunity, are YOU up for the challenge?

We'd love to hear from you if you wish to be a part of our journey. Please submit your CV now for immediate consideration and we will be in touch shortly.

*The Exploration Company is an equal opportunity employer and values diversity. We do not discriminate based on race, religion, colour, national origin, gender, sexual orientation, age, marital status or disability status. Relocation assistance is provided for those willing to relocate including visa sponsorship where applicable. *

*
All offers are contingent upon the successful completion of a background check, which will be subject to the country, role, and project you applied for. By submitting your application, you acknowledge and agree that any offer of employment may be conditional upon successful condition of this check. The Exploration Company partners with Zinc Work Limited located in the UK (Zinc), a third-party provider, to ensure this process as efficient and transparent as possible.

If applicable, you will receive an email from Zinc upon acceptance of your offer with a link to a secure portal where you can provide the required information to Zinc. *

Compensation: €77.5K – €105K

- • €77.5K – €105K

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
