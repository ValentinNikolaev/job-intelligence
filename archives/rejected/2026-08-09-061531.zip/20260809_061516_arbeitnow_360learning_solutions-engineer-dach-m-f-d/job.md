# Solutions Engineer DACH (m/f/d)

Posted: 2026-08-09T02:05:11Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

As a Solutions Engineer, you will be working at the intersection of Sales, Product and Customer Success, working with top learning and development organizations to align their growth objectives to 360learning capabilities. As the first Solutions Engineer for the German market, you will play a crucial role in ensuring the region’s success, but you will have the support from the whole EMEA team.

This role will be foundational to 360learning business expansion. Reinforcing a new function in Germany, as a Solutions Engineer, you will become an internal expert in our technology, developing a deep understanding of how 360learning is being used by current customers and how it can drive value for future ones. You will bridge the gap between the strategic direction of our product development and the needs of our market.

**Within 1 month, you will:**

- Become an expert of 360Learning ways of working through our onboarding process on Convexity

- Meet the global team through virtual coffee meets and happy hours

- Master our value proposition like no one else thanks to shadow meetings with AEs and intensive training with your coach

- Learn our product like nobody else knows it in the company, and be able to support our Product team with great insights and feedback thanks to a detailed product training

- Have defined your first OKR

**Within 3 months, you will:**

- Understand, master, and become a pro at describing our product to prospects, and addressing promptly every question they may have surrounding our technology

- Collaborate with sales teams to understand customer requirements and provide sales support

- Be a responsive and creative member of a cross-functional teams (sales, marketing, customer success) by providing valued feedback internally to our teams

- Plan and configure products to meet presentation needs

- Be a creative, upbeat, and positive player collaborating with AEs to build engaging strategies to move deals forward in our sales funnel (POC/pilot construction)

**Within 6 months, you will:**

- Become a trusted advisor to all levels within the prospective customer organization from CEOs, to Developers, to Learning and Development Directors

- Be identified as a prime expert by our Account Executives to support them in any prospective context

- Share your expertise with other team members and 360Learners

**Within 12 months, you will:**

- Contribute in making the Solutions Engineering department grow by identifying best practices, designing new processes and creating new contribution for the team

- Work alongside sales team members at every step of the sales process

- Help shape the Solutions Engineering team by recruiting your colleagues

**The Skills Set:**

- 5+ years’ experience working either as a Pre-Sales, Solutions Engineer, Engagement Management, or LMS implementation consultant, ideally in the SaaS industry

- A consultative selling background

- Knowledge of enterprise technologies and systems, including SSO, CRM, ERP or HRIS

- Proven ability to demonstrate technical expertise while interacting with high level stakeholders such as CTO, CISO

- Ability to lead technical workshops (ex : SaaS integrations, Middleware, ETL, API, Web Services, …)

- Excellent written and verbal communication skills

- Fluent German and business fluent English proficiency; other languages are a plus

- Enthusiasm for our culture explained here: [https://bit.ly/Convexity360L](https://bit.ly/Convexity360L)

**What We Offer:**

- **Compensation: **Package includes base salary, a variable component and equity 📈

- **Benefits**: Work From Home perks, 1 month parental leave for the second parent

- **Balance**: Flexible hours, remote work possible anywhere in Germany, France or the UK 🏠

- **Diversity, Equity, and Inclusion: **We have 6 active ERGs including Mental Health, Environmental/Sustainability, Women, Parents, LGBTQIA2S+, and Ethnic Diversity. Each group has at least one executive team member serving as a member of the group, bringing greater awareness to each group’s activities and providing a quick path to impact 🤝

- **Corporate Social Responsibility**: Review our CSR Charter: [360learning.com/blog/corporate-social-responsibility-charter](http://360learning.com/blog/corporate-social-responsibility-charter) 🌎🌏🌍

- **Culture:** A framework that will help you make an impact - envision what's it like to join 360Learning through our onboarding journey: [https://360learning.com/blog/360learner-journey/](https://360learning.com/blog/360learner-journey/) & Convexity Culture: [https://bit.ly/Convexity360L](https://bit.ly/Convexity360L) 🚀👩🏻‍💻🏆

**Interview process:**

- Interview with our Recruiter

- Discovery Meeting with our Head of Solutions Engineering

- Role-play with our Head of Sales Engineering and our Solutions Engineer

- Clarification Meeting with our Sales Enterprise Director

- Culture Fit Meeting with our CRO

- Reference Checks

- Offer!

**Who We Are**

360Learning enables companies to upskill from within by turning their experts into champions for employee, customer, and partner growth. With our LMS for collaborative learning, Learning & Development teams can accelerate upskilling with the help of internal experts instead of slow top-down training. 360Learning is the easiest way to onboard and upskill employees, train customer-facing teams, and enable customers and partners–all from one place.

360Learning powers the future of work at 1,700 organizations. Founded in 2013, 360Learning has raised $240 million with 400+ team members across North America and EMEA.

**Learning Includes Everyone.**

In concert with our culture, 360Learning believes learning includes everyone and that means embracing the strengths of diversity, connectedness, and inclusion. Through conscientious efforts, our global footprint celebrates cultures, perspectives, and experiences from all over the world to support our platform that is built for all regardless of race, ethnicity, gender identity or expression, sexual orientation, religion, age, neurodiversity, disability status, citizenship, veteran status or any other aspect which makes an individual unique or protected by laws and regulations in the locations where we operate. Thus, 360Learning is proud to be an equal opportunity workplace, and we commit to continue this throughout our processes for recruitment, compensation, benefits, performance, promotion, and all other conditions and terms of employment. **We want to learn from and with you!**

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
