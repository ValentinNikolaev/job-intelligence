# Head of Marketing (F/M/*)

Posted: 2026-08-08T20:40:23Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**Aus Europa, für Europa – Wir bauen Europas Business-KI.**

Wir sind amber, ein wachsendes und innovatives KI-Startup. KMUs profitieren davon, wenn internes Wissen sofort nutzbar wird und intelligente Agenten darauf reagieren können. Wir glauben an eine Zukunft, in der Business-KI, einschließlich Agenten, in einer gemeinsamen Plattform zusammenarbeitet, sodass Teams schneller arbeiten, Übergaben nahtlos erfolgen und das Know-how im Unternehmen bleibt.

Als **Head of Marketing (F/M/*)** bei amber übernimmst du die Verantwortung für unsere gesamte Marketingstrategie – von Brand über Demand Generation bis hin zu Content und Events. Du arbeitest eng mit Sales, Product und der Geschäftsführung zusammen, positionierst amber als führende Business-KI aus Europa und sorgst dafür, dass unsere Pipeline kontinuierlich wächst. Dabei führst du unser Marketing-Team, entwickelst es weiter und setzt klare Prioritäten in einem dynamischen Umfeld.

Wenn du Lust hast, die Marke eines innovativen SaaS-Produkts aktiv zu prägen, dann melde dich jetzt bei uns!

## Deine Aufgaben

-

Du entwickelst und verantwortest die gesamte Marketingstrategie – von Positionierung und Messaging über Demand Generation bis hin zu Brand Awareness

-

Du führst das Marketing-Team fachlich und disziplinarisch, entwickelst es weiter und baust es entsprechend unserer Wachstumsziele gezielt aus

-

Du verantwortest die Lead- und Pipeline-Ziele im Marketing und arbeitest dafür eng verzahnt mit Sales zusammen

-

Du steuerst unsere Kanäle ganzheitlich: Website, SEO/SEA, Social Media, E-Mail, Webinare, Events und PR

-

Du entwickelst eine Content-Strategie, die unsere Zielgruppe im Mittelstand und in der Industrie wirklich erreicht – von Fachartikeln bis Case Studies

-

Du misst, was zählt: Du baust ein datengetriebenes Marketing-Reporting auf, analysierst Funnels und optimierst Kampagnen kontinuierlich anhand klarer KPIs

-

Du verantwortest das Marketingbudget und setzt Ressourcen dort ein, wo sie den größten Effekt auf unser Wachstum haben

-

Du beobachtest Markt, Wettbewerb und Trends im Bereich Business-KI und leitest daraus Impulse für Positionierung und Produktkommunikation ab

## Deine Qualifikationen

-

Du hast mehrjährige Erfahrung im B2B-Marketing, idealerweise im SaaS- oder Tech-Umfeld; Erfahrung in der Scale-up- oder Startup-Welt ist ein muss.

-

Du bringst fundierte Erfahrung aus dem Hyper-Growth-Umfeld mit und weißt, wie man Unternehmen in kürzester Zeit skaliert und international ausrichtet

-

Du hast bereits ein Team geführt oder aufgebaut und weißt, wie man Menschen motiviert, entwickelt und Prioritäten klar setzt

-

Du denkst strategisch und packst gleichzeitig operativ mit an – Hands-on-Mentalität ist für dich selbstverständlich

-

Du arbeitest datenorientiert, analysierst Funnels und Kampagnen-Performance und leitest daraus konkrete Maßnahmen ab

-

Du bist technikaffin und sicher im Umgang mit gängigen Marketing- und CRM-Tools; Erfahrung mit HubSpot ist ein Muss für diese Position.

-

Du hast ein gutes Gespür für Marke, Storytelling und Zielgruppen – insbesondere für erklärungsbedürftige B2B-Produkte

-

Du kommunizierst klar und verbindlich auf Deutsch und Englisch und trittst sicher mit unterschiedlichen Stakeholdern auf

## Deine Benefits

-

Team Offsites – Da du in einem internationalen Team arbeiten wirst, treffen wir uns zweimal im Jahr alle zusammen irgendwo in Europa

-

Du hast die Wahl: Entweder ein bezuschusstes Deutschlandticket oder eine Urban Sports Club Mitgliedschaft

-

Wir leben ein hybrides Arbeitsmodell: Wir sind der Meinung, dass es wichtig ist, regelmäßig in Person zusammenzuarbeiten. Daher treffen wir uns dreimal wöchentlich an einem unserer Standorte

-

Damit du vor Ort auch gut versorgt bist, gibt es bei uns jeden Arbeitstag vor Ort digitale, steuerfreie Essensgutscheine direkt aufs Handy

-

Starte in einem Unternehmen, das dich wachsen lässt und dir die Möglichkeit gibt, deine Fähigkeiten Schritt für Schritt auszubauen

-

Wir fördern deine persönliche Entwicklung durch Weiterbildung und Raum für Eigenverantwortung

-

Ein Team von motivierten Leuten, die Bock haben, KI-Lösungen auch für mittelständische Unternehmen zugänglich zu machen

-

Arbeite mit den neuesten Technologien und Tools

**Ein paar Worte zum Schluss**

Klingt spannend? Dann hilf uns jetzt und schick uns einfach kurz deinen CV oder dein LinkedIn-Profil. Wir freuen uns auf dich!

Bitte beachte: Für diese Position berücksichtigen wir ausschließlich Bewerber:innen mit Wohnsitz in Deutschland.

**Let's go big together** 🚀

Compensation: €70K – €120K

- • €70K – €120K

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
