# Senior Social Media Manager (m/f/d) - 1-Year Fixed Term (Maternity Cover)

Posted: 2026-08-08T20:30:21Z

## Rejection

- Category: location_requirement
- Reason: requires United States location

****This position is based in Germany with hybrid or remote working options. Applicants must hold a valid work/residence permit for the respective location.****

Chaos is a leading global software company that provides world-class visualization and design solutions, empowering creative minds to bring ideas to life.

For over twenty years, Chaos has developed innovative technologies serving multiple industries, including architecture and design, media and entertainment, and product e-commerce. Chaos’ solutions help architects, designers, VFX artists/animators, and other creative professionals share ideas, optimize workflows, and create immersive experiences.

Headquartered in Karlsruhe, Germany, Chaos is a global company with offices in 11 cities worldwide. In 2022, Chaos and Enscape merged, bringing together two industry-leading companies into one. Since then, Chaos has continued to grow with the additions of Cylindo, AXYZ Design, and Evolve Lab, further expanding our expertise and solutions across architecture, design, e-commerce, and AI. For more information, please visit [chaos.com](http://chaos.com).

**Role Overview**

The **Senior Social Media Manager** is responsible for developing and executing the social media strategy across all platforms, driving brand awareness, audience engagement, and traffic in support of broader marketing and business objectives. The role owns the content calendar, manages all social media accounts, and works closely with Creative, Product Marketing, and PR to ensure consistent, on-brand messaging across channels. This role requires a data-driven social media professional with a strong track record of growing and engaging audiences across platforms, and the seniority to translate performance insights into clear strategic recommendations.

**Main Responsibilities**

-

Create, evolve and implement comprehensive social media strategies to drive brand awareness, engagement, and traffic across all platforms.

-

Align social media plans with overall marketing and business objectives.

-

Develop and manage a content calendar, ensuring timely and consistent posts.

-

Manage and optimize all social media accounts, incl. LinkedIn, Instagram, Facebook, YouTube, and emerging platforms.

-

Collaborate with creative and content teams to produce high-quality, engaging, and visually appealing content tailored to each platform.

-

Foster a positive online community and encourage user-generated content.

-

Plan and execute social media campaigns for our organic social media efforts.

-

Track and analyze key performance metrics and prepare regular reports.

-

Drive data-informed decision-making by translating insights into clear strategic recommendations.

-

Stay up-to-date with social media trends, tools, and platform updates.

-

Collaborate with Creative, PMM, PR and other teams to ensure aligned messaging and execution.

-

Monitor brand mentions and sentiment to address potential issues proactively.

-

Support in executing social media crisis communication plans when needed.

**Required Experience**

-

At least 5 years of experience in social media management, with a demonstrated track record of developing and executing data-driven strategies that deliver measurable business impact.

-

Proven experience growing and scaling social media channels, with clear ownership of engagement and audience growth outcomes.

-

Experience working cross-functionally with Creative, Marketing, and PR teams, influencing stakeholders and driving aligned execution across channels.

-

Hands-on experience with social media management and analytics platforms, including tools such as Sprout Social or equivalent.

-

Familiarity with Adobe Creative Suite or Canva for visual content production is an advantage.

-

Background in using social media to support event promotion, online and offline, is an advantage.

**Required Skills**

-

Deep understanding of platform dynamics, content strategy, and audience behaviour across major and emerging social media channels.

-

Able to interpret social media performance data and translate metrics into strategic decisions and stakeholder-ready reporting.

-

Skilled in crafting concise, brand-consistent messaging and visually engaging content suited to each platform's format and audience.

-

Able to plan, execute, and optimize multi-channel campaigns, managing timelines, KPIs, and cross-functional dependencies simultaneously.

-

Comfortable handling brand reputation challenges: responds to negative feedback and manages crisis communication with composure and good judgement.

-

Experience growing and managing a YouTube channel specifically, including content strategy, audience retention, and video performance metrics, is an advantage.

-

Proficient in SEO principles as applied to social: keyword research, discoverability optimisation, and hashtag strategy.

-

Fluent English is required.

We welcome people who value teamwork, stick to their commitments and are curious to explore new ways for achieving mastery. If you believe that you are a good match for the job, just send us your CV in **English**.

Only shortlisted candidates will be contacted.

Confidentiality of all applications is assured.

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
