# Director Enterprise IT & Data (m/f/d)

Posted: 2026-08-08T23:55:28Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**Mission Brief **

Isar Aerospace is building the launch company Europe needs: fast, vertically integrated, technically ambitious, and execution-driven. To scale from a high-performing engineering and production organization into a global space company, we need Enterprise IT & Data to become a true force multiplier, building an AI-first technology landscape where systems, platforms, and data are designed for interoperability, scalability, and long-term sovereignty.

As Director Enterprise IT & Data, you lead the function that makes Isar faster, sharper, and more scalable: enterprise IT, core business platforms, architecture, data, AI enablement, and digital demand governance. Your mission is to turn Isar’s vertical integration and the data it generates into an unfair advantage.

This is not a maintenance role. Day-to-day operations need to be reliable, but the real mandate is bigger: build the digital backbone that allows the company to move at mission speed. You set direction, create focus, remove noise, make trade-offs, and hold the organization accountable for outcomes. Functional leads own day-to-day execution; you own the operating model, roadmap, priorities, standards, and business impact.

You will work in a high-ownership environment with little room for bureaucracy, politics, or theoretical transformation work. We need someone who can think strategically, operate pragmatically, and drive execution relentlessly. Someone who understands that great IT is not about tools — it is about enabling people, processes, data, and decisions to move faster.

The role works closely with Information & Cybersecurity as an independent counterpart responsible for security governance, risk, compliance, threat detection, and assurance.

**Leadership and strategy**

- Lead and develop the Enterprise IT & Data organization and its functional leads.

- Define the roadmap, priorities, budget, capacity, and performance expectations for Enterprise IT & Data.

- Own the operating model, governance, vendor landscape, service levels, delivery KPIs, and roadmap reporting.

- Ensure Enterprise IT & Data provides a secure, reliable, scalable, and cost-effective technology environment that supports business growth and operational excellence.

- Ensure the enterprise technology and data landscape is designed with AI enablement, interoperability, digital sovereignty, and long-term independence in mind, reducing unnecessary vendor lock-in while maintaining the flexibility to evolve technologies, locations, and operating models as the company scales.

- Create transparent prioritization for business requests, platform initiatives, data products, automation, and AI use cases.

- Ensure the enterprise technology landscape scales effectively with new production facilities, launch operations, and international expansion while maintaining operational consistency and efficiency.

- Act as a strategic technology partner to Engineering, Manufacturing, Supply Chain, Quality, and Launch Operations leadership, aligning digital capabilities with business objectives and operational priorities.

**Portfolio & Demand / PMO**

- Establish a transparent intake, prioritization, and capacity process for Enterprise IT & Data work.

- Maintain leadership visibility on initiatives, dependencies, risks, trade-offs, and portfolio decisions.

**Business Applications, Digital Thread & Enterprise Architecture**

- Own SAP/ERP and the broader enterprise application landscape, ensuring scalable, integrated, and data-enabled business processes.

- Establish governance for business-critical enterprise and internally developed applications across engineering, manufacturing, testing, and launch operations.

- Own application, architecture, and master data governance, ensuring system, integration, platform, and data decisions align with the target enterprise architecture and data platform.

- Drive an integrated digital thread across MES, PLM, ERP, and operational systems while reducing tool fragmentation and architectural debt and ensuring measurable business value.

**IT Operations**

- Set direction and performance expectations for reliable IT support, infrastructure services, resilience, and business continuity across all sites.

- Ensure the IT Operations function delivers reliable, scalable, and cost-effective services aligned with business needs.

- Ensure

- Partner with Information & Cybersecurity on operational security standards.

**AI & Data Platform**

- Set the ambition and governance for an enterprise data platform that enables AI & business intelligence use cases across core business and operational domains.

- Partner closely with the CEO-Office on AI strategy and implementation, including tooling rollout, priority use cases, analytics, AI coding workflows, and executive dashboards.

- Establish pragmatic data governance, ownership, access, and quality standards.

- Ensure data, automation, AI, and business intelligence initiatives create measurable business leverage across the organization.

- Build the organizational capabilities required for an AI-native Enterprise IT & Data function, including the adoption of AI-assisted workflows, modern engineering practices, automation, and continuous upskilling of the team.

- Transform enterprise, engineering, manufacturing, test, supply chain, and business data into governed strategic assets that enable operational excellence, faster decision-making, and scalable growth.

**Qualification Checklist **

- Significant leadership experience in IT, digital platforms, infrastructure, enterprise applications, or digital transformation, ideally in a scaling technology, engineering, or manufacturing environment.

- Experience in fast-moving environments with evolving priorities, developing structures, high ownership, and pragmatic execution needs.

- Ability to lead through functional leads while shaping the operating model, roadmap, architecture, data platform, and AI agenda.

- Strong experience with SAP/ERP and core enterprise platforms; familiarity with PLM, MES, collaboration platforms, and their integration into a coherent enterprise and data landscape.

- Solid understanding of infrastructure, cloud, identity, endpoint management, networking, and service management.

- Experience with portfolio, demand, or PMO-style governance for technology initiatives, including AI and automation use cases.

- Practical experience building or scaling data platforms, analytics capabilities, executive dashboards, data governance, automation, or AI-enabled workflows.

- Strong vendor, budget, stakeholder, and executive communication skills.

- Fluent English skills.

Bonus skills

- Experience in aerospace, defense, automotive, advanced manufacturing, or another regulated engineering environment.

- Experience integrating ERP, PLM, MES, data platforms, and collaboration tools into a coherent enterprise landscape.

- Familiarity with cybersecurity, ISO 27001, NIS2, export-control-sensitive environments, responsible AI governance, or modern IT operating models.

- Fluent German skills.

**Benefits **

- **Employee Participation Program: **Share in our success through our virtual company share program

- **30 days of vacation: **Enjoy the days off to relax and recharge

- **Company pension plan:** Secure your future with our company pension plan, featuring a 20% employer contribution after the probation period

- **Subsidised lunch:** Stay energised with delicious, subsidised lunches every day

- **Public transport ticket: **Commute with ease using a fully financed Deutschlandticket

- **Sport Clubs membership: **Stay fit with our sponsored sports club memberships (EGYM Wellpass)

- **Individual learning allowance:** Grow your skills with an individual learning budget granted after the probation period

- **Childcare allowance:** Receive a childcare allowance for your non-school-age children

- **And Much More!** Discover additional perks and benefits when you join our team

**Who we are**

****

We are Isar Aerospace and we are at the forefront of New Space building a modern space business to enable faster, better and cheaper access to space.

Our mission is to help democratise space and use it for good in order to improve life on Earth now and for the future generations.

We are a fast-growing company aiming to provide sustainable and environmentally friendly launch solutions for small and medium-sized satellites and constellations into Low Earth Orbit. The company is privately funded by world-leading technology investors with strong commitment and support and our team is made of driven and talented people with a real passion for space innovation.

We're making rockets in a way that hasn't been done before disrupting a traditional industry. If you are up for the challenge, want to work on cutting-edge projects and be part of a team changing the world for better, come, join us and launch your career!

Want to find out more about us?

Visit [www.isaraerospace.com](http://www.isaraerospace.com/)

**Data Protection**

We process your personal data for the purpose of managing the recruitment process and assessing your application. For detailed information on how your data is processed, including your rights, please refer to our [Privacy Policy](https://isaraerospace.com/privacy-policy).

**Disclaimer**

Isar Aerospace SE is an equal-opportunity employer committed to fairness and inclusivity. We do not prioritize any specific religion, gender, nationality, or background. Due to security clearance requirements, affiliations with countries listed under § 13 para. 1 no. 17 SÜG may affect the application process. All qualified applicants are encouraged to apply.

We use Metaview to record interview audio so our team can review it later and stay focused during the conversation. We will record interviews only if you opt in. Please note that we will request your consent separately during the interview process. Participation is completely voluntary and will not affect your application in any way. For more information on how we process your personal data, please see our [Privacy Policy](https://deu01.safelinks.protection.outlook.com/?url=https%3A%2F%2Fisaraerospace.com%2Fprivacy-policy&data=05%7C02%7Cbritta.bonn%40ext.isaraerospace.com%7Cbf5a1173fd434834ab1c08dea5c061eb%7C50154d7ed4fe4770bb43bf09a927cc45%7C0%7C0%7C639130442882001477%7CUnknown%7CTWFpbGZsb3d8eyJFbXB0eU1hcGkiOnRydWUsIlYiOiIwLjAuMDAwMCIsIlAiOiJXaW4zMiIsIkFOIjoiTWFpbCIsIldUIjoyfQ%3D%3D%7C0%7C%7C%7C&sdata=l1vw27o02fEuCFAICyAHO91ObS%2FjnXDl5woYeGiSRek%3D&reserved=0).

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
