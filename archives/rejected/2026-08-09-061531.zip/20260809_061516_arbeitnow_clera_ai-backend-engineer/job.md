# AI & Backend Engineer

Posted: 2026-08-09T02:40:08Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

### About the Role

We're a seed-stage B2B SaaS company building an AI support agent platform that helps technical B2B teams automatically resolve complex customer support tickets. Our product integrates deeply with tools like Zendesk, Jira, Slack, and Sentry, and is built on a modern stack including Python, FastAPI, Next.js, TypeScript, PostgreSQL, Firestore, Docker, and Kubernetes — with OpenAI models at the core of our AI capabilities.

We're a small, fast-moving team of 9 based in **Munich, Germany**, and we're looking for an **AI & Backend Engineer** to join us on-site, 5 days a week. You'll own end-to-end features, push the boundaries of current-gen AI systems, and help shape the architecture powering our agents.

### What You'll Do

-

Shape and implement full-stack product features across the entire stack.

-

Develop and enhance AI-powered capabilities, including agent workflows and model pipelines.

-

Collaborate with the team to plan, design, and launch new features at pace.

-

Help make internal workflows AI-native — you'll use and improve AI tooling as part of your daily work.

### What We're Looking For

**Must-haves:**

-

1–4 years of experience in backend or AI engineering (new grads with strong projects welcome).

-

Hands-on experience integrating with OpenAI models and prompt engineering.

-

Demonstrable experience building backend systems or AI pipelines to production.

-

At least foundational experience working with AI agents or agentic workflows.

-

Experience deploying and operating applications with **Docker** and **Kubernetes**.

-

Proficiency with **Next.js, React, and TypeScript** for full-stack development.

-

Experience with **PostgreSQL** and/or **Firestore (GCP)**.

-

Eligibility to work in Germany (visa sponsorship is available).

-

Ability to work on-site in Munich, 5 days a week.

**Strong signals we look for:**

-

Hobby or side projects involving LLMs or related AI topics — we love seeing genuine curiosity in the space.

-

Heavy usage of AI coding agents (e.g., Codex, Claude Code, or Cursor), with concrete ideas or learnings on improving AI coding setups.

-

Experience designing end-to-end architectures and data/model pipelines.

-

Background at companies in the AI, SaaS, or enterprise software space.

### Location & Work Arrangement

-

**Location:** Munich, Germany

-

**Work arrangement:** On-site, 5 days a week

-

**Visa sponsorship:** Available

### Compensation & Benefits

Compensation details will be discussed during the interview process. As a seed-stage startup, we offer competitive equity alongside salary, and the opportunity to have real ownership over the product and architecture from day one.

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
