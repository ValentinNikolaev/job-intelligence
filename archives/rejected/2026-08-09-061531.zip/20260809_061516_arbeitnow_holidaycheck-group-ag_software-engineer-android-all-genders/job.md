# Software Engineer - Android (all genders)

Posted: 2026-08-09T02:09:06Z

## Rejection

- Category: role_mismatch
- Reason: title is an obvious mismatch for a backend profile

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
