# EGSE Engineer

Posted: 2026-08-08T20:40:23Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Here at The Exploration Company, we are developing, producing, and operating Nyx, a modular and reusable space orbital vehicle that can eventually be refuelled in orbit and that can carry cargo - and potentially humans in the longer run.

**Key Responsibilities:**

-

Design, develop, and maintain Electrical Ground Support Equipment (EGSE) sub-system and system level testing

-

Define and implement EGSE hardware and software architectures tailored to specific test scenarios, AIT campaigns, and HiL environments

-

Develop LabVIEW-based applications, for both desktop and real-time platforms (e.g., PXI, cRIO), supporting checkout, functional, and pre-launch test operations

-

Integrate and configure NI VeriStand as part of real-time test setups, including simulation of spacecraft interfaces and umbilical/harness verification

-

Design and support power, signal conditioning, and telemetry/telecommand interfaces between EGSE and the Unit/Spacecraft Under Test

-

Support RF test activities for the TT&C chain, including uplink telecommand injection, downlink telemetry reception, and coordination of conducted/radiated test setups with the RF/comms subsystem team

-

Collaborate with cross-functional teams (AIT, systems, RF, electrical, and FSW) to ensure seamless integration of EGSE hardware and software into functional test platforms

-

Support test execution, data acquisition, logging, and automated reporting during integration, functional, and environmental test campaigns

-

Create and maintain technical documentation, including EGSE architecture specifications, ICDs, code documentation, and user/operator guides

-

Provide support for debugging, troubleshooting, and continuous improvement of EGSE and test platforms, including on-site support during AIT/launch campaigns

-

Develop a robust and scalable EGSE software framework supporting reuse and modularity across projects

-

Define test automation workflows

-

Design and maintain EGSE-to-EUT interface hardware (harnesses, breakout boxes, simulators, load banks) with correct isolation, protection, and safety interlocks

-

Own cable and harness design for EGSE-to-EUT connections, including pinout definition, connector selection, shielding/grounding strategy, and drawing generation

-

Coordinate closely with electrical, RF, and systems engineers to ensure requirements traceability, interface compatibility, and test coverage

-

Drive the continuous evolution of EGSE/HiL infrastructure, with an emphasis on performance, reliability, and maintainability

-

Ensure all solutions meet space-grade quality, safety, and cleanliness standards (e.g., ESD, contamination control), aligned with project and range safety requirements

**Must-Have Skills and Qualifications**

-

Bachelor's or Master's degree in Electrical Engineering, Aerospace Engineering, Computer Science, or a related field

-

Proficiency in LabVIEW, including desktop and real-time application development

-

Hands-on experience with NI VeriStand in real-time test environments

-

Familiarity with NI TestStand for test automation and execution management

-

Solid understanding of EGSE/test platform architectures, hardware/software integration, and real-time systems

-

Experience with spacecraft electrical interfaces: power distribution/simulation, discrete/analog telemetry, telecommand encoding, and standard space communication protocols (e.g., CAN, RS422/485, MIL-STD-1553, SpaceWire, Ethernet)

-

Working knowledge of ICD development and requirements traceability between EGSE and flight hardware

-

Ability to influence and shape ICDs and connector/pinout definitions upstream, rather than solely implementing to a fixed interface — working with electrical/systems engineers early in the design cycle to ensure EGSE testability and harness manufacturability

-

Experience with cable/harness design, including connector selection, pinout/wiring diagrams, shielding and grounding practices, and generation of harness drawings (e.g., in ECAD tools or [draw.io/Visio](http://draw.io/Visio) equivalents)

-

Familiarity with RF test equipment and techniques (signal generators, spectrum/vector signal analyzers, RF switches, calibrated attenuators) for TT&C uplink/downlink stimulation and monitoring

-

Strong debugging and troubleshooting skills, with a structured and methodical approach, including at hardware bring-up and integration level

-

Experience working with LabVIEW FPGA is appreciated

-

Ability to write and integrate Python scripts to extend test workflows or support automation tasks

-

Familiarity with test/measurement hardware (oscilloscopes, DMMs, power supplies, electronic loads) and their programmatic control (e.g., VISA/SCPI)

-

Understanding of EMC/ESD-safe practices for handling flight and flight-like hardware

-

Fluent in English, with excellent written and verbal communication skills

-

Proven ability to work independently, drive initiatives end-to-end, and deliver in a high-paced environment

-

Willingness to travel/support on-site AIT or launch site campaigns is a plus

**Why you should join us!**

What makes us special here at The Exploration Company and why we think you will enjoy working here is:

-

We’re Agile - we make decisions fast whilst keeping our goals and systems in mind

-

We’re Open and Collaborative - we are transparent about risks and obstacles, so that we can cooperate to overcome them

-

We have a lot of Fun - we refuel our energy knowing we are democratising space. It’s a wonderful and rare opportunity, are YOU up for the challenge?

We'd love to hear from you if you wish to be a part of our journey. Please submit your CV now for immediate consideration and we will be in touch shortly.

*The Exploration Company is an equal opportunity employer and values diversity. We do not discriminate based on race, religion, colour, national origin, gender, sexual orientation, age, marital status or disability status. Relocation assistance is provided for those willing to relocate including visa sponsorship where applicable. *

*
All offers are contingent upon the successful completion of a background check, which will be subject to the country, role, and project you applied for. By submitting your application, you acknowledge and agree that any offer of employment may be conditional upon successful condition of this check. The Exploration Company partners with Zinc Work Limited located in the UK (Zinc), a third-party provider, to ensure this process as efficient and transparent as possible.

If applicable, you will receive an email from Zinc upon acceptance of your offer with a link to a secure portal where you can provide the required information to Zinc. *

Compensation: €65K – €82.5K

- • €65K – €82.5K

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
