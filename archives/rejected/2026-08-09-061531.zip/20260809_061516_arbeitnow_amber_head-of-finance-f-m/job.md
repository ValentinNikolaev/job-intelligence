# Head of Finance (F/M/*)

Posted: 2026-08-08T20:40:23Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**Aus Europa, für Europa – Wir bauen Europas Business-KI.**

Wir sind amber, ein wachsendes und innovatives KI-Startup. KMUs profitieren davon, wenn internes Wissen sofort nutzbar wird und intelligente Agenten darauf reagieren können. Wir glauben an eine Zukunft, in der Business-KI, einschließlich Agenten, in einer gemeinsamen Plattform zusammenarbeitet, sodass Teams schneller arbeiten, Übergaben nahtlos erfolgen und das Know-how im Unternehmen bleibt.

Als Head of Finance (F/M/*) bei amber übernimmst du die volle Verantwortung für unsere Finanzorganisation – und baust sie von Grund auf mit auf. Wichtig zu wissen: Kein Team am Tag 1 – du stellst es auf. Du arbeitest eng mit der Geschäftsführung zusammen, schaffst Transparenz über unsere Zahlen, professionalisierst unsere Finanzprozesse und begleitest unser Wachstum strategisch. Diese Rolle wächst mit dem Unternehmen – mit klarer Perspektive CFO.

Wenn du Lust hast, die Finanzfunktion eines innovativen SaaS-Unternehmens von Anfang an zu gestalten, dann melde dich jetzt bei uns!

## Deine Aufgaben

-

Du verantwortest das gesamte Finanzmanagement – von Controlling und Reporting über Liquiditätsplanung bis hin zu Budgetierung und Forecasting

-

Du baust die Finanzorganisation eigenständig auf: Am Tag 1 gibt es kein Team – du definierst Strukturen, Prozesse und stellst nach und nach dein eigenes Team zusammen

-

Du entwickelst aussagekräftige KPI-Dashboards und schaffst Zahlentransparenz für Geschäftsführung, Team und Investoren

-

Du steuerst die Zusammenarbeit mit Steuerberatung, Wirtschaftsprüfung und Banken und verantwortest Monats- und Jahresabschlüsse

-

Du begleitest Finanzierungsrunden, Due-Diligence-Prozesse und strategische Projekte gemeinsam mit der Geschäftsführung

-

Du professionalisierst unsere Tool-Landschaft im Finance-Bereich und treibst die Automatisierung von Finanzprozessen voran

-

Du wächst mit deiner Rolle: Mittelfristig entwickelst du dich in Richtung CFO und gestaltest die strategische Ausrichtung des Unternehmens aktiv mit

## Deine Qualifikationen

-

Du bringst mindestens 3 Jahre Erfahrung in Transaction Services, Wirtschaftsprüfung oder Investment Banking mit

-

Du hast ein abgeschlossenes Studium in BWL, Finance, Accounting oder einem vergleichbaren Bereich

-

Du verfügst über fundierte Kenntnisse in Rechnungslegung (HGB), Controlling und Finanzplanung; erste Berührungspunkte mit SaaS-Metriken (ARR, MRR, Churn, CAC) sind ein Plus

-

Du hast Lust auf Aufbauarbeit: Du willst nicht verwalten, sondern gestalten – Hands-on-Mentalität und Eigenverantwortung zeichnen dich aus

-

Du arbeitest datenorientiert, analysierst komplexe Sachverhalte strukturiert und leitest daraus konkrete Maßnahmen ab

-

Du bist technikaffin und sicher im Umgang mit modernen Finance-Tools und ERP-/Buchhaltungssystemen

-

Du denkst unternehmerisch und möchtest langfristig Verantwortung übernehmen – bis hin zur Perspektive CFO

-

Du kommunizierst klar und verbindlich auf Deutsch und Englisch und trittst sicher gegenüber Geschäftsführung, Investoren und Banken auf

## **Deine Benefits**

-

Team Offsites – Da du in einem internationalen Team arbeiten wirst, treffen wir uns zweimal im Jahr alle zusammen irgendwo in Europa

-

Du hast die Wahl: Entweder ein bezuschusstes Deutschlandticket oder eine Urban Sports Club Mitgliedschaft

-

Wir leben ein hybrides Arbeitsmodell: Wir sind der Meinung, dass es wichtig ist, regelmäßig in Person zusammenzuarbeiten. Daher treffen wir uns dreimal wöchentlich an einem unserer Standorte

-

Damit du vor Ort auch gut versorgt bist, gibt es bei uns jeden Arbeitstag vor Ort digitale, steuerfreie Essensgutscheine direkt aufs Handy

-

Starte in einem Unternehmen, das dich wachsen lässt und dir die Möglichkeit gibt, deine Fähigkeiten Schritt für Schritt auszubauen

-

Wir fördern deine persönliche Entwicklung durch Weiterbildung und Raum für Eigenverantwortung

-

Ein Team von motivierten Leuten, die Bock haben, KI-Lösungen auch für mittelständische Unternehmen zugänglich zu machen

-

Arbeite mit den neuesten Technologien und Tools

### **Ein paar Worte zum Schluss**

Klingt spannend? Dann hilf uns jetzt und schick uns einfach kurz deinen CV oder dein LinkedIn-Profil. Wir freuen uns auf dich!

Bitte beachte: Für diese Position berücksichtigen wir ausschließlich Bewerber:innen mit Wohnsitz in Deutschland.

**Let's go big together 🚀**

Compensation: €70K – €120K • Offers Equity

- • €70K – €120K • Offers Equity

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
