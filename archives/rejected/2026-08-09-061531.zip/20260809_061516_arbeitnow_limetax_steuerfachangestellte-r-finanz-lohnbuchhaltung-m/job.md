# Steuerfachangestellte/r - Finanz- & Lohnbuchhaltung (m/w/d)

Posted: 2026-08-08T23:40:14Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**Welzenbach Wirtschafts- und Steuerberatungsgesellschaft mbH | Standort: Würzburg & Lohr am Main (Hybrid)**

**Über uns**

Wir als Welzenbach sind eine Steuerkanzlei mit Standorten in Lohr am Main und Würzburg. Wir setzen auf digitale Prozesse, einen hohen fachlichen Anspruch sowie eine persönliche Mandantenbetreuung durch feste Ansprechpartner, für einen vielseitigen Mandantenstamm aus Unternehmen und Privatpersonen verschiedenster Branchen.

Welzenbach ist Teil der Limetax-Gruppe, einer Kanzleigruppe, die Vorreiter bei Digitalisierung, KI-gestützten Tools und der Weiterentwicklung von Kanzleiprozessen ist.

Im Team legen wir Wert auf kurze Wege, offene Kommunikation und ein unterstützendes Miteinander.

**Deine Aufgaben**

-

Eigenständige Betreuung der laufenden Finanzbuchhaltung

-

Erstellung von Lohn- und Gehaltsabrechnungen für verschiedene Mandant:innen

-

Direkter Austausch mit Mandant:innen als feste Ansprechperson

-

Digitale Kommunikation mit Behörden und Sozialversicherungsträgern

-

Mitarbeit an modernen und digitalen Kanzleiprozessen

**Dein Profil**

-

Abgeschlossene Ausbildung als Steuerfachangestellte:r

-

Mehrjährige Erfahrung in der Finanz- und/oder Lohnbuchhaltung

-

Kenntnisse in DATEV – idealerweise DATEV LODAS

-

Strukturierte und selbstständige Arbeitsweise

-

Freude an direktem Mandantenkontakt

-

Teamfähigkeit und Interesse an digitalem Arbeiten

-

Erfahrung mit Jahresabschlüssen und Steuererklärungen

**Das erwartet Dich**

-

Flexible Arbeitszeiten & regelmäßige Homeoffice-Tage

-

Digitales Arbeiten mit modernen Prozessen und Tools

-

Eigenverantwortliche Betreuung fester Mandant:innen

-

Kurze Entscheidungswege & direkte Ansprechpartner:innen

-

Persönliche Weiterbildungs- und Entwicklungsmöglichkeiten

-

Freier Tag an Deinem Geburtstag

-

Sommer-Event & Weihnachtsfeier

-

Wöchentlicher Teamlunch

-

Kollegiales und familiäres Team mit echter Zusammenarbeit

**Arbeitsort**

Würzburg oder Lohr am Main

**Bewerbung**

Wir freuen uns auf Deine Bewerbung mit Angabe Deines frühestmöglichen Eintrittstermins.

Die Position wird zentral über Limetax Recruiting betreut.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
