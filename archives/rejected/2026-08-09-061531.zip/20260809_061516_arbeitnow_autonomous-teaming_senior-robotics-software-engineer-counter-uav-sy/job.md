# Senior Robotics Software Engineer Counter UAV Systems - Generalist (m/w/d)

Posted: 2026-08-09T02:09:34Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
