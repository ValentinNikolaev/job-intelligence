# Business Development Representative

Posted: 2026-08-08T20:40:16Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

# **About Zip**

Zip is the AI platform for enterprise procurement — built for humans and agents working together. By orchestrating procurement across teams, tools, and suppliers with the help of AI agents, companies can secure the resources they need to innovate faster than ever before.

The world’s most influential enterprises trust Zip, including T-Mobile, OpenAI, AMD, Mars, Dollar Tree, and more. Together they’ve saved over $8 billion and processed over $500 billion in spend. Zip’s team includes product leaders from Apple, Airbnb, and Meta, as well as former procurement leaders from United Health, Sanofi, MGM Resorts, Discover, and NASA.

Backed by Adams Street, Alkeon, BOND, CRV, DST, Tiger Global, and Y Combinator, Zip has raised $371 million, most recently at a $2.2 billion valuation and has been recognized by Forbes Fintech 50, Fast Company's Most Innovative Companies, Inc. Best in Business, and LinkedIn Top Startups.

## **Your Role**

Zip is looking for a highly motivated, outgoing, and tech-savvy sales representative with strong business acumen to join our growing Business Development team. As a Business Development Representative, you will generate new business by prospecting outbound leads through cold outreach and work collaboratively across our sales organization to set high-value meetings. This is a highly strategic role that requires creativity, resilience, and the ability to partner effectively with an Account Executive to create new business opportunities. This is a fully remote role supporting our EMEA team.

Joining the Business Development team is an opportunity to fast-track your career in sales. Applicants should have a growth mindset and be excited to work collaboratively across the Revenue organization. You will learn consultative selling and hone in on our best-in-class outbound motion to execute our sales strategy. High performers in the BDR role will open up new opportunities for career growth within our rapidly growing organization.

We’re looking for a customer-focused, highly motivated, and driven individual with a desire to grow and advance in a career in sales. If you have a proactive and customer-first mentality with the passion to demonstrate Zip’s commitment to our merchants, we’d love to talk to you!

## **You Will**

-

Partner closely with our VP of Sales and Account Executives to identify and source meetings that lead to pipeline and closed revenue

-

Prospect across a high volume of accounts, with a keen eye on strategically prioritizing your time

-

Become a market expert – researching and understanding our target industries and personas, and what makes them tick

-

Build a point of view on how to help customers with their needs and the right qualifying questions to ask

-

Be adaptable and flexible – as part of an early-stage hyper growth company, we are rapidly growing out our process but we want to you to help shape our sales process

## **Qualifications**

-

6-12+ months or equivalent sales experience

-

A consistent track record of meeting and exceeding goals

-

Be a highly strategic thinker and problem solver with a solutions first and adaptable mindset

## **Nice to Haves**

-

Experience with Salesforce, Outreach, ZoomInfo, ScratchPad, Gong, and/or SalesNavigator

-

Tech experience or proven success in a fast-paced environment

-

A strong passion for fintech is a plus

-

Excellent written and verbal communication skills with a paramount focus on detail

-

An ability to celebrate change and embrace accountability

## **Within 2 weeks, you will...**

-

Complete Zip’s new hire training & onboarding program alongside other new Zip team members

-

Gain a broader understanding of our products and how your role fits into the organization

-

Partner with the Director of Business Development on key success metrics for your role and how you will measure against them

-

Partner with the Director of Business Development to discuss your personal and professional goals

-

Begin developing familiarity with our business, platform, and applications, as well as our company’s key metrics

-

Acclimate yourself with the day-to-day responsibilities of Zip’s Business Development team by shadowing team members, listening to recorded customer calls, and working closely with our Account Executive team

## **Within 1 month, you will...**

-

Identify and contact prospective clients to build a pipeline through a variety of methods including, but not limited to cold-calling, emailing, social media outreach, and mass email campaigns

-

Create a professional and engaging first impression with our prospects and customers

-

Create, maintain and update our database of prospects with complete information and emails

-

Thoroughly qualify all outbound opportunities and collaborate with Account Executives for a smooth and sophisticated customer experience

-

Generate net new business through outbound prospecting

-

Prioritize leads, research prospects and position relevant product features to solve business needs while strategically managing your time

-

Manage follow-up with calls-to-action to consistently build a sales pipeline

## **Within 2 months, you will...**

Achieve department standards for activity that includes:

-

Making a minimum number of quality outbound calls per day

-

Scheduling a minimum number of new quality discovery calls per week

-

Become a market expert by researching and understanding our target industries and personas

-

Exceed activity and pipeline goals on a monthly basis

-

Consistently reflect on your own skill and development gaps along with the Director of Business Development to identify personal and professional goals

-

Become a mentor to new hires entering into the Business Development organization

-

Become a key stakeholder in Zip’s growth as we continue to scale our core business

## **Perks & Benefits**

At Zip, we’re committed to providing our employees with everything they need to do their best work.

-

📈 Start-up equity

-

🦷 Health, vision & dental coverage

-

🚠 Team building events & happy hours

-

🌴 Flexible PTO

-

💻 Apple equipment plus home office budget

*We're looking to hire Zipsters and that means hiring people who take ownership, communicate openly, have an underdog mindset, and are excited to increase the pace of innovation for every business in the world. We encourage all candidates to apply even if your experience doesn't exactly match up to our job description. We are committed to building a diverse and inclusive workspace where everyone (regardless of age, religion, ethnicity, gender, sexual orientation, and more) feels like they belong. We look forward to hearing from you!*

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
