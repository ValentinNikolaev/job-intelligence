# Senior Software Engineer (m/w/d) - SEtrade

Posted: 2026-08-08T23:00:25Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**Strom lässt sich nicht auf Halde legen. Erzeugung und Verbrauch müssen sich in jeder Sekunde ausgleichen, sonst kippt die Netzfrequenz. Das ist keine Haltung, das ist Physik.**

Aus dieser Physik entsteht ein Markt, der in 15-Minuten-Scheiben handelt und keine Rücksicht nimmt. Genau dort läuft unsere Software.

Wir bewirtschaften heute 350 MWp Solar, 100 MWp Wind, 100 MWh Speicher, 12 MW Wasserstoff und über 40 HPC-Ladepunkte. Jede dieser Anlagen liefert Zeitreihen. Aus Zeitreihen werden Prognosen, aus Prognosen Fahrpläne, aus Fahrplänen Gebote an der Börse. Wenn ein Glied dieser Kette zwanzig Minuten zu spät ist, kostet das Geld. Nicht Story Points. Geld.

**WARUM ES DIESE STELLE GIBT**

Wir haben die Plattform in wenigen Jahren von null auf 850 GWh gebracht. An einigen Stellen haben wir dabei bewusst pragmatisch gebaut, weil am Markt zu sein wichtiger war als sauber zu sein. Das war richtig.

Heute ist es das nicht mehr. Dieselben Abkürzungen, die uns schnell gemacht haben, bremsen uns inzwischen. Tabellen, die für Millionen Zeilen gedacht waren, halten Milliarden. Prozessketten, die früher jemand morgens von Hand angestoßen hat, laufen rund um die Uhr und dürfen nicht mehr ausfallen.

Wir suchen niemanden, der das verwaltet. Wir suchen jemanden, der es neu baut, während es läuft.

## Aufgaben

**WAS DU TATSÄCHLICH TUST**

- Du entscheidest, wie unsere Systeme geschnitten sind. Nicht in einem Gremium, sondern indem Du den Vorschlag machst, ihn verteidigst und ihn anschließend umsetzt. Wer entscheidet, baut mit.

- PostgreSQL und TimescaleDB, Fahrpläne, Messwerte, Marktdaten. Schema, Partitionierung, Aggregation, Query-Pläne. Wenn eine Abfrage acht Sekunden braucht, ist das für uns ein Fehler und kein Feature.

- Prognose, Optimierung, Fahrplanübermittlung. Retry, Idempotenz, Alerting. Der Maßstab ist simpel: Was nachts schiefgeht, darf morgens niemand von Hand nacharbeiten müssen.

- Anlagen anbinden. PV, Speicher, Wasserstoff, Ladeinfrastruktur. ModbusTCP, REST, SFTP. Du telefonierst dabei direkt mit den Technikern beim Kunden und suchst den Fehler gemeinsam, statt ein Ticket zu schreiben.

- Am Monatsende wird aus denselben Zeitreihen Geld. Marktprämie, PPA- und Speichervergütung, Umlagen, Ladevorgänge, THG-Quoten. Netzbetreiber liefern Messwerte nach, korrigieren sie und schicken ein Jahr später erneut. Deine Läufe müssen das aushalten und beim zweiten Durchlauf dasselbe Ergebnis liefern wie beim ersten.

- PHP mit Laravel, React, PostgreSQL/TimescaleDB, Python. Tests, CI/CD und Monitoring gehören zur Umsetzung und nicht zu dem, was man danach noch macht.

- Wir arbeiten mit Claude und vergleichbaren Werkzeugen produktiv, nicht als Demo. Du weißt aus eigener Erfahrung, wo sie tragen und wo sie Unsinn produzieren, und Du gibst das ins Team weiter.

**HANDEL UND ABRECHNUNG SIND EIN SYSTEM**

Die Zeitreihe, die um 14:30 den Fahrplan bestimmt, bestimmt am Monatsende, was der Kunde ausgezahlt bekommt. Wenn beide Wege zu unterschiedlichen Zahlen kommen, ist das kein Monitoring-Thema mehr. Das findet dann der Wirtschaftsprüfer.

Deshalb liegen bei dieser Rolle beide Seiten in einer Hand. Vorne zählt Geschwindigkeit, hinten Reproduzierbarkeit: Ein Abrechnungslauf muss nach einem Jahr mit korrigierten Netzbetreiberdaten erneut startbar sein und nachvollziehbar erklären, warum sich das Ergebnis geändert hat. Versionierte Tarif- und Vergütungslogik, idempotente Wiederholungsläufe, saubere Zuordnung über MaLo-IDs. Wer das trennt, baut zwei Wahrheiten.

## Qualifikation

**WORAN WIR DICH MESSEN**

Nach 90 Tagen hast Du einen strukturellen Engpass beseitigt, und man kann es messen.

Nach zwölf Monaten gehen neue Anlagen ohne Sonderlösung produktiv, die zeitkritischen Ketten und die Abrechnungsläufe laufen ohne Handarbeit, und die Entwickler um Dich herum sind besser geworden. Der letzte Punkt zählt genauso wie die beiden davor.

**DIE MESSLATTE**

**Wir haben keine Anforderung an Deinen Abschluss. Wir haben eine an Deinen Nachweis.**

- Du hast mindestens ein System durch einen Skalierungssprung getragen und warst dabei derjenige, der die Architekturentscheidung getroffen hat. Fünf Jahre Berufserfahrung ist unsere Faustregel dafür, keine Bedingung. Wer es in drei geschafft hat, ist uns genauso recht.

- Du hast mit Zeitreihen im Milliardenbereich gearbeitet und weißt, wie sich ein schlechter Partitionierungsschnitt anfühlt, wenn er zwei Jahre alt ist.

- Du hast eine Prozesskette gebaut, die nachts ohne Dich läuft. Und Du hast erlebt, was passiert, wenn sie es nicht tut.

- PHP mit Laravel, React, PostgreSQL. Vergleichbare Erfahrung in anderen Sprachen zählt genauso. Wir stellen niemanden wegen eines Frameworks ein und niemanden deswegen ab.

- Git, Docker, CI/CD, automatisierte Tests, Observability. Handwerk, kein Projekt.

- Deutsch ab C1, weil Du mit Netzbetreibern, Kunden und Marktpartnern sprichst. Englisch sicher.

- Du hältst ein Code Review für ein Geschenk.

**Was wir ausdrücklich nicht verlangen**

Einen bestimmten Abschluss. Zertifikate. Eine Mindestzahl an Jahren. Und Energiewirtschaft im Lebenslauf. Direktvermarktung, Regelenergie, Bilanzkreise und Abrechnungslogik lernst Du hier in Monaten. Technisches Urteilsvermögen bringen wir Dir nicht bei.

Zeig uns ein System, keine Liste.

## Benefits

**WANN DU HIER UNGLÜCKLICH WIRST**

- Wenn Du eine fertig geschnittene Anforderung brauchst, bevor Du anfängst.

- Wenn Du auf die perfekte Lösung wartest.

- Wenn „läuft bei mir lokal" für Dich fertig bedeutet.

- Wenn Du Probleme außerhalb Deines Bereichs siehst und sie für nicht Dein Thema hältst.

- Wenn Dir der Titel wichtiger ist als das, was am Ende produktiv läuft.

**WAS WIR NICHT HABEN**

Keinen Absatz über Obstkörbe. Keine acht Freigabestufen. Keine Architekten, die nicht programmieren. Und keine Roadmap, die so tut, als wüsste sie, wie der Markt in zwei Jahren aussieht.

**WAS WIR HABEN**

- Ein Büro in München, in dem tatsächlich Leute sitzen.

- Entscheidungswege über max. zwei Personen statt über zwölf.

- Moderne KI-Werkzeuge als Standard und nicht als Pilotprojekt.

- Weiterbildung, vermögenswirksame Leistungen in maximaler Höhe, Firmenfitness. Das steht hier, weil es dazugehört, nicht weil es der Grund sein sollte.

- Perspektive Richtung Lead Engineer oder Software Architect, sobald die Arbeit es hergibt.

- Probleme, die noch niemand für Dich gelöst hat.

**BEWERBUNG**

Kein Motivationsschreiben. Schick uns drei Dinge:

- Deinen Lebenslauf oder Dein Profil auf GitHub oder GitLab.

- Ein System, das Du wesentlich mitentworfen hast, und in drei bis fünf Sätzen die Entscheidung, die Du daran heute am meisten bereust.

- Eine Stelle in dieser Ausschreibung, die Deiner Meinung nach falsch gedacht ist.

**Punkt drei ist ernst gemeint. Wir lesen ihn zuerst.**

**DEIN ANSPRECHPARTNER**

Lara-Theresa Masur

+49 151 27657632

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
