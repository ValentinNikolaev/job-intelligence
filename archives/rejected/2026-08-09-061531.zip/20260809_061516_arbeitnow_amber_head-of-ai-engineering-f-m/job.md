# Head of AI Engineering (F/M/*)

Posted: 2026-08-08T20:40:23Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**Aus Europa, für Europa – Wir bauen Europas Business-KI.**

Wir sind amber, ein wachsendes und innovatives KI-Startup. KMUs profitieren davon, wenn internes Wissen sofort nutzbar wird und intelligente Agenten darauf reagieren können. Wir glauben an eine Zukunft, in der Business-KI, einschließlich Agenten, in einer gemeinsamen Plattform zusammenarbeitet, sodass Teams schneller arbeiten, Übergaben nahtlos erfolgen und das Know-how im Unternehmen bleibt.

Als **Head of AI Engineering (F/M/*)** bei amber verantwortest du die technische Weiterentwicklung unserer KI-Plattform – von Enterprise Search über RAG-Pipelines bis hin zu agentenbasierten Workflows. Du führst unser AI-Engineering-Team, setzt die technologische Roadmap gemeinsam mit Product und Geschäftsführung um und sorgst dafür, dass unsere Lösungen sicher, skalierbar und produktionsreif bei über 400 Unternehmen im Einsatz sind.

Wenn du Lust hast, die technologische Zukunft eines innovativen SaaS-Produkts maßgeblich zu prägen, dann melde dich jetzt bei uns!

## Deine Aufgaben

-

Du verantwortest die technische Vision und Architektur unserer KI-Plattform – von in House trained small language models über Vektorisierung, RAG-Pipelines bis hin zu agentenbasierten Workflow

-

Du führst das AI-Engineering-Team fachlich und disziplinarisch, entwickelst es weiter und baust es entsprechend unserer Wachstumsziele gezielt aus

-

Du übersetzt Produktanforderungen gemeinsam mit Product und Geschäftsführung in eine klare technische Roadmap und priorisierst konsequent nach Kundennutzen

-

Du stellst sicher, dass unsere Systeme skalierbar, performant und zuverlässig laufen – von der Modellauswahl über Evaluierung bis zum Monitoring in Produktion

-

Du etablierst Best Practices für ML-/LLM-Ops, Code-Qualität, Testing und Deployment und entwickelst unsere Engineering-Prozesse kontinuierlich weiter

-

Du verantwortest Sicherheits- und Compliance-Anforderungen im Engineering mit – DSGVO-Konformität, ISO 27001 und Berechtigungsbewusstsein sind bei uns keine Nebensache, sondern Kern des Produkts

-

Du beobachtest aktuelle Entwicklungen im Bereich LLMs, Retrieval und Agenten, bewertest neue Technologien und entscheidest, was den Weg in unsere Plattform findet

-

Du bist Sparringspartner für dein Team: Du förderst technische Exzellenz, gibst Feedback und schaffst ein Umfeld, in dem Engineers wachsen können

## Deine Qualifikationen

-

Du hast mehrjährige Erfahrung in der Entwicklung und im Betrieb von Machine-Learning- oder KI-Systemen in Produktion, idealerweise im SaaS- oder B2B-Umfeld

-

Du hast bereits ein Engineering-Team geführt oder aufgebaut und weißt, wie man technische Teams motiviert, entwickelt und Prioritäten klar setzt

-

Du bringst tiefes Verständnis für moderne KI-Technologien mit – LLMs, RAG, Vektor-Datenbanken, Embeddings und idealerweise agentenbasierte Architekturen

-

Du bist stark in Softwarearchitektur und Backend-Entwicklung, sicher in Python und vertraut mit Cloud-Infrastruktur, CI/CD und MLOps-Praktiken

-

Du denkst strategisch und packst gleichzeitig operativ mit an – Hands-on-Mentalität ist für dich selbstverständlich

-

Du triffst technische Entscheidungen datenbasiert, pragmatisch und mit Blick auf Wartbarkeit und Skalierung

-

Du hast ein Bewusstsein für Datenschutz und Sicherheit und idealerweise Erfahrung mit Compliance-Anforderungen im Enterprise-Umfeld

-

Du kommunizierst klar und verbindlich auf Deutsch und Englisch und trittst sicher mit unterschiedlichen Stakeholdern auf – vom Engineer bis zur Geschäftsführung

## Deine Benefits

-

Team Offsites – Da du in einem internationalen Team arbeiten wirst, treffen wir uns zweimal im Jahr alle zusammen irgendwo in Europa

-

Du hast die Wahl: Entweder ein bezuschusstes Deutschlandticket oder eine Urban Sports Club Mitgliedschaft

-

Wir leben ein hybrides Arbeitsmodell: Wir sind der Meinung, dass es wichtig ist, regelmäßig in Person zusammenzuarbeiten. Daher treffen wir uns dreimal wöchentlich an einem unserer Standorte

-

Damit du vor Ort auch gut versorgt bist, gibt es bei uns jeden Arbeitstag vor Ort digitale, steuerfreie Essensgutscheine direkt aufs Handy

-

Starte in einem Unternehmen, das dich wachsen lässt und dir die Möglichkeit gibt, deine Fähigkeiten Schritt für Schritt auszubauen

-

Wir fördern deine persönliche Entwicklung durch Weiterbildung und Raum für Eigenverantwortung

-

Ein Team von motivierten Leuten, die Bock haben, KI-Lösungen auch für mittelständische Unternehmen zugänglich zu machen

-

Arbeite mit den neuesten Technologien und Tools

**Ein paar Worte zum Schluss**

Klingt spannend? Dann hilf uns jetzt und schick uns einfach kurz deinen CV oder dein LinkedIn-Profil. Wir freuen uns auf dich!

Bitte beachte: Für diese Position berücksichtigen wir ausschließlich Bewerber:innen mit Wohnsitz in Deutschland.

**Let's go big together** 🚀

Compensation: €70K – €120K • Offers Equity

- • €70K – €120K • Offers Equity

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
