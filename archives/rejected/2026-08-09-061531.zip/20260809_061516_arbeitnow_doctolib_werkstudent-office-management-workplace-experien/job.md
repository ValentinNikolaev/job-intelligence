# Werkstudent Office Management & Workplace Experience (x/f/m) - München

Posted: 2026-08-08T20:55:27Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

## **Gemeinsam gestalten wir die Gesundheitsversorgung der Zukunft**

Doctolib sucht Dich **ab sofort** als **Werkstudent:in im Bereich **Office Management & Workplace Experience**** für unseren Standort **in München. **

Deine Aufgaben umfassen ein breites Spektrum an Initiativen – von der Schaffung und Pflege eines sozialen Arbeitsumfeldes für unser Team in unserem Münchner Büro bis hin zur Unterstützung bei der Organisation von Veranstaltungen und mitarbeiterbezogenen Projekten in enger Zusammenarbeit mit dem Workplace Experience Team in Berlin.

## **Deine Aufgaben**

Als Werkstudent:in unterstützt Du uns in den folgenden Aufgabenbereichen:

- **Workplace Point of Contact:** erste Ansprechperson für alle Büronutzer:innen und Mitarbeiter:innen in München (ca. 47 Schreibtische)

- **Front Office Management:** Empfang von Besucher:innen sowie Lieferant:innen und Lieferungen

- **Bürokoordination und -management: **Steuerung der Bürologistik zur Gewährleistung eines organisierten, sauberen und sicheren Arbeitsumfeldes

- **Verwaltung des Zutrittssystems:** Beantragen, verwalten und organisieren von neuen Zutrittskarten und Parkplätzen

- **Verwaltung der ein- und ausgehenden Pakete und Post**

- **Verwaltung der Lebensmittel- und Cateringlieferungen: **Versorgung des Büros mit Speisen und Getränken

- **Verwaltung des Büromaterials: **Sicherstellen, dass alle Mitarbeiter:innen alles haben, was sie im Büro benötigen (Stühle, Schreibtisch, Büromaterial usw.)

- **Zusammenarbeit mit HR und Events Team:** Planung, Organisation und Unterstützung von Unternehmensaktivitäten und -veranstaltungen

**Während Deiner Tätigkeit bei uns wirst Du:**

- alle Aspekte des Büromanagements erlernen und vertiefen

- Deine Projektmanagementfähigkeiten weiterentwickeln und auf die nächste Ebene bringen

- Fachkenntnisse im Lieferanten- und Stakeholdermanagement erwerben

## **Dein Profil**

*Du bist der festen Überzeugung, dass Du genau das mitbringst, was es für die Position braucht? Dann ermutigen wir Dich, Dich zu bewerben. Selbst wenn Du nicht jede Anforderung erfüllst, bist Du vielleicht genau die/der richtige zukünftige Doctoliber:in für diese oder andere Stellen!*

**Um Teil unseres Teams zu werden, bringst Du Folgendes mit:**

- Du bist in Vollzeit an einer Hochschule immatrikuliert

- Du hast erste Erfahrungen in Positionen mit Kundenkontakt

- Du hast eine schnelle Auffassungsgabe und ein ausgeprägtes Organisationstalent

- Du gehst offen auf Menschen zu und pflegst einen klaren und freundlichen Kommunikationsstil

- Du arbeitest selbstständig und zuverlässig

- Du verfügst über sehr gute Deutschkenntnisse (C1-Niveau)

**Besonders interessant sind für uns außerdem:**

- Fließende Englischkenntnisse (B2-Niveau)

- Erfahrung im Büromanagement oder als (Team-)Assistent:in

- Die Fähigkeit, mehrere Projekte gleichzeitig zu managen

## **Was wir Dir bieten**

- Ein strukturiertes und individuelles Onboarding im Rahmen unserer Doctolib Academy sowie ein breites Angebot an internen Trainingsprogrammen

- Ein von Doctolib gesponsertes Deutschlandticket oder die Übernahme Deines Semestertickets

- 28 Urlaubstage im Jahr (anteilig auf Deine Arbeitszeiten berechnet)

- Eine betriebliche Krankenversicherung mit vielen Zusatzleistungen und Bezuschussungen (nach 6 Monaten)

- Bezuschussungen zu Deinem Lebensmitteleinkauf

- Ein gefördertes Sportangebot mit unserem Partner Urban Sports Club

## **Der Interviewprozess**

- Interview mit Deinem Team

- Kennenlerngespräch mit dem Head of Workplace Experience

- Offer

## **Job Details**

- Tätigkeit als Werkstudent:in (20 Std./Woche)

- Tätigkeitsdauer: min. 1 Jahr

- Arbeitsort: München

- Gehalt: 14 €/Stunde

- Startdatum: ab sofort

- Arbeitsmodus: Office-basiert

*Wir verfolgen die Vision, die Gesundheit aller zu verbessern. Dies spiegelt sich auch im Recruiting wider. Wir evaluieren Bewerbungen ausschließlich auf der Grundlage von Qualifikation und Motivation. Diskriminierung wird bei uns nicht toleriert.*

*Je diverser unser Team und die Ideen sind, desto mehr wird unser Produkt die Gesundheit unserer Nutzer:innen verbessern können. Deshalb laden wir Dich ein, Dich bei uns zu bewerben, unabhängig von Geschlecht, Religion, Alter, sexueller Orientierung, ethnischer Herkunft oder Behinderung.*

*Um Chancengleichheit zu gewährleisten, kannst Du in Deiner Bewerbung auf Angaben wie Fotos, Alter, etc. verzichten. Lass uns bitte wissen, welche Vorkehrungen wir treffen können, um Dich bestmöglich zu unterstützen. Wir freuen uns, mit Dir das Gesundheitswesen zu digitalisieren!*

*Alle bereitgestellten Informationen werden von Doctolib für das Bewerbungsmanagement verarbeitet. Für Details zur Datenverarbeitung klicke bitte[ hier](https://doctolib.legal/B2C-Privacy-Policy-Career-DE). Bei Fragen oder wenn Du Deine Rechte wahrnehmen möchtest, wende Dich bitte an hr.dataprivacy(at)doctolib.com.*

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
