# Werkstudent:in Content Creation & Fulfillment (m/w/d)

Posted: 2026-08-10T21:59:03Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

HACOY ist ein junges Slow Luxury Modelabel, entworfen in Rom und zuhause in München. Wir stehen für HAppiness, Comfort und jOY, spürbar in jedem Stück und in jedem Paket, das rausgeht. Für unseren Showroom in München suchen wir einen Menschen, der unsere Marke sichtbar macht und gleichzeitig mit anpackt.

## Aufgaben

- Du erstellst Content für unsere Social Media Kanäle, vor und hinter der Kamera

- Du entwickelst eigene Ideen und hast ein Auge dafür, was gerade passiert

- Du kommissionierst und verpackst unsere lokalen Bestellungen schön und zuverlässig

## Qualifikation

- Du bist als Student:in eingeschrieben und wohnst in München

- Du sprichst Deutsch und Englisch sicher

- Du stehst gerne vor der Kamera und wirkst dabei natürlich

- Du hast ein gutes Auge für Ästhetik und Storytelling

- Zuverlässigkeit und Sorgfalt, gerade beim Verpacken

- Erste Erfahrung mit Content Creation ist ein Plus, aber kein Muss

## Benefits

- 16 € pro Stunde in einem fairen, planbaren Rahmen

- Rund 10 Stunden pro Woche, Samstag als Wunschtag plus ein Wochentag nach Absprache, flexibel um dein Studium herum

- Viel Raum für eigene Ideen und deine Handschrift im Content

- Ein Team, in dem deine Arbeit sichtbar ist und zählt

Am liebsten mit einem kurzen Video von 30 Sekunden: wer du bist, was du bisher gemacht hast und warum HACOY. Ein Lebenslauf reicht uns auch, das Video macht aber den Unterschied. Wir freuen uns auf dich.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
