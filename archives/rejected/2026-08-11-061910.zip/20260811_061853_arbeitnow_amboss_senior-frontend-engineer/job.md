# Senior Frontend Engineer

Posted: 2026-08-10T17:40:15Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Hi! We are AMBOSS and we are looking for a **Senior Frontend Engineer** to join our Educator Experience team, and shape the future of medical education with us!

**About AMBOSS**

AMBOSS is a dynamic learning and clinical decision support tool committed to empowering physicians globally to deliver optimal care. Since our inception in 2012, we've harnessed cutting-edge technology to transform the way physicians acquire and apply scientific knowledge. Each AMBOSSian is passionate about being the champion of clinicians today - this motivates and unites us each day towards success. And what does success look like? When a clinician or med student tells us, “AMBOSS makes practicing medicine easier and enjoyable. I love what I do, and a big part is because of AMBOSS.”

**Why can this position be exciting for you?**

We are AMBOSS, and we’re looking for a Senior Frontend Engineer in the Educator Experience team. Engineers at AMBOSS are at the forefront of shaping user experience for doctors and students, helping them make critical decisions, ultimately impacting the healthcare of billions of people worldwide. We are looking for someone with a passion for getting the most out of technology and people, setting the pace and direction of excellence for our frontend craft. We work AI-first: agentic tools like Claude Code are part of our daily engineering workflow, and we are looking for someone ready to lead the way in how software gets built in this new era. Join our agile team on a mission to enable institutions (like educational clinics, medical schools) to use AMBOSS resources efficiently and effectively when teaching their learners (e.g. residents and students).**

You will:**

-

Lead frontend engineering projects within our B2B product “Educator Tool”, from conception to completion.

-

Set the bar for best practices in code health, testing, accessibility, and maintainability, and drive their adoption across the team.

-

Champion our AI-first way of working: use agentic tools (like Claude Code) across the development lifecycle, and help the team get more out of them.

-

Collaborate with Product and Design to shape requirements, turning ambiguous ideas into well-scoped technical plans.

-

Address Ad-Hoc requests from customer support channels.

-

Mentor engineers and share your knowledge within the AMBOSS community, contributing to a culture of continuous learning and growth.

**You bring:**

-

Deep hands-on expertise with modern JavaScript, TypeScript, and React, and curiosity about emerging frontend technologies and practices.

-

Proven experience integrating AI coding agents such as Claude Code (or similar) into real production work, and the judgment to know where they excel and where they fail.

-

Experience across the full development lifecycle, from requirements analysis and system design through coding, testing, deployment, and maintenance.

-

Experience working with shared design systems and component libraries, and integrating APIs (GraphQL and/or REST) from the frontend.

-

Deep understanding of accessibility: you treat WCAG guidelines as the baseline, not the ceiling, and advocate for inclusive design in every architectural decision.

-

Performance optimization expertise: bundle sizes, tree-shaking, lazy loading, and how architectural decisions affect performance across devices and network conditions.

-

A testing and quality mindset, with experience in component testing strategies (unit, integration, visual regression) and building maintainable test suites.

-

Excellent verbal and written communication skills in English, able to articulate technical concepts and trade-offs to engineers, designers, and stakeholders.

-

Curiosity, being interested in optimizing processes, learning domain’s ins and outs.

-

Taking initiatives, having analytical mindset, being proactive and solution-oriented.

-

A strong sense of ownership, driving topics end-to-end and mentoring others along the way.

**You enjoy:**

-

**Collaborative deep work.** You thrive in a balance of focused coding time and collaborative design sessions. You're equally comfortable whiteboarding with designers, pair programming with engineers, or diving deep into a complex problem solo.

-

**Teaching and enabling others.** You light up when explaining complex concepts in simple terms, and you enjoy mentoring teammates and sharing knowledge that levels up the whole team.

-

**The details AND the big picture.** You can obsess over the fine details of a user-facing flow one moment and architect a complete feature the next. You find satisfaction in both micro and macro optimizations.

-

**Impact in a meaningful domain.** You're excited that what you build helps medical educators teach more effectively and, ultimately, helps their learners become better clinicians.

-

**Making the complex feel simple.** You take pride in abstractions that hide complexity while remaining flexible. You enjoy the challenge of making powerful tools feel intuitive and approachable.

-

**Systematic thinking with pragmatic execution.** You love creating order from chaos and establishing patterns, but you also know when to ship an 80% solution that delivers value now rather than pursuing perfection.

**Benefits:**

AMBOSSians tell us that innovative work keeps them energized, and employee benefits help them to feel appreciated and empowered. We invest in every AMBOSSians with our employee benefits package, crafted to support financial, physical, and mental health and work-life harmony. Check out all of our employee benefits below:

[https://go.amboss.com/the-amboss-prescription-de](https://go.amboss.com/the-amboss-prescription-de)

We believe that diversity is a powerful driver of innovation and progress. That’s why we are committed to fostering an inclusive, respectful, and supportive environment where everyone—regardless of gender, age, ethnic or cultural background, religion, disability, sexual orientation, gender identity—is valued and given equal opportunity to thrive. We warmly welcome people of all backgrounds to help us fulfil our mission: empowering all medical professionals to provide the best possible care .

Even if you don’t meet every single point in the job description, we still encourage you to apply. We’d love to hear from you!

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
