# Working Student – Quadruped Robot Applications (m/f/d)

Posted: 2026-08-11T02:09:14Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
