# Information Security Lead

Posted: 2026-08-10T17:40:21Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

***Remote (+/- 2hrs from Germany GMT+1). C1 or C2 English is essential***

At Secfix, we’re at the forefront of automating security compliance in Europe. We help companies get and stay ISO 27001, GDPR, TISAX, and SOC 2 fast and easy and reduce hundreds of hours of manual work.

Secfix is run by a 100% remote team with hubs in Munich, Berlin and London. We’re a high-performing team looking for passionate, execution-focused, owners to help us automate security and compliance for modern companies and become the European compliance automation leader.

We’ve just raised our $12M Series A and are backed by top VCs, including Alstin Capital, Neosfer (Commerzbank), and Bayern Capital.

**About the Role**

We're hiring a Senior Information Security Specialist to strengthen our compliance function as Secfix scales into more frameworks, mid-market customers, and a growing compliance team. This role sits at the intersection of compliance delivery, content, and team support. You'll own the compliance knowledge that lives inside our platform, mentor our junior compliance specialists, support our customer success team, and act as the senior compliance voice for customers, auditors, and product. You'll work closely with our co-founder & CISO and our CS Lead. This is a high-impact role with real influence on how Secfix delivers compliance: both as a service to customers and as content inside our app.

**What You'll Do:**

You will own one of the most important pillars of Secfix: **the quality and breadth of our compliance offering**. We don't (and can't afford to) micro-manage. We've built strong foundations and will give you full context on what works. You can test new approaches, but at the end of the day, you have full ownership of how you deliver results (with a strong support network from within and outside the company). You will:

-

Own and drive the compliance roadmap inside the Secfix platform across different compliance frameworks (ISO 27001, TISAX, SOC 2, GDPR, NIS 2, DORA, ISO 27017/27018, ISO 42001, C5, and more as we expand)

-

Implement ISO 27001 and adjacent frameworks end-to-end for customers

-

Mentor and upskill the compliance team: sharing expertise, reviewing work, and helping drive consistency in audits and customer deliverables

-

Conduct internal audits directly for strategic and complex customers, and review the internal audits performed by junior team members to drive quality and consistency

-

Act as a compliance partner to CSMs and sales reps: fast, reliable support for customer questions, and joining customer calls when deep expertise is needed

-

Own the quality of compliance content in the platform (including creating policies, evidence templates, Compliance enable playbooks for our CSMs, security awareness trainings and more)

-

Close framework gaps and incorporate auditor feedback into both team practice and platform improvements

-

Partner with product and engineering to translate compliance gaps into structured product work

-

Collaborate closely with CS, Product, and Founders to align compliance, customer, and roadmap priorities

-

Deepen relationships with our existing certification partners and train auditors on the Secfix platform so they can confidently use it during customer audits

**To be qualified for this role, you must have the following:**

-

English (fluent) is a must for this role

-

7+ years of hands‑on information security and GRC experience in B2B SaaS

-

Led 5+ successful ISO 27001 certification projects as an implementer and/or auditor at a startup or mid-market company

-

2+ years of people/team management experience

-

Hands on experience with a GRC platform like Secfix, or similar GRC platforms

-

Cloud infrastructure readiness across AWS, Azure, and GCP; experience with posture analysis and remediation planning

-

Strong project management skills with the ability to break down ambiguous initiatives into concrete deliverables, prioritizes ruthlessly, and ships

-

Excellent written communication, especially in producing clear, precise compliance content for diverse audiences (auditors, founders, engineers)

-

Strong ownership mindset: operates as a senior individual contributor without waiting for direction

**Bonus:**

-

Experience implementing one or two additional compliance frameworks (e.g. SOC 2, GDPR, NIS 2, etc.)

-

Experience mentoring or coaching colleagues in a compliance, audit, or GRC context

-

Experience in a startup environment is a plus

**What we offer**

-

**Remote Work:** 100% remote work with a virtual office in Gather.

-

**Competitive Salary:** Industry-competitive local salaries. We pay local rates that are at or above the market. We share this philosophy with GitLab.

-

**Equity:** Generous equity package – we’re all owners of Secfix and beneficiaries of our collective success.

-

**Mentorship:** We are backed by top VCs and accelerators and have direct access to world-class mentors.

-

**Development Budget:** €1,000 annual personal development budget.

-

**Home office Budget:** Home office budget and access to co-working spaces.

-

**Holidays:** 26 days holiday + local public holidays.

-

**Health Insurance:** Comprehensive health coverage.

-

**Annual Retreat:** Annual retreat to build connections and inspire ideas (this year we’re headed to Milan!).

-

**Company Events:** Company-wide events to build relationships and have some fun!

-

**Tech Equipment:** Latest tech equipment (MacBook, monitors, headphones).

**Interview Process:**

-

20-30 min - Intro call with Talent team

-

Take-home Assessment

-

1.5hr Assessment review and interview with our CS Lead and CEO

-

45 min - Final Founder Interview with Co-Founders (CTO & CISO)

*Please note: We are an equal-opportunity employer and remote-only company. At this time, we can support hiring only within EU time zones. We work in sync using Gather as our virtual office. As a small fast-growing company, we believe in the need for an in-sync component of daily communication and therefore cannot support 100% asynchronous work. *[*Read more about our Remote Culture here*](https://www.notion.so/Remote-Culture-93bf571583904c5e814b7afd83c240f2?pvs=21)*.*

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
