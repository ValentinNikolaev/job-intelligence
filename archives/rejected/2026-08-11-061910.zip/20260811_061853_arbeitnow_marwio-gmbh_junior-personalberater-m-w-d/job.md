# Junior Personalberater (m/w/d)

Posted: 2026-08-10T17:30:26Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**Dein Karrierestart in einer modernen Personalberatung**

**Du suchst keinen gewöhnlichen Berufseinstieg?**

Du möchtest Verantwortung übernehmen, mit Menschen arbeiten und Dich fachlich wie persönlich schnell weiterentwickeln?

Dann könnte Marwio genau der richtige Ort für Deinen Karrierestart sein.

Wir sind eine spezialisierte Personalberatung und unterstützen Unternehmen aus der Bau- und Engineeringbranche bei der Besetzung anspruchsvoller Fach- und Führungspositionen in ganz Deutschland.

Dabei setzen wir auf moderne Recruitingmethoden, digitale Prozesse und persönliche Beratung.

## Aufgaben

Während Deiner Einarbeitung lernst Du die Personalberatung von Grund auf kennen und entwickelst Dich Schritt für Schritt in Richtung einer eigenverantwortlichen Beraterrolle.

Zu Deinen Aufgaben gehören unter anderem:

Unterstützung unserer Berater in laufenden Recruitingprojekten

- Durchführung von Bewerber- und Kandidateninterviews

- Begleitung von Kandidaten während des gesamten Auswahlprozesses

- Recherche, Ansprache und Vorqualifizierung geeigneter Kandidaten

- Arbeit mit unserem CRM-System sowie strukturierte Nachverfolgung von Prozessen und Wiedervorlagen

- Enge Zusammenarbeit mit der Geschäftsführung und aktive Mitarbeit an anspruchsvollen Suchprojekten

- Kontinuierliche Übernahme weiterer Verantwortung entsprechend Deiner Entwicklung

## Qualifikation

- erfolgreich abgeschlossenes Studium (z. B. BWL, Wirtschaftspsychologie, Wirtschaftsrecht oder vergleichbar)

- Freude am Umgang mit Menschen und ausgeprägte Kommunikationsstärke

- professionelles, sympathisches und verbindliches Auftreten

- sehr gute organisatorische Fähigkeiten und eine strukturierte Arbeitsweise

- Eigeninitiative und Verantwortungsbewusstsein

- Lernbereitschaft sowie Offenheit für Feedback

- Interesse an persönlicher und fachlicher Weiterentwicklung

- sicherer Umgang mit digitalen Anwendungen und neuen Technologien

## Benefits

- strukturierte und persönliche Einarbeitung

- intensives Mentoring durch erfahrene Personalberater

- direkte Zusammenarbeit mit der Geschäftsführung

- früh Verantwortung in echten Recruitingprojekten

- moderne Recruitingmethoden und digitale Arbeitsprozesse

- MacBook und iPhone – auch zur privaten Nutzung

- flexible Arbeitszeiten

- flache Hierarchien und kurze Entscheidungswege

- eine langfristige Entwicklungsperspektive mit wachsender Verantwortung

- attraktive Gehaltsentwicklung entsprechend Deiner persönlichen Entwicklung

- variable Vergütung nach erfolgreicher Einarbeitung

- ein Umfeld, in dem Leistung gesehen, Entwicklung gefördert und Eigeninitiative ausdrücklich gewünscht ist

**Wir suchen keine fertigen Personalberater.**

**Wir suchen Persönlichkeiten mit Potenzial, die wir Schritt für Schritt zu hervorragenden Personalberatern entwickeln.**

Von Anfang an arbeitest Du eng mit der Geschäftsführung zusammen, erhältst Einblicke in echte Recruitingprojekte und übernimmst früh Verantwortung.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
