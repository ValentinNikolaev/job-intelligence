# Senior Software Engineer

Posted: 2026-08-10T17:55:20Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**WHO WE ARE **

Zeta Global (NYSE: ZETA) is the AI-Powered Marketing Cloud that leverages advanced artificial intelligence (AI) and trillions of consumer signals to make it easier for marketers to acquire, grow, and retain customers more efficiently. Through the Zeta Marketing Platform (ZMP), our vision is to make sophisticated marketing simple by unifying identity, intelligence, and omnichannel activation into a single platform – powered by one of the industry’s largest proprietary databases and AI. Our enterprise customers across multiple verticals are empowered to personalize experiences with consumers at an individual level across every channel, delivering better results for marketing programs. Zeta was founded in 2007 by David A. Steinberg and John Sculley and is headquartered in New York City with offices around the world. To learn more, go to [www.zetaglobal.com](https://www.zetaglobal.com).

**The Role**

As a Senior Software Engineer you will provide technical leadership to the group responsible for architecting, developing, and owning Addressability part of the Zeta Marketing Platform. You will collaborate with Engineers, Product Managers and Executives across the organization to develop a roadmap and subsequent projects to build the next generation comprehensive, multichannel marketing solution that unifies and unlocks data across digital touch points, driving return on marketing investment.

This position will be responsible for the design and development of realtime systems of The Zeta Marketing Platform and LiveIntent, working on technology that enables access to core of Identity Solutions. You will mentor an organization of developers through your knowledge sharing sessions that will guide and strengthen their knowledge.
You should have a deep knowledge of distributed systems and cloud architecture. You will need extensive design and development experience and passion about working with large amounts of data and designing reliable low-latency data processing systems.

This is a hybrid role based out of our Berlin, Germany office

**Essential Responsibilities:**

As a Senior Software Engineer, your responsibilities will include:

- Building, refining, tuning, and maintaining our real-time infrastructure

- Designing, developing and maintaining services responsible for data collection and real-time data processing

- Working with Product Managers to design and build data products

- Working with our DevOps team to scale and optimize our infrastructure

- Participate in architecture discussions, influence the road map, take ownership and responsibility over new projects

- Participating in on-call rotation (be available by phone or email in case something goes wrong)

**Desired Characteristics:**

- Minimum 4 years of software engineering experience.

- An undergraduate degree in Computer Science (or a related field) from a university where the primary language of instruction is English is strongly desired.

- 2+ Years of Experience/Fluency in Scala/Java

- Proficient with both relational and NoSQL databases

- Experience working with container-based solutions is a plus.

- Experience in adequate usage of libraries such as ZIO, Akka, Play Framework is a plus

- Experience in adequate usage of cloud services (AWS) at scale

- Experience in adequate usage of Terraform

- Proven long term experience and enthusiasm for distributed data processing at scale, eagerness to learn new things.

- Expertise in designing and architecting distributed low latency and scalable solutions in cloud.

- Exposure to the whole software development lifecycle from inception to production and monitoring.

- Experience in Advertising Attribution domain is a plus

- Experience in agile software development processes

- Excellent interpersonal and communication skills

**BENEFITS & PERKS**

- Excellent medical, dental, and vision coverage

**PEOPLE & CULTURE AT ZETA**

Zeta considers applicants for employment without regard to, and does not discriminate on the basis of an individual’s sex, race, color, religion, age, disability, status as a veteran, or national or ethnic origin; nor does Zeta discriminate on the basis of sexual orientation, gender identity or expression.

We’re committed to building a workplace culture of trust and belonging, so everyone feels invited to bring their whole selves to work. We provide a forum for employees to celebrate, support and advocate for one another. Learn more about our commitment to diversity, equity and inclusion here: [https://zetaglobal.com/blog/a-look-into-zetas-ergs/](https://zetaglobal.com/blog/a-look-into-zetas-ergs/)

**ZETA IN THE NEWS!**

[https://zetaglobal.com/press/?cat=press-releases](https://zetaglobal.com/press/?cat=press-releases)

#LI-NP1

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
