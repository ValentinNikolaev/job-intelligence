# Werkstudent (m/w/d) Personal & Recruiting – 12105 Berlin

Posted: 2026-09-15T07:20:10Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Sie studieren und möchten parallel praktische Erfahrung im **Personalwesen, Recruiting und in der Einsatzplanung** sammeln? Für unseren Standort in **12105 Berlin** suchen wir einen engagierten **Werkstudenten (m/w/d)**, der unser Team im operativen Tagesgeschäft unterstützt. Sie begleiten Bewerbungsprozesse, helfen bei der Disposition von Mitarbeitenden und erhalten einen direkten Einblick in die Personalorganisation eines bundesweit tätigen Sicherheitsunternehmens. Die Position richtet sich an Studierende **ab dem 3. Semester**, die Theorie und Praxis sinnvoll miteinander verbinden möchten.

#### **Ihre Benefits:
**

-

Flexible Arbeitszeiten

-

Eigenständige Aufgaben nach erfolgreicher Einarbeitung

-

Individuelle Weiterbildungs- und Entwicklungsmöglichkeiten

-

Kostenfreier Parkplatz am Standort

-

Kantine eines externen Anbieters fußläufig erreichbar

-

Betriebliche Altersvorsorge

-

**Corporate Benefits & [benefits.me](http://benefits.me)**

#### **Ihre Aufgaben:
**

-

Unterstützung bei der Disposition und Einsatzplanung unserer Mitarbeitenden

-

Mitarbeit bei der Besetzung offener Dienste und Einsatzstellen

-

Unterstützung im gesamten Recruitingprozess

-

Kommunikation mit Bewerbern sowie Koordination von Vorstellungsgesprächen

-

Unterstützung bei der Vorbereitung und Durchführung von Interviews

-

Betreuung und Kommunikation mit Mitarbeitenden im operativen Tagesgeschäft

-

Unterstützung bei Kundenanfragen und organisatorischen Abstimmungen

-

Pflege und Aktualisierung personalrelevanter Daten und Unterlagen

-

Unterstützung bei administrativen Aufgaben im Personalbereich

-

Mitarbeit an einem reibungslosen Informationsfluss zwischen Personal, Disposition und operativen Bereichen

#### **Ihr Profil:**

-

Laufendes Studium, beispielsweise in **BWL, Personalmanagement, Sicherheitsmanagement, Vertrieb, Marketing** oder einem vergleichbaren Studiengang

-

Studium **ab dem 3. Semester**

-

Interesse an Personal, Recruiting und operativen Unternehmensabläufen

-

Sehr gute Deutschkenntnisse in Wort und Schrift, mindestens **C1**

-

Gute Englischkenntnisse

-

Kommunikationsstärke und Freude am Umgang mit Menschen

-

Strukturierte, sorgfältige und zuverlässige Arbeitsweise

-

Organisationstalent und die Fähigkeit, auch bei mehreren Aufgaben den Überblick zu behalten

-

Sicherer Umgang mit MS Office

-

Eigeninitiative und Bereitschaft, sich aktiv in das Tagesgeschäft einzubringen

**Ihr Ansprechpartner:**

Sicherheit Nord GmbH & Co. KG
Herr Yannick Baumhauer
Ringstraße 44/45
12105 Berlin

**Jetzt bewerben!**

Sie möchten neben Ihrem Studium praktische Erfahrung im **Personalbereich, Recruiting und in der Disposition** sammeln?

Dann bewerben Sie sich jetzt schnell und unkompliziert.

Kein Anschreiben erforderlich – Ihr aktueller Lebenslauf genügt.

Wir freuen uns darauf, Sie kennenzulernen.

**Hinweis zur Sprache und Vielfalt:**

Wir freuen uns über Bewerbungen aller Menschen – unabhängig von Geschlecht, Herkunft, Religion, Behinderung, Alter oder sexueller Identität. Aus Gründen der besseren Lesbarkeit verwenden wir verkürzte Sprachformen; diese beziehen sich immer auf alle Geschlechter (m/w/d).

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
