# Sales Trainee (m/w/d)

Posted: 2026-09-15T08:00:35Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Die KplusA Communications GmbH ist eine spezialisierte Eventagentur mit Sitz in Düsseldorf. Wir vereinen Konzeption, Eventstrategie, Eventmarketing und Eventmanagement unter einem Dach. Seit 2021 haben wir über 500 Veranstaltungen umgesetzt, für Konzerne wie Mercedes-Benz, Transfermarkt und Vinted, für Softwareunternehmen wie LeadTable und für Personal Brands wie den Ex-CEO Dr. Michael Stoermer.

Unser Ansatz ist klar: Ein Event ist ein strategisches Vertriebsinstrument mit messbarem ROI. Genauso arbeiten wir intern. Wir verkaufen mit System, nicht mit Bauchgefühl. Unsere Vertriebsmethodik basiert auf TÜV-zertifizierter Verkaufspsychologie.

## Aufgaben

Du bist die erste Anlaufstelle, wenn ein neuer Interessent auf uns zukommt. Du qualifizierst, berätst und begleitest ihn bis zum Vertrag. Du arbeitest mit vorbereiteten Leitfäden, definierten Prozessen und einem sauber geführten CRM.

Die telefonische Vorbereitung und Beratung unserer Interessenten

- Kundenakquise und Kundenbetreuung entlang eines definierten Vertriebsprozesses

- Telefonische Vorbereitung und Beratung unserer Interessenten

- Erstellung von Angeboten und VerträgenMarktanalysen und Wettbewerbsbeobachtung als Grundlage für unsere Positionierung

- Organisation und Koordination der Vertriebsaktivitäten

- Pflege und Aktualisierung des CRM, inklusive Dokumentation aller Kontaktpunkte

- Gelegentlicher Besuch von Messen und Seminaren zur Neukundenakquise

## Qualifikation

- Du arbeitest strukturiert und verbindlich. Zusagen hältst Du ein, Termine dokumentierst Du, Wiedervorlagen verfallen bei Dir nicht.

- Du bist redegewandt und vorbereitet. Du gehst nicht unvorbereitet in ein Gespräch und überzeugst über Klarheit und Sachverstand.

- Du denkst in Zahlen. Du misst Deine eigenen Ergebnisse und leitest daraus Deine nächsten Schritte ab.

- Du willst Dich langfristig im Vertrieb entwickeln. Kurzfristige Zwischenstationen passen nicht zu dieser Rolle.

- Du bist genau. Angebote, Verträge und CRM-Daten sind bei Dir fehlerfrei.

Erfahrung im B2B-Vertrieb, im Eventumfeld oder in der Beratung ist ein Vorteil. Verpflichtend ist sie nicht.

## Benefits

- Sicherer Arbeitsplatz: Jede Einstellung ist auf langfristiges Wachstum ausgelegt. Das Ziel ist die unbefristete Übernahme.

- Internes Gesundheitssystem: Über 300 Gesundheitsleistungen, 600 € Gesundheitsbudget pro Jahr, kostenlose Massagen, Facharzttermine innerhalb von 5 bis 10 Werktagen.

- Firmen-Rabatte und VIP-Status: Exklusive Sonderkonditionen bei über 500 Online-Shops und Fitnessstudios in ganz Deutschland.

- Ausführliche interne Schulungen: Einarbeitung über unsere interne Schulungsplattform, mit Rollenspielen und begleitetem Training am Telefon.

- Reale Aufstiegsmöglichkeiten: Wir wachsen. Bei entsprechender Leistung ist der interne Aufstieg vorgezeichnet.

- Kollegiale Arbeitsatmosphäre: Ein eingespieltes Team, kurze Wege, offene Kommunikation.

- Gute Erreichbarkeit: Büroräume im Herzen von Düsseldorf Benrath, mit direkter Anbindung an Autobahn und ÖPNV.

Trage im Feld **„Möchtest Du noch etwas ergänzen“** die Wörter **„Vertrieb ist super“** ein. Damit zeigst Du, dass Du die Anzeige vollständig gelesen hast. Wir erhalten eine große Anzahl an Bewerbungen und können Zuschriften ohne diesen Hinweis nicht berücksichtigen.

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
