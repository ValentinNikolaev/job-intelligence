# Leitung Labor (m/w/d)

Posted: 2026-09-15T08:00:36Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**Wir. Ökologisch, wirtschaftlich, sozial.**

Künftigen Generationen eine bessere Welt zu hinterlassen, ist wahrscheinlich die größte Herausforderung unserer Zeit. Es geht dabei um die Umwelt und den Klimaschutz, soziale Verantwortung und die Art und Weise, wie wir als Unternehmen agieren. Neue Ideen sind gefragt, aber auch Entschlossenheit, Integrität und Mut, um die notwendigen Veränderungen voranzutreiben.

Als international agierender Hersteller eines Produkts mit Jahrhunderte alter Kulturgeschichte sind wir uns bei der Deutsche Steinzeug Solar Ceramics GmbH einig, dass die Zukunft der Architektur und des Bauwesens nicht an den Toren zu unseren Fliesenwerken endet, sondern mit unserer Verantwortung beginnt. Fairer Umgang mit Partnern und wertschätzendes Miteinander sind daher nicht erst seit heute Treiber für die besondere Qualität und Innovationskraft unseres Unternehmens.

## Aufgaben

- Fachliche und personelle Führung des keramischen/chemischen Labors

- Sicherstellung der effizienten Durchführung von Analysen

- Berücksichtigung rechtlicher und sicherheitstechnischer Aspekte sowie interner Vorgaben

- Verantwortlich für die Qualitätssicherung ISO 9001

- Schnittstelle zu internen und externen Ansprechpartnern

- Erstellung von Untersuchungsberichten und Expertisen

- Ansprechpartner für die Labormitarbeiter bei FachfragenPersonalverantwortung für die Mitarbeiter

## Qualifikation

- Ingenieur der Fachrichtung Keramik alternativ Werkstofftechnik/Technische Chemie

- Berufserfahrung in einem Analyselabor vorzugsweise im Bereich Keramik

- Führungspraxis

- Sicheres Auftreten und Teamfähigkeit

- Hohes Durchsetzungs- und Kommunikationsvermögen

- Versiert im Umgang mit MS-Office und SAP R/3

- Englischkenntnisse in Wort und Schrift

- Durchsetzungsvermögen, Kommunikations- sowie Teamfähigkeit runden ihr Qualifikationsprofil ab

## Benefits

- Arbeiten im Traditionsunternehmen

- Abwechslungsreiche, Interessante Aufgaben

- Attraktive Vergütung

- Partnerschaftliches Arbeiten im Team

- Abwechslungsreiche, interessante Aufgaben

- Mitarbeiterbenefits

Wir freuen uns sehr auf eine aussagekräftige Bewerbung von Ihnen.

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
