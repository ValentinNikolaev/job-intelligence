# Junior Retail Merchandising Manager (f/m/d)

Posted: 2026-09-15T09:00:32Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**Wer sind wir?**

Wir sind ein vielfältiges Team von Schönheitsenthusiasten aus der ganzen Welt, die sich für ein integratives und unterstützendes Arbeitsumfeld einsetzen, in dem sich jeder wertgeschätzt und respektiert fühlt.

Als führende internationale Schönheitsmarke haben wir uns zum Ziel gesetzt, qualitativ hochwertige Produkte anzubieten, die den Menschen helfen, ihren einzigartigen Sinn für Stil zu stärken. Unser innovativer und dynamischer Ansatz hat uns zur ersten Wahl für Schönheitssalons und Geschäfte weltweit gemacht. Bei uns dreht sich alles um Kreativität und individuelles Wachstum. Wir ermutigen unsere Teammitglieder, mutig zu sein und über den Tellerrand hinauszuschauen.

Als **Junior Retail Merchandising Manager (f/m/d)** koordinierst du die operative Umsetzung unserer stationären Markenpräsenz – von Store Openings und Rollouts über saisonale Updates bis hin zur Instandhaltung unserer Retail-Möbel und Displays.

Du verantwortest die Bedarfsplanung und Bestandssteuerung sowie die Beschaffungskoordination von Retail-Möbeln, Inserts, Displays und Ersatzteilen.

In enger Zusammenarbeit mit **Visual Merchandising, Retail Marketing, Category Management, unseren Handelspartnern sowie externen Dienstleistern und Lieferanten** stellst du sicher, dass freigegebene Konzepte und Planogramme an allen POS einheitlich, termingerecht und innerhalb des vorgesehenen Budgets umgesetzt werden.

## Tasks

- Du koordinierst **externe Agenturen, Dienstleister und Lieferanten** bei der Produktion, Installation und Instandhaltung von Retail-Möbeln und Displays.

- Du verantwortest die **Bestands- und Bedarfsplanung** und stellst die Verfügbarkeit von Möbeln, Inserts, Display-Komponenten und Ersatzteilen sicher.

- Du koordinierst die **Beschaffung von Merchandising-Dienstleistungen, Retail-Möbeln und zugehörigen Komponenten**.

- Du planst und koordinierst **Store Openings, Re-Openings, Schließungen sowie saisonale POS-Updates**.Gemeinsam mit Retail Marketing und Category Management setzt du **freigegebene Planogramme und Merchandising-Konzepte** um.

- Du koordinierst **großflächige Rollouts** – von der Mengenplanung und Bestellung bis hin zu Lieferung und Installation.

- Du steuerst die operative Kommunikation mit unseren **Handelspartnern** rund um Installationen, Austauschmaßnahmen und Merchandising-Anforderungen.

- Du koordinierst die **Produktion und Umsetzung neuer Retail-Möbel und Fixtures** auf Basis freigegebener Konzepte und Spezifikationen.

- Du steuerst **Updates, Reparaturen und den Austausch bestehender Retail-Möbel** und behältst dabei stets die Kosteneffizienz im Blick.

- Du behältst **Projektzeitpläne, Budgets, Bestellmengen und Lieferstatus** im Blick und sorgst für einen reibungslosen Ablauf.

- Du stellst eine **konsistente und präzise Umsetzung unserer Marke** an allen Retail-Standorten sicher.

## Requirements

- Du hast eine **abgeschlossene kaufmännische Ausbildung oder ein Studium** – idealerweise mit Bezug zu Handel, Retail Management, Projektmanagement oder einem vergleichbaren Bereich.

- Du bringst **mindestens 2 Jahre Berufserfahrung im Retail Merchandising, POS Management, Retail Operations oder in einer vergleichbaren koordinativen Funktion** mit.

- Du hast Erfahrung in der **Koordination operativer Retail-Projekte**, beispielsweise Rollouts, Store Openings, POS-Updates oder der Umsetzung von Retail-Möbeln und Displays.

- Du arbeitest **strukturiert und organisiert** und behältst auch bei mehreren parallel laufenden Projekten Timings, Mengen, Budgets und Deliverables zuverlässig im Blick.

- Du hast idealerweise Erfahrung in der **Steuerung externer Lieferanten, Agenturen oder Dienstleister** sowie in der Koordination von Bestellungen, Produktionen, Lieferungen oder Installationen.

- Du fühlst dich sicher im Umgang mit **Zahlen, Beständen und Bedarfsplanungen** und kannst operative Anforderungen in konkrete Mengen und nächste Schritte übersetzen.

- Du kennst die grundlegenden Prinzipien von **Planogrammen und POS-Merchandising** und kannst freigegebene Konzepte und Vorgaben zuverlässig in die operative Umsetzung bringen.

- Du bist ein:e **proaktive:r und lösungsorientierte:r Kommunikator:in** und kannst unterschiedliche interne und externe Stakeholder souverän koordinieren.

- Du arbeitest gerne **hands-on**, übernimmst Verantwortung und findest auch bei kurzfristigen Änderungen oder operativen Herausforderungen pragmatische Lösungen.

- Du kommunizierst **fließend auf Deutsch und Englisch** und fühlst dich in einem internationalen, cross-funktionalen Arbeitsumfeld wohl.

## Benefits

- **Flexibles Hybrid-Modell:** Die Möglichkeit, Büroarbeit und Home Office flexibel miteinander zu kombinieren.

- **Mobilität & Lifestyle:** Wähle zwischen einem Zuschuss zum öffentlichen Nahverkehr oder einer Edenred-Sachbezugslösung / Urban Sports Club.

- **Beauty Benefits:** Mitarbeiterrabatte auf unsere Produkte und die Möglichkeit, unsere neuesten Beauty-Produkte selbst kennenzulernen und zu testen.

- **Gemeinsam statt nur arbeiten:** Regelmäßige Firmen- und Teamevents sowie ein internationales Arbeitsumfeld.

- **Mitgestalten & Verantwortung übernehmen:** Kurze Entscheidungswege, viel Eigenverantwortung und die Möglichkeit, die Weiterentwicklung unserer Marken aktiv mitzugestalten.

- **Arbeiten im Herzen Berlins:** Modernes Office in zentraler Lage mit sehr guter Verkehrsanbindung.

- **Mitarbeiter-werben-Mitarbeiter-Programm:** Empfehlungsbonus für erfolgreiche Mitarbeiterempfehlungen.

Bereit, das Einkaufserlebnis am POS mitzugestalten und die Präsenz unserer Marke im Handel weiter voranzutreiben? Dann bewirb dich jetzt und werde Teil unserer Erfolgsgeschichte!

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
