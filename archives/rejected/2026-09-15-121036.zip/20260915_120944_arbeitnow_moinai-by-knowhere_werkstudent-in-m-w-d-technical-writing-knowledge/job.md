# Werkstudent:in (m/w/d) Technical Writing & Knowledge Management - SaaS & Conversational AI

Posted: 2026-09-15T08:30:32Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

- Start: Okt./Nov. 2026

- Ort: Hamburg oder Remote (DACH)

**

Über moinAI**

Wir sind eine führende Conversational-AI-Plattform, mit der Unternehmen ihren Kundenservice und Vertrieb KI-basiert automatisieren. Unsere intelligenten Chatbots beantworten Anfragen in Echtzeit, qualifizieren Leads und integrieren sich nahtlos in bestehende Tech-Stacks. Unser Ziel: Herausragende KI-gestützte Kundenerlebnisse, mehr Umsatz und messbare Skalierung.

**Warum du bei uns starten solltest**

Du willst nicht irgendwelche Texte schreiben, die niemand liest, sondern die Stimme eines KI-Produkts mitprägen, das täglich tausende Kundendialoge automatisiert? Bei moinAI arbeitest du von Tag eins an der Schnittstelle zwischen Produkt, Customer Success und unseren Kund:innen – und dein Wissen landet direkt bei den Menschen, die unsere Plattform täglich nutzen.

- **Direkter Impact:** Deine Artikel sind Teil des Produkterlebnisses. An Artikel-Ratings, Suchverhalten und sinkenden Ticketzahlen siehst du schwarz auf weiß, was deine Arbeit bewirkt.

- **Echte Verantwortung:** Du bekommst dein eigenes Themengebiet, arbeitest eng mit Product und Engineering und bringst deine Ideen direkt ins Produktteam zurück.

- **Arbeiten mit Agentic AI:** Für unsere Dokumentation nutzen wir agentische KI-Workflows, die Inhalte vorbereiten, übersetzen und aktuell halten. Du lernst aus erster Hand, wie man solche Content-Prozesse aufsetzt und wo es trotzdem dein Urteil braucht.

- **Lernen an einem Produkt, das sich rasant weiterentwickelt:** Du verstehst Conversational AI, LLMs und APIs, weil du sie erklärst. Neue Modelle und Features bekommst du mit, während sie bei uns entstehen. Ein strukturiertes Onboarding und ein Learning-Budget bringen dich zusätzlich aufs nächste Level.

- **Flexibilität, die zum Studium passt:** Du entscheidest, wo und wann du arbeitest. Rund um Vorlesungen, Prüfungen und Semesterferien finden wir gemeinsam einen Rhythmus, der funktioniert.

## Aufgaben

**Dokumentation & Storytelling**

Du tauchst tief in moinAI ein, begleitest Produktreleases und Features und übersetzt sie in klare, hilfreiche Help-Center-Artikel und kurze How-to-Guides.

**Content-Creation für alle Kanäle**

Du verfasst und pflegst Dokumentationsinhalte in Deutsch und Englisch: Help Center, In-App-Guides und Microcopy.

**Arbeiten mit Agentic AI**

Du nutzt agentische KI-Workflows, um Inhalte zu entwerfen, zu übersetzen und aktuell zu halten, und entwickelst diese Workflows gemeinsam mit uns weiter.

**Pflege unseres eigenen Support-Chatbots**

Du hältst die Wissensbasis unseres moinAI-Chatbots auf dem neuesten Stand, prüfst seine Antworten und entwickelst ihn Schritt für Schritt weiter.

**Knowledge Management & Qualität**

Du entwickelst unser Help Center als zentrale Wissensdatenbank konzeptionell weiter: Struktur, Kategorien und Navigation. Du sammelst Input aus Product, Customer Success und Development, strukturierst das Wissen und stellst sicher, dass es für unsere Nutzer:innen schnell auffindbar ist. Dabei entwickelst du unsere Terminologie, Tonalität und Formatierungsrichtlinien weiter und achtest darauf, dass sie eingehalten werden.

## Qualifikation

- Laufendes Studium – idealerweise Technische Redaktion, Sprach-/Kommunikationswissenschaft, (Wirtschafts-)Informatik oder vergleichbar

- Ausgezeichnete Deutschkenntnisse (Muttersprache) und sehr gutes Englisch (B2)

- Du erklärst komplexe Sachverhalte präzise, zielgruppengerecht und gerne – Schreib-Flow gehört für dich einfach dazu

- Große Neugier auf SaaS-Produkte, B2B-Software und Conversational AI; erste Erfahrung mit Markdown, HTML, Git oder Agentic AI (z. B. Claude) ist ein Plus

- Erfahrung mit Doku-/CMS-Tools (z. B. Zendesk Guide, Notion, Confluence) oder Grafiktools (Figma, Snagit) sind nice-to-have

- Strukturierte Arbeitsweise, Eigeninitiative und Lust, Verantwortung zu übernehmen

## Benefits

- Hands-on-Einblicke in ein schnell wachsendes AI-SaaS-Unternehmen.

- Flexibles Arbeiten – Du entscheidest, wo und wann du arbeiten möchtest. Unser schönes und modernes Karoviertel-Office ist jederzeit offen.

- Gute Arbeitsatmosphäre ohne Chaos: agil, kollegial, datengetrieben.

- Vergütung 15 €/Std., modernes MacBook, Learning-Budget, natürlich unsere legendären Team-Events & mehr

Schick Ole deinen Lebenslauf plus ein kurzes Motivationsschreiben (max. 150 Wörter). Statt eines klassischen Anschreibens interessiert uns, warum du für großartige Dokumentation brennst und wie du komplexe Features in einfache Worte packst. Gerne kannst du 1–2 Schreibproben oder Links zu bisherigen Doku-Projekten beifügen – ist aber kein Muss.

Wir freuen uns darauf, dich kennenzulernen! 🚀

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
