# Lead Generation Manager (m/w/d)

Posted: 2026-09-15T09:00:33Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**Über adlicious**

adlicious ist einer der führenden Advertising Solutions Provider im schönen Hamburg und unsere Mission ist es, die besten Werbekampagnen für unsere Kunden zu kreieren, indem wir Media, Creative & Tech miteinander vereinen. Mit unserer einzigartigen Ad Delivery Technologie unterstützen wir führende Marken dabei, ihre Botschaft in Echtzeit über die gesamte digitale Customer Journey personalisiert an ihre Zielgruppen auszuliefern. Dafür brauchen wir talentierte Individuen aus unterschiedlichen Bereichen, die gemeinsam Synergien schaffen. Momentan sind wir ca. 90 Mitarbeitende, Tendenz steigend - was uns noch fehlt, bist DU!

## Aufgaben

**Identifikation & Qualifizierung neuer Geschäftsmöglichkeiten:**

- Du recherchierst potenzielle Neukunden, analysierst Zielmärkte und identifizierst vielversprechende Leads. Durch eine strukturierte Qualifizierung legst du die Grundlage für erfolgreiche Vertriebsgespräche.

**Wettbewerbs- & Marktanalyse:**

- Du analysierst Mitbewerber, um sicherzustellen, dass unsere Agentur einen Wettbewerbsvorteil behält.

**Unterstützung im Vertrieb & Projektarbeit:**

- Du arbeitest an zusätzlichen Aufgaben und Projekten im Vertrieb, um zum Erfolg des Teams beizutragen.

**CRM-Pflege & Datenmanagement:**

- Du aktualisierst und pflegst CRM-Daten, um die Effizienz des Vertriebsteams zu unterstützen.

**Ideenentwicklung & Business Development:**

- Du steuerst kreative Ideen bei, um unsere Business-Development-Projekte zu bereichern und voranzutreiben.

## Qualifikation

**Vertriebserfahrung & Kaltakquise-Erfolge:**

- Nachgewiesene Erfahrung im Vertrieb, insbesondere mit Erfolgen bei der Kaltakquise.

**Branchenerfahrung (Werbung / Einzelhandel):**

- Bevorzugter Hintergrund in der Arbeit mit der Werbe- und / oder Einzelhandelsbranche.

**Analytische Recherchekompetenz:**

- Fähigkeit zur Durchführung gründlicher und strukturierter Recherchen.

**Hohe Eigenmotivation & Zielorientierung:**

- Eigenmotivation mit einem wettbewerbsorientierten Geist, um Ziele zu erreichen und sogar zu übertreffen. Dabei lässt du dich auch von Rückschlägen und Absagen nicht aufhalten – du bleibst dran und behältst deine Ziele im Blick.

**Sprachliche Kompetenz**:

- Ausgezeichnete Deutschkenntnisse in Wort und Schrift.

**Corporate-Culture-Fit:**

- Um gut zu uns zu passen, solltest du Verantwortung proaktiv übernehmen, nach Exzellenz streben, innovativ denken, Spaß an der Arbeit haben, Teamarbeit schätzen und ein respektvolles Umfeld fördern.

## Benefits

- Abwechslungsreiche Tätigkeit in einem jungen und dynamischen Team

- Übernahme der ÖPNV-Kosten

- JobRad

- Möglichkeiten zur eigenen Entwicklung (interne und externe Weiterbildungen)

- Möglichkeit zu Mobile-Office und Workation

- Modernste Arbeitsausstattung mit der Auswahl zwischen MacBook Pro oder Lenovo Thinkpad als Laptop inkl. Noise-Cancelling-Kopfhörer

- Ergonomische Arbeitsplätze

- Sprachkurse (egal ob Fremdsprache oder Deutsch)

- Viele Teamevents und Barabende in unserer Office-Bar mit leckeren Cocktails

- Firmeneigenes Fitnessstudio mit Cross-Training, Bodybuidling, Cardio, HIIT und Online Workouts

- Office Dogs :)

Haben wir dein Interesse geweckt? Dann freuen wir uns auf deine Bewerbung.

Besuch gerne unseren TikTok, Instagram oder Facebook Account um mehr über uns zu erfahren.

Wir freuen uns auf Dich!

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
