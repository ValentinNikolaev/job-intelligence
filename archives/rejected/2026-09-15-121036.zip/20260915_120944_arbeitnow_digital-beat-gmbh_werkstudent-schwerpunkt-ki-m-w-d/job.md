# Werkstudent Schwerpunkt KI (m/w/d)

Posted: 2026-09-15T09:20:10Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**Wir sind Digital Beat**, wir gestalten Wissensaustausch im Bereich Künstliche Intelligenz. An unserem Standort in Köln unterstützen 20 Mitarbeiter:innen andere Menschen und deren Unternehmen bei ihrer Weiterentwicklung durch Onlinekurse, Coachings, digitale Events und Bücher. Nach unserem Grundsatz „Besser mit KI“ entwickeln wir bestehende Produkte weiter und bringen neue, innovative Angebote mit Schwerpunkt KI auf den Markt. Gleichzeitig optimieren wir unsere internen Arbeitsprozesse nach unserem #KIfirst Prinzip.

Du beschäftigst dich mit KI nicht nur, weil gerade alle darüber reden, sondern weil du wissen willst, was damit wirklich möglich ist?

Du testest neue Tools, baust eigene Automationen, probierst AI Agents aus und fragst dich regelmäßig, welche Prozesse man mit KI eigentlich längst besser lösen könnte? Dann könnte das hier ziemlich gut passen:

Wir suchen einen **Werkstudenten (m/w/d) im Bereich AI & Automation**, der unser Produktmanagement Team unterstützt und gemeinsam mit uns daran arbeitet, KI sinnvoll in unseren Produkten, Prozessen und entlang der gesamten Customer Journey einzusetzen.

**Dein Aufgabenbereich:**

Bei uns bekommst du keine theoretische KI Spielwiese. Du arbeitest gemeinsam mit unserem Produktmanagement an konkreten Projekten und bringst neue Technologien direkt in die Anwendung.

Du wirst unter anderem:

-

AI Agents und automatisierte Workflows konzipieren, testen und weiterentwickeln

-

eigenständig neue KI Tools und Technologien recherchieren, ausprobieren und bewerten und herausfinden, was davon für uns und unsere Kunden wirklich relevant ist

-

im direkten Austausch mit unseren KI Lehrgangskunden stehen, ihre Fragen und Herausforderungen verstehen und ihre Erkenntnisse und Bedürfnisse in die Weiterentwicklung unserer Produkte einbringen

-

unsere internen Prozesse und die gesamte Customer Journey analysieren und konkrete Möglichkeiten identifizieren, wie wir sie mit KI besser, schneller und skalierbarer gestalten können

-

unser Produktmanagement bei der Weiterentwicklung unserer Lehrgänge und Lerninhalte unterstützen und neue Themen, Tools und Entwicklungen aus der KI Welt einbringen

-

neue AI Use Cases entwickeln, praktisch testen und so aufbereiten, dass daraus konkrete Anwendungen und Best Practices für unsere Teilnehmer und Kunden entstehen

-

eigene Ideen und Projekte einbringen und bei geeigneten Themen selbst Verantwortung für die Umsetzung übernehmen

-

bei passenden Themen auch vor der Kamera stehen und Tools, Workflows oder AI Use Cases verständlich erklären und demonstrieren

Du passt gut zu uns, wenn du:

-

derzeit ein Studium absolvierst, zum Beispiel in Informatik, Wirtschaftsinformatik, Künstlicher Intelligenz, Data Science, BWL, Wirtschaftswissenschaften oder einem vergleichbaren Studiengang

-

bereits erste Berührungspunkte mit Künstlicher Intelligenz, Automatisierung oder digitalen Technologien hast, entweder durch dein Studium, eigene Projekte oder weil du dich selbst intensiv mit diesen Themen beschäftigst

-

dich aktiv mit dem aktuellen KI Tool Ökosystem beschäftigst und Tools wie Claude, Perplexity, Cursor oder vergleichbare Anwendungen bereits für eigene Projekte, Workflows oder konkrete Anwendungsfälle eingesetzt hast

-

dich für AI Agents, Automatisierungen und intelligente Workflows begeisterst und Lust hast, eigene Lösungen zu entwickeln und umzusetzen

-

ein gutes technisches Verständnis mitbringst und Cloud Anwendungen, APIs und digitale Tools für dich keine Fremdwörter sind

-

die Entwicklungen rund um KI aktiv verfolgst und beispielsweise über LinkedIn, Fachmedien oder andere relevante Quellen mitbekommst, welche neuen Tools, Modelle und Anwendungsfälle entstehen

-

dich schnell und eigenständig in neue Tools, Technologien und Themengebiete einarbeiten kannst

-

analytisch denkst, strukturiert arbeitest und gleichzeitig einen ausgeprägten Hands on Ansatz mitbringst

-

gerne mit Kunden kommunizierst und komplexe oder technische Sachverhalte verständlich und lösungsorientiert vermitteln kannst

-

sehr gute Deutschkenntnisse in Wort und Schrift mitbringst

### Von Vorteil, aber kein Muss

-

erste praktische Erfahrungen mit Automatisierungstools, Workflow Plattformen, APIs oder AI Agents

-

eigene Projekte oder Experimente im Bereich KI und Automatisierung

-

erste Erfahrungen in der Erstellung von Content oder Lerninhalten

-

erste Erfahrungen vor der Kamera und Freude daran, Tools, Workflows und KI Anwendungsfälle verständlich zu erklären

#### **Wir bieten dir:**

-

Flache Hierarchien sowie ein junges, smartes und hochgradig motiviertes Team

-

Flexible Arbeitszeiten sowie Homeoffice-Optionen

-

Kostenlose M-Mitgliedschaft des Urban Sports Clubs (Zugang zu über 400 Fitnessstudios und Sportangeboten in Köln und Umgebung)

-

Regelmäßiges persönliches Feedback und Weiterbildungsmöglichkeiten

-

Free drinks, Snacks sowie spannende Battles am Tischkicker, beim Tischtennis oder an der Dartscheibe

-

Auf Wunsch bieten wir dir ein Bahn-/Jobticket

-

Egal ob bei Teamevents, Sommerpartys, Weihnachtsfeiern oder bei unserer jährlichen Teamfahrt - wir feiern Erfolge gemeinsam

**
**

**Haben wir dein Interesse geweckt?**
Dann freuen wir uns auf deine vollständige Bewerbung über unser Bewerbungsportal.

Digital Beat GmbH, Hansaring 97, 50670 Köln
Deine Ansprechpartnerin: Miriam Fretwurst
Weitere Infos findest du unter [www.digitalbeat.de/karriere/](http://www.digitalbeat.de/karriere/)

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
