# Business Process Owner - Global Learning Management Systems (all genders)

Posted: 2026-09-15T08:00:34Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Zusammen mit der Adolf Würth GmbH & Co. KG suchen wir für den Bereich HR Digital Solutions & Processes eine/n Business Process Owner - Global Learning Management Systems (all genders), um die digitale Lernsystemlandschaft international weiterzuentwickeln und strategisch zu gestalten.

Die Position in Künzelsau bietet ein flexibles hybrides Arbeitsmodell (ca. drei Tage Mobile Office / zwei Tage vor Ort).

## Aufgaben

- Fachliche Verantwortung für die digitale Lernsystemlandschaft und deren strategische Weiterentwicklung international

- Betrieb und strategische Weiterentwicklung der digitalen Lernsystemlandschaft im internationalen Konzernumfeld

- Weiterentwicklung und weltweite Umsetzung von Standards und Prozessen im aktuellen LMS "Time4You"

- Erarbeitung eines Business Cases und einer Entscheidungsmatrix zur Systemauswahl (SuccessFactors Learning vs. Alternativen wie z.B. imc)

- Steuerung des komplexen Anforderungsmanagements (Erarbeitung gemeinsam mit Key Usern)

- Erstellung und Umsetzung von globalen Rollout-Strategien für weitere Konzerngesellschaften

- Agieren als Bindeglied und Schnittstellenkoordination zwischen der Würth IT, der Würth Business Academy und den weltweiten Gesellschaften

- Analyse der Systemnutzung, Erstellung von KPI-Reportings und Dashboards (z.B. via Power BI) zur Performance-Messung

## Qualifikation

- Mehrjährige Berufserfahrung in der Verwaltung, dem Rollout und der Weiterentwicklung digitaler Lerntechnologien und moderner Learning Management Systeme im internationalen Umfeld

- Nachweisliche Expertise im Projekt- und Prozessmanagement (Anforderungsanalyse, Stakeholder-Management, Change Management und Rollout-Strategien)

- Ausgeprägte IT-Affinität sowie Verständnis für Schnittstellen, Datenstrukturen und Systemarchitekturen

- Diplomatisches Geschick, Verhandlungsstärke und Souveränität im Umgang mit internationalen Stakeholdern verschiedener Hierarchieebenen bis hin zur Konzernführung

- Verhandlungssichere Deutsch- und Englischkenntnisse

## Benefits

- Eine zentrale Schlüsselrolle in der Group HR an der Schnittstelle zwischen Business, HR und IT, um die globale Lernkultur eines Weltmarktführers aktiv mitzugeben und neu zu prägen

- Die Stabilität eines krisensicheren Weltmarktführers gepaart mit flachen Hierarchien, starkem Vertrauen, hoher Eigenverantwortung und gelebter Duz-Kultur

- Erstklassige Benefits: 30 Tage Urlaub, 50% Zuschuss im modernen Betriebsrestaurant inkl. kostenloser Heißgetränke, EGYM Wellpass, E-Bike-Leasing, Zuschuss zur betrieblichen Altersvorsorge, betriebliche Weiterbildung über die AKADEMIE WÜRTH sowie umfangreiche Corporate Benefits und Mitarbeiterrabatte

Deine Ansprechpartnerin ist Malin Knöpler. Wir sind schon gespannt darauf, dich kennenzulernen. Als exklusiver Recruiting-Partner übernehmen wir die Vorauswahl für diese Position und versorgen dich im Prozess mit weiterführenden Informationen.

Hast du dich nicht wiedergefunden? Kein Problem. Komm’ auf unsere Website. Wir sind immer auf der Suche nach Talenten, Professionals und Digital Experts, die bereit sind, neue Wege zu gehen. Deine passende Herausforderung ist bestimmt auch dabei.

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
