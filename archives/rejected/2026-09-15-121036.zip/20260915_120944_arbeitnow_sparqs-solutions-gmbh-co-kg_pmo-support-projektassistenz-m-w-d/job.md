# PMO Support/Projektassistenz (m/w/d)

Posted: 2026-09-15T07:00:48Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Du behältst immer den Überblick und vergisst keine Deadline? Du hast Freude daran, nicht nur Aufgaben abzuarbeiten, sondern Themen proaktiv voranzutreiben? Du erledigst Aufgaben, bevor sie dir überhaupt gestellt werden?

Dann bist du bei sparqs als PMO Support/Projektassistenz (m/w/d) genau richtig! Bei uns unterstützt Du die (Teil-)Projektleitenden in den Projekten für unsere Kunden vor allem in den Bereichen Energiewirtschaft, Handel und Gesundheitswesen. Mit deiner guten methodischen und organisatorischen Herangehensweise unterstützt du entweder die sparqs-eigenen Projektleitenden und das dazugehörigen Projektteam oder auf Kundenseite Projektleitende bei der erfolgreichen Gestaltung bei dem Projektaufbau und der -durchführung.

## Aufgaben

- Du unterstützt die (Teil-)Projektleitenden im Projekttagesgeschäft im Rahmen ihrer **administrativen Tätigkeiten**. Dabei geht es u.a um die Organisation von Terminen inkl. Vorbereitung, Protokollierung von Projektsitzungen, Koordinierung interner und externer Kommunikation sowie um die Erstellung von erforderlichen Präsentationsunterlagen.

- Du **planst** in Abstimmung mit den (Teil-)Projektleitenden Workshops und Trainings und unterstützt bei der **Durchführung** der **Workshops** und **Trainings** bei unseren Kunden.

- Du bis verantwortlich für die **Verwaltung** der **Projektdokumentationen**. Dazu zählen u. a. Konzepte, Projektpläne, Präsentationen.

- Du stellst die **Einhaltung** der von **sparqs eingesetzten Projektmethoden und-tools** (sowie den dazugehörigen Standards und Prozessen) in den Projekten sicher inkl. der **Durchführung** des dazugehörigen **Wissenstransfers** bei unseren Kunden.

- Du unterstützt proaktiv die (Teil-)Projektleitenden im Rahmen des **Qualitäts- und Risikomanagements**. Dazu gehört die Sicherstellung zur Einhaltung des sparqs-eigenen Qualitätsmanagements, Statusüberwachung, Einhaltung des Change-Request-Verfahren und bei der Dokumentation von Risiken inkl. Entscheidungsvorlagen und Maßnahmenkatalog im Projekt.

- Du wirkst proaktiv am **operativen Ressourcen-Management** mit und kümmerst Dich ggf. um die **Beschaffung** von externen Dienstleistern.

## Qualifikation

- Du hast ein **abgeschlossene kaufmännische Ausbildung im Büromanagement** oder eine vergleichbare Qualifikation im Projektumfeld.

- Deine **Berufserfahrung** liegt bei mindestens **drei Jahren** in einer adäquaten Position oder Projekten; wünschenswert in der Energieversorgung.

- Du bist sicher im Umgang mit **MS Office-Produkten** (MS Word, MS Excel, MS PowerPoint, MS Project) und Softwareprodukten wie **Confluence** und **Jira**.

- Dich zeichnet eine **hohe Selbstständigkeit** und ein **ausgeprägtes Organisationsgeschick** aus.

- **Komplexe Herausforderungen** motivieren Dich, **Zusammenhänge** zu erkennen und innovative **Lösungen** zu entwickeln.

- Du hast eine **strukturierte**, **kundenorientierte** und **sorgfältige Arbeitsweise**,

- Dich zeichnet ein **aufgabenübergreifendes Denken** und **Verantwortungsbewusstsein** aus.

- Du arbeitest **eigenverantwortlich** und hast ein hohes Maß an **Vertrauenswürdigkeit** und **Zuverlässigkeit**.

- Du bist **belastbar**, hast ein **professionelles** und **überzeugendes Auftreten** sowie gute **Kommunikationsfähigkeiten**

- Du bringst eine für das Projekt erforderliche **Hands-on-Mentalität** mit.

- **Verhandlungssichere Deutschkenntnisse** auf C1-Niveau und gute Englischkenntnisse in Wort und Schrift.

## Benefits

✅ **Ein Team, das dich wirklich supportet**

– Hochmotivierte Kollegen, eine entspannte Arbeitsatmosphäre & echter Teamspirit!

✅ **Startup-Vibes & flache Hierarchien**

– Keine langen Entscheidungswege – hier zählt deine Meinung von Tag 1 an.

✅ **Flexibilität pur – du bestimmst, wann & wo du arbeitest**

– Flexible Arbeitszeiten & Remote-Option – arbeite so, wie es für dich am besten passt.

✅ **Top-Onboarding mit persönlichem Mentor**

– Dein Start wird easy: Wir begleiten dich mit einem strukturierten Onboarding & Mentoring-Programm.

✅ **Attraktive Benefits, die sich lohnen**

– Betriebliche Altersvorsorge, Corporate Benefits & weitere exklusive Vergünstigungen.

✅ **Wähle dein eigenes Arbeits-Setup**

– Mac oder Windows? Du entscheidest! Wir stellen dir die Hardware, mit der du am produktivsten bist.

✅ **Werde Teil unserer Erfolgsgeschichte**

– Gestalte aktiv unser Unternehmen mit und bringe deine Ideen ein.

✅ **Verantwortung & Impact in Kundenprojekten**

– Arbeite an spannenden Projekten und begleite unsere Kunden durch die digitale Transformation.

✅ **Langeweile? Gibt’s bei uns nicht!**

– Dich erwarten ständig neue Herausforderungen sowie regelmäßige Team-Events.

✅ **Transparenz & Weiterentwicklung**

– Regelmäßige Feedbackgespräche, klare Perspektiven & individuelle Entwicklungsmöglichkeiten.

✅ **Deine Karriere, dein Weg**

– Fachliche & persönliche Weiterentwicklung durch top Trainings & Coachings.

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
