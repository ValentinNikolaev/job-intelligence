# Manager/ Architect SAP Business Intelligence (m/w/d) im Application Management Support

Posted: 2026-09-15T08:30:54Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**Wir sind die Berater der Weltmarktführer: Hochmotivierte Expertinnen und Experten, die als erfolgreiches Team digitale End-to-End-Geschäftsprozesslösungen vorantreiben. Gemeinsam stärken wir die Zukunft der beeindruckendsten Unternehmen der Welt aus Maschinen- und Anlagenbau, Automotive, Life Science, Pharma und Chemie, mit denen wir viel gemeinsam haben.**

Unser ausgezeichneter Ruf bei Hidden Champions öffnet Dir die Türen für anspruchsvolle Projekte mit einzigartigen Gestaltungsmöglichkeiten. Werde Teil einer der besten und verlässlichsten Beratungen und nutze vielfältige Entwicklungschancen. Als engagiertes Teammitglied kannst Du bei uns schnell Verantwortung übernehmen und über Dich hinauswachsen. Du triffst auf ein starkes Team, das zusammenhält und wirklich etwas bewegen will.

Im Applikationssupport unterstützen wir als Lösungsanbieter unsere Kunden über den kompletten Lebenszyklus einer SAP-Systemlandschaft, in Projekt- und in Betriebsphasen. Zum weiteren Ausbau des Geschäftsfeldes suchen wir aktuell einen **Team Lead im Bereich SAP Business Intelligence** (m/w/d) im Application Management Support.

### **Was Dich erwartet**

-

Du bist fachlich und disziplinarisch für ein Team aus SAP Business Intelligence Experten zuständig

-

Du stehst in enger Abstimmung mit unseren Kunden und begleitest diese in langfristigen Partnerschaften bezüglich Reporting-Lösungen

-

Du wirkst im Vertriebs- und Angebotsprozess zur Kundengewinnung mit (kein Presales)

-

Du analysierst technische SAP Business Intelligence Probleme im Detail auf der Suche nach Fehlerquellen und deren Lösungen

-

Du bearbeitest 3rd-Level-Support Tickets und bist für deren Nachverfolgung und Lösung zuständig

-

Du bist für die Weiterentwicklung des Serviceangebotes und des Teams im BI-Application Management Support zuständig

-

Du bist für das Service Management für Application Management Support-Kunden zuständig

-

Hybride Arbeitsweise, Flexibilität hinsichtlich Präsenz (Kombination aus Home-Office und Bürotagen idealerweise im Raum Frankfurt a.M.)

### **Was wir uns wünschen**

-

Umfangreiche Kenntnisse in SAP Business Intelligence auf Architektenlevel

-

Erfahrungen für Reporting-Lösungen mit SAP SAC oder SAP Datasphere

-

Hochschulabschluss in BWL, (Wirtschafts-)Informatik oder einschlägige Berufserfahrung, auch in der Mitarbeiterführung

-

Erfahrung im Betrieb und Entwicklung von SAP Business Intelligence Lösungen und Kenntnisse in den Bereichen Service Management, Support, ITIL etc.

-

Sehr gute Deutsch und Englischkenntnisse

-

Reisebereitschaft für gelegentliche Kundenbesuche, Firmenevents, Weiterbildungsmaßnahmen, etc.

### **Unsere Benefits:**

**Aus- und Weiterbildung**

SAP- und Salesforce-Zertifizierungen, Competence Center-Tage, Fachspezifische Schulungen

**Betriebliche Gesundheitsförderung**

Zuschuss zur betrieblichen Altersvorsorge, Zusatzversicherungen, diverse Sportangebote wie Urban Sports Club, Yoga etc.

**Events**

Beratertage, Weihnachtsfeier, Sommerfest, Teamevents, Alumni-Treffen, Jubiläumsfeiern und -reisen

**Prämien**

Umsatzbeteiligungen, Prämienzahlungen für erfolgreich abgeschlossene Projekte, Attraktive Gehaltsmodelle, Mitarbeiterempfehlungsprämien

**Arbeitszeiten**

Flexible Arbeitszeitmodelle, mobiles Arbeiten, 30 Tage Urlaub, Workation

**Ausstattung**

Firmenhandy (iPhone), Notebook / Macbook, Mitarbeiter PC Programm, Ergonomische Arbeitsplätze, Kostenlose Getränke, Gemeinschaftsräume mit Wohlfühlcharakter

**Firmenwagen**

Firmenwagen inkl. Tankkarte/ Mobilitätspauschale, Bahncard, Jobrad

**Zuwendungen**

Zuschüsse für Kindergarten/Kita und außerordentliche Zuwendungen je Lebenssituation und Betriebszugehörigkeit

#### Dein Ansprechpartner

**Yasemin Sarayli**

Senior Recruiter

[+49 151 65577091](tel:+49 151 65577091)

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
