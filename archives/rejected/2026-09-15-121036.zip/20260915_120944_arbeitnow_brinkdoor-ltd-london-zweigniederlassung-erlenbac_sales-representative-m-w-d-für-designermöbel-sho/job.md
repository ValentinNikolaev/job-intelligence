# Sales Representative (m/w/d) für Designermöbel Showroom

Posted: 2026-09-15T08:30:35Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Über die Rolle

Du liebst hochwertige Designermöbel, den persönlichen Kundenkontakt im Showroom und hast Freude daran, aktiv zu verkaufen?

Als **Kundenbetreuer (m/w/d)** übernimmst du eine zentrale Rolle im Vertrieb: Du berätst Kund:innen vor Ort und digital, qualifizierst Anfragen, steuerst Leads durch den Sales‑Prozess und führst sie gezielt zum Abschluss.

Der Samstag ist unser stärkster Verkaufstag, dafür erhältst du unter der Woche einen festen Ausgleichstag.

## Aufgaben

Deine Aufgaben

**Aktiver Verkauf & Kundenberatung**

- Verkauf hochwertiger (gebrauchter) Designermöbel

- Persönliche Beratung im Showroom in Köln‑Lövenich

- Beratung und Verkauf per Telefon, E‑Mail und Videocall

- Begeisternde Betreuung vom Erstkontakt bis zum Abschluss

**Lead‑Management & Conversion**

- Qualifizierung, Priorisierung und Nachverfolgung eingehender Anfragen

- Aktive Steuerung der Leads mit Fokus auf Abschlusswahrscheinlichkeit und Umsatz

- Verantwortung für den gesamten Sales‑Prozess deiner Leads

**Schnittstelle Showroom & Online**

- Zentrale Sales‑Schnittstelle zwischen Online‑Anfragen und dem Showroom‑Team

- Sicherstellung einer schnellen, strukturierten und hochwertigen Bearbeitung verkaufsreifer Leads

**CRM & Sales‑Pipeline**

- Pflege von Leads, Kundendaten und Verkaufschancen im CRM

- Sicherstellung einer transparenten, aktuellen und belastbaren Sales‑Pipeline

- Arbeiten mit digitalen Tools und Ticket‑Systemen (z. B. Zendesk)

**Teamarbeit**

- Enge Zusammenarbeit mit dem Sales‑Team

- Terminabstimmungen, Vorbereitung von Verkaufsgesprächen und gemeinsame Zielerreichung

## Qualifikation

Dein Profil

- Erfahrung im Vertriebsumfeld (z. B. Inside Sales, Kaltakquise, Door-2-Door, Sales Assistant, Vertriebsinnendienst, Kundenberatung mit Sales‑Fokus)

- Freude am aktiven Verkaufen und an messbaren Ergebnissen

- Strukturierte, selbstständige Arbeitsweise, auch bei hohem Anfragevolumen

- Sicherer Umgang mit PC, digitalen Tools und gängigen Office‑Anwendungen

- Verbindliches, professionelles Auftreten im Kundenkontakt

- Sehr gute Deutsch‑ und Englischkenntnisse in Wort und Schrift

- Starkes Interesse an Interior Design und hochwertigen Designermöbeln

## Benefits

Das erwartet dich

-

Verantwortungsvolle Sales‑Position mit viel Gestaltungsspielraum ab Tag eins

-

Arbeit in einem wachsenden, ambitionierten Interior‑Scale‑up

-

Transparentes **Teambonus‑Modell**

-

Bonus bei Erreichen des Zielumsatzes

-

Accelerator bei deutlicher Übererfüllung

-

32 Urlaubstage (30 regulär + 24.12. & 31.12. frei)

-

Flexible Arbeitszeiten & teilweise Homeoffice‑Option

-

Deutschlandticket (50 % Zuschuss)

-

Urban Sports Club & Essenszuschuss

-

Gewinnbeteiligung für Mitarbeitende

-

Regelmäßige Team‑Events & offene Unternehmenskultur

Über das Unternehmen

Unser Kunde ist ein **schnell wachsendes Interior‑Scale‑up** im Bereich hochwertiger Designermöbel und Teil der Circular Economy.

Das Unternehmen steht für unternehmerisches Denken, Nachhaltigkeit und ein starkes Sales‑Mindset, mit kurzen Entscheidungswegen, hoher Eigenverantwortung und echtem Teamgeist.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
