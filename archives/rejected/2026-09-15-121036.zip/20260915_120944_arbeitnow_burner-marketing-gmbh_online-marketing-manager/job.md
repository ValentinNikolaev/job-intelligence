# Online Marketing Manager

Posted: 2026-09-15T06:30:53Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Unsere Firmenkultur ist alles andere als gewöhnlich. Hier geht es nicht nur um Arbeit, sondern um Leidenschaft und Verantwortung. Wir lieben Freiraum für Kreativität und eigenständiges Arbeiten. Echte Teamarbeit bedeutet bei uns, dass wir zusammen an einem Strang ziehen, uns gegenseitig pushen und Erfolge gemeinsam feiern.

Hier findest du nicht nur Kollegen – sondern Mentoren, die dich wachsen lassen, und ein Umfeld, das dich dazu bringt, jeden Tag noch ein Stück besser zu werden. Wir sind Macher, die ständig nach neuen Herausforderungen streben. Und das Beste daran? Dein Erfolg ist unser Erfolg – gemeinsam erreichen wir Großes!

## Aufgaben

**Kampagnen erschaffen

**Du erschaffst Kampagnen, die alle Erwartungen sprengen.

**Ads entwickeln**

Du entwickelst Ads, die nicht nur performen, sondern dominieren.

**Kreative Content-Strategien**

Du entwickelst Content-Strategien, die die Marke stärken und digital durchstarten.

**Marken transformieren**

Du verwandelst Unternehmen in Marken, die im Gedächtnis bleiben.

**Datengetrieben optimieren**

Du nutzt Daten, um Kampagnen stetig zu verbessern und Performance zu maximieren.

**Kundenprojekte übernehmen**

Du übernimmst mittelfristig eigene Kundenprojekte.

## Qualifikation

**Erfahrung in mind. einem der folgenden Bereiche:**

- Media-Buying

- Mediendesign

- Copywriting

- Webdesign

- SEO / SEA

## Benefits

**Freiraum für Visionen:

**Ab Tag eins hast du echte Gestaltungsmacht und die Freiheit, deine Ideen umzusetzen.

**Anerkennung für deinen Beitrag:**

Deine Leistung wird gesehen und gefeiert – gemeinsam machen wir jeden Erfolg sichtbar.

**Beteiligung am Unternehmenserfolg:**

Dein Erfolg zahlt sich aus! Mit attraktiven Provisionen wächst dein Verdienst parallel zu deinem Erfolg.

**Mentoring auf höchstem Niveau:

**Lerne von erfahrenen Profis und entwickle dich kontinuierlich weiter – wir fördern dein Wachstum.

**Schnelle Aufstiegsmöglichkeiten:**

Übernimm schnell Verantwortung und steigere dich mit klaren Perspektiven, die dir echte Karrierechancen bieten.

**Top Lage:

**Arbeiten mitten in der Innenstadt – top Lage, perfekte Anbindung, und alles, was du brauchst, direkt vor der Tür!

Unsere Reise begann direkt nach dem Abitur – im kleinen Kinderzimmer in Erlangen, wo unsere Leidenschaft für Marketing und Kreativität entfacht wurde. Was als kleine Idee in unseren Köpfen begann, ist heute eine Erfolgsgeschichte, die durch die kraftvollen Empfehlungen zufriedener Kunden immer weiter wächst.

Von Tag eins an hatten wir nur ein Ziel: Wir wollten mittelständischen Unternehmen nicht einfach Marketing bieten – wir wollten echtes Wachstum und sichtbare Ergebnisse liefern. Wir hinterfragten den Status quo, gingen neue, mutige Wege und schrieben unseren eigenen Erfolgsweg.

Mit unendlichem Drive, kreativen Ideen und der Entschlossenheit, nie mit „gut genug“ zufrieden zu sein, haben wir uns von einem Start-up zu einem Wachstumspartner für Unternehmen entwickelt. Heute sind wir stolz auf das, was wir erreicht haben – aber wir stehen erst am Anfang. Mit einem dynamischen Team und starken Freelancern kombinieren wir Expertise, Innovation und Feuer in allem, was wir tun – wir sind der Burner!

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
