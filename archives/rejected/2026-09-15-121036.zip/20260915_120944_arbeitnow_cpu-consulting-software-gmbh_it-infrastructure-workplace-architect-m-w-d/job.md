# IT Infrastructure & Workplace Architect (m/w/d)

Posted: 2026-09-15T08:00:35Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**Deine Rolle**

Du möchtest moderne Workplace-Architekturen nicht nur betreiben, sondern strategisch weiterentwickeln? Als **IT Workplace Architect / Consultant (m/w/d)** analysierst du bestehende IT-Infrastrukturen, vergleichst Microsoft-Lösungen mit Open-Source- und Best-of-Breed-Alternativen und entwickelst fundierte Entscheidungsgrundlagen für zukünftige Zielarchitekturen.

Dich erwartet ein anspruchsvolles Beratungsprojekt mit **hohem Remote-Anteil und gelegentlicher Präsenz in München**.

## Aufgaben

- Analyse bestehender Workplace- und IT-Infrastrukturen

Entwicklung und Bewertung zukünftiger Zielarchitekturen

- Vergleich von Microsoft mit Open-Source- und Best-of-Breed-Lösungen

- Betrachtung von Microsoft 365, Exchange Online, SharePoint sowie alternativen Lösungen

- Bewertung von Chancen, Risiken, Lizenzkosten und organisatorischen Auswirkungen

- Erstellung von Managementunterlagen und Präsentationen

- Präsentation und Vertretung der Ergebnisse gegenüber Entscheidern

## Qualifikation

- Mehrjährige Erfahrung in **Workplace-, Infrastruktur- oder Solution-Architektur**

- Fundierte Kenntnisse des **Microsoft-Produktportfolios**

- Marktkenntnisse im Bereich **Open Source und Best-of-Breed**

- Erfahrung mit Workplace-Technologien wie Fileservices, Verzeichnisdiensten, E-Mail, Client-Virtualisierung oder Softwareverteilung

- Erfahrung in der Analyse und Bewertung komplexer IT-Landschaften

- Technologieoffene und herstellerunabhängige Arbeitsweise

- Ausgeprägte Beratungs- und Präsentationskompetenz

- Sehr gute Deutschkenntnisse

## Benefits

**Strategischer Impact:** Deine Arbeit bildet die Grundlage für eine relevante Technologieentscheidung.

**Technologieoffenes Umfeld:** Im Mittelpunkt steht die beste Lösung – nicht ein bestimmter Hersteller.

**Flexibles Arbeiten:** Überwiegend remote mit ca. 1–2 Präsenztagen pro Monat in München.

**Spannende IT-Projekte:** Anspruchsvolle Beratungsprojekte mit hoher fachlicher Verantwortung.

**Zukunftssicherheit:** Unbefristeter Arbeitsvertrag und 20 % Zuschuss zur betrieblichen Altersvorsorge.

**Du findest dich in unserem Profil wieder?**

**Dann sollten wir uns kennenlernen!**

**Bitte sende uns hierzu deine vollständige, deutschsprachige Bewerbung mit frühestmöglichem Eintrittstermin und deiner Gehaltsvorstellung zu.**

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
