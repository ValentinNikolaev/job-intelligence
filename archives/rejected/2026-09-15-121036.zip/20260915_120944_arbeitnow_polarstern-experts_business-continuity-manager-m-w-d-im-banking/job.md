# Business Continuity Manager (m/w/d) im Banking

Posted: 2026-09-15T08:30:31Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Sie behalten auch in Ausnahmesituationen einen kühlen Kopf und wollen Verantwortung für das Notfallmanagement übernehmen? Sie arbeiten gerne eigenständig und können Leute begeistern und für wichtige Themen mitnehmen? Dann starten Sie mit uns als Business Continuity Manager durch!

## Aufgaben

- Sie verantworten das Notfallmanagement (BCMS) und entwickeln die Business Continuity gemäß **BSI 200-4** weiter.

- Sie führen regelmäßig **Business-Impact-Analysen** durch, werten Ergebnisse aus und leiten Maßnahmen ab.

- Sie erstellen, pflegen und koordinieren **Notfall-, Geschäftsfortführungs- und Wiederanlaufpläne**.

- Sie entwickeln **Vorsorgekonzepte, Übungen und Tests**, unterstützen die Fachbereiche bei der Umsetzung.

- Sie arbeiten eng mit der **IT** zusammen, um IT-Notfallplanungen und Testläufe abzustimmen.

## Qualifikation

- Mehrjährige Berufserfahrung im **Notfallmanagement** oder ein Studium (Wirtschaftsinformatik, Informatik o. Ä.)

- Gute Kenntnisse nach **ISO 22301** oder **BSI IT-Grundschutz 200-4**

- Idealerweise Erfahrung im **Informationssicherheits- oder Risikomanagement** (z. B. ISO 2700X, BAIT, MaRisk).

- Strukturierte, eigenständige und zuverlässige Arbeitsweise sowie Teamgeist und Kommunikationsstärke.

- Nice to have: Kenntnisse über Produkte und Abläufe in der **Bankenbranche**

## Benefits

- Leistungsgerechte Vergütung

- Flexible Arbeitszeiten und über **30 Urlaubstage**

- Möglichkeit zur **mobilen Arbeit**

- **Betriebliche Altersvorsorge**, Vermögenswirksame Leistungen und Kinderbetreuungszuschuss

- Attraktive **Mitarbeiterangebote**: Bistro, Getränke, Team-Events u. v. m.

Klingt spannend? Dann freuen wir uns auf Ihre Bewerbung. Melden Sie sich gerne per Mail oder telefonisch und wir besprechen die Details dazu: 0221 6700 2181

Ich freue mich sehr auf Sie!

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
