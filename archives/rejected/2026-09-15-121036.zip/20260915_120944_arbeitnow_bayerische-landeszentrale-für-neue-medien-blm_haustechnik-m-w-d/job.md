# Haustechnik (m/w/d)

Posted: 2026-09-15T08:30:32Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Staatsfern und unabhängig beaufsichtigt die Bayerische Landeszentrale für neue Medien (BLM) private Rundfunk- und Internetangebote in Bayern. Als moderner Regulierer begleiten wir sowohl die Anbieter als auch die Nutzerinnen und Nutzer kompetent in die Medienzukunft. Wir regulieren, wir fördern, wir forschen und wir informieren. Dafür setzten wir uns ein: Vielfalt, Qualität, Glaubwürdigkeit und Transparenz für eine vielfältige und meinungsfreie Medienlandschaft.

**Wir suchen ab sofort und beristet für zwei Jahre einen Haustechniker (m/w/d).**

## Aufgaben

Mit Ihrem technischen Know-how übernehmen Sie folgende Aufgaben:

- Sie sorgen für einen sicheren und zuverlässigen Betrieb der technischen Gebäudeausrüstung (HKLSE)

- Wartungs-, Instandhaltungs- und Instandsetzungsmaßnahmen führen Sie eigenständig durch oder koordinieren diese mit Dienstleistern

- Bei der Digitalisierung der Haustechnik bringen Sie sich unterstützend ein

- Als Ansprechperson stehen Sie unseren Dienstleistern zur Seite

- Die Planung, Steuerung und Kontrolle externer Dienstleister gehört ebenfalls zu Ihrem Aufgabenbereich

- Sie unterstützen den Leiter Haustechnik im Tagesgeschäft und übernehmen bei Bedarf dessen Vertretung

## Qualifikation

Idealerweise bringen Sie Folgendes mit:

- Abgeschlossene Ausbildung im gewerblichen Bereichoder im Handwerk oder vergleichbare Qualifikation

- Führerscheinklasse B

- Gutes technisches Grundverständnis, handwerkliches Geschick und Leistungsbereitschaft

- Selbstständige und zuverlässige Arbeitsweise, Entscheidungsfähigkeit sowie eine schnelle Auffassungsgabe

## Benefits

Bei uns bekommen Sie mehr als nur einen Job:

- 29 Urlaubstage mit zusätzlichen Urlaubstagen

- Gute Vereinbarkeit von Familie und Beruf

- Flexible Arbeitszeitregelung

- Konkurrenzfähiges Gehaltsmodell

- Bezuschusstes Betriebsrestaurant

- Zusatzleistungen wie z.B. arbeitgeberfinanzierte betriebliche öffentlich-rechtliche Altersversorgung, vermögenswirksame Leistungen

- Fachliche und persönliche Weiterbildungsmöglichkeiten

- Bürostandort in München mit guter ÖPNV-Anbindung sowie kostenloser Parkmöglichkeit

- Konjunkturunabhängiger Arbeitsplatz bei einem öffentlich-rechtlichen Arbeitgeber

**Bitte geben Sie Ihre Bewerbung über unser Online-Formular auf unserer Website ab.**

Wir laden ausdrücklich alle Menschen mit entsprechender Qualifikation dazu ein, sich bei uns zu bewerben - unabhängig von ethnischer, kultureller oder sozialer Herkunft, Alter, Religion, Weltanschauung, Behinderung oder sexueller Identität. Schwerbehinderte und Gleichgestellte werden bei gleichwertiger Qualifikation bevorzugt berücksichtigt. Informationen zum Datenschutz, insbesondere zu Ihren Rechten und zur Aufsicht im Datenschutz finden Sie auf unserer Website.

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
