# Senior Customer Success Manager - DACH

Posted: 2026-09-15T08:40:10Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

About You

You're a jack-of-all-trades with a passion for cool technology and interacting with people and making them happy. You're a self-starter who's good at triaging problems and working on the most important one. You've worked directly with customers for a long time and are comfortable being the face of the company to them. One of the things that pleases you most in life is customers successfully using your product, being thrilled with its value, and telling you they're happy they partnered with you. Further, you're a curious person, and you'd love the opportunity to work with a technology team that includes data scientists, algorithm experts, back-end and front-end engineers to expand your knowledge.

About Us

[Constructor.io](http://Constructor.io) powers product search and discovery for some of the largest retailers in the world. We serve billions of requests every week, and you've probably seen our results somewhere and used our product without knowing it. We differentiate ourselves by focusing on metrics over features, and reinventing search and discovery from the ground up as a machine learning challenge with the specific goal of improving metrics like revenue. We're approximately doubling year over year despite the market slow down and have customers in every eCommerce vertical.

We're a passionate team of technologists who love solving problems and want to make our customers' and coworkers' lives better. We value empathy, openness, curiosity, continuous improvement, and are excited by metrics that matter. We believe that empowering everyone in a company to do what they think is best can lead to great things.

About The Position

As a Customer Success Manager, you'll be joining a rapidly growing team that helps our customers increase their revenue by improving the search and product discovery experiences of their websites and mobile apps through integrating with our services.

Your specific responsibilities will include:

-

Own the customer journey from project kick-off, launch, adoption, and ongoing value realization, ensuring customers achieve meaningful business outcomes and are delighted with the partnership.

-

Build trusted relationships across complex enterprise organizations, engaging confidently with stakeholders ranging from engineers, data and product teams to Heads and Directors of Ecommerce, Digital, Product, and Technology, as well as VP and C-level executives.

-

Understand the goals, priorities, and influence of different customer personas, and align technical and business stakeholders around a shared success plan.

-

Translate technical concepts, product capabilities, and performance data into clear business value, connecting Constructor’s work to outcomes such as conversion, revenue, customer experience, and operational efficiency.

-

Plan and lead effective QBRs and EBRs that go beyond reporting: communicate measurable impact, facilitate strategic conversations, make recommendations, and align stakeholders on priorities and next steps.

-

Identify risks, blockers, and changing customer priorities early. Lead escalations with clarity and urgency by defining the business impact, engaging the right internal teams, setting expectations, and maintaining customer confidence through resolution.

-

Advocate effectively for customer needs while exercising strong judgment about when engineering involvement is required, how requests should be prioritized, and when an alternative solution can deliver the desired outcome.

-

Use customer insights, performance data, and ecommerce best practices to provide proactive, strategic recommendations, not simply respond to requests.

-

Maintain clear success plans, stakeholder maps, account documentation, training materials, and agreed actions so that both the customer and Constructor teams remain aligned.

-

Partner closely with Account Management to support retention and growth by demonstrating value, strengthening executive relationships, and identifying opportunities to expand the partnership.

-

Continuously improve how we onboard, integrate, and support customers, sharing repeatable best practices that make our processes more scalable and the customer experience more effective.

Requirements

-

Based in EMEA, ideally in the DACH region —particularly Germany. Fluency in German is an advantage but not required.

-

At least three years of experience managing relationships with enterprise customers in Customer Success, Account Management, Solutions Consulting, or a similar customer-facing role.

-

Experience working with complex enterprise organizations and building trusted relationships with stakeholders ranging from technical teams and product leaders to Ecommerce Directors, VPs, and C-level executives.

-

Strong executive presence and the confidence to lead strategic customer conversations, including QBRs and EBRs.

-

Strong influencing and stakeholder-management skills, including the ability to create momentum and drive progress without direct authority.

-

Strong problem-solving skills, intellectual curiosity, and the ability to learn quickly in a fast-moving, technically sophisticated environment.

-

Experience in ecommerce, digital commerce, search, product discovery, or a related field is highly valued.

Benefits

-

A competitive compensation package including stock options

-

Fully remote team - choose where you live

-

Work from home stipend! We want you to have the resources you need to set up your home office

-

Apple laptops provided for new employees

-

Training and development budget for every employee, refreshed each year

-

Parental leave for qualified employees

-

Work with smart people who will help you grow and make a meaningful impact

-

Diversity, Equity, and Inclusion at Constructor

At [Constructor.io](http://Constructor.io) we are committed to cultivating a work environment that is diverse, equitable, and inclusive. As an equal opportunity employer, we welcome individuals of all backgrounds and provide equal opportunities to all applicants regardless of their education, diversity of opinion, race, color, religion, gender, gender expression, sexual orientation, national origin, genetics, disability, age, veteran status or affiliation in any other protected group.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
