# Product Manager | Intch

Posted: 2026-09-15T08:40:11Z

## Rejection

- Category: tech_stack
- Reason: role does not mention Go/Golang or PHP

## About Intch

Intch is a professional social network with a marketplace for part-time work. You can think of it as a professional network built for senior specialists who take on meaningful contracts alongside their main work. A typical contract lasts from three to six months. The product is used in 140 countries and is available in up to 20 languages. Intch has fewer than 40 people and four product areas, with three already live and one preparing to launch. Intch is rethinking how people and companies find each other and build trust online.

## What you’ll do

-

Own the B2C product end to end, including its P&L.

-

Set the product direction and own the 3–6 month roadmap across strategy, experimentation, and delivery.

-

Drive growth through hypothesis-driven experiments and measurable improvements in acquisition, activation, and retention.

-

Own the product metrics and use data to guide decisions and prioritisation.

-

Conduct CustDev interviews and build a deep understanding of user behaviour across a global, multilingual audience.

-

Partner with the B2B product teams to make the B2C product the connective layer across Intch’s product ecosystem.

-

Report directly to the founder and take over the product vertical they currently lead.

## What you need to succeed

-

5+ years of experience in product management.

-

A strong B2C growth track record, including experiments, acquisition, and measurable results.

-

Proven experience scaling a product that already has strong product–market fit.

-

A strong record of improving key metrics such as growth, activation, and retention.

-

Strong product sense and a hypothesis-driven approach to problem-solving.

-

Comfort working with data and translating insights into action.

-

Experience working in a startup or another fast-moving, high-ownership environment.

-

High autonomy, accountability, and comfort working without micromanagement.

-

Fluent Russian.

## What you get

-

Full ownership of a profitable, fast-growing product and its P&L, reporting directly to the founder.

-

A deliberately compact team (under 40 people) where everyone has a large area of ownership and streamlined collaboration.

-

Metrics-driven culture: every function, including support and payments, owns numbers. Your P&L is your scoreboard.

-

Flat, cross-pollinating structure: anyone in the company can bring a validated idea to your product. You can do the same across other verticals.

-

Paid vacation and sick leave.

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
