# Team Lead People (w/m/d) - befristet

Posted: 2026-09-15T09:30:41Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

## Your mission

Für unser People-Team suchen wir ab dem 01.12.2026 eine:n erfahrene:n Team Lead People (w/m/d), befristet auf 15 Monate (01.12.2026 - 29.02.2028). In dieser Rolle bist du verantwortlich für die strategische und operative Führung des People & Office Management Teams und trägst aktiv zur Gestaltung und Weiterentwicklung unserer Unternehmenskultur bei.

- Teamführung: Du führst unser People- und Office-Management-Team fachlich und disziplinarisch.

- Strategische Führung: Du betreust und verantwortest die strategische Ausrichtung und Weiterentwicklung aller People-Bereiche (Recruiting, People Operations, Personalentwicklung, Office Management).

- Personalstrategie: Im Austausch mit der Geschäftsleitung erarbeitest du die Personalstrategie, erstellst aussagekräftige und anschauliche Personalberichte und formulierst daraus datenbasierte, zukunftsorientierte Handlungsempfehlungen für die Geschäftsleitung.

- Organisationsentwicklung & Change: Du begleitest aktiv die Weiterentwicklung unserer Team- und Organisationsstrukturen, unterstützt Change-Management-Initiativen im gesamten Unternehmen und sorgst dafür, dass Veränderungen klar kommuniziert, sauber umgesetzt und im Team verankert werden.

- Hands-on-Mitarbeit: Neben der strategischen Führung übernimmst du operative Aufgaben selbst – etwa im Recruiting, in der Pflege unseres HRIS (Personio), bei administrativen Dokumenten oder im People-Tagesgeschäft.

- Beratung & Employee Relations: Du bist vertrauensvolle:r Berater:in für alle Mitarbeitenden und die Geschäftsleitung und findest schnell Lösungen.

- Performance & Feedback: Du koordinierst und entwickelst unsere Performance-Review- und Feedbackprozesse sowie Maßnahmen der Personalentwicklung weiter, z. B. unser Growth Framework und die Verankerung unserer Unternehmenswerte.

- Kommunikation: Du kommunizierst unternehmensinterne Neuigkeiten sowie People- und Office-Management-Themen in Stand-ups und über Slack (unsere Unternehmenssprache ist Englisch).

## Your profile

- Du hast 5+ Jahre Berufserfahrung im Personalbereich. In dieser Zeit hast du Erfahrung in einer generalistischen HR-Rolle über den gesamten Employee Lifecycle hinweg (Recruiting, People Operations, Performance, Employee Relations) gesammelt.

- Du hast Führungserfahrung und hast schon ein Team geleitet.

- Du verfügst über Entscheidungs- und Überzeugungskraft sowie Konflikt- und Kritikfähigkeit und vermittelst auch in Zeiten des Wandels Ruhe und Struktur.

- Du bist strategisch und hands-on zugleich: Du entwickelst gemeinsam mit der Geschäftsleitung die Personalstrategie weiter und packst gleichzeitig selbstverständlich im Tagesgeschäft mit an.

- Du führst souverän Teams durch Veränderungen und schaffst Vertrauen und stärkst Stabilität.

- Du hast fundierte Arbeitsrechtskenntnisse und erweiterst sie kontinuierlich.

- Du hast sehr gute Moderations- und Präsentationsfähigkeiten, einen diplomatischen Kommunikationsstil sowie sehr gute Deutsch- und Englischkenntnisse in Wort und Schrift.

- Du lebst in Berlin. Du wertschätzt persönlichen Austausch und kommst gern ins Büro. Vier Tage Präsenz im Office sind für diese Rolle notwendig, einen Tag kannst du gern aus dem Home Office arbeiten.

## What we offer

- Einen sinnstiftenden Job – wir bauen ein großartiges Produkt, das echten Mehrwert für Communities liefert

- Arbeiten in einem fröhlichen, erfahrenen Team, das Wissen teilt und voneinander lernt

- Einblicke in den gesamten Arbeitsprozess unseres Social Startups sowie der [nebenan.de](http://nebenan.de) Stiftung

- Deine [nebenan.de](http://nebenan.de) SpenditCard – jeden Monat erhältst Du zusätzlich 35 € zur freien Verfügung

- 30 Tage Jahresurlaub, plus die Möglichkeit von Workation-Modellen und Sabbaticals

- Eine stärkenorientierte Entwicklungskultur (wir arbeiten mit dem Gallup StrengthsFinder)

- Ein Büro in Berlin-Kreuzberg Nähe Markthalle Neun und regelmäßige Events

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
