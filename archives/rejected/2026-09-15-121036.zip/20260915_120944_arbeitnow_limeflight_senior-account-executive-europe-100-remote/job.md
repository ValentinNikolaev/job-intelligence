# Senior Account Executive (Europe, 100% remote)

Posted: 2026-09-15T07:20:10Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Join our fully remote, mission-driven team dedicated to pioneering **sustainable inflight service management**. Work on innovative technology solutions with global impact, collaborate within a diverse, international environment, and continuously enhance your skills through ongoing learning opportunities.

Headquartered in Zurich, Switzerland with team members across 11 countries, we offer a dynamic and engaging company culture that celebrates creativity, collaboration, and inclusion.

#### **About the role**

We are on a mission to contribute to a **zero-waste future** by drastically reducing food waste, fuel consumption, costs, and most importantly, **CO₂ emissions** in the airline industry. Every role in our company is a direct contributor to this vision and as a Senior Account Executive, you will be at the heart of the team that makes it possible.

You will report directly to one of the founders and work closely with Account Executives, Marketing, Product Management, Customer Success, and the broader founding team.

This is not a traditional SaaS sales role focused on high-volume transactions. Our customers are airlines, our sales cycles are complex, and our relationships often span many years.

You will be responsible for building and executing strategic sales plans, identifying and developing new opportunities, and managing enterprise sales cycles from initial engagement through to contract signature.

Rather than relying solely on inbound demand, you will proactively identify target airlines, build stakeholder relationships, and develop opportunities through a structured account-based sales approach.

We are looking for someone who has already built pipeline, navigated complex airline buying processes, and personally closed significant enterprise business. You will bring both the experience and confidence to independently lead opportunities while collaborating effectively with founders and subject matter experts throughout the sales process.

This is a hands-on individual contributor role. While you will mentor and coach junior sales colleagues, your primary responsibility is generating pipeline, advancing opportunities, and winning new business. If your primary motivation is managing teams rather than selling, this role is not going to be a good fit.

#### **Key responsibilities**

**Strategic Enterprise Sales**

-

Own the full sales cycle from prospecting to contract signature

-

Develop and execute account-based sales strategies for airline customers

-

Build relationships with executive and senior stakeholders

-

Lead commercial negotiations and enterprise procurement processes

-

Create and maintain strategic account plans

**Pipeline Generation & Market Development**

-

Identify and pursue new growth opportunities with airlines globally

-

Build and maintain a healthy pipeline of qualified opportunities

-

Develop stakeholder maps and engagement strategies

-

Generate opportunities through industry networking, referrals, partnerships, and events

-

Continuously expand LimeFlight's presence within the airline industry

**Commercial Leadership**

-

Lead by example through active pipeline creation, opportunity management, and enterprise sales execution

-

Mentor and coach junior sales team members

-

Support deal reviews, account planning, and opportunity strategy

-

Share best practices for enterprise sales execution and stakeholder management

-

Contribute to the continuous improvement of sales methodologies and commercial processes

**Cross-functional Collaboration**

-

Work closely with Marketing, Customer Success, Product, Implementation, and Founder teams

-

Coordinate internal resources throughout the sales cycle

-

Ensure customer requirements are clearly understood and communicated internally

-

Support smooth transitions from sales into implementation and customer success

-

Act as the voice of the market and customer within LimeFlight

#### **Key competencies**

-

10+ years of enterprise B2B sales experience, including significant experience selling to airlines

-

Proven track record of generating pipeline through strategic account-based selling

-

Demonstrated success selling enterprise software, SaaS, or technology solutions to large airline organizations

-

Track record of personally leading and closing enterprise opportunities with a combined contract value exceeding CHF 3 million

-

Experience managing six- and seven-figure enterprise sales opportunities

-

Strong understanding of airline buying processes, stakeholder management, and enterprise procurement

-

Ability to independently drive opportunities forward within complex stakeholder environments

-

Excellent communication, presentation, and negotiation skills

-

Strong commercial and business acumen

-

Collaborative mindset with a team-first attitude

-

Passion for mentoring and developing others

-

High degree of ownership, accountability, and resilience

**Strongly Preferred**

-

Direct experience selling SaaS or enterprise software solutions to airlines.

-

Existing network within the airline industry

-

Deep understanding of airline operations and organizational structures

-

Experience selling across different global markets, with the ability to adapt sales strategies and stakeholder engagement approaches to regional business cultures and buying processes.

-

Experience coaching or mentoring junior commercial team members

#### **Language**

-

Fluent English required

-

Additional languages are a plus

#### **Expected travel needs**

You should be willing to travel up to 30% of the year for customer meetings, industry conferences, trade shows, and relationship-building activities.

Given the relationship-driven nature of the airline industry, regular face-to-face interactions are an important part of the role.

#### **Hiring Process**

-

Recruiter Screen (45 mins)

-

Interview with Hiring Manager (1 hour)

-

Technical Interview (1 hour)

-

Discussion with founder(s) and peer(s)

**LimeFlight is proud to be an equal opportunity employer.**

We are committed to creating an inclusive environment where everyone regardless of race, ethnicity, gender identity or expression, sexual orientation, age, disability, religion, or background can thrive and do their best work.

Join us and be part of a team committed to shaping a zero-waste future for aviation, where your ideas and passion truly matter.

Let’s talk!

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
