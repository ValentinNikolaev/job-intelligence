# Praktikum im Recruiting, Iserlohn

Posted: 2026-09-15T08:00:34Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Als spezialisierte Personalberatung bieten wir unserer Mandantschaft ganzheitliche HR Konzepte, Executive Search & Headhunting. Im Rahmen des Praktikums vermitteln wir Ihnen tief greifende Einblicke in die Tätigkeiten eines Personalberaters/ Headhunters.

## Aufgaben

- Sie bekommen Einsicht in sämtliche Research und Recruiting Prozesse.

Dabei nutzen Sie verschiedene Kanäle und Medien um eine Vorauswahl möglicher Kandidaten zu ermitteln.

- Sie sind bei Kandidaten Interviews und Vorstellungsgesprächen dabei.

- Sie pflegen unsere hauseigene Datenbank und erstellen Kandidatenprofile.

## Qualifikation

- Sie sollten kommunikativ sein.

- Computerkenntnisse setzen wir voraus.

- Das Praktikum soll dazu dienen Ihnen Einblicke in den Tätigkeiten eines

Personalberater/ Headhunter zu geben.

## Benefits

Bei Eignung besteht die Möglichkeit künftig in einen interessanten Arbeitsumfeld mit erstklassigen Perspektiven tätig zu werden.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
