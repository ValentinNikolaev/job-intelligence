# Influencer Marketing Manager DACH (m/w/d)

Posted: 2026-09-15T08:30:31Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

## DEINE MISSION

**Lust, Ernährung neu zu denken?** Bei yfood machen wir seit 2017 gutes Essen alltagstauglich – ausgewogen, praktisch und richtig lecker. Mit unseren Produkten haben wir eine eigene Kategorie geformt: Smart Food. In ganz Europa unterwegs, rasant wachsend und immer auf der Suche nach neuen Ideen. Wenn du Teil eines dynamischen Teams sein möchtest, das die Lebensmittelbranche revolutioniert, dann bist du bei yfood genau richtig.

## Deine Aufgaben als Influencer Marketing Manager DACH

Für unser Influencer Marketing Team bei yfood suchen wir einen Influencer Marketing Manager mit starkem Performance-Fokus.

Social Media ist für dich mehr als ein Job – es ist dein Alltag. Du bist ständig auf Instagram, TikTok und YouTube unterwegs, erkennst Trends, bevor sie mainstream werden, und hast ein feines Gespür dafür, welche Formate und Influencer gerade wirklich funktionieren. Dabei weißt du: Influencer und Communities performen am besten, wenn sie einen klaren Use Case für yfood haben – und genau danach suchst du.

Du betreust dein eigenes Influencer-Portfolio von Research über Verhandlung bis hin zu Performance-Analyse und Rebooking. Du gehst Deals effizient und zielsicher an, verhandelst gerne und hast dabei jederzeit die Zahlen im Blick.

- Eigenständige Betreuung und Weiterentwicklung eines DACH Influencer-Portfolios – von Research und Scouting bis Rebooking

- Laufendes Scouting von Trends, Formaten und neuen Influencern auf Instagram, TikTok, YouTube & Co., mit Fokus auf Performance, Audience Fit und einen klaren Use Case für yfood

- Effizientes Deal Making: Verhandlung und Umsetzung von Kooperationen auf allen relevanten Plattformen, inkl. Testing von Affiliate-, Hybrid- und weiteren erfolgsbasierten Vergütungsmodellen

- Analyse und Optimierung anhand relevanter Performance-KPIs sowie performancebasierte Rebooking- und Budgetentscheidungen

- Testing neuer Influencer, Zielgruppen, Occasions und Content-Formate sowie Aufbau und Pflege werthaltiger Influencer-Beziehungen

- Einsatz von AI-Tools für Research, Analyse, Briefings und Prozessoptimierung sowie enge Zusammenarbeit mit Brand, Social, E-Commerce und weiteren internen Teams

## DAS MACHT DICH AUS

## Deine Qualifikationen als Influencer Marketing Manager DACH

- Ca. 2–4 Jahre Erfahrung im Influencer Marketing, idealerweise mit Performance-Fokus

- Social Media ist dein Alltag: Du bist nah an Trends, Formaten und der Creator-Szene, kennst die gängigen Plattformen und ihre Mechaniken und mindestens den deutschen Influencer-Markt sehr gut

- Du hast Spaß an Verhandlungen, gehst Deals effizient an und sprichst gerne mit Menschen – dabei bringst du ein gutes kommerzielles Verständnis mit

- Gutes Verständnis relevanter KPIs wie ROAS, CAC, Conversion und Revenue, Erfahrung darin, daraus konkrete Optimierungsmaßnahmen abzuleiten, sowie sicherer Umgang mit Excel / Google Sheets und datenbasierten Reportings

- Du hast ein gutes Gespür für Marke, digitale Trends und zielgruppenrelevanten Content und verstehst, dass Influencer und Communities am besten funktionieren, wenn sie einen klaren Use Case für yfood haben

- Du arbeitest strukturiert, eigenständig und hands-on, bist ein starker Team Player, hast Erfahrung mit oder Interesse an AI-Tools und bringst sehr gute Deutsch- und Englischkenntnisse mit

## WAS UNS ANTREIBT

**Wir sind ein bisschen anders – und genau das macht uns aus:**

- **Leidenschaft** – Wir brennen für das, was wir tun. Voller Energie, voller Optimismus, immer hungrig nach Neuem.

- **Verantwortung** – Heißt für uns: Füreinander einstehen, Verantwortung übernehmen und alles geben, wenn’s drauf ankommt.

- **Professionalität** – Wir nehmen unsere Arbeit ernst – uns selbst aber nicht zu sehr. Wir sind offen, direkt und immer auf Augenhöhe. Kein Bullshit, kein Ego. Nur Team.

- **Innovation** – Wir denken lieber „Warum eigentlich nicht?“ statt „Das war schon immer so.“ Wir lieben neue Ideen, unkonventionelle Wege – und bleiben nie stehen.

## (WH)yfood?

## Was wir dir bieten - Unsere Benefits

- **Wir fördern Chancengleichheit und schätzen Vielfalt.** Wir verpflichten uns, ein integratives Umfeld für alle Mitarbeitende zu schaffen.

- **yfood wächst international:** Obwohl Deutschland unsers „Home Base“ ist, haben wir mit unseren internationalen Märkten ein dynamisches und buntes Umfeld geschaffen, in dem viele spannende Themen auf Dich warten.

- **Agilität ist uns wichtig**. Daher arbeiten wir in einem hybriden Arbeitsmodell und bieten dir die Möglichkeit mit Workation aus dem EU-Ausland zu arbeiten.

- **Urlaub ist wichtig.** Daher erhältst du bei uns 30 Tage bezahlten Urlaub im Jahr.

- **yfood hält dich fit.** Mit einer subventionierten Mitgliedschaft bei EGYM-Wellpass kannst du dir für nur 29€ im Monat Gutes tun. Dazu bieten wir im Rahmen unseres Gesundheitsmanagements & Healthy@yfood Workshops und Aktionen (z.B. Yoga, Breathwork, Soccer, Pickleball) an.

- **Weg vom Fleck.** Wir steuern 30€ zu deinem ÖPNV-Ticket bei und bieten dir über JobRad die Möglichkeit, vergünstigt ein Fahrrad zu leasen.

- **Trainiere deine Geschmacksnerven.** Bei uns ist jeder der Lust hat Teil unseres Sensory-Teams. Probiere also neue Produkte, Sorten oder Geschmäcker vor allen anderen. Ansonsten gibt es so viel yfood wie du tragen kannst, natürlich auch für dich gratis.

- **Als Start-Up hat man oft mit Klischees zu kämpfen.** Manche sind aber auch wahr. Daher gibt es bei uns natürlich auch einen Obstkorb, deinen gratis Koffein-Kick oder das stille Wässerchen.

- **Come as you are**. Ob im Anzug oder Einhorn-Onesie. Einen Dresscode kennen wir nicht.

## KONTAKT

Katharina Bauer

Senior Talent Acquisition Manager

**Chancengleichheit für alle:** yfood steht für die Chancengleichheit aller ein. Wir begrüßen und feiern Vielfalt und setzen uns dafür ein, ein inklusives Arbeitsumfeld für alle Mitarbeiter:innen zu schaffen. Wir stehen allen Personengruppen offen, unabhängig von Alter, Hautfarbe, Herkunft, Ethnizität, Religion, Geschlecht, sexueller Orientierung, Geschlechtsidentität und/oder -ausdruck, Familienstand oder anderen gesetzlich geschützten Merkmalen.

Wir begrüßen Bewerbungen von Menschen mit Schwerbehinderung ausdrücklich.

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
