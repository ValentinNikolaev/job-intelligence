# Algorithm Engineer - Radar Tracking (m/f/d)

Posted: 2026-09-15T08:30:36Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

## Introduction

We are smartmicro, the leading specialist in high-performance automotive and traffic radar- and radar/camera hybrid sensor technology. We design, develop and manufacture high-tech sensors for autonomous driving, intelligent traffic infrastructure and smart cities. Our mission is to make roads safer, enable autonomous driving in all-weather scenarios, optimize traffic flow for reduced travel times and enable greener, smarter cities.

We are a German company with international presence in the UK and in the US, while we are headquartered in Braunschweig for design, development and production.

We make the future of mobility a reality.

We are looking for an experienced Algorithm Engineer for Radar Tracking.

## Your Tasks

In this role, you develop tracking and sensor fusion algorithms for radar and camera-based sensor systems used in intelligent traffic systems, smart mobility, ADAS-related applications, automated driving scenarios and airborne radar applications.

- You develop, implement and validate algorithms for multi-object tracking, sensor fusion and statistical signal processing

- You work on advanced tracking approaches such as extended object tracking, Bernoulli filters, Kalman filters, Bayesian filtering, probabilistic data association and related estimation methods

- You work with real radar, camera and radar/camera fusion data and analyze algorithm performance in realistic traffic, mobility and airborne scenarios

- You turn algorithmic concepts, prototypes and proof-of-concepts into robust, maintainable and testable software for product development and customer projects

- You improve robustness, accuracy, runtime behavior and reliability of tracking and fusion algorithms under challenging real-world conditions

- You define and use suitable test cases, metrics and validation methods to evaluate detection, tracking, fusion and object-level perception quality

- Depending on the project, your work may contribute to applications such as intelligent traffic infrastructure, ADAS, automated driving, drone detection, UAV/UAS tracking and airborne radar systems.

- You cooperate closely with embedded software, system engineering, testing and product teams to ensure reliable integration into our sensor platforms

- Your work contributes to safety-critical and high-performance radar applications, for example by improving traffic flow, protecting vulnerable road users and enabling robust radar-based perception in airborne use cases

## Your Strengths

We are looking for an engineer with proven professional experience in algorithm development, not only an academic background.

- You have completed a Master’s degree in Electrical Engineering, Computer Science, Robotics, Mathematics or a comparable technical field

- You have some years of full-time professional experience in industrial or commercial algorithm/software development after graduation (Internships, thesis work, student jobs and purely university-based projects do not count toward this requirement)

- You have practical experience with at least one of the following areas: multi-object tracking, sensor fusion, radar tracking, object-level fusion, nonlinear state estimation, statistical signal processing, perception algorithms or probabilistic methods

- You are confident in programming with Python and C or C++ and can write structured, maintainable and testable code

- You have a solid mathematical foundation, especially in linear algebra, statistics, probability theory, estimation theory and filtering methods

- Experience with radar systems, camera systems, automotive sensors, ADAS, automated driving, intelligent traffic systems, embedded systems, real-time applications, drone tracking, UAV/UAS applications, airborne radar or radar altimeters is a strong advantage

- Knowledge of tracking methods such as Kalman filters, EKF, UKF, particle filters, JPDA, MHT, Bernoulli filters, PHD filters or extended object tracking is beneficial

- You are able to analyze complex technical problems independently and convert your findings into reliable software solutions

- You work in a structured, delivery-oriented way and can balance technical quality with project constraints.

- You communicate clearly in English; German language skills are an advantage

## What you can expect from us

- **Innovation:** latest technology, innovation and rapid development cycles, excellent work- and test equipment

- **Pleasant working environment:** informal culture, motivated teams, short communication channels, room for active participation

- **Future-oriented workplace:** modern buildings, offices and labs, permanent employment and individual training opportunities

- **Attractive location:** located directly next to the highway, direct bus stop at our facilities, parking facilities for cars and bikes, free charging of electric vehicles

- **Flexible working:** hybrid working (4 days office presence per week)

- **Activities:** team events, gym membership and more

- **Other benefits**

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
