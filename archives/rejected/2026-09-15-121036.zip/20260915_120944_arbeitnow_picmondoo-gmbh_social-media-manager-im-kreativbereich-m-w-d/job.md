# Social Media Manager im Kreativbereich (m/w/d)

Posted: 2026-09-15T06:30:50Z

## Rejection

- Category: tech_stack
- Reason: role does not mention Go/Golang or PHP

Du kennst Social Media nicht nur aus der Theorie, sondern weißt aus eigener Erfahrung, welcher Content funktioniert, wie man Reichweite aufbaut und eine Community begeistert?

Dann suchen wir genau dich!

Für **Picmondoo®**, eine der bekanntesten Marken rund um Diamond Painting in Deutschland, suchen wir einen **Social Media Manager / Creator Coach (m/w/d)** mit einem besonderen Fokus auf die Betreuung und Weiterentwicklung unserer Creator.

Deine Aufgabe ist es nicht nur, selbst Social Media zu verstehen – du sollst dieses Wissen auch an unsere Creator weitergeben und ihnen dabei helfen, besseren Content zu produzieren, ihre Reichweite zu steigern und sich auf Social Media weiterzuentwickeln.

## Aufgaben

- Betreuung und Weiterentwicklung unserer nationalen und internationalen Creator

- Regelmäßiges Coaching unserer Creator rund um Instagram, TikTok und weitere Social-Media-Plattformen

- Analyse der bestehenden Creator-Accounts und ihrer Inhalte

- Konkretes Feedback zu Videos, Reels, Hooks, Storytelling, Bildsprache und Content-Aufbau

- Entwicklung individueller Strategien zur Steigerung von Reichweite, Engagement und Followerzahlen

- Vermittlung aktueller Social-Media-Trends und Best Practices

- Unterstützung unserer Creator bei der Entwicklung neuer Content-Ideen und Formate

- Durchführung von regelmäßigen Online-Meetings und Schulungen

- Erstellung von Guidelines, Briefings und Schulungsmaterialien für unsere CreatorIdentifikation neuer Trends und Übertragung auf den Kreativ- und Diamond-Painting-Bereich

- Enge Zusammenarbeit mit unserem Social-Media-, Creator- und Marketing-Team

## Qualifikation

- Du hast **sehr gute Kenntnisse im Bereich Social Media**, insbesondere Instagram und TikTokIdealerweise betreibst du selbst einen erfolgreichen Social-Media-Account oder hast bereits nachweislich Accounts aufgebaut

- Ein eigener Account im **Kreativ-, DIY-, Bastel-, Art- oder vergleichbaren Bereich** ist ein großes PlusDu verstehst, warum bestimmte Videos funktionieren und andere nicht

- Du kannst dein Wissen verständlich vermitteln und andere motivieren, sich weiterzuentwickeln

- Du hast ein gutes Gespür für Content, Trends, Storytelling und Zielgruppen

- Du kommunizierst gerne und hast Freude daran, mit unterschiedlichen Persönlichkeiten zusammenzuarbeiten

- **Fließendes Englisch ist Voraussetzung**, da du auch internationale Creator betreust

- **Französischkenntnisse sind ein großes Plus**, aber keine Voraussetzung

- Du arbeitest selbstständig, strukturiert und bringst eigene Ideen ein

## Benefits

- Eine Position in **Vollzeit oder Teilzeit**

- Eine kreative Rolle mit viel Gestaltungsspielraum

- Direkten Kontakt zu einer großen und aktiven Creator- und Kreativ-Community

- Die Möglichkeit, unsere Creator-Strukturen aktiv mit aufzubauen und weiterzuentwickeln

- Viel Eigenverantwortung und kurze Entscheidungswege

- Ein junges und unkompliziertes TeamRaum für eigene Ideen und neue Social-Media-Formate

- Einen Arbeitsplatz in einem wachsenden E-Commerce-Unternehmen

- Mitarbeiterrabatte auf unsere Produkte

Schick uns unbedingt direkt die Links zu deinen eigenen Social-Media-Accounts oder zu Accounts, an denen du bereits gearbeitet hast.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
