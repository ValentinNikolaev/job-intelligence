# Store Manager:in LAMOUR Crêperie Berlin

Posted: 2026-09-15T08:30:31Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Wir suchen keine Person, die unsere Crêperie nur führt.

Wir suchen die Person, die LAMOUR mit uns groß macht.

LAMOUR ist der Familientraum der Geschwister Joline und Robin.

Wir sind in Frankreich aufgewachsen, wo Crêpes einfach zum Alltag gehören, von den Crêperien der Bretagne bis zu den Straßenecken von Paris war das immer ein Stück Zuhause. Im September 2024 haben wir dieses Zuhause nach Berlin geholt und LAMOUR am Helmholtzplatz eröffnet. Ohne einen einzigen Tag Gastro-Erfahrung. Einfach gemacht.

Zwei Jahre später sind wir die Crêperie im Prenzlauer Berg. Fast 700 Google-Bewertungen. Sieben Tage die Woche offen. Ein Team aus 8 Leuten, das diesen Laden zu dem macht, was er ist. Prozesse, die stehen.

Und wir sind noch lange nicht fertig.

Bei uns bist du die Person, mit der wir entscheiden, wie es weitergeht.

Du führst nicht aus einem Büro heraus, sondern mittendrin

## Aufgaben

**Tasks**

**Ab Tag 1 gehört dir der Laden**

- Du führst unser Team von ca. 8 Mitarbeitenden – Einarbeitung, Feedback, Entwicklung.

- Du planst Dienste und Urlaube für einen Betrieb, der sieben Tage die Woche offen hat

- Du verantwortest den reibungslosen Ablauf: Öffnung, Stoßzeiten, Abschluss

- Du bestellst Ware, hältst Kontakt zu unseren Lieferanten und führst Inventuren durch

- Du sorgst dafür, dass Hygiene, HACCP und Arbeitssicherheit sitzen

- Du bist Gastgeber:in: Stammgäste, Gästefeedback, unsere Google-Bewertungen

- Du arbeitest im Tagesgeschäft mit. Immer.

**Und dann bauen wir weiter**

**- Zahlen: W**areneinsatz, Personalquote, Umsatz. Du drehst selbst an den Schrauben, statt sie nur zu melden

**- Prozesse: D**u baust Abläufe, die auch dann noch funktionieren, wenn wir größer sind

**- Team: D**u baust das Team, mit dem LAMOUR wächst – Recruiting, Einarbeitung, Standards

**- Umsatz: D**u entwickelst unser Liefergeschäft über Wolt, Lieferando und Uber Eats weiter

**- Deine Ideen: D**u bringst sie ein und setzt sie um.

**- Events: D**u gestaltest unsere LAMOUR Crêperie-Abende mit

**- Qualität: D**u hältst unser Niveau – Teig, Füllungen, unser Specialty Coffee, Sauberkeit, Atmosphäre

## Qualifikation

- Du hast Erfahrung in Gastronomie, Café, Bäckerei oder Food-Retail, idealerweise schon mit Führungsverantwortung. Schichtleitung reicht als Einstieg, wenn du den Rest wirklich willst

- Du kannst mit Zahlen umgehen: Wareneinsatz, Personalkosten und Umsatzsteuerung sind keine Fremdwörter für dich

- Du hast schon mal Dienstpläne gebaut und Personal koordiniert

- Du behältst den Überblick, auch wenn zwei Leute krank sind, drei Bestellungen offen sind und der Laden voll ist

- Du führst mit Herz und Klarheit. Struktur und Sicherheit statt Druck

- Du wartest nicht auf Ansagen. Du siehst, was fehlt, und machst es

- Du teilst unsere Leidenschaft für Crêpes, guten Kaffee und exzellenten Service

- Gute Deutsch- und Englischkenntnisse

- Bereitschaft zu Früh-, Spät- und Wochenenddiensten

- Gültige Belehrung nach § 43 IfSG (Gesundheitszeugnis) – oder die Bereitschaft, sie vor Arbeitsbeginn zu machen

Was du nicht mitbringen musst: eine Hotelfachschule, zehn Jahre Systemgastronomie oder einen perfekten Lebenslauf. Wir haben selbst bei null angefangen.

## Benefits

- **Ei**ne Rolle, die mit dir wächst.

- Direkt bei den Gründer:innen.

**- Ec**hte Mitgestaltung.

- Ein Team, das schon da ist.

- Zentrale Lage am Helmholtzplatz im Prenzlauer Berg

- Eigene Mitarbeiter-App für Dienstpläne und Kommunikation

- Faire Vergütung und Entwicklungsperspektiven

Ganz ehrlich: Das hier ist kein Job, bei dem man abends den Schlüssel umdreht und abschaltet. Das hier ist für jemanden, der Lust hat, etwas aufzubauen, das es so in Berlin noch nicht gibt.

Wenn du das beim Lesen gespürt hast: schreib uns.

Wir freuen uns auf dich!

Joline & Robin

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
