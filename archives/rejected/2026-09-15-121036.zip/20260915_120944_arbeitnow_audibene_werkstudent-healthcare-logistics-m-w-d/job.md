# Werkstudent Healthcare Logistics (m/w/d)

Posted: 2026-09-15T08:30:35Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**audibene** ist das am schnellsten wachsende Hörgeräte-Unternehmen aller Zeiten. Wir wissen, dass gutes Hören die Lebensqualität entscheidend erhöht. Mit unserem einzigartigen digitalen Geschäftsmodell haben wir die Art und Weise der Hörgeräte-Versorgung revolutioniert. Unser Ursprung und Hauptsitz liegen in Deutschland. In den letzten 14 Jahren haben wir uns zu einem international tätigen Unternehmen mit mehr als 1.200 Mitarbeiter: innen entwickelt: an 9 Standorten weltweit von Berlin bis Seoul. Um gut leben zu können, ist es wichtig, gut hören zu können. Das ist es, woran wir bei audibene glauben. Unser Ziel ist es, das Leben unserer Kund:innen nachhaltig zu verändern. Auf dieser spannenden Reise brauchen wir deine Hilfe.

Werde Teil unseres Teams und verhilf Menschen zu besserem Hören als **Werkstudent:in** in unserem Logistikteam!

## Das sind Deine Aufgaben:

- Systemische Vorbereitung von technischen Komponenten sowie Durchführung von Qualitätstests

- Bearbeitung von Bestellungen in unserem ERP System und Auswahl der richtigen Produkte aus dem Lager

- Erstellung von Versanddokumenten und Vorbereitung von Sendungen für ihren Versand

- Annahme, Reinigung und Einlagerung von Retouren sowie deren technische Erfassung in unserem ERP System

- Unterstützung bei administrativen Tätigkeiten in der Lagerlogistik

## Dein Profil

- Du befindest dich idealerweise im Studium

- Deine beruflichen Ziele und Interessen erleichtern dir die Einarbeitung in unsere Healthcare-Logistik

- Du bist an einer vertrauensvollen, langfristigen Zusammenarbeit und kontinuierlichen Weiterentwicklung interessiert

- Du arbeitest selbstständig, bist gut organisiert und legst großen Wert auf einen verantwortungsvollen Umgang mit unseren Produkten und Daten

- Du verfügst über fließende Deutschkenntnisse in Wort und Schrift sowie gute Englischkenntnisse

- Erste praktische Erfahrungen im Bereich Sachbearbeitung, Logistik, Customer Service oder Büroassistenz sowie eine absolvierte kaufmännische Ausbildung sind von Vorteil

## Das bieten wir Dir:

- Einen spannenden Arbeitsplatz in einem wachstumsstarken Unternehmen im Herzen Berlins

- Abwechslungsreiche und anspruchsvolle Aufgaben ab dem ersten Tag in unserem kompetenten und herzlichen Logistikteam

- Einblicke in die betrieblichen Abläufe unserer Logistik sowie in die speziellen Logistikprozesse im Gesundheitswesen

- Die Möglichkeit, in einem internationalen Unternehmen zu arbeiten, mit attraktiven Chancen für den Berufseinstieg

- Flexible Arbeitszeiten, sodass sich die Arbeit gut mit deinem Studium vereinbaren lässt

- Exklusive Mitarbeiterrabatte bei vielen bekannten Firmen

- Um fit und gesund zu bleiben, hast du mit Urban Sports Zugang zu über 50.000 Fitnessstudios und Sport-Einrichtungen

- Damit du immer gut an dein Ziel kommst, übernehmen wir für alle Mitarbeiter:innen das Deutschland-Ticket

- Als Teil des audibene Teams triffst du dich regelmäßig zu Team-Events und gemeinsamen Off-Sites, sowie zum audibene Wandertag

- Du arbeitest 3-4 Tage die Woche gemeinsam mit einem tollen Team in unserem Loft-Büro

Werde jetzt Teil eines motivierten und zielstrebigen Teams, das die Welt ein bisschen glücklicher machen möchte.

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
