# Data & Business Intelligence Specialist (m/w/d)

Posted: 2026-09-15T08:30:32Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Für ein **inhabergeführtes IT-Unternehmen mit mehr als 30 Jahren Erfahrung** suchen wir einen **Data & Business Intelligence Specialist (m/w/d)** in Vollzeit.

In dieser Position übernimmst Du eine zentrale Rolle rund um Datenanalyse, Business Intelligence und Datenintegration und entwickelst den unternehmensweiten Datenbereich gemeinsam mit dem DevOps-Team weiter.

Dabei arbeitest Du unter anderem mit **Power BI, Grafana, SQL und Datenplattformen** und sorgst dafür, dass aus unterschiedlichen Datenquellen verlässliche Informationen für Fachbereiche und Entscheidungen entstehen.

## Aufgaben

- Du verantwortest den unternehmensweiten Datenbereich und bist zentrale Ansprechperson für datenbezogene Fragestellungen

- Du analysierst Geschäftsanforderungen und entwickelst daraus Berichte, Dashboards und KPI-Visualisierungen, unter anderem mit **Microsoft Power BI und Grafana**

- Du konzipierst, entwickelst und pflegst umfangreiche **Datenmodelle**

- Du stellst eine zuverlässige **Datenintegration** zwischen internen und externen Systemen sicher

- Du etablierst und entwickelst Standards für **Datenqualität und Data Governance** weiter

- Du identifizierst datenbasierte Optimierungs- und Automatisierungspotenziale

- Gemeinsam mit den Fachbereichen entwickelst Du passende Datenlösungen für unterschiedliche Geschäftsanforderungen

- Du definierst technische Anforderungen und stimmst Dich mit dem DevOps-Team zur Umsetzung skalierbarer und sicherer Datenplattformen ab

- Du dokumentierst Datenmodelle, Datenquellen und Integrationen nachvollziehbar und strukturiert.

## Qualifikation

- Ein abgeschlossenes Studium oder eine Berufsausbildung im Bereich Informatik, Wirtschaftsinformatik, Data Science, Business Analytics oder eine vergleichbare Qualifikation

- Idealerweise rund **7 Jahre oder mehr Berufserfahrung** in Data Analytics, Business Intelligence, Data Solutions oder einem vergleichbaren Umfeld

- Erfahrung im Umgang mit großen Mengen strukturierter und unstrukturierter Daten

- Sehr gute Deutsch- und Englischkenntnisse in Wort und Schrift

- Die Fähigkeit, komplexe Datenzusammenhänge verständlich für technische und nicht-technische Ansprechpartner aufzubereiten

- Ein ausgeprägtes Verständnis für Datenqualität, Data Governance und kontinuierliche Verbesserung

**Besonders interessant sind Kenntnisse in mehreren dieser Technologien und Themen:**

- SQL sowie Datenbanktechnologien wie **Microsoft SQL Server, Azure SQL oder PostgreSQL**

- **Microsoft Power BI**

- **Microsoft Azure Data Platform**

- Elasticsearch

- ETL-Prozesse und ETL-Konzepte

- Data Warehousing

- Datenmodellierung nach gängigen Modellen und Best Practices

- Daten-APIs sowie gängige Datenformate und Datenstrukturen

Erfahrung aus der IT-, Telekommunikations- oder Managed-Services-Branche ist von Vorteil.

## Benefits

- Eine Festanstellung mit langfristigen Entwicklungsperspektiven

- 4 Tage Homeoffice pro Woche

- Flexible Arbeitszeit- und Arbeitsortmodelle

- Ein professionelles Arbeitsumfeld mit moderner technischer Ausstattung

- Ein familienfreundliches und flexibles Arbeitsumfeld

- Nationale und internationale Kunden sowie unterschiedliche Projekte und Serviceleistungen

- Möglichkeiten zur fachlichen Qualifizierung und persönlichen Weiterentwicklung

- Lademöglichkeiten für private Elektrofahrzeuge am Standort

**Klingt nach Deinem nächsten Karriereschritt?**

Dann freue ich mich auf Deine Kontaktaufnahme! Auch wenn Du nicht jede einzelne Anforderung zu 100 % erfüllst, melde Dich gerne – vieles lässt sich gemeinsam entwickeln oder aufbauen.

In einem persönlichen Gespräch stelle ich Dir das Unternehmen und die Position gerne näher vor.

Simona Dankova steht Dir jederzeit telefonisch unter +0211 / 54 55 87 19 zur Verfügung und begleitet Dich persönlich durch den gesamten Bewerbungsprozess.

Das Team der FlexIT Consulting GmbH freut sich auf Dich!

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
