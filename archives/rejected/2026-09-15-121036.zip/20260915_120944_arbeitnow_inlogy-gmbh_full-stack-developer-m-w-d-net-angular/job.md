# Full-Stack-Developer (m/w/d) .NET/Angular

Posted: 2026-09-15T08:30:34Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**PROBLEMLÖSER GESUCHT**

Technische Herausforderungen meistern, innovative Lösungen entwickeln und echte Probleme unserer Kunden lösen: genau das macht die Arbeit bei uns aus.

Als **Full-Stack-Developer** wirst du Teil eines Teams, das kreative Köpfe mit Leidenschaft für clevere Softwarelösungen vereint. Bei uns findest du die perfekte Mischung aus Eigenverantwortung, Teamwork und der Möglichkeit, spürbare Mehrwerte zu schaffen.

## Aufgaben

**UNSERE CHALLENGE**

- **Entwickle** komplexe Lösungen mit C#/.NET und modernen Webtechnologien wie Angular, SignalR oder React – sowohl eigenständig als auch im Team

- **Integriere** neue Anwendungen und Module in bestehende Systeme und **analysiere** IT-Prozesse sowie Softwarearchitekturen

- **Kommuniziere** sicher mit Kunden, **kläre** technische Anforderungen und **präsentiere** geeignete Lösungsansätze

- **Erstelle** automatisierte Tests (z. B. Unit- und Integrationstests) und **dokumentiere** Anwendungen sowie Prozesse nachvollziehbar

- **Plane** Sprints und **pflege** Backlog-Elemente in Azure DevOps zur effizienten Steuerung der Projektabläufe

## Qualifikation

**DEINE LÖSUNGSKOMPETENZ**

- Praktische Erfahrungen in der Entwicklung mit .NET (C#) und Angular

- Erste Erfahrungen mit Azure-Services und Docker oder vergleichbaren Technologien

- Fließende Deutsch- und Englischkenntnisse für die Kommunikation im Team und mit Kunden

- Strukturierte, eigenständige und lösungsorientierte Arbeitsweise

- Verständnis für saubere Softwarearchitektur und Testbarkeit)

## Benefits

**WORAUF DU DICH FREUEN KANNST**

- Offene Gehaltsstruktur

- Flexible Arbeitszeiten und Homeoffice

- Ein motiviertes, kollegiales Team mit echter Wertschätzung

- Spannende, abwechslungsreiche Projekte statt Routineaufgaben

- Regelmäßige Team-Events und eine offene Feedbackkultur

- Moderne Technologien und Tools, die dich in deiner Arbeit unterstützen

**DEIN WEG ZU UNS**

- **Bewirb dich:** Schick uns dein Profil, das deine IT-Kenntnisse auf den Punkt bringt.

- **Lass uns sprechen:** Lerne uns in einem ersten Gespräch kennen. Wir gestalten es offen und partnerschaftlich

- **Dein Start:** Beginne deinen neuen Job und werde mit uns Problemlöser.

Talent Sourcer der

INLOGY GmbH

Besuche gern unsere Website: www(dot)inlogy(dot)de

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
