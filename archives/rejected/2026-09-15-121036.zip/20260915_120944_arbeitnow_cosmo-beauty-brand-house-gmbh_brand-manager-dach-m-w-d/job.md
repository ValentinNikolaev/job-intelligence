# Brand Manager DACH (m/w/d)

Posted: 2026-09-15T09:00:33Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Wir sind ein vielfältiges Team von Schönheitsenthusiasten aus der ganzen Welt, die sich für ein integratives und unterstützendes Arbeitsumfeld einsetzen, in dem sich jeder wertgeschätzt und respektiert fühlt.

Als führende internationale Schönheitsmarke haben wir uns zum Ziel gesetzt, qualitativ hochwertige Produkte anzubieten, die den Menschen helfen, ihren einzigartigen Sinn für Stil zu stärken. Unser innovativer und dynamischer Ansatz hat uns zur ersten Wahl für Schönheitssalons und Geschäfte weltweit gemacht. Bei uns dreht sich alles um Kreativität und individuelles Wachstum. Wir ermutigen unsere Teammitglieder, mutig zu sein und über den Tellerrand hinauszuschauen.

Dein Herz schlägt für Themen rund um UV Nagellack, Care sowie Beauty und du hast ein Gespür für die neuesten Trends? Dann bist du bei uns genau richtig! Wir suchen für die Rolle als **Brand Manager DACH (m/w/d)** eine flexible und engagierte Person, die Lust hat, unsere Marken gemeinsam mit uns in Berlin zu gestalten und weiterzubringen.

## Tasks

- Du bist verantwortlich für die **Weiterentwicklung der Markenstrategie** und arbeitest kontinuierlich an der richtigen Markenpositionierung und Markenidentität unserer Brands.

- Mit deinem hohen Gespür für Trends entwickelst du gemeinsam mit dem **Produktteam innovative Konzepte und Kollektionen**.

- Du verantwortest die **Planung, Steuerung und Umsetzung der Go-to-Market-Pläne für den DACH-Markt sowie von 360°-Marketingkampagnen und Produktlaunches** – von der Konzeption bis zur kanalübergreifenden Aktivierung und Erfolgskontrolle.

- Du übernimmst das **Projektmanagement für deine Kampagnen und Launches** und behältst Timings, Milestones, Budgets und Deliverables im Blick.

- Du sorgst für eine **konsistente Kommunikation über alle relevanten internen und externen Kommunikationskanäle** hinweg und arbeitest dabei eng mit Social Media, Influencer Marketing, E-Commerce und PR zusammen.

- Du entwickelst und steuerst **POS- und Retail-Aktivierungskonzepte für deine Kampagnen und Produktlaunches**, insbesondere Hotspots und Secondary Sites, und arbeitest bei der Umsetzung eng mit **Visual Merchandising** zusammen.

- Du steuerst **externe Agenturen und Freelancer** vom Briefing bis zur Umsetzung und stellst Qualität, Timing und Budgeteinhaltung sicher.

- Du arbeitest eng mit **Product, Sales, E-Commerce, Retail Marketing, Performance Marketing sowie relevanten internationalen Stakeholdern** zusammen.

- Du analysierst relevante **Marken-, Kampagnen- und Business-KPIs**, wie Sell-in, Sell-out und Sell-through, und leitest daraus konkrete Maßnahmen ab.

## Requirements

- Ausbildung oder Studium im Bereich Marketing / PR / Communications.

- Mindestens **2–3 Jahre Berufserfahrung in einer vergleichbaren Position mit Fokus auf Beauty**.

- Erfahrung in der **Planung und Umsetzung von Marketingkampagnen und Produktlaunches sowie im Projektmanagement**.

- Erste Kontakte zu Distributoren oder Erfahrungen mit dem stationären Handel von Vorteil.

- Du bist kreativ und neugierig und liebst es, Ideen zu entwickeln und umzusetzen.

- Dabei denkst du strategisch – unsere Mission und Zielgruppe immer im Blick.

- Du hast zündende kreative Ideen und Ansätze, unsere Produkte und Mission zu teilen.

- Auf dein Gespür für Gestaltung, Text & Sprache ist Verlass.

- Du bist sicher in Deutsch und Englisch gleichermaßen.

- Du arbeitest am liebsten eigenständig und organisiert und willst selbst gestalten.

- Vor-Ort-Präsenz in Berlin notwendig (mit flexibler Home Office Regelung).

## Benefits

- **Spannende Projekte in einem agilen Umfeld:** Bei Cosmo Beauty Brand House hast du die Chance, zu glänzen und wirklich etwas zu bewegen. Mit dem Fokus auf „Moments that matter“ und einer außergewöhnlichen Mitarbeitererfahrung kannst du den DACH-Markt mitgestalten und uns helfen, zu einer bedeutenden Größe zu werden!

- **Ein Ort voller Kreativität und Inspiration:** Unser pulsierendes Büro im Herzen Berlins bietet dir hervorragende Anbindung an die öffentlichen Verkehrsmittel und die Flexibilität des hybriden Arbeitens für eine ausgewogene Work-Life-Balance.

- **Persönliche und berufliche Entwicklung ab Tag eins:** Bei uns kannst du dich vom ersten Tag an weiterentwickeln, an internationalen Projekten mitwirken und zum Wachstum unserer Marke beitragen.

- **Eigenverantwortliches Arbeiten:** Wir bieten dir die Freiheit, dich so zu entfalten, wie es dir am besten liegt, und Verantwortung zu übernehmen. Eigeninitiative wird bei uns großgeschrieben!

- **Flexibles Hybrid-Modell:** Die Möglichkeit, Büroarbeit und Home Office flexibel miteinander zu kombinieren.

- **Mobilität & Lifestyle:** Wähle zwischen einem Zuschuss zum öffentlichen Nahverkehr oder einer Edenred-Sachbezugslösung / Urban Sports Club.

- **Beauty Benefits:** Mitarbeiterrabatte auf unsere Produkte und die Möglichkeit, unsere neuesten Beauty-Produkte selbst kennenzulernen und zu testen.

- **Gemeinsam statt nur arbeiten:** Regelmäßige Firmen- und Teamevents sowie ein internationales Arbeitsumfeld.

- **Mitarbeiter-werben-Mitarbeiter-Programm:** Empfehlungsbonus für erfolgreiche Mitarbeiterempfehlungen.

Bereit, unsere Marken im DACH-Markt mitzugestalten und mit kreativen Ideen, starken Kampagnen und erfolgreichen Produktlaunches weiter voranzubringen? Dann bewirb dich jetzt und werde Teil unserer Beauty-Erfolgsgeschichte!

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
