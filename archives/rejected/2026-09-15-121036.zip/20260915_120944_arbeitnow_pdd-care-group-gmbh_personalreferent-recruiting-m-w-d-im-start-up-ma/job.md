# Personalreferent / Recruiting (m/w/d) im Start Up Management

Posted: 2026-09-15T08:30:32Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Wir, die Junior-Senior Gruppe, suchen für den nächstmöglichen Zeitraum eine engagierte und motivierte Kollegin/Kollegen im Recruiting Bereich in Vollzeit (40 Wochenstunden). Wir sind ein Start Up Unternehmen aus dem Jahr 2021. Wenn du gerne selbst mitgestaltest und kreativ arbeitest, in lockerer Arbeitsatmosphäre, dann bist Du bei uns genau richtig! Du hast bei uns sehr hohe Aufstiegschancen und bieten Dir eigenen Gestaltungsfreiraum.

**Über uns:**

Wir sind ein anerkannter Betreuungsdienst in Berlin. Unsere Angebote zur Betreuung im Alltag richten sich an pflege- und betreuungsbedürftige Menschen und an deren Angehörige, sowie vergleichbar nahestehende Pflegepersonen. Insbesondere haben wir uns zum Ziel gesetzt, die Angehörigen zu entlasten und für die Betroffenen einen abwechslungsreichen Aufenthalt in den eigenen vier Wänden durch die Dienstleistungen zu gewähren.

Deine Aufgabe als Recruiter ist die Organisation, Begleitung, Beschaffung und Steuerung unseres Betreuungspersonals. Du wirst in Eigeninitiative Bewerbungsgespräche führen und neue verabreden. Des weiteren wirst du bei Langzeitprojekten mitwirken.

## Aufgaben

**Deine Aufgaben:**

- Bewerbungsgespräche führen

- Bewerbungsprozess von Anfang bis Ende begleiten

- Bewerbungen prüfen

- Bewerbungsgespräche organisieren

- Briefe schreiben und frankieren

- Zusammenarbeit mit der Bundesagentur für Arbeit und dem Jobcenter

- Sonderaufträge / Projekte zur Unterstützung der Geschäftsführung

- Personalsachbearbeitung (Gehaltsauswertung etc.)

- Urlaubsplanung & Personal An- sowie Abmeldung

- Personalgespräche führen

- Personalmarketing

- Zusammenarbeit mit dem Lohnbüro

- Korrespondenz mit Behörden, Ämtern etc.

## Qualifikation

**Das bringst Du mit:**

- mindestens einen guten Realschulabschluss

- eine abgeschlossene kaufmännische Ausbildung im Bereich Personalwesen, Büromanagement, Bürokommunikation, E-Commerce, Industriekaufmann, oder vergleichbares

- Spaß am realen und telefonischen Kontakt mit Bewerbern, Kunden und externen Kooperationspartnern, sowie Kolleginnen und Kollegen

- Eine schnelle Auffassungsgabe

- Sehr gute Kenntnisse in Microsoft 365 Office (Teams, Outlook, Word, Excel und Co.).

- Kreativität und spaß an Problemlösungen zu arbeiten.

- Freude am Organisieren von Projekten

- Freude an eigenverantwortlicher Sachbearbeitung

## Benefits

**Das bieten wir Dir:**

- 30 Tage Urlaub

- Zuschuss zum Deutschland Ticket

- Diverse Entwicklungsmöglichkeiten

- Microsoft Office Lizenzen (Teams, Outlook, Word, Excel)

- Gleitarbeitszeit

- Eigener Gestaltungsfreiraum in einem jung dynamisch wachsendem Unternehmen

- eine selbstständige, abwechslungsreiche und verantwortungsvolle Tätigkeit

- moderner Arbeitsplatz

- umfangreiche Fortbildungsmöglichkeiten und Aufstiegschancen

Sei dabei, unsere HR-Strategien in einem dynamischen Start-up zu gestalten. Bewirb dich jetzt als Personalreferent / Recruiting (m/w/d) und wachse mit uns!

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
