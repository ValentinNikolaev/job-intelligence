# Ausbildung zum Kaufmann/Kauffrau für E-Commerce (m/w/d) für folgenden Standort: Gersthofen

Posted: 2026-09-15T09:00:37Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Was will ich werden?

Während deiner Ausbildung bereiten dich erfahrene Ausbilder Schritt für Schritt auf eine Zukunft in unserem Unternehmen vor. Beim Durchlaufen der verschiedenen Abteilungen wie Vertrieb, Logistik oder Finanzbuchhaltung, lernst du dabei die einzelnen Bereiche des Unternehmens kennen.

Bei regelmäßig stattfindenden Team Events treffen sich „Azubi’s“ aus den verschiedenen Standorten um sich kennenzulernen und gemeinsam spannende Teambuilding Aufgaben zu meistern.

Engagierten Schulabgängern bieten wir eine sichere Zukunft in einem spannenden Team mit sehr guten Übernahmechancen in die Stammbelegschaft bei guten Leistungen.

„Mit dem Start einer Ausbildung legst du einen wichtigen Grundstein für deine weitere berufliche Laufbahn.“

## Aufgaben

Du beurteilst, wählst aus und setzt Vertriebskanäle des E-Commerce ein • Du konzipierst Waren- oder Dienstleistungssortimente für den E-Commerce, bewirtschaftest sie online und entwickelst sie weiter • Wendest projektorientierte Arbeitsweisen im E-Commerce an • Gestaltest Kundenkommunikation • Du setzt kennzahlenbasierte Instrumente der kaufmännischen Steuerung im E-Commerce ein • Bereitest Maßnahmen des Onlinemarketings vor und führst sie durch • Du bahnst Online-Waren- und Dienstleistungsverträge an • Wickelst Online-Waren- und Dienstleistungsverträge ab

Betriebliche Ausbildung:

In der dreijährigen Ausbildungszeit arbeitest du mit folgenden Abteilungen unseres Betriebes zusammen:

•Einkauf

•Verkauf

•Marketing

•IT-Abteilung

Schulische Ausbildung:

Die schulische Ausbildung findet in der Berufsschule in Lauingen statt.

## Qualifikation

... Online-affin sein.

... Gut mit Zahlen und Daten umgehen können.

... Interesse an Online-Marktplätzen haben.

... Wissen wie Online-Shops funktionieren.

## Benefits

•Anspruchsvolle Tätigkeiten

•Motiviertes und kollegiales Team

•Umfangreiche betriebliche Sozialleistungen

•Fort- und Weiterbildungsmöglichkeiten

Haben wir dein Interesse geweckt?

Dann freuen wir uns auf deine Bewerbung!

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
