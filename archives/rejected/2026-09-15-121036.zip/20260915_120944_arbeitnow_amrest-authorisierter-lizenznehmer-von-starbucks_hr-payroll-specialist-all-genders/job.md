# HR Payroll Specialist (all genders)

Posted: 2026-09-15T07:30:52Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**“Service is our recipe for winning”**

Wir sind mehr als 50.000 Menschen in 23 Ländern auf der ganzen Welt. Wir sind ein globales Unternehmen, das sich von einem globalen Ziel leiten lässt und fest davon überzeugt ist, dass wir die Herzen der Menschen durch einen hervorragenden Service gewinnen können.

AmRest Deutschland ist eine Tochtergesellschaft der AmRest Holdings SE, dem größten unabhängigen Restaurantbetreiber in Zentral- und Osteuropa mit einer wachsenden internationalen Präsenz und einem Portfolio von bekannten, starken Marken wie KFC, Pizza Hut, Burger King und Starbucks, das auf Franchise, Lizenzpartnern und Joint Venture Partnerschaften basiert. In Deutschland betreibt AmRest als Lizenzpartner mehr als 130 Starbucks Stores mit über 1700 Mitarbeitern und 25 KFC Restaurants mit ca. 750 Mitarbeitern. Unser Restaurant Support Team hat seinen Sitz in München mit etwa 150 Mitarbeitern.

## Aufgaben

- Eigenständige Bearbeitung von administrativen Personalaufgaben (z.B. Vertragserstellung, Erstellung von Zeugnissen und diversen Bescheinigungen, etc.)

- Bearbeitung der abrechnungsrelevanten Unterlagen zur Vorbereitung für die externe Gehaltsabrechnung

- Erster Ansprechpartner für das Store Management im Hinblick auf administrative Fragen und Umsetzung auf operativer Ebene

- Sicherstellung einer korrekten Gehaltsabrechnung mit dem externen Abrechnungsdienstleister

- Pflege der Personalakten & des Zeiterfassungssystems

- Verantwortung und Mitarbeit bei HR-Projekten

- Vorbereiten und Halten von Workshops für das Store Management zu administrativen wie rechtlichen Sachverhalten

- Bereitstellung von Auswertungen & Personaldaten

- Stetige, gemeinsame Prozessoptimierung aller administrativen HR-Abläufe

- Anpassen & Umsetzung neuer gesetzlicher und organisatorischer Richtlinien

## Qualifikation

- Eine erfolgreiche abgeschlossene kaufmännische Ausbildung oder Studium

- Erste Erfahrung in Personalwesen

- Gute Kenntnisse im Sozialversicherungs- und Lohnsteuerrecht

- Gute Kommunikationsfähigkeit mit internen & externen Abteilungen

- Ausgeprägte Team- und Dienstleistungsfähigkeiten

- Cross-funktionale Zusammenarbeit mit den Kollegen innerhalb der Matrixorganisation verschiedener Abteilungen

- Effektive Arbeitsweise in einer schnelllebigen Umgebung

- Ein routinierter Umgang mit gängiger Software (MS-Office, besonders Excel) sowie mit Online-Anwendungen

- Sehr gute Deutsch- und Englischkenntnisse in Wort und Schrift

## Benefits

- Personalisiertes Vergütungspaket & performancebasierter Bonus

- Wöchentliches Coffee Benefit

- Vielfältige Aufgabenbereiche im HR Department

- Motivierende & familiäre Arbeitsatmosphäre

- Schnelle berufliche & persönliche Entwicklung

- Flexible Arbeitszeiten

- Zuschuss zum Deutschlandticket

- JobRad - Leasing

- Zuschuss zur betrieblichen Altersvorsorge

- voiio (Work-Life-Balance Online-Plattform)

- Möglichkeit zum mobilen Arbeiten

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
