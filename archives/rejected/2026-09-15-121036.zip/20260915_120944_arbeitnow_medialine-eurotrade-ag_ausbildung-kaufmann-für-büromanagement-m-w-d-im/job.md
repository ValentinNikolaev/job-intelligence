# Ausbildung Kaufmann für Büromanagement (m/w/d) im IT Systemhaus

Posted: 2026-09-15T07:30:52Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Diese Position ist für unsere Tochtergesellschaft interface systems GmbH zu besetzen.

Du bist ein echtes Organisationstalent und nichts bringt Dich so schnell aus der Ruhe? Du hast Freude an der Kommunikation mit Anderen und die Arbeit am PC bereitet dir Spaß?

Dann freuen wir uns auf Dich!

## Aufgaben

Während Deiner Ausbildung lernst Du die unterschiedlichen kaufmännischen Bereiche unseres Unternehmens kennen und erhältst einen umfassenden Einblick in die Abläufe eines modernen IT-Unternehmens.

- Kennenlernen verschiedener Fachbereiche wie Inside Sales, Vertrieb, Office Management, Personal und Buchhaltung

- Unterstützung bei der Auftragssteuerung und -koordination – von der Auftragserfassung bis zur Auslieferung

- Bearbeitung und Weiterleitung von Rechnungen sowie Überwachung von Zahlungseingängen

- Einholen von Herstellerkonditionen und Erstellung von Kundenangeboten

- Überwachung und Koordination von Lieferprozessen

- Unterstützung bei der kaufmännischen Steuerung und Kontrolle von Geschäftsprozessen

- Kennenlernen und Mitwirken bei kaufmännischen Abläufen

- Kommunikation und Zusammenarbeit mit Kunden, Lieferanten und internen Fachbereichen

- Organisation und Bearbeitung von allgemeinen Büro- und Verwaltungsaufgaben

- Teilnahme an der dualen Ausbildung: Theorie an der AFBB gGmbH in Dresden, Praxis in unserem Unternehmen in Dresden

Im Rahmen der Ausbildung absolvierst Du ein vierwöchiges Auslandspraktikum in Irland oder Spanien.

## Qualifikation

- Organisationstalent und Spaß an der Kommunikation mit Kollegen, Kunden und Dienstleistern

- Du hast Dein (Fach-) Abitur in der Hand und

- gute Noten in Deutsch, Mathematik und Englisch, vorzugsweise auch in Informatik

- ein persönlicher Bezug zur IT ist vorteilhaft (Gaming, Home-Server, Technik-Affinität, o.ä.)

- guter Umgang mit dem MS Office Paket, insbesondere Outlook, Word und Excel

- Du bist teamfähig, arbeitest aber auch gern eigenverantwortlich, bist belastbar und gut organisiert

- auch in stressigen Situationen behältst Du stets einen klaren Kopf

- Du verfügst über sehr gute Deutschkenntnisse in Wort und Schrift sowie gute Englischkenntnisse

## Benefits

Was wir bieten:

-

Übernahme des Schulgeldes (AFBB GGmbH)

-

Übernahme des Bildungstickets

-

Zuschuss zum Fitness-Studio

-

Mitarbeiter-Events

-

Mitarbeiterrabatte

-

warme und kalte Getränke

-

Müsli-Bar

-

zahlreiche Möglichkeiten zur fachlichen und persönlichen Weiterentwicklung

-

abwechslungsreiche Tätigkeit in einem engagierten und kollegialen Team

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
