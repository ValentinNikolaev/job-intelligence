# Office Manager (m/w/d)

Posted: 2026-09-15T08:40:06Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**Deine Rolle

**Als **Office Manager (w/m/d)** bist du das Herzstück unseres Berliner Offices. Du sorgst dafür, dass im Hintergrund alles funktioniert und sich Kolleg, Kund und Gäste rundum wohlfühlen.

Du denkst voraus, behältst den Überblick und packst selbst mit an – vom täglichen Office-Betrieb über Events bis hin zu größeren Projekten wie Umzügen oder Umbauten.

**Was machst du dabei konkret?**

**Du hältst unser Office am Laufen.** Du koordinierst Hausverwaltung, Vermieter, Handwerker und Dienstleister und kümmerst dich um alles, was einen reibungslosen Office-Alltag ausmacht – von Meetingräumen, Bestellungen und Post bis zu Dokumentationen, Reisebuchungen, Rechnungen und Belegen. Auch ausgewählte Themen für unser Münchener Office liegen bei dir.

**Du bist Gastgeber und bringst Menschen zusammen.** Du empfängst Kund und Gäste, bereitest Meetings und Catering vor und sorgst dafür, dass unser Office ein Ort ist, an dem man gerne zusammenkommt. Dazu gehören auch unsere internen Events, All Hands sowie die kleinen Dinge, die unsere Office Culture ausmachen – von Geburtstagen bis Merchandise.

**Du sorgst für einen großartigen Employee Lifecycle.** Gemeinsam mit IT und den relevanten Teams organisierst du ein reibungsloses On- und Offboarding und kümmerst dich um organisatorische Themen rund um Wellbeing und Arbeitssicherheit.

**Du übernimmst Projekte und packst an.** Ob Event, Umbau oder Umzug: Du koordinierst Timelines, Budgets und Beteiligte und sorgst dafür, dass es läuft. Und wenn eine Glühbirne gewechselt oder ein Griff festgeschraubt werden muss, machst du das auch einfach selbst.

**Das bringst du mit:**

**Background
**Du hast eine abgeschlossene kaufmännische Ausbildung, eine Ausbildung in Hotellerie, Gastronomie oder Eventmanagement oder einen vergleichbaren Hintergrund. Entscheidend ist für uns aber nicht dein konkreter Abschluss, sondern dass du bereits relevante praktische Erfahrung mitbringst.

**Skills und Qualifikationen:**

-

Du hast Erfahrung im **Office Management, Workplace Management, Hospitality, Eventmanagement** oder in einer vergleichbaren Rolle.

-

Du kommunizierst **fließend auf Deutsch und Englisch** und fühlst dich mit digitalen Tools wohl.

-

Du bist stark in **Organisation und Koordination** und kannst mehrere Themen gleichzeitig souverän steuern.

-

Erfahrung aus **Hotellerie, Gastronomie, Events oder Projektmanagement** ist ein Plus.

**Mindset**

**Hospitality & Service:** Du hast Freude daran, dass sich andere willkommen und gut aufgehoben fühlen, und hast ein Auge für die Details, die den Unterschied machen.

**Ownership & Hands-on:** Du siehst, was zu tun ist, übernimmst Verantwortung und findest pragmatische Lösungen – selbst oder mit den richtigen Leuten.

**Organisation & Ruhe:** Du behältst auch dann den Überblick, wenn fünf Dinge gleichzeitig passieren, setzt Prioritäten und sorgst dafür, dass nichts liegen bleibt.

**Gut zu wissen:**
Die Position ist in Vollzeit (40 Std./Woche) und wird vor Ort in unserem Berliner Office ausgeübt – so bist du mittendrin im Team und im täglichen Austausch mit deinen Kolleg:innen. Deinen Starttermin stimmen wir flexibel mit dir ab.

*Du erfüllst nicht alle Anforderungen? Bewirb dich trotzdem bei uns! Wir sind gespannt auf deine Bewerbung!*

*
***Das bieten wir dir:**

**Vielfalt: **Flache Hierarchien und kulturelle Offenheit machen dich ab Tag 1 zum integralen Bestandteil unseres bunten Teams aus internationalen Talenten.

**Flexibilität:** Wir machen dein Leben nicht kompliziert. In flexiblen Arbeitsmodellen, Arbeitszeiten und Mobile-Working-Regelungen findest du die richtige Balance. 28 Tage Urlaub und 2 zusätzliche freie Tage am 24. und 31.12. verschaffen dir zudem entspannte Auszeiten.

**Wertschätzung: **Du gestaltest mit uns die Zukunft des digitalen Wealth Managements in einem innovativen, mehrfach ausgezeichneten Unternehmen auf Wachstumskurs, mit hoher Marktrelevanz und viel Raum für deine Ideen.

**Entwicklung: **Wir unterstützen deine persönliche und fachliche Entwicklung mit einem jährlichen Development-Budget von 1.500€. Außerdem erhältst du zu Beginn deiner Tätigkeit bei LIQID ein hochwertiges Equipment, bestehend aus MacBook, Kopfhörern und Display.

**Smart Money:** Als LIQIDian erhältst du attraktive Konditionen für unsere Anlagestrategien, einen monatlichen Lunch-Zuschuss und exklusive Discounts bei verschiedenen Anbietern.

**Wohlbefinden:** Regionale Bio-Produkte halten Dich vor Ort im Office fit – und unsere Gesundheitsinitiativen oder unser Health Assistance Programm auch weit darüber hinaus.

**So geht es für dich weiter**

Eine ausgezeichnete Candidate Experience und Transparenz haben für uns im Interviewprozess die höchste Priorität. Die verschiedenen Bewerbungsphasen helfen uns zu verstehen, wie eine Zusammenarbeit aussehen könnte.

-

Erstes Kennenlernen mit unserem Recruiting-Team via Videocall.

-

Videointerview mit deiner zukünftigen Führungskraft: Wir tauschen uns aus, ob deine Erfahrungen und Erwartungen an die Position mit unseren Anforderungen übereinstimmen.

-

Persönliches Kennenlernen: Du triffst das Team und erhältst praktische Einblicke in die Arbeit im Office Management

**Über uns**

Wir sind LIQID, einer der führenden digitalen Vermögensverwalter in Europa und eines der am schnellsten wachsenden deutschen Fintechs. Unsere Mission ist es, gleiche Bedingungen für wohlhabende Anlegerinnen und Anleger zu schaffen, indem wir ihnen Zugang zu Expertise und Anlagelösungen ermöglichen, die ihnen bisher verschlossen waren. Dabei setzen wir auf ein Gleichgewicht zwischen Mensch, Umwelt und Profit.

Wir bieten unseren Kundinnen und Kunden umfassende Anlagelösungen – von erstklassiger Vermögensverwaltung bis hin zu kuratierten Portfolios aus den weltweit besten Private-Equity- und Venture-Capital-Fonds. Mit einem verwalteten Vermögen von über 3,8 Milliarden Euro gehören wir schon jetzt zu den führenden Vermögensverwaltern in Deutschland. In unserer weiteren Entwicklung arbeiten wir mit starken und erfahrenen Partnern wie [LGT](https://www.lgt.com/de/), [Toscafund](https://www.toscafund.com/), [HQ Trust](https://www.hqtrust.de/de) und [Project A](https://www.project-a.com/) zusammen.

*LIQID ist ein Arbeitgeber, der für Chancengleichheit steht. Alle qualifizierten Bewerbungen werden ohne Rücksicht auf Hautfarbe, Alter, Religion, Geschlecht, ethnische und nationale Herkunft, Behinderung oder aufgrund von anderen durch Gleichbehandlungsgesetze geschützte Eigenschaften berücksichtigt.*

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
