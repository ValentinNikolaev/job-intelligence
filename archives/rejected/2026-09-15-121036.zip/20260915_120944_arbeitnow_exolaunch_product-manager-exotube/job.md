# Product Manager - EXOtube

Posted: 2026-09-15T08:09:57Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**Introduction**

Curious about supporting a team working on real launch missions? Then Exolaunch might be the perfect place for you.

Exolaunch is a global leader in launch mission management, satellite integration and satellite deployment technologies. With a decade of flight heritage and over **830 satellites** launched across **48** missions to date, Exolaunch leverages industry insight to tailor turnkey solutions that meet customer needs and respond to market trends. The company fulfills launch contracts for industry leaders, the world's most innovative startups, research institutions, government organizations, and international space agencies.

Key to our success is a combination of an expert Mission Management team, our growing portfolio of in-house designed and market leading separation systems, and our rideshare structures including **EXOtube**. Rideshare structures are the answer to a growing diversification of launch opportunities coupled with a market seeking flexible and agile access to space for a growing number of satellite constellations. The **EXOtube Product Manager **is a multi-faceted role which combines technical management of complex development and launch planning projects with customer and market facing Business Development and Sales work. You will be coordinating the development and qualification of **EXOtube projects**, becoming intimately familiar with how our products function and how we execute our missions. You will also help the business team in marketing and selling EXOtube projects, shaping how it is seen on the market and helping us identify market demand.

Your role is based at our headquarters in **Berlin, Germany**. The ideal candidate for this role has a background in space technology, structural design and environmental testing for space, is an excellent communicator and team player, and is passionate about being part of a dynamic team that is driving the satellite industry forward.

**Your mission**

-

Manage the requirements, design, qualification and launch planning of **EXOtube projects**.

-

Lead **communication with customers** and ensure a fluent progression of the project.

-

Help develop concepts for **Ground Support Equipment** and test hardware and coordinate with suppliers.

-

Plan and participate in test and launch campaigns internationally.

-

Create and maintain **documentation **incl. User Manuals, Sales materials, technical reports and internal and external procedures.

-

Work hand-in-hand with the **Sales team **to answer prospect’s questions regarding Exolaunch’s capabilities and services, including EXOtube’s compatibility with different launch vehicles and other Exolaunch products.

-

Solidify and expand upon Exolaunch’s commitment to **customer care and service excellence**.

-

Write **proposals **alongside the business team to bid for the hardware development and launch of satellite constellations.

-

Attend **space conferences and industry events **– represent Exolaunch at the highest professional level

-

Gather **customer requirements** and work with the engineering teams to iterate on and improve Exolaunch product offerings and cultivate new business opportunities.

**Your profile**

-

Bachelor’s or Master’s degree in structural, mechanical or space engineering or a similar field.

-

5+ years of engineering work experience.

-

Experience in customer-facing work and sales work.

-

Excellent written and spoken English.

-

Excellent technical communication skills.

-

Strong experience in working with CAD software such as SolidWorks.

-

Strong sense of style and form to be able to integrate Exolaunch style into documentation and hardware design.

-

Positive attitude and ability to work in a highly integrated team setting.

-

Ability to work in a fast-paced and demanding environment.

-

Flexibility for travel, occasionally at short notice

**Why us?**

-

Competitive compensation package tailored to your experience and responsibilities

-

Subsidies for lunch, mobility, and special occasions, depending on eligibility

-

Flexible working hours and a friendly, collaborative atmosphere

-

State-of-the-art Office in the heart of Berlin at Potsdamer Platz

-

Access to an in-house gym at the HQ

-

All necessary IT equipment and office tools to perform your role effectively

-

Complimentary drinks, snacks, and fresh fruit, plus a well-equipped office environment

-

Regular team gatherings, celebrations, and internal events

**Travel Expectations**

The position requires flexibility for regular travel, including short-notice trips. You should be comfortable with traveling approximately at 10-15% of your work time.

**Location Requirement**

This role is based in Berlin. Candidates must either currently reside in Berlin or be open to relocating.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
