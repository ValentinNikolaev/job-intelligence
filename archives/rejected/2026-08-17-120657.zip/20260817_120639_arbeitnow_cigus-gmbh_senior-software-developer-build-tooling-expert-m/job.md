# Senior Software Developer / Build & Tooling Expert (m/w/d)

Posted: 2026-08-17T07:20:13Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

#### **Hochtechnologie und Innovation...**

…aktiv mitgestalten und vorantreiben – für diese Position suchen wir eine engagierte Persönlichkeit (m/w/d), die mit Ideenreichtum, Verantwortungsbewusstsein und fachlicher Kompetenz überzeugt. Als Beratungsunternehmen unterstützen wir unseren Kunden bei der Suche nach einer passenden Person, die Herausforderungen nicht als Hürde, sondern als spannende Möglichkeit zur Weiterentwicklung versteht.

#### **Das erwartet dich:**

-

Konzeption und Optimierung komplexer **Build- und Tooling-Landschaften** für .NET- und C++-Entwicklungssysteme

-

Analyse von Compiler-, Linker- und Build-Prozessen für performante, reproduzierbare **Software-Releases**

-

Entwicklung anspruchsvoller **MSBuild**-Lösungen mit Custom Targets, Tasks, Multi-Targeting und Projektabhängigkeiten

-

Design und Integration **COM-basierter Schnittstellen** sowie moderner .NET-Interop-Architekturen

-

Entwicklung skalierbarer **gRPC-Service-Architekturen** für die Kommunikation verteilter Anwendungen und Systeme

-

Erstellung von **Roslyn-Analyzern** und Code-Fix-Providern zur automatisierten Sicherung technischer Entwicklungsstandards

-

Weiterentwicklung von **CI/CD**, Build-Automatisierung und Developer Tooling sowie Unterstützung bei komplexen Technologiefragen

Für diese Position sind bestimmte fachliche und persönliche Voraussetzungen hilfreich. Die folgenden Anforderungen geben dir einen Überblick darüber, welche Erfahrungen und Eigenschaften für diese Rolle von Vorteil sind.

#### **Was du mitbringen solltest:**

-

Studium in Informatik, Software Engineering oder vergleichbare Qualifikation sowie mehrjährige Entwicklungserfahrung

-

Sehr gute Kenntnisse in **C#**, **.NET**, C++ und der Visual-Studio-Toolchain

-

Expertenwissen in **MSBuild**, Compiler-Konfiguration, Build-Optimierung und großen Softwarelösungen

-

Fundierte Erfahrung mit **COM**, .NET Interop, Marshaling, Speicherlecks und Threading-Problemen

-

Mehrjährige Erfahrung mit **gRPC**, Protocol Buffers sowie verteilten Service- und Microservice-Architekturen

-

Praxis mit **Roslyn**, Azure DevOps oder GitHub Actions sowie automatisierten Build- und Release-Pipelines

-

Erfahrung mit Software-Architektur, **Plattformengineering**, Legacy-Modernisierung und technischer Betreuung von Entwicklungsteams

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
