# Koordinator Netzanschluss (m/w/d) Mittelspannung in Hockenheim (1709)

Posted: 2026-08-17T07:00:39Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**Ihre Karriere in der technischen Koordination moderner Energieinfrastruktur.**

Mit BRÜGGEN ENGINEERING übernehmen Sie eine zentrale Schnittstellenfunktion bei der Realisierung anspruchsvoller Netzanschlüsse. Mit klarem Fokus auf die Bauausführung koordinieren Sie technische Abstimmungen mit Netzbetreibern, begleiten die Umsetzung von Übergabestationen und sorgen für eine strukturierte Dokumentation.

## Aufgaben

- **Netzanschluss:** Sie koordinieren die technischen Abstimmungen mit dem Netzbetreiber für 110-kV-Netzanschlüsse.

- **Schnittstellen:** Sie stimmen Themen zu Netzanschlusskonzept, Primär- und Sekundärtechnik sowie Abrechnungsmessung mit den Projektbeteiligten ab.

- **Mittelspannung:** Sie begleiten die technische Abstimmung und Umsetzung von MS-Übergabestationen mit dem zuständigen Netzbetreiber.

- **Bauausführung:** Sie unterstützen die technische Umsetzung vor Ort und stellen die Abstimmung zwischen Planung, Netzbetreiber und Projektbeteiligten sicher.

- **Inbetriebnahme:** Sie begleiten die Inbetriebnahme der Übergabestation und koordinieren notwendige technische Klärungen.

- **Dokumentation:** Sie erstellen und verwalten Gesprächsprotokolle, technische Unterlagen und relevante Nachweise.

## Qualifikation

- **Qualifikation:** Weiterbildung zum Techniker:in bzw. Meister:in im Bereich Elektrotechnik, Energietechnik, Versorgungstechnik, alternativ ein technisches Studium oder vergleichbare Qualifikation.

- **Erfahrung:** Berufspraxis im Umfeld von Energieversorgung, Netzanschlüssen oder elektrischer Infrastruktur.

- **Fachwissen:** Fundierte Kenntnisse in Mittel- und Hochspannungstechnik sowie ein gutes Verständnis von Netzanschlusskonzepten.

- **Regelwerke:** Sicherer Umgang mit relevanten VDE-Vorschriften und technischen Anforderungen.

- **Baupraxis:** Erfahrung in der Bauausführung und technischen Begleitung elektrotechnischer Projekte.

- **Arbeitsweise:** Strukturierte, eigenverantwortliche und lösungsorientierte Herangehensweise.

- **Kommunikation:** Sicheres Auftreten und ausgeprägte Koordinationsfähigkeit im Umgang mit Netzbetreibern und Projektbeteiligten.

## Benefits

- **Attraktive Konditionen:** Freuen Sie sich auf eine unbefristete Vollzeitstelle bei BRÜGGEN ENGINEERING mit einer Vergütung, die Ihre Expertise würdigt.

- **Zukunftssichere Projekte:** Arbeiten Sie an anspruchsvollen Netzanschlüssen und leisten Sie einen wichtigen Beitrag zur zuverlässigen Energieinfrastruktur.

- **Dynamisches Team:** Werden Sie Teil eines Teams, das Wert auf persönliches Wachstum und eine Kultur der Unterstützung und Förderung legt.

Wir freuen uns auf Ihre aussagekräftigen Bewerbungsunterlagen mit

Angabe Ihres frühesten Starttermins und Ihrer Gehaltsvorstellung.

Ihr Ansprechpartner für Ihre Bewerbung ist:

Herr Dipl.-Ing. Thomas Keller

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
