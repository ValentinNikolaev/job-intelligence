# Senior Software Developer / 3rd-Level Support & Customer Issue Resolution Expert (m/w/d)

Posted: 2026-08-17T07:20:13Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

#### **Hochtechnologie und Innovation...**

…aktiv mitgestalten und vorantreiben – für diese Position suchen wir eine engagierte Persönlichkeit (m/w/d), die mit Ideenreichtum, Verantwortungsbewusstsein und fachlicher Kompetenz überzeugt. Als Beratungsunternehmen unterstützen wir unseren Kunden bei der Suche nach einer passenden Person, die Herausforderungen nicht als Hürde, sondern als spannende Möglichkeit zur Weiterentwicklung versteht.

#### **Das erwartet dich:**

-

Steuerung technischer Eskalationen als Schnittstelle zwischen **3rd-Level Support**, Service, QA und Softwareentwicklung

-

Analyse, Reproduktion und Eingrenzung komplexer Kundenprobleme durch **Debugging** und strukturierte Log-Analysen

-

Durchführung technischer Ursachenanalysen sowie Entwicklung pragmatischer und nachhaltiger Lösungen für kritische Softwarefehler

-

Erstellung präziser Bugreports, technischer Konzepte und dokumentierter **Best Practices** für wiederkehrende Problemstellungen

-

Unterstützung internationaler Kunden und Teams bei priorisierten Incidents und technisch anspruchsvollen Supportfällen

-

Weiterentwicklung von **Supportprozessen**, Analysewerkzeugen und Dokumentation zur effizienten Bearbeitung komplexer Eskalationen

-

Vermittlung technischer Zusammenhänge sowie Wissenstransfer zwischen Entwicklungsteams, Support, Service und Key Usern

Für diese Position sind bestimmte fachliche und persönliche Voraussetzungen hilfreich. Die folgenden Anforderungen geben dir einen Überblick darüber, welche Erfahrungen und Eigenschaften für diese Rolle von Vorteil sind.

#### **Was du mitbringen solltest:**

-

Fundierte Erfahrung im **B2B-Software-Support** und in der Bearbeitung anspruchsvoller 3rd-Level-Eskalationen

-

Sehr gute Kenntnisse in **C#**, C++ sowie bestehenden Softwarearchitekturen mit Legacy-Anteilen

-

Sicherer Umgang mit Debugging, **Log-Analyse**, Schnittstellen, Datenbanken und technischer Infrastruktur

-

Ausgeprägte Fähigkeiten bei Fehlerreproduktion, Ursachenanalyse und strukturierter Eingrenzung komplexer Kundenbugs

-

Erfahrung in der Erstellung präziser Bugreports, technischer Dokumentationen und umsetzbarer Lösungskonzepte

-

Sehr gute Kommunikationsfähigkeiten für internationale Zusammenarbeit sowie sichere Englischkenntnisse in Wort und Schrift

-

Strukturierte Arbeitsweise bei parallelen Tickets, hoher Priorität und kurzfristigen technischen Eskalationen

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
