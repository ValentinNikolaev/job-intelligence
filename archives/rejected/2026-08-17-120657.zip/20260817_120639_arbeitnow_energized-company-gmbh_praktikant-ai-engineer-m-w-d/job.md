# Praktikant AI Engineer (m/w/d)

Posted: 2026-08-17T10:00:42Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**energized& – Dein Growth Partner aus deiner Branche.**

Wir sind eine tech- und datengetriebene Unternehmensberatung, die B2B-Unternehmen aus den Bereichen New Energy und E-Mobility dabei unterstützt, ihre Pipeline zu stärken, den Umsatz zu steigern und die Customer Acquisition Costs zu senken. Mit technischem Branchenwissen, modernen AI-Tools und In- & Outbound-Expertise helfen wir unseren Kunden, sich klar zu positionieren, Vertrieb und Marketing effizient aufzustellen und nachhaltig zu wachsen.

Wenn du Lust hast, echtes B2B-Growth mitzugestalten, bist du bei energized& genau richtig. Als **Praktikant AI Engineer (m/w/d)** hilfst du uns, unsere internen Prozesse und das Business Development durch Künstliche Intelligenz zu revolutionieren.

## Aufgaben

- Konzeption und Entwicklung autonomer Agenten zur Übernahme komplexer Aufgaben im Business Development

- Analyse und Automatisierung von Geschäfts- und Sales-Prozessen mittels intelligenter Workflows

- Verknüpfung zwischen der bestehenden BI-Infrastruktur und innovativen KI-Anwendungen

- Optimierung des Outputs von KI-Tools hinsichtlich spezifischer Business-Anforderungen

- Evaluierung neuer AI-Tools und Technologien bezüglich ihres praktischen Nutzens für das Unternehmen

- Überführung interner KI-Automatisierungen in skalierbare Produktlösungen

## Qualifikation

- Du studierst (Wirtschafts-)Informatik, (Wirtschafts-)Ingenieurwesen, Data Science oder einen vergleichbaren Studiengang

- Du hast ein tiefes Verständnis für LLMs und willst diese zur Lösung von Business-Problemen einsetzen

- Du beherrscht Python und hast Erfahrung mit APIs, Webhooks sowie Frameworks für KI-Agenten

- Du kannst komplexe Prozesse in logische Einzelschritte zerlegen und automatisieren

- Du arbeitest strukturiert, eigeninitiativ und hast eine schnelle Auffassungsgabe

- Du kommunizierst verhandlungssicher auf **Deutsch** in Wort und Schrift (mindestens C1)

## Benefits

- Zuschuss für Sport- und Firmenfitness-Angebot

- Flexible Arbeitszeiten und 100% remote – perfekt neben dem Studium

- Zusammenarbeit mit dem Gründerteam und Branchenexpert:innen

- Steile Lernkurve und Verantwortung

- Einblicke in moderne Growth-Strategien, AI-Tools und datengetriebene Beratung

**Interesse geweckt?**

Wir freuen uns auf Deine aussagekräftige, digitale Bewerbung im **PDF-Format**, idealerweise bestehend aus Lebenslauf, Studienbescheinigung und Zeugnis.

Hinweis: Vielfalt ist uns wichtig – wir freuen uns über Bewerbungen von Menschen unabhängig von Geschlecht, Herkunft, Identität, Alter oder Perspektive.

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
