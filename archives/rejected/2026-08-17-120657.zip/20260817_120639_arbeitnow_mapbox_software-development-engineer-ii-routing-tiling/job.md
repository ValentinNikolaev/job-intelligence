# Software Development Engineer II, Routing Tiling

Posted: 2026-08-17T02:40:15Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Mapbox is the leading real-time location platform for a new generation of location-aware businesses. Mapbox is the only platform that equips organizations with the full set of tools to power the navigation of people, packages, and vehicles everywhere. More than 4 million registered developers have chosen Mapbox because of the platform’s flexibility, security and privacy compliance. Organizations use Mapbox applications, data, SDKs and APIs to create customized and immersive experiences that delight their customers.

**What We Do**

The Routing Tiling team builds and operates the data infrastructure that powers navigation at global scale. We process raw geospatial data from OpenStreetMap and commercial providers into highly optimized routing tiles, integrate real-time traffic signals, and deliver this data reliably to millions of users. Our systems directly support navigation experiences used by major automotive partners such as BMW. The team operates at the intersection of large-scale data processing, distributed systems, and geospatial intelligence, with a strong emphasis on automation, data quality, and operational excellence.

Read about Mapbox Navigation on our blog: [https://blog.mapbox.com/tagged/navigation](https://blog.mapbox.com/tagged/navigation)

**What You'll Do**

As an Engineer on the Routing Tiling team, you will design, build, and operate critical components of the routing data pipeline. In this role, you can expect to:

-

Develop and scale systems that transform raw map data into performant, production-ready routing tiles

-

Improve data freshness and processing efficiency, reducing pipeline latency from days to hours

-

Integrate real-time traffic and map updates to enhance routing accuracy and guidance quality

-

Ensure high reliability and availability of routing data delivered to global users and partners

-

Build automated systems that maintain data integrity, consistency, and quality at scale

**Employment Type:** Full-time

**Weekly Hours:** 40 hours per week - 1 week on call every 5 weeks

**Location/Hybrid Policy:** Remote

**What We Believe are Important Traits for This Role**

-

5+ years of backend focused experience

-

3+ engineering modern Rust applications in a commercial or open-source development environment

-

3+ years of working with distributed systems. Preferably with AWS based tools or Azure/GCP alternatives

## **What We Value**

In addition to [our core values](https://www.mapbox.com/about/values/), which are not unique to this position and are necessary for Mapbox leaders:

-

We value high-performing creative individuals who dig into problems and opportunities.

-

We believe in individuals being their whole selves at work. We commit to this through supportive health care, parental leave, flexibility for the things that come up in life, and innovating on how we think about supporting our people.

-

We emphasize an environment of teaching and learning to equip employees with the tools needed to be successful in their function and the company.

-

We strongly believe in the value of growing a diverse team and encourage people of all backgrounds, genders, ethnicities, abilities, and sexual orientations to apply.

By applying for this position, you acknowledge that you have received the [Mapbox Non-US Privacy Notice](https://www.mapbox.com/legal/applicant-privacy-notice/) for applicants, which is linked here. Completing this application requires you to provide personal data, such as your name and contact information, which is mandatory for Mapbox to process your application.

*We are committed to a fair and equitable hiring process. We do not discriminate against any protected class.*

#LI-Remote

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
