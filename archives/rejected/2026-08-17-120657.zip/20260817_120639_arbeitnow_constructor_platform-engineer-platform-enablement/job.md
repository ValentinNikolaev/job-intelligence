# Platform Engineer: Platform Enablement

Posted: 2026-08-16T17:40:14Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

## **About Us**

Launched in 2019, Constructor is an AI-first ecommerce search and discovery platform that helps shoppers find the right products at the right time and enables leading global e-commerce brands to drive meaningful revenue and conversion gains.

## **About the role**

Our Platform Enablement team is a developer-centric SRE team dedicated to treating our internal engineers as our primary customers. We maintain the foundational layers that impact daily workflows—including observability, CI/CD, and workload orchestration—with the goal of making it simpler and more efficient for teams to deploy and manage their services. If you are passionate about eliminating friction, automating repetitive tasks, and engineering self-service architectures, we would love to meet you.

## **What You'll Do**

-

Manage and advance our internal observability ecosystem, including technologies like Grafana, VictoriaMetrics, and OpenSearch, to empower teams in troubleshooting their own workloads.

-

Enhance CI/CD workflows and developer utilities using Jenkins and GitHub Actions to optimize the build and deployment lifecycle.

-

Guide the adoption of Kubernetes and establish standardized patterns for deploying various workloads.

-

Collaborate closely with engineering teams to resolve technical bottlenecks and build custom tooling when existing solutions fall short.

-

Contribute to the development and maintenance of our Internal Developer Platform based on Backstage.

-

Develop and support specialized tooling for AI-driven initiatives.

## **What You'll Bring**

-

More than 5 years of professional experience in SRE or DevOps roles with a clear emphasis on enabling developer success.

-

Strong interpersonal skills and a deep sense of empathy for the challenges faced by software developers.

-

Proven expertise in AWS and Kubernetes environments, coupled with a mastery of Infrastructure as Code via Terraform or similar frameworks.

-

Practical experience managing monitoring stacks and deployment pipelines at scale.

-

A natural inclination toward building automated, reusable systems that favor self-service over manual intervention.

-

A track record of integrating AI tools into your engineering methodology to improve productivity.

## **Nice to Have**

-

Familiarity with the broader ecosystem including ClickHouse, Sentry, or developer portals like Backstage.

-

Understanding of FinOps principles and strategies for optimizing infrastructure expenditure.

-

Previous involvement in constructing or scaling internal developer platforms.

## **Benefits**

-

🏝️ Unlimited vacation time - we strongly encourage all of our employees take at least 3 weeks per year

-

🌎 Fully remote team - choose where you live

-

🛋️ Work from home stipend! We want you to have the resources you need to set up your home office

-

💻 Apple laptops provided for new employees

-

🧑‍🎓 Training and development budget for every employee, refreshed each year

-

👪 Maternity & Paternity leave for qualified employees

-

🧠 Work with smart people who will help you grow and make a meaningful impact

-

💵 This position has a base salary range between $80k and $120k USD. The offer varies on many factors including job related knowledge, skills, experience, and interview results.

-

🎉 Regular team offsites to connect and collaborate

## **Diversity, Equity, and Inclusion at Constructor**

At [Constructor.io](http://Constructor.io) we are committed to cultivating a work environment that is diverse, equitable, and inclusive. As an equal opportunity employer, we welcome individuals of all backgrounds and provide equal opportunities to all applicants regardless of their education, diversity of opinion, race, color, religion, gender, gender expression, sexual orientation, national origin, genetics, disability, age, veteran status or affiliation in any other protected group.

*Studies have shown that women and people of color may be less likely to apply for jobs unless they meet every one of the qualifications listed. Our primary interest is in finding the best candidate for the job. We encourage you to apply even if you don’t meet all of our listed qualifications.*

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
