# Senior Manager, Strategy & Operations, New Verticals – Retail (South and Central)

Posted: 2026-08-16T23:55:21Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

## About Wolt

At Wolt, we create technology that brings joy, simplicity and earnings to the neighborhoods of the world. In 2014 we started with delivery of restaurant food. Now we’re building the delivery of (almost) everything and you’ll find us in over 500 cities in 30 countries around the world. In 2022 we joined forces with DoorDash and together we keep on dreaming big and expanding across the globe.

Working at Wolt isn’t always easy, but it’s definitely exciting. Here you’ll learn more, build more, and ship more than in most other companies. You’ll be challenged a lot, but also have a lot of fun on the way. So, if you’re a self-starter with drive and entrepreneurial spirit, this could be the ride of your life.

Wolt’s 3rd Party (3P) Retail business is a core pillar of New Verticals, giving customers access to grocery, convenience, pharmacy, and specialty retail through strong partnerships with merchants across markets. Our vision is to make Wolt the world’s best shopping mall, in your pocket.

We at Wolt have a slightly different take on what a strategy team delivers, compared with traditional, larger corporations. It’s a little more hands-on (don’t worry, that’s what makes it exciting!). We work closely with cross-functional teams to build solid growth plans, execute them well in our country operations, and spread best practices across the organization – all with the goal of keeping the growing pains of rapid scaling in check.

As Wolt continues to scale its 3P Retail business across the South and Central region, we’re looking for a Strategy & Operations Manager to drive sustainable topline growth and bottomline performance. You’ll work closely with the Regional GM for 3P Retail, Heads of Retail across country clusters, and Account Management / sales teams on the ground – and partner with Marketing, Finance, Commercial, and other global functional teams to align strategy, planning, and execution.

We’ve learned over the years that there’s an abundance of strategic thinkers out there, but for this role we need a strategic doer. We have data on anything and everything, so we can and will make every decision through analysis – what we don’t need is death by Powerpoint. Planning should be decisive, quick, and efficient, so we can move on to the real challenge: execution.

## **What you’ll be doing**

- Own topline (GOV, orders, merchant expansion, basket size) and bottomline (contribution margin, profitability, cost efficiency) performance across the region, partnering closely with the Regional GM, Heads of Retail, and country teams – identifying performance gaps, diagnosing root causes, and driving corrective action

- Partner with Finance on regional planning, forecasting, and target setting, and help shape long-term growth plans, expansion strategies, and investment priorities across the region

- Work with Heads of Retail and Key Account Management teams to unlock growth opportunities with merchant partners, including merchant expansion strategy and priority categories and markets

- Partner with Marketing on growth initiatives across acquisition, retention, and basket size expansion, and build scalable playbooks that drive consistent growth across markets

- Lead cross-functional projects end-to-end – from problem definition to execution and impact measurement – alongside Marketing, Commercial, and Analytics, ensuring global strategy and local execution stay aligned

- Use Cursor, Claude, Looker, Excel, and other BI tools to turn business performance data into dashboards, models, and clear strategic recommendations for regional and global leadership

- Support experimentation and test-and-learn approaches to keep optimizing growth and profitability

## **Our humble expectations**

- 4+ years of relevant experience in Strategy & Operations, management consulting, investment banking, tech companies, or high-growth retail/e-commerce – ideally with exposure to multi-country or regional business environments and merchant-facing or commercial teams

- Brilliant data analysis skills – an exceptional ability to frame and synthesize complex, ambiguous business problems into clear, concise solutions. Advanced Cursor/Claude + Excel (financial modelling, forecasting, scenario analysis) and solid experience with BI tools like Looker; SQL is a plus but not required

- Outstanding structured problem-solving skills, with the ability to spot high-impact opportunities, prioritize effectively, and connect strategy to commercial and operational execution

- Natural tendency for ownership: we grow quickly, everyone has more to do than time allows, and just because something’s not in your job description doesn’t mean you shouldn’t do it

- Proven ability to work with senior stakeholders – Regional GMs, Heads of Retail, and global functional leaders – and to influence without authority across global, regional, and local teams

- Strong project management skills, with a track record of leading cross-functional initiatives end-to-end and managing multiple priorities and workstreams at once

- Excellent written and verbal communication skills in English, with an eye for detail and a passion for presenting data in clear, compelling ways. You’ll be working at a rapid pace across country teams in several time zones – it’s not easy ;-)

- Experience from high-growth VC/PE-backed companies is a plus

## **Next Steps**

If you’re excited about working in a high-growth environment, taking ownership, and being part of an ambitious team redefining retail, click below to apply and get the conversation going! Along with a competitive salary and benefits, you’ll also be eligible for our stock option plan.

We’ll be reviewing applications on an ongoing basis, so if this sounds like an opportunity you want to pursue, apply today!

## Our Commitment to Diversity and Inclusion

We’re committed to growing and empowering a more inclusive community within our company, industry, and cities. That’s why we hire and cultivate diverse teams of people from all backgrounds, experiences, and perspectives. We believe that true innovation happens when everyone has room at the table and the tools, resources, and opportunity to excel.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
