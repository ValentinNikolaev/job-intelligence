# IT-Spezialist Digitalisierung (m/w/d)

Posted: 2026-08-17T06:00:40Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

## Warum du bei uns genau richtig bist?!

WORK LIFE BALANCE

- flexible Arbeitszeiten & mobile Arbeitsplatzgestaltung sowie Home-Office Optionen

- attraktives Büro in zentraler, verkehrsgünstiger Lage

- Top-Büroausstattung (z.B. höhenverstellbare Schreibtische)

- moderne IT- und Telko-Ausstattung
FINANZEN & MEHR

- attraktives Gehalt mit Bonusoptionen

- 30 + 1 Urlaubstage

- Nettolohnoptimierungen wie z.B. Erholungsbeihilfe, Gutscheinkarte mit 50€ Aufladung pro Monat etc.

- Weihnachts- und Geburtstagsgeschenk

- bezahlter Parkplatz

- Kaffee, Getränke, Obst & Süßes kostenlos
SPASS & GESUNDHEIT

- Team-Events wie After-Work-Sessions, Sommerfest, Betriebsausflug, Weihnachtsfeier

- Sportliche Events wie z.B. InnRun, Stadtlauf etc.

- Gesundheitsangebote
ZUKUNFT

- interne und externe Fort- und Weiterbildungen sowie Coachings

- persönliche Weiterentwicklung und Karriereplanung

- ein nachhaltiges, resilientes & vielfältiges Unternehmen
KOMPETENZ

- Top-Kanzlei in Ostbayern - Steuerberatung, Wirtschaftsprüfung, Rechts- und Unternehmensberatung unter einem Dach

- über 150 Mitarbeitende, davon 35 Berufsträger – ein starkes, interdisziplinäres und diverses Team (6 von 17 Partner sind Frauen)

- Große Mandantenvielfalt: Von kleinen Selbständigen bis hin zu internationalen Konzernen
IT & DIGITALISIERUNG

- IT & Digitalisierung als strategischer Erfolgsfaktor zur Gestaltung der digitalen Zukunft des Unternehmens

- einfachere und schnellere Arbeit durch gute digitale Prozesse, sinnvolle Automatisierung, Cloud-Lösungen, KI und eigene Anwendungen

## Der Job passt zu dir, wenn du...

- Fachassistent Digitalisierung und IT-Prozesse, Fibutroniker, DATEV-Spezialist, Digitalisierungsberater, Steuerfachangestellter mit hoher IT-Affinität bist oder Quereinsteiger mit fundierten DATEV- und Microsoft-365-Kenntnissen.

- Erfahrung mit DATEV mitbringst, Microsoft 365 sicher nutzt, Interesse an digitalen Prozessen hast und neugierig auf KI-Anwendungen bist.

- gern bereichsübergreifend arbeitest, verständlich erklären kannst, gerne mit Menschen arbeitest und Veränderungen aktiv mitgestalten möchtest.

- Digitalisierung nicht nur verstehst, sondern gemeinsam mit anderen gestalten möchtest.

- über eine sehr gute Analysefähigkeit und schnelle Auffassungsgabe verfügst, eigenverantwortlich arbeitest und Verantwortung übernimmst.

- Offenheit und Lernbereitschaft sowie Interesse an Weiterbildung mitbringst.

- kommunikativ, motiviert und engagiert bist - mit dem "Blick über den Tellerrand hinaus".

- Team-Work genauso lebst wie selbständiges und eigeninitiatives Arbeiten.

- Lust auf Herausforderungen und gemeinsame Ziele hast.

## Welche Aufgaben dich bei uns erwarten:

- Du bist Berater, Impulsgeber und Übersetzter zwischen Technologie und Praxis.

- Du analysierst bestehende Prozesse, erkennst Verbesserungspotenziale und entwickelst gemeinsam mit den Fachbereichen Lösungen, die im Arbeitsalltag funktionieren. Dabei arbeitest du eng mit den Fachabteilungen und Mandanten zusammen.

- Du kannst bei verschiedensten Projekten mitwirken, z.B. Einführung neuer DATEV-Lösungen, Ausbau digitaler Mandantenprozesse, Optimierung der Zusammenarbeit mit Microsoft 365, Entwicklung eines modernen Wissensmanagements, Einführung von Microsoft Copilot und DATEV Copilot, Bewertung neuer KI-Anwendungen für Steuerberatung und Kanzleialltag, Automatisierung wiederkehrender Arbeitsabläufe, Digitalisierung interner Kanzleiprozesse und Entwicklung neuer Standards für digitale Zusammenarbeit.

- Du arbeitest unter anderem mit DATEV Unternehmen online, DATEV Eigenorganisation, DATEV-Schnittstellen, Microsoft 365, Microsoft Teams, SharePoint, OneDrive, gängigen KI-Systemen und Cloud-Anwendungen verschiedener Anbieter.

- Du bist Ansprechpartner für Kollegen und Mandanten.

## Dein Kontakt zu uns

**Interesse in unserem Team mit dabei zu sein?!**

Dann nutze jetzt deine Chance - bewirb dich schnell und unkompliziert über unser Bewerberportal.

Ein einfacher Klick direkt unten über den Button **"Jetzt im Portal bewerben".**

**Du hast noch Fragen?**

Unsere Kollegin Stefanie Purucker aus der Personalabteilung ist gern für dich da.

Telefon: 0991 / 320138 - 573

Wir freuen uns auf dich!

## Unsere Standorte

## Dr. Kittl & Partner

**Steuerberatung, Wirtschaftsprüfung, Unternehmensberatung und Rechtsberatung**
Standort Deggendorf, Bahnhofstraße 41, 94469 Deggendorf

Standort Passau, Erhardstraße 4, 94032 Passau

Standort Regensburg, Fritz-Fend-Straße 4, 93047 Regensburg

Standort Trostberg, Kirchenstraße 1, 83308 Trostberg

Standort München, Hohenzollernstraße 10, 80801 München

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
