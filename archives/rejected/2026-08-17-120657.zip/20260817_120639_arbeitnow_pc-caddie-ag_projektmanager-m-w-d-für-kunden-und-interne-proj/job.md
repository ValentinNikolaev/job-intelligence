# Projektmanager (m/w/d) für Kunden- und interne Projekte

Posted: 2026-08-17T10:00:41Z

## Rejection

- Category: tech_stack
- Reason: role does not mention Go/Golang or PHP

Hast du Erfahrung in der Leitung von Projekten und Lust, komplexe Vorhaben gemeinsam mit Kollegen und Kunden souverän ans Ziel zu bringen? Dann könnte diese Position genau das Richtige für dich sein.

Wir sind eine international tätige Softwarefirma, spezialisiert auf IT-Lösungen für Golfanlagen und Golfverbände. Wenn ein Club Mitglieder verwaltet, Startzeiten bucht, Turniere organisiert oder an der Theke kassiert, läuft das bei den meisten über uns. Mit über 700 Kunden sind wir ein langjähriger, verlässlicher Partner im deutschsprachigen Golf, mit persönlicher Betreuung in mehreren Sprachen.

Wir wachsen, und mit uns wachsen die Projekte: neue Clubs, die zu uns wechseln, große Umstellungen und Migrationen, Verbände und Großkunden mit eigenen Anforderungen. Solche Projekte brauchen jemanden, der sie führt, der weiß, wer was bis wann macht, und der das Team und den Club durch die entscheidenden Wochen begleitet. Genau dafür suchen wir dich.

## Aufgaben

- Du leitest Kunden- und interne Projekte von der Planung bis zum Go-live: Onboarding neuer Golfanlagen, Umstellungs- und Migrationsprojekte, die Betreuung von Großkunden und Verbänden.

- Du führst auch interne Projekte, zum Beispiel rund um unsere ERP-Einführung und unseren Wissensspeicher.

- Du behältst Termine, Abhängigkeiten und alle Beteiligten im Blick und kommunizierst klar in beide Richtungen, zum Club wie ins Team.

- Für deine Projekte bist du das Gesicht, die Person, bei der sich Kunden und Kollegen gut aufgehoben fühlen.

- Du arbeitest KI-gestützt: Wir holen KI gezielt in den Alltag, damit deine Energie in Menschen und Entscheidungen fließt statt in Fleißarbeit.

Du arbeitest dabei nicht allein: Du landest in einem eingespielten Team von rund [XX] Kolleginnen und Kollegen. Support, Entwicklung, Vertrieb und Geschäftsführung sind nah, die Wege sind kurz.

## Qualifikation

- Zwei bis vier Jahre Erfahrung in der Projektleitung oder im Projektmanagement, gern im Software- oder IT-Umfeld, mit mehreren Projekten, die du nachweislich sauber ans Ziel gebracht hast.

- Eine abgeschlossene Ausbildung oder ein Studium, gern mit IT-Bezug, oder eine vergleichbare Qualifikation.

- Du bist strukturiert und behältst auch bei mehreren Projekten parallel den Überblick.

- Kommunikationsstärke, Teamfähigkeit und ein hoher Kundenfokus. Kundennähe ist für dich kein Buzzword.

- Du organisierst dich im Remote-Setup selbstständig und zuverlässig.

- Du bist KI-affin und neugierig, wie moderne Tools deine Arbeit besser machen.

- Sehr gute Deutsch- und Englischkenntnisse in Wort und Schrift, weitere Sprachen sind ein Plus.

Eine Projektmanagement-Zertifizierung (zum Beispiel PMI, PRINCE2 oder IPMA) ist willkommen, aber kein Muss. Erfahrung mit Golf, Freizeit- oder Sporttechnik freut uns. Fehlt sie dir, bringst du dafür Lust mit, dich in unsere Welt einzuarbeiten.

## Benefits

- Ein eingespieltes, kollegiales Team, das hinter dir steht, und kurze Wege bis zur Geschäftsführung.

- Selbstständiges Arbeiten mit echtem Kundenkontakt.

- Remote in ganz DACH, ergänzt um Team-Treffen, Fortbildungen und persönlichen Austausch mit Kunden.

- Ein pragmatischer, ehrlicher Umgang mit KI: Wir sind kein Hochglanz-Tech-Konzern, holen KI aber gezielt in den Alltag und bauen das weiter aus.

Du gestaltest das aktiv mit.

- Planbare Arbeitszeiten, im Wesentlichen werktags. Projektarbeit, kein Schichtdienst.

- Eine sichere Position mit unbefristetem Arbeitsvertrag.

**Deine Perspektive:**

Wir denken diese Stelle langfristig. Du startest als Projektmanager und wächst mit der Zeit tiefer in unser Produkt hinein, bis du verstehst, wie unsere Software wirklich tickt. So leitest du perspektivisch nicht nur Projekte, sondern kennst unser Produkt in der Tiefe und stärkst das Team auch fachlich. Wohin die Reise genau geht, gestalten wir gemeinsam.

Klingt nach dir? Dann freuen wir uns auf deine Bewerbung per Mail. Ein perfektes Anschreiben brauchen wir nicht, schreib uns einfach, wer du bist und was dich an dieser Rolle reizt.

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
