# Mitarbeiter Office Management & Personal (m/w/d) | Teilzeit

Posted: 2026-08-17T06:30:40Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Finanzbuchhaltung & Office Management (m/w/d) – Teilzeit (20 Std./Woche)

**Standort:** Raum Gilching bei München

**Arbeitszeit:** Teilzeit, 20 Stunden pro Woche

**Anstellung:** Unbefristete Festanstellung in Direktvermittlung

**Start:** Ab sofort oder nach Vereinbarung

Ihr neuer Arbeitgeber

Unser Kunde ist ein erfolgreiches, inhabergeführtes Unternehmen im Bereich IT- und Unternehmensdienstleistungen mit Sitz im Westen von München. Seit vielen Jahren unterstützt das Unternehmen seine Kunden mit maßgeschneiderten Lösungen und legt großen Wert auf eine partnerschaftliche Zusammenarbeit, flache Hierarchien sowie kurze Entscheidungswege. In einem überschaubaren Team übernehmen Mitarbeitende Verantwortung und gestalten Prozesse aktiv mit.

## Aufgaben

Ihre Aufgaben

- Organisation und Koordination des gesamten Büroalltags

- Unterstützung der Geschäftsleitung bei administrativen und organisatorischen Aufgaben

- Planung und Abstimmung von Terminen, Meetings und Geschäftsreisen

- Eigenständige Bearbeitung der Personaladministration – von der Vertragserstellung über das Onboarding bis zur Pflege der Personalunterlagen

- Betreuung der Mitarbeitenden bei administrativen Fragestellungen rund um das Arbeitsverhältnis

- Unterstützung im Recruiting, einschließlich Bewerbermanagement, Terminorganisation und Kommunikation mit Kandidatinnen und Kandidaten

- Steuerung allgemeiner Verwaltungsaufgaben wie Postbearbeitung, Telefonzentrale, Bestellwesen sowie Koordination externer Dienstleister

- Sicherstellung eines gut organisierten Informationsflusses innerhalb des Unternehmens

- Mitwirkung bei der Optimierung und Digitalisierung administrativer Prozesse

## Qualifikation

- Erfolgreich abgeschlossene kaufmännische Ausbildung oder eine vergleichbare Qualifikation mit Schwerpunkt Personal oder Verwaltung

- Berufserfahrung im Office Management, in der Personaladministration oder in einer vergleichbaren Position

- Sicherer Umgang mit HR-Systemen, beispielsweise Personio, Sage oder vergleichbaren Anwendungen

- Gute Kenntnisse in den MS-Office-Programmen

- Sehr gute Deutschkenntnisse sowie gute Englischkenntnisse in Wort und Schrift

- Selbstständige, strukturierte und sorgfältige Arbeitsweise

- Hohe Serviceorientierung, Organisationsgeschick und absolute Vertrauenswürdigkeit

- Kommunikationsstärke und Freude an der Zusammenarbeit mit unterschiedlichen Ansprechpartnern

**Von Vorteil sind außerdem:**

- Erfahrung im Recruiting und Bewerbermanagement

- Grundkenntnisse im deutschen Arbeitsrecht

- Erfahrung in der Zusammenarbeit mit der Geschäftsleitung oder dem Management

## Benefits

- Unbefristete Festanstellung in einem wirtschaftlich erfolgreichen Unternehmen

- Verantwortungsvolle und abwechslungsreiche Aufgaben mit viel Eigenständigkeit

- Direkte Zusammenarbeit mit der Geschäftsführung

- Flache Hierarchien und kurze Entscheidungswege

- Moderne Arbeitsmittel sowie digitalisierte Prozesse

- Wertschätzendes Arbeitsumfeld in einem kollegialen Team

- Teilzeitmodell mit 20 Stunden pro Woche

- Arbeitsort im Raum Gilching bei München

**Interesse geweckt?**

Dann freuen wir uns auf Ihre Bewerbung. Die Vermittlung erfolgt exklusiv und selbstverständlich vertraulich über die Jobbusters!

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
