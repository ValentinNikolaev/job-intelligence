# Creator Growth Manager // AI Music Video Platform

Posted: 2026-08-17T10:00:42Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Neural Frames makes AI music videos. Musicians, producers and labels use it to turn their songs into visuals that actually move with the music, from full music videos to short-form clips.

We're bootstrapped, profitable and growing fast. We got to several million in ARR with a team of about a dozen people, almost entirely through product and SEO. Now we're getting serious about growth, and creators are one of our biggest bets.

You'll be one of our first growth hires, and the creator channel will be yours to own: which creators we work with, what we offer them, what the content looks like, and how all of it connects to signups and revenue.

You won't start cold. We work with an external agency that has built creator programs before, and they'll train you on how to run ours: sourcing, outreach, briefs, deal structures, what tends to work and what doesn't. Expect to learn a lot, fast. From there you take over and scale it, working directly with the founder and seeing within weeks whether your ideas show up in the numbers.

If this works, creator content becomes one of the main ways people discover Neural Frames. And if there's appetite, the role can expand into other parts of growth over time.

## Tasks

- Find and recruit creators across TikTok, Instagram and YouTube: musicians, producers, AI and video creators, ideally before everyone else has noticed them

- Get them publishing: briefs, concepts, challenges and campaigns around launches, new features and cultural moments

- Test incentives until you find what works: flat fees, free credits, affiliate commissions, bonuses, competitions

- Recruit and activate high-potential affiliates into our existing affiliate program

- Turn individual creators into a community, not a list of one-off deals

- Track everything back to traffic, signups, revenue and CAC, and double down on what performs

## Requirements

- 2+ years in creator, influencer, affiliate or growth marketing, and you've personally recruited and managed creators rather than briefing an agency to do it

- Strong instincts for short-form content: you can tell why one video gets 400 views and another gets 4 million

- You think in signups, revenue and CAC, not impressions

- Organized enough to run dozens of creator conversations, deadlines and campaigns at once

- Proactive and independent: you soak up what the agency teaches you, then run the program on your own

- Genuinely into music, AI and internet culture

- You live in Berlin, or are ready to move

Bonus points:

- You've built a creator, ambassador or affiliate program before

- Existing relationships with creators in music, AI or video

- You make short-form content yourself

How we measure success:

This is a growth role, so it comes down to numbers: active creators per month, videos published, traffic and signups from creator content, affiliate revenue, and the CAC of the channel.

We don't want occasional sponsored posts. We want hundreds of creators who genuinely use neural frames, make things with it, and bring the next wave of musicians with them.

## Benefits

VSOPs & Profit Sharing. Bi-weekly team lunches, regular team events, an annual summer offsite, learning & development support, productivity tools, a one-time headphone budget, Deutschlandticket, and a €5,000 referral bonus.

Neural Frames is dedicated to creating an equitable, inclusive, and supportive work environment that brings people together from diverse backgrounds, experiences, and perspectives. Our strength is in our differences. We're proud to be an equal opportunity employer and welcome all applicants as we're committed to promoting a culture of opportunity for all.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
