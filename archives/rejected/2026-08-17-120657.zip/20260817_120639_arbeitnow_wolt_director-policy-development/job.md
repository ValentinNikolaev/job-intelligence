# Director, Policy Development

Posted: 2026-08-17T08:55:30Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

## About Wolt

At Wolt, we create technology that brings joy, simplicity and earnings to the neighborhoods of the world. In 2014 we started with delivery of restaurant food. Now we’re building the delivery of (almost) everything and you’ll find us in over 500 cities in 30 countries around the world. In 2022 we joined forces with DoorDash and together we keep on dreaming big and expanding across the globe.

Working at Wolt isn’t always easy, but it’s definitely exciting. Here you’ll learn more, build more, and ship more than in most other companies. You’ll be challenged a lot, but also have a lot of fun on the way. So, if you’re a self-starter with drive and entrepreneurial spirit, this could be the ride of your life.

DoorDash's mission is to grow and empower local economies — and in Europe, that mission comes to life through two of the continent's most dynamic consumer brands: Wolt and Deliveroo. Together, they bring an extraordinary range of products to people's doors, from restaurant meals and groceries to electronics, beauty, pet supplies, pharmaceuticals and more. Underpinning it all is a broad and ambitious technology platform spanning logistics, retail software, financial solutions and autonomous delivery, as well as Wolt's own grocery retail operation under the Wolt Market brand. With thousands of merchant partners across dozens of European markets, the business is growing fast — and the regulatory landscape is growing more complex with it. To help us navigate this evolving environment, we are looking for a Director of Policy Development to join the team, working across our European and Middle Eastern operations at Wolt and Deliveroo.

## **About the Role**

We are looking for an experienced policy professional to join the Global Policy Team’s Policy Development and Research Group. The Director level role will shape the legal and regulatory framework for a new sector of the economy at a pivotal moment in Europe and the Middle East. This expansive role will focus on legislative analysis, developing our policy positions with input from cross-functional business teams, and strategic input on our policy priorities. You will work closely with Policy Team members across Europe and the Middle East and stakeholders across the company to develop and support the adoption of policies that best serve couriers, merchants, and consumers.

## **What you'll be doing**

- Owning and driving Wolt and Deliveroo's regulatory analysis on high-impact legislative proposals across Europe and the Middle East — translating complex law-making processes into clear business, operational and commercial outcomes for senior leadership.

- Bringing sharp legal and legislative expertise to our most ambiguous and high-stakes regulatory challenges — particularly around the future of work for courier partners — and making sound judgments with incomplete information under time pressure.

- Acting as a strategic engine of the policy development function: partnering with our Public Affairs Team to understand the political landscape and how we can best advance our priorities through legislative and regulatory processes. .

- Building and driving alignment across Legal, Strategy & Operations, Product, Finance and Communications, acting as the connective tissue between policy and the business functions that need to act on it.

- As needed, supporting our Public Affairs Team in external engagement with policymakers, regulators, industry groups, and other stakeholders.

- Engaging with academics, think tanks, and other stakeholders to build thought leadership in cutting-edge policy issues — shaping the broader policy environment and building our credibility as a constructive voice in the regulatory debate.

- Balancing legal, operational and financial trade-offs when advising on regulatory risk, ensuring that our positions are not only legally sound but commercially realistic and executable at scale.

## **We’re excited about you because…**

- 10+ years of professional experience from the legal field and/or government or policy development in an international setting, with a demonstrated record of success focusing on a wide range of legislative and regulatory issues. In-house experience is considered an advantage.

- Master of Laws degree from a reputable university in the EU, or strong legal experience.

- Previous professional exposure to digital platforms, mobile apps or software solutions.

- A self-starter who isn’t afraid to roll up their sleeves no matter the task.

- Fluency in English, along with excellent interpersonal and communication skills.

- You have experience working in a global business environment, demonstrating the ability to operate with strong cross-cultural competence and flexibility with working hours – plus the ability to occasionally travel to other cities in Europe, as well as the U.S. to further global collaboration across the team.

- Bonus points for experience in employment and labour law, in international settings at a law firm, in-house at a technology company, and/or with a U.S.-based company.

## **Next Steps**

- If you are excited about working in a high-growth environment, taking ownership, and being part of an ambitious team, then click below to apply and let’s get the conversation going! Please submit both your CV and a cover letter as supporting documents for your application.

- Along with a competitive salary and benefits, you will also be eligible for:

- Opportunity to be part of building something exceptional, in an international environment.

- Lots of learning and growth in a globally scaling tech company.

- Hybrid work model, blending office presence with flexibility.

## Our Commitment to Diversity and Inclusion

We’re committed to growing and empowering a more inclusive community within our company, industry, and cities. That’s why we hire and cultivate diverse teams of people from all backgrounds, experiences, and perspectives. We believe that true innovation happens when everyone has room at the table and the tools, resources, and opportunity to excel.

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
