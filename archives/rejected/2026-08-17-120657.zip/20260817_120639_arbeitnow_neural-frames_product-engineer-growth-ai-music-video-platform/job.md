# Product Engineer (Growth) // AI Music Video Platform

Posted: 2026-08-17T10:00:42Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Neural Frames is a leading AI music video generator, turning any song into a fully produced music video in minutes. We're bootstrapped, profitable, and generating more than $5M in annualized revenue. Our ambition is to build a category-defining company that helps tens of millions of audio creators visualize their content and promote it online. The next target is a $15M run rate.

We're hiring our first product engineer focused on growth. You'll own our marketing pages and the surfaces that turn attention into revenue: free tools, landing pages, signup, onboarding, paywalls, and pricing. You'll also ship on the core product itself. Wherever the biggest lever is, that's where you build.

This is a builder role. You'll ship production code daily, look at the results, decide what to test next, and be one of the people most directly responsible for taking us from $5M to $15M and ultimately to $100M.

As a profitable company, there is no VC drama. We are a small, ambitious group of people striving to build something creators love.

## Tasks

- Own our marketing pages: build, maintain, and continuously improve the landing pages and site experiences that bring people into Neural Frames, and keep them fast, high-converting, and visible in traditional search, Google AI Overviews, and AI assistants like ChatGPT, Claude, Gemini, and Perplexity

- Turn our free tools into real product entry points, where users get immediate value and then continue into Neural Frames without losing their song, lyrics, artwork, or progress

- Run conversion experiments across the whole funnel: landing pages, calls to action, signup, onboarding, paywalls, packaging, and pricing

- Ship on the core product when that's where the growth lever is, especially product-native loops: shareable creations, templates, embeds, referrals, and public pages that give creators a reason to spread Neural Frames for us

- Run programmatic SEO experiments without creating low-quality pages, index bloat, or content that exists only for search engines

- Build lifecycle experiments tied to real product behavior: activation, abandoned projects, paywall recovery, feature discovery, re-engagement

- Own growth measurement and data quality across PostHog, Google Search Console, Google Analytics, and our backend payment data: build funnels and dashboards you can trust, investigate unexpected movements, and turn them into decisions

## Requirements

- You're a product engineer who can independently ship production experiences with React, Next.js, and TypeScript, and you sweat the details that make pages convert: speed, layout, copy, polish

- You're comfortable moving into backend and data work when necessary. Our backend is written in Python, and you can work with APIs, SQL, event data, and attribution logic

- You think like a marketer as much as an engineer: you have real opinions about headlines, page structure, and pricing pages, and you'd rather be measured on signups and revenue than on tickets closed

- You think through the complete funnel. A page that ranks is not a win if visitors don't activate, pay, and stick around

- You understand experimentation: hypothesis, primary metric, guardrails, and a decision threshold defined before the test goes live

- You have strong product and editorial judgment. You build useful experiences for humans rather than filling the internet with generic AI-generated pages

- You use AI tools as a genuine extension of how you work, with a high bar for accuracy, originality, and brand quality

- You have high agency: you identify the bottleneck, gather the evidence, ship a solution, and communicate results without waiting for a perfectly specified ticket

- You're based in Berlin and can join us in the office at least four days per week

Bonus points:

- You've personally built something that produced meaningful organic or product-led growth: a startup, a free tool, a programmatic SEO engine, or growth ownership at a product company. We care more about attributable revenue than impressive traffic screenshots

- You know technical SEO well: crawling, indexing, structured data, internal linking, canonicalization, and safe migrations

## Benefits

VSOPs & Profit Sharing. Bi-weekly team lunches, regular team events, an annual summer offsite, learning & development support, productivity tools, a one-time headphone budget, Deutschlandticket, and a €5,000 referral bonus.

neural frames is dedicated to creating an equitable, inclusive, and supportive work environment that brings people together from diverse backgrounds, experiences, and perspectives. Our strength is in our differences. We're proud to be an equal opportunity employer and welcome all applicants as we're committed to promoting a culture of opportunity for all.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
