# Head of Product Design

Posted: 2026-08-17T08:40:05Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**The AI orchestration of your wildest imagination.**

n8n is the open workflow orchestration platform built for the new era of AI. We give technical teams the freedom of code with the speed of no-code, so they can automate faster, smarter, and without limits. Backed by a fiercely inventive community and 500+ builder-approved integrations, we’re changing the way people bring systems together and scale ideas for impact.

Since our founding in 2019, we’ve grown into a diverse team of over 260 - working across Europe and the US, connected by a shared builder spirit and with our centre of gravity in Berlin. Along the way, we’ve:

-

Cultivated a community of more than 650,000 active developers and builders

-

Earned 190K+ GitHub stars, making us one of the world’s Top 40 most popular projects

-

Backed by top investors, from Sequoia’s first German seed to our SAP's recent strategic investment - bringing us to a $5.2bn valuation

That’s the company we’ve built. Now we’d love to see what *you *can build. If you’re applying, try n8n out - whether you’re technical or not - and share a screenshot of your first workflow with us. The easiest place to start is here: [app.n8n.cloud/register](http://app.n8n.cloud/register).

We’re in a defining moment of an incredible journey. Come and build with us.

n8n sits at one of the most interesting UX problems in software right now: more than 80% of workflows built on n8n today involve AI agents, and the platform is in the middle of a deliberate expansion from deeply technical developers toward a broader set of builders. That tension, keeping power users happy while dramatically lowering the floor, is the central design challenge.

This is a foundational hire with a real mandate and direct exec partnership.

### What you'll do

### Own the quality bar

-

Set a clear, consistent quality bar that the team can orient around and build toward, so great work becomes the natural output of how we design together.

-

Build review processes and critique rituals that give the team a shared language for quality and the confidence to make strong craft decisions together.

-

Evolve the design system and QA practices so the bar rises as the team grows.

-

Dig into one of the most genuinely interesting UX challenges in the space: n8n has historically had a steep learning curve for new users. Your job is to lower that floor without losing the power that experienced builders love.

### Drive design's strategic influence

-

Shape product strategy, not just respond to it. Bring design thinking into roadmap conversations and help surface user problems before they become someone else's brief.

-

Help lead n8n's expansion toward a broader, less technical audience, a deliberate and exciting strategic shift that design should be leading.

-

Build the kind of relationships with Product, Engineering, and leadership where design is a genuine thought partner at every stage.

### Build and grow the team

-

Lead a team of around 14 designers today: 2 Design Leads each working with ~6 ICs, plus Design Engineering and UX Research (with more hires ahead).

-

Shape the team structure, career framework, and progression paths so people know where they stand and where they're going.

-

Create a culture of high standards and honest feedback, where people feel supported to do their best work and have a clear sense of what great looks like.

-

Own hiring and headcount planning for the department, and help us grow without losing what makes the team good.

### Build research into how we make decisions

-

Establish a pragmatic, continuous research practice from the ground up. We're making our first dedicated UX research hires, so there's real room to shape this.

-

Make customer insight, product data, and community feedback a live input to product decisions, so teams are building from evidence at every step.

-

Connect research to the decisions that matter most: activation, adoption, retention, and helping new users find their way into n8n with confidence.

### Help the team work in new ways

-

Champion practical AI adoption inside the design org, from prototyping and research synthesis to design QA and workflow efficiency.

-

Help the team stay curious and current as the tools, patterns, and expectations around AI products continue to evolve fast.

-

Model the kind of working style you want to see: thoughtful, adaptive, and genuinely excited about what's changing.

### Requirements

### Must-haves

-

🧭 **Product design leadership:** You have managed managers, coached senior designers, and built design teams that improve both craft and business outcomes, including making hard performance calls when needed.

-

🧩 **Complex product systems experience:** You have led design across complex or developer-facing products where UX quality depends on deep product understanding.

-

🎨 **Craft authority:** You are a quality bar, not just someone who appreciates quality. You can identify great work, explain why it's great, and hold the line on standards even when it's uncomfortable.

-

📣 **Strategic influence, not just strategic thinking:** You have made design a co-equal in product conversations, not a downstream function. You know how to bring people with you, create debate, and drive decisions.

-

🔀 **Structured problem-solving under ambiguity:** You find your way into unclear problems and create a plan. You don't just ask good questions, you answer them. You move forward when there's no map.

-

🤖 **AI-era product judgment:** You understand the AI, automation, or adjacent tooling landscape and can turn emerging patterns into usable, trustworthy product experiences.

-

🔍 **Research literacy:** You know how to build research into product development so insight becomes part of how teams make decisions, not a separate artifact.

-

📊 **Data-informed decision making:** You use product analytics, research, and customer evidence to guide decisions instead of relying on taste or opinion alone.

-

🧱 **Org design and performance management:** You can design team structures, define career paths, raise expectations, and handle difficult performance conversations with clarity.

### Nice-to-haves

-

🌱 **Open-source or community product experience:** You have worked on open-source, fair-code, community-led, or builder-driven products and understand what it means to design for a community that has strong opinions.

-

💻 **Design engineering credibility:** You have enough front-end or design engineering fluency to partner deeply on design system adoption and implementation quality.

-

🌍 **Remote-first operating systems:** You have built design rituals, critique, QA, and collaboration practices that work across distributed teams and time zones.

-

🚀 **Growth surface experience:** You have worked on activation, onboarding, templates, time-to-value, or product-led growth surfaces.

-

⬆️ **Rising Design Manager profile:** We are open to someone who has been an exceptional Design Manager and is ready for their first Head-level role, if the fundamentals are exceptional.

*n8n is an equal opportunity employer and does not discriminate on the basis of race, religion, colour, national origin, gender, sexual orientation, gender identity, age, marital status, veteran status, or disability status.*

*We can sponsor visas to Germany; for any other country, you need to have existing right to work.*

***Our company language is English.***

*You care about diversity and inclusion? We do too! Check out our *[*Diversity, Inclusion and Belonging initiatives at n8n*](https://www.notion.so/Diversity-inclusion-and-belonging-n8n-c1bec2fff536422d868b1a438d990e35?pvs=21)* (*[*https://www.notion.so/n8n/Diversity-inclusion-and-belonging-n8n-c1bec2fff536422d868b1a438d990e35*](https://www.notion.so/n8n/Diversity-inclusion-and-belonging-n8n-c1bec2fff536422d868b1a438d990e35)*).*

##

***Location disclaimer:** If you see multiple job postings for the same role, it is most likely because we're hiring remotely for this role and posting in different locations to make sure every potential candidate can see the role. Please apply to the location you're the most likely to work from in the future. *

## **Benefits **

-

**Competitive compensation** 💸 – We offer fair and attractive pay.

-

**Ownership** 💪 – Our core value is to “empower others,” and we mean it—you’ll get a slice of n8n with equity.

-

**Work/life balance** 🏖️ – We work hard but ensure you have time to recharge:

-

**Europe:** 30 days of vacation, plus public holidays wherever you are.

-

**US:** 20 vacation days, 8 sick days, plus public holidays wherever you are.

-

**Health & wellness** 🩺 –

-

**Europe:** We provide benefits according to local country norms.*

-

**US**: Multiple low-premium, low-deductible medical plans with coverage for individuals and families—plus a no-cost premium HDHP option with a pre-seeded HSA—along with dental and vision coverage.

-

**Future planning** 💰 –

-

**Europe:** We provide pension contributions according to local country norms.*

-

**US:** 401(k) retirement plan with a 4% employer match.

-

**Financial security** 🛡️ –

-

**Europe:** We provide benefits according to local country norms.*

-

**US: **Company-paid short-term and long-term disability insurance, plus life insurance to support you and your loved ones.

-

**Career growth** 📈 – We hire rising stars who grow with us! You’ll get €1K (or equivalent) per year to spend on courses, books, events, or coaching to level up your skills.

-

**A passionate team** 🤩 – We love our product, and we prove it with regular hackathons where we see who can build the coolest thing with it!

-

**Remote-first** 🌏 – Our team works remotely across Europe, with regular off-sites for team bonding. Some roles, like sales in the US, are hybrid—please check the job description.

-

**Giving back** 🤝 – We're big fans of open source, and you'll get $100 per month to support projects you care about.

-

**Transparency** 🙏 – We all know what everyone’s working on, how the company is doing—the whole shebang.

** Country-specific details are provided in your contract.*

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
