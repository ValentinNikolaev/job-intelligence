# Werkstudent*in Quereinstieg Kosmetikerin (m/w/d) | Waxing & Brows

Posted: 2026-08-17T08:30:31Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**Weniger Haare – mehr Spaß, mehr Gehalt!**

Wir bei Waxcat sind auf professionelles Waxing und Brow Styling spezialisiert – mit hochwertigen Produkten, einem modernen Studio-Konzept und einem starken Team, das Beauty liebt.

Für unser Studio in Düsseldorf suchen wir ab sofort engagierte Werkstudierende (m/w/d), die Lust haben, praktische Erfahrung in der Kosmetikbranche zu sammeln und Teil unseres Teams zu werden.

## Aufgaben

- Professionelle Behandlung und Beratung unserer Kund:innen

- Waxing mit Heißwachs & Augenbrauenmodellage

- Brow- & Lashlifting, Färben von Augenbrauen & Wimpern

- Laserbehandlungen (nur mit NISV-Schein)

- Einhaltung hoher Hygiene-Standards

- Terminvereinbarungen und Kassenführung inkl. Kassenabschluss

- Freundlicher & professioneller Kundenkontakt

## Qualifikation

- Du bist eingeschriebene*r Student*in (Studienrichtung egal – Hauptsache, du hast Lust auf Beauty!)

- Erste Erfahrung im Waxing oder Beauty-Bereich ist super – aber kein Muss

- Begeisterung für Beauty & Pflege

- Freundliches, serviceorientiertes Auftreten

- Teamfähigkeit, Eigenmotivation und Verantwortungsbewusstsein

- Keine Berührungsängste – Behandlung von Frauen & Männern, inkl. Intimbereich

Keine abgeschlossene Kosmetiker*in-Ausbildung? Kein Problem!

Wir bringen dir alles bei – von grundlegenden Beauty-Behandlungen bis zu professionellen Waxing-Techniken

## Benefits

- Attraktives Festgehalt + Umsatzprovision + Trinkgeld

- Professionelle Schulung & Weiterentwicklung zur Depiladora & Beauty-Expert*in

- Kostenlose Waxcat-Behandlungen & exklusive Schulungen

- Moderne, zentral gelegene Studios in Hamburg

- Familiäres Team & kurze Entscheidungswege

- Fahrtkostenzuschuss (Deutschland-Ticket)

- Weiterbildungs- & Aufstiegsmöglichkeiten

- Kostenlose Getränke & Teamevents

- Individuelle Entwicklungsmaßnahmen in Verkauf & Kommunikation

Haben wir Dein Interesse geweckt? Dann freuen wir uns auf Deine Bewerbung! Bei Fragen melde Dich gerne bei uns!

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
