# Enterprise Business Development

Posted: 2026-08-17T05:40:20Z

## Rejection

- Category: tech_stack
- Reason: role does not mention Go/Golang or PHP

# Enterprise Business Development, AI Infrastructure – APAC

## About 0G

0G is building the infrastructure layer for the next generation of AI applications, combining high-performance compute, storage, and decentralized infrastructure to enable developers and enterprises to build and scale AI systems.

We are looking for an **Enterprise Business Development** to help bring 0G's AI infrastructure solutions to enterprise customers across APAC.

This is not a partnerships or pre-sales role. You will personally own the commercial cycle: identifying target accounts, opening doors, understanding customer needs, building the business case, navigating complex buying processes, negotiating commercial terms, and closing deals.

## What You'll Do

-

Own the full enterprise sales cycle across APAC, from prospecting and qualification through negotiation and close

-

Build pipeline from the ground up, with a strong focus on new-logo acquisition

-

Sell 0G's compute, storage, and AI infrastructure solutions to enterprises, AI companies, developers, and other high-compute or data-intensive customers

-

Engage CTOs, CIOs, Heads of AI, infrastructure leaders, engineering teams, procurement teams, and other senior decision-makers

-

Understand customers' AI, compute, storage, and infrastructure requirements and translate them into a compelling commercial proposition

-

Develop account strategies for complex enterprise opportunities and drive deals through multi-stakeholder buying processes

-

Lead commercial negotiations, pricing discussions, proposals, and contract execution

-

Work closely with product and engineering teams when technical support is required, while remaining accountable for moving the commercial process forward

-

Build relationships across the APAC AI and enterprise technology ecosystem

-

Represent 0G at relevant customer meetings, industry events, and conferences

-

Provide direct customer feedback to help shape our product, positioning, pricing, and go-to-market strategy

## What We're Looking For

-

Approximately **5–12 years of B2B technology sales experience**, although we care more about your track record than years of experience

-

A proven **quota-carrying enterprise sales** track record

-

Demonstrated experience personally sourcing, progressing, negotiating, and closing new enterprise customers

-

Strong new-business hunting skills and the ability to generate your own pipeline

-

Experience selling technically complex products or infrastructure

-

Comfortable selling to both technical stakeholders and senior business decision-makers

-

Strong commercial judgment and negotiation skills

-

Comfortable operating without a mature sales playbook, large support organization, or established brand

-

Able to move quickly, operate independently, and adapt as priorities and products evolve

-

Based in Singapore, Hong Kong, or other SEA countries, with strong knowledge of APAC enterprise markets

-

Fluent English communication skills

## Particularly Relevant Backgrounds

Experience selling any of the following is highly relevant:

-

AI infrastructure or GPU cloud

-

Cloud compute or infrastructure

-

Data infrastructure

-

Enterprise storage

-

Databases or data platforms

-

HPC or accelerated computing

-

Developer infrastructure

-

Infrastructure SaaS / PaaS

-

Data center or cloud connectivity solutions

Experience at an early-stage or high-growth technology company is a strong plus.

##

##

# What we offer

-

*Purpose*: The opportunity to contribute to making AI a public good

-

*Growth*: A self-directed environment where you can take initiative to shape your role and career

-

*Compensation*: Market-competitive compensation including, for most roles, exposure to pre-launch tokens

In addition, 0G Labs is committed to the health and well being of all of our team members. To that end, we provide reimbursements towards a holistic set of experiences and courses:

-

*Core self*: Transcendental Meditation

-

*Mind*: [Landmark Education](https://www.landmarkworldwide.com)

-

*Emotion*: Art of Communication

-

*Presence*: Speech Coach

-

*Body*: Fitness, gym and exercise memberships/classes

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
