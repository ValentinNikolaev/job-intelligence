# Steuerberater (m/w/d) in Passau

Posted: 2026-08-17T06:00:38Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

## Warum du bei uns genau richtig bist?!

WORK LIFE BALANCE

- flexible Arbeitszeiten & mobile Arbeitsplatzgestaltung sowie Home-Office Optionen

- attraktives Büro in zentraler, verkehrsgünstiger Lage

- Top-Büroausstattung (z.B. höhenverstellbare Schreibtische)

- moderne IT- und Telko-Ausstattung
FINANZEN & MEHR

- attraktives Gehalt mit Bonusoptionen

- 30 + 1 Urlaubstage

- Nettolohnoptimierungen wie z.B. Erholungsbeihilfe, Gutscheinkarte mit 50€ Aufladung pro Monat etc.

- Weihnachts- und Geburtstagsgeschenk

- bezahlter Parkplatz

- Kaffee, Getränke, Obst & Süßes kostenlos
SPASS & GESUNDHEIT

- Team-Events wie After-Work-Sessions, Sommerfest, Betriebsausflug, Weihnachtsfeier

- Sportliche Events wie z.B. InnRun, Stadtlauf etc.

- Gesundheitsangebote
ZUKUNFT

- interne und externe Fort- und Weiterbildungen sowie Coachings

- persönliche Weiterentwicklung und Karriereplanung

- ein nachhaltiges, resilientes & vielfältiges Unternehmen
KOMPETENZ

- Top-Kanzlei in Ostbayern - Steuerberatung, Wirtschaftsprüfung, Rechts- und Unternehmensberatung unter einem Dach

- über 140 Mitarbeitende, davon ca. 30 Berufsträger – ein starkes, interdisziplinäres und diverses Team (6 von 14 Partner sind Frauen)

- Große Mandantenvielfalt: Von kleinen Selbständigen bis hin zu internationalen Konzernen

## Der Job passt zu dir, wenn du...

- ein erfolgreich bestandenes Steuerberaterexamen und bereits Erfahrungen als Steuerberater mitbringst

- über sehr gute Kenntnisse in MS-Office Anwendungen als auch DATEV verfügst

- kommunikativ, motiviert und engagiert bist - mit dem "Blick über den Tellerrand hinaus"

- Team-Work genauso lebst wie selbständiges und eigeninitiatives Arbeiten

- Lust auf Herausforderungen und gemeinsame Ziele hast

## Welche Aufgaben dich bei uns erwarten:

- du bist verantwortlich für die Erstellung von Jahresabschlüssen, Steuererklärungen und Steuerbilanzen

- du begleitest bei steuerlichen Betriebsprüfungen

- du unterstützt bei steuerlichen Sonderfragen, Umstrukturierungsmaßnahmen und Steueroptimierungen

- du bist zuständig für die ganzheitliche Betreuung und Beratung unserer Mandanten

## Dein Kontakt zu uns

**Interesse?!**

Dann nutze jetzt deine Chance - bewirb dich schnell und unkompliziert über unser Bewerberportal.

Ein einfacher Klick direkt unten über den Button **"Jetzt im Portal bewerben".**

**Du hast noch Fragen?**

Unsere Kollegin Stefanie Purucker aus der Personalabteilung ist gern für dich da.

Telefon: 0991 / 320138 - 573

Wir freuen uns auf dich!

## Unsere Standorte

## Dr. Kittl & Partner

**Steuerberatung, Wirtschaftsprüfung, Unternehmensberatung und Rechtsberatung**
Standort Deggendorf, Bahnhofstraße 41, 94469 Deggendorf

Standort Passau, Erhardstraße 4, 94032 Passau

Standort Regensburg, Fritz-Fend-Straße 4, 93047 Regensburg

Standort Trostberg, Kirchenstraße 1, 83308 Trostberg

Standort München, Hohenzollernstraße 10, 80801 München

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
