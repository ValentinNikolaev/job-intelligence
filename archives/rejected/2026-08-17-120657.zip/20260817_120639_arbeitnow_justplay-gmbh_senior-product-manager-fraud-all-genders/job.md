# Senior Product Manager - Fraud (all genders)

Posted: 2026-08-17T05:40:06Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

JustPlay is searching for an experienced Senior Product Manager - Fraud to join our team to take ownership of safeguarding our players and protecting our platform’s integrity by designing, implementing, and optimizing innovative systems to detect and prevent fraud across our loyalty gaming ecosystem.

You’ll combine strategic product ownership with a hands-on, data-driven approach to solve emerging issues while building systems and tools that improve detection precision.

## **Job Responsibilities**

-

Define and own fraud prevention strategies, identifying risks across user journeys-from onboarding to engagement and payouts.

-

Develop and deploy real-time detection mechanisms, anomaly analytics, and proactive interventions to mitigate malicious behavior and abuse.

-

Collaborate with data, engineering, and product teams to build robust detection pipelines, alert systems, and responsive workflows.

-

Prioritize fraud-related KPIs such as false positives, chargeback rates, fraud velocity, and user friction metrics, driving continuous optimization.

-

Integrate A/B testing and iterative validation to refine detection models and user intervention flows.

-

Influence product design to incorporate fraud-resilient user experiences, while minimizing friction for legitimate players.

-

Stay informed on global fraud trends in mobile gaming and ad revenue-based platforms to keep our defenses innovative and effective.

## **Job Requirements**

-

4+ years of product management experience, ideally in digital products with complex user behavior and monetisation models

-

Strong experience in AdTech or ad monetisation, such as attribution, measurement platforms, or ad networks.

-

Strong analytical and data-driven mindset, with experience using behavioral data, patterns, and signals to improve product decisions.

-

Proficient in designing and measuring the impact of A/B tests in risk and fraud scenarios.

-

Skilled at cross-functional collaboration with engineers, analysts, and operations to drive implementation of scalable fraud solutions.

-

Excellent problem-solving mindset, analytical orientation, and strong communication skills.

-

**Nice to have:** Experience with behavioral fraud, KYC/identity verification, Trust & Safety, risk management, or fraud prevention.

##

## **Job Benefits**

-

**Work-Life Balance and Flexibility**: Flexible working hours and options for digital nomads, occasional office visitors, or regular office-goers

-

**Mental Health Support**: Free personal coaching through our partner [nilo.health](http://nilo.health) to support our team members to live fulfilled lives at home and at work

-

**Training & Development**: A competitive personal development budget of up to 2000€/year for training, conferences, workshops, etc.

-

**Germany-Based Benefits**: 25 vacation days, free [Wellhub](https://wellhub.com/de-de/) gold subscription, free monthly Deutschland-Ticket, and a monthly €50 tax-free internet contribution

-

**State-of-the-Art Equipment**: Doesn’t matter if you are a MacBook or Windows user; we will provide you with the technical gear you need to succeed

-

**A Relocation Package**: Includes visa support for those who need it

-

**Berlin Office Perks**: Ergonomic setup, free daily lunch, and a dog-friendly environment.

-

**Engaging and Diverse Work Environment:** Join a diverse team, with over 30 nationalities working from over 25 different locations

*Benefits may vary depending on location and contract type. Do not hesitate to ask us about more details on our benefits offer.*

## **About us**

Come join the team building the engine behind rewarded mobile gaming – making playtime truly rewarding. At JustPlay, we’re on a mission to power a fairer, more sustainable rewarded gaming ecosystem where users earn real value for their time through a self-sustaining model.

Since launching in 2020, we’ve grown into one of the world’s leading rewarded gaming platforms, with 25M+ downloads and 500K+ daily active users. Headquartered in Berlin and backed by NCSoft, one of the world’s leading gaming companies, we continue to operate fully independently – combining the speed, ownership, and ambition of a startup with the long-term backing of a global gaming powerhouse.

With a team across 20+ countries, we’re shaping a major shift in mobile gaming – and it’s still early enough for you to make your mark. At JustPlay, you’ll build end-to-end, move fast, and ship work that reaches millions – in a company that’s profitable, built to last, and focused on outcomes over hype.

##

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
