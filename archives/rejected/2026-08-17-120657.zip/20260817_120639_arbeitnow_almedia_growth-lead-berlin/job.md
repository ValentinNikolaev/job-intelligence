# Growth Lead - Berlin

Posted: 2026-08-17T08:40:13Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

This isn’t your regular job. Almedia is a place where those who want to push harder can accelerate their careers faster than anywhere else. We’re aiming to become Germany’s second bootstrapped unicorn. Almedia is already Europe’s #3 fastest-growing company in 2025 (FT1000).

We are building the future of marketing by rewarding our community of over 70 million users for engaging with our advertisers’ products. We are offering a new way to acquire users for the biggest companies in the world.

At Almedia, you’ll:

-

**Own way more, way earlier** — you’ll be trusted with responsibility fast.

-

**Push harder, get further** — this isn’t a 9–5. We highly reward intensity.

-

**Join a rare environment** — you will work with ambitious high-speed, high-ownership people.

-

**Fully present** — we’re 5 days a week in the office to build the energising momentum we need.

**Salary OTE:** €150K • Offers Equity • Offers Bonus

We are looking for a powerhouse **Lead Growth Manager** to become the a dedicated leader for our Growth (CSM) team. Reporting directly to the CEO, you will be the architect of our go-to-market engine. This is a dual-impact role: you will lead, coach, and motivate a high-performing team while remaining "in the trenches" to close strategic partnerships with the world’s top mobile game publishers.

You will own end-to-end growth by building a high-accountability CSM culture and a repeatable GTM playbook. You will turn publisher insights into product strategy, move fast to scale our outbound motion, and raise the bar on execution across the entire lifecycle—from first contact to long-term integration.

##

## What You’ll Do 🎯

-

**Architect the GTM Playbook:** Build and own a repeatable outbound sales motion. You’ll define our segmentation, messaging, and CRM workflows to ensure the team executes with speed and precision.

-

**Lead from the Front:** Personally drive Tier-1 deals from discovery to signed integration. You will land key accounts that serve as the "win stories" to unlock the rest of the market.

-

**Scale & Mentor the Team:** Manage, motivate, and develop the CSM team. You’ll be responsible for their KPIs, career growth plans, and day-to-day coaching to foster a culture of extreme ownership.

-

**Bridge Product & Market:** Create a tight feedback loop with Product and Engineering. You will translate publisher needs into a prioritized backlog, ensuring our roadmap is aligned with what the market actually buys.

-

**Operational Excellence:** Define the rituals of success—qualification standards, pipeline hygiene, and forecasting. You will provide the CEO with a live, transparent view of deal health and unblock the team to keep opportunities moving.

## What You’ll Bring 💡

-

**The "Player-Coach" DNA:** You have a proven track record of running full-cycle enterprise sales (prospect → pitch → close) while simultaneously managing a team of 2–5 people.

-

**Pipeline Mastery:** You know how to build an outbound engine from scratch. You are comfortable experimenting with A/B outreach, sequencing, and offer tests to find what sticks.

-

**Strategic Communication:** You can translate complex product features into quantified ROI for Monetization and LiveOps leaders at major game studios.

-

**High-Stakes Leadership:** You give candid feedback, address performance early, and know how to keep a remote or multi-geo team (Berlin/China/Israel) engaged and hungry.

-

**Operational Rigor:** You don’t just "do sales"—you build systems. You are a power user of CRM data and live by pipeline hygiene.

## What Makes You a Great Fit 🌟

-

**Own Everything:** You care deeply about the team's performance and see every roadblock as an opportunity to build a better process.

-

**Move Fast:** You thrive in the ambiguity of an early-stage environment and can pivot strategies without losing momentum.

-

**Focus on Impact:** You prioritize the 20% of activities that drive 80% of the revenue. You are obsessed with results, not just "being busy."

## Why Almedia? 🎁

-

**Scale With Almedia:** Have a real impact and grow alongside a startup that has been profitable from day one.

-

**High-Growth Environment:** We encourage all staff to take ownership of projects and consistently raise the bar.

-

**Do More, Get More:** Generous bonus scheme to ensure great, proactive work is valued.

We believe in fostering talent, evaluating all skill levels during the hiring process, and providing a clear path for growth. Almedia is an equal opportunity employer. We embrace and celebrate diversity, and encourage individuals from all backgrounds to apply.

Compensation: €100K – €120K • €20K – €30K Equity • Offers Bonus • OTE: €150k

- • Base Salary €100K – €120K • €20K – €30K Equity • Offers Bonus • OTE: €150k

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
