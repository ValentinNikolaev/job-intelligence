# Working Student

Posted: 2026-08-17T02:24:18Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Novaspace is seeking a working student, based in Munich, to support our firm both with administrative tasks and analytical work for our clients. The ideal candidate will be highly organised with excellent attention to detail and will be able to work well under pressure.

Our consulting service lines span strategy, market development and innovation advisory. We are looking for motivated, experienced professionals to support on and lead typical consultant tasks such as: sector and market entry strategies, economic and cost benefit analyses, investment business cases, impact assessment of policy options, market studies, strategic and business planning, user requirement gathering and analysis, program and project management. The role includes interaction with clients, partners and program stakeholders with exposure to senior decision-makers in the space ecosystem, both in industry and government.

If this sounds like you, then read on!

**Your tasks include supporting our projects in the space domain such as:**

- Desktop research and analysis

- Drafting project reports

- Preparation of presentations

- Support to administrative & financial processes

- Providing general & administrative support to colleagues and management

**We offer**

- Opportunity to develop your management consultancy skill set

- Exciting work topics to showcase technology affinity

- International work environment in an attractive area of downtown Munich

- Intellectual challenges paired with work-life balance and limited travel

- Developing a unique network among stakeholders in the aerospace and security sectors

**Desired skills & experience**

- Strong academic background

- Fully fluent in English

- Good problem solving skills, aptitude for quantitative and qualitative analytics, good writing and presentation skills

- Fast learner, flexible, organised, meticulous and detail-oriented

- Ability to work independently and yet to work effectively and nicely in a team

**Any of the following would be a plus**

- Experience in space business, earth observation, satellite navigation, transport policy, mobility, and security matters

- Engineering/ scientific background / interest in space technology

- Working proficiency in a second or more European languages, e.g.: French, German, Italian, Spanish, Czech, Polish ...

**About Novaspace**

Novaspace is the global leading consulting firm in the space sector. With a robust 40-year legacy of expertise in guiding private companies and government entities through strategic decisionmaking processes, Novaspace offers end-to-end consulting services, from project strategy definition to implementation, providing data-led perspectives on critical issues. Our mission is to empower clients with strategic and technical insights, enabling them to navigate and seize new opportunities within the rapidly evolving space sector. As a privately owned and fully independent organization, Novaspace presents an expanded portfolio of services, featuring combined expertise in management and technology consulting, top-tier executive summits, and market intelligence. Trusted by 1,200 clients in over 60 countries, Novaspace has offices strategically located in Brussels, Montreal, Munich, Paris, Singapore, Sydney, Tokyo, Toulouse, and Washington D.C. Working at Novaspace will give you the opportunity to boost your career in the space/consulting industry where our role is to support the decision-makers by providing them the highest quality support in everything we do: consulting, market intelligence, training and summits.

Only Applications containing a Motivation Letter and a CV in English will be considered.

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
