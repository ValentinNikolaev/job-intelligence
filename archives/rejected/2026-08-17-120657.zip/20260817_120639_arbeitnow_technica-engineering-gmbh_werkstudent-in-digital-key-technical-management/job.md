# Werkstudent:in Digital Key technical/management/marketing (m/w/d)

Posted: 2026-08-17T05:30:06Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**Lust auf neueste Technologien, spannende Projekte und ein tolles Team, das dich gerne in seiner Mitte willkommen heißt? Perfekt. Dann komm zu uns!**

-

Du bewirbst dich auf eine Stelle bei der Technica Engineering GmbH am Standort München.

-

Technica Engineering GmbH ist Teil der Technica Firmengruppe mit aktuell ca. 1000 Mitarbeiter:innen weltweit.🌍

**Technica Engineering GmbH** ist ein produzierendes Elektronik-Unternehmen im Bereich der Entwicklung von Fahrzeugen. Wir entwickeln und produzieren eigene Software und elektronische Produkte, ebenso wie wir unseren Kunden bei neuen Entwicklungs- und Testprojekten beratend zur Seite stehen. Unsere technische Spezialisierung im Bereich Automotive Ethernet und Steuergeräteentwicklung ermöglicht uns, technische Lösungen zu Themen wie Embedded Steuergeräte, Bordnetze, ADAS, Security, Body Funktion, Komfort Funktion, Gateway u.v.a. anzubieten.

Aktuell bieten wir eine Position als** **

**Werkstudent:in Digital Key technical/management/marketing (m/w/d)**

für unsere Niederlassung in München sowie im Allgäu (Türkheim, Mindelheim).

Diese Position ist auf eine Wochenarbeitszeit von 16 - 20h ausgelegt.

**Deine Aufgaben mit dem Team:**

-

Unterstützung im technischen Projektalltag

-

Software-Tests am Testsystem sowie direkt am Fahrzeug

-

Mitarbeit im Test- und Problemmanagement

-

Unterstützung bei Logistikthemen, z. B. beim Versand von Testsystemen und bei der Prozessgestaltung im HIL-Aufbau

-

Erstellung von Präsentationen und Dokumentationen

-

Mitwirkung bei der Entwicklung von Marketing- und Social-Media-Inhalten

**Das bieten wir dir:** Wir bieten dir die Möglichkeit, praktische Erfahrungen in den Bereichen Testing, Absicherung und Projektmanagement zu sammeln und dein Wissen aktiv in ein dynamisches Team einzubringen. Du erhältst Einblicke in die Abläufe eines international tätigen Unternehmens sowie in die technische Umsetzung unserer Kundenprojekte. Zudem kannst du dein theoretisches Wissen direkt in der Praxis anwenden.

**Wir freuen uns, wenn du Folgendes mitbringst:**

-

Studium im Bereich Elektrotechnik, Mechatronik oder in einem vergleichbaren Studiengang, idealerweise mit Interesse an Medien- bzw. Kommunikationsdesign

-

Erste Erfahrungen im Bereich Automotive oder Software-Testing sind von Vorteil

-

Gute Kenntnisse in MS Office, insbesondere Excel und PowerPoint (gerne mit Nutzung von KI-Tools)

-

Teamfähigkeit und Kommunikationsstärke

-

Zuverlässige und selbstständige Arbeitsweise

-

Gute Deutsch- und Englischkenntnisse

**Unser Angebot lässt dein Herz höher schlagen ❤**

-

Außergewöhnliche Work- Life Balance: – Flexible Urlaubsgestaltung – Weil du am besten weißt, wann du eine Pause brauchst.

-

Gleitzeitmodell – ob früher Vogel oder Nachteule – Du kannst deinen Arbeitstag flexibel gestalten.

-

Wir sind Multi-Kulti und leben eine außerordentliche **DIVERSITY **von sehr vielen Nationalitäten und Kulturen - voll integriert im Arbeitsalltag*.

-

Großes Schulungsangebot über die Technica Academy – damit du dich bei uns zielgerichtet weiterbilden kannst.

-

Eine sehr gute Vergütung und ein umfangreiches Paket an attraktiven betrieblichen Sozialleistungen.

-

Unsere Benefits sind vielfältig: Wir bieten dir unter anderem ein monatliches Guthaben über die guudcard sowie Unterstützung in allen Lebenslagen mit unserem meinEAP. Zusätzlich schenken wir dir Zeit für soziales Engagement mit einem bezahlten Volunteering Day.

-

Eine auf Forschung und Entwicklung ausgerichtete Unternehmenskultur mit einer klaren Reinvestitionsmentalität. Ein Unternehmen, das von Ingenieur:innen gemacht und von Ingenieur:innen geführt wird.

Unser Talent Acquisition Team freut sich auf dich.
Bei Fragen melde dich gerne bei uns.

Erzähle uns von deinem Talent und schick deine Bewerbung über unser Online-Formular damit deine Karriere bei **Technica **beginnen kann.

*Diversität und Inklusion sind für uns keine Trends, sondern fest in unserer Unternehmenskultur verankert. Daher begrüßen wir alle Bewerbungen, unabhängig von Geschlecht, Alter, Behinderung, Religion, ethnischer Herkunft oder sexueller Identität. Wir gewährleisten Chancengleichheit für alle Kandidat: innen im gesamten Bewerbungsprozess und lehnen jede Form von Diskriminierung oder Belästigung ab.

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
