# Senior Software Developer – Async Architecture & Concurrency (m/w/d)

Posted: 2026-08-17T07:20:13Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

#### **Hochtechnologie und Innovation...**

…aktiv mitgestalten und vorantreiben – für diese Position suchen wir eine engagierte Persönlichkeit (m/w/d), die mit Ideenreichtum, Verantwortungsbewusstsein und fachlicher Kompetenz überzeugt. Als Beratungsunternehmen unterstützen wir unseren Kunden bei der Suche nach einer passenden Person, die Herausforderungen nicht als Hürde, sondern als spannende Möglichkeit zur Weiterentwicklung versteht.

#### **Das erwartet dich:**

-

Modernisierung komplexer **.NET-Anwendungen** mit Fokus auf Asynchronität, Threading und Anwendungsperformance

-

Migration synchroner Legacy-Codebasen in stabile **Async-/Await-Architekturen** mit geeigneten Übergangsstrategien

-

Entwicklung robuster Integrationskonzepte zwischen synchronen und asynchronen Komponenten mittels moderner Architekturmuster

-

Analyse und Behebung komplexer **Concurrency-, Threading- und Performance-Probleme** in produktiven Anwendungen

-

Gestaltung skalierbarer Desktop-Architekturen mit **WPF**, WinForms und performanter UI-Thread-Kommunikation

-

Definition von Best Practices für Cancellation, Fehlerbehandlung, Ressourcenmanagement und reproduzierbare Qualitätssicherung

-

Technische Beratung zu **Async-Paradigmen**, Softwarearchitektur, Refactoring und schrittweiser Modernisierung großer Softwarelandschaften

Für diese Position sind bestimmte fachliche und persönliche Voraussetzungen hilfreich. Die folgenden Anforderungen geben dir einen Überblick darüber, welche Erfahrungen und Eigenschaften für diese Rolle von Vorteil sind.

#### **Was du mitbringen solltest:**

-

Studium der Informatik, Software Engineering oder vergleichbare Qualifikation sowie mehrjährige **C#/.NET**-Erfahrung

-

Fundierte Praxis mit **Async/Await**, SynchronizationContext, Task Scheduler, ConfigureAwait und hybriden Sync-/Async-Architekturen

-

Erfahrung mit Deadlocks, Race Conditions, Thread-Pool-Exhaustion und komplexen Multi-Threading-Fehlerbildern

-

Mehrjährige Kenntnisse in **WPF**, WinForms, Dispatcher und performanter Entkopplung rechenintensiver UI-Prozesse

-

Erfahrung mit Profiling und Diagnosewerkzeugen wie **Visual Studio Diagnostics** oder PerfView

-

Praxis in Legacy-Modernisierung, Refactoring, Softwarearchitektur und automatisierten Tests für Concurrency-Szenarien

-

Erfahrung als technischer Lead, Coach oder Mentor sowie mit Architekturstandards und statischer Codeanalyse

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
