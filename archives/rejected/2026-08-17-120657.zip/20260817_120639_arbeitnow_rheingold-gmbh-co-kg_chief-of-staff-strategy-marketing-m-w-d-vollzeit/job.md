# Chief of Staff -Strategy & Marketing (m/w/d) - Vollzeit-Köln-Start November 26

Posted: 2026-08-17T08:30:31Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Du möchtest eng mit der Geschäftsführung zusammenarbeiten, strategische Entscheidungen mitgestalten und Verantwortung für unternehmensweite Projekte übernehmen? Du denkst analytisch, handelst unternehmerisch und möchtest dich in einem anspruchsvollen Umfeld fachlich und persönlich weiterentwickeln?

Dann bist du bei uns genau richtig.

Als **Chief of Staff Strategy & Marketing** arbeitest du direkt mit der Geschäftsführung zusammen und unterstützt sie bei strategischen und operativen Fragestellungen. Du koordinierst bereichsübergreifende Projekte, entwickelst neue Ideen und sorgst dafür, dass wichtige Initiativen erfolgreich umgesetzt werden. Dabei erhältst du umfassende Einblicke in die Führung und Weiterentwicklung eines erfolgreichen Beratungsunternehmens.

## Aufgaben

**Strategie & Unternehmenssteuerung**

- Du steuerst bereichsübergreifende strategische Projekte und unterstützt unsere CEO bei wichtigen Initiativen und Entscheidungen.

- Du strukturierst komplexe Themen, bereitest Management- und Executive-Meetings vor und sorgst für eine konsequente Umsetzung beschlossener Maßnahmen.

- Du schaffst Transparenz über Ziele, KPIs und Fortschritte und unterstützt bei der Weiterentwicklung von Prozessen und Strukturen.

**Marketing & Geschäftsentwicklung**

- Du entwickelst unsere Marketingstrategie und Positionierung gemeinsam mit der Geschäftsführung weiter.

- Du steuerst und optimierst unsere Online-Marketing-Aktivitäten anhand relevanter KPIs.

- Du entwickelst Vertriebs- und Leadgenerierungsinitiativen zur Gewinnung neuer Kunden.

- Du unterstützt Go-to-Market-Initiativen für neue Angebote und Leistungen.

- Du steuerst externe Dienstleister und arbeitest eng mit PR, Vertrieb und interner Kommunikation zusammen.

## Qualifikation

- Ein abgeschlossenes **wirtschaftswissenschaftliches Studium**, idealerweise mit Schwerpunkt Marketing oder Strategie

- Erste Berufserfahrung, vorzugsweise in einer **Unternehmensberatung, Strategie oder im Marketing**

- Ausgeprägte analytische und konzeptionelle Fähigkeiten sowie eine strukturierte Arbeitsweise und Spaß an der Umsetzung

- Unternehmerisches Denken, hohe Eigeninitiative und Freude daran, Verantwortung zu übernehmen

- Kommunikationsstärke und ein sicheres Auftreten

- Sehr gute Deutsch- und Englischkenntnisse

## Benefits

**Das erwartet dich**

- Eine verantwortungsvolle Position mit direkter Anbindung an die Geschäftsführung

- Ein abwechslungsreiches Aufgabenspektrum mit hoher strategischer Relevanz

- Viel Gestaltungsspielraum und kurze Entscheidungswege

- Ein hybrides Arbeitsmodell und ein modernes Arbeitsumfeld im Herzen von Köln

- Individuelle Möglichkeiten zur fachlichen und persönlichen Weiterentwicklung

**Interesse?**

Dann freuen wir uns auf deine Bewerbung mit Lebenslauf, relevanten Zeugnissen sowie deiner Gehaltsvorstellung und dem frühestmöglichen Eintrittstermin.

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
