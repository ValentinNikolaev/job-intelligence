# Projektingenieur/in (m/w/d)

Posted: 2026-08-17T07:30:43Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

SEGURA ist eine Industriegruppe, die sich auf das Design, die Entwicklung und die Industrialisierung von Metallteilen und Komponenten für die Automobilindustrie spezialisiert hat, hauptsächlich durch Stanz- und Schweißverfahren.

Die Gruppe beschäftigt derzeit 1500 Mitarbeiter, die auf verschiedene Standorte verteilt sind: Almussafes (Spanien), Vigo (Spanien), Szolnok (Ungarn), Deutschland (Treuenbrietzen und Eisenach) und den Hauptsitz in Paterna (Spanien).

Zur Verstärkung unseres Teams suchen wir zum nächstmöglichen Zeitpunkt eine/n **Process Launch Engineer** (m/d/w)

## Aufgaben

- Projekte planen, koordinieren und bis zum erfolgreichen Abschluss begleiten

- Projektfortschritt mithilfe der Kundensysteme (z. B. APQP, LiOn, BeON, ITP) überwachen sowie Termine, Meilensteine und Kundenanforderungen sicherstellen

- Projektunterlagen und Dokumentationen termingerecht erstellen und pflegen

- Kunden von der Prototypen- und Vorserienphase bis zur PSW-Freigabe und zum Serienstart betreuen und unterstützen

- Mit internen Fachbereichen zusammenarbeiten und bei Abweichungen geeignete Korrekturmaßnahmen einleiten

- An Besprechungen und Audits teilnehmen

- Vorgaben zu Qualität, Arbeitssicherheit, Umweltschutz, Vertraulichkeit und Informationssicherheit einhalten

## Qualifikation

- Abgeschlossenes Ingenieurstudium

- Gute Englischkenntnisse

- Problemlösungsorientierte Denkweise

- Strukturierte und eigenverantwortliche Arbeitsweise

- Selbstständigkeit

- Entscheidungsfreude sowie ein hohes Maß an Verantwortungsbewusstsein

## Benefits

- Bei Grupo Segura finden Sie ein dynamisches und enges Arbeitsumfeld mit einer starken Teamkultur.

- Wir bieten Ihnen die Mitarbeit in einem stabilen und ständig wachsenden Projekt, mit professionellen Entwicklungsprogrammen, um Ihre Karriere voranzutreiben, sowie die Möglichkeit, an internationalen Projekten der Gruppe teilzunehmen.

- Werden Sie Teil eines zukunftsorientierten Unternehmens, das sich der Verantwortung für die Umwelt und einer nachhaltigen Zukunft verschrieben hat.

- leistungsgerechte Vergütung

- Soziale Vorteile

- Wenn Sie das Gefühl haben, dass Sie eine Person mit Problemlösungskompetenz sind und vor allem mit Leidenschaft bei der Sache sind, dann bewerben Sie sich und werden Sie Teil unseres Teams! Bei Grupo Segura gehört die Chancengleichheit zu unseren Werten.

- Wir gestalten die Zukunft mit Ihnen

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
