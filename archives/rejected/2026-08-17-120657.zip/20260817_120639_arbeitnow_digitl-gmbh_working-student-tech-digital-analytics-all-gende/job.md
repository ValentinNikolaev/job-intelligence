# Working Student - Tech Digital Analytics (All Genders)

Posted: 2026-08-17T10:30:33Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Digitl ist ein junges und innovatives Unternehmen im Bereich Marketing und Cloud-Technologie. In einem kollaborativen und funktionsübergreifenden Umfeld entwickeln wir neue Konzepte, um unsere Kunden aus den unterschiedlichsten Branchen in eine digital-getriebene Zukunft zu führen. Sei Teil davon, und bringe als Werkstudent im Bereich Digital Analytics deine eigenen frischen Ideen ein.

Aufgaben

- Du unterstützt uns im Digital Analytics Team bei interessanten, technischen Implementierungsprojekten rund um server-side Tracking und bekommst dadurch einen guten Einblick in die Arbeit mit den neuesten Technologien im digitalen Marketing.

- Im Tagesgeschäft hilfst du beim Aufsetzen und Testen von Tracking-Setups, bei der Fehleranalyse und beim Debugging sowie bei kleineren Aufgaben rund um unsere Google-Cloud-Infrastruktur.

- Du erhältst sehr schnell deine eigenen Aufgaben und die Verantwortung, diese eigenständig zu bearbeiten.

Qualifikation

- Du bist an einer Hochschule eingeschrieben, z.B. im Bereich Informatik, Digitalisierung, Betriebswirtschaft, Marketing oder Ähnlichem.

- Du bringst erste Berührungspunkte mit einer Programmiersprache wie JavaScript mit.

- Du hast ein gutes technisches Verständnis und Lust, dich in Themen wie server-side Tracking und Cloud einzuarbeiten.

- Du bist ein echter Teamplayer und kannst dich sowohl auf Deutsch als auch auf Englisch gut verständigen.

- Du stellst dich Herausforderungen und hast eine natürliche Neugier an neuen Themengebieten.

Perks & Benefits

- Flexible Arbeitszeiten - um deinen Studienplan zu berücksichtigen.

- Co-Working - dir steht ein Platz in den besten Co-Working Spaces in Düsseldorf, Zürich, Barcelona oder Hamburg zur Verfügung.

- Remote 1st - alle unsere Prozesse sind auf dezentrales Arbeiten ausgelegt. Du entscheidest, ob du lieber in deinem Home Office arbeiten oder deinen Tag in einem unserer Büros verbringen.

- Home Office Equipment - deine digitale Arbeitsumgebung kommt direkt zu Dir nach Hause

- Animal Lovers - Hunde sind bei uns willkommen und dürfen dich in unsere Offices begleiten.

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
