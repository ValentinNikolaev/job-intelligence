# Werkstudent Campaign Management/Ad Operations (m/w/d)

Posted: 2026-08-17T02:30:18Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

## Werde Teil eines starken Teams bei emetriq!

emetriq, Teil der Deutschen Telekom AG, bietet datengetriebene Online-Advertising-Lösungen und setzt sich für fairen Datenzugang als Treibstoff für Innovation und Vielfalt ein. Mit unserer Expertise und Technologiekompetenz steigern wir die Präzision und Relevanz von Online-Werbung. Als Initiatoren des größten kollaborativen Datenpools in Deutschland vereinen wir über 100 Data- und Mediaexperten.

Im Geschäftsbereich T-Ads verbinden wir Daten, Technologie und digitale Werbeflächen, um Werbung relevanter und messbarer zu machen. Dafür kombinieren wir anonymisierte Daten aus der TV- und App-Nutzung mit einem der größten Consented-Datenpools Deutschlands. Die T Advertising Platform ergänzt diese Datenbasis um exklusive Telco-Daten aus 27 Millionen anonymisierten Profilen und smarte Geo-Aktivierung. So unterstützen wir Unternehmen dabei, die richtigen Zielgruppen über verschiedene digitale Kanäle zu erreichen und ihre Kampagnen wirkungsvoll auszusteuern.

Zur Verstärkung unseres **T-Ads Teams** suchen wir ab sofort einen **Werkstudenten im Campaign Management**. In dieser Position unterstützt du unser Sales Team und kannst wertvolle Erfahrungen sammeln sowie erste Verantwortung übernehmen.

## Wie du uns helfen kannst

-

**Campaign Management:** Mit Deiner Kompetenz unterstützt Du bei der Umsetzung sowie Abwicklung von programmatischen & DOOH-Kampagnen

-

**Auftragsbearbeitung:** Du prüfst Aufträge auf ihre Machbarkeit, erstellst Auftragsbestätigungen und bist zuständig für die Buchung der Aufträge in unserem Buchungssystem

-

**Koordination:** Du koordinierst die Kommunikation und Abläufe zwischen dem Sales- und Marketing-Team

-

**Reporting:** Du übernimmst die Nachbereitung von Kampagnen und erstellst Reportings

## Was du mitbringst

-

**Immatrikulation:** Du befindest dich im Studium der BWL, Wirtschaftspsychologie, Sales Management oder einem vergleichbaren Fachbereich

-

**Kenntnisse:** Du hast idealerweise bereits praktische Erfahrungen im Sales Support / Vertriebsinnendienst

-

**Erfahrungswerte: **Erste Erfahrung im Marketing, insbesondere im OOH-Bereich und im Umfeld der Mediaagenturen sind von Vorteil

-

**Eigenverantwortung:** Du arbeitest eigenständig, proaktiv und strukturiert, um Aufgaben effizient zu erledigen

-

**Analytische Fähigkeiten:** Du bringst ein hohes Maß an analytischen und Multitasking-Fähigkeiten mit

-

**Teamarbeit:** Du schätzt es, sowohl selbstständig als auch im Team an Lösungen zu arbeiten

-

**Kommunikationsfähigkeit:** Du beherrschst Deutsch auf sehr gutem Niveau und drückst dich eloquent aus

## Was uns besonders macht

Wir bei emetriq sind ein Team aus Experten, die gemeinsam wachsen und das Unternehmen voranbringen möchten. Unsere Arbeit basiert auf Vertrauen, Agilität, Selbstorganisation und Eigenverantwortung – ohne starre Hierarchien, aber mit klaren Entwicklungsperspektiven. Mut zur Veränderung, Arbeiten auf Augenhöhe und teamübergreifende Zusammenarbeit prägen unsere Kultur.

**Wir suchen Menschen, die unsere Leidenschaft für Daten und Innovation teilen.** Perfektion ist nicht unser Ziel, aber Engagement und kontinuierliche Weiterentwicklung – Schritt für Schritt.

## Unsere Benefits

-

**Hybrides Arbeiten:** Einmal pro Woche im Büro zur intensiven Zusammenarbeit. An den anderen Tagen entscheidest du selbst, ob du im Büro oder von zuhause arbeitest

-

**Flexible Arbeitszeiten:** Keine festen Kernzeiten – arbeite nach deinen eigenen Bedürfnissen

-

**Mobilität:** Unterstützung durch JobRad und das Deutschlandticket

-

**Vergünstigungen:** Telekom-Produkte zu attraktiven Konditionen und eine Benefit-Card ohne Zuzahlung

-

**Teamgeist und Events:** Von Workshops und Strategietagen bis hin zu Sport-Events und Feierabendtreffen auf unserer Dachterrasse

-

**Verpflegung:** Kostenlose Getränke, Siebträgermaschine, Snacks und eine Dachterrasse mit Aussicht

**Klingt das nach deinem nächsten Schritt?** Dann freuen wir uns auf deine Bewerbung und darauf, gemeinsam die Zukunft des datengetriebenen Marketings zu gestalten!

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
