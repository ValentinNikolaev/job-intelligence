# Go To Market Lead, DACH

Posted: 2026-08-17T08:55:29Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

## **About Gigs**

At Gigs, we're building the operating system for mobile services—a platform that lets tech companies embed global connectivity into their products effortlessly.

Just as Stripe lets any business add a payment button in seconds, Gigs empowers platforms to weave in connectivity—bridging the traditional world of telecom with modern tech. From fintechs launching mobile services to HR platforms offering work phone plans, we automate provisioning and remove telecom complexity.

Our team of around 150 people across the US and Europe, backed by nearly $100 million in funding from Ribbit Capital, Google, and Y Combinator. As one of the fastest-growing tech companies, bringing together early-stage engineers, product builders, and business athletes from companies like Stripe, Airbnb, and Shopify. We’re tackling deep technical and regulatory challenges to make connectivity truly seamless.

If you’re driven by curiosity, creativity, and the chance to shape the future of telecom, we’d love to hear from you.

## **Things We Care About**

We are building in a highly complex space and tackling a massive problem. We want people who lean in when things get hard.

- **Speed. **We move and we ship. We set bold deadlines and treat every week like it matters.

- **Ownership.** If you see something broken, fix it. We don't wait for permission.

- **Customer Obsession**. Our customers' product is our product.

- **Ambiguity. **We're building frontier technology in a complex domain. You'll need sound judgement and good instincts to make decisions without complete information.

- **First principles. **We don't ask how things have been done before. We ask why they were done that way at all.

## **The Role**

DACH is one of the most exciting European markets for Gigs. With world-class fintech infrastructure, highly digitised economies, strong telecom ecosystems, and some of Europe’s most sophisticated B2B buyers, the region is a natural fit for what we’re building.

We’re looking for a Go to Market (GTM) Lead to own our DACH strategy and execution end-to-end - from landing lighthouse customers and building operator partnerships to setting up and growing a high-performance regional team.

**Salary range: **€125,000 - €150,000 basic salary + sales commission plan.

(The final offer depends on your background, skills, and how you perform through the process. We're open to considering outlier candidates, which may result in an adjustment to the scope and compensation)

## Work At Gigs

At Gigs, we value in-person collaboration. We believe the best ideas, decisions, and relationships are built when teams spend meaningful time together, and our culture is designed around that belief. We support flexibility where it makes sense. Some focused work can be done remotely, and not every role or week looks the same. **You should expect regular time in one of our** **hubs**, as well as occasional travel for team workshops, customer meetings, and **Gigs Republic, our bi-annual company off-site**. Our offices are designed to feel like home-inspired workspaces, with plants, thoughtful tools, and small, tight-knit teams that make collaboration feel natural, energizing, and effective.

## What We Offer

At Gigs, we believe in rewarding excellence. We offer competitive compensation and stock options because we see you as a true partner in our growth. We also provide stipends for your home office or work setup, a budget for learning and development to fuel your career, and of course, a free phone and international data plan

*Want to learn more about our benefits, hubs, and what it’s like to work at Gigs? Check out our [Careers](https://gigs.com/careers) page.*

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
