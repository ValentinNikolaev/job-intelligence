# EPC Manager / Owner's Engineer (m/w/d) - Utility-Scale Solar, BESS, Wind

Posted: 2026-08-17T10:00:41Z

## Rejection

- Category: tech_stack
- Reason: role does not mention Go/Golang or PHP

Die Renergo entwickelt bundesweit große PV-Freiflächen, Windparks und Batteriespeicher (BESS) – und geht als unabhängiger Stromerzeuger (IPP) nun den nächsten Schritt: vom reinen Projektentwickler zum Betreiber eigener Anlagen.

Für den Aufbau unseres EPC-Managements suchen wir erfahrene Kolleg:innen, die echte Verantwortung übernehmen und kurze Entscheidungswege mögen – du berichtest direkt an die Geschäftsführung. Als erste Besetzung in diesem Bereich gestaltest du ihn bei uns – einem dezentralen Team von rund 18 Menschen – von Grund auf mit und bewegst gemeinsam mit uns etwas gegen den Klimawandel.

## Aufgaben

- Technische Gesamtverantwortung im EPC-Management insbesondere unserer PV- und BESS-Projekte – als zentrale technische Instanz (Owner's Engineer) gemeinsam mit den bestehenden Projektmanagern von Renergo

- Erstellung und Durchsetzung interner technischer Vorgaben und Spezifikationen

- Technische Bewertung von Lösungen und Komponenten – z. B. Batteriespeichertypen, Hersteller, Degradationskurven und Systemauslegung

- Begleitung und Abnahme über den gesamten Projektzyklus: Factory Acceptance Tests (FAT), Baustellenkontrollen und Abnahmen vor Ort gemeinsam mit den EPC-Contractoren / Subunternehmern

- Steuerung der EPC-Verhandlung komplexer Liefer- und EPC-Verträge inkl. technischer Vorgaben und Zahlungsbedingungen – in Abstimmung mit der kaufmännischen Seite und dem Projektmanagement

- Unterstützung bei der Erstellung von technischen Planungen und Leistungsverzeichnissen, insbesondere im Bereich Netzanschluss- und Kabeltrassenplanungen, PV-Auslegungen.

## Qualifikation

- Mindestens 5 Jahre einschlägige Berufserfahrung im EPC-Management, Owner's Engineering oder in der technischen Projektrealisierung von PV-Freiflächen und/oder Batteriespeichern (BESS) in Deutschland – **kein Quereinstieg**

- Abgeschlossenes Studium der Elektro-, Energie- oder Bautechnik bzw. eine vergleichbare Qualifikation

- Fundiertes technisches Know-how zu PV- und/oder BESS-Systemen, Komponenten und Herstellern; Erfahrung mit FAT und Bauabnahmen

- Erfahrung in der Verhandlung und vertraglichen Gestaltung komplexer Liefer-/EPC-Verträge inkl. Zahlungsbedingungen

- Bestehendes Netzwerk und konkrete Marktkenntnis im deutschen PV-/BESS-Umfeld

- Reisebereitschaft für Vor-Ort-Termine (Baustellen, Termine mit Lieferanten, FAT)

- Verhandlungssichere Deutsch- **und** verhandlungssichere Englischkenntnisse (internationale Supplier)

- Selbstständige, verantwortungsvolle Arbeitsweise und der Wille, echte Verantwortung zu übernehmen.

## Benefits

- Unbefristetes Arbeitsverhältnis mit 30 Tagen Jahresurlaub

- Attraktives Bonusmodell

- Flexible Arbeitszeiten

- Remote Arbeitsweise

- iPhone mit Privatnutzung

- Geschäftswagen mit Privatnutzung (nach der Probezeit)

- Monatlicher Zuschuss zu den Kinderbetreuungskosten von bis zu 100 Euro pro Kind

- Zuschuss zu Sport/Fitnessstudio

- Individuell zugeschnittene Weiterbildungsmöglichkeiten & Entwicklungsmöglichkeiten

- Sinnvolle Arbeit in einer aufstrebenden Branche: Lass uns gemeinsam etwas gegen den Klimawandel tun!

Du willst nicht verwalten, sondern gestalten? Dann bring deine Erfahrung und dein Netzwerk in ein Team ein, das die Energiewende konkret umsetzt. Wir freuen uns auf deine Bewerbung!

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
