# Werkstudent HR Recruiting Fach-& Führungskräfte (m/w/d)

Posted: 2026-08-17T07:20:13Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Die CURRENTA GRUPPE sucht **Dich** für unser Recruiting-Team.

Als **Werkstudent*in HR Recruiting Fach-& Führungskräfte** bist Du für die folgenden Aufgaben verantwortlich:

-

Du unterstützt das Team bei der **Rekrutierung** **qualifizierter Fach- und Führungskräfte**.

-

Du sichtest und bewertest **eingehende Bewerbungsunterlagen**, erstellst und **publizierst Stellenanzeigen**.

-

Du kümmerst dich eigenverantwortlich um den **Austausch mit Kandidat*innen **und unseren** internen Fachbereichen.**

-

Du pflegst das **Bewerbermanagementsystem, **koordinierst **Interviews** und hast auch die Möglichkeit Vorstellungsgespräche zu begleiten.

-

Du wirkst bei **Projekten** in den Themenbereichen Recruiting und Employer Branding mit.

-

Du hast **Lust auf ein Team** aus zehn Kolleg*innen, die das Recruiting der CURRENTA-Gruppe rocken? Du **lachst gerne** und bist offen? Dann bist Du bei uns genau richtig!

-

Du bist **eingeschriebene*r Student*in** im Bereich **Betriebswirtschaft, Personalmanagement, Psychologie** oder vergleichbar und unterstützt uns mit bis zu 20 Stunden in der Woche, anfangs befristet für 1 Jahr.

-

Idealerweise konntest du bereits **erste Erfahrungen** im Recruiting‑Umfeld sammeln.

-

Du hast großes Interesse mit uns unsere **HR- bzw. Recruitingthemen **voranzutreiben**. **

-

Du arbeitest **strukturiert, eigenverantwortlich** und **verlässlich** im **Home-Office**, aber auch die Anreise in den **CHEMPARK Leverkusen** stellt für dich kein Problem dar.

-

Du zeichnest dich durch **zuverlässige** und **selbstständige** **Arbeitsweise** aus und bist **kommunikationsstark** und **serviceorientiert**

**Hinweis:**

Die Gehaltsangabe basiert auf einer Wochenarbeitszeit von 20 Stunden in Teilzeit und je nach Studiengrad (Bachelor / Master). In den vorlesungsfreien Zeiten ist eine Stundenaufstockung möglich.

*Die Veröffentlichung dieser Anzeige auf Drittanbieter-Portalen ohne unsere ausdrückliche Zustimmung ist untersagt.*

Einstieg als: Werkstudierende (m/w/d)

Erfahrungsniveau: Junior

Gesellschaft: Currenta GmbH & Co. OHG

Stepstone: Pro Campus

Entgeltstufe: WS

Department: Recruiting

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
