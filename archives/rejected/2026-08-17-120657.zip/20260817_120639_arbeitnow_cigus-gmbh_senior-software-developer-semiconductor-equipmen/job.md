# Senior Software Developer – Semiconductor Equipment Software, Real-Time Control & Motion Systems (m/w/d)

Posted: 2026-08-17T07:20:13Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

#### **Hochtechnologie und Innovation...**

…aktiv mitgestalten und vorantreiben – für diese Position suchen wir eine engagierte Persönlichkeit (m/w/d), die mit Ideenreichtum, Verantwortungsbewusstsein und fachlicher Kompetenz überzeugt. Als Beratungsunternehmen unterstützen wir unseren Kunden bei der Suche nach einer passenden Person, die Herausforderungen nicht als Hürde, sondern als spannende Möglichkeit zur Weiterentwicklung versteht.

#### **Das erwartet dich:**

-

Entwicklung echtzeitfähiger **Softwarearchitekturen** für hochpräzise Steuerungs- und Positioniersysteme in Halbleiterfertigungsanlagen

-

Hands-on-Entwicklung mit **C#**, C++ und WPF für industrielle Anlagensteuerungen und Bedienoberflächen

-

Entwicklung und Optimierung von **Motion-Control-Systemen** sowie Schnittstellen zwischen Software, Hardware und Anlagenkomponenten

-

Design performanter Automatisierungs-APIs und Kommunikationsschnittstellen mit **gRPC** und Protobuf

-

Aufbau automatisierter Tests, **CI/CD-Pipelines** sowie Entwicklungs- und Simulationsinfrastrukturen für zuverlässige Software-Releases

-

Technische Führung interdisziplinärer Entwicklungsteams inklusive Code Reviews, Architekturentscheidungen und Wissensvermittlung

-

Zusammenarbeit mit Hardware, Physik und Prozessentwicklung bei Prototypen und halbleiterspezifischen Anlagenkonzepten

Für diese Position sind bestimmte fachliche und persönliche Voraussetzungen hilfreich. Die folgenden Anforderungen geben dir einen Überblick darüber, welche Erfahrungen und Eigenschaften für diese Rolle von Vorteil sind.

#### **Was du mitbringen solltest:**

-

Studium in Informatik, Physik, Elektrotechnik, Mechatronik oder vergleichbare Qualifikation

-

Mehrjährige Softwareentwicklungserfahrung mit **C#**, C++, .NET und WPF in komplexen technischen Systemen

-

Fundierte Kenntnisse in **Motion Control**, Präzisionspositionierung, Echtzeitanforderungen und deterministischem Systemverhalten

-

Erfahrung mit **gRPC**, Protobuf, Automatisierungs-APIs und industriellen Kommunikationsschnittstellen

-

Sicherer Umgang mit Git, **CI/CD**, Unit Testing und testgetriebener Softwareentwicklung

-

Kenntnisse in Containerisierung, Kubernetes sowie modernen Web-Technologien für Monitoring- und Diagnoseanwendungen

-

Verständnis von Halbleiter-, Lithografie-, Inspektions- oder **Metrologie-Prozessen** sowie technischen Reinraumanforderungen

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
