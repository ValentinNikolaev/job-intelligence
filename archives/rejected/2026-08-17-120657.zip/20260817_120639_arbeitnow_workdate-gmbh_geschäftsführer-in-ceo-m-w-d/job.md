# Geschäftsführer:in / CEO (m/w/d)

Posted: 2026-08-17T09:00:29Z

## Rejection

- Category: tech_stack
- Reason: role does not mention Go/Golang or PHP

**Workdate** bringt Menschen in Unternehmen zusammen. Unsere Software hilft Organisationen dabei, Silos aufzubrechen, Wissen zu teilen und über Abteilungen, Standorte und Hierarchieebenen hinweg echte Verbindungen zu schaffen.

Ob Lunch Roulette, virtuelle Kaffeepausen, Mentoring oder Lerngruppen: Workdate organisiert Begegnungen intelligent und weitgehend automatisiert.

Heute nutzen Unternehmen im Mittelstand und Konzernumfeld Workdate, um Zusammenarbeit und Unternehmenskultur nachhaltig zu stärken. Mit mehr als 500 Kunden und 250.000 Nutzer:innen weltweit haben wir eine starke Basis geschaffen. Nun suchen wir eine unternehmerisch denkende Persönlichkeit, die Workdate in die nächste Wachstumsphase führt. Mehr über Workdate

## Aufgaben

Als Geschäftsführer:in übernimmst du die operative und strategische Gesamtverantwortung für Workdate. Du entwickelst gemeinsam mit dem Gründerteam, dem Team und unseren Partnern die nächste Wachstumsphase – mit einem klaren Blick auf Kunden, Produkt, Umsatz und nachhaltige Unternehmensentwicklung.

Du verbindest strategisches Denken mit konsequenter Umsetzung. Dabei arbeitest du nah am Markt, verstehst die Anforderungen von HR-Verantwortlichen und Entscheidern und kannst aus Kundenbedürfnissen überzeugende Angebote, Produktentscheidungen und skalierbare Prozesse ableiten.

- **Unternehmensstrategie weiterentwickeln:** Du schärfst die Positionierung von Workdate und übersetzt sie in konkrete Ziele, Prioritäten und Maßnahmen.

- **Wachstum verantworten:** Du steuerst Umsatzentwicklung, Neukundengewinnung, Bestandskundenausbau und strategische Partnerschaften im B2B-SaaS-Umfeld.

- **Vertrieb aktiv vorantreiben:** Du führst wichtige Kundengespräche selbst, entwickelst den Sales-Prozess weiter und baust eine belastbare Pipeline auf.

- **Kundenbeziehungen ausbauen:** Du pflegst den direkten Austausch mit HR-Verantwortlichen und Entscheidern, verstehst deren Herausforderungen und stärkst langfristige Kundenbeziehungen.

- **Produktentwicklung mitgestalten:** Gemeinsam mit dem Produkt- und Entwicklungsteam priorisierst du Anforderungen und entwickelst Workdate markt- und kundenorientiert weiter.

- **Organisation und Team führen:** Du schaffst klare Verantwortlichkeiten, etablierst wirksame Prozesse und entwickelst eine vertrauensvolle, leistungsorientierte Remote-Kultur weiter.

- **Unternehmenskennzahlen steuern:** Du verantwortest Planung, Budget, Liquidität und Reporting und leitest aus den relevanten Kennzahlen fundierte Entscheidungen ab.

- **Workdate nach außen vertreten:** Du repräsentierst das Unternehmen gegenüber Kunden, Partnern, Netzwerken und weiteren relevanten Stakeholdern.

## Qualifikation

Uns ist wichtiger, was du aufgebaut und erreicht hast, als ein bestimmter Abschluss.

- Mehrjährige operative Verantwortung in einem Start-up, Scale-up, SaaS-Unternehmen oder einer vergleichbaren unternehmerischen Rolle.

- Nachweisbare Erfahrung in mindestens zwei der Bereiche Geschäftsführung, B2B-Vertrieb, Business Development, Produktstrategie oder Customer Success.

- Freude daran, selbst Kundengespräche zu führen, Abschlüsse voranzutreiben und Verantwortung für Ergebnisse zu übernehmen.

- Klare, verbindliche und wertschätzende Kommunikation

- Strukturierte, eigenständige Arbeitsweise in einem Remote-first-Umfeld

- Verhandlungssicheres Deutsch und sehr gutes Englisch

- Interesse an HR Tech, Employee Experience, Organisationsentwicklung und der Zukunft der Zusammenarbeit

Du musst nicht jede Anforderung erfüllen. Entscheidend sind unternehmerischer Gestaltungswille, Lernfähigkeit und der Wunsch, Workdate langfristig weiterzuentwickeln.

## Benefits

- **Echte unternehmerische Verantwortung:** Du gestaltest Strategie, Produkt, Organisation und Wachstum maßgeblich mit.

- **Bewährtes Produkt mit Substanz:** Du startest mit einer etablierten B2B-SaaS-Lösung, namhaften Kunden und einer großen Nutzerbasis.

- **Sinnvolle Mission:** Deine Arbeit trägt dazu bei, Wissenstransfer, Zusammenarbeit und menschliche Verbindungen in Unternehmen zu stärken.

- **Direkter Gestaltungsspielraum:** Kurze Entscheidungswege und enge Zusammenarbeit mit Gründerteam, Mitarbeitenden, Kunden und Partnern.

- **Remote-first:** Flexible Arbeit unabhängig vom klassischen Büroalltag.

- **Persönlicher Austausch:** Regelmäßige Teamtreffen und gemeinsame Workations.

- **Faire Vergütung:** Ein attraktives Vergütungsmodell aus fixen und erfolgsabhängigen Bestandteilen.

- **Langfristige Perspektive:** Bei gegenseitigem Interesse besteht die Möglichkeit einer Beteiligung am Unternehmen.

- **Workation:** Regelmäßige Treffen im Team, u. a. in Schweden.

Wir suchen keine Person, die lediglich bestehende Abläufe verwaltet. Wir suchen jemanden, der Verantwortung übernehmen, Entscheidungen treffen und gemeinsam mit einem kleinen Team etwas aufbauen möchte.

Wenn du Lust hast, aus einem etablierten HR-Tech-Produkt ein noch stärkeres, wachsendes Unternehmen zu entwickeln, möchten wir dich kennenlernen.

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
