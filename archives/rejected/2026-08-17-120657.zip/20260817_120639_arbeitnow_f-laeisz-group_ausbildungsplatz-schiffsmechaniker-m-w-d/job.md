# Ausbildungsplatz Schiffsmechaniker (m/w/d)

Posted: 2026-08-17T08:30:30Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Die Reederei F. Laeisz zählt mit rund 600 Besatzungsmitgliedern auf See und etwa 80 Mitarbeitenden an Land zu den traditionsreichsten deutschen Unternehmen der Branche. Die Bereederung unserer Schiffe bildet das Herzstück unserer Arbeit - modern, international und zukunftsorientiert.

Wir suchen **2. August 2027** hochmotivierte **Auszubildende zum Schiffsmechaniker (m/w/d)**, die Interesse an der Seefahrt haben und in einem internationalen Umfeld ausgebildet werden möchten.

## Aufgaben

Die Ausbildung zum Schiffsmechaniker (m/w/d) dauert drei Jahre und beinhaltet eine überbetriebliche Ausbildung am Maritimen Kompetenzzentrum in Elsfleth, in der Du neben den Schulzeitblöcken auch das Basic Safety Training sowie eine siebenwöchige Metallausbildung absolvieren wirst. Während der praktischen Ausbildung an Bord unserer Schiffe machst Du dich mit allen seemännischen Arbeiten im Decks- und Maschinenbereich vertraut und lernst, wie das Schiff und seine Maschinen und Anlagen gewartet und instandgehalten werden. Du unterstützt bei der Überwachung des Ladungsumschlags an Deck, im Wachdienst auf der Brücke und beim An- und Ablegen des Schiffes. Du nimmst an Sicherheitsübungen teil und lernst, was in Notfallsituationen an Bord zu tun ist.

## Qualifikation

- Mindestalter 16 Jahre

- guter Realschulabschluss, Abitur oder ein gleichwertiger Abschluss

- Interesse für die Seefahrt, an Maschinen und Anlagen sowie deren Reparatur, Wartung und Instandhaltung

- Sehr gute Deutschkenntnisse sowie gute bis sehr gute Englischkenntnisse

- Interesse an Geographie ist wünschenswert

- Seediensttauglichkeitszeugnis für den Decks- und Maschinendienst

- Einverständnis der Erziehungsberechtigten, wenn du zu Ausbildungsbeginn noch minderjährig bist

## Benefits

- eine vielseitige und praxisnahe Ausbildung in einem traditionsreichen und zugleich modernen Unternehmen

- ein starkes und multikulturelles Team in einem internationalen Arbeitsumfeld

- die Ausbildung an Bord von Autotransportern, Containerschiffen und auf dem Forschungsschiff „Polarstern“

- eine attraktive Ausbildungsvergütung

- eine freie Unterkunft und Verpflegung während der überbetrieblichen Ausbildung

- die Übernahme der Kosten für das Deutschlandticket während der Ausbildung an Land

- gute Übernahme- und Zukunftschancen nach der Ausbildung

Haben wir Dein Interesse geweckt? Dann bewirb Dich noch heute mit Deinen vollständigen Bewerbungsunterlagen (Anschreiben, Lebenslauf, die letzten beiden Schulzeugnisse) über die Homepage der Reederei F. Laeisz G.m.b.H. .

Bei Rückfragen steht Dir Dein Ansprechpartner Herr Daniel Schimmelpfennig gerne zur Verfügung .

Wir freuen uns auf Deine Bewerbung und darauf, Dich bald an Bord unseres Teams begrüßen zu dürfen!

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
