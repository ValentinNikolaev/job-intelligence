# Consultant- und Sales-Manager M365 (m/w/d)

Posted: 2026-08-17T07:30:43Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Du begeisterst Dich für moderne Arbeitsplätze, Digitalisierung und Microsoft 365? Du verstehst Geschäftsprozesse und erkennst Potenziale für Verbesserungen? Dann suchen wir Dich. Als Consultant- Sales-Manager für Microsoft 365 begleitest Du unsere Kunden von der ersten Idee bis zur erfolgreichen Umsetzung. Dabei verbindest Du Beratung, Vertrieb und Lösungsentwicklung zu einem ganzheitlichen Kundenerlebnis.

## Aufgaben

- Beratung von Kunden rund um Microsoft 365 und Modern Work

- Identifikation von Digitalisierungs- und Automatisierungspotenzialen

- Analyse und Verständnis von Geschäftsprozessen

- Entwicklung passender Lösungskonzepte auf Basis von Microsoft 365

- Präsentation von Lösungen und Durchführung von Workshops

- Erstellung von Angeboten und Unterstützung im Vertriebsprozess

- Enge Zusammenarbeit mit unseren technischen Teams und Consultants

- Begleitung von Kundenprojekten von der Idee bis zur Umsetzung

**Was wir bieten**

- Spannende Kundenprojekte mit modernen Microsoft-Technologien

- Hohe Eigenverantwortung und Gestaltungsspielraum

- Ein starkes Team aus Consultants und Technikern

- Flexible Arbeitsmodelle und moderne Arbeitsausstattung

- Persönliche und fachliche Weiterentwicklung

## Qualifikation

- Begeisterung für Digitalisierung und moderne Arbeitsweisen

- Erfahrung im Umgang mit Microsoft 365, beispielsweise SharePoint, Teams, Power Platform oder Copilot

- Interesse an Kundenberatung und Lösungsvertrieb

- Verständnis von Geschäftsprozessen und deren Optimierung

- Kommunikationsstärke und sicheres Auftreten

- Eigeninitiative und Motivation, Dinge voranzubringen

**Das wäre ein Plus**

- Erfahrung mit der Einführung von Microsoft-365-Lösungen

- Kenntnisse in der Prozessdigitalisierung und Automatisierung

- Erfahrung im IT-Vertrieb oder Consulting

- Verständnis für Change Management und Anwenderschulungen

## Benefits

- *Du willst Dich Details widmen und nachhaltig Probleme lösen?*

- *Du willst Dich kontinuierlich weiterentwickeln und neue Wege gehen?*

- *Du willst wirklich etwas verändern und hohe eigene Qualitätsansprüche umsetzen?*

- *Du willst flexible Arbeitszeiten und auch im Homeoffice arbeiten?*

- *Du willst eine unbefristete Festeinstellung?*

Bei GECKO suchen wir Menschen mit Leidenschaft und Engagement, um in den kommenden Jahren weiter wachsen zu können. Im Gegenzug sind wir gern bereit in unsere Mitarbeiter zu investieren, sowohl bei der Arbeit als auch im täglichen Leben.

**Bleib flexibel**

Uns ist es nicht wichtig, dass du zu einem festen Zeitpunkt im Büro sitzt. Wir wissen, dass Mitarbeiter am produktivsten sind, wenn sie ihre Arbeitsroutine in Einklang mit dem Privatleben bringen können. Ob im Büro oder im Home Office, bei uns kannst du dir den Tag mit flexiblen Arbeitszeiten so einteilen, dass er zu deinem Leben passt. Dabei unterstützen wir dich mit modernen Kommunikationstools und einer transparenten Arbeitsplanung.

**Bleib fit**

Kennst du das auch? Du steckst gerade mitten im Workflow und ein kleines Hungergefühl stellt sich ein. Dafür haben wir vorgesorgt und stellen kostenlos frisches Obst in den Büros bereit und sorgen mit Getränken, wie z.B. Wasser, Kaffee und Mate dafür, dass auch das Trinken nicht zu kurz kommt. So kannst du dich jederzeit stärken und schon geht’s motiviert weiter.

**Empfehle und profitiere**

Wir sind ständig auf der Suche nach Talenten, die Teil unseres Teams werden möchten. Für Mitarbeiter, die überzeugt sind den perfekten Kandidaten zu kennen, der uns beim Wachsen unterstützen kann und der gut zu uns passt, zahlen wir bei Übernahme eines empfohlenen Mitarbeiters eine Prämie, die sich sehen lassen kann.

**Arbeiten und Spaß haben**

Wer fleißig gearbeitet hat, darf sich natürlich auch belohnen. In den Pausen oder nach Feierabend kannst du dich gern bei uns in den Chillout Areas zum Quatschen mit den Kollegen treffen oder beim Zocken an der Playstation antreten. Team-Events und Mitarbeiterfrühstück gehören bei uns genauso dazu, wie der kleine Plausch in der Küche, denn stärken wir das Wir-Gefühl und wachsen weiter zusammen.

Um für die täglichen Herausforderungen gewappnet zu sein und den Geschäftserfolg nachhaltig zu stärken, glauben wir nicht nur an Expertise und Erfahrung. Wir glauben vor allem auch an den Zusammenhalt unserer Teams und an eine Kultur, die Respekt, Toleranz und ein faires Miteinander fördert. Wenn du ähnlich tickst wie wir, sind wir schon jetzt sehr gespannt darauf dich kennenzulernen.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
