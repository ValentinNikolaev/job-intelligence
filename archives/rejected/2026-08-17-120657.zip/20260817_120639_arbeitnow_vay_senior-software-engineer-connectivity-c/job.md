# Senior Software Engineer, Connectivity, C++

Posted: 2026-08-16T23:55:15Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Ever imagined saying, “I helped launch the future of transportation”?

We’re rewriting the rules of urban mobility. At Vay, customers tap a button and a car arrives - with no one inside - powered by our world-first Remote Driving technology on real public streets.

We’re live in Las Vegas and scaling fast, powered by a strategic investment of up to $410 million from [Grab](https://www.grab.com/sg/). Our mission is simple: replace private car ownership with a faster, cleaner, door-to-door mobility model. If you want to build something real, visible, and genuinely transformative, you’ll feel right at home here.

**Curious to experience Vay yourself? Use the code *VAYCANDIDATE* for $10 off your first trip in Las Vegas! Download the "Vay" app from the Apple or Google Play store & off you go! **

#### **What’s happening at Vay**

- First to roll out vehicles in both Europe and the USA on public roads without a human being inside & currently the 2nd largest commercial, driverless car fleet in the Western World.

- We've partnered with [Kodiak](https://kodiak.ai/) to bring remote-driving technology to autonomous trucks in the US, showcasing our ability to integrate our system into heavy-duty commercial vehicles and expand the applications of our tech across the US.

- We’ve completed 10’s of thousands of trips so far and are busy multiplying our Las Vegas fleet just to meet demand!

- **...And soon we’ll be expanding across the US & Europe 🚀**

#### ***Why this role is exciting***

**As a Senior Software Engineer, Connectivity at Vay, you’ll help build and optimize the networking backbone that makes remote driving possible.** Our Connectivity team owns the low-latency real-time video streaming and data transport systems that connect our vehicles with our telestations across cellular and satellite networks. This is a hands-on engineering role where performance, reliability, and safety matter every day, and where your work will directly shape the quality of the remote driving experience.

You’ll work on a latency-sensitive distributed system, test your solutions on state-of-the-art hardware, and use real production data to investigate incidents, improve performance, and keep pushing our network stack forward.

#### ***What you'll be driving***

- Develop, optimize, and maintain high-performance network stack used to transport data (video, audio, control, telemetry) between the vehicle and the telestation with a strong emphasis on clarity, maintainability, and efficiency.

- Integrate the Vay network stack into various target hardware and software platforms.

- Extend and maintain network testbeds and CI infrastructure.

- Profile and optimize the performance of the system.

- Triage incidents from the production system and create fixes/improvements.

#### ***What are we looking for***

- Strong proficiency in modern C++ (C++17 or later), with a focus on high-performance, multi-threaded applications.

- Experience working in Linux-based environments.

- Solid understanding of networking fundamentals and protocols (TCP, UDP).

- Ability to analyze and optimize systems.

- Strong problem-solving skills and a research-oriented mindset.

- Experience working on distributed systems.

- Good interpersonal and communication (oral and written) skills

Nice to have:

- Understanding of networking and wireless technologies, including LTE/5G, WiFi, Starlink, and experience with tools like Wireshark for traffic analysis.

- Hands-on experience with streaming protocols, such as RTP/RTCP/RTMP/SRT, and media frameworks, such as GStreamer, FFmpeg, or DirectShow.

- Familiarity with congestion control algorithms and network simulation environments.

- Experience with building and deployment (e.g. CMake, Docker, Yocto), and scripting languages such as Python or Lua.

- Experience in real-time or embedded systems development, with knowledge of modem configuration via AT commands.

- Background in performance analysis and debugging, using tools like perf, perfetto; and graphical UIs like ImGui.

#### ***Why choose Vay***

💪 A global team of smart, motivated people from 30+ countries who love tackling hard problems and turning bold ideas into reality

🌍 Huge scope for impact in a fast paced environment

💰 ESOP stock options: A stake in Vay’s future - not just a salary

🌴 Unlimited Paid Vacation Days

🎫 Subsidised Deutschland ticket (Berlin)

🏋️‍♂️ Subsidised Urban Sports Club or FitX Membership

🚗 All Vay team members receive 30% off their Vay rides

🛍️ Exclusive external discounts

💼 €350 Home Office Set-up

✈️ Relocation financial assistance when relocating to Berlin

📚 Fully funded German Lessons

🎊 Regular team events throughout the year

For more information on Vay’s physical demands, working environments and safety requirements, you can review this [link](https://docs.google.com/document/d/1swEohclBwsOgx37G4NHE2szYCA6avS_aQX_WSJ7Ih8k/edit?tab=t.0#heading=h.6dlrur2mwcd9). We’ll also cover anything specific to this role during the first interview.

We’d love to stay connected for future opportunities, so feel free to include your LinkedIn profile when you apply.

We welcome applications from all backgrounds and experiences. If you’re excited about shaping something truly groundbreaking, we’d be happy to hear from you.

####

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
