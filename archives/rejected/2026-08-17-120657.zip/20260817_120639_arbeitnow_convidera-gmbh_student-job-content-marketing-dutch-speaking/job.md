# Student Job - Content Marketing (Dutch-Speaking)

Posted: 2026-08-17T10:30:33Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

🚀 **Du hast Lust, starken Content zu entwickeln, der Menschen wirklich erreicht?**

Dann gestalte mit uns kreative Content-Marketing-Konzepte für eine innovative Smart-Home-Marke und trage dazu bei, nachhaltige Performance im deutschen und niederländischen Markt zu erzielen. Wenn du ein gutes Gespür für Sprache mitbringst, fließend Niederländisch sprichst und in einem agilen Umfeld Verantwortung übernehmen möchtest, freuen wir uns darauf, dich kennenzulernen.

## Aufgaben

✨ Du entwickelst gemeinsam mit uns kreative Content-Ideen und unterstützt bei der Redaktions- und Themenplanung.

🔍 Du recherchierst spannende Themen, greifst aktuelle Trends auf und bringst eigene Ideen für Magazinartikel, Website-Inhalte, Newsletter oder neue Content-Formate ein.

✍️ Du schreibst und veröffentlichst Inhalte auf Niederländisch und Deutsch und pflegst diese in unserem CMS.

📱 Du bereitest Content zielgruppengerecht für verschiedene Kanäle auf und unterstützt bei der Betreuung unserer Social-Media-Kanäle.

## Qualifikation

🎓 Du bist immatrikuliert – dein Studienfach ist für uns zweitrangig. Wichtig ist, dass du Spaß am Schreiben hast und uns 16–20 Stunden pro Woche unterstützen kannst.

📝 Du schreibst gerne und hast Lust, Content-Marketing in der Praxis kennenzulernen. Erste Erfahrungen mit Social Media, Blogs oder Newslettern sind ein Plus – aber keine Voraussetzung.

🇳🇱 Du sprichst und schreibst fließend Niederländisch und kannst dich auch auf Deutsch gut verständigen.

🤝 Du arbeitest gerne eigenverantwortlich, bist zuverlässig und bringst deine Ideen mit ein.

🤖 Du bist offen für neue Tools und Technologien und nutzt KI-Anwendungen wie ChatGPT oder Claude gerne als Unterstützung – oder möchtest lernen, wie man sie sinnvoll im Arbeitsalltag einsetzt.

## Benefits

- Maximale Flexibilität & Vertrauen: Deine Arbeitszeiten passen zu deinem Studium und dabei kannst du entscheiden, ob du im Kölner Office, remote von zuhause oder mal aus dem Ausland arbeitest

- Immer am Zahn der Zeit: Wir sind up to date bei den neuesten Entwicklungen im Bereich KI. Du erhältst Zugang zu relevanten Tools und Lizenzen sowie die Möglichkeit, dich in diesem Bereich kontinuierlich weiterzubilden.

- Vertrauen und Wachstum: Du bist Teil des Teams und für uns gehört Eigenverantwortung sowie regelmäßiges Feedback mit dazu, damit du dich entfalten kannst und praxisnahe Erfahrungen sammelst

- Mehr als Erholung: 27 Tage Urlaub, damit auch dein Privatleben genug Raum bekommt

- Arbeiten op Kölsch: Unser Industrial Office in Köln-Ehrenfeld ist der Ort für Austausch, Kreativität – und unsere legendären Sommer- und Weihnachtsfeiern

- Und sonst so: Auf dich warten eine vergünstigte Urban Sports Club-Mitgliedschaft, Corporate Benefits, unsere kostenlose Snackbar und weitere kleine Extras, die den Alltag einfach besser machen

Zur Kommunikation auf Augenhöhe gehört für uns auch, dass Du uns so ansprechen kannst, wie wir Dich. Da wir uns alle duzen und Du ja vielleicht auch schon bald zu unserem Team gehörst: Fang' doch in Deiner Bewerbung gleich damit an.

Wir freuen uns, Dich kennenzulernen!

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
