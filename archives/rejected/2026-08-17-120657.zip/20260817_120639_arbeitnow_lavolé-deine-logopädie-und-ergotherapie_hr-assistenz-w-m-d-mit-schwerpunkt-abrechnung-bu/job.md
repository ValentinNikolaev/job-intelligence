# HR-Assistenz (w,m,d) mit Schwerpunkt Abrechnung, Buchhaltung, Back Office

Posted: 2026-08-17T09:30:26Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**UNTERNEHMENSBESCHREIBUNG**

Für unsere Standorte in der Maxvorstadt, dem Glockenbachviertel und in Bogenhausen suchen wir eine engagierte und zuverlässige Persönlichkeit in Teilzeit. Die Arbeitszeit beträgt 15 bis 20 Stunden pro Woche. Der Arbeitsort befindet sich am Gärtnerplatz. Wir bieten eine attraktive Stelle mit flexiblen Arbeitszeiten. Haben Sie Lust, unsere moderne logopädische Praxis durch Ihr zahlenaffines Denken zu unterstützen und mit Ihrer aufgeschlossenen Art unser Team zu bereichern?

**UNSER ANGEBOT**

- Zusammenarbeit in einem jungen, engagierten und weltoffenen Team

- arbeiten in zentraler Lage mitten in München

- eigenverantwortliches Arbeiten mit Gestaltungsfreiraum

- gründliche Einarbeitung

- Entwicklungsmöglichkeiten

- Einbeziehung in neue Verantwortungsbereiche

- flache Hierarchien

**WIE KÖNNEN SIE SICH BEI UNS BEWERBEN**

**Bitte die vollständige Bewerbung per E-Mail an uns.**

Wir freuen uns auf Ihre aussagekräftige Bewerbung (inkl. Anschreiben, Lebenslauf mit Bild, ggf. Arbeitszeugnisse und weitere Zeugnisse), via E-Mail.

Informieren Sie sicher gerne über unsere Praxis unter:

## Aufgaben

Ansprechpartner*in für unsere Patient*innen betreffend der Buchhaltung am Telefon, per Mail und persönlich in den Bereichen:

- Rechnungswesen, Mahnwesen, Verwaltung von Debitoren

- Stundenabrechnung

- Belegablage mit DATEV

- Aktenablage

- Nachbestellung von Verbrauchsmaterialien

- Mitarbeit an der Weiterentwicklung der Praxis und Prozessoptimierung

- Überarbeiten und Erstellen von Praxissheets betreffend Ihrer Aufgaben

- Aufgaben in unserem Backoffice

## Qualifikation

- Abgeschlossenes wirtschaftliches Studium (BWL) oder eine abgeschlossene kaufmännische Ausbildung (als BuchhalterIn, Steuerfachangestellte/r, Bankkauffrau/mann oder eine vergleichbare Qualifikation), Wirtschaftspsychologie

- mehrjährige Erfahrung im Finanzbereich

- Berufserfahrung im Praxisalltag erwünscht aber kein muss

- sicherer und routinierter Umgang mit Microsoft Office (Word, Outlook und Excel) ist Voraussetzung, gerne auch über die normalen Kenntnisse hinaus

- Deutsch fließend in Wort und Schrift und Englischkenntnisse

- empathisch, kommunikativ und teamfähig

- zuverlässig, strukturiert und organisiert

- souveränes Auftreten auch am Telefon

- alle Altersklassen willkommen

## Benefits

Leistungen:

- Firmenevents

- Firmenhandy

- Flexible Arbeitszeiten

- Kostenlose Getränke

- MVG-Ticket

- Steuergutscheine bis zu 1200 Euro pro Jahr

Wir freuen uns auf Ihre aussagekräftige Bewerbung, Team LAVOLE´ :-)

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
