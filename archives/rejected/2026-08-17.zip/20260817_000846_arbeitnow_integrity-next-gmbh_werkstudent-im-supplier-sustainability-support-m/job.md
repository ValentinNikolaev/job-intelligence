# Werkstudent im Supplier Sustainability Support (m/w/d)

Posted: 2026-08-16T17:09:22Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**Mach mit!**

Während des Studiums praktische Erfahrung in einem internationalen B2B-SaaS-Umfeld sammeln und gleichzeitig lernen, wie moderne Support-Prozesse mit digitalen Tools und AI effizienter gestaltet werden? Dann ist diese **Werkstudentenrolle im Supplier Sustainability Support (m/w/d) **genau passend für dich!

In dieser Rolle unterstützt du Lieferant und B2B-Nutzer bei ihren Anfragen, sorgst für klare Kommunikation auf Deutsch, Englisch und weiteren Sprachen und hilfst dabei, Support-Prozesse weiterzuentwickeln. Dabei erhältst du Einblicke in Nachhaltigkeit, Produkt-Compliance und digitale Lieferkettenprozesse und arbeitest in einem internationalen Team, das sich gegenseitig unterstützt und gemeinsam dazulernt.

Wir freuen uns auf dich!

**Was erwartet dich?**

- Unterstützung von Lieferanten und B2B-Nutzern bei Support-Anfragen rund um unsere Plattform
- Schriftliche Beantwortung von Anfragen auf verschiedenen Sprachen – klar, sorgfältig und serviceorientiert
- Erkennen wiederkehrender Fragen, Bedienfehler oder Prozesslücken und Weitergabe relevanter Erkenntnisse ans Team
- Mitarbeit an der Weiterentwicklung und Dokumentation von Support-Prozessen
- Unterstützung bei digitalen und AI-gestützten Prozessverbesserungen
- Flexible Mitarbeit dort, wo im Team zusätzliche Kapazitätgebrauchtwird

**Was solltest du mitbringen?**

**Erfahrung & fachlicher Fokus **

- Laufendes Studium an einer staatlich anerkannten Hochschule in Deutschland
- Verfügbarkeit von 20 Stunden pro Woche in der Vorlesungszeit
- Idealerweise noch mindestens 1,5 Jahre Studienzeit
- Interesse an Nachhaltigkeit, Lieferketten, ESG, digitalen Plattformen oder B2B-Kommunikation
- Erste praktische Erfahrung im B2B-Umfeld, SaaS oder mit digitalen Tools ist ein Plus, aber keine Voraussetzung

**Technische / methodische Kompetenzen **

- Sicherer Umgang mit digitalen Tools und Bereitschaft, neue Systeme schnell kennenzulernen
- Fähigkeit, Informationen strukturiert zu erfassen, sauber zu dokumentieren und zuverlässig weiterzuverarbeiten
- Sorgfältige Arbeitsweise mit Blick für sprachliche Genauigkeit, klare Formulierungen und Details
- Erste Berührungspunkte mit AI-Tools, Prozessautomatisierung oder Support-Systemen sind hilfreich, aber kein Muss

**Arbeitsweise & Mindset **

- Freude daran, Neues zu lernen und sich in neue Technologien und Prozesse einzuarbeiten
- Zuverlässige, genaue und lösungsorientierte Arbeitsweise
- Teamorientierung und Bereitschaft, dort zu unterstützen, wo gerade Hilfegebrauchtwird
- Konzentration und Sorgfalt auch bei wiederkehrenden oder kleinteiligen Aufgaben
- Serviceorientierte Haltung und der Anspruch, Nutzer wirklich weiterzuhelfen

**Kommunikation & Zusammenarbeit **

- Fließende Deutsch- und Englischkenntnisse in Wort und Schrift, weitere Sprachkenntnisse sind ein Plus
- Freundliche, klare und professionelle Kommunikation mit B2B-Nutzer
- Freude am Austausch mit Menschen aus unterschiedlichen Ländern und Unternehmenskontexten
- Offenheit für Feedback und Spaß daran, gemeinsam mit dem Team bessere Lösungen zu entwickeln

**Was bieten wir dir?**

- **Spannende Aufgaben mit Sinn**: Eine Tätigkeit, die nicht nur Spaß macht, sondern auch echte Bedeutung hat – kombiniert mit hervorragenden Verdienstmöglichkeiten
- **Agile Arbeitsatmosphäre**: Arbeite in einem internationalen Umfeld mit starkem Wachstum, das dir langfristig Entwicklungsmöglichkeiten und Raum für dein Potenzial bietet
- **Tolles Team**: Ein professionelles und herzliches Team, das sich auf dich freut
- **Attraktive Benefits**: 30 Tage Urlaub und eine EGYM Wellpass Mitgliedschaft für deine Work-Life-Balance
- **Flache Hierarchien**: Setze deine eigenen Ideen erfolgreich um und gestalte aktiv mit
- **Modernes Arbeitsumfeld**: Inspirierende Büroräume im Herzen Münchens und die Flexibilität, auch remote im Home Office oder in ganz Deutschland zu arbeiten

**Bewerbungsprozess**

Please apply exclusively via our online application portal. This ensures a smooth and fair process for all candidates. Applications submitted by email will not be considered. Thank you for your understanding.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
