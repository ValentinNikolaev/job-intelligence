# Junior Produktentwickler - Home & Personal Care (m/w/d)

Posted: 2026-08-16T17:30:32Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

### **DAS IST DER JOB**

Du suchst keinen klassischen, monotonen Laboranten-Job, sondern willst die Entwicklung von Wasch-/Putz-/Reinigungsmittel- und Kosmetikrezepturen aktiv mitgestalten? Dann bist du als **Junior Produktentwickler - Home & Personal Care (m/w/d) **bei uns genau richtig, denn hier übernimmst du schnell Verantwortung für deine eigenen Projekte.

Deine Hauptaufgaben werden sein:

-

**Rezepturen entwickeln & optimieren:** Du führst praktische Machbarkeitsprüfungen neuer Rezepturideen für Wasch-/Putz-/Reinigungsmittel sowie Kosmetika durch und optimierst bestehende Produkte.

-

**Labortests & Analytik:** Du begleitest deine Laboransätze eigenständig durch systematische Labortests (Charakterisierung, Stabilitäts- und Lagerprüfungen).

-

**Labororganisation:** Du verantwortest den reibungslosen, praktischen Laborbetrieb und bringst eigene Ideen zur Optimierung unserer internen Laborabläufe ein.

-

**Rohstoffqualifikation:** Gemeinsam mit dem Team prüfst und qualifizierst du neue, innovative oder alternative Rohstoffe.

-

**Schnittstellen & Benchmarking:** Du führst technisches Benchmarking sowie Leistungsbeurteilungen durch, wählst externe Testinstitute aus (z. B. für Dermatest, Schwermetallanalysen) und beauftragst diese. Zudem stimmst du dich bezüglich Qualitätsvereinbarungen, QS-Parametern und der Scale-up-Betreuung eng mit unseren Lohnherstellern ab.

-

**Dokumentation:** Du dokumentierst deine Ergebnisse systematisch und teilst sie im R&D-Team.

### **DAS BIST DU**

Wenn du dich leidenschaftlich für Nachhaltigkeit engagieren möchtest und hochmotiviert bist, mit uns die Welt ein bisschen sauberer zu machen, dann finden wir dich richtig gut!
Wenn du außerdem gerne proaktiv und im Team arbeitest, und du jede kleine und große Herausforderung als eine Chance ansiehst, noch besser zu werden – dann sind wir schon ein ganz kleines bisschen verknallt.
Wenn du schließlich auch noch über die folgenden Skills und Erfahrungen verfügst, dann sind wir uns fast sicher: Das könnte der Beginn einer ganz großen Love Story sein!

-

Erfolgreich abgeschlossene Berufsausbildung als Chemie-/Biologielaborant:in, als chemisch/biologisch-technische:r Assistent:in (CTA/BTA) ODER ein abgeschlossenes Studium im Bereich Chemie, Biologie, Life Sciences, Chemieingenieurwesen,Kosmetik- oder Lebensmitteltechnologie o.ä.

-

Du hast idealerweise schon erste Berufserfahrung in der Produktentwicklung gesammelt – z. B. durch Praktika, Abschlussarbeiten oder erste Berufsjahre – und bringst idealerweise erste Berührungspunkte mit der Formulierung von Tensidsystemen oder Emulsionen mit.

-

Ein hohes Maß an analytischem Denken sowie eine eigenorganisierte, zuverlässige und gewissenhafte Arbeitsweise zeichnen dich aus. Du hast Lust darauf, Verantwortung für den praktischen Laborbetrieb zu übernehmen, komplexe Fragestellungen lösungsorientiert anzugehen und stehst für eine präzise, sichere Dokumentation deiner Arbeitsergebnisse.

-

Du bist ein echter Teamplayer und traust dir zu, dich professionell und durchsetzungsstark mit externen Partnern sowie Lohnherstellern abzustimmen.

-

Du bist sicher im Umgang mit MS-Office/Google Suite; Kenntnisse in SAP sind ein willkommenes Plus (wünschenswert).

-

Sehr gute Deutsch- und gute bis verhandlungssichere Englischkenntnisse in Wort und Schrift für die internationale Kommunikation mit Lieferanten.

### **DAS IST EVERDROP**

**Unsere Mission 💚🌱🌎**

Wir wollen die Welt verändern – gemeinsam mit dir! **Die Alltagsprodukte von everdrop helfen den Menschen, ganz einfach ihren ökologischen Fußabdruck im Haushalt zu reduzieren.** Im Jahr 2020 sind wir mit unseren Reiniger-Tabs gestartet. Seitdem haben unsere Haushalts- und Pflegeprodukte bereits** mehr als 20 Millionen** **Einweg-Plastikflaschen** und Tausende Tonnen unnötige CO2-Emissionen und chemische Rohstoffe eingespart. Seit 2023 sind wir übrigens eine zertifizierte [B Corp](https://bcorporation.eu/). Und mit deiner Hilfe wollen wir everdrop aufs nächste Level bringen. Schließ dich unserer Mission an – und hilf uns, einen nachhaltigen Lifestyle so einfach zu machen, dass er zum neuen Standard in unserer Gesellschaft wird.

**Unsere Benefits **🍲💪🏡

-

abwechslungsreiche, sinnstiftende und Purpose-getriebene Arbeit

-

großartiger Teamgeist und regelmäßige Team-Events

-

Special Rate für EGYM Wellpass-Mitgliedschaft

-

kostenloses veganes Mittagessen einmal pro Woche

-

ein monatlicher Gutschein für everdrop Produkte in unserem Mitarbeitershop

-

Familien- und Freunde-Rabattcodes für everdrop und andere Startups for Tomorrow-Unternehmen

-

Mitgliedschaft bei FutureBens & Corporate Benefits

-

flexible Arbeitszeiten

-

mobiles Arbeiten für 20 Tage pro Jahr innerhalb der EU möglich

-

30 Tage bezahlter Urlaub plus 24.12. und 31.12. frei

-

zusätzlich 2 Tage bezahlter Urlaub pro Jahr für eigene umwelt- oder gemeinnützige Projekte ("Green & Social Impact Days”)dein eigenes MacBook, solange du bei everdrop arbeitest

**Unsere Werte 💛🏳️‍🌈🤝‍**

Bei everdrop wollen wir eine Kultur der Inklusion, Vielfalt und Chancengleichheit leben. Das Commitment, die Welt ein bisschen besser zu machen, ist Teil unseres alltäglichen Handelns. Vor allem wollen wir das Bewusstsein für unseren Planeten und für andere Menschen fördern.

Ein Beispiel dafür, wie wir am Arbeitsplatz Awareness schaffen möchten: Menstruierende Kolleg*innen, die unter Schmerzen leiden, können ganz einfach einen oder mehrere "Power Days" nehmen, zusätzliche bezahlte freie Tage. Und das ohne Fragen, ohne Rechtfertigungen. Ein weiteres Beispiel: Unsere "Green & Social Impact Days” sind zwei weitere bezahlte freie Tage pro Jahr, die du eigenen Projekten für die Umwelt oder für Deine Community widmen kannst. Auch in unserem Hiring-Prozess versuchen wir, so achtsam wie möglich zu sein.

**Wir behandeln jeden Menschen gleich, unabhängig von Herkunft, Geschlecht, Religion, Alter, Aussehen, Sprache, Kultur, Nationalität, Familienstand, sexueller Orientierung oder körperlicher Einschränkung.**

Wir sind ganz bestimmt nicht perfekt – aber wir wollen jeden Tag besser werden und mit jedem Schritt etwas Neues dazulernen. Genau darum geht es ja bei jeder Reise. Kommst du mit?

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
