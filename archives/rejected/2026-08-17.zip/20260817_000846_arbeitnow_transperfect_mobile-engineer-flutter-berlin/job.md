# Mobile Engineer - Flutter | Berlin

Posted: 2026-08-16T17:30:23Z

## Rejection

- Category: role_mismatch
- Reason: title is an obvious mismatch for a backend profile

TransPerfect is an established company with a start-up culture seeking creative entrepreneurial people like you to join our team. We’re hiring a **Mobile Engineer** to join our global team to be responsible for crafting top-tier user experiences in the iOS and Android platforms. This full-time hybrid role demands both independent and collaborative work within a high-impact team, focused on delivering innovative products.

This role is full-time, and the ideal applicant will be an expert in working in iOS and Android apps built within Flutter and building new components from the ground up.

**About the team you will be joining at TransPerfect – TechOps:**

The TransPerfect TechOps team has been a vital part of the company’s success since its formation 10 years ago – delivering technology and services that have drastically simplified the lives of our clients and colleagues – from workflow improvements for colleagues to core services that form the basis of the company’s GlobalLink platform, to creating scalable client interfaces that allow novice users to navigate complex ecosystems.

**Your responsibilities and tasks will include:**

-

Be the subject matter expertise on mobile app development – helping define the team’s mobile development practices, design thinking and deployment processes

-

Collaborate with product managers, engineers, product designers and QA to define and build compelling user experiences on iOS and Android

-

Own and lead delivery of major mobile app features, components, foundations and overall entire application solutions in partnership with technical leads and senior engineers

-

Operate in an agile environment, communicate and manage internal and external implementation requirements and expectations

-

Provide constructive feedback to the technical staff during all phases of the software lifecycle to keep development priorities aligned with business needs

-

Write clean, efficient, and maintainable code following best practices and coding standards

-

Stay up-to-date with latest trends, technologies, and best practices in mobile development

**The minimum we’re looking for (show us what you got if you aren’t a perfect fit):**

-

4+ years of experience in mobile applications development

-

Proficiency in Flutter

-

Solid knowledge of Dart

-

Deep understanding of mobile app UX/UI best practices

-

Expertise in CI/CD, testing, and agile methodologies

-

Experience deploying applications to Apple App Store and Google Play

-

Experience with Agile methodologies like SCRUM/Kanban

-

Excellent communication and collaboration skills with a proven ability to work effectively in a team environment

**Why you should join us? Let's see:**

-

💰 Competitive salary in line with your experience and knowledge.

-

😏 You will work in a dynamic, well-functioning software development division with the world's largest provider of language services and technology solutions.

-

📈 Significant room for growth.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
