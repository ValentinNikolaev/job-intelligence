# Director of Talent Acquisition (f/m/d)

Posted: 2026-08-16T17:40:19Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

## **About Focused Energy**

Focused Energy is building the future of clean energy through laser-driven inertial fusion. Backed by our $240M Series A — the largest fully secured Series A in the global fusion industry — we are scaling rapidly across multiple geographies.

Based in Germany and the US, we have brought together the top scientific and engineering minds using proven technologies to unlock fusion power at commercial scale. Focused Energy is working to realize game-changing scientific innovation that promises to deliver a clean, sustainable and abundant source of power globally.

Location: Role is Hybrid and based in either Berlin or Darmstadt, Germany, with remote flexibility.

## **Your Role**

We're hiring a Director of Talent Acquisition to own how this company hires. This isn't a caretaker role over a recruiting queue. You'll lead our Talent Acquisition and Employer Branding function — a team of five TA Partners and a TA Enablement & Analytics Partner — and build the operating model that makes hiring a genuine competitive advantage.

You're joining at a pivotal moment. The TA function is operational and delivering, but quality, consistency, and hiring manager capability haven't yet caught up with our ambitions. Our ability to scale from Series A through commercialization depends on hiring the right people, at the right pace, into the right roles — across fusion science, laser engineering, software, operations, and G&A. You won't inherit a finished machine. You'll build one.

## **What You'll Do**

**Team Leadership **Lead and develop five TA Partners and the TA Enablement & Analytics Partner — setting clear expectations, building capability, and creating a high-performing team culture that delivers without you in every decision.

**Hiring Standards and Rigour **Build and maintain the TA operating standards: hiring processes, interview frameworks, scorecards, and decision criteria applied consistently across every function. Raise the bar on quality, not just throughput.

**Capacity Planning **Drive capacity planning in close partnership with Finance and department heads, ensuring TA is resourced and sequenced ahead of demand — never the bottleneck to a planned hire.

**Hiring Manager Enablement **Equip leaders to run structured, fair hiring processes through training, coaching, and tooling — reducing dependency on TA for process guidance and raising the quality of hiring decisions.

**ATS and Data **Own the ATS end to end: configuration, data integrity, adoption, and continuous improvement. Use pipeline data and KPIs to identify bottlenecks, drive process changes, and report progress that drives decisions rather than decorates them.

**Employer Branding **Build a consistent, differentiated presence in our target talent markets — LinkedIn, Glassdoor, job boards, events, and content — in partnership with Marketing, so inbound quality improves quarter on quarter.

## **Who You Are**

• 10+ years of progressive talent acquisition experience, with meaningful time leading and developing recruiting teams

• Experience in a scaling tech, deep-tech, or engineering-heavy environment, hiring for specialised, hard-to-fill roles

• Fluent with AI in your daily recruiting work — sourcing, screening, content, analytics — and able to raise your team's bar on it

• A KPI-driven operator: structured interviewing, assessment design, capacity planning, and hiring manager enablement are core methods, not buzzwords

• Hands-on ATS ownership: configuration, vendor management, reporting, and driving adoption across recruiters and hiring managers

• Strong working knowledge of GDPR as it applies to candidate data, and of German employment law in hiring

• Fluent in English; German is a meaningful plus

## **What Sets You Apart**

• You've built or significantly rebuilt a TA operating model — standards, processes, and team structure — in a company that doubled headcount

• You've made employer branding work in a competitive talent market, with results you can point to

• You have a point of view on what great talent acquisition looks like — and it's grounded in outcomes, not activity

• You're drawn to mission-driven companies and want your work to connect to something larger than the next quarter

## **Why This Role**

• Own the function that most directly gates the growth of one of the most ambitious clean energy ventures in the world

• Build the hiring engine that carries a science-driven company from Series A through commercialization

• A leadership team that treats People as a strategic function, not a support desk

• Competitive compensation, equity participation, and benefits reflective of the talent bar we hold

## **What We Offer**

• **Innovative Technology & Mission: **Be part of a cutting-edge company working on groundbreaking research in clean energy and scientific discovery.

• **Career Development: **We invest in our people. This is an opportunity to join an early, growing company at the forefront of new technology, where you'll have the opportunity to develop and grow your career.

• **Collaborative Culture: **Work with great people in a dynamic, international environment with top-tier scientists, engineers and professionals passionate about solving global challenges.

• **Ownership: **Take ownership from day 1 and drive impact by making decisions, solving challenges and shaping the future of our company.

• **Your Success is our Success: **We offer a competitive salary and company ownership in the form of stock options, giving you a direct stake in our success and ownership in what we build together.

• **Vacation Days: **We support your work-life-balance by granting you 30 days of vacation per year.

• **Snacks and Drinks: **Our office fridges are never empty. Enjoy our healthy snacks and drinks. Our Darmstadt office even offers a canteen with delicious lunch options daily.

• **Retirement Plan: **If you decide for a private pension plan, we will finance 20% on top of your monthly contributions, plus loyalty incentives.

• **Events: **We organize regular events to foster team bonding, encourage collaboration, and build a strong, supportive company culture. Connect with colleagues across departments, share ideas, and have fun together, both in and outside of the workplace.

• **Mobility with NAVIT: **We partner with NAVIT to support your flexible commuting needs — whether it's a public transportation ticket, taxi rides or car-sharing, you choose what fits your lifestyle.

• **Fitness with Wellhub: **We care about your health. Get access to a wide range of gyms, fitness studios and wellness services across Europe through our partnership with Wellhub.

Focused Energy is an equal opportunity employer committed to creating an inclusive environment. Qualified applicants will receive consideration for employment without regard to race, color, religion, sex, sexual orientation, gender perception or identity, national origin, age, marital status, protected veteran status, or disability status.

Pursuant to the San Francisco Fair Chance Ordinance, Focused Energy will consider for employment qualified applicants with arrest and conviction records.

Compensation offered will be determined by factors such as location, level, job-related knowledge, skills, and experience. Certain roles may be eligible for incentive compensation, equity, benefits.

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
