# Working student - Customer Success DACH (m/f/d)

Posted: 2026-08-16T17:40:14Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**Build with us**

Since 2004, we've had one clear goal: to make payments and money management effortless for every business in Europe.

Today, more than 250,000 companies use Mollie to get paid, manage money and grow – with products designed to be simple, scalable, and dependable.

With 950+ Mollies across 14+ locations, we care deeply about autonomy and craft. So we work in small teams, with real ownership, and we trust you to make the right decisions.

We're building for the long term, so we provide the tools you need, processes you can rely on, and a balanced work environment to help you do work you're proud of.

Sound like your kind of place? Let's build together.

**Your impact**

Mollie is looking for a Customer Success Work-Student (Werkstudent) in Munich who will help us become the most loved financial service provider in Germany and Europe. Be part of an extraordinary growth story of a scale-up with outstanding products and company culture by winning the German e-commerce market. Help online businesses to scale more efficiently with a solid and easy-to-use payment solution and great support. Mollie currently has over 130.000 customers in the Benelux market and we are on a mission to win the rest of Europe. Winning Germany has been set as the number one priority for Mollie and we need your help to make us well-known.

**What you'll ship**

-

**Implement a Centralized Feedback Loop:** Unify merchant input channels into a single management tool, establishing a standardized process for intake, categorization, and roadmap integration.

-

**Drive Data-Driven Merchant Insights:** Analyze merchant performance using available dashboards and funnel data to identify trends, report on key metrics, find upsell opportunities and communicate actionable insights to the team.

-

**Support Strategic Decision-Making:** Leverage deep market and customer knowledge to provide the German management team with strategic analysis and support for high-level business initiatives.

**What you'll bring**

-

Enrolled in a Bachelor or Master Program

-

Hands-on mentality with a positive attitude

-

Curious with a hunger to learn

-

Outstanding client-facing and communication skills

-

Analytical skills

-

Fluency in German is a must. Good working English is important as it is our company language.

-

Nice to have: Some sales/customer experience from a previous internship or voluntary work

**Grow your way**

At Mollie, growth is personal. We believe everyone should have the chance to develop their skills, explore new challenges and shape their career on their own terms.

You'll get regular feedback and performance reviews to support your development, with fair and transparent salary reviews along the way. Many Mollies move into new roles or take on new projects to stretch themselves, and we actively hire from within to help you take the next step.

No matter if you're aiming for promotion, exploring a different career path or building new skills, you'll be supported with the tools, trust and opportunities to grow your way.

**Unlock your full potential and join us to eliminate financial bureaucracy**

If you're excited by the idea of building what's next, for yourself and for thousands of businesses across Europe, we'd love to hear from you. Apply with your CV (in English) using the form below.

Want a peek behind the scenes? Check out what [life at Mollie](https://jobs.mollie.com) is really like.

**AI at Mollie**

We believe in Always Be Shipping, and [AI brings](https://jobs.mollie.com/ai-manifesto) that philosophy to life across every team, every role, every day

AI is core to how we build. It helps us move faster, simplify work and make smarter decisions, creating real impact for the businesses we serve. We're looking for people who are excited to use AI to shape the future of finance with us.

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
