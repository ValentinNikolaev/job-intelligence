# VFX Artist (f/m/d) Regular / Senior

Posted: 2026-08-16T11:09:50Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
