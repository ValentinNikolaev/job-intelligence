# AI/ML & Forward Deployed Engineer

Posted: 2026-08-27T23:04:59Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**This position is listed on behalf of a partner company, who manages all applications and next steps. Our partner is looking for an AI/ML & Forward Deployed Engineer based in Germany.**

This role offers the opportunity to build and deploy high-impact AI, machine learning, and generative AI solutions from initial concept through production.
You will combine software engineering, machine learning, and MLOps/LLMOps expertise to create scalable and reliable AI products.
The position involves solving complex business problems through technologies such as LLMs, RAG pipelines, NLP, forecasting, and anomaly detection.
You will work across the full AI lifecycle, from experimentation and evaluation to deployment, monitoring, and continuous improvement.
Strong attention to security, governance, observability, and data quality will be essential when delivering production-ready solutions.
You will also collaborate closely with stakeholders to translate business needs into practical technical solutions and measurable outcomes.
This is an excellent opportunity for an experienced engineer who enjoys combining advanced AI technologies with hands-on implementation and real-world impact.

**Accountabilities**

- Design, develop, and deploy machine learning, AI, and GenAI solutions from proof of concept through production.

- Build and optimize ML models and applications covering deep learning, NLP, forecasting, classification, regression, and anomaly detection use cases.

- Develop production-grade GenAI applications using LLMs, RAG pipelines, embeddings, retrieval optimization, reranking, and prompt engineering.

- Design and implement AI evaluation frameworks to assess model quality, reliability, relevance, and performance.

- Build scalable AI services and integrations using REST and gRPC APIs as well as event-driven architectures.

- Establish and maintain MLOps and LLMOps practices covering deployment, automation, versioning, monitoring, and lifecycle management.

- Containerize and orchestrate AI applications using Docker and Kubernetes and integrate them into robust CI/CD pipelines.

- Implement model monitoring, drift detection, performance tracking, and processes for continuous model improvement.

- Ensure AI solutions meet enterprise requirements for data quality, governance, security, role-based access control, encryption, and auditability.

- Collaborate with business and technical stakeholders to understand requirements, identify opportunities for AI adoption, and translate them into effective technical solutions.

- Support solutions through production operations, troubleshooting, optimization, and ongoing improvements.

- Apply strong engineering practices to ensure AI systems are scalable, secure, observable, maintainable, and aligned with business objectives.

## **Requirements**

- 8+ years of professional software engineering or technical engineering experience.

- Strong hands-on experience in Machine Learning and AI/ML Engineering.

- Advanced Python development skills and practical experience with deep learning and machine learning techniques.

- Experience with NLP, forecasting, classification, regression, and anomaly detection.

- Proven experience building GenAI applications using LLMs and Retrieval-Augmented Generation (RAG) architectures.

- Strong understanding of embeddings, retrieval tuning, reranking, prompt engineering, and AI/LLM evaluation methodologies.

- Solid knowledge of MLOps and LLMOps principles and practices across the AI development lifecycle.

- Hands-on experience with Docker, Kubernetes, and CI/CD technologies for production deployments.

- Experience designing and developing REST and gRPC APIs and event-driven services.

- Knowledge of model monitoring, model versioning, drift detection, performance evaluation, and model lifecycle management.

- Strong understanding of data quality, data governance, security controls, RBAC, encryption, and audit trails.

- Ability to work effectively with both technical and non-technical stakeholders and translate business challenges into practical AI solutions.

- Strong problem-solving, analytical, communication, and collaboration skills.

- Ability to operate effectively in fast-moving environments while balancing experimentation with production reliability.

## **Benefits**

- Competitive annual salary of **$100,000–$120,000**.

- Full-time opportunity with a **remote working model**.

- Opportunity to work on cutting-edge AI, machine learning, and GenAI solutions.

- Hands-on exposure to LLMs, RAG, MLOps, LLMOps, Kubernetes, and cloud-native engineering practices.

- Opportunity to contribute to AI solutions from concept and experimentation through production deployment.

- Work on technically challenging projects with a strong focus on scalability, security, governance, and observability.

- Collaborative environment with opportunities to engage directly with stakeholders and influence AI solution strategy.

- Opportunity to expand expertise across modern AI engineering, machine learning, and production software development.

**How Jobgether works:**

We use an **AI-powered matching process** to ensure your application is reviewed quickly, objectively, and fairly against the role's core requirements. Our system identifies the top-fitting candidates, and this shortlist is then shared directly with the hiring company. The final decision and next steps (interviews, assessments) are managed by their internal team.

We appreciate your interest and wish you the best!

[ Why Apply Through Jobgether?](https://jobgether.com/how-jobgether-works)

**Data Privacy Notice:** By submitting your application, you acknowledge that Jobgether will process your personal data to evaluate your candidacy and share relevant information with the hiring employer. This processing is based on legitimate interest and pre-contractual measures under applicable data protection laws (including GDPR). You may exercise your rights (access, rectification, erasure, objection) at any time.

#LI-CL1

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
