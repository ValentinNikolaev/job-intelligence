# Lead .Net Software Developer, JR628

Posted: 2026-08-28T02:04:21Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

ELEKS [Software Engineering and Development Office ](https://careers.eleks.com/about/software-engineering-development-office/)is seeking a Lead .NET Developer in Germany to join our team on-site in Göttingen.

ABOUT CLIENT

Our team is working with an international pharmaceutical and laboratory equipment supplier based in Germany, serving the global biopharmaceutical industry.

The ELEKS team helps the client to develop software solutions for biopharma process automation.

**REQUIREMENTS**

- 8+ years of experience working in software development

- 5+ years of experience in .Net

- Basic experience and understanding of modern front-end approaches (Angular, React, Vue or JavaScript)

- Experience with WPF

- Strong understanding of software architecture principles, including Microservices and design patterns

- Excellent leadership and communication skills

- Advanced level of English

**RESPONSIBILITIES**

- Design, develop, and maintain reliable software at an expert level in line with the technical requirements, focusing on performance and availability

- Actively contribute to all phases of the SDLC lifecycle, including requirement analysis, design, and deployment

- Proactively propose code refactoring and software architecture improvements according to the best practices, delivering resilient, integral, and well-documented software. Collaborate with the project system analyst and software architect

- Review designs, prepare the Work Breakdown Structure (WBS), and estimate tasks with a profound understanding of project methodology (Agile, Waterfall, etc)

- Communicate with stakeholders, assess, and approve task acceptance criteria

- Distribute tasks to developers, and coordinate the team to ensure smooth execution

- Help maintain and improve high-quality standards within the developer community by sharing knowledge, mentoring, coaching, organizing training for students (Academies), and encouraging others to share their experiences

- Contribute to the internal promotion verification process and conduct preliminary interviews

- Stay up-to-date with modern technology and obtain professional certifications

- Consult on existing projects and prepare proposals for new projects, providing technical stack advisory. Collaborate with other departments, including marketing, to work on Case Studies

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
