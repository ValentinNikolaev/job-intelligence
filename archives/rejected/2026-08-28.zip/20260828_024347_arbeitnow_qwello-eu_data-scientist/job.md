# Data Scientist

Posted: 2026-08-27T23:04:07Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Our mission at **Qwello** is to revolutionize the charging industry, we are committed to turn the world from combustion to electric. We design, build and operate charging infrastructure for the public space. We excel in simplicity, user focus and engineering excellence. We value diversity of thought, background and approaches and foster a culture of belonging. We understand that the best products are built by excellent teams, not individual superstars. Be part of shaping the E-mobility of the future! ⚡

The goal of the data team is to provide insights from our data to the right people and tools at the right time. As a **Data Scientist** for our growing DATA team you go one step further and design models that allow us to predict behavior and optimize relevant kpi/metrics. You also build, train and evaluate these models with help of your colleagues in your team. You own your work end to end and therefore you are responsible for the performance of your work in the field across their entire life-span.

You are working with the other engineering teams but also with various business units to understand requirements to create and improve our data-driven solutions. You will be a key player in supporting strategic business and technical decisions and to foster profitability and innovation across the company. You are primarily responsible for innovative models and pipelines. But you are much more than the data person: You enable the next steps in charging the ever growing number of EVs in our cities more efficiently and without adding to grid overload. And by that you actively help to transform the world we live in to be more sustainable and less polluted.

**Your Responsibilities 🚀 **

- Requirements engineering / ideation as part of the team, but also on your own.

- Design, implement and maintain both models (ML & Statistical) and analytics pipelines tailored to the needs of both technical and business oriented stakeholders

- Own the solution of open-ended ambiguous problems by singling out and execute the best viable approaches

- Design experiments to test new features, pricing schemas, discover new business opportunities

- Design, implement and test prototypes of data-driven products

- Communicate relevant KPIs and results to cross-functional teams

- Proactively share knowledge and experience with the team

**Your Profile ✨**

- Great communication skills. You are able to present complicated solutions to non-technical audiences in a simple and logical way. Seriously, the non-techies have to understand you too.

- Proven experience designing and developing ML models

- Expert level statistical modeling skills, ideally including time-series modelling and forcasting

- Ideally you have industry experience in productizing, monitoring and maintaining ML models

- Ideally you have extensive experience working with geospatial data

- Solid experience with Python and the typical data libraries and tools.

- A make-it-happen attitude, helping the team to deliver on changing the world from combustion to electric

- Ability to self-organise in an environment of changing priorities; willingness to work on multiple tasks/content switching

- Fluency in English, German language knowledge is a plus

**Your Benefits 🪴**

- Flat hierarchies with an efficient decision-making processes without red tape

- The opportunity to play a key role in shaping the mobility revolution.

- Be part of an international and dynamic team of more than 30 nationalities.

- Enjoy a flexible hybrid setup — choose how you want to split your time between our Munich office and working from home, with the possibility of workation within the EU, plus 30 vacation days

- Regular company and team events outside of the office to disconnect from our computers and reconnect with colleagues on hikes, mountain e-bike tours, offsites and more.

- Personal and professional development through in-house lunch & learn sessions, collaborative coding challenge discussions, as well as externally provided training, courses and conferences.

- Discounted access to Wellpass for comprehensive wellbeing support—enjoy fitness, wellness, and mindfulness options to help you stay balanced and energized

***Equal Opportunities:***

*We strive to eliminate discrimination, remove barriers and ensure equal opportunity through a transparent recruitment process. We are fully committed to fostering an inclusive and respectful work environment where everyone can succeed. At Qwello everyone is welcomed regardless of cultural background, creed, race, sexual orientation, colour or gender expression. *

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
