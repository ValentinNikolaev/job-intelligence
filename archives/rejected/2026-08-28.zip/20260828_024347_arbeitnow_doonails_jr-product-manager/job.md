# Jr. Product Manager

Posted: 2026-08-27T17:24:34Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Hi, wir sind Doonails! 💅🏼 Ein schnell wachsendes Beauty-Startup, das die Manikürewelt revolutioniert. Mit innovativen Produkten, einer starken Community und Präsenz im Online-Shop sowie bei führenden Retail-Partnern bringen wir Studio-Qualität direkt zu unseren Kund:innen nach Hause, einfach, schnell und stilvoll.

Und genau hier kommst DU ins Spiel.

Damit unser Sortiment auch in Zukunft begeistert und Trends setzt, suchen wir dich!

Als **Junior Product Manager (m/w/d)** arbeitest du unserem Product Manager direkt zu und hältst ihm/ihr im Tagesgeschäft den Rücken frei. Du übernimmst die Recherche, Aufbereitung und Koordination, die dafür sorgen, dass Produktentwicklungen und Launches rundlaufen. Wenn du strukturiert arbeitest, Lust auf Beauty-Produkte hast und gerne der/die verlässliche Person im Team bist, auf die man sich bei der Umsetzung verlassen kann, bist du bei uns genau richtig.

**Deine Rolle & dein Impact ⚡️**

Du bist die rechte Hand unseres Product Managers und sorgst dafür, dass alles Operative reibungslos läuft. Von der Datenaufbereitung über die Abstimmung mit internen Teams bis zur Nachverfolgung offener Punkte - du hältst die Fäden im Hintergrund zusammen und schaffst so den Freiraum, in dem gute Produktentscheidungen entstehen. So trägst du direkt dazu bei, dass Doonails weiter erfolgreiche Produkte auf den Markt bringt.

**Deine zentralen Aufgaben 👩‍💻👨‍💻**

Zuarbeit in der Produktentwicklung (NPD)

- Du unterstützt unseren Product Manager entlang des gesamten Entwicklungsprozesses - von der Idee bis zum Launch - und übernimmst zuverlässig zugeteilte Aufgaben und Teilbereiche.

Recherche & Aufbereitung

- Du recherchierst Markt-, Trend- und Wettbewerbsdaten sowie Kundenfeedback und bereitest sie so auf, dass daraus schnell fundierte Entscheidungen getroffen werden können.

Datenpflege & Reporting

- Du pflegst Produktdaten, KPIs (Absatz, Umsatz, Margen) und Übersichten und bereitest Auswertungen vor, die unser Product Management in der Steuerung nutzt.

Koordination & Nachverfolgung

- Du behältst offene Aufgaben, Timelines und To-dos im Blick, hakst nach und sorgst dafür, dass nichts liegen bleibt.

Schnittstellen- & Lieferantenkommunikation

- Du unterstützt in der Abstimmung mit internen Teams (Einkauf/Ops, Brand/Marketing, Retail) und in der laufenden Kommunikation mit externen Partnern wie Produzenten, Lieferanten und Dufthäusern.

**Das bringst du mit 🤝**

- Struktur & Zuverlässigkeit: Du arbeitest organisiert, denkst mit und behältst auch bei vielen parallelen Themen den Überblick.

- Idealerweise ein Praktikum, Werkstudentenjob oder junior Tätigkeit im Product Management, Beauty Branche ist ein klarer Vorteil

- Trend-Gespür & Customer Focus: Leidenschaft für Beauty-Trends und ein Gespür für Konsumentenbedürfnisse.

- Zahlenaffinität: Freude am Umgang mit Daten und KPIs und Sorgfalt bei der Aufbereitung.

- Kommunikation & Teamwork: Offenheit und Verlässlichkeit in der Zusammenarbeit mit internen Teams und externen Partnern.

- Sprachkenntnisse: Sehr gute Deutsch- und Englischkenntnisse in Wort und Schrift.

**Deine Perspektive 📈**

Du lernst das Product Management bei einem schnell wachsenden Beauty-Brand von Grund auf kennen, direkt an der Seite unseres Product Managers. Mit der Zeit und wachsender Erfahrung kannst du mehr Eigenverantwortung übernehmen und dich Schritt für Schritt in Richtung einer eigenständigen Product-Management-Rolle entwickeln.

**Was wir dir bieten 💝**

- 💸 Faire Bezahlung, angepasst an deine Qualifikation & Erfahrung

-

🤝 Ein echtes Ownership-Rollenprofil mit viel Vertrauen & Gestaltungsspielraum

-

📈 Wachstumspotenzial: übernimm Verantwortung & bring deine Ideen direkt ein

-

📚 1.300 € Weiterbildungsbudget pro Jahr für deine persönliche Entwicklung

-

🧘 Nilo Health, denn mentale Gesundheit ist uns wichtig und dein Zugang ist inklusive

-

💪🏼 Urban Sports Mitgliedschaft

-

💼 Co-Working-Space oder Homeoffice-Ausstattung? Wir übernehmen die Kosten!

-

🥳 Teamevents in ganz Europa, weil ein starkes Team alles ist

**Ready? Wir freuen uns auf dich! ✨**

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
