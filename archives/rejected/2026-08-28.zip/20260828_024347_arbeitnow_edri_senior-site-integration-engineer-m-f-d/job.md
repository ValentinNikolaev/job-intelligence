# (Senior) Site Integration Engineer (m/f/d)

Posted: 2026-08-27T23:30:07Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**Your mission**

E.ON Drive Infrastructure operates a rapidly growing charging network across Europe. As a Site Integration Engineer, you ensure that devices, connectivity, and data flows come together in a scalable and standardized site architecture, enabling reliable operations and efficient deployments across thousands of charging locations.

- Define and evolve the reference architecture for connected sites, including connectivity topology, device standards, data flows, and monitoring concepts
- Establish technical integration standards for new devices and collaborate with vendors to ensure compliance with our architecture and connectivity requirements
- Design and maintain scalable device onboarding and zero-touch provisioning processes, including automated certificate provisioning and registration
- Lead the integration of new device types and site formats into our network and operational landscape
- Configure, operate, and maintain a diverse device fleet, including routers, cameras, sensors, and digital displays
- Manage connectivity services such as firewalls, VPNs, private APNs, and site-to-cloud connections in collaboration with external network partners
- Own SIM fleet management across multiple countries and carriers, including provisioning, lifecycle management, and carrier-level troubleshooting
- Build and continuously improve monitoring solutions for device health, connectivity, and network performance, ensuring end-to-end visibility and reliability
- Perform deep-dive troubleshooting and root-cause analysis across network, device, and cloud integration layers to ensure reliable and secure data transmission to the cloud

**Your profile**

- 4+ years of experience in networking, with a solid understanding of VPNs, NAT, firewalls, routing, and MPLS fundamentals
- Hands-on experience configuring and managing IoT devices such as routers, cameras, sensors, and digital displays
- Ability to evaluate how new devices fit into a broader site architecture, collaborate with vendors on integrations, and translate solutions into scalable standards
- Experience with SIM provisioning, APN management, and connectivity providers; a background in telecommunications or carrier environments is a strong advantage
- Good understanding of certificate lifecycle management and PKI concepts within IoT ecosystems
- Comfortable working in Linux environments, using command-line tools, and leveraging Python for automation and operational efficiency
- You think in scalable solutions rather than one-off fixes, with a strong focus on standardization, repeatability, and long-term maintainability across large site portfolios
- Familiarity with technologies and tools such as MQTT, Azure-based IoT architectures, and Grafana is considered a plus
- A hands-on builder mindset combined with a willingness to travel to charging sites when needed. You enjoy taking ownership, solving complex challenges, and continuously improving platforms, integrations, and processes in a fast-changing environment.

**Why us?**

- People take centre stage: Become part of a dynamic, ambitious and agile team that develops solutions for the eMobility market and be part of our EDRI events or the next after-work event
- With us, you get the best of both worlds - 100% start-up with the support of a large company
- The freedom you need: We offer you hybrid working with flexible working hours 
- Workation: Enjoy the flexibility to work temporarily from abroad – within the EU
- You will receive a competitive salary with a performance-related bonus 
- A company pension scheme is of course also one of the benefits with us
- Sustainable learning opportunities: We support you with a training budget of 5,000 euros per year
- You get everything you need to get started: onboarding with welcome gifts and all the hardware you need

**Contact**

Diversity counts at E.ON. We welcome all people and are convinced that differences make us stronger. Become part of our inclusive and diverse corporate culture!
 
Seize the opportunity to become part of our E.ON Drive Infrastructure team and not only create prospects for the future of E.ON, but also for your own. 
 
We look forward to getting to know you!
 
Laura
Junior Recruiter
 
Do you have any questions or difficulties with your application? Please contact me at -----

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
