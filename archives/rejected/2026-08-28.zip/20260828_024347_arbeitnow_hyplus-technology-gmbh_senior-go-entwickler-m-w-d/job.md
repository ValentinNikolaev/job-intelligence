# Senior Go Entwickler (m/w/d)

Posted: 2026-08-27T23:30:15Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**Über uns:**

Die HyPlus ist Dein Wegbegleiter im digitalen Wandel. Gemeinsam mit unseren Kund:innen entwickeln wir strukturiert, partnerschaftlich und mit klarem Fokus auf nachhaltigen Mehrwert deren digitale DNA.

Wir begleiten Unternehmen von der Anforderungsanalyse über Architektur, Softwareentwicklung und Implementierung bis hin zum Betrieb. Mit rund 800 Kolleg:innen in Deutschland, Polen, Litauen, Rumänien und Indien verbinden wir technologische Exzellenz mit Branchenkompetenz in unterschiedlichsten Marktsegmenten.

Wir begrüßen Bewerberinnen und Bewerber, die sich bereits mit modernen KI-gestützten Entwicklungstools und generativer KI beschäftigen oder Interesse daran haben, diese sinnvoll in ihren Arbeitsalltag zu integrieren. Der reflektierte Einsatz von KI sehen wir als wertvolle Ergänzung zu technischem Know-how und eigenständigem Denken.

-

Entwicklung moderner Softwarelösungen mit Schwerpunkt **Go, **von der Konzeption bis zur Umsetzung

-

Zusammenarbeit in agilen Scrum-Teams mit Kund:innen und internen Fachexpert:innen, um passgenaue Lösungen zu entwickeln

-

Konzeption, Aufbau und Weiterentwicklung von Softwarearchitekturen, APIs, Integrationslösungen und Cloud-nativen Anwendungen

-

Mitarbeit bei der Automatisierung von Deployments sowie der Weiterentwicklung von CI/CD-Prozessen

-

Unterstützung bei Refactoring-, Reengineering- und Cloud-Transformationsprojekten

-

Schrittweise Übernahme von Verantwortung, beispielsweise in den Bereichen Architektur, DevOps, Code-Qualität oder IT-Security

-

Aktiver Wissensaustausch mit Kund:innen und Kolleg:innen sowie Unterstützung bei fachlichen Fragestellungen

-

Abgeschlossenes Studium im IT-nahen Umfeld oder eine vergleichbare Qualifikation

-

Mehrjährige praktische Erfahrung in der Softwareentwicklung mit Go (Golang) sowie sicherer Umgang mit Git

-

Deutschkenntnisse auf C1/C2 Niveau

-

Englischkenntnisse auf B2 Niveau

-

Wohnsitz in Deutschland, idealerweise Nähe Ratingen/Frankfurt

-

Gute Kenntnisse in SQL und im Arbeiten mit relationalen Datenbanken

-

Vertrautheit mit Microservice-Architekturen, Docker, Kubernetes und gRPC

-

Erfahrung in der Entwicklung und dem Betrieb verteilter Backend-Systeme

-

Praktische Erfahrung im Einsatz von CI/CD-Praktiken innerhalb von Entwicklungsteams

-

Analytisches Denkvermögen, hohe Eigenverantwortung und Freude an der Arbeit im Team

-

Offene und wertschätzende Kommunikation im Austausch mit Kund:innen und Kolleg:innen

**Nice-to-have Anforderungen:**

-

Erfahrung mit weiteren Programmiersprachen oder Technologien

-

Kenntnisse im Bereich Observability, Monitoring oder Logging in verteilten Systemen

-

Erfahrung im Cloud-Umfeld (z. B. AWS, GCP, Azure)

-

Interesse an DevOps-Praktiken

**Das erwartet dich**

-

Attraktive Vergütung – wettbewerbsfähiges Fixgehalt plus leistungsabhängige Provision

-

Karriereperspektive – klar definierte Entwicklungsmöglichkeiten

-

Weiterentwicklung – kontinuierliche Trainings, Zertifizierungen und Zugang zu Branchen-Events

-

Flexibilität – Hybrid-/Remote-Modell, flexible Arbeitszeiten

-

Unternehmenskultur – kollegiales, politikarmes Umfeld, in dem deine Ideen und Ergebnisse zählen

-

Zusatzleistungen – z. B. Gesundheitsbudget, Team-Offsites, moderne Tech-Ausstattung, Mobilitätspaket, Jobrad etc.

**Chancengleichheit**

HyPlus ist ein Arbeitgeber der Chancengleichheit. Wir schätzen Vielfalt und setzen uns aktiv für ein inklusives Arbeitsumfeld ein, in dem sich alle Mitarbeitenden willkommen und wertgeschätzt fühlen.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
