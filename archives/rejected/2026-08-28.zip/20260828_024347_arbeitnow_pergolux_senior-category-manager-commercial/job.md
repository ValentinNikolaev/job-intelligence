# Senior Category Manager (Commercial)

Posted: 2026-08-27T23:40:20Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

As a Senior Category Manager (Commercial) (m/w/d), you will own the global commercial success of PERGOLUX's tailormade pergolas, one of our biggest untapped growth opportunities. While roughly 70% of the market demands custom sizing, tailormade currently represents only a small share of our revenue, and your mandate is to change that by driving revenue, contribution margin, and market adoption across all PERGOLUX markets globally. Sitting at the intersection of Product, Marketing, Sales, and E-commerce, you will translate product potential into measurable business results and uncover the product adjustments needed to scale the category.

PERGOLUX designs and sells Scandinavian-inspired outdoor living products, from pergolas to garden furniture, directly to consumers. With around 300 employees, 9-figure revenue, and operations across 8 markets, we combine premium product quality with the pace and ownership culture of a company that has grown consistently across Europe and beyond.

**What You'll Do**

-

Own the global commercial performance of tailormade pergolas, including revenue, conversion, and contribution margin, and define the go-to-market and scaling strategy in alignment with Product Management and Country Managers.

-

Identify and remove commercial bottlenecks across the funnel (traffic, conversion, average order value, attach rate) and continuously optimise based on data and insights across markets.

-

Ensure optimal product presentation, pricing logic, content, and UX on all Shopify websites, and maintain consistent positioning and branding across every touchpoint.

-

Pilot and scale new commercial initiatives such as bundles, promotions, upsell logic, and channel experiments, and enable local sales teams with playbooks, training, objection handling, and pricing logic.

-

Generate industry and user insights that inform product development, and, when it keeps execution speed high, personally deliver first versions of website updates, ad copy, and sales scripts.

**What You'll Bring**

-

4+ years of experience in E-commerce, Growth, Business Development, or Commercial Category Management, with a proven track record of driving revenue and margin growth in a complex or global environment.

-

Fluent German language skills (required).

-

Strong commercial intuition and an analytical mindset, comfortable working with funnel analytics (traffic, conversion rate, AOV, attach rate, contribution margin) and turning data into action.

-

High ownership mentality, a clear bias for action, and a hands-on, zero-to-one execution style, paired with strong stakeholder management across global, cross-functional teams.

-

Nice to have: experience with Shopify UX/content optimisation, GTM playbook creation, and product marketing, plus direct experience in home & garden, outdoor living, DTC furniture/hardware, or custom/tailormade product categories.

**🌟 Benefits and Lifestyle**

-

You will take real ownership from the start with direct impact on key business outcomes, and gain fast-track opportunities to grow into senior leadership roles as PERGOLUX scales the tailormade category globally.

-

Up to 30 vacation days, starting at 27

-

One week per year remote workation in EU/UK

-

International, collaborative team, working with colleagues across Europe

-

Regular team events (summer party, Christmas party, after-work gatherings) and retreats

-

Modern setup and laptops (Apple or Windows)

-

Employee discounts on PERGOLUX products

-

Jobrad / Bike leasing program, promoting sustainable and healthy commuting

**How to Apply**

If you are ready to own and scale a high-impact commercial category, we would love to hear from you. Apply via our [Career Page]([https://pergolux.careers/](https://pergolux.careers/)) or connect with us on [LinkedIn]([https://www.linkedin.com/company/pergolux/posts/?feedView=all](https://www.linkedin.com/company/pergolux/posts/?feedView=all)).

PERGOLUX is an equal opportunity employer. We welcome applicants from all backgrounds, we think it's less about ticking every box and more about what you bring to the table!

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
