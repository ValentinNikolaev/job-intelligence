# IT Systemadministrator Cloud Security in Stuttgart gesucht (m/w/d)

Posted: 2026-08-27T21:30:35Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Stuttgart | IT-Projekte | Support | Cloud & Security

**Du willst nicht einfach Tickets abarbeiten, sondern IT aktiv mitgestalten?**

Du bringst Erfahrung in der Systemadministration mit, arbeitest strukturiert und lösungsorientiert und hast Spaß daran, technische Themen eigenständig voranzutreiben?

Dann könnte diese Position genau zu dir passen.

## Aufgaben

Deine Aufgaben

Dich erwartet ein vielseitiges Umfeld, in dem du neben dem operativen IT-Betrieb auch bei spannenden Projekten Verantwortung übernimmst.

- Planung und Mitwirkung bei IT-Projekten – unter anderem Hardware- und Software-Rollouts, Cloud-Migrationen und IT-Security

- Übernahme von Projektmanagement-Aufgaben und eigenverantwortliche Betreuung einzelner Themen

- Analyse, Optimierung und Dokumentation von IT-Prozessen im Service- und Supportbereich

- Betreuung der Telefonanlage, des Mobile Device Managements, des Rechenzentrums und des Dokumentenmanagements

- Konzeption und Durchführung von IT-Schulungen

- Unterstützung und Begleitung neuer Mitarbeitender bei der Nutzung von IT-Systemen und Standardanwendungen

## Qualifikation

Das bringst du mit

Du arbeitest gerne selbstständig, behältst auch bei mehreren Themen den Überblick und hast einen ausgeprägten Servicegedanken.

Idealerweise bringst du mit:

- Abgeschlossene Ausbildung als Fachinformatiker/in für Systemintegration oder eine vergleichbare Qualifikation

- Mehrjährige Berufserfahrung, idealerweise in einem Dienstleistungsumfeld

- Organisatorisches Geschick sowie eine strukturierte und serviceorientierte Arbeitsweise

- Eigenverantwortung, Zuverlässigkeit und Engagement

- Sicherer Umgang mit MS Server, Windows 11 und MS Office

- Sehr gute Deutschkenntnisse in Wort und Schrift

## Benefits

Was dich erwartet

Hier bekommst du eine Position mit Verantwortung, abwechslungsreichen Aufgaben und Möglichkeiten, dich fachlich wie persönlich weiterzuentwickeln.

- Vielseitiges und verantwortungsvolles Aufgabengebiet

Persönliche und fachliche Entwicklungsmöglichkeiten

- Modernes Arbeitsumfeld in zentraler Lage in Stuttgart

- Flexible Arbeitszeiten

Möglichkeit zum mobilen Arbeiten

- Urlaubs- und Weihnachtsgeld

- EGYM Wellpass und weitere Zusatzleistunge

Warum die Position interessant ist

IT wird hier nicht nur verwaltet – sie wird weiterentwickelt.

Du bewegst dich zwischen klassischer Systemadministration, Support, Infrastruktur und modernen Projekten. Dadurch bleibt dein Arbeitsalltag abwechslungsreich und du kannst deine Erfahrung dort einbringen, wo sie wirklich gebraucht wird.

Du suchst eine Aufgabe mit Verantwortung, kurzen Wegen und Entwicklungsmöglichkeiten? Dann freuen wir uns darauf, dich kennenzulernen**.**

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
