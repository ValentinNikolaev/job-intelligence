# Staff Backend Engineer

Posted: 2026-08-27T23:45:23Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

## **Who We Are**

AI is changing how software gets built. Code production is becoming a commodity. The focus is shifting from writing code to specifying, orchestrating, verifying, and governing change – and the toolchain is the new constraint.

We are at the center of this shift. We build Develocity, a toolchain observability and intelligence platform used by some of the world's leading software organizations – Netflix, Airbnb, Spotify, SAP, major global banks, and hundreds more. Develocity helps software teams achieve delivery excellence through deep observability, build and test acceleration, and AI-powered intelligence across the entire toolchain – with support for Gradle Build Tool, Apache Maven™, sbt, npm, Python, and Bazel.

We are an AI-native company. AI is not a feature we're bolting on – it's central to how we work, how we think about our product, and where we're heading. Develocity encodes a decade of build and test expertise into a context engineering layer: the ground truth AI agents need to change code safely, and the governance to attribute and gate that change at machine speed. Trust, evidence, and explainability are at the core of everything we build.

We have partnered with the Apache Software Foundation, the Commonhaus Foundation, the Micronaut Foundation, and other OSS projects such as Spring, Quarkus, Kotlin, JUnit, AndroidX, and many more to bring the values of Develocity also to the OSS Community.

## **Our Values**

**Seek to Understand: **Everything starts with listening and understanding, and we strive to understand different viewpoints, problems, and motivations. Before we take action, we ensure we truly grasp the challenges, perspectives, and goals.

**Know the Why**: We approach our work with a clear sense of purpose, ensuring every step is deliberate and focused. We take meaningful action with urgency, but never at the expense of thoughtful consideration.

**Innovate & Iterate**: We embrace challenges and are not afraid to try new things, even if they might fail. With deep understanding and a clear purpose, we can develop creative and bold solutions to tackle challenges.

**Own the Outcome: **We are empowered to take initiative and we maintain transparency in our work and its outcomes. When we execute, we take responsibility for our decisions, measure the success of our innovations, and learn from the results.

## **Who You Are**

You're an experienced Staff Software Engineer and your adoption of AI has changed the scale of what you take on.

You've taken initiatives that were ambiguous at the start, created structure where none existed, and driven them across teams to completion. You use what you build, and push for everyone around you to do the same. You judge your work by how much value reaches customers and how quickly. You make consequential calls with pragmatism and without close guidance, and you bring stakeholders and leadership with you. That judgment covers product direction as much as technical aspects.

You have a strong record of delivering testable, evolvable, and scalable back-end architectures to production, and you thrive on the problems that come with them. You don't need to be a build expert, though you bring a deep understanding of and interest in the automation domain, as well as developer and AI agent productivity. You hold strong opinions, articulate them clearly, and change them when the evidence says so. Working in a distributed team suits you, and you can write concise documents that align everyone.

## **Responsibilities**

- Design, implement, test, deliver, and maintain Develocity features

- Own ambiguous initiatives, from discovery through production to proven impact

- Surface scope and delivery risk early across the initiatives you run, and drive the mitigation

- Write the discoveries and specifications that turn several teams' input into one coherent plan

- Set the standard in the day-to-day: the code you write, the reviews you give, and how you use AI

- Dogfood what you ship, and keep the practice strong across teams

- Work and communicate directly with customers on product discoveries and rollouts

- Participate in Develocity releases, in collaboration with the entire engineering team

## **Minimum Qualifications**

- Effective use of AI to ship quality software at high velocity

- In-depth experience with Java or another JVM language (our codebase is primarily Java)

- Experience leading complex features end-to-end and cross-team

- Proficiency in written and spoken English

- Self-motivated and self-managing, with excellent organizational skills

## **Preferred Qualifications**

- Building systems where AI agents are a primary consumer

- Working on developer tools

- Automating the software build and delivery process

- Working with AWS, Docker, and Kubernetes

- Designing and scaling fault-tolerant, highly-available distributed systems

## **What We Offer**

- Opportunity to work on a widely-used product with a clear vision for the future

- Work on the problem AI created: verifying and governing change at machine scale

- Close customer interaction with engineers from leading tech organizations

- An automation-focused, test-driven engineering culture where working with frontier AI is the default

- Close collaboration with experienced and dedicated peer engineers

- Opportunities for growth in technical and leadership responsibilities

- In-person meetings, such as our annual company offsite and team meetings

- Work from home in a remote-first environment

- Competitive salaries and equity grants

## **Location**

- Remote from Europe, with working conditions allowing seamless collaboration with your colleagues through email, chat, and video conferencing

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
