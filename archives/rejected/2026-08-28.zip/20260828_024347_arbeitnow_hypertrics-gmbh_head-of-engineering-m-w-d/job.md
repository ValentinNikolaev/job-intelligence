# Head of Engineering (m/w/d)

Posted: 2026-08-27T23:30:42Z

## Rejection

- Category: tech_stack
- Reason: role does not mention Go/Golang or PHP

### **Head of Engineering (m/w/d)**

**Standort: Kassel | Vollzeit | Unbefristet**

Für unseren Mandanten, ein etabliertes Unternehmen aus dem **Sondermaschinenbau**, suchen wir im exklusiven Auftrag zum nächstmöglichen Zeitpunkt einen **Head of Engineering (m/w/d)** am Standort Kassel. In dieser verantwortungsvollen Position übernehmen Sie die fachliche und disziplinarische Führung der mechanischen Konstruktion und gestalten die technische sowie organisatorische Weiterentwicklung des Bereichs aktiv mit.

#### **Ihre Aufgaben**

-

**Führung & Teamentwicklung:** Fachliche und disziplinarische Führung der Mitarbeitenden in der mechanischen Konstruktion – inklusive Coaching, Kompetenzentwicklung und Förderung einer offenen, leistungsorientierten Teamkultur

-

**Mechanische Konstruktion:** Verantwortung für die konstruktive Betreuung und Weiterentwicklung komplexer Maschinen und technischer Systeme

-

**Produktentwicklung:** Mitgestaltung und Weiterentwicklung bestehender Lösungen sowie Entwicklung neuer technischer Konzepte auf Basis zukünftiger Anforderungen

-

**Engineering & Problemlösung:** Verantwortung für anspruchsvolle technische und mechanische Fragestellungen sowie Entwicklung konstruktiv, fertigungstechnisch und wirtschaftlich überzeugender Lösungen

-

**Konstruktionsmethodik:** Weiterentwicklung moderner Engineering- und Konstruktionsmethoden – insbesondere in den Bereichen CAD-Konstruktion, Belastungsbetrachtung und Simulation

-

**Prozesse & Transformation:** Aktive Weiterentwicklung von Organisation, Prozessen und Strukturen innerhalb des Verantwortungsbereichs sowie Begleitung technischer und organisatorischer Veränderungsprojekte

-

**Schnittstellenmanagement:** Enge Zusammenarbeit mit angrenzenden technischen Bereichen und der Fertigung, um eine effiziente und praxisnahe Entwicklung sicherzustellen

-

**Strategische Mitgestaltung:** Aktive Mitarbeit im erweiterten Führungskreis sowie Mitgestaltung und Umsetzung der technischen und organisatorischen Ausrichtung des Engineering-Bereichs

#### **Ihr Profil**

-

**Fachliche Qualifikation:** Erfolgreich abgeschlossenes Studium im Bereich Maschinenbau oder eine vergleichbare technische Qualifikation

-

**Berufserfahrung:** Mehrjährige Erfahrung in der Konstruktion und Entwicklung komplexer Maschinen und Anlagen – idealerweise aus dem Sondermaschinen- oder Anlagenbau

-

**Führungserfahrung:** Fundierte Erfahrung in der fachlichen und disziplinarischen Führung technischer Mitarbeitender sowie Freude daran, Teams weiterzuentwickeln und Veränderungen aktiv zu gestalten

-

**CAD-Kenntnisse:** Sehr gute Kenntnisse in der mechanischen Konstruktion, idealerweise mit **Autodesk Inventor und Vault**

-

**Fertigungskompetenz:** Fundiertes Verständnis für Fertigungstechnologien, Werkstoffe und die fertigungsgerechte Konstruktion technischer Lösungen

-

**Technisches Verständnis:** Gute Kenntnisse in Festigkeitsberechnung, Werkstoffkunde und der methodischen Entwicklung mechanischer Systeme

-

**Zusatzqualifikation:** Idealerweise Zusatzqualifikation als **Schweißfachingenieur** – alternativ Bereitschaft, diese Qualifikation zu erwerben

-

**Persönlichkeit:** Kommunikationsstarke und souveräne Führungspersönlichkeit mit strategischem Denken, hoher Veränderungsbereitschaft und der Fähigkeit, Mitarbeitende für neue Technologien und Arbeitsweisen zu gewinnen

-

**Arbeitsweise:** Strukturiert, präzise und ergebnisorientiert mit hohem Qualitätsanspruch, Eigeninitiative und einem ganzheitlichen Blick auf technische und wirtschaftliche Anforderungen

-

**Sprachen:** Sicheres Englisch in Wort und Schrift für die Zusammenarbeit in einem internationalen technischen Umfeld

#### **Ihre Vorteile**

-

**Verantwortungsvolle Führungsposition:** Zentrale Rolle mit fachlicher und disziplinarischer Verantwortung für die mechanische Konstruktion

-

**Gestaltungsspielraum:** Möglichkeit, Engineering-Prozesse, Strukturen und Konstruktionsmethoden aktiv weiterzuentwickeln und eigene Ideen nachhaltig umzusetzen

-

**Technischer Anspruch:** Abwechslungsreiche und anspruchsvolle Aufgaben in einem professionellen Engineering-Umfeld

-

**Strategischer Einfluss:** Mitarbeit im erweiterten Führungskreis und aktive Beteiligung an der zukünftigen Ausrichtung des Verantwortungsbereichs

-

**Innovation & Entwicklung:** Möglichkeit, neue Technologien, Methoden und Entwicklungsansätze voranzutreiben

-

**Weiterentwicklung:** Unterstützung bei der fachlichen und persönlichen Entwicklung sowie Möglichkeit zum Erwerb relevanter Zusatzqualifikationen

-

**Langfristige Perspektive:** Unbefristete Führungsposition in einem etablierten Unternehmen des Sondermaschinenbaus mit langfristiger beruflicher Perspektive

#### **Kontakt**

Hypertrics GmbH
Schürmannstraße 22a
45136 Essen

####

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
