# Senior Software Engineer - .Net & AI (m/f/d)

Posted: 2026-08-27T23:30:31Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**Job Description**

We're looking for a Senior Software Engineer to join our backend team. You'll work on distributed, event-driven systems that power core product functionality. In addition, you'll play a key role in designing and building AI agent workflows that are integrated into real customer-facing products. This is a hands-on engineering role for someone who is passionate about turning the potential of agentic AI into production-ready solutions.

**Your tasks:**

- Design, build, and operate scalable backend services using C# and .NET
- Develop distributed, event-driven systems leveraging RabbitMQ and asynchronous messaging patterns
- Drive the design and implementation of agentic AI solutions that create real customer value and are deeply integrated into our products
- Partner with product, data, and platform teams to deliver high-quality features from concept to production
- Help shape our engineering culture by raising technical standards, mentoring others, and fostering best practices

**Your skillset:**

- Strong hands-on expertise in C# and the .NET ecosystem. You are comfortable designing, building, and owning complex backend services end-to-end
- Proven experience building and operating distributed backend systems in production environments
- Practical experience with RabbitMQ or similar message brokers (Kafka, Azure Service Bus, etc.)
- Hands-on experience building AI agentic systems — this is a must, not a nice-to-have
- Solid understanding of distributed systems, asynchronous programming patterns, and event-driven architecture
- Experience with Azure cloud infrastructure
- Familiarity with LLM orchestration frameworks (LangChain, Semantic Kernel, AutoGen, etc.)
- Prior work on systems that integrate AI into customer-facing workflows

**What we offer:**

- Office spaces in Germany (Berlin, Selmsdorf) and Sweden (Örebro) with flexible hybrid work arrangements
- Meaningful work as the market leader in funeral technology
- The opportunity to participate in the technical transformation of a European company
- A small, focused engineering leadership group working on fundamental platform challenge

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
