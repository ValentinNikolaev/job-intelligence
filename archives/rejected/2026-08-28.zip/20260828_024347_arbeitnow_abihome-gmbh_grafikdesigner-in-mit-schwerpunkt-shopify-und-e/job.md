# Grafikdesigner:in mit Schwerpunkt Shopify und E-Commerce (m/w/d)

Posted: 2026-08-27T22:00:31Z

## Rejection

- Category: tech_stack
- Reason: role does not mention Go/Golang or PHP

Wir von Gradoo erstellen Abschlusszeitungen, Merchandise und Textilien für Schulen. Dafür entstehen regelmäßig neue Shopify-Shops, die individuell gestaltet werden.

Wir suchen eine **kreative, zuverlässige und selbstständig arbeitende Person**, die uns bei der optischen Gestaltung und Umsetzung unterstützt.

Die Aufgaben fallen je nach Saison und Anzahl der neuen Schulshops unterschiedlich an. Deshalb suchen wir keine klassische feste Besetzung, sondern eine **langfristige Freelancer-Zusammenarbeit mit flexiblem Umfang**.

Aktuell rechnen wir mit etwa 10–40 Stunden pro Monat. Der Umfang kann entsprechend der Auftragslage schwanken.

## Aufgaben

- Gestaltung und Anpassung von Shopify-Schulshops

- Anpassung von Farben, Bildern, Layouts und Bannern

- Erstellung von Grafiken und individuellen Visuals

- Nutzung von KI-Tools für neue Bildwelten und Gestaltungsideen

- kleinere Anpassungen an bestehenden Shopify-Layouts

- eigenständige Entwicklung von kreativen Lösungen

## Qualifikation

- gutes Gespür für modernes und ansprechendes Design

- Erfahrung mit einem oder mehreren Grafik-Tools, z. B. Figma, Adobe-Programme, Canva

- Erfahrung im E-Commerce, Design oder Websdesign (Shopify)

- sicherer Umgang mit KI-Tools zur Bildgenerierung und -bearbeitung

- eigenständige und strukturierte Arbeitsweise

- zuverlässige Kommunikation und Einhaltung von vereinbarten Deadlines

## Benefits

- viel Gestaltungsfreiraum

- abwechslungsreiche Aufgaben zwischen E-Commerce und klassischem Grafikdesign

- kurze Entscheidungswege

- eigenverantwortliches Arbeiten

- flexible Arbeitszeiten

- Homeoffice

Klingt nach dir? Dann freuen wir uns sehr darauf dich kennezulernen.

Schick uns dein Portfolio bzw. einige Arbeitsproben, ein paar Informationen zu dir, deine Preisvorstellung und deine ungefähre Verfügbarkeit.

Zum Kennenlernen würden wir anschließend einen kleinen Testauftrag durchführen.

Wir freuen uns!

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
