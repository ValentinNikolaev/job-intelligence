# Senior Community Manager (m/w/d)

Posted: 2026-08-27T23:30:23Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Tibia begeistert seit 1997 Spielerinnen und Spieler auf der ganzen Welt und zählt zu den ältesten und erfolgreichsten MMORPGs überhaupt. Als Community Manager bist Du die Brücke zwischen unserer großen internationalen Community und unserem Entwicklerteam und trägst aktiv dazu bei, dass das Spiel weiterhin lebendig bleibt. Ein besonderes Highlight steht schon an: Du hilfst mit, das **30-jährige Jubiläum von Tibia** vorzubereiten, eines der größten Events in der Geschichte des Spiels. Wenn Du gerne schreibst, Menschen verbindest und für Games brennst, dann bewirb Dich jetzt bei uns in Regensburg.

**Bei uns kannst Du:**

-

eine große internationale und loyale Community begleiten und mitgestalten

-

anspruchsvolle englische Texte und Artikel rund um Tibia verfassen

-

die Wünsche und Bedürfnisse unserer Community direkt bei der Weiterentwicklung des Spiels einbringen

-

das 30-jährige Jubiläum von Tibia als großes Community-Event mitprägen

-

Produktmanagement und Entwicklung mit fundiertem Community-Wissen beraten

**Wir stellen uns vor, dass Du:**

-

Erfahrung im Community Management und ein sicheres Gespür für soziale Dynamiken mitbringst

-

redaktionelle Fähigkeiten besitzt und stilsicheres Englisch auf hohem Niveau beherrschst

-

auch in kontroversen Diskussionen souverän und sachlich bleibst

-

Deine Standpunkte fundiert und beherzt vertrittst und dabei andere Perspektiven konstruktiv einbeziehst

-

sorgfältig und strukturiert arbeitest, sehr belastbar bist und hohe Eigeninitiative zeigst

**Warum CipSoft? Wir bieten** **Dir:**

-

ein **flexibles Arbeitszeitmodell**, mit dem Du zwischen 6 und 23 Uhr arbeiten kannst, wie Du möchtest

-

eine Arbeitswelt **ohne Überstunden und ohne Crunch**, dank guter und vorausschauender Planung

-

**grenzenlose Weiterbildung** mit unbegrenztem Fachbudget plus 5.000 Euro individuellem Budget alle zwei Jahre

-

einen **zukunftssicheren Arbeitsplatz** in einem unabhängigen, profitablen Spiele-Studio

-

einen **Umzugs-Support**, der Dir den Start in Regensburg mit finanzieller Hilfe oder Übergangslösungen erleichtert

-

viele weitere Vorteile, die das Arbeiten bei CipSoft besonders machen und unter **[karriere.cipsoft.com/vorteile](http://karriere.cipsoft.com/vorteile)** auf Dich warten

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
