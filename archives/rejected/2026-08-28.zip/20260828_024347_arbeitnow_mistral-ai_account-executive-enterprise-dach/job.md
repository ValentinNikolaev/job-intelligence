# Account Executive, Enterprise, DACH

Posted: 2026-08-27T23:40:17Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

## **About Mistral**

Mistral provides full-stack AI solutions: from frontier models to developer tools, applications, and compute. We partner with enterprises tackling the hardest problems—across high-stakes industries like finance, manufacturing, defense, healthcare, and the public sector—co-creating customized AI systems that they can run on their terms.

We are a dynamic, collaborative team passionate about AI and its potential to transform society. Our diverse workforce thrives in competitive environments and is committed to driving innovation. Our teams are distributed between Europe, North America, Asia and the Middle East. We are creative, low-ego and team-spirited.

**About Mistral **

At Mistral AI, we believe in the power of AI to simplify tasks, save time, and enhance learning and creativity. Our technology is designed to integrate seamlessly into daily working life.

We democratize AI through high-performance, optimized, open-source and cutting-edge models, products and solutions. Our comprehensive AI platform is designed to meet enterprise needs, whether on-premises or in cloud environments. Our offerings include le Chat, the AI assistant for life and work.

We are a dynamic, collaborative team passionate about AI and its potential to transform society.

Our diverse workforce thrives in competitive environments and is committed to driving innovation. Our teams are distributed between France, USA, UK, Germany and Singapore. We are creative, low-ego and team-spirited.

Join us to be part of a pioneering company shaping the future of AI. Together, we can make a meaningful impact. See more about our culture on [https://mistral.ai/careers](https://mistral.ai/careers).

**Role Summary:**

As our Enterprise Sales Executive, you will be instrumental in shaping Mistral’s adoption with our largest customers across a variety of industries. You will be driving deals end2end: from prospective, first intro call until closing and beyond — together with our dedicated implementation specialist, tech and legal teams.

**What you will do:**

**Lead development (strategic outbound and qualified inbound):**

- Handle strategic outreach as well as warm introductions to promising enterprise customers

- Converting inbound deals where upselling / more bespoke agreements can be achieved

**Value prop validation for customer:**

- Provide hands-on support and guidance to clients during a potential Proof of Concept (POC) phase, ensuring a smooth and successful evaluation process

- Leverage successful POC outcomes to facilitate the conversion of POCs into long-term, revenue-generating contracts

**Deal management & closing:**

- Develop and execute strategic sales plans to convert leads into valued customers — you are the first point of contact for all external stakeholders and are responsible for properly managing deals and aligning all stakeholders (heavy involvement of customer engineering, product, and commercial teams, both on operational and C-level)

- Handle customer negotiation end2end, together with our legal and implementation specialist team

**Executive Engagement:**

- Cultivate and maintain strong relationships with C-level executives, heads of innovation/AI, and other key decision-makers within target organisations

- Comprehend their specific challenges and needs, positioning our solution as an integral part of their strategic initiatives

**Technical Aptitude:**

- Demonstrate a deep understanding of the technical intricacies of our product and articulate its value proposition effectively to potential clients

- Work side-by-side with our implementation team to ensure that customer’s questions, concerns and challenges are taken care of during pre-sales, deployment and post-deployment phase

- Collaborate with our technical team to address any customer inquiries or concerns

**Training and enablement:**

-Empower internal teams with the knowledge and resources that you collect in customer conversations to drive product roadmap and align on priorities

**Who you are:**

- 7-10 years experience in Sales (enterprise sales/consultative selling, ideally selling a highly complex, technical product)

- Excellent academics: Bachelor and/or Master Degree in Business, Computer Science, or a related field

- Significant work experience within AI ecosystem or related data/infrastructure field

- Experience at successful fast growing startup, ideally in deep-tech

- Strong technical skills to navigate quickly evolving products and steer technical discussions

- Excellent German and English

- Outstanding negotiation and communication skills

**What We Offer:**

💰 Competitive cash salary and equity

🥕 Food : Daily lunch vouchers

🥎 Sport : Monthly contribution to a Gym pass subscription

🚴 Transportation : Monthly contribution to a mobility pass

🧑‍⚕ Health : Full health insurance for you and your family

🍼 Parental : Generous parental leave policy

🌎 Visa sponsorship

By applying, you agree to our [Applicant Privacy Policy](https://legal.mistral.ai/terms/applicant-privacy-policy).

## **What We Offer**

We offer a comprehensive benefits package designed to support your well-being, growth, and work-life balance. Benefits vary by country and may include healthcare coverage, parental leave, retirement plans, relocation support, wellness programs, meal and transportation allowances, and other location-specific perks.

For the most up-to-date details on benefits available in your location, please refer to our [Benefits page](https://app.notion.com/p/mistralai/Benefits-at-Mistral-36e6ba59a7fe836b93dd01737fcc27ef?source=copy_link).

## **Privacy Policy**

Your privacy matters to us. You can learn more about how we handle your personal data in our [Applicant Privacy Policy](https://legal.mistral.ai/terms/applicant-privacy-policy).

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
