# Strategic Partner Lead, SAP

Posted: 2026-08-27T23:40:17Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

## **About Mistral**

Mistral provides full-stack AI solutions: from frontier models to developer tools, applications, and compute. We partner with enterprises tackling the hardest problems—across high-stakes industries like finance, manufacturing, defense, healthcare, and the public sector—co-creating customized AI systems that they can run on their terms.

We are a dynamic, collaborative team passionate about AI and its potential to transform society. Our diverse workforce thrives in competitive environments and is committed to driving innovation. Our teams are distributed between Europe, North America, Asia and the Middle East. We are creative, low-ego and team-spirited.

## **Role Summary **

As part of our rapid global expansion we are looking for a Strategic Partner Lead for our SAP partnership in Germany to join our first-on-the-ground Germany Partner GTM team. Our ambitions are high and wide and to bring to market the most advanced AI technology, we are building a best-in-class Go-To-Market team. Builders wanted!

In this role you will be instrumental in driving the strategy and execution for our SAP partnership globally.

## **What You Will Do**

**Build strategic partnership plans and executive relationships:**

-

Negotiate or enhance partnership agreements and contracts, ensuring they are mutually beneficial and align with our company's interests.

-

Develop and execute strategic plans to drive pipeline and co-selling activities with SAP in Europe, APAC and the US.

-

Own end-to-end partnership responsibilities including financial business outcomes, co-sell, technical integrations, joint marketing campaigns, etc.

-

Develop and drive Mistral on SAP offerings including Sovereign AI

-

Expand the partnership within SAP to new product teams, industry sales teams, etc.

-

Align partner executive stakeholders to key Mistral executive counterparts.

**Execute SAP plans to drive results:**

-

Execute strategic partnership plans to achieve pipeline and revenue results as a critical part of the Global GTM team.

-

Serve as a point of escalation to help resolve field conflicts using your network of key contacts within both companies as well as your knowledge of each company’s strategic priorities

-

Lead the development and communication of the partnership performance analysis, including financial performance, agreed metrics, and related insights.

-

Provide enablement and support to strategic partners to ensure they are effectively promoting and selling our products or services.

**Company Builder and Collaborator:**

-

Collaborate with cross-functional teams to ensure the successful implementation of partnership initiatives.

-

Work with Mistral engineering and products team to help advance the customer experience for Mistral’s models and tools on SAP’s platform, including defining new routes to market through the SAP partnership

-

Develop a strong collaboration with Mistral’s GTM team to help drive pipeline and help advance opportunities to closure.

-

Align SAP Global and regional sales teams with Mistral’s sales counterparts and facilitate a regular MBR cadence.

## **Who you are:**

-

Bachelor's degree in Business, Marketing, Information Technology, or a related field. An MBA or related advanced degree is preferred.

-

Minimum of 10 years of experience in GTM roles with 5+ years experience in partner management, business development or sales roles.

-

Deep knowledge and past experience working in the specific SAP ecosystem (organizational structure, relationships, offerings), preferably with the SAP AI teams.

-

Understanding of Sovereign AI partnerships and offerings

-

Ideally, a strong network at global level within SAP’s partner organizations.

-

Knowledge of the SAP partner ecosystem and the sales motion between SAP and it partners

-

Excellent negotiation, communication, and interpersonal skills.

-

Strong understanding of the technology or software industry, with a focus on Cloud partnerships.

-

Ability to travel as needed to meet with strategic partners and attend industry events.

-

Strong analytical skills, with the ability to monitor and analyze partnership performance and provide actionable insights.

-

Builder and self-starter with the ability to work independently and as part of a team.

## **What we offer:**

💰 Competitive cash salary and equity

🥕 Food : 150€ Monthly meal allowance

🥎 Sport : Monthly contribution to a Gympass subscription

🚴 Transportation : Monthly contribution to your mobility (parking charges or public transport)

🍼 Parental : Generous parental leave policy

🌎 Visa sponsorship

By applying, you agree to our [Applicant Privacy Policy](https://legal.mistral.ai/terms/applicant-privacy-policy).

## **What We Offer**

We offer a comprehensive benefits package designed to support your well-being, growth, and work-life balance. Benefits vary by country and may include healthcare coverage, parental leave, retirement plans, relocation support, wellness programs, meal and transportation allowances, and other location-specific perks.

For the most up-to-date details on benefits available in your location, please refer to our [Benefits page](https://app.notion.com/p/mistralai/Benefits-at-Mistral-36e6ba59a7fe836b93dd01737fcc27ef?source=copy_link).

## **Privacy Policy**

Your privacy matters to us. You can learn more about how we handle your personal data in our [Applicant Privacy Policy](https://legal.mistral.ai/terms/applicant-privacy-policy).

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
