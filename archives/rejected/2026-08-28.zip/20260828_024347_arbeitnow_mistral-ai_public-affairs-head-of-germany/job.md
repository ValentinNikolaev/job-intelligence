# Public Affairs, Head of Germany

Posted: 2026-08-27T23:40:17Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

## **About Mistral**

Mistral provides full-stack AI solutions: from frontier models to developer tools, applications, and compute. We partner with enterprises tackling the hardest problems—across high-stakes industries like finance, manufacturing, defense, healthcare, and the public sector—co-creating customized AI systems that they can run on their terms.

We are a dynamic, collaborative team passionate about AI and its potential to transform society. Our diverse workforce thrives in competitive environments and is committed to driving innovation. Our teams are distributed between Europe, North America, Asia and the Middle East. We are creative, low-ego and team-spirited.

# The Role

As a Head of Public Affairs for Germany on the Policy and Government Relations team, you will shape Mistral AI’s presence and influence in Germany, ensuring the company plays a leading role in the future of AI policy and regulation.

This role exists to establish Mistral AI as a trusted thought leader in Germany, driving both public interest and business growth by navigating complex regulatory landscapes.

You will work closely with policymakers, industry leaders, and internal teams to build a regulatory ecosystem that supports innovation while enabling adoption in the public sector.

Your impact will be immediate: from shaping policy strategies to unlocking revenue opportunities, you will help Mistral AI thrive in one of its most critical markets.

This role directly reports to our Public Affairs Director for EMEA, and may evolve to a larger DACH and/or Central Europe scope in the future.

# What You Will Do

-

Monitor and analyze AI-related policy developments in Germany and the EU, assessing their impact on Mistral AI.

-

Develop and execute a long-term public affairs strategy, including parliamentary engagement, position papers, and lobbying campaigns.

-

Engage with policymakers, industry leaders, and key opinion leaders to foster constructive dialogue on AI and technology policy.

-

Prioritize and respond to policy issues affecting Mistral AI, proposing solutions that align with business and community interests.

-

Advise cross-functional teams on regulatory changes, ensuring compliance and informing product and business decisions.

-

Collaborate with Sales to design strategies that accelerate public sector adoption of AI.

-

Track industry trends and best practices in public affairs, ensuring the team remains ahead of regulatory shifts.

-

Build and maintain a strong network in Germany to amplify Mistral AI’s influence and reputation.

# What We're Looking For

-

Extensive public affairs experience, with a track record of impacting policy-making, ideally in both public and private sectors.

-

Deep understanding of German institutions (federal, regional, and local) and the ability to map decision-making power.

-

Expertise in tech regulations, including GDPR, Copyright, AI Act, DMA, and tax laws.

-

Experience in highly scrutinized environments, where public affairs are critical to business success.

-

Trust-building skills, with the ability to defend positions rigorously, foster long-term relationships, and act as a thought partner.

-

Team player with a bias for action, ownership, and the ability to navigate ambiguity.

-

AI knowledge and familiarity with long-term industrial plans or model development (a plus).

-

Open Source mindset, aligning with Mistral AI’s commitment to openness and collaboration.

## **What We Offer**

We offer a comprehensive benefits package designed to support your well-being, growth, and work-life balance. Benefits vary by country and may include healthcare coverage, parental leave, retirement plans, relocation support, wellness programs, meal and transportation allowances, and other location-specific perks.

For the most up-to-date details on benefits available in your location, please refer to our [Benefits page](https://app.notion.com/p/mistralai/Benefits-at-Mistral-36e6ba59a7fe836b93dd01737fcc27ef?source=copy_link).

## **Privacy Policy**

Your privacy matters to us. You can learn more about how we handle your personal data in our [Applicant Privacy Policy](https://legal.mistral.ai/terms/applicant-privacy-policy).

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
