# Corporate FP&A – Financial Planning

Posted: 2026-08-27T23:40:20Z

## Rejection

- Category: tech_stack
- Reason: role does not mention Go/Golang or PHP

### ABOUT CODEWAY

We build and publish mobile apps that reach millions fast.

We've built category-leading apps time and time again. A track record proven by hits like Cleanup (#1 iPhone storage cleaner worldwide), Retake AI (#1 AI face editing app in the US), and Learna AI (the top AI language learning app globally), alongside 50+ other apps across productivity, edtech, wellness, and entertainment, all shaping the future of consumer mobile.

Since launching in 2020 with a small team in Istanbul, we've grown into a 300+ person global team. With over 400 million downloads and a worldwide footprint, we're already one of the fastest-growing consumer tech companies in Europe, and join us in our next big chapter.

### POSITION

As our Corporate FP&A Analyst - Planning, you will report directly to the Director of FP&A and sit at the ultimate strategic clearinghouse of our finance function. As our portfolio scales globally, we are building a lean, world-class decision-support function from the ground up to evaluate complex strategic options, portfolio expansions, and capital deployment choices. You will sit at the corporate level, owning the master consolidation, corporate budget, and the underlying logic for individual app-level P&Ls.

This is an AI-first, digital-native finance team. We communicate via active Slack channels, build out our operational blueprints and context sharing inside Notion, and run collaboration entirely through Google Workspace. You will leverage modern workflows—initially building and auditing multi-variable models in Microsoft Excel using the Claude for Excel add-in, with a direct, subsequent mandate to act as a core product stakeholder driving our platform migration to Pigment.

### KEY SKILLS**

**

To excel in this role, you must bring a sharp blend of institutional corporate finance discipline, modern data literacy, and a forward-looking technology stack:

-

**Strategic Architecture:** Mastery of 3-statement long-range planning (LRP), **rolling monthly forecasting**, and corporate top-down / bottom-up budget reconciliation.

-

**Tactical Liquidity Control:** Active management of short-term cash mechanics, specifically building **13-week rolling cash flow forecasts**.

-

**Next-Gen Financial Stack:** Advanced driver-based Excel modeling paired with prompt engineering (**Claude for Excel**) and multi-dimensional EPM exposure (**Pigment** / Anaplan).

-

**Data & Ledger Awareness:** Familiarity or exposure to data systems (**Looker** / BI tools) and cloud ERP structures (**NetSuite**) to collaborate effectively on data alignment.

-

**Mobile Ecosystem Domain Expertise:** Deep familiarity with B2C mobile metrics (**ROAS**, LTV, CAC, and cohort curves) and institutional debt facility covenant tracking.

### WHAT YOU’LL BE DOING**

**

-

**Own the Global Planning Cycle Engine & Budget Setting:** Act as the architect and coordinator of Codeway’s global budget setting and forecasting process. You will build and own the corporate top-down strategic forecasting model and lead the continuous process of coordinating and consolidating the bottom-up inputs from the FBP network. You will design, establish, and push unified planning templates out to the FBPs, running a rigorous rolling monthly forecast to keep the global corporate model perfectly synchronised with live business pacing. You will partner closely with FBPs to challenge operational assumptions, extract key variables, and align strategic direction to fuel "The Engine."

-

**Enterprise Valuation & Long-Range Planning (LRP):** Build and scale corporate three-statement models and integrated multi-year cash flow frameworks explicitly designed to evaluate macro strategic options, support capital structuring, and drive long-term corporate value creation.

-

**Tactility & Liquidity Control:** Balance macro long-range planning with hyper-tactical operational control by owning, executing, and maintaining a tight, rolling 13-week cash flow forecast.

-

**Corporate UA Integration & Capital Pacing:** Partner closely with our Corporate FP&A team members who own the portfolio UA allocation models. While they evaluate cohort dynamics across our apps to maximise ROAS, you will integrate their marketing deployment outputs into our central business plan, reconciling portfolio allocation shifts directly against corporate cash reserves and growth capital constraints.

-

**Growth Capital & Credit Facility Management:** Direct the tracking, optimisation, and structural compliance of our institutional credit facility used to scale UA. Monitor global capital drawdowns, track funding velocity against strict covenant thresholds, and generate institutional-grade financial reporting for our lending partners.

-

**Multi-Dimensional Portfolio Cost Allocations:** Architect and manage the cost allocation framework required to distribute centralised overhead (shared engineering, global data lakes, corporate G&A) down to individual app-level P&Ls to isolate and report true fully loaded unit economics.

-

**Advanced Scenario Modeling:** Build dynamic, driver-based sensitivity models to instantly simulate shifting ecosystem dynamics and top-of-funnel marketing performance, cleanly integrating core growth metrics (ROAS, LTV, and CAC).

-

**Board Preparation & Headcount Alignment:** Synthesise complex data into premium corporate narratives and visual decks for quarterly board reviews. Partner closely with the Talent Acquisition (TA) team to ensure global hiring plans and recruitment velocity reconcile perfectly with approved corporate budget constraints.

-

**System Integration & BI Collaboration:** Support the connection between our corporate planning stack and underlying data environments. You will collaborate on projects to ensure financial actuals from NetSuite and core revenue performance/unit economics from Looker sync cleanly into our planning architecture (Excel/Claude → Pigment).

### WHAT YOU’LL BRING

-

**Experience:** 3-6 years in Corporate FP&A, Strategic Finance, Investment Banking, or Transaction Advisory within a high-growth B2C digital platform, mobile app company, or gaming studio.

-

**Dual-Speed Financial Fluency:** Equal comfort building high-level strategic valuation structures (3-statement multi-year planning) and executing rapid, short-term liquidity controls.

-

**Elite Individual Contributor Profile:** A high-autonomy operator who executes with urgency. You are highly proactive, you drive projects forward independently, and take immense pride in the technical integrity of your models.

-

**The Codeway Ethos:** A natural self-starter who looks forward, not backward. You completely avoid an audit or ledger-heavy mindset; you treat finance as an agile, value-generating growth partner, and possess the conviction to challenge leadership constructively in a founder-led culture.

-

**Collaborative Matrix Skills:** Strong foundational background in corporate consolidation and recurring planning windows. You excel at extracting variables from decentralised partners, using high-impact communication to pressure-test assumptions and seamlessly turn operational data into continuous rolling monthly forecasts.

-

**Mobile Ecosystem Domain Expertise:** Deep operational understanding of app store economics, subscription models, digital revenue dynamics, and core growth tracking metrics—specifically ROAS, LTV, and CAC.

-

**Next-Gen Technical Profile:** You treat prompt engineering as a core finance capability, with hands-on experience or immediate adaptability to LLM add-in layers (Claude for Excel).

-

**Systems & Data Literacy:** Comfortable navigating Looker (or equivalent BI platforms) to view or cross-check revenue performance and tracking data frameworks within NetSuite. Exposure to multi-dimensional EPM tools (Pigment, Anaplan, or Workday Adaptive) is a major plus.

### WHAT WE OFFER

-

Flexible Career Trajectory: We are looking for an exceptional builder. If leadership is your goal and you demonstrate the capability, this role is positioned on a direct track to step up and lead the Corporate FP&A team. Alternatively, if your passion lies in pure execution, you have the option to remain as a principal individual contributor driving global architecture.

-

Scale & Impact: The rare opportunity to shape the central financial architecture of a profitable, self-funded scale-up ($400M+ ARR) right at its inception.

-

Culture: An energetic, high-performance environment where finance is treated as an aggressive value-generator rather than administrative overhead. Relocation support available if you decide to move to Barcelona.

-

Full-time contract with competitive salary

-

Private health insurance

-

Full visa & relocation support if you’re moving to Barcelona

-

Annual learning & development budget for courses, tools, or events that support your growth

-

Wellness perks, including sports budget and psychological consultations.

-

Free access to Codeway’s suite of apps across productivity, wellness, and education

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
