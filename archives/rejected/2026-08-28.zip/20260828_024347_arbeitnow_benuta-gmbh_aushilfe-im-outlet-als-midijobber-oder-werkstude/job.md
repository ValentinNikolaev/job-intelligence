# Aushilfe im Outlet als Midijobber oder Werkstudent (m/w/d)

Posted: 2026-08-27T20:30:24Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Willkommen bei benuta, dem führenden E-Commerce-Unternehmen für Teppiche! Seit 2008 begeistern wir über 1,5 Millionen Menschen in 17 Ländern mit unseren Onlineshops. Wir haben es uns zur Aufgabe gemacht, das Zuhause unserer Kund*innen zu verschönern und ihre vielfältigen Bedürfnisse in unseren Markenwelten abzubilden. Mit viel Leidenschaft und Engagement arbeiten wir als inhabergeführtes Unternehmen an unserer gemeinsamen Vision: Die Entwicklung der Brand und die Besten zu sein, in dem, was wir tun!

Wir freuen uns über deine Hilfe im Rahmen eines Midijobs (30 Std./ Woche) oder als Werkstuden*in (bis 20 Std. / Woche) in unserem benuta Outlet in Bonn und bieten dir die Flexibilität, die du brauchst. Freue Dich auf eine positive Arbeitsatmosphäre sowie ein junges und nettes Team. Werde Teil von benuta – wir freuen uns auf dich! (Werkstudent*innen auch willkommen)

**Deine Aufgaben**

-

Du unterstützt unser Team im Bereich Lager bei der Warenverräumung und sorgst dafür, dass unsere Teppiche ordentlich sortiert und für den Verkauf vorbereitet sind.

-

Du übernimmst die Kontrolle, Etikettierung und das Scannen unserer Produkte.

-

Du bist im Verkauf aktiv, berätst unsere Kunden kompetent und hilfst ihnen bei der Auswahl der passenden Produkte.

-

Du kümmerst dich um die Abwicklung der Kassiervorgänge (nur Kartenzahlung).

-

Du sorgst für eine ansprechende Warenpräsentation und trägst zur Gestaltung des Verkaufsbereichs bei.

-

Du achtest auf Sauberkeit und Ordnung im Lager und Verkaufsraum, um ein angenehmes Einkaufserlebnis zu gewährleisten.

**Über Dich**

-

Du zeichnest Dich durch Pünktlichkeit, Zuverlässigkeit und eine hohe Motivation aus.

-

Du hast idealerweise erste Erfahrung in einem Lager oder im Einzelhandel gemacht und kannst Aufgaben selbstständig priorisieren.

-

Du bringst eine gute körperliche Fitness mit, da das Bewegen unserer Teppiche körperlich herausfordernd sein kann.

-

Du bist bereit, auch samstags zu arbeiten und Dich flexibel in unser Team einzubringen.

-

Du schätzt ein kollegiales Arbeitsumfeld und bist bereit, Verantwortung zu übernehmen.

**Unser Angebot**

-

**Sei Du selbst: **Bei uns sind alle willkommen - das heißt come as you are und fühl Dich wohl!

-

**Stärke Dich: **Wir bieten Dir ein umfangreiches (veganes) Verpflegungsangebot mit bezuschusstem Mittagessen, Frühstück, Kaffee, (Hafer-) Milch, Obst, einer Vielzahl von kalten Getränken und mehr.

-

**Bring Dich ein:** Deine Ideen werden gehört und Du wirst immer Freiraum für die Umsetzung eigener Ansätze bekommen.

-

**Profitiere von:** Förderung und Zuschüssen für Mobilität (Fahrrad-Leasing, E-Ladesäulen) und guter ÖPNV-Anbindung sowie attraktiven Rabatten für Mitarbeitende.

-

**Deine Vergütung:** 14,50- € brutto / Std. nach einem Jahr Betriebszugehörigkeit 15,50 - €

**Schwerbehinderte Bewerber*innen werden bei gleicher Eignung besonders berücksichtigt.*

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
