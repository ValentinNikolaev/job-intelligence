# Client Operation Specialist (all gender)

Posted: 2026-08-27T23:40:18Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**Client Operations Specialist (all genders)**

Erledigst Du am liebsten Dinge, bevor sie überhaupt zum Problem werden? Behältst Du in unübersichtlichen Prozessen den Überblick**,** während andere längst den Faden verloren haben, und macht es Dir Freude, aus Daten die richtigen Schlüsse zu ziehen? Als **Client Operations Specialist ** sorgst Du für den reibungslosen Ablauf unserer (geförderten) Weiterbildungsprogramme und hältst mit dem Team eine unserer wichtigsten KPIs – die Absolventenrate – auf einem hohen Niveau.

Du begleitest Teilnehmende auf ihrer Lernreise und sorgst dafür, dass unsere Kunden ihre Trainingsziele erreichen und die bestmögliche Lernerfahrung mit uns haben. Dabei arbeitest Du eng mit Sales, Coaching, Learning und Engineering zusammen, nutzt Dashboards für datenbasierte Entscheidungen und übernimmst eigenständig Verantwortung für Projekte, die unsere Prozesse jeden Tag ein Stück besser machen.

**Schwerpunkte Deiner Rolle**

-

**Teilnehmendenbegleitung & Support**: Du begleitest Teilnehmende organisatorisch durch den gesamten Weiterbildungszyklus – von Onboarding bis Abschluss. Dabei beantwortest du Support-Anfragen zuverlässig und erkennst Abbruchrisiken frühzeitig.

-

**Prozesse & Automatisierung: **Du stellst reibungslose Abläufe sicher, optimierst diese kontinuierlich und identifizierst Automatisierungspotenziale zur Effizienzsteigerung interner Prozesse und Weiterentwicklung unserer Workflows

-

**Koordination & Schnittstelle:** Du bist eine Kommunikationsschnittstelle zu Teilnehmenden und relevanten Stakeholdern (z. B. Sales, Coaching, Learning, Engineering)

-

**Datenarbeit & Dashboards:** Du arbeitest datenorientiert und nutzt täglich Dashboards, um Deine Aufgaben zu steuern und Entscheidungen zu treffen.

-

**Projektverantwortung & Agilität:** Du übernimmst eigenständig Projekte, definierst Key Results und arbeitest flexibel in sich ändernden Prozessen.

**Das bringst Du mit**

-

Abgeschlossenes Studium (z. B. Betriebswirtschaftslehre, Wirtschaftsinformatik oder vergleichbar) oder vergleichbare Qualifikation sowie ein gutes Verständnis für Daten und den sinnvollen Einsatz von KI zur Automatisierung und Optimierung von Prozessen

-

Technische Affinität und schnelle Einarbeitung in administrative Tools; idealerweise erste Erfahrung mit Asana, HubSpot/CRM, Slack, und LMS (Learning Management System)

-

Du hast echtes Interesse an Daten- und KI-Themen und nutzt KI-Tools (z. B. Claude, ChatGPT, Copilot) selbstverständlich in Deinem Arbeitsalltag, um Prozesse und Kommunikation zu optimieren.

-

Ausgeprägte Kommunikationsfähigkeit und Empathie im Umgang mit Teilnehmenden, Kund:innen und Kolleg:innen (E‑Mail, Telefon, Webinar/Meeting)

-

Selbstständige, eigenverantwortliche Arbeitsweise, hohe Eigenmotivation, Teamgeist und Freude an agilen Methoden

-

Vorteil: Erfahrung im Kundenservice, Customer Success oder in der Teilnehmendenbetreuung, idealerweise im Bildungs- oder SaaS-Umfeld.

-

Sehr gute Deutschkenntnisse (min. C1) und gute Englischkenntnisse

**Das bieten wir Dir**

**Arbeitskultur
**Dich erwartet eine lösungsorientierte und datengetriebene Arbeitsweise, eine offene Feedbackkultur sowie ein starker Teamspirit. Zwei vom gesamten StackFuel-Team gewählte Trustees unterstützen Dich bei Fragen und Anliegen als neutrale, vertrauliche Anlaufstelle.

**Ownership
**Übernehme ab dem ersten Tag Verantwortung, bringe Deine eigenen Ideen aktiv ein, gestalte Prozesse nachhaltig und präge unsere Abläufe maßgeblich mit.

**Hybrides Arbeiten
**Wir arbeiten in einem hybriden Modell und sind üblicherweise 3 Tage pro Woche vor Ort in unserem Office in Berlin.

**Workation
**Bis zu 10 Tage pro Jahr kannst Du von überall aus der EU, dem EWR und der Türkei arbeiten.

**Raum für Austausch
**Regelmäßiger Austausch im Team, saisonale Feiern und eine immer gut gefüllte Küche sorgen für ein lebendiges Miteinander.

**Weiterentwicklung
**Absolviere unsere Online-Trainings, um Deine fachlichen Fähigkeiten auszubauen und Dich zur Expert:in für Daten und KI zu entwickeln.

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
