# DSP Engineer - Werkstudent

Posted: 2026-08-27T23:55:21Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

#### **Join Axon and be a Force for Good.**

At Axon, we’re on a mission to Protect Life. We’re explorers, pursuing society’s most critical safety and justice issues with our ecosystem of devices and cloud software. Like our products, we work better together. We connect with candor and care, seeking out diverse perspectives from our customers, communities and each other.

Life at Axon is fast-paced, challenging and meaningful. Here, you’ll take ownership and drive real change. Constantly grow as you work hard for a mission that matters at a company where you matter.

### Your Impact

This is a hands-on opportunity to apply what you're learning about signal processing to a real product that keeps people and critical infrastructure safe. As a Working Student on our RF Engineering team in Kassel, you'll work alongside experienced DSP engineers — prototyping algorithms, analyzing real RF captures, and building the tooling that helps us detect and classify drones in the wild. You'll grow your practical DSP and software skills on real-world data, with mentorship and room to take ownership of meaningful pieces of work.

### What You'll Do

**Location:** Onsite at our Kassel, Germany office, with flexible hours around your studies
**Reports to:** Team Lead

- Help prototype, implement, and test DSP algorithms in Python and C++.

- Analyze recorded RF / I/Q captures and help characterize drone and controller signals.

- Build and improve scripts and tooling for signal analysis, data handling, and visualization.

- Run experiments and document results to support detection and classification work.

### What You Bring

- Currently enrolled in a Bachelor's or Master's program in Electrical Engineering, Communications Engineering, Computer Science, or a related field.

- Coursework or project experience in DSP fundamentals (e.g., sampling, filtering, FFT/spectral analysis, modulation).

- Programming experience in Python and/or C++.

- Genuine curiosity about RF / wireless and signal processing, and an eagerness to learn on real data.

- Good communication skills in English; German is a plus.

Don’t meet every single requirement? That's ok. At Axon, we Aim Far. We think big with a long-term view because we want to reinvent the world to be a safer, better place. We are also committed to building diverse teams that reflect the communities we serve.

Studies have shown that women and people of color are less likely to apply to jobs unless they check every box in the job description. If you’re excited about this role and our mission to Protect Life but your experience doesn’t align perfectly with every qualification listed here, we encourage you to apply anyways. You may be just the right candidate for this or other roles.

**Important Notes**

*The above job description is not intended as, nor should it be construed as, exhaustive of all duties, responsibilities, skills, efforts, or working conditions associated with this job. The job description may change or be supplemented at any time in accordance with business needs and conditions.*

*Some roles may also require legal eligibility to work in a firearms environment.*

*We collect personal information from applicants to evaluate candidates for employment. You may request access, deletion, or exercise other CCPA rights at **[Axon Privacy Web Form](https://privacyportal.onetrust.com/webform/0efc1702-9321-4119-bc9d-a06c3a1d3e4e/ca57cc26-a159-4193-9f6e-58ffe3fd2509). For more information, please see the Your California Privacy Rights section of our [Applicant and Candidate Privacy Notice.](https://www.axon.com/candidateprivacypolicy)*

*Axon’s mission is to Protect Life and is committed to the well-being and safety of its employees as well as Axon’s impact on the environment. All Axon employees must be aware of and committed to the appropriate environmental, health, and safety regulations, policies, and procedures. Axon employees are empowered to report safety concerns as they arise and activities potentially impacting the environment.*

*We are an equal opportunity employer that promotes justice, advances equity, values diversity and fosters inclusion. We’re committed to hiring the best talent — regardless of race, creed, color, ancestry, religion, sex (including pregnancy), national origin, sexual orientation, age, citizenship status, marital status, disability, gender identity, genetic information, veteran status, or any other characteristic protected by applicable laws, regulations and ordinances — and empowering all of our employees so they can do their best work. If you have a disability or special need that requires assistance or accommodation during the application or the recruiting process, please email Please note that this email address is for accommodation purposes only. Axon will not respond to inquiries for other purposes.*

Phishing alert: Axon will never ask you to pay for any part of the hiring process, including training, equipment, or background checks. We do not make job offers via text message, WhatsApp, or instant messaging platforms without a formal interview process. All legitimate job openings are listed on our official careers page at [https://www.axon.com/careers](https://www.axon.com/careers). If you receive a suspicious offer or outreach from an email address that is not ----- or if you are asked for sensitive personal information (bank details, Social Security Number) prematurely, please ignore the message and report it to

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
