# Principal Security Engineer

Posted: 2026-08-28T02:04:57Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

We believe it takes great people to create a great product. That’s why our team lives our company values, and we hire based on them, too. Since 2010, Pipedrive has been on a mission to support sales and marketing teams with easy-to-use, powerful tools that make everyday work faster and easier. Today, our cloud-based software is trusted by over 100,000 companies and used in 179 countries. We have grown from a five-person team to a truly international company of over 850+ people, representing more than 50 nationalities, with ten offices distributed across Europe and the US. In 2020, Pipedrive received a majority investment from Vista Equity Partners, a global investment firm that invests exclusively in enterprise software, data and technology-enabled businesses, making Pipedrive the fifth unicorn from Estonia.

We’re looking for a Principal Security Engineer to join Pipedrive as a technical builder responsible for engineering the security architecture of our SaaS platform, corporate operations and the tools and methods the security team will use. This position is a high-level engineering role focused on building the systems that automate security at scale and simultaneously address the threats to them. The role will also be an active partner across the business acting in an advisory role to both technical and business partners to ensure their vision and objectives can be safely met.

If this sounds like an exciting opportunity, we’d love to chat!

**Your new adventure:**

**Security Engineering & Agentic Automation**

- Engineer and architect scalable security solutions for cloud-native environments to protect customer data, applications, and networks

- Develop autonomous security agents and workflows using LLMs and agentic frameworks to automate complex tasks such as event monitoring and triage, threat modeling, vulnerability discovery and remediation

- Design and build automated identity and access management (IAM), data encryption, and threat detection capabilities that function without manual intervention

**AI Security Architecture & Integrity**

- Create technical baselines and security controls for AI-driven products, ensuring data model integrity and the security of training pipelines

- Build defenses against emerging AI-specific threats, such as prompt injection, model inversion, and data leakage, within both customer-facing and internal AI initiatives

- Conduct deep-dive technical reviews of AI architectures to ensure security is embedded into the foundation of every new model and automation project

**Technical Leadership & Collaboration**

- Lead the response effort during active security incidents and provide expert analysis when called upon for internal investigations

- As a Principal Security Engineer, you will participate in an off-hours on-call rotation with a 30-minute response SLA—serving as the primary security SME for high-severity alerts, driving swift containment and mitigation, and leading incident orchestration across engineering teams and internal stakeholders when critical security events arise

- Partner with Engineering and SRE teams to engineer security directly into our Platform, CI/CD pipelines and Infrastructure-as-Code (IaC)

- Provide technical mentorship to security and engineering teams, fostering a culture where security is viewed as an engineering challenge to be solved with code

- Ensure that all engineered solutions align with the broader enterprise security strategy

**Does this sound like you?**

- 7+ years of experience in security engineering, cloud security, or security architecture in a SaaS or cloud-native environment

- Proficiency in at least one programming language with the ability to write and review production-quality code

- Demonstrated ability building with AI: developing with LLM APIs, agentic frameworks or utilizing AI-assisted coding tools to automate engineering workflows

- Deep technical proficiency in cloud security, modern IAM, and network security

- Expertise in Secure SDLC & DevSecOps: Strong understanding of building security into automated deployment pipelines and infrastructure

- Strong written and verbal communication skills, with the ability to explain complex security issues to both technical and non-technical audiences

**Why Pipedrive?**

- **People-first culture** – Be part of a team that values authenticity, champions collaboration, and supports each other—no egos, just teamwork. Work alongside top talent from around the world in an inclusive space where different perspectives fuel our best ideas. Everyone is welcome

- **Unlock potential **– Push boundaries, take ownership, and experiment with the latest technologies as we enhance our AI First Vision. We empower bold ideas that drive real change

- **We’ve got you** – Your well-being matters. Enjoy flexible hours, wellness perks and SWAG. Think performance-based bonuses, 28 paid leave days, well-being days, compassionate leave, and even pawternal leave—because we take care of ourselves and our people

- **Grow with us** – Whether through mentorship, coaching, or internal mobility, we invest in helping you unlock your potential. Open, honest feedback and clear communication are at our core. We grow together through trust and accountability

- **Packed with purpose** – Help 100,000+ small and medium-sized businesses grow and succeed while doing meaningful, customer-driven work

**Diversity & Inclusion:** Pipedrive is an equal opportunity employer. We value diversity and are committed to creating an inclusive environment for all employees. We welcome applications regardless of race, color, religion, age, gender, sexual orientation, gender identity or expression, national origin, disability, veteran status, marital or family status, or any other characteristic protected by applicable law.

**
Eligibility:** Please note that for this position, we are only able to consider candidates who already possess the legal right to work in **Germany** without the need for visa sponsorship or relocation assistance and located within a commutable distance to our Pipedrive **Berlin **office.

**
Background Checks:** Where permitted by local law and necessitated by the scope of the role (e.g., access to sensitive data), Pipedrive may conduct a pre-employment background check. This will be handled in strict accordance with our [Candidates Privacy Notice](https://www.pipedrive.com/en/jobs/privacy-notice).

#LI-Hybrid
#LI-ME1

We’re looking for a Principal Security Engineer to join Pipedrive as a technical builder responsible for engineering the security architecture of our SaaS platform, corporate operations and the tools and methods the security team will use.

If this is something for you, send us your resume (in English) or a link to your LinkedIn profile and please add why we should pay extra attention to your application.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
