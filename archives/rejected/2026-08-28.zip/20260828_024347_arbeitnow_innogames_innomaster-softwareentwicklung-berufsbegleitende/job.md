# InnoMaster Softwareentwicklung (berufsbegleitendes Masterstudium) - WiSe27

Posted: 2026-08-27T20:24:42Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Du hast eine Leidenschaft für die Softwareentwicklung und möchtest Dein Masterstudium spannend und praxisnah gestalten? Du möchtest nach Deinem Bachelorabschluss weiter studieren und gleichzeitig ins Berufsleben einsteigen? Und das alles bei einem festen Monatsgehalt und voller Finanzierung Deiner Studiengebühren? Dann ist unser InnoMaster Programm genau das Richtige für Dich!

Im Rahmen des **InnoMaster Softwareentwicklung** studierst Du berufsbegleitend an der Uni Hamburg, der Fachhochschule Wedel oder der Hochschule für angewandte Wissenschaften einen akkreditierten Masterstudiengang im Bereich Informatik/ Softwareentwicklung und wir übernehmen die Kosten! Parallel dazu sammelst Du wertvolle praktische Berufserfahrung in verschiedenen Bereichen der Softwareentwicklung und kannst Dein theoretisches Wissen direkt in die Praxis umsetzen. Neben verantwortungsvollen Aufgaben und einer festen angemessenen Vergütung bieten wir Dir die Teilnahme an Trainings (aus dem Fachbereich, Programmiersprachen oder Soft Skills) und Unterstützung bei Deiner weiteren Karriereplanung.

Der InnoMaster Softwareentwicklung ist auf ca. drei Jahre ausgelegt mit einer wöchentlichen Arbeitszeit von 25 Stunden während der laufenden Semester und 40 Wochenstunden während den vorlesungsfreien Zeiten. Für weitere Fragen bezüglich des berufsbegleitenden Studiums stehen wir Dir gerne zur Verfügung.

**Dein Skillset**

- **Bachelor. **Du hast Dein IT-bezogenes Bachelor- oder Diplomstudium mit guten Noten abgeschlossen (Notendurchschnitt 2,5 oder besser).

- **Zulassungsvoraussetzungen.** Du erfüllst die Zulassungsvoraussetzungen Deines Wunschstudiengangs an der Universität Hamburg (UHH), der Fachhochschule Wedel (FH Wedel) oder der Hochschule für angewandte Wissenschaften Hamburg (HAW).

- **Programmiersprachen.** Du hast Vorkenntnisse in einer objektorientierten Skript- oder Programmiersprache (z.B. Java, C# or PHP).

- **Softwareentwicklung.** Dich zeichnet eine Affinität zur Softwareentwicklung aus, die sich in deinen persönlichen Softwareprojekten zeigt.

- **Zukunftsgestalter*in**. Du siehst in der Künstlichen Intelligenz die Chance, die Zukunft unserer Spiele mitzugestalten und freust dich, Deine Begeisterung und ersten KI-Erfahrungen in realen Projekten anzuwenden.

- **Soft skills.** Du arbeitest gerne selbstständig, zeigst ein hohes Maß an Eigeninitiative und hast eine ausgeprägte Teamorientierung und eine schnelle Auffassungsgabe.

- **Englisch.** Unsere Unternehmenssprache ist Englisch. Du freust Dich darauf deine sehr guten Englischkenntnisse täglich in Wort und Schrift anzuwenden.

**Deine Power-Ups**

- **Ein Team von Spezialist*innen.** Werde Teil eines stabilen, wachsenden und preisgekrönten globalen Unternehmens. Lerne deine zukünftigen Kolleg*innen im Bereich [Softwareentwicklung & IT](https://www.youtube.com/watch?v=eFCFIo447tU) in diesem Video kennen.

- **Perfektes Lernumfeld.** Wir bieten Dir ein äußerst interessantes technisches Umfeld und modernste Arbeitsbedingungen.

- **Karriereentwicklung.** Wir unterstützen Deine berufliche und persönliche Entwicklung durch eine optimale Betreuung durch eine Ansprechperson in der Abteilung und eine Ansprechperson in unserem People & Culture Team.

- **Gehalt und Studiengebühren. **Wir finanzieren Deine vollen Studiengebühren einschließlich Bücher und zahlen Dir ein monatliches Gehalt von 2.531 € brutto.

- **Hervorragende Ausstattung.** Du arbeitest mit einem voll ausgestatteten MacBook Pro und wir stellen Dir zusätzlich dazu ein Smartphone oder Tablet Deiner Wahl zur Verfügung.

- **Agiles Arbeiten. **Dich erwarten flexible Arbeitszeiten, sowie agile, funktionsübergreifende Teams mit kurzen Entscheidungswegen.

- **Team Events.** Teamwork ist uns wichtig: Wir legen viel Wert auf ein Arbeitsklima, in dem Kommunikation und Interkulturalität großgeschrieben werden; wir feiern unsere Erfolge in wöchentlichen Afterworks sowie regelmäßigen Team- und Unternehmensevents wie die [InnoConf](https://youtu.be/UpcpmS41jbU?si=7ssAlPojio3-jBbJ).

- **Modernes und gemütliches Büro.** Wir bieten Dir diverse Möglichkeiten Arbeit und Wohlbefinden miteinander zu vereinbaren: frisches Obst und kostenlose Getränke, hauseigenes Fitnessstudio, Gaming-Bereich, Dachterrasse mit BBQ, Relaxing-Rooms und vieles mehr.

InnoGames ist einer der führenden deutschen Entwickler und Publisher von Mobile- und Browsergames und ein zertifizierter Great Place to Work®. Das Unternehmen mit Sitz in Hamburg wurde 2007 gegründet und gehört heute zur Modern Times Group (MTG). Zusammen mit ca. 350 Mitarbeitern aus 40 Nationen entwickeln die Unternehmensgründer einzigartige Games, die Millionen von Spielern auf der ganzen Welt jahrelangen Spaß bieten. Bekannt ist InnoGames vor allem für Forge of Empires, Elvenar und Die Stämme, aber das Unternehmen vergrößert sein mittlerweile 10 Spiele umfassendes Portfolio kontinuierlich über Plattformen und Genres hinweg. Die letzten Neuzugänge waren Heroes of History, ein neuartiger Mix aus City Builder und Hero Collection RPG und Cozy Coast, ein Strandabenteuer zum Wohlfühlen mit ausgefeiltem Merge-2-Gameplay und einer packenden Story.

Du bist bereit Deine Reise mit InnoGames zu beginnen und Teil unseres Teams zu werden? Dann freuen wir uns auf Deine Bewerbung (Anschreiben, Lebenslauf, Bachelorzertifikat mit Notenübersicht und Codebeispiele) ausschließlich als Onlinebewerbung über [innogames.com/career](http://innogames.com/career). Deine Ansprechpartnerin ist **Saara Harris.**

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
