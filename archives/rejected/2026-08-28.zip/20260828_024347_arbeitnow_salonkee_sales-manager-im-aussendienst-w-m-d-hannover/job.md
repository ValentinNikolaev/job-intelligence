# Sales Manager im Außendienst (w/m/d) - Hannover

Posted: 2026-08-27T20:40:26Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**Über Salonkee**

Wir sind eines der am schnellsten wachsenden SaaS-Unternehmen Europas und das digitale Herz der Friseur- und Beauty-Salons. Von smarter Terminplanung und Payments bis hin zu KI-gestütztem Reporting: Wir geben Salons die Tools, die sie brauchen, um als modernes Business zu glänzen.

**Wir verbinden Software mit Fintech und Automatisierung.**

Unser Ziel? Selbstständigen Unternehmer:innen den Rücken freizuhalten, damit sie fundierte Entscheidungen treffen und nachhaltig wachsen können.

Wir sind ein internationales, technologiegetriebenes Team, das Verantwortung liebt und Dinge wirklich bewegt.

**Hast du Lust, eine ganze Branche aufs nächste Level zu heben?**

**Deine Aufgaben**

-

**Dein Tag, deine Mission:** Du planst deine Woche flexibel und zielgerichtet – für maximalen Erfolg.

-

**Mitreißende Produkt-Demos:** Du bringst unsere Software zum Leben und zeigst, wie sie den Alltag deiner Kund:innen einfacher und erfolgreicher macht.

-

**Kund:innen gewinnen:** Du überzeugst potenzielle Kund:innen mit Know-how – ob bei der Kaltakquise am Telefon, vor Ort oder spontan beim Walk-In.

-

**Strategien schmieden, Erfolge feiern**﻿**:** Im Team entwickelst du Ansätze, die unseren gemeinsamen Erfolg vorantreiben.

**Das bringst du mit**

-

**Vertriebsleidenschaft:** Begeisterung für den Vertrieb und Freude am Kontakt mit Menschen – nachweisliche Berufserfahrung im Vertrieb, insbesondere in der Akquise und im Abschluss.

-

**Autonom und strategisch arbeiten:** Du planst deine Aktivitäten selbstständig, setzt klare Ziele und findest smarte Wege, Salonkee erfolgreich vor Ort zu etablieren.

-

**Technisches Know-how:** Ein gutes Verständnis für technische Zusammenhänge und fundierte Erfahrungen mit CRM-Systemen.

-

**Mobil und flexibel:** Mit Führerschein und Bereitschaft für Außeneinsätze bist du jederzeit einsatzbereit.

-

**Kommunikationsstark:** Nahezu muttersprachliches Deutsch und gutes Englisch für den Austausch mit Kunde:innen und Kolleg:innen.

**Das erwartet dich bei uns**

-

**Attraktive Vergütung:** Fixum plus ungedeckelter Bonus – dein Erfolg zahlt sich aus!

-

**Firmenwagen: **Immer mobil, ob Kundentermin oder Wochenende.

-

**Flexibilität:** Vertrauensarbeitszeit und volle Freiheit, deine Zeit selbst zu planen.

-

**Unvergessliche Highlights:** Sommerfeste, Winterfeiern und regelmäßige Teamevents stärken den Zusammenhalt.

-

**Ohne Abzüge. Exklusiv für dich: **Als Teil des Salonkee-Teams bekommst du **jeden Monat 50 € steuerfreies Guthaben** über Probonio. Du nutzt es, wie *DU* willst.

Wir wachsen schnell und suchen dich - werde Teil unseres Teams 🏆

**Wie geht's weiter:**

Nach Eingang deiner Bewerbung werden wir uns schnellstmöglich bei Dir melden. Im weiteren Prozess lernst du unser Recruiting-Team, die Team Leads und den Regional Manager deiner Region kennen.

*Salonkee fördert Chancengleichheit und Vielfalt. Wir begrüßen Bewerbungen unabhängig von Geschlecht, Herkunft, Alter, Behinderung oder Identität.*

Wir freuen uns auf deine Bewerbung!

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
