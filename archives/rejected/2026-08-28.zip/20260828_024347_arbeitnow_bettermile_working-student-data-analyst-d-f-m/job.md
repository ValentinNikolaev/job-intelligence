# Working Student Data Analyst (d/f/m)

Posted: 2026-08-27T23:40:24Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

## **What is working at Bettermile like?**

-

🌟 We have a very supportive and appreciative working environment with a lot of autonomy, a flat hierarchy, and professional growth possibilities

-

🌍 We mean diversity and we put it in numbers: 40 languages, 40 nationalities, 40% female (vs. ø26% in tech industry), and yes, we do have Schlager-Fans among us

-

🚀 You can quickly take on responsibility without feeling left alone. Your team is always at your side

-

🎨 We mean it when we say “cutting edge” and have a high level of creative freedom in our everyday work

-

🏢 We work in a hybrid mode with weekly team days for better collaboration and nurturing interpersonal connections. When onsite - we work in a modern kid & pet-friendly Better Space in the heart of Berlin-Kreuzberg

-

✈️ Remote work from anywhere for up to 12 weeks in total in a year

-

🛌 Enjoy 27 vacation days (with a 5-day week model)

-

🍎 Regular team breakfasts, fitness & wellness classes, company runs, and other events. Fruits, snacks, drinks, and coffee with a variety of milk are a given - but yes, we have them

-

💡 Outstanding flexibility we are proud of – and of course, the best colleagues in the world!

## **You will be taking care of**

-

Maintain, improve, and build in-production dashboards and reports

-

Conducting routine data quality checks, data hygiene, and maintaining documentation across our pipelines

-

Conducting exploratory data analyses on operational and product metrics (e.g., user behavior, feature impact on KPIs) and translating findings into actionable insights

-

Handling ad-hoc data requests and supporting cross-functional teams (product, engineering, operations)

-

Contributing to the maintenance, triage, and optimization of data pipelines and our data platform

**Our stack** (you do not have to already know these tools): Snowflake, AWS Data Lake, SQL, Python, AWS QuickSight, Metabase, dbt, Jira, and Confluence.

## **You check these boxes**

-

You are currently enrolled in a relevant STEM-focused program (e.g., Computer Science, Data Science, Business Analytics, Mathematics, Information Systems)

-

You are proficient in Python and SQL (university projects are enough)

-

You have hands-on experience in data analysis and data visualization

-

You are curious, detail-oriented, and possess strong problem-solving skills

-

You communicate confidently in English and are proactive

-

You are a motivated learner who enjoys taking ownership, collaborating closely with a team, and working in a hybrid setup (2 days/week in the office)

**Important: **To be eligible for this role, you have to be enrolled in a university in Germany as a student and have at least 1 year left in your studies.

## **It is awesome if you also have**

-

Any exposure to AI concepts, prompt engineering fundamentals, or experience calling LLM APIs via Python

-

We value long-term collaboration: the more time remaining in your degree, the better!

## **Take your chance**

Be a part of shaping a fast-growing industry and make an impact from day one. You’ll have the chance to take on responsibility early, with guidance and support from experienced mentors. We foster a learning culture, collaboration on equal footing, and quick decision-making that moves things forward.

**Currently, we’re proceeding only with candidates authorized to work in Germany or who already hold a Job Seeker Visa.**

## **About us**

At Bettermile, we believe delivery shouldn’t be business as usual. We’re transforming last-mile logistics to drive efficiency and create a better delivery experience for everyone.

Our geo-based, AI-powered SaaS product handles complex address processing, dynamic routing, and navigation. It is built to manage many stops and multiple constraints.

We’re setting a new standard for the last mile and pushing the industry forward, powered by a skilled, international team of tech enthusiasts, logistics experts, and a product suite designed to keep evolving.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
