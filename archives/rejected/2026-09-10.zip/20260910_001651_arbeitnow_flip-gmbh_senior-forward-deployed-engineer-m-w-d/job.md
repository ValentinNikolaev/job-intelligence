# Senior Forward Deployed Engineer (m/w/d)

Posted: 2026-09-09T23:40:04Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

## **Empower every employee.**

Flip ist die führende KI-gestützte Employee Experience Platform für Frontline Worker. Wir revolutionieren, wie die Menschen arbeiten, die die Welt am Laufen halten- in Retail, Manufacturing und Logistics. Eine App. Ein Touch. Alles, was sie brauchen.

**Unsere Mission: *****Connect every employee to everything they need in one touch.***

## **Stellenbeschreibung**

Hunderttausende Menschen, die nicht am Schreibtisch arbeiten, öffnen Flip, um alles zu erreichen, was die digitale Welt ihres Unternehmens für sie bereithält. Unteranderem gehören Bosch, REWE und Porsche zu den Unternehmen, die damit arbeiten. Der schwierige Teil ist die letzte Meile in eine über Jahrzehnte gewachsene Enterprise-IT und genau diese letzte Meile ist diese Rolle.

Als Customer Engineer arbeitest du an der Schnittstelle zwischen unserem Produkt und der Umgebung unserer Kund:innen: ihrem Identity-Stack, ihren HR-Systemen, ihrem Security Review, ihrer KI-Roadmap. Du bringst einen Flip-Tenant von null auf Hunderttausende aktive Nutzende und entscheidest, wie die technische Seite gelöst wird. Manchmal, indem du die Integration designst und die IT auf Kundenseite in die Lage versetzt, sie selbst zu bauen, manchmal, indem du die erste Version selbst baust und sie anschließend übergibst. Dazu gehört der Teil, an dem unsere KI beim Kunden live geht: Agents in der App, Tool-Zugriff über MCP und die Authentifizierungsfragen darunter, die bisher niemand gelöst hat.

### **Das erwartet dich bei uns**

-

**Technische Verantwortung von Anfang bis Ende:** Du verantwortest die technische Seite unserer Enterprise-Onboardings, vom ersten Architekturgespräch bis zum stabilen Rollout in der Breite.

-

**Integrationen, die Flip tragfähig machen:** Du designst und lieferst Identity und Authentifizierung (OIDC, Entra ID, Frontline Identity), SCIM-Provisioning, REST-APIs und Anbindungen an HR- und operative Systeme wie SAP SuccessFactors, Workday oder UKG.

-

**Beraten und befähigen statt selbst abarbeiten:** Du führst die IT auf Kundenseite, ihre Partner und unsere externen Entwicklungspartner zu einer Lösung, die du selbst unterschreiben würdest, und sorgst dafür, dass sie ohne dich betrieben werden kann.

-

**Bauen, wo es den Rollout löst:** Wo Bauen der schnellste Weg ist, einen Ansatz zu belegen oder ein Rollout wieder in Bewegung zu bringen, baust du die erste Version und übergibst sie danach sauber, mit Dokumentation und Übergabegespräch, damit sie Bestand hat.

-

**KI dort, wo sie auf den Kunden trifft:** Du gestaltest, wie Agents, Tool-Zugriff über MCP und Agent-to-Agent-Szenarien in echten Enterprise-Umgebungen ankommen, inklusive der Auth- und Datengrenzen, die dabei halten müssen.

-

**Technische Autorität im Account:** Du stimmst Anforderungen mit Projektleitung, IT, Security, Fachbereichen und Betriebsräten ab, entscheidest die technischen Fragen und gibst die Lücken, die du dabei siehst, an unser Produkt- und Engineering-Team zurück. Rechne mit regelmäßigen Reisen zu Kund:innen, etwa 10 bis 30 Prozent deiner Zeit.

### **Das bringst du mit**

**Must-haves**

-

Rund 3 bis 5 Jahre (oder mehr) in der IT- oder Tech-Beratung, im Customer Engineering, Forward Deployed Engineering, Solutions Engineering oder in der SaaS-Implementierung, mit echter Enterprise-Erfahrung.

-

Praktische Erfahrung mit Enterprise-Integration und Identity: SSO und Authentifizierung (OIDC, OAuth, Entra ID oder vergleichbar), REST-APIs und API-basierte Integrationen, die du in echten Enterprise-IT-Landschaften geliefert hast.

-

Technische Verantwortung am Kunden in Enterprise-Projekten, in denen du die technischen Entscheidungen gemeinsam mit IT, Security und Fachbereichen getroffen und nicht nur koordiniert hast.

-

Echte technische Tiefe, ohne in Vollzeit Produktcode zu schreiben: Du liest Code, prüfst ein Design, debuggst eine Integration und baust einen funktionierenden Prototypen.

-

Deutsch auf C1-Niveau oder höher und fließendes Englisch.

**Nice-to-haves**

-

Erfahrung mit SCIM-Provisioning und Anbindungen an HR- oder Workforce-Systeme wie SAP SuccessFactors, Workday oder UKG.

-

Ein fundierter, aktueller Blick darauf, wohin sich agentische KI entwickelt: MCP, A2A, EMA und die Authentifizierungsfragen darunter. Wir suchen jemanden, der das Feld eng verfolgt und eine eigene Meinung dazu hat, keine Jahre an Erfahrung, die es noch nicht geben kann.

-

Vorerfahrung als Customer Engineer oder Forward Deployed Engineer in einem Produktunternehmen statt ausschließlich in der klassischen Beratung.

-

Tools zur Workflow-Automatisierung (n8n oder ähnlich), Routine mit Logs, Metriken und Dashboards oder Erfahrung mit Mitbestimmung und Datenschutz im Enterprise-Umfeld.

### Das bieten wir dir

-

**Work-Mode:** Wir sind remote-first und geben dir damit die Flexibilität, von zu Hause aus zu arbeiten. Gleichzeitig schätzen wir den Mehrwert der persönlichen Zusammenarbeit sehr. Je nach Rolle nimmst du gelegentlich an Team-Events, Workshops oder Meetings in unseren Büros in Berlin oder Stuttgart teil – selbstverständlich immer mit ausreichend Vorlauf. Das genaue Verhältnis besprechen wir transparent während deines Bewerbungsprozesses.

-

**Work-Life-Balance:** Wir wollen nicht, dass du an deinem Schreibtischstuhl festwächst und übernehmen deshalb die Kosten für deine E-Gym-Wellpass-Mitgliedschaft und bieten Job-Rad Leasing an.

-

**Erfolge feiern**: Dich erwarten hoch motivierte und engagierte Menschen in einer lockeren Arbeitsatmosphäre.

-

**Mittendrin statt nur dabei:** Du gestaltest Flip aktiv mit. Ganz nebenbei bist du Enabler des rasanten Wachstumsprozesses eines jungen Tech-Unternehmens und wächst an deinen Zielen. Gute Laune garantiert.

-

**Happy to be a Flipster: **Freu dich auf regelmäßige Teamevents und Culture Days, die uns als Flipster zusammenschweißen.

-

**Arbeiten im Ausland:** Bei Flip kannst du auch im europäischen Ausland arbeiten, lass uns im Interview über Workation sprechen.

Damit unsere Stellenanzeigen leichter lesbar sind, verwenden wird im Textverlauf die männliche Form der Anrede. Bei Flip sind alle willkommen ganz egal, welches Geschlecht du hast oder wie alt du bist. Sexuelle Identität, Herkunft, Religion, Weltanschauung und Behinderungen spielen keine Rolle. Das Wichtigste ist, dass DU zu uns passt!

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
