# Java Full Stack Developer (m/f/d)

Posted: 2026-09-09T20:20:04Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Do you enjoy developing scalable applications, while consistently adopting an AI-first approach? As a Java Full Stack Developer, AI-powered tools are a key part of your daily work, while you design, build and optimize modern software solutions. From implementing new features and conducting code reviews to testing and troubleshooting, you play a key role in delivering high-quality applications that are both reliable and user-friendly.

**Requirements**

🚀 **Your Impact:**

- Collaborate in the design and creation of scalable software, including both client-side and server-side architecture.
- Write clean, functional, and maintainable code for front-end and back-end systems, while consistently using AI tools to optimize efficiency, code quality, and development processes.
- Test software to ensure responsiveness, efficiency, and accuracy.
- Identify, debug, and resolve coding issues to maintain optimal system performance.
- Oversee automated testing and provide feedback to management during the development process.

**Some of your daily tasks will be:**

- Contribute to software design and development, bringing fresh ideas to the table.

- Test and debug software to keep systems optimized and robust.
- Conduct thorough code reviews to ensure quality and consistency.
- Develop and implement new features that enhance user experience and functionality.

💫 **Your Expertise:**

- **Technical Skills:** Proficiency in programming languages like Java, J2EE, JavaScript, and HTML5.
- **AI Mindset: **You have hands-on experience with AI-powered development tools and use them daily as an integral part of your work, with a clear focus on actively integrating AI into your workflow.
- **Framework Experience:** Familiarity with Spring Boot, Vue.js, and REST APIs.
- **Database Knowledge:** Hands-on experience with MySQL, MariaDB, or Oracle databases.
- **Problem-Solving:** A sharp mind for identifying challenges and delivering solutions.

Do our values **One Team**, **Innovation & Transformation**, **Ownership**, **Entrepreneurship **and **Empowerment **reflect your mindset as well? If so, you’ve come to the right place!

**Benefits**

- **Hybrid Work:** At epay, you’ll have the opportunity to work for a global company—with two days a week working from home.
- **Culture:** Our culture thrives where people communicate openly, support one another, and take responsibility together. From communication and feedback to leadership and dealing with mistakes—that’s what our daily interactions are all about.
- **Personal Development: **Through regular performance reviews and personalized professional development initiatives, we support your personal and professional growth. Our Europe-wide epay Academy offers a wide range of training opportunities—there’s something for everyone.
- **Benefits from Day One: **You’ll have access to our corporate benefits platform. We also subsidize your DeutschlandTicket and your EGYM WellPass membership.
- **Benefits After the Probationary Period:** In addition to numerous employee discounts, you’ll gain access to the Employee Benefit Club, which offers you a monthly shopping voucher worth €50. You can also lease a bicycle through the company with EuroRad. You can find an overview of the benefits on our careers page [here](https://epay.de/karriere/).

###

### epay

As an independent full-service payment provider, we offer our global partners a platform with a single interface that enables them to remain fully flexible at all times amid the ever-changing payment journey.

Our sales network is one of the fastest-growing networks, with hundreds of innovative partners in numerous countries. This allows us to connect retailers, brands, and customers with scalable gift card, prepaid, payment, issuing, acquiring, and incentive solutions across all channels and borders.

We are the Digital Payment Unit of Euronet Worldwide, Inc. (NASDAQ: EEFT). **Let**’**s drive the payment journey of the future together!**

### We deliver highly advanced, secure and sustainable payment & incentive products and solutions that drive contribution to our partners and exceptional value to their customers.

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
