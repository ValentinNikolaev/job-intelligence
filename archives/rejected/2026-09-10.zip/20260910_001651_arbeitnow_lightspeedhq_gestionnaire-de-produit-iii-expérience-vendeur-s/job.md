# Gestionnaire de produit III, Expérience vendeur·se

Posted: 2026-09-09T23:40:06Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**Bonjour! Merci de ta visite **👋

Es-tu activement à la recherche d’une nouvelle opportunité? Ou tu ne fais que jeter un coup d’œil au marché? Eh bien… tu te trouves au bon endroit!

Nous avons pour mission d'appuyer les entreprises qui forment la colonne vertébrale de l'économie mondiale. Tu joueras un rôle clé au sein de notre groupe NuORDER par Lightspeed pour aider Lightspeed à concevoir d'excellents produits et à prendre des décisions éclairées reposant sur les données.

À la recherche d'un milieu de travail dynamique et fortement axé sur la collaboration, qui touche une vaste clientèle mondiale? Parlons-nous! La personne occupant le poste de gestionnaire de produit III, Expérience vendeur·se est responsable de la vision permettant d'aider des marques de calibre mondial à mettre en valeur leurs marchandises et à les connecter aux acheteur·euses du commerce de détail sur NuORDER par Lightspeed. La candidature idéale possède un solide bagage en gestion de produit, en stratégie de produit, en UX et en analyse de données, ainsi qu'une passion pour la création d'expériences utilisateur d'exception dans le secteur du commerce de détail. Tu as l'esprit d'entreprise, un don pour la résolution de problèmes et l'envie d'avoir un impact majeur sur l'avenir de l'entreprise? L'équipe aimerait beaucoup te lire!

**Tes responsabilités :**

-

**Prendre en charge la stratégie de vente B2B :** Piloter la stratégie globale du produit afin d'élaborer une proposition de valeur attrayante répondant aux besoins et aux tâches fondamentales de nos marques (le côté offre sur la plateforme NuORDER).

-

**Bâtir une expérience de vente de calibre mondial :** Collaborer avec diverses marques à travers le monde, des griffe émergentes aux géants mondiaux, pour comprendre leurs besoins et créer une expérience de vente en gros inégalée.

-

**Gérer le parcours de vente de bout en bout :** Superviser le cycle de vie complet des transactions B2B, en prenant en charge le parcours à partir du moment où un article est acheté jusqu'à son paiement complet.

-

**Stimuler des fonctionnalités transactionnelles clés :** Assurer la responsabilité produit directe des points de contact fonctionnels majeurs, incluant les profils de marque, la gestion des acheteur·euses, les analyses, l'expérience de passage à la caisse, la facturation, les paiements B2B et le suivi des commandes, garantissant ainsi un traitement et une livraison fluides pour la clientèle acheteuse.

-

**Exécuter avec impact :** Travailler en étroite collaboration avec les équipes d'ingénierie, de design et de mise en marché pour traduire la vision stratégique en feuilles de route et en documents d'exigences produit (PRD), menant au lancement de fonctionnalités qui font évoluer les métriques d'utilisation, de tunnel de conversion et d'affaires.

**Ce que tu apportes à l'équipe :**

-

**Grande maîtrise de la gestion de produit :** Au moins 5 ans d'expérience éprouvée en gestion de produit démontrant une maîtrise exceptionnelle de la profession.

-

**La mentalité de « gestionnaire-propriétaire » :** Une forte orientation vers l'impact commercial et la viabilité de l'entreprise, en traitant le produit comme ta propre entreprise et en générant des résultats de revenus mesurables.

-

**Pensée stratégique et innovante :** Une vision axée sur la résolution de problèmes qui ne se contente pas d'exécuter, mais qui apporte constamment des idées et des stratégies fraîches et innovantes.

-

**Leadership et communication d'exception :** De grandes compétences en scénarisation (storytelling), avec la capacité d'influencer, d'aligner et de guider efficacement des équipes transversales ainsi que des parties prenantes externes.

-

**Culture des données et souci de l'utilisateur·rice :** Une approche fortement ancrée dans les métriques et les besoins des utilisateur·rices pour guider les décisions produit, avec une grande capacité à traduire les informations en actions.

-

**Compétences en UX et en expérimentation :** Une solide compréhension des meilleures pratiques UX combinée à une connaissance pratique et rigoureuse des méthodologies de tests A/B pour optimiser le parcours utilisateur.

-

**Parcours en grande entreprise technologique et création de zéro :** Expérience éprouvée au sein de grands environnements technologiques (Big Tech), avec un historique démontré de création et d'expansion de produits complexes à partir de zéro (0 à 1).

Nous savons qu’une personne ne se résume pas à son CV. Si tu ne sais pas si ton profil convient au poste, clique sur le bouton « Postulez maintenant » pour le découvrir!

**Ose le changement :**

Tu pourras profiter:

-

d’un environnement de travail flexible qui te permettra de donner le meilleur de toi-même (3 jours semaine au bureau)

-

d’une culture qui célèbre la performance

-

de la possibilité d’avoir un impact au sein d’une équipe assez grande pour évoluer professionnellement, mais assez agile pour que ta voix soit entendue

-

d’opportunités qui façonneront ta carrière

Sans oublier des avantages conçus pour favoriser ton bonheur, ta santé et ton épanouissement:

-

Des congés payés flexibles et des politiques de télétravail

-

Des options d’achat d’actions, parce que c’est aussi ton entreprise

-

Des cotisations à ton régime de retraite, parce que ton avenir nous tient à cœur

-

Des possibilités de formation pour développer tes compétences et ta carrière

-

Une allocation santé et bien-être pour te sentir au sommet de ta forme

-

Des congés pour faire du bénévolat et t’impliquer dans ta communauté

-

Des groupes d’intérêt, allant des groupes menés par des employés aux équipes sportives commanditées

-

Un programme d’achat d’ordinateur pour acquérir ton MacBook personnel

-

Un congé parental amélioré pour soutenir les familles qui s’agrandissent

Propulse ta croissance. Trouve ton équipe.

Chez Lightspeed, ta croissance est notre priorité. On investit en toi grâce à des possibilités d’apprentissage en continu, une mobilité internationale et des avantages conçus pour te soutenir, le tout au sein d’une équipe motivée, diversifiée et inclusive qui se passionne pour la réussite de nos communautés.

Lightspeed est fier d'être un employeur respectueux de l'égalité des chances et s'engage à créer un lieu de travail inclusif et sans barrières.

Lightspeed accueille et encourage les candidatures de personnes handicapées. Des aménagements sont disponibles sur demande pour les candidats qui participent à tous les aspects du processus de sélection.

**À propos de nous**

Propulsant les commerces qui sont le moteur de l’économie mondiale, la plateforme de commerce tout-en-un de Lightspeed aide les commerçants à innover afin de simplifier, adapter et offrir des expériences client exceptionnelles. Notre solution infonuagique transforme et unifie les opérations en ligne et hors ligne, les ventes omnicanaux, l’expansion avec de nouveaux emplacements, les paiements internationaux, les solutions financières et la connexion aux réseaux de fournisseurs.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
