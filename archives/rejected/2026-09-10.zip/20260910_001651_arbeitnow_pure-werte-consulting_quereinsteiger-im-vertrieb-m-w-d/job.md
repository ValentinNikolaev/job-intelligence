# Quereinsteiger im Vertrieb (m/w/d)

Posted: 2026-09-09T22:00:32Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Quereinsteiger im Vertrieb (m/w/d) Hybrid - Finanzdienstleistung

## Aufgaben

- Aktive Neukundenakquise im Bereich Finanzdienstleistungen

- Pflege und Ausbau bestehender Kundenbeziehungen

- Beratung von Kund:innen zu passenden Finanzprodukten und -lösungen

- Präsentation und Vermittlung unserer Angebote sowohl online als auch persönlich

- Erstellung und Nachverfolgung von Angeboten sowie Vertragsabschlüssen

- Selbstständige Organisation des eigenen Vertriebsprozesses und -controllings

- Teilnahme an Schulungen und Weiterbildungsmaßnahmen zur Vertiefung des Fachwissens

## Qualifikation

- Erfahrung im Vertrieb, idealerweise im Finanzdienstleistungsbereich oder vergleichbar

- Ausgeprägte Sales-Kompetenz und Überzeugungsfähigkeit

- Sicherer Umgang mit Microsoft Office Anwendungen sowie grundlegende Computerkenntnisse

- Sehr gute Deutschkenntnisse in Wort und Schrift; Englischkenntnisse sind von Vorteil

- Kommunikationsstärke sowie überzeugendes Auftreten und Verhandlungsgeschick

- Selbstständige Arbeitsweise, Eigenmotivation und Zielorientierung

## Benefits

- Betriebliche Altersvorsorge

- Betriebliche Weiterbildung

- Firmenevents

- Firmenwagen

- Flexible Arbeitszeiten

- Kostenloser Parkplatz

Dann bewirb Dich bis mit Deinen vollständigen Bewerbungsunterlagen bei **Pure Werte Consulting**

Wir freuen uns darauf, Dich persönlich kennenzulernen und gemeinsam herauszufinden, ob Du zu unserem Team und unseren Entwicklungsmöglichkeiten passt.

**Pure Werte Consulting**

Wir freuen uns auf Deine Online-Bewerbung.

Dein Ansprechpartner

**Yasin Moussa**

**+491725314025**

Pure Werte Consulting

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
