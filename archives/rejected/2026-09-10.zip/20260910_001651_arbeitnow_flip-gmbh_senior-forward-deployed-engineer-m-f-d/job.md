# Senior Forward Deployed Engineer (m/f/d)

Posted: 2026-09-09T23:40:04Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

## **Empower every employee.**

At Flip, we have a clear goal: to revolutionize the world for frontline workers and give them a voice. Become a Flip Game Changer and work with an unbeatable team to ensure that all employees, no matter where they work, have access to their company's internal information. If you're ready to make an impact and shape the work lives of millions of people, then you've come to the right place!

**Our Mission: *****Connect every employee to everything they need in one touch.***

## **Job Description**

Flip is the frontline employee experience platform. Hundreds of thousands of people who do not work at a desk open Flip to reach everything their employer's digital world holds for them and Bosch, REWE and Porsche are a a few of the companies that run it. The hard part is the last mile into a decades-old enterprise IT landscape, and that last mile is this role.

As a Customer Engineer you sit on the edge of the product, inside the customer's environment: their identity stack, their HR systems, their security review, their AI roadmap. You take a Flip tenant from nothing to hundreds of thousands of live users and you decide how the technical side gets solved, sometimes by designing the integration and enabling the customer's IT to build it, sometimes by building the first version yourself and handing it over. That includes where our AI goes live: agents in the frontline app, tool access over MCP, and the authentication questions underneath them that nobody has solved yet.

### **What you can expect**

-

**Technical ownership end to end:** You own the technical side of enterprise onboardings, from the first architecture conversation to a stable live rollout at scale.

-

**Integrations that make Flip load-bearing:** You design and land identity and authentication (OIDC, Entra ID, Frontline Identity), user provisioning (SCIM), REST APIs and connections into HR and ops systems such as SAP SuccessFactors, Workday or UKG.

-

**Advise and enable instead of absorb:** You bring the customer's IT, their partners and our external development partners to a solution you would sign off on, and you make sure they can run it without you.

-

**Build where building unblocks:** Where building is the fastest way to prove an approach or to unblock a rollout, you build the first version and then hand it over cleanly, with the documentation and the handover conversation that make it stick.

-

**AI where it meets the customer:** You lead how agents, MCP-based tool access and agent-to-agent scenarios land at enterprise customers, including the auth and data boundaries that have to hold around them.

-

**Technical authority in the account:** You work with customer project management, IT, security, functional departments and works councils, you decide the technical questions, and you feed the gaps you see back into our product and engineering teams. Expect regular travel to customer sites, roughly 10 to 30 percent of your time.

### **What you bring to the table**

**Must-haves**

-

Around 3 to 5 (or more) years in IT or tech consulting, customer engineering, forward deployed engineering, solutions engineering or SaaS implementation, with real enterprise exposure.

-

Hands-on experience with enterprise integration and identity: SSO and authentication (OIDC, OAuth, Entra ID or comparable), REST APIs and API-based integrations delivered inside real enterprise IT environments.

-

Customer-facing technical responsibility in enterprise projects, where you made the technical calls together with IT, security and functional departments rather than only coordinating them.

-

Genuine technical depth without being a full-time production developer: you read code, review a design, debug an integration and build a working prototype.

-

German at C1 level or above and fluent English.

**Nice-to-haves**

-

Provisioning experience (SCIM) and integrations into HR or workforce systems such as SAP SuccessFactors, Workday or UKG.

-

An informed, current view on where agentic AI is heading: MCP, A2A, EMA and the authentication questions underneath them. We are looking for someone who follows the field closely and has an opinion, not for years of experience that cannot exist yet.

-

Prior work as a Customer Engineer or Forward Deployed Engineer at a product company, rather than in classic consulting only.

-

Workflow automation tooling (n8n or similar), comfort with logs, metrics and dashboards, or experience with German co-determination and enterprise data protection.

### What we offer you

-

**Work mode:** We’re remote-first, giving you flexibility to work from home. At the same time, we deeply value the power of in-person collaboration. Depending on the role, you’ll join occasional team events, workshops, or meetings in our Berlin or Stuttgart offices - always with plenty of notice. The exact balance will be discussed during your interview.

-

**Work-Life-Balance:** We don't want you to grow roots to your desk chair. That's why we cover the costs of your E-Gym-Wellpass membership and offer job bike leasing.

-

**Celebrating success:** Expect highly motivated and committed people in a relaxed working atmosphere.

-

**Be part of something bigger**: You actively shape Flip in your role. Along the way, you are an enabler of the rapid growth process of a young tech company and grow towards your goals, fun is guaranteed.

-

**Happy to be a Flipster:** Stay tuned for regular team events and culture days that bring us together as Flipsters.

-

**Working abroad:** At Flip you can also work abroad in the European Union. Let's talk about remote work in the interview.

At Flip, everyone is welcome - no matter what gender you identify as or how old you are. Sexual *identity*, origin, religion, world view and disabilities do not influence your potential job at Flip. The most important thing is that **YOU** fit in!

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
