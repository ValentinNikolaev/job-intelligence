# Werkstudent (w/m/d) Business Development

Posted: 2026-09-09T23:30:33Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Holzprofi24 ist Marktführer im eCommerce für Home & Garden im DACH-Raum. Wir skalierten unser Geschäft konsequent über eine AI-driven und tech-fokussierte Infrastruktur. Um unsere Automatisierung weiter voranzutreiben und neue Wachstumspotenziale im eCommerce zu heben, suchen wir Unterstützung im Business Development. Du arbeitest an der Schnittstelle zwischen Business, Tech und AI und wirst flexibel in Projekten über verschiedene Abteilungen hinweg eingesetzt.

-

Identifikation und Testen neuer AI-Tools und Automatisierungen zur Prozessoptimierung

-

Unterstützung bei der Konzeption und Umsetzung technischer sowie strategischer eCommerce-Projekte

-

Datenbasierte Analysen zur Performancesteigerung entlang der Wertschöpfungskette

-

Abteilungsübergreifender Einsatz in wechselnden Schwerpunktbereichen je nach Projektlage

-

Einbringen pragmatischer Lösungen im operativen Tagesgeschäft

-

Laufendes Studium der Wirtschaftswissenschaften, Wirtschaftsinformatik, Informatik oder eines verwandten Studiengangs

-

Fließende Deutschkenntnisse in Wort und Schrift

-

Ausgeprägte Tech- und AI-Affinität sowie Interesse an modernen Software-Lösungen

-

Starke betriebswirtschaftliche Denkweise und analytisches Verständnis

-

Begeisterung für den Online-Handel und datengetriebenes Arbeiten

-

Eigenverantwortliche, strukturierte und lösungsorientierte Arbeitsweise

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
