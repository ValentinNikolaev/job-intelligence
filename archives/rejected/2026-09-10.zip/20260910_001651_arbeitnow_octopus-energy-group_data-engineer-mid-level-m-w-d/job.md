# Data Engineer Mid-Level (m/w/d)

Posted: 2026-09-09T20:04:12Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**Energie neu denken. Infrastruktur neu bauen. Zukunft neu gestalten – bei der Energy Metering Germany GmbH, einem Unternehmen der Octopus Energy Group.**

Als innovativer Messstellenbetreiber treiben wir die Energiewende nicht nur voran – wir setzen sie technisch um.

Digital, skalierbar und kompromisslos praxisorientiert.

Von der Installation **intelligenter Messsysteme **inklusive Smart Meter Gateway über moderne Wallbox-Lösungen für Privathaushalte bis hin zu komplexen 1:n-Lösungen und CLS-Management nach §14a und §9 EnWG – wir bauen die vernetzte Energieinfrastruktur von morgen. Sicher, normkonform und hochautomatisiert.

Unser Anspruch: Messstellenbetrieb neu definieren – als Rückgrat eines flexiblen, datengetriebenen Energiesystems. Dafür kombinieren wir regulatorische Exzellenz mit technischer Umsetzungskompetenz und operativer Geschwindigkeit.

Wenn du nicht nur verwalten, sondern gestalten willst – dann baue mit uns das Energy Metering der nächsten Generation. 💚

Für den weiteren Ausbau und Betrieb unserer modernen Daten- und Analytics-Landschaft suchen wir einen vielseitigen **Mid-Level Data Engineer (m/w/d)**. In dieser Rolle bist du das Bindeglied zwischen robuster Data-Lakehouse-Infrastruktur, analytischem Reporting mit **Lightdash & Streamlit** und angewandten Data-Science-Use-Cases.

**Deine Aufgaben: **

Du begleitest Daten entlang ihres gesamten Lebenszyklus – von der Rohdatenaufnahme im Lakehouse über automatisierte Datenmodelle bis hin zu interaktiven Dashboards und Machine-Learning-gestützten Datenanwendungen.

-

**Lakehouse & Data Engineering (ca. 50%):**

-

Konzeption, Aufbau und Tuning performanter Pipelines auf Basis von **Databricks**.

-

Datenmodellierung mit **dbt** sowie Orchestrierung robuster DAGs via **Apache Airflow**.

-

**Governance & Performance:**

-

Etablierung automatisierter Data-Quality-Prüfungen, Data Lineage und Cluster-Optimierung.

-

**Analytics & Data Apps (ca. 25%):**

-

Aufbau einer semantischen Metriken-Schicht und Self-Service-BI in **Lightdash**.

-

Entwicklung interaktiver Analyse-Tools und Data Apps in Python (**Streamlit**).

-

**Data Science & ML (ca. 25%):**

-

Explorative Analysen, Prototyping und Training von ML-Modellen (z. B. Prognosen, Anomalien).

-

**MLOps & Business-Integration:**

-

Experiment-Tracking auf Databricks und Bereitstellung der Ergebnisse für Fachbereiche.

**Dein Profil: **

-

**Berufserfahrung:**

-

Mindestens 2–4 Jahre Praxis im Data Engineering, Analytics Engineering oder einer vergleichbaren Rolle.

-

**Core Engineering Stack:**

-

Fundierte Praxis mit **Databricks** (Delta Lake, Unity Catalog), **dbt** und **Apache Airflow**.

-

**BI & Data Apps:**

-

Erfahrung mit **Lightdash** (oder Interesse an code-basierter BI) sowie mit **Streamlit**.

-

**Code & Datenbanksprachen:**

-

Exzellentes **SQL** (Performance-Tuning, komplexe Joins) und sehr gutes **Python** (pandas, PySpark, scikit-learn).

-

**Methodik & Best Practices:**

-

Routinierter Umgang mit **Git** / CI/CD und modernen Modellierungskonzepten (Star-Schema).

-

**Mindset & Sprachen:**

-

Pragmatische Hands-on-Mentalität, starke Kommunikationsfähigkeit und sehr gutes Deutsch & Englisch.

Deine Benefits bei uns:

✅ Vergünstigungen & Vorsorge:

- Aktienoptionen der Octopus Energy Group Ltd.

- Monatlicher Zuschuss zum Nahverkehrsticket

- Monatlicher Zuschuss zum Mittagessen

- Vergünstigtes Fahrradleasing

- Betriebliche Altersvorsorge
- Nachhaltig unterwegs mit unserem E-Auto-Leasing

✅ Familie

- Beratungsangebote und Unterstützung bei Kinderbetreuung über HeyNanny

- Monatlicher Zuschuss zur Kinderbetreuung

- Elterngeld-Bonus: Wir stocken dein Elterngeld für 3 Monate auf, damit du deine Elternzeit entspannter genießen kannst

✅ Sport & Gesundheit

- Zuzahlungen zu Fitness- Angeboten über Wellpass

- Förderung deines mentalen Wohlbefindens mit unserem Partner Open Up

✅ Lernen & Weiterbildung

- Attraktive Weiterbildungsmöglichkeiten und Aufstiegsmöglichkeiten

- Kostenlose Sprachkurse über Busuu

✅ Extra Goodies

- Gutschein zu deinem Geburtstag

_________________

Bereit, den Energiemarkt mit uns zu revolutionieren? Bewirb dich ganz einfach in nur wenigen Schritten. Wir freuen uns auf dich!

Du findest die Stelle super spannend, bist dir aber unsicher, ob du alle Anforderungen zu 100% erfüllst? Bitte zögere nicht, dich trotzdem zu bewerben!

P.S.: Octopusse gibt es in allen Farben, Formen und Größen. Wir freuen uns auf Mitarbeiter*innen jeden Geschlechts, Alters, jeder sexuellen Identität, Herkunft, Religion, Weltanschauung, mit und ohne Behinderungen. Für uns zählt nur eins: du passt zu uns und brennst darauf, etwas zu verändern.

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
