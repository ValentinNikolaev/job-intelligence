# Senior Director, Legal & Compliance, OUS Regions

Posted: 2026-09-09T20:55:38Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

For more than 25 years, Corcept has been singularly focused on the science of cortisol, a powerful hormone that when unregulated, can play a role in a broad range of diseases.

Our commercial portfolio includes treatments for hypercortisolism and oncology, and the company has discovered more than 1,000 proprietary selective cortisol modulators and glucocorticoid receptor antagonists. With advanced clinical trials in patients with hypercortisolism, solid tumors, ALS and liver disease, Corcept is unlocking the power of cortisol modulation to help address some of the most devastating diseases patients face today.

Corcept is headquartered in Redwood City, California. To learn more, visit [www.corcept.com](https://nam10.safelinks.protection.outlook.com/?url=http%3A%2F%2Fwww.corcept.com%2F&data=05%7C02%7Cgcastrence%40corcept.com%7C8262d50a280e4da5b72208de91a94917%7Cf75457eed65640339f048a7aedb19388%7C0%7C0%7C639108353411832645%7CUnknown%7CTWFpbGZsb3d8eyJFbXB0eU1hcGkiOnRydWUsIlYiOiIwLjAuMDAwMCIsIlAiOiJXaW4zMiIsIkFOIjoiTWFpbCIsIldUIjoyfQ%3D%3D%7C0%7C%7C%7C&sdata=Yc8odS9%2FPf%2B7kSorJ4ftwNYbnrVi9jKto%2BkzxHyv3ZA%3D&reserved=0).

Reporting to the VP, Legal & Compliance, the Senior Director, Legal & Compliance, OUS Regions will serve as lead legal counsel for Corcept’s burgeoning operations outside the United States, with particular focus on the European Economic Area, Switzerland and the United Kingdom. This role will provide legal and compliance guidance for a broad scope of legal issues and clients in support of Corcept’s business opportunities across all existing and emerging therapeutic areas and will lead the development and coordination of OUS compliance policies and training as part of the company’s overall compliance program. The successful candidate will partner with business teams in achieving critical objectives while mitigating the potential impact of compliance risks. This role guarantees exposure to all aspects of Corcept’s OUS business.

**Responsibilities:**

- **Legal advice regarding product Sales, Promotion and Scientific Communication **– Provide practical and timely advice, training and solutions regarding compliance with laws related to all aspects of Corcept’s business operations primarily in the EEA, Switzerland and the United Kingdom, including those related to interactions with healthcare professionals, patients and health authorities; market access, reimbursement and government pricing regulation; product distribution, sales and promotion; and data privacy. Advise regulatory, medical affairs, and other teams on EMA and country-specific regulatory submissions and scientific communications

- **Affiliate Corporate Governance **– Oversee maintenance of corporate governance records and registrations for all OUS affiliates

- **Compliance, Policy Development and Training** – Design, implement and oversee the OUS compliance program, including development and implementation of policies, resources, and training to drive comprehensive, functional knowledge among OUS business teams regarding conduct in accordance with the law and ethical standards

- **Contract Drafting and Negotiations** – Support negotiation of contractual arrangements encompassing a wide array of third parties, including healthcare providers and vendors of services, products and data, to ensure appropriate protection of Corcept’s business opportunities, assets, confidential information and intellectual property

- colleagues to coordinate legal and compliance guidance for teams operating in OUS jurisdictions

- **External counsel engagement **- Develop a trusted network of external legal advisors and established frameworks for engagement, coordination, budgeting and oversight

**Necessary Skills, Qualifications or Technical Proficiencies: **

- Professional legal qualification in a European jurisdiction

- Comprehensive knowledge of and compliance experience with laws in the EEA, the UK and Switzerland regarding development and commercialization of pharmaceuticals

- Complex contract drafting and negotiations skills

- Excellent written and verbal communication skills

- Ability to operate as a strategic partner and provide timely and practical legal advice

- High emotional intelligence, capable of collaboratively influencing decision-making through the respectful exchange of competing ideas and perspectives

- Self-driven to identify and solve complex and challenging problems

**Required Education and Experience: **

- 12+ years of legal practice in the EEA countries regarding healthcare regulatory and pharmaceutical industry law, including experience related to general healthcare/corporate compliance, business transactions and governance matters

- Law firm and in-house counsel experience

- Law degree or equivalent from a respected university

*This role can be based in Germany or Switzerland*

For information on how Corcept collects, uses, discloses, protects, and otherwise processes personal information and an explanation of the rights and choices available to you with respect to your personal information, please refer to our [Privacy Notice link](https://corcept.com/privacy-notice/).

Corcept appreciates the commitment and hard work of all our team members as we strive to discover and develop novel treatments for patients with serious unmet medical needs.

** ****Please visit our website at: [https://www.corcept.com/](https://www.corcept.com/)**

**Corcept is an Equal Opportunity Employer**

*Corcept will not conduct interviews via text message or messaging platforms and will not ask you to download anything as part of your interview. Though we use third-party tools to help with advertising our jobs, please be vigilant in checking that the communication is in fact coming from Corcept.*

*** ***

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
