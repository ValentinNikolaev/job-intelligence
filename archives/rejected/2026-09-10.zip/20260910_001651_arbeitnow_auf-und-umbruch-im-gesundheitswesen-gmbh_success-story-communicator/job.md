# Success Story Communicator

Posted: 2026-09-09T20:30:50Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Bei **Auf- und Umbruch im Gesundheitswesen** passiert viel: Wir begleiten Einrichtungen des Gesundheitswesens, entwickeln Bildungsangebote, setzen innovative Projekte um und arbeiten gemeinsam mit unseren Kundinnen und Kunden daran, die professionelle Pflege weiterzuentwickeln.

Dabei entstehen immer wieder spannende Projekte, erfolgreiche Veränderungen und Geschichten, die etwas bewegen. Viele davon sind bislang nur den direkt Beteiligten bekannt. Das möchten wir ändern.

Als **Success Story Communicator** machst Du sichtbar, was bei Auf- und Umbruch im Gesundheitswesen passiert und welche Wirkung unsere Arbeit hat. Du findest interessante Geschichten, sprichst mit den Menschen dahinter und entwickelst daraus Inhalte für LinkedIn, unsere Website und unseren Newsletter. Dabei nutzt Du moderne KI-Tools aktiv für die Aufbereitung von Text-, Bild-, Audio- und Videoinhalten.

## Aufgaben

• Du spürst Erfolgsgeschichten, spannende Projekte und relevante Themen bei Auf- und Umbruch im Gesundheitswesen auf.

• Du gehst eigenständig auf Kolleginnen und Kollegen sowie Projektbeteiligte zu, führst kurze Interviews und sammelst die Informationen, die eine gute Geschichte braucht.

• Du entwickelst daraus Beiträge für LinkedIn, Erfolgsgeschichten und Projektberichte für unsere Website sowie Inhalte für unseren Newsletter.

• Du verwertest bestehende Inhalte aus Podcasts, Veranstaltungen und Projekten kanalübergreifend weiter.

• Du nutzt KI-gestützte Tools aktiv, um Bild-, Audio- und Videomaterial aufzubereiten, weiterzuentwickeln und in passende Formate zu übersetzen – zum Beispiel in kurze Clips, Teaser, Grafiken oder Social-Media-Inhalte.

• Du planst Themen gemeinsam mit uns vorausschauend und pflegst einen einfachen Redaktionsplan.

• Du darfst ausdrücklich selbst aktiv werden: Wenn Du eine gute Geschichte entdeckst, musst Du nicht auf einen fertigen Auftrag warten.

## Qualifikation

Uns ist weniger wichtig, was genau Du studierst. Entscheidend ist, dass Du Lust auf Kommunikation, Storytelling und eigenständiges Arbeiten hast.

• Du schreibst gerne und hast ein gutes Gefühl für Sprache.

• Du bist neugierig, offen und kommst gerne mit Menschen ins Gespräch.

• Du arbeitest zuverlässig, strukturiert und selbstständig.

• Du entwickelst gerne eigene Ideen und wartest nicht darauf, dass jede Aufgabe fertig vorbereitet bei Dir landet.

• Du interessierst Dich für Kommunikation, Content, Social Media und Storytelling.

• Interesse an Themen rund um Gesundheitswesen, Pflege, Bildung oder Organisationsentwicklung ist ein Plus.

• Erste Erfahrungen mit LinkedIn, CMS-Systemen, Newslettern, Content-Erstellung oder KI-Tools sind willkommen, aber keine Voraussetzung.

• Ein Studium z. B. in Kommunikations-, Medien-, Wirtschafts-, Gesundheits- oder Pflegewissenschaften kann gut passen, ist aber nicht zwingend erforderlich.

## Benefits

• **603 € Vergütung pro Monat auf Minijob-Basis**

• alternativ die Möglichkeit eines Praktikums

• flexible Arbeitszeiten, die sich gut mit Deinem Studium verbinden lassen

• Homeoffice und in der Regel **ein gemeinsamer Arbeitstag pro Woche in Köln**

• viel Gestaltungsspielraum und die Möglichkeit, eigene Ideen direkt umzusetzen

• kurze Entscheidungswege und direkter Austausch im Team

• offene und informelle Unternehmenskultur

• Einblicke in vielfältige Projekte aus Pflege, Bildung, Beratung und Gesundheitswesen

• praktische Arbeit mit modernen KI-gestützten Kommunikations- und Contenttools

• bei fachlicher Passung die Möglichkeit, eine Abschlussarbeit gemeinsam mit uns zu entwickeln

• Möglichkeit auf ein geleastes Dienstfahrrad über JobRad

Wir suchen keine Person, die einfach nur unseren Social-Media-Kanal „bespielt“.

Wir suchen jemanden, der neugierig fragt:

**Was ist hier eigentlich passiert? Was hat sich verändert? Warum ist dieses Projekt besonders? Und warum sollten andere davon erfahren?**

Aus diesen Antworten entstehen Geschichten, die zeigen, wer wir sind und was unsere Arbeit bewirken kann.

Klingt nach Dir? Dann freuen wir uns auf Deine Bewerbung mit Lebenslauf und relevanten Unterlagen. Auf ein Bewerbungsfoto kannst Du gerne verzichten.

**Start: 01.10.2026 oder nächstmöglich**

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
