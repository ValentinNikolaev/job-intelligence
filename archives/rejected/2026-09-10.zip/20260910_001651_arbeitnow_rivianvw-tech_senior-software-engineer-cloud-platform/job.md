# Senior Software Engineer, Cloud Platform

Posted: 2026-09-09T17:40:06Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

# About Us

Rivian and Volkswagen Group Technologies is a joint venture between two industry leaders with a clear vision for automotive’s next chapter. From operating systems to zonal controllers to cloud and connectivity solutions, we’re addressing the challenges of electric vehicles through technology that will set the standards for software-defined vehicles around the world.

The road to the future is uncharted. By combining our expertise across connectivity, AI, security and more, we’ll map a new way forward. Working together, we’ll create a future that’s more connected, more intelligent, more sustainable for everyone.

# **Role Summary**

The **Parallax Cloud** team builds the communication fabric that lets vehicles, mobile apps, and cloud services exchange live state and commands securely and reliably.

As a Senior Software Engineer, you will build and operate services and APIs that hide messaging, routing, and authorization complexity from product teams. This is hands-on platform work: you will solve distributed-systems problems, trace failures across the stack, and carry changes from design through production.

# **Responsibilities**

-

Design, build, and operate cloud services and **gRPC**/Protobuf APIs that let product teams read vehicle state, subscribe to changes, and send commands.

-

Operate and tune NATS, our high-performance messaging system, including configuration, upgrades, troubleshooting, performance validation, and capacity planning.

-

Own services end to end, from implementation through deployment and production operation, using **Kubernetes**, GitOps/Argo CD, and infrastructure as code.

-

Diagnose production behavior using metrics, traces, logs, dashboards, and alerts.

-

Design, operate, and tune service networking, load balancers, and L4/L7 traffic routing.

-

Develop and run end-to-end, integration, and load tests to catch functional and performance regressions before production.

# **Qualifications**

Minimum Qualifications:

-

At least 5 years of software engineering experience focused on distributed systems, high-scale backend services, or streaming and messaging platforms.

-

Strong proficiency in at least one general-purpose programming language and willingness to work primarily in **Go**, with occasional work in Java and TypeScript client SDKs.

-

Practical experience building and operating production services, including observability and troubleshooting.

-

Solid foundations in API design, networking, concurrency, and distributed systems with working knowledge of Kubernetes.

Preferred Qualifications

-

Hands-on experience with high-throughput messaging systems such as NATS, Kafka, or MQTT.

-

Experience with Kubernetes and owning service deployments; familiarity with GitOps/Argo CD and infrastructure as code.

-

Strong knowledge of HTTP/2, TCP, L4/L7 load balancing along with experience operating gRPC services in production is a major plus.

-

Familiarity with mTLS, certificates, service identity, secure transport and authentication patterns.

-

Track record of maintaining or making contributions to established open-source projects.

# **Why this role**

Parallax Cloud engineers collaborate closely with both product and cloud platform teams, creating a unique opportunity to shape how connected features are designed and how the underlying platform evolves. The role offers broad visibility across the system and meaningful influence on decisions on both sides. You will have the autonomy to investigate problems and carry improvements from design through rollout.

## **Total Rewards**

We build the exceptional — and we believe the people doing that work should be rewarded accordingly. In addition to a competitive base salary, full-time positions may be is eligible to participate in our annual company performance bonus program.

Payments are discretionary and not guaranteed; actual amounts depend on company results and the terms of the plan in effect, and require active employment at the time of payout. This role is also eligible for equity in the form of Restricted Stock Units (RSUs), subject to board approval and the terms of our equity incentive plans, including applicable vesting requirements.

In addition to our compensation programs, we invest in our people with a comprehensive benefits package designed to support the health, wellbeing, and financial future for full-time employees — including health coverage, retirement savings, time off, and family planning programs. Offerings vary by country. [**Learn more about our global benefit programs**](https://rvtech.mybenefits.life/)**.**

External candidates can apply for this role through the Rivian and Volkswagen Group Technologies careers site ([**https://rivianvw.tech/#careers**](https://rivianvw.tech/#careers)). If you are a current employee, please apply through our [**internal job board**](https://app.ashbyhq.com/internal/job-board/b10a9912-eb45-4a84-9a34-84b2a459923a)***.***

## Equal Opportunity

Rivian and Volkswagen Group Technologies is committed to creating a diverse environment and is proud to be an equal opportunity employer. All qualified applicants will receive consideration for employment without regard to race, color, religion, national origin, ancestry, sex, sexual orientation, gender, gender expression, gender identity, genetic information or characteristics, physical or mental disability, marital/domestic partner status, age, military/veteran status, medical condition, or any other characteristic protected by law. We are also committed to ensuring compliance with all applicable fair employment practice laws regarding citizenship and immigration status.

Rivian and Volkswagen Group Technologies is committed to ensuring that our hiring process is accessible for persons with disabilities. If you have a disability or limitation, such as those covered by the Americans with Disabilities Act, that requires accommodations to assist you in the search and application process, please email us at ----- style="min-height:1.5em">

## Candidate Data Privacy

Rivian and Volkswagen Group Technologies” may collect, use and disclose your personal information or personal data (within the meaning of the applicable data protection laws) when you apply for employment and/or participate in our recruitment processes (“Candidate Personal Data”). This data includes contact, demographic, communications, educational, professional, employment, social media/website, network/device, recruiting system usage/interaction, security and preference information. Rivian and Volkswagen Group Technologies may use your Candidate Personal Data for the purposes of (i) tracking interactions with our recruiting system; (ii) carrying out, analyzing and improving our application and recruitment process, including assessing you and your application and conducting employment, background and reference checks; (iii) establishing an employment relationship or entering into an employment contract with you; (iv) complying with our legal, regulatory and corporate governance obligations; (v) record keeping; (vi) ensuring network and information security and preventing fraud; and (vii) as otherwise required or permitted by applicable law.

Rivian and Volkswagen Group Technologies may share your Candidate Personal Data with (i) internal personnel who have a need to know such information in order to perform their duties, including individuals on our People Team, Finance, Legal, and the team(s) with the position(s) for which you are applying; (ii) Rivian and Volkswagen Group Technologies affiliates; and (iii) Rivian and Volkswagen Group Technologies’ service providers, including providers of background checks, staffing services, and cloud services.

Rivian and Volkswagen Group Technologies may transfer or store internationally your Candidate Personal Data, including to or in the United States, Canada, and the European Union and in the cloud, and this data may be subject to the laws and accessible to the courts, law enforcement and national security authorities of such jurisdictions.

If you provide a mobile telephone number as part of your application or during the recruitment process, Rivian and Volkswagen Group Technologies may use that number to contact you via SMS text message for recruitment-related purposes, including scheduling, logistics, and status updates. Message and data rates may apply. You may opt out of SMS communications at any time by replying STOP to any text message you receive from us. Consent to receive SMS messages is not a condition of applying for or being considered for employment.

Please see our [**Candidate Data Privacy Notice (English)**](https://assets.ctfassets.net/2md5qhoeajym/53otRWdzXPzSdWPgiel5T/07c61b0eed2d91f2f403f788fd20d315/RVTech_Candidate_Data_Privacy_Notice_-_Nov_2024.pdf)** **and [**Candidate Data Privacy Notice (Serbian)**](https://assets.ctfassets.net/2md5qhoeajym/40xUZMehbGToclkLqWXW0E/eb5b553bd8af7c607066253fbb227bda/RVTech_Candidate_Data_Privacy_Notice_-_Nov_2024_Serbian.pdf) for more information.

--

*Please note this job posting represents an open, active vacancy. Additionally, we are not currently accepting applications from third party application services.*

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
