# Working Student - Electronics (f/m/d)

Posted: 2026-09-09T17:40:11Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**About Munich Electrification**

Munich Electrification is an innovative company founded with the aim of accelerating the transition to electric and connected mobility. We develop innovative electronic control units for electric vehicles and stationary storage systems for our global customers. Our international team is composed of highly motivated and exceptional engineers. As a small and specialized team we are well-aware of the importance of each individual colleague and support and promote each employee according to their abilities and needs. Our office with adjacent prototype and testing lab is located in the heart of Munich at the Heimeranplatz.

This is what we stand for:

- **Technological Leadership**: We challenge norms, innovate quickly, and anticipate future needs. We take smart risks and learn from outcomes to stay ahead.

- **Sustainability**: We actively drive change for a sustainable future, aware of our impact and inspiring others to build a better world.

-** Team Culture**: We believe work should be enjoyable, fostering a spirit of inspiration, celebration, and teamwork across the globe.

- **Entrepreneurial Spirit**: We embrace change, think big, and push limits with passion.

**Your future tasks at a glance**

-

Support the development of electronic parts from concept design to production release, including detailed design of parts and/or components

-

Design and perform measurement or test setups for electronic and electromechanical components

-

Set up, operate and monitor machines and devices (including climate chambers, electrical power supplies and force measurement devices)

-

Support and execution of engineering, validation and production tests in coordination with the electronics team or other departments, e.g. by writing or modifying automation test sequences

-

Carry out measurements and tests for concept and design validation

-

Evaluate and document test results

-

Support the electronics team with building prototypes and test samples

**What you bring with you**

-

Bachelor or Master student in electrical engineering, mechatronics, physics or similar engineering field

-

Hands on mentality, willingness to build and execute tests and experiments in our lab

-

Willing to take responsibility of a project

-

Creativity and enthusiasm for innovative solutions for electric vehicles or energy storage systems

-

Ability to work in a team & strong communication skills in English (German is a plus)

-

Nice to have: initial programming experiences (ideally C/C++ and Excel VBA) & insights in the functionality and the handling of lithium-ion battery systems or BMS.

**Our Offer & Benefits**

The chance to be part of a highly innovative, agile, and unique team with prestigious customers in the automotive and battery storage sector. You will gain a deeper knowledge around connected & electric vehicle batteries, battery management and electronics development and strive in an exciting work environment

**Benefits (Full-time Employees):**

- Trust-based working hours and hybrid work

- Adequate and competitive compensation

- Pension Plan/Bonus

- Free access to the fitness center right next to us or subsidized EGYM Wellpass

- Free snacks, coffee, drinks and lunch (freshly cooked by our chef) every day

- Public transport ticket

- Bike-Leasing via Business Bike

- Experience various inspiring and fun team events

- ME-branded clothing

- Option to "work from anywhere" (6 weeks/year)

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
