# Team Lead IT Infrastructure & IT Operations (all genders)

Posted: 2026-09-09T19:00:43Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

## Daran solltest Du Freude haben

Gemeinsam mit Deinem Team verantwortest Du den sicheren, hochverfügbaren und zukunftsfähigen Betrieb unserer Unternehmens-IT. Du entwickelst technische Lösungen, die Unternehmensstrukturen, Geschäftsprozesse und Governance-Anforderungen optimal unterstützen. Dabei behältst Du sowohl Risiken und Compliance-Vorgaben als auch die Anforderungen eines modernen und effizienten Arbeitsumfelds im Blick.

- **Führung & Organisation:** Du übernimmst gemeinsam mit Deinem Team die Verantwortung für unsere IT Infrastructure & Operations, steuerst Infrastrukturprojekte sowie externe Partner und sorgst für effiziente, skalierbare und zukunftsfähige Betriebsprozesse.

- **Netzwerk & Infrastruktur:** Du verantwortest eine stabile, hochverfügbare und sichere Infrastruktur über mehrere Standorte hinweg und entwickelst unsere Netzwerk-, Rechenzentrums- und Connectivity-Konzepte kontinuierlich weiter.

- **Security, Governance & Identity:** Du entwickelst Sicherheits-, Identitäts- und Berechtigungskonzepte weiter und stellst sicher, dass Unternehmensstrukturen, Risikobetrachtungen und Governance-Anforderungen nachhaltig in unserer IT-Landschaft abgebildet werden.

- **Microsoft 365, Identity & Modern Workplace:** Du gestaltest die Weiterentwicklung unserer Microsoft-365- und Identity-Plattformen und sorgst für sichere, effiziente und benutzerfreundliche Lösungen rund um Zusammenarbeit, Geräteverwaltung und Zugriffssteuerung.

- **Collaboration, Messaging & Archivierung:** Du verantwortest unsere Kommunikations- und Kollaborationsplattformen sowie die Umsetzung von Governance-, Compliance- und Archivierungsanforderungen.

- **Server, Storage & Virtualisierung:** Du stellst den zuverlässigen Betrieb und die strategische Weiterentwicklung unserer Server-, Storage- und linuxbasierten Virtualisierungsplattformen sicher und schaffst die Basis für eine leistungsfähige und zukunftssichere IT-Landschaft.

- **Backup, Monitoring & Operations:** Du verantwortest Backup-, Recovery- und Monitoring-Konzepte, etablierst geeignete Betriebs- und Sicherheitsstandards und sorgst für Transparenz, Stabilität und die kontinuierliche Verbesserung unserer IT-Services.

## Das bringst Du mit

## Fachliche Qualifikationen

- Erfolgreich abgeschlossenes Studium der Informatik, Wirtschaftsinformatik oder eine vergleichbare Ausbildung.

- Mindestens fünf Jahre Berufserfahrung im Bereich IT Infrastructure, System Engineering oder IT Operations in vergleichbaren Unternehmensumgebungen.

- Erfahrung in der fachlichen oder disziplinarischen Führung technischer Teams sowie in der Steuerung von IT-Projekten und Dienstleistern.

- Fundierte Kenntnisse moderner Infrastruktur-, Netzwerk-, Security-, Identity- und Modern-Workplace-Lösungen.

## Persönliche Kompetenzen

- Ausgeprägte Führungs- und Kommunikationsstärke sowie Freude an der Zusammenarbeit mit unterschiedlichen Stakeholdern.

- Hands-on-Mentalität kombiniert mit strategischem Denken und einem ganzheitlichen Blick auf Unternehmensprozesse.

- Hohes Qualitäts-, Sicherheits- und Verantwortungsbewusstsein.

- Fähigkeit, pragmatische Lösungen zu entwickeln, die Unternehmensanforderungen, Governance und Risikomanagement in Einklang bringen.

- Verhandlungssichere Deutsch- und Englischkenntnisse (mindestens B2-Niveau).

## Das erwartet Dich

- Viel Gestaltungsspielraum, kurze Entscheidungswege und ein hohes Maß an Eigenverantwortung.

- Ein unbefristeter Arbeitsvertrag in einem erfolgreichen und zukunftsorientierten Unternehmen.

- Flexible Arbeitszeiten, hybrides Arbeiten und bis zu vier Wochen „Work from Anywhere“ pro Jahr.

- Attraktive Benefits wie das Deutschlandticket, Urban Sports Club oder Essenszuschüsse.

- Exklusive Vorteile aus der Tourismusbranche, darunter die DRV Card und weitere Vergünstigungen.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
