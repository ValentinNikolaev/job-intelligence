# Venture Development - New Products UK Market (AI x Greentech) (m/f/d)

Posted: 2026-09-09T23:40:09Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**You build what Reonic launches next. Start it, sell it, own it.**
Looking for a role with real, end-to-end ownership, not a slice of one? This is for you! You'll run your own workstreams end to end, working closely with a small, highly motivated team of venture developers. If you're impatient to take on real responsibility fast, this is built for you.

***Please note that for this role, C2 English proficiency is required. This is a full-time, on-site position based in Berlin.***

**What You’ll Do**

-

**End-to-end ownership of new initiatives.** From first idea to market rollout, you define the MVP, prioritize what gets built, and drive it through launch.

-

**Go-to-market strategy and execution.** You don't hand off to a GTM team, you build the launch plan yourself: positioning, pricing, channels, and the first wave of sales. Then you own how it performs.

-

**Cross-functional execution.** You'll pull together sales, marketing, and tech around your initiative and keep it moving. You're the one people look to for the next step.

-

**Customer immersion.** Daily conversations with customers to find pain points, validate ideas, pressure-test what you're building against reality, and sell them what you've built.

-

**Commercial responsibility.** You don't just launch products, you help sell them: positioning, upselling, and iterating based on what actually works in the field.

-

**A seat at the table where the bets are made.** Markets, partnerships, pricing: you evaluate them with the founders and decide which product becomes the next big thing.

**What Makes You a Great Fit**

-

Native or C2-level English.

-

Strong sense of ownership and impatient if things don't move fast.

-

Startup experience, ideally somewhere you had to build something from nothing.

-

You want to experience the full cycle of tech, ops, and business strategy at a high-growth company, not just understand how they fit together.

-

Top university background with a clear entrepreneurial streak. You've built or driven something, not just studied it.

-

You're excited to talk to customers, iterate quickly, learn, and get your product out there.

**Why Join Us?**

-

Be part of one of the fastest growing VC-backed startup in Germany with 3000+ satisfied B2B customers.

-

A vibrant, collaborative office culture where great ideas happen face-to-face - we're a full in-person team (5 days/week) in a beautiful Berlin office near Hackescher Markt.

-

Enjoy opportunities for personal and professional growth.

-

Embrace the freedom to innovate and make quick changes in a dynamic team.

-

Perks include gym membership ,or Deutschlandticket, Uber Eats after 7pm, Uber home after 7:30pm, regular team events, and a MacBook.

-

Receive competitive pay.

Even if you don’t meet every requirement, we encourage you to apply! Imposter syndrome shouldn't hold you back - we value talent and passion above all.

**About Reonic**

At Reonic, we’re on a mission to simplify renewable technology with our AI operating system for renewable installers. Backed by top-tier investors and trusted by 3000+ business customers, we’re growing fast - and we need YOU to help us accommodate our new and existing customers.

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
