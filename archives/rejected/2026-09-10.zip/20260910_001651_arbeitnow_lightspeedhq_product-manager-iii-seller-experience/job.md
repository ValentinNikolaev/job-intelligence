# Product Manager III, Seller Experience

Posted: 2026-09-09T23:40:06Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**Hi there! Thanks for stopping by 👋**

Are you actively looking for a new opportunity? Or just checking the market? Well… you might just be in the right place!

We’re on a mission to help power the businesses that are the backbone of the global economy. You will be a key part within our NuOrder by Lightspeed group to help Lightspeed make great products and strong decisions grounded in data.

If you’re looking to work in a fast-paced, highly collaborative environment that impacts a large global customer base - let’s talk! The **Product Manager III, Seller Experience **is responsible for the vision for helping world class brands showcase their merchandise and connecting them to retail buyers on NuORDER by Lightspeed. The ideal candidate will have a strong background in product management, product strategy, UX, data analytics and a passion for delivering exceptional user experiences in the retail industry.

If you are an entrepreneurial problem-solver and are ready to make a huge impact on the future of the company, we would love to hear from you!

**What you’ll be responsible for:**

-

**Owning the B2B Selling Strategy: **Drive the overarching product strategy to build a compelling value proposition that addresses the core jobs-to-be-done and needs of our brands (the supply side on the NuORDER platform.

-

**Building a World-Class Selling Experience:** Partner with diverse brands all over the world, ranging from emerging labels to global enterprise powerhouses, to understand their needs and craft an unparalleled, best-in-class wholesale selling experience.

-

**Managing the End-to-End Selling Journey:** Oversee the complete lifecycle of B2B transactions, owning the journey from the moment an item is purchased to when it is fully paid for.

-

**Driving Critical Transactional Capabilities: **Take direct product ownership of key functional touchpoints, including Brand Profiles, Buyer Management, Insights, Checkout Experience, Invoicing, B2B payments, and order tracking, ensuring seamless fulfillment and delivery to buyers.

-

**Executing with Impact: **Work closely with engineering, design, and go-to-market teams to translate strategic vision into roadmaps and PRDs, resulting in launched features that move feature, funnel and business metrics.

**
What you’ll be bringing to the team:**

-

**Extensive PM Craft:** Minimum 5 years of proven product management experience demonstrating an exceptionally strong mastery of product management craft.

-

**The "PM as CEO" Mindset:** A strong focus on commercial impact and business viability, treating the product as your own business and driving measurable revenue outcomes.

-

**Strategic & Innovative Thinking:** A visionary problem-solver who doesn't just execute, but consistently brings fresh, innovative ideas and strategies to the table.

-

**Exceptional Leadership & Communication:** Great storytelling skills with the ability to influence, align, and lead cross-functional teams and external stakeholders effectively.

-

**Data & User-Centricity:** Deeply grounded in metrics and user needs to drive product decisions, with a strong ability to translate insights into action.

-

**UX & Experimentation Proficiency:** A solid understanding of best-in-class UX principles coupled with rigorous, hands-on knowledge of A/B testing methodologies to optimize the user journey.

-

**Big Tech & 0-to-1 Background:** Proven experience working in Big Tech environments with a demonstrated track record of building and scaling complex products from zero to one.

We know that people are more than what’s on their CV. If you’re unsure that you have the right profile for the role... hit the ‘Apply’ button and let’s have a chat!

**What’s in it for you?**

Come live the Lightspeed experience...

-

Lots of autonomy, flexible work culture and the option of fully remote work

-

Genuine career opportunities in a company that’s creating new jobs everyday

-

Opportunity to make a difference; help merchants grow their businesses and become more successful by creating or improving products and addressing customer feedback

-

Work in a team big enough for growth but lean enough to make a real impact

-

Development of very high traffic products, used at the global scale

-

Opportunities to learn and expand your skill set

-

Become a valued part of the diverse and inclusive Lightspeed family

… and enjoy a range of benefits that’ll keep you happy, healthy and (not) hungry:

-

Lightspeed equity scheme (we are all owners)

-

Flexible paid time off policy

-

Health insurance

-

Health and wellness benefit of $500 per year

-

Hybrid working policy

-

Paid leave and assistance for new parents

-

Mental health online platform and counseling & coaching services

-

Volunteer day

#LI-AL2

*To all recruitment agencies: Lightspeed does not accept unsolicited agency resumes. If we have not directly engaged your company in writing to supply candidates for a specific vacancy, Lightspeed will not be responsible for any fees related to unsolicited resumes.*

*Lightspeed is a proud equal opportunity employer and we are committed to creating an inclusive and barrier-free workplace. Lightspeed welcomes and encourages applications from people with disabilities. Accommodations are available on request for candidates taking part in all aspects of the selection process.*

## **Where to from here?**

Obviously, this has to be mutually beneficial: we want you to step into a role you love, and we want to offer you a place you’re proud to come to every day. For a glimpse into our world check out our [career page here](https://www.lightspeedhq.com/careers/).

Lightspeed is building communities through commerce, and we need people from all backgrounds and lived experiences to do that. We were founded in 2005, in Montreal’s gay village and our original members were all part of the LGBTQ+ community. The ethos of our business has been about inclusion from the very beginning, and we strive to provide a workplace where everyone belongs.

## **Who we are:**

Powering the businesses that are the backbone of the global economy, Lightspeed's one-stop commerce platform helps merchants innovate to simplify, scale, and provide exceptional customer experiences. Our cloud commerce solution transforms and unifies online and physical operations, multichannel sales, expansion to new locations, global payments, financial solutions, and connection to supplier networks.

Founded in Montréal, Canada in 2005, Lightspeed is dual-listed on the New York Stock Exchange (NYSE: LSPD) and Toronto Stock Exchange (TSX: LSPD). With teams across North America, Europe, and Asia Pacific, the company serves retail, hospitality, and golf businesses in over 100 countries.

Lightspeed handles your information in accordance with our [Applicant Privacy Statement](https://www.lightspeedhq.com/legal/applicant-privacy-statement/).

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
