# Working student IT Service Management & Governance (m/f/d)

Posted: 2026-09-09T23:30:28Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

### **Transform with us the future of energy ⚡**

The **SGB‑SMIT Group** is an international transformer manufacturer with locations in **Europe, Asia** and **America.** With reliable transformer technology, the company actively supports the global energy transition in areas such as renewable energy, industry and urban energy infrastructure.

As a key link between power generation, transmission and distribution, **SGB‑SMIT Group** develops and manufactures **power transformers, distribution transformers, cast‑resin transformers** and custom solutions for data centers, industrial applications and e‑mobility. These products ensure efficient, stable and secure energy flows worldwide.

With more than **3,800 employees** worldwide, the **SGB‑SMIT Group** stands for quality, innovation and sustainability and offers a stable environment to work on technologies that shape the energy systems of the future.

#### What sets the SGB-SMIT Group apart**: 🌍**

We combine the strength of an **international technology company** with an **employee-oriented corporate culture**:

-

Meaningful work at the heart of the energy transition

-

Short decision-making processes and direct cooperation

-

Stable, growing company with long-term prospects

Your contribution counts – **both professionally and personally**.

#### **Your benefits at SGB-SMIT Group: 🚀**

-

Flexible working hours

-

Various home office options

-

Personal development and further training

-

Excellent health management

-

Fitness pass in cooperation with Hanse Fit

-

Excellent company restaurant and free drinks (coffee, water)

-

Company parking spaces with charging facilities for electric vehicles

-

Various discounts as part of Benify Benefits (Apple, Nike, Dell, Zalando, etc.)

#### **Your tasks: 📌**

-

Support the continuous improvement and quality assurance of central IT service processes

-

Monitor relevant KPIs using existing dashboards and track agreed actions and measures

-

Contribute to the further development of the ServiceNow platform by testing new functionalities and supporting the business acceptance of implemented requirements

-

Assist with the implementation and maintenance of the Configuration Management Database (CMDB)

-

Maintain and update process documentation, policies, and knowledge content

#### **Your profile: 🔎**

-

Currently enrolled in a degree program in Business Information Systems, Computer Science, Business Administration, or a comparable field of study

-

Analytical mindset with an interest in processes, digitalization, and IT services

-

Structured, independent, and detail-oriented way of working

-

Strong communication skills and enjoyment of collaborating with international teams

-

Good written and spoken English skills

If you value a dynamic, growing, and intercultural environment and enjoy hands-on work, then become part of the **SGB-SMIT Group** - **transform with us the future of energy**. ⚡

We look forward to receiving your application! ⚡

Learn more about the SGB-SMIT Group as an employer, our values, and career opportunities on our careers page:

[https://www.sgb-smit.com/career-jobs/sgb-smit-group#/](https://www.sgb-smit.com/career-jobs/sgb-smit-group#/)

*The terms used in this text refer to all genders in accordance with the General Equal Treatment Act (AGG).*

.

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
