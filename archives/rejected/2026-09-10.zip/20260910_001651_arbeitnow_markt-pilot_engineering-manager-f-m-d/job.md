# Engineering Manager (f/m/d)

Posted: 2026-09-09T20:24:20Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**Be bold, think big and grow with us!**

We are one of the fastest growing B2B scale-ups in Germany, creating real value for the engineering industry. With our software, we are setting a new standard in the spare parts business, enabling comprehensive market transparency for the first time. To achieve this, we challenge the status quo every day and support our employees in actively shaping their careers and pushing their own boundaries. Become part of a team that can't be stopped, that overcomes challenges together and celebrates success together.

**Be part of our success story and join us as Engineering Manager (f/m/d)! 🚀**

**Your Mission**

- Act as the engineering execution and people leadership counterpart to the CPTO, translating product and technical direction into clear expectations and action for teams.

- Shape the Engineering organization together with the CPTO, aligning teams, roles and capabilities with the product modules and direction the company needs next.

- Lead difficult organizational change, including restructuring teams, redefining roles and responsibilities, communicating changes and stabilizing teams afterwards.

- Set clear performance standards, give direct feedback, run meaningful performance conversations, develop strong performers and address underperformance consistently.

- Build trust across technical and non-technical stakeholders by translating between executive, business and engineering perspectives.

- Identify capability gaps and help determine where to build capability, hire differently, redesign roles or make organizational changes.

- Create accountability without unnecessary process and intervene when the organization is not moving fast enough.

- Partner closely with the CPTO to surface signals from Engineering, challenge direction where useful and turn decisions into an executable pace of change.

**Your Skills**

- Experience in people leadership within software engineering organizations, with evidence of leading teams through change.

- Excellent communicator and listener who can adapt messages for senior leadership, go-to-market stakeholders and highly technical engineers.

- A strong people leader who is comfortable with direct feedback, difficult conversations, performance management and accountability.

- Technically credible enough to understand modern software architecture and engineering practices, engage senior engineers and translate technical decisions into organizational consequences.

- Practical experience with organizational design, team structures or capability development, with a clear focus on aligning the organization to the product.

- Comfort with ambiguity and ownership, including the ability to test and adjust approaches without waiting for a complete playbook.

- A pragmatic change leader who combines high standards with empathy and does not avoid uncomfortable decisions.

- Able to work effectively within European time zones and to influence the organization without expecting ownership of the CPTO’s product, architecture or technical direction.

**Your Benefits**

- Our modern and open scale-up culture gives you the freedom to unleash your creativity within a dynamic and agile team. 💡

- Fail Fast, Learn Faster: Feedback here is exactly what it should be - an essential part of your work. 📈

- We invest in your growth: Discover our Learning & Development programs - including an L&D budget! 🌱

- Flexible working hours and the option to work hybrid. Remote is also possible.

- Rest is important too - 30 days of vacation 🏖️

- Travel by Train: Even MARKT-PILOTS take the train! We subsidize your monthly Deutschland-Ticket! 🚆

- Job bikes for those who prefer to travel on two wheels! 🚴‍♀️

- Crew-Love: Look forward to regular team events, exciting gaming sessions, and much more. 🎮️

- Stay Healthy: With a discounted WELLPASS membership and healthy snacks, you can always recharge your batteries. 🍏

- Corporate Benefits: Discover a variety of attractive offers from top brands with exclusive discounts. 🛒

Awarded as a Top-5%-Employer for the 5th time in a row. Fly with us @MARKT-PILOT! 🚀

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
