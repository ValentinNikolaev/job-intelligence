# Lead Business Analyst, Process & Automation (Berlin | remote)

Posted: 2026-09-09T23:40:06Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**Hi there! Thanks for stopping by 👋**

Are you actively looking for a new opportunity? Or just checking the market? Well… you might just be in the right place!

We’re looking for a Lead Business Analyst, Process & Automation to join our Capital and Payments team. Process & Automation is a small team working across the operations behind payments, lending, underwriting, risk, and billing. We find operational friction, diagnose root causes, and build the process, data, tooling, and automation solutions that fix it.

You will own projects end to end: find where a process is failing or create toil, prove it with data, design something better, coordinate the build with stakeholders, and stay with it until the receiving team owns it and the numbers have moved. AI is a default tool in how we work rather than a separate initiative.

This is a hands-on individual-contributor role with full ownership of your projects.

**What you’ll be doing:**

-

**Define**: map end-to-end flows, trace handoffs, and understand how a process actually runs rather than how it is documented.

-

**Diagnose**: separate root causes from symptoms and quantify where time, money, and customers are being lost.

-

**Design**: turn what you find into clear requirements, better flows, and delivery plans with measurable success criteria, then build or coordinate the automation, tooling, data, and controls they depend on.

-

**Instrument**: lead testing and launch readiness, track impact against agreed measures, drive adoption, and hand ownership back to the team that owns the outcome.

-

Establish how we use AI agents in operations: identify where they create real leverage, then design, test, and deploy them for bounded, multi-step workflows, including the evaluation methods that prove they work.

-

Partner with teams outside operations whose work affects these outcomes, and turn operational findings into business cases that help Product and Technology prioritize longer-term solutions.

**What you need to bring:**

We're looking for a candidate who has experience with the following:

-

7+ years in business analysis, process improvement, operations, implementation, or product operations.

-

A track record leading complex cross-functional projects from problem definition through implementation and ongoing measurement.

-

Strong analytical skills - you use data, queries, and dashboards to validate problems and prove outcomes, not only to report on them.

-

Demonstrated ability to turn ambiguous business needs into clear requirements, process designs, and delivery plans.

-

Excellent stakeholder management, facilitation, written communication, and presentation skills, with a track record of driving alignment and outcomes across teams you do not manage.

**Even better if you have, but not necessary:**

-

Financial services, fintech, payments, lending, or insurance - or another complex, regulated operating environment.

-

Commerce, e-commerce, point-of-sale, or marketplace experience.

-

Hands-on experience with workflow, case-management, or process-automation platforms.

-

SQL, business-intelligence tools, or data modelling.

-

Experience evaluating or deploying AI-enabled solutions for operational use cases.

-

Experience driving adoption and effectiveness after launch, not just delivery.

We know that people are more than what’s on their CV. If you’re unsure that you have the right profile for the role... hit the ‘Apply’ button and give it a try!

**Be a changemaker**

**You’ll enjoy:**

-

A flexible work environment that empowers you to do your best work

-

A culture that celebrates performance

-

The chance to make an impact in a team that’s big enough for career growth, but lean enough to make your voice heard

-

Career-defining opportunities

**Plus benefits designed to keep you happy, healthy and fulfilled.**

-

Equity options, because this is your company too

-

Contributions to your pension plan. Your future matters

-

Training opportunities to grow your skills and career

-

Health and wellness credit so you feel your best

-

Time off to volunteer and give back to your community

-

Enhanced parental leave to support growing families

-

Etc…

Fuel your growth. Find your people.

At Lightspeed, your growth is our priority. We invest in you with continuous learning opportunities, global mobility and benefits designed to support you—all within a driven, diverse and inclusive team that’s passionate about empowering our communities

*Please note that we ask applicants to disclose any criminal convictions, and we conduct criminal record checks as part of our hiring process for this role.*

*To all recruitment agencies: Lightspeed does not accept unsolicited agency resumes. If we have not directly engaged your company in writing to supply candidates for a specific vacancy, Lightspeed will not be responsible for any fees related to unsolicited resumes.*

*Lightspeed is a proud equal opportunity employer and we are committed to creating an inclusive and barrier-free workplace. Lightspeed welcomes and encourages applications from people with disabilities. Accommodations are available on request for candidates taking part in all aspects of the selection process.*

## **Where to from here?**

Obviously, this has to be mutually beneficial: we want you to step into a role you love, and we want to offer you a place you’re proud to come to every day. For a glimpse into our world check out our [career page here](https://www.lightspeedhq.com/careers/).

Lightspeed is building communities through commerce, and we need people from all backgrounds and lived experiences to do that. We were founded in 2005, in Montreal’s gay village and our original members were all part of the LGBTQ+ community. The ethos of our business has been about inclusion from the very beginning, and we strive to provide a workplace where everyone belongs.

## **Who we are:**

Powering the businesses that are the backbone of the global economy, Lightspeed's one-stop commerce platform helps merchants innovate to simplify, scale, and provide exceptional customer experiences. Our cloud commerce solution transforms and unifies online and physical operations, multichannel sales, expansion to new locations, global payments, financial solutions, and connection to supplier networks.

Founded in Montréal, Canada in 2005, Lightspeed is dual-listed on the New York Stock Exchange (NYSE: LSPD) and Toronto Stock Exchange (TSX: LSPD). With teams across North America, Europe, and Asia Pacific, the company serves retail, hospitality, and golf businesses in over 100 countries.

Lightspeed handles your information in accordance with our [Applicant Privacy Statement](https://www.lightspeedhq.com/legal/applicant-privacy-statement/).

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
