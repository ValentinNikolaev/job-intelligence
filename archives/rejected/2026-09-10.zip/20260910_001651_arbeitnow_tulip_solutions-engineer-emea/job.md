# Solutions Engineer - EMEA

Posted: 2026-09-09T20:55:09Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**This is a Hybrid role, 3 days from our office in Munich**

[Tulip](https://tulip.co/) brings modern technology and AI into manufacturing. Manufacturing accounts for almost 20% of the global economy and one in every seven workers on Earth, yet remains among the least digitized. More than a decade ago, we created the category to close that gap: AI-native software that puts cutting-edge tools directly in the hands of the people on the manufacturing front lines. Because we are human-centered and tech-obsessed, we are building a future of work where human ingenuity is amplified with the latest technology.

In January 2026 we became one of Boston's few new AI unicorns, reaching a $1.3B valuation. We're growing double digits in revenue year over year. The world's best manufacturers run on Tulip - turning inventory 10x faster, releasing gene therapies in hours instead of weeks, and training master craftspeople to forge engagement rings 5x more rapidly. Headquartered in Somerville, MA with offices in Germany, Hungary, Singapore, Japan, and Israel, we've been consistently named a World Economic Forum Global Innovator, a Gartner leader, and one of Built In Boston's "Best Places to Work."

We run the way we build: AI-forward, humanistic, and high ownership. We're looking for builders who are energized by complex problems, rapid cycles, and the unique opportunity to see their impact on a global scale.

**About You:**

We are seeking a highly motivated and talented individual to join our delivery team in our Munich office.

- You know the challenges in manufacturing and operations, and you believe in putting the operator in the center

- You can take on and lead projects with complex stakeholder landscapes

- You are comfortable communicating with customer stakeholders from the shop floor to the C-suite

- You’re flexible and can thrive in environments that don’t have defined processes, and you’re excited to help build

- those processes

- You have experience working in a startup environment or at a minimum are ready to take the plunge.

**What skills do I need?**

- BS Degree: Industrial Engineering, Mechanical Engineering, Engineering Management, Computer Science or a related field.

- 5+ years of work experience; prior experience in project management and manufacturing or process engineering is - a plus

- Exceptional analytical and problem-solving skills, with a keen eye for detail.

- Basic coding skills and familiarity with SQL and REST API

- Excellent communication and collaboration abilities.

- Proactive, self-starter attitude with a willingness to learn and grow.

- Fluency in English & German is reuired, French - a big plus.

- A strong track record of academic excellence and a passion for continuous improvement.

**Key Responsibilities:**

- Manage and execute enterprise-level customer projects using Tulip No-Code platform

- Work side by side with customers and partners to develop and implement Tulip solutions

- Provide ongoing customer technical support and build and maintain relationships

- Contribute to internal process building, improvement, and collaboration

- Collaborate with the engineering and product teams to provide insights and feedback based on customer2

- interactions.

- Working At Tulip

**Working At Tulip**

We know even great candidates experience imposter syndrome. Even if you don’t match every requirement, applying gives you the opportunity to be considered. We’re building a strong, diverse team that values hard work, families, and personal well-being. Benefits of working with us include:

- Direct impact on product and culture

- Company equity

- Competitive benefits package including Health, Dental, Vision, Short-term Disability, Long-term Disability, Life Insurance, AD&D Insurance, Flexible Spending Account (FSA), Commuter Benefits, Parental Leave, and 401(K)

- Flexible work schedule and unlimited vacation policy

- Virtual company events and happy hours

- Fitness subsidies

- An inclusive, dog-friendly office with diverse and inspiring colleagues

We are an equal opportunity employer. At Tulip, we celebrate all. Qualified applicants will receive consideration for employment without regard to race, religion, color, national origin, gender, sexual orientation, age, marital status, veteran status, or disability status. Help us build an inclusive community that will transform frontline operations.

It is unlawful in Massachusetts to require or administer a lie detector test as a condition of employment or continued employment. An employer who violates this law shall be subject to criminal penalties and civil liability.

Please note that we may use AI-based tools to support parts of our hiring process. All data processing is carried out in compliance with local data protection laws, ensuring all personal candidate information is handled securely and ethically.

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
