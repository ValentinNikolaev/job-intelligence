# Senior Product Manager (w/m/d) - Abrechnung & ERP

Posted: 2026-09-09T23:30:03Z

## Rejection

- Category: tech_stack
- Reason: role does not mention Go/Golang or PHP

**Du bringst Struktur in komplexe Fachprozesse, übersetzt Anforderungen in klare Produktentscheidungen und willst zentrale ERP- und Abrechnungsmodule in einer eigens entwickelten Softwarelösung weiterentwickeln? Dann gestalte mit uns den nächsten Entwicklungsschritt im Rahme des weiteren Teamaufbau’s als:**

**Senior Product Manager (w/m/d) - Abrechnung & ERP

**Wir suchen eine/n Senior Product Manager/in (w/m/d) - Abrechnung & ERP für unsere Softwarelösung ginisuite, unser ERP/PVS für Arbeitsmedizin und Arbeitssicherheit. Die Rolle kann remote in Deutschland oder hybrid aus Berlin ausgeübt werden. In dieser Rolle verantwortest Du die Weiterentwicklung zentraler Fachmodule unserer ginisuite mit Fokus auf Verträge, Rechnungswesen, Zeiterfassung und Buchhaltung. Du arbeitest eng mit dem Entwicklungsteam, relevanten Stakeholdern im Management und unseren Tochtergesellschaften zusammen und begleitest Themen von der fachlichen Anforderungsanalyse über die Übersetzung in User Stories und Tickets bis hin zu QA, Release, Datenmigration und Rollout.

Die **Arsipa Gruppe** ist eine schnell wachsende Unternehmensgruppe im Bereich Health, Safety & Environment, unterstützt von Warburg Pincus. Mit über 1.000 Mitarbeitenden, 20+ Tochtergesellschaften und 48 Standorten in Deutschland und Österreich bauen wir im Rahmen einer klaren Buy-&-Build-Strategie eine skalierbare Plattform mit nachhaltiger Wertschöpfung. Unser Ziel: eine der führenden Anbieterinnen im deutschsprachigen Markt - unterstützt durch zentrale Funktionen wie Finance, HR, Marketing und IT am Standort Berlin.

**Deine Aufgaben:**

-

**Produktverantwortung für Abrechnung & ERP**

-

Ownership für die Fachmodule Verträge, Rechnungswesen, Zeiterfassung und Buchhaltung innerhalb unserer eigens entwickelten Softwarelösung

-

Evaluierung und Weiterentwicklung operativer Prozesse und Standards mit Schwerpunkt Abrechnung und Vertragswesen

-

Identifikation fachlicher Verbesserungspotenziale und Überführung in wirksame Produktanforderungen

-

**Anforderungen, Umsetzung & Rollout**

-

Analyse fachlicher Anforderungen und Übersetzung in klare User Stories und Tickets sowie Begleitung der Umsetzung durch das Entwicklungsteam

-

Hands-on Unterstützung entlang des Entwicklungsprozesses, inklusive QA und Release

-

Unterstützung bei Datenmigrationen sowie Begleitung von Rollouts

-

**Enge Zusammenarbeit mit:**

-

dem Lead PM sowie dem CTO und weiteren relevanten Stakeholdern im Management

-

unseren Tochtergesellschaften zur Aufnahme fachlicher Anforderungen und operativer Bedarfe

-

dem Entwicklungsteam bei Umsetzung, Testing und Weiterentwicklung

-

internen und externen Partnern, z. B. dem Data-Warehouse-Team.

**Deine Startvoraussetzungen:**

-

**Das bringst Du mit:**

-

Nachweisbare Berufserfahrung im Produktmanagement, bevorzugt mit Schwerpunkt Rechnungswesen, ERP, Abrechnung oder vergleichbaren B2B-Softwarelösungen

-

Ausgeprägte Bereitschaft, Ownership für komplexe Fachmodule zu übernehmen und den Entwicklungsprozess hands-on zu begleiten

-

Erfahrung darin, fachliche Anforderungen in umsetzbare User Stories, Tickets und Produktverbesserungen zu übersetzen

-

Technische Erfahrung in den Bereichen Datenmigration, Datenanalyse und Softwareentwicklung

-

Hohe Eigenverantwortung, Strukturstärke und ein ausgeprägtes Ownership-Mindset

-

Sehr gute Deutsch- und Englischkenntnisse sowie Bereitschaft zu gelegentlichen Dienstreisen (ca. 20 %)

-

**Das hilft Dir, schneller erfolgreich zu sein:**

-

Erfahrung in SaaS-, Plattform- oder ERP-nahen Umfeldern sowie in technisch anspruchsvollen Produktlandschaften, z. B. mit Cloud-basierten Plattformen, APIs, Integrationen und verteilten Systemen

-

Verständnis für Softwarearchitektur, Microservices oder containerbasierte Systemlandschaften

-

Erfahrung im Umgang mit Legacy-Systemen und Migrationen, insbesondere im Spannungsfeld zwischen Bestandssystem und neuer Produktgeneration

-

Verständnis für operative Prozesse in einem Multi-Entity-, Buy-and-Build- oder stark wachsenden Unternehmensumfeld

-

Kenntnisse in den Bereichen Occupational Health & Safety, Arbeitsmedizin oder Arbeitssicherheit oder die Bereitschaft, sich schnell in dieses Umfeld einzuarbeiten

**Unsere Benefits:**

-

**Attraktives Arbeitsumfeld:** 30 Tage Jahresurlaub, Heiligabend und Silvester jeweils einen halben Tag frei, ein hybrides Setup mit großzügigen Homeoffice-Möglichkeiten sowie ein zentral gelegenes Office im Rocket Tower inklusive Gym, unmittelbar an der U-Bahn-Station „Kochstraße“. Ein Full-Remote Setup innerhalb Deutschlands ist auch möglich.

-

**Starke Teamkultur:** Eine offene und wertschätzende Unternehmenskultur mit regelmäßigen Stand-ups, monatlichen All-Hands Meetings und gemeinsamen Events zur Förderung einer positiven und kollegialen Arbeitsatmosphäre.

-

**Direkte Nähe zu Management, Tech und Business:** Enge Zusammenarbeit mit dem Group CTO, zentralen Management-Stakeholdern, unseren Tochtergesellschaften und dem Entwicklungsteam - mit direktem Einfluss auf zentrale Produktentscheidungen rund um Abrechnung, ERP und operative Fachprozesse.

-

**Gestaltungsspielraum in einer Buy-&-Build-Plattform:** Aktive Mitgestaltung von Prozessen, Strukturen und Standards in einer krisensicheren, rasant wachsenden Unternehmensgruppe sowie Einblicke in die Umsetzung einer Roll-up-Strategie - unterstützt durch einen der weltweit führenden Investoren, Warburg Pincus.

-

**Gestaltung einer skalierbaren Produkt- und ERP-Landschaft:** Von Verträgen, Rechnungswesen, Zeiterfassung und Buchhaltung über User Stories, QA und Release bis hin zu Datenmigration und Rollout wirkst Du an zentralen Produktinitiativen unserer Buy-&-Build-Strategie mit.

**Unser Bewerbungsprozess:**

-

**Kurzes Telefonat** mit dem Group Talent-Acquisition-Team der Arsipa Gruppe.

-

**Interview** mit den zuständigen Ansprechpartner*innen aus dem Group Product Team.

-

**Persönliches Kennenlernen **mit den zuständigen Ansprechpartner*innen aus dem Group Product Team.

Für weitere Fragen stehen wir Dir gerne jederzeit zur Verfügung!
Du erreichst das Group Talent-Acquisition-Team der Arsipa-Gruppe unter **.**

**Werde Teil unserer spannenden Reise bei der Arsipa Gruppe - Wir freuen uns auf Dich!**

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
