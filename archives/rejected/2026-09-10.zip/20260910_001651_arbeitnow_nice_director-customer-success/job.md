# Director, Customer Success

Posted: 2026-09-09T23:55:51Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

At NiCE, we don’t limit our challenges. We challenge our limits. Always. We’re ambitious. We’re game changers. And we play to win. We set the highest standards and execute beyond them. And if you’re like us, we can offer you the ultimate career opportunity that will light a fire within you.

## So, what’s the role all about?

We are looking for an exceptional Customer Success leader to lead and elevate a global team of approximately 26 Customer Success Managers across Australia, the US, UK, Germany and the wider EMEA region.

This is a senior leadership role for someone who knows what great Customer Success looks like and has the experience, credibility and energy to build it at scale. You will set the global Customer Success strategy, establish a clear and scalable operating model, raise standards across regions and develop our CSMs into consistently stronger strategic customer leaders.

This is deliberately **not an account owning role**. You will not carry your own customer portfolio. Instead, you will operate as a strategic leader, coach and expert across the Customer Success organisation, providing direction, challenge and expertise across Customer Success strategy, methodology, processes, commercial discipline, customer value and team performance.

You will bring consistency to a geographically distributed organisation while recognising that different markets and customers require different approaches. You will challenge existing thinking, raise the bar and create an environment where CSMs are accountable for delivering measurable customer and business outcomes.

Working closely with Sales, Professional Services, Product, Support, Engineering and senior leadership, you will play a critical role in ensuring Customer Success is positioned as a strategic function and a key driver of customer value, retention and growth.

## How will you make an impact?

- Lead, coach and develop a global team of approximately 26 Customer Success Managers across Australia, the US, UK, Germany and the wider EMEA region, creating a high performance, accountable and collaborative culture.

- Set the global Customer Success strategy and translate it into clear priorities, standards and measurable outcomes that can be consistently understood and executed across regions.

- Own and continuously evolve the global Customer Success methodology, operating model, processes, governance, tooling and best practices, ensuring they remain effective as the organisation scales.

- Establish a consistent framework for customer planning, onboarding, adoption, value realisation, customer health, risk identification, renewals and expansion, working closely with Sales to ensure clear ownership and collaboration.

- Coach CSMs to become stronger strategic customer leaders, developing their capabilities across executive engagement, commercial acumen, value selling, stakeholder management, strategic account planning and effective customer conversations.

- Provide constructive challenge to CSMs and regional leaders, raising the quality and consistency of customer strategy and ensuring teams are focused on meaningful customer and business outcomes rather than simply completing activities.

- Establish clear performance expectations, KPIs and management rhythms across Customer Success, using data and customer insight to identify trends, diagnose performance gaps and uncover opportunities for improvement.

- Build and maintain a strong Customer Success knowledge base, including playbooks, frameworks, templates and repeatable practices that enable CSMs to operate effectively and consistently.

- Partner closely with Sales leadership to establish effective collaboration across renewals, expansion, customer risk and executive relationships, ensuring Customer Success maintains its strategic customer focus without becoming a sales function.

- Partner with Professional Services, Product, Support and Engineering to improve the end to end customer experience, identify recurring sources of friction and drive improvements across the customer lifecycle.

- Act as a senior escalation point for strategically important or complex customer situations, providing direction, coaching and strategic guidance to the CSM rather than taking over account ownership.

- Represent the voice of Customer Success at senior leadership level, bringing clear customer insight, recommendations and data driven perspectives to business decisions.

- Identify capability gaps across the organisation and build targeted development plans, coaching programmes and succession pipelines to strengthen the long term capability of the Customer Success function.

- Support hiring and organisational design decisions as the Customer Success organisation continues to grow, ensuring we have the right structure, capabilities and leadership in place for scale.

- Champion a culture of continuous improvement, accountability and customer value, encouraging the team to challenge established thinking and continually raise the standard of Customer Success.

## Have you got what it takes?

- Significant senior leadership experience within Customer Success, ideally gained in B2B SaaS, enterprise technology, AI, automation or a similarly complex technology environment.

- Proven experience leading geographically distributed Customer Success teams, ideally at a scale comparable to 20+ CSMs across multiple regions and markets.

- Deep expertise in Customer Success strategy, operating models, methodologies, processes, tooling, governance and performance management.

- A strong track record of coaching and developing Customer Success Managers and building high performing teams.

- Experience establishing, transforming or scaling Customer Success processes and standards during periods of significant growth or organisational change.

- A strong understanding of customer value realisation, product adoption, retention, renewals, expansion, customer health and executive engagement.

- Strong commercial understanding, with the ability to partner effectively with Sales and understand the commercial drivers of the business without turning Customer Success into a sales function.

- Highly data driven, with the ability to use customer and business insight to diagnose performance, identify risk, establish priorities and make informed decisions.

- Exceptional executive communication and influencing skills, with the confidence and credibility to engage senior stakeholders, challenge established thinking and communicate complex ideas clearly.

- An exceptional coach who can elevate CSM performance through clear, practical guidance, constructive challenge and strong leadership.

- Strategic and structured, with the ability to operate at a global level while diving into the detail when required.

- Strong judgement and commercial acumen, with a clear focus on measurable outcomes and the ability to balance customer, commercial and organisational priorities.

- Collaborative, pragmatic and confident. You are comfortable challenging established thinking while building strong relationships across functions and levels of seniority.

- Calm, credible and highly organised, particularly when dealing with complex customer situations, competing priorities and high pressure environments.

- Able to create clarity, align distributed teams and lead effectively through periods of change.

- Naturally curious about customers, technology and the ways organisations can use AI and automation to generate measurable business value.

## How will we measure success?

Success in this role will be measured through a combination of customer, commercial, organisational and team outcomes, including:

- Achievement of Net Revenue Retention (NRR), Gross Retention Revenue (GRR) and NPS targets established at the start of each financial year.

- Customer satisfaction, advocacy and the strength of strategic customer relationships.

- Improved customer time to value and measurable value realisation from Cognigy solutions.

- CSM performance, capability development, engagement and retention.

- Consistent adoption and effective execution of the global Customer Success methodology.

- The quality, scalability and effectiveness of Customer Success processes, playbooks, governance and operating rhythms.

- Reduction in preventable customer risk, escalations and recurring sources of customer friction.

- Stronger cross functional collaboration and execution across Customer Success, Sales, Professional Services, Product, Support and Engineering.

Ultimately, success means building a Customer Success organisation that is highly trusted by our customers, commercially effective, operationally consistent and capable of scaling with the business.

## What’s in it for you?

Join an ever growing, market disrupting global company where the teams, comprised of the best of the best, work in a fast paced, collaborative and creative environment.

At NiCE, every day is an opportunity to learn, grow and make an impact. As the market leader, there are endless internal career opportunities across roles, disciplines, domains and locations.

If you are passionate about Customer Success, excited by the potential of AI and motivated by the opportunity to build and lead a truly global organisation, you may just be our next NICEr!

## About Cognigy

NiCE Cognigy delivers AI that works, fast, human and enterprise ready. As the leading AI first CX platform built for real world scale, we combine Generative and Conversational AI through orchestration, tools and enterprise systems to power Agentic AI.

Backed by global CX leader NiCE, we empower brands with AI Agents that redefine customer experiences and achieve measurable ROI, instantly, across every channel and in 100+ languages.

**Requisition ID: 11696**

**Reporting into:** Senior Director, Customer Management

**Job type: Director**

#LI-Remote

***About NiCE ***

*NICE Ltd. (NASDAQ: NICE) software products are used by 25,000+ global businesses, including 85 of the Fortune 100 corporations, to deliver extraordinary customer experiences, fight financial crime and ensure public safety. Every day, NiCE software manages more than 120 million customer interactions and monitors 3+ billion financial transactions. *

*Known as an innovation powerhouse that excels in AI, cloud and digital, NiCE is consistently recognized as the market leader in its domains, with over 8,500 employees across 30+ countries. *

*NiCE is proud to be an equal opportunity employer. All qualified applicants will receive consideration for employment without regard to race, color, religion, national origin, age, sex, marital status, ancestry, neurotype, physical or mental disability, veteran status, gender identity, sexual orientation or any other category protected by law.*

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
