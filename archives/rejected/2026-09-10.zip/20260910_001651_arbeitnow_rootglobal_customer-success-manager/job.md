# Customer Success Manager

Posted: 2026-09-09T23:40:05Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

## **🌎 What we do**

### **Root is Europe’s #1 primary data collection platform for F&B companies. We help our customers to measure and reduce farm-level emissions.**

~31% of global GHG emissions originate from food-related activities. For the first time in history, climate performance has become an overall business performance indicator. Enterprises are mandated by regulatory bodies to disclose their climate performance, which leads to increasing pressure from investors, competitors, retailers, and consumers to *prevent and reduce* their CO2e emissions. Over the next 10 years, companies have set ambitious reduction targets that need to be met. Unlike other industries, the vast majority of F&B emissions originate from farms (known as Scope 3.1 emissions) and are highly complex to address. Root exists to help overcome this challenge.

We raised >€10m in funding in the first 2 years of our existence, we launched our enterprise product, signed and onboarded some of the largest F&B players in Europe, and put together what we believe is the best-suited early-stage tech team in Europe. Will you be the next to join us? 🚀

# **🔭 What you will work on**

**Your mission**

Drive customer success by supporting a customer portfolio, ensuring smooth project execution and tool adoption, and helping build strong, trust-based relationships that maximize long-term value and advocacy.

**📅 Over the next months, you will…**

Drive Customer Success and Long-Term Value for Root's Customers

-

**Own the success of a defined customer portfolio**, acting as the primary point of contact and trusted advisor, guiding customers through key success milestones (onboarding, data collection, verification, reporting, reduction readiness) and ensuring they clearly understand and realize the value of the Root Platform

-

**Plan, manage, and execute customer projects end-to-end**, driving primary data coverage at scale through increased user engagement and data completion, serving as the first point of contact for agricultural users when needed, and ensuring high data quality, clear milestones, and on-time delivery

-

**Design and run farmer-facing enablement**, including digital webinars to drive participation, improve data quality, and build trust at the farm level

-

**Collaborate with Account Management** to relay customer feedback while building trust-based customer relationships that drive long-term satisfaction, retention, and advocacy

-

**Collaborate with Product** to bring agricultural and agronomic expertise into our products, translating practical farming knowledge and farmer needs into actionable product feedback and clear, farmer-facing recommendations.

**🧺 What you bring along**

-

Agricultural background (practical farm experience, agricultural studies, or prior work with agricultural users such as advisors, cooperatives)

-

Hands-on and detail-oriented, you thrive in fast-changing, early-stage environments, can juggle multiple tasks, and ensure nothing falls through the cracks

-

First experience in Customer Success, Operations or other fast-paced environments, where you supported or executed customer-facing processes end-to-end

-

People-centric and proactive, empathetic, approachable, and able to communicate clearly while keeping customer outcomes and business priorities in mind

-

Comfortable working with data in Excel and digital platforms, with an eye for completeness and consistency

-

Fluent in German and English; additional languages (Polish, French, Portuguese, Spanish) are a plus

-

Work from our Berlin office 5 days a week

*🤗 You don't feel like you fulfill all the criteria? We get it: confidence can sometimes hold us back from applying for a job. But guess what?! There is no such thing as a “perfect” candidate. The only thing you need to ensure along the recruiting process and beyond is that the problem that we are solving with Root is one you cannot wait to get out of bed for on Monday morning!*

*Root Global is an equal opportunity employer, which means we do not discriminate on the basis of race, colour, religion, marital status, age, national origin, ancestry, physical or mental disability, medical condition, pregnancy, genetic information, gender, sexual orientation, gender identity or expression. We celebrate diversity and are committed to creating an inclusive environment for all employees.*

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
