# Senior Consultant | Manager (m/w/d) - Operational Transformation in Energy, Utilities & Resources

Posted: 2026-09-09T23:55:36Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

### About Baringa

Baringa is a global consulting firm that partners with leaders to drive change and create value. With deep industry expertise, and enabled by advanced technology, the firm helps clients to deliver with greater confidence and certainty. With over 2,000 people across the UK, Europe, North America, Asia and Australia, the firm combines global insight with local understanding.

The firm works across energy and resources, financial services, government and public sector, consumer products and retail, pharmaceuticals and life sciences, manufacturing, and technology, media and telecoms, with capabilities spanning strategy, transformation and operational excellence – all powered by advanced technology, data, AI and digital innovation.

Clients value Baringa’s collaborative approach and the way its teams integrate seamlessly – all working with a shared understanding of what matters most. The firm is known for its kind, curious experts who listen closely and care deeply about client success as they help clients transform energy markets, modernise financial platforms, expand telecoms and digital networks through advanced data analytics, enable digital services in government, and unlock growth in consumer sectors.

Certified as a *Great Place to Work *around the world, Baringa has been recognised by the *Financial Times *in 22 categories of its UK Leading Management Consultants rankings, and by *Forbes *for four consecutive years as one of the World’s Best Management Consulting Firms.

## **Our Operational Transformation practice is looking for a Senior Consultant (m/w/d) or Manager (m/w/d) to join the team in Düsseldorf or Munich**.

As a member of our team, you will help shape and drive a breadth of exciting transformational work across one of our core sectors, Energy & Resources. Within our Organisational Transformation practice, we partner with clients to solve complex business challenges through operational excellence, process optimisation and people-led transformation.

Our approach combines expertise in leadership and culture change, organisational design, operating model definition, agile, automation and AI to create solutions tailored to our clients' specific needs. We are passionate about delivering lasting change initiatives that place the user experience at the heart of both design and execution.

We are growing our team to meet future demand and would love you to be part of our exciting growth ambitions.

We pride ourselves on being a bit more geek than generalist and live by the mantra: Be kind, be curious, be great at work.

### What you will be doing

As part of our Organisational Transformation team, you will:

-

Get involved from the outset by engaging with clients, developing propositions and proposals, and showcasing our expertise during business development and acquisition meetings.

-

Lead or support the delivery of consulting projects focused on streamlining client processes and improving operational efficiency.

- Collaborate closely with our clients to develop, coordinate, and implement sustainable improvements and new ways of working.

- In the spirit of continuous improvement, you will be instrumental in developing our operational excellence approaches, techniques and tools.

###
Your skills and experience

We're interested in people who bring a combination of the following:

-

At least 3 years of experience in management consulting or in an internal Operational Excellence, Process Excellence, or similar continuous improvement role.

-

Demonstrated experience in digitalisation, automation, and Lean methodologies, including their practical application to drive business improvements.

-

Experience in process optimisation within the energy sector, commodity trading environment, or related industries.

-

Exposure to transformation programmes, organisational change initiatives, reorganisation projects, and/or change management activities.

-

A solid understanding of business process management, automation technologies, and the potential of AI to support continuous improvement.

-

A proactive and results-oriented mindset, with the ability to take ownership and deliver outcomes in a complex, client-focused environment.

-

Strong communication, stakeholder management, and presentation skills.

-

Essential: Advanced (C1) proficiency in both German and English, written and spoken*.*

## What a career at Baringa will give you

### Putting People First.

### Baringa is a People First company and wellbeing is at the forefront of our culture. We recognise the importance of work-life balance and flexible working and provide our staff amazing benefits. Some of these benefits include:

- Generous Annual Leave Policy: We recognise everyone needs a well-deserved break. We provide our employees with 5 weeks of annual leave, fully available at the start of each year. In addition to this, we have introduced our 5-Year Recharge benefit which allows all employees an additional 2 weeks of paid leave after 5 years continuous service.

- Flexible Working: We know that the ‘ideal’ work-life balance will vary from person to person and change at different stages of our working lives. To accommodate this, we have implemented a hybrid working policy and introduced more flexibility around taking unpaid leave.

- Corporate Responsibility Days: Our world is important to us, so all our employees get 3 days every year to help social and environmental causes and increase our impact on the communities that mean the most to us.

- Wellbeing Fund: We want to encourage all employees to take charge and prioritise their own wellbeing. We’ve introduced our annual People Fund to support this by offering every individual a fund to support and manage their wellbeing through an activity of their choice.

- Profit Share Scheme: All employees participate in the Baringa Group Profit Share Scheme so everyone has a stake in the company’s success.

### Diversity and Inclusion

We are proud to be an Equal Opportunity Employer. We believe that creating an environment where everyone feels a sense of belonging is central to our culture and that diversity is paramount to driving creativity, innovation, and value for our clients and for our people.

### An award-winning workplace

You can be a part of our ‘Great Place to Work’ – with our commitment to women and well-being in the workplace for all. [Click here](https://www.baringa.com/en/impact/awards/) to see some of our recent awards and how we’ve achieved this.

### Using business as a force for good.

We maintain high standards of environmental performance and transparency, which can be seen through our commitment to Net Zero with our SBTI-verified Scope 1, 2 and 3 emissions reduction targets and our support of the Better Business Act. We report our progress publicly and ensure that we are also externally assessed and scored through organisations like CDP and EcoVadis - helping us to continually identify where we can improve.

We have a long legacy of supporting the communities in which we work, and offer a variety of ways to contribute, by putting people first and creating impact that lasts. Our Corporate Social Responsibility (CSR) agenda is about giving back to the communities in which we live and work by sharing our skills, talent and time. In essence, we aim to empower and encourage everyone in the firm to contribute to the things we care about, and support registered charities and organisations with a clear social or environmental purpose to increase the positive impact they can have.

### Join us

All applications received will be reviewed by a member of our Talent Acquisition team. We never rely solely on automated screening or AI tools to make hiring decisions. Your application will be considered for employment without regard to race, ethnicity, religion, gender, gender identity or expression, sexual orientation, nationality, disability, age, faith or social background. We do not filter applications by university background and encourage those who have taken alternative educational and career paths to apply. We would like to actively encourage applications from those who identify with less represented and minority groups. We operate an inclusive recruitment process, ensuring reasonable adjustments where needed. Please contact a member of our Recruitment Team to discuss further.

### Baringa Privacy Notices

**For UK & EU**

Your personal data will be retained by Baringa for up to two years, in accordance with our [UK Recruitment Privacy Notice / ](https://www.baringa.com/globalassets/careers/dp-004-ukrpn---uk-recruitment-privacy-notice-pdf.pdf)[EU Recruitment Privacy Notice](https://www.baringa.com/globalassets/careers/dp-005-eurpn---eu-recruitment-privacy-notice-pdf.pdf), to evaluate your application and meet our legal and reporting obligations. In line with the General Data Protection Regulation (GDPR), you have the right to request access to, rectification, or erasure (subject to legal limitations) of your personal data. For more information, please contact us at **For the USA**

Your personal data may be retained by Baringa for up to two years, as outlined in our [Recruitment Privacy Notice (AMER & APAC)](https://www.baringa.com/globalassets/careers/dp-007-nerpn-amer--apac-recruitment-privacy-notice-word.pdf), to support the recruitment process and internal reporting requirements. Where applicable, and in accordance with relevant federal and state laws, you may have the right to request access to or correction of your personal information. For further details, please contact **For Australia & Singapore**

Your personal data will be retained by Baringa for up to two years, in accordance with our [Recruitment Privacy Notice (AMER & APAC)](https://www.baringa.com/globalassets/careers/dp-007-nerpn-amer--apac-recruitment-privacy-notice-word.pdf), to assess your application and meet applicable reporting and legal obligations. In line with the Australian Privacy Act and Singapore’s Personal Data Protection Act (PDPA), you may have rights to access, correct, or request limited deletion of your personal data. For more information, please contact us at Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
