# Strategic Alliances Director

Posted: 2026-09-09T23:55:39Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

***OUR MISSION***

**At Redwood, we empower our customers with lights-out automation for their mission-critical business processes.**

***ABOUT US***

Redwood Software is the leading orchestration platform for the autonomous enterprise, driving business transformation at the lowest total cost of ownership. Redwood empowers organizations to intelligently automate and orchestrate mission-critical business and IT processes across complex ERP, hybrid cloud, data and emerging agentic AI systems. Through its SaaS-first automation fabric—with AI embedded across the automation lifecycle—Redwood accelerates the path to autonomous operations. Backed by 30 years of experience and trusted by more than 50% of the Fortune 50, Redwood helps organizations unlock human potential to focus on innovation, growth and what’s next.

***CORE VALUES***

One Team. One Redwood
Make Your Own Weather
Obsess over Customer Success
Work the Problem
Be Curious
Own the Outcome
Respect Each Other

***YOUR IMPACT***

The Strategic Alliance Director is responsible for driving key partnerships with SAP and AWS across program architecture and go-to-market. This includes leading engagement with partner field teams in your territory, driving new and expansion pipeline creation, supporting deal execution, and working on new programs and innovations in the partnerships.

- Orchestrate the growth and strategic expansion of Redwood's SAP and AWS partnership

- Lead alliance engagement internally and externally, ensuring alignment with organizational priorities and partner frameworks

- Develop and sustain executive-level relationships with SAP and AWS leadership and Redwood stakeholders

- Design and execute joint go-to-market strategies with SAP and AWS and internal teams to accelerate pipeline growth and client acquisition

- Collaborate with sales, marketing and Professional Services to deliver strategic initiatives that maximize joint business opportunities

- Broker Product Management and Engineering access to key SAP and AWS Product owners and experts and help build out a joint product roadmap

- Manage key performance indicators, including SAP and AWS Partner KPIs and Redwood-specific metrics

- Represent Redwood at SAP and AWS partner events, executive forums and industry conferences to enhance brand visibility and stakeholder engagement

- Coordinate with operations teams to manage deal registration, ensure alliance compliance and deliver impactful business reviews

- Track SAP and AWS ecosystem developments and market trends to proactively shape strategic direction and identify growth opportunities

***YOUR EXPERIENCE ***

- 7+ years of experience in enterprise technology ecosystems, partnerships or channel management

- 5+ years of experience in cloud partnerships, alliances or business development with proven SAP and/or AWS expertise

- Strong ability to operate within complex organizations and deliver results in cross-functional environments

- Established network and prior experience engaging SAP and/or AWS stakeholders

- Advanced business development and relationship management skills, including pipeline and partnership growth execution

- Excellent communication, presentation and executive influencing skills

- Highly organized, self-driven, and capable of working with minimal supervision in a fast-paced setting

- Professional fluency in English (written and spoken)

- Hands-on experience working within SAP or AWS or their partner ecosystems

- Familiarity with emerging technologies and cloud transformation best practices

If you like growth and working with happy, enthusiastic over-achievers, you'll enjoy your career with us!

*If you like growth and working with happy, enthusiastic over-achievers, you'll enjoy your career with us!*

**THE LEGAL BIT**
Redwood is an equal opportunity employer. Redwood prohibits unlawful discrimination based on race, colour, religion, sex, gender identity, marital or veteran status, age, national origin, ancestry, citizenship, physical or mental disability, medical condition, genetic information or characteristics (or those of a family member), sexual orientation, pregnancy or any other consideration made unlawful by regional or local laws. We also prohibit discrimination based on a perception that anyone has any of those characteristics or is associated with a person who has or is perceived as having any of those characteristics. All such discrimination is unlawful and will have a zero tolerance policy applied to it.

Redwood will comply with all local data protection laws, including GDPR when it comes to the handling and processing of personal data. Should you wish for us to remove your personal data from our recruitment database, please email us directly at -----

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
