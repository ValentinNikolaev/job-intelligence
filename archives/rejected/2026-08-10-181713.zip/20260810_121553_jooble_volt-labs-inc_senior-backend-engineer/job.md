# Senior Backend Engineer

Posted: 2026-08-03T00:00:00.0000000

## Rejection

- Category: stale
- Reason: published_at 2026-08-03T00:00:00.0000000 is older than 7 days

Role Description
We are hiring a **Senior **Back End **Engineer **to help architect and scale the core infrastructure powering Volt's messaging platform... ...platforms or automation systems


How We Work

~**Remote-**first team with high ownership and accountability

~Small...
