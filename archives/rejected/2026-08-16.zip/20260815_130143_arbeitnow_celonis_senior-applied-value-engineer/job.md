# Senior Applied Value Engineer

Posted: 2026-08-15T02:55:20Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Celonis is the global leader in Process Intelligence and the pioneer of Process Mining technology. As one of the world’s fastest-growing enterprise SaaS companies, we are changemakers pushing the boundaries of what’s possible. We invest heavily in advanced AI capabilities—specifically our Process Intelligence Graph—to turn data insights into immediate business action. We believe there is a massive opportunity to unlock global productivity and sustainability by placing intelligence at the core of every business process. Join our mission to make processes work for people, companies, and the planet.

**The Team:**

As an Senior Applied Value Engineer you push the envelope in solving mission-critical problems for our customers. You will work with our most strategic customers, understand their strategy and key challenges, and build Celonis solutions using cutting-edge AI technologies from market leaders such as Microsoft and OpenAI. With Celonis’ market-leading Process Intelligence (PI) Platform we feed operational context to AI so it understands our customers’ businesses and enables them to industrialize AI unlocking real ROI on AI deployments and at scale. There is no AI without PI. You will prototype these solutions, demonstrate their value to executives, and ensure successful implementation, adoption and value realization to increase Celonis' footprint at those customers..

**The Role:**

As an Senior Applied Value Engineer, responsibilities include translating customers’ objectives into value assessments or proof-of-value projects, building specific Celonis business cases and demos, running value workshops, and engaging with multiple senior stakeholders to deliver value driven results and secure long term partnership agreements. In collaboration with our partners and Celonis Services, you will drive measurable business impact across various processes and industries and accelerate the adoption of our platform. You will blend deep process and industry expertise with a proven consulting skill set with strong analytical skills at the forefront of one of the fastest-growing tech companies worldwide.

**The work you’ll do:**

- **AI Discovery & Solutioning:** Understand customers AI strategy and business critical challenges. As Celonis product & domain expert, find the best problem-solution fit and translate customer requirements into innovative solutions that move the needle

- **Identify & Frame Value:**
Discover and translate customers’ strategic priorities into high-impact Celonis use cases
Build demos and business cases, leveraging industry benchmarks and best practices in order to win new customers
Undertake Value Assessments or Proof-of-Value Projects and communicate the value opportunity and strategic roadmap to C-Level executives

- **Realize Value:**
Facilitate business value workshops and use Celonis to identify and qualify opportunities for process enhancement
Derive improvement measures in core business functions and initiate improvement actions and enterprise-wide change initiatives
Present results and realized value to senior management and C-level executives

- **Scale Value:**
Responsible for the end-to-end customer value journey, landing, expanding, adoption and renewing
Build a strategic expansion roadmap for customers embedding Celonis Process Intelligence as a strategic business transformation platform in their organization and therefore drive adoption and expansion
Provide feedback to our product development teams to enhance the Celonis platform and Apps based on new use case

**The qualifications you need:**

- **Live for Customer Value: 7+ **years of experience in an analytical role with the objective to demonstrate or secure value through business data analysis, business process improvement and respective Software deployment. Ideally in a customer-facing role in Solution Consulting, Sales Engineering or IT/Management Consulting with a Business Software / SaaS Provider or a Consultancy. Alternatively in an Inhouse role (e.g. Center of Excellence for Data Mining / Analytics / Intelligence) within an Enterprise.
Data, Analytics, Applications & IT: Good knowledge of Business Software / SaaS applications (e.g. SAP/ Oracle), experience with implementing RPA and/or BI Tools and/or building Dashboards, Apps and Action Flows. Hands-on Experience with Process Mining tools and technologies is preferred. Hands-on SQL experience and Python is preferred . Experience in collaborating with IT teams.

- **Process Improvement & Value Realization:** Experience in identifying business use cases for business process improvement and deploying improvement measures, being a change agent and training users/process owners to realize value. Domain and industry knowledge such as Supply chain, finance, CPG, BFSI, Manufacturing etc. would be a plus.

- **Project Management:** Experience in planning and managing project scopes, expectations and timelines. You will manage multiple projects across your aligned accounts that will be at different parts of the value journey. Also, you will leverage partners from the Celonis Ecosystem wherever possible.

- **Executive Stakeholder Management:** Experience in preparing and communicating (value) roadmaps and results to stakeholders and management, both internally and externally. Excellent communication and presentation skills in English.

**What Celonis can offer you:**

- Pioneer Innovation: Work with the global leader in Process Mining and the Process Intelligence Graph to shape the future of AI-driven business operations.

- Ownership from Day 1: Every full-time "Celonaut" is an owner, receiving Restricted Stock Units (RSUs) and merit-based refresh grants.

- Unrivaled Family Support: Benefit from our inclusive parental leave policy—24 weeks of fully paid leave for primary carers and 12 weeks for supporting carers, available from your first day of employment.

- Work-Life Integration: Enjoy Unlimited PTO (in applicable regions) and generous PTO globally, as well as a flexible hybrid work model that balances remote focus with vibrant office collaboration.

- Continuous Growth: Elevate your skills through our 70-20-10 learning framework, mentorship programs, and access to a dedicated learning platform.

- Holistic Well-being: Prioritize your health with subsidized Wellhub memberships, mental health counseling, and dedicated "Wellness Weeks" that prioritize work/life balance.

- Drive Sustainability: Participate in annual Impact Days, where you receive paid time off to volunteer for community and environmental causes with your local office, or virtually.

- Global Inclusion & Belonging: Find community through our Inclusion Think Tank and participate in our annual Inclusion Days, ensuring every voice is heard and valued.

- Value-Driven Impact: Join a mission-led organization where our core values—Live for Customer Value, The Best Team Wins, We Own It, and Earth Is Our Future—drive every decision.

**About Us:**

Celonis makes processes work — for people, companies, and the planet. Powered by process mining and AI, the Celonis Process Intelligence Platform integrates process data and business context to create a living digital twin of business operations. We enable thousands of companies worldwide to understand how their business actually runs and, together with their partners, build intelligent solutions that transform and continuously improve the way they operate — unlocking billions in value. Celonis is headquartered in Munich, Germany, and New York City, USA, with more than 20 offices worldwide.

Get familiar with the Celonis Process Intelligence Platform by watching this [video](https://academy.celonis.com/learn/video/discover-the-ems).

**Celonis Inclusion Statement:**

At Celonis, we believe our people make us who we are and that “The Best Team Wins”. We know that the best teams are made up of people who bring different perspectives to the table. And when everyone feels included, able to speak up and knows their voice is heard - that's when creativity and innovation happen.**
**

**Your Privacy:**

Any information you submit to Celonis as part of your application will be processed in accordance with Celonis’ [Accessibility and Candidate Notices](https://www.celonis.com/careers/candidate-notices)

By submitting this application, you confirm that you agree to the storing and processing of your personal data by Celonis as described in our [Privacy Notice for the Application and Hiring Process](https://www.celonis.com/careers/privacy-notice/).

Please be aware of common job offer scams, impersonators and frauds. Learn more [here](https://www.celonis.com/careers/fraud-alert/).

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
