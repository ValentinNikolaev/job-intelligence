# Proposal Manager (Global)

Posted: 2026-08-15T11:40:22Z

## Rejection

- Category: tech_stack
- Reason: role does not mention Go/Golang or PHP

## About ElevenLabs

ElevenLabs is an AI research and product company transforming how we interact with technology.

We launched in January 2023 with the first human-like AI voice model. Today, we serve millions of users and thousands of businesses - from fast-growing startups to large enterprises like Deutsche Telekom and Meta. Our investors are some of the world's most prominent, including Andreessen Horowitz, ICONIQ Growth and Sequoia. We've raised $781M in funding and our last valuation was $11B - multiples of 11, always.

We have expanded from voice into three main platforms:

-

ElevenAgents enables businesses to deliver seamless and intelligent customer experiences, with the integrations, testing, monitoring, and reliability necessary to deploy voice and chat agents at scale.

-

ElevenCreative empowers creators and marketers to generate and edit speech, music, image, and video across 70+ languages.

-

ElevenAPI gives developers access to our leading AI audio foundational models.

Everything we do is the result of the creativity and commitment of our team - builders doing the best work of their lives. We are researchers, engineers, and operators. IOI medalists and ex-founders. If you want to work hard and create lasting positive impact, we want to hear from you.

## How we work

-

**High-velocity: **Rapid experimentation, lean autonomous teams, and minimal bureaucracy.

-

**Impact not job titles: **We don’t have job titles. Instead, it’s about the impact you have. No task is above or beneath you.

-

**AI first:** We use AI to move faster with higher-quality results. We do this across the whole company—from engineering to growth to operations.

-

**Excellence everywhere: **Everything we do should match the quality of our AI models.

-

**Global team: **We prioritize your talent, not your location.

## What we offer

-

**Innovative culture:** You’ll be part of a generational opportunity to define the trajectory of AI, surrounded by a team pushing the boundaries of what’s possible.

-

**Growth paths: **Joining ElevenLabs means joining a dynamic team with countless opportunities to drive impact - beyond your immediate role and responsibilities.

-

**Learning & development**: ElevenLabs proactively supports professional development through an annual discretionary stipend.

-

**Social travel**: We also provide an annual discretionary stipend to meet up with colleagues each year, however you choose.

-

**Annual company offsite: **Each year, we bring the entire team together in a new location - past offsites have included Croatia and Italy.

-

**Co-working**: If you’re not located near one of our main hubs, we offer a monthly co-working stipend.

**About the role**

ElevenLabs is expanding globally, and some of our largest enterprise opportunities are won through complex procurement processes. We're building the RFP Engine to own how we compete in them — a new function at the heart of how ElevenLabs pursues its most strategic deals. As a Proposal Manager, you'll be one of its founding members, owning strategic pursuits in your region from qualification through submission: decoding what evaluators actually want, shaping the response strategy with account teams, coordinating input across sales, solutions engineering, legal, and security, and driving every submission to an exceptionally high bar — on time, every time.

You'll run pursuits through an AI-first system and help make it better with every cycle. Automation handles the mechanical work — first drafts, compliance checks, content retrieval — so your judgment goes where it matters: positioning, differentiation, and quality. When you spot work being repeated, you'll help systematise it, turning what you learn on each bid into templates, content, and process the whole company benefits from.

We think the right person has lived complex enterprise bids and knows the difference between a compliant response and a winning one. You write and edit exceptionally well, you're calm and decisive coordinating many contributors against a hard deadline, and you'd rather build the machine than crank the handle.

**Requirements**

-

A track record managing complex enterprise RFP or bid responses end-to-end, from qualification through submission, ideally at a technology company

-

A builder's approach to AI and automation: you use AI fluently in your own work, you've shipped internal tooling or workflows (or partnered closely with engineers to do so), and you treat repeated manual effort as a design flaw

-

Exceptional writing and editing: you turn technical and commercial input from many contributors into clear, compliant, persuasive responses

-

Strong project management under deadline pressure — running contributors, review cycles, and sign-offs across functions and timezones without dropping quality

-

Commercial instincts: you can read scoring criteria, spot what will differentiate a response, and flag pursuits that aren't worth the effort

Bonus: additional languages beyond English; experience with security or compliance questionnaires; a technical or pre-sales background.

**Growth Potential**

We believe in hiring the best talent in the world to look make an impact in the right role at the right time. At ElevenLabs, strong performance creates opportunities for growth. Here are some of the career paths you can expect after excelling in this role:

-

Leading regional proposals capacity as pursuit volume grows across markets

-

Specialising in bid strategy on our most strategic global pursuits

**Location**

We're hiring for this role in two regions. This role is remote-first and can be executed from anywhere in the United States (West Coast preferred) or in EMEA. If you prefer, you can work from our growing number of offices, including in San Francisco, London, Dublin, or Warsaw.

We are an equal opportunity employer and do not discriminate on the basis of race, religion, national origin, gender, sexual orientation, age, veteran status, disability or other legally protected statuses.

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
