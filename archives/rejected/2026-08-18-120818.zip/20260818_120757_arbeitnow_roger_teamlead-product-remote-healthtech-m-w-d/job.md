# Teamlead Product - Remote - Healthtech (m/w/d)

Posted: 2026-08-18T10:00:28Z

## Rejection

- Category: tech_stack
- Reason: role does not mention Go/Golang or PHP

In Deutschland geben Patienten jährlich 30 Milliarden EUR beim Zahnarzt aus. Trotz dieser Marktgröße arbeiten viele Praxen noch immer mit veralteter Offline-Software aus den 80er Jahren. **Roger ist hier, um das zu ändern**.

**Unsere Mission:** Zahnarztpraxen mit unserem virtuellen KI-Assistenten Roger zu revolutionieren. Unsere Software transformiert Behandlungsplanung und Patientenkommunikation, steigert Effizienz und Umsatz und vereinfacht den Praxisalltag für Zahnärzt:innen und ihre Teams.

Wenn du technologiebegeistert bist, Verantwortung übernehmen willst und in einem schnell wachsenden Umfeld wirklich etwas bewegen möchtest, bist du bei Roger richtig.

## Aufgaben

- Features zur Optimierung des Praxisalltags entwickeln: Deine Hauptaufgabe besteht darin, neue Features zu konzipieren und umzusetzen, die den Arbeitsalltag in Arztpraxen erleichtern.

- Praxisverwaltungssysteme (PMS) verstehen und analysieren: Du führst Analysen und Reverse Engineering der Praxisverwaltungssysteme durch.

- Datenabgleich und Nutzerfeedback einholen: Durch den Abgleich von Datenstrukturen mittels SQL und das Einholen von direktem Nutzerfeedback gestaltest du praxisnahe, bedarfsgerechte Lösungen. Ein umfassendes Verständnis der medizinischen Realität wird dir helfen, passgenaue Features zu entwickeln.

- Als Kommunikationsschnittstelle zwischen Business und Technik agieren: Du bist das Bindeglied zwischen Produktmanagement und technischer Entwicklung.

- Enge Zusammenarbeit mit unserem CEO

## Qualifikation

- Product Management: Du kennst die Ins und Outs, wenn es darum geht Produkte zu bauen die Kunden begeistern

- Abgeschlossenes Studium, idealerweise im medizinischen, wirtschaftlichen oder IT-Bereich.

- 2-3 Jahre praktische Erfahrung als (Senior) Product Manager:in in einem Healthtech Start-up/ Scale-up

- Sehr gutes technisches Know-how um Produktanforderungen an das Engineering Team weiterzugeben

- Wachstumsdrang/Growth Mindset: Tiefe Verpflichtung zu persönlichem und beruflichem Wachstum, immer offen für Feedback und neue Lernmöglichkeiten.

- Persönliche Fähigkeiten: Analytisches und strukturiertes Arbeiten, Eigeninitiative, selbstständige Problemlösung, Lernbereitschaft und Freude an der Arbeit im Team

- AI-First-Mentalität

- Sprachkenntnisse: Sehr gute Deutsch- und Englischkenntnisse.

**Nice to have:**

- SQL-Kenntnisse

- BigQuery

- Führungserfahrung

## Benefits

- Karrierechance

- Lebendige Kultur: Tauche ein in eine Kultur mit tatsächlich flachen Hirarchien, die Innovation, Teamarbeit und Spaß bei der Arbeit feiert.

- 100% Remote und flexible Arbeitszeiten: Arbeite vollständig von zu Hause und gestalte deine Arbeitszeiten flexibel nach deinen Bedürfnissen.

Bewirb Dich jetzt bei Roger und teile uns Dein frühestmögliches Startdatum mit. Wir können es kaum erwarten, Dich kennen zu lernen und Dein Potenzial zu entfesseln!

Falls du nicht alle geforderten Erfahrungen mitbringst – kein Problem! Wenn du motiviert bist und Lust hast, dich im Bereich Product Management weiterzuentwickeln, freuen wir uns trotzdem auf deine Bewerbung.

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
