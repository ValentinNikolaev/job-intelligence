# Partner Manager Incentives (all genders)

Posted: 2026-08-18T10:30:31Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Du erkennst Potenziale im Markt, baust starke Partnerschaften auf und bewegst dich sicher zwischen Akquise, Verhandlung und operativer Umsetzung? Dann werde Teil von BONAGO und gestalte den Bereich Incentives aktiv mit. In dieser Rolle entwickelst du unser Partnernetzwerk im B2B-Gutscheinmarkt weiter, bringst neue Kooperationen auf den Weg und sorgst dafür, dass aus guten Ideen erfolgreiche, nachhaltige Partnerschaften werden.

## Aufgaben

- Im B2B-Gutscheinmarkt identifizierst und akquirierst du potenzielle Partner und baust unser Netzwerk gezielt weiter aus

- Von der ersten Abstimmung bis zur technischen Umsetzung begleitest du Partnerschaften systemseitig und koordinierst gemeinsam mit den Partnern die Entwicklung direkter Schnittstellenlösungen

- Du verhandelst Konditionen und Rabatte

- Auch die Erstellung und Prüfung von Partnerverträgen gehört zu deinem Verantwortungsbereich

- Mit einem guten Gespür für Trends, Wettbewerb und Marktpotenziale analysierst du die Branche/ Gutescheinmarkt

- Du entwickelst den Bereich strategisch weiter und steuerst Projekte eigenverantwortlich

## Qualifikation

- Du hast eine abgeschlossene kaufmännische Ausbildung oder ein Studium mit Wirtschaftsschwerpunkt bzw. im Bereich Kommunikationswissenschaften

- Mehrjährige Berufserfahrung bringst du bereits mit — idealerweise im Handel, Versandhandel oder in vergleichbaren Branchen

- Im Partnermanagement konntest du bereits fundierte Erfahrung sammeln, bestenfalls im Incentive- oder B2B-Gutscheinmarkt

- Verhandlungsgeschick, Durchsetzungsstärke sowie ein sicherer Umgang mit IT-Systemen, CRM-Tools und digitalen Anwendungen zeichnen dich aus

- Eine selbstständige, strukturierte und verantwortungsbewusste Arbeitsweise sowie sehr gute Deutsch- und Englischkenntnisse runden dein Profil ab

## Benefits

- Arbeitsumfeld & Organisation: Du arbeitest gerne in unserem Büro am Standort München und schätzt den persönlichen Austausch im Team. Ergänzend kannst du einen Tag pro Woche im Homeoffice arbeiten. Deine Arbeitszeit gestaltest du eigenverantwortlich im Rahmen unserer betrieblichen Anforderungen

- Workation: Nach Absprache sind bis zu 4 Wochen EU-Workation pro Jahr möglich. Wenn du dich für Fuerteventura entscheidest, unterstützen wir dich zusätzlich mit Flug, Unterkunft und Mietwagen

- Gestaltungsfreiheit & Verantwortung: Bei uns übernimmst du Verantwortung, bringst deine Ideen aktiv ein und arbeitest in einem Umfeld mit kurzen Entscheidungswegen und ohne starre Prozesse

- Moderner Standort: Freu dich auf einen ergonomischen Arbeitsplatz in München mit höhenverstellbarem Schreibtisch, viel Grün durch Pflanzen sowie einer offenen Atmosphäre und kurzen Entscheidungswegen

- Attraktive Benefits: Monatliche Einzahlung auf deine MitarbeiterCARD, Zuschüsse für Mobilfunk & Internet, Bike-Leasing, Auto-Abo, Altersvorsorge & mehrBitte beachte: Das Bewerbungsverfahren wird zentral über die ValueNet Group koordiniert.

Wir freuen uns über Deine Bewerbung!

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
