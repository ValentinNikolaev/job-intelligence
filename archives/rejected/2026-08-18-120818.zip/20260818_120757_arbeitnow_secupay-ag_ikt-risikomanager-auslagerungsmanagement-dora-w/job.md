# IKT-Risikomanager / Auslagerungsmanagement DORA (W/M/D)

Posted: 2026-08-18T09:00:28Z

## Rejection

- Category: language_requirement
- Reason: hard German language requirement without English green light

**Festanstellung** **| Vollzeit | Hybrid | remote** **| Pulsnitz**

Gestalten Sie die Weiterentwicklung unseres IKT-Risikomanagements und Auslagerungsmanagements aktiv mit und schaffen Sie die Grundlage für transparente Risiken, sichere Dienstleistersteuerung und digitale operationale Resilienz.

## Aufgaben

- Sie steuern IKT-Risikomanagement und Auslagerungsmanagement nach DORA, ZAG und BaFin-Anforderungen

- Sie bewerten IKT-Risiken, IKT-Drittparteienrisiken und Auslagerungen risikoorientiert

- Sie koordinieren Risikoanalysen, Schutzbedarfsbewertungen, Kontrollbewertungen und Maßnahmen zur Risikobehandlung

- Sie bewerten Dienstleisterrisiken, Exit-Fähigkeit, Notfallvorsorge und Business-Continuity-Anforderungen

- Sie begleiten Prüfungen, Audits und regulatorische Anfragen mit prüfungssicheren Nachweisen

- Sie bewerten IKT-Vorfälle, Business-Continuity-Anforderungen und Resilienztests aus Risikoperspektive

- Sie erstellen Berichte und Entscheidungsvorlagen für Fachbereiche, Kontrollfunktionen, Gremien und Geschäftsleitung

## Qualifikation

- Sie bringen fundierte Erfahrung im IKT-Risikomanagement, Auslagerungsmanagement, Risikomanagement, Compliance, Informationssicherheit oder IT-Governance mit

- Sie kennen regulatorische Anforderungen wie DORA, ZAG, EBA-Leitlinien, BaFin-Vorgaben sowie Datenschutzanforderungen

- Sie verstehen IT-Prozesse, Informationssicherheit, Business Continuity, Incident Management und digitale operationale Resilienz

- Sie bewerten Risiken strukturiert und übersetzen regulatorische Anforderungen in praxistaugliche Prozesse, Kontrollen und Entscheidungsvorlagen

- Sie arbeiten idealerweise sicher mit Jira, Jira Service Management, Confluence oder vergleichbaren Kollaborations- und Ticket-Systemen

- Sie verfügen über fließende Deutschkenntnisse und sehr gute Englischkenntnisse

## Benefits

- Vertrauen! Arbeitszeit selbstverantwortlich gestaltbar

- Die Mischung macht‘s! Mobiles Arbeiten, mit gelegenlichen Treffen im Büro

- Geschichte! Arbeitsplatz in Pulsnitz in einem historischen Gebäude mit moderner Ausstattung

- Lebenslanges Lernen! Bedarfsorientierte Zertifizierungen und Weiterbildungen

- Kultur! Wertschätzendes Miteinander, offene Kommunikation und dynamische Teams

- Work-Life-Balance! 30 Tage Basis-Urlaub

Sie möchten regulatorische Anforderungen nicht nur erfüllen, sondern aktiv in wirksame, praxistaugliche Prozesse übersetzen? Dann freuen wir uns auf Ihre vollständigen Bewerbungsunterlagen inklusive Gehaltsvorstellung und frühestem Starttermin.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
