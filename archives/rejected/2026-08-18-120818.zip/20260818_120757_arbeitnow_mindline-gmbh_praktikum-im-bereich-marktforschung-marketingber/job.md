# Praktikum Im Bereich Marktforschung/Marketingberatung

Posted: 2026-08-18T10:30:30Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Du gehst den Dingen gerne auf den Grund? Du hast Spaß, Kunden dabei zu helfen, die erfolgversprechendsten Produktentwicklungen auszuwählen? Dann bist du bei uns genau richtig! Wir suchen am Standort Hamburg zum nächstmöglichen Zeitpunkt für mindestens drei Monate Verstärkung durch eine:nPraktikant:in (m/w/d) im Bereich Consumer Goods (FMCG) and Retail

## Aufgaben

Deine Aufgaben:

Unterstützung der Projektleiter:innen bei allen Projektschritten, wie z.B.

- Fragebogenerstellung

- Programmierung mithilfe unserer DIY-Software smoove

- Qualitätskontrolle, u.a. durch Linkchecks, Datencleaning

- Datenauswertung und –analyse

- Erstellung von Dashboards und PowerPoint-Berichten

- Dienstleisterkommunikation

## Qualifikation

Dein Profil:

- Laufendes Studium, idealerweise mit der Fachrichtung Marktforschung, Konsumentenpsychologie, Wirtschafts-, Sozialwissenschaften oder ähnlichen Disziplinen

- Ausgeprägtes Interesse an Marktforschung und Datenanalyse

- Logisch-analytisches Verständnis und Spaß am Umgang mit Zahlen

- Eigeninitiative, Organisationstalent, Teamgeist und Sorgfalt

- Sicherer Umgang mit MS-Office-Paket

## Benefits

Unser Angebot:

- Einblick in vielfältige Marktforschungsprojekte und -methoden, wie z.B. Werbemessung, Produkttests, Conjoints – für namhafte Kunden, sowohl national als auch international

- Praxiserfahrung in einem renommierten Marktforschungsinstitut

- Möglichkeit, andere Bereiche, wie z.B. unsere qualitative Abteilung, kennenzulernen

- Regelmäßig stattfindender Stammtisch für neue Mitarbeiter:innen und weitere After-Works

- Kaffee-Vollautomat, Obst und Süßigkeiten für den kleinen Energieschub zwischendurch, aber auch Nudeln und Pesto für den großen Hunger frei Haus

- Höhenverstellbare Schreibtische, wöchentlicher Yoga-Kurs, grüne Innenhöfe, Kickertisch und Xbox für jegliche Art der Entspannung zwischendurch

- HomeOffice-Möglichkeiten

- 1.200 EUR pro Monat + Deutschlandticket bei einer 38,5 Stundenwoche

Bereit, deine Fähigkeiten in der Marktforschung zu entfalten? Dann sende deine aussagekräftige Bewerbung inkl. Angaben zu gewünschtem Beginn, Dauer und der Art des Praktikums (verpflichtend oder freiwillig) per E-Mail an Amina Rezevcanin. Wir freuen uns darauf, dich kennenzulernen und gemeinsam neue Erkenntnisse zu gewinnen!

Über uns:

mindline ist ein renommiertes Full-Service Institut für Marktforschung und Marketingberatung mit Standorten in Hamburg, Berlin und Nürnberg. Als eines der Top10 Marktforschungsinstitute in Deutschland betreuen über 150 Mitarbeiter:innen führende sowie aufstrebende Unternehmen national und global.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
