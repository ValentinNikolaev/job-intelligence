# Teamleiter:in Field Service (m/w/d)

Posted: 2026-08-18T09:30:35Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

termios macht Heizen in Wohn- und Gewerbeimmobilien smarter und klimafreundlicher. Unser Thermostat spart spürbar Energie und hilft Asset Managern, Wohnungsunternehmen und Eigentümern, ihre ESG- und Net-Zero-Ziele zu erreichen.

termios ist ein 2023 gegründetes Joint-Venture von mantro als Company Builder, dem sauerländischen Familienunternehmen Oventrop und der Düsseldorfer LEG Immobilien SE. Als Technologieunternehmen entwickeln wir grüne Lösungen rund um Heizen, Nachhaltigkeit und ESG für Wohnimmobilien.

## Aufgaben

Wir suchen **zum nächstmöglichen Zeitpunkt** am **Standort Düsseldorf** eine:n

**Teamleiter:in Field Service (d/w/m)**

Als Teamleiter:in Field Service (d/w/m) führst du unser Außendienst-Team – bestehend aus internen Technikern und externen Installations-Dienstleistern – und verantwortest die Planung, Steuerung und Qualität der Thermostat- und Gatewayinstallationen. Du verbindest technisches Verständnis für Heizungen und Anlagemechanik mit kaufmännischer Stärke in Einsatzplanung, Dienstleistersteurung, Budget und Reporting.

- Du führst und entwickelst unser internes Außendienst-Team und koordinierst und externen Installationspartner.

- Von Kapazitäten und Routen bis zur Umsetzung vor Ort planst und steuerst du unsere Installations- und Serviceeinsätze.

- Du stellst sicher, dass Thermostate und Gateways sicher und termingerecht installiert und die Installationen vollständig dokumentiert werden.

- Qualität, Kosten und die wichtigsten KPIs behältst du im Blick. Bei Abweichungen leitest du passende Maßnahmen ein und übernimmst die Abstimmung in Eskalationsfällen.

- Gemeinsam mit Sales, Customer Success und unseren Partnern entwickelst du unsere Field-Service-Prozesse weiter.

## Qualifikation

- Du bringst mehrjährige Erfahrung in der Führung und Koordination technischer Teams sowie in der Planung und Steuerung von Service- oder Installationseinsätzen mit

- Die zusammenarbeit mit internen Teams und externen Dienstleistern oder Partnern ist dir vertraut, auch bei kurzfristigen Änderungen und erhöhtem Steuerungsbedarf

- Du verfügst über technisches Verständnis für Heizungsanlagen, Thermostate und Ventile im SHL- oder vergleichbaren gebäudetechnischen Umfeld

- Kapazitäten, Budgets, Kosten, Qualität, Termine und relevante Kennzahlen kannst du zuverlässig steuern

- Eine strukturierte, lösungsorientiere Arbeitsweise sowie klare und verbindliche Kommunikation mit Technikern, Dienstleistern, Kunden und internen Schnittstellen zeichnen dich aus

- Digitale Einsatz-, Ticket- und Dokumentationstools sowie gängige Office-Anwendungen nutzt du sicher

- Du besitzt einen Führerschein der Klasse B und bist zu gelegentlichen Reisen bereit.

Eine technische Ausbildung im Bereich SHK, Heizungsbau, Elektro- oder Gebäudetechnik, idealerweise mit Meister- oder Technikerabschluss, ist von Vorteil. Erfahrung mit smarten Thermostaten, Gateways, IoT-Komponenten oder Qualitäts- und Sicherheitsmanagement runden dein Profil ab.

## Benefits

- Flexibler Arbeitsplatz und flexible Arbeitszeiten, damit Dein Job zu Deinem Leben passt

- Ein agiles Team mit flachen Hierarchien, offener Kommunikation und kurzen Entscheidungswegen

- Regelmäßige Mitarbeiter- und Teamevents

- Gestaltungsfreiraum für die Umsetzung Deiner eigenen Ideen ab dem ersten Tag

- Ein modernes Büro mit guter Erreichbarkeit, E-Ladestation & Parkplätzen

- 30 Tage bezahlter Urlaub

- Eine wettbewerbsfähige Vergütung und weitere Mitarbeiter-Benefits

Wir freuen uns auf deine Bewerbung!

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
