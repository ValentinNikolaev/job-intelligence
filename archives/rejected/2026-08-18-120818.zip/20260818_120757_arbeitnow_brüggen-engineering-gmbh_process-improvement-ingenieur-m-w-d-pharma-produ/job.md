# Process Improvement Ingenieur (m/w/d) Pharma / Produktionsmanagement in Mannheim (1711)

Posted: 2026-08-18T09:00:28Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**Ihre Karriere in der Optimierung pharmazeutischer Herstellungsprozesse.**

Mit BRÜGGEN ENGINEERING übernehmen Sie Verantwortung für anspruchsvolle Verbesserungsprojekte in einem regulierten Produktionsumfeld. Sie steigern die Effizienz technischer Prozesse, reduzieren Ausschuss und setzen etablierte Lean- und Six-Sigma-Methoden ein, um nachhaltige Optimierungen in der pharmazeutischen Produktion zu erreichen.

## Aufgaben

- **Projektleitung:** Sie leiten interdisziplinäre Projekte im Produktionsumfeld eigenverantwortlich und wirken aktiv an deren Umsetzung mit

- **Prozessverbesserung:** Sie analysieren bestehende Abläufe und setzen strukturierte Methoden zur kontinuierlichen Optimierung ein

- **Produktivität:** Sie entwickeln Maßnahmen zur Steigerung der Produktionseffizienz und reduzieren systematisch Prozessverluste und Ausschuss

- **Lean Management:** Sie wenden Lean- und Six-Sigma-Methoden gezielt auf technische und organisatorische Fragestellungen an

- **Problemlösung:** Sie bearbeiten komplexe technische Abweichungen mithilfe strukturierter Problemlösungsprozesse und fundierter Ursachenanalysen

- **Umsetzung:** Sie koordinieren Verbesserungsmaßnahmen und stellen deren nachhaltige Implementierung im Produktionsprozess sicher

## Qualifikation

- **Qualifikation:** Abgeschlossenes natur- oder ingenieurwissenschaftliches Studium oder vergleichbare Qualifikation

- **Projektmanagement:** Fundierte Kenntnisse in der methodischen Steuerung, Koordination und Umsetzung technischer Projekte

- **Methodenkompetenz:** Nachweisbare Erfahrung mit Lean Management und Six Sigma

- **Produktionsumfeld:** Hohe Affinität zu technischen Anlagen und Produktionsprozessen in einem GMP-regulierten Umfeld

- **Arbeitsweise:** Sorgfältige, prozessorientierte und eigenverantwortliche Herangehensweise mit ausgeprägter Lösungs-, Qualitäts- und Compliance-Orientierung

- **Zertifizierung:** Lean- oder Six-Sigma-Zertifizierung, beispielsweise Green Belt oder Black Belt, von Vorteil

## Benefits

- **Attraktive Konditionen:** Freuen Sie sich auf eine unbefristete Vollzeitstelle bei BRÜGGEN ENGINEERING mit einer Vergütung, die Ihre Expertise würdigt

- **Effiziente Produktion:** Gestalten Sie anspruchsvolle Optimierungsprojekte im pharmazeutischen Produktionsmanagement und verbessern Sie Prozesse nachhaltig

- **Dynamisches Team:** Werden Sie Teil eines Teams, das Wert auf persönliches Wachstum und eine Kultur der Unterstützung und Förderung legt

Wir freuen uns auf Ihre aussagekräftigen Bewerbungsunterlagen mit Angabe Ihres frühesten Starttermins und Ihrer Gehaltsvorstellung.

Ihr Ansprechpartner für Ihre Bewerbung ist:

Herr Dipl.-Wirt.-Ing. Thorsten Schermann

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
