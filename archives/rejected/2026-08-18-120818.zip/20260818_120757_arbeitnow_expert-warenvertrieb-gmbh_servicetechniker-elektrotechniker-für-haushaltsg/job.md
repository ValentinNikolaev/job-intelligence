# Servicetechniker / Elektrotechniker für Haushaltsgeräte (m/w/x)

Posted: 2026-08-18T11:00:23Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Die expert ESC GmbH ist mit ihren Elektronikfachmärkten in Rangsdorf, Fürstenwalde, Königs Wusterhausen, Hoyerswerda, Bautzen, Bischofswerda, Görlitz und Cottbus ansässig und fest in den Regionen verwurzelt.

Auf rund 8000 Quadratmetern Ausstellungsfläche bietet ESC das gesamte Produktspektrum der Haushalts- und Unterhaltungselektronik – sowie individuelle Beratung und besten Service.

Insgesamt sind 150 Mitarbeitende und 20 Auszubildende im Unternehmen beschäftigt.

Wir suchen dich in **Rangsdorf** und **Königs Wusterhausen** als:

**Servicetechniker / Elektrotechniker für Haushaltsgeräte (m/w/x)- Quereinstieg möglich**

## Aufgaben

- Du bist verantwortlich für die Tourenplanung und Nachbereitung

- Du lieferst, installierst und reparierst Elektro-Haushaltsgeräte beim Kunden zuhause

- Zu deinen Aufgaben gehören die Kundenbetreuung und die Beratung bei Neuinstallationen und Reparaturen

## Qualifikation

- Wünschenswert, aber kein Muss: Berufserfahrung als Auslieferungs-/Servicefahrer oder eine Ausbildung im technischen Bereich, aber wir sind auch offen für **Quereinsteiger** (m/w/x), die motiviert sind, etwas Neues zu lernen

- Führerschein Klasse B

- Technische Kenntnisse sowie handwerkliches Geschick (E-Schein von Vorteil)

- Gute Deutschkenntnisse in Wort und Schrift

- Eigenverantwortliches Arbeiten und körperliche Belastbarkeit

## Benefits

- Attraktive **Mitarbeiterrabatte**

- **Kostenfreie** Getränke

- **Kostenfreie** Parkmöglichkeiten direkt am Markt

- Gemeinsame **Weihnachtsessen und Feste**

- Umfangreiche Weiterbildungsmöglichkeiten

- Abwechslungsreiche Arbeitstage

- Eine detaillierte Einarbeitung- ganz auf dich abgestimmt

- Gute Aufstiegsmöglichkeiten

- **Prämiensystem** mit hohen Verdienstmöglichkeiten

- Betriebliches **Gesundheitskonto**

Wir sind expert. Seit über 60 Jahren dein Technik-Experte von nebenan. Überall in Deutschland. Genauer gesagt an 396 Standorten mit 199 selbstständigen Unternehmern, die dort ihre Elektronikfachmärkte betreiben. Und das offenbar so gut, dass wir uns Deutschlands erfolgreichste Fachhandelskooperation nennen dürfen. Möchtest du Teil der expert-Familie werden und unser Team mit deinen Fähigkeiten verstärken?**Dann freuen wir uns auf deine Bewerbung bei Herrn Perlow unter der 0160-96444331 oder online.** Falls du dich nicht online bewerben möchtest, kannst du uns deine Unterlagen auch per Post schicken. Verwende dafür bitte folgende Adresse: expert Warenvertrieb GmbH - Bayernstraße 4 - 30855 Langenhagen

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
