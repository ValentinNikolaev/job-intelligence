# Freelancer Frontend-Entwickler (m/w/d) WinUI / XAML / .NET

Posted: 2026-08-18T07:01:07Z

## Rejection

- Category: language_requirement
- Reason: hard German language requirement without English green light

**Gestalte die Zukunft der industriellen Bildverarbeitung mit uns**

Wir suchen einen erfahrenen Frontend-Entwickler (m/w/d) auf Freelance-Basis, der die Weiterentwicklung unseres VisionCommanders vorantreibt. Gemeinsam mit unserem engagierten Software-Team entwickelst Du moderne Windows-Desktop-Anwendungen und anspruchsvolle Benutzeroberflächen für innovative industrielle Bildverarbeitungslösungen. Dabei arbeitest Du eng mit unseren Entwicklern sowie dem Teamleiter Softwareentwicklung zusammen.

**Deine Aufgaben**

- Entwicklung moderner Frontend-Komponenten mit WinUI 3

- Umsetzung ansprechender UI-Designs basierend auf dem Fluent-2-Designsystem

- Erstellung wiederverwendbarer Frontend-Bausteine

- Mitwirkung bei der Weiterentwicklung von UX- und UI-Konzepten

- Entwicklung komplexer grafischer Komponenten, beispielsweise für Visualisierungen und Editoren

- Umsetzung einer modernen, skalierbaren MVVM-Architektur

- Sicherstellung einer performanten und responsiven Benutzeroberfläche

- Eigenverantwortliche Planung und Umsetzung von Arbeitspaketen

- Enge Zusammenarbeit mit dem gesamten Softwareentwicklungsteam

**Das bringst Du mit**

- Abgeschlossenes Studium der Informatik oder eine vergleichbare Qualifikation

- 3 bis 5 Jahre Berufserfahrung in der Softwareentwicklung mit C# und .NET

- Fundierte Erfahrung in der Entwicklung moderner Windows-Desktop-Anwendungen

- Hervorragende Kenntnisse in WinUI 3 und XAML

- Sehr gute Erfahrung mit MVVM-Architekturen

- Verhandlungssichere Deutschkenntnisse auf C2-Niveau

**Deine Vorteile**

- Erfahrung mit grafischen Desktop-Anwendungen und Visualisierungskomponenten

- Know-how in modernen Softwarearchitekturen, automatisierten Tests und GraphQL

- Ein Gespür für UX/UI-Design und benutzerfreundliche Bedienkonzepte

**Unser Technologie-Stack**

- C#

- .NET

- WinUI 3

- XAML

- Fluent 2

- MVVM

- .NET Community Toolkit

**Rahmenbedingungen**

- Freelance-Tätigkeit mit flexibler Stundenzahl (ca. 20 bis 40 Stunden pro Woche)

- Möglichkeit zur langfristigen Zusammenarbeit

- Start nach Absprache

**Interesse geweckt?**

Dann freuen wir uns auf Deine Bewerbung! Bitte teile uns Deine Verfügbarkeit, Deinen Stundensatz sowie relevante Projektreferenzen mit.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
