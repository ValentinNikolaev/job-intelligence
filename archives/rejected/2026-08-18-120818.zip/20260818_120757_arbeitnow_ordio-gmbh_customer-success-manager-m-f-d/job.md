# Customer Success Manager (m/f/d)

Posted: 2026-08-18T09:30:35Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**Worldwide, 80% of all employees do not work at a desk.**

**With Ordio** 💙, we offer an all-in-one software solution built specifically for these employees, helping companies organize their daily work and make operations more efficient for everyone involved.

As a **Customer Success Manager at Ordio 💙**, you will own the success and commercial development of a portfolio of customers.

Your main goal is to **drive Net Revenue Retention (NRR)** by ensuring customers successfully adopt Ordio, renew their contracts, expand into additional locations, and use more of our products over time.

You will build strong customer relationships, identify growth opportunities early, and work closely with Sales, Product and Support to increase the long-term value of every account.

## Tasks

🚤 **Onboarding & Activation:** You guide new customers quickly to their first “aha moment” by managing data import, setup and training so they feel confident using Ordio within the first two months.

📈 **Net Revenue Retention:** You take ownership of retaining and growing your customer portfolio, with a clear focus on increasing **NRR through renewals, upselling and expansion**.

🚀 **Upsell & Cross-Sell:** You identify commercial opportunities such as Payroll Plus, additional modules, seats or services and actively drive expansions and upgrades to completion.

🔎 **Renewals & Churn Prevention:** You proactively manage renewals, identify churn risks early and create clear action plans to retain and develop customers.

🗺️ **Account Development:** You build structured account plans for your customers, understand their growth plans and identify where Ordio can support them further.

📊 **Pipeline & Forecasting:** You maintain your renewal and expansion pipeline in the CRM, qualify opportunities and provide reliable forecasts for upsell, expansion and renewals.

🤝 **Close collaboration with Sales & Product:** You ensure a smooth handover from Sales to Customer Success and work closely with Sales on account expansion opportunities. You also communicate customer feedback and feature requests to the Product team.

💡 **Product Adoption:** You proactively help customers get more value from Ordio by increasing adoption of relevant features, modules and workflows.

☎️ **Professional Communication:** You communicate confidently via email, telephone, chat and video, maintain clear follow-up routines and document customer activity and commercial opportunities accurately in the CRM.

## Requirements

🇩🇪 German speaking (C1+)

💪 **Previous experience in Customer Success within a SaaS or B2B software company.**

📈 Experience managing and developing an existing customer portfolio, ideally with responsibility for metrics such as **Net Revenue Retention, Gross Revenue Retention, renewals, churn or expansion revenue**.

🚀 Proven experience identifying and closing **upsell, cross-sell or account expansion opportunities**.

🌍 Ideally, experience working with customers that operate across **multiple locations, sites, regions or business units**.

🤝 Experience building strong relationships with customers and developing accounts over the long term.

🎯 A commercial mindset: you enjoy helping customers succeed while also identifying opportunities to grow the partnership.

🔎 You are proactive and comfortable identifying customer risks and commercial opportunities before they become obvious.

😌 A customer-oriented attitude with a friendly, professional and solution-focused style.

🦮 You enjoy helping customers understand the value of **Ordio** 💙 and how they can use the platform more effectively.

🙌 You are motivated, independent and quickly familiarize yourself with new topics.

💻 You have a strong affinity for technology and can quickly understand new software products.

📊 You are comfortable working with CRM systems, customer data, pipelines and commercial KPIs.

## Benefits

💰 Competitive salary

🚀 Opportunity to be there from the start and successfully scale **Ordio 💙**

💡 Contribute to innovative solutions and products

😌 Opportunity to create an open & successful culture

🤝 Personal advancement opportunities and plenty of responsibility from day one

🤩 Young & motivated team

🏝️ Flexibility - home office, remote work and flexible working hours

🌃 Modern office at WeWork in the heart of Cologne

🚀 Agile startup culture

📱 State of the art technical equipment

🥳 Cool team events

🐶 Dogs welcome at the workplace

🏋️ Urban Sports Club Membership

🚴 Option to lease a company bike

**At Ordio** 💙, we're looking for people who want to be more than just another employee: ambitious, forward-thinking individuals who are ready to shape and grow our young start-up 🚀

**Ordio** 💙 is a web-based HR software that allows companies to centrally manage employees who don't work at a desk – from employee registration and shift planning to time tracking, document management, absence management and payroll.

We believe that together we can solve the world's problems better by equipping people with the right tools to solve their own.

We are always looking for talented people who want to shape the future with us.

**Does that sound like an exciting challenge to you?**

Then we'd love to hear from you.

**We're looking forward to meeting you! 😌**

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
