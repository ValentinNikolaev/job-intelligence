# Assistenz der Geschäftsführung / Operations (m/w/d)

Posted: 2026-08-18T10:00:30Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Wir suchen eine engagierte und selbstständig arbeitende Persönlichkeit, die als **rechte Hand der Geschäftsführung** eng in unsere Unternehmen, Marken und Projekte eingebunden ist.

Bei uns erwartet dich keine klassische Assistenzrolle. Du arbeitest direkt mit der Geschäftsführung zusammen, bekommst Einblicke in unterschiedlichste Unternehmensbereiche und übernimmst von Beginn an Verantwortung. Wir suchen jemanden, der mitdenkt, organisiert, Themen eigenständig vorantreibt und Lust darauf hat, gemeinsam mit uns zu wachsen.

Die Stelle ist in **Vollzeit oder** **Teilzeit** und bietet eine flexible Kombination aus **Frankfurt am Main und Remote Work**.

## Aufgaben

- Direkte Unterstützung der Geschäftsführung im operativen Tagesgeschäft

- Eigenständige Organisation, Priorisierung und Nachverfolgung von Aufgaben und Projekten

- Koordination von Terminen, Meetings, Reisen und Veranstaltungen

- Kommunikation mit Kunden, Partnern, Creatorn, Lieferanten und Dienstleistern

- Bearbeitung und Koordination von E-Mails und Anfragen

- Erstellung und Pflege von Dokumenten, Präsentationen, Übersichten und Tabellen

- Unterstützung bei organisatorischen und administrativen Themen

- Koordination von Produktionen, Bestellungen und externen Partnern

- Unterstützung bei Creator- und Influencer-Kooperationen

- Planung und Organisation von Events, Shootings und Content-Produktionen

- Unterstützung bei Social Media und Content-Planung

- Recherche und Vorbereitung neuer Projekte und Geschäftsideen

- Optimierung und Weiterentwicklung interner Prozesse

- Eigenständiges Nachhalten von Deadlines, Rückmeldungen und offenen Themen

Dein Aufgabenbereich ist bewusst vielseitig. Du sollst nicht auf jede einzelne Aufgabe warten, sondern **selbstständig mitdenken, Verantwortung übernehmen und Themen eigenständig vorantreiben**.

## Qualifikation

Für uns ist weniger entscheidend, welchen perfekten Lebenslauf du mitbringst. Viel wichtiger ist, **wie du arbeitest und Verantwortung übernimmst**.

Du solltest:

- sehr selbstständig und eigenverantwortlich arbeiten

- strukturiert, organisiert und zuverlässig sein

- mitdenken und offene Aufgaben eigenständig erkennen

- mehrere Themen gleichzeitig koordinieren und priorisieren können

- kommunikativ und professionell auftreten

- pragmatisch und lösungsorientiert arbeiten

- dich schnell in neue Themen und digitale Tools einarbeiten können

- sehr gute Deutsch- und gute Englischkenntnisse mitbringen

- Lust auf ein dynamisches und unternehmerisches Umfeld haben

**Optimal, aber kein Muss:** Du hast bereits Erfahrung im **Social Media Management, Content Management oder Influencer Marketing** und verstehst, wie Marken auf Social Media arbeiten und kommunizieren.

## Benefits

- Flexible Arbeitszeiten

- Remote Work

- Direkte Zusammenarbeit mit der Geschäftsführung

- Viel Eigenverantwortung

- Kurze Entscheidungswege

- Abwechslungsreiche Projekte

- Raum für eigene Ideen

- Enge Einbindung in Unternehmensprozesse

- Langfristige Entwicklungsmöglichkeiten

Wir suchen jemanden, der nicht einfach nur Aufgaben abarbeitet, sondern wirklich Teil unserer Unternehmen werden möchte. Wenn du gerne Verantwortung übernimmst, selbstständig arbeitest und Lust darauf hast, gemeinsam mit uns Dinge aufzubauen und voranzutreiben, freuen wir uns auf deine Bewerbung.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
