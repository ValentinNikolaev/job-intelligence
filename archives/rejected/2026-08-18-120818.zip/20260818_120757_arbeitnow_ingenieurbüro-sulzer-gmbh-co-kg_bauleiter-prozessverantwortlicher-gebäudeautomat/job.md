# Bauleiter / Prozessverantwortlicher Gebäudeautomation (m/w/d)

Posted: 2026-08-18T07:01:07Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Bei unseren Projekten setzen wir uns für die Entwicklung und Verbreitung moderner und nachhaltiger Gebäudetechnik ein. Wo immer möglich, bieten wir unseren Auftraggebern energieeffiziente und wirtschaftliche Lösungen für den Gebäudebetrieb an.

Damit die verschiedenen technischen Gewerke optimal zusammenspielen, suchen wir einen Bauleiter / Prozessverantwortlichen für Gebäudeautomation (m/w/d).

Du begleitest unsere Projekte sowohl in der technischen Ausarbeitung als auch während der Ausführung und Inbetriebnahme und stellst sicher, dass die Gebäudeautomation gewerkeübergreifend funktioniert.

## Aufgaben

**Prozessverantwortung und Planung**

- Technische Ausarbeitung von Projekten im Bereich Gebäudeautomation auf Grundlage der Vor- und Konzeptplanung

- Prüfung und Abstimmung gewerkeübergreifender Planunterlagen hinsichtlich der Mess-, Steuer- und Regelungstechnik

- Erstellung und Mitwirkung an Funktionsbeschreibungen und Ausschreibungen

- Koordination technischer Schnittstellen mit Projektleitung und Fachabteilungen

- Erstellung von Automationsschemata und Automationstopologien im CAD sowie Pflege der zugehörigen Projektdaten

**Bauleitung und Inbetriebnahme**

- Teilnahme an Jour fixe und Baubesprechungen sowie Kontrolle des Ausführungsstands

- Prüfung und Freigabe von Montage- und Ausführungsplänen

- Koordination der ausführenden Firmen und gewerkeübergreifenden Schnittstellen

- Überwachung von Kosten, Qualität und Terminen

- Koordination und Begleitung des Inbetriebnahmeprozesses über alle Gewerke

## Qualifikation

- Abgeschlossene Ausbildung zum Meister oder Techniker ODER ein Studium im Bereich Gebäudeautomation, Elektro-, Versorgungs- oder Gebäudetechnik bzw. einer vergleichbaren FachrichtungIdealerweise Berufserfahrung in der Gebäudeautomation sowie Mess-, Steuer- und Regelungstechnik

- Gute Kenntnisse der technischen Zusammenhänge zwischen Heizung, Lüftung, Klima und Elektrotechnik

- Erfahrung in der Planung und/oder Bauleitung gebäudetechnischer Anlagen sowie CAD-Kenntnisse sind von Vorteil

- Sicherer Umgang mit technischen Zeichnungen, Schemata und Planunterlagen

- Selbstständige, lösungsorientierte Arbeitsweise sowie ein gutes Verständnis für gewerkeübergreifende Schnittstellen

- Kommunikationsstärke und Freude an der Zusammenarbeit mit unterschiedlichen Projektbeteiligten

- Fließende Deutschkenntnisse in Wort und Schrift, mindestens C1-Niveau

## Benefits

- Modernste Arbeitsplätze

- Flexible Arbeitszeiten

- Kontinuierliche Weiterbildung mit persönlichem Schulungskontingent

- Attraktives Vergütungssystem mit monatlich ausgezahlter ErfolgsbeteiligungViele zusätzliche Sozialleistungen: JobRad, Zeitwertkonto, bAV-Zuschuss, Kita-Zuschuss, Zusatzkrankenversicherung und EGYM Wellpass

- Teamevents wie Sommerfest, mehrtägiger Betriebsausflug und weitere teambezogene Events

- Ein dynamisches und heterogenes Team in einer kollegialen Arbeitsatmosphäre mit kurzen Entscheidungswegen

- Firmeneigene Kantine mit bezuschussten Mahlzeiten

- Sehr gute Work-Life-Balance durch Homeoffice-Option und Teilzeit-/4-Tage-Modelle

- Wertschätzende Kultur mit Feedback, Mentoring und klaren Entwicklungspfaden

- Firmenwagen mit Privatnutzung möglich

Du möchtest mehr über unsere Unternehmenskultur erfahren? Schau doch bei uns auf Kununu vorbei und überzeug dich selbst!

Wir freuen uns von dir zu hören!

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
