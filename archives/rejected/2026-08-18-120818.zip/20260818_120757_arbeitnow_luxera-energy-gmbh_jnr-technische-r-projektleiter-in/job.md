# (Jnr.) Technische:r Projektleiter:in

Posted: 2026-08-18T09:00:27Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Der notwendige Ausbau erneuerbarer Energien führt zu Volatilitäten im Energiesystem und stellt u.a. unsere Stromnetze vor große Herausforderungen. Genau hier setzt Luxera Energy an: Als Plattform für stationäre Batteriespeichersysteme (BESS) - alleinstehend sowie co-located mit PV & Wind - schaffen wir die notwendige Flexibilität, um erneuerbare Energien effizient ins Netz zu integrieren und leisten damit einen entscheidenden Beitrag zur Energiewende.

Unser dynamisches Team aus derzeit 17 Mitarbeitenden vereint umfassende Erfahrung aus der Strategieberatung (MBB) sowie der Entwicklung, der Finanzierung, dem Bau und dem Betrieb von Batteriespeicher- und Erneuerbare-Energien-Projekten. Unsere Projektpipeline umfasst derzeit rund 1 GW an fortgeschrittenen Batteriespeicherprojekten, von denen wir einen großen Teil selbst bauen und betreiben werden.

Dabei legen wir eine hohe Geschwindigkeit an den Tag - in den nächsten 12 Monaten setzen wir mindestens 200MW an Mittel- und Hochspannungsprojekten um. Dafür suchen wir eine:n Technische:n Projektleiter:in, der:die von Tag eins an Verantwortung übernimmt, und genauso auf die Inbetriebnahme der Batteriespeicher hinfiebert wie wir!

## Aufgaben

- Mitverantwortung für die ganzheitliche technische Umsetzung von stationären Batteriespeichersystemen – von der Auswahl der projektspezifisch idealen Komponenten, über die Evaluation und Beauftragung der geeigneten Generalunternehmer für den Bau, bis zur Steuerung des Baufortschritts und der Inbetriebnahme des Speichers

- Koordination externer Stakeholder, darunter deutsche und internationale OEMs, EPCs, Direktvermarkter etc., und Unterstützung der Überwachung von Qualität und Zeitleisteneinhaltung entlang dieser Partnerschaften

- Erstellung von entscheidungsrelevanten Analysen wie bspw. zu Hardware/Software Innovationen, Kostenschätzungen, oder Make-or-Buy-Bewertungen für einzelne Tätigkeiten und/oder Gewerke

- Enge Abstimmung mit unseren Teams für Genehmigungsplanung, Netzanschluss, und Finance zu Zeitleisten und technischen Projektdetails (z.B. Layoutplanung oder Auswahl der Hardware für Netzanträge)

- Mitwirkung am weiteren Firmenaufbau, beispielsweise durch die Verbesserung bestehender Prozesse und Tools, oder sonstige Initiativen - du gestaltest deine Themen mit :)

## Qualifikation

- Großes Interesse an erneuerbaren Energien, Batteriespeichern und der Energiewende im Allgemeinen

- Ausgeprägte Fachkenntnisse in Elektro- oder Energietechnik ****durch den Abschluss eines technischen Studiums im Bereich Energietechnik, Elektrotechnik, Maschinenbau, Bauingenieurswesen oder Ähnlichem

- (Erste) Berufserfahrung im Bereich der Steuerung der technischen Umsetzung von Infrastrukturprojekten im Energiesektor, bspw. bei einem EPC, einem Technischen Betriebsführer, einem OEM, einem Projektentwickler oder einem vergleichbarem Unternehmen

- Hohes Maß an Sorgfältigkeit und Auge fürs Detail, sowie ausgeprägte analytische Fähigkeiten

- Unternehmerische Persönlichkeit mit einem hohen Maß an Eigeninitiative und Ergebnisorientierung

- Sehr gute Deutsch- und Englischkenntnisse in Wort und Schrift

## Benefits

- Verantwortung und Gestaltungsspielraum: Werde ein integraler Bestandteil unseres Teams, spiele vom ersten Tag an eine aktive Rolle in unserem Unternehmen

- Einblicke und Auswirkungen: Du hast die Möglichkeit, in einem schnell wachsenden Unternehmen an der Spitze der Energiewende mitzuwirken und mit den spannendsten Themen und Technologien im Bereich der erneuerbaren Energien zu arbeiten

- Leidenschaftliche und kooperative Teamathmosphäre: Lerne von und mit unserem Team - wir setzen auf flache Hierarchien und eine offene und direkte Kommunikation sowie regelmäißge Weiterbildungsmöglichkeiten

- Attraktives Vergütungsmodell mit zusätzlichen Leistungen: Freu dich auf unsere regelmäßigen Teamevents, Wellpass sowie einen zentralen Arbeitsplatz in München, und die Option zur Teilnahme am Mitarbeiterbeteiligungsprogramm (VSOP)

Du bist bereit, die Zukunft der Energie mit uns zu gestalten? Dann freuen wir uns sehr auf deine Bewerbung mit Lebenslauf, frühestmöglichem Eintrittstermin und allen weiteren Informationen, die uns helfen, dich besser kennenzulernen und zu verstehen, warum du bei Luxera einsteigen möchtest.

*Studien haben gezeigt, dass sich Frauen nur dann auf Stellen bewerben, wenn sie glauben, dass sie alle Anforderungen der Stellenbeschreibung erfüllen. Wir möchten dich dennoch ermutigen, dich zu bewerben, auch wenn du nicht alle von uns gewünschten Qualifikationen erfüllst.*

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
