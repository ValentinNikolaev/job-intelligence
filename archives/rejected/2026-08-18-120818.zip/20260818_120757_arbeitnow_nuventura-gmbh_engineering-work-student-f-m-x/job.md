# Engineering Work Student (f/m/x)

Posted: 2026-08-18T07:01:06Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Nuventura is a Berlin-based climate tech company developing a new generation of medium-voltage switchgear that is both highly innovative and environmentally sustainable. With our patented gas-insulated technology, we replace SF₆ — one of the most harmful greenhouse gases — with clean, dry air, while maintaining the same reliability and performance as conventional systems.

Our mission is to accelerate the global transition toward sustainable electrical infrastructure. To achieve this, we work at the intersection of deep engineering expertise, industrial partnerships, and rapid product development. Our product portfolio is expanding quickly through new development projects and international scaling activities. As an interdisciplinary and engineering-driven company, we enable utilities and manufacturers worldwide to adopt SF₆-free technology and make power grids future-proof.

As an **Engineering Work Student (f/m/x)**, you will play a key role in advancing our next-generation R&D prototype, **nu2**, which is set to undergo rigorous mechanical and electrical type testing. This is a hands-on position where you will contribute directly to building, assembling, and refining complex mechanical systems. Your work will support Nuventura’s mission to revolutionize sustainable electrical infrastructure with SF₆-free technology.

**Your Mission**

You will be at the heart of **nu2’s development**, gaining hands-on experience in assembling heavy and intricate mechanical components, creating precise **mechanical detailed drawings with GD&T**, and developing clear work instructions. Your contributions will help shape the future of **medium-voltage switchgear** and drive innovation in climate tech.

## Tasks

- Build **sub-assemblies and full assemblies** for the **nu2 prototype**.

- Create **detailed work instructions** to guide assembly processes.

- Document **issues and challenges** encountered during assembly and propose solutions.

- Collaborate with **design engineers** to suggest improvements for **design-for-assembly (DFA)**.

- Work closely with **Maruthi Nagaraja, Kushal Kotegowdara, and technicians** to ensure seamless execution.

## Requirements

**Must-have:**

- Currently pursuing a degree in **Mechanical or Industrial Engineering** with experience in **mechanical design**.

- Hands-on experience in **building and assembling mechanical systems**.

- Strong problem-solving skills and attention to detail.

- **Languages:** Fluent in **English** and **German**.

**Nice-to-have:**

- Background in **mechanical engineering** with a focus on prototyping or testing.

## Benefits

- You will be part of an innovative group of high-performance and experienced people from diverse backgrounds.

- We are committed to your growth and will challenge you directly to become the best professional version of yourself.

- We believe in a culture of trusted ownership, caring meritocracy, and constructive feedback where we elevate each other and challenge the status quo.

- A sustainable, down-to-earth, and passionate company.

- Free snacks, drinks and fruit basket every day.

- Exciting and regular team events, including a Christmas party, summer celebrations with a budget for departmental events.

**Ready to Build the Future?**

If you’re passionate about **hands-on engineering** and want to contribute to **sustainable electrical infrastructure**, apply now and join our team in **Berlin**.

*Nuventura is an equal-opportunity employer. We celebrate diversity and are committed to creating an inclusive environment for all employees.*

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
