# Customer Experience Specialist (all genders) at AI Audit-Tech Startup

Posted: 2026-08-18T10:47:30Z

## Rejection

- Category: tech_stack
- Reason: role does not mention Go/Golang or PHP

You know how auditors really work, and you're fascinated by what AI could do to change it? Then this might be an exciting opportunity for you.

We are dnl, an AI audit-tech startup building intelligent software for leading audit firms. Our AI helps auditors work through mountains of documents faster, more accurately, and with far less manual effort. And we're just getting started.

We're looking for a Customer Experience Specialist who brings real audit experience and wants to put it to work shaping an AI product built for their own profession. You've lived the workflows and the pain points, and now you get to be the person who helps fix them, working directly with the team building the product. If you're curious about how complex software works and want your audit background to finally power something new, you'll feel at home here.

## Tasks

- Be the **voice of our customers inside the company**, the person whose audit insight directly influences what we build next.

- **Take charge of the full customer journey**, from the first question to a resolved case, and make sure every touchpoint feels smooth and genuinely helpful.

- Use your **audit background to dig into real customer cases, reproduce them, and work hand-in-hand with our engineers** to turn problems into product improvements.

- **Communicate with users** in a clear, structured, and proactive way.

- **Build our knowledge base and documentation from the ground up** as we scale. You're creating the playbook as we grow.

- **Collaborate closely with Product, Engineering, and Sales** to shape both the product and how we work.

- **Help design the experience for a product that's changing how auditors work worldwide.**

## Requirements

- **1-2 years of experience in financial audit** or a related field. You know the workflows and pain points of our customers firsthand and speak their language.

- **Genuine curiosity for how complex software and AI actually work** under the hood.

- **Excellent communication skills in German and English (C1+).**

- A **structured, hands-on approach to solving problems.**

- **Strong project management skills.** You're always on top of things, have a high sense of urgency, and know how to prioritise effectively.

- **Ownership and startup compatibility.** You actively shape things rather than just execute, and you thrive in a dynamic, fast-moving environment.

## Benefits

- **Real ownership from day one.** Your work visibly shapes the product and the company from the start.

- **A front-row seat at an AI startup** at its most exciting stage, with flat hierarchies and short decision paths where your ideas actually ship.

- **The chance to leave the audit desk behind** and help build the tool that changes the profession you came from.

- **Fully remote work**, with regular trips to Berlin for on-site teamwork.

- **Flexible working hours.**

- **Competitive compensation package.**

- **A monthly 50€ voucher** usable at 50+ stores, free lunch at the office, and regular online and offline team events.

- **A collaborative, international, ambitious, and supportive team.**

**Join our team** and help us create an **outstanding experience for audit professionals worldwide** – with an AI product that truly changes the way they work.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
