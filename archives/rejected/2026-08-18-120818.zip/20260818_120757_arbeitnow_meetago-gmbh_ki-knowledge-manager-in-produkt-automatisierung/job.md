# KI & Knowledge Manager:in – Produkt, Automatisierung & Qualitätssicherung

Posted: 2026-08-18T08:30:07Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

### **Gestalte, wie wir mit Wissen und KI arbeiten**

Wir bauen unser Helpcenter um – hin zu einem Wissenssystem, auf dem unsere KI, unser Support und unser Produkt aufsetzen – und du baust mit.
Im Kern deiner Rolle steht eine zentrale Wissensbasis: sauber strukturiert, immer aktuell und so aufbereitet, dass Menschen **und** KI-Systeme damit arbeiten können. Sie ist die Grundlage für unseren KI-Agenten, für automatisierte Support-Prozesse, interne Produktdoku und neue KI-Workflows. Wer dieses Wissen gut organisiert, entscheidet mit, wie intelligent das ganze Unternehmen arbeitet.

### Dein Aufgabengebiet

-

Wissensbasis & agentisches KI-System
Du strukturierst Produktwissen, Prozesse und häufige Fragen so, dass unser KI-Agent verlässlich antworten kann. Du sorgst dafür, dass Inhalte konsistent, verständlich und maschinenlesbar bleiben – die Voraussetzung für jede gute KI-Automatisierung.

-

Agentisches Produktmanagement
Produktideen, Kundenfeedback und Anforderungen laufen bei uns KI-gestützt zusammen: vorqualifiziert, geschärft, mit den richtigen Rückfragen versehen. Die KI bereitet vor, der Mensch entscheidet. Du gestaltest diese Verbindung zwischen Wissen, Produkt und Entscheidung aktiv mit.

-

Schnittstelle & Kommunikation
Du bist die Verbindung zwischen Support, Produkt, Key Account Management, Agentur und Technik. Du bündelst Informationen, bringst sie auf den Punkt und an die richtige Stelle.

-

Qualität & Testing
Du wertest automatisierte Tests aus, testest manuell, dokumentierst Auffälligkeiten nachvollziehbar – und speist deine Erkenntnisse direkt zurück in Wissensbasis und Produktprozesse.

-

Du sprichst sehr gutes Deutsch und Englisch und bist in der Lage, Komplexes einfach zu machen.

-

KI ist für dich kein Buzzword, sondern Werkzeug – du willst damit arbeiten und mitgestalten.

-

Du arbeitest dich gern tief in Produkte, Tools und Prozesse ein.

-

Du bist sorgfältig, analytisch, eigeninitiativ – und gleichzeitig kommunikativ und serviceorientiert.

-

Du hast idealerweise erste Erfahrung mit Wissensmanagement, Support, Testing/QS oder Produktdoku. Kein Muss, wenn der Rest passt.

###
Womit wir Dich überzeugen

Eine Rolle an der Schnittstelle von KI, Produkt, Wissen und Qualität – mit echtem Gestaltungsspielraum. Du baust eine zentrale Wissensbasis von Grund auf mit, arbeitest praktisch mit KI-Tools und Automatisierung und bekommst Einblick in agentisches Produktmanagement, bevor es Mainstream ist. Dazu ein Team, das pragmatisch denkt, Eigeninitiative schätzt und für neue Ideen offen ist.

### Über uns

Wir, die **meetago group,** betreiben die europaweit **führende Online-Plattform** für Suche, Vergleich und Buchung von Meeting- und Tagungsräumen sowie (Gruppen-) Übernachtungen. Über **200.000 Meeting- und Tagungsplaner** aus mehr als **13.500 Unternehmen**, vom globalen Konzern bis hin zum Einzelunternehmen, vertrauen **seit mehr als 20 Jahren** auf unsere Expertise.

Unsere Kunden können auf unserer Plattform über **100.000 Tagungshotels und -Locations** weltweit entdecken und buchen. Täglich laufen hunderte Anfragen und Buchungen über unsere Plattform.

Wir legen uns täglich dafür ins Zeug, unsere Kunden und Partner **wunschlos glücklich** zu machen. Denn durch unsere digitalen, maximal einfachen Lösungen und unseren Service können diese jede Menge **Zeit und Geld sparen**.

**Werde jetzt Teil unseres Erfolgs und starte Deine Karriere mit der meetago group! Wir freuen uns auf Dich!**

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
