# Projektleiter (m/w/d)

Posted: 2026-08-18T07:01:07Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

KONDI Engineering & Prototyping ist seit 2011 Entwicklungspartner für Produkt- und Systementwicklung. Unser Schwerpunkt liegt im Automotive-Bereich, insbesondere in der Entwicklung hybrider und elektrischer Antriebe und Systeme. Darüber hinaus sind wir in den Bereichen Energie, Medizintechnik, Robotik und Automatisierung tätig.

Wir begleiten unsere Kunden entlang des gesamten Produktentwicklungsprozesses – von der ersten Idee über Konstruktion, Simulation und Validierung bis hin zur Serienreife. Mit einem erfahrenen Engineering-Team und modernen Entwicklungsmethoden schaffen wir innovative, praxisnahe und zukunftsfähige Lösungen.

## Aufgaben

- Leitung von Entwicklungsprojekten im Bereich Electric & Hybrid Drive Systems

- Steuerung der technischen und organisatorischen Projektumsetzung – vom Anforderungsmanagement bis zur Serienreife

- Planung, Koordination und Steuerung der Projektaufgaben und des Projektteams

- Sicherstellung der Projektziele hinsichtlich Termine, Technik, Qualität und Kosten

- Regelmäßige Abstimmung mit Kunden und internen Fachbereichen

- Unterstützung des Vertriebs während der Akquise- und Angebotsphase

- Monatliches Projektreporting und Durchführung von Projektreviews mit der Geschäftsleitung

## Qualifikation

- Abgeschlossenes technisches Studium, vorzugsweise in Elektrotechnik, Mechatronik, Fahrzeugtechnik, Wirtschaftsingenieurwesen, Maschinenbau oder einer vergleichbaren Fachrichtung

- Erfahrung im technischen Projektmanagement, idealerweise im Automotive-Umfeld

- Kenntnisse oder praktische Erfahrung im Bereich Electric & Hybrid Drive Systems

- Ausgeprägtes technisches Verständnis und Begeisterung für die Entwicklung innovativer technischer Lösungen

- Gute Deutsch- und Englischkenntnisse in Wort und Schrift

- Unternehmerisches Denken sowie ein ausgeprägtes Verständnis für Termine, Qualität und Kosten

- Durchsetzungsvermögen, Eigeninitiative und sicheres Auftreten gegenüber Kunden und Projektteams

- Ausgeprägte Kommunikations- und Koordinationsfähigkeit

## Benefits

- Spannende und vielseitige Tätigkeit in einem anspruchsvollen

Arbeitsgebiet

- Angenehme Arbeitsatmosphäre in einem motivierten Team

- Aufgaben/Lösungen aktiv mitzugestalten und Ihre

Entwicklungsmöglichkeiten selbst zu bestimmen.

- Teilnahme an internen und externen Schulungen

- Tätigkeit in einem professionellen Projektteam

- Modernes Umfeld, attraktive Vergütung und flache

Hierarchien

- Leistungsstarke und innovative Ausstattung sowie Home-Office

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
