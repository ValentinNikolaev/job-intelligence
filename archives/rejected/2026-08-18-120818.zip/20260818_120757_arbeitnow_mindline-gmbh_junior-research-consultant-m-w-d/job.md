# Junior Research Consultant (m/w/d)

Posted: 2026-08-18T10:00:27Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

mindline ist ein Full-Service Institut für Marktforschung und Marketingberatung mit Sitz in Hamburg und weiteren Niederlassungen in Berlin und Nürnberg. Mit über 100 Mitarbeiter:innen zählt mindline zu den zehn größten Full-Service Marktforschungs-Anbietern in Deutschland.

Zu unseren Kund:innen zählen unter anderem einige der größten Unternehmen in den Bereichen FMCG, Handel und Mobilität aber auch einige kleine und aufstrebende Unternehmen/Start-ups. Für viele unserer Kund:innen sind wir global tätig.

Seit Gründung in 2002 ist mindline kontinuierlich gewachsen. Dadurch bieten wir unseren Mitarbeiter:innen viele Entwicklungsmöglichkeiten und spannende Betätigungsfelder.

Unsere Unternehmenskultur ist durch Offenheit, Spaß an unserer Arbeit und Professionalität geprägt. Durch unsere flachen Hierarchien können wir schnelle Entscheidungen treffen und flexibel Dinge für unsere Kund:innen und unsere Mitarbeiter:innen bewegen.

## Aufgaben

Deine Aufgaben:

- Du arbeitest eng und gemeinsam mit der Teamleitung an der operativen Durchführung und Analyse der Studien

- Kundenbetreuung! Du hältst intensiven Kontakt mit unseren Kund:innen

- Du kontrollierest die Einhaltung der Qualitätsstandards und bist für die Überwachung und Aufgabendelegation der beteiligten Dienstleister:innen und der internen Services zuständig

- Du übernimmst nach einer erfolgreichen Einarbeitung selbständig kleine Projekte oder Teilaufgaben von großen, internationalen Projekten

## Qualifikation

Dein Profil:

- Abgeschlossenes Studium im Bereich BWL, VWL oder Sozialwissenschaften, idealerweise mit Schwerpunkt Marketing und/oder Wirtschaftspsychologie

- Ausgeprägtes analytisches und konzeptionelles Denkvermögen

- Hohe Kunden-, Service- und Marketingorientierung

- Kreativität und Freude daran, neue Ideen zu entwickeln

- Spaß am datenbasierten Marketing: Analyse und Bewertung von Daten sowie Ableitung von Erkenntnissen und konkreter Handlungsempfehlungen

- Idealerweise gute (theoretische) Kenntnisse der Methoden der empirischen Marktforschung

- Fähigkeit, komplexe Markforschungssachverhalte und Analysen einfach, verständlich und anschaulich aufzubereiten

- Gute Präsentationsfähigkeiten und Freude daran, Ergebnisse überzeugend zu vermitteln

- Organisationstalent und eine strukturierte Arbeitsweise

- Sehr gute Kenntnisse in der Deutschen und Englischen Sprache

- Sehr gute Kenntnisse in MS Office insbesondere PowerPoint, sowie KI-Tools (z.B. ChatGPT, Claude) und idealerweise Kenntnisse in SPSS, R oder Survey Reporter oder vergleichbare Tools

- Und nicht zuletzt: Ein offenes Wesen, Spaß am Umgang mit Kund:innen und Kolleg:innen

## Benefits

Wir bieten:

- Eine sehr gute Arbeitsatmosphäre in einem tollen Team

- Zusammenarbeit mit einigen der spannendsten Unternehmen aus den verschiedensten Branchen – lokal wie international

- Freiräume und Trainings zur fachlichen und persönlichen Weiterentwicklung

- Eine attraktive Vergütung

- Flexible Arbeitszeitgestaltung (außerhalb der Kernarbeitszeiten)

- Viele gemeinsame Aktivitäten, z.B. Firmen- und Teamevents

- Weitere attraktive Nebenleistungen, z.B. HVV-ProfiTicket, Bike-Leasing-Angebot, Zuschuss zur betrieblichen Altersvorsorge

Bewirb dich jetzt und werde Teil unseres Teams!

Wenn du dich angesprochen fühlst, dann sende bitte deine vollständigen Unterlagen mit Angaben zur Verfügbarkeit und Gehaltsvorstellung an unsere Personalreferentin Amina Rezevcanin. Für weitere Fragen vorab kannst du Amina auch gern kontaktieren oder du besuchst unsere website.

Wir freuen uns auf deine Bewerbung!

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
