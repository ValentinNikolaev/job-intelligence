# Senior Controller (m/w/d)

Posted: 2026-08-18T08:30:30Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**Du wirst die starke Nummer 2 im Finanzbereich einer Firmengruppe mit rund 105 Mio. € Umsatz — und baust Kostenrechnung, Controlling-Systeme und Beteiligungscontrolling erst auf.**

Wer Non-Food-Ware aus Asien nach Europa bringt, gewinnt heute nicht mehr über den Einkaufspreis, sondern über Verlässlichkeit: geprüfte Lieferketten, belastbare Zertifizierungen, planbare Termine. Genau das macht Carstensen seit 1991 — mit rund 200 Menschen, eigenen Büros in Shanghai, Hongkong, Bangkok und Jakarta und rund 105 Mio. € Umsatz. Der Plan für die nächsten Jahre steht: organisch in Richtung 150 Mio. €, unter anderem über eine neue Warengruppe.

Gleichzeitig ist um das Handelshaus eine Gruppe gewachsen. Neben der Tochtergesellschaft Stylex gehören inzwischen mehrere E-Commerce-Beteiligungen dazu, und es werden weitere. Zwei sehr unterschiedliche Geschäftsmodelle, die im Controlling noch zusammenfinden müssen. Dafür suchen wir für Carstensen eine zweite starke Stimme im Finanzbereich: jemanden, der das Bankenreporting und den Konzernabschluss verlässlich trägt und daneben die Themen aufbaut, die bisher zu kurz gekommen sind — Kostenrechnung, Controlling-Systeme, Beteiligungscontrolling.

Der Hebel dafür ist groß. Über dir sitzt genau eine Person: unser CFO, der Finance, Controlling, IT und das Lager verantwortet.

Kein Matrixgeflecht, keine Freigabekette über drei Ebenen — täglicher Austausch und echtes Sparring. Bis zu sieben Kolleg:innen in der Finanzbuchhaltung arbeiten dir zu.

Und ab Q1/2027 wird das ERP-System gewechselt: Du gestaltest als Key User im Modul CO die neue Controlling-Welt von Grund auf mit, statt eine bestehende zu übernehmen.

## Aufgaben

**Was du bewegen wirst**

**Keine Aufgabenliste, sondern das, was in zwölf Monaten anders sein soll:**

- Das Bankenreporting läuft ohne Nacharbeit. Monatliche Bestandsmeldungen und quartalsweise Plan-Ist-Ergebnisse gegenüber unseren finanzierenden Banken liegen termingerecht und belastbar vor — du verantwortest Termine und Kennzahlenlogik.

- Die Abschlüsse sitzen. Vorbereitende Abschlüsse und die dazugehörigen Abstimmungsarbeiten sind fertig, bevor jemand nachfragt, und halten der Prüfung stand. Am Konzernabschluss der Gruppe arbeitest du mit.

- Die Kostenrechnung existiert. Was heute Lücke ist, ist dann Struktur: Kostenstellen, Auswertungslogik und Controlling-Prozesse, die auch dann tragen, wenn die Gruppe weiter wächst.

- Die Datenbasis stimmt. Kennzahlen und Auswertungen für die Abwicklung baust du selbst — mit modernem BI statt gewachsener Excel-Inseln. Fehlerursachen klärst du an der Quelle, nicht in der Auswertung.

- Die Beteiligungen sind im Blick. Die Reportings der Tochtergesellschaften laufen zusammen und sind konsolidiert — Handel und E-Commerce nebeneinander lesbar.

- Der ERP-Wechsel ist gestartet. Ab Q1/2027 bist du als Key User im Modul CO handlungsfähig, ohne dass das laufende Reporting darunter leidet.

**Wie hier gearbeitet wird**

Carstensen ist ein Familienunternehmen, und das ist bei uns keine Zeile im Leitbild. Die Geschäftsführung beschreibt ihren Führungsstil selbst als „lange Leine, solange die Leute einen guten Job machen" — Family First wird authentisch gelebt.

- Entscheidungen erarbeiten wir im Team. Bestehende Strukturen musst du zuerst verstehen — danach sind wir für Veränderungen ausdrücklich offen.

- Das Controlling sitzt nicht getrennt, sondern im direkten Austausch mit Einkauf, Logistik und Abwicklung. Wer Zahlen verantwortet, redet hier mit den Menschen, die sie erzeugen.

- Bis zu 2 Tage Homeoffice pro Woche sind gesetzt. Mehr passt für diese Rolle nicht, weil der enge Draht zu den Fachbereichen der halbe Job ist.

- Wir entwickeln Leute intern weiter und haben dafür eine Teamlead-Struktur eingeführt — Verantwortung wächst hier mit dem Track Record, nicht mit dem Dienstalter. Du hast also einen großen Einfluss auf deine Journey.

## Qualifikation

Uns interessiert weniger der Titel als zwei Nachweise: eigene Abschlussarbeit und eigene Systemarbeit im ERP. Wer beides mitbringt, passt hier oft besser als jemand mit dem passenderen Jobtitel.

**Das brauchst du auf jeden Fall**

- Mehrjährige operative Controlling-Praxis: Du hast Monats- oder Jahresabschlüsse selbst vorbereitet und Abstimmungsarbeiten selbst verantwortet — nicht nur ausgewertet, was andere geliefert haben.

- ERP-Tiefe: Du arbeitest in einem ERP bis auf Buchungs- und Datenebene und baust daraus belastbare Kennzahlen. Welches System du kennst, ist zweitrangig.

- Du gehst auf Menschen zu und holst dir Zahlen und Hintergründe aktiv aus den Fachbereichen, statt auf Zulieferung zu warten.

- Eigenantrieb, den du belegen kannst: eine Sache, die du ohne Auftrag angefangen und zu Ende gebracht hast.

- Excel auf hohem Niveau, dazu Sicherheit im Umgang mit Datenbanken oder einem BI-Tool — du baust Auswertungen selbst, statt sie nur zu lesen.

- Abgeschlossenes Studium (mindestens Bachelor) und verhandlungssicheres Deutsch.

**Das ist ein Plus, aber kein Muss**

- Konzernabschluss oder Konsolidierung aus eigener Hand

- Reporting gegenüber finanzierenden Banken, Covenant- oder Konsortialkredit-Reporting

- Kostenrechnung schon einmal selbst aufgebaut, nicht nur gepflegt

- Eine ERP-Einführung begleitet oder eine Key-User-Rolle im Modul CO gehabt

- Power BI, Lucanet, Access oder SQL aus der Praxis

- Handels-, Import-, Großhandels- oder Logistikumfeld — der Alltag unterscheidet sich spürbar vom Produktionscontrolling

- Wirtschaftsprüfung oder Steuerberatung als Financial Background

Vier von sechs Pflichtpunkten und beim Rest bist du sicher, dass du schnell aufholst? Dann melde dich trotzdem — wir schauen uns das gemeinsam an.

## Benefits

**Die Vorteile für dich**

- Eine Ebene über dir, mehr nicht. Du berichtest direkt an den CFO der Gruppe und bist ausdrücklich als seine Vertretung und sein Sparringspartner angelegt — nicht als Zuarbeit.

- Aufbauen statt fortschreiben. Kostenrechnung und Controlling-Systeme entstehen mit dir. Du übernimmst kein Schema, du entscheidest mit, wie es aussieht.

- Ein ERP-Wechsel zum Mitgestalten. Ab Q1/2027 baust du die Controlling-Welt im neuen System als Key User im Modul CO von Grund auf mit.

- Zwei Geschäftsmodelle in einer Rolle. Klassisches Handelscontrolling und das Controlling unserer E-Commerce-Beteiligungen — eine Bandbreite, die es in Häusern dieser Größe selten gibt.

- Ein Team, das dir zuarbeitet. Sechs bis sieben Kolleg:innen in der Finanzbuchhaltung als eigene Abteilung nebenan, kurze Wege statt Ticketsystem.

- Bis zu 2 Tage Homeoffice pro Woche.

- Eine Perspektive, die mitwächst. Läuft der Aufbau, öffnen sich Konzernthemen über Carstensen hinaus — unter anderem für unsere Tochtergesellschaft Stylex.

**Vier Schritte, ohne Überraschungen — Qualität geht uns vor Geschwindigkeit, aber wir lassen dich nicht warten.**

- Kurzes Telefonat, rund 15 Minuten. Rahmen, Zeitpunkt, Gehaltsvorstellung und die Frage, ob die Richtung für dich stimmt.

- Videogespräch, 45 bis 60 Minuten. Fachlicher Tiefgang und ein ehrliches Bild davon, wie wir arbeiten.

- Persönliches Gespräch im Office. Mit dem CFO — hier entscheidet sich fachlich und menschlich das Meiste. Du siehst dabei auch das Haus und das Team.

- Abschlussgespräch und Angebot. Ein zweites Gespräch, bei dem einer unserer Gesellschafter-Geschäftsführer dazukommt, danach klären wir die Konditionen.

**Warum du dich jetzt melden solltest**

Controlling-Stellen gibt es viele. Eine, in der die Systeme noch nicht stehen, das Bankenreporting wirklich anspruchsvoll ist und über dir genau eine Person sitzt, deutlich seltener.

Wenn du Abschlüsse selbst gemacht hast und trotzdem Lust hast, etwas aufzubauen statt es zu verwalten, dann lohnt sich ein erstes Telefonat. Zwanzig Minuten reichen, um zu merken, ob es passt.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
