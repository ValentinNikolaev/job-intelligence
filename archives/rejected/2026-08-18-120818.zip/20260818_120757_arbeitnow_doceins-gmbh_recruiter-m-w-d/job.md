# Recruiter (m/w/d)

Posted: 2026-08-18T09:30:35Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

für die Doceins Gruppe

Kennziffer: M-03

Die **MVZ Doceins Gruppe** sucht einen engagierten Recruiter (m/w/d) zur Unterstützung unseres HR-Teams. Für deinen Einsatz bieten wir spannende enefits, wie beispielsweise ein Diensthandy, einen Arbeitslaptop, die Möglichkeit des Job-Rad-Leasings und ein kollegiales sympathisches Team sowie die Möglichkeit des Mobilen Arbeitens.

Die MVZ Doceins Gruppe bietet an ihren Standorten deutschlandweit modernste ambulante Versorgung für alle Patienten und Patientinnen. Einen besonderen Schwerpunkt bilden dabei die onkologischen, internistischen und dermatologischen Fachbereiche. Von Leipzig aus werden die MVZ Strukturen der verschiedenen Bundesländer zentral organisiert und unterstützt.

Wir versorgen Patienten. Gem**eins**am.

## Aufgaben

**Operatives Recruiting**

- Steuerung des gesamten

Recruitingprozesses für ein definiertes Portfolio der medizinischen

Vakanzen der Doceins Gruppe – von der Anforderungsaufnahme bis zur

Besetzung (Recruiting von Ärzten, Pflegefachkräften, MFAs und weiteren

medizinischen Fachkräften)

- Erstellung von Anforderungsprofilen und Stellenausschreibungen; Auswahl geeigneter Recruitingkanäle sowie Active Sourcing

- Eigenständige

Durchführung von Vorstellungsgesprächen sowie die Steuerung und

Begleitung der Kandidatinnen und Kandidaten im gesamten

Bewerbungsprozess

- Recruiting-Ansprechpartner für Praxen, Standortmanager und Führungskräfte

- Beauftragung und Steuerung von Personaldienstleistern, Vermittlern und Headhuntern

- Pflege von Kandidatenkontakten und Aufbau von Talent Pools

**Recruiting Operations & HR-Projekte**

- Analyse und Weiterentwicklung bestehender Recruitingprozesse und -kanäle

- Auswertung von Recruiting-Kennzahlen und Ableitung von Maßnahmen

- Unterstützung bei der Weiterentwicklung des Bewerbermanagementsystems und digitaler Recruiting-Tools

- Identifikation sinnvoller Einsatzmöglichkeiten von Automatisierung und KI im Recruiting

- Mitwirkung bei der Weiterentwicklung von Onboarding-, Einarbeitungs- und Personalentwicklungsprozessen

- Aktive und kreative

Konzeption und Umsetzung von Personalmarketing- und Employer

Branding-Aktivitäten in Zusammenarbeit mit der Marketingabteilung

## Qualifikation

- Abgeschlossenes Studium mit Schwerpunkt Personalmanagement, Wirtschaftspsychologie, Gesundheitsmanagement, Betriebswirtschaft oder ähnliches oder Ausbildung zum Personaldienstleistungskaufmann

- Mindestens 1 Jahr Recruitingerfahrung, optimalerweise im Bereich Medizin bzw. des Gesundheitswesen

- Gute MS-Office Kenntnisse

- Ein agiles Mindset sowie einen lösungsorientierten und proaktiven Arbeitsstil

- Überzeugende Kommunikations- und Organisationsfähigkeiten.

- Hohes Verantwortungsbewusstsein, Sorgfalt, Vertrauenswürdigkeit sowie Teamfähigkeit

## Benefits

- Ein vielseitiges Tätigkeitsfeld im wachsenden Gesundheitssektor

- Unbefristeter Arbeitsvertrag

- Zuschuss zur betrieblichen Altersvorsorge

- Einarbeitung vor Ort

- Ein moderner Arbeitsplatz im Zentrum von Leipzig mit Möglichkeit zum Mobilen Arbeiten

- Flexible Arbeitszeiten

- Ein sympathisches Team

- Teilnahme an internen Schulungen

- Jährliche Teamevents

- JobRad-Leasing

- 31 Tage Urlaub

**Bewerbungsunterlagen**

- Lebenslauf

- Nachweis über die erfolgreich abgeschlossene Berufsausbildung

- relevante Fortbildungsnachweise

- Arbeitszeugnisse

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
