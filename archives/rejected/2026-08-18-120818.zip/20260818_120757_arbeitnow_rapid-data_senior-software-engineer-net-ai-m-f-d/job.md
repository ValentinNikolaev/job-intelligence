# Senior Software Engineer - .Net & AI (m/f/d)

Posted: 2026-08-18T08:29:42Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
