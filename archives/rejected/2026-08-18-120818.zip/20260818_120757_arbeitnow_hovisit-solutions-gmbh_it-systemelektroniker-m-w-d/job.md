# IT-Systemelektroniker (m/w/d)

Posted: 2026-08-18T09:00:27Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Die HovisIT Solutions GmbH betreut kleine und mittelständische Unternehmen rund um ihre IT – von Arbeitsplätzen und Microsoft 365 über Netzwerke und IT-Sicherheit bis zu Servern und Managed Services. Hinter HovisIT stehe aktuell vor allem ich persönlich. Für die weitere Betreuung meiner Kunden suche ich einen IT-Systemelektroniker (m/w/d), der langfristig und zuverlässig mit mir zusammenarbeitet.

Dabei musst du nicht schon jedes System kennen. Entscheidend sind für mich solide IT-Grundlagen, technisches Verständnis und die Bereitschaft, dich in neue Themen einzuarbeiten. Deine Aufgabe ist es nicht, den Betrieb umzukrempeln oder neue Konzepte für meine Arbeitsweise zu entwickeln. Du sollst mitdenken, selbstständig Lösungen finden und deine Aufgaben innerhalb der bestehenden Abläufe zuverlässig zum Abschluss bringen.

Dein Arbeitsalltag besteht aus Support, Administration und technischen Projekten. Vieles kann per Fernwartung oder im Homeoffice erledigt werden, für andere Aufgaben bist du direkt beim Kunden. Als Arbeitsplatz steht ein Büro in Hamburg zur Verfügung.

## Aufgaben

- 1st- und 2nd-Level-Support per Fernwartung, Telefon und vor Ort

- Einrichtung, Wartung und Fehlerbehebung von IT-Hardware

- Administration von Windows Server, AD, GPO, Microsoft 365, Exchange und Entra ID

- Einrichtung und Betreuung von Netzwerken, VLANs, VPNs, Firewalls, WLAN

- Betreuung von Backup-, Monitoring-, RMM- und Endpoint-Security-Lösungen im MSP-Umfeld

- Installation und Inbetriebnahme von Server-, Netzwerk- und Arbeitsplatzlösungen

- Bearbeitung und nachvollziehbare Dokumentation der durchgeführten Arbeiten

## Qualifikation

- Eine abgeschlossene IT-Ausbildung ist von Vorteil, aber kein Muss; auch Berufseinsteiger und Quereinsteiger mit guten praktischen IT-Kenntnissen sind willkommen

- Du verfügst über solide Windows-Kenntnisse und kennst die Grundlagen von Netzwerken, IP, DNS und DHCP

- Erste Kenntnisse in Microsoft 365, Windows Server oder vergleichbaren IT-Infrastrukturen solltest du mitbringen

- Erfahrung bei einem IT-Dienstleister oder mit Managed Services ist von Vorteil, aber keine Voraussetzung

- Du arbeitest zuverlässig, sorgfältig und eigenständig, denkst bei Problemen mit und suchst nach pragmatischen Lösungen

- Du gehst freundlich und geduldig mit Kunden um, bleibst bei Störungen ruhig und besitzt einen Führerschein der Klasse B

**Diese Stelle passt nicht zu dir, wenn…**

- du jeden Tag neue Herausforderungen und ständigen Wandel brauchst

- du eigene Vorstellungen umsetzen und den Betrieb grundlegend neu ausrichten möchtest

- du möglichst schnell Personal führen oder in eine Leitungsrolle wechseln möchtes

- dir Status und Außenwirkung wichtiger sind als solide und zuverlässige Arbeit

Ich suche jemanden, auf den ich mich verlassen kann und der mit der Zeit immer mehr Aufgaben selbstständig erledigen kann. Wenn du gerne gründlich arbeitest, Neues lernst und auch dann gelassen bleibst, wenn technisch einmal nicht alles nach Plan läuft, passt das gut.

## Benefits

- 40.000–60.000 € Jahresbruttogehalt, abhängig von Erfahrung und Qualifikation

- Unbefristeter Arbeitsvertrag mit 3 Monaten Probezeit zum beidseitigen Kennenlernen

- 40-Stunden-Woche

- 30 Tage Urlaub

- Arbeitsplatz im Büro in Hamburg

- Flexibles Homeoffice nach Absprache und abhängig von den anstehenden Aufgaben

- Flexible Gestaltung des Arbeitstags im Rahmen der anstehenden Termine und Kundenaufträge

- Notebook und Smartphone

- Fachliche Fortbildungen und Zertifizierungen nach Absprache

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
