# Senior Produktmanager - Entlass-Manager (m/w/d)

Posted: 2026-08-18T08:30:18Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**Deine Mission:**

**Großartige Produkte entstehen dort, wo Nutzerbedürfnisse, Daten und unternehmerisches Denken zusammenkommen. Genau dafür suchen wir Dich.
Als Senior Produktmanager übernimmst Du die Verantwortung für unseren Entlass-Manager, setzt die richtigen Prioritäten und sorgst dafür, dass aus Ideen digitale Lösungen mit echtem Mehrwert für unsere Nutzer und unser Unternehmen entstehen. Der Übergang vom Krankenhaus nach Hause entscheidet oft darüber, wie es einem Menschen weitergeht. Wir vernetzen Kliniken digital mit den Versorgern ihrer Region und machen Entlass- und Überleitungsprozesse so schnell, effizient und rechtskonform, wie sie sein sollten. Als einer der führenden Anbieter digitaler Lösungen im Pflege- und Gesundheitswesen entwickeln wir unser Produkt kontinuierlich weiter und treiben die Digitalisierung der sektorenübergreifenden Versorgung aktiv voran. Dabei arbeitest Du an einem Produkt mit hoher Relevanz für unsere Kunden und sichtbarem Einfluss auf den Unternehmenserfolg.**

**Deine Aufgabe:**

- Du wirkst aktiv an der Weiterentwicklung unserer Produktstrategie mit und leitest daraus die Product Roadmap, den Product Backlog sowie die Priorisierung neuer Anforderungen ab. Dabei orientierst Du Dich konsequent an Nutzerbedürfnissen, Unternehmenszielen und dem größtmöglichen Mehrwert für unsere Kunden.
- Du identifizierst neue Produktpotenziale durch Product Discovery, validierst neue Produktideen frühzeitig und entwickelst gemeinsam mit Kunden Prototypen und Pilotlösungen. Dabei überführst du erfolgreiche Ansätze in skalierbare Produktlösungen.
- Du verstehst den Entlassalltag im Detail – aus Gesprächen mit Sozialdiensten und Case Managern, aus Nutzungsdaten und aus dem, was Deine Kunden Dir über ihre Engpässe berichten – und übersetzt das in Produktlösungen, die den Prozess spürbar entlasten.
- Du priorisierst Anforderungen datenbasiert, schärfst fachliche Anforderungen und begleitest deren Umsetzung gemeinsam mit unserem Entwicklerteam bis zum erfolgreichen Release.
- Du nutzt KPIs, Nutzungsdaten und Kundenfeedback, um den Erfolg unseres Produkts zu bewerten und fundierte Entscheidungen für dessen kontinuierliche Weiterentwicklung zu treffen.

**Deine Skills:**

- Du verfügst über mehrjährige Erfahrung als Produktmanager und hast digitale Produkte bereits mit hoher Eigenverantwortung über den gesamten Product Lifecycle erfolgreich weiterentwickelt – idealerweise in einem erklärungsbedürftigen B2B-Umfeld mit längeren Einführungszyklen.
- Du hast Erfahrung mit Product Discovery und datengetriebener Produktentwicklung und weißt, wie Du auch aus überwiegend remote geführten Kundengesprächen belastbare Erkenntnisse gewinnst.
- Du arbeitest Dich schnell in regulatorische Rahmenbedingungen ein und siehst sie als Gestaltungsraum, nicht als Hindernis. Kenntnisse im Entlassmanagement nach § 39 SGB V oder im Klinikumfeld sind ein klarer Vorteil.
- Du bringst Verständnis dafür mit, wie Software in einer Organisation eingeführt wird, in der viele Berufsgruppen zusammenarbeiten – und wie Produktentscheidungen die Akzeptanz beim Anwender beeinflussen.
- Du hast Erfahrung darin, Potenziale von Künstlicher Intelligenz für digitale Produkte zu identifizieren und in nutzerorientierte Funktionen, Prozesse oder Produktinnovationen zu überführen.
- Du arbeitest analytisch, denkst unternehmerisch und triffst fundierte Entscheidungen auch dann, wenn nicht alle Informationen vollständig vorliegen.
- Ein abgeschlossenes Studium der Wirtschaftsinformatik, Informatik, Betriebswirtschaftslehre oder eine vergleichbare Qualifikation bildet eine gute Grundlage. Entscheidender sind für uns jedoch Deine Erfahrung, Deine Arbeitsweise und Deine nachweisbaren Erfolge im Produktmanagement.
- Du verfügst über sehr gute Deutsch- und Englischkenntnisse in Wort und Schrift.

**Dein Vorteil:**

- Ein attraktives Fixgehalt mit extra steuerfreien 50 € monatlich sowie einem Zuschuss von 49 € für Dein Deutschlandticket
- Vollzeitmodell mit Gleitzeit und 29 Tagen Urlaub im Jahr
- Strukturierte Einarbeitung und ein umfassender Weiterbildungskatalog
- Starke Feedbackkultur und ein transparentes Beförderungssystem mit klaren Entwicklungsperspektiven
- Top-Performer- und Teamevents sowie drei große Unternehmensfeiern im Jahr
- Ein modernes Büro direkt am Rhein, Jobrad- und Technik-Leasing, betriebliche Altersvorsorge, exklusive Mitarbeiterrabatte sowie kostenlose Snacks, Obst und Getränke
- Unser Feel Good Management, das sich um Dein Wohlbefinden kümmert
- Für Sportfans stehen Duschen im Gebäude bereit, ideal nach einer Runde am Rhein

**Dein Bewerbungsprozess:**

1. Telefoninterview + Practical Case
2. Vorstellungsgespräch
3. Finales Vorstellungsgespräch

Deine Bewerbung bestehend aus:
- Lebenslauf
- Anschreiben
- Akademisches Abschlusszeugnis
- Arbeitszeugnis der letzten beiden Arbeitgeber

Bewerber mit Schwerbehinderung werden bei gleicher Eignung bevorzugt berücksichtigt.

**Wir freuen uns auf Dich!**

**Kontakt:**

Herr Michael Haas
Verbund Pflegehilfe
Inge-Reitz-Str. 5-7
55120 Mainz

[pflegehilfe.org/karriere](https://www.pflegehilfe.org/karriere)

01735209826 (Mo-Fr 10 Uhr bis 16 Uhr)

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
