# Senior Strategic Buyer – Mechanical Components (m/f/d)

Posted: 2026-08-18T08:29:09Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
