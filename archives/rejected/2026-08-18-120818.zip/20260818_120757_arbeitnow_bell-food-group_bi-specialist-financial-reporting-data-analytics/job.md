# BI Specialist - Financial Reporting & Data Analytics

Posted: 2026-08-18T08:30:29Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Bei Hügli schauen wir, dass wir unsere BI-Landschaft laufend auf den neusten Stand bringen. Als BI Specialist bist du in dieser Funktion nicht einfach Entwickler oder klassischer Controller: Du bist das Bindeglied zwischen Finance & Controlling, Business und IT und hilfst dabei, Reporting und Analytics von Grund auf neu zu denken.Du bringst dein Verständnis für finanzielle Zusammenhänge ein, übersetzt fachliche Anforderungen in moderne BI-Lösungen und setzt diese mit Technologien wie Power BI, SAP und Microsoft Azure selbstständig um. Dabei arbeitest du projektorientiert, hast viel Gestaltungsspielraum und begleitest die Weiterentwicklung unseres Reportings aktiv.

## Aufgaben

- Reporting neu denken: Du entwickelst moderne Reporting- und Analytics-Lösungen mit Power BI und gestaltest unser Financial Reporting aktiv mit

- Finance & Controlling: Du verstehst die fachlichen Anforderungen aus Finance und Controlling und übersetzt diese in nachhaltige technische Lösungen

- BI-Lösungen entwickeln: Du konzipierst und entwickelst Power-BI-Reports, Datenmodelle und komplexe DAX-Logiken eigenständig weiter

- Daten nutzbar machen: Du arbeitest mit SAP-Daten, verstehst relevante Strukturen und leitest daraus die benötigten Informationen für Reporting und Analytics ab

- Cloud & Data: Du nutzt Microsoft Azure, Azure Data Lake bzw. moderne Microsoft-Fabric-Technologien, um Daten für die weitere Verarbeitung und Analyse bereitzustellen

- Projekte gestalten: Du begleitest Finance-Projekte entlang unserer Financial Roadmap, entwickelst neue Berichtlösungen und stimmst diese eng mit den Fachbereichen ab

- Innovation vorantreiben: Du beschäftigst dich mit neuen Technologien und KI-gestützter Entwicklung und bringst diese dort ein, wo sie einen echten Mehrwert für Reporting und Analytics schaffen

- Schnittstelle sein: Du arbeitest eng mit Finance & Controlling, dem BI-Team sowie dem gruppenweiten Umfeld zusammen und übernimmst dabei eine beratende Rolle

## Qualifikation

- Du hast einen Finance- oder Controlling-Hintergrund und dich im Laufe deiner Karriere in Richtung IT, Business Intelligence oder Data Analytics weiterentwickelt - alternativ verfügst du über eine vergleichbare Kombination aus Business- und IT-Erfahrung

- Du verfügstüber fundierte Erfahrung mit Power BI und kannst Reports, Datenmodelle und auch komplexe DAX-Logiken selbständig entwickeln

- Du verstehst FInance- und Controlling-Prozesse und kannst fachliche Anforderungen hinter Zahlen, Reports und Kennzahlen nachvollziehen und hinterfragen

- Du kennst dich mit SAP-Daten und -Strukturen aus, idealerweise im Umfeld von FI/CO, und kannst relevante Daten für Reporting und Analysen identifizieren und nutzen

- Du hast praktische Erfahrung mit Microsoft Azure, insbesondere Azure Data Lake, Microsoft Fabric oder vergleichbaren Cloud-Technologien

- Du bringst gute SQL- und Datenverständnis mit und hast idealerweise bereits mit Data Warehouses, ETL-Prozessen oder vergleichbaren Datenarchitekturen gearbeitet

- Du denkst analytisch und konzeptionell, kannst Anforderungen strukturieren und Lösungen entwickeln und hast bereits Erfahrung in der Durchführung von Projekten

- Du bist kommunikationsstark in Deutsch und Englisch und fühlst dich wohl darin, zwischen Fachbereichen und IT zu vermitteln

## Benefits

- Work-Life-Balance: Wir bieten flexibles Arbeiten an 4,5 Tagen die Woche, mehr als 30 Tage frei im Jahr und 1 Tag pro Woche im Mobile Office zu arbeiten

- Verpflegung: Kulinarik wird bei uns gross geschrieben, frisch zubereitetes Essen in unserer Kantine macht es für unsere Mitarbeitenden erlebbar

- Mobilität: Mit unserem Fahrkostenzuschuss, der guten Anbindung an den ÖPNV sowie ausreichend Parkplätzen für Auto und Fahrrad sind unsere Mitarbeitenden mobil

- Berufliche Weiterentwicklungsmöglichkeiten: Bei uns erwarten dich berufliche Weiterentwicklungsmöglichkeiten in einem internationalen Umfeld. Mit unserem Schulungscampus bieten wir vielfältige Weiterbildungsangebote und regelmässige Schulungen

- Gesundheit: Mit HANSEFIT können alle Mitarbeitenden Angebote für Sport-, Freizeit- & Wellnessangebote in ganz Deutschland nutzen. Zusätzlich bietet unser JobRad die Möglichkeit, umweltfreundlich und fit mobil zu bleiben

- Firmenevents: Vielseitige Firmenevents sorgen für eine tolle Gemeinschaft und eine familiäre Arbeitsathmosphäre

- Faire Löhne und Sozialleistungen: Unsere attraktiven finanziellen Zusatzleistungen umfassen betriebliche Altersvorsorge, Urlaubsgeld, Jahressondervergütung, Mitarbeiterbeteiligung und Jubiläumszahlungen

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
