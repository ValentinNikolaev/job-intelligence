# Strategy & Operations Lead (f/m/d)

Posted: 2026-08-18T09:00:25Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

## Short Description

SPREAD builds engineering intelligence for the world's most complex products. Our AI-native platform gives automotive OEMs, defense primes, and industrial manufacturers a single source of product truth so engineering teams can make confident product decisions, fast. We work with companies like Volkswagen, BMW, Mercedes-Benz, Audi, Bosch, and Rheinmetall. Backed by HV Capital, DTCP, La Famiglia, and Salesforce, and recognized with the SPARK AI Innovation Award and a place among LinkedIn's Top Startups in DACH.

**Role**

In this role, you sit inside the Founders' Office and work on the decisions that set SPREAD's direction. You own the strategy cycle and translate it into company goals and OKRs; you drive the strategic and improvement initiatives that come out of it, and you run the operating rhythm that keeps the leadership team deciding and the company executing. Alongside that, you own SPREAD's ecosystem of partners and senior industry advisors. You shape how the whole company hears about strategy through the monthly Assembly, and you build the material founders and the leadership team decide on. You report to the VP Strategy & Finance and work daily with the founders, the leadership team, and the people delivering the outcomes you help define.

## Your Mission

- Own the strategy cycle from analysis through to a written strategy the leadership team commits to, then translate it into company OKRs, goals, and the quarterly review rhythm that keeps every team measured against them.

- Drive strategic and improvement initiatives end to end. Recent examples include improving our cross-functional delivery model, leveling up our performance management system, building out our competitor intelligence, and rolling AI agents out company-wide.

- Run the operating rhythm of the leadership team across the weekly leadership meeting, monthly workshops, and half-year offsites. Set the agenda, prepare the discussions and decisions, and track every decision and task.

- Own the monthly company Assembly, from storyline to deck, so every team leaves knowing where SPREAD stands, where we are going, and what it means for their work.

- Build and steer SPREAD's partner ecosystem across hyperscalers, systems integrators, strategy consultancies, and tech companies, and convert those relationships into commercial opportunities, co-marketing and integrated offerings.

- Manage SPREAD's portfolio of senior industry advisors, former executives from the automotive and defense industry, to generate commercial opportunities and capture deep industry insights and expertise.

- Step into selected high-stakes commercial opportunities and ongoing engagements alongside Sales, Product, Value Realization, and Engineering, bringing structure and pace.

- Prepare investor materials and board reporting across fundraising rounds and quarterly cycles.

## Your Experience

- 4+ years in strategy consulting, investment banking, or an operating strategy role inside a scale-up, with end-to-end ownership of your own workstreams and direct exposure to the client side.

- Deep understanding of the automotive and/or defense industry. You know how a vehicle or a defense platform moves from requirement to development to integration to testing to production to field service, and you can hold that conversation with a senior engineering leader.

- Business-fluent German and English, because both appear in the same week across leadership meetings, partner negotiations, customer conversations, and investor material.

- A strong analytical toolkit covering quantitative analysis and executive-level materials. You do the analysis, and you write the slide that makes it decision-ready.

- Track record of driving decisions with executive stakeholders, including the judgment to know which questions belong in the room and which you resolve before the meeting starts.

- Experience turning strategy into action, whether through OKRs, a goal cascade, or an operating rhythm you designed and ran yourself.

- Commercial instinct for partnerships and customer opportunities. You are comfortable opening a relationship, holding a cadence, and being honest with yourself about which relationships produce outcomes and which absorb time.

- AI-native working style. You use AI tools daily to scale your output across research, analysis, drafting, and workflow automation. SPREAD is an AI-first company, and every team member operates accordingly.

- Based in Berlin or close enough for regular in-office collaboration.

## Why SPREAD?

- Work on the questions that decide where a company building engineering intelligence for the products that move the world goes next, with the founders and the leadership team as your direct counterparts.

- Own initiatives end to end with full visibility across Product, Engineering, Sales, Finance, and the partner ecosystem, and see your work land in the company's direction and in decisions that actually get made.

- Grow inside a high-talent-density environment with direct feedback and a leadership team that expects you to challenge it.

- Attractive compensation, an annual learning budget, and workation options.

- Deutschlandticket mobility budget and Urban Sports Club partnership.

- 30 vacation days and one paid volunteering day per year.

- Lunch provided three times per week in our Berlin office.

## Contact

**Dmytro İefymenko**

Köpenicker Str. 40c | 10179 Berlin

Stay connected—follow us on for the latest insights and updates

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
