# Senior Manager Digital Transformation (m/w/d)

Posted: 2026-08-18T07:30:28Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Das Estrel ist mit 1.125 Zimmern und Suiten, vier Restaurants und drei Bars, einem multifunktionalen Congress Center und Berlins erfolgreichster Live Show „Stars in Concert“ Europas größtes Hotel-, Congress- & Entertainment-Center. Mit 1.200 Veranstaltungen jährlich belegt das Estrel eine Spitzenposition als Kongress- und Event-Location. Ein Team von 550 Mitarbeitenden aus 23 Nationen betreut unsere nationalen und internationalen Gäste und Kunden. Zum jetzigen Zeitpunkt entsteht der Estrel Tower, der bis Ende 2026 die „Estrel Welt“ erweitern wird.

## Aufgaben

- Konzeption, Steuerung und Umsetzung unternehmensweiter Digitalisierungs- und IT-Transformationsprojekte

- Analyse, Modellierung und Weiterentwicklung von Geschäfts- und IT-Prozessen als Grundlage für digitale Lösungen

- Erstellung von Projektdokumentationen

- Weiterentwicklung von IT-Architekturen sowie Analyse und Optimierung der bestehenden Prozess- und Systemlandschaft

- Sicherstellung von Integration, Skalierbarkeit und Performance neuer Systeme

- Übersetzung fachlicher Anforderungen aus den operativen Bereichen in praktikable, umsetzbare IT-Lösungen

- Weiterentwicklung von Governance-, Qualitäts- und Projektstandards im IT- und Digitalumfeld

- Aktive Begleitung von Change- und Transformationsprozessen

## Qualifikation

- Mehrjährige Erfahrung in der Projektleitung von Digitalisierungs- und IT-Transformationsprojekten

- Sehr gutes Verständnis moderner IT-Architekturen (z. B. ERP, CRM, Cloud- und hybride Infrastrukturen, APIs)

- Ausgeprägte Kompetenz in Prozessanalyse, -modellierung und strukturierter Dokumentation

- Erfahrung in der Bewertung von Softwarelösungen

- Change-Management-Erfahrung sowie Fähigkeit, komplexe Inhalte verständlich und zielgruppengerecht aufzubereiten

- Strategische Denkweise mit hoher Umsetzungsstärke

- Strukturierte, lösungsorientierte und teamorientierte Arbeitsweise sowie Freude an komplexen Aufgaben und Lösungskonzepten

- Sicheres Auftreten und Kommunikationsstärke im Austausch mit Fachbereichen und Management

- Verhandlungssichere Deutsch- und Englischkenntnisse in Wort und Schrift

## Benefits

- Familiäres Arbeitsklima in einem engagierten Team mit Leidenschaft für die Hotellerie und Gastronomie

- Unbefristeter Arbeitsvertrag

- 28 Tage Urlaub mit Steigerung nach Betriebszugehörigkeit

- Urlaubs- und Weihnachtsgeld

- Kostenfreier Mitarbeiter-Parkplatz

- Betriebliche Altersvorsorge sowie vermögenswirksame Leistungen

- Family & Friends Rate

- Sonderkonditionen für Restaurant & Bar

- Zuschuss zum BVG-Ticket

- Zuschuss zum Urban Sports Club

- JobRad - Leasing eines Fahrrads für Arbeitsweg und Freizeit

- Personights - exklusive Angebote für Mitarbeitende in anderen Hotels

- Mitarbeiterrestaurant - frische und preiswerte Mahlzeiten vor Ort

- Breites Angebot an Schulungen und Weiterbildungen, inkl. Estrel Academy für die Karriereentwicklung

Wenn Sie in einem erfolgreich geführten Privatunternehmen arbeiten möchten, in dem Innovationen und Nachhaltigkeit im besonderen Maße im Mittelpunkt stehen und Sie mit sehr motivierten und einzigartigen Kolleginnen und Kollegen arbeiten möchten, dann sind Sie richtig bei uns.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
