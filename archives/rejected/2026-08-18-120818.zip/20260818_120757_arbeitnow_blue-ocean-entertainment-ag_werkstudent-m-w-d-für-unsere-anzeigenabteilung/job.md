# Werkstudent (m/w/d) für unsere Anzeigenabteilung

Posted: 2026-08-18T08:09:44Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**Ihre/Deine Aufgaben**

- Als Teil unseres Teams übernimmst du eigenverantwortlich Aufgaben in unserem Tagesgeschäft
- Du unterstützt uns bei allen Themen rund um die Kundenbetreuung, -gewinnung und -kommunikation
- Du arbeitest aktiv im Kundenmarketing mit und hilfst u.a. bei der Erstellung und Versendung von Mailings
- Du unterstützt uns bei der Abwicklung unserer Prozesse rund um den Anzeigenverkauf
- Du analysierst aktuelle Trends und recherchierst Themen mit denen wir bei unseren Kunden punkten können
- Du sorgst dafür, dass unser Anzeigenlager stets mit den aktuellsten Magazinen ausgestattet ist
- Du machst Kids glücklich, indem du sie als Gewinner unserer Preisausschreibungen auslost

**Ihr/Dein Profil**

- Du befindest dich idealerweise in einem Studiengang mit dem Schwerpunkt Medien und hast vielleicht schon erste Praxiserfahrungen im Bereich Print sammeln können
- Du bist sicher im Umgang mit MS Office-Programmen
- Du kannst flexibel auf Anforderungen reagieren, bist teamfähig und arbeitest selbständig und strukturiert
- Du hast Lust unsere Anzeigenabteilung von A bis Z kennenzulernen und einen facettenreichen Einblick in die bunte Magazinwelt bei Blue Ocean zu erhalten

**Was wir bieten:**

- Die Option eines direkt an deine Werkstudententätigkeit anschließenden 6-monatigen Praxissemesters
- Viel Flexibilität und eine freie Zeiteinteilung
- Ein modernes Büro im Herzen Stuttgarts
- Nie versiegende Quellen an Wasser, Saftschorlen, Kaffee und Tee

**Interessiert?**

Dann bewirb Dich bei uns! Wir bieten Dir eine interessante, spannende und vielseitige Tätigkeit in einem Team, das nicht nur viel bewegt, sondern auch großen Spaß daran hat!

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
