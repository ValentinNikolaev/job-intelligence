# SOC-Analyst/SIEM Engineer (W/M/D)

Posted: 2026-08-18T10:00:31Z

## Rejection

- Category: language_requirement
- Reason: hard German language requirement without English green light

**Festanstellung | Vollzeit** | **Remote** **| Deutschland**

Als SOC-Analyst/SIEM Engineer stärken Sie unsere IT-Sicherheit durch wirksames Monitoring, präzise Analysen und die kontinuierliche Weiterentwicklung unserer SIEM- und Security-Monitoring-Landschaft

## Aufgaben

- Sie überwachen und analysieren sicherheitsrelevante Ereignisse aus SIEM, EDR, Firewall, Netzwerk, Servern, Cloud-Diensten und weiteren IT-Systemen

- Sie bewerten und priorisieren Security Alerts nach Kritikalität, Risiko und möglicher Auswirkung auf den Geschäftsbetrieb

- Sie entwickeln und optimieren Korrelationsregeln, Detection Use Cases, Dashboards und Reports

- Sie unterstützen bei der Untersuchung, Eindämmung und Nachbearbeitung von IT-Sicherheitsvorfällen

- Sie dokumentieren Vorfälle, Analyseergebnisse, Entscheidungen und Maßnahmen nachvollziehbar und prüfbar

- Sie arbeiten eng mit IT-Infrastruktur, IT Operations, Informationssicherheit, Datenschutz und externen Security-Partnern zusammen

- Sie wirken an Sicherheitsprojekten, Tool-Einführungen und der Weiterentwicklung der Security-Monitoring-Landschaft mit

## Qualifikation

- Sie verfügen über mehrjährige Berufserfahrung in IT-Security, Security Operation, SIEM Engineering oder IT-Infrastruktur

- Sie kennen Security Monitoring, Log-Analyse, SIEM-Betrieb und Incident Detection sehr gut

- Sie bringen mehrjährige Erfahrung mit FortiSIEM mit

- Sie kennen idealerweise weitere SIEM- und Security-Tools wie Microsoft Sentinel, Splunk, Elastic, QRadar oder vergleichbare Lösungen

- Sie verfügen über Kenntnisse in Windows, Linux, Netzwerken, Firewalls, Active Directory, Cloud-Diensten und Endpoint Security

- Sie entwickeln sich kontinuierlich weiter und bringen die Bereitschaft mit, relevante Schulungen und Zertifizierungen zu absolvieren

- Sie analysieren komplexe technische Sachverhalte strukturiert, präzise und risikoorientiert

- Sie arbeiten verantwortungsbewusst, diskret und ruhig in zeitkritischen Situationen

- Sie verfügen über fließende Deutschkenntnisse und über Englischkenntnisse

## Benefits

- Vertrauen! Arbeitszeit selbstverantwortlich gestaltbar

- Geschichte! Arbeitsplatz in Pulsnitz (Anbindung ÖPNV: S8 aus Dresden) in einem historischen Gebäude mit moderner Ausstattung

- Lebenslanges Lernen! Bedarfsorientierte Zertifizierungen und Weiterbildungen

- Kultur! Wertschätzendes Miteinander, offene Kommunikation und dynamische Teams

- Work-Life-Balance! 30 Tage Basis-Urlaub

Auf Sie wartet eine anspruchsvolle, abwechslungsreiche Tätigkeit mit Perspektive in einem spannenden und wachstumsstarken Unternehmen. Wir haben Ihr Interesse geweckt? Dann freuen wir uns über Ihre Bewerbung.

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
