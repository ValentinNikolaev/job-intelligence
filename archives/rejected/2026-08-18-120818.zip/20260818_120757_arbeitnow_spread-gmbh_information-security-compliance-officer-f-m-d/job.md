# Information Security & Compliance Officer (f/m/d)

Posted: 2026-08-18T07:30:27Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

## Short Description

SPREAD builds engineering intelligence for the world's most complex products. Our AI-native platform gives automotive OEMs, defense primes, and industrial manufacturers a single source of product truth so engineering teams can make confident product decisions, fast. We work with companies like Volkswagen, BMW, Mercedes, Bosch, Stadler, and Rheinmetall. Backed by HV Capital, DTCP, La Famiglia, and Salesforce.

You'll support and grow into owning SPREAD's information security and compliance program: ISO 27001, SOC 2, and TISAX, alongside the technical and IT operations that keep it running. You inherit a working program, three live certifications, and an established evidence base, not a blank slate. As you take on more of each certification cycle independently, the scope and title grow with you toward full ownership of the program.

## Your Mission

- Support ISO 27001, SOC 2 Type II, and TISAX audit cycles end-to-end, building on our existing evidence base, and take on more ownership of each cycle as you grow into the role.

- Answer customer and OEM security questionnaires directly with the GTM team, turning security review into a reason deals close.

- Present ISMS status and audit results directly to SPREAD's leadership team each cycle.

- Maintain the risk register, policies, and vendor and supplier security assessments, keeping the whole program audit-ready year-round.

- Run security awareness training and phishing simulations across the company.

- Administer identity and access: provisioning, access reviews, conditional access, and RBAC, kept as audit evidence for the program above.

- Manage device and endpoint lifecycle across the company: procurement, enrollment, repair, and retirement.

- Own end-user IT support and the full joiner-mover-leaver process: ticket queue, onboarding and offboarding, and the office network.

- Automate repetitive IT and evidence-collection work in Vanta and beyond, in line with how SPREAD approaches automation across the business.

## Your Experience

- 3 to 5 years of hands-on experience in IT operations, InfoSec operations, or a compliance-adjacent IT role.

- Direct experience supporting a full ISO 27001 or SOC 2 audit cycle, evidence collection and auditor liaison included.

- Currently working, or recently worked, in a small security or compliance function alongside a senior person above you.

- Strong, hands-on identity and access management (Entra ID or comparable IdP): provisioning, access reviews, conditional access, RBAC.

- Strong M365/Exchange Online administration and Mac-first endpoint management.

- Comfortable owning an end-user support queue and the full joiner-mover-leaver process.

- Fluent German proficiency and eligibility to obtain a German security clearance or equivalent.

- *Bonus:* Direct exposure to TISAX or the automotive OEM security ecosystem.

- *Bonus:* Scripting or automation skills and the instinct to remove repetitive work.

- *Bonus:* Exposure to Vanta or a similar compliance platform.

## Why SPREAD?

- You're joining a security program that's already protecting deals with some of the biggest names in automotive, with a clear path to owning it fully.

- High ownership and measurable impact. You connect your work directly to the success of the organization.

- A senior team that values craft, speed, and accountability over process and hierarchy.

- Strong overall package including attractive compensation, VSO and an annual learning budget.

- Mobility and wellbeing support through a Deutschlandticket mobility budget, bike-leasing and an Urban Sports partnership.

- Time off and flexibility with 30 vacation days, and one paid volunteering day per year.

## Contact

**Dmytro İefymenko**

Köpenicker Str. 40c | 10179 Berlin

Stay connected—follow us on for the latest insights and updates

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
