# Bankkaufmann in der Geldwäscheprüfung (all genders) - 100% remote

Posted: 2026-08-18T07:30:27Z

## Rejection

- Category: tech_stack
- Reason: role does not mention Go/Golang or PHP

**Gestalte die digitale Zukunft mit fino digital!**

fino hat seine Wurzeln im ersten digitalen und vollautomatisierten Kontowechsel der FinTech-Branche. Seit der Gründung im Jahr 2015 hat sich fino stetig weiterentwickelt und ist heute der marktführende Innovationstreiber in den Bereichen Konto- und Datenanalyse, Regulatorik, Steuern und Dokumentenmanagement. Mit maßgeschneiderten Softwarelösungen schafft fino für seine Kunden und Partner neue Perspektiven für Geschäftsmodelle im B2B- und B2B2C-Bereich.

Wir bei fino digital sind überzeugt, dass datengetriebenen Geschäftsmodellen die Zukunft gehört. Unsere Mission ist es, Daten einen Wert zu geben und sie durch intelligente Data-Analytics-Lösungen in hochwertige Insights zu verwandeln. Mit über 240 Millionen durchgeführten Transaktionsanalysen und Kooperationen mit mehr als 1.000 Banken sowie 10.000 weiteren Partnern, darunter renommierte Namen wie Sparkassen, VR-Banken, DATEV und Schufa, genießen wir das Vertrauen zahlreicher Unternehmen und Institutionen.

Möchtest du Teil dieses innovativen Teams werden und die digitale Zukunft aktiv mitgestalten? Dann bewirb dich jetzt bei fino digital!

**Deine Aufgaben**

- Du sichtest und prüfst fristgerecht transaktionsbezogene Daten auf Hinweise für Geldwäsche

- Du gehst Auffälligkeiten nach, klärst offene Fragen und dokumentierst deine Prüfergebnisse nachvollziehbar

- Bei Verdachtsfällen veranlasst du die notwendigen Meldungen

- Du pflegst und aktualisierst die Prüfkriterien (z. B. Szenarien und Schwellenwerte)

- Du bringst dich aktiv in die Weiterentwicklung unseres AML-Tools und der dazugehörigen Prozesse ein

- Du bist Ansprechpartner für interne Rückfragen rund um das Thema Geldwäsche

**Deine Qualifikationen**

- Du bringst Berufserfahrung im Bereich Geldwäscheprävention / AML mit – idealerweise aus dem Bankenumfeld

- Der Umgang mit Zahlen und Daten liegt dir und du hast ein gutes Gespür für Zusammenhänge und Auffälligkeiten

- Du arbeitest eigenverantwortlich und bringst deine Erfahrung und Ideen gerne proaktiv ein

- Du sprichst verhandlungssicheres Deutsch

**Unsere Benefits**

- **Gestaltungsspielraum:** Viel Eigenverantwortung, offene Kommunikation, aktive Mitgestaltung und ein motiviertes, erfolgsorientiertes Team

- **Flexibles Arbeiten:** Remote-first mit hybrider Option am Standort Kassel, flexible Arbeitszeiten, modernes Equipment, Workation

- **Attraktive Zusatzleistungen:** Jahresbonus, Geschenke zu Jubiläen und runden Geburtstagen, Corporate Benefits, vergünstigte Handytarife, übergesetzliche Zuschüsse zur betrieblichen Altersvorsorge, Vermögenswirksame Leistungen

- **Gesundheit & Mobilität:** Jobticket, Bikeleasing, vergünstigte Fitness- & Wellnessangebote in deiner Stadt (egym)

- **Team & Office-Life:** Sommer- & Weihnachtsfeiern, regelmäßige Teamtreffen, Office in Kassel mit hundefreundlichen Arbeitsplätzen

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
