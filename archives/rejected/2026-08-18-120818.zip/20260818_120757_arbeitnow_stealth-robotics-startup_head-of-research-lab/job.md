# Head of Research Lab

Posted: 2026-08-18T09:00:26Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Join a well-funded robotics startup founded out of TUM MIRMI and backed by €1M+ in pre-seed funding from a leading European VC. Our mission is to bring frontier Robot Learning and Physical AI research to industrial readiness. Alongside our industrial deployment business, we are building a dedicated Robotics Lab to explore, validate and industrialize the next generation of robotics technologies. You will have the unique opportunity to shape this lab from day one, define its research direction, pursue ambitious projects with real industrial impact, and build your own team as the lab grows. As a founding role, the position includes meaningful equity participation.

We encourage to apply globally and offer significant support for relocation.

## Aufgaben

- Build and shape our Robotics Lab from the ground up

- Define and pursue research in Robot Learning, dexterous manipulation and mobile robotics

- Turn frontier research into working prototypes on real robotic systems

- Explore new approaches and rapidly validate promising ideas

- Bridge the gap between research and real-world industrial deployment

- Build your own research team as the Lab grows

## Qualifikation

This is a highly selective role. We are looking for an exceptional researcher with the potential to define a research field, not simply execute against an existing roadmap.

- Outstanding track record in Robotics, Robot Learning, or Embodied AI from a top-tier research environment

- Deep expertise in areas such as Robot Learning, VLA/Foundation Models, manipulation, imitation learning, or robotic perception

- Evidence of exceptional research ability through top-tier publications, influential projects, open-source contributions, or comparable technical achievements

- Strong hands-on ability to turn novel research ideas into working systems on real robots

- Experience with modern robotics and ML stacks such as Python, PyTorch, ROS/ROS2, and large-scale model training

- Strong technical intuition and the ability to independently identify research directions worth pursuing

- High ambition, intellectual curiosity, and a desire to build rather than simply join an established research organization

## Benefits

- **Your own Robotics Lab** — shape its research direction and infrastructure from day one

- **Research freedom** — pursue ambitious ideas with significant autonomy and resources

- **Real-world impact** — direct access to real robots, industrial problems, and deployments

- **Resources to build** — access the hardware, compute, and budget needed to move fast, without spending your time chasing grants or asking permission

- **Meaningful equity** — participate in the long-term value you help create

- **Build your own team** — grow a dedicated research team over time

- **At the heart of European robotics** — build and research in Munich, one of Europe’s leading hubs for robotics and AI

Our ambition is to build a company where real-world industrial deployment and frontier robotics research continuously reinforce each other — turning access to robots, data, and real environments into a unique foundation for Physical AI.

You will have the freedom, resources, and ownership to build the research side of that vision — without having to raise funding, run sales, or build the business around it.

If you want to help build what could become one of Europe’s defining Physical AI companies, this is your opportunity to shape it from the beginning.

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
