# Praktikant:in Social Media & Content Creation (m/w/d)

Posted: 2026-08-18T08:00:33Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

PILLAR entwickelt und montiert Solarcarports, PV-Montagesysteme und Schraubfundamente. Große Maschinen, echte Baustellen, sichtbare Ergebnisse, aber online findet das bisher kaum jemand.

Genau das ist dein Job. Du machst aus dem, was auf unseren Baustellen passiert, Content, der Leute festhält: kein Hochglanz-Imagefilm, sondern das, was auf Instagram, TikTok und LinkedIn wirklich funktioniert.

Wir suchen dich für drei Monate, mit der klaren Absicht, dich danach fest zu übernehmen.

## Aufgaben

**Videos drehen** – im Büro, auf der Baustelle, beim Kunden vor Ort. Du hast die Kamera in der Hand, wenn der Bohrer im Boden steckt.

**Videos schneiden** – Cuts, Sound, Untertitel, Hooks. Du bereitest jeden Clip publikationsfertig für die jeweilige Plattform auf.

**Bilder erstellen und aufbereiten** – von der Aufnahme über die Bearbeitung bis zum fertigen Post inklusive Formaten, Text-Overlays und Thumbnails.

**Trends erkennen und übersetzen** – du weißt, welches Format oder welcher Sound gerade läuft, und überlegst dir, wie das zu einer Baustelle passt.

**Eigene Ideen einbringen** – du wartest nicht auf Briefings, sondern schlägst Formate vor, testest sie und schaust dir an, was funktioniert hat.

**Content-Planung unterstützen** – du hilfst mit, einen Redaktionsplan aufzubauen, damit regelmäßig etwas rausgeht.

## Qualifikation

Du bist auf TikTok, Instagram und YouTube nicht nur Zuschauer, sondern verstehst, warum ein Video läuft und ein anderes nicht.

Erste Erfahrung im Videoschnitt (CapCut, Premiere, DaVinci, After Effects – womit du arbeitest, ist uns egal, solange das Ergebnis stimmt).

Du erzeugst mit Kamera oder Smartphone brauchbares Material: Bildaufbau, Licht, Ton.

Bildbearbeitung auf Basisniveau (Photoshop, Canva, Figma o. Ä.).

Du gehst gerne auf Baustellen und hast keine Berührungsangst mit Dreck, Lärm und Sicherheitsschuhen.

Führerschein Klasse B von Vorteil aber kein muss.

Du arbeitest eigeninitiativ und selbstorganisiert.

Deutsch fließend, Englisch von Vorteil.

Du bist in München oder Umgebung und kannst regelmäßig ins Büro kommen.

## Benefits

**Ein Praktikum mit echter Perspektive:** Diese Stelle ist ausdrücklich als Einstieg gedacht. Wenn es auf beiden Seiten passt, übernehmen wir dich im Anschluss als **Social Media Manager (m/w/d)** in Festanstellung.

**Kreative Freiheit von Tag eins** – du baust unseren Social-Media-Auftritt von Grund auf mit, statt bestehende Vorgaben abzuarbeiten.

**Kurze Wege** – direkter Draht zur Geschäftsführung, kein Freigabe-Marathon über fünf Ebenen.

**Abwechslung** – Büro in München und Außeneinsätze auf Baustellen.

**Vergütung: Das Praktikum wird vergütet.

**

**Ein Portfolio, das sich sehen lässt** – am Ende der drei Monate hast du echte Cases mit echten Zahlen.

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
