# Vertriebsleitung, Sales Team Lead (m/w/d)

Posted: 2026-08-18T08:30:30Z

## Rejection

- Category: tech_stack
- Reason: role does not mention Go/Golang or PHP

TutorSpace ist eine der schnellstwachsenden Bildungsplattformen in Deutschland. Nachdem wir den Nachhilfemarkt bereits digitalisiert haben, wollen wir auch die Zukunft der Online-Nachhilfe mitbestimmen. Warum? Um jedem Schüler zu ermöglichen, sein volles Potenzial zu entfalten.

Genau darum suchen wir aktuell neue Mitstreiter, die uns dabei unterstützen, die besten Online-Lehrkräfte in Deutschland mit den Schülern zusammenzubringen, die Unterstützung brauchen. Eine einmalige Möglichkeit, nicht nur einen signifikanten Einfluss auf die Noten von tausenden Schülern zu nehmen, sondern auch an sich selbst zu wachsen und hohe Verantwortung zu übernehmen.

Bist du bereit, die Challenge anzunehmen?

## Aufgaben

- Du übernimmst die fachliche und disziplinarische Führung eines Sales-Teams und coachst deine Kolleg:innen mit Fokus auf nachhaltige Steigerung der Abschlussquote.

- Du berätst weiterhin selbst telefonisch Eltern, die sich für unsere Nachhilfe interessieren, und begleitest sie bis zur ersten Unterrichtseinheit – mit einem reduzierten eigenen Leadvolumen, um Raum für Coaching zu schaffen.

- Du analysierst Gesprächsaufzeichnungen und Call-Daten deines Teams, identifizierst Verbesserungspotenziale und gibst gezieltes, individuelles Feedback.

- Du entwickelst und dokumentierst Verkaufsmethodik – von der Bedarfsanalyse bis zum Zusatzverkauf – und machst sie für das gesamte Team nutzbar.

- Du verantwortest die Weiterentwicklung des Teams: Onboarding neuer Sales-Mitarbeitender, laufendes Performance-Tracking und regelmäßige 1:1s.

- Du berichtest direkt an die Geschäftsführung und bringst deine Erkenntnisse aktiv in die Weiterentwicklung unserer Vertriebsstrategie ein.

## Qualifikation

**Qualifikationen:**

- **Mehrjährige Erfahrung** im telefonischen B2C-Vertrieb, idealerweise in einem Abo- oder Subscription-Geschäftsmodell.

- Nachweisbare Führungserfahrung im Vertrieb – du hast bereits ein Team geführt, gecoacht oder Verantwortung für die Entwicklung anderer Vertriebler:innen übernommen.

- Die Fähigkeit, den eigenen Erfolg zu analysieren und in wiederholbare, vermittelbare Methodik zu übersetzen – du kannst erklären, warum etwas funktioniert, nicht nur, dass es funktioniert.

- Zuverlässigkeit und Accountability, auch wenn die eigene Zielerreichung zugunsten des Teamerfolgs zurücksteht.

- Muttersprachliche oder akzentfreie Kenntnisse der deutschen Sprache.

- Ausgeprägtes Verständnis für Verhalten und Bedürfnisse von Menschen sowie Freude daran, andere weiterzuentwickeln.

**Nice to have:**

- Erfahrung in der Konzeption von Coaching-Formaten, Playbooks oder Trainingsmaterialien für Vertriebsteams.

- Erfahrung im Bildungs- oder Nachhilfesektor.

- Bachelor-, Master- oder MBA-Abschluss.

- Weitere Sprachen sind ein Plus.

## Benefits

- Du gestaltest von Anfang an die Zukunft einer Bildungsplattform, die tausenden von Schülerinnen und Schülern hilft.

- Wir trauen Dir vom ersten Tag an viel Eigenverantwortung zu und du hast direkten Einfluss auf die Unternehmensentwicklung.

- Du verkaufst weder Drogen noch Schrott, sondern ein Produkt, welches das Leben unserer Kunden nachhaltig positiv beeinflusst.

- Du hast flexible Arbeitszeiten, arbeitest zu 100% remote im Homeoffice

- Du erhältst ein attraktives Jahresbruttogehalt. Zur Einordnung: Baseline 60.000€, bis 160.000€ abhängig von der Verbesserung der quartalsweisen Wandlungsquote.

- Junges und dynamisches Team, das was bewegen will und auf Augenhöhe kommuniziert.

Bitte nur Bewerbungen von Personen, die schon mehrjährige Führungserfahrung in Outbound Sales Teams haben.

Wir freuen uns auf deine Bewerbung!

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
