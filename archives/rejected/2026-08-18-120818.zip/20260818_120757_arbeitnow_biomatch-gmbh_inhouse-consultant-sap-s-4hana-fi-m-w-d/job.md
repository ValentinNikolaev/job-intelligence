# Inhouse Consultant SAP S/4HANA FI (m/w/d)

Posted: 2026-08-18T07:30:28Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**Im Auftrag unseres Mandanten**, eines international erfolgreichen und technologisch führenden Unternehmens im Bereich der Vakuumtechnologie, suchen wir eine erfahrene Persönlichkeit als **Inhouse Consultant SAP S/4HANA FI (m/w/d)**. In dieser verantwortungsvollen Position übernimmst du eine zentrale Rolle bei der Weiterentwicklung der globalen SAP-Finance-Prozesse und fungierst als wichtige Schnittstelle zwischen **IT und Fachbereichen**. Dabei bringst du deine Expertise in **SAP S/4HANA FI, End-to-End-Prozessen, Customizing und der Umsetzung internationaler IT-Projekte** ein.

## Aufgaben

- Du unterstützt bei der Weiterentwicklung und Umsetzung globaler Geschäftsprozesse innerhalb der SAP-Landschaft.

- Dabei stellst du einen reibungslosen und durchgängigen Prozessablauf im Bereich **SAP S/4HANA Finance (FI)** sicher – insbesondere entlang der Prozesse **Record-to-Report** und **Cash-to-Invest**.

- Du übernimmst das Customizing sowie die Pflege relevanter Stammdaten und Systemeinstellungen im SAP-FI-Umfeld.

- Als Ansprechpartner berätst du die Fachbereiche bei der Optimierung ihrer Finance-Prozesse und entwickelst gemeinsam mit ihnen passende SAP-Lösungen.

- Du verantwortest eigene (Teil-)Projekte und begleitest unter anderem die Planung und Durchführung von IT-Integrationstests.

- Für Key User, Anwender und den 1st-Level-Support erstellst du technische Dokumentationen, Prozessbeschreibungen und Schulungsunterlagen.

- Darüber hinaus unterstützt du den laufenden SAP-Betrieb im Rahmen des **2nd- und 3rd-Level-Supports**.

- Du arbeitest eng mit den relevanten Fachbereichen sowie weiteren internen IT-Stakeholdern zusammen.

## Qualifikation

- Du hast ein abgeschlossenes Studium im Bereich Informatik, Wirtschaftsinformatik oder eine vergleichbare Qualifikation.

- Du verfügst über mehrjährige Erfahrung in der SAP-Beratung und bringst fundierte Kenntnisse in **SAP S/4HANA FI** mit.

- Ein gutes Verständnis der zugrunde liegenden End-to-End-Prozesse, insbesondere **Record-to-Report** und **Cash-to-Invest**, ist für dich selbstverständlich.

- Kenntnisse in weiteren SAP-Modulen wie **CO, SD, MM oder PP** sind von Vorteil.

- Erfahrung mit **SAP ABAP** sowie dem **SAP Solution Manager** ist ein Pluspunkt.

- Idealerweise hast du bereits Erfahrung in der technischen bzw. IT-seitigen Projektsteuerung gesammelt.

- Du kommunizierst sicher auf **Deutsch und Englisch**; Französischkenntnisse sind ein zusätzlicher Vorteil.

- Eine selbstständige, strukturierte und lösungsorientierte Arbeitsweise zeichnet dich aus.

- Du verfügst über ausgeprägtes analytisches Denkvermögen und kannst dich schnell in komplexe Prozesse und Systemlandschaften einarbeiten.

## Benefits

- Eine vielseitige Inhouse-Position mit Gestaltungsspielraum und internationalen Projekten.

- Individuelle Weiterbildungs- und Entwicklungsmöglichkeiten sowie interne Karriereperspektiven.

- Eine attraktive Vergütung nach **IG-Metall-Tarif** inklusive Urlaubs- und Weihnachtsgeld sowie weiteren Zusatzleistungen.

- Weitere Benefits wie **AVWL, bezuschusste Kantine und Fahrradleasing**.

- Flexible Arbeitszeiten durch Gleitzeit und **30 Tage Urlaub**.

- Die Möglichkeit, flexibel mobil zu arbeiten und Beruf und Privatleben miteinander zu verbinden.

- Eine offene und wertschätzende Unternehmenskultur mit einem internationalen Arbeitsumfeld.

- Einen langfristig sicheren Arbeitsplatz bei einem international aufgestellten und zukunftsorientierten Arbeitgeber.

Bei offenen Fragen kannst du dich gerne an mich wenden.

**Max Löwe**

Recruiter

Tel. +49 69209757704

[linkedin.com/in/max-löwe-a58981346](https://www.linkedin.com/in/max-l%C3%B6we-a58981346)

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
