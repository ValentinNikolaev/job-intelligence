# Senior Backend Engineer, Card Acquisition (Remote)

Posted: 2026-08-17T00:00:00.0000000

## Rejection

- Category: tech_stack
- Reason: role does not mention Go/Golang or PHP

...Affirm is seeking a **Senior **Software **Engineer **for Card Acquisition to shape the first customer experience... ..., and drive durable, scalable **backend **systems in collaboration with product... ...strong coding standards. This role is **remote **in Spain with visa sponsorship available...
