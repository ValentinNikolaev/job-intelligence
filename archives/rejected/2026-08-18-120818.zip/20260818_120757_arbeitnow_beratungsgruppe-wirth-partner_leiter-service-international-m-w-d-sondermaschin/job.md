# Leiter Service international (m/w/d) - Sondermaschinenbau / Lasermaterialbearbeitung

Posted: 2026-08-18T10:30:31Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

- Ausgeprägte Kunden- und Lösungsorientierung

- Entwickeln Sie unsere Service-Organisation zielgerichtet weiter

Wir sind ein weltweit agierender, mittelständischer Hersteller von innovativen Sondermaschinen. Mit unseren Laseranlagen für die Materialbearbeitung realisieren wir höchste Präzision sowie Bearbeitungsgeschwindigkeiten und gehören damit heute zu den führenden Anbietern. Auf Basis unserer Technologie-Expertise sind wir dabei in der Lage, kundenspezifische Applikationen und Prozesse zielgenau zu realisieren. Globale Kunden, z.B. aus der Verpackungs-, Lebensmittel- und Papierindustrie sowie dem Automotive- und Pharma-Bereich vertrauen unserer Lösungskompetenz. Im Zuge einer Nachfolgeregelung suchen wir für unseren **Firmensitz im Osten von München** den engagierten

## Aufgaben

- Motivierende Führung und aktive Unterstützung unserer international erfahrenen und dezentral organisierten Servicetechniker

- Vorausschauende Planung und Steuerung der weltweiten Serviceeinsätze sowie Sicherstellung der Servicequalität auf höchstem Niveau

- Umfassende Verantwortung für die Abwicklung der Service- und Ersatzteilaufträge in enger Abstimmung mit der Serviceassistenz

- Bearbeitung von Service Requests inkl. Kommunikation mit Kunden, Durchführung technischer Klärungen sowie Ableitung und Koordination geeigneter Maßnahmen; dabei kontinuierliche Optimierung unserer Prozesse

- Direkte Berichterstattung an die Geschäftsführung, sowohl zu laufenden Serviceaktivitäten als auch bei der strategischen Weiterentwicklung Ihres Bereichs (hinsichtlich Kundenzufriedenheit, Ersatzteilversorgung, Kapazitäts- und Budgetplanung)

- Zukunftsorientierte Entwicklung sowie Umsetzung von konkreten Maßnahmen, u.a. Konzepte für Verfügbarkeit, Wartung und Dokumentation, zur Stärkung der Kundenbindung

## Qualifikation

- Sie verfügen über eine technische Berufsausbildung mit Weiterbildung zum Staatlich geprüften Techniker oder Meister (z.B. im Bereich Maschinenbau, Mechatronik, Automatisierungstechnik, Elektrotechnik) oder über ein erfolgreich abgeschlossenes Ingenieur-Studium

- Einschlägige Berufserfahrung im technischen Service / Customer Support / Aftersales eines international agierenden Unternehmens im Anlagen-/Maschinenbau, verbunden mit erster Führungserfahrung

- Sehr gute Kenntnisse in Deutsch, Englisch sowie den üblichen Office-Anwendungen sind für Sie selbstverständlich

- Kommunikations-, Führungs- und Teamfähigkeit

- Selbstständige, strukturierte Arbeitsweise gepaart mit Organisationsgeschick

- Kundenorientiertes Denken und Handeln sowie freundliches und sicheres Auftreten

- Gelegentliche internationale Reisebereitschaft

## Benefits

- Innovatives Technologieumfeld und eine Aufgabe, in der Sie etwas bewegen können

- Kurze Entscheidungswege, flache Hierarchien in einem wachsenden Unternehmen mit zukunftsorientierten Produkten

- Verantwortungsvolle Position mit Gestaltungsspielraum

- **Auch Kandidaten, die das Anforderungsprofil heute noch nicht vollständig erfüllen, bieten wir die Möglichkeit der Entwicklung in diese anspruchsvolle Aufgabenstellung**

Haben wir Ihr Interesse geweckt? Dann freuen wir uns auf Ihre Bewerbung, die Sie bitte an die von uns beauftragte beratungsgruppe wirth + partner per E-Mail senden. Wir schätzen einen vertraulichen telefonischen Kontakt vorab, um dabei erste Fragen, die Chancen Ihrer Bewerbung und den weiteren Entscheidungsablauf besprechen zu können. Herr Stefan Wirth steht Ihnen unter Tel. 089 / 45 99 58 0 dafür jederzeit gerne zur Verfügung.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
