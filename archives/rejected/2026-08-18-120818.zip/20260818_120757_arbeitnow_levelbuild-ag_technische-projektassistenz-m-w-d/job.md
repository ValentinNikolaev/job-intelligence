# Technische Projektassistenz (m/w/d)

Posted: 2026-08-18T08:30:27Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Du behältst auch bei vielen parallelen Themen den Überblick, denkst mit statt nur

abzuarbeiten und stellst die richtigen Fragen, bevor Lücken zum Problem werden? Du

möchtest praktische Verantwortung in der Projektorganisation übernehmen und aktiv daran mitarbeiten, ein wachsendes Software- und Beratungsteam zuverlässig und skalierbar zu machen? Dann unterstütze uns als Technische Projektassistenz bei levelbuild und hilf dabei, die Digitalisierung der Baubranche auf das nächste Level zu bringen.

## Aufgaben

- Du übersetzt die operativen Bedürfnisse unserer Projektleitung in klare Strukturen: Statuscockpits, Action Items und Reportings, die so vorbereitet sind, dass das Team sofort handlungsfähig bleibt

- Du sorgst dafür, dass Vereinbarungen nicht versanden: intern wie beim Kunden hakst du verbindlich nach, hältst offene Punkte sichtbar und erkennst, wann etwas eskaliert werden muss

- Du planst und begleitest Testdurchläufe, richtest Rollen und Zugänge ein und sorgst dafür, dass neue Funktionen nicht nur technisch laufen, sondern im echten Kundenprozess tragen

- Du bereitest Kundentermine, Reviews und interne Rituale vor, führst Protokoll und sorgst danach dafür, dass aus jeder Vereinbarung ein nachverfolgbares Action Item wird

- Du hältst Qualitäts- und Reporting-Kennzahlen pro Kunde und Modul aktuell und hast die Zahlen im Monatsmeeting griffbereit, bevor jemand danach fragt

- Du behältst Teamauslastung und Kundenstämme im Blick, erkennst Engpässe frühzeitig und hilfst, Planungsverschiebungen rechtzeitig sichtbar zu machen

## Qualifikation

- Du arbeitest sehr strukturiert und behältst auch in vielen parallelen Themen den Überblick. Verbindliches, freundlich-konsequentes Nachfassen liegt dir.

- Du erschließt dir Zusammenhänge schnell, handelst proaktiv und bewegst dich flexibel zwischen Themen und Ansprechpartnern. Mitdenken statt Abarbeiten ist für dich die Grundeinstellung.

- Du hörst gut zu und erkennst, was gemeint ist, auch wenn es noch nicht perfekt formuliert ist. Du stellst die Fragen, die Lücken früh sichtbar machen.

- Du hast Interesse an technischen Themen und bringst ein Grundverständnis von IT-Strukturen wie Datenbanken, Schnittstellen oder Netzwerken mit. Selbst entwickeln musst du nicht.

- Du hast bereits erste Berufserfahrung in der Koordination von Projekten gesammelt, idealerweise im Beratungs-, Agentur- oder Softwareumfeld.

- Du hast Erfahrung mit agilen Arbeitsweisen, Ticketsystemen und Tabellenkalkulation. Erfahrung mit No-Code-Plattformen ist ein Plus, aber kein Muss.

- Dein Weg hierher ist uns nicht so wichtig wie deine Fähigkeiten. Ob mit Studium, Ausbildung oder als Quereinsteiger mit relevanter Erfahrung: Bei uns bist du willkommen.

## Benefits

- Start-up-Mentalität in einem etablierten Unternehmen: kurze Entscheidungswege, echte Mitgestaltung, ein Team, das füreinander einsteht

- Eine Rolle, die wächst: Du startest mit Querblick über unsere drei Fachteams und entwickelst dich in Richtung dedizierter Teamverantwortung. Kein Abarbeiten, sondern Mitgestalten.

- Zentrale Lage in Leipzig mit einem schönen Büro

- Flexible Arbeitszeiten und die Möglichkeit, an einem Tag pro Woche im Homeoffice zu arbeiten

- Deine Gesundheit ist uns wichtig: Deshalb bezuschussen wir deinen Wellpass und unterstützen dich dabei, aktiv zu bleiben

- Deutschlandticket, Zuschuss zur Mittagsverpflegung und Benefit-Karte sowie regelmäßige gemeinsame Aktivitäten wie After Work, Sport und Spieleabende gehören ebenfalls zum Gesamtpaket

Wenn du Lust hast, in einem wachsenden Team echte Verantwortung in der Projektorganisation zu übernehmen und dabei sowohl mit Menschen als auch mit Systemen sauber umgehen möchtest, dann melde dich.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
