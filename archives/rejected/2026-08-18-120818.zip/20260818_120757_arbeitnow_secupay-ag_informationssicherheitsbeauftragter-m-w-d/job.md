# Informationssicherheitsbeauftragter (m/w/d)

Posted: 2026-08-18T10:00:24Z

## Rejection

- Category: tech_stack
- Reason: role does not mention Go/Golang or PHP

**Festanstellung | Vollzeit** **| Hybrid / Remote mit gelegentlichen Treffen in Pulsnitz**

Als Informationssicherheitsbeauftragter übernehmen Sie eine zentrale Rolle bei der Weiterentwicklung unseres Informationssicherheitsmanagements und sorgen dafür, dass Sicherheitsanforderungen wirksam, prüfungsfähig und nachvollziehbar umgesetzt werden.

## Aufgaben

- Sie steuern und entwickeln das Informationssicherheitsmanagementsystem der secupay AG inklusive Richtlinien, Standards, Verfahren, Rollen und Kontrollrahmen weiter

- Sie beraten Vorstand, Führungskräfte, Fachbereiche, IT und Security Office/SOC zu Informationssicherheit und sicheren Systemen, Anwendungen, Prozessen und Dienstleistern

- Sie leiten Sicherheitsanforderungen aus DORA, ZAG-MaRisk, BaFin- und EBA-Vorgaben, DSGVO, ISO/IEC 27001, TISAX und PCI DSS ab und überwachen deren Umsetzung

- Sie begleiten Audits, Assessments, Managementbewertungen, Zertifizierungen und Prüfungen inklusive prüfungsfähiger Nachweise

- Sie bewerten Sicherheitsvorfälle, Schwachstellen, Bedrohungen und Testergebnisse und unterstützen Notfallmanagement, Wiederanlauf und digitale operationale Resilienz

- Sie konzipieren Awareness- und Schulungsmaßnahmen und arbeiten eng mit IKT-Risikomanagement, IT-Compliance, Datenschutz, Auslagerungsmanagement, Revision und weiteren Kontrollfunktionen zusammen

## Qualifikation

Als leidenschaftlicher Sicherheitsexperte kennen Sie die Regelwerke aus dem Effeff und können sie in die Praxis übersetzen. Sie arbeiten selbstständig und eigenverantwortlich, können aber auch andere für gemeinsame Ziele gewinnen und begeistern.

- Sie bringen mehrjährige relevante Berufserfahrung im Bereich Informationssicherheit mit

- Sie verfügen über sehr gute Kenntnisse im Informationssicherheitsmanagement sowie in ISO/IEC 27001 und PCI DSS

- Sie kennen relevante regulatorische Anforderungen, insbesondere DORA, ZAG-MaRisk, DSGVO, BaFin- und EBA-Vorgaben

- Sie bringen Erfahrung in Audit-, Zertifizierungs-, Assessment- und Nachweisprozessen mit

- Sie verfügen über Kenntnisse moderner IT-Infrastrukturen, Netzwerk- und Security-Architekturen sowie SIEM-, EDR-, Monitoring- und Vulnerability-Management-Lösungen

- Sie arbeiten analytisch, sorgfältig, eigenverantwortlich und kommunizieren sicher mit Management, IT, Fachbereichen, Prüfern und Dienstleistern

- Sie sprechen sicher Deutsch und Englisch

**WÜNSCHENSWERT, ABER NICHT BEDINGUNG**

- Idealerweise bringen Sie Erfahrung im Aufbau oder in der Weiterentwicklung eines ISMS mit

- Idealerweise sind Sie zertifizierter Informationssicherheitsbeauftragter

- Idealerweise haben Sie bereits mit Jira und Confluence gearbeitet

## Benefits

- Vertrauen! Arbeitszeit selbstverantwortlich gestaltbar

- Die Mischung macht‘s! Mobiles Arbeiten, auch langfristig möglich, mit Anwesenheit vor Ort nur bei Audits, wichtigen Terminen oder nach Abstimmung

- Lebenslanges Lernen! Bedarfsorientierte Zertifizierungen und Weiterbildungen

- Kultur! Wertschätzendes Miteinander, offene Kommunikation und dynamische Teams

- Work-Life-Balance! 30 Tage Basis-Urlaub

Auf Sie wartet eine anspruchsvolle, abwechslungsreiche Tätigkeit mit Perspektive in einem spannenden und wachstumsstarken Unternehmen. Wir haben Ihr Interesse geweckt? Dann freuen wir uns über ihre vollständigen Unterlagen, inkl. Gehaltsvorstellung und frühestem Starttermin.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
