# Senior SAP functional in-house Consultant (m/f/d)

Posted: 2026-08-18T06:45:25Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

At Flix, we offer a dynamic work environment with competitive pay, strong growth opportunities, and a tech-driven approach to making travel more accessible, sustainable, and affordable. 

We're looking for an experienced** ****SAP functional Consultant (m/f/d)** to join our ERP Finance team at Flix, in Berlin or Munich.

In the Foundation Division of FlixTech, the ERP Finance team is responsible for the platform that powers our financial backbone: accounting, controlling, procurement, period close, and the integrations that connect them to the rest of Flix. We're setting up a new ERP system for our Train business (FlixTrain) with a first focus on Finance and Procurement.

As our in-house SAP expert, you'll work closely with our Finance and Procurement teams as well as external partners to make sure the new ERP fits our needs: today and in the long run. After go-live, you'll be the person who owns, evolves and continuously improves the SAP solution from the inside.

This role is well suited for someone who enjoys ownership, working close to real business problems, and combining solid SAP craftsmanship with a long-term, in-house perspective

**About the Role**

- Act as Flix's in-house SAP expert during the implementation of our new ERP, with a focus on Finance and Procurement.

- Translate business requirements from Finance, Procurement and adjacent functions into clean, scalable SAP solutions.

- Work closely with external implementation partners during design, build, testing and cut over.

- Support data migration, test management, and go-live preparation from a Flix-side ownership perspective.

- Take long-term ownership of the SAP solution after go-live: enhancements, change requests, integrations and continuous process improvement.

- Contribute to building broader SAP capability within the ERP Finance team thought teaching and mentoring.

- Be a trusted advisor to Finance and Procurement stakeholders on what SAP can do for

**About You**

- 7+ years of experience as an SAP Consultant (incl. 5+ years in S/4HANA), with a strong focus on Finance (FI/CO) and Procurement (MM).

- Additional working knowledge in SAP Supply Chain and Asset Management modules.

- At least two full end-to-end SAP implementations, ideally in a company of similar size and complexity to Flix.

- Solid understanding of core finance and procurement processes: General Ledger, Accounts Payable / Receivable, Fixed Assets, Controlling, Purchase-to-Pay.

- Experience working with external system integrators and the confidence to engage with them as an equal partner.

- Comfortable engaging with senior Finance and Procurement stakeholders and translating between business and SAP language.

- Structured, pragmatic, delivery-oriented; strong communication and facilitation skills.

- Based in Germany, you're fluent in German and English.

We recognize that everyone carries a unique set of valuable skills and experiences. If you think you could have an impact even though you don't meet 100% of the requirements, we still encourage you to apply. We want to hear from you! 

**What We Offer**

- **Travel perks**: 12 free Flix vouchers + 12 discount vouchers for friends & family.

- **Work from (M)Anywhere**: Depending on your role, work from another location for up to 60 days per year.

- **Hybrid work model**: We are an office-first company, but we offer flexibility to balance work and life.

- **Wellbeing support**: Access confidential 1:1 counselling, courses, and stress management for yourself and up to four family members.

- **Learning & Development**: Take advantage of language classes, training courses, and expert-led sessions to grow your skills.

- **Mentoring Program**: Connect with experienced colleagues to gain insights and accelerate your career.

To view more local benefits specific to each office location, please check out this link:** [Locations - Flix Career](https://flix.careers/locations/)**

**Why Join Flix?**

At Flix, you'll find teams that rally together to overcome challenges and spark creativity. We believe in ownership culture - giving you the freedom to take initiative, make an impact, and shape your own career path.
As we continue to expand across the globe, you can make a real difference in how we work.

If you're ready to grow and lead your journey, Flix is the place for you!

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
