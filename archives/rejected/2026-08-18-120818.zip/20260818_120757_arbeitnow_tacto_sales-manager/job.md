# Sales Manager

Posted: 2026-08-18T08:40:13Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

## **Your Impact**

We have built a sales machine that works: ~90% of our AEs hit quota, our top performers achieve significantly more, we rarely lose head to head, and almost nobody who buys Tacto ever leaves. The bottleneck is no longer the market or the product, it is leadership capacity. We need managers who can turn good AEs into great ones at the speed we are hiring them.

As Sales Manager you own one customer segment and lead a team of ~5 Account Executives. You carry no personal quota. Your number is your team's number, and your job is the thing that produces it: the quality of your people, the rigor of your deal strategy, and the discipline of your pipeline. You will work directly with the founders and sales leadership on how we go to market in a segment where over 10,000 industrial companies in DACH still run procurement on Excel, and where we are the category of one.

## **Your Tasks**

-

**Own your segment's number through your team**: You are measured on team attainment. You build the pipeline coverage, forecast accuracy, and win rates that make the number inevitable.

-

**Team Development:** Build and coach a high-performing sales team through structured training, hands-on deal support, and performance management. You'll model best practices while developing each team member's capabilities.

-

**Deal Strategy & Execution:** Actively join critical customer conversations, challenge assumptions, eliminate risks, and design winning game plans alongside your AEs. You'll roll up your sleeves to support negotiations and business case development.

-

**Sales Excellence:** Implement and coach on proven sales methodologies (MEDDIC) while creating a culture of continuous improvement through regular training in discovery, negotiation, and process management.

-

**Performance Optimization:** Drive team performance through structured metrics tracking, pipeline reviews, and action planning. You'll identify improvement opportunities and implement solutions that increase win rates and deal velocity.

-

**Become AI Native:** Proactively identify opportunities to leverage AI to accelerate the work of your team, experiment with new approaches, and share successful workflows – contributing to Tacto's culture of high-velocity execution and innovation.

## **Your Profile**

-

3+ years as an Account Executive in B2B SaaS with complex, non-transactional, multi-stakeholder sales

-

At least 1 year leading a sales team, ideally in a high-growth environment

-

A track record of consistently hitting or beating quota, as an individual and with a team

-

You coach from a real methodology, not from instinct, and you can teach it to someone who does not have it yet

-

You are strategic and tactical in the same week: you can design a segment plan on Monday and rescue a stalled deal on Thursday

-

You are direct. You give hard feedback early because you would rather have the uncomfortable conversation than watch someone miss

-

Resilient, high-agency, and drawn to a hard problem over an easy title

-

Fluent in German and English

## Why this role is awesome

Product-market fit is not a hypothesis here. Customers stay, they grow, and our product team ships against a real vision, so every quarter your AEs walk into calls with something they could not say the quarter before. That means you will not spend your first year explaining why anyone should care. You will spend it coaching sellers who are ambitious, hungry to grow, and carry almost no ego about it, the kind who ask for feedback and then act on it. Whatever you have learned in your career lands on fertile soil here.

## Why Tacto

-

**A standout sales organization built for the long term**

-

~90% of AEs hit their quota, with top performers reaching up to 400%

-

Incentives that reward over-performance: 150% uncapped kicker

-

No compromises on the talent bar: a lean, high-density team of A-players who push each other, with zero elbow culture. We hire the best, incentivize them right, and promote from within.

-

**Top-tier support so your team can focus on closing**

-

CVMs recruited exclusively from top-tier consultancies (BCG, Inverto, AT Kearney, Oliver Wyman) own onboarding and tee up your upsells, a Proof of Value team builds your business case in 48 hours, plus dedicated Value Engineers, Solution Engineers, Sales Ops, and a BDR machine that delivers the majority of your qualified pipeline

-

**A truly AI-native sales organization**

-

Access to all the leading AI tools plus a stack of custom agents that handle the work that used to eat your week, from meeting prep and demo follow-ups to value cases, call coaching, and instant battlecards, so you spend your time selling, not preparing to sell

-

We invest to keep it that way: dedicated 'AI captains' across every team, with a group focused on Sales and Go-to-Market, building new tooling and running enablement so new knowledge spreads fast

-

**Backed to win big**

-

Sequoia- and Index-funded, with €50M+ behind us. Our founders sit at the same table as the people defining the global AI agenda, from Sam Altman to Europe's leading tech entrepreneurs. We're building Tacto to be the lighthouse for European industrial AI.

-

**A front-row seat in the European startup ecosystem**

-

Weekly exposure to leading founders and operators through internal and external events

-

e.g. Sales-focused Events with [CRO of DeepL](https://luma.com/muzg718x), [CRO of Dash0](https://luma.com/670uuufu) or [ex Head of RevOps at Forto](https://luma.com/fg98jm17)

## **Our Background**

Tacto is building the intelligence layer that connects AI to the physical world of manufacturing, starting with procurement. AI is transforming every industry, but it stops at the factory gate. The knowledge that holds manufacturing together - part costs, suppliers, materials - is scattered across systems and people. Over 50% of a product's cost originates from suppliers, making procurement the single largest cost lever in manufacturing and the missing connection between the digital and the physical world. Yet it still runs on Excel and legacy systems. We're changing that with our Procurement Intelligence Platform, trusted by hundreds of companies running billions of Euros of material.

Based in Munich, we are 100+ passionate builders who are in-office, with high expectations, fast growth, and a lot of fun. We are supported by >€50m from Sequoia, Index, and Europe's leading tech entrepreneurs and industry veterans.

## **Why It Matters**

Manufacturing forms Europe's economic backbone, driving a fourth of Europe's GDP and providing over 30% of jobs. These hidden champions and global market leaders manufacture the physical world around us, from the machines that build our cities to the medical devices that save lives.

But the world is changing. The US dominates the digital world of bits. China is scaling the world of atoms, manufacturing at unprecedented speed and scale. Geopolitics are more uncertain than ever. Europe's strength lies in its deep industrial knowledge through generations of engineering. Manufacturing worldwide runs on European machines and software. But that heritage is only an advantage if we leverage it in the age of AI.

Tacto builds the AI that connects Atoms and Bits, empowering our Industrial Base to Stay Stronger and building a lighthouse for European tech.

## **What We Offer**

The people at Tacto are passionate about building the organization, growing themselves, and our product while having fun and being real. We have high expectations, great talent density, and a culture where your ambition, performance, and agency are what count - not where you come from or how big your ego is. You'll grow at the forefront of AI, have real ownership and impact, and be surrounded by the best people in their field who challenge you and make you better every day. That is demanding and rewarding, but that's where we thrive. Besides that you have:

-

Money: Competitive salary & equity in the company with real upside, so you are invested in our success

-

Workplace: A vibrant in-office culture (> 4 days/week) in a beautiful office in central Munich

-

Development: A development budget and regular exposure to exceptional people, e.g., Lunch & Learns, peer mentoring, external speakers

-

Time off: 26 + 4 vacation days per year (4 fixed “company rest days”) as well as regular off-sites and team events

-

Health: Wellpass membership, of course, a fruit basket (!), and access to Jobrad, for your health

-

Family & Social Security: Voluntary pension contribution, voluntary KITA subsidy for your children

*Tacto is an equal opportunity employer. We are committed to equal employment opportunity regardless of race, religion, sexual orientation, age, marital status, disability, or gender identity. Please do not submit personal data revealing racial or ethnic origin, political opinions, religious or philosophical beliefs, trade union membership, data concerning your health, or data concerning your sexual orientation.*

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
