# IT Business Analyst (m/w/d)

Posted: 2026-08-18T09:00:28Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Du verstehst die Bedürfnisse des Business und hast gleichzeitig ein gutes Gespür dafür, wie daraus passende IT-Lösungen entstehen? Dann bist du bei uns genau richtig. Als IT Business Analyst bist du die zentrale Schnittstelle zwischen unseren Fachbereichen und der IT. Du analysierst Prozesse, nimmst Anforderungen auf und entwickelst gemeinsam mit den Beteiligten Lösungen, die im Arbeitsalltag wirklich funktionieren.

Dich erwartet eine vielseitige Position mit viel Gestaltungsspielraum, spannenden Projekten und engem Austausch mit Fachbereichen, IT-Teams und externen Partnern.

## Aufgaben

- Als zentrale Ansprechperson berätst du unsere Fachbereiche und unterstützt sie dabei, ihre Anforderungen und Bedürfnisse zu konkretisieren

- Gemeinsam mit den Fachbereichen analysierst du Geschäftsprozesse, erkennst Optimierungspotenziale und entwickelst passende IT-Lösungen

- Fachliche Anforderungen übersetzt du in strukturierte IT-Requirements und schaffst damit die Grundlage für eine erfolgreiche Umsetzung

- Bei nationalen und internationalen Projekten übernimmst du Verantwortung – von der Konzeption über die Umsetzung und das Testing bis zur Einführung

- Im Demand Management bewertest und koordinierst du neue Anforderungen und stimmst diese mit den relevanten IT-Stellen innerhalb der Bell Food Group ab

- Bei neuen Lösungen und Systemen begleitest du Auswahl, Machbarkeit und Einführung und arbeitest dabei eng mit internen sowie externen Dienstleistern zusammen

## Qualifikation

- Eine Ausbildung oder ein Studium im Bereich Informatik, Wirtschaftsinformatik, Betriebswirtschaft oder eine vergleichbare Qualifikation hast du erfolgreich abgeschlossen

- Mehrjährige Berufserfahrung als IT Business Analyst, Business Analyst, IT Consultant, Application Manager oder in einer vergleichbaren Schnittstellenfunktion bringst du idealerweise mit

- Requirements Engineering und Prozessanalyse gehören zu deinem Erfahrungsschatz und du kannst Business-Anforderungen strukturiert erfassen und in IT-Lösungen übersetzen

- Projektarbeit ist dir vertraut: Du hast IT-Projekte bereits begleitet oder eigenständig gesteuert und bringst ein gutes Verständnis für die unterschiedlichen Projektphasen mit

- Mit unterschiedlichen Ansprechpartnern kommunizierst du souverän und kannst zwischen Fachbereich, IT, Key Usern und externen Partnern vermitteln

- Analytisches Denken und ausgeprägtes Prozessverständnis zeichnen dich ebenso aus wie eine strukturierte und eigenverantwortliche Arbeitsweise

- Sehr gute Deutschkenntnisse bringst du mit; gute Englischkenntnisse sowie Freude an der Zusammenarbeit in einem internationalen Umfeld sind von Vorteil

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
