# Teamleiter Automotive

Posted: 2026-08-18T07:30:27Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**KONDI GmbH** ist ein innovatives, dynamisches Unternehmen mit langjähriger Erfahrung in den Bereichen Engineering & Test. Im Automotive und Non Automotiv ist es unser erklärtes Ziel von der Planung und Prozessen, Produkt und Systementwicklung sowie Prototypenherstellung und Test, unseren Kunden einen vollständigen Service zu bieten.

Unsere Experten entwickeln und testen mit/und für unsere Kunden, Maßstäbe setzende Produkte, Komponenten sowie Gesamtantriebssysteme für Anwendungen von morgen.

Mit modernen Werkzeugen und Methoden erarbeiten wir innovative, pragmatische und prozesskonforme Lösungen - und das stets zur vollen Zufriedenheit unserer Kunden.

## Aufgaben

- Fachliche und disziplinarische Leitung eines Entwicklungsteams im Bereich Electric & Hybrid Drive Systems

- Koordination und Führung mehrerer Projektleiter

- Steuerung und Weiterentwicklung des Projektmanagements innerhalb des Verantwortungsbereichs

- Unterstützung und Weiterentwicklung der Projektleiter bei der erfolgreichen Umsetzung ihrer Projekte

- Sicherstellung einer zielgerichteten Zusammenarbeit innerhalb der Projektteams

- Projektplanung und regelmäßige Abstimmung mit Kunden

- Reporting der Entwicklungs- und Projektfortschritte an den Abteilungsleiter

- Unterstützung des Vertriebs während der Akquise- und Angebotsphase

- Motivation der Mitarbeiter und Förderung eines unternehmerischen Denkens im Team

## Qualifikation

- Abgeschlossenes technisches Studium, vorzugsweise in Elektrotechnik, Mechatronik, Fahrzeugtechnik, Wirtschaftsingenieurwesen, Maschinenbau oder einer vergleichbaren Fachrichtung

- Mehrjährige Erfahrung im technischen Projektmanagement, idealerweise in der Automobilindustrie

- Erfahrung oder fundierte Kenntnisse im Bereich Electric & Hybrid Drive Systems

- Führungserfahrung bzw. Erfahrung in der fachlichen Steuerung von Mitarbeitern und Projektteams

- Unternehmerisches Denken und ausgeprägte Führungs- und Kommunikationskompetenz

- Durchsetzungsvermögen, Einsatzbereitschaft und sicheres Auftreten gegenüber Mitarbeitern und Kunden

- Gute Deutsch- und Englischkenntnisse in Wort und Schrift

## Benefits

**Wir bieten Ihnen:**

· Spannende und vielseitige Tätigkeit in einem anspruchsvollen

Arbeitsgebiet

· Angenehme Arbeitsatmosphäre in einem motivierten Team

· Aufgaben/Lösungen aktiv mitzugestalten und Ihre

Entwicklungsmöglichkeiten selbst zu bestimmen.

· Teilnahme an internen und externen Schulungen

· Tätigkeit in einem professionellen Projektteam

· Modernes Umfeld, attraktive Vergütung und flache

Hierarchien

· Leistungsstarke und innovative Ausstattung sowie Home-Office

Wir haben Ihr Interesse geweckt? Dann freuen wir uns auf Ihre vollständige und aussagekräftige Bewerbung inkl. Gehaltswunsch und möglichen Eintrittstermin. Gerne auch per Mail, die E-Mail Adresse finden Sie auf unserer Webseite.

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
