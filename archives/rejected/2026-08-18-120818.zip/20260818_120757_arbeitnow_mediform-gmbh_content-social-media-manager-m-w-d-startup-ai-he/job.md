# Content & Social Media Manager (m/w/d) - Startup AI Healthcare - Hybrid

Posted: 2026-08-18T09:00:27Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Hast du Lust, Teil eines ambitionierten Startups zu sein, das die Zukunft der Patientenkommunikation neu definiert? Dann bist du bei Mediform genau richtig! Wir sind Pionier in der autonomen Bearbeitung von Patientenanliegen – per Telefon und per Chat über die Praxis-Webseite. Unsere Technologie ermöglicht beispielsweise die automatische Terminvergabe, ohne dass das Praxispersonal eingreifen muss – das spart wertvolle Zeit und Ressourcen. So kann sich das Team voll und ganz auf die persönliche Betreuung der Patienten konzentrieren, während unsere KI zuverlässig die administrativen Aufgaben übernimmt.

Als ambitioniertes KI-Startup stehen wir für Innovation und Wachstum – KI ist Teil unserer DNA. Nachdem wir mit unserem Marketing-Team bereits die Leadgewinnung erfolgreich aufgebaut haben, suchen wir jetzt Verstärkung, die unsere Marke durch starken Content, eine klare Marketing-Strategie und eine lebendige Social-Media-Präsenz sichtbar macht. Werde Teil unseres Teams und hilf uns, das Gesundheitssystem gemeinsam zu revolutionieren.

## Aufgaben

- **Entwicklung und Umsetzung** einer ganzheitlichen Content- und Marketing-Strategie entlang der gesamten Customer Journey

- **Konzeption, Erstellung und Ausspielung von Content** für unsere Social-Media-Kanäle (v.a. LinkedIn, Instagram) inklusive Redaktionsplanung

- **Aufbau und Pflege einer aktiven Community** sowie Steuerung des Community-Managements

- **Erstellung von Inhalten** für Blog, Website, Newsletter, Whitepaper und Case Studies

- **Weiterentwicklung unserer Markenkommunikation** und unseres Tone of Voice über alle Kanäle hinweg

- **Zusammenarbeit im Bereich Leadgewinnung**, um Content und Kampagnen aufeinander abzustimmen

- **Analyse und Auswertung der Content**- und Social-Media-Performance sowie Ableitung von Optimierungsmaßnahmen

- **Beobachtung von Trends im Content**- und Social-Media-Marketing sowie Einbringen neuer Formate und Ideen

## Qualifikation

- **Abgeschlossenes Studium** im Bereich Marketing, Kommunikation, Medien oder eine vergleichbare Ausbildung

- **Erste praktische Erfahrungen** im Bereich Content-Erstellung, Social Media oder Marketing-Strategie

- **Ausgeprägtes Gespür** für Sprache, Storytelling und zielgruppengerechte Kommunikation

- **Erfahrung** mit Social-Media- und Content-Tools (z.B. Canva, Adobe Creative Suite, Meta Business Suite, LinkedIn, Buffer/Hootsuite) von Vorteil

- **Kreativität,** Organisationstalent und ein gutes Gespür für aktuelle Trends

- **Selbstständige** Arbeitsweise, Teamfähigkeit und Kommunikationsstärke

- **Ausgeprägte KI-Affinität**

- **Sehr gute Deutsch- und Englischkenntnisse** in Wort und Schrift

## Benefits

- **Hybrides Arbeiten:** Du kannst flexibel im Homeoffice und in unserem modernen Büro im Herzen von Karlsruhe arbeiten

- **Flache Hierarchien** und kurze Entscheidungswege: Bei uns hast Du die Freiheit, eigene Ideen schnell umzusetzen

- **Ein hochmotiviertes Team:** Werde Teil eines engagierten Umfelds, das gemeinsam die digitale Zukunft von Arztpraxen gestaltet

- **Weiterentwicklung:** Wir fördern Deine berufliche und persönliche Entwicklung im Bereich KI und Marketing

- **Startup-Spirit:** Bei uns erwartet Dich eine offene und innovative Kultur, in der Du aktiv an Entscheidungsprozessen teilnimmst und wirklich etwas bewegen kannst

Wenn Du Lust hast, mit starkem Content und cleverer Marketing-Strategie die Stimme von Mediform zu prägen und Dich in einem innovativen KI-Startup langfristig weiterzuentwickeln, dann freuen wir uns auf Deine Bewerbung!

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
