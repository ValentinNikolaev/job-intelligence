# Working Student (m/f/d) Product Management - VGI

Posted: 2026-08-18T08:10:14Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**Warum The Mobility House?**

- A rapid advancement in a rapidly growing and innovative market
- You take on responsible tasks and grow with your projects
- Flexible working hours and home office options
- An open, international, dynamic & very motivated team
- Modern workplaces near Munich's Ostbahnhof railway station/ incl. roof terrace & grill
- We enjoy joint activities and like to meet for sports, after-workor team events
- We have a vision - to create an emission-free energy and mobility future together
- And much more!

**Deine Aufgaben**

- Support Product Managers in the development, launch and operation of V1G and V2G products
- Help coordinate product activities acrosstechnology, hardware, energy, operations and external partners
- Support product testing and launch readiness, including preparation, documentation and tracking of test activities, findingsand open points
- Support the pilot customer program and the systematic collection of user feedback
- Analyze qualitative feedback and product usage data to identify patterns, painpoints and improvement opportunities
- Maintain and improve product documentation, status overviews and project tracking
- Support the analysis and structuring of product requirements, customer journeys and partner feedback
- Take ownership of smaller work packages and product-related projects
- Conduct research and analyses one-mobility, smart charging, V2G and related market developments
- Help continuously improve thetools, processes and structures we use to develop and operate our products

**Das bringst du mit**

- Currently enrolled in a Bachelor’s or Master’s degree, preferably in Business Administration, Industrial Engineering, Engineering, Energy, Mobility or a comparable field
- Strong analytical skills and curiosity to understand how customers actually use a product
- Ability to structure data, feedback and observations and derive clear product insights
- Reliable and organized, with a high level of ownership and attention to detail
- Comfortable working across different teams and proactively following up on open topics
- Hands-on mentality and willingness totake responsibility for your own topics
- Interest in e-mobility, charging infrastructure,energy or automotive products
- Experience with data analysis or visualization is a plus
- Confident working with common collaboration tools; experience with Jira and Confluenceis a plus
- Very good communication skills in German and English

**Passt du zu uns?**

Diversity enriches our team and makes us stronger. Regardless of origin, gender, age, sexual orientation, religion, or any disability – everyone is welcome here! We look forward to receiving your application and achieving great things together.

**Deine -----

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
