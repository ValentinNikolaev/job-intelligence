# Softwareentwickler Full-Stack (m/w/d)

Posted: 2026-08-18T09:20:39Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Seit 2003 ist die askDANTE systems GmbH ein verlässlicher IT-Partner für mittelständische Unternehmen. Unser SaaS-Produkt askDANTE haben wir in den vergangenen Jahren vom innovativen Newcomer zur etablierten Lösung bei mehr als 4.000 Unternehmen entwickelt. Wir suchen Dich, um unser Produkt stetig weiterzuentwickeln und askDANTE zur führenden Plattform für Online Zeiterfassung zu machen.

### Deine Aufgaben

-

Entwicklung neuer Funktionen & Komponenten für unsere SaaS Plattform askDANTE

-

Begleitung des Entwicklungsprozesses von der Anforderungsanalyse bis zur technischen Umsetzung

-

Aktive Mitgestaltung bei Architektur- und Designdiskussionen

-

Eigenverantwortliche Qualitätssicherung durch Konzeption & Ausführung von Unit- und Integrationstests

-

Unterstützung von anderen Kundenprojekten

-

Du hast ein abgeschlossenes Studium der Informatik, der Wirtschaftsinformatik oder eine vergleichbare Qualifikation fundierte Kenntnisse in Java/JEE, Spring, Hibernate, HTML5/CSS, JavaScript, React oder TypeScript

-

Sicherer Umgang mit GIT und modernen IDEs

-

Idealerweise hast Du mehrjährige Berufserfahrung in der OO-Programmierung mit Java/JEE & den gängigen Web-Technologien

-

Bei der Umsetzung von Anforderungen liegt Dein Fokus auf einem „Clean Code"

-

Begeisterung für technologische Trends & Innovationen, Bereitschaft neue Technologien zu erlernen

-

Teamgeist, strukturiertes Arbeiten und Zuverlässigkeit

-

Kreativität, Offenheit & Kommunikationsstärke

-

Sehr gute Deutsch- (C2 Level) und Englischkenntnisse in Wort und Schrift

### Was wir bieten

-

Abwechslungsreiche Arbeit in einem hochmotivierten Team mit einer agilen Arbeitsweise.

-

Die Mitbestimmung und Mitgestaltung einzelner Aufgaben

-

Wertschätzendes Miteinander und flache Hierarchien

-

Unbefristeter Vertrag

-

38,5 Stunden pro Woche

-

Bis zu 3 Tage Homeoffice pro Woche

-

Frischer Kaffee, Tee und Getränke for free

-

Ruhige und individuelle Büros

-

Arbeiten im im Herzen der Landeshauptstadt Kiel

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
