# Entwicklungsingenieur (m/w/d) Medizintechnik Injektionssysteme in Mannheim (1710)

Posted: 2026-08-18T09:00:26Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**Ihre Karriere in der Entwicklung innovativer Medizinprodukte.**

Mit BRÜGGEN ENGINEERING gestalten Sie innovative Injektionssysteme, Testträger und technische Vorrichtungen für medizinische und diagnostische Anwendungen. Sie begleiten Projekte von der Konzeption und experimentellen Erprobung bis zur regulatorischen Zulassung und klinischen Bewertung.

## Aufgaben

- **Injektionssysteme:** Sie entwickeln Lösungen auf Basis von Nadeln, Spritzen und vergleichbaren medizinischen Applikationssystemen

- **Vorrichtungsentwicklung:** Sie konzipieren und realisieren spezielle Vorrichtungen zur kontrollierten Gewinnung und Entnahme humaner Flüssigkeiten

- **Testträger:** Sie entwickeln und evaluieren geeignete Testträger für diagnostische und experimentelle Anwendungen

- **Versuchsplanung:** Sie planen und organisieren Experimente, führen Untersuchungen durch und werten die Ergebnisse systematisch aus

- **Projektkoordination:** Sie steuern interne und externe Entwicklungsleistungen und begleiten die technische Abstimmung sowie Abnahme erbrachter Leistungen

- **Dokumentation:** Sie dokumentieren Entwicklungsaktivitäten, Versuchsergebnisse und technische Entscheidungen umfassend und nachvollziehbar

- **Zulassung:** Sie unterstützen regulatorische Zulassungsverfahren sowie die Planung, Durchführung und Auswertung klinischer Studien

## Qualifikation

- **Qualifikation:** Studium der Medizintechnik, Biomedizintechnik, Biotechnologie, Materialwissenschaften, Chemie, des Maschinenbaus oder einer vergleichbaren Fachrichtung

- **Erfahrung:** Praxis in der Entwicklung von Medizinprodukten, Injektionssystemen, Testträgern oder diagnostischen Produkten

- **Fachwissen:** Kenntnisse im Umgang mit Nadeln, Spritzen, Testträgern oder Vorrichtungen zur Entnahme humaner Flüssigkeiten

- **Experimentelle Praxis:** Erfahrung in der Planung, Durchführung, Auswertung und Dokumentation von Versuchsreihen

- **Projektmanagement:** Idealerweise Erfahrung in der Koordination von Entwicklungsprojekten und externen Partnern

- **Regulatorik:** Kenntnisse in der Zulassung von Medizinprodukten und im Umfeld klinischer Studien von Vorteil

- **Arbeitsweise & Sprachen:** Strukturierte, eigenständige und qualitätsbewusste Arbeitsweise sowie sehr gute Deutsch- und Englischkenntnisse

## Benefits

- **Attraktive Konditionen:** Freuen Sie sich auf eine unbefristete Vollzeitstelle bei BRÜGGEN ENGINEERING mit einer Vergütung, die Ihre Expertise würdigt

- **Zukunftssichere Projekte:** Arbeiten Sie an innovativen Entwicklungsprojekten in der Medizintechnik und gestalten Sie moderne medizinische Anwendungen aktiv mit

- **Dynamisches Team:** Werden Sie Teil eines Teams, das Wert auf persönliches Wachstum und eine Kultur der Unterstützung und Förderung legt

Wir freuen uns auf Ihre aussagekräftigen Bewerbungsunterlagen mit Angabe Ihres frühesten Starttermins und Ihrer Gehaltsvorstellung.

Ihr Ansprechpartner für Ihre Bewerbung ist:

Herr Dipl.-Wirt.-Ing. Thorsten Schermann

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
