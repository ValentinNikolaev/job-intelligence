# Brand Activation & Event Manager:in

Posted: 2026-08-18T07:01:05Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

## Jobbeschreibung

Hey!

## Wir sind vly – ein innovatives FoodTech-Startup aus Berlin, das die Lebensmittelindustrie revolutioniert. Unser Ziel: Gesunde, pflanzliche Milchalternativen, die nicht nur dir guttun sondern auch unserem Planeten. Nach jahrelanger Forschung haben wir Produkte entwickelt, die deutlich weniger Zucker und mehr Protein enthalten, mit Preisen ausgezeichnet wurden und deutschlandweit erhältlich sind – wie unsere Milchalternativen aus Erbsenprotein und den allerersten Joghurt aus Ackerbohnenprotein. Aber das soll erst der Anfang sein! Neben der ständigen Verbesserung unserer Produkte sind natürlich die Erkennbarkeit und das eigentliche Verkosten weitere wichtige Treiber für die Zukunft von vly. Hier beginnt dein nächster Schritt bei vly...

Deine Mission als **Manager:in Brand Activation & Events** wird sein, möglichst viele Menschen von vly als gesunde & nachhaltige Marke zu überzeugen, indem du die Marke und Produkte bei unserer Zielgruppe erlebbar machst.

## Deine Rolle / Deine Aufgaben:

- **Event Organisation:** Eigenständige Organisation, Planung und Umsetzung von Messen, Verkostungen, Pop-ups, Brand-Events, Event Sponsoring, internen Veranstaltungen sowie aktive Betreuung vor Ort.

- **Projekt- und Zeitmanagement:** Erstellung und Überwachung von Ablaufplänen, Checklisten und Timelines zur reibungslosen Umsetzung aller Events.

- **Partner- & Dienstleistersteuerung:** Klare Kommunikation und zuverlässige Koordination mit externen Partner:innen, Locations, Lieferant:innen und Agenturen.

- **Logistik & Lager:** Eigenverantwortliche Steuerung der Event-Logistik – von der Materialbestellung und Lagerorganisation bis hin zum Transport.

- **Teamführung vor Ort:** Briefing, Koordination und Betreuung von Promoter:innen und Event-Helfer:innen während der Einsätze.

- **Konzeption & Innovation:** Aktive Mitgestaltung neuer Eventformate durch Recherche, Ideengenerierung, Präsentationen und Einbringen eigener Impulse in internen Meetings.

- **Nachbereitung & Reporting:** Dokumentation und Evaluierung von Events (z. B. Feedbackauswertung, Fotoauswahl, Erstellung von Reportings) zur stetigen Optimierung.

- **Event-Administration:** Zuweisung und Pflege von Budgets, Rechnungsablage, Verwaltung von Teilnehmer:innenlisten sowie Pflege der Event-Datenbank und Materialübersicht.

## Deine Benefits:

- **Purpose:** Es ist absolut essenziell, dass sich das Lebensmittelsystem zum Besseren verändert. Deine Rolle trägt direkt dazu bei, es gesünder und nachhaltiger zu machen.

- **Echtes Teamgefühl:** Ein kreatives und motiviertes Team, das zusammenhält – inklusive regelmäßiger vly-Day-Events, gemeinsamer Team-Lunches und Offsite-Events.

- **Persönliches Wachstum und Erfahrung:** Einblick in die Event- & Brandaktivierung eines der spannendsten Food-Startups Europas. Vielseitige Aufgaben, definierte Zuständigkeiten und echtes Vertrauen. Reisen, Arbeiten an unterschiedlichen Orten.

- **Mobilität:** Zuschuss zum BVG / Deutschland-Ticket.

- **Company-Fitness:** Zuschuss zu deiner Urban Sports Club Mitgliedschaft.

- **vly-Flatrate:** Genieße so viel vly, wie du willst!

## Stellenanforderungen

Dein Profil:

- **Hintergrund:** Du hast eine kaufmännische Ausbildung (z. B. Eventkaufmann/-frau, Kaufmann/-frau für Marketingkommunikation) oder ein entsprechendes Studium erfolgreich abgeschlossen

- **Sprachkenntnisse:** Du kommunizierst verhandlungssicher auf Deutsch und verfügst über sehr gute Englischkenntnisse.

- **Tools:** Der sichere Umgang mit MS Office bzw. Google Workspace (insbesondere Excel/Sheets und PowerPoint/Slides) gehört für dich zum Handwerkszeug.

- **Berufserfahrung:** Du bringst praktische Erfahrung im Event Management bzw. in der Messeorganisation mit (z. B. durch Ausbildung, Praktika oder Festanstellungen in Eventabteilungen von Unternehmen oder Event Agenturen).

- **Hands-on-Mentalität & Stressresistenz:** Du bewahrst auch in dynamischen Phasen einen kühlen Kopf, denkst lösungsorientiert und packst operativ wie administrativ eigenverantwortlich an. Multitasking und flexible Arbeitszeiten (inkl. Wochenendeinsätze bei Events) machen dir nichts aus.

- **Arbeitsweise:** Eine strukturierte, selbstständige Arbeitsweise zeichnet dich ebenso aus wie klare Kommunikation und Freude an der Arbeit im Team.

Bereit, die Lebensmittelwelt zu verändern? Dann bewirb dich jetzt und werde Teil von vly! Wir freuen uns darauf, dich kennenzulernen.

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
