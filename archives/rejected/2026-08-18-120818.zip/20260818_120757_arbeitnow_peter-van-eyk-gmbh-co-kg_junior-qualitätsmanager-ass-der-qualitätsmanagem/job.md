# Junior Qualitätsmanager / Ass. der Qualitätsmanagement Leitung (w/m/d) gesucht

Posted: 2026-08-18T10:30:28Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Die Firma Peter van Eyk GmbH & Co. KG in 41379 Brüggen - Bracht besteht bereits seit über 100 Jahren und hat sich auf dem Gebiet der Kunststoffverarbeitung über viele Jahrzehnte in den Bereichen Extrusion und Spritzguss auf die Entwicklung, Fertigung und den Verkauf hochwertiger Kunststoffrohre, -formstücke sowie Sonderartikel aus PVC spezialisiert. 'Qualität und Flexibilität' ist unsere Unternehmensphilosophie.

**Wir wachsen weiter!!!**

Wir sind ein gesundes, expandierendes, mittelständisches Unternehmen und suchen zur Verstärkung unseres Teams eine/-n Betriebselektroniker (w/m/d)

## Aufgaben

- Unterstützung bei der Implementierung und Pflege des Qualitätsmanagementsystems nach ISO-Normen.

- Durchführung von internen und externen Audits zur Sicherstellung der Produktqualität.

- Selbstständige Durchführung von Qualitätsprüfungen

- Zusammenarbeit mit Produktionsabteilungen zur Lösung von Qualitätsproblemen.

- Erstellung und Aktualisierung von Qualitätsdokumentationen und Berichten.

- Unterstützung bei der Schulung von Mitarbeitern zu qualitätsrelevanten Themen.

- Direkte Berichterstattung an QM-Leitung.

## Qualifikation

- Abgeschlossene Berufsausbildung und idealerweise Berufserfahrung im Qualitätswesen eines produzierenden Industrieunternehmens.

- Kenntnisse der relevanten Qualitätsmanagementsysteme und Normen (z. B. ISO 9001).

- Vorhandene Zertifizierung oder Weiterbildung zum QMF/QMB

- Selbstständige Arbeitsweise

- Gute Kommunikationsfähigkeiten in Deutsch und Englisch.

- Ausbilderschein (wünschenswert)

## Benefits

- Nutzen Sie unser attraktives Bike-Leasing-Angebot.

- Profitieren Sie von unserer Sachbezugskarte für Ihre persönlichen Wünsche.

- Sichern Sie Ihre Zukunft mit unserer betrieblichen Altersvorsorge.

- Kostenlose Parkmöglichkeiten stehen Ihnen zur Verfügung.

- Genießen Sie finanzielle Vorteile mit unserem Urlaubs- und Weihnachtsgeld.

- Wir bieten Ihnen eine unbefristete Anstellung für langfristige Sicherheit.

Werde Teil von Peter van Eyk GmbH & Co. KG! Unterstütze unser Qualitätsmanagement-Team in der Kunststoffindustrie und gestalte mit uns die Zukunft hochwertiger PVC-Produkte. Bewirb dich jetzt!

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
