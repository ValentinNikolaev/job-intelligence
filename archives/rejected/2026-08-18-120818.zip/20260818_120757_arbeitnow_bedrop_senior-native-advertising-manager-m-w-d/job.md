# (Senior) Native Advertising Manager (m/w/d)

Posted: 2026-08-18T08:00:33Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Als (Senior) Native Advertising Manager (m/w/d) verantwortest Du unseren umsatzstärksten Performance-Kanal gemeinsam mit deinem Team, von der Ideenfindung über Konzeption und Umsetzung bis zu Testing und Optimierung.

Native ist bei bedrop kein Nebenkanal, sondern ein zentraler Wachstumstreiber. Entsprechend liegt hier echte Gestaltungsfreiheit: Du entscheidest über Angles, Advertorials, Plattformen und Budgetverteilung – und arbeitest dafür eng mit Creative Strategy, Copywriting und Grafik zusammen.

Je nach Erfahrungslevel schneiden wir die Rolle unterschiedlich zu: Wenn Du bereits mehrere Jahre Native verantwortet hast, übernimmst Du von Beginn an volle Verantwortung für bestimmte Channels oder Funnels. Wenn Du auf dem Weg dorthin bist, wächst Du mit klarer fachlicher Begleitung hinein.

## Aufgaben

- Native Advertising end-to-end: Du planst, baust und steuerst unsere Kampagnen auf Outbrain, Taboola und Mediago – von der Idee bis zur laufenden Optimierung

- Kampagnen-Steuerung: Bidding, Budgetallokation, Publisher-Steuerung und Blacklisting liegen in Deiner Hand. Du erkennst früh, wo Budget verbrennt und wo es sich lohnt

- Direct Response: Du denkst in Advertorials, Landingpages und Angebotslogik. Du weißt, welche Hooks und Mechanismen Menschen zum Kauf bewegen – und baust daraus systematisch Tests

- Testing & Skalierung: Du verantwortest A/B-Tests auf Creative-, Headline- und Landingpage-Ebene und entwickelst daraus Skalierungs-Strategien

- Attribution & Profitabilität: Du arbeitest mit unserem cross-channel Attribution Layer, verstehst den Unterschied zwischen ROAS und POAS – und triffst Budgetentscheidungen entsprechend

- Data & Analytics: Du analysierst Performance-Daten anhand relevanter KPIs (CTR, CPC, CPA, ROAS/POAS, Conversion Rates) und leitest daraus konkrete Handlungsempfehlungen ab

- Creative-Sparring: Du gibst datenbasiertes Feedback und briefst Creative Strategy, Copywriting und Grafik – was performt, was nicht, und warum. Eigene Ideen für neue Angles und Formate sind ausdrücklich erwünscht

- Plattform- & Kanal-Tests: Du testest weitere Native-Plattformen und unterstützt bei angrenzenden Kanälen wie unserem Upsell-Programm (Tool: Aftersell), Criteo, 3rd-Party-Newsletter und Connexity

## Qualifikation

- Mindestens 3 Jahre Erfahrung im Performance Marketing, davon fundierte Erfahrung im Native Advertising (z.B. Outbrain, Taboola)

- Du hast Kampagnen selbst im Tool gebaut und gesteuert – nicht nur über eine Agentur begleitet

- Ausgeprägtes Direct-Response-Verständnis: Advertorials, Landingpages, Angebotslogiken, Funnel-Denken

- Du liebst Zahlen und hast eine analytische, strukturierte Denkweise

- Bid-Strategien und eine effiziente Budgetsteuerung sind für Dich kein Problem

- Du bist kreativ, ideenreich und hast ein starkes Interesse an Storytelling und dem Erstellen von Werbetexten

- Du bist kommunikationsstark, arbeitest selbstständig und bist ein:e echte:r Teamplayer:in

- Du sprichst Deutsch auf Muttersprachniveau oder sehr nah dran (Du beurteilst deutsche Advertorial-Copy) und gutes Englisch

Nice to have

- Erfahrung mit Tracking- und Attributionstools (z.B. Redtrack, Voluum, GA4, Admetrics)

- Erfahrung mit weiteren Kanälen wie z.B. Criteo oder Upsell-Tools (z.B. Aftersell)

- Erfahrung in der Produktion und Optimierung von Advertorials

- Hintergrund im E-Commerce- bzw. D2C-Umfeld, idealerweise Beauty oder Health

## Benefits

- Eine langfristige Perspektive in einem schnell wachsenden Health / Food Scale-up

- kollegiale Zusammenarbeit in gutem Betriebsklima

- flache Hierarchien

- faire Vergütung

- abwechslungsreiche und interessante Tätigkeit

- Scale-up Flair: Du arbeitest eng mit einem dynamischen und hochmotivierten Team zusammen

- Partizipationsmöglichkeiten an fachübergreifender Unternehmensentwicklung

- Mitarbeiter-Veranstaltungen (sofern möglich)

- Netzwerken auf verschiedenen Events und Termine, u.a. Judith Williams

- Einstellung ab sofort

Haben wir Dein Interesse geweckt? Dann freuen wir uns auf Deine vollständige Bewerbung!

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
