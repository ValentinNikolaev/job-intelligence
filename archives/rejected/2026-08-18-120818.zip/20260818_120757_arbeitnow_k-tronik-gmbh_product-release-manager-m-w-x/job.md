# Product Release Manager (m/w/x)

Posted: 2026-08-18T07:30:27Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

## Projektbeschreibung:

Technologie begeistert Sie? Uns auch! Zur Verstärkung unseres Expertenteams bei unserem Kunden aus der Funk- und Kommunikationsbranche suchen wir einen Product Release Manager (m/w/x) in Kiel in Festanstellung bei K-tronik. Wir freuen uns darauf, Sie persönlich kennen zu lernen - und gemeinsam mit Leidenschaft und Teamgeist an spannenden Projekten und zukunftsweisenden Technologien zu arbeiten.

## Aufgaben:

- Du bist zentrale Ansprechperson für alle relevanten Stakeholder und informierst das Management transparent über KPIs und Projektergebnisse

- Als Release Manager (m/w/x) verantwortest du die Planung und Umsetzung stabiler Software-Releases und treibst gleichzeitig die Modernisierung und Automatisierung der Release-Prozesse voran. Du sorgst für Transparenz, Qualität und klare Kommunikation – von der technischen Umsetzung bis zu verständlichen Release Notes

- Du wirst Teil unseres Produkt-Teams und koordinierst umgebungsübergreifende Software-Releases

- Du verantwortest Release-Pläne und moderierst Go-/No-Go-Entscheidungen in der agilen Softwareentwicklung im Produktumfeld

- Du konzipierst und realisierst moderne, skalierbare Release-Prozesse (CI/CD-orientiert) und analysierst sowie optimierst Build-, Test- und Deployment-Automatisierungen

- Du stellst eine zielgruppengerechte, verständliche und vollständige Release-Dokumentation bereit und kannst dabei auf GenAI-Unterstützung zurückgreifen

- Du übernimmst die zielgruppengerechte Release-Kommunikation

- Du bereitest Daten auf, analysierst und visualisierst Ergebnisse und leitest daraus Handlungsempfehlungen ab

## Qualifikationen:

- Du hast ein abgeschlossenes Studium im Bereich IT, Informatik, Informationstechnik oder einer vergleichbaren Fachrichtung oder Ausbildung

- Du zeichnest dich durch mehrjährige Erfahrung im Release Management aus, idealerweise in komplexen Software- oder IT-Landschaften

- Du hast dir ein fundiertes Verständnis von Softwareentwicklungsprozessen (agil, klassisch oder hybrid) erarbeitet

- Du verfügst über Erfahrung im Umgang mit CI/CD-Pipelines und Automatisierungstools wie Jenkins oder GitLab CI

- Du kombinierst deine Praxiserfahrung in der Erstellung von Release Notes sowie technischer Dokumentation mit starken Kommunikations- und Moderationsfähigkeiten

## Benefits:

- Kollegiales und freundschaftliches Arbeitsklima

- Flexible Arbeitszeiten

- 30 Urlaubstage und flexible Urlaubsplanung

- Regelmäßige Team-Events

- Auszeichnung als Kununu TOP Company

- Corporate Benefits (Mitarbeiterangebote)

- Kostenlose Getränke

- Individuelle Weiterbildungsmöglichkeiten

- 360° Betreuung: Feedbackgespräche, Karriereplanung, Unterstützung bei Umzug, etc.

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
