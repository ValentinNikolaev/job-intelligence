# Marketingmanager:in

Posted: 2026-08-18T09:30:35Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Als Marketingmanager:in bei JIMI PALAIS haben Sie die einmalige Gelegenheit, Teil eines dynamischen und innovativen Start-Ups im Bereich Retail Apparel und Fashion zu werden. Unser Unternehmen, das in Hamburg ansässig ist, kombiniert Nostalgie mit der Kultur der Streetwear und einem eleganten Lifestyle, um ein einzigartiges Modeerlebnis zu schaffen. In dieser Rolle sind Sie verantwortlich für die Entwicklung und Umsetzung kreativer Marketingstrategien, die unsere Philosophie von Lässigkeit und Exklusivität widerspiegeln. Sie arbeiten eng mit einem kleinen, engagierten Team zusammen, um unsere Markenpräsenz zu stärken und neue Marktchancen zu identifizieren. Ihre Expertise in digitalem Marketing und Ihre Fähigkeit, Trends zu antizipieren, tragen entscheidend dazu bei, unsere Vision von neu definiertem Streetwear Culture und Classy-Luxury zu verwirklichen. Wenn Sie eine Leidenschaft für Mode und Innovation mitbringen, freuen wir uns darauf, gemeinsam mit Ihnen die besonderen Dinge des Lebens zu zelebrieren.

## Aufgaben

- Entwicklung und Umsetzung innovativer Marketingstrategien zur Stärkung der Markenbekanntheit von Jimi Palais.

- Analyse und Interpretation von Markttrends, um neue Wachstumschancen zu identifizieren und zu nutzen.

- Koordination und Durchführung von Social-Media-Kampagnen zur Förderung des Engagements und der Kundenbindung.

- Zusammenarbeit mit dem Kreativteam, um ansprechende und zielgerichtete Marketingmaterialien zu erstellen.

- Überwachung und Bewertung der Effektivität aller Marketinginitiativen und Anpassung der Strategien basierend auf Performance-Daten.

## Qualifikation

- Abgeschlossenes Studium im Bereich Marketing, Kommunikation oder eine vergleichbare Qualifikation

- Mindestens 3 Jahre Berufserfahrung im Marketing, vorzugsweise in der Modebranche

- Erfahrung im Umgang mit digitalen Marketingtools und Social Media Plattformen

- Kreatives Denken und die Fähigkeit, innovative Marketingstrategien zu entwickeln

- Exzellente Kommunikationsfähigkeiten in Deutsch und Englisch

Schließen Sie sich Jimi Palais an, einem innovativen Modelabel, das Nostalgie und Streetwear vereint. Gestalten Sie als Marketingmanager:in die Zukunft der Fashion-Industrie in einem dynamischen Team!

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
