# Werstudent:in/ Praktikant:in - Product & Growth I Louco App

Posted: 2026-08-18T09:00:26Z

## Rejection

- Category: tech_stack
- Reason: role does not mention Go/Golang or PHP

**Startzeit: Ab sofort**

**Dauer: mind. 3 Monate**

**Ort: remote**

**Du liebst gute Apps, erkennst Verbesserungspotenzial sofort und möchtest nicht nur zuschauen, sondern aktiv mitgestalten? Dann suchen wir dich.**

Die **Louco App** verbindet **Events, Creator und Ticketing** in einer Plattform. Unser Ziel ist es, Menschen dabei zu helfen, spannende Events zu entdecken, ihren Lieblings-Creatorn zu folgen und Tickets einfach und direkt zu sichern.

Dafür suchen wir eine **Werkstudent oder Praktikant im Bereich Product & Growth**, der/die unsere App aktiv mit uns weiterentwickelt, Verantwortung für CRM-Themen übernimmt und gleichzeitig relevante Markt- und Wettbewerbsentwicklungen im Blick behält.

Bei uns bekommst du keine klassischen Praktikantenaufgaben. Deine Ideen, Analysen und dein Feedback sollen direkt dazu beitragen, **die Louco App besser zu machen und weiterzuentwickeln.**

## Aufgaben

📱 Product & App Improvements

Du beschäftigst dich intensiv mit der Louco App und unserer gesamten User Experience.

- Du analysierst bestehende Features und User Flows und identifizierst Verbesserungspotenziale.

- Du entwickelst konkrete Ideen für neue Features und Optimierungen.

- Du beschäftigst dich mit zentralen Journeys wie **Event Discovery, Search, Ticketing, Waitlists, Guestlists und Creator Profiles**.

- Du analysierst, an welchen Stellen Nutzer abspringen oder Prozesse unnötig kompliziert sind.

- Du testest neue Features und Releases aus Sicht unserer Nutzer.

- Du sammelst und strukturierst Feedback und übersetzt es in konkrete Verbesserungsvorschläge.

- Du arbeitest eng mit Product, Design und Development zusammen.

- Du behältst auch nach Releases im Blick, ob Features in der Live-App so funktionieren und angenommen werden wie geplant.

💬 CRM & User Engagement

Ein weiterer wichtiger Teil deiner Rolle ist unser **CRM und die Kommunikation mit unseren Nutzer**.

Du unterstützt nicht nur bei einzelnen Aufgaben, sondern sollst in diesem Bereich zunehmend **eigenständig Verantwortung übernehmen**.

- Du entwickelst und optimierst unsere **E-Mail-, Push- und In-App-Kommunikation**.

- Du konzipierst automatisierte CRM Journeys entlang des gesamten User Lifecycles.

- Du kümmerst dich um Kommunikation rund um **Tickets, Waitlists, Guestlists, Events und Creator**.

- Du arbeitest an Segmentierungen und personalisierten User Journeys.

- Du analysierst Öffnungs-, Klick- und Conversion-Raten und leitest daraus Optimierungen ab.

- Du entwickelst Ideen für **Activation, Engagement, Retention und Re-Activation**.

- Du stellst sicher, dass CRM-Flows, CTAs und Deep Links zuverlässig funktionieren.

- Du unterstützt uns dabei, eine skalierbare CRM-Struktur für die Louco App aufzubauen.

🔎 Market & Competitor Research

Wir wollen nicht nur wissen, was heute im Markt passiert, sondern früh verstehen, **was morgen relevant wird**.

- Du beobachtest den **Event-, Ticketing-, Creator- und Consumer-App-Markt**.

- Du analysierst relevante Wettbewerber und neue Produkte.

- Du untersuchst Features, User Journeys, Geschäftsmodelle, Pricing und Growth-Mechaniken anderer Plattformen.

- Du recherchierst neue Trends und Technologien rund um **Mobile Apps, AI, Ticketing, Events und Creator Economy**.

- Du identifizierst Best Practices und spannende internationale Produkte.

- Du bereitest deine Erkenntnisse kompakt auf und leitest konkrete Empfehlungen für die Louco App daraus ab.

Uns geht es dabei nicht um lange Präsentationen, sondern vor allem um eine Frage:

**Was können wir daraus lernen – und wie können wir Louco noch besser machen?**

## Qualifikation

Du passt gut zu uns, wenn du:

- aktuell studierst oder ein Praktikum suchst,

- bereits erste praktische Erfahrung mit **digitalen Produkten, Apps, CRM, Growth oder Digital Marketing** gesammelt hast,

- ein sehr gutes Verständnis für digitale Produkte und User Experience mitbringst,

- Apps nicht einfach benutzt, sondern automatisch darüber nachdenkst, wie man sie besser machen könnte,

- analytisch denkst und gleichzeitig ein gutes Gespür für Design, Content und Kommunikation hast,

- strukturiert und eigenständig arbeitest,

- gerne recherchierst und neue digitale Trends früh entdeckst,

- Verantwortung übernehmen und eigene Ideen umsetzen möchtest,

- sehr gut auf Deutsch und Englisch kommunizieren kannst.

Erfahrung mit **CRM- und Analytics-Tools, Figma, E-Mail-Automation, Push Notifications oder Product-Management-Tools** ist ein großes Plus.

Was uns besonders wichtig ist

Wir suchen keine Person, die morgens auf eine To-do-Liste wartet.

Wenn dir in der Louco App etwas auffällt, **sprich es an.**

Wenn ein Wettbewerber ein spannendes Feature veröffentlicht, **analysiere es.**

Wenn Nutzer an einer bestimmten Stelle abspringen, **finde heraus, warum.**

Und wenn du eine bessere Idee hast, **bring sie ein.**

Du sollst die Louco App nicht nur unterstützen – du sollst **mitdenken, hinterfragen und mitgestalten.**

## Benefits

🚀 **Echter Impact**

Deine Arbeit und deine Ideen können direkt in unser Produkt einfließen.

📱 **Ein echtes digitales Produkt**

Du arbeitest an einer Live Consumer App und nicht an theoretischen Cases.

💡 **Verantwortung statt Praktikantenaufgaben**

Wir möchten, dass du eigene Themen übernimmst und vorantreibst.

🤝 **Direkte Zusammenarbeit**

Du arbeitest eng mit Foundern, Product, Design und Development zusammen.

🎟️ **Events, Creator & Tech**

Du arbeitest an der Schnittstelle von Event Discovery, Ticketing, Creator Economy, CRM und AI.

📈 **Wachse mit uns**

Mit der Louco App kann auch dein Verantwortungsbereich wachsen.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
