# IT Engineer

Posted: 2026-08-18T20:40:23Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

## **About Black Forest Labs**

We're the team behind Latent Diffusion, Stable Diffusion, and FLUX—foundational technologies that changed how the world creates images and video. We’re creating the generative models that power how people make images and video—tools used by millions of creators, developers, and businesses worldwide. Our FLUX models are among the most advanced in the world, and we're just getting started.

Headquartered in Freiburg, Germany with a growing presence in San Francisco, we’re scaling fast while staying true to what makes us different: research excellence, open science, and building technology that expands human creativity.

## **Why This Role**

This is a build role, not a maintenance one. You'll take a partially built environment that still runs largely on manual ClickOps and turn it into automated, self-service, code-defined infrastructure for workforce enablement.

## **What You'll Work On**

-

Own the full endpoint lifecycle for our (currently all-macOS) fleet: purchasing, issuance, zero-touch setup, management, and retrieval.

-

Complete our MDM migration across the endpoint fleet.

-

Own identity and access across our SaaS vendor stack, and replace manual access administration with an automated joiner-mover-leaver lifecycle (SSO, SCIM, provisioning/de-provisioning).

-

Build automation and internal tooling to remove routine human work from the path to staff productivity.

-

Define IT infrastructure as code, with configuration, provisioning, and access managed in version control.

-

Implement and maintain identity, access, and endpoint security controls for workforce systems, ensuring the fastest path is the secure path.

-

Provide workplace technical support in Freiburg and remote support for our San Francisco office.

-

Manage video conferencing equipment across offices.

-

Develop the tooling and reporting that turn endpoint metrics, tool usage, and support data into a clear picture of our operational health.

## **What We're Looking For**

-

Hands-on IT / corporate engineering experience in a fast-growing startup, and comfortable being the primary day-to-day IT contact.

-

macOS fleet management, MDM (Iru, Jamf, or similar), Apple Business Manager / ADE, and zero-touch provisioning experience.

-

Identity and access administration with an IdP, including SSO/SAML and SCIM-based lifecycle automation across SaaS applications.

-

Scripting and automation (e.g. Python, shell) and hands-on infrastructure-as-code experience (e.g. Terraform).

-

A security mindset for workforce systems: access, endpoints, and the tradeoffs between control and usability.

### **While not required, it's an added plus if you also have:**

-

Experience running an MDM migration or standardizing an existing fleet.

## **How We Work Together**

We're a distributed team with real offices that people actually use. Depending on your role, you'll either join us in Freiburg or SF at least 2 days a week (or one full week every other week), or work
remotely with a monthly in-person week to stay connected. We'll cover reasonable travel costs to make this possible. We think in-person time matters, and we've structured things to make it accessible to all. We'll discuss what this will look like for the role during our interview process.

**Everything we do is grounded in four values:**

-

**Obsessed.** We are a frontier research lab. The science has to be right, the understanding deep, the product beautiful.

-

**Low Ego.** The work speaks. The best idea wins, no matter who said it. Credit is shared. Nobody is above any task.

-

**Bold.** We take the ambitious bet. We ship, we do not wait for conditions to be perfect.

-

**Kind.** People over politics. We treat each other with genuine warmth. Agency without empathy creates chaos.

If this sounds like work you’d enjoy, we’d love to hear from you.

**Base Annual Salary:**

**EU **€95,000 - €110,000 + Equity

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
