# Senior Site Reliability Engineer, Vehicle SW

Posted: 2026-09-03T17:55:03Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

## **About us **

Founded in 2017, Wayve is the leading developer of Embodied AI technology. Our advanced AI software and foundation models enable vehicles to perceive, understand, and navigate any complex environment, enhancing the usability and safety of automated driving systems.

Our vision is to create autonomy that propels the world forward. Our intelligent, mapless, and hardware-agnostic AI products are designed for automakers, accelerating the transition from assisted to automated driving.

In our fast-paced environment big problems ignite us—we embrace uncertainty, leaning into complex challenges to unlock groundbreaking solutions. We aim high and stay humble in our pursuit of excellence, constantly learning and evolving as we pave the way for a smarter, safer future.

At Wayve, your contributions matter. We value diversity, embrace new perspectives, and foster an inclusive work environment; we back each other to deliver impact.

Make Wayve the experience that defines your career!

## **The role **

As an SRE in Vehicle Software, you will keep Wayve’s autonomous driving fleet reliable, observable, and safe while it operates on public roads. You will work at the boundary of software, hardware, and operations, turning real-world incidents and performance bottlenecks into lasting engineering improvements. This role offers a direct line of sight from what you build to safer deployments, faster iteration, and greater fleet scale.

**Key responsibilities**

- Own and improve the reliability, availability, and performance of vehicle software systems used across the dev fleet.

- Take part in a team on-call rotation, providing out-of-hours support for live systems when required.

- Build and operate monitoring, logging, alerting, and on-call tooling that enables fast detection, diagnosis, and recovery.

- Drive incident response and post-incident learning, translating root causes into durable fixes and preventative controls.

- Design and deliver automation for fleet operations, deployments, and repetitive workflows to reduce manual intervention.

- Partner closely with Vehicle SW, operations, and platform teams to define SLOs, reliability metrics, and release readiness.

- Continuously harden the production environment through capacity planning, change management, and reliability-focused reviews.

## **About you**

In order to set you up for success as a Site Reliability Engineer at Wayve, we’re looking for the following skills and experience.

**Essential skills**

- Proven experience in an SRE, production reliability, or platform operations role for complex distributed systems.

- Strong Linux fundamentals and hands-on experience with CI/CD, containers (Docker), and orchestration (Kubernetes).

- Proficiency in at least one systems or scripting language (Python, C++, or Rust) with a bias for automation.

- Deep troubleshooting skills across networking, distributed systems, and databases, including performance and availability issues.

- Experience designing observability stacks and using tools such as Datadog, Prometheus, Grafana, OpenTelemetry, Splunk, or Humio.

- Clear communication skills, including incident leadership, writing postmortems, and influencing engineering priorities.

**Desirable skills**

- Cloud platform experience (AWS, GCP, or Azure), including infrastructure-as-code and secure production operations.

- Experience with real-time or safety-critical systems, hardware-in-the-loop, or embedded/robotics environments.

- Familiarity with fleet operations, telemetry pipelines, and operating software on edge devices at scale.

- Experience defining and running SLOs/SLIs and reliability programs across multiple teams.

This is a full-time role based in our office in Germany, Baden-Württemberg (Hybrid 3 days a week min). At Wayve we want the best of all worlds so we operate a hybrid working policy that combines time together in our offices and workshops to fuel innovation, culture, relationships and learning, and time spent working from home.

Wayve is committed to creating an inclusive interview experience. If you require any accommodations or adjustments to participate fully in our interview process, please let us know.

We understand that everyone has a unique set of skills and experiences and that not everyone will meet all of the requirements listed above. If you’re passionate about self-driving cars and think you have what it takes to make a positive impact on the world, we encourage you to apply.

At Wayve we're committed to creating a diverse, fair and respectful culture that is inclusive of everyone based on their unique skills and perspectives, and regardless of sex, race, religion or belief, ethnic or national origin, disability, age, citizenship, marital, domestic or civil partnership status, sexual orientation, gender identity, veteran status, pregnancy or related condition (including breastfeeding) or any other basis as protected by applicable law.

For more information visit [Careers at Wayve. ](https://wayve.ai/careers/)

To learn more about what drives us, visit [Values at Wayve ](https://wayve.ai/careers/)

For US candidates only, please visit [E-Verify Notice](https://drive.google.com/file/d/1N46n3iN0AG8EPEO-hCanyyv7hzz8KgT_/view?usp=sharing) and [Participation and Right to Work](https://www.ussc.gov/sites/default/files/pdf/employment/RightToWork.pdf)

DISCLAIMER: We will not ask about marriage or pregnancy, care responsibilities or disabilities in any of our job adverts or interviews. However, we do look to capture information about care responsibilities, and disabilities among other diversity information as part of an optional DEI Monitoring form to help us identify areas of improvement in our hiring process and ensure that the process is inclusive and non-discriminatory.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
