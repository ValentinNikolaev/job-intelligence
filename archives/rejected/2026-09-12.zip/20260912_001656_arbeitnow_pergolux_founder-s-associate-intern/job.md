# Founder’s Associate Intern

Posted: 2026-09-11T17:40:05Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

# The opportunity

Help build a new part of the business while the first Pergolux showrooms take shape. Working closely with leadership and the team leading the rollout, you’ll evaluate locations, build business cases and move live opportunities forward. You’ll turn what we learn into practical tools and a repeatable expansion playbook.

You’ll combine research and modelling with calls, site visits and follow-up. You’ll own defined projects, with priorities and analysis reviewed by your manager. Leadership retains responsibility for lease commitments and investment decisions.

# What you’ll do

-

Evaluate opportunities: research priority markets, customer demand, retail formats and competitors; speak with brokers, landlords and operators to test assumptions.

-

Build business cases: compare rent, setup investment, revenue scenarios and expected payback; make assumptions and commercial trade-offs clear.

-

Progress the pipeline: follow up on live opportunities, organise information and coordinate next steps with internal teams and external partners.

-

Improve decision-making: develop practical location scorecards and decision criteria with the rollout team, highlighting what is known and what still needs checking.

-

Build useful tools: improve workflows, handovers and reporting with simple templates, dashboards and automations.

-

Capture early lessons: compare initial assumptions with available showroom results and customer feedback, then recommend changes for the next wave. Longer-term economics will continue to be tested as data builds.

# What you’ll bring

-

You are studying or have recently graduated; your subject matters less than your ability to think clearly and deliver useful work.

-

You enjoy moving between research, conversations and numbers, and can explain a recommendation and its assumptions.

-

You are comfortable using Excel or Google Sheets to organise data, compare scenarios and build basic financial models.

-

You take initiative, follow up reliably and bring structure to incomplete information.

-

You communicate confidently in German with external partners and in English with international colleagues.

-

You are willing to travel across Germany for site visits and project work.

# Helpful, not required

-

Experience in retail, commercial real estate, consulting, startups, operations or business development.

-

A project where you built a business case, improved a process or created an internal tool.

-

Experience using AI or no-code tools to build useful automations, dashboards or data workflows. We care about sound judgement and useful results; coding experience is optional.

# What we offer

-

Defined project ownership and close collaboration with leadership on a live expansion initiative.

-

Practical experience in location evaluation, commercial modelling and the work behind showroom openings.

-

The opportunity to see your analysis inform investment decisions and your tools support future expansion.

-

An international team, modern equipment, employee events and product discounts.

# How to apply

Send your CV and 3–5 sentences about a project where you turned an unclear problem into a concrete result to [application link or email]. No formal cover letter is needed. If you have built or automated something, you are welcome to share an example—AI projects are optional.

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
