# Praktikant:in (w/m/d) - für Integration und Deutschsprachlehre

Posted: 2026-09-11T20:40:13Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Unser Ziel ist eine Solaranlage auf jedem Dach, ein Speicher in jedem Haus und ein E-Auto in jeder Garage. Enpal macht das möglich mit einer integrierten Gesamtlösung für dezentrale Energie – von Solaranlage und Batteriespeicher über Wallbox, Smart Meter bis zur Wärmepumpe. Herzstück ist unsere KI-gestützte Plattform [Enpal.One](http://Enpal.One)+, die tausende Systeme intelligent vernetzt und Strombezug sowie -einspeisung effizient am Energiemarkt optimiert.

Bist Du bereit für Lösungen, die mehr als nur ein Versprechen sind und täglich echte Lebensqualität in tausende Haushalte bringen? Was du bei Enpal gestaltest, liefert morgen sauberen Strom und verändert nachhaltig, wie wir Energie nutzen.

###
**Deine Aufgaben**

Im Projekt „Global Growth“ integrieren wir Elektriker aus Südamerika, die deutschlandweit Photovoltaik-Anlagen und Wärmepumpen installieren. Dafür erhalten kolumbianische und brasilianische Fachkräfte in unserer Enpal-Akademie in Blankenfelde-Mahlow (Ludwig-Erhard-Ring 12, 15827) eine 6-wöchige technische und sprachliche Ausbildung – und genau hier brauchen wir deine Hilfe!

Zum **Juli** **2026 oder August 2026** suchen wir eine:n Praktikant:in für 6 Monate in Vollzeit zur Unterstützung bei folgenden Aufgaben:

-

Durchführung von Deutsch-Sprachschulungen (DaF) auf den Niveaustufen A2/B1

-

Weiterentwicklung didaktischer Unterrichtsmaterialien, insbesondere im Bereich Fachsprache Elektrik

-

Auswahl und Einsatz geeigneter Lernmethoden und -tools

-

Betreuung südamerikanischer Fachkräfte vor Ort in der Enpal-Akademie

-

Mitwirkung beim Aufbau und der Koordination zusätzlicher Online-Sprachkurse

-

Durchführung qualitativer Evaluationsprozesse zur Bewertung der Schulungswirksamkeit

-

Unterstützung bei administrativen Prozessen

### **Dein Profil**

-

Lehrerfahrung im Bereich Deutsch als Fremdsprache und/oder Studium der Sprachwissenschaften

-

Sprachkenntnisse in Spanisch, mindestens auf B2-Niveau

-

Kulturraumerfahrung Südamerika wünschenswert

-

Hohe Motivation und Teamgeist, Freude an der Arbeit mit Menschen

-

Kommunikationsstärke und sicheres Auftreten

-

Lösungsorientiert, belastbar und selbstständig

-

Sehr gutes Organisationstalent

###
**Darauf kannst Du Dich freuen**

-

**Arbeite in Deutschlands erstem grünen Unicorn** - Gestalte aktiv die solare Energiewende mit.

-

**Die Sonne scheint auf der ganzen Welt** - Bei Enpal arbeitest du mit einem hochmotivierten, diversen Team aus über 65 Nationalitäten.

-

**Das ideale Setup für deinen Fokus - **Wir sind überzeugt, dass exzellente Ergebnisse dort entstehen, wo die Bedingungen stimmen. Deshalb setzen wir auf ein hybrides Arbeitskonzept, das dir die Freiheit gibt, immer genau so zu arbeiten, wie es am besten zu deinen Aufgaben passt. Du brauchst neue Impulse auf internationalem Niveau? Mit Workflex bieten wir, abhängig von deiner Verantwortung, die Möglichkeit, deine Tätigkeit bis zu 30 Tage im Jahr ins Ausland zu verlegen.

-

**Grown-up Business & Startup Spirit** - In unserem modernen Office in Berlin-Friedrichshain findest du von höhenverstellbaren Tischen, Tischtennisplatte bis gefüllten Getränkekühlschränken und Barista-Coffee alles was das Herz begehrt.

-

**Dein Kick-start bei Enpal** - Onboarding-Tag mit Welcome Bag, Buddy-Programm und einem Team, das dich wirklich abholt.

-

**Bleib auf dem Laufenden & gestalte mit** -** **Transparente All-Hands, kurze Entscheidungswege und eine offene Feedback-Kultur, denn ohne Fehler gibt es keinen Fortschritt.

-

**Energiewende geht nur gemeinsam** - Bei Enpal erwartet dich ein legendärer Teamspirit und unvergessliche Team- und Companyevents.

-

**Dein Extra-Boost** -** **29 + 2 Urlaubstage, vergünstigte Mitgliedschaft bei Wellhub und Corporate Benefits. Alles, was dir hilft, Arbeit und Leben gut zu verbinden.

*Wir bei Enpal sind stolz auf die Vielfältigkeit unseres Teams. Weder bei der Einstellung noch während des Beschäftigungsverhältnisses werden Entscheidungen auf Basis von Hautfarbe, Religion oder religiösen Glaubens, ethnischer oder nationaler Herkunft, Nationalität, Geschlechteridentität, sexuelle Orientierung, Behinderung oder Alter getroffen. Enpal steht für einen sicheren Arbeitsplatz und geht gegen Diskriminierung und Belästigung jeglicher Art vor.*

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
