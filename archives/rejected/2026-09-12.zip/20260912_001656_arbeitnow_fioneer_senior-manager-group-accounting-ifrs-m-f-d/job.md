# Senior Manager Group Accounting & IFRS (m/f/d)

Posted: 2026-09-11T17:20:15Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**Shape the Future of Finance with SAP Fioneer!**

At **SAP Fioneer**, we’re not just building software — we’re redefining what’s possible in financial services. As a global fintech innovator, we empower banks and insurers to run smarter, faster, and more flexibly with cloud-native solutions built on SAP’s trusted foundation.

We’re growing fast — and we’re looking for a **Senior Manager Group Accounting & IFRS (m/f/d) **who is as passionate about precision as about progress. If you’re an expert in **IFRS and HGB**, thrive on complex revenue models, and want to make an impact in a high-growth, high-tech environment, we want to meet you!

**Requirements**

**What You’ll Do**

- Drive the month-end, quarter-end, and year-end close processes for revenue and related accounts, ensuring timely and accurate results.
- Lead the end-to-end process of revenue recognition for software licenses, SaaS, and professional services, ensuring compliance with IFRS 15 and local GAAP for 20 countries.
- Prepare, review, and analyze financial statements (balance sheet, P&L, cash flow) under both IFRS and HGB, ensuring compliance and transparency.
- Take ownership of group reporting, consolidating results and coordinating the activities that power both internal decisions and external disclosures.
- Build and evolve accounting policies, procedures, and internal controls that keep our financial reporting rock-solid.
- Author technical accounting memos and documentation that stand up to audit scrutiny.
- Manage internal and external audits with confidence and clarity, serving as the primary point of contact and owning the resolution of accounting and reporting matters.
- Continuously improve financial systems and processes, with a focus on automation, efficiency, and scalability in a cloud-first environment.
- Be a trusted advisor on financial reporting topics across the business.

**What You Bring**

- A degree in Accounting, Finance, or a related field — CPA, ACCA, or equivalent is a big plus.
- 6+ years of experience in accounting, ideally in the software or professional services space.
- Deep knowledge of IFRS (especially IFRS 15) and HGB — and the ability to apply it in real-world, fast-moving scenarios.
- Strong experience in financial statement preparation, group reporting, and consolidation.
- Experience with SAP ERP, preferably S/4 HANA, and a passion for leveraging technology to improve processes.
- Strong analytical skills, attention to detail, and the confidence to communicate complex topics clearly.
- Fluent in English and German.

**Benefits**

**Why SAP Fioneer?**

- Be part of a **scale-up with enterprise roots** — combining the agility of a startup with the stability of SAP.
- Work on **cutting-edge financial solutions** that are transforming the industry.
- Enjoy a **flexible hybrid work model**, competitive compensation, and a culture that values innovation, ownership, and collaboration.
- Join a team of **smart, driven, and genuinely nice people** who love what they do.

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
