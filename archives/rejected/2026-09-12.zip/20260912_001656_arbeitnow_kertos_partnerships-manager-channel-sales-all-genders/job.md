# Partnerships Manager - Channel Sales (all genders)

Posted: 2026-09-11T20:40:04Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**Kertos is the fastest-growing compliance startup in Europe.** Following our **€14M Series A**, backed by leading VCs and business angels, we are building the **compliance engine for Europe** – faster, smarter, and more automated than ever. With customers like **Enpal, Flink, Personio, and Blacklane**, leading companies trust our AI-native platform that automates compliance, scales effortlessly, and makes organizations audit-ready in record time. The market is growing by **20% every year**, fueled by regulations like **GDPR, NIS2, DORA, and the AI Act**. We are perfectly positioned to establish Kertos as the European compliance champion. There has never been a better moment to join our team. **Come shape the future of compliance in Europe with us.**

**Your purpose at Kertos**

Als Channel Sales Manager übernimmst du die Gesamtverantwortung für den Partnerkanal von Kertos – von der Pipeline bis zum Umsatz. Du baust das Ökosystem von Grund auf auf: du entscheidest, welche Partner wir angehen, gewinnst sie und machst aus diesen Beziehungen eine verlässliche, messbare Wachstumsquelle. Dabei arbeitest du eng mit Sales, Marketing und Product zusammen, damit Partnerschaften kein Silo bilden, sondern echten Impact im gesamten Unternehmen erzeugen.

-

Auf- und Ausbau des Partnerkanals mit belastbaren, vertrauensbasierten Beziehungen zu Key-Partnern – mit dem Ziel, Umsatzwachstum zu treiben und Partner- und Kundenzufriedenheit sicherzustellen.

-

Rekrutierung und Onboarding kommerzieller Partner, darunter Reseller und MSSPs, sowie kontinuierliche Weiterentwicklung unserer Partner-Go-to-Market-Strategie.

-

Entwicklung skalierbarer Prozesse zur Gewinnung, Aktivierung und langfristigen Betreuung strategischer Partner – damit das Programm strukturiert und nachhaltig wächst.

-

Konzeption und Durchführung von Partner-Enablement-Programmen, Webinaren und Trainings, die Partner in die Lage versetzen, Kertos selbstständig und überzeugend bei ihren Kunden zu positionieren.

-

Aufbau eines nachhaltigen Partner-Ökosystems, das qualifizierte Leads bei Endkunden generiert und neue Geschäftsmöglichkeiten erschließt.

-

Enge Zusammenarbeit mit Marketing, Product und Sales, um Partnerinitiativen mit den Unternehmenszielen abzustimmen und den Partnerkanal konsequent weiterzuentwickeln.

**The skills, motivation, and mentality you should bring**

-

Du hast nachweislich Partnerprogramme im B2B SaaS-Umfeld aufgebaut oder wesentlich mitgestaltet – idealerweise in einem Startup oder Scale-up.

-

Du hast einen Hintergrund im Channel Sales mit einer quota-carrying Rolle und hast langjährige Erfahrung darin, wie Pipeline über Partner generiert und Deals gewonnen werden.

-

Du arbeitest eigenverantwortlich und lieferst Ergebnisse, auch wenn kein Playbook existiert – das ist dein bevorzugtes Umfeld, nicht dein Problem.

-

Deine Kommunikations- und Verhandlungsfähigkeiten auf Entscheiderebene sind auf Deutsch und Englisch gleichermaßen stark.

-

Erfahrung in der Compliance-, Cybersecurity- oder Legal-Tech-Branche ist ein echtes Plus – du weißt, wer unsere Kunden sind und welche Partner für sie relevant sind.

-

Du misst deinen Erfolg an Partnership-sourced Pipeline und ARR.

**Why Kertos**

-

**Dein Erfolg ist unser Erfolg**: Du partizipierst am Unternehmenserfolg durch unseren Virtual Share Incentive Plan (VSIP)

-

**Cutting Edge AI Technologie**: Führende VCs haben in unsere Vision und nachhaltiges Wachstum investiert, damit wir nachhaltig verändern, wie Compliance-Maßnahmen gehandhabt werden

-

**Großer Impact**: Bei uns bekommst du Verantwortung ab Tag 1, arbeitest selbstständig an Themen und bringst so Kertos richtig voran

-

**Starkes Onboarding**: Keine Ahnung von Compliance? Kein Problem, wir schlauen dich auf und stellen dir einen Onboarding-Buddy an die Seite

-

**Regelmäßiges Feedback**: Wir leben eine offene Feedbackkultur und unterstützen dich bei deinem Wachstum mit regelmäßigen 1-1s, 360 Grad Feedback, Schulungen und einem Top Netzwerk von Expert*innen

-

**Mental Health**: In Zusammenarbeit mit nilo legen wir Wert auf dein Wohlbefinden und bieten allen Mitarbeitenden individuelle Unterstützung für ihre mentale Gesundheit

-

**Keep growing**: Um deine berufliche und persönliche Weiterentwicklung zu unterstützen, stellen wir dir ein jährliches Budget von 1.500€ zur Verfügung

-

**Volle Flexibilität**: Ob im Münchner Hauptquartier, Berliner Büro oder aus dem Homeoffice – wir sind flexibel und du happy

-

F**ür Sportsfreund*innen**: Wir bezuschussen deine Wellpass-Mitgliedschaft für den sportlichen Ausgleich zum Arbeitsalltag

-

**Fahrrad Leasing**: Neues Fahrrad gefällig? Easy, nutze unser unsere Partnerschaft mit JobRad und lease dir ein Fahrrad

-

**Gemeinsam stark**: Wir arbeiten über unsere Standorte hinweg eng zusammen, unterstützen uns gegenseitig und schaffen durch echtes Miteinander eine starke, einzigartige Kultur, die uns erfolgreich macht.

-

**Regelmäßige Team-Events**: Ob Brunch, Lunch oder After Work,wir nehmen uns regelmäßig Zeit, auch jenseits des Arbeitsalltags gemeinsam Zeit zu verbringen und Spaß zu haben.Dazu kommen legendäre Sommer- und Winterpartys sowie jährliche Offsites

**Sounds like you are the one we’ve been looking for?**

Du willst Teil unserer Wachstumsstory sein und mit uns den Weg ebnen, Europas Compliance-Leader zu werden? Dann melde dich bei uns. Wir freuen uns auf deine Bewerbung! Falls du vorher noch Fragen hast, melde dich jederzeit bei Julia, unserem Senior Talent Acquisition Manager.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
