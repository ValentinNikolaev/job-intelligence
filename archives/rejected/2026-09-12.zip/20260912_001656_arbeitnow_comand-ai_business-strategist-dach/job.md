# Business Strategist - DACH

Posted: 2026-09-11T20:40:14Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Comand AI's mission is to deliver the next-generation of software to the European defense.

From the very identification of the capacities that need building to their actual delivery within the hands of our forces, achieving our objective means finding the narrow ways through complex legacy environments, dense ecosystems, concrete partnership engagements.

We are looking for a Business Strategist to build Comand AI’s presence from the ground up. You will identify the right entry points, build trusted relationships across the defense ecosystem, and create the path from first operational engagement to pilot and contract. Working closely with product and forward deployed teams, you’ll turn operational proof into commercial traction and establish Comand AI as a trusted partner in the market.

What this looks like in practice:

-

Build Comand AI’s presence in your market: identify the right units, partners, champions, and procurement pathways, then own the journey from first engagement through experimentation, pilot, and contract

-

Identify and shape strategic opportunities before formal procurement, positioning Comand AI where operational needs emerge

-

Build and maintain trusted relationships across the defense ecosystem, from operational units to industrial partners and government stakeholders

-

Navigate long, politically sensitive B2G sales cycles involving multiple stakeholders, security clearances, RFIs, RFPs, and public procurement rules

-

Translate Prevail’s technical capabilities into language that resonates with procurement officers, general staffs, and program leads

-

Work closely with the founders, product, and forward deployed teams to turn field validation into commercial traction

-

Collaborate with a Europe-wide team to unlock strategic opportunities with armed forces, partners, and defense organizations

## Who We're Looking For

**Must-have:**

-

Experience selling into armed forces, ministries of defense, or another highly regulated B2G market with long sales cycles

-

A top performing history on your sales team and a clear track record of two or three large-size deals you personally closed

-

Comfortable building a pipeline and a market from close to zero, without a playbook handed to you

-

Technical curiosity and the ability to understand complex software products well enough to translate them into operational and commercial value

-

Empathy for military users and their mission

-

EU citizenship (contractual requirement tied to our defense contracts)

-

Fluency in the local language of the market you're covering, plus English

**Nice to have:**

-

Existing relationships inside defense ministries, armed forces, or NATO-adjacent institutions

-

Prior experience at a defense tech or dual-use startup

-

Background in the military or a related government role

## What's In It For You

-

Competitive package (top 0.1% of compensation in Europe: base + equity)

-

Munich-based with field travel to active deployment areas

## The Process

-

**Talent screening**: 30 min, online. Background and motivation.

-

**Role screening**: 60 min, online.

-

**Onsite in Paris**: half day.

-

**Roundtable**: hiring committee.

## How to Apply

If this sounds like a good fit, we’d love to hear from you. Apply using the link above.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
