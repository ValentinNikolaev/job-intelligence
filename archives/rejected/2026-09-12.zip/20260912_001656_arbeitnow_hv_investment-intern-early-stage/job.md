# Investment Intern – Early Stage

Posted: 2026-09-11T17:40:07Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

HV backs bold founders from the first check to IPO.

With €2.8 billion in assets under management and a track record spanning nine fund generations, HV has invested in more than 290 companies across Europe, from consumer and software to deep tech and AI.

Through dedicated Venture and Growth funds, HV backs founders at every stage of their journey, from first cheque to global scale. This approach makes HV one of Europe's leading multistage investors and a long-term partner to bold founders who are building the future.

Our Venture Fund leads Seed and Series A rounds with investments from €500K to €10M, backing founders from the earliest stages of company building — including the first checks into Zalando, Flix, Depop, Neura Robotics, and Upvest.

## **About the Internship**

Join the Early Investment Team in Munich or Berlin.

**Key Responsibilities**

-

**Deal Analysis & Due Diligence:** Assess investment opportunities through market and competitive research, product deep-dives, customer insights, KPI analysis and financial modelling.

-

**Sourcing & Founder Interaction:** Identify promising companies through proactive sourcing and your network, meet founders and develop a view on team quality and execution potential.

-

**Market Views:** Build expertise in one or two sectors, understand key trends and players, and translate your insights into actionable investment theses.

-

**Investment Process:** Support deals from initial screening through investment decision, including investment memos, expert calls, cap tables and participation in IC discussions.

-

**Portfolio Support:** Stay close to portfolio companies, track performance and key KPIs, and identify early warning signs, inflection points and areas for support.

**What We're Looking For**

*Essential:*

-

**Strong analytical and research skills**, with a data-driven, pragmatic approach and real attention to detail.

-

**Intellectual curiosity** and a genuine interest in startups, technology, business models and what makes great companies succeed.

-

**Clear communication and ownership**: be able to turn complex information into actionable insights and confidently engage with founders and colleagues.

-

**Financial literacy**, including comfort with spreadsheets, business metrics, unit economics and basic accounting.

-

**Proficiency with AI tools**: we use them every day and expect you to do the same.

*Nice-to-haves:*

-

Previous experience in venture capital, investment banking or consulting.

-

Experience at a fast-growing startup, whether as a founder, early employee or in an operating role.

-

A technical background in areas such as engineering, product or data science.

**Why Join HV Capital**

-

Exceptional access: work directly with senior investors and attend pitches, diligence meetings, and board meetings.

-

Real responsibility: your analysis and insights will directly influence investment decisions.

-

Founder networks: build relationships with founders and industry leaders across Europe.

-

Learning curve: quickly deepen your understanding of venture capital, SaaS, fintech, and AI in a real-world setting.

-

Career pathways: we have a strong track record of interns moving into analyst and investment roles.

Duration: 3 to 6 months (flexible; preferred start November/December 2026 or Q1 2027).

Location: Munich or Berlin, Germany

Language: fluent English required

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
