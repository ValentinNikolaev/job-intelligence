# IT-Systemadministrator - Linux (m/w/d)

Posted: 2026-09-11T22:30:26Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**Stabilität, moderne IT und echte Wertschätzung.**

Du möchtest in einem erfolgreichen und wirtschaftlich stabilen Unternehmen arbeiten, in dem deine Leistung nicht nur gesehen, sondern auch entsprechend honoriert wird? Dann erwartet dich hier ein Umfeld, das fachliche Kompetenz ebenso schätzt wie den Menschen dahinter. Die Umstellung von Windows auf Linux wurde bereits erfolgreich vollzogen – jetzt geht es darum, die neue Linux-Infrastruktur professionell zu betreiben, weiterzuentwickeln und langfristig zukunftssicher aufzustellen.

## Aufgaben

- **Linux-Systemadministration:** Betrieb, Administration, Wartung und kontinuierliche Optimierung der bestehenden Linux-Serverlandschaft.

- **Infrastruktur & Weiterentwicklung:** Weiterentwicklung der bereits migrierten Linux-Umgebung sowie Implementierung neuer Systeme und technischer Lösungen.

- **Monitoring & Troubleshooting:** Überwachung der Systeme, Analyse von Störungen und nachhaltige Behebung technischer Probleme mit Blick auf Verfügbarkeit und Performance.

- **Security & Automatisierung:** Weiterentwicklung von Sicherheitsstandards sowie Automatisierung wiederkehrender administrativer Prozesse und Deployments

## Qualifikation

- Fundierte Kenntnisse in der **Administration von Linux-Systemen** und ein gutes Verständnis moderner IT-Infrastrukturen.

- Eine **strukturierte und zuverlässige Arbeitsweise**, verbunden mit Verantwortungsbewusstsein, Teamgeist und dem Wunsch, sich langfristig einzubringen.

## Benefits

- **Attraktives Gehalt**, das deiner Erfahrung, Verantwortung und fachlichen Kompetenz gerecht wird.

- **Hohe Arbeitsplatzsicherheit** bei einem wirtschaftlich stabilen und erfolgreichen Unternehmen.

- **Große persönliche Wertschätzung** und eine Unternehmenskultur, in der der Mensch zählt.

- **Moderne Linux-Infrastruktur**, bei der die Migration bereits abgeschlossen ist und du dich auf Betrieb und Weiterentwicklung konzentrieren kannst.

- **Weiterbildungs- und Entwicklungsmöglichkeiten**, um deine fachlichen Stärken gezielt auszubauen.

- **Langfristige Perspektive** mit verantwortungsvollen Aufgaben und echtem Gestaltungsspielraum.

Klingt nach deinem nächsten Schritt?

Dann freuen wir uns darauf, dich kennenzulernen. Bei uns sollst du nicht einfach eine weitere Position besetzen, sondern mit deiner Erfahrung und Persönlichkeit ein geschätzter Teil des Teams werden. **Gute Arbeit verdient Vertrauen, Anerkennung und eine faire Vergütung – und genau das möchten wir dir bieten.**

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
