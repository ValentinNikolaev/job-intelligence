# Influencer Marketing Manager (m/w/d), Vollzeit, 100% Remote

Posted: 2026-09-11T20:30:33Z

## Rejection

- Category: tech_stack
- Reason: role does not mention Go/Golang or PHP

Du entdeckst gerne neue Creator, kannst Menschen für eine Zusammenarbeit begeistern und behältst auch bei mehreren laufenden Kooperationen den Überblick? Dann unterstütze uns dabei, unser Influencer Marketing bei meluya weiter auszubauen.

Meluya ist eine Marke für Musselin-Bettwäsche und Wohntextilien. Wir suchen jemanden, der passende Influencer findet, Kooperationen organisiert und gemeinsam mit uns herausfindet, welche Partnerschaften unsere Marke voranbringen.

## Aufgaben

- **Passende Influencer finden:** Du recherchierst Creator, die zu unseren Produkten und unserer Zielgruppe passen, und prüfst ihre Insights, Inhalte und Community.

- **Kontakte aufbauen:** Du übernimmst den Outreach per E-Mail oder Direktnachricht, beantwortest Anfragen und hältst den Kontakt zu Influencern und Managements.

- **Kooperationen abstimmen:** Du holst Angebote und Insights ein und verhandelst Preise, Leistungen und Veröffentlichungstermine.

- **Die Umsetzung begleiten:** Du koordinierst Produktauswahl und Versand, bereitest Briefings vor und behältst vereinbarte Inhalte und Termine im Blick.

- **Den Überblick behalten:** Du dokumentierst Absprachen, pflegst unsere Kontakte und hakst nach, wenn noch etwas fehlt.

- **Ergebnisse auswerten:** Du sammelst die Ergebnisse der Kooperationen und wertest diese aus.

- **Partnerschaften weiterentwickeln:** Du betreust bestehende Kontakte und planst mit uns weitere Kooperationen mit Creatorn, die gut zu meluya passen.

## Qualifikation

- Du hast erste praktische Erfahrung im Influencer Marketing, Creator Management oder in der Betreuung von Kooperationen, idealerweise für eine Marke oder Agentur.

- Du kennst dich auf Instagram aus und hast ein Gespür dafür, welche Creator und Inhalte zu einer Marke passen.

- Du gehst gerne auf Menschen zu und traust dich, Preise zu besprechen und nachzuverhandeln.

- Du arbeitest strukturiert und zuverlässig. Auch bei mehreren Kooperationen gleichzeitig gehen dir Absprachen und Fristen nicht verloren.

- Du kannst mit Tabellen und Zahlen umgehen und möchtest verstehen, welche Kooperationen sich wirtschaftlich lohnen.

Erfahrung mit Interior, Home & Living oder Lifestyle ist ein Plus.

## Benefits

- 100% Remote, du arbeitest, wo du willst.

- Flexible Arbeitszeiten, die sich deinem Leben anpassen. Wir bewerten dich nach Leistung, nicht nach Anwesenheit.

- Vertrauen statt Konzern-Bürokratie: brauchst du mal spontan einen freien Tag, reicht eine kurze Nachricht.

- 30 Tage Urlaub, am Geburtstag zusätzlich frei.

- Flache Hierarchien.

- Attraktives Gehalt plus Performance-Bonus

- Netzwerk: meluya ist eng mit den führenden D2C-Brands Deutschlands vernetzt und tauscht sich täglich mit anderen E-Commerce-Brands im 8- bis 9-stelligen Bereich aus.

- Lerneffekt: echte D2C-Skalierung von innen, ein 7-stelliges Unternehmen auf dem Weg zum 8-stelligen.

**Was dich bei uns erwartet**

Du findest passende Influencer, verhandelst Konditionen und buchst Kooperationen eigenständig. Vom ersten Kontakt bis zur Auswertung liegt die Zusammenarbeit in deiner Hand. Dabei siehst du direkt, was deine Arbeit bewirkt, und profitierst durch eine zusätzliche Erfolgsprovision vom Erfolg deiner Kooperationen.

**Klingt nach dir?**

Dann schick uns deinen Lebenslauf und ein paar kurze Zeilen: Welche Erfahrungen bringst du mit? Welche Kooperationen hast du schon begleitet und was war dabei deine Aufgabe?

Sag uns auch, ab wann du starten könntest, wie viele Stunden du arbeiten möchtest und welche Vergütung du dir vorstellst.

Wir freuen uns, von dir zu hören!

Beste Grüße

Marc

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
