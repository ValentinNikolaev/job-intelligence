# Account Executive, Public Sector

Posted: 2026-09-11T20:55:09Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**Overview**

As an Account Executive for the Public Sector in the DACH region, you will play a pivotal role in building and shaping our public sector business from the ground up. You will be responsible for developing and closing new business opportunities with public accounts across Germany, focusing on subverticals such as Healthcare, NGOs, Energy, Education, State Government and more.

Read more about what our Hiring Manager has to share about the Public Sector here: [We're Hiring: Public Sector Account Executive in DACH | AvePoint](https://www.avepoint.com/blog/careers/hiring-public-sector-account-executive-dach)

**Your responsibilities will include:**

- Developing new prospects and expanding existing accounts in the Public Sector

- Managing sales cycles with a consultative sales approach

- Planning and delivering presentations that give prospective and existing customers insights into how our solutions solve their challenges

- Communicating new product developments to prospective and existing clients

- Working with strategic AvePoint partners to grow your pipeline and ensure successful collaboration

- Attending remote and on-site meetings with clients as well as fairs and partner events

- Collaborating closely with pre-sales engineers, strategic partners, and cross-functional teams to close deals

- Working with the Business Development Representative

- Handling opportunities prospected by our Account Specialist team

- Implementing and executing effective sales campaigns to ensure maximum penetration of key accounts within your territory

- Maintaining an accurate and current pipeline of opportunities within the CRM system

**OK, I'm interested... is this the job for me?**

We are seeking individuals who value agility, passion, and teamwork; those who can bring fresh ideas to the table and are eager to learn, grow, and advance their careers. Bring your aptitude and build upon what you do best for our customers, partners, team, and you.

You are tasked with bringing in new business. This means you are a creative thinker who is confident and self-motivated with an entrepreneurial mindset. You take pride in seeing your hard work pay off when you see the final results.

**Other qualities you’ll need to be a fit for this role include:**

- Bachelor’s degree or relevant vocational training

- A minimum of 3-5 years of previous sales experience

- Experience in the software/technology industry

- Sales experience in the German public sector is a plus

- Experience with executive selling, both business and technical

- Excellent communication and listening skills

- Self-motivated, entrepreneurial mindset with a high level of initiative and determination

- Determination to surpass performance goals

- Willingness to learn

- Ability to work individually and within a highly collaborative team environment

- Ability to think on your feet

- Fluent in German and English

**Benefits we offer:**

- Competitive market-based compensation 

- Work-life balance through a hybrid working model

- Comprehensive onboarding in Munich with experienced professionals to ensure a smooth start in the role

- Career progression and internal mobility opportunities

- EUR 1.000,00/Year towards our Tuition Reimbursement Program 

- Employee Referral Program 

- Corporate Donation Matching Program

- Company sponsored events / regular team building events  

- 30 PTO/Year, plus all public holidays and access to AvePoint holidays!

- ... and much more!

AvePoint is proud to employ talent from many different backgrounds, experiences, and identities. We believe that diversity and inclusion drives our success and is at the core of how we hire, communicate, and collaborate to deliver value and excellence. We are committed to fostering an environment where people can bring their whole selves to work and feel a sense of belonging, and we continue to work toward creating a workforce that represents the diversity of our customers and communities.

#LI-SW1
#LI-HYBRID

Any personal data you share with us during the application process will be processed strictly in compliance with applicable data protection laws and our [Privacy Notice](https://www.avepoint.com/company/privacy-notice).

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
