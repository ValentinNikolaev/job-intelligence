# Creator Acquisition Manager

Posted: 2026-09-11T20:40:07Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

## About Passionfroot

Creator-led growth is one of the fastest-growing channels in B2B. We build the infrastructure behind it.

[Passionfroot](https://www.passionfroot.me/) is the leading platform where modern companies scale creator-led growth, and where top creators manage and monetize brand partnerships.

Our customers are some of the most ambitious, fastest-moving companies in the world: Replit, Figma, Framer, LumaAI, Gamma, Airtable. We help them run high-impact creator programs across LinkedIn, YouTube, newsletters, and more.

We're growing 13x in revenue year over year, profitable, and just closed our Series A round. We are backed by Insight Partners, Creandum, Supernode, and founders and operators from Cursor, Anthropic, n8n and more. We're expanding fast across New York, Europe, and Brazil.

## About the role

**Why this role exists right now**

Every campaign we run needs the right creators on the platform first. Today we onboard hundreds of creators a month, and brand demand is growing faster than that. Our Creator Growth Lead is building the system to close that gap. You are the person who runs it every day: finding creators, checking they fit, and getting them live.

**High-level description**

-

Scope: find, vet, and onboard creators worldwide across all platforms (LinkedIn, YouTube, newsletters etc). Answer sourcing requests from campaign managers with a shortlist the same day.

-

Ownership: you own the volume and the quality of new creator supply. If a campaign is short on creators, you are the first call.

-

How this fits into the team: you report to the Creator Growth Lead.

-

Who you work closely with: the Creator Growth Lead, campaign managers who send you requests, and our GTM operations team who help you with tooling and data.

## If you join, you will

-

Own the daily sourcing pipeline: build lists in Clay and Apollo, run outreach, and track every creator in Attio

-

Vet creators against a brief: audience fit, content quality, and whether they can deliver for a B2B brand

-

Run onboarding calls with the largest creators and get them from "signed up" to "ready for a campaign"

-

Answer same-day sourcing requests from campaign managers with a shortlist that fits the brief

-

Build and improve the automations that speed this up, using n8n and Claude, so more of your week goes to judgment and less to manual work

-

Report on supply: how many creators came in, how many activated, and where the gaps are

## We need your help with

-

Volume and quality at the same time. We need hundreds of new creators a month, and a bad-fit creator on a live campaign costs more than a missed target.

-

Sourcing across regions and languages. What works on LinkedIn in the US does not work on YouTube in Brazil.

-

Hitting a same-day turnaround on requests while the longer-term pipeline keeps moving.

-

Working without a finished playbook. The Creator Growth Lead is building the system in parallel. You will help shape it and tell us what breaks.

## We'll be most excited if you

-

Have done outbound before, as a BDR, SDR, or in a growth or acquisition role, and know what a good day of prospecting looks like

-

Are close to the creator world: you worked at a talent agency, ran a creator program or built an audience yourself and can spot a strong B2B creator fast

-

Are comfortable in tools like Clay, Apollo, Attio, or an equivalent, and are curious about AI tools like Claude and n8n to automate the boring parts

-

Are good on a call. Onboarding creators means selling them on Passionfroot and setting clear expectations in 15 minutes

-

Hold a bar on quality even when the volume target is close

## Working with us

**Location and setup**

Berlin or São Paulo. Hybrid setup, with approximately three days per week in the office.

**How we work**

-

Pace: an idea on Monday, a live test by Thursday. We move fast and fix as we go.

-

Ownership model: you own your numbers and your pipeline. Nobody will check your outreach one message at a time.

-

Collaboration style: weekly priorities with the Creator Growth Lead, direct contact with campaign managers, no layers.

**Compensation and benefits**

-

Salary range: $40K–$60K, depending on location and profile

-

Equity: To be reviz

-

Benefits: 21 days paid vacation plus local public holidays

-

Extras: latest Apple hardware, regular team off-sites (Mallorca, Barcelona, South of France, Berlin)

This is a role where the results are visible every week: creators you found are on live campaigns for companies like Replit and Figma. If you have done outbound and care about creators, but your CV does not match every line above, apply anyway. We welcome applications from people of all backgrounds and are committed to a fair and inclusive hiring process.

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
