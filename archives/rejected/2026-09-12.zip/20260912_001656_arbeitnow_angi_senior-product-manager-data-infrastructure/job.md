# Senior Product Manager, Data Infrastructure

Posted: 2026-09-11T17:40:10Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

For over 30 years, Angi has powered the future of the home services industry, creating an environment where homeowners and pros benefit from more jobs done well.

For homeowners, our platform is a reliable way to find skilled pros. For pros, we're a reliable business partner who helps them find the winnable work they want, when they want. For employees, we're an amazing place to call home. We can't wait to welcome you.

**Angi at a glance:**

-

Founded in 1995 as Angie’s List and rebranded in 2021

-

Global company with 9 brands in 8 countries and employees worldwide

-

Homeowners have turned to us for 300 million home projects and counting

**About the Team**

Data Infrastructure builds the platform that every other data team stands on: access to shared data, orchestration, data ingestion, and the retirement of systems the company has outgrown. Every layer of this platform exists to make it easier for a homeowner to hire an Angi Pro, on one certified source of truth that people and AI agents can trust equally.

The team's strategy is built around one idea: this platform should feel like a self-service product, not a ticket queue, for the engineers and analysts who depend on it, and increasingly for the AI agents who depend on it too. Angi is moving toward AI agents as a normal way of building and operating, and every agent that touches company data comes through this platform first.

This role stewards that platform's product direction.

**What You'll Do**

**Product Management**

-

Manage governed platform access - give engineers, analysts, and services safe, auditable access to shared data, and make the safe path the easy path.

-

Streamline orchestration and scheduling - bring fragmented scheduling tools together into one system every team reaches for by default, and use AI-assisted tooling to migrate jobs faster, with less manual engineering effort.

-

Drive data ingestion and replication - define what self-service ingestion looks like for teams who want to bring their own data onto the platform, and build toward that.

-

Oversee legacy system retirement - close out systems that are no longer the source of truth, with clear ownership handed off at every step.

-

Optimize compute cost efficiency - find where cost comes from habit rather than real need, and bring it down without anyone losing the developer experience they rely on.

-

Advance compute strategy diversification - help move the platform toward a storage layer that works with more than one compute engine, so each workload runs on the engine built for it.

-

Build the platform's AI-ready substrate - make agentic workflows safe by default, with the same governed access and audit trail for an agent as for a person.

**Execution and Individual Contribution**

-

Use AI agents in your own daily work, set clear norms so the engineers and peers around you feel safe experimenting with agents and agentic workflows.

-

Protect the team's focus and drive real rigor without micromanaging how the work gets done. Steward outcomes, not tasks.

-

Build trust across engineering, domain teams, and leadership through empathetic, transparent, and clear communication when addressing complex challenges.

-

Work closely with Data Engineering's other delivery teams - Data Mesh Enablement and Managed Data Products - and with the team building Angi's agentic workflows, toward one overall technical strategy.

**Who You Are**

-

Five or more years of product management experience on a data or infrastructure platform team, where you stewarded technical roadmaps directly.

-

Comfortable reading system architecture and pipeline dependencies well enough to make real sequencing calls with engineering.

-

A record of taking cross-team migrations and retirements all the way to done, not just to a plan.

-

Transparent about areas of growth and open to learning, rather than presenting incomplete information as fully resolved under pressure.

**Preferred Qualifications**

-

Experience weighing compute cost against performance and developer experience, and driving that tradeoff to a decision rather than just planning around it.

-

Working knowledge of how AI agents consume data and tools differently from people, and judgment on when a vendor's own agent layer already covers a need.

-

A proactive approach to navigating and understanding new technical systems, key contacts, and open questions independently.

**Compensation & Benefits**

-

The salary band for this position ranges from €90,000 - 120,000, commensurate with experience and qualifications.

-

Hybrid work environment and home office set-up allowance.

-

Temporary work from abroad policy.

-

Regular team and social events.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
