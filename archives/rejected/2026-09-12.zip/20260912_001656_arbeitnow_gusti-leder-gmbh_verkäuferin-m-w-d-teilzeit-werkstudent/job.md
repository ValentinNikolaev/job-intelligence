# Verkäuferin (m/w/d) - Teilzeit/Werkstudent

Posted: 2026-09-11T20:30:26Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**Willkommen bei Gusti Leder Stores GmbH 🌿**

Wir sind ein wachsendes Unternehmen mit einer klaren Mission: hochwertige, verantwortungsvoll produzierte Ledertaschen und -accessoires in die Welt zu bringen. Transparenz, Qualität und echte Handwerksliebe stehen bei uns im Mittelpunkt.

Für unseren **Store in Potsdam **suchen wir ab sofort eine motivierte **Verkäuferin in Teilzeit (20 / 25 / 30 h) **oder als **Werkstudent (15-20h).**

Du hast Freude am Kontakt mit Menschen, ein Gespür für Stil und möchtest unseren Kund:innen ein herzliches Einkaufserlebnis bieten? Dann passt du zu uns.

**Deine Vorteile bei Gusti**

💰 **Attraktive Vergütung
**Ein fairer Stundenlohn (bis zu 17 €)– abhängig von Deiner Berufserfahrung – inklusive bezahlter Überstunden.

🎯 **Prämiensystem mit Mehrwert
**Gesundheitsprämie, Umsatzbeteiligung und weitere Anreize in Form von Bonuszahlungen – Dein Einsatz zahlt sich aus.

🛍️ **Starke Benefits
**Flexible Arbeitszeiten, Verkaufstraining und bis zu 20 % Mitarbeiterrabatt.

🤝 **Offene Teamkultur
**Flache Hierarchien, direkte Kommunikation und regelmäßige Teamevents sorgen für ein wertschätzendes Miteinander.

🚂 **Gute Anbindung**

Unsere Stores liegen alle in unmittelbarer Nähe eines Bahnhofs und können bestens mit den öffentlichen Verkehrsmittel erreicht werden.

**Deine Aufgaben im Verkauf**

-

Du berätst unsere Kund:innen persönlich und findest gemeinsam mit ihnen das passende Produkt.

-

Du erzählst die Geschichten hinter unseren Produkten und vermittelst die Werte von Gusti Leder.

-

Du führst Verkaufsgespräche und bedienst das Kassensystem.

-

Du präsentierst unsere Taschen und Accessoires ansprechend und kreativ.

-

Du füllst Waren nach und sorgst für einen gepflegten und einladenden Store.

-

Du unterstützt bei verkaufsfördernden Aktionen und den täglichen Abläufen im Geschäft.

-

Du arbeitest eng mit der Filialleitung und deinem Store-Team zusammen.

**Das bringst du mit**

-

Du hast Freude am Verkauf und am persönlichen Kontakt mit Kund:innen.

-

Du gehst offen und empathisch auf Menschen zu und kannst gut zuhören.

-

Du begeisterst dich für individuelle Beratung und authentisches Storytelling.

-

Du hast ein Auge für Ästhetik, Warenpräsentation und Details.

-

Du arbeitest zuverlässig, organisiert und gerne im Team.

-

Du bist offen für digitale Kassensysteme, Warenwirtschaftssysteme und digitale Tools.

-

Du verfügst über gute Deutschkenntnisse; Englischkenntnisse sind wünschenswert.

Eine Ausbildung oder Berufserfahrung im Einzelhandel ist hilfreich, aber keine Voraussetzung. Auch als Quereinsteiger aus der Gastronomie, Hotellerie, Dienstleistung oder einer anderen kundenorientierten Branche bist du bei uns willkommen.

Du musst nicht jeden Punkt zu 100 % erfüllen. Wenn du Freude am Verkauf hast, gerne mit Menschen arbeitest und Lust auf Lederwaren und Accessoires mitbringst, möchten wir dich kennenlernen. 🧡

Bewirb dich jetzt als **Verkäuferin (m/w/d) in Teilzeit / Werkstudent **und werde Teil von Gusti Leder.

Wir freuen uns darauf, Dich kennenzulernen!

Bewerbungen von Menschen mit Schwerbehinderung und ihnen gleichgestellten Personen sind bei uns ausdrücklich willkommen.

Weitere Informationen zur Datenverarbeitung im Bewerbungsverfahren findest Du hier:[ https://gusti-leder.de/policies/privacy-policy](https://gusti-leder.de/policies/privacy-policy)

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
