# Founding Customer Success Manager (German-speaking)

Posted: 2026-09-11T20:40:11Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

## About BoWatt

BoWatt is building agentic requirements and systems engineering software for manufacturing.

We believe AI will reach PhD-level engineering capability within the next 10 years. This will unlock massive value across complex manufacturing industries. Cars. Planes. Rockets. Factories. Chips. Medical devices. All will be engineered with agents.

We bootstrapped BoWatt to €500k+ ARR before raising our first round. BoWatt is backed by tier-1 investors, including Atlantic Foodlabs, Buildery (CDTM affiliates), and Prequel Ventures, along with angels from Cohere and Luminovo.

You’ll join a small team of startup builders focused on speed, ownership, and execution. Over half the team are former founders, with backgrounds across DeepTech AI, gaming, and other startups. We’ve studied and worked at institutions and companies including Stanford, TUM, Google, EA, and YC-backed AI startups.

## The role

This role offers a clear path towards leading Customer Success as BoWatt grows.

As our Founding Customer Success Manager, you will own everything that happens after the initial sale: turning new customers into successful, deeply engaged, long-term partners.

You will be our first dedicated Customer Success hire. Initially, you will work hands-on with customers while building the playbooks, processes, and team that will eventually allow Customer Success to scale.

This is not a reactive support role. You will become a trusted partner to customers, help them embed BoWatt into real engineering workflows, and take responsibility for adoption, retention, and expansion.

-

Own the customer relationship after the initial sale, from onboarding through adoption, renewal, and long-term partnership

-

Design and run onboarding and implementation plans for large Mittelstand companies and Tier-1 enterprises

-

Build strong relationships with users, internal champions, and senior decision-makers

-

Establish clear success plans and help customers achieve measurable value from BoWatt

-

Drive adoption across customer teams and embed BoWatt into day-to-day engineering processes

-

Monitor account health, identify risks early, and take practical action to resolve blockers

-

Own customer-facing communication during software incidents and coordinate resolutions with Product and Engineering

-

Identify and develop opportunities to expand BoWatt across additional teams, use cases, and business units

-

Over time, take commercial ownership of renewals and customer expansion

-

Bring structured customer feedback and recurring problems into the Product team

-

Build BoWatt’s Customer Success playbook, including onboarding, success planning, account reviews, health metrics, renewals, and expansion

-

Develop deep expertise in BoWatt’s software, customers, and target industries

During your first six months, you will work closely with our CEO and Product team to develop the product, industry, and customer knowledge needed to take ownership of increasingly complex customers.

## You

-

You genuinely enjoy working with customers and building strong, long-term relationships

-

You care about whether customers achieve meaningful outcomes—not simply whether meetings happen

-

You communicate confidently and can build trust with technical users, internal champions, and senior executives

-

You are highly structured and take ownership of driving customer initiatives to completion

-

You are proactive and identify risks and opportunities before customers raise them

-

You combine customer empathy with commercial judgment

-

You are comfortable discussing technical products, bugs, integrations, priorities, and trade-offs

-

You are ambitious, resourceful, and willing to go the extra mile to make customers successful

-

You want to build a function rather than inherit an established playbook

-

You want to grow into a domain expert across our software, customers, and industry

## Requirements

-

At least two years of experience in Customer Success, Implementation, Account Management, Solutions Consulting, or a similar customer-facing B2B software role

-

Alternatively, relevant experience in a technical customer-facing role at an industrial manufacturer, engineering company, or technology business

-

Experience onboarding customers and driving ongoing product adoption

-

Experience managing multiple stakeholders and customer initiatives in parallel

-

The ability to understand technical products and communicate effectively with technical and business stakeholders

-

Strong project management and organisational skills

-

Fluent German required; English is our internal working language

-

Four days per week in our Munich office at Balanstraße

-

Experience with enterprise software, manufacturing, engineering, commercial account ownership, or early-stage startups is a bonus

## What we offer

-

Competitive salary based on experience

-

Participation in BoWatt’s Founders Pool

-

A clear path towards leading Customer Success as BoWatt grows

-

Significant ownership from day one

-

Direct exposure to customers, Product, Engineering, and the founders

-

The opportunity to build BoWatt’s Customer Success function from the ground up

-

25 vacation days per year, plus public holidays

-

Company retreats

-

WellPass membership

## The Founders Pool

BoWatt’s Founders Pool is a dedicated virtual-equity pool for a small group of early team members who take responsibility for building and leading a major part of the company.

We created it because we want the people building BoWatt alongside us to participate meaningfully in the value they help create. These are not narrow execution roles with finished playbooks. You will own your vertical with co-founder-like autonomy and accountability: setting the standard, building the function, and being responsible for its results.

As our founding Customer Success hire, you will participate in the Founders Pool (5-10%) and have the opportunity to build Customer Success from the ground up. The precise allocation, vesting structure, and plan terms will be discussed transparently during the interview process.

## Interview process

-

20-minute screening call

-

90-minute Customer Success case interview (CEO and team member)

-

60-minute culture interview (CEO)

-

Reference checks & Offer

We aim to complete the entire interview process within 14 days.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
