# Investment Intern - Growth Stage

Posted: 2026-09-11T17:40:07Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

HV backs bold founders from the first check to IPO.

With €2.8 billion in assets under management and a track record spanning nine fund generations, HV has invested in more than 290 companies across Europe, from consumer and software to deep tech and AI.

Through dedicated Venture and Growth funds, HV backs founders at every stage of their journey, from first cheque to global scale. This approach makes HV one of Europe's leading multistage investors and a long-term partner to bold founders who are building the future.

Our Growth Fund invests up to €60M in Series B and beyond, with follow-on capital of up to €100M, partnering with companies as they scale into global category leaders.

## About the Internship

Join the Growth Investment Team in Berlin in the first half of 2027.

## What you will do:

-

**Deal Analysis & Due Diligence:** Assess investment opportunities through market and competitive research, product deep-dives, customer insights, KPI analysis and financial modelling.

-

**Investment Process:** Support deals from initial screening through investment decision, including investment memos, expert calls, cap tables and participation in IC discussions.

-

**Market Views:** Develop your own perspective in one or two sectors and turn your insights into actionable investment theses.

-

**Portfolio Support:** Stay close to our portfolio companies, track KPIs, and help where needed.

## What we’re looking for:

-

Excellent academic background

-

Relevant experience from an internship in VC, banking, consulting, a fast-growing startup, or your own entrepreneurial experience

-

Able to roll up your sleeves and a resourceful, pragmatic approach to problem-solving

-

Confidence to interact with experienced founders and colleagues, plus ownership of topics end-to-end

-

AI native

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
