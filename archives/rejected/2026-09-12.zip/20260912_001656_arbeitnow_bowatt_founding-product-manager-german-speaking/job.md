# Founding Product Manager (German-speaking)

Posted: 2026-09-11T20:40:11Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

## About BoWatt

BoWatt is building agentic requirements and systems engineering software for manufacturing.

We believe AI will reach PhD-level engineering capability within the next 10 years. This will unlock massive value across complex manufacturing industries. Cars. Planes. Rockets. Factories. Chips. Medical devices. All will be engineered with agents.

We bootstrapped BoWatt to €500k+ ARR before raising our first round. BoWatt is backed by tier-1 investors, including Atlantic Foodlabs, Buildery (CDTM affiliates), and Prequel Ventures, along with angels from Cohere and Luminovo.

You’ll join a small team of startup builders focused on speed, ownership, and execution. Over half the team are former founders, with backgrounds across DeepTech AI, gaming, and other startups. We’ve studied and worked at institutions and companies including Stanford, TUM, Google, EA, and YC-backed AI startups.

## The role

As our Founding Product Manager, you will help determine what BoWatt builds, why we build it, and whether it creates meaningful value for customers.

You will work closely across our commercial, customer success and engineering teams, as well as with our customers. You will develop a deep understanding of complex engineering workflows, turn customer problems into clear product opportunities, and drive initiatives from discovery through launch and iteration.

This is a hands-on product role. You will spend time with customers, work through technical and operational detail, write requirements, make trade-offs, test solutions, and help the team ship quickly.

-

Lead product discovery - translate complex workflows and customer needs into clear product requirements and success criteria

-

Develop a deep understanding of how manufacturing and systems-engineering teams work

-

Identify and define the highest-value customer problems for BoWatt to solve

-

Help own and prioritise the product roadmap

-

Balance strategic opportunities, recurring customer needs, commercial importance, and engineering effort

-

Drive product initiatives from initial discovery through scoping, development, launch, and iteration

-

Give engineers the context and clarity needed to make strong implementation decisions

-

Prototype and test potential solutions with customers before and during development

-

Work with Customer Success to turn individual customer feedback into scalable product improvements

-

Use qualitative feedback and product data to understand adoption and evaluate whether features are working

-

Triage product issues and bugs, make clear prioritisation decisions, and coordinate with Engineering

-

Improve BoWatt’s processes for discovery, prioritisation, product delivery, launches, and feedback

-

Develop deep expertise in BoWatt’s product, customers, and target industries

During your first six months, you will work closely with our engineering team to build the domain and product knowledge required to take ownership of increasingly important product areas.

## You

-

You are deeply curious about customers and want to understand how their work actually happens

-

You enjoy turning complex, ambiguous problems into clear product decisions

-

You combine strategic thinking with hands-on execution

-

You can distinguish between an individual customer request and a scalable product opportunity

-

You make thoughtful trade-offs and are comfortable deciding with incomplete information

-

You write clearly, communicate confidently, and know how to get to the point

-

You are comfortable working closely with software engineers and discussing technical constraints

-

You move quickly without losing sight of product quality or customer outcomes

-

You take ownership of results rather than simply managing tickets and meetings

-

You want to build a product function rather than inherit an established playbook

-

You are ambitious, resourceful, and excited to become an expert in a complex industry

## Requirements

-

At least two years of experience in Product Management, Product Ownership, Product Operations, or a comparable product-building role

-

Experience shipping B2B software in close collaboration with engineers

-

Experience conducting product discovery and translating customer problems into clear requirements

-

Strong prioritisation, project management, and stakeholder-management skills

-

The ability to understand technical products and communicate with engineers, technical users, and business stakeholders

-

Fluent German required; English is our internal working language

-

Four days per week in our Munich office at Balanstraße

-

Experience with enterprise software, AI products, manufacturing, engineering, systems engineering, or early-stage startups is a bonus

## What we offer

-

Competitive salary based on experience

-

Participation in BoWatt’s Founders Pool (5-10%)

-

Significant ownership over an important part of BoWatt’s product

-

The opportunity to help build BoWatt’s product function and ways of working

-

25 vacation days per year, plus public holidays

-

Company retreats

-

WellPass membership

## The Founders Pool

BoWatt’s Founders Pool is a dedicated virtual-equity pool for a small group of early team members who take responsibility for building and leading a major part of the company.

We created it because we want the people building BoWatt alongside us to participate meaningfully in the value they help create. These are not narrow execution roles with finished playbooks. You will own your vertical with co-founder-like autonomy and accountability: setting the standard, making difficult trade-offs, and being responsible for the results.

As our Founding Product Manager, you will participate in the Founders Pool (5-10%) and take meaningful ownership of how BoWatt’s product develops. The precise allocation, vesting structure, and plan terms will be discussed transparently during the interview process.

## Interview process

-

20-minute screening call

-

90-minute live product case (CEO and team member)

-

60-minute culture interview (CEO)

-

Reference checks & Offer

We aim to complete the entire interview process within 14 days.

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
