# UX/UI Designer | Intch

Posted: 2026-09-11T20:40:03Z

## Rejection

- Category: tech_stack
- Reason: role does not mention Go/Golang or PHP

## About Intch

Intch is a professional social network with a marketplace for part time work. You can think of it as a professional network built for senior specialists who take on meaningful contracts alongside their main work. A typical contract lasts from three to six months.

The product is used in 140 countries and is available in up to 20 languages. Intch has fewer than 40 people and four product areas, with three already live and one preparing to launch.

Intch is rethinking how people and companies find each other and build trust online. Changes that made the interface feel more like a real conversation have already improved key metrics by up to three times.

## About the role

Today one part time designer supports all Intch products. Since the company moved to a product based structure, that is no longer enough. Intch is now looking for its first full time designer.

Product managers build and test early prototypes themselves. Around one in ten experiments moves forward. Your role is to join the thinking early, work through the problem with the product team and turn validated ideas into clear, production ready experiences.

This is a hands on role with broad ownership. You will work across all Intch products and collaborate closely with product managers, engineers and the current designer.

## What you will work on

-

Join product discussions early and help shape the problem before screens are made.

-

Take a task from an open question to a production ready design.

-

Design flows where the interface supports communication between people and businesses.

-

Work on onboarding, profiles, discovery, paywalls and other core product areas.

-

Cover key states, edge cases and handoff details, then stay involved during implementation.

-

Extend the existing UI kit and keep patterns consistent across products.

-

Increase the share of design work that can move into production without another rework round.

## What matters for this role

-

Strong UI craft and a portfolio of clear, thoughtful interfaces.

-

Solid web product experience. Web is the primary platform at Intch.

-

The ability to explain your decisions through user context, not personal taste.

-

Openness to evidence and the confidence to change your mind when a better argument appears.

-

Experience owning design from an unclear problem through to launch.

-

Comfort working with autonomy in a small product company.

-

Experience in a startup, as a founding designer or in an in-house product role, would be useful.

-

A practical approach to AI tools. The current workflow includes Figma handoff and clickable prototypes in Claude. Production code is not expected.

-

English at B1, fluent Russian.

## What you get

-

Remote, open geography. Time zone overlap with ~CET is what matters.

-

Flexible schedule. Paid vacation, sick leave, and days off.

-

A flat team under 40 where you can bring a worked-out idea into any product — and get paid for it if it performs.

-

A design problem the market hasn't solved yet, in a product used across 140 countries.

-

Real autonomy from day one. You'll sit in product discussions, not receive tickets.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
