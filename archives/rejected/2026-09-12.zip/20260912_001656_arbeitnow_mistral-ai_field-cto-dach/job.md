# Field CTO, DACH

Posted: 2026-09-11T17:40:04Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

## **About Mistral**

Mistral provides full-stack AI solutions: from frontier models to developer tools, applications, and compute. We partner with enterprises tackling the hardest problems—across high-stakes industries like finance, manufacturing, defense, healthcare, and the public sector—co-creating customized AI systems that they can run on their terms.

We are a dynamic, collaborative team passionate about AI and its potential to transform society. Our diverse workforce thrives in competitive environments and is committed to driving innovation. Our teams are distributed between Europe, North America, Asia and the Middle East. We are creative, low-ego and team-spirited.

## The role

The Field CTO role is one of Mistral's senior external technical voices; a role for someone who has earned genuine credibility in the AI field and can engage enterprise boards, CIOs, and CTOs as a peer. You will shape how strategic accounts think about their AI strategy, represent Mistral at major industry events, and publish thought leadership that reflects a real point of view on where AI is going.

You will work closely with regional sales leadership across your territory and bring what you learn from executive conversations back into Mistral's product direction. This is an externally-facing, influence-driven role. The output is measured in relationships built, content published, and executive conversations that move.

## What You Will Do

**Executive engagement**

Run Mistral's Executive Briefing Center with your regional VP; a selective program for C-level stakeholders at strategic accounts. Build and sustain trusted-advisor relationships with CIOs, CTOs, CDOs, and VP Engineering across your territory.

**Thought leadership**

Publish regularly: articles, whitepapers, and analysis of where enterprise AI is heading. Brief Gartner and Forrester on Mistral's roadmap and market position. Track frontier research and bring it into customer conversations.

**Conference and event presence**

Represent Mistral at major industry events through keynotes, panels, and roundtables. Build a public presence that generates inbound interest from enterprise executives and the wider AI community.

**Market feedback**

Bring what you hear in executive conversations back into product direction. Patterns across accounts on governance requirements and deployment constraints should reach the people building the models.

## What We're Looking For

-

Demonstrable credibility in the AI field. A public track record in AI: published papers, articles, or talks that reflect a clear, defensible position. Your work should read as credible next to Mistral's technical brand.

-

A stated position on open-weight models and what they change for the enterprises adopting them. Your existing public positions should sit comfortable next to Mistral's.

-

You are fluent in European data sovereignty and on-premise deployment, at the level that holds up with a CTO or VP Engineering asking hard questions.

-

You are comfortable engaging C-level stakeholders across multiple verticals on technical architecture and business strategy, in the same conversation.

-

Cross-vertical fluency, you can credibly engage across financial services, manufacturing, defense, and energy without being a domain specialist in any one of them.

-

10–25 years of experience in enterprise technology. You have held roles such as: Field CTO, Principal Architect, or VP Engineering at a major cloud or AI company, or a founder who built technical credibility and executive relationships through their own company.

-

Comfortable with 30-50% travel depending on your region.

## Nice to have

-

Existing network of CTO and CIO relationships at enterprise accounts in your region

-

Prior Field CTO or equivalent externally facing technical role at a major cloud or AI company

-

Fluent in multiple languages spoken across your region

## **What We Offer**

We offer a comprehensive benefits package designed to support your well-being, growth, and work-life balance. Benefits vary by country and may include healthcare coverage, parental leave, retirement plans, relocation support, wellness programs, meal and transportation allowances, and other location-specific perks.

For the most up-to-date details on benefits available in your location, please refer to our [Benefits page](https://app.notion.com/p/mistralai/Benefits-at-Mistral-36e6ba59a7fe836b93dd01737fcc27ef?source=copy_link).

## **Privacy Policy**

Your privacy matters to us. You can learn more about how we handle your personal data in our [Applicant Privacy Policy](https://legal.mistral.ai/terms/applicant-privacy-policy).

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
