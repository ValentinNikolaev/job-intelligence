# Werkstudent (m/w/d) Social Media Marketing / PR

Posted: 2026-09-11T20:30:26Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

### 👜 Gestalte die Zukunft der Lederindustrie mit uns bei Gusti Leder!🌿

Tauche ein in die Welt von Gusti Leder, wo jede Tasche eine Geschichte erzählt. Wir stehen für Nachhaltigkeit, Stil und Slow Fashion. Bei uns kaufst du nicht einfach nur ein Accessoire – du setzt ein Statement für Transparenz und Qualität.

Wir bieten dir nicht nur einen Job, sondern die Chance, Teil einer Bewegung zu sein, die die Lederindustrie nachhaltig zum Besseren verändert.

#### 🎯 Deine Mission bei uns:

-

**Markenstimme:** Du unterstützt das Team aktiv bei der Entwicklung und Umsetzung unserer Kommunikationsstrategien.

-

**Netzwerkaufbau:** Du pflegst unsere Presseverteiler, unterstützt bei der Ansprache von Journalist:innen sowie Influencer:innen und baust unser Netzwerk weiter aus.

-

**PR-Management:** Du hilfst bei der Planung und Durchführung von PR-Kampagnen, übernimmst Aufgaben im Tagesgeschäft und behältst relevante Kennzahlen im Blick.

-

**Content-Planung:** Du entwickelst und organisierst den Content für unsere Social Media Kanäle, um unsere Zielgruppe bestmöglich zu erreichen und zu begeistern.

-

**Posten und Community-Management:** Du kümmerst Dich um die Veröffentlichung der Beiträge und das Management der Interaktionen auf unseren Social Media Kanälen.

#### 💼 Das bringst du mit:

-

**Basiswissen:** Erste Erfahrung in der PR-Arbeit, mit Content-Management-Systemen und Social Media sind wünschenswert, aber kein Muss.

-

**Mindset:** Du arbeitest eigenverantwortlich, denkst strukturiert mit und brennst darauf, neue Ideen zu entwickeln.

-

**Arbeitsweise:** Dich zeichnet eine eigenständige, kreative und teamorientierte Arbeitsweise aus.

-

**Sprachkenntnisse:** Du besitzt eine sehr gute Ausdrucksfähigkeit in Deutsch und Englisch (in Wort und Schrift).

-

**Content-Knowledge**: Kreativität und ein gutes Gespür für Trends.

-

**Online-Kanäle**: Affinität zu digitaler Kommunikation und Social Media Plattformen.

#### 🎁 Das erwartet dich bei Gusti Leder:

-

**Faire Vergütung **-** **Ein attraktiver Stundenlohn von 15 - 17 € inklusive Überstundenvergütung.

-

**Außergewöhnliche Benefits** -** **Attraktive Mitarbeiterrabatte, Prämiensysteme und weitere Corporate Benefits.

-

**Nachhaltigkeit first **-** **Wir leben Slow Fashion und gestalten die Lederindustrie verantwortungsvoll und transparent.

-

**Gestaltungsfreiheit **-** **Deine Ideen zählen – du kannst aktiv mitprägen, wie wir arbeiten und als Unternehmen wahrgenommen werden.

-

**Praxisnahes Lernen** -** **Du erhältst echte Einblicke in Retail- und Storemanagement und kannst dein wirtschaftliches Wissen direkt anwenden.

-

**Teamkultur **-** **Flache Hierarchien, offene Kommunikation und regelmäßige Teamevents sorgen für ein starkes Miteinander.

-

**Flexible Arbeitszeiten **-** **Ideal mit deinem Studium vereinbar.

-

**Work-Life-Balance **-** **Flexible Arbeitszeiten CrossFit- und Yoga-Sessions unterstützen dein Wohlbefinden.

-

**Gute Anbindung **-** **Unser Standort befindet sich in unmittelbarer Nähe zum Rostocker Hauptbahnhof und ist somit bequem mit der S-Bahn oder Straßenbahn erreichbar.

-

**Energie für den Tag **- Zweimal pro Woche frisches Mittagessen.

-

**Frisches Extra **-** **Täglich frisches Obst, Kaffee, Tee und Wasser stehen dir kostenfrei zur Verfügung.

__________________________________________________________________________________________________________________________________

#### 🚀 Bereit für dein nächstes Abenteuer?

Wir freuen uns auf deine Bewerbung über unser Online-Formular – es dauert **nur 5 Minuten**!

👉 [https://gustileder.recruitee.com/](https://gustileder.recruitee.com/)

Du hast noch Fragen? Deine Ansprechpartnerin **Lea **ist gerne unter für dich da.

___________________________________________________________________________________________________________________________________

#### ✨ Warum Gusti Leder?

Unsere Produkte sind ein Symbol für bewussten Konsum und nachhaltige Eleganz. Wir setzen uns aktiv für die Prinzipien der Slow Fashion ein, indem wir in eine transparente Produktion und langlebige Vintage-Artikel investieren. Durch die enge, vertrauensvolle Zusammenarbeit mit unseren lokalen Produzenten wahren wir höchste Standards an Qualität und ethischer Verantwortung.

*
Weitere Informationen zur Datenverarbeitung im Bewerbungsverfahren findest Du hier: *[https://gusti-leder.de/policies/privacy-policy](https://gusti-leder.de/policies/privacy-policy)

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
