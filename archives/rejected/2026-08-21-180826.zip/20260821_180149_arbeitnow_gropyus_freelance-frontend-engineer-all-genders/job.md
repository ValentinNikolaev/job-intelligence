# Freelance Frontend Engineer (all genders)

Posted: 2026-08-21T14:55:05Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**About The Company**

GROPYUS is a technology-based construction company focused on building multi-story residential buildings. Thanks to its prefabricated building system with various design options, industrial offsite construction, and fully digitalized processes, the company manufactures aspirational, sustainable, and affordable homes using timber construction methods. GROPYUS is using scalable construction and manufacturing solutions to tap into a future market, boost Europe's strength in innovation, while also playing a substantial role in improving sustainability.

## **About the Role:**

As a Frontend Software Engineer Freelancer (f/m/d), you will help shape the user experience of the tools that power GROPYUS' automated planning and production processes. You will work closely with engineers, product managers, and designers to deliver new features for our 3D parametric visualization and configuration platform.

Your primary focus will be evolving frontend experiences using React, integrating interactive 3D visualisation capabilities using Three.js and our internal canvas-based libraries, and creating intuitive workflows that help users interact with complex building data and parametric models. While frontend delivery is at the core of the role, you will also collaborate closely with backend services and occasionally contribute to API development where needed.

You will join a highly collaborative team that combines software engineering, automation, and 3D technology to transform how buildings are designed and manufactured. If you enjoy turning complex technical capabilities into seamless user experiences and are excited by the challenge of interactive 3D applications, this is the team for you.

We believe that curiosity, ownership, and a pragmatic mindset are more important than following a predefined career path. At GROPYUS, we value engineers who are passionate about delivering high-quality products, collaborating across disciplines, and continuously improving how we work.

You will need a self-employed/contractor setup for taxation purposes and you can work remotely from anywhere from EU. Project load is estimated at 30-40 hours weekly and total duration to 6-8 months.

## **What you bring:**

- Strong experience with React and modern TypeScript-based frontend development.

- Experience building complex, interactive web applications with a focus on usability and performance.

- Hands-on experience with Three.js or other 3D web technologies.

- Experience working with HTML5 Canvas, WebGL, or similar visualisation frameworks.

- Ability to translate product and design requirements into robust, user-friendly solutions.

- Experience integrating frontend applications with GRPC APIs and backend services.

- Comfortable working across the stack when needed, including implementing or extending backend endpoints.

- Strong understanding of frontend architecture, state management, component design, and performance optimisation.

- Experience working with design systems and collaborating closely with Product Designers.

- Familiarity with testing, debugging, and maintaining production-grade applications.

- Interest in 3D visualisation, CAD-like applications, digital planning tools, or parametric systems is a strong plus.

- Experience with Kotlin, Azure, or backend development is beneficial but not required.

#### Join us on our mission to design buildings as continuously evolving products to create the most exciting and affordable experience for all. We build for people and conserve the resources of our planet.

We can't wait to get to know you.
For more information, visit our [website](https://gropyus.com/).

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
