# Backend Software Engineer - AI Systems (m/w/d)

Posted: 2026-08-17T13:01:38Z

## Rejection

- Category: tech_stack
- Reason: role does not mention Go/Golang or PHP

**HAIAR®** entwickelt Technologien, um Unternehmen der Automobilbranche datengetrieben zu beschleunigen.

CARvinci® ist die erste wirklich praxisnahe Autohaus-KI, die den Alltag im jeweiligen Betrieb revolutioniert.

**Warum CARvinci®?**

🤝 Gemeinsam mit über 30 Autohäusern entwickelt – von Brancheninsidern für Brancheninsider

⚡️ Erledigt Alltagsaufgaben im Autohaus durchschnittlich 3x schneller

🛡 100% DSGVO-konform und sofort einsatzbereit – ohne Schnittstellen oder komplexe IT-Projekte

🌱 Über 100 KI-Lösungen für Service, Vertrieb, Disposition, Verwaltung, Personal & Marketing

**Deine Rolle**

Du bist technisch mit verantwortlich für das Backend unserer KI-Plattform.

Dein Fokus liegt auf Systemarchitektur, KI-Integration und langfristiger Produktqualität.

## Aufgaben

- Architektur und Weiterentwicklung unseres Python-Backends mit Fokus auf KI-Systeme.

- Konzeption und Umsetzung von **RAG-Architekturen** für produktive Anwendungsfälle.

- Aufbau und Pflege von **KI-Pipelines** (Ingestion, Retrieval, Kontextsteuerung, Inferenz).

- Design und Orchestrierung von **Agent-Workflows** inklusive Zustands- und Fehlerhandling.

- Bewertung von Trade-offs zwischen Qualität, Latenz, Kosten und Skalierbarkeit.

- Sicherstellen von Stabilität, Monitoring und langfristiger Wartbarkeit.

## Qualifikation

**Pflicht**

- Mehrjährige Erfahrung im Backend-Engineering mit **Python**.

- Sehr gutes Verständnis von skalierbaren Backend-Architekturen und APIs.

- Erfahrung mit produktiven Systemen. Nicht nur Prototypen.

- Fähigkeit, technische Entscheidungen zu treffen und zu vertreten.

**Erwünscht**

- Praktische Erfahrung mit **RAG-Systemen**.

- Verständnis von Embeddings, Retrieval-Strategien und Kontextmanagement.

- Erfahrung mit **Agent-Architekturen oder Workflow-Orchestrierung**.

- Gefühl für typische KI-Probleme wie Halluzinationen, Drift, Latenz und Evaluierung.

## Benefits

- Volle Verantwortung für die Implementierung von Features in unserer Software

- Remote Arbeit (wir treffen uns nur gelegentlich in Münster)

- Mac / Windows / Linux – freie Wahl deiner Arbeitsumgebung

- Attraktive Vergütung, fair und marktgerecht

- Work-Life-Balance: 30 Tage Urlaub + frei am Geburtstag 🎉

👉 Wenn du **KI-Systeme bauen willst, die im Alltag funktionieren**

👉 Wenn du Verantwortung für Architektur übernehmen willst

Dann bist Du bei uns genau richtig!

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
