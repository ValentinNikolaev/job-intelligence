# Working Student - Accounting (AP)

Posted: 2026-08-17T14:40:16Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Hello, we’re AMBOSS - and we’re looking for a **Working Student in Accounting** to join our **Accounts Payable** team!

# **About AMBOSS**

AMBOSS is a learning and clinical decision support tool striving to empower physicians across the globe to provide the best possible care. Our founders set out in 2011 to create a tool that they would have hoped to have as medical students and doctors. Since then we have grown to currently operate in 180 countries and have gained immense traction in Germany and the US. Currently, we are pursuing this mission with more than 500+ employees in our offices in Berlin, Cologne, New York, and Cagliari.

## **Are you ready to join us at AMBOSS?**

As a Working Student in Accounting, you'll contribute directly to the financial health and operational efficiency of AMBOSS. Your main focus will be on processing travel expenses, verifying transactions, and supporting accurate and timely accounting practices. This is an ideal opportunity to apply your academic knowledge in a meaningful context, gain hands-on experience with real-world financial processes, and grow alongside a supportive, experienced Accounting team.

## **Why join us in this role?**

In this role, you'll play a key part in maintaining financial accuracy and ensuring compliance with internal policies. You’ll have the chance to develop your technical skills, collaborate with a diverse and motivated team, and see the real impact of your work as AMBOSS continues to scale. If you're excited to dive into financial operations, contribute your analytical mindset, and learn in a dynamic, mission-driven environment - this could be the perfect next step in your journey.

## **You will:**

-

Review and process employee travel expenses in line with company policies

-

Reconcile submitted expenses with receipts and supporting documentation

-

Accurately code transactions using appropriate accounts, VAT codes, and cost centers

-

Communicate with employees to resolve discrepancies or clarify payment inquiries

-

Ensure compliance with internal policies and accounting principles

-

Support the Accounting team with ad hoc tasks and projects

-

Identify ways to improve and streamline accounting processes

-

Gain hands-on experience with accounting tools and internal systems

## **You bring:**

-

Currently enrolled in a degree program in economics, finance, accounting, or a related field

-

Availability to work around 20 hours per week (preferably two full days and a half day, with availability on Mondays)

-

At least 12 months left to complete your studies

-

Proficiency in MS Office, or G-Suite

-

Excellent written and verbal communication skills in English (German is a plus)

-

Ability to identify and analyze discrepancies in financial data

-

Strong attention to detail

-

A proactive attitude and eagerness to learn

-

Ability to work independently as well as collaboratively in a fast-paced environment

-

Strong organizational and time management skills

-

Curious about financial operations and open to continuous learning

## **You enjoy:**

-

Applying your studies in a meaningful, real-world context

-

Solving problems with an analytical mindset

-

Taking ownership of your tasks and seeing their impact

-

Working in a diverse, mission-driven company

-

Being part of a professional, friendly, and supportive team

-

Developing your skills and learning from experienced finance professionals

## **Benefits:**

**🌴 Rest & Time Off** (paid vacation days, AMBOSS holiday, personal purpose day and more)

**🥙Food & Office Comfort (**Daily healthy breakfast & lunch by in-house chef in Berlin HQ, AMBOSS daycare, work remotely from other office spaces in Cologne, Sardinia, Cape Town)

**🏃 Health, Fitness & Mobility** (Urban Sports Club -M plan- , Fitbit Versa 3, Deutschland Ticket…)

Check out the full list of benefits below:

[https://go.amboss.com/the-amboss-prescription-de](https://go.amboss.com/the-amboss-prescription-de)

We believe that diversity is a powerful driver of innovation and progress. That’s why we are committed to fostering an inclusive, respectful, and supportive environment where everyone—regardless of gender, age, ethnic or cultural background, religion, disability, sexual orientation, gender identity—is valued and given equal opportunity to thrive. We warmly welcome people of all backgrounds to help us fulfil our mission: empowering all medical professionals to provide the best possible care 🩺

Even if you don’t meet every single point in the job description, we still encourage you to apply. We’d love to hear from you!

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
