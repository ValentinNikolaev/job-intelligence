# Bilanzbuchhalter / Steuerfachangestellter (m/w/d) - Fonds & Immobilien | München

Posted: 2026-08-17T15:00:28Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**Direktvermittlung über PRIME HR Agentur®**

Für unseren Mandanten suchen wir zum nächstmöglichen Zeitpunkt einen erfahrenen **Bilanzbuchhalter oder Steuerfachangestellten (m/w/d)** für den Standort **München**. Sie erwartet eine verantwortungsvolle Position mit abwechslungsreichen Aufgaben rund um die Rechnungslegung und das Finanzwesen verschiedener Gesellschaften im Fonds- und Immobilienbereich.

## Aufgaben

- Sie übernehmen die laufende Finanzbuchhaltung mehrerer Gesellschaften und sorgen für eine zuverlässige sowie termingerechte Verarbeitung sämtlicher Geschäftsvorfälle.

- Ihr Aufgabenbereich umfasst Gesellschaften in unterschiedlichen Rechtsformen, insbesondere GmbHs und GmbH & Co. KGs sowie komplexere Beteiligungsstrukturen.

- Sie erstellen eigenständig Quartals- und Jahresabschlüsse und berücksichtigen dabei die relevanten handelsrechtlichen Vorschriften.

- Je nach Gesellschaft wenden Sie zusätzlich die einschlägigen Anforderungen des KAGB an.

- Sie bereiten aussagekräftige Reports und Auswertungen für interne und externe Empfänger auf.

- Zur Unterstützung der Unternehmenssteuerung erstellen Sie Ergebnisprognosen, Budgetauswertungen und Abweichungsanalysen.

- Bei Bilanzierungs- und Buchhaltungsthemen stimmen Sie sich eng mit Wirtschaftsprüfern, externen Geschäftspartnern und internen Fachbereichen ab.

- Sie begleiten die fachliche Klärung komplexer Sachverhalte und bringen Ihre Expertise bei der Weiterentwicklung von Prozessen ein.

## Qualifikation

- Sie haben eine Ausbildung zum **Steuerfachangestellten (m/w/d)** abgeschlossen oder verfügen über eine Weiterbildung zum **Bilanzbuchhalter (IHK) (m/w/d)**.

- Sie bringen fundierte Berufserfahrung aus der Finanzbuchhaltung mit und kennen die wesentlichen Bereiche der laufenden Buchführung.

- Mit Sachkonten, Debitoren, Kreditoren und der Anlagenbuchhaltung gehen Sie sicher und routiniert um.

- Die eigenständige Erstellung von Jahresabschlüssen nach HGB ist Ihnen vertraut.

- Idealerweise verfügen Sie über Kenntnisse in der Rechnungslegung nach **KAGB** und haben bereits mit Gesellschaften aus dem Fonds- oder Immobiliensektor gearbeitet.

- Im Umgang mit **MS Office** sind Sie sicher; Kenntnisse in **SAP** sind wünschenswert, aber keine zwingende Voraussetzung.

- Sie arbeiten sorgfältig, eigenständig und strukturiert und übernehmen gerne Verantwortung für Ihren Aufgabenbereich.

- Kommunikationsstärke und Teamorientierung zeichnen Sie ebenso aus wie Ihre zuverlässige Arbeitsweise.

- Auch bei komplexen Fragestellungen bleiben Sie lösungsorientiert und behalten die notwendigen Details im Blick.

## Benefits

- Eine anspruchsvolle und vielseitige Position mit langfristiger Perspektive.

- Ein attraktives Gesamtpaket aus Vergütung und zusätzlichen Arbeitgeberleistungen.

- Unterstützung bei der privaten Altersvorsorge.

- Ein professionelles Onboarding mit einer strukturierten und umfassenden Einarbeitung.

- Persönliche Begleitung und Unterstützung durch erfahrene Kolleginnen und Kollegen.

- Individuelle Möglichkeiten zur fachlichen Weiterbildung und persönlichen Entwicklung.

- Flexible Arbeitszeiten sowie die Möglichkeit, teilweise mobil zu arbeiten.

- Ein eigenständiges Aufgabengebiet mit kurzen Entscheidungswegen und viel Gestaltungsspielraum.

- Zuschüsse zum öffentlichen Nahverkehr und attraktive Konditionen für Dienstrad-Leasing.

- Maßnahmen zur Förderung von Gesundheit und Wohlbefinden am Arbeitsplatz, beispielsweise frisches Obst und ein abwechslungsreiches gastronomisches Angebot.

Sie möchten Ihre Erfahrung in einem professionellen Umfeld einbringen und eine verantwortungsvolle Position mit langfristiger Perspektive übernehmen?

Dann freuen wir uns auf Ihre Bewerbung über **PRIME HR Agentur®**. Wir begleiten Sie während des gesamten Bewerbungsprozesses persönlich, vertraulich und professionell und stellen bei gegenseitigem Interesse den direkten Kontakt zu unserem Mandanten her.

**Standort:** München

**Anstellungsart:** Vollzeit

**Vermittlungsart:** Direktvermittlung über PRIME HR Agentur®

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
