# Founding Associate(Operations, Growth, German Speaking) to CEO

Posted: 2026-08-17T13:20:15Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**Berlin • Cybersecurity & AI Startup • Recently Funded**

A funded cybersecurity startup in Berlin is looking for a **Founder's Associate(Operations, Growth) to CEO **to join as a team member and help to build startup foundations of a next-generation AI-powered security risk management platform.

We are an early-stage startup founded by experienced cybersecurity leaders with backgrounds in Israeli Intelligence units. We are looking for a motivated, dynamic and hands-on **Founder's Associate(Operations & Growth) to CEO** for a hybrid role based in central of Berlin, Potzdamer Platz. If you are passionate about cybersecurity and AI tech, thrive in fast-paced startup environments, and enjoy building processes from the ground up, this is an opportunity to make a real impact.

We are seeking a **Founder's Associate(Operations & Growth) to CEO** to support our CEO with finance, general operations, travel. The ideal candidate is energetic, smart, and able to thrive under pressure while managing multiple tasks effectively.

The position is hybrid and can be done full time or part time.

**We can accept also entry level candidates without experience if the culture fit is right.**

**Key Responsibilities**

-

Act as the primary **operational founder associate to the Founder & CEO and grow the company together**

-

Own and help running day-to-day company operations across **HR, finance, admin, and internal processes**

-

Own financial reporting, planning, and key metrics, ensuring transparency, clarity, and reliability

-

Take ownership of company wide **projects** such as developing an AI pricing model

-

Assist the founders with **strategic topics**, including investor relations, board preparation, and key hiring decisions.

-

Take care of **administrative** work like manage CEO calendar, priorities, meetings, business travel and follow-ups to **maximize focus and execution**

-

Support **HR, **including hiring logistics, onboarding, offboarding, and people administration

-

Support **Finance, **includinginvoicing, expense tracking, payments, and coordination with external accountants

-

Ensure operational hygiene, deadlines, and **compliance** across the company

**Must have skills**

-

**2+ years** of experience in startup doing one of the following: HR, finance, operations, business support, or executive assistance roles. **We can accept also entry level candidates without experience if the culture fit is right.**

-

Strong **organizational skills** and can do Attitude with the ability to manage multiple priorities independently

-

Excellent written and verbal communication skills in **English**

-

Excellent written and verbal communication skills in **German**

-

High level of discretion, **trustworthiness**, and attention to detail

-

Strong **execution mindset** and ability to operate under ambiguity

-

Comfortable working directly with **founders and senior stakeholders**

-

Ability to **build things from scratch** at early stage startup

-

High ownership mentality, startup mindset, and ability to move quickly.

-

Experience in early stage **startup or scale-up environments**

-

Low ego, high commitment, and a **true tech startup mentality**.

-

Strong **problem-solving skills** and ability to work in a collaborative environment.

-

Familiarity with German employment basics or EU labor processes

-

Comfortable working under **direct supervision** and ready to engage in business discussions when needed.

**Nice-to-have requirements**

-

**Experience supporting a CEO** or senior executive in a fast-paced environment

-

Exposure to PR, communications, or employer branding activities

-

Design skills and knowledge in design tools

-

Proficiency in at least one additional language, ideally **Russian or Hebrew**

-

Background in analytics

-

Background in sales

-

Public speaking experience and confidence presenting to audiences

-

Experience with **social media management**.

-

You are a fan of **rock or metal** music

**Benefits**

-

**Competitive Compensation** — salary aligned with market, flexible early-stage arrangements possible

-

**Fresh Funding Secured** — immediate runway to build, hire, and execute fast

-

**High Autonomy** — freedom to design and build without corporate overhead

-

**Work with a Technical CEO **— fast iteration, strong alignment, clear direction

-

**Cutting-Edge Domain** — identity security, SaaS-to-SaaS access, AI agent governance

-

**Massive Learning Curve** — quickly gain depth in various operational topics

-

**Fast Career Path** — opportunity evolve into leadership as we scale the team

-

**Berlin Location** — top-tier tech environment with strong cybersecurity and AI ecosystems

-

**Direct Impact** — your impact become the foundation of the entire company

-

**Best Equipment and Tools** - High quality equipment and modern tools to help you do your best work from day one

-

**Team Offsites - **Regular team offsites designed to build strong connections, alignment, and shared momentum

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
