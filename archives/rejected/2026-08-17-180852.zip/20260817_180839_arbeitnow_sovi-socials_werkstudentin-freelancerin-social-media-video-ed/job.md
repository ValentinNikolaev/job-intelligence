# Werkstudentin / Freelancerin Social Media & Video Editing

Posted: 2026-08-17T16:00:27Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Du liebst Social Media, hast ein richtig gutes Auge für Ästhetik und weißt, wann ein Reel einfach gut aussieht und sich auch so anfühlt?

Für unsere Social-Media-Agentur suchen wir kreative Unterstützung als Werkstudentin oder Freelancerin – am besten aus NRW. Bei uns arbeitest du an abwechslungsreichen Social-Media-Projekten, unterstützt bei Content-Produktionen und bist auch mal live bei Influencer-Events dabei 🎥

## Aufgaben

- Cutting und Bearbeitung von Reels & Social-Media-Videos

- Aufbereitung von Content für Instagram

- Unterstützung bei der Content-Erstellung und -Planung

- Recherche aktueller Trends, Sounds und Reel-Formate

- Entwicklung kreativer Ideen und Hooks

- Unterstützung bei Shootings und Content-Produktionen

- Gelegentliche Unterstützung und Begleitung bei Influencer-Events

- Enge Zusammenarbeit mit unserem Social-Media-Team

## Qualifikation

- Sehr gutes ästhetisches Auge und Gespür für hochwertigen Content

- Erfahrung im Video Editing, insbesondere mit Short-Form-Content

- Sicherer Umgang mit gängigen Schnittprogrammen wie CapCut, Edits o. Ä.

- Sehr gutes Verständnis für Instagram, Reels und aktuelle Social-Media-Trends

- Kreativität und ein Gespür dafür, was auf Social Media funktioniert

- Selbstständige, schnelle und zuverlässige Arbeitsweise

- Sehr gute Deutsch Kenntnisse

- Interesse an Influencer Marketing, Lifestyle und Events

## Benefits

- Flexible Arbeitszeiten und viel Remote Work

- Abwechslungsreiche Projekte mit bekannten Brands & Creatorn

- Einblicke hinter die Kulissen von Influencer Marketing und Social Media

- Möglichkeit, bei Influencer-Events, Shootings und Produktionen dabei zu sein

- Viel kreativer Freiraum und die Möglichkeit, eigene Ideen einzubringen

- Kurze Entscheidungswege statt unnötiger Abstimmungsschleifen

- Junges, modernes Arbeitsumfeld

- Möglichkeit auf eine langfristige Zusammenarbeit

Ich freue mich auf dich 🧡🌸

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
