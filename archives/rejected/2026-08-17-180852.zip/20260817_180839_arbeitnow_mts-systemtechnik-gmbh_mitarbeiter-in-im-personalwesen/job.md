# Mitarbeiter:in im Personalwesen

Posted: 2026-08-17T13:30:33Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Die **MTS Systemtechnik GmbH** ist ein innovatives, mittelständisches **Familienunternehmen** mit Sitz in Mertingen. Seit über 30 Jahren entwickeln und fertigen wir hochwertige, kundenspezifische Systemlösungen in den Bereichen Hochfrequenztechnik und EMV – *made in Germany*. Unsere Produkte kommen weltweit in den Bereichen Defense, Mobilfunk und anderen industriellen Anwendungen zum Einsatz.

Als Familienunternehmen mit langfristiger Perspektive stehen wir für **kontinuierliches Wachstum, Nachhaltigkeit und ein partnerschaftliches Miteinander**. Mit einem erfahrenen Engineering-Team, eigener Fertigung, eigenem Vertrieb und einer klaren Wachstumsstrategie suchen wir eine/n Hardware orientierte/n Ingenieur/in aus dem Bereich der Nachrichtentechnik als **Chief Technology Officer (CTO)**. Sie arbeiten direkt mit dem geschäftsführenden Gesellschafter zusammen, übernehmen Verantwortung für den technischen Bereich – und haben bei entsprechender Performance die **klare Perspektive, mittelfristig die CEO-Rolle zu übernehmen**.

## Aufgaben

- Pflege und Verwaltung der Personalakten, einschließlich Einführung der elektronischen Personalakte.

- Durchführung Lohn- und Gehaltsbuchhaltung.

- Auswertung der Zeiterfassung sowie Pflege der Urlaubs- und Abwesentheitskartei.

- Bearbeitung von Bewerbungen und Mitwirkung im Bewerbermanagement.

- Erstellung von Anstellungs- und Ausbildungsverträgen.

- Organisation und Verwaltung von Schulungen.

- Allgemeine Sekretariats- und Verwaltungsarbeiten

## Qualifikation

Grundanforderungen

- Sicherer Umgang mit MS Office und digitalen Verwaltungssystemen.

- Strukturierte, sorgfältige und vertrauenswürdige Arbeitsweise.

- Gute Kommunikationsfähigkeit und serviceorientiertes Auftreten.

- Kenntnisse im Arbeits-, Steuer- und Sozialversicherungsrecht sind von Vorteil

Sprachkenntnisse

- Sehr gute Deutschkenntnisse in Wort und Schrift

Berufsausbildung

- Eine abgeschlossene kaufmännische Berufsausbildung, idealerweise mit Erfahrung im Personalwesen und Gehaltsabrechnung

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
