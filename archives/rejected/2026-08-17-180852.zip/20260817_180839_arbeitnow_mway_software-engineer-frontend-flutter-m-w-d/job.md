# Software Engineer Frontend - Flutter (m/w/d)

Posted: 2026-08-17T14:30:18Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**Deine Aufgaben**

App-Entwicklung ist deine Leidenschaft und du bist absolute:r Flutter-Profi? Unterstütze unser Team bei der Entwicklung innovativer, plattformübergreifender mobiler Anwendungen. Als Software Engineer bei Relution übernimmst du Verantwortung für die Entwicklung neuer Features – von der Konzeption bis zum Release!

- Du entwickelst unsere plattformübergreifende Apps auf Basis von Flutter und Dart weiter
- Du übernimmst technisches Ownership für unsere Flutter-Apps und bringst neue Ideen ein
- Du bindest via OpenAPI spezifizierte REST-APIs an und nutzt die vom Backend bereitgestellten Datenmodelle sinnvoll in der App
- Du triffst Arichtekturentscheidungen (z. B. Provider, Riverpod, Bloc) und setzt sie um
- Du kümmerst dich um Testautomatisierung und CI/CD für unsere Lösungen
- Du verantwortest Release-Prozesse und die Veröffentlichung im App Store und Play Store
- Du arbeitest im Scrum-Team eng mit Design und Backend zusammen, um ein rundes Produkt zu bauen

**Dein Profil**

- Du hast fundierte Erfahrung mit Flutter und Dart und schon mehrere Apps von Grund auf gebaut
- Du kennst dich mit nativer iOS- (Swift) und Android-Entwicklung (Kotlin/Java) sowie den jeweiligen Appstore-Prozessen aus
- Du arbeitest selbstständig und bringst dich gerne im Team ein
- Gute Deutsch- und Englischkenntnisse runden dein Profil ab
- Erfahrung im MDM-/UEM-Umfeld ist ein Plus, aber kein Muss

**Was uns wichtig ist**

- Du willst dich langfristig in ein Produkt einarbeiten, statt von Projekt zu Projekt zu springen
- Du denkst technische Themen aktiv mit, statt nur Tickets abzuarbeiten
- Du bist mit mindestens 50% vor Ort in Stuttgart – an unseren Testgeräten geht's nicht komplett remote
- Bewirb dich auch dann, wenn du nicht alle Punkte zu 100% erfüllst – Lernbereitschaft zählt bei uns genauso viel wie Erfahrung

**Warum wir?**

- **Zeit und Ort, die zu dir passen:** Flexible Arbeitszeiten, saubere Zeiterfassung, die Möglichkeit, in Teilzeit zu arbeiten, und Homeoffice, wann immer es passt.
- **30 Tage Urlaub + 6 Gleittage:** Genug Zeit zum Abschalten, on top of the usual.
- **Gut eingearbeitet:** Mentoring von Tag eins an, damit du schnell ankommst.
- **Macademy:** Unser eigenes Weiterentwicklungsprogramm – für alle, die mehr wollen.
- **Mobil unterwegs:** Wir bezuschussen dein Deutschlandticket.
- **Aufs Rad:** (E-)Bike-Leasing über Jobrad – dank eigener Fahrradgarage und Duschen kommst du entspannt an, egal wie du fährst.
- **Für später vorgesorgt:** Betriebliche Altersvorsorge ist bei uns Standard.
- **Rundum versorgt:** Mittagessen in unserer bezuschussten Kantine, Getränke gibt's den ganzen Tag kostenlos.
- **Fit bleiben:** Wellpass oder Urban Sports Club – so wie's dir passt.
- **Team-Momente:** Regelmäßige Teamevents, die auch wirklich Spaß machen.
- **Unser Zuhause in Stuttgart:** Helle, neue Räume, gut angebunden an den ÖPNV – du kommst schnell und unkompliziert zu uns.

Wir wurden von FOCUS-Business als bester Arbeitgeber im Mittelstand 2026 empfohlen. Überzeuge auch Du Dich von uns und bring Deine Karriere auf das nächste Level.

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
