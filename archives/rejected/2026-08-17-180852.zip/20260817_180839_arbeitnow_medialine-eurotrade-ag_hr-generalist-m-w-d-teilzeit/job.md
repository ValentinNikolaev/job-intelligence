# HR Generalist (m/w/d) - Teilzeit

Posted: 2026-08-17T15:00:29Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Diese Position ist für unsere Gesellschaft CYBERDYNE Informationstechnologie GmbH zu besetzen.

Wir suchen zum nächstmöglichen Zeitpunkt (ab dem 15.09.2026) einen HR Generalist (m/w/d) in Teilzeit (ca. 25-30 Stunden/Woche) mit Büropräsenz von mindestens drei Tagen pro Woche.

Wer wir sind? Wir sind ein regionaler IT-Dienstleister aus Köln, mit einem diversen Team aus knapp 60 Mitarbeiter und Mitarbeiterinnen und einem sehr lieben Firmenhund. Wir arbeiten jeden Tag mit hohem Anspruch daran, unseren kleinen und mittelständigen Kunden bei ihren IT-Herausforderungen zu helfen und deren technische Probleme zu lösen. Unser Motto ist „#stresslessIT“ und das leben wir intern wie auch extern bei unseren Kunden.

Seit 2023 haben wir uns der Medialine Gruppe angeschlossen, um von dem gemeinsamen Erfahrungsschatz und dem Leistungsspektrum zu profitieren.

## Aufgaben

Als HR Generalist (m/w/d) bist du die erste Anlaufstelle für unsere Fach- und Führungskräfte, Azubis, Studenten und Praktikanten. Du verantwortest u.a.:

- Recruiting und Bewerbermanagement

- Unterstützung und Beratung der Führungskräfte und sonstigen Mitarbeitenden in personalrelevanten und arbeitsrechtlichen Fragestellungen

- operative Personalarbeit über den gesamten employee-life-cycle (u.a. On- und Offboardings)

- Vertragswesen: Erstellung von u.a. Arbeitsverträgen, Arbeitszeugnissen und Bescheinigungen

- monatliche Vorbereitung der Gehälter (keine Gehaltsabrechnung)

- Stammdatenpflege und Verwaltung des Personalmanagementtools HRWorks

- enge Zusammenarbeit mit der Geschäftsleitung

- Unterstützung bei der Organisation von bedarfsgerechten Personalentwicklungsmaßnahmen

- Begleitung von sonstigen Personalprojekten u.a. zu den Themen Mitarbeiterbindung und -Gewinnung (z.B. Benefits)

- Mitgestaltung eines positiven und inklusiven Arbeitsumfelds

## Qualifikation

- erfolgreich abgeschlossene Ausbildung oder Studium im Bereich Wirtschafts- oder Sozialwissenschaften

- mehrjährige Erfahrung (min. 2-3 Jahre) in einer generalistischen HR-Rolle und im Recruiting

- Erfahrung mit der vorbereitenden Gehaltsabrechnung

- idealerweise Erfahrung in der Arbeit mit Auszubildenden und Werkstudenten

- sehr gute Deutschkenntnisse in Wort und Schrift

- Arbeitsrechtliches Grundlagenwissen

- Freude an der Zusammenarbeit mit Menschen auf unterschiedlichen Ebenen

- eine strukturierte, eigenständige und zuverlässige Arbeitsweise

- Kommunikationsstärke, Empathie, Diskretion und Auffassungsgabe

- Teamfähigkeit, Hands-on-Mentalität und ein souveräner Umgang mit Herausforderungen

## Benefits

- Ein Ort mit Sinn – und Parkplatz: Du wirst Teil eines Teams, das zusammenhält und weiterdenkt. Dein Auto parkt kostenlos in Köln.

- JobRad oder Jobticket? Oder beides – du entscheidest, wie du am liebsten pendelst.

- Teamevents & Bewegung: Ob Firmenlauf, Kicker-Turnier oder Feierabendbier – wer mag, ist dabei.

- Gelebte Nachhaltigkeit: Digitale Prozesse, eine E-Auto-Flotte für Kundentermine und unser eigener CYBERDYNE Forest.

- Gesundheit & Genuss: Zuschuss bei Mealmates, Teamküche, Urban Sports Club und Kooperation mit DoQtor.

- Moderne Ausstattung: Leistungsfähige Hardware und – je nach Rolle – ein aktuelles iPhone inklusive.

- Ruhe finden: Entspannungsbereich im Haus oder eine Runde Yoga direkt im Park vor der Tür.

- An morgen denken: Wir unterstützen dich aktiv beim Thema Altersvorsorge.

- Erholung: Finden wir zum Beispiel beim gemeinsamen Mittagessen oder bei unseren 30+1 Urlaubstagen.

Wir freuen uns auf Deine Bewerbung!

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
