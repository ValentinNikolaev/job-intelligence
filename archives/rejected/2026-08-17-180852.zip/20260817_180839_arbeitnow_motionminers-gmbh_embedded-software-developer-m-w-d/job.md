# Embedded Software Developer (m/w/d)

Posted: 2026-08-17T16:47:33Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**Lust auf Start-Up-Gefühl, Hardwareentwicklung IoT und eingebettete Technik?**

Dann komm‘ zu den MotionMiners. Mit einem Team von 60 neugierigen und motivierten Mitarbeiter:innen entwickeln wir die revolutionäre Motion-Mining-Technologie zur automatischen Aufnahme und Analyse von manuellen Arbeitsprozessen. Mittels Sensoren (Wearables) und KI können wir so die Ergonomie und Effizienz von Prozessen, bspw. in der Produktion oder Logistik verbessern.

Wir sind auf der Suche nach begeisterten Menschen, die unser Team bereichern und gemeinsam mit uns die Zukunft des Unternehmens formen.

## Aufgaben

- Hauptverantwortung für die Firmwareentwicklung in C mit Fokus auf Sensorik und Datenaufzeichnung

- (Weiter-)Entwicklung robuster Datenupload- und Flottenmanagement-Prozesse

- Testing, Wartung und kontinuierliche Weiterentwicklung unserer Firmware

- Mitgestaltung und Begleitung des gesamten Produktentwicklungsprozesses von der Konzeption bis zum Roll-Out

- Analyse und Lösung von technischen Fehlern auf Hard- und Firmware-Ebene

- Unterstützung bei der Wartung und technischen Betreuung bestehender Geräte

- Technischer Support im Falle von komplexen Fragestellungen und Fehlerbildern

- Zusammenarbeit mit dem Produkt Management und angrenzenden Teams beim Einsatz und der Weiterentwicklung unserer Produkte

## Qualifikation

- Abgeschlossenes Studium oder eine vergleichbare Qualifikation im Bereich Informatik, Elektrotechnik, Robotik oder ähnlichem

- Mehrjährige Berufserfahrung in der Embedded Entwicklung

- Sehr gute Kenntnisse in C und Erfahrung in der hardwarenahen Softwareentwicklung

- Erfahrung mit Hardwareplattformen wie Nordic nRF und Espressif ESP32

- Sicherer Umgang mit Kollaborationswerkzeugen wie Git, GitLab, Teams und Co.

- Vorkenntnisse im Bereich Bluetooth Low Energy, Real-Time Operating Systems und/oder AWS IoT Core wünschenswert

- Teamfähigkeit, Leistungsbereitschaft sowie ausgeprägte Kommunikationsfähigkeit

- Hohe Eigenverantwortlichkeit, sowie eine zuverlässige, strukturierte und lösungsorientierte Arbeitsweise

- Hands-On Mentalität, handwerkliches Geschick und Freude an der Einbringung eigener Ideen

- Gute Englischkenntnisse

## Benefits

- unbefristeter Arbeitsvertrag

- 100% Start-up-Atmosphäre mit Kicker und Tischtennisplatte

- Hohe Eigenverantwortlichkeit

- Cooles Team und flache Hierarchien

- Beste Karriere- und Entwicklungsmöglichkeiten

- Aktive Mitwirkung bei der Ausgestaltung unserer Technologie

- Feel Good Management inkl. kostenloser Getränke

- Legendäre Team-Events, flexible Arbeitszeiten, viel zu tun und viel Spaß

**Bereit mit uns durchzustarten?**

Dann schick uns einfach deine vollständige Bewerbung! Wir freuen uns auf Dich!

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
