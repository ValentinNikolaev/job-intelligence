# Senior Product Designer - Heartbeat AI (m/f/d)

Posted: 2026-08-17T14:30:27Z

## Rejection

- Category: tech_stack
- Reason: role does not mention Go/Golang or PHP

## 1KOMMA5°

At **1KOMMA5°**, we pursue a clear vision: **Living on wind and sunlight forever for free**. To make this a reality, we are building the energy system of the future with Heartbeat AI. Want to be part of it?

We bring together regional craftsmanship and scalable software: We don't think of solar, batteries, heat pumps, and e-mobility as isolated components, but control them as an intelligent, integrated overall system in our virtual power plant. Directly connected to the electricity market – in real time, fully automated. This way, energy is used when it is available from renewables and particularly cost-effective. By 2030, our goal is to transition 1.5 million households to renewable energies. Over 3,000 people are working towards this every day, at more than 80 locations worldwide, from Finland to Australia.

**Want to take responsibility and build solutions that truly matter? Apply now and help us shape the energy world of tomorrow.**

Learn about our Product & Tech team!

## Deine Position

We are looking for an AI-native designer Senior Product Designer to embed directly into our B2C product teams. You won't be doing side tasks; you'll be shaping our flagship consumer product, the Heartbeat app.

You can onboard and ideate quickly on complex technical energy concepts, prototype fast, and you've already figured out how to use AI as a force multiplier in your design workflow.

This role sits at the intersection of craft and impact. You'll own the full design loop — from shaping the problem, to shipping polished and production-ready app experiences.

As a Senior Product Designer you will

- Own end-to-end design for core app features — from discovery to delivery

- Leverage AI to enhance every step of the design process

- Elevate the product experience - you can take things from good to excellent

- Run effective user research — interviews, usability tests, and surveys

- Partner closely & proactively with PMs, engineers, and data scientists

- Synthesise complex data into simple, elegant product decisions

- Advocate for the user in a fast-moving, technical environment

- Tools: Figma, Cursor, Claude, Notion, Linear

- Skills: AI-First Design, Prototyping, User Research, UX Process, Data Visualization, Mobile App Design

## Dein Profil

- You don't need to tick every box — but this is the mold we're hiring for. If this profile sounds like the person you're becoming, we want to hear from you.

- **AI native** — you use AI tools daily in your design process and can show us the work

- **Block-shaped** — equally strong and curious in UX process, visual design, UI craft, and cross-functional collaboration

- **End-to-end ownership** — you've taken features from 0 to 1, from messy problem statement to shipped product

- **Mobile app design fluency** — you’re proficient in mobile app design patterns

- **High agency** — you spot gaps and fill them without being asked

- **Builder mindset** — you care about things being made, not just imagined

- **Excellent communicator** — you bring clarity and efficiency to verbal & written communication; our working language is English; fluency in German is a big plus

## Benefits

- You are part of an international, dynamic, and highly motivated team of people who have proven to make things happen

- With your work, you accelerate the "energy transition" and hence have a direct impact on our climate

- Work with and learn from other super-smart colleagues

- You will enjoy direct contact with core decision-makers

- You will enjoy the best chances of entering full-time in one of Europe’s most thriving scaleups

- You work remotely (Germany-wide), with offices in Hamburg, Berlin or Munich

- Create a healthy balance alongside your work and enjoy all the benefits of the EGYM Wellpass

- Benefits and discounts are yours with Futurebens

- Whether city bike or e-bike - be flexible with our job bike leasing and do something good for the environment at the same time

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
