# Vertriebsmitarbeiter für IT- und Digitalisierungslösungen (m/w/d)

Posted: 2026-08-17T14:30:29Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Im Vertrieb von apia geht es nicht um kurzfristige Abschlüsse oder austauschbare Produkte. Du findest heraus, vor welchen Herausforderungen ein Unternehmen steht, koordinierst die passenden Fachbereiche und entwickelst gemeinsam mit dem Kunden eine tragfähige Lösung.

## Aufgaben

Du baust Beziehungen zu mittelständischen Unternehmen auf und entwickelst diese langfristig weiter. Dabei vertrittst du das Leistungsportfolio von apia aus den Bereichen Proalpha ERP, Prozessdigitalisierung und IT-Security.

Identifikation und Ansprache potenzieller Geschäftskunden

- Aufbau neuer Kundenbeziehungen

- Betreuung und Weiterentwicklung bestehender Kunden

- Ermittlung von Anforderungen und konkreten Handlungsbedarfen

- Beratung zu den Leistungsbereichen von apia

- Enge Zusammenarbeit mit ERP-, IT- und Security-Spezialisten

- Vorbereitung von Kundenterminen und Präsentationen

- Koordination fachlicher Gespräche und Lösungspräsentationen

- Erstellung und Nachverfolgung von Angeboten

- Strukturierte Pflege von Kontakten, Gesprächsergebnissen und Verkaufschancen

- Begleitung des Kunden vom Erstkontakt bis zur Beauftragung

- Übergabe gewonnener Projekte an die verantwortlichen Fachbereiche

- Beobachtung von Marktanforderungen und Rückmeldung an das interne Team

## Qualifikation

- Erfahrung im Vertrieb, in der Kundenberatung oder im Geschäftskundenumfeld

- Interesse an IT, Digitalisierung und erklärungsbedürftigen Lösungen

- Fähigkeit, aufmerksam zuzuhören und relevante Anforderungen zu erkennen

- Kommunikationsstärke und ein verbindliches Auftreten

- Selbstständige und strukturierte Arbeitsweise

- Eigeninitiative und Verlässlichkeit

- Freude am Aufbau langfristiger Kundenbeziehungen

- Sicheres Ausdrucksvermögen in deutscher Sprache

- Bereitschaft, sich in ERP-, IT- und Security-Themen einzuarbeiten

- Verständnis dafür, dass gute Beratung vor dem Verkauf steht

## Benefits

- Eigenverantwortliches Arbeiten: Du erhältst den Freiraum, Aufgaben selbstständig zu strukturieren, Entscheidungen vorzubereiten und Projekte aktiv mitzugestalten.

- Flache Hierarchien: Kurze Abstimmungswege ermöglichen schnelle Entscheidungen und einen direkten Austausch mit Kollegen und Verantwortlichen.

- Flexible Arbeitsgestaltung: Abhängig von Aufgabe, Projekt und Abstimmung im Team kann Arbeit flexibel organisiert werden. Präsenz und mobiles Arbeiten sollen sinnvoll miteinander verbunden werden.

- Fundierte Einarbeitung: Du wirst fachlich und methodisch in deine Aufgaben eingearbeitet. Dazu gehören der direkte Austausch im Team, praktische Projektarbeit und Schulungen.

- Fachliche Weiterentwicklung: Neue Lösungen, Technologien und Kundenanforderungen sorgen dafür, dass du dein Wissen kontinuierlich erweitern und eigene fachliche Schwerpunkte entwickeln kannst.

- Offene Zusammenarbeit: Informationen, Erfahrungen und Herausforderungen werden im Team offen besprochen. Gute Ergebnisse entstehen nicht durch Einzelkämpfer, sondern durch verlässliche Zusammenarbeit.

Lass uns miteinander sprechen

Sende uns deine Bewerbung oder zunächst eine kurze Nachricht. Entscheidend ist nicht, wie umfangreich deine Unterlagen sind, sondern ob deine Erfahrung, deine Interessen und die Position zueinander passen.

Wir freuen uns auf deine Bewerbung!

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
