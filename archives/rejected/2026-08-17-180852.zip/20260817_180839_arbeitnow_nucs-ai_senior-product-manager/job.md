# Senior Product Manager

Posted: 2026-08-17T14:30:19Z

## Rejection

- Category: tech_stack
- Reason: role does not mention Go/Golang or PHP

### **About Nucs AI**

Nucs AI is revolutionizing cancer care through cutting-edge AI and medical imaging technology. Founded in 2024 by a multidisciplinary team of oncologists, AI researchers, and healthcare innovators, we’re tackling one of medicine’s most pressing challenges: the growing demand for accurate, timely cancer diagnostics in the face of rising scan volumes and limited radiologist capacity.

We sit at the intersection of diagnostics and treatment planning—building AI-powered tools at the convergence of medical imaging, radioligand therapy, and artificial intelligence. Starting with prostate cancer and expanding across oncology, we partner with world-leading medical institutions and pharmaceutical companies across the US, Europe, and Australia to bring precision oncology into everyday clinical practice.

Our mission is to enhance diagnostic precision and expand access to expert-level cancer care, improving patient outcomes worldwide. We’re venture-backed, early-stage, and building a team that blends deep clinical expertise with engineering intensity—moving with the rigor the medical field demands and the speed the problem deserves.

### **The Opportunity**

Nucs AI is looking for a Senior Product Manager who thrives at the intersection of complex technology and specialized end-users. You will own critical parts of our product roadmap, translating deep clinical and technical requirements into clear product direction, then driving execution across data, engineering, regulatory, and commercial areas. This is not a role where you manage a feature backlog in isolation; you will be expected to build conviction around what we should build, why, and in what order, and to defend that thinking rigorously.

### **What You’ll Do**

#### **Product Development Support**

-

Own the roadmap for one or more product lines (e.g., DeepPSMA, SelectPSMA, TrackPSMA), balancing clinical impact, technical feasibility, and business value.

-

Engage directly with clinicians, nuclear medicine physicians, and oncologists to deeply understand their workflows, pain points, and decision-making processes.

-

Translate ambiguous, technically complex problems into well-structured product requirements and clear success criteria.

-

Develop and articulate a clear product narrative: why this feature matters, who it serves, and how it connects to the broader platform vision.

-

Navigate the regulatory landscape (FDA, CE marking) as a stakeholder, you do not need to be a regulatory expert, but you must understand how regulatory requirements shape product decisions and timelines.

#### **Cross-Functional Coordination**

-

Drive cross-functional execution with engineering, AI/ML, clinical, regulatory, and commercial stakeholders, keeping a small team moving fast without sacrificing quality.

-

Contribute to go-to-market strategy, positioning, and customer enablement alongside commercial and clinical teams.

#### **Analytics & Insights**

-

Define and track meaningful product metrics; use data and user feedback to inform iteration and prioritization decisions.

### **What You Bring**

-

3-6 years of product management experience in a B2B or technical environment building products for specialized, professional users (not purely consumer products).

-

Demonstrated ability to manage complex products where the user base has deep domain expertise, e.g., enterprise software, developer tools, scientific instruments, industrial platforms, or similar.

-

Strong conceptual and systems thinking. You can see the big picture, connect disparate inputs into a coherent product thesis, and reason about second-order effects. You don't just execute, you think.

-

Startup or high-growth experience. You have worked in an environment where speed, ambiguity, and wearing multiple hats were the norm, not the exception.

-

Excellent communication skills. You can write clearly, present a compelling argument, and facilitate productive discussions with both technical and non-technical stakeholders.

-

Comfort with technical depth. You do not need to write code, but you should be able to engage meaningfully with engineers and data scientists on architecture, data, and tradeoff discussions.

-

Intellectual curiosity and learning agility. You pick up new domains quickly and enjoy becoming a quasi-expert in areas you previously knew nothing about.

-

Fluency in English (native or professional proficiency required - C1 level or higher)

### **Bonus Points**

-

Experience in healthcare, medtech, health-AI, or a regulated industry.

-

Familiarity with medical imaging, oncology workflows, or clinical decision support.

-

Experience working with AI/ML-driven products where model behavior shapes the user experience.

-

Exposure to FDA 510(k), De Novo, or CE marking processes for software as a medical device (SaMD).

### **Why Nucs AI**

-

**Mission with real impact ** – Your work directly improves how cancer patients are diagnosed and treated.

-

**Ground-floor opportunity ** – Early-stage company, meaningful equity, and outsized influence on the direction we take.

-

**World-class collaborators ** – Work alongside leading oncologists, nuclear medicine physicians, and AI researchers globally.

-

**Massive market tailwinds ** – Radioligand therapy and AI-driven oncology are multi-billion dollar growth markets.

-

**Autonomy and flexibility ** – Remote-first, flexible working. We hire great people and trust them to deliver.

-

**Equity upside ** – Competitive equity package. We’re building something big and want you to share in it.

### **How to Apply**

Submit your resume and a brief note on why this role and Nucs AI excite you.

### **Equal Opportunity**

Nucs AI is an equal opportunity employer. We celebrate diversity and are committed to creating an inclusive environment for all team members. All qualified applicants will receive consideration without regard to race, color, religion, sex, sexual orientation, gender identity, national origin, disability, or veteran status.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
