# JTL Wawi Experte (m/w/d) Freelance o, projektbasiert

Posted: 2026-08-17T13:01:35Z

## Rejection

- Category: tech_stack
- Reason: role does not mention Go/Golang or PHP

Wir sind ein wachsendes Fulfilment Center und suchen einen erfahrenen Experten (m/w/d) für JTL Wawi, der uns projektbasiert bei der Optimierung und Weiterentwicklung unserer Systeme unterstützt. Der Schwerpunkt liegt auf der Automatisierung von Prozessen, der Anbindung und Optimierung von Marktplätzen sowie der Migration bestehender Strukturen.

Du arbeitest eng mit unserem internen JTL-Experten zusammen, der bereits ein umfassendes System aufgesetzt hat und dieses laufend weiterentwickelt, sowie mit unserem Operations Manager und der Geschäftsführung. Wir freuen uns mit dir schnell ins Doing zu kommen!

## Aufgaben

- Optimierung und Automatisierung von Abläufen in JTL Wawi

- Workflows aufsetzen, pflegen und neue Kunden anbinden

- Beratung und technische Umsetzung zur Verbesserung von Bestell- und Lagerprozessen (WMS)

- Unterstützung bei täglichen Optimierungen und To-dos

## Qualifikation

- Fundierte Erfahrung mit JTL Wawi und WMS sowie den dazugehörigen Prozessen

- Erfahrung mit Picklistenoptimierung, Rechnungen, Artikeletiketten und Layout

- Technisches Verständnis für API-Schnittstellen und Datenmigration

- Sicherer Umgang mit dem JTL-Ameise Import/Export inkl. Erstellung von Skripten

- Selbstständige und lösungsorientierte Arbeitsweise

- Zuverlässige Umsetzung innerhalb gemeinsam festgelegter SLAs

## Benefits

- Flexible Zusammenarbeit auf freiberuflicher Basis

- Verschiedene Modelle möglich: festes Stundenkontingent im Monat oder andere Vereinbarungen

- Spannende Projekte mit viel Gestaltungsspielraum

- Möglichkeit für eine langfristige Kooperation

Wir freuen uns auf deine Bewerbung inkl. Verügtungsvorstellung pro Stunde sowie zeitlicher Verfügbarkeit.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
