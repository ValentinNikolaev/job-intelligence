# Senior Data Engineer (m/w/x)

Posted: 2026-08-17T14:30:25Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

## Projektbeschreibung:

Technologie begeistert Sie? Uns auch! Zur Verstärkung unseres Expertenteams bei unserem Kunden aus der Funk- und Kommunikationsbranche suchen wir einen Senior Data Engineer (m/w/x) in Festanstellung bei K-tronik. Wir freuen uns darauf, Sie persönlich kennen zu lernen - und gemeinsam mit Leidenschaft und Teamgeist an spannenden Projekten und zukunftsweisenden Technologien zu arbeiten.

## Aufgaben:

- Du arbeitest an der Konzeption und Entwicklung einer On-Premises-Datenplattform mit

- Du entwickelst und integrierst Komponenten für Datenorchestrierung, Deployment und Plattformautomatisierung

- Du erstellst Proof of Concepts, gerne mithilfe von KI-Agent-Tools wie [Cursor.ai](http://Cursor.ai)

- Du implementierst Batch- und Streaming-Datenpipelines und plattformbezogene Services

- Du integrierst Workloads auf Kubernetes sowie S3-kompatiblen Storage-Lösungen

- Du untersuchst Datenkataloge, Datenversionierung und ihre Integration in die Plattform

- Du untersuchst Datenkataloge und ihre Integration in die Plattform

- Dabei arbeitest Du mit Lead Architekten, Infrastruktur- und Security-Teams zusammen

## Qualifikationen:

- Du hast ein abgeschlossenes Studium der Informatik oder eine vergleichbare Qualifikation oder Ausbildung und möchtest Software gestalten, die wirklich etwas bewegt

- Dabei experimentierst du gerne mit Proofs of Concept und bringst diese eigenständig zum Laufen

- Du bringst mehrjährige Erfahrung mit Kubernetes und Kubernetes-Infrastruktur sowie mit Linux-Betriebssystemen mit

- Mit modernen Datenplattform-Architekturen wie Kappa oder Medallion sowie Batch- und Low-Latency-Streaming-Pipelines kennst Du Dich aus

- Du verfügst über praktische Kenntnisse in Python, Golang, SQL (MPP), Bash und Java

- Mit vielen dieser Tools und Technologien hast Du schon gearbeitet : S3, Apache Iceberg, GitOps Workflows, [NATS.io](http://NATS.io), Risingwave, Dagster, Spark, Kafka, Flink und Airflow, idealerweise ergänzt durch Erfahrung mit [Cursor.ai](http://Cursor.ai) und Konzepten wie NUMA und Core Pinning

- Du bist ein Cloud Native, arbeitest routiniert mit Linux, Linux-Containern und Kubernetes und hast eigene Ideen, wie sich Data-Management-Plattformen am Edge ganz ohne Public-Cloud-Services realisieren lassen

- Optimalerweise kannst du mehrjährige Berufserfahrung als Data Scientest nachweisen

- Du überzeugst durch analytisches Denken, ein agiles Mindset, ausgeprägte Problemlösungskompetenz und eine starke Lösungsorientierung.

- Sehr gute Deutsch- und Englischkenntnisse (in Wort und Schrift) runden Dein Profil ab

## Benefits:

- Kollegiales und freundschaftliches Arbeitsklima

- Flexible Arbeitszeiten

- 30 Urlaubstage und flexible Urlaubsplanung

- Regelmäßige Team-Events

- Auszeichnung als Kununu TOP Company

- Corporate Benefits (Mitarbeiterangebote)

- Kostenlose Getränke

- Individuelle Weiterbildungsmöglichkeiten

- 360° Betreuung: Feedbackgespräche, Karriereplanung, Unterstützung bei Umzug, etc.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
