# Ausbildung zum Fachinformatiker (m/w/d) - Anwendungsentwicklung

Posted: 2026-08-17T13:30:32Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Starte deine Zukunft mit uns!

**Du möchtest Software entwickeln, die Unternehmen wirklich weiterbringt? Dann bist du bei uns genau richtig!**

Die **softwareproduktiv GmbH** entwickelt seit über 20 Jahren individuelle Softwarelösungen und eigene Softwareprodukte für mittelständische Unternehmen. Bei uns arbeitest du nicht an Übungsprojekten, sondern von Anfang an an echten Anwendungen und spannenden Kundenprojekten

## Aufgaben

Das erwartet dich:

- Entwicklung moderner Softwarelösungen

- Mitarbeit an spannenden Projekten für mittelständische Unternehmen

- Ein motiviertes Team mit kurzen Entscheidungswegen

- Moderne Arbeitsplätze und neueste Technologien

- Persönliche Betreuung während deiner gesamten Ausbildung

## Qualifikation

Das solltest du mitbringen:

- Interesse an IT und Softwareentwicklung

- Spaß am logischen Denken und Lösen von Problemen

- Motivation, Neues zu lernen

- Teamgeist und Eigeninitiative

## Benefits

Das bieten wir dir:

- Eine abwechslungsreiche und praxisnahe Ausbildung

- Ein familiäres Arbeitsumfeld

- Moderne Arbeitsausstattung

- Kostenlose Getränke

- Ein Team, das dich unterstützt und fördert

- Sehr gute Übernahmeperspektiven nach erfolgreichem Ausbildungsabschluss

**Bewirb dich jetzt!**

Sende uns einfach deine Bewerbungsunterlagen per E-Mail an:

**softwareproduktiv GmbH**

Christine Park

Konrad-Zuse-Str. 4

46397 Bocholt

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
