# Staff Backend Engineer - Core Product (Europe)

Posted: 2026-08-16T21:00:13Z

## Rejection

- Category: tech_stack
- Reason: role does not mention Go/Golang or PHP

### About [Kalepa](https://himalayas.app/companies/kalepa):

Insurance is a $7T global industry built on professional labor: underwriting, claims, pricing, operations, and distribution. [Kalepa](https://himalayas.app/companies/kalepa) is building AI that can perform that work.

We create professional-grade AI systems for insurers: software that can read, reason, decide, and act inside real workflows and operate over long-time horizons. [Kalepa](https://himalayas.app/companies/kalepa) begins by augmenting professionals with the tools to succeed at their jobs. That earns us the right to learn from real decisions, capture decision traces, and automate what can be automated successfully over time.

Our products are already in production with leading insurers, driving measurable outcomes and expanding across functions. The opportunity is far broader than any single workflow: to build the AI operating system for decision-making across insurance. For people who want to work on AI that matters, in a sector where correctness, trust, and real-world impact count, [Kalepa](https://himalayas.app/companies/kalepa) is just getting started.

[Kalepa](https://himalayas.app/companies/kalepa) is backed by leading investors such as IA Ventures and Inspired Capital, and our team brings experience from Facebook, Palantir, Google, Amazon, McKinsey, Mastercard, and Uber.

### Our Values (This is important):

Many organizations have a dusty list of corporate values that no one ever follows. [Kalepa](https://himalayas.app/companies/kalepa) is not one of those companies. Our values are designed to unlock the potential of our employees.

Success at [Kalepa](https://himalayas.app/companies/kalepa) is bred from five core principles:

-
**Hustle and Determination **- We hire people who take full ownership of their craft and relentlessly pursue excellence with speed and determination. We choose the hard problems and do not give up. This is the foundation of how we work and how we win.

-
**Deliver Customer Impact **- We're obsessed with customer impact. Every feature, every line of code, every decision is measured against one question: does this help insurers make better decisions? If it doesn't drive speed, accuracy, or profitability for our customers, we don't build it.

-
**Meritocracy **- We're building something exceptional, and that requires exceptional people and ideas. We have a high bar but we reward excellence with rapid growth. If you're the best at what you do, you'll thrive here.

-
**Transparency** - We value honest, transparent communication over politics. We challenge ideas, not people. We say what needs to be said, even when it's hard. This is how we solve problems fast and find the truth.

-
**Experiment Relentlessly** - Many of the problems we face have never been solved before. We tackle them by testing quickly, measuring rigorously, and iterating until we find the path forward. Speed of learning is our advantage.

In addition to our NY office, we have remote employees speaking 10+ languages across the globe. But we invest in bringing our people together both for regional meetups and global offsites (2021 - Playa Del Carmen | 2022 - Rome | 2023 - Buenos Aires | 2024 - Lisbon | 2025 - Cartagena).

[Kalepa](https://himalayas.app/companies/kalepa)’s culture isn’t for everyone, and that’s ok. But for the people who are a fit, they can’t imagine working elsewhere.

### **About the role:**

### Salary range: $100k – $185k USD*

We’re looking for strong backend engineers who love building reliable systems around fragmented, but high-value data. As part of the Core Backend team, you’ll work on the systems at the center of [Kalepa](https://himalayas.app/companies/kalepa): designing services, data models, pipelines, and evaluation loops. The goal is not just cleaner data, but an intelligence layer that makes better, faster, and more explainable decisions.

You’ll join a high-ownership team responsible for some of [Kalepa](https://himalayas.app/companies/kalepa)’s most business-critical infrastructure. Your work will make our data more complete, our decisions more transparent, and our products even more valuable.

### **You'll be right at home if you:**

- Have 8+ years of software engineering experience.

- Embody hustle and grit, you're excellent at your craft and relentless in pursuing it.

- Take full ownership of your work and drive projects to completion with minimal oversight.

- Communicate proactively, surfacing blockers, asking the right questions, keeping stakeholders in the loop.

- Thrive on experimentation: you're comfortable testing ideas, measuring results, and iterating quickly on problems no one has solved before.

- Have strong fundamentals in system design, debugging, and problem-solving.

- Know Python (our main stack), though we're open to strong candidates from other OO backgrounds.

- Have experience with serverless technologies (Lambda, EC2), asynchronous workflows, and cloud environments.

- Are comfortable with relational databases, ideally PostgreSQL.

- Bonus: experience with LLMs/generative AI, distributed systems.

### **What you’ll get: **

- Competitive salary (based on experience level*).

- Significant equity options package.

- Work with an ambitious, smart, global, and fun team to transform a $7T global industry.

- 20 days of PTO a year.

- Global team offsites (2021 - Playa del Carmen, 2022 - Rome, 2023 - Buenos Aires, 2024 - Lisbon, 2025 - Cartagena)

- Healthy living/gym stipend. Mobile phone bill stipend.

- Continuing education credits.

**The salary range listed is an estimate and will vary based on a variety of factors. Final compensation will be determined during the offer stage based on relevant experience, performance during the interview process, and geographic location, and may therefore differ from the posted range. *

Originally posted on [Himalayas](https://himalayas.app)
