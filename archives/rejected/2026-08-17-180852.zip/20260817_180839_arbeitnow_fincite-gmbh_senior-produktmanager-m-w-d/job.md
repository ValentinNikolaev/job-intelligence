# Senior Produktmanager (m/w/d)

Posted: 2026-08-17T14:09:58Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**Deine Herausforderungen**

- Du übernimmst die **End-to-End-Verantwortung** für unsere Wealth Advisory Platform – von der Produktidee über Discovery und Delivery bis hin zur erfolgreichen Einführung und kontinuierlichen Weiterentwicklung.
- Gemeinsam mit Kunden, Wealth Managern, internen Fachexperten und Stakeholdern entwickelst du ein tiefes **Kundenverständnis** und übersetzt Erkenntnisse in eine überzeugende Produktvision sowie nachhaltige Lösungen.
- Mit einem klaren Blick auf Kundennutzen und Unternehmensziele entwickelst, priorisierst und verantwortest du die **Produkt-Roadmap** und bringst Initiativen strukturiert durch den gesamten Produktentwicklungsprozess.
- Präzise **Anforderungen**, User Stories und Akzeptanzkriterien schaffen für Engineering und Design die Grundlage, um gemeinsam hochwertige Lösungen zu entwickeln.
- Als Sparringspartner für Engineering und Design triffst du fundierte **Produktentscheidungen**, löst Zielkonflikte pragmatisch und sorgst dafür, dass Qualität und Time-to-Market gleichermaßen im Fokus bleiben.
- Regulatorische **Compliance** ist für dich fester Bestandteil moderner Produktentwicklung – Anforderungen wie GDPR, DORA oder der EU AI Act denkst du von Beginn an mit.
- Mithilfe relevanter **Produktdaten** definierst du Erfolgskennzahlen, analysierst Nutzerverhalten und leitest daraus Maßnahmen für die kontinuierliche Weiterentwicklung unserer Plattform ab.
- In enger Zusammenarbeit mit internationalen und cross-funktionalen Teams innerhalb der Harvest-Gruppe sorgst du für eine nahtlose **Zusammenarbeit** über Unternehmensgrenzen hinweg.
- Ob Kunden, Geschäftsführung oder interne Stakeholder – deine **Kommunikation** schafft Transparenz, Vertrauen und Orientierung auf allen Ebenen.
- Dein oberstes Ziel ist die erfolgreiche Weiterentwicklung der Wealth Advisory Platform bei gleichzeitig reibungsloser **Kundenlieferung**.

**Das bringst du mit**

- Mehr als fünf Jahre Erfahrung im **Produktmanagement** von B2B-SaaS-Produkten – idealerweise im WealthTech-, FinTech- oder einem anderen regulierten Umfeld.
- Einen nachweisbaren **Track Record** bei der Entwicklung und erfolgreichen Einführung digitaler Produkte über den gesamten Produktlebenszyklus hinweg.
- **Leadership-Erfahrung** ist für diese Position zwingend erforderlich – du verstehst es, Teams zu führen, Menschen zu begeistern und Entscheidungen voranzutreiben.
- Du fühlst dich in internationalen sowie cross-funktionalen und cross-kulturellen **Arbeitsumfeldern** zuhause und bringst unterschiedliche Perspektiven erfolgreich zusammen.
- Agile Produktentwicklung, Product Discovery, Priorisierung und das Formulieren klarer **Anforderungen** gehören zu deinem Handwerkszeug.
- Ausgeprägte **Analysefähigkeiten** sowie ein datengetriebener und kundenorientierter Arbeitsstil zeichnen dich aus.
- Auch in komplexen oder dynamischen Situationen bewahrst du den Überblick und entwickelst pragmatische **Lösungen**.
- Mit deiner **Kommunikationsstärke** überzeugst du Entwicklerteams ebenso wie Executive Management und Kunden.

**Unser Angebot**

Wir sind ein etabliertes Produktunternehmen mit dem Spirit eines Startups. Dich erwarten Teamgeist, schnelle Entscheidungen und echte Freiheit, dein Arbeitsumfeld zu gestalten. Flexible Arbeitszeiten, Weiterbildungsbudgets und attraktive Benefits geben dir Raum für persönliche Entwicklung, Karrieremöglichkeiten und ein erfülltes Leben.

**Sprachkenntnisse**

**Verhandlungssichere Deutsch- und Englischkenntnisse**
Zusätzliche Sprachkenntnisse wie **Italienisch, Französisch oder Schweizerdeutsch **nice-to-have

**Ansprechpartner/in**

Julian Eder

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
