# Service Techniker (m/w/d) im Außendienst (Gebiet Stuttgart)

Posted: 2026-08-17T12:00:41Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**Deine Ideen, unsere Technik. Gemeinsam Menschen begeistern!**

Du willst nicht nur mitarbeiten, sondern auch etwas bewegen? Bei der **Me Group Germany GmbH** bekommst Du die Chance dazu. Wir sind ein 100%iges Tochterunternehmen der weltweit agierenden ME-Group. In Deutschland sind wir mit unseren Brands Fotofix und Revolution Waschstationen vertreten.

Wenn Du Lust hast, Teil eines Unternehmens zu sein, dass nicht stehen bleibt, sondern mit Dir gemeinsam die Zukunft entwickelt, dann bist Du bei uns genau richtig!

Für unser Team suchen wir ab sofort in Vollzeit einen **Service Techniker** **(m/w/d)** im Gebiet Stuttgart.

## Aufgaben

- Betreuung und regelmäßige Kontrolle unserer Automaten

- Durchführung von Wartungs-, Reparatur- und Instandhaltungsarbeiten

- Reinigung und Befüllung der Automaten mit Verbrauchsmaterialien

- Installation und Deinstallation verschiedener Automatentypen

- Direkter Ansprechpartner für unsere Kunden vor Ort

- Umsetzung von Werbemaßnahmen an den Automaten

- Digitale Dokumentation aller Tätigkeiten über unsere Service-App

## Qualifikation

- Flexibilität im Außendienst und in der Tagesplanung

- Abgeschlossene elektrotechnische Ausbildung (z. B. Elektriker, Elektroniker, Elektrotechniker)

- Befähigung und Berechtigung zur Durchführung von Arbeiten an elektrischen Anlagen (Arbeiten unter Spannung bzw. nach geltenden Vorschriften)

- Nachweisbare praktische Erfahrung im Umgang mit elektrischen Systemen

- Teamfähigkeit und Verantwortungsbewusstsein

- Sicherer Umgang mit PC und mobilen Anwendungen

- Wohnort innerhalb des Servicegebiets

- Führerschein der Klasse B sowie gute Deutschkenntnisse erforderlich

## Benefits

- Einen unbefristeten Arbeitsvertrag mit einer attraktiven Vergütung

- Ein abwechslungsreiches Aufgabengebiet in einem modernen und dynamischen Arbeitsumfeld

- Flache Hierarchien und Entscheidungswege

- Eine intensive Einarbeitung mit on-the-job-Training und gezielten Schulungen

- Mitgliedschaft bei Wellpass mit vergünstigten Konditionen

- Vermögenswirksame Leistung

- Exklusive Mitarbeiterrabatte über unser Corporate Benefits Programm

- Mitarbeiter werben Mitarbeiter Programm

- Bonus für erfolgreiche Empfehlungen für unsere Automaten

**Wir freuen uns auf Deine Bewerbung!**

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
