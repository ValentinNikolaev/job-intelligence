# IT-Systemintegrator (m/w/d) - 100% remote

Posted: 2026-08-17T13:01:26Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Du hast Spaß daran, IT-Systeme zu planen, einzurichten und dafür zu sorgen, dass bei unseren Kunden technisch alles rundläuft? Du löst Probleme gerne selbstständig und hast gleichzeitig Freude am direkten Kontakt mit Menschen? Dann bist du bei uns genau richtig.

FastRocket GmbH ist ein Software- und IT-Unternehmen aus Regen. Wir unterstützen mittelständische Unternehmen bei ihrer IT, entwickeln individuelle Softwarelösungen und begleiten unsere Kunden bei der Digitalisierung ihrer Prozesse.

Zum nächstmöglichen Zeitpunkt suchen wir einen **IT-Systemintegrator (m/w/d)** für den Raum **Regen/Deggendorf**.

Bei uns erwarten dich abwechslungsreiche IT-Aufgaben, direkter Kundenkontakt und ein Team, das Wert auf Zusammenarbeit, Eigenverantwortung und einen unkomplizierten Umgang miteinander legt.

## Aufgaben

- Installation, Konfiguration und Wartung von IT-Systemen und Arbeitsplätzen

- Planung, Einrichtung und Betreuung von IT-Infrastrukturen bei unseren Kunden

- Administration und Betreuung von Netzwerken, Servern und Cloud-Umgebungen

- Monitoring von IT-Systemen und frühzeitiges Erkennen sowie Beheben von Störungen

- Analyse und Lösung von technischen Problemen im Rahmen des IT-Supports

- Betreuung unserer Kunden bei technischen Fragen und Anliegen

- Umsetzung und Weiterentwicklung von IT-Sicherheitsmaßnahmen

- Unterstützung bei der Einhaltung von Datenschutz- und Sicherheitsrichtlinien

- Dokumentation bestehender Systeme, Prozesse und Lösungen

- Standardisierung und kontinuierliche Optimierung von IT-Prozessen

- Beratung unserer Kunden bei der Weiterentwicklung ihrer IT-Infrastruktur

- Selbstständige Planung und Umsetzung von IT-Projekten

## Qualifikation

- Abgeschlossene Ausbildung als **Fachinformatiker für Systemintegration (m/w/d)** oder eine vergleichbare Qualifikation

- **Berufserfahrung in der IT-Systemintegration** wünschenswert

- Gute Kenntnisse in der Administration von IT-Systemen, Netzwerken und Servern

- Erfahrung mit Cloud-Umgebungen und modernen IT-Infrastrukturen

- Verständnis für IT-Sicherheit, Datenschutz und Backup-Konzepte

- Eine strukturierte, lösungsorientierte und selbstständige Arbeitsweise

- Freude am direkten Kontakt mit Kunden und ein freundliches, verbindliches Auftreten

- Du kannst technische Zusammenhänge verständlich erklären und behältst auch bei Problemen einen kühlen Kopf

- Teamfähigkeit, Zuverlässigkeit und die Bereitschaft, dich kontinuierlich weiterzuentwickeln

- Sehr gute Deutschkenntnisse in Wort und Schrift

## Benefits

- **100 % Remote innerhalb Deutschlands**, mit Kunden- und Teamterminen vor Ort

- Arbeiten mit modernen Technologien und aktuellen IT-Lösungen

- Unbefristete Festanstellung

- Jährliches Weiterbildungsbudget von **1.000 €**

- Freie Hardwareauswahl mit einem Budget von **2.000 €**

- Remote und vor Ort Team-Events sowie gemeinsame Workations

- Flache Hierarchien und Du-Ansprache

- Abwechslungsreiche Aufgaben mit direktem Kundenkontakt

- Eigenverantwortliches Arbeiten mit viel Gestaltungsspielraum

- Ein kollegiales Team und kurze Entscheidungswege

Du bist IT-Systemintegrator (m/w/d) und möchtest nicht einfach nur Probleme lösen, sondern IT-Infrastrukturen aktiv mitgestalten und unsere Kunden bei ihren täglichen Herausforderungen unterstützen?

Dann freuen wir uns darauf, dich kennenzulernen. **Bewirb dich jetzt bei FastRocket und werde Teil unseres Teams!**

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
