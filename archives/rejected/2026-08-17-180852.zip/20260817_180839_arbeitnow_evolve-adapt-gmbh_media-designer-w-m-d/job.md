# Media Designer (w/m/d)

Posted: 2026-08-17T15:00:29Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**Essen (Rüttenscheid) | Vollzeit | E-Commerce Agentur**

Du hast Erfahrung in der Umsetzung von Corporate Designs, brennst für innovative Designideen und nutzt moderne KI-Tools gezielt, um tägliche Design- und Textprozesse effizienter zu gestalten?

Wir suchen einen kreativen Kopf mit einem Auge für's Detail, der KI als smarten Beschleuniger einzusetzen weiß (ohne das echte Designhandwerk zu ersetzen) und die Markenauftritte unserer Kunden aus den Bereichen Fashion, Food & Lifestyle auf dem Amazon-Marktplatz auf das nächste Level hebt.

## Aufgaben

- **Corporate Design & Layout:** Du gestaltest Bildmaterialien im Rahmen der Corporate Designs unserer Kunden und adaptierst Layouts auf verschiedene Formate und Sprachen.

- **Content & Bildbearbeitung:** Du übernimmst die zielgerichtete Bildrecherche, Bildbearbeitung sowie die Erstellung und strategische Planung von conversion-starken Produktbildern.

- **E-Commerce & SEO:** Du führst Keyword-Recherchen durch und erstellst KI- und SEO-optimierte Titel, Bullet Points und Produktbeschreibungen.

- **KI-Workflows:** Du setzt KI routiniert in der Bild- und Textproduktion ein (generative Bildbearbeitung/-erweiterung, LLM-gestütztes Texten/Recherche) und baust wiederverwendbare Prompts und Briefings auf.

- **Qualitätskontrolle & Finish:** Du prüfst KI-Output kritisch auf Markenton, Faktentreue sowie Amazon-Richtlinien und veredelst die Ergebnisse final von Hand (KI beschleunigt, entscheidet aber nicht).

## Qualifikation

- **Ausbildung/Studium:** Du hast ein abgeschlossenes Studium oder eine Ausbildung im Bereich Grafikdesign, Kommunikationsdesign oder Mediengestaltung.

- **Berufserfahrung:** Du bringst mehrjährige Berufserfahrung im Grafik- oder Kommunikationsdesign mit, idealerweise aus dem Agenturumfeld.

- **Tool-Fit:** Du besitzt sehr gute Kenntnisse in Figma sowie praxiserprobte Erfahrung in der Integration von KI-Tools in deinen täglichen Arbeitsalltag.

- **Arbeitsweise:** Du arbeitest extrem genau, gewissenhaft und hast einen hohen Qualitätsanspruch an deine eigene Arbeit.

- **Mindset:** Du hast Eigeninitiative, ein Auge für gutes Design, große Begeisterung für digitale Projekte und eine ausgeprägte Hands-On-Mentalität.

- **Sprachen:** Sehr gute Deutschkenntnisse in Wort und Schrift.

## Benefits

- **Zukunftsorientiertes Arbeiten:** Wir möchten das Thema KI-Integration und Prozessautomatisierung konsequent angehen, du gestaltest diesen Weg von Anfang an mit.

- **Verantwortung & Vertrauen:** Du arbeitest mit namhaften Marken aus Lifestyle, Food und Fashion mit großem Gestaltungsspielraum.

- **Work-Life-Balance:** Wir legen Wert auf eine nachhaltige Arbeitsweise, planbare Strukturen und eine gesunde Team-Dynamik.

- **Flexibilität:** Unser Büro liegt im Herzen von Essen-Rüttenscheid, aber wir bieten dir flexible Hybrid-Lösungen für deine Arbeitszeit.

- **Team-Kultur:** Ein motiviertes, professionelles Umfeld mit flachen Hierarchien und direktem Austausch.

- **Benefits:** Du kannst deinen Benefit frei wählen, je nachdem was besser zu dir passt: Urban Sports Mitgliedschaft oder givve Karte.

**Du hast Lust, unser Team in Essen-Rüttenscheid zu verstärken?** Wir freuen uns darauf, dich kennenzulernen! Schicke uns deine Bewerbungsunterlagen (Lebenslauf, Portfolio und Anschreiben) unter Angabe deines frühestmöglichen Eintrittstermins und deiner Gehaltsvorstellung.

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
