# Senior Solutions Engineer, New Business

Posted: 2026-08-17T14:55:08Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

***OUR MISSION***

**At Redwood, we empower our customers with lights-out automation for their mission-critical business processes.**

***ABOUT US***

Redwood Software is the leading orchestration platform for the autonomous enterprise, driving business transformation at the lowest total cost of ownership. Redwood empowers organizations to intelligently automate and orchestrate mission-critical business and IT processes across complex ERP, hybrid cloud, data and emerging agentic AI systems. Through its SaaS-first automation fabric—with AI embedded across the automation lifecycle—Redwood accelerates the path to autonomous operations. Backed by 30 years of experience and trusted by more than 50% of the Fortune 50, Redwood helps organizations unlock human potential to focus on innovation, growth and what’s next.

***CORE VALUES***

One Team. One Redwood

Make Your Own Weather

Obsess over Customer Success

Work the Problem

Be Curious

Own the Outcome

Respect Each Other

***YOUR IMPACT***

Gartner predicts that by 2029, 90% of organizations currently delivering workload automation will have transitioned to Service Orchestration and Automation Platforms (SOAPs) — a market expected to reach $4.9 billion by 2028. Redwood is the top-ranked vendor in Gartner's 2025 Critical Capabilities for SOAP, scoring #1 across all five use cases. We're expanding our Solutions Engineering team to meet that demand. In this role, you'll be the technical face of a category leader — helping enterprise prospects understand not just what Redwood does, but why it's the right answer in a market that's fundamentally changing.

- **Cover the full SOAP surface area.** Present and position Redwood's capabilities across all five Gartner-defined SOAP use cases — IT workload automation, IT workflow orchestration, data orchestration, citizen/self-service automation, and DevOps automation. You won't be a deep expert in all five on day one, but you'll develop enough fluency to lead discovery and qualify the right fit for each prospect.

- **Demonstrate Redwood's platform with AI fluency.** Deliver compelling technical presentations and live product overviews that connect Redwood's AI capabilities — AI-powered observability, intelligent job scheduling, and agentic orchestration — to concrete operational outcomes, not just platform features.

- **Use AI tools as a force multiplier.** Leverage LLM-based research, prompt-driven workflows, and AI productivity tooling as a standard part of how you work — accelerating demo preparation, account research, competitive analysis, and technical documentation.

- **Position confidently in a competitive market.** Develop a working understanding of the SOAP competitive landscape well enough to articulate Redwood's differentiation, handle objections live, and understand why you win and why you lose.

- **Drive technical evaluations hands-on.** Lead proof-of-concept work with prospects to validate use cases and prove out business outcomes — including light scripting (REST APIs, Python, bash) where needed to close technical gaps.

- **Enable Account Executives.** Provide technical insight, SOAP market context, and prospect feedback that sharpens messaging and accelerates new account acquisition.

- **Stay ahead of the SOAP and AI landscape.** Continuously deepen your understanding of how the market is evolving — from agentic AI and GenAI-powered automation to data pipeline orchestration and self-service automation — and bring that context into every prospect conversation.

- **Uphold Redwood's standards.** Maintain the highest ethical standards across all customer-facing work, representing the company with professionalism and technical credibility at every level of the prospect organization.

**What we're looking for in how you work:**

- **Resourceful:** You're constantly curious, proactively learning new AI tools and technical capabilities as part of how you operate — not as a side project.

- **Competitive:** You bring initiative, confidence, and a results-oriented mindset to every pursuit.

- **Goal-Oriented:** You set meaningful objectives, track them rigorously, and hold yourself accountable to outcomes.

- **Detail-Oriented:** You're organized and exercise sound judgment — able to manage multiple technical evaluations and sales cycles simultaneously without things falling through.

- **Communicator:** You can explain SOAP, AI, and automation concepts clearly to both a VP of Engineering and a CFO, and you know the difference matters.

- **Adaptable:** You're comfortable shifting priorities and handling complex, dynamic requirements in a fast-moving enterprise sales environment.

## YOUR EXPERIENCE

The most important thing we're hiring for is technical aptitude and intellectual curiosity. Domain knowledge can be taught — the ability to learn fast, think technically, and communicate clearly cannot.

**What we require:**

- **3+ years in a pre-sales, solutions engineering, or adjacent technical role** in enterprise software — Process Automation, ERP, Data Integration, Business Intelligence, ESB, or similar.

- **Technical aptitude.** Working knowledge of REST APIs and comfort with light scripting (Python, bash, or equivalent) sufficient to build simple integrations, validate technical scenarios, or debug issues in a demo environment. You don't need to be a software engineer — but you need to be comfortable in that world.

- **Demonstrated, hands-on use of AI tools in a professional context** — LLMs, prompt-based workflows, AI-assisted research, AI productivity tooling. This is a baseline requirement, not a differentiator. Bonus if you understand how AI capabilities like observability, intelligent automation, and agentic orchestration are being embedded into enterprise automation platforms specifically.

- **Familiarity with agentic AI and AI orchestration concepts.** You understand what multi-agent systems are, how LLMs are being embedded into enterprise workflows, and can hold a substantive conversation with technical buyers about where this is headed.

- **High-level ERP literacy** across core business processes: Financials, Procure to Pay, Plan to Build, Quote to Cash, Reporting, and Data Quality.

- **Ability to bridge technical depth and business value** — credible in a room with enterprise architects, while equally effective communicating ROI to executive stakeholders.

- **Bachelor's degree** from an accredited college or university.

**A head start — not a hard filter. We'll invest in the rest:**

- Prior exposure to workload automation, job scheduling, or enterprise orchestration platforms.

- Familiarity with SAP environments — S/4HANA, RISE with SAP, SAP BTP, or core SAP business processes. We operate deeply in this ecosystem and will develop this knowledge in you.

- Awareness of data orchestration concepts — ETL/ELT pipelines, DataOps workflows, data movement across hybrid environments.

- Familiarity with DevOps toolchains and how automation intersects with CI/CD, infrastructure provisioning, or SRE practices.

- Experience in Customer Success, Technical Support, or Professional Services.

*If you like growth and working with happy, enthusiastic over-achievers, you'll enjoy your career with us!*

**THE LEGAL BIT**
Redwood is an equal opportunity employer. Redwood prohibits unlawful discrimination based on race, colour, religion, sex, gender identity, marital or veteran status, age, national origin, ancestry, citizenship, physical or mental disability, medical condition, genetic information or characteristics (or those of a family member), sexual orientation, pregnancy or any other consideration made unlawful by regional or local laws. We also prohibit discrimination based on a perception that anyone has any of those characteristics or is associated with a person who has or is perceived as having any of those characteristics. All such discrimination is unlawful and will have a zero tolerance policy applied to it.

Redwood will comply with all local data protection laws, including GDPR when it comes to the handling and processing of personal data. Should you wish for us to remove your personal data from our recruitment database, please email us directly at -----

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
