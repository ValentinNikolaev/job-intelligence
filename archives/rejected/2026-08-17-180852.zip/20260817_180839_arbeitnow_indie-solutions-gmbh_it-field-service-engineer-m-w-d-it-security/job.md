# IT Field Service Engineer (m/w/d) IT-Security

Posted: 2026-08-17T14:01:14Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Du möchtest an technisch anspruchsvollen Systemen arbeiten, die eine echte gesellschaftliche Relevanz haben? Du suchst eine Position, die Dich sowohl an den Schreibtisch als auch an internationale Einsatzorte führt? Dann könnte diese Position genau das Richtige für Dich sein.

Für ein etabliertes Technologieunternehmen im Bereich IT-Sicherheit und Homeland-Security suchen wir einen **IT Field Service Engineer (m/w/d)** für den Standort Berlin. Du wirst Teil eines erfahrenen Teams und arbeitest an hochkomplexen Lösungen, die unter anderem an europäischen Grenz- und Kontrollpunkten zum Einsatz kommen.

## Aufgaben

- Du bist technischer Ansprechpartner für Kunden bei Fragen, Störungen und Problemen rund um die eingesetzten Grenzkontrolllösungen.

- Du unterstützt Kunden und Partner bei der Installation und Konfiguration spezialisierter IT-Sicherheitsprodukte.

- Während Installations-, Inbetriebnahme- und Rolloutphasen unterstützt Du die Projektteams direkt vor Ort, beispielsweise an Flughäfen.

- Du führst Wartungs- und Entstörungseinsätze durch und koordinierst bei Bedarf externe Partner und Zulieferer.

- Eingehende 2nd- und 3rd-Level-Supportfälle analysierst, qualifizierst und bearbeitest Du. Wenn eine weitere Expertise erforderlich ist, leitest Du die Themen gezielt an die zuständigen Fachbereiche weiter.

- Deine technischen Erkenntnisse und wiederkehrenden Problemstellungen bringst Du in die Zusammenarbeit mit Softwareentwicklung und Produktmanagement ein.

- Du installierst, administrierst und pflegst Referenzsysteme und sorgst für eine vollständige technische Dokumentation.

- Supportfälle dokumentierst Du strukturiert und trägst damit aktiv zum Ausbau und zur Pflege einer Wissensdatenbank bei.

## Qualifikation

- Eine abgeschlossene technische Ausbildung, idealerweise als Fachinformatiker (m/w/d) für Systemintegration oder eine vergleichbare Qualifikation.

- Berufserfahrung im **2nd- oder 3rd-Level-Support**, in der Systemadministration oder im **technischen Außendienst**.

- Erfahrung im Umgang mit komplexen IT-Systemen und anspruchsvollen IT-Infrastrukturen.

- Gute praktische Kenntnisse in **Windows- und Linux-Umgebungen** sowie im Umgang mit den entsprechenden Werkzeugen und Verfahren.

- Fundierte Kenntnisse im Bereich IT-Sicherheit.

- Ein professionelles, souveränes Auftreten und ein ausgeprägtes Verständnis für Service- und Kundenorientierung.

- Sehr gute Deutsch- und Englischkenntnisse in Wort und Schrift.

- Bereitschaft zu **regelmäßigen Dienstreisen**, auch innerhalb Europas.

- Bereitschaft zur Teilnahme an einer geregelten und entsprechend vergüteten **Rufbereitschaft**.

## Benefits

- **Technologie mit Sinn:** Du arbeitest an Lösungen, bei denen IT-Sicherheit und gesellschaftliche Relevanz unmittelbar zusammenkommen. Deine Arbeit trägt dazu bei, Sicherheits- und Kontrollsysteme an wichtigen europäischen Standorten zuverlässig zu betreiben.

- **Anspruchsvolle Aufgaben statt Routine:** Dich erwarten komplexe technische Fragestellungen, internationale Einsatzmöglichkeiten und Projekte, bei denen Deine Erfahrung und Dein analytisches Denken gefragt sind.

- **Teamarbeit auf Augenhöhe:** Du arbeitest in Teams, die auch anspruchsvolle und umfangreiche Projekte gemeinsam vorantreiben. Dabei bringst Du Deine Expertise ein und entwickelst Dich kontinuierlich weiter.

- **Individuelle Entwicklung:** Deine berufliche Entwicklung wird nicht nach einem starren Standardmodell geplant. Stattdessen werden Möglichkeiten geschaffen, die zu Deinen fachlichen Interessen und persönlichen Zielen passen.

- **Flexibles Arbeitsmodell:** Je nach Aufgabe stehen Dir verschiedene Arbeitsmodelle zur Verfügung – darunter Mobile Office, Shared Desk, Vertrauensarbeitszeit und flexible Teilzeitmodelle. Insgesamt gibt es zwölf Standorte in Deutschland.

- **Arbeiten innerhalb der EU:** Du kannst bis zu 20 Tage pro Jahr remote aus dem EU-Ausland arbeiten – ideal, wenn Du Arbeit und einen längeren Aufenthalt im europäischen Ausland verbinden möchtest.

- **Vergütung:** Das Jahreszielgehalt setzt sich aus einem attraktiven Fixgehalt und einer leistungsabhängigen Tantieme zusammen.

- **Zusätzliche Benefits:** Dich erwarten unter anderem Bike-Leasing, ein Firmenfitnessprogramm, ein vergünstigtes Jobticket und weitere Mitarbeiterangebote

Lass uns entspannt über weitere Details verständigen!

🎯Bewirb dich direkt: Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
