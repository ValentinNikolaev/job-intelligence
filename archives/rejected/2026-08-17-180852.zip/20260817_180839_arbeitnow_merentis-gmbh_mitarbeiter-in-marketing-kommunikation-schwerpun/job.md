# Mitarbeiter:in Marketing & Kommunikation - Schwerpunkt Gestaltung (all genders)

Posted: 2026-08-17T14:30:28Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

*Vollzeit (40 Std./Woche) | 35.000 € - 38.000 € / Jahr*

Bei MERENTIS gestalten wir seit 30 Jahren die digitale Zukunft unserer Kunden – mit smarten Lösungen, echter Beratungskompetenz und einem Team, das Digitalisierung lebt.

**Du bist zur Hälfte Kreativkopf und zur Hälfte Kommunikationsmensch:** Zum einen beinhaltet deine Aufgabe die visuelle Umsetzung unserer Themen – zum anderen besteht sie darin, diese Themen gemeinsam mit uns nach außen und innen zu bringen. D.h. Du gestaltest unsere Marketing- und Vertriebsunterlagen, begleitest gleichzeitig Events und Workshops, präsentierst auf diese Weise unsere Themen und bekommst die Möglichkeit, immer tiefer in unsere Produkte und Märkte einzutauchen.

**Kurz gesagt:** Wir suchen keine:n reine:n Grafiker:in und keinen klassischen Marketing-Allrounder, sondern einen **kreativen Kommunikationsmenschen**, der gestalten kann, gerne auf Menschen zugeht und Lust hat, unsere Produkte, Märkte und Themen wirklich kennenzulernen.

Zur Verstärkung unseres Marketingteams suchen wir zeitnah eine:n **Mitarbeiter:in Marketing & Kommunikation - Schwerpunkt Gestaltung**.

## Aufgaben

- Du gestaltest **Vertriebsunterlagen, Präsentationen, Marketingmittel, Intranet-Inhalte und weitere Print- und Digitalmedien** und behältst dabei unser Corporate Design sicher im Blick.

- Du entwickelst unser **CI und unsere visuellen Kommunikationsformate** weiter und bringst eigene Ideen und Trends in unsere Marketingarbeit ein.

- Du arbeitest dich in unsere **Produkte, Zielgruppen und Märkte** ein und entwickelst daraus ein Gespür dafür, welche Themen und Botschaften relevant sind und wie wir sie am besten vermitteln.

- Du arbeitest eng mit **Vertrieb, Geschäftsführung und weiteren internen Schnittstellen** zusammen und machst aus deren Themen verständliche, kreative und zielgruppengerechte Kommunikation außerdem sorgst Du für die passende

Visualisierung.

- Du begleitest **Events und Workshops** und bringst dich dabei nicht nur gestalterisch, sondern auch inhaltlich und organisatorisch ein.

- Du hast Lust, vor Menschen zu sprechen, unsere Themen zu präsentieren und **perspektivisch Workshops oder Programmpunkte zu moderieren**.

- Bei Veranstaltungen packst du auch praktisch mit an – ob bei der **Raumvorbereitung oder der Organisation von Materialien**.

- Du beobachtest aktuelle Entwicklungen und bringst **neue Ideen für Marketing, Kommunikation und Gestaltung** ein.

## Qualifikation

- Du hast eine **Ausbildung als Mediengestalter, Grafikdesigner oder in einem vergleichbaren gestalterischen Bereich** und bereits erste bis mehrjährige Berufserfahrung gesammelt.

- Die **Adobe Creative Cloud**, insbesondere InDesign, Illustrator und Photoshop, beherrschst du sicher.

- Du hast Interesse an **KI-gestütztem Marketing** und modernen Technologien

- Du hast ein gutes Gespür für **Design, Typografie, Bildsprache und Markenwirkung** und kannst ein Corporate Design sicher und kreativ umsetzen.

- Du bist **kommunikativ, offen und präsentationsfreudig** und hast Lust, nicht nur am Bildschirm zu arbeiten, sondern auch vor Menschen aufzutreten und unsere Themen zu vertreten.

- Du hast Interesse daran, **unsere Produkte und Märkte wirklich zu verstehen**, Zusammenhänge zu erkennen und daraus gute Kommunikationsideen zu entwickeln.

- Du arbeitest **selbstständig, strukturiert und zuverlässig**, bist gleichzeitig ein Teamplayer und packst auch bei organisatorischen Aufgaben gerne mit an.

- Gute Kenntnisse der **gängigen MS-Office-Anwendungen** sowie sehr gute Deutschkenntnisse in Wort und Schrift runden dein Profil ab.

## Benefits

- Eine tolle Unternehmenskultur

- Firmenhandy & mobile Hardware

- Firmenfitness

- SpenditCard

- Bikeleasing

- Betriebliche Altersvorsorge

- Regelmäßige Firmenevents und -veranstaltungen

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
