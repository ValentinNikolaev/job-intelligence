# Head of Marketing (m/w/d) mit Schwerpunkt E-Commerce

Posted: 2026-08-17T12:30:35Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Du möchtest Marketing nicht nur verwalten, sondern aktiv gestalten, weiterentwickeln und messbar zum Unternehmenserfolg beitragen? Du verbindest strategisches Denken mit einer ausgeprägten Hands-on-Mentalität und kennst die entscheidenden Hebel im E-Commerce?

Dann suchen wir dich als **Head of Marketing (m/w/d)** zur Führung und Weiterentwicklung unseres mehrköpfigen Marketingteams in Gersthofen, nahe Augsburgs, in Vollzeit.

**Deine Rolle bei uns**

Als Head of Marketing übernimmst du die **fachliche und disziplinarische Führung unseres Marketingteams** und verantwortest die strategische sowie operative Weiterentwicklung unserer Marketing- und E-Commerce-Aktivitäten.

Dein Schwerpunkt liegt auf der Entwicklung unseres digitalen Geschäfts: von Onlineshop und Performance Marketing über SEO und Content bis hin zu Social Media, CRM und Marketing Automation.

Dabei arbeitest du eng mit der Geschäftsführung sowie mit Vertrieb, Einkauf, IT, Kundenservice und Logistik zusammen

## Aufgaben

- Fachliche und disziplinarische Führung sowie Weiterentwicklung eines **mehrköpfigen Marketingteams**

- Entwicklung und Umsetzung unserer Marketing- und E-Commerce-Strategie

- Weiterentwicklung und Optimierung unserer Onlineshops und digitalen Vertriebskanäle

- Steuerung der Customer Journey und kontinuierliche Verbesserung der Conversion Rate

- Planung, Steuerung und Optimierung von Performance-Marketing-Kampagnen

- Verantwortung für SEA, Paid Social, Shopping, Retargeting und weitere digitale Kanäle

- Weiterentwicklung unserer SEO-, Content- und Social-Media-Strategie

- Steuerung von Newsletter, CRM und Marketing-Automation-Maßnahmen

- Planung und Umsetzung von Produkteinführungen, Verkaufsaktionen und saisonalen Kampagnen

- Weiterentwicklung unserer Markenpositionierung und digitalen Markenkommunikation

- Steuerung und Kontrolle des Marketingbudgets

- Aufbau und Weiterentwicklung eines aussagekräftigen KPI- und Marketing-Reportings

- Analyse von Umsatz, Conversion Rate, ROAS, CAC, Warenkorbwert, Wiederkaufrate und weiteren relevanten Kennzahlen

- Steuerung externer Agenturen, Freelancer und Dienstleister

- Identifikation neuer Markt-, Kunden- und Wachstumspotenziale

- Optimierung und Automatisierung bestehender Marketingprozesse

**Deine Führungsverantwortung**

Als Head of Marketing bist du nicht nur fachlicher Ansprechpartner, sondern übernimmst echte Führungsverantwortung.

Du:

- schaffst klare Rollen, Verantwortlichkeiten und Prioritäten,

- führst regelmäßige Team- und Mitarbeitergespräche,

- definierst Ziele und verfolgst deren Umsetzung,

- entwickelst deine Mitarbeitenden fachlich und persönlich weiter,

- steuerst Ressourcen und Kapazitäten,

- etablierst effiziente Prozesse und

- sorgst für eine eigenverantwortliche, strukturierte und ergebnisorientierte Zusammenarbeit.

Dabei schaffst du die Balance zwischen **Kreativität, Geschwindigkeit, Qualität und wirtschaftlichem Ergebnis**.

## Qualifikation

- Mehrjährige Berufserfahrung im Marketing mit ausgeprägtem Schwerpunkt auf **E-Commerce und Digital Marketing**

- Fundierte Erfahrung in der **Führung und Entwicklung von Mitarbeitenden**

- Erfahrung mit Onlineshops und digitalen Vertriebskanälen

- Sehr gutes Verständnis für Performance Marketing, SEO, SEA, Social Media und Content Marketing

- Sicherer Umgang mit Webanalyse, Tracking und Marketing-KPIs

- Erfahrung in Conversion-Optimierung und digitaler Customer-Journey-Entwicklung

- Analytisches Verständnis und die Fähigkeit, aus Daten konkrete Maßnahmen abzuleiten

- Erfahrung in der Planung und Steuerung von Marketingbudgets

- Unternehmerisches und wirtschaftliches Denken

- Strukturierte und eigenverantwortliche Arbeitsweise

- Kommunikations- und Durchsetzungsstärke

- Entscheidungsfreude und ein hohes Maß an Verantwortungsbewusstsein

Ein Studium im Bereich Marketing, E-Commerce, BWL, Medien oder Kommunikation ist von Vorteil. Entscheidend sind für uns jedoch vor allem deine **praktische Erfahrung, Führungskompetenz und dein Verständnis für erfolgreiches E-Commerce**.

**Was uns bei dieser Position wichtig ist?**

Wir suchen keine reine Konzept- oder Verwaltungsrolle.

Du solltest strategisch denken können, gleichzeitig aber nah am operativen Geschäft bleiben. Du erkennst Potenziale, setzt Prioritäten und sorgst gemeinsam mit deinem Team dafür, dass aus Ideen konkrete und messbare Ergebnisse entstehen.

Marketing bedeutet für dich nicht nur Reichweite und Markenbekanntheit. Du verstehst die Zusammenhänge zwischen **Marketinginvestition, Traffic,** **Conversion, Umsatz, Marge und Profitabilität**.

## Benefits

- Eine verantwortungsvolle Schlüsselposition mit direkter Anbindung an die Geschäftsführung

- Führung eines bestehenden **mehrköpfigen Marketingteams**

- Großer Gestaltungsspielraum bei der Weiterentwicklung unseres Marketings

- Die Möglichkeit, unsere E-Commerce-Strategie maßgeblich mitzugestalten

- Kurze Entscheidungswege und direkte Kommunikation

- Eigenverantwortliches Arbeiten mit sichtbaren Ergebnissen

- Abwechslungsreiche Aufgaben zwischen Strategie, Führung und operativer Umsetzung

- Zusammenarbeit mit verschiedenen Unternehmensbereichen und externen Partnern

- Ein dynamisches Umfeld, in dem neue Ideen ausdrücklich erwünscht sind

- Benefits: BAV, JobRad, EgyWellpass, Jobticket

**Klingt nach deiner nächsten Herausforderung?**

Dann freuen wir uns darauf, dich kennenzulernen.

Schick uns deine Bewerbung mit deinem **Lebenslauf, deinem möglichen Eintrittstermin und deiner Gehaltsvorstellung**.

Wir freuen uns auf deine Bewerbung als **Head of Marketing (m/w/d) – Schwerpunkt E-Commerce**.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
