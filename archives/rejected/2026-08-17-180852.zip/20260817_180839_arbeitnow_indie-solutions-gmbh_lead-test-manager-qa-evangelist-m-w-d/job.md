# Lead Test Manager / QA Evangelist (m/w/d)

Posted: 2026-08-17T13:30:32Z

## Rejection

- Category: role_mismatch
- Reason: title is an obvious mismatch for a backend profile

*Gestalte mit uns die Zukunft der Retail-IT!*

Du brennst für Qualitätssicherung, liebst es, Standards zu schaffen und Menschen für Exzellenz im Testmanagement zu begeistern? Dann ist das deine Gelegenheit, Verantwortung zu übernehmen und die Zukunft einer marktführenden Retail-Plattform mitzugestalten!

In dieser Schlüsselrolle als **Lead Test Manager / QA Evangelist (m/w/d)** übernimmst du die strategische und operative Verantwortung für die Qualität komplexer IT-Lösungen – von der Anforderungsanalyse bis zum Go-Live.

Wenn du Testmanagement nicht nur als Aufgabe, sondern als Berufung verstehst und Lust hast, in einem dynamischen Umfeld Standards zu prägen – dann freuen wir uns darauf, dich kennenzulernen.

## Aufgaben

- Du entwickelst Teststrategien, Prozesse und Standards, die Maßstäbe setzen

- Du bist Coach und Mentor für engagierte Tester:innen und förderst den QA-Nachwuchs

- Du etablierst moderne Testmethoden und Tools – von agilen Verfahren bis zur Testautomatisierung

- Du leitest und motivierst ein interdisziplinäres Testteam in einem innovativen Retail-Umfeld

- Du trägst mit Leidenschaft die QA-Philosophie im Unternehmen und in die Fachcommunity hinaus

- Du bringst dich mit Ideen und Impulsen aktiv in die Weiterentwicklung von Testframeworks ein

## Qualifikation

- 10+ Jahre Erfahrung im Testmanagement komplexer IT-Projekte (ideal im Handels- oder Retail-Bereich)

- Tiefes Verständnis für Testmethoden, Tools & Frameworks (z. B. Testautomatisierung, Systemtests, agile Verfahren)

- Leidenschaft dafür, Qualität als Kultur zu leben – du bist Treiber, Moderator und Evangelist

- Erfahrung im Coaching von Teams und in der Community-Moderation

- Analytisches Denken, strukturiertes Vorgehen und Begeisterungsfähigkeit

- Kommunikationsstärke und Souveränität im Umgang mit Stakeholdern auf allen Ebenen

- Sehr gute Deutsch- und Englischkenntnisse

## Benefits

- Hybrides Arbeiten, flexible Zeiten und 30 Urlaubstage

- Zwei Weiterbildungstage pro Monat für deine persönliche Entwicklung

- Zugang zu Schulungen, Konferenzen und internen Communities of Practice

- Team-Events, Sommer- & Weihnachtskonferenzen, gemeinsames Mittagessen

- Option auf Workation im europäischen Ausland

- Jobrad, Mobilitätsunterstützung und moderne Büros mit echter Feel-Good-Kultur

Lass uns entspannt über weitere Details verständigen!

🎯Bewirb dich direkt: Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
