# Senior Fullstack Entwickler (alle Geschlechter)

Posted: 2026-08-17T14:01:15Z

## Rejection

- Category: tech_stack
- Reason: Spring Boot is not a target stack

**Wer ist it-novum?**

it-novum ist das im deutschsprachigen Markt führende IT-

Beratungsunternehmen für Business Open Source. Als Konzerntochter der

Allgeier SE betreuen wir seit knapp 20 Jahren von unserem Hauptsitz in Fulda und unserer Niederlassung in Wien aus vorwiegend große Mittelstandskunden sowie Großunternehmen im deutschsprachigen Raum.

Wir leben das „Offene Tür“-Prinzip und die direkte Feedbackkultur. Bei uns sind die Hierarchien flach und die Entscheidungswege kurz. Uns ist die Förderung deines Talents wichtig: wir geben dir Freiraum, um dein Potential, deine

Interessen und persönlichen Stärken zu entfalten.

## Aufgaben

- Du entwickelst kundenspezifische Lösungen im Bereich Dokumentenmanagement und Prozessautomatisierung – im Backend (Java) und Frontend (moderne Web-Technologien)​

- Du arbeitest an Anwendungen, die Geschäftsprozesse digital abbilden und Fachbereiche in ihrer täglichen Arbeit unterstützen ​

- Du gestaltest performante, nutzerfreundliche Oberflächen für komplexe Fachanwendungen – keine reinen „Klickstrecken“, sondern echte Arbeitswerkzeuge​

- Du arbeitest im gesamten Entwicklungsprozess mit – von der Anforderungsaufnahme über Architektur und Entwicklung bis zum Go-Live ​

- Du integrierst Frontend und Backend zu konsistenten, skalierbaren Gesamtlösungen​

- Du denkst in End-to-End-Prozessen und sorgst dafür, dass Daten, Dokumente und Workflows nahtlos zusammenspielen ​

- Du arbeitest in Projekten mit fachlichem Tiefgang, z. B. in Verwaltung, Finanzdienstleistung oder anderen regulierten Umfeldern​

- Auch nach der Übergabe bleibst du involviert und entwickelst Lösungen gemeinsam mit dem Kunden weiter

## Qualifikation

- Du hast Interesse daran, dich in Themen wie Prozessautomatisierung, Workflows oder dokumentenbasierte Anwendungen einzuarbeiten​

- Du hast umfangreiche Erfahrung in der Java-Entwicklung (z. B. Spring / Spring Boot)​

- Du hast fundierte Kenntnisse in modernen Frontend-Technologien (z. B. Angular, React oder Vue) ​

- Du kennst dich mit relationalen Datenbanken aus ​

- Du bist ein flexibler Teamplayer mit Spaß an der Lösung komplexer Aufgaben​

- Du kommunizierst sicher auf Deutsch und gut auf Englisch

## Benefits

- Deine Arbeitszeiten kannst du flexibel während deiner Gleitzeit wählen​

- Du gestaltest dir deinen perfekten Arbeitsraum selbst – ob bis zu 100% remote, Hybrid oder ganz im Büro​

- Hardwareauswahl zwischen Apple und Lenovo Geräten sowie Betriebssystemauswahl zwischen Windows und MacOS​

- Unbefristeter Arbeitsvertrag​

- 30 Tage Urlaub​

- Onboarding: Wir möchten, dass du Dich ab dem ersten Tag wohl bei uns fühlst. Dafür haben wir ein strukturiertes Onboarding entwickelt und stellen Dir einen Buddy/ Mentor an Deine Seite.​

- Kontinuierliche Weiterentwicklung durch Seminare, Workshops und internen Wissenstransfer​

- Spannende und abwechslungsreiche Aufgaben mit der Nutzung von innovativen Technologien​

- Betriebliche Altersvorsorge, vermögenswirksame Leistungen

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
