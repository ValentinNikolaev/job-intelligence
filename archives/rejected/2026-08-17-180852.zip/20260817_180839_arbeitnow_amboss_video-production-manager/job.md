# Video Production Manager

Posted: 2026-08-17T14:40:16Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Hi! We are AMBOSS and we are looking for a **Video Production Manager** to join our team, and shape the future of medical education with us!

**About AMBOSS**

AMBOSS is a dynamic learning and clinical decision support tool committed to empowering medical professionals globally to deliver optimal care. Since our inception in 2012, we've harnessed cutting-edge technology to transform the way physicians acquire and apply scientific knowledge. Each AMBOSSian is passionate about being the champion of clinicians today - this motivates and unites us each day towards success. And what does success look like? When a clinician or med student tells us, “AMBOSS makes practicing medicine easier and enjoyable. I love what I do, and a big part is because of AMBOSS.”

**Why can this position be exciting for you?**

Explore and apply a range of visual storytelling techniques within our course content, combining creativity with technical execution to bring medical education to life for medical professionals. You will collaborate closely with professionals from creative, strategic, and medical backgrounds, gaining exposure to diverse perspectives while owning the production process end-to-end — from pre-production planning through the final cut.

## **You will:**

-

Bring AMBOSS's educational courses to life, producing, alongside medical experts, presentation-style content and practical medical videos that sit at the heart of our on-demand course offering.

-

Collaborate with our Medical Project Managers to plan and coordinate pre-production for course video shoots

-

Manage studio and location shoots, acting as the primary point of contact for the production team on shoot days

-

Own post-production end-to-end, from editing through final review, ensuring the output matches the creative and educational brief

-

Drive and maintain the in-house studio and its equipment

-

Define visual concepts from learning objectives, proposing formats and design solutions rather than only executing on brief

-

Collaborate with stakeholders to keep course video production on track

-

Develop your ability to independently manage the full production cycle for course videos, becoming a trusted go-to video producer for medical/content stakeholders after 6 months

## **You bring:**

-

Relevant work experience in video production, ideally within an educational or e-learning context

-

Distinct ability to translate learning objectives into strong visual storytelling

-

Structured work approach to ensure timelines and stakeholder expectations are consistently met

-

Proven track record as a hands-on video production professional — filming, lighting, and audio recording

-

Deep understanding of production tools and workflows, with a drive to keep improving them

-

Clear and effective communication skills and openness to feedback

-

Professional and consistent quality standards across every video delivered

-

Proficiency with Adobe Creative Suite (Premiere Pro, After Effects, Audition) and other relevant production software

## **You enjoy:**

-

Working in a structured environment and following visual templates

-

Exploring and implementing various visual storytelling techniques

-

Mastering each detail of a video to fit the highest production standard

-

Collaborating with cross-functional teams in an iterative production environment

-

Working closely with Medical Project Managers, translating their input into visual concepts

-

Taking ownership of a project end-to-end, from first idea to final cut

## **Benefits:**

**🌴 Rest & Time Off** (30 paid vacation days, AMBOSS holiday, personal purpose day and more)

**🥙Food & Office Comfort (**Daily healthy breakfast & lunch by in-house chef in Berlin HQ, AMBOSS daycare, work remotely from other office spaces in Cologne, Sardinia, Cape Town)

**🏃 Health, Fitness & Mobility** (Urban Sports Club -M plan- , Fitbit Versa 3, Deutschland Ticket…)

Check out the full list of benefits below:

[https://go.amboss.com/the-amboss-prescription-de](https://go.amboss.com/the-amboss-prescription-de)

We believe that diversity is a powerful driver of innovation and progress. That’s why we are committed to fostering an inclusive, respectful, and supportive environment where everyone—regardless of gender, age, ethnic or cultural background, religion, disability, sexual orientation, gender identity—is valued and given equal opportunity to thrive. We warmly welcome people of all backgrounds to help us fulfil our mission: empowering all medical professionals to provide the best possible care 🩺

Even if you don’t meet every single point in the job description, we still encourage you to apply. We’d love to hear from you!

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
