# Deputy Manager Defense and Automotive Products (m/f/d)

Posted: 2026-08-17T14:30:27Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

## Introduction

We are smartmicro, leading specialist in high-performance radar sensor technology. We design, develop and manufacture sensors and systems for autonomous driving, intelligent traffic infrastructure, as well as defense and airborne applications. Our mission is to make roads safer, enable autonomous driving in all-weather scenarios, optimize traffic flow for reduced travel times and to reliably and efficiently detect threats from drones and other aircraft.

We are looking for a deputy leader of our *Defense and Automotive* department, who will drive the development of our latest defense and automotive products, which are software-defined radar sensors, and contribute to delivering cutting-edge radar systems and solutions to our fast-growing customer base.

You will lead a team of ~15 engineers in the following fields:

- Smartmicro standard products mainstream development team (C-UAS sensors, altimeters and automotive sensors).

- Customer projects teams who make customer-specific C-UAS or altimeter products.

- Application-specific tracking, classification and sensor fusion software

- Software tool (i.e. for visualization and data logging).

- Data logging / system testing

- Languages and tools used: C, C++, bare metal, Linux, ROS2.
You will play a key role in growing and developing the team. Over time, you will have the opportunity to take over full leadership of the department.

## Your Tasks

- You are supporting the department manager and take over certain tasks directly

- You are responsible for coordinating projects and prioritizing tasks between the department and the embedded- and other software departments, with strong customer focus

- You will support the leadership of the teams within your department, fostering a strong culture of teamwork in collaboration with the group leaders and other departments

- This includes coaching, motivating, managing and giving technical guidance to the team members

- You should strive for effectiveness in using engineering resources and maintain high quality of the developed code

## Your Strengths

- Completed Master or PhD. in the field of software engineering, computer science or similar

- You have many years of experience in software technology, development methods & tools, software architecture, CI/CD, embedded Linux, C and C++

- Also, a deep understanding of embedded hard- and software

- Strong commitment to achieving project schedules and milestones, with the ability to inspire the same mindset across the teams

- You can show high social and leadership skills, next to a strong motivation and result-driven personality

- You have excellent communication skills, with the ability to take on mentoring roles and organize feedback

- Fluent English, German language skills would be a plus

## What you can expect from us

- **Innovation:** latest technologies, modern building and free charging of electric and hybrid electric vehicles

- **Pleasant working environment:** informal culture, motivated teams, short communication channels, room for active participation

- **Future-oriented workplace:** permanent employment and individual training opportunities

- **Attractive location:** located directly next to the highway and bus stop, with parking facilities for cars and bikes

- **Flexible working:** hybrid working (4 days office presence per week)

- **Activities:** team events, gym membership and more

- **Other benefits**

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
