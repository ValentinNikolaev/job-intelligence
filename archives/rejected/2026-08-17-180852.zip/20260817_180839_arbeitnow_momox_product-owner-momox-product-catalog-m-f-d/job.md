# Product Owner - momox Product Catalog (m/f/d)

Posted: 2026-08-17T17:00:25Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

## Our mission

**We are on a mission to save our planet - one second hand product at a time.**

We are looking for an experienced Product Owner to take ownership of the momox Product Catalog (MPC) - our central catalog system and single source of truth for product master data. MPC ingests, enriches and standardizes product data from external sources and distributes it to all downstream systems, including our buying platform, storefronts and marketplaces.

The Product Owner defines the product vision, strategy and roadmap for MPC and owns the end-to-end product data lifecycle - from ingestion, matching and enrichment to compliance and reliable data distribution.

Working closely with your engineering team, the role collaborates with Marketing, BI, Legal, the e-commerce onsite teams and marketplace operations to ensure a scalable, high-quality catalog that directly supports momox's growth.

## Your mission

- **Product Strategy & Roadmap:** Co-create a data-driven vision and product strategy and translate it into an actionable product roadmap. Define and prioritize initiatives based on business impact, customer value, and technical feasibility

- **Catalogue Sourcing & Distribution:** Drive the discovery and onboarding of external data sources (e.g. full-catalogue feeds and API integrations), while ensuring a reliable, performant data flow from MPC to all consumers

- **Data Quality & Product Matching:** Improve product matching across identifiers and ensure validity and correctness of product data and attributes

- **Internationalization & Localization:** Scale catalogue coverage and multi-language enrichment to support European expansion including relevant regulatory logic

- **Analytics & Monitoring:** Further develop and maintain product catalogue monitoring and reporting to track catalogue health and quality, define alerting, and drive data-informed prioritization

- **Stakeholder Management & Lateral Leadership:** Align with your stakeholders across Marketing, BI, Legal, and the consuming shops and marketplaces and lead the execution of cross-functional initiatives

## Your profile

- **Experience:** Several years of experience as a Product Owner, Product Manager, or in a comparable role, ideally with product data, PIM / catalogue, e-commerce or marketplace exposure

- **Data & Catalogue Expertise:** Hands-on understanding of master data / product information management identifiers and matching logic, data enrichment, and large-scale catalogues

- **Technical Fluency:** Comfortable working closely with engineers on APIs, data feeds and pipelines and data modeling; a working understanding of asynchronous / event-driven processing and its scalability trade-offs

- **Analytical Acumen:** Expertise in utilizing data and analytics tools (e.g. Looker, Grafana) to inform decisions and assess performance

- **Methodological Proficiency:** Skilled in agile methodologies, ideation techniques and backlog management, with the ability to write precise requirements and acceptance criteria

- **Interpersonal Skills:** Strong communication and stakeholder-management abilities, with a proven track record of leading cross-functional projects without direct authority

- **Language Skills:** Fluent English required

## You can look forward to

- Flexible working hours: We follow a hybrid work model with 20 in-office days per quarter to foster important personal interaction while enabling a modern, flexible way of working. The remaining days can be worked from home, and you also have the option to spend up to 6 weeks per year working from countries within EU. You’ll also benefit from flexible working hours to fit your individual needs.

- **Open work environment**:
We work together in a bright, open-plan office where even the few existing doors are always open. Our teams are motivated and open to new ideas. Bring your creativity to the table and make things happen! If you need a moment of peace, you can retreat to a cozy corner of the medimops library in the break room, or recharge with a game of foosball, table tennis, or PlayStation.

- **Reduced ticket for the public transport**: Save real money with the Germany or Job Ticket for the Berlin S-Bahn.

- **Company discounts**:
As a momoxian, you can look forward to a monthly voucher for our momox Fashion online shop, as well as medimops. Additionally, you benefit from numerous company discounts from our partners.

- **Office dogs**:
Our office dogs contribute to a relaxed work atmosphere and are always happy to receive some extra cuddles.

- **Team events**:
Having fun at work and celebrating our successes together are core to our values. That’s why we regularly come together at various events to connect, get to know each other better, and strengthen our team spirit.

- **Individual work environment**:
Design your ergonomic workspace just the way you like it – with height-adjustable desks and the laptop of your choice (MacBook or ThinkPad). If things get a bit noisy in the office, your Bose noise-cancelling headphones ensure uninterrupted focus. If needed, we can also provide you with an ergonomic chair or additional monitors for your home office.

- **Sustainability**: We love second-hand and incorporate our sustainable business idea into the office routine with simple methods like using eco-friendly supplies, double-sided printing, energy-saving modes on devices, waste separation, etc. In doing so, we take responsibility and integrate sustainability into all our activities.

- Training: momox is only as good as you. That's why you will find room and budget for your individual professional development with language classes, internal training, conferences, (online) courses and more.

- **1/2 day off on your birthday**: Celebrate your birthday with half a day of vacation! Come in later, leave earlier, or simply take an additional half day off to have your entire birthday free – provided your birthday falls on a regular working day. Additionally, you get half a day off on December 24th and 31st.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
