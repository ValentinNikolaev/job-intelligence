# Account Executive (w/m/d)

Posted: 2026-08-17T14:40:25Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**SKALAR – Wir bauen die digitale Steuerkanzlei der Zukunft**

Radikal einfach. Voll digital. 100% mandantenfokussiert.

Wir denken Steuerberatung komplett neu: einfacher, schneller und transparenter für Mandanten und Kanzleiteam zugleich.

Wo andere Kanzleien mit manuellen Prozessen, langen Wartezeiten und intransparenter Kommunikation kämpfen, bauen wir ein völlig neues Erlebnis - digital, proaktiv, KI-gestützt. Mit automatisierten Prozessen im Hintergrund und digitalen Schnittstellen zum Mandanten laufen repetitive Aufgaben weitgehend von selbst - damit du Zeit hast für das, was wirklich zählt: anspruchsvolle Beratung, Sonderfälle und strategische Mandantenfragen.

Der Unterschied zu anderen "Digitalkanzleien": Über die Hälfte unseres Teams sind Softwareentwickler. Du gestaltest direkt mit, was sie bauen - und damit, wie KI-gestützte Steuerberatung in dieser Branche überhaupt aussehen wird. Dein Steuerwissen prägt das Produkt, nicht nur dessen Anwendung.

Wir sind ein erfahrenes Gründerteam aus Steuerberatern, Digital-Unternehmern und Softwareentwicklern mit einem Exit-Track-Record von 140 Mio. €. Mit dir gemeinsam möchten wir eine der führenden Kanzleien Deutschlands aufbauen.

**DEINE ROLLE**

Als Account Executive verantwortest du unser Umsatzwachstum: Du sprichst mit Gründern, Geschäftsführern und CFOs mittelständischer Unternehmen, bewertest ihre Finanz- und Steuerarchitektur und überzeugst sie davon, ihre Steuern in unsere Hände zu legen. Die Nachfrage ist da – deine Aufgabe ist nicht Kaltakquise um jeden Preis, sondern die Richtigen auszuwählen und sicher abzuschließen.

Du arbeitest in einem engen Trio mit unserem Growth Manager und unserem Marketing Manager: Growth liefert dir Pipeline und Daten zu Kanälen und Lead-Qualität, Marketing die Inhalte und Stories, die deine Zielgruppe bewegen. Du bringst aus den Calls zurück, was Mandanten wirklich bewegt – und schließt damit den Loop. Parallel baust du den Sales-Prozess weiter aus: sauber dokumentiert, automatisiert, skalierbar. Dein Ziel: die Wahrnehmung von Steuerberatung vom verlängerten Arm des Finanzamts zum strategischen, modernen Partner zu verschieben.

## **DEINE AUFGABE**

### **PIPELINE & QUALIFIZIERUNG**

-

Qualifizierung eingehender Leads – steuerliche und technische Komplexität bewerten und Fit zum Ideal Customer Profile (ICP) prüfen

-

Gatekeeping: Wir onboarden nur Mandanten, denen wir eine herausragende Dienstleistung bieten können – du entscheidest mit

-

Saubere Dokumentation und Pipeline-Hygiene in HubSpot

### **DISCOVERY & CLOSING**

-

Discovery Calls auf C-Level – bestehende Buchhaltungs- und Steuerstrukturen analysieren, echte Pain Points der Geschäftsführung identifizieren

-

Verantwortung für den gesamten Deal-Cycle vom Erstkontakt bis zur Unterschrift

-

Offer- und Closing-Calls proaktiv treiben, Vertrauen über fachliche Kompetenz aufbauen

-

Strukturierte Übergabe ins Onboarding – gemeinsam mit Tax Operations

### **PROZESSARCHITEKTUR & AUTOMATISIERUNG**

-

Den Funnel konsequent aus Mandantenbrille hinterfragen: Wo wird das Erlebnis besser, wo werden wir intern effizienter?

-

Automatisierungen in HubSpot und KI-gestützte Sales-Tools bauen und weiterentwickeln

-

Anforderungen an unsere Softwareentwickler formulieren – du beschreibst das Problem, gemeinsam baut ihr die Lösung

## **WAS DU MITBRINGST**

-

Nachweisbarer Track Record im B2B-Vertrieb erklärungsbedürftiger Dienstleistungen oder komplexer Softwarelösungen an kleine und mittlere Unternehmen

-

Erfahrung darin, Sales-Strukturen aktiv mitzugestalten – statt ein fertiges Playbook abzuarbeiten

-

Souveräne Kommunikation auf C-Level: Du agierst als Berater und strategischer Sparringspartner

-

Solides Verständnis von Unternehmenssteuern – oder die klare Bereitschaft, es dir schnell anzueignen. Du musst beurteilen können, ob das Steuer-Setup eines Leads zu unserem operativen Modell passt

-

Hohe Tech- und Prozessaffinität: sicherer Umgang mit HubSpot; Erfahrung mit Sales-Automation oder Conversational-Intelligence-Tools ist ein starkes Plus

-

Verhandlungssicheres Deutsch (zwingend für Mandantengespräche), fließendes Englisch (Unternehmenssprache)

-

Lust, in einem schnell wachsenden Team mit hoher Eigenverantwortung und echtem Gestaltungsspielraum zu arbeiten

## **BENEFITS**

-

🎯 Volle Ownership über den Deal-Cycle – du entscheidest mit, wer Mandant wird

-

🤝 Cross-funktionale Zusammenarbeit – Hand in Hand mit dem GTM Team und unseren Softwareentwicklern

-

🚀 Ownership ab Tag 1 – Baue aktiv die Zukunft der 1 Bio. $ schweren Tax- & Accounting-Industrie mit

-

🧠 Steile Lernkurve – Arbeite Seite an Seite mit den klügsten und ambitioniertesten Köpfen Europas

-

👥 Smartes, ambitioniertes & lustiges Team – Direkte Zusammenarbeit mit einem erfahrenen Founding-Team (Exit-Track-Record 140 Mio. €), regelmäßige Team-Events, Lunches und mehr – globale Ambition mitten in München

-

🛠️ Modernes Tech-Setup – Digitale Prozesse, klare Strukturen, moderne Sales-Tools

-

💰 Kompetitives Gehaltspaket

-

📍 Büro im Herzen Münchens, top angebunden

-

🎁 3.000 € p.a. Benefitsprogramm + Firmenhandy

## **BEREIT, STEUERBERATUNG NEU ZU DEFINIEREN?**

Werde Teil von Skalar — und baue mit uns den Vertrieb einer der modernsten Kanzleien Deutschlands.

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
