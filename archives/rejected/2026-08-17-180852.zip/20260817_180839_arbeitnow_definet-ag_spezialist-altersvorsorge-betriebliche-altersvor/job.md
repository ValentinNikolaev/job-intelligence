# Spezialist Altersvorsorge/betriebliche Altersvorsorge (m/w/d)

Posted: 2026-08-17T14:01:14Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

DEFINET bietet einen Komplettservice für Finanzberatungsunternehmen. Mit rund 70 Mitarbeitern an unseren Leistungszentren in Eschborn & Hannover übernehmen wir für unsere Kunden alle Backoffice-Themen rund um die Vertriebsunterstützung, Abwicklung und IT.

Unseren Partnern bieten wir ein ganzheitliches Produktportfolio: Versicherungen, Investments, Finanzierungen, Immobilien, Sachwerte und vieles mehr. Unsere hoch qualifizierten Experten unterstützen Finanzberater:innen vollkommen unabhängig.

## Aufgaben

Qualifizierte Unterstützung der Kundenberater bei fachlichen Fragen zu Produkten und Konzepten

- Ausbau und Mitgestaltung des Geschäftsbereiches Altersvorsorge mit Engagement und vertrieblichen Ideen

- Erstellung professioneller Produktvergleiche und Rankings sowie individueller Absicherungskonzepte

- Ansprechpartner für Produktpartner im Bereich Altersvorsorge

- Vorbereitung und Durchführung von Schulungen und

- Weiterbildungen von Kundenberatern

## Qualifikation

- Abgeschlossene Berufsausbildung als Kaufmann für Versicherungen und Finanzen oder eine vergleichbare versicherungsfachliche Qualifikation

- Berufserfahrung sowie Kenntnisse oder praktische Berührungspunkte im Bereich Altersvorsorge – fundiertes Spezialwissen kannst Du bei uns weiter aufbauen

- Lernbereitschaft und Freude daran, Dich in komplexe fachliche Themen einzuarbeiten

- Ausgeprägte Kommunikationsfähigkeit und Interesse am Austausch mit unterschiedlichen Ansprechpartnern

- Freude an der Wissensvermittlung und Bereitschaft, Schulungen und Weiterbildungen durchzuführen

- Kontaktfreude, Teamfähigkeit sowie ein freundliches und souveränes Auftreten

- Selbstständigkeit, Eigenmotivation, strukturierte Arbeitsweise, Flexibilität

## Benefits

Flache Hierarchien | Team Spirit

Betriebliche Krankenversicherung

Betriebliche Altersversorgung

Mobile Office

Corporate Benefits

Weiterbildung | Entwicklung | Training

Komm‘ an Bord und bereichere unser professionelles, aber vor allem kollegiales Arbeitsumfeld! Wir bieten interessante Aufgaben und einen innovativen Arbeitsplatz mit modernster IT-Technik.

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
