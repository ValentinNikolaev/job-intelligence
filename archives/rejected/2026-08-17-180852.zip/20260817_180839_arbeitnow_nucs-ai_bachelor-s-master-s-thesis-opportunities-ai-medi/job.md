# Bachelor's & Master's Thesis Opportunities - AI, Medical Imaging & Clinical Software

Posted: 2026-08-17T14:30:19Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**About Us:**
Nucs AI is an innovative MedTech startup, transforming the clinical management of prostate cancer through cutting-edge AI-powered software solutions. Our mission is to revolutionize healthcare by delivering impactful, user-friendly tools that support healthcare professionals in diagnosing, treating, and monitoring patients.

**Why Join Us?**

-

**Contribute to Impactful Work**: Be a part of a startup that is focused on making a real difference in the healthcare field.

-

**Innovative Environment**: Collaborate with a passionate team, exploring the latest technologies and ideas.

-

**Real Clinical Impact**: Work on tools used by physicians at leading medical centers.

**About the Thesis Program:**

We're open to Bachelor's and Master's students who want to build at the intersection of AI, software, medical imaging, and clinical oncology. We don't have fixed thesis topics on a shelf. We talk, understand your profile, and shape something meaningful together.

**Possible directions:**

-

**Next-generation research interfaces with LLMs:** tools that let clinicians query, summarize, and reason over multimodal medical data.

-

**Front-end or back-end tools for medical imaging workflows:** the software layer radiologists and nuclear medicine physicians actually use.

-

**Deep learning for segmentation or classification:** applied work on PSMA PET/CT, SSTR imaging, and related modalities, with real clinical datasets.

**Who Should Apply?**

-

Currently enrolled in a Bachelor's or Master's program in Computer Science, Biomedical Engineering, Medical Informatics, AI/ML, or a related field

-

Self-directed and able to drive a research or engineering question independently

-

Excited about applied clinical AI - prior exposure to medical imaging or oncology is a plus, not a requirement

**What We Offer:**

-

A dynamic, fast-paced startup environment

-

The potential to work on innovative projects in the MedTech space

-

Flexible work arrangements with a focus on collaboration and results

**How to Apply:**
If you are interested in joining our journey, submit your application and CV. While we may not have an immediate role for you, we will review your information and reach out when relevant opportunities arise.

**
**

**Join Nucs AI and help shape the future of personalized cancer care!**

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
