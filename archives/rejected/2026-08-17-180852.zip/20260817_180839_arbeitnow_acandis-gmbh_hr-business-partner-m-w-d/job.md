# HR Business Partner (m/w/d)

Posted: 2026-08-17T13:01:40Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Sie möchten HR aktiv mitgestalten statt verwalten? Sie beraten Führungskräfte auf Augenhöhe, begleiten unsere internationalen Mitarbeitenden über den gesamten Employee Lifecycle und schätzen ein internationales Arbeitsumfeld? Dann freuen wir uns darauf, Sie kennenzulernen.

**Ihre Aufgaben:**

- Eigenverantwortliche Betreuung unserer internationalen Mitarbeitenden über den gesamten Employee Lifecycle

- Beratung und Unterstützung von Führungskräften in allen personalrelevanten Fragestellungen

- Steuerung des Recruiting-Prozesses von der Stellenausschreibung bis zum Onboarding

- Begleitung personeller Einzelmaßnahmen und arbeitsrechtlicher Themen

- Mitarbeit an Personalentwicklungsmaßnahmen und HR-Projekten

- Abstimmung mit internationalen Steuerbüros und externen Dienstleistern

**Unsere Anforderungen:**

- Abgeschlossenes Studium mit Schwerpunkt Personal oder vergleichbare Qualifikation

- Mehrjährige Berufserfahrung als HR Business Partner oder HR Generalist

- Sehr gute Deutsch- und Englischkenntnisse

- Freude an der Zusammenarbeit mit Menschen unterschiedlicher Kulturen

- Selbstständige und strukturierte Arbeitsweise

- Kommunikationsstärke sowie ausgeprägte Beratungskompetenz

**Was wir bieten:**

- Viel Gestaltungsspielraum und Eigenverantwortung

- Spannende HR-Arbeit über den gesamten Employee Lifecycle – ohne Zeiterfassung und Entgeltabrechnung

- Enge Zusammenarbeit in einem kollegialen HR-Team

- Eine zunächst befristete Position mit der Möglichkeit einer unbefristeten Übernahme

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
