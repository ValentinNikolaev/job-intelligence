# Mediengestalter:in / Grafiker:in in Teilzeit (all genders)

Posted: 2026-08-17T14:30:28Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

*Teilzeit (20 Std./Woche) | 31.500 € - 34.000 € / Jahr (Vollzeitäquivalent)*

Bei MERENTIS gestalten wir seit 30 Jahren die digitale Zukunft unserer Kunden – mit smarten Lösungen, echter Beratungskompetenz und einem Team, das Digitalisierung lebt.

Eine **kreative Teilzeitposition mit 20 Stunden pro Woche**, in der du dich auf das konzentrieren kannst, was du am besten kannst: **gestalten, Ideen entwickeln und unsere Marke visuell weiterbringen.**

Zur Verstärkung unseres Marketingteams suchen wir zeitnah eine:n **Mediengestalter:in / Grafiker:in**.

## Aufgaben

- Du sorgst dafür, dass unsere Marke und unsere Themen visuell überzeugen – von der ersten Idee bis zum fertigen Kommunikationsmittel.

- Du entwickelst und gestaltest **Print- und Digitalmedien für unsere Unternehmens-, Produkt- und Vertriebskommunikation** – von Präsentationen und Broschüren bis hin zu digitalen Inhalten und weiteren Marketingmaterialien.

- Du setzt unser **Corporate Design** sicher und konsistent um und entwickelst es gemeinsam mit uns weiter.

- Du unterstützt bei der Umsetzung von **Marketing- und Vertriebsaktionen** und entwickelst dafür passende visuelle Materialien.

- Du bereitest bestehende Inhalte für unterschiedliche Formate und Medien auf und sorgst für eine **professionelle und hochwertige Umsetzung**.

- Du bringst eigene **Gestaltungsideen** ein, beobachtest aktuelle Trends und hast Freude daran, bestehende Formate weiterzuentwickeln.

- Du gestaltest Inhalte für unser **Intranet und weitere digitale Kommunikationskanäle**.

- Du arbeitest eng mit **Marketing, Vertrieb und weiteren internen Schnittstellen** zusammen und setzt deren Anforderungen in kreative und zielgruppengerechte Lösungen um.

## Qualifikation

- Du hast eine **Ausbildung als Mediengestalter, Grafikdesigner oder in einem vergleichbaren gestalterischen Bereich** abgeschlossen und bereits erste Berufserfahrung gesammelt.

- Die **Adobe Creative Cloud**, insbesondere InDesign, Illustrator und Photoshop, beherrschst du sicher.

- Du hast Interesse an **KI-gestütztem Marketing** und modernen Technologien

- Du hast ein gutes Auge für **Gestaltung, Typografie, Farben, Bildsprache und Details** und ein ausgeprägtes Gespür für eine konsistente Markenwirkung.

- Du kannst ein bestehendes Corporate Design sicher anwenden und hast gleichzeitig Freude daran, **eigene kreative Ideen** einzubringen.

- Du arbeitest **selbstständig, strukturiert und zuverlässig** und behältst auch bei mehreren Aufgaben den Überblick.

- Du bist offen für Feedback, arbeitest gerne im Team und kannst Anforderungen verschiedener interner Ansprechpartner gut aufnehmen und umsetzen.

- Gute Kenntnisse der **gängigen MS-Office-Anwendungen** und sehr gute Deutschkenntnisse in Wort und Schrift runden dein Profil ab.

## Benefits

- Eine tolle Unternehmenskultur

- Firmenhandy & mobile Hardware

- Firmenfitness

- SpenditCard

- Bikeleasing

- Betriebliche Altersvorsorge

- Regelmäßige Firmenevents und -veranstaltungen

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
