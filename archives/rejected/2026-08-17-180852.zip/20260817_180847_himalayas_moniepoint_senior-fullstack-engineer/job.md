# Senior Fullstack Engineer

Posted: 2026-08-16T22:09:49Z

## Rejection

- Category: tech_stack
- Reason: role does not mention Go/Golang or PHP

### Who we are

[Moniepoint](https://himalayas.app/companies/moniepoint) Inc. is Africa’s all-in-one financial ecosystem, helping 10 million businesses and individuals access seamless payments, banking, credit, and business management tools since 2019.
As Nigeria’s largest merchant acquirer, [Moniepoint](https://himalayas.app/companies/moniepoint) Inc. powers most of the country’s point-of-sale (POS) transactions. Through its subsidiaries, [Moniepoint](https://himalayas.app/companies/moniepoint) Inc. processes $22 billion monthly for its customers while operating profitably.

### About the role

We’re looking for a Full-Stack Engineer to join the [Moniepoint](https://himalayas.app/companies/moniepoint) team. The ideal candidate has strong experience with Node.js and TypeScript, and is proficient in at least one object-oriented programming language (e.g., Java, C#, etc.). You’ll be building scalable backend services and intuitive frontend interfaces that power financial services used by millions. This role requires a problem-solver with a builder mindset and the ability to work across the stack to deliver high-impact features.

### Location: Remote (Full-time)

### What you’ll get to do

- Work with developers to design algorithms and flowcharts

- Produce clean, efficient code based on specifications

- Integrate software components and third-party programs

- Verify and deploy programs and systems

- Troubleshoot, debug and upgrade existing software

- Gather and evaluate user feedback

- Recommend and execute improvements

- Create technical documentation for reference and reporting

### To succeed in this role, we think you should have

- 7-10 years of experience as a Software Developer, Software Engineer or similar role

- 5+ years of MERN stack experience

- 2+ years of OOP language like Java, C# etc.

- Familiarity with Agile development methodologies

- Experience with software design and development in a test-driven environment

- Knowledge of coding languages (e.g. Javascript, Typescript) and frameworks/systems (e.g. ReactJS, Node.js, ExpressJs, Git)

- Experience with databases (MySQL, Mongo) and Object-Relational Mapping (ORM) frameworks

- Ability to learn new languages and technologies

- Excellent communication skills

- Resourcefulness and troubleshooting aptitude

- BSc/BA in Computer Science, Engineering or a related field

### Some of the technologies you’ll get to work with

- Javascript & Typescript

- ReactJS and NodeJS

- Docker and Kubernetes

- MySQL, MSSQL, Redis

- Microservices architecture on AWS

### What we can offer you

- Culture -We put our people first and prioritize the well-being of every team member. We’ve built a company where all opinions carry weight and where all voices are heard. We value and respect each other and always look out for one another. Above all, we are human.

- Learning - We have a learning and development-focused environment with an emphasis on knowledge sharing, training, and regular internal technical talks.

- Compensation - You’ll receive an attractive salary, pension, health insurance, annual bonus, plus other benefits.

Originally posted on [Himalayas](https://himalayas.app)
