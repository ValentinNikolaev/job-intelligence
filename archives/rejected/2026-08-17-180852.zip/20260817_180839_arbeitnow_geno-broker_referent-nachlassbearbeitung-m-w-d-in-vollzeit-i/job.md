# Referent Nachlassbearbeitung (m/w/d) in Vollzeit in der DZ BANK Gruppe

Posted: 2026-08-17T13:01:41Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Die GENO Broker GmbH ist der Online Broker innerhalb der Genossenschaftlichen FinanzGruppe. Als 100-%ige Tochtergesellschaft der DZ BANK AG kooperieren wir u.a. mit den Volks- und Raiffeisenbanken im Wertpapiergeschäft. Dabei bieten wir den Kunden unserer Kooperationsbanken günstige Depots und eine innovative Handelsplattform an - digital und in der Filiale vor Ort.

## Aufgaben

- Du bearbeitest eigenverantwortlich Nachlassfälle unter Einhaltung regulatorischer und interner Vorgaben

- Du stellst eine termingerechte, qualitativ hochwertige und serviceorientierte Auftragsbearbeitung sicher

- Du bist Ansprechpartner für Berater unserer Kooperationsbanken bei Fragestellungen rund um die Nachlassbearbeitung

- Du wirkst aktiv an der Weiterentwicklung und Optimierung von Prozessen in deinem Aufgabenbereich mit

## Qualifikation

- Du verfügst über eine bankfachliche Ausbildung oder eine vergleichbare Qualifikation

- Du hast idealerweise bereits erste Erfahrungen in der Nachlassbearbeitung gesammelt

- Du besitzt eine hohe IT-Affinität

- Erste Erfahrungen im Umgang mit agree21 und WPdirect sind von Vorteil

- Du hast eine ausgeprägte Hands-On Mentalität, bist flexibel und arbeitest sehr gerne im Team, dabei bist Du offen für Innovationen und bringst gerne eigene Ideen ein

- Zuverlässigkeit und Verantwortungsbewusstsein, sowie eine hohe soziale Kompetenz sind wesentliche Pfeiler Deiner Arbeitsweise

## Benefits

Neben einer vielseitigen und abwechslungsreichen Tätigkeit im Herzen von Frankfurt wirst Du Teil eines dynamischen und motivierten Teams, das die Umsetzung eines innovativen Geschäftsmodells mit Fokus auf das Wertpapiergeschäft verfolgt. In diesem Rahmen bieten wir Dir Freiraum für Deine persönliche Entwicklung und fördern Dich dabei über gezielte Fortbildungsmaßnahmen. Durch das Leben flacher Hierarchien kannst Du die Entwicklung des GENO Broker mitgestalten.

- Mobiles Arbeiten – gerne stellen wir auch die benötigte Hardware dafür

- Nutzung der DZ BANK Corporate Benefits

- Vermögenswirksame Leistungen

- eGYM-Wellpass für 30 EUR Eigenbeitrag

- Kostenfrei zur Verfügung gestelltes Deutschlandticket

- Nutzung unseres JobRad-Angebots

- Bezuschusste Mitarbeiterkantine der DZ BANK

- Firmenevents sowie ein kostenloses Angebot an Kaffee und Wasser

- Vorteile eines Mitarbeiters der genossenschaftlichen Finanzgruppe

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
