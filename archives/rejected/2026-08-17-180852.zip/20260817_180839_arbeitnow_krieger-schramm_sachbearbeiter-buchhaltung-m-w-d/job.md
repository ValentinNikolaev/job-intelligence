# Sachbearbeiter Buchhaltung (m/w/d)

Posted: 2026-08-17T13:30:33Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Wer wir sind

Werde Teil eines Teams voller Leidenschaft. Warum wir täglich mit Motivation und Leidenschaft unserer Arbeit nachgehen? Wir schaffen Raum für Gesundheit und nachhaltige Lebensqualität. Gemeinsam bauen wir heute die Stadt von morgen. In der Krieger + Schramm Gruppe findest Du einen modernen Wohnungsbau-Spezialisten mit Niederlassungen in Dingelstädt/Eichsfeld, Lohfelden/Kassel, Frankfurt/Main, Berlin und München. Wir entwickeln, planen und bauen wohngesunde Wohnungsbauprojekte zwischen 10 und 150 Wohneinheiten - dabei stehen sowohl Kundennutzen als auch Nachhaltigkeit im Mittelpunkt. **Gemeinsam schaffen wir Großes - gemeinsam bauen wir heute die Stadt von morgen!**

## Aufgaben

- Bearbeitung, Verteilung und Nachverfolgung von Eingangsrechnungen

- Verwaltung von Lieferscheinen, Nachweisen, Bescheinigungen etc.

- Unterstützung bei der Auszahlung von Sicherheitseinbehalten

- Erfassung und Verwaltung von Bürgschaften

- Anlage und Pflege von Kreditoren- und Adressstammdaten

- Bearbeitung von Lieferanten- und Nachunternehmeranfragen sowie Mahnungen

## Qualifikation

- Abgeschlossene kaufmännische Ausbildung oder vergleichbare Qualifikation

- Erfahrung in der Buchhaltung, Verwaltung oder kaufmännischen Sachbearbeitung

- Sicherer Umgang mit MS Office (insbesondere Outlook, Word, Excel, TEAMS)

- Erfahrungen mit Dokumentenmanagementsystemen (z. B. DocuWare) und ERP-Systemen

- Hohes Maß an Zuverlässigkeit + Teamfähigkeit

- Selbstständige, strukturierte und gewissenhafte Arbeitsweise

## Benefits

- Ein Umfeld, in dem sich junge und auch berufserfahrene Kollegen wohlfühlen und sich einbringen können

- Eigenverantwortliche Aufgaben mit individuellen Entwicklungs- und Weiterbildungsmöglichkeiten

- Strukturierte Prozesse und ein modernes Rechnungswesen

- Wertschätzende Zusammenarbeit in einem kollegialen Team mit kurzen Entscheidungswegen

- Attraktive Benefits, u.a. Vertrauensarbeitszeit, betriebliche Altersvorsorge, moderne Arbeitsmittel, Bike-Leasing, Gesundheitsmanagement, Wellpass, Gewinn- und Kapitalbeteiligung, E-Ladestation zur freien Nutzung u.v.m.

Du hast Interesse?Dann bewirb Dich jetzt mit Deinen Bewerbungsunterlagen per E-Mail an Michael Fuhlrott:

Krieger+Schramm GmbH & Co. KG

Neue Str. 12

37351 Dingelstädt

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
