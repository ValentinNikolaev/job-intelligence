# Onbarding Engineer

Posted: 2026-08-17T14:40:21Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**What you’ll do**

-

Own onboarding outcomes against success metrics and customer KPIs (quality, reliability, time-to-value)

-

Execute the initial onboarding cycle using internal tools, then **revisit and iterate** to improve quality as new data and edge cases appear

-

Validate input data quality and flag issues early (camera angle, occlusion, anonymization, variance, missing detections)

-

Detect and document edge cases and SOP/process variance; grow a diverse dataset and keep it up to date

-

Communicate progress, metrics movement, and blockers clearly to stakeholders; propose concrete next steps

-

Improve the onboarding process over time: checklists, docs, templates, and **suggestions for tool improvements** based on real usage

-

Coordinate with installation teams to ensure camera setups support reliable onboarding and cross-station consistency

**You are**

-

2–5 years experience in a structured execution role (implementation, QA, solutions engineering, ops/industrial engineering, data ops, etc.)

-

Metrics-minded: you can define “good”, track it, and drive iteration until it improves

-

Detail-oriented and reliable with process execution (no skipped steps, good documentation hygiene)

-

Fast, concise communicator who escalates early and clearly

-

Strong ownership mindset: you drive onboarding to completion and keep improving it post go-live

-

Comfortable with technical systems (ML depth not required, but you can reason about symptoms and inputs)

-

Manufacturing/process exposure is a strong plus

#LI-Hybrid #LI-SP1

**What we offer**

Employee Share Options Program for all permanent employees*

An increasing benefits list: currently includes Urban Sports club and quarterly team retreats.

Be on the forefront in defining what artificial intelligence means in manufacturing

Gain hands-on experience in working in an AI-first software company

Supportive and inclusive culture that values diversity and promotes the advancement of underrepresented groups within the company

Collaborate with a diverse (currently more than 10 nationalities) and talented team, working on cutting-edge projects with real-world impact

Network with professionals and leaders in the field, opening doors to potential future career opportunities

We have a very flat hierarchy, open 360° feedback, and flexible working hours

Ethics⚖: We are committed to developing ethical AI software

**Don't meet all the requirements?**

*Almetra is committed to creating a workplace that is diverse, fair, and inclusive. We encourage candidates from all backgrounds, even if they do not meet every qualification, to submit their application. We firmly believe that having a team with diverse perspectives only strengthens our company and drives innovation. Our commitment also extends to providing an accessible environment for everyone, including those with disabilities. Please let us know if you require any accommodations during the application process or while working with us, and we will do our best to support you.*

**Only full-time, permanent roles are eligible for stock options. Part-time roles, contract roles, work-student, internships and freelance roles are not eligible for stock options.*

Compensation: €55K – €68K • Offers Equity

- • €55K – €68K • Offers Equity

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
