# Technischer Projektkoordinator (m/w/d) Smart Locker Systeme

Posted: 2026-08-17T15:30:29Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

🌱 Auf der Suche nach einer beruflichen Herausforderung mit Mehrwert für **Gesellschaft & Klima?**

Du hast Erfahrung in der technischen Koordination und möchtest nicht nur vom Schreibtisch aus steuern, sondern auch draußen anpacken?

**Dann lies weiter!**

Der Arbeitgeber ist ein **Smart City Unternehmen** mit der Mission, den CO₂ Ausstoß auf der letzten Meile von Paketzustellungen zu reduzieren.

Wie? Als Marktführer betreibt das Unternehmen das größte anbieterneutrale Smart Locker Netzwerk im deutschsprachigen Raum.

🙏 Win win Szenario: Höhere Lebensqualität & Flexibilität für Bewohner:innen UND Entlastung für E Commerce und Paketdienstleister.

**Werde Teil der Mission:**

Sorge dafür, dass neue Standorte reibungslos umgesetzt werden und bestehende Infrastruktur technisch stabil bleibt.

🔍 Als **Technischer Projektkoordinator für die Region München**

## Aufgaben

**Du verantwortest die technische Umsetzung und Betreuung der Smart Locker Infrastruktur in deiner Region.**

🔍 Das heißt konkret:

- Perspektivisch erfolgt die **Koordination** der Errichtung neuer Standorte in enger Zusammenarbeit mit externen Gewerken.

- Nach dem Aufstellen liegt der **Fokus auf der Steuerung von Wartungs- und Instandhaltungsarbeiten** sowie der Sicherstellung definierter Service Level Agreements.

- Wiederkehrende Fehlerbilder werden analysiert, dokumentiert und gemeinsam mit internen sowie externen Partnern nachhaltig behoben.

- Die **Zusammenarbeit mit Hardwarelieferanten** umfasst vor allem die strukturierte Bereitstellung technischer Informationen.

- Um die Nähe zum Produkt zu gewährleisten, ist **ein fester Außendiensttag pro Woche** vorgesehen, an dem Fehler an Lockern in Wohnortnähe eigenständig behoben werden.

- Zusätzlich gehört die **Einweisung und Schulung externer Gewerke** sowie die Qualitätssicherung der Umsetzung zum Verantwortungsbereich.

## Qualifikation

- Mehrjährige Erfahrung in der **technischen Koordination oder Projektumsetzung**, z. B. im **Elektro, Bau oder Infrastrukturumfeld** + einer Abgeschlossenen **Technischen Ausbildung**

- Organisationsgeschick zur Überwachung von Projektfortschritten

- Erfahrung in der Fehleranalyse und strukturierten Dokumentation

- **Führerschein Klasse B**

- Sehr gute Deutschkenntnisse sind erforderlich

- **Wohnort in der Region München**

- **Nice to have:**

- Erfahrung im Remote Arbeiten oder mit Dashboards zur Infrastrukturüberwachung

## Benefits

- Flexibles Arbeiten aus dem Homeoffice in der Region Hamburg/Hannover oder München

- **100 % remote** mit einem festen Außendiensttag pro Woche

- Ein **qualifikationsabhängiges Mindestjahresgehalt** **ab** 50.000€ + **zusätzlichem Jahresbonus** bei Zielerreichung

- Ein **Firmenfahrzeug** (VW ID 5) zur privaten Nutzung

- **Work Life Balance** UND Verantwortung: Flexible Arbeitszeitgestaltung im Rahmen der Service Level Agreements

- **Startup Spirit**, flache Hierarchien & Austausch auf Augenhöhe 👀 hier wird wirklich zusammengearbeitet

- Ein wachsendes Operation Team mit Entwicklungsperspektive und zahlreiche Weiterbildungsmöglichkeiten

- **Strukturiertes Onboarding** und enger Austausch mit erfahrenen Kollegen in Deutschland und Österreich

- Events wie Firmenfeiern oder spontane Afterwork Meet Ups: für dich ist sicher etwas dabei.

- Ein sicherer Arbeitsplatz in einem stark wachsenden Unternehmen mit nachhaltiger Mission

- 30 Tage Urlaub bei unbefristetem Vertrag, Bikeleasing & EGYM Wellpass

- **Du wünschst dir einen Benefit, der hier nicht aufgeführt ist? Dieser Arbeitgeber ist offen für deine Wünsche! 🌼**

Du möchtest für ein Unternehmen arbeiten, das Nachhaltigkeit nicht nur kommuniziert, sondern aktiv lebt?

**Dich reizt es, Infrastrukturprojekte technisch mitzugestalten und Verantwortung zu übernehmen?**

🎯 Dann sende uns deinen Lebenslauf.

Wir geben dir gern in einem kurzen Telefonat alle weiteren Infos & Insights zum Unternehmen und zur Rolle als Technischer Projektkoordinator.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
