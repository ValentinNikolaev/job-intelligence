# ERP-Consultant (m/w/d)

Posted: 2026-08-17T15:00:28Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Als ERP-Consultant bei apia verbindest du betriebswirtschaftliche Abläufe mit den Möglichkeiten moderner Unternehmenssoftware. Du arbeitest eng mit mittelständischen Kunden zusammen, analysierst ihre Prozesse und begleitest die Einführung sowie Weiterentwicklung von Proalpha.

## Aufgaben

Du sorgst dafür, dass aus komplexen betrieblichen Anforderungen klare, digitale und praktikable Prozesse entstehen. Dabei bist du fachlicher Berater, Projektbegleiter und Ansprechpartner für unsere Kunden.

- Analyse bestehender Geschäfts- und Produktionsprozesse

- Aufnahme und Strukturierung fachlicher Kundenanforderungen

- Beratung rund um Proalpha ERP

- Abbildung von Prozessen aus Produktion und Fertigung im ERP-System

- Beschäftigung mit Produktions- und Lagerlogistik

- Mitwirkung bei der Restrukturierung und Optimierung von Abläufen

- Dokumentation von Prozessen, Anforderungen und Lösungskonzepten

- Vorbereitung und Durchführung von Workshops

- Unterstützung bei ERP-Einführungen und Systemerweiterungen

- Schulung und Begleitung der späteren Anwender

- Abstimmung mit Kunden, Projektverantwortlichen und internen Fachbereichen

- Begleitung der Kunden auch nach der eigentlichen Einführung

## Qualifikation

- Verständnis für betriebswirtschaftliche Geschäftsprozesse

- Kenntnisse aus Produktion, Fertigung, Produktionsplanung, Logistik oder Warenwirtschaft

- Interesse an ERP-Systemen und digitaler Prozessgestaltung

- Analytisches und strukturiertes Denken

- Fähigkeit, komplexe Zusammenhänge verständlich zu erklären

- Selbstständige und verantwortungsbewusste Arbeitsweise

- Kommunikationsstärke und ein verbindliches Auftreten

- Freude an der Zusammenarbeit mit Kunden und Kollegen

- Sehr gute Deutschkenntnisse

- Sicherer Umgang mit gängiger Standardsoftware und digitalen Kommunikationswerkzeugen

## Benefits

- Eigenverantwortliches Arbeiten: Du erhältst den Freiraum, Aufgaben selbstständig zu strukturieren, Entscheidungen vorzubereiten und Projekte aktiv mitzugestalten.

- Flache Hierarchien: Kurze Abstimmungswege ermöglichen schnelle Entscheidungen und einen direkten Austausch mit Kollegen und Verantwortlichen.

- Flexible Arbeitsgestaltung: Abhängig von Aufgabe, Projekt und Abstimmung im Team kann Arbeit flexibel organisiert werden. Präsenz und mobiles Arbeiten sollen sinnvoll miteinander verbunden werden.

- Fundierte Einarbeitung: Du wirst fachlich und methodisch in deine Aufgaben eingearbeitet. Dazu gehören der direkte Austausch im Team, praktische Projektarbeit und Schulungen.

- Fachliche Weiterentwicklung: Neue Lösungen, Technologien und Kundenanforderungen sorgen dafür, dass du dein Wissen kontinuierlich erweitern und eigene fachliche Schwerpunkte entwickeln kannst.

- Offene Zusammenarbeit: Informationen, Erfahrungen und Herausforderungen werden im Team offen besprochen. Gute Ergebnisse entstehen nicht durch Einzelkämpfer, sondern durch verlässliche Zusammenarbeit.

Du musst nicht bereits jeden Bereich von Proalpha beherrschen. Entscheidend sind dein Prozessverständnis, deine Lernbereitschaft und deine Fähigkeit, dich in neue fachliche Zusammenhänge einzuarbeiten.

Wir freuen uns auf deine Bewerbung!

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
