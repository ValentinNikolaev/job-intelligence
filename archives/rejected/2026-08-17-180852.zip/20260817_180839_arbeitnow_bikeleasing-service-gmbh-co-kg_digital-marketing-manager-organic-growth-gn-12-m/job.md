# Digital Marketing Manager – Organic Growth (gn), 12 Monate Elternzeitvertretung mit Option auf Verlängerung

Posted: 2026-08-17T12:30:33Z

## Rejection

- Category: tech_stack
- Reason: role does not mention Go/Golang or PHP

## Deine Aufgaben

Die Bikeleasing-Gruppe ist eines der führenden Unternehmen rund um Arbeitgeber-Mobilitätslösungen und Dienstradleasing. Mit unseren Marken gestalten wir moderne Arbeitswelten und wachsen dabei kontinuierlich weiter. In der Rolle als **Digital Marketing Manager – Organic Growth (gn)** übernimmst Du eine zentrale Funktion im Bereich organisches Wachstum und trägst aktiv dazu bei, dass unsere Marken Bikeleasing und Probonio in Suchmaschinen, auf der Website und in relevanten Zielgruppen sichtbar und wirksam sind. Dabei arbeitest Du eng mit Sales, Produkt, Data und Automation zusammen und kannst Deine Expertise in SEO, GEO, CRO und Content gezielt einbringen und weiterentwickeln. Wenn Du Lust hast, Verantwortung zu übernehmen, Dinge datengetrieben voranzutreiben und in einem professionellen Umfeld mit kurzen Entscheidungswegen zu arbeiten, bist Du bei uns genau richtig. Klingt gut? Dann freuen wir uns darauf, Dich kennenzulernen.

- Du pflegst und entwickelst zentrale Website-Seiten weiter – von Produktseiten über Landingpages bis hin zu Use-Case-Seiten – und optimierst sie iterativ auf Basis von Performance-Signalen wie Conversion-Pfaden, Suchintentionen und Content-Gaps

- Du konzipierst und führst A/B-Tests durch, um Website-Performance experimentell sauber und signifikant zu steigern: Seitenstruktur, Messaging, CTA-Logik, interne Verlinkung und Friction-Reduktion stehen dabei im Fokus

- Themen- und Intent-Cluster für Bikeleasing und Probonio baust Du auf und erstellst und optimierst organische Content-Formate (Ratgeber, Glossar- und Erklärseiten, Vergleichs-Content). Dabei sorgst Du für eine solide Onpage-Basis, die SEO und GEO gleichzeitig unterstützt

- Du entwickelst und steuerst eine integrierte Content-Strategie – inklusive Themen-Backlog, Intent-Logik (Awareness → Consideration → Conversion), Content-Standards und Erfolgskriterien – und machst Output und Wirkung damit skalierbar

- Du konzipierst Lead-Assets wie Whitepapers und Webinare, koordinierst deren Umsetzung und sorgst für konsequentes Content-Repurposing in Website-Module, organische Formate und Sales-Enablement-Materialien

## Deine Stärken

-

Du bringst mindestens 5 Jahre nachweisbare Erfahrung in der experimentellen Steigerung von Website-Performance durch A/B-Tests mit – und kannst konkrete Ergebnisse und Metriken benennen

-

Du hast mindestens 5 Jahre Erfahrung in der Optimierung von Websites im Organic-Search-Kontext (SEO + GEO) und weißt, wie man Sichtbarkeit messbar aufbaut

-

Du leitest Content-Strategien datengetrieben und SEO- bzw. GEO-geleitet ab – von der Zielgruppenanalyse bis zur Priorisierung von Themenfeldern

-

Du kommunizierst sicher auf Deutsch (C2) und Englisch (C1) und kannst komplexe Inhalte klar und zielgruppengerecht aufbereiten

-

Operative Erfahrung in Paid Search oder Paid Social ist ein Plus – kein Muss, aber hilfreich für die enge Zusammenarbeit im Team

## Warum zu uns?

- Du bist Teil eines stark wachsenden Unternehmens, kannst vieles vorantreiben und aktiv mitgestalten – gemeinsam schaffen wir eine langfristige Karriereperspektive

- Zurück ins Office? Nicht bei uns! Stattdessen erwartet Dich maximale Flexibilität – unterstützt durch unser modernes Gleitzeitmodell sowie unsere Workation-Policy

- Wir leben echtes Sparring: offene Kommunikation, ehrliches Feedback und Zusammenarbeit auf Augenhöhe

- Über Probonio erhältst Du monatlich einen 50-Euro-Gutschein Deiner Wahl – plus 60 Euro jährlich zu Deinem Geburtstag

- Neben starken Versicherungsbedingungen für Deine betriebliche Altersvorsorge profitierst Du zusätzlich von vermögenswirksamen Leistungen

- Und selbstverständlich kannst Du bis zu zwei Fahrräder oder Pedelecs über uns als Arbeitgeber leasen

Wir sehen Vielfalt als Bereicherung für unser Team. Darum freuen wir uns über alle Bewerbungen und möchten besonders Menschen mit Behinderung oder anderen Herausforderungen dazu ermutigen, sich bei uns zu bewerben.

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
