# Werkstudent:in People (m/w/d)

Posted: 2026-08-17T14:01:15Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**Du willst People nicht nur verwalten, sondern von Grund auf mitaufbauen?**

Du willst von Tag eins an echte Verantwortung übernehmen und miterleben, wie eine People-Funktion in einem wachsenden Unternehmen tatsächlich entsteht? Dann komm zur Softengine Holding GmbH!

**Wer wir sind - Innovation trifft auf 30 Jahre Erfolg**

Als technologisch führendes ERP-Unternehmen liefert Softengine seit über 30 Jahren kaufmännische Komplettlösungen. Mit unserer ERP-SUITE, modernsten KI-Tools und einem starken Partnernetzwerk digitalisieren wir den Mittelstand, von Warenwirtschaft über Finanzwesen bis E-Commerce. Wir stehen für Sicherheit und Wachstum.

Für unsere neue People-Funktion suchen wir ab Oktober 2026 eine:n **Werkstudent:in People (m/w/d)**, der/die direkt an der Seite unserer neuen Head of People von Grund auf mitaufbaut und unsere People-Prozesse aktiv mitgestaltet.

## Aufgaben

- Du unterstützt den Aufbau und die Skalierung unserer People-Funktion von Grund auf, direkt an der Seite der Head of People.

- Du wirkst aktiv an der Einführung unseres neuen HR-Management-Systems mit, von der Datenaufbereitung bis zum Rollout an unseren Standorten.

- Du hilfst dabei, Personaldaten aus unseren verschiedenen Gesellschaften und Standorten zu harmonisieren und sauber zu strukturieren.

- Du bringst dich bei der Entwicklung gemeinsamer People-Grundsätze, Prozesse und Richtlinien für die wachsende Unternehmensgruppe ein.

- Du übernimmst People-Administration im Tagesgeschäft, von Vertragswesen bis zur Verwaltung unserer digitalen Personalakten.

- Du unterstützt vorbereitend bei der Lohn- und Gehaltsabrechnung.

- Du unterstützt im Recruiting- und Bewerbermanagement, von Stellenausschreibungen über Terminkoordination bis zur Kommunikation mit Kandidat:innen.

- Du bringst eigene Ideen in unsere People-Projekte ein und gestaltest aktiv mit, statt nur zuzuarbeiten.

## Qualifikation

- Du studierst, idealerweise im Master, ein fortgeschrittenes Bachelorstudium ist aber auch willkommen, mit Bezug zu Personal, Wirtschaft, Psychologie oder Ähnlichem.

- Erste praktische Erfahrung im HR-/People-Bereich, zum Beispiel durch ein Praktikum, ist von Vorteil.

- Idealerweise hast du schon mal mit einem HR-Tool gearbeitet (z. B. Personio o.Ä.), ist aber kein Muss.

- Du bist echte:r Generalist:in und scheust dich nicht, überall mit anzupacken, wo gerade Bedarf ist.

- Du arbeitest strukturiert, diskret und sorgfältig, gerade im Umgang mit sensiblen Personaldaten.

- Du beherrschst den sicheren Umgang mit MS Office.

- Du hast eine hohe IT-Affinität und Lust, ein neues HR-System aktiv mit aufzubauen.

- Du bringst Eigeninitiative mit und willst in einem dynamisch wachsenden Umfeld wirklich etwas bewegen.

- Du sprichst fließend Deutsch, Englischkenntnisse sind von Vorteil.

- Du hast mindestens 15-20 Stunden pro Woche Zeit.

## Benefits

- Direkte Zusammenarbeit mit der Head of People, mit steiler Lernkurve und echter Verantwortung ab Tag eins.

- Einblick in den Aufbau einer People-Funktion in einem Buy-and-Build-Unternehmen aus erster Reihe.

- Flache Hierarchien und kurze Entscheidungswege.

- Moderne Standorte und hybrides Arbeiten.

- Modernste Hard- und Software und individuelle Weiterbildungsmöglichkeiten.

Zum 15.09.2026 startet unsere neue Head of People und wir suchen eine Werkstudentin oder einen Werkstudenten, der oder die direkt an ihrer Seite von Anfang an mit dabei ist. Wir melden uns mit einer ersten Rückmeldung zu deiner Bewerbung Mitte September.

Bewirb Dich jetzt und gestalte unseren Erfolg mit!

*Wenn du dich für diese Rolle begeisterst, aber nicht jede Qualifikation erfüllst, ermutigen wir dich, dich trotzdem zu bewerben.*

Softengine ist ein Arbeitgeber, der Chancengleichheit fördert. Wir setzen uns für ein vielfältiges und inklusives Umfeld ein, in dem Empathie und Respekt unser Miteinander leiten.

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
