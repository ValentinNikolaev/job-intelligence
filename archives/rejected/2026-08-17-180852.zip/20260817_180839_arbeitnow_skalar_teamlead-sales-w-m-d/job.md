# Teamlead Sales (w/m/d)

Posted: 2026-08-17T14:40:25Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

## **WIR BAUEN DIE STEUERKANZLEI DER ZUKUNFT**

**Radikal einfach. Hochautomatisiert. 100% mandantenfokussiert.**

Wir denken Steuerberatung komplett neu: einfach, schnell und transparent für Mandanten und Kanzleiteam zugleich.

Wo andere Kanzleien mit manuellen Prozessen, langen Wartezeiten und intransparenter Kommunikation kämpfen, bauen wir ein völlig neues Erlebnis – digital, proaktiv, KI-gestützt. Mit automatisierten Prozessen im Hintergrund und digitalen Schnittstellen zum Mandanten laufen repetitive Aufgaben weitgehend von selbst – damit du Zeit hast für das, was wirklich zählt: Beratung, Sonderfälle und smarte Lösungen.

Der Unterschied zu anderen „Digitalkanzleien“: Über die Hälfte unseres Teams sind Softwareentwickler. Deine Kollegen bauen die Tools, die dir im Vertriebsalltag wirklich helfen – für deine Probleme, nicht von der Stange.

Wir sind ein erfahrenes Gründerteam aus Steuerberatern, Digital-Unternehmern und Softwareentwicklern mit einem Exit-Track-Record von 140 Mio. €. Mit dir gemeinsam möchten wir eine der führenden Kanzleien Deutschlands aufbauen.

## **DEINE ROLLE**

Als Teamlead Sales führst du unser Sales-Team – Account Executives und SDRs – und verantwortest den gesamten Funnel von der ersten Ansprache bis zum Abschluss. Du berichtest direkt an unseren Growth Manager (Co-Founder).

Die Rolle ist bewusst 50/50 geschnitten: Die Hälfte deiner Zeit bist du selbst im Deal – auf C-Level, bei den strategisch wichtigsten Mandaten. Die andere Hälfte baust du das System dahinter: Team, Playbook, Forecast, Automatisierung. Du führst also nicht vom Spielfeldrand, sondern bleibst nah genug am Markt, um zu wissen, was in den Calls wirklich passiert.

Du arbeitest eng mit Growth und Marketing an Lead-Qualität und Positionierung, mit Tax Operations an einer sauberen Übergabe ins Onboarding und mit unseren Softwareentwicklern an den Tools, die den Vertrieb skalierbar machen. Dein Ziel: die Wahrnehmung von Steuerberatung vom verlängerten Arm des Finanzamts zum strategischen, modernen Partner zu verschieben – und daraus einen planbaren Wachstumsmotor zu bauen.

## **DEINE AUFGABE**

### **FÜHRUNG & TEAM-PERFORMANCE**

-

Führung und Entwicklung von Account Executives und SDRs – Zielsetzung, 1:1s, Coaching entlang konkreter Calls und Deals

-

Verantwortung für Pipeline, Conversion Rates und Forecast – belastbare Zahlen statt Bauchgefühl

-

Hiring, Onboarding und Ramp-up neuer Teammitglieder

-

Aufbau einer Feedback- und Enablement-Kultur: Call-Reviews, Best-Practice-Sharing, klare Standards für Discovery und Closing

### **EIGENE DEALS**

-

Du führst die strategisch wichtigsten Deals selbst – von Discovery bis Abschluss, auf C-Level mit Gründern, Geschäftsführern und CFOs

-

Bewertung der Finanz- und Steuerarchitektur von Interessenten und Gatekeeping entlang unseres Ideal Customer Profile (ICP)

-

Testfeld für neue Ansätze: Was bei dir funktioniert, wird zum Standard im Team

### **SALES-SYSTEM & AUTOMATISIERUNG**

-

Aufbau und Weiterentwicklung unseres Sales-Playbooks: Qualifizierungskriterien, Discovery-Framework, Angebots- und Pricing-Logik

-

Pipeline-Architektur, Reporting und Automatisierungen in HubSpot – sauber dokumentiert, skalierbar

-

Anforderungen an unsere Softwareentwickler formulieren – du beschreibst das Problem, gemeinsam baut ihr die Lösung

-

Schnittstelle zu Marketing (Lead-Qualität, Content-Loop) und Tax Operations (Übergabe, Kapazitätsplanung)

## **WAS DU MITBRINGST**

-

Nachweisbarer Track Record als Account Executive im B2B-Vertrieb erklärungsbedürftiger Dienstleistungen oder komplexer Softwarelösungen an kleine und mittlere Unternehmen – du hast deine Zahl selbst konstant erreicht

-

Führungserfahrung im Vertrieb: du hast bereits AEs oder SDRs geführt, gecoacht und eingestellt – oder als Senior AE nachweislich Verantwortung für die Entwicklung anderer übernommen

-

Erfahrung darin, Sales-Strukturen aufzubauen und zu skalieren: Playbook, Forecast, Pipeline-Hygiene, Enablement

-

Souveräne Kommunikation auf C-Level: Du agierst als Berater und strategischer Sparringspartner

-

Solides Verständnis von Unternehmenssteuern – oder die klare Bereitschaft, es dir schnell anzueignen. Du musst beurteilen können, ob das Steuer-Setup eines Leads zu unserem operativen Modell passt

-

Hohe Tech- und Prozessaffinität: sicherer Umgang mit HubSpot; Erfahrung mit Sales-Automation, Conversational-Intelligence- oder KI-Tools ist ein starkes Plus

-

Verhandlungssicheres Deutsch (zwingend für Mandantengespräche), fließendes Englisch (Unternehmenssprache)

-

Lust, in einem schnell wachsenden Team mit hoher Eigenverantwortung und echtem Gestaltungsspielraum zu arbeiten

## **BENEFITS**

-

🎯 Volle Verantwortung für Team und Zahl – du baust den Sales-Motor, nicht nur die Pipeline

-

🤝 Cross-funktionale Zusammenarbeit – Hand in Hand mit Growth, Marketing, Tax Operations und unseren Softwareentwicklern

-

🚀 Ownership ab Tag 1 – Baue aktiv die Zukunft der 1 Bio. $ schweren Tax- & Accounting-Industrie mit

-

🧠 Steile Lernkurve – Arbeite Seite an Seite mit den klügsten und ambitioniertesten Köpfen Europas

-

👥 Smartes, ambitioniertes & lustiges Team – Direkte Zusammenarbeit mit einem erfahrenen Founding-Team (Exit-Track-Record 140 Mio. €), regelmäßige Team-Events, Lunches und mehr – globale Ambition mitten in München

-

🛠️ Modernes Tech-Setup – Digitale Prozesse, klare Strukturen, moderne Sales-Tools

-

💰 Kompetitives Gehaltspaket

-

📍 Büro im Herzen Münchens, top angebunden

-

🎁 3.000 € p.a. Benefitsprogramm + Firmenhandy

## **BEREIT, STEUERBERATUNG NEU ZU DEFINIEREN?**

Werde Teil von Skalar — und baue mit uns den Vertrieb einer der modernsten Kanzleien Deutschlands.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
