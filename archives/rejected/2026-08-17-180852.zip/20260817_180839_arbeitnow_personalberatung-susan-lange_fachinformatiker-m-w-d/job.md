# Fachinformatiker (m/w/d)

Posted: 2026-08-17T14:01:15Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Die Personalberatung Susan Lange in Rostock ist spezialisiert auf die Direktsuche und Vermittlung von gewerblich-technischen Fachkräften. Für Bewerber ist unser Service kostenfrei.

Im Auftrag unseres Kunden in Rostock, ein mittelständisches Unternehmen aus der regionalen Wirtschaft, suchen wir zur Verstärkung seines Teams einen

**Fachinformatiker (m/w/d)**

## Aufgaben

- Unterstützung bei der Analyse und Optimierung der internen IT-Prozesse

- Qualitätssicherung im Rahmen der Supportprozesse und Kundenkommunikation

- Fehleranalyse und Beseitigung von Störungen

- Beratung und Schulung von Anwendern

- Einweisen der Benutzer in die Bedienung der Systeme

## Qualifikation

- abgeschlossene Ausbildung zum IT - Systemkaufmann, Fachinformatiker oder vergleichbarer Abschluss (wie beispielsweise Bachelor of Science, Informatik)

- mehrjährige Berufserfahrungen und Kenntnisse in den Bereichen IT-Systeme und Webtechnologien wünschenswert

- gute Kenntnisse des Debian Betriebssystems, Administration von Proxmox, PostgreSQL, RabbitMQ zwingend notwendig

- Sie verfügen über fließende Deutschkenntnisse (C1) und gute Englischkenntnisse (B2)

- eine selbstständige und strukturierte Arbeitsweise ist Ihnen bestens vertraut

Interessiert? Dann freuen wir uns auf Ihre vollständigen Bewerbungsunterlagen per einfacher Onlinebewerbung, per E-Mail oder schriftlich an:

Personalberatung Susan Lange

Lange Straße 6

18055 RostockTelefon: 0381 - 40 33 45 60

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
