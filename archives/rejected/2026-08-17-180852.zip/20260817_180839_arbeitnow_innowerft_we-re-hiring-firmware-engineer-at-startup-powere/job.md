# WE´RE HIRING FIRMWARE ENGINEER AT STARTUP POWERED ORTHOTICS

Posted: 2026-08-17T17:00:26Z

## Rejection

- Category: tech_stack
- Reason: role does not mention Go/Golang or PHP

Build firmware for wearable robotics that changes lives.

We are a healthtech startup developing robotic hand orthoses that help people regain function and independence.

We are looking for a Firmware Engineer with a strong background in embedded systems, enjoys a hands-on approach

to development, and is motivated to create meaningful technology in a fast-moving team.

Your Role

We are looking for an innovator to help bring our devices to life. In this role, you will take ownership of embedded

software development for our wearable robotic systems and work closely with a multidisciplinary team to turn

prototypes into robust, user-ready products.

If you enjoy solving real-world engineering challenges, moving quickly, and building meaningful technology in a highly

collaborative startup environment, we would love to hear from you. You will work on everything from low-level device

control to system integration and testing.

## Aufgaben

Your Responsibilities

• Develop, test, and maintain firmware for embedded systems used in our robotic

hand orthosis

• Implement control logic for motors, sensors, buttons, and communication interfaces

• Debug hardware-software interactions and troubleshoot real-world system behavior

• Support integration of embedded software with electronics, mechanical systems,

and higher-level software

• Optimize firmware for reliability, responsiveness, safety, and power efficiency

• Implement software testing and verification framework for device safety

• Document firmware architecture, interfaces, and development decisions in a clear

and structured way

• Work closely with cross-functional teammates to rapidly test, improve, and refine

product performance

## Qualifikation

What you bring

• At least a Master’s degree in Electronics, Mechatronics, Mechanical Engineering,

Robotics Engineering or Computer Engineering (specialized towards Embedded

Firmware development)

• Hands-on experience in embedded firmware development and hardware-software

integration

• Strong programming skills in C/C++

• Experience working with microcontrollers and real-time or near-real-time systems

• Familiarity with hardware interfaces such as UART, I2C, SPI, ADC, PWM, CAN, or

BLE

• Structured, pragmatic way of working and strong problem-solving mindset

• Comfortable working in a dynamic environment with evolving priorities

• Willingness to learn and take on new challenges

## Benefits

Why Join Us?

• A flat organizational hierarchy where your input will always be valued

• Within the first year, you will see the tangible impact of your work on people’s lives

• A hands-on role with real ownership and influence on the product

• Flexible structures, direct communication, and room to grow with the company

Application

• Send us a short paragraph telling us why you think we might be a fit, along with a CV

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
