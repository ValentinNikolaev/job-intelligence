# Staff Software Engineer

Posted: 2026-08-16T18:17:05Z

## Rejection

- Category: tech_stack
- Reason: role does not mention Go/Golang or PHP

There's nothing more exciting than transforming an industry that's been stagnant for decades.

[Federato](https://himalayas.app/companies/federato) is an AI-native platform that’s bringing agentic AI to the full policy lifecycle. We’re aggressively transforming how insurance work gets done, and the world is paying attention: we've raised $180 million, including a $100 million Series D from Goldman Sachs. We have powerful product-market fit, and we're growing fast globally.

You'll get to work on complex problems with one of the most advanced AI teams you'll find anywhere. If you're the person we need, you know that AI bolted onto legacy systems is too weak to matter. That's why we built our platform to be AI-native from day one. That's why you can do here what you can never do at a legacy software company. move fast and prove it, not theorize it. We think from first principles. You’ll work on problems that matter, building software that fundamentally changes how insurance operates.

**What You'll Be Doing**:

- Lead a small team of engineers, providing technical mentorship, code review, and architectural guidance to ensure high-quality delivery.

- Collaborate closely with Product Managers and Designers to shape roadmap priorities and translate customer needs into scalable solutions.

- Architect and build complex features across the stack using React, TypeScript, Python (Django), Node.js, and PostgreSQL.

- Drive engineering best practices, including robust testing, code quality, and tooling improvements that elevate team productivity.

- Own technical delivery from design through deployment, including performance, reliability, and monitoring considerations.

- Champion engineering excellence by proactively identifying areas of improvement in the codebase, development workflow, and team processes.

- Serve as a thought partner to engineering leadership in scaling systems, reducing complexity, and mentoring others.

- Build deep empathy for our customers and help ensure our products are intuitive, impactful, and reliable.

### Who We Hope You Are:

- 10+ years of professional software engineering experience, including substantial full stack development.

- Proven experience leading engineering teams or pods, including mentorship, task planning, and technical decision-making.

- Strong frontend skills with modern JavaScript/TypeScript and React.

- Significant backend experience with Python (Django) and Node.js with TypeScript, including building and scaling APIs and services.

- Familiarity with infrastructure components like Kubernetes (K8s) and containerized deployments.

- Experience working with relational databases such as PostgreSQL.

- Familiarity with event-driven architectures and tools like Kafka.

- Deep understanding of software design principles, testing strategies, and CI/CD pipelines.

- Track record of making pragmatic technical decisions that balance speed, quality, and long-term maintainability.

- Ability to thrive in a highly collaborative environment, working closely with cross-functional peers in Product and Design.

- Strong communication skills and the ability to advocate for technical solutions across stakeholders.

### $210,000 - $260,000 a year

Final offer amounts are determined by multiple factors including candidate location, experience and expertise and may vary from the amounts listed above. Total compensation package does include stock options, benefits and additional perks. Role may require 15-20% travel.

Here at [Federato](https://himalayas.app/companies/federato), your capabilities are important, but culture fit is essential. We move fast, are eager to listen to our users, take a first principles approach to solving problems, and value learning and the ability to change our minds. Most importantly, we're here to have fun. Our ability to make a difference starts with our people. We would love to work with you!

*We are an equal-opportunity employer and value diversity at our company. We do not discriminate on the basis of race, religion, color, national origin, sex, gender expression, sexual orientation, age, marital status, veteran status or disability status. We will provide reasonable accommodation to individuals with disabilities to participate in the job application or interview process, to perform essential job functions, and to receive other benefits and privileges of employment. Please contact us to request accommodation at *

Originally posted on [Himalayas](https://himalayas.app)
