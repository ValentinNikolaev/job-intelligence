# CNC Fräser / Polymechaniker | 100% Region: St. Gallen, Schweiz

Posted: 2026-08-17T13:01:17Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Über das Unternehmen

Für ein international tätiges Technologieunternehmen im Bereich Präzisionsfertigung suchen wir eine erfahrene Fachkraft für die CNC-Fräsbearbeitung. Das Umfeld ist technisch anspruchsvoll und geprägt von hohen Anforderungen an Qualität, Prozessstabilitaet und Genauigkeit.

In dieser Position übernehmen Sie die Verantwortung für CNC-Fräsbearbeitungszentren und begleiten den Prozess von der Einrichtung und dem Einfahren neuer Teile bis zur laufenden Produktion. Sie arbeiten eng mit der Programmierung zusammen und haben gleichzeitig die Möglichkeit, fachlich Verantwortung für weitere Mitarbeitende in der Fertigung zu übernehmen.

## Aufgaben

**Aufgaben**

- Sie bedienen CNC-Fräsbearbeitungszentren und tragen die Verantwortung für einen stabilen und effizienten Produktionsablauf.

- Sie richten Maschinen ein, führen neue Bauteile ein und stimmen sich dabei eng mit der CNC-Programmierung ab.

- Sie übernehmen das selbstständige Ein- und Umrüsten der Maschinen entsprechend den jeweiligen Fertigungsanforderungen.

- Sie überwachen die laufende Fertigung, prüfen die Prozessqualität und stellen die geforderte Teilequalität sicher.

- Sie behalten Termine und Kapazitäten im Blick und sorgen für eine möglichst effiziente Nutzung der eingesetzten Maschinen und Betriebsmittel.

- Sie führen Wartungs- und Pflegearbeiten an den zugewiesenen Maschinen und Einrichtungen durch.

- Sie unterstützen und betreuen die Ihnen zugeordneten Operateure fachlich im täglichen Produktionsablauf.

## Qualifikation

**Anforderungen**

- Abgeschlossene technische Ausbildung als Polymechaniker, Produktionsmechaniker oder in einer vergleichbaren Fachrichtung.

- Mehrjährige praktische Erfahrung in der CNC-Fräsbearbeitung.

- Sicherer Umgang mit CNC-Fräsmaschinen und Erfahrung im Einrichten und Umrüsten von Maschinen.

- Erfahrung beim Einfahren neuer Bauteile und bei der Optimierung von Fertigungsprozessen ist von Vorteil.

- Präzise, selbstständige und verantwortungsbewusste Arbeitsweise mit hohem Qualitätsbewusstsein.

- Teamfähigkeit, Zuverlässigkeit und Flexibilität im Produktionsumfeld.

- Bereitschaft zur Arbeit im 2-Schichtbetrieb.

## Benefits

- Mitarbeit an **spannenden Entwicklungsprojekten für die internationale Luftrettung**.

- Verantwortungsvolle Aufgaben mit viel **Eigenverantwortung und Gestaltungsspielraum**.

- Ein motiviertes, interdisziplinäres Team mit kurzen Entscheidungswegen.

- **Attraktive Anstellungsbedingungen** sowie gezielte interne und externe Weiterbildungsangebote.

- **Flexible Arbeitszeiten**, Homeoffice-Möglichkeiten und Teilzeitoptionen.

- Internationale Zusammenarbeit mit Kolleginnen und Kollegen in der **Schweiz, Deutschland und den USA**.

- Regelmässige Firmen- und Teamevents zur Förderung einer starken Teamkultur.

- Gute Erreichbarkeit mit öffentlichen Verkehrsmitteln sowie Firmenparkplätze vor Ort.

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
