# IT System Engineer (m/w/d)

Posted: 2026-08-17T13:01:33Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

*Gestalte komplexe IT-Systemlandschaften im Gesundheitswesen*

Du möchtest nicht nur Tickets bearbeiten, sondern komplexe IT-Systeme verstehen, optimieren und gemeinsam mit Kunden weiterentwickeln? Dich reizt eine Rolle, in der Systemintegration, Infrastruktur, Datenbanken, Netzwerke und Kundenkommunikation zusammenkommen? Dann erwartet Dich hier eine abwechslungsreiche Position mit viel Eigenverantwortung.

Für unseren Partner, ein etabliertes Softwareunternehmen mit Fokus auf die Digitalisierung von Gesundheitseinrichtungen, suchen wir einen **IT System Engineer (m/w/d)**.

Gemeinsam mit Deinem Team sorgst Du dafür, dass moderne Enterprise-Content-Management-Lösungen (ECM) und Dokumentenmanagementsysteme (DMS) bei Kunden zuverlässig implementiert, betrieben und kontinuierlich weiterentwickelt werden.

Dich erwartet eine komplexe Systemlandschaft mit zahlreichen technischen Schnittstellen und individuellen Kundenanpassungen. Statt standardisierter Routineaufgaben arbeitest Du an maßgeschneiderten Lösungen und bist technischer Ansprechpartner für Kunden – von der Implementierung über Systemerweiterungen bis hin zur Fehleranalyse und Optimierung.

## Aufgaben

- Installation, Konfiguration und Inbetriebnahme moderner Enterprise Content Management (ECM)- und Dokumentenmanagement-Systeme (DMS)

- Betreuung komplexer Windows-Systemlandschaften sowie Durchführung von Software-Updates und Releasewechseln

- Einrichtung, Konfiguration und Optimierung technischer Schnittstellen sowie Durchführung von Datenmigrationen

- Analyse und Behebung technischer Störungen per Remote-Zugriff im 2nd-Level-Support

- Enge Zusammenarbeit mit dem 1st-Level-Support auf Kundenseite zur nachhaltigen Lösungsfindung

- Direkter Austausch mit Kunden zur Analyse technischer Anforderungen und Entwicklung individueller Lösungen

- Unterstützung der IT-Consultants und Projektteams bei technischen Fragestellungen

- Erstellung und Pflege technischer Dokumentationen sowie Wissensdatenbanken

- Mitarbeit in einem 19-köpfigen Team, aufgeteilt auf drei spezialisierte Fachbereiche

- Aktive Mitgestaltung und kontinuierliche Optimierung bestehender IT-Infrastrukturen und Systemlandschaften

## Qualifikation

- Abgeschlossenes Studium der Informatik, Wirtschaftsinformatik oder eine Ausbildung als Fachinformatiker für Systemintegration bzw. eine vergleichbare IT-Qualifikation

- Berufserfahrung als IT System Engineer, Systemadministrator, IT Consultant, IT Support Engineer, Technical Consultant oder IT Systemadministrator

- Sehr gute Kenntnisse im Microsoft Windows Server-Umfeld

- Erfahrung in der Administration komplexer IT-Infrastrukturen

- Gute Kenntnisse im Bereich Netzwerktechnik (TCP/IP, DNS, Active Directory, Netzwerkkommunikation oder vergleichbare Technologien)

- Erfahrung mit SQL sowie grundlegendes Datenbankverständnis

- Kenntnisse mindestens einer Skriptsprache sowie die Fähigkeit, Skripte zu analysieren und nachzuvollziehen – ohne selbst Software entwickeln zu müssen

- Analytisches Denkvermögen und Freude daran, komplexe technische Zusammenhänge zu verstehen

- Ausgeprägte Service- und Kundenorientierung sowie sicheres Auftreten im direkten Kundendialog

- Teamfähigkeit, Eigeninitiative und strukturierte Arbeitsweise

- Fließende Deutschkenntnisse sowie gute Englischkenntnisse

## Benefits

- Anspruchsvolle Aufgaben in einer technisch komplexen und abwechslungsreichen Systemlandschaft

- Viel Eigenverantwortung und direkter Kundenkontakt statt reinem Ticketsupport

- Mitarbeit in einem erfahrenen, interdisziplinären Team mit kurzen Entscheidungswegen

- Strukturierte Einarbeitung sowie persönliche Betreuung durch erfahrene Kolleginnen und Kollegen

- Individuelle Weiterbildungs- und Entwicklungsmöglichkeiten innerhalb einer etablierten Softwaregruppe

- Moderne Arbeitsausstattung und professionelle Entwicklungsumgebung

- **Vollzeitposition** mit langfristiger Perspektive

- Homeoffice-Möglichkeit an bis zu zwei Tagen pro Woche nach erfolgreicher Einarbeitung bzw. Probezeit

- Flexible Arbeitszeiten für eine ausgewogene Work-Life-Balance

- Offene Unternehmenskultur mit flachen Hierarchien und kollegialem Miteinander

- Kostenfreie Getränke sowie weitere attraktive Mitarbeiterangebote

Lass uns entspannt über weitere Details verständigen!

🎯Bewirb dich direkt: Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
