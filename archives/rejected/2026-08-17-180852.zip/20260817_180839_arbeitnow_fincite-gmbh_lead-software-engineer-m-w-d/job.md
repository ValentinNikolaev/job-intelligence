# Lead Software Engineer (m/w/d)

Posted: 2026-08-17T14:09:58Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**Deine Herausforderungen**

• Gemeinsam mit zwei weiteren Kolleg:innen agierst du als Lead Engineer für eine rund 20-köpfige Entwicklerorganisation.
• Du übernimmst die fachliche und technische Führung eines Teams; Bis zu fünf Mitarbeitende führst du direkt.
• Du entwickelst robuste Backend-Lösungen für anspruchsvolle Wealth-Management-Produkte und gestaltest deren Architektur aktiv mit.
• Du etablierst neue technische Standards und sorgst für ein hochwertiges, nachhaltiges Softwaredesign in einem regulierten Umfeld.
• Du strukturierst komplexe fachliche und technische Themen, schneidest Arbeitspakete sinnvoll zu und schaffst klare Verantwortlichkeiten.
• Zu Beginn arbeitest du stark hands-on an der Codebasis; perspektivisch entwickelt sich die Rolle zu etwa 70 % Teamführung und 30 % fachlich-technischer Arbeit.
• Du förderst die Weiterentwicklung deiner Mitarbeitenden und etablierst eine konstruktive, lernorientierte Engineering-Kultur.
• Du stärkst unsere interne Entwicklungskapazität und trägst dazu bei, verlässliche Software für langfristige Kundenbeziehungen zu liefern.

**Das bringst du mit**

• Mehrjährige Erfahrung in der Backend-Entwicklung mit Python und Django.
• Fundierte Kenntnisse in PostgreSQL und Redis sowie Erfahrung mit cloudbasierten Architekturen wie Microsoft Azure oder AWS
• Ein ausgeprägtes Faible für gutes Softwaredesign und Begeisterung für saubere, wartbare Lösungen.
• Erste oder nachweisbare Erfahrung in technischer beziehungsweise fachlicher Führung.
• Echtes Interesse an Finanzmärkten, Geldanlage und Wealth Management – damit du die Perspektive unserer Nutzer:innen verstehst und dich langfristig mit dem Produkt identifizierst.
• Growth Mindset, Lernbereitschaft und Motivation, dich fachlich sowie als Führungskraft weiterzuentwickeln.

**Unser Angebot**

Wir sind ein etabliertes Produktunternehmen mit dem Spirit eines Startups. Dich erwarten Teamgeist, schnelle Entscheidungen und echte Freiheit, dein Arbeitsumfeld zu gestalten. Flexible Arbeitszeiten, Weiterbildungsbudgets und attraktive Benefits geben dir Raum für persönliche Entwicklung, Karrieremöglichkeiten und ein erfülltes Leben.

**Sprachkenntnisse**

Fließende Englischkenntnisse sind erforderlich
Deutschkenntnisse Nice-to-Have

**Ansprechpartner/in**

Julian Eder

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
