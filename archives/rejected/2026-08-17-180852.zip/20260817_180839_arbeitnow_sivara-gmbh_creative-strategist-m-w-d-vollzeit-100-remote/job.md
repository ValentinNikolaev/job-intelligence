# Creative Strategist (m/w/d), Vollzeit, 100% Remote

Posted: 2026-08-17T17:00:28Z

## Rejection

- Category: tech_stack
- Reason: role does not mention Go/Golang or PHP

Du siehst dir einen Funnel an und weißt sofort, wo es gerade hakt? Du weißt, welcher Angle als Nächstes getestet oder iteriert werden sollte, wo BOF Ads fehlen und welche Landingpage wir brauchen, und du denkst dabei in Hypothesen, Angles und Zahlen, nicht in schönen Kampagnen? Schon mal ein gutes Zeichen.

Aber damit wir uns nicht missverstehen: Wir suchen keinen Strategen, der nur theoretische Slides baut und andere machen lässt. Wir suchen jemanden, der die Strategie setzt UND selbst liefert. Du entscheidest, was wir launchen, planst den Funnel, und baust die Skripte, Listicles und Landingpages, die performen, auch selbst. Wenn du lieber nur Konzepte präsentierst und auf Applaus wartest, passen wir nicht.

## Aufgaben

- Du verantwortest die Creative- und Funnel-Strategie bei Sivara, von der ersten Idee bis zur Umsetzung.

- Du analysierst unsere Funnel, findest die Lücken (fehlende Angles, Bottom-of-Funnel-Ads, schwache Landingpages) und leitest daraus konkrete Test-Pläne ab.

- Du entscheidest, was wir als Nächstes launchen, und priorisierst nach Wirkung.

- Du schreibst und baust die DR-Assets selbst: Advertorials, Listicles, Landingpages, VSL-Skripte, Ad-Copy.

- Du briefst und challengst unsere Agenturen, damit die Creatives performen und das Mediabuying läuft.

- Du iterierst Winner weiter und leitest aus den Performance-Daten die nächste Version ab.

- Du arbeitest im Alltag eng mit Claude, baust dir eigene Prompts und Workflows und nutzt AI, um schneller und besser zu liefern.

## Qualifikation

- Mehrere Jahre Erfahrung als Creative Strategist, Direct-Response-Marketer oder in einer vergleichbaren Rolle, idealerweise im D2C- oder E-Commerce-Bereich.

- Du denkst in Funnels und Awareness Stages (Schwartz) und wendest sie in der Praxis an, nicht nur als Theorie.

- Du hast nachweislich Funnels, Landingpages, Advertorials oder VSLs konzipiert UND selbst gebaut, die performt haben.

- Du bist strategisch stark und gleichzeitig hands-on, du setzt deine Ideen selbst um.

- Du arbeitest datengetrieben und schaust auf die Zahlen (ROAS, CAC, CTR, Hook-Rate, etc.), nicht auf dein Bauchgefühl.

- Du bist sehr vertraut mit Claude und arbeitest ohnehin täglich damit.

- Du ziehst Themen eigenständig durch, lieferst sauber und gibst Gas, auch wenn keiner zuschaut.

## Benefits

- 100% Remote, du arbeitest, wo du willst.

- Flexible Arbeitszeiten, die sich deinem Leben anpassen. Wir bewerten dich nach Leistung, nicht nach Anwesenheit.

- Vertrauen statt Konzern-Bürokratie: brauchst du mal spontan einen Tag, reicht eine kurze Nachricht.

- 30 Tage Urlaub, am Geburtstag zusätzlich frei.

- Flache Hierarchien.

- Attraktives Gehalt plus Performance-Bonus, wenn deine Arbeit die Zahlen bewegt.

- Netzwerk: Sivara ist eng vernetzt mit den führenden D2C-Brands Deutschlands und tauscht sich täglich mit anderen E-Commerce-Brands im 8- bis 9-stelligen Bereich aus.

- Lerneffekt: echte D2C-Skalierung von innen, ein 7-stelliges Unternehmen auf dem Weg zum 8-stelligen.

Bis hier durch? Dann sind wir vielleicht dein Match.

Schick mir ein kurzes, ungezwungenes Anschreiben per du. Was hast du bisher gebaut, welche Copy- oder Funnel-Beispiele, Landingpages oder Advertorials von dir haben am besten performt, ab wann hättest du Lust, etc. Wenn du ein Portfolio hast, immer her damit.

Bitte kein 5-Seiten-Roman mit „Ich bin teamfähig und belastbar", sondern lieber kurz und knapp zeigen, wer du bist und was du drauf hast. Gerne auch über Linkedin.

Ich freu mich von dir zu hören!

Beste Grüße

Kacper

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
