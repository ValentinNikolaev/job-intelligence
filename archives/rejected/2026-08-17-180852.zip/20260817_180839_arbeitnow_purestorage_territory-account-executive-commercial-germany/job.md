# Territory Account Executive, Commercial (Germany)

Posted: 2026-08-17T14:55:37Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

We’re in an unbelievably exciting area of tech and are fundamentally reshaping the data storage industry. Here, you lead with innovative thinking, grow along with us, and join the smartest team in the industry.

This type of work—work that changes the world—is what the tech industry was founded on. So, if you're ready to seize the endless opportunities and leave your mark, come join us.

As a Territory Account Executive (TAE), you’ll play a pivotal role in bringing this vision to life — helping customers unlock the power of their data, modernise their infrastructure, and accelerate transformation. You’ll **join our ****Commercial team in Germany**, with the autonomy to own a dynamic territory, driving growth across a broad set of customers, from re-engaging dormant relationships to winning new logos.

At Pure, you’ll join a culture built on curiosity, innovation, and integrity. We celebrate diverse perspectives, challenge convention, and empower our people to think big, take bold action, and make a measurable impact. This is your opportunity to grow your career with one of the most innovative technology companies in the world and to do work that truly changes how businesses use data to compete and win.

### **The Role**

The **Territory Account Executive** (TAE) is a key growth role within Everpure (formerly Pure Storage) Germany's Go-To-Market organisation. This position focuses on driving growth across all accounts not currently managed by an Account Executive, including the full install base, dormant accounts, and new inbound opportunities. TAEs are responsible for expanding Pure’s footprint, reigniting customer relationships, and capturing new business through a combination of direct engagement and partner collaboration.

**What You'll Do**

- **Drive Account Growth & Pipeline:** Execute sales activities to generate revenue, manage a high-volume pipeline, and contribute to closing deals on a quarterly basis.

- **Execute Outreach & Prospecting:** Perform consistent, high-activity prospecting to penetrate new accounts, reach decision-makers, and learn how to win new business effectively.

- **Support Partner Strategy:** Collaborate closely with Channel Partners and Partner Managers to align on customer engagement and utilise partner resources to advance opportunities.

- **Reactivate Customer Relationships:** Focus on re-engaging dormant or inactive customers by discovering new business use cases and identifying potential refresh and expansion opportunities.

- **Build Foundational Skills:** Develop and deliver proposals and business cases that clearly demonstrate the value of Pure's solutions, supported by internal experts.

- **Maintain Sales Discipline:** Diligently manage sales technology (Salesforce), deliver accurate forecasts, and maintain strong time management to thrive in a fast-paced, team environment.

### **What You Bring**

- **Proven Sales Experience:** Demonstrated success in direct, full-lifecycle B2B technology sales with a consistent record of meeting or exceeding sales metrics (KPIs).

- **Sales Drive & Motivation:** A high degree of self-motivation, strong time management skills, demonstrates initiative and the drive to learn quickly and succeed across both transactional and early-stage strategic sales motions.

- **Collaborative Mindset:** Demonstrated success working with both internal teams and channel partners to ensure seamless customer engagement and shared goal achievement.

- **Digital Proficiency:** Proficiency with core sales technologies, including Salesforce and G Suite, and an ability to use data to prioritise daily activities.

- **Communication & Presence:** Strong verbal and written communication skills suitable for engaging with business leaders and maintaining professional business relationships.

- **Resilience & Focus:** A competitive, positive attitude combined with strong organisational and time management skills necessary to handle a dynamic, high-activity territory.

- **Language Skills: **Business Level, written and spoken, German and English language skills required.

### **Nice to Have**

- **Industry Knowledge:** Prior knowledge of the storage industry and familiarity with how data solutions drive business outcomes.

- **Channel Sales Expertise:** Understanding of channel-led sales motions and experience collaborating effectively within the broader partner ecosystem.

- **Sales Training:** Completion of a structured B2B sales methodology training (e.g., Business Value Selling or similar).

- **Digital Tools:** Experience using digital prospecting and engagement tools (e.g., Outreach, LinkedIn Sales Navigator) to accelerate the sales cycle.

Join Everpure Germany team and be part of a team that's redefining data storage. Apply now and unleash your potential!

#LI-REMOTE

**WHAT YOU CAN EXPECT FROM US:**

- **Innovation**: We celebrate those who think critically, like a challenge, and aspire to be trailblazers.

- **Growth**: We give you the space and support to grow along with us and to contribute to something meaningful. We have been named Fortune's Best Workplaces in Technology™, Fortune's Best Workplaces in the Bay Area™, and certified as a Great Place to Work®!

- **Team**: We build each other up and set aside ego for the greater good.

And because we understand the value of bringing your full and best self to work, we offer a variety of perks to manage a healthy balance, including flexible time off, wellness resources, and company-sponsored team events. Check out [purebenefits.com](http://purebenefits.com) for more information.

**ACCOMMODATIONS AND ACCESSIBILITY:**

Candidates with disabilities may request accommodations for all aspects of our hiring process. For more on this, contact us at

**OUR COMMITMENT TO A STRONG AND INCLUSIVE TEAM:**

We’re forging a future where everyone finds their rightful place and where every voice matters. Where uniqueness isn’t just accepted but embraced. That’s why we are committed to fostering the growth and development of every person, cultivating a sense of community through our Employee Resource Groups and advocating for inclusive leadership.

Everpure is proud to be an equal opportunity employer. We do not discriminate based upon race, religion, color, national origin, sex (including pregnancy, childbirth, or related medical conditions), sexual orientation, gender, gender identity, gender expression, transgender status, sexual stereotypes, age, status as a protected veteran, status as an individual with a disability, or any other characteristic legally protected by the laws of the jurisdiction in which you are being considered for hire.

**Join us and bring your best.**

**Bring your bold.**

**Pure and simple.**

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
