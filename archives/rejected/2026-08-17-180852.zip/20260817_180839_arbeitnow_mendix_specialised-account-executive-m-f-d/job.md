# Specialised Account Executive (m/f/d)

Posted: 2026-08-17T14:25:33Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**Company Overview**

Siemens Digital Industries Software is a leading provider of solutions for the design, simulation, and manufacture of products across many different industries. Formula 1 cars, skyscrapers, ships, space exploration vehicles, and many of the objects we see in our daily lives are being conceived and manufactured using our Product Lifecycle Management (PLM) software.

**Position Overview**

We are expanding our sales team in the DACH region and are looking for an experienced Specialized Account Executive to drive growth in Intelligence Center X – our leading low-code and process automation platform. Intelligence Center X combines the Mendix low-code platform with Siemens' Graph Studio and AI Studio software to enable enterprises to deploy AI-driven applications and agents faster, with full traceability and control. By connecting data, models, and workflows on a single governed foundation, Intelligence Center X helps companies turn AI ambition into real value gains.

In this role, you will help our customers transform their businesses by addressing a critical market challenge: while companies have invested heavily in AI, many struggle to scale beyond pilots due to fragmented data, inconsistent governance, and disconnected insights. Intelligence Center X closes that gap as the production-ready system that orchestrates people and AI agents together, with full auditability and policy controls. You'll work with enterprise leaders across industries to demonstrate how Intelligence Center X enables proactive, data-driven decision-making and automated workflows that drive efficiency and competitive advantage.

**Key Responsibilities:**

• Drive innovation: Identify and qualify leads for Intelligence Center X – from low-code applications to AI and data science solutions

• Build a strong pipeline: Develop high-value opportunities through strategic account and opportunity planning

• Engage at the C-level: Build relationships at the highest executive levels to address business challenges and transformation priorities

• Present product differentiation: Demonstrate the unique value of both platforms – Mendix for low-code and Graph Studio and AI Cloud for data-driven automation

• Data strategy & automation: Showcase how Intelligence Center X enables organizations to adopt proactive, data-driven approaches and automated insights for smarter decisions

• Take ownership: Lead the entire sales cycle – from uncovering opportunities to facilitating negotiations and achieving successful deals

**Qualifications:**

• Proven track record of successfully selling enterprise platform solutions such as PaaS, low-code, or AI/data science solutions

• Professional experience selling to Financial Services, Manufacturing, or other key industries with an established network in the DACH region

• Demonstrated ability to manage complex, multi-step sales cycles and collaborate effectively with cross-functional teams

• Fluent in German and English with excellent communication skills to articulate business value to C-level stakeholders

• Passion for data-driven strategies, digital transformation, and automation-focused solutions

• Willingness to travel within the DACH region

**Why Us**

At Siemens Software, flexibility is how we work—hybrid by default, built on trust and autonomy. Together, 30,000 people across more than 200 countries build technology that shapes the real world. You'll grow through real projects, strong technical peers, and global mobility, backed by the scale and benefits of an industrial software leader. We're committed to equality and inclusion, and we hire based on merit, skills, and impact. Bring your curiosity and creativity and help us shape tomorrow!

**Our Benefits & Rewards**

The total cash compensation range for this position is €135,000 to €180,000 with 50% of this being comprised of an annual incentive target (100% achievement). The actual compensation offered is based on the successful candidate's job-related skills, experience, and relevant education/training. Siemens offers health and wellness benefits to employees; you can access the benefits available in your country via the link: [https://jobs.sw.siemens.com/benefits/](https://jobs.sw.siemens.com/benefits/)

**Diversity & Inclusion**

We value equal opportunities and welcome applications from people with disabilities. At Siemens, we believe people who've had real experiences dealing with being different will excel as leaders. Let's foster a culture of creativity and innovation. We will ensure that individuals with disabilities are provided reasonable accommodation to participate in the job application or interview process, to perform essential job functions, and to receive other benefits and privileges of employment. Please contact us to request accommodation.

**Siemens Software. Transform the Everyday**

#LI-Hybrid #LI-Mendix #SaaS #LI-LP2

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
