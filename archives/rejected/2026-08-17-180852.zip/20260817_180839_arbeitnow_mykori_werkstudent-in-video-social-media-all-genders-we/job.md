# Werkstudent:in Video & Social Media (all genders welcome)

Posted: 2026-08-17T14:30:28Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Du willst mit der Kamera arbeiten und Sachen machen, die auch wirklich rausgehen? Bei mykori dreht sich alles um gesellschaftliches Engagement: Genossenschaftsbanken und Sparkassen fördern jedes Jahr Vereine, Schulen und Projekte in ihrer Region. Wir bauen die Software, mit der sie das an einer Stelle steuern und den Überblick behalten.

Für dich heißt das: Du bist dabei, wenn wir diese Projekte besuchen, und machst daraus unsere Videos.

## Aufgaben

Der größte Teil deiner Zeit geht in Dreh, Schnitt und Aufbereitung. Planung und Ablage laufen nebenher mit.

- **Du drehst und fotografierst.** Talking-Head- und Erklärformate mit dem Team im Büro in Bielefeld, Interviews mit unseren Kund:innen vor Ort, Material von Messen und Events.

- **Du schneidest.** Aus dem Rohmaterial baust du Formate, die man auch zu Ende schaut: Schnitt, Untertitel, Grafik, Ton.

- **Du drehst unsere Erfolgsgeschichten.** Unsere Kund:innen bewegen mit mykori eine Menge in ihrer Region. Diese Geschichten holst du mit uns vor Ort ab: Video, Bilder, Zitate und Kennzahlen für Website, LinkedIn und Vertrieb.

- **Du bringst eigene Ideen mit.** Du verfolgst, was auf LinkedIn funktioniert, und überträgst es auf unsere Zielgruppe, statt Trends nur nachzubauen.

- **Du hältst den Content-Plan am Laufen.** Themen eintragen, Posts einplanen und das Material so ablegen, dass wir jeden Clip in einer Minute wiederfinden.

## Qualifikation

- Du hast schon eigene Sachen umgesetzt, von der Idee über Dreh oder Shooting und Schnitt bis zum fertigen Post. Ob für die Uni, einen Verein, nebenbei oder im Job, ist uns egal

- Du hast ein Gespür dafür, was auf welcher Plattform funktioniert, und erzählst eine Geschichte, statt Clips aneinanderzureihen

- Du bist sicher im Schnitt und in der Bildbearbeitung. Womit du arbeitest, ist deine Sache

- Du arbeitest strukturiert, zuverlässig und organisierst dich auch bei wechselnden Aufgaben gut selbst

- Du bringst deine Kreativität und deine Ideen ein, arbeitest gerne im Team und hands-on

Ansonsten gilt bei uns: *Hire for attitude, train for skills*. Bedeutet: Du als Mensch, deine Mentalität, dein Drang zu lernen und deine Motivation, hier mit uns an mykori zu arbeiten, stehen an erster Stelle. Uni, Semester, Studiengang? Optional! Hauptsache, du bist eingeschrieben.

Überzeug uns von dir!

**Wo du arbeitest**

Die Drehtage sind der feste Teil der Rolle. Dafür bist du bei uns im Büro in Bielefeld oder mit uns bei Kund:innen vor Ort. Du solltest also in erreichbarer Nähe wohnen.

Alles andere ist flexibel. In der Einarbeitung bist du viel bei uns, danach machst du Schnitt, Planung und Bearbeitung, wo du willst. Wenn das Material im Kasten ist, geht das auch mal eine Woche aus Italien, Spanien oder Bangkok. Solange die Drehtermine stehen und wir uns abstimmen können, passt das für uns.

## Benefits

Wir schätzen dich als Person und Mensch, das wirst du bei mykori merken.

Unter anderem bieten wir dir:

- Das Equipment, mit dem du gut arbeiten kannst: eine gute Videokamera, Mikrofon und die Lizenzen für Schnitt und Bearbeitung. Was dir darüber hinaus fehlt, besorgen wir

- MacBook als Arbeitsgerät, welches du auch privat für Uni & Co. verwenden darfst

- Kurze Wege: Du arbeitest den größten Teil der Zeit direkt mit Yannick aus dem Marketing, dazu regelmäßig mit Max, unserem Gründer. Dazwischen sitzt niemand

- Flexible Arbeitszeiten, Home-Office und Workation, sobald die Drehtermine stehen

- Verantwortung und echten Gestaltungsspielraum für deine eigenen Formate

- Arbeiten in einem Team mit Impact. Wir wollen zusammen etwas bewegen und fördern deine Leidenschaft

- Eine wertschätzende Arbeitskultur

- Persönliche und berufliche Weiterentwicklungsmöglichkeiten

- Natürlich auch bezahlten Urlaub

- Enge Vernetzung zur Start-up-Szene: Wir sind eng mit der Founders Foundation (der Start-up-Schmiede der Bertelsmann Stiftung) verbunden und du kannst regelmäßig an interessanten Veranstaltungen für Gründungsinteressierte teilnehmen

**Zum Prozess**

So läuft es bei uns: drei kurze Gespräche, dann kann es losgehen.

- Kurzes Kennenlernen mit Melissa.

- Ein Call mit Max, unserem Gründer. Du lernst mykori kennen, wir deine Ziele.

- Ein Gespräch mit Yannick, mit dem du später im Alltag zusammenarbeitest, und Max. Bring gerne etwas mit, das du gemacht hast. Ein Link reicht, vorbereiten musst du nichts.

Wir sagen dir gleich im ersten Gespräch, wie es zeitlich bei uns weitergeht. Wir freuen uns darauf, dich kennenzulernen! 🚀

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
