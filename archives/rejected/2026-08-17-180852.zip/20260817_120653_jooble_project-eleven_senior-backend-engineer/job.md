# Senior Backend Engineer

Posted: 2026-08-13T00:00:00.0000000

## Rejection

- Category: tech_stack
- Reason: role does not mention Go/Golang or PHP

...**Senior Backend Engineer **
We're looking for a Senior Backend Engineer to join our growing Product Engineering team. You'll play a pivotal role... ...a post-quantum world. 
This role is a full-time, fully **remote **position in Europe (GMT to GMT+2). 
Responsibilities...
