# Referent:in Kommunikation & Verbandsorganisation

Posted: 2026-08-17T12:30:34Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**Teilzeit | ca. 20–25 Stunden/Woche | Großraum Frankfurt | flexibel & überwiegend remote**

Sie möchten Kommunikation mitgestalten, eigene Ideen einbringen und mit Ihrer Arbeit etwas bewegen?

Der **Deutsche Schädlingsbekämpfer-Verband e. V. (DSV)** stellt seine Geschäftsstelle neu auf. Dafür suchen wir zur Direkteinstellung eine kommunikativ starke Persönlichkeit, die gerne schreibt, strukturiert arbeitet und Freude daran hat, Verantwortung zu übernehmen.

Als **Referent:in Kommunikation & Verbandsorganisation (m/w/d)** gestalten Sie die Kommunikation mit Mitgliedern, Öffentlichkeit und weiteren Stakeholdern und arbeiten eng mit dem ehrenamtlichen Vorstand zusammen. Dabei erwartet Sie keine Rolle mit starren, bereits vollständig definierten Abläufen: Sie haben die Möglichkeit, eigene Ideen einzubringen, Kommunikationswege weiterzuentwickeln und den Aufbau einer modernen, digital arbeitenden Geschäftsstelle aktiv mitzugestalten.

## Aufgaben

- Sie gestalten den DSV-Newsletter – von der Themenplanung und Redaktion über Layout und Versand bis zur Auswertung.

- Sie halten die Website inhaltlich aktuell und pflegen unter anderem Veröffentlichungen, Termine, Downloads und weitere relevante Informationen.

- Sie entwickeln die Social-Media-Kommunikation, insbesondere auf LinkedIn, weiter und planen, erstellen und veröffentlichen passende Inhalte.

- Sie bereiten Fach- und Verbandsthemen für Mitglieder, Medien, Öffentlichkeit und weitere Stakeholder verständlich, seriös und zielgruppengerecht auf.

- Sie unterstützen die Presse- und Öffentlichkeitsarbeit und wirken an Presseinformationen, Fachbeiträgen, Brancheninformationen und der politischen Kommunikation mit.

- Sie begleiten Veranstaltungen, Mitgliederversammlungen und die DSV-Messe kommunikativ und koordinieren die dazugehörigen Kommunikationsmaterialien.

- Sie arbeiten mit externen Partnern wie der Werbeagentur zusammen und sorgen für eine gute Abstimmung der gemeinsamen Kommunikationsmaßnahmen.

- In der Zusammenarbeit mit dem ehrenamtlichen Vorstand übernehmen Sie eine wichtige koordinierende Rolle: Sie sammeln und strukturieren Themen für die regelmäßigen Vorstandstermine, schaffen einen guten Überblick und behalten gemeinsam vereinbarte nächste Schritte im Blick.

- Sie bringen Ihre Perspektive und eigene Empfehlungen ein und entwickeln gemeinsam mit dem Vorstand Kommunikationswege und Arbeitsstrukturen weiter.

**Das macht die Rolle besonders**

**Mitgestalten statt nur umsetzen:** Die Geschäftsstelle befindet sich im Neuaufbau. Ihre Ideen und Erfahrungen sind ausdrücklich gefragt, wenn neue Strukturen und Arbeitsweisen entstehen.

**Verantwortung in echter Teilzeit:** Sie übernehmen eine vielseitige und verantwortungsvolle Aufgabe bei einem Umfang von ca. 20–25 Stunden pro Woche.

**Nah an den Themen und Entscheidungen:** Sie arbeiten direkt mit dem ehrenamtlichen Vorstand zusammen und erhalten Einblick in die Themen, die den Verband und seine Branche bewegen.

**Freiraum für Ihre Arbeitsweise:** Die Rolle bietet Ihnen die Möglichkeit, eigene Ideen einzubringen, Empfehlungen auszusprechen und Themen selbstständig zu gestalten.

**Kommunikation in ihrer ganzen Vielfalt:** Newsletter, Website, Social Media, Mitgliederkommunikation, Öffentlichkeitsarbeit und Veranstaltungen sorgen für ein abwechslungsreiches Aufgabenspektrum.

**Eine neue Branche kennenlernen:** Kenntnisse in der Schädlingsbekämpfung werden nicht vorausgesetzt. Sie erhalten die Möglichkeit, sich Schritt für Schritt mit der Branche, dem Verband und seinen Themen vertraut zu machen.

## Qualifikation

**Das bringen Sie mit – Must** **have**

- Sie schreiben gerne und können auch komplexere Informationen verständlich, präzise und zielgruppengerecht aufbereiten.

- Sie bringen praktische Erfahrung mit digitaler Kommunikation mit und sind mit Themen wie Website/CMS, Newsletter und Social Media grundsätzlich vertraut.

- Sie arbeiten gerne selbstständig und strukturiert, können unterschiedliche Themen gut ordnen und behalten auch mehrere Aufgaben zuverlässig im Blick.

- Sie übernehmen gerne Verantwortung für Ihre Themen und haben Freude daran, diese von der Idee bis zur Umsetzung zu begleiten.

- Sie kommunizieren verbindlich und wertschätzend und können unterschiedliche Ansprechpartner:innen und Perspektiven gut zusammenbringen.

- Sie fühlen sich in einem Arbeitsumfeld wohl, in dem noch nicht jeder Prozess abschließend definiert ist und Ihre Ideen ausdrücklich willkommen sind.

- Sie sind neugierig auf neue Themen und haben Lust, sich in den DSV und eine für Sie möglicherweise noch unbekannte Branche einzuarbeiten.

**Das bringen Sie mit – Nice to have**

- Erfahrung aus Kommunikation, PR, Redaktion, Marketing- oder Mitgliederkommunikation.

- Erfahrung in der Zusammenarbeit mit Vorständen, Geschäftsführungen oder anderen Entscheidungsträger:innen.

- Kenntnisse im Umgang mit Adobe und/oder Canva.

- Erfahrung in der Presse- und Öffentlichkeitsarbeit oder der institutionellen bzw. politischen Kommunikation.

- Ein Studium oder eine Ausbildung aus Kommunikation, Medien, Marketing oder einem kaufmännischen Umfeld kann hilfreich sein – ist aber keine Voraussetzung.

**Entscheidender als ein perfekter Lebenslauf sind Ihre kommunikativen Fähigkeiten, Eigeninitiative, Lernbereitschaft und die Freude daran, Verantwortung zu übernehmen und gemeinsam etwas aufzubauen.**

## Benefits

**Das wird Ihnen geboten**

- **Flexible Teilzeit:** Die Position ist mit ca. 20–25 Stunden pro Woche vorgesehen. Ihre Arbeitszeit können Sie flexibel über die Woche verteilen.

- **Flexibles Arbeiten:** Homeoffice ist fester Bestandteil des Arbeitsmodells. Wenn Sie vor Ort arbeiten möchten, steht Ihnen eine Regus-Office-Lösung im Raum Frankfurt zur Verfügung.

- **Transparentes Gehalt:** Bei 20 Wochenstunden liegt der Gehaltsrahmen bei **24.000–28.000 € brutto pro Jahr**. Bei einem höheren Stundenumfang wird das Gehalt entsprechend angepasst.

- **28 Urlaubstage**

- **Planbare Präsenz:** Vor-Ort- und Veranstaltungstermine finden nur gelegentlich statt und sind grundsätzlich gut planbar.

- **Abwechslung und Verantwortung:** Sie erwartet ein vielseitiges Aufgabengebiet rund um Kommunikation und Verbandsorganisation mit direkter Zusammenarbeit mit dem Vorstand.

- **Individuelle Zusatzleistungen:** Je nach persönlicher Vereinbarung können beispielsweise eine Gutscheinkarte, betriebliche Altersvorsorge, JobRad oder Corporate Benefits Teil des Gesamtpakets sein.

Senden Sie uns Ihre Kontaktdaten und wir melden uns innerhalb von 48 Stunden bei Ihnen und stellen Ihnen die Position in einem kurzen Gespräch vor.

Danach entscheiden Sie, ob Sie in den Auswahlprozess einsteigen möchten.

Die HR-Werkstatt unterstützt unseren Kunden im Besetzungsprozess dieser Vakanz. Etwaige Unterlagen werden von uns entgegengenommen und erst im Rahmen des weiteren Bewerbungsprozesses – also nach dem Erstgespräch und mit Ihrer Zustimmung – an unseren Kunden weitergeleitet

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
