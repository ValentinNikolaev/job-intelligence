# Servicetechniker Kältetechnik / Umweltsimulation (m/w/d) | bis zu 32 €/h

Posted: 2026-08-17T15:00:29Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Sie möchten Teil eines familiären, mittelständischen und gleichzeitig sehr erfolgreichen Industrieunternehmens werden, bei dem Sie als Servicetechniker mit Kältesystemen von modernen und innovativen Umweltsimulationsanlagen zu tun haben? Sie möchten spannende Kunden wie z.B. BMW, Audi, Porsche, Frauenhofer, ZF, Schott, bertrandt und viele mehr kennen lernen? Sie wollen in einem Unternehmen arbeiten, in dem auf das Wohl der Mitarbeiter geachtet wird und in dem es keine Wochenendarbeit oder Nachtschichten gibt? Sie möchten wohnortnahe Projekte ohne Auswärtsübernachtungen übernehmen und direkt von Zuhause aus mit dem eigenen Firmenfahrzeug den Arbeitstag beginnen? Sie wünschen sich mehr als nur ein faires Gehalt?

Dann könnte dieses unbefristete Jobangebot für Sie genau das Richtige sein!

**Servicetechniker Kältetechnik / Umweltsimulation (m/w/d) | bis zu 32 €/h**

## Aufgaben

- Wartung, Service und Montage von Kälteanlagen und Klimaprüfkammern beim Kunden vor Ort (firmeneigene Anlagen und Fremdanlagen)

- Inbetriebnahmen nach Auslieferung der Anlagen

- Kundenschulung an den Anlagen

## Qualifikation

- Absolvierte Ausbildung als Mechatroniker für Kälte- und Klimatechnik, als Kälteanlagenbauer oder eine vergleichbare Ausbildung/Weiterbildung/Berufserfahrung

- Großer Kälteschein

- Führerschein Klasse B

- Gute deutsche Sprachkenntnisse in Wort und Schrift

## Benefits

- **Attraktive Vergütung:** zwischen 24 bis 32 €/h bzw. 54.000 – 72.000 €/Jahr mit Firmenwagen und 13. Gehalt

- **Spannendes Arbeitsumfeld:** Arbeiten Sie als Servicetechniker für ein bedeutsames, zukunftsträchtiges und innovatives Produkt (Umweltsimulationsanlagen)

- **Namhafte Kunden:** Lernen Sie spannende Kunden und Großkunden aus dem Automobilbereich, der Forschung und anderen Branchen kennen

- **Wohlfühl-Atmosphäre:** Genießen Sie alle Vorteile eines erfolgreichen und stabilen Mittelständers: beste Rahmenbedingungen, kurze Entscheidungswege, flache Hierarchien, Teamspirit, Wissenstransfer

- **Mitarbeiterorientierung:** Profitieren Sie von der mitarbeiterfreundlichen Unternehmensphilosophie ohne Nachtschichten und Wochenendarbeit

**Haben wir Ihr Interesse geweckt?**

Wir freuen uns sehr auf Ihre Kontaktaufnahme und Ihre Bewerbung. Gerne senden wir Ihnen dann eine ausführliche Informationsbroschüre mit allen Details zum Jobangebot zu.

Bei Rückfragen können Sie sich unter der +49 176 5521 6618 vorab auch sehr gerne telefonisch bei dem zuständigen Ansprechpartner Herr Daniel Dercho melden.

Bei der Position handelt es sich um eine unbefristete Festanstellung direkt bei unserem Kunden. Die Betreuung und Vermittlung sind unsere kostenfreien Serviceleistungen für Sie als Bewerber.

# Kältetechnik # Klimatechnik # Kälteanlagenbauer # Industriekälte # Mechatroniker # Anlagenmechaniker # SHK # HLS

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
