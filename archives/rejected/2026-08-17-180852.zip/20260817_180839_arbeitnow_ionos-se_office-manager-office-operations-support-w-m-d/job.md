# Office Manager / Office Operations Support (w/m/d)

Posted: 2026-08-17T15:00:28Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Bei IONOS arbeitest Du bei dem führenden europäischen Anbieter von Cloud-Infrastruktur, Cloud-Services und Hosting-Dienstleistungen partnerschaftlich mit unterschiedlichen Teams zusammen. Wir bieten Dir eine Perspektive in einer der zukunftssichersten Branchen. Uns zeichnen offene Arbeitsstrukturen, Duz-Kultur und flache Hierarchien mit unvergleichlichem Team-Spirit aus. Wir sind fest davon überzeugt, dass Job und Spaß vereinbar sind und bieten Dir hierfür das entsprechende Umfeld. Bei ständigem Wachstum sind wir stets auf der Suche nach neuen Teammitgliedern. Werde Teil von IONOS und lass uns gemeinsam wachsen.

## Aufgabenbereich

Bei IONOS bringst Du täglich Ordnung in die Dinge, die zählen – und das buchstäblich. Als Office Manager oder Office Operations Support bist Du das Herzstück unseres Büros: die erste Anlaufstelle für Kolleg:innen, Dienstleister und Gäste. Du schaffst eine Arbeitsumgebung, in der sich alle wohlfühlen, Prozesse reibungslos laufen und nichts dem Zufall überlassen wird.

- **Empfang & Gästebetreuung:** Du bist das freundliche Gesicht unseres Unternehmens – Du empfängst Gäste und Besucher:innen professionell, koordinierst Meetingräume und sorgst dafür, dass unsere Mitarbeitenden jederzeit einen gut organisierten Anlaufpunkt vorfinden.

- **Büroorganisation & Logistik:** Du planst und optimierst eigenständig die Bestände an Büromaterialien, Verbrauchsgütern und Cateringartikeln (Kaffee, Getränke, Snacks, Sanitärprodukte) – mit Blick auf Effizienz und Verfügbarkeit. Außerdem koordinierst Du die gesamte ein- und ausgehende Paket- und Postlogistik, einschließlich komplexer Sendungen und IT-Hardware-Versand.

- **Infrastruktur & Facility Management:** Du bist die zentrale Schnittstelle zum Gebäudemanagement und zu externen Dienstleistern: Du überwachst Wartungspläne, koordinierst Reparaturen und sorgst dafür, dass unser Büro stets in einwandfreiem Zustand ist. Dabei arbeitest Du eng mit dem Einkauf zusammen und bringst Deine operativen Anforderungen proaktiv ein.

- **Zugangsverwaltung:** Du pflegst Zugangssysteme, aktualisierst Sitzpläne und unterstützt HR aktiv bei On- und Offboarding-Prozessen durch die Einrichtung und Verwaltung von Zugangsberechtigungen.

- **Arbeitssicherheit & Events:** Du trägst aktiv zur Einhaltung von Arbeitsschutz- und Brandschutzanforderungen bei und arbeitest dabei eng mit der Sicherheitsbeauftragten zusammen. Darüber hinaus planst und koordinierst Du interne Events, All-Hands-Meetings, Partys und externe Konferenzen.

## Qualifikationen

- **Berufserfahrung:** Du hast mindestens 1–3 Jahre nachweisbare Berufserfahrung im Office Management, Facility Management, Front Office oder in einer vergleichbaren administrativen Funktion.

- **Prozess- & Organisationsverständnis:** Du arbeitest strukturiert und eigenverantwortlich, verstehst betriebliche Abläufe und hast ein gutes Gespür für effiziente Bestands- und Wartungsplanung.

- **Serviceorientierung & Hands-on-Mentalität:** Du bist bekannt für Deine hohe Kunden- und Mitarbeiterorientierung – Du packst an, wo es gebraucht wird, und findest auch in unerwarteten Situationen pragmatische Lösungen.

- **Digitale Kompetenz:** Du arbeitest sicher mit modernen Office-Tools und hast grundsätzliche Offenheit gegenüber digitalen Arbeitsmitteln, Automatisierungsansätzen und neuen Systemen.

- **Kommunikation & Compliance:** Du kommunizierst klar und professionell auf Deutsch (Englischkenntnisse von Vorteil) und verfügst über Grundkenntnisse im Bereich Datenschutz und Informationssicherheit.

- **Persönlichkeit:** Du bist teamorientiert, zuverlässig und bringst ausgezeichnete Organisations- und Multitasking-Fähigkeiten mit. Flexibilität, Detailgenauigkeit und Lösungsorientierung sind für Dich selbstverständlich.

## Benefits

- Flexible Arbeitszeiten durch Vertrauensarbeitszeit.

- An einigen Standorten eine bezuschusste Kantine und verschiedene kostenfreie Getränke.

- Moderne Büroflächen mit sehr guter Verkehrsanbindung.

- Diverse Mitarbeiterrabatte für Aktivitäten und Produkte.

- Mitarbeiterevents wie Sommer- und Winterfeiern, sowie Workshops.

- Zahlreiche Weiterbildungs- und Entwicklungsmöglichkeiten.

- Verschiedene Gesundheitsangebote, wie Sport- und Gesundheitskurse.

## Über IONOS

IONOS ist der führende europäische Digitalisierungs-Partner für kleine und mittlere Unternehmen (KMU). IONOS hat mehr als sechs Millionen Kundinnen und Kunden und ist mit einer weltweit verfügbaren Plattform in 18 Märkten in Europa und Nordamerika aktiv. Mit seinen Web Presence & Productivity-Angeboten agiert das Unternehmen als “One-Stop-Shop" für alle Digitalisierungs-Bedürfnisse - von Domains und Webhosting über klassische Website-Builder und Do-It-Yourself-Lösungen, von E-Commerce bis zu Online-Marketing-Tools. Darüber hinaus bietet IONOS Cloud-Lösungen für Firmen, die im Zuge der Weiterentwicklung ihres Geschäfts in die Cloud wechseln möchten.

Wir wertschätzen Vielfalt und begrüßen alle Bewerbungen – unabhängig von z. B. Geschlecht, Nationalität, ethnischer und sozialer Herkunft, Religion, Behinderung, Alter sowie sexueller Orientierung und Identität, körperlichen Merkmalen, Familienstand oder einem anderen sachfremden Kriterium nach geltendem Recht.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
