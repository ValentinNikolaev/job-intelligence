# Werkstudent HR Operations (m/w/d)

Posted: 2026-08-17T14:24:21Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**Hi, wir sind Doonails! 💅🏼**

Ein schnell wachsendes Beauty-Startup, das die Manikürewelt revolutioniert. Mit innovativen Produkten, einer starken Community und Präsenz im Online-Shop sowie bei führenden Retail-Partnern bringen wir Studio-Qualität direkt nach Hause, einfach, schnell und stilvoll.

Und genau hier kommst **DU** ins Spiel.

Unser People-Team braucht Verstärkung 😍 und das könnte deine Chance sein hautnah mitzuerleben, wie People Themen in einem datengetriebenen Omnichannel-Scale-up wirklich funktionieren! Als Werkstudent HR Operations (m/w/d) wirst du zur rechten Hand in allem, was den People-Alltag am Laufen hält: von Verträgen über sauber gepflegte Daten bis zu den Prozessen, die ein Team wirklich zusammenhalten.

**Deine Rolle & dein Impact ⚡️**

Du unterstützt das HR-Team bei den unterschiedlichsten HR-Ops-Themen und arbeitest vor allem unserer HR-Ops Managerin zu: Sie setzt Rahmen und Standards, du führst innerhalb dieses Rahmens sauber aus, denkst mit und hältst ihr den Rücken frei. Dabei wirst du außerdem Einblicke in andere HR Bereiche wie People & Culture, Recruiting und Development erhalten.

**Deine zentralen Aufgaben 👩‍💻👨‍💻**

- Du bereitest Personaldokumente vor - Arbeitsverträge, NDAs, Änderungsvereinbarungen, Informationsschreiben und weitere HR-Unterlagen (finale Freigabe bleibt bei HR-Ops Managerin).

- Du koordinierst die Kommunikation mit unserer externen Lohnbuchhaltung, z.B. bei Lohnsteuerbescheinigungen, Behördenanfragen und Mitarbeiteranliegen.

- Du pflegst und entwickelst unser HR-Tool Personio weiter - Stammdaten, Datenqualität, digitale Personalakten und Prozessverbesserungen im System.-

- Du bereitest Auswertungen und Dashboards auf, z.B. zu Überstunden, Urlaubstagen und weiteren HR-Kennzahlen.

- Du recherchierst eigenständig zu HR-Themen wie gesetzliche Änderungen, arbeitsrechtliche Entwicklungen, Best Practices.

- Du dokumentierst SOPs, unterstützt bei HR-Projekten und bei der Optimierung interner Prozesse.

- Du bereitest Reisekosten und Belege auf und unterstützt bei der Benefits-Administration (An- und Abmeldungen, z.B. Urban Sports, bAV).

**Das bringst du mit 🤝**

- Du bist eingeschriebene:r Student:in - idealerweise mit Bezug zu BWL, Psychologie, HR oder etwas Vergleichbarem.

- Du arbeitest strukturiert, genau und zuverlässig und behältst auch bei vielen kleinen To-dos den Überblick.

- Du gehst sicher mit Tools wie Google Sheets oder KI Tools um und hast Lust, dich in HR-Systeme wie Personio einzuarbeiten.

- Du packst gerne an und denkst mit, statt nur abzuarbeiten.

- Diskretion und ein sauberer Umgang mit sensiblen Daten sind für dich selbstverständlich.

- Du kommunizierst sicher auf Deutsch, Englisch ist ein Plus.

**Was wir dir bieten 💝**

- 💸 Faire Bezahlung, angepasst an deine Qualifikation & Erfahrung

-

🤝 Ein echtes Ownership-Rollenprofil mit viel Vertrauen & Gestaltungsspielraum

-

📈 Wachstumspotenzial: übernimm Verantwortung & bring deine Ideen direkt ein

-

🥳 Teamevents in ganz Europa, weil ein starkes Team alles ist

**Ready? Wir freuen uns auf dich! ✨**

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
