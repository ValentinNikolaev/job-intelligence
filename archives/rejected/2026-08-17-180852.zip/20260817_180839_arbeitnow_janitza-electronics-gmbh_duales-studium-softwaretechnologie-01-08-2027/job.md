# Duales Studium Softwaretechnologie - 01.08.2027

Posted: 2026-08-17T13:20:15Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Mit zukunftsweisenden Hard- und Software-Lösungen ermöglicht Janitza die Energie zu messen, auszuwerten und verfügbar zu machen. Janitza trägt so dazu bei, dass Unternehmen Ressourcen schonen, produktiv bleiben und erfolgreich sind. Werde Teil eines nachhaltig wachsenden Unternehmens und nutze deine Arbeitszeit sinnvoll. Denn Arbeitszeit ist Lebenszeit.

Du willst Energie messbar machen, Dinge neu denken und die Zukunft mitentwickeln?
Dann sag „Ja!“ zu Janitza als: Dualer Student (m/w/d) Softwaretechnologie ab August 2027

**Deine Aufgaben**

-

Du unterstützt unsere Entwickler in der Neu- und Weiterentwicklung unserer Kundensoftware

-

Im Rahmen von Implementierungsentscheidungen führst du Vorabanalysen durch, baust Prototypen, um Tools auszuprobieren und sprichst unseren Softwareentwicklern Empfehlungen aus

-

Du lernst bestehende Anwendungen weiterzuentwickeln und zu optimieren

-

Im der Abteilung Softwareentwicklung hast du die Möglichkeit an realen Zusatzprojekten aktiv mitzuarbeiten

-

Bei Softwaretests unterstützt du bei der Vorbereitung und Durchführung

-

Du lernst die moderne agile Arbeitsweise kennen (bspw. Scrum-Framework)

** **

**Unser Angebot**

-

Attraktive Vergütung (angelehnt an den Tarif Metall Hessen)

-

30 Tage Urlaubsanspruch pro Jahr

-

Fachliche und persönliche Weiterbildungsmöglichkeiten mit Prüfungsvorbereitung

-

Offenheit für neue Ideen als innovatives Unternehmen mit moderner Ausstattung

-

Individuelle Gesundheitsförderung durch eine betriebliche Krankenzusatzversicherung

-

Weitere Benefits (Mitarbeiterrabatte, Fitnessprogramm u.v.m.)

-

Individuelle Förderung und Betreuung

-

Übernahmechancen bei entsprechender Leistung

**Dein Profil**

-

Deine Fachhochschulreife oder allgemeine Hochschulreife hast du (bald) erfolgreich abgeschlossen

-

Du interessierst dich für Software, IT und neue Technologien und möchtest verstehen, wie digitale Lösungen entstehen

-

Du möchtest wissen, was hinter einem innovativen agenten-gesteuerten Softwareprozess steckt

-

Du kannst mit digitalen Anwendungen gut umgehen und besitzt fortgeschrittene PC-Anwenderkenntnisse sowie gute Englischkenntnisse

-

Idealerweise hast du bereits erste Erfahrungen mit Programmierung gesammelt

-

Neugier, Lernbereitschaft, Genauigkeit und eine schnelle Auffassungsgabe runden dein Profil ab

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
