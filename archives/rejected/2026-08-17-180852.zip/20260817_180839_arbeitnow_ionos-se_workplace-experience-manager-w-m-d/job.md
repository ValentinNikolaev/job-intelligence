# Workplace Experience Manager (w/m/d)

Posted: 2026-08-17T12:30:31Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Bei IONOS arbeitest Du bei dem führenden europäischen Anbieter von Cloud-Infrastruktur, Cloud-Services und Hosting-Dienstleistungen partnerschaftlich mit unterschiedlichen Teams zusammen. Wir bieten Dir eine Perspektive in einer der zukunftssichersten Branchen. Uns zeichnen offene Arbeitsstrukturen, Duz-Kultur und flache Hierarchien mit unvergleichlichem Team-Spirit aus. Wir sind fest davon überzeugt, dass Job und Spaß vereinbar sind und bieten Dir hierfür das entsprechende Umfeld. Bei ständigem Wachstum sind wir stets auf der Suche nach neuen Teammitgliedern. Werde Teil von IONOS und lass uns gemeinsam wachsen.

Wir suchen eine dynamische und serviceorientierte Persönlichkeit, die eine zentrale Rolle bei der Gestaltung unserer Arbeitsumgebung am Standort Berlin übernimmt. Bei uns gestaltest Du nicht nur Räume, sondern prägst aktiv die Kultur und das Wohlbefinden unserer Teams – sowohl vor Ort im Büro als auch im Kontext des hybriden Arbeitens. Wenn Du Leidenschaft für exzellenten Service mit operativer Stärke und strategischem Weitblick verbindest, bist Du bei uns genau richtig.

In Deiner Rolle bist Du die zentrale Ansprechperson für ein herausragendes Mitarbeitererlebnis an den Berliner Bürostandorten. Gemeinsam im Peer-Team mit dem Karlsruher Pendant gestaltest Du zudem die taktische und strategische Ausrichtung des gesamtdeutschen Bereichs.

## Aufgaben

- Entwicklung und Umsetzung einer gesamtdeutschen Workplace-Experience-Strategie im Peer-Team mit Karlsruhe sowie Vorbereitung des Bereichs auf eine perspektivische Globalisierung.

- Analyse von Mitarbeiter-Feedback und datengestützte Optimierung der Raumnutzung und Flächeneffizienz.

- Standardisierung von Workplace-Prozessen über alle deutschen Standorte hinweg und Mitgestaltung der KI- und Digitalisierungsroadmap für den Fachbereich.

- Förderung einer inklusiven Unternehmenskultur sowie eigenständige Planung und Durchführung von Teamevents und After-Work-Formaten.

- Zentrale Ansprechperson für alle Mitarbeitenden bei Fragen zum Büroalltag, Koordination des lokalen Office- und Empfangsteams sowie Organisation interner Umzüge.

- Auswahl, Performance-Review und Qualitätssicherung externer Dienstleistungsunternehmen (z. B. Reinigung, Catering, Gebäudetechnik).

- Sicherstellung von Arbeitsschutz- und Sicherheitsstandards sowie Koordination von Schulungen, Brandschutz- und Notfallprotokollen.

## Qualifikationen

Du verfügst über ein abgeschlossenes Studium (z. B. Facility oder Hospitality Management) oder eine vergleichbare Qualifikation mit relevanter Berufserfahrung. Zudem bringst Du folgende Kompetenzen mit:

- Mindestens 3–5 Jahre Berufserfahrung im Bereich Office Management, Facility Management oder Hospitality/Gästebetreuung.

- Erfahrung in der Standardisierung überregionaler Prozesse, im Gebäudebetrieb, in modernem Workplace Design sowie im Projekt- und Dienstleistungsmanagement.

- Ausgeprägte Digitalaffinität und starkes Interesse an KI-Tools und Prozessautomatisierung im Workplace-Bereich.

- Verhandlungssichere Deutsch- und sehr gute Englischkenntnisse in Wort und Schrift.

## Benefits

- Flexible Arbeitszeiten durch Vertrauensarbeitszeit.

- An einigen Standorten eine bezuschusste Kantine und verschiedene kostenfreie Getränke.

- Moderne Büroflächen mit sehr guter Verkehrsanbindung.

- Diverse Mitarbeiterrabatte für Aktivitäten und Produkte.

- Mitarbeiterevents wie Sommer- und Winterfeiern sowie Workshops.

- Zahlreiche Weiterbildungs- und Entwicklungsmöglichkeiten.

- Verschiedene Gesundheitsangebote, wie Sport- und Gesundheitskurse.

## Über IONOS

IONOS ist der führende europäische Digitalisierungs-Partner für kleine und mittlere Unternehmen (KMU). IONOS hat mehr als sechs Millionen Kundinnen und Kunden und ist mit einer weltweit verfügbaren Plattform in 18 Märkten in Europa und Nordamerika aktiv. Mit seinen Web Presence & Productivity-Angeboten agiert das Unternehmen als “One-Stop-Shop" für alle Digitalisierungs-Bedürfnisse - von Domains und Webhosting über klassische Website-Builder und Do-It-Yourself-Lösungen, von E-Commerce bis zu Online-Marketing-Tools. Darüber hinaus bietet IONOS Cloud-Lösungen für Firmen, die im Zuge der Weiterentwicklung ihres Geschäfts in die Cloud wechseln möchten.

Wir wertschätzen Vielfalt und begrüßen alle Bewerbungen – unabhängig von z. B. Geschlecht, Nationalität, ethnischer und sozialer Herkunft, Religion, Behinderung, Alter sowie sexueller Orientierung und Identität, körperlichen Merkmalen, Familienstand oder einem anderen sachfremden Kriterium nach geltendem Recht.

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
