# Fullstack Entwickler:in im Finanzdienstleistungsumfeld (m/w/d)

Posted: 2026-08-17T12:30:33Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

**Deine Aufgaben bei uns im Team:**

Du hast Spaß daran, moderne Anwendungen nicht nur zu entwickeln, sondern wirklich mitzugestalten? Als Fullstack Entwickler:in arbeitest Du mit unseren Kunden aus dem Banken- und Versicherungsumfeld an sicheren, skalierbaren und gut nutzbaren Softwarelösungen. Dabei bringst Du Deine Erfahrung in Backend und Frontend ein, denkst Schnittstellen, Datenflüsse und den späteren Betrieb direkt mit und bist eine verlässliche technische Ansprechperson.

## Aufgaben

**Das erwartet Dich:**

- Du entwickelst und modernisierst Fullstack-Anwendungen in regulierten Umfeldern wie Banken und Versicherungen

- Du konzipierst Backend-Services, APIs, Frontend-Komponenten und stabile Schnittstellen

- Du gestaltest eventgetriebene Architekturen mit, z. B. mit Apache Kafka oder vergleichbaren Technologien

- Du achtest auf Skalierbarkeit, Performance, Sicherheit und eine gute Nutzererfahrung

- Du unterstützt bei DevOps-Themen wie CI/CD, Deployment, Containerisierung und Infrastructure-as-Code

- Du arbeitest agil, bringst Ideen ein und sicherst Code-Qualität durch Testing, Reviews und Dokumentation

- Du nutzt moderne KI-Tools im Entwicklungsprozess sinnvoll und verantwortungsvoll

## Qualifikation

**Das bringst Du mit:**

Du hast ein abgeschlossenes Studium oder eine fundierte Ausbildung im Bereich Informatik und bringst Erfahrung in der Softwareentwicklung mit. Wenn Du das Banken-, Versicherungs- oder Finanzdienstleistungsumfeld bereits kennst, ist das ein Plus – aber kein Muss. Außerdem freuen wir uns über folgende Kenntnisse und Erfahrungen:

- Sichere Entwicklung mit Java, idealerweise Java 17 oder Java 21; Java 11-Erfahrung ist im Migrations- oder Legacy-Kontext hilfreich

- Sehr gute Kenntnisse in Spring, Spring Boot, REST-APIs und modernen Backend-Architekturen

- Erfahrung mit Event Streaming, Messaging oder eventgetriebenen Architekturen, idealerweise mit Apache Kafka

- Frontend-Erfahrung mit React, Angular oder Vue.js sowie TypeScript, JavaScript, HTML und CSS

- Praxis mit relationalen Datenbanken wie PostgreSQL, Oracle, IBM DB2 oder vergleichbaren Systemen

- Idealerweise Erfahrung mit agiler Entwicklung, Cloud, Containerisierung, Kubernetes und CI/CD

- Nice to have: Kotlin, Bash, Infrastructure-as-Code, Observability sowie Security- oder Regulatorik-Erfahrung im Finanzdienstleistungsumfeld

## Benefits

**Wir als Arbeitgeber:**

- Flexible Arbeitszeiten und mobiles Arbeiten – beim Kunden, im Homeoffice oder in unserem modernen Büro mitten in der City

- Weiterbildungen, Coaching und Mentoring für Deine fachliche und persönliche Entwicklung

- Zuschuss zum Deutschlandticket Hannover Job, JobRad und Corporate Benefits

- Unterstützung bei Kita, betrieblicher Altersvorsorge, Wellhub und Sabbatical

- Gemeinsame Firmenevents, Team-Erlebnisse und die Möglichkeit zur Workation

Bei uns sind alle Menschen willkommen, unabhängig von Geschlecht, Hautfarbe, Herkunft oder Religion.

Deine Unterlagen (Lebenslauf und Zeugnisse) sendest du einfach mit der Angabe zum Starttermin und Deiner Gehaltsvorstellung.

**Ansprechpartner:in:**

Susanne Meyer

+49 (511) 26 17 76 - 103

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
