# (Senior) Software Engineer - Android (m/w/d)

Posted: 2026-08-17T14:30:18Z

## Rejection

- Category: role_mismatch
- Reason: title is an obvious mismatch for a backend profile

**Deine Aufgaben**

Bist du ein passionierter Android-Engineer und möchtest deine Erfahrung in einem modernen Software-Unternehmen einbringen? Bewirb dich jetzt und treibe mit uns die Digitalisierung an Schulen mit unserer modernen UEM-Software voran!

Bewirb dich auch, wenn du nicht 100 % der Punkte erfüllst – uns ist Potenzial wichtiger als eine perfekte Checkliste.

- Du entwickelst gemeinsam im agilen Team Android Apps mit Kotlin (schwerpunktmäßig im B2B- und B2E-Umfeld)
- Du bringst deine persönliche Erfahrung und dein Know-how ein, um bestehende Apps zu optimieren
- Du treibst neue Features voran und trägst zur Konzeption und Auswahl geeigneter Technologien bei
- Du führst Code-Reviews von Pull-/Merge-Requests durch, um die Know-how-Verteilung und die Code-Qualität im Team kontinuierlich zu verbessern
- Du setzt Impulse zur Optimierung der Entwicklungs-, Continuous-Integration- (CI) und Continuous-Delivery- (CD) Prozesse, um Gesamtlösung und Betrieb langfristig auf ein neues Niveau zu heben
- Du erweiterst den Code um automatisierte Tests, damit deine Bugfixes dir nicht am nächsten Tag neue Bugs bescheren

**Dein Profil**

- Große Leidenschaft fürs Programmieren und tiefes Verständnis für moderne Softwareentwicklung für Android
- Know-how und ein Gespür für Interaktionsdesign und Usability zur Entwicklung intuitiver mobiler Anwendungen
- Erfahrung bei der Konzeption und Anbindung von RESTful- und/oder GraphQL-APIs
- Nice to have: erste Erfahrung mit Spring Boot
- Nice to have: du hast bereits mit Flutter gearbeitet
- Du arbeitest gerne im Team und hast ein ausgeprägtes Verantwortungsbewusstsein
- Qualitätsbewusstsein mit praktischer Erfahrung in Software-Testing (Unit-Tests, Integrationstests etc.)
- Sehr gute Kommunikationsfähigkeiten in Deutsch und Englisch, in Wort und Schrift

**Was uns wichtig ist**

- Du übernimmst Verantwortung für deinen Code, nicht nur für dein Ticket
- Qualität ist für dich kein Nice-to-have – testgetriebenes Denken gehört für dich zum Handwerk dazu
- Du gibst und nimmst Feedback im Code-Review offen und konstruktiv
- Du denkst über dein Feature hinaus mit – bei CI/CD, Prozessen, Toolauswahl bringst du dich aktiv ein

**Warum wir?**

- **Zeit und Ort, die zu dir passen:** Flexible Arbeitszeiten, saubere Zeiterfassung, die Möglichkeit, in Teilzeit zu arbeiten, und Homeoffice, wann immer es passt.
- **30 Tage Urlaub + 6 Gleittage:** Genug Zeit zum Abschalten, on top of the usual.
- **Gut eingearbeitet:** Mentoring von Tag eins an, damit du schnell ankommst.
- **Macademy:** Unser eigenes Weiterentwicklungsprogramm – für alle, die mehr wollen.
- **Mobil unterwegs:** Wir bezuschussen dein Deutschlandticket.
- **Aufs Rad:** (E-)Bike-Leasing über Jobrad – dank eigener Fahrradgarage und Duschen kommst du entspannt an, egal wie du fährst.
- **Für später vorgesorgt:** Betriebliche Altersvorsorge ist bei uns Standard.
- **Rundum versorgt:** Mittagessen in unserer bezuschussten Kantine, Getränke gibt's den ganzen Tag kostenlos.
- **Fit bleiben:** Wellpass oder Urban Sports Club – so wie's dir passt.
- **Team-Momente:** Regelmäßige Teamevents, die auch wirklich Spaß machen.
- **Unser Zuhause in Stuttgart:** Helle, neue Räume, gut angebunden an den ÖPNV – du kommst schnell und unkompliziert zu uns.

Wir wurden von FOCUS-Business als bester Arbeitgeber im Mittelstand 2026 empfohlen. Überzeuge auch Du Dich von uns und bring Deine Karriere auf das nächste Level.

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
