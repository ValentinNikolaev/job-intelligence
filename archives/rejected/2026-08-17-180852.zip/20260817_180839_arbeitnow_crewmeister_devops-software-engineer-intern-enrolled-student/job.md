# DevOps Software Engineer Intern (Enrolled Students Only) (m/f/d)

Posted: 2026-08-17T14:30:28Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

With over 19,000 customers, Crewmeister is one of the fastest-growing software providers in Munich. This dynamic growth is made possible by the personal development and teamwork of our now more than 60 outstanding employees.

But this is just the beginning: Apply to join us as a Software Engineer Intern, focused on DevOps, learn from the best, and make our success story your own.

**Your Responsibilities**

- Maintain and improve CI/CD pipelines under close supervision of more senior DevOps engineers.

- Monitor system performance and report issues.

- Support in routine maintenance tasks.

- Participate in team meetings and contribute to discussions.

- Learn the tech vision and apply it’s best practices in daily tasks

- **Full time working hours- 40 hours per week, 6 months minimum**

## What you’ll bring to the team

-

**Must be currently enrolled** in a Bachelor’s degree program in Information Technology or a related field.

-

**Internship must be a compulsory component of your degree program.**

-

Competent in technologies for running online software in the cloud, building pipelines and maintaining application environments

-

Exposure to our tech stack (Python, Jenkins, AWS/Azure or GCP)

-

Strong desire to learn and improve

-

Positive, motivated and curious nature

-

Good communication and teamwork skills

-

User-centric mindset

-

Join a dynamic team focused on personal and professional development

-

Enjoy a hybrid work model with a flexible schedule, combining home office and regular in-office days in Munich

-

Work in a modern office in the Werksviertel Start-Up hub with in-house Barista

-

Engage in team-building activities and events like soccer, yoga, and company-wide runs.

-

Enjoy Perks like: lunch vouchers, MacBook, discounted rail pass

With us, you not only receive the security of a financially strong corporation, but also the corporate culture and advancement opportunities of a startup.

It's not just about the job here, but about you and your potential. Show us who you are – convince us with your resume and later in the personal interview.

We look forward to possibly welcoming you to our crew very soon!

Do you have any remaining questions?

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
