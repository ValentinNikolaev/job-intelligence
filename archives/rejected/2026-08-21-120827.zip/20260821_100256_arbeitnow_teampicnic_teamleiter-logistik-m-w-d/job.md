# Teamleiter Logistik (m/w/d)

Posted: 2026-08-21T08:55:26Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

##

## **Kurz und knapp**

Suchst du eine Führungsrolle, in der deine positive Energie und dein Teamgeist den Unterschied machen?

Bei Picnic suchen wir nicht nur jemanden, der Prozesse steuert, sondern eine Führungskraft, die ihr Team inspiriert und jeden Tag zu einem Erfolgserlebnis macht. Als Teamleiter Logistik (m/w/d) bist du das Herzstück des täglichen Betriebs in unserem Fulfillment Center (FC) in **Erding**. Du coachst, motivierst und unterstützt dein Team aus Shoppers, stellst sicher, dass sie sich wohlfühlen und gemeinsam Großes leisten. Dein Engagement ist entscheidend, um unsere Lagerabläufe reibungslos zu gestalten. Im engen Austausch mit anderen Teamleitungen und der Schichtleitung sorgst du dafür, dass wir als großes Team unsere täglichen Ziele erreichen.

## **Das erwartet dich **

- **Teamleitung: **Leite, motiviere und inspiriere täglich ein Team aus 20+ Shoppers. Du bist ihre erste Ansprechperson, hast stets ein offenes Ohr und förderst ihre Entwicklung.

- **Teamwork: **Gemeinsam mit anderen Teamleitungen und der Schichtleitung steuerst du proaktiv die Prozesse im FC. Du trägst maßgeblich zu einer positiven und unterstützenden Arbeitsatmosphäre bei.

- **Tagesgeschäft:** Stelle sicher, dass alle Einkäufe pünktlich, sicher und in bester Qualität das FC verlassen. Dabei bist du der Fels in der Brandung, der auch in stressigen Situationen einen kühlen Kopf bewahrt und Ruhe ausstrahlt.

- **Prozessoptimierung:** Bringe deine Ideen ein und verbessere gemeinsam mit dem Leadership stetig unsere Logistikprozesse. Du ermutigst dein Team, mitzudenken und sich aktiv einzubringen.

- **Faires Gehalt mit Perspektive:** Ein Jahresgehalt zwischen 34.000 € und 38.000 € brutto, bewertet durch jährliche Performance Reviews, für deine persönliche und finanzielle Weiterentwicklung.

## **Das bringst du mit**

- Du hast eine abgeschlossene Berufsausbildung im Bereich Logistik, Hotellerie, Gastronomie oder Ähnlichem absolviert.

- Alternativ bringst du min. 1 Jahr Berufserfahrung in der Teamleitung oder einer ähnlichen Führungsposition in der Logistik mit.

- Du sprichst fließend Deutsch und hast gute Englischkenntnisse, um dich in unserem internationalen Team zu verständigen.

- Du bist flexibel für die Arbeit in zwei Schichten (6:00 – 14:30 Uhr & 14:30 – 23:00 Uhr, auch samstags) in einer 37,5-Stunden-Woche.

- Du liebst es, mit Menschen zusammenzuarbeiten und packst selbst mit an.

## **Darauf kannst du dich freuen**

- **Starte durch - mit uns:** Werde Teil unseres internationalen Teams in einem Umfeld, das echtes Wachstum und eine „Act like an Owner“-Mentalität fördert. Bei uns hast du die Chance, neue Ideen zu testen und direkt miterleben zu können, wie deine Arbeit in unserem schnell wachsenden Unternehmen Wirkung zeigt.

- **Nachhaltigkeit als Kern:** Werde Teil der Revolution. Du trägst zu einer grüneren Zukunft bei – durch unsere 100 % elektrische Flotte und eine Lieferkette, die Lebensmittelverschwendung reduziert.

- **Die Basics:** Wir stellen dir alles für deinen Erfolg bereit – mit Zugang zu modernen und innovativen Tools, die dich im Arbeitsalltag optimal unterstützen, sowie exklusiven Mitarbeiter-Rabatten (Corporate Benefits) für Reisen, Technik und vieles mehr.

- **Zeit zum Auftanken:** Mit 30 Urlaubstagen pro Jahr sorgst du für den perfekten Ausgleich zwischen Arbeit und Erholung.

- **Verpflegung für Gewinner:** Wir kümmern uns um dich. Genieße jeden Tag ein frisches, kostenloses Frühstück, Mittag- und Abendessen in unserem Fulfilment Center, dazu gibt es reichlich Snacks und Obst für den Energiekick zwischendurch.

- **Unvergessliche Momente:** Wir sind mehr als nur ein Team. Ob bei unseren Weihnachts- oder Sommerpartys und weitere Teamevents – wir feiern unsere Erfolge gemeinsam und schaffen Erinnerungen, die verbinden.

- **Lebensmittelretter:** Hol dir unsere exklusiven "Too-Good-To-Go"-Tüten und rette leckere Lebensmittel – nur für unsere Mitarbeitenden!

- **Lerne & wachse:** Profitiere von internen Lern- & Entwicklungsmöglichkeiten durch spannende Workshops und intensive Bootcamps, um deine Skills ständig zu erweitern.

- **Absicherung für morgen:** Wir unterstützen dich mit einem überdurchschnittlichen Zuschuss zur Betrieblichen Altersvorsorge, damit du auch an später denkst.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
