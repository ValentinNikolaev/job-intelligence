# Founding Product & Solutions Engineer (m/f/d)

Posted: 2026-09-04T16:47:43Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

ONYVEN is an early-stage AI startup from the Technical University of Munich ecosystem. We develop software for enterprise operations, focusing on supply chain, logistics and industrial workflows. Working closely with customers, we turn operational challenges into scalable automation.

## Tasks

You will work across product, engineering and customer projects.

• Join customer discovery sessions and map operational workflows

• Identify automation opportunities and translate customer needs into product and technical requirements

• Build and test prototypes using APIs, structured data and AI tools

• Support customer pilots and implementations

• Gather feedback and identify recurring patterns across projects

• Contribute to product and company development

## Requirements

We are looking for a technically strong, curious and proactive person who enjoys solving unfamiliar problems and working directly with customers.

• Experience with some of the following: Python, APIs, SQL, structured data, AI applications or workflow automation

• Strong analytical, communication and collaboration skills

• A relevant technical or analytical background, such as Computer Science, Information Systems, Management and Technology, Industrial Engineering, Operations Research, Data or AI

• Strong English skills. German is an advantage for customer-facing work in Germany

Experience with enterprise software, SAP or ERP systems, supply chain, logistics or industrial environments is an advantage.

Individual eligibility under the EXIST program is required and will be assessed by the responsible university and funding authority.

## Benefits

• Join an early-stage AI startup from the Technical University of Munich ecosystem

• Work directly with the founding team

• Solve real operational problems with enterprise customers

• Contribute across product, technology and customer projects

• Influence product and company development from an early stage

• Take responsibility across the full process, from discovery to implementation

• Develop your role according to your strengths, interests and the needs of the company

Send us your CV or LinkedIn profile. A traditional cover letter is not required. Instead, briefly describe something you started, built or improved through your own initiative.

If the project is approved, funding will take the form of a personal stipend under an agreement with the responsible university or research institution. This posting creates no entitlement to selection, funding, employment or equity. Any future employment or equity arrangement requires a separate written agreement.

We review applications based on relevant experience, skills and fit with the founding project. Depending on application volume, we might be unable to respond to every applicant individually. We will contact candidates selected for the next stage.

We welcome applications regardless of gender, racial or ethnic origin, religion or belief, disability, age or sexual identity.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
