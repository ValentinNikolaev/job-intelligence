# Senior Product Manager

Posted: 2026-08-12T20:40:10Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

We're building a new global Berlitz, and this is your opportunity to help shape it. Nearly 150 years of expertise, meeting the ambition and technology to power a new era of learning.

If you are the kind of person who thrives in a fast-paced environment, isn’t afraid of a blank page, and is excited to help shape the future of a global company undergoing a significant transformation, **you might belong at Berlitz!**

We're looking for a **Senior Product Manager** to own the experience our customers live in every day. Right now, using our product means juggling different tools for leads, performance tracking, billing, compliance, and support.

This isn't a maintenance role. It's a build from the ground up mandate for a product that will touch every customer we have, in every market we operate.

**Your Responsibilities**

-

Own the customer experience end to end, from lead and pipeline management to performance tracking, billing transparency, compliance, and support, unified into one clear, trustworthy product.

-

Design for a genuinely multi sided user base. Customers, their internal teams, and our own internal teams all need different views of the same truth. You'll figure out how to serve all of them without compromise.

-

Turn customer pain into product decisions. Talk directly to customers across our markets, translate what you hear into a sharp, prioritized roadmap, and ship things that make their day to day genuinely easier.

-

Drive company wide visibility and growth. Give both customers and internal teams a real time, trustworthy picture of how the business is performing, market by market.

-

Use AI as your default tool, not a side project. Claude, Claude Code, Cursor, and modern AI prototyping tools are part of your daily workflow for discovery, prototyping, PRD creation, and execution.

-

Move fast, end to end. Take ideas from research and discovery through validation, launch, and iteration, using AI assisted workflows to compress the cycle from "we think" to "we know."

-

Champion the initiative internally. Build the case, rally the stakeholders, and be the person who makes this initiative impossible to ignore.

**Who You Are**

-

5+ years in product management, ideally with exposure to B2B partner ecosystems or enterprise SaaS.

-

You're energized by complexity, not intimidated by it. Multiple user types, multiple markets, multiple stakeholders, one coherent product.

-

You build influence through clarity and trust, not title. You can walk out of a customer conversation and straight into a prioritized roadmap, without losing the thread.

-

Sharp analytical instincts paired with a genuine builder mindset. You'd rather ship a prototype than write another slide.

-

A collaborative operator who makes the people around them better.

**Why You Should Join**

You'll be the product owner for something customers around the world will use every single day, with the freedom to shape it from the ground up, backed by modern AI tooling and a company that's serious about giving its customers a genuinely great product, not just a good enough one.

*At Berlitz, connecting people across languages and cultures is at the heart of what we do. Our global workplace reflects the diverse world we serve, bringing together different backgrounds, experiences and perspectives. We create an inclusive environment where everyone has an equal opportunity to belong, contribute and grow.*

Ready to shape what’s next? Join us and help build the future with us.

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
