# Accounts Payable Accountant EMEA

Posted: 2026-08-12T20:40:10Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

We're building a new global Berlitz, and this is your opportunity to help shape it. Nearly 150 years of expertise, meeting the ambition and technology to power a new era of learning.

If you are the kind of person who thrives in a fast-paced environment, isn’t afraid of a blank page, and is excited to help shape the future of a global company undergoing a significant transformation, **you might belong at Berlitz!**

**What You'll Do**

-

Perform invoice processing and expense reports to ensure accurate disbursement and expense accounting

-

Build and maintain strong supplier relationships, maintain vendor master data, and resolve escalated discrepancies or disputes

-

Ensure accurate vendor statement reconciliations.

-

Ensure compliance with company policies, tax requirements and regulatory standards. Support audits by providing requested documentation

-

Standardize and automate workflows using modern ERP tools – like Netsuite, Tipalti, Emburse.

**What You'll Bring**

-

You have several years of experience in Accounts Payable or Financial Accounting.

-

You have a solid understanding of accounting principles, reconciliations, and month-end processes.

-

You enjoy improving processes and are comfortable working in a changing environment.

-

You communicate clearly and enjoy working with colleagues across different teams and countries.

-

You take ownership of your work and are comfortable managing priorities independently.

-

Experience with NetSuite, Tipalti, Emburse, or similar finance systems is an advantage.

-

Experience working in an international organization or a startup/scale-up environment is a plus.

-

You are fluent in English and German.

## Why Join Berlitz?

-

Join Berlitz at an exciting point in its transformation as we build a new global organization.

-

Be part of creating a modern, digital-first finance function with the opportunity to influence how we work from the beginning.

-

Enjoy the flexibility of a remote-first environment while staying closely connected to an international team that collaborates, supports one another, and regularly comes together in person to connect, celebrate successes, and move ideas forward.

-

Be part of a culture that values ownership, continuous improvement, and the confidence to challenge the status quo.

*At Berlitz, connecting people across languages and cultures is at the heart of what we do. Our global workplace reflects the diverse world we serve, bringing together different backgrounds, experiences and perspectives. We create an inclusive environment where everyone has an equal opportunity to belong, contribute and grow.*

Ready to shape what’s next? Join us and help build the future with us.

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
