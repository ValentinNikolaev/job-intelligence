# Senior Product Designer

Posted: 2026-08-12T20:20:09Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

### Description

At CloudFactory, we are a mission-driven team passionate about unlocking the potential of AI to transform the world. By combining advanced technology with a global network of talented people, we make unusable data usable, driving real-world impact at scale.

More than just a workplace, we’re a global community founded on strong relationships and the belief that meaningful work transforms lives. Our commitment to earning, learning, and serving fuels everything we do as we strive to connect one million people to meaningful work and build leaders worth following.

**Our Culture**

At CloudFactory, we believe in building a workplace where everyone feels empowered, valued, and inspired to bring their authentic selves to work. We are:

- Mission-Driven: We focus on creating economic and social impact.
- People-Centric: We care deeply about our team’s growth, well-being, and sense of belonging.
- Innovative: We embrace change and find better ways to do things together.
- Globally Connected: We foster collaboration between diverse cultures and perspectives.

If you’re passionate about innovation, collaboration, and making a real impact, we’d love to have you on board!

**Role Summary**

We are seeking a Senior Product Designer to join our Product & Technology organization. This role plays a key role in shaping user-centric, end-to-end product experiences across our platform. You will work closely with Engineering, Product Management, and cross-functional stakeholders to transform complex user needs into elegant, scalable design solutions and interaction systems.

This is an exciting opportunity to grow professionally while contributing to a mission-driven organization. As a senior individual contributor, you will balance strategic design thinking with hands-on execution, driving design excellence while mentoring team members and cultivating a culture of continuous learning.

### Key Responsibilities

### User Research & Discovery

- Plan and drive end-to-end user research activities, utilizing appropriate generative and evaluative research methods to uncover complex user needs and motivations.
- Synthesize research findings, data, and user insights into actionable recommendations to inform product decision-making and business strategy.
- Select techniques and tools to define goals, develop user stories, and elicit functional and usability requirements for complex systems.
- Specify measurable criteria for product usability and accessibility across platforms.

### Interaction & Visual Design

- Design complex interaction flows, detailed user paths, and edge cases across varied user contexts.
- Create high-fidelity interactive prototypes for user testing, validation, and stakeholder alignment.
- Deliver visually appealing, scalable, and user-centered visual designs that seamlessly incorporate visual identity and branding standards.
- Proactively identify opportunities for visual and interaction design improvements within the design system and propose implementation solutions.

### Information Architecture & Usability

- Plan and implement clear information architecture and content organization to ensure intuitive findability and task completion.
- Use iterative design approaches to rapidly integrate user feedback and testing results into product iterations.
- Advocate for user-centered design principles, accessibility standards, and usability best practices throughout the product development lifecycle.

### Strategy, Leadership & Mentorship

- Independently set and manage personal OKRs aligned with departmental goals, leading by example to focus the team on outcomes rather than just outputs.
- Act as a role model and mentor to junior designers, developing personalized coaching plans, providing constructive feedback, and facilitating professional growth.
- Champion a culture of continuous learning by introducing new methodologies, tools, and industry trends to the product team.
- Participate in peer reviews and contribute to establishing organizational standards and methods for research and design.

### Cross-Functional Collaboration & Execution

- Partner closely with Product Managers and Engineering from discovery to launch, balancing user needs with business goals and technical feasibility.
- Manage cross-functional dependencies, acting as a bridge between technical and non-technical stakeholders to translate complex concepts clearly.
- Proactively identify and resolve team process bottlenecks to optimize design-to-development workflows.

**Requirements**

### Required Qualifications

- 5+ years of Product Design (UX/UI) experience, with a strong portfolio showcasing end-to-end design processes for complex digital products or platforms.
- Proven experience independently planning, conducting, and synthesizing user research to drive design decisions.
- Demonstrated mastery of interaction design, user flows, information architecture, and high-fidelity interactive prototyping.
- Strong visual design capability with hands-on experience working with and contributing to design systems.
- Track record of setting performance goals/OKRs and driving cross-functional alignment with Product Management and Engineering.
- Demonstrated experience mentoring, coaching, or guiding junior designers and participating in design critiques.
- Deep knowledge of user-centered design principles, accessibility standards, and modern design tools (e.g., Figma).

### Preferred Qualifications

- Experience designing complex B2B SaaS, enterprise platforms, data-heavy applications, or AI/ML-driven user interfaces.
- Experience building, scaling, or maintaining enterprise design systems.
- Proven track record of defining organizational design standards and research frameworks.
- Experience working in high-growth, fast-paced, and Agile development environments.
- Experience designing for platforms with multiple distinct user types, roles, or permission levels.
- Experience working directly with engineering on implementation detail — writing tickets, defining edge cases, and adjusting scope for technical constraints.

### What We Look For

- A user-obsessed designer who thrives on solving intricate workflow and systems-level problems.
- A collaborative team player who builds strong relationships with engineering, product, and business partners.
- An outcome-oriented owner who uses qualitative data and quantitative metrics to validate design decisions.
- A passionate mentor who fosters a culture of learning, feedback, and continuous improvement across the design team.

**Benefits**

At CloudFactory, we believe that work should be more than just a job, it should be a platform for growth, impact, and community. Here, you’ll earn with purpose, learn every day, and serve a mission that truly matters. If you're looking for a career where you can develop professionally, contribute meaningfully, and be part of a global movement, we’d love to have you on this journey!

Join us today and be part of our mission to connect people and technology for a better world! Apply now and bring your whole, authentic self to work, we can’t wait to meet you!

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
