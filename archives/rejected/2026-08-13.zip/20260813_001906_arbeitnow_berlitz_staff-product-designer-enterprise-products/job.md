# Staff Product Designer, Enterprise Products

Posted: 2026-08-12T20:40:10Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

We're building a new global Berlitz, and this is your opportunity to help shape it. Nearly 150 years of expertise, meeting the ambition and technology to power a new era of learning.

If you are the kind of person who thrives in a fast-paced environment, isn’t afraid of a blank page, and is excited to help shape the future of a global company undergoing a significant transformation, **you might belong at Berlitz!**

A lot of our customers today are enterprise HR and L&D teams, but we haven't given those teams a great way to run what they've bought from us, report on it, and track the value. That gap costs us deals and renewals. We're building our Enterprise customer platform to close that gap. The control center that HR and L&D teams use to manage learners, connect their existing LMS and HR systems, track engagement and CEFR progress, and prove Berlitz's ROI to their own leadership. It serves two very different buyers under one roof: a Global HR Director who checks in occasionally for a strategic view, and an L&D Manager who lives in the tool day to day running the program. Getting both right, with no live product to build on, is the job.

As Staff Product Designer, you'll own design for our Enterprise customer platform from the ground up, reporting directly to the VP of Design. You'll work as an equal partner alongside Product Management and Engineering, and you'll be the first dedicated design hire on this product, so the standards, patterns, and process you set will shape how the team designs enterprise software at Berlitz for years to come.

**Your responsibilities**

-

Design our Enterprise customer platform end to end, from a mostly blank slate: user management, LMS and HRIS integrations, SSO and provisioning, reporting and ROI dashboards, and the invoicing and admin workflows enterprise buyers expect.

-

Conduct a lot of customer research. Understand deeply our buyer personas, their jobs to be done, their pain points, and their buying triggers. Talk directly and often with HR directors, L&D managers, and procurement teams to build real empathy for people who touch the product a few times a month, not every day.

-

Design for two distinct users in one product: the L&D Manager who needs fast, frequent, operational tools, and the Global HR Director who needs a clear, summarized view of impact across regions.

-

Build within Berlitz's shared design system while extending it with the patterns a data-heavy, enterprise admin product needs.

-

Help set the vision, strategy, and roadmap for Enterprise Products, balancing what buyers ask for against what actually drives retention and expansion.

-

Partner with Engineering and Product Management to ship an MVP fast, then iterate toward a product that can compete with established competitors.

-

Own part of the Enterprise KPIs (dashboard adoption, admin engagement, renewal and expansion metrics) and know how design moves them.

-

Treat compliance and security requirements, including SSO, SCIM provisioning, GDPR, and accessibility standards, as real design constraints from the start, not afterthoughts.

-

Mentor other product designers at Berlitz as the design team grows around you.

Who you are

-

Have a proven track record designing and shipping B2B enterprise software, ideally admin consoles, reporting tools, or control panels built for HR, L&D, IT, or similarly technical buyers.

-

Experience taking a product from 0 to 1, with little existing structure to lean on and real comfort in ambiguity.

-

AI native experience. You're already deep in context engineering, MCP, generative design tools, and thinking in systems that support that.

-

Experience designing for more than one stakeholder in a single product, and knowing when a workflow needs speed versus when it needs clarity and summary.

-

A strong systems mindset. You've built or extended a design system before, beyond simply working within one someone else built.

-

Confidence handling the unglamorous but critical parts of enterprise product design: integrations, permissions, data-heavy interfaces, and compliance requirements.

-

The ability to work closely with Sales, Customer Success, or Procurement-facing teams to translate what enterprise buyers actually need into a usable product.

-

A results-driven approach. You set an ambitious bar for your own work and hold yourself to it.

-

Fluent English.

**Why you should join**

-

Shape what's next. Our Enterprise customer platform doesn't exist yet. You'll define the product our biggest customers rely on, not maintain someone else's decisions.

-

Impact from day one. You'll be the first dedicated designer on Enterprise Products, working directly with the VP of Design and the leaders sponsoring this build.

-

One global Berlitz. Join a company actively rebuilding itself, with new products, new systems, and new ways of working across every team.

-

True remote-first flexibility.

-

Room to grow while we transform. Berlitz is changing fast, and so is the scope of this role as the product and team grow.

*At Berlitz, connecting people across languages and cultures is at the heart of what we do. Our global workplace reflects the diverse world we serve, bringing together different backgrounds, experiences and perspectives. We create an inclusive environment where everyone has an equal opportunity to belong, contribute and grow.*

Ready to shape what’s next? Join us and help build the future with us.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
