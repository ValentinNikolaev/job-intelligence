# Marketing Manager*in (m/w/d)

Posted: 2026-08-12T20:59:04Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

Du hast Spaß an Social Media, stehst gerne vor der Kamera und willst Content nicht nur umsetzen, sondern aktiv mitgestalten? Du denkst kreativ, bringst eigene Ideen ein und hast Lust, in einem modernen KI-Start-up deinen eigenen Bereich voranzutreiben?

Dann ist diese Stelle für dich gemacht.

Wir suchen eine_n Marketing Manager_in (m/w/d) für unser Büro in Münster, die/der unser Marketing aktiv mitgestaltet, Social-Media-Kampagnen konzipiert und umsetzt, selbst vor der Kamera steht und die kreative Richtung für unser KI-Start-up mitprägt.

## Aufgaben

- Planung, Umsetzung und Weiterentwicklung unserer Social-Media-Kampagnen (vor allem LinkedIn, Instagram, ggf. TikTok) für die Zielgruppe der Automobilbranche

- Konzeption und Produktion von Video-Content (Reels, Shorts, Erklärvideos) – gerne auch selbst vor der Kamera

- Entwicklung neuer Content-Formate und Kampagnen für Autohaus-Zielgruppen

- Mitgestaltung von Tonalität und Markenbotschaft über alle Kanäle – von Captions über Postings bis zu Video-Skripten

- Enge Zusammenarbeit mit Geschäftsführung und Customer-Success-Team

## Qualifikation

Das bringst du fachlich mit:

- Abgeschlossenes Studium im Bereich Marketing, Medien, Kommunikation, BWL oder vergleichbar

- Erste Erfahrung im Social-Media- und Content-Marketing – idealerweise mit eigenen Reels/Shorts

- Ein Gespür für Kampagnen und Content-Formate, gern auch mit Blick auf Performance-Kennzahlen

- Sicherer Umgang mit digitalen Tools (z. B. Canva, gängige Schnitt-Apps, MS Office)

Und das bringst du persönlich mit:

- Du hast keine Scheu vor der Kamera und probierst gerne neue Formate aus

- Du bringst kreative Ideen ein und hast Lust, sie direkt umzusetzen

- Du arbeitest zuverlässig und strukturiert, auch wenn es kreativ wird

- Du hast ein gutes Gefühl für Bild, Video und Sprache und einen hohen Qualitätsanspruch

- Du arbeitest eigenständig und bringst Dinge voran

## Benefits

- Büro in Münster. Remote oder Hybrid möglich

- Wenig Reisetätigkeit

- Freie Wahl deiner Arbeitsumgebung

- Faire, marktgerechte Vergütung

- 30 Tage Urlaub + frei am Geburtstag

- Gesundes Mittagessen im Office

- Freie Wahl deiner technischen Ausstattung

👉 Wenn du Social Media liebst und Content strategisch denken willst

👉 Wenn du Spaß daran hast, kreative Formate zu planen und gemeinsam mit dem Team umzusetzen

👉 Wenn du aktiv an unserer Markenwirkung mitarbeiten und unsere Zielgruppe mit deinem Content erreichen willst

Dann passt dieser Job perfekt zu dir - Wir freuen uns auf deine Bewerbung!

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
