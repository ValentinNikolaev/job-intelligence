# Operations Process Manager:in

Posted: 2026-08-12T20:59:04Z

## Rejection

- Category: location_requirement
- Reason: vacancy is explicitly non-remote

## Deine Mission

Als Operations Process Manager:in bei SpotmyEnergy gestaltest du unsere operativen Kernprozesse und treibst sie bis ins Tagesgeschäft — von der Konzeption bis zur Umsetzung. Du baust nicht nur, du setzt um: end-to-end, bis es läuft. Inhaltlich geht es um Logistik, Supply Chain, Disposition von Technikern und Billing. Die Rolle kommt mit viel Verantwortung und Freiheit. Deine Ziel: ein skalierbares, datenbasiertes operatives Fundament.

## Deine Verantwortlichkeiten

- End-to-end-Verantwortung für die Weiterentwicklung unserer operativen Kernprozesse — von Konzeption bis Umsetzung im Tagesgeschäft

- Weiterentwicklung unserer Systemlandschaft (u.a. ERP) für konsistente Daten- und Bestandsstrukturen und saubere Schnittstellen zu externen Partnern

- Automatisierung unserer Prozesse auch durch AI und Agents

- Aufbau eines KPI- und Reporting-Frameworks für Operations, inkl. Kostencontrolling der Dienstleister

- Eigenständige Umsetzung operativer Projekte — Prozessoptimierungen, Systemintegrationen, strukturelle Themen, auch wenn es kleinteilig und langwierig wird

- Übersetzung fachlicher Anforderungen in umsetzbare Lösungen, gemeinsam mit dem Tech-Team

## Dein Profil

## Erfahrung

- Mehrjährige Erfahrung in einer prozess- oder operationsnahen Rolle mit Track Record in Optimierung und Umsetzung von Prozessen

- Beratungserfahrung ist ein starkes Plus, Erfahrung in Startup- oder Scale-up-Umfeldern von Vorteil

## Arbeitsweise

- Umsetzungsgetrieben: Konzepte reichen dir nicht, du willst, dass die Dinge laufen — inkl. der „letzten 20%

- Hohe Technikaffinität, keine Berührungsängste mit Tech und AI

- Du programmierst nicht, arbeitest aber eng mit dem Tech-Team und übersetzt zwischen Fachbereich und Technik

- Sehr gute Kenntnisse in Excel und Co. (Modellierung, Forecasting, Datenanalyse)

- Strukturiert, pragmatisch, ergebnisorientiert

## Sonstiges

- Verhandlungssicher in Deutsch, sicher in Englisch

- Bereitschaft zur regelmäßigen Präsenz in Köln

## Unser Offer

- **Mission & Impact:** Werde Teil eines missionsorientierten Start-ups, das die Energiewende aktiv vorantreibt und echten Unterschied macht.

- **Gestaltungsspielraum:** Du hilfst dabei SpotmyEnergy auf das nächste Level zu heben – mit viel Freiheit für eigene Ideen und Formate.

- **Lern- & Wachstumskurve:** Von Strategie bis Umsetzung – hier bekommst du die volle Bandbreite und die Chance, dich persönlich und fachlich stark weiterzuentwickeln.

- **Spot Spirit:** Ein motiviertes, wertschätzendes Team mit kurzen Wegen, offener Kommunikation und regelmäßigen Events.

- **Flexibilität:** Moderne, hybrid-friendly Arbeitsumgebung mit viel Gestaltungsspielraum und Eigenverantwortung.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
