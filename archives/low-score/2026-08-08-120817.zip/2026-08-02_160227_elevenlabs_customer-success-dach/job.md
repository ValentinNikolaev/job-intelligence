# Customer Success - DACH

Posted: 2026-08-02T14:40:20Z

## About ElevenLabs

ElevenLabs is an AI research and product company transforming how we interact with technology.

We launched in January 2023 with the first human-like AI voice model. Today, we serve millions of users and thousands of businesses - from fast-growing startups to large enterprises like Deutsche Telekom and Meta. Our investors are some of the world's most prominent, including Andreessen Horowitz, ICONIQ Growth and Sequoia. We've raised $781M in funding and our last valuation was $11B - multiples of 11, always.

We have expanded from voice into three main platforms:

-

ElevenAgents enables businesses to deliver seamless and intelligent customer experiences, with the integrations, testing, monitoring, and reliability necessary to deploy voice and chat agents at scale.

-

ElevenCreative empowers creators and marketers to generate and edit speech, music, image, and video across 70+ languages.

-

ElevenAPI gives developers access to our leading AI audio foundational models.

Everything we do is the result of the creativity and commitment of our team - builders doing the best work of their lives. We are researchers, engineers, and operators. IOI medalists and ex-founders. If you want to work hard and create lasting positive impact, we want to hear from you.

## How we work

-

**High-velocity: **Rapid experimentation, lean autonomous teams, and minimal bureaucracy.

-

**Impact not job titles: **We don’t have job titles. Instead, it’s about the impact you have. No task is above or beneath you.

-

**AI first:** We use AI to move faster with higher-quality results. We do this across the whole company—from engineering to growth to operations.

-

**Excellence everywhere: **Everything we do should match the quality of our AI models.

-

**Global team: **We prioritize your talent, not your location.

## What we offer

-

**Innovative culture:** You’ll be part of a generational opportunity to define the trajectory of AI, surrounded by a team pushing the boundaries of what’s possible.

-

**Growth paths: **Joining ElevenLabs means joining a dynamic team with countless opportunities to drive impact - beyond your immediate role and responsibilities.

-

**Learning & development**: ElevenLabs proactively supports professional development through an annual discretionary stipend.

-

**Social travel**: We also provide an annual discretionary stipend to meet up with colleagues each year, however you choose.

-

**Annual company offsite: **Each year, we bring the entire team together in a new location - past offsites have included Croatia and Italy.

-

**Co-working**: If you’re not located near one of our main hubs, we offer a monthly co-working stipend.

## **About the role**

This is a builder's role, where you'll own both the technical depth and commercial outcomes for some of ElevenLabs' most exciting customers across the DACH region (Germany, Austria, Switzerland), sitting at the intersection of product, engineering, and revenue.

You'll get ahead of the problem. You'll dig into how customers deploy ElevenLabs across web, mobile, and their systems, spot the problems before they do, inspire new use-cases and own the solution end to end. You'll own the number too: renewals, expansion and cross-sell. Success here means driving real revenue retention and growth for your book of business.

## **What this looks like day to day**

You'll run onboarding, enablement, and growth across ElevenLabs' full platform, core speech models, creative tools, and Agents. You'll advise customers on production deployment, not just theory, digging into usage and performance data to catch friction early and keep adoption moving.

You'll also own commercial outcomes for a defined book of business against clear targets: Gross Revenue Retention, Net Revenue Retention, cross-sell, and net expansion. You'll spot expansion opportunities early, own renewals and upsells end to end, and work closely with Sales, Engineering, and CS leadership to turn technical wins into revenue.

## **Requirements**

-

5+ years of Customer Success, Account Management or Technical Account Management experience supporting complex B2B SaaS, Developer Tools, or AI/ML products in the DACH region

-

Proven experience of owning and managing a defined Book of Business

-

Fluent in German and English

-

Proven experience working across the DACH market. Knowledge of the landscape and cultural nuances

-

Familiarity and experience with building and deploying AI agents

-

Strong builder mindset - you thrive in ambiguity and being a pioneer, finding ways to innovate across a full region or market to drive revenue outcomes

-

Familiarity and experience with API Integrations, and comfort and knowledge of navigating SDKs

-

Proven experience working cross functionally with Sales, Engineering, Product, and Marketing teams

-

Proven experience driving revenue outcomes, including owning a revenue quota and identifying, qualifying, and closing cross-sell opportunities along with renewals

-

Excellent problem-solving, technical, and analytical skills to address customer needs and concerns

-

Strong communication and interpersonal skills, with the ability to build and maintain relationships with customers at all levels of an organization

-

Self-motivated and able to work independently in a remote or distributed team environment

## **Location**

This role is remote-first, so it can be executed from anywhere in Germany, Austria, or Switzerland.

#LI-Remote

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
