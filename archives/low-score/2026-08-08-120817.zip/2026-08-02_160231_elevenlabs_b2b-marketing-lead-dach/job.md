# B2B Marketing Lead - DACH

Posted: 2026-08-02T14:40:20Z

## About ElevenLabs

ElevenLabs is an AI research and product company transforming how we interact with technology.

We launched in January 2023 with the first human-like AI voice model. Today, we serve millions of users and thousands of businesses - from fast-growing startups to large enterprises like Deutsche Telekom and Meta. Our investors are some of the world's most prominent, including Andreessen Horowitz, ICONIQ Growth and Sequoia. We've raised $781M in funding and our last valuation was $11B - multiples of 11, always.

We have expanded from voice into three main platforms:

-

ElevenAgents enables businesses to deliver seamless and intelligent customer experiences, with the integrations, testing, monitoring, and reliability necessary to deploy voice and chat agents at scale.

-

ElevenCreative empowers creators and marketers to generate and edit speech, music, image, and video across 70+ languages.

-

ElevenAPI gives developers access to our leading AI audio foundational models.

Everything we do is the result of the creativity and commitment of our team - builders doing the best work of their lives. We are researchers, engineers, and operators. IOI medalists and ex-founders. If you want to work hard and create lasting positive impact, we want to hear from you.

## How we work

-

**High-velocity: **Rapid experimentation, lean autonomous teams, and minimal bureaucracy.

-

**Impact not job titles: **We don’t have job titles. Instead, it’s about the impact you have. No task is above or beneath you.

-

**AI first:** We use AI to move faster with higher-quality results. We do this across the whole company—from engineering to growth to operations.

-

**Excellence everywhere: **Everything we do should match the quality of our AI models.

-

**Global team: **We prioritize your talent, not your location.

## What we offer

-

**Innovative culture:** You’ll be part of a generational opportunity to define the trajectory of AI, surrounded by a team pushing the boundaries of what’s possible.

-

**Growth paths: **Joining ElevenLabs means joining a dynamic team with countless opportunities to drive impact - beyond your immediate role and responsibilities.

-

**Learning & development**: ElevenLabs proactively supports professional development through an annual discretionary stipend.

-

**Social travel**: We also provide an annual discretionary stipend to meet up with colleagues each year, however you choose.

-

**Annual company offsite: **Each year, we bring the entire team together in a new location - past offsites have included Croatia and Italy.

-

**Co-working**: If you’re not located near one of our main hubs, we offer a monthly co-working stipend.

## **About the role**

We are seeking a seasoned Growth Marketer to lead our expansion into the **DACH Region**. We need a builder who is comfortable with the "zero-to-one" phase of regional growth.

You will be the local "Source of Truth" for marketing, acting as a creative, an analyst, and an operator all at once. You should be someone who enjoys the complexity of multi-lingual markets and has the drive to implement projects from start to finish while owning the outcome entirely.

## **Your Responsibilities**

-

**Regional Growth Engine:** Make sure DACH** **B2B grows through aggressive lead generation and brand awareness.

-

**Outbound Strategy:** Build and execute complex, multi-language outbound sequences that cut through the noise.

-

**Local Events:** End-to-end ownership of local industry events, user conferences, and webinars in the region.

-

**Cross-Functional Synergy:** Collaborate with performance marketing on ABM initiatives and localized retargeting.

-

**Analytics & Reporting:** Monitor campaign performance, produce executive-level reporting, and recommend data-driven optimizations.

-

**Localization & Messaging:** Adapt ElevenLabs’ global voice to resonate deeply with the DACH business cultures.

## **Requirements**

-

**Native German speaker.**

-

**Fluent English speaker.**

-

**Ownership Pedigree:** You have implemented marketing projects from start to finish and held yourself accountable for the ROI.

-

**Entrepreneurial Background:** You have a strong drive and a history of high engagement, ideally in an entrepreneurial endeavor or a similar high-stakes environment.

-

**Thrives in Chaos:** You are energized by a dynamic, ever-changing environment and can manage multiple workstreams without losing focus.

-

**The "Jack of All Trades":** Broad knowledge in growth marketing, ranging from numbers analysis and performance knowledge to campaign planning and event organizing.

-

**DRI Mentality:** Ability to act as the local Directly Responsible Individual (DRI) for all marketing operations.

## **Bonus Experience**

-

Proficiency in cold email, SEO, or affiliate management.

-

Product marketing sense and design skills.

-

Deep understanding of the Southern European tech ecosystem and buying-cycle shifts.

## **What we offer**

-

Innovative culture & growth paths.

-

Annual discretionary L&D stipend & social travel stipend.

-

Annual company offsite.

-

Monthly co-working stipend.

This role is remote-friendly within Germany (Berlin, Hamburg, Munich is preferred).

#LI-Remote

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
