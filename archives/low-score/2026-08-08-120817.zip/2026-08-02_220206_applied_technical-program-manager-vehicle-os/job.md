# Technical Program Manager - Vehicle OS

Posted: 2026-08-02T20:41:57Z

## About Applied Intuition

Applied Intuition, Inc. is powering the future of physical AI. Founded in 2017 and now valued at $15 billion, the Silicon Valley company is creating the digital infrastructure needed to bring intelligence to every moving machine on the planet. Applied Intuition services the automotive, defense, trucking, construction, mining and agriculture industries in three core areas: tools and infrastructure, operating systems, and autonomy. Eighteen of the top 20 global automakers, as well as the United States military and its allies, trust the company’s solutions to deliver physical intelligence. Applied Intuition is headquartered in Sunnyvale, California, with offices in Washington, D.C.; San Diego; Ft. Walton Beach, Florida; Ann Arbor, Michigan; London; Stuttgart; Munich; Stockholm; Bangalore; Seoul; and Tokyo. Learn more at [applied.co](http://applied.co).

*We are an in-office company, and our expectation is that employees primarily work from their Applied Intuition office 5 days a week. However, we also recognize the importance of flexibility and trust our employees to manage their schedules responsibly. This may include occasional remote work, starting the day with morning meetings from home before heading to the office, or leaving earlier when needed to accommodate family commitments.*

## About the role

We are looking for a Technical Program Manager to stand up and run program management across multiple high-priority automotive engagements from our Stuttgart hub. This role requires deep technical credibility, direct customer ownership, and the ability to build structure from scratch in a fast-moving environment.

You will operate across supplier engagements, OEM programs, and internal delivery teams – translating ambiguous asks into tracked, executable work and representing Applied Intuition directly with customers and partners.

## At Applied Intuition, you will:

-

Stand up and run program management – define milestones, own timelines and deliverables, manage sprint and roadmap execution for software development teams through series production

-

Manage supplier relationships at Tier-1 and Tier-2 level; hold partners accountable to schedule and quality commitments

-

Serve as the primary customer contact for EMEA OEMs; translate requirements into tracked engineering work and provide structured, regular updates

-

Coordinate across internal and external teams; align technical roadmaps, unblock cross-team dependencies, and support international roll-outs

-

Drive issues to closure – own problem-solving and decision-making across teams and sites

## **We're looking for someone who has:**

-

5+ years in technical program management or engineering within the automotive industry, ideally with hands-on experience at an OEM or Tier-1 supplier

-

Proven supplier management experience – able to hold Tier-1 and Tier-2 partners to schedule and quality commitments

-

Strong customer-facing presence; comfortable representing Applied Intuition independently with OEMs and executive stakeholders

-

Technical depth in embedded systems, middleware, or ADAS – enough to assess feasibility and engage engineers credibly

-

Builder mindset: able to set up program structure from scratch with minimal existing scaffolding

-

Ability to operate independently across sites and time zones

-

Stuttgart-based or open to relocation; fluent in German and English

## Nice to have:

-

Prior experience in a startup or high-growth environment.

-

Familiarity with automotive development standards (ASPICE, ISO 26262, AUTOSAR).

-

Background in series production programs or SDS/ADAS platform delivery.

## **Benefits:**

-

30 days of paid vacation per year

-

Daily meal benefits: €19 lunch budget and €19 dinner budget, free breakfast, snacks, and drinks in the office

-

You’ll receive €965 annual learning & development and €580 annual fitness budget

-

Subsidized Wellpass membership, giving you access to thousands of gyms, studios, and wellness facilities across Germany

-

€25 monthly contribution to your Deutschlandticket for regional public transport across Germany

-

Generous parental leave: on top of statutory parental leave

*Don’t meet every single requirement? If you’re excited about this role but your past experience doesn’t align perfectly with every qualification in the job description, we encourage you to apply anyway. You may be just the right candidate for this or other roles.*

*Applied Intuition is an equal opportunity employer and federal contractor or subcontractor. Consequently, the parties agree that, as applicable, they will abide by the requirements of 41 CFR 60-1.4(a), 41 CFR 60-300.5(a) and 41 CFR 60-741.5(a) and that these laws are incorporated herein by reference. These regulations prohibit discrimination against qualified individuals based on their status as protected veterans or individuals with disabilities, and prohibit discrimination against all individuals based on their race, color, religion, sex, sexual orientation, gender identity or national origin. These regulations require that covered prime contractors and subcontractors take affirmative action to employ and advance in employment individuals without regard to race, color, religion, sex, sexual orientation, gender identity, national origin, protected veteran status or disability. The parties also agree that, as applicable, they will abide by the requirements of Executive Order 13496 (29 CFR Part 471, Appendix A to Subpart A), relating to the notice of employee rights under federal labor laws.*

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
