# Golang Engineer

Posted: 2026-07-21T16:19:49Z

Canonical is a leading provider of open-source software and operating systems for global enterprise and technology markets. Our platform, Ubuntu, is very widely used in breakthrough enterprise initiatives such as public cloud, data science, AI, engineering innovation and IoT. Our customers include the world's leading public cloud and silicon providers, and industry leaders in many sectors. The company is a pioneer of global distributed collaboration, with 1200+ colleagues in more than 80 countries and very few office-based roles. Teams meet two to four times yearly in person, in interesting locations around the world, to align on strategy and execution.

The company is founder led, profitable and growing.

We are hiring **Golang engineers** of all levels of seniority, for all relevant teams at Canonical. Apply here if you are an exceptional software engineer who prefers to work in Go. After the first round of interviews we’ll find the best fit product team at Canonical for you to progress your application based on your personal interests.

Canonical prefers Golang for software where performance and security are primary considerations. We also have substantial projects in Python, C, C++ and are starting to invest in Rust. For front-end development we prefer React and Flutter.

Golang is an essential language for our engineering teams, who build the systems that deliver Ubuntu to the world. From our software distribution systems, to those which build and test every possible kind of open source on every architecture, from our systems management tools to our distributed systems operations R&D, we count on Golang for its tasteful concurrency and developer ecosystem. Juju, Livepatch, LXD, MAAS, Microk8s, Snapd, Ubuntu Core, Ubuntu Pro, and many more Canonical offerings include Golang components.

We also want to ensure that Ubuntu is the very best platform for Golang development, offering easy access to the widest range of tooling and capabilities that support cutting edge open source and enterprise development.

Join us in our mission to deliver innovative open-source solutions to individuals and enterprises around the world. We expect the highest engineering standards and strong motivation to get things done well in a fully remote and distributed environment. These roles require extensive personal experience with Linux - the more different versions of Linux the better!

**Location**: we have open roles for Golang engineers in every time zone

## **The role entails**

- Design and implement well-tested and documented software in Go

- Debug and fix issues encountered by your users

- Participate in our engineering process through code and architectural reviews

- Collaborate with community and colleagues on technical specifications

- Seek improvements to engineering and operations practices

- In some cases, deploy and operate services developed by the team

- Contribute to the success of your product through technical advocacy

## **What we are looking for in you**

- An exceptional academic track record from both high school and university

- Undergraduate degree in Computer Science or STEM, or a compelling narrative about your alternative path

- Drive and a track record of going above-and-beyond expectations

- Well-organized, self-starting and able to deliver to schedule

- Professional manner interacting with colleagues, partners, and community

- Experience designing and writing high-quality Golang software on Linux

- Experience with and passion for Linux at the system level

- For more senior roles, experience building, deploying, and operating distributed systems and APIs

- Professional written and spoken English

- Experience with Linux (Debian or Ubuntu preferred)

- Excellent interpersonal skills, curiosity, flexibility, and accountability

- Passion, thoughtfulness, and self-motivation

- Excellent communication and presentation skills

- Result-oriented, with a personal drive to meet commitments

- Ability to travel twice a year, for company events up to two weeks each

## **Nice-to-have skills**

- Experience developing for Ubuntu Linux

- Experience with Juju, LXD, Microk8s, Snapd, Ubuntu Core, Ubuntu Pro

- Performance engineering and security experience

## What we offer colleagues

We consider geographical location, experience, and performance in shaping compensation worldwide. We revisit compensation annually (and more often for graduates and associates) to ensure we recognize outstanding performance. In addition to base pay, we offer a performance-driven annual bonus or commission. We provide all team members with additional benefits, which reflect our values and ideals. We balance our programs to meet local needs and ensure fairness globally.

- Distributed work environment with twice-yearly team sprints in person

- Personal learning and development budget of USD 2,000 per year

- Annual compensation review

- Recognition rewards

- Annual holiday leave

- Maternity and paternity leave

- Employee Assistance Program

- Opportunity to travel to new locations to meet colleagues

- Priority Pass, and travel upgrades for long haul company events

## About Canonical

Canonical is a pioneering tech firm at the forefront of the global move to open source. As the company that publishes Ubuntu, one of the most important open source projects and the platform for AI, IoT and the cloud, we are changing the world of software. We recruit on a global basis and set a very high standard for people joining the company. We expect excellence - in order to succeed, we need to be the best at what we do. Most colleagues at Canonical have worked from home since its inception in 2004.​ Working here is a step into the future, and will challenge you to think differently, work smarter, learn new skills, and raise your game.

**Canonical is an equal opportunity employer**

We are proud to foster a workplace free from discrimination. Diversity of experience, perspectives, and background create a better work environment and better products. [Whatever your identity, we will give your application fair consideration.](https://canonical.com/careers/diversity/identity)

#LI-remote
