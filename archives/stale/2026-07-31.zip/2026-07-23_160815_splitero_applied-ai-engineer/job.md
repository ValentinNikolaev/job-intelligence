# Applied AI Engineer

Posted: 2026-07-23T10:55:00Z

### About the Job

As [Splitero](https://himalayas.app/companies/splitero)'s Applied AI Engineer, you will own the identification, scoping, and delivery of AI-powered capabilities across our product and operations. You'll sit within the engineering organization but operate cross-functionally, partnering with product, operations, and business teams to identify where AI creates real leverage, then build it. [Splitero](https://himalayas.app/companies/splitero) sits at the intersection of financial services and property technology, and our product and engineering teams are at the center of that innovation every day. In this role, you'll work directly with our sales, processing, underwriting, closing, and servicing teams to identify, scope, and execute opportunities to streamline and automate their workflows as we scale. On the engineering side, you'll champion AI-first development, educate the team on emerging tooling, and lead technical initiatives that drive the organization forward.

You'll spend your time shipping working AI solutions into production by automating workflows, augmenting our product experience, and helping [Splitero](https://himalayas.app/companies/splitero) move faster and smarter as a business. You will have a strong understanding of when supervised AI outweighs the risk of full automation. You're as comfortable standing up a low-code n8n automation as you are writing clean code, and you know when each approach is the right one.

At [Splitero](https://himalayas.app/companies/splitero), we move fast, and the ideal candidate thrives in that environment. You default to the simplest path to a working solution, prototype quickly using every tool available to you, and have the engineering discipline to know when something needs to be rebuilt properly before it goes to production.

### Responsibilities:

- AI Discovery & Strategy

- Socialize AI capabilities, limitations, and roadmap across the org, acting as an internal resource and thought leader on what's possible.

- Maintain a prioritized backlog of AI opportunities across the business, triaging ideas from leadership, product, and operations into scoped, deliverable workstreams.

- Define AI initiatives end-to-end: problem framing, data requirements, build vs. buy decisions, and measurable success criteria.

- Stay current on the AI tooling landscape and recommend adoption where it meaningfully improves velocity, quality, or competitive positioning.

- Building & Delivery

- Build, integrate, and maintain AI-powered features and workflows, leveraging LLM APIs (OpenAI, Anthropic, etc.), RAG pipelines, and agentic frameworks.

- Develop automation workflows using low/no-code orchestration tools (n8n, Make) to deliver AI solutions rapidly without requiring full engineering cycles.

- Integrate AI capabilities into existing systems and codebases in close partnership with the product and engineering teams.

- Own the full AI development lifecycle, including prototyping, evaluation, deployment, monitoring, and iteration, with support from engineering, product, and operational teams.

- Cross-Functional Partnership

- Partner with product to translate user problems into AI-driven features and experiences.

- Embed within operations and business teams to identify workflow automation and efficiency opportunities.

- Collaborate with engineering to ensure AI integrations meet production standards for reliability, maintainability, and security.

- Document and communicate AI implementations clearly so the broader team can support and build on them.

### Reporting Structure

- Reports directly to the VP of Product and Engineering

- Embedded within the product engineering team, works cross-functionally across Salesforce, product, operations, and business functions

The salary range for this position is $135,000 - $175,000. Within the range, individual pay is determined by job-related skills, experience, and relevant education or training.

### About You

- 6+ years in software engineering with at least 2 years of focused experience building production AI or LLM-powered applications

- Hands-on experience with LLM APIs, prompt engineering, retrieval-augmented generation (RAG), and agentic workflow design. You are on the bleeding edge of the latest releases and advancements in AI platforms.

- Demonstrated experience evaluating, advocating, and operationalizing AI tooling across an organization

- Proficiency with low/no-code orchestration platforms (n8n, Make, Zapier) to prototype and deliver AI workflows rapidly

- Comfortable with AI-assisted development tools (Claude Code, Cursor, GitHub Copilot, etc.) to accelerate build cycles, with the judgment to write clean, maintainable code when it matters. You are not a *vibe coder*; you leverage your engineering background to balance speed with quality using AI-based tooling.

- Strong backend or full-stack engineering fundamentals; you integrate AI into real systems, not just prototypes

- Fluency in Python, TypeScript/, or similar; familiarity with PostgreSQL and cloud deployment platforms (AWS, Vercel, or similar)

- Experience with multi-agent frameworks (LangChain, LlamaIndex, or similar)

- Familiarity with vector databases, embedding pipelines, and evaluation frameworks for LLM outputs

- Self-directed and comfortable operating as a team of one. You run your own backlog and don't need a fully defined spec to get started and validate business use cases

- Strong communicator who can translate technical AI concepts for non-technical stakeholders across the org

### Preferred:

- Experience in fintech, proptech, or real estate technology — particularly products handling sensitive financial data or consumer lending.

- Knowledge of SOC 2 or data privacy frameworks relevant to financial and personal data.

### About Us

Millions of homeowners in today’s economy are sitting on substantial home equity they are unable to access due to rising interest rates and strict qualification requirements of traditional lenders. That means millions of homeowners can’t convert their hard-earned equity into cash to pay off debt, start a home renovation, or pad their retirement to better their lives.

[Splitero](https://himalayas.app/companies/splitero) co-founders Michael Gifford and David Zvaifler witnessed the problem firsthand throughout their real estate careers. They set out to create a win-win product that could help those homeowners access their home equity but not make monthly payments like traditional financing options. And thus, [Splitero](https://himalayas.app/companies/splitero) was born.

As part of our team, you will join our quest to revolutionize the real estate industry while helping families in need. We offer a suite of benefits designed to help you thrive in all areas of life.

-
**Fully Remote Team - **Our remote-first culture allows us to hire the best people, regardless of location.

-
**OneTeam Culture - **We foster a culture of transparency, innovation, and inclusivity, where every voice is heard and every team member is valued. We believe in celebrating our successes, doing the right thing, and helping each other so we grow as a team and as individuals.

-
**Generous Resources -** We want to ensure you are set up to do your best work. In addition to a solid tech stack, and access to any WeWork location, you will receive a monthly cell and internet stipend.

-
**Premium Healthcare - **We offer comprehensive healthcare plans for you and your family, which employees are eligible for on their first day.

-
**Flexible PTO and Parental Leave - **We offer a generous PTO and encourage employees to take time off to recharge. We're proud to offer a parental leave policy that allows you to welcome your new addition without worry.

We are a workforce composed of individuals with diverse backgrounds, abilities, minds, and identities. In keeping with our commitment to inclusion, we will ensure that people with disabilities are provided reasonable accommodations. If reasonable accommodations are required when applying, interviewing, or performing the essential functions of this position, please contact People Operations, at .

Originally posted on [Himalayas](https://himalayas.app)
