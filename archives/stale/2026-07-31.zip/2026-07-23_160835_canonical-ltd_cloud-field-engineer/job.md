# Cloud Field Engineer

Posted: 2026-07-21T16:19:24Z

Help global companies embrace the latest private cloud infrastructure, Linux and cloud native operations, and open source applications. Our team applies expert insights to real-world customer problems, enabling the enterprise adoption of Linux Ubuntu, OpenStack, Kubernetes and a wide range of associated technology.

This role has very diverse responsibilities. The team members are Linux and cloud solutions architects for our customers, designing private and public cloud solutions fitting their workload needs. They are the cloud consultants who work hands-on with the technologies by deploying, testing and handing over the solution to our support or managed services team at the end of a project. They are also software engineers who use Python to develop Kubernetes operators and Linux open source infrastructure-as-code.

The people who love this role are developers who like to solve customer problems through architecture, presentations and training.

**Location:** This role will be home based.

**What your day will look like**

- Work across the entire Linux stack, from kernel, networking, storage, to applications

- Work in Python to design and deliver open source code

- Architect cloud infrastructure solutions like OpenStack, Kubernetes, Ceph, Hadoop and Spark either On-Premises or in Public Cloud (AWS, Azure, Google Cloud)

- Coach and develop your colleagues where you have insights

- Grow a healthy, collaborative engineering culture in line with the company values

- Work from the comfort of your home

- Global travel up to 25% of time for internal and external events

**What we are looking for in you**

- University degree in Computer Science or related software engineering expertise

- You have sound knowledge of cloud computing concepts & technologies, such as Kubernetes, OpenStack, AWS, GCP, Azure, Ceph, etc.

- You have practical knowledge of Linux and networking

- You have Intermediate to Advanced level of Python programming skills

- You are a dynamic person who loves to jump in new projects and interact with people

- You have a demonstrated drive for continual learning

- Excellent communication and presentation skills (English)

- You have great organisational skills and follow-up reliably on commitments

- (Optional) You speak a second language

**What you’ll learn**

- OpenStack and Kubernetes infrastructure

- Linux Ubuntu and networking knowledge

- Wide range of open source applications and skills

- Work directly with customers in a range of different businesses

- Real-life and hands-on exposure to a wide range of emerging technologies and tools

**What we offer you**

We consider geographical location, experience, and performance in shaping compensation worldwide. We revisit compensation annually (and more often for graduates and associates) to ensure we recognise outstanding performance. In addition to base pay, we offer a performance-driven quarterly bonus. We provide all team members with additional benefits, which reflect our values and ideals. We balance our programs to meet local needs and ensure fairness globally.

- Distributed work environment with twice-yearly team sprints in person - we’ve been working remotely since 2004!

- Personal learning and development budget of USD 2,000 per year

- Annual compensation review

- Recognition rewards

- 40 days annual leave per annum, including public holidays and our All Company holiday periods

- Maternity and paternity leave

- Employee Assistance Programme

- Opportunity to travel to new locations to meet colleagues from your team and others

- Priority Pass for travel and travel upgrades for long haul company events

**About Canonical**

Canonical is a pioneering tech firm that is at the forefront of the global move to open source. As the company that publishes Ubuntu, one of the most important open source projects and the platform for AI, IoT and the cloud, we are changing the world on a daily basis. We recruit on a global basis and set a very high standard for people joining the company. We expect excellence - in order to succeed, we need to be the best at what we do.

Canonical has been a remote-first company since its inception in 2004.​ Work at Canonical is a step into the future, and will challenge you to think differently, work smarter, learn new skills, and raise your game. Canonical provides a unique window into the world of 21st-century digital business.

**Canonical is an equal opportunity employer**

We are proud to foster a workplace free from discrimination. Diversity of experience, perspectives, and background create a better work environment and better products. [Whatever your identity, we will give your application fair consideration.](https://canonical.com/careers/diversity/identity)

#LI-Remote

#stack
