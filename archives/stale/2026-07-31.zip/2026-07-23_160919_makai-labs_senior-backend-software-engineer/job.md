# Senior Backend Software Engineer

Posted: 2026-07-22T04:54:26.6116868+00:00

...About the role This is a full-time **remote **role for a **Senior Backend **Software **Engineer **at Makai. This person will be responsible for backend app development and will collaborate with cross-functional teams to design and implement innovative solutions that enhance user...
