# Embedded & Desktop Linux Systems Engineer - Optimisation

Posted: 2026-07-21T16:20:40Z

Work across the full Linux stack from kernel through GUI to optimise Ubuntu, the world’s most widely used Linux desktop and server, for the latest silicon.

The role is a fast-paced, problem-solving role that’s challenging yet very exciting. The right candidate must be resourceful, articulate, and able to deliver on a wide variety of solutions across PC and IoT technologies. Our teams partner with specialist engineers from major silicon companies to integrate next-generation features and performance enhancements for upcoming hardware.

**Location:** *This is a Globally remote role*

## What your day will look like

- Design and implement the best Ubuntu integration for the latest IoT and server-class hardware platforms and software stacks

- Work with partners to deliver a delightful, optimised, first class Ubuntu experience on their platforms

- Take a holistic approach to the Ubuntu experience on partner platforms with inputs on technical plans, testing strategy, quality metrics

- Participate as technical lead on complex customer engagements involving complete system architectures from cloud to edge

- Help our customers integrate their apps, SDKs, build device OS images, optimize applications with Ubuntu Core, Desktop and Server

- Work with the most advanced operating systems and application technologies available in the enterprise world.

Joining Canonical, you will partner with bright minds from all over the world, and work with an exciting set of new technologies in a fast growing company with a truly unique and ambitious vision to build a better platform with free software. You will work with customers on exciting IoT and server platforms and technologies, built to support different verticals: from robots to data centers, from telco to retail.

## What we are looking for in you

- You love technology and working with brilliant people

- You have a Bachelor’s degree in Computer Science, STEM or similar

- You have experience with Linux packaging (Debian, RPM, Yocto)

- You have experience working with open source communities and licences

- You have experience working with C, C++

- You can work in a globally distributed team through self-discipline and self-motivation.

## Additional skills that you might also bring

- Experience with graphics stacks

- Good understanding of networking - TCP/IP, DHCP, HTTP/REST

- Basic understanding of security best practices in IoT or server environments

- Good communication skills, ideally public speaking experience

- IoT / Embedded experience – from board and SoC, BMCs, bootloaders and firmware to OS, through apps and services

- Some experience with Docker/OCI containers/K8s

## What we offer you

Your base pay will depend on various factors including your geographical location, level of experience, knowledge and skills. In addition to the benefits above, certain roles are also eligible for additional benefits and rewards including annual bonuses and sales incentives based on revenue or utilisation. Our compensation philosophy is to ensure equity right across our global workforce.

In addition to a competitive base pay, we provide all team members with additional benefits, which reflect our values and ideals. Please note that additional benefits may apply depending on the work location and, for more information on these, you can ask in the later stages of the recruitment process.

- Fully remote working environment - we’ve been working remotely since 2004!

- Personal learning and development budget of 2,000USD per annum

- Annual compensation review

- Recognition rewards

- Annual holiday leave

- Parental Leave

- Employee Assistance Programme

- Opportunity to travel to new locations to meet colleagues at ‘sprints’

- Priority Pass for travel and travel upgrades for long haul company events

## About Canonical

Canonical is a pioneering tech firm that is at the forefront of the global move to open source. As the company that publishes Ubuntu, one of the most important open source projects and the platform for AI, IoT and the cloud, we are changing the world on a daily basis. We recruit on a global basis and set a very high standard for people joining the company. We expect excellence - in order to succeed, we need to be the best at what we do.

Canonical has been a remote-first company since its inception in 2004.​ Work at Canonical is a step into the future, and will challenge you to think differently, work smarter, learn new skills, and raise your game. Canonical provides a unique window into the world of 21st-century digital business.

## Canonical is an equal opportunity employer

We are proud to foster a workplace free from discrimination. Diversity of experience, perspectives, and background create a better work environment and better products. [Whatever your identity, we will give your application fair consideration.](https://canonical.com/careers/diversity/identity)

#LI-remote
