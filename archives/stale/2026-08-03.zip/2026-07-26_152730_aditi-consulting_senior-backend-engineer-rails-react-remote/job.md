# Senior Backend Engineer (Rails/React) - Remote

Posted: 2026-07-23T00:00:00.0000000

A consulting firm in Hillsboro, Oregon is seeking a Back-End Developer with expertise in Ruby on Rails and front-end development using React. Candidates should have 9 years of experience in web development, be familiar with MySQL, and possess excellent communication skills...
