# Backend Engineer - Transfers Gateway

Posted: 2026-08-05T13:45:24Z

At SumUp, the **Global Bank tribe **builds the core infrastructure and services that give merchants a digital business account, helping small businesses manage their banking needs easily and reliably.

The **Transfers Gateway squad **connects SumUp's internal systems to external financial networks across the EU and the UK. We build and run the services that move money through payment schemes every day. The team owns end‑to‑end scheme integrations and operates production services that process real money at scale. You'll help modernise existing systems while balancing reliability, correctness, and change, making architectural decisions that directly affect uptime and merchant experience across multiple markets.

Our tech stack includes Go, AWS, Kafka, PostgreSQL, and Kubernetes, supported by a strong observability toolchain with Prometheus, Grafana, and Honeycomb. We also actively use AI‑assisted development tools such as Cursor, GitHub Copilot, and others.

SumUp's engineering culture is built around ownership. We follow a "build it, run it, improve it" model, with strong observability and a focus on learning. Engineers have clear scope and autonomy, with decisions documented, reviewed, and made collaboratively.

**What You'll Do**

- Build and maintain production money movement backend services, contributing to their delivery, observability, and ongoing maintenance.

- Own and deliver end to end features, and contribute to larger projects within the team's domain.

- Contribute to technical design and implementation, following established architectural patterns and best practices.

- Improve service reliability and quality by writing tests, enhancing monitoring, and following established delivery pipelines.

- Support the operation of the systems you work on by participating in on‑call rotations, incident response, and learning from post‑incident reviews.

- Apply a backend and systems perspective during refinement, raising questions about risks, dependencies, and edge cases.

- Collaborate closely with Product, QA, and other engineers to deliver end‑to‑end transfer and banking capabilities.

**You'll be great for this role if you**

- Have experience building backend services in a modern environment and supporting them in production.

- You are proficient in **Golang** and and comfortable learning and working with other languages as needed

- Are comfortable working with cloud‑based systems, containerized workloads, and automated delivery pipelines.

- Raise well-scoped pull requests, conduct thorough code reviews, and help maintain high standards of code quality and test coverage across the team

- Understand the fundamentals of system architecture, data modelling, and API design, and are eager to deepen this knowledge.

- Are curious about how your work fits into the broader system and product experience.

- Communicate clearly and collaborate effectively with engineers, product managers, and other stakeholders.

**Any of the following would be considered a plus**

- Exposure to banking, payments, or financial systems, especially in regulated environments.

- Experience supporting systems with production traffic, including participating in incident response.

- Use of AI‑assisted tools to improve development speed, learning, or code quality.

**Why you should join SumUp**

- 🌎 We're a truly global team of 3200+ skilled professionals from 92+ countries, spread across 4 continents. Join the team from our Vilnius office.

- 🌈 Commitment to Diversity and Inclusion: be part of a workplace that values and promotes diversity, fostering an inclusive environment where everyone's perspectives are respected and embraced

- 🚀 Enrolment onto our Virtual Stock Option programme: you will own a stake in SumUp's future success

- 🏖️ Time off: 25 days of paid leave, plus special holidays

- 🏥 Peace of mind: health insurance through Gjensidige and life & accidental coverage from Ergo

- 💪 Stay active: gym membership allowance to help you keep fit on your terms

- 📚Career growth and learning opportunities: We invest in your development through regular training, mentorship programs, SumUp University cohort and a yearly learning budget (2,000 EUR)

- 💡We take learning and experimentation seriously with Hack Days every second Friday, and entire[ global Hack Weeks](https://www.youtube.com/watch?v=FBKiVCLompk).

- 🌴 Break4me: 1-month sabbatical after 3 years of service

- 🔗 Referral Bonus: earn additional rewards by referring talented individuals to join the SumUp team

**Compensation: **From **midlevel** level 3,493 to 4,657 Euro p/m + 2000 EUR annual learning budget + Virtual Stock Options. Ranges may vary based on skills and experience.

**About SumUp**

At SumUp, we're on a mission to empower small businesses around the world with simple, affordable tools to help them start, run, and grow. More than 4 million merchants across 37 markets trust us as their financial partner — and we're just getting started.

We're a global team of 3,000+ people from over 90 nationalities, united by curiosity, collaboration, and care. Our[ core values](https://youtu.be/1axu-TmW088?si=5NjHKNq5n-1GbXc2) and[ culture](https://youtu.be/XEH_nmJ9KZ4?si=pr6TdFl98FhpD5KG) shape everything we do, fostering inclusion, learning, and belonging.

SumUp is proud to be an Equal Employment Opportunity employer, committed to building a safe, respectful, and diverse workplace where everyone can thrive.

👉 Explore more about our culture on our[ careers site](https://www.sumup.com/careers/), or follow us on[ LinkedIn](https://www.linkedin.com/company/sumup/) and[ Instagram](https://www.instagram.com/insidesumup/).

*SumUp is proud to be an Equal Employment Opportunity employer, actively seeking and embracing diversity in our workforce. We don't make hiring or employment decisions based on race, colour, religion or religious belief, ethnic or national origin, nationality, sex, gender, gender identity, sexual orientation, disability, age or any other basis protected by applicable laws or prohibited by company policy. Our commitment extends beyond recruitment to creating a safe and respectful workplace where harassment of any form is strictly prohibited.*

**Job Application Tip**

We recognise that candidates feel they need to meet 100% of the job criteria in order to apply for a job. Please note that this is only a guide. If you don't tick every box, it's ok too because it means you have room to learn and develop your career at SumUp.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
