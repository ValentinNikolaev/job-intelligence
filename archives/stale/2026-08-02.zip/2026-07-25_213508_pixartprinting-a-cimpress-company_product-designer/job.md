# Product Designer

Posted: 2026-07-23T00:00:00.0000000

...following the entire flow of a product manufacturing)
Configure the **backend **to enable the agreed workflow
Coordinate with customer care to... ...and extremely detail-oriented
PREFERRED:
Degree in management **engineering,** architecture or industrial design or equivalent academic...
