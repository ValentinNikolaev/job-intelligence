# Enterprise Solutions Engineer - Germany

Posted: 2026-07-27T09:40:03Z

## About ElevenLabs

ElevenLabs is an AI research and product company transforming how we interact with technology.

We launched in January 2023 with the first human-like AI voice model. Today, we serve millions of users and thousands of businesses - from fast-growing startups to large enterprises like Deutsche Telekom and Meta. Our investors are some of the world's most prominent, including Andreessen Horowitz, ICONIQ Growth and Sequoia. We've raised $781M in funding and our last valuation was $11B - multiples of 11, always.
We have expanded from voice into three main platforms:

-

ElevenAgents enables businesses to deliver seamless and intelligent customer experiences, with the integrations, testing, monitoring, and reliability necessary to deploy voice and chat agents at scale.

-

ElevenCreative empowers creators and marketers to generate and edit speech, music, image, and video across 70+ languages.

-

ElevenAPI gives developers access to our leading AI audio foundational models.

Everything we do is the result of the creativity and commitment of our team - builders doing the best work of their lives. We are researchers, engineers, and operators. IOI medalists and ex-founders. If you want to work hard and create lasting positive impact, we want to hear from you.

## How we work

-

**High-velocity: **Rapid experimentation, lean autonomous teams, and minimal bureaucracy.

-

**Impact not job titles: **We don’t have job titles. Instead, it’s about the impact you have. No task is above or beneath you.

-

**AI first:** We use AI to move faster with higher-quality results. We do this across the whole company—from engineering to growth to operations.

-

**Excellence everywhere: **Everything we do should match the quality of our AI models.

-

**Global team: **We prioritize your talent, not your location.

## What we offer

-

**Innovative culture:** You’ll be part of a generational opportunity to define the trajectory of AI, surrounded by a team pushing the boundaries of what’s possible.

-

**Growth paths: **Joining ElevenLabs means joining a dynamic team with countless opportunities to drive impact - beyond your immediate role and responsibilities.

-

**Learning & development**: ElevenLabs proactively supports professional development through an annual discretionary stipend.

-

**Social travel**: We also provide an annual discretionary stipend to meet up with colleagues each year, however you choose.

-

**Annual company offsite: **Each year, we bring the entire team together in a new location - past offsites have included Croatia and Italy.

-

**Co-working**: If you’re not located near one of our main hubs, we offer a monthly co-working stipend.

This role is remote but the successful candidate should be based in Germany or surrounding area.

## About the role

As a Solutions Engineer, you'll work as part of a driven team to unlock the full potential of our voice AI platform for a growing customer base. Your mission is to efficiently scale our technical solutions to many enterprise customers, both directly and by improving our internal processes and supporting our sales teams.

As a Solutions Engineer, you can expect to:

-

Collaborate strategically with Account Executives to enhance the technical aspects of the sales process.

-

Work directly with technical contacts from our customers and prospective customers to provide bespoke support and architect solutions.

-

Craft compelling technical demonstrations that clearly communicate our product's value proposition.

-

Create technical enablement resources that amplify our sales team's effectiveness and technical fluency.

-

Build self-service tools and documentation that empower customers to implement solutions independently.

-

Identify opportunities to productize common integration patterns or features, and work with our product teams to make these real!

## **Requirements**

We're looking for exceptional individuals who excel at working with customers on technical problems and excited to work with us to scale this efficiently. You'll thrive with us if you:

-

Are passionate about AI, technology and ElevenLabs products.

-

Enjoy working directly with customers, iterating on solutions and providing tailored support

-

Have a talent for identifying patterns that can be standardized and scaled.

-

Have strong empathy for customers, sales and product teams.

-

Have a strong technical background in order to help customers architect integration between our solutions and their existing solutions

-

Experience working with customers. It’s ok if you only worked with customers in student clubs or side projects, as long as you are interested in working closely with them on a technical capacity

-

Proficiency in Python, inclusive of a deep understanding of software development, software architecture, and common integration patterns.

-

Excellent communication skills with the ability to adapt messaging to different audiences.

#LI-Remote
