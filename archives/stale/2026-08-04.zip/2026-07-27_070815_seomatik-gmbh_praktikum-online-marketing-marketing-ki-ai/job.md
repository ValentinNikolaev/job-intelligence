# Praktikum Online-Marketing / Marketing / KI / AI

Posted: 2026-07-27T04:00:59Z

Die SEOMATIK GmbH ist eine der führenden Online-Marketing-Agenturen in Europa.

Als Full-Service-Agentur in der digitalen Vermarktung von Produkten und Websites liegen unsere Kernkompetenzen in den Bereichen Suchmaschinenoptimierung (SEO), Suchmaschinenwerbung (SEA) und Social Media Marketing (SMM).

Aktuell bieten wir folgende Position:

Praktikum Online-Marketing / Marketing / StartUp (KI / AI)

## Aufgaben

Zu den Aufgaben im Praktikum gehören u.a. nachfolgenden Themen:

- Suchmaschinenoptimierung (SEO)

- KI Optimierung (GEO)

- Suchmaschinenwerbung (SEA)

- Webdesign

- Content Marketing

- Social Media Marketing (SMM)

- Konzeptionierung

-uvm.

## Qualifikation

- ein laufendes oder abgeschlossenes Studium,

- Kreativität,

- Teamfährigkeit,

- Motivation,

- und HUMOR (sehr wichtig!) :)

## Benefits

- spannende Projekte,

- grosses Lernpotential,

- familiäre Athmosphäre,

- offener Umgang,

- Nebentätigkeit nach Abschluss Praktikum,

- Zukunftschancen.

Wir freuen uns über Deine Bewerbung :)

LG Agnes Kmety

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
