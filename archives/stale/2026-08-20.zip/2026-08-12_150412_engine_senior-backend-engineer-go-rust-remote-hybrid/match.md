# Match Analysis

**Score:** 74/100  
**Recommendation:** Match

Senior Backend Engineer (Go/Rust) — Remote & Hybrid at Engine has relevant backend evidence, with role-specific requirements assessed from the sealed posting.

## Why it matches

- Documented senior backend experience across Go and PHP, APIs, scalable services, and production reliability.
- Relevant architecture, database, cloud, monitoring, and troubleshooting experience is supported by the candidate profile.

## Gaps

- Some role-specific technologies, domain requirements, or infrastructure details are not explicitly evidenced in the candidate profile.

## Concerns

- The syndicated or abbreviated posting leaves some employer, timezone, eligibility, or complete-requirement details uncertain.
