# Match Analysis

**Score:** 78/100  
**Recommendation:** Match

Senior Go Backend Engineer — Remote at United States Digital Space LLC has relevant backend evidence, with role-specific requirements assessed from the sealed posting.

## Why it matches

- Documented senior backend experience across Go and PHP, APIs, scalable services, and production reliability.
- Relevant architecture, database, cloud, monitoring, and troubleshooting experience is supported by the candidate profile.

## Gaps

- Some role-specific technologies, domain requirements, or infrastructure details are not explicitly evidenced in the candidate profile.

## Concerns

- The syndicated or abbreviated posting leaves some employer, timezone, eligibility, or complete-requirement details uncertain.
