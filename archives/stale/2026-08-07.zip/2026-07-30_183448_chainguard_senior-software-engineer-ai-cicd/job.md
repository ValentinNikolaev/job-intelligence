# Senior Software Engineer (AI CICD)

Posted: 2026-07-30T14:39:53Z

Chainguard is the trusted source for open source. By delivering hardened, secure, and production-ready builds of all the open source software engineers and AI agents rely on, Chainguard helps organizations build faster, stay compliant, and eliminate risk.
Our customers include Fortune 500 enterprises and global industry leaders, including Anduril, Canva, Fortinet, Hewlett Packard Enterprise, OpenAI, Snap Inc., and Snowflake.
Chainguard is venture-backed by leading investors, including Amplify, IVP, Kleiner Perkins, Lightspeed Venture Partners, Mantis VC, Redpoint Ventures, Sequoia Capital, and Spark Capital.

**Senior Software Engineer, AI CICD**

**The role, in a nutshell:**

At Chainguard we’re focused on securing the software supply chain, and we're building the next generation of products at the intersection of security and AI. You'll join a small, fast-moving team shipping tools that developers will actually use.

The successful candidate will work on new products including the [Guardener](https://www.chainguard.dev/unchained/meet-the-guardener), hardened [Github Actions](https://www.chainguard.dev/unchained/introducing-chainguard-actions), [Chainguard Agent Skills](https://www.chainguard.dev/unchained/introducing-chainguard-agent-skills), and more. You'll collaborate closely with team members and Product, guide technical decisions, and promote a culture of excellence.

**What you’ll do:**

- Own features end-to-end. From design through implementation, rollout, and iteration in close partnership with Product and our Experience (front-end) team.

- Navigate ambiguous problems and find a clear path forward. You take initiative rather than waiting for complete specs.

- Contribute to a product-driven roadmap with real deadlines: help the team prioritize tradeoffs and ship iteratively rather than waiting for perfect.

- Extend Chainguard's agentic AI foundation into customer-facing product experiences across the full product suite.

- Bring a strong technical point of view to architectural decisions and a collaborative spirit when working through them with the team.

**What we're looking for:**

- Bachelor's degree or equivalent practical experience

- 5+ years of experience in software development

- Expertise with containers, artifact registries, Docker, Kubernetes and its greater ecosystem

- Experience building and securing CI/CD systems

- Proficiency with Go (Golang) or strong readiness to ramp quickly.

- Experience with AI tooling and a genuine enthusiasm for applying it to complex problems

- Enthusiasm to work closely with the Product team and customers to launch new features

- Strong communication skills, proficiency in English, ability to work autonomously, take initiative, and seek help proactively when necessary.

**Explore Our Work**

Dive into the practical side of what we do at Chainguard. These resources provide a hands-on look at our processes and offer an opportunity for in-depth understanding of our product offerings and the technology behind them.

- [Chainguard Academy ](https://edu.chainguard.dev/)

- [https://www.chainguard.dev](https://www.chainguard.dev/)

Base Salary Range

$157,000—$184,000 USD

## About Us

We live and breathe our company values:

- We are customer obsessed — We focus on delivering solutions to our customers that create value and make their lives better.

- We have a bias for intentional action — We prioritize, plan, try things, and fail fast.

- We don't take ourselves too seriously (but we do serious work) — We are solving an important problem which takes focus, but we also like to enjoy the journey.

- We trust each other and assume good intentions — We're transparent with decisions to empower team members to make well informed decisions.

A few of the benefits we offer:

- **Flexible & Remote-First Culture:** Work remotely with team meetup opportunities, bi-annual destination summits, and a monthly stipend for coworking spaces, phone and internet costs.

- **Our Approach to Equity:** Receive stock options upon hire and promotion. Plus, you can participate in secondary offerings and have 10 years to exercise your options (yes, you read that correctly: 10 years!).

- **100% Covered Health Insurance:** We cover 100% of your health, vision and dental insurance premiums for you and your dependents. Nothing comes out of your paycheck.

- **∞ Flexible Time Off:** Take the time you need – to do our best work, we need to recharge and reset.

- **18 Weeks Paid Parental Leave:** We offer 18 weeks for birthing parents and 12 weeks for non-birthing parents, with the option to use it all at once or throughout your child's first year.

If your experience is close but doesn't fulfill all requirements, please apply. We're building the best team in technology and are focused on hiring "Chainguardians" with unique backgrounds, perspectives, and experiences.

Chainguard is an equal opportunity employer. We do not discriminate based upon race, religion, color, national origin, sex (including pregnancy, childbirth, reproductive health decisions, or related medical conditions), sexual orientation, gender identity, gender expression, age, status as a protected veteran, status as an individual with a disability, genetic information, political views or activity, or other applicable legally protected characteristics. We also consider qualified applicants with criminal histories, consistent with applicable federal, state and local law.

By submitting your application, you acknowledge that Chainguard will process your personal data in accordance with [Chainguard's Global Candidate Privacy Notice](https://www.chainguard.dev/legal/candidate-privacy-notice).

©2026 Chainguard. All Rights Reserved.
