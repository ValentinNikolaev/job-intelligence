# Senior AI Engineer

Posted: 2026-07-30T08:55:55Z

**WongDoody **creates human experiences at 24 studios across 4 continents. We believe the future can be molded. And by shaping human experiences through creativity and tech, we work to build a future we believe in.

For us, this starts with our own culture. We strive to create an inclusive environment where every human can bring their whole self to work. Our clients are brands we believe in, from global big players to local heroes to startups we love. With each of our partners, we embark on a journey of co-creation, pushing the boundaries of what's possible and exploring the space where creativity and tech meet.

Our team of fun, welcoming, values-driven, and collaborative problem solvers has one focus at the heart of everything we do: human experience. Human experiences are the touchpoints where brands connect with customers. And we transform businesses by creating engaging, inspiring moments using strategy, creativity, data and technology - all backed by the global technological power of Infosys.

**Experience, Tech & AI **

We are a cross-unit and cross-location AI, tech and experience team. With more than 50 developers, AI & Fullstack engineers, UX designers and consultants working directly with other WongDoody teams, we are team players and specialists - oth in frontend and backend. As part of Infosys, we belong to a leading global technology company with access to solutions and extensive know-how in the fields of commerce, marketing automation and AI, among others.

We are now looking for a Senior AI Engineer who combines strong engineering fundamentals with a pragmatic delivery mindset—turning ambitious ideas into stable, scalable AI systems.

**Our local benefits **

- Flexible working hours and 100% overtime compensation
- Work where it works for you. At home or in the office, or any mix you like
- Working for strong brands and clients we believe in
- 30 days vacation per year
- Company Benefits
- Urban Sports Club
- Nice people in welcoming teams

**What you can expect **

AI Systems & Service Architecture

- Design and build production-ready AI services and backend systems
- Develop APIs, orchestrations, and integrations for GenAI and LLM-based applications
- Create technical foundations that enable teams to build, scale, and operate reliably
- Contribute to RFPs, pitches, and forward-looking AI solution concepts

Reliability, Scale & Performance

- Ensure AI solutions run reliably, perform efficiently, and remain cost-effective
- Make architectural decisions around scalability, monitoring, security, and maintainability
- Optimize systems across quality, latency, operational cost, and developer experience

Technical Leadership & Collaboration

- Work closely with Creative Technologists, Product, Design, and Engineering
- Lead technical discussions and bring clarity to complex initiatives
- Support other engineers through reviews, sparring, and best practices
- Engage in client-facing conversations and explain technical concepts to senior stakeholders

**What we'd love to see **

- A passion for creative technology, curiosity for emerging AI tools, and the ability to turn ideas into working prototypes
- Analytical and structured mindset with the ability to make complexity simple
- End-to-end architecture from prototyping to production (including CI/CD, logging, analytics, and scaling)
- Several years of experience building production-grade AI or backend systems
- Strong experience in software engineering (Python and/or TypeScript)
- Practical knowledge of LLM frameworks,tools and protocols (LangChain, LangGraph, n8n, MCP, A2A, Bedrock, or similar) including agentic architectures
- Experience in integrating visual AI tools such as ComfyUI, Stable Diffusion, Google Imagen, or Adobe Firefly into broader workflow systems
- Proven experience integrating text-based AI APIs like ChatGPT, Claude, Gemini, or Llama into end-to-end workflow solutions
- Familiarity with prompting techniques, RAG pipelines, and AI workflow orchestration including guidance/guardrails, observability (P95, cost/request), evaluation pipelines
- Understanding of real-time communication protocols (Websocket / gRPC / PubSub event handling) and API integration across data and creative environments
- Competence in infrastructure setup (Docker, Terraform, cloud platforms like GCP, AWS, or Azure), understanding the resources cost factor and ability to optimize it
- Open-source engagement or hands-on experimentation with AI agents, visual frameworks, or orchestration systems
- Excellent English communication skills (German is a plus)
- Work permit for Germany and at least one year of work onsite in Germany
- Nice to have: Experience with IBM watsonx / Watson AI or related enterprise AI ecosystems

**Your impact **

You’ll shape the future of AI agent experiences and scalable AI systems that work reliably in production environments, create standards, and transform complex systems into meaningful, measurable experiences - for users, brands, and products.

Please note: This is a job ad by WongDoody GmbH, based in Germany. Through our website or other sources, you may find job ads published by one of our WongDoody sister companies around the globe with whom we act jointly under the brand “WongDoody”. For each job offer, only the entity which published the ad is responsible. Contact people, required information and applicable terms may differ. Read more about how WongDoody GmbH processes your personal data in the application process [here](https://www.wongdoody.com/de-privacy).

If you have any questions about the application process, please feel free to contact our People & Culture Team directly at -----

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
