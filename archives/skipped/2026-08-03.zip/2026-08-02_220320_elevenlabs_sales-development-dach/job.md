# Sales Development - DACH

Posted: 2026-08-02T20:41:13Z

## About ElevenLabs

ElevenLabs is an AI research and product company transforming how we interact with technology.

We launched in January 2023 with the first human-like AI voice model. Today, we serve millions of users and thousands of businesses - from fast-growing startups to large enterprises like Deutsche Telekom and Meta. Our investors are some of the world's most prominent, including Andreessen Horowitz, ICONIQ Growth and Sequoia. We've raised $781M in funding and our last valuation was $11B - multiples of 11, always.

We have expanded from voice into three main platforms:

-

ElevenAgents enables businesses to deliver seamless and intelligent customer experiences, with the integrations, testing, monitoring, and reliability necessary to deploy voice and chat agents at scale.

-

ElevenCreative empowers creators and marketers to generate and edit speech, music, image, and video across 70+ languages.

-

ElevenAPI gives developers access to our leading AI audio foundational models.

Everything we do is the result of the creativity and commitment of our team - builders doing the best work of their lives. We are researchers, engineers, and operators. IOI medalists and ex-founders. If you want to work hard and create lasting positive impact, we want to hear from you.

## How we work

-

**High-velocity: **Rapid experimentation, lean autonomous teams, and minimal bureaucracy.

-

**Impact not job titles: **We don’t have job titles. Instead, it’s about the impact you have. No task is above or beneath you.

-

**AI first:** We use AI to move faster with higher-quality results. We do this across the whole company—from engineering to growth to operations.

-

**Excellence everywhere: **Everything we do should match the quality of our AI models.

-

**Global team: **We prioritize your talent, not your location.

## What we offer

-

**Innovative culture:** You’ll be part of a generational opportunity to define the trajectory of AI, surrounded by a team pushing the boundaries of what’s possible.

-

**Growth paths: **Joining ElevenLabs means joining a dynamic team with countless opportunities to drive impact - beyond your immediate role and responsibilities.

-

**Learning & development**: ElevenLabs proactively supports professional development through an annual discretionary stipend.

-

**Social travel**: We also provide an annual discretionary stipend to meet up with colleagues each year, however you choose.

-

**Annual company offsite: **Each year, we bring the entire team together in a new location - past offsites have included Croatia and Italy.

-

**Co-working**: If you’re not located near one of our main hubs, we offer a monthly co-working stipend.

## **About the role**

Our Sales Development team play a crucial role in building an effective outbound sales strategy, whilst working closely with the Account Executives.

We don’t just sell a product or custom-level solutions; we are partnering with enterprises to help them generate new experiences and monetisation opportunities at scale with our breakthrough voice technology.

In this role you will:

-

Conduct research to identify potential leads and prospects within the target market

-

Engage in outbound activities such as cold calling, emailing, and social media outreach to initiate contact with potential customers

-

Implement personalized and effective outreach campaigns to maximize lead conversion.

-

Collaborate closely with the Account Executive to exchange insights on prospect feedback, objections, and market trends

-

Continuously refine and adjust outreach strategies based on the feedback loop

-

Monitor and report key performance indicators (KPIs) related to outbound sales activities, including conversion rates, lead quality, and outreach effectiveness

-

Collaborate with the sales leadership to analyze data and optimize strategies for better results

## **Requirements**

-

2–3+ years of outbound B2B sales experience, with a strong track record of securing net-new business meetings

-

Proven ability to build and qualify opportunity-sized lead lists in new markets and verticals

-

Fluency with modern prospecting tools and multi-channel outreach strategies

-

Experience building and scaling outbound processes in fast-paced environments

-

Intellectually curious, asking thoughtful questions and developing insights-driven approaches to outreach

-

Highly self-motivated, able to work independently while thriving in a collaborative team culture

-

Strong prioritization and time management skills, with the ability to handle a high volume of leads efficiently

-

Excellent written and verbal communication skills in both German and English

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
