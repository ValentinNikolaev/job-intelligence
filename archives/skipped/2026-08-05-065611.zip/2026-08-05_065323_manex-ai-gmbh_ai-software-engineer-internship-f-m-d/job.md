# AI Software Engineer - Internship (f/m/d)

Posted: 2026-08-05T02:40:35Z

# AI Software Engineer - Internship (f/m/d)

**About Us**
Manex AI is on a mission to enable autonomy for the world's leading organizations, currently building the production system for the era of autonomous manufacturing. With our Seed Round raised from Lightspeed and BlueYard and leading manufacturing enterprises relying on our systems, we are now scaling fast. For our world-class team, we are looking for exceptionally driven students who want real ownership early.

**Your Role**
You will build the software and AI applications that power autonomous manufacturing. You work on our platform "Kosmos" alongside our engineers, shipping features and AI-driven solutions that go straight into live production environments at industry leaders including BMW, Audi, BSH, Stellantis, Still, TDK Electronics, and Co.

From your first week, you own pieces of real problems. You write code that goes into production, you see your work run inside real factories, and you learn exactly how technical decisions create measurable impact for some of the most demanding manufacturers in the world.

For interns who deliver, this is the fastest path into a full-time engineering role.

**Your Responsibilities**

-

Build software and AI application features within real customer projects

-

Work alongside senior engineers to troubleshoot, document, and ship solutions

-

Support the technical integration of our platform into customer environments

-

Turn concrete customer requirements into working technical solutions

-

Learn how production processes, IT infrastructure, and AI products come together

**Your Profile**

-

Currently studying Computer Science, Information Systems, or similar, towards the end of your Bachelor's or the start of your Master's

-

Strong hands-on coding ability, proven through your own projects, ventures, or open-source work

-

An ownership mindset: you take initiative, move fast, and finish what you start

-

Ideally strong experience in Python, TypeScript and Docker

-

Fluent in English and ideally in German as well

-

Based in Munich or willing to relocate for the duration of the internship

We appreciate your application even if you don't tick all the boxes.

**What We Offer**

-

Real ownership from day one

-

A fast-track into a full-time role

-

Direct mentorship from senior engineers and direct access to founders

-

Hands-on experience onsite with real customers, real production systems, and frontier AI

-

A fast-paced environment backed by the world's best investors, with the world's leading organizations as customers

Want to build real things at the edge of industrial AI? Apply now.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
