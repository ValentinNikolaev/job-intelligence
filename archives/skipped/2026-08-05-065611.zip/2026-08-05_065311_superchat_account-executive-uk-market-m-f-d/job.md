# Account Executive | UK Market (m/f/d)

Posted: 2026-08-05T05:55:37Z

**At Superchat, we're rebuilding how businesses talk to their customers. The phone call, the contact form, the support ticket: all of it is being replaced by messaging and AI. We're building the platform that runs underneath.**

Founded in 2020, Superchat has become the platform of choice for **10,000+ businesses worldwide**, from globally recognized brands like Allianz, Auto1, Enpal, Danone, and GASAG to the small businesses, dental practices, and one-person startups that need to look bigger than they are. Today, **millions of messages flow through Superchat every single day**.

We started as a unified inbox: one place for every channel a customer might pick, WhatsApp, email, SMS, Instagram. Then ChatGPT happened, and the second chapter began: AI agents that respond across chat, email, and voice at the quality of the best human teams.

We're **100 people**, **profitable**, and have raised **€18M in funding** (last round 4.5 years ago, we've been growing on our own money since). Headquartered in Berlin.

*In this role, you'll own the full sales cycle in the UK market. You'll handle warm inbound enquiries while proactively prospecting new leads yourself, book and run demo calls, and guide the process through to successful close. You'll also support technical implementation to ensure new customers get off to a strong start.*

#### **Who We Want**

**2-3 years of B2B sales experience.
**You've worked in B2B sales for several years and know the full sales cycle first-hand, from prospecting to close.

**Self-confident.
**You believe in your ability to run and close a conversation without coming across as arrogant.

**Self-starter.
**You build your own pipeline instead of waiting for inbound leads, and use a quiet week to prospect even harder.

**Coachable.
**You take direct feedback without getting defensive, and visibly apply it in your next conversation.

**Resilient.
**You bounce back quickly from a lost deal or a tough week and keep your activity levels consistently high.

**Fast learner.
**You get up to speed on a technical product quickly and can explain it to customers in a way they understand.

**Structured**.
You keep your pipeline clean and your CRM notes reliable, without anyone having to chase you.

**Strong** **communicator**.
You're a native English speaker with excellent written and verbal communication skills.

#### **Who We Don't Want**

- People who rely on leads being handed to them and can't or won't proactively acquire customers themselves

- People who get defensive with direct feedback instead of taking it on board and developing

- People with weak written communication who can't express themselves clearly and professionally

- People chasing the salary alone with no genuine interest in the craft of selling

#### **Your Day To Day**

Demos & Product Presentation (~80%)

- You convince prospects to join a product demo and book the relevant appointments

- You present Superchat's capabilities convincingly and show customers how the product solves their specific challenges

Lead Sourcing & Prospecting (~10%)

- You generate new pipeline independently, regardless of inbound leads, and identify the right target customers in the UK market

Closing (~10%)

- You convince prospects to sign a contract and successfully guide the sales cycle through to close

#### **Stakeholders**

**Customers**: your most important point of contact day-to-day - from first outreach through demos to close
**Sales Team:** for joint training, knowledge-sharing, and exchanging best practices across the sales cycle
**Customer Success Team**: for handover after a successful close and a smooth start to onboarding

#### **Why People Choose Us**

- We believe in the power of in-person collaboration: You'll work with your team from our Berlin office at least three days a week. Some of the best ideas happen when we're in the same room - decisions are made faster, we learn from each other, and we grow stronger as a team.

- We're an international team with diverse cultural backgrounds and languages. Openness, mutual respect, and the exchange of different perspectives shape the way we work together.

- We value ambition and drive. We're looking for people who take ownership, show initiative, and are excited to grow quickly.

- We work with a high degree of ownership and a strong learning mindset. Asking questions, staying curious, and continuously improving are part of our everyday culture.

- We care deeply about humility and teamwork. No egos, open feedback, and a willingness to learn from one another matter more to us than titles.

**Benefits & Culture**

- Choose between an Urban Sports Club or John Reed membership, or a public transport pass/Dance subscription.

- Regular company-wide and team events.

- An annual €500 learning and development budget that you can use for conferences, courses, books, career coaching, and more.

- An inclusive and exciting startup culture that supports rapid professional and personal growth.

- A beautiful office in the heart of Berlin (Prenzlauer Allee 242) with free snacks, drinks, and top-notch equipment.

**We want to build a community, not just a company.**

Creating an environment where people genuinely enjoy spending time together is important to us - whether that's through HYROX training, golf, beer pong tournaments, running clubs, Warhammer, weekend activities, or any other community you'd like to build here.

**We believe that diversity makes companies stronger. We welcome applications from everyone, regardless of gender, background, nationality, or religion. Feel free to apply - we'd love to hear from you!**

**By submitting your application, you agree to our Privacy Policy.**

**We look forward to receiving your application! 🙂**

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
