# Forward Deployed Engineer - Internship (f/m/d)

Posted: 2026-08-05T02:40:35Z

## Forward Deployed Engineer - Internship (f/m/d)

**About Us**

Manex AI is on a mission to enable autonomy for the world's leading organizations, currently building the production system for the era of autonomous manufacturing. With our Seed Round raised from Lightspeed and BlueYard and leading manufacturing enterprises relying on our systems, we are now focused on scaling operations across all departments. For our world-class team, we are looking for experts and talent that is ambitious enough to tackle some of the world’s most pressing and complex problems.

**Your Role**

As a Forward Deployed Engineer Intern, you work at the core of our customer delivery, alongside our engineers who are embedded in the production environments of our industry-leading customers. You build software and AI applications on our platform "Kosmos" that ship into live customer projects. From your first week, you own real problems and see how your technical decisions create measurable impact for some of the most demanding manufacturers in the world.

For interns who deliver, this is the fastest path into a full-time Forward Deployed Engineer role.

**Your Responsibilities**

-

Build software and AI application features within real customer projects

-

Work alongside senior engineers to troubleshoot, document, and ship solutions

-

Support the technical integration of our platform into customer environments

-

Turn concrete customer requirements into working technical solutions

-

Learn how production processes, IT infrastructure, and AI products come together

**Your Profile**

-

Currently studying Computer Science, Information Systems or similar in your Masters or towards the end of your Bachelor's

-

Strong hands-on coding ability, proven through your own projects, ventures, or open-source work

-

An agentic mindset: you take initiative, move fast, and finish what you start

-

Ideally strong experience in Python, TypeScript and Docker

-

Fluent in English and ideally in German as well

-

Based in Munich or willing to relocate for the duration of the internship

If you don't tick all the boxes, we would appreciate your application as well.

**What We Offer**

-

Real ownership from day one

-

A fast-track into a full-time Forward Deployed Engineer role

-

Direct mentorship from senior engineers and direct access to founders

-

Hands-on experience onsite with real customers, real production systems, and frontier applied AI

-

A fast-paced environment backed by the world's best investors, with the world's leading organizations as customers

Want to build real things at the edge of industrial AI? Apply now.

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
