# Business Development Representative BDR (German-speaking)

Posted: 2026-08-04T23:41:07Z

**About BoWatt**

BoWatt is building **agentic requirements and system engineering software for manufacturing**. We believe AI will reach **PhD-level engineering capability within the next 10 years**. This will unlock massive value across several complex manufacturing industries. Cars. Planes. Rockets. Factories. Chips. Medical devices. All will be engineered with agents.

We bootstrapped BoWatt to **€500k+ ARR** before raising our first round.

BoWatt is backed by **tier-1 investors,** including Atlantic Foodlabs, Buildery (CDTM affiliates), and Prequel Ventures, along with angels from Cohere and Luminovo.

You’ll join a small, exceptional team of startup builders, driven by innovation and execution.

Over half the team are former founders across DeepTech AI, psychedelics, and gaming.

We’ve studied and worked at top institutions and companies like **Stanford**, **TUM**, **Google**, **EA**, and **YC**-backed AI startups.

**The role**

-

Own outbound prospecting - cold email, LinkedIn, cold calling — to generate a qualified lead pipeline

-

Convert inbound leads into booked demos, fast and reliably

-

Build and refine our outreach playbook - messaging, sequences, positioning

-

Sit in on every demo to understand how we sell and what customers care about

-

Track your activity in the CRM and flag what's working and what isn't

-

Nurture long-term plays. Keep lower-priority accounts in motion with thoughtful follow-ups and signal-based reactivations

-

Work shoulder-to-shoulder with our Founder Steven — no layers, no bureaucracy

**You**

-

You are able to easily shake off rejection

-

You write clearly, speak confidently, and know how to get to the point

-

You're curious about what customers actually need - not just hitting dial quotas

-

You're energised by ambiguity, not slowed down by it

-

You want to grow into closing deals - the Account Executive path excites you

-

You are self-motived - hunger matters more than pedigree

**Requirements**

-

Prior experience in a startup or sales internship

-

4 days per week in the office in Munich (Meta Office, Balanstraße)

-

Fluent German required; English is our internal working language

-

Prior experience in manufacturing is a bonus

**What we offer**

-

Competitive salary based on experience (base salary of 55–75k € depending on experience, plus uncapped commission)

-

25 vacation days/per yr + plus public holidays

-

WellPass membership

**Interview process**

-

30min Screening call (Nat or Malte)

-

1.5hr Sales Interview (CEO + team member)

-

1hr Culture fit interview (CEO + CPO)

-

Offer and reference checks

We aim to complete the interview process within 14 days.

Compensation: €55K – €75K • Offers Commission

- • €55K – €75K • Offers Commission

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
