# Junior Software Engineer (Flutter/Python)

Posted: 2026-08-05T05:27:52Z

Bloom Future is a startup building a digital career-orientation app for students, schools, and employers. Based at Campus Founders in Heilbronn, we help young people make more informed decisions about their professional future.

We are hiring a product-minded engineer to help build the mobile experiences and technical systems behind it.

## Tasks

You will work across our Flutter application and FastAPI backend, taking features from problem definition through implementation and release.

We are looking for strong engineering fundamentals, evidence that you can ship working software, and the judgment to make sensible product and technical decisions. You should be effective in at least one area of the stack and capable of becoming productive across both.

This is a hands-on role with meaningful responsibility. You will be expected to investigate problems independently, form clear opinions, and take responsibility for the quality of your work.

**What you'll do**

- Build end-to-end product features across our Flutter app, APIs, and database.

- Improve interactive career-exploration, profile, and recommendation experiences.

- Design and maintain APIs, data models, and external integrations.

- Diagnose problems across mobile, backend, data, and infrastructure.

- Propose and implement improvements to UX, architecture, reliability, and performance.

- Write tests, review code, and support the release of production changes.

## Requirements

**Our Stack:**

Mobile: Flutter and Dart

Backend: Python and FastAPI

Data: PostgreSQL and Supabase

Infrastructure: Docker and cloud services

Interfaces: REST APIs, WebSockets, and external integrations

**What we’re looking for**

- Strong fundamentals in at least one modern programming language.

- Evidence that you have built and completed a substantial application or software project.

- Practical understanding of REST APIs, relational databases, testing, and Git.

- Strong debugging skills and the ability to understand unfamiliar systems.

- Attention to product behaviour, usability, and interaction details.

- Ability to evaluate alternatives and explain your decisions clearly.

- Initiative, good judgment, and willingness to raise problems early.

- Good English for technical collaboration. German is a plus.

This is an early-career role, typically suited to someone with around one to two years of experience. Substantial internship, working-student, open-source, university, or independent project experience may also qualify.

**Nice-to-have**

- Flutter or another mobile framework.

- FastAPI or another backend framework.

- PostgreSQL or Supabase.

- Automated testing, CI/CD, Docker, or cloud deployment.

- AI-powered, data-driven or user-facing products.

## Benefits

**What we offer**

- Ownership of work that reaches real users.

- Influence over both product and technical decisions.

- Close collaboration and short decision-making paths.

- Hybrid working at Campus Founders in Heilbronn.

- A motivated, international team working on a meaningful product.

Send us your CV or LinkedIn profile and a project or portfolio you are proud of. Briefly explain:

- What you built and your contribution.

- One important technical or product decision you made.

- What you would do differently now.

We are interested in the quality of your work and reasoning, not a checklist of technologies.

Find more [English Speaking Jobs in Germany](https://www.arbeitnow.com/english-speaking-jobs) on Arbeitnow
