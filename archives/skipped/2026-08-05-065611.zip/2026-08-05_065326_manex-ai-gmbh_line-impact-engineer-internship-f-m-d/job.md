# Line Impact Engineer - Internship (f/m/d)

Posted: 2026-08-05T02:40:35Z

**OUR MISSION**

Manex AI is on a mission to enable autonomy for the world’s leading organizations and is currently building autonomous factories. After raising our Seed Round from Lightspeed and BlueYard and winning leading enterprise manufacturing customers, we are now focused on scaling operations across all departments. With our world-class team, we are looking for the key individuals who will help take us to the next level and build a truly outstanding organization.

## **Your Role**

As a Line Impact Intern, you’ll take part in complex customer projects and make sure our platform delivers real results on the factory floor. You combine a hands-on mentality with good stakeholder management, analytical abilities, and understanding of manufacturing. You will work with our leadership and project teams from day 1 and become a great contributor for our success.

**WHY JOIN US?**

**PICTURE THIS**

-

You will get to be involved in customer projects and take over a customer facing role

-

You will majorly contribute to our client's success in their plants and become a key role within customer teams

-

You will take over ownership from day for your tasks and are incentivized to showcase self-initiative

-

You are directly part of a team that loves solving hard problems, building products that matter, and where knowledge flows fast

-

You will act on behalf of the entire company, beyond just your own team

-

You’ll be part of a high-growth company backed by top-tier investors

**YOUR ROLE**

-

Contributor to customer projects and customer integrations across industries

-

Work with our solution side-to-side with customer stakeholders

-

Evaluate software performance and feedback into the product and project team

-

Run data analysis to present daily results

-

Ensure our success by working hands-on with all stakeholders from Manex AI and the customer

**WHAT SETS YOU UP FOR SUCCESS**

-

Bachelor / Masters studies in Industrial Engineering, Mechanical Engineering, Information Systems, Economics, or similar

-

First professional experience through internships in automotive, manufacturing, consulting or tech

-

Basic Understanding of manufacturing and production processes

-

Good communication and stakeholder management skills

-

Very motivated, ready to go all-in & work hands-on

-

Business-fluent in German and English

-

Based in Munich or willing to relocate for the internship

**WHAT WE OFFER**

-

Compensation: 3.000€ Brutto

-

Mentorship & fast learning curve in a high-impact AI-Startup environment (Working side-by-side with our Founders)

-

Flat hierarchy, direct access to founders, fast decisions

-

Join one of Europe’s most driven and ambitious teams

-

EGYM Wellpass & Deutschlandticket

**HIRING PROCESS**

-

Intro Call (30 min) – culture & fit

-

Leadership Session (30 min) – project, problem-solving and fit

-

Offer – typically within one week

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
