# Founding Account Executive, Head of Sales Track (German-speaking)

Posted: 2026-08-04T23:41:07Z

**About BoWatt**

BoWatt is building **agentic requirements and system engineering software for manufacturing**. We believe AI will reach **PhD-level engineering capability within the next 10 years**. This will unlock massive value across several complex manufacturing industries. Cars. Planes. Rockets. Factories. Chips. Medical devices. All will be engineered with agents.

We bootstrapped BoWatt to** €500k+ ARR** before raising our first round. BoWatt is backed by** tier-1 investors**, including Atlantic Foodlabs, Buildery (CDTM affiliates), and Prequel Ventures, along with angels from Cohere and Luminovo.

You’ll join a small, exceptional team of startup builders, driven by innovation and execution. **Over half the team are former founders** across DeepTech AI, psychedelics, and gaming. We’ve studied and worked at top institutions and companies like** Stanford, TUM, Google, EA**, and** YC**-backed AI startups.

**The role**

-

Responsible for qualifying and closing new pilot customers, from large Mittelstand companies to Tier-1 enterprises in the DACH region and beyond

-

Run product demos tailored to each customer's specific pain points

-

Build the business case and quantify the ROI for each demo client

-

Own and manage your pipeline end-to-end

-

Develop deep expertise in BoWatt's software, customers, and target industries

-

Work with BDRs who help feed the top of your funnel

-

First 6 months: intensive training and close collaboration with the CEO to build the industry knowledge and context needed to succeed in the role

**You**

-

You are able to easily shake off rejection

-

You write clearly, speak confidently, and know how to get to the point

-

You are able to adapt and develop practical solutions for each situation - every customer has unique challenges and goals

-

You want to grow into a domain expert - software, customers, and industry

-

You are ambitious, proactive, and willing to go the extra mile to achieve results

**Requirements**

-

At least 1 year of closing experience in B2B software sales, ideally in an industrial or technical environment

-

Alternatively, experience in technical sales or other sales position at an industrial manufacturer

-

Experience working with CRM systems (e.g. Pipedrive) and sales metrics

-

4 days per week in the office in Munich (Meta Office, Balanstraße)

-

Fluent German required; English is our internal working language

-

Manufacturing and/or startup experience is a bonus

**What we offer**

-

Competitive salary based on experience (base salary, plus uncapped commission)

-

25 vacation days/per yr, plus public holidays

-

Company retreats

-

WellPass membership

**Interview process**

-

30min Screening call (Nat or Malte)

-

1.5hr Sales Interview (CEO + team member)

-

1hr Culture fit interview (CEO + CPO)

-

Offer and reference checks

We aim to complete the interview process within 14 days.

Find [Jobs in Germany](https://www.arbeitnow.com) on Arbeitnow
